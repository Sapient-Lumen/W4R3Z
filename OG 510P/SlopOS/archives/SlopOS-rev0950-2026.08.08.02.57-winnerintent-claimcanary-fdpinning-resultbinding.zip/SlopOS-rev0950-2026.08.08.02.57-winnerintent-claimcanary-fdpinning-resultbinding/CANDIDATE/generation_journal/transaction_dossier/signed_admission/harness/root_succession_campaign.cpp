#include "slopos/e0/signed_admission/root_succession.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <openssl/evp.h>

namespace slopos::e0::signed_admission::root_succession {
namespace {

constexpr std::uint64_t kObservedTime = 1'800'000'000U;
constexpr std::uint64_t kPredecessorVersion = 7U;
constexpr std::string_view kEnvelopeIntegrityDomain =
    "SlopOS/root-succession/envelope-integrity/v1";

struct FixtureKey final {
    std::array<std::uint8_t, 32U> seed{};
    KeyV1 public_part{};
};

struct ManifestFixture final {
    OwnerManifestV1 logical{};
    EncodedManifest encoded{};
    std::array<FixtureKey, kMaximumKeys> keys{};
};

struct CompleteFixture final {
    ManifestFixture predecessor{};
    ManifestFixture successor{};
    RootSuccessionStatementV1 statement{};
    EncodedRootStatement statement_bytes{};
    EncodedRootEnvelope envelope{};
    CurrentRootRegisterV1 root_register{};
};

struct Case final {
    std::string name;
    EncodedManifest predecessor{};
    EncodedManifest successor{};
    EncodedRootEnvelope envelope{};
    CurrentRootRegisterV1 root_register{};
    std::uint64_t observed_time{kObservedTime};
    ReplyCut reply_cut{ReplyCut::reply_delivered};
    EvidenceCode expected_evidence{EvidenceCode::invalid_envelope};
    ApplyCode expected_apply{ApplyCode::invalid_evidence};
    bool expected_valid{false};
    bool expected_committed{false};
    bool expected_query_only{false};
};

[[noreturn]] void stop(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) stop(detail);
}

[[nodiscard]] Digest domain_digest(
    const std::string_view domain,
    const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(domain.size() + 1U + payload.size());
    bytes.insert(bytes.end(), domain.begin(), domain.end());
    bytes.push_back(0U);
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return generation_journal::sha256(bytes);
}

template <std::size_t N>
void put_digest(
    std::array<std::uint8_t, N>& bytes,
    const std::size_t offset,
    const Digest& digest) {
    std::copy(digest.begin(), digest.end(),
              bytes.begin() + static_cast<std::ptrdiff_t>(offset));
}

void rehash_envelope(EncodedRootEnvelope& bytes) {
    put_digest(bytes, 992U, domain_digest(
        kEnvelopeIntegrityDomain,
        std::span<const std::uint8_t>(bytes.data(), 992U)));
}

[[nodiscard]] FixtureKey make_key(const std::string_view label) {
    FixtureKey result;
    const Digest seed = transaction_dossier::labeled_digest(
        std::string{"root-succession/test-only-private-seed/"} + std::string{label});
    std::copy(seed.begin(), seed.end(), result.seed.begin());
    EVP_PKEY* pkey = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, result.seed.data(), result.seed.size());
    require(pkey != nullptr, "fixture private key construction");
    std::size_t public_size = result.public_part.public_key.size();
    const int exported = EVP_PKEY_get_raw_public_key(
        pkey, result.public_part.public_key.data(), &public_size);
    EVP_PKEY_free(pkey);
    require(exported == 1 && public_size == result.public_part.public_key.size(),
            "fixture public key derivation");
    result.public_part.key_id = key_id_for(result.public_part.public_key);
    return result;
}

[[nodiscard]] Signature sign(
    const FixtureKey& key,
    const RootSigningMessage& message) {
    Signature signature{};
    EVP_PKEY* pkey = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, key.seed.data(), key.seed.size());
    require(pkey != nullptr, "sign private key");
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    require(context != nullptr, "sign context");
    require(EVP_DigestSignInit(context, nullptr, nullptr, nullptr, pkey) == 1,
            "sign init");
    std::size_t signature_size = signature.size();
    const int signed_ok = EVP_DigestSign(
        context,
        signature.data(), &signature_size,
        message.data(), message.size());
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(pkey);
    require(signed_ok == 1 && signature_size == signature.size(), "sign result");
    return signature;
}

[[nodiscard]] ManifestFixture make_manifest(
    const Digest& project,
    const Digest& constitution,
    const Digest& predecessor,
    const std::uint64_t version,
    const std::array<std::string_view, kMaximumKeys>& labels,
    const std::uint8_t threshold) {
    ManifestFixture fixture;
    fixture.logical.project_id = project;
    fixture.logical.constitution_id = constitution;
    fixture.logical.predecessor_manifest = predecessor;
    fixture.logical.version = version;
    fixture.logical.threshold = threshold;
    fixture.logical.key_count = static_cast<std::uint8_t>(kMaximumKeys);
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        fixture.keys[index] = make_key(labels[index]);
    }
    std::sort(fixture.keys.begin(), fixture.keys.end(),
              [](const FixtureKey& left, const FixtureKey& right) {
                  return left.public_part.key_id < right.public_part.key_id;
              });
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        fixture.logical.keys[index] = fixture.keys[index].public_part;
    }
    require(encode_manifest(fixture.logical, fixture.encoded), "encode manifest");
    return fixture;
}

[[nodiscard]] EncodedRootEnvelope make_envelope(
    const EncodedRootStatement& statement,
    const ManifestFixture& predecessor,
    const std::uint8_t predecessor_count,
    const ManifestFixture& successor,
    const std::uint8_t successor_count) {
    DualThresholdEnvelopeV1 logical;
    logical.statement = statement;
    logical.predecessor_signature_count = predecessor_count;
    logical.successor_signature_count = successor_count;
    const RootSigningMessage message = root_signing_message_for(statement);
    for (std::size_t index = 0U; index < predecessor_count; ++index) {
        logical.predecessor_signatures[index].key_id =
            predecessor.keys[index].public_part.key_id;
        logical.predecessor_signatures[index].signature =
            sign(predecessor.keys[index], message);
    }
    for (std::size_t index = 0U; index < successor_count; ++index) {
        logical.successor_signatures[index].key_id =
            successor.keys[index].public_part.key_id;
        logical.successor_signatures[index].signature =
            sign(successor.keys[index], message);
    }
    EncodedRootEnvelope encoded{};
    require(encode_root_envelope(logical, encoded), "encode root envelope");
    return encoded;
}

[[nodiscard]] CompleteFixture make_fixture(
    const std::string_view label,
    const std::array<std::string_view, kMaximumKeys>& predecessor_labels,
    const std::array<std::string_view, kMaximumKeys>& successor_labels,
    const std::uint8_t predecessor_threshold = 2U,
    const std::uint8_t successor_threshold = 2U,
    const std::uint8_t predecessor_signature_count = 2U,
    const std::uint8_t successor_signature_count = 2U) {
    CompleteFixture fixture;
    const Digest project = transaction_dossier::labeled_digest(
        std::string{"root-succession/project/"} + std::string{label});
    fixture.predecessor = make_manifest(
        project,
        transaction_dossier::labeled_digest(
            std::string{"root-succession/constitution/old/"} + std::string{label}),
        {},
        kPredecessorVersion,
        predecessor_labels,
        predecessor_threshold);
    fixture.successor = make_manifest(
        project,
        transaction_dossier::labeled_digest(
            std::string{"root-succession/constitution/new/"} + std::string{label}),
        manifest_head(fixture.predecessor.encoded),
        kPredecessorVersion + 1U,
        successor_labels,
        successor_threshold);
    fixture.statement.project_id = project;
    fixture.statement.predecessor_manifest_head =
        manifest_head(fixture.predecessor.encoded);
    fixture.statement.successor_manifest_head =
        manifest_head(fixture.successor.encoded);
    fixture.statement.precommitted_successor_head =
        fixture.statement.successor_manifest_head;
    fixture.statement.register_id = transaction_dossier::labeled_digest(
        std::string{"root-succession/register/"} + std::string{label});
    fixture.statement.ceremony_id = transaction_dossier::labeled_digest(
        std::string{"root-succession/ceremony/"} + std::string{label});
    fixture.statement.predecessor_version = kPredecessorVersion;
    fixture.statement.successor_version = kPredecessorVersion + 1U;
    fixture.statement.not_before = kObservedTime - 100U;
    fixture.statement.expires_at = kObservedTime + 100U;
    fixture.statement.transition_nonce = 9001U;
    require(encode_root_statement(fixture.statement, fixture.statement_bytes),
            "encode root statement");
    fixture.envelope = make_envelope(
        fixture.statement_bytes,
        fixture.predecessor, predecessor_signature_count,
        fixture.successor, successor_signature_count);
    fixture.root_register.register_id = fixture.statement.register_id;
    fixture.root_register.current_manifest_head =
        fixture.statement.predecessor_manifest_head;
    fixture.root_register.precommitted_successor_head =
        fixture.statement.successor_manifest_head;
    fixture.root_register.current_version = fixture.statement.predecessor_version;
    fixture.root_register.transition_ordinal = 0U;
    return fixture;
}

[[nodiscard]] EncodedRootEnvelope resign_statement(
    const CompleteFixture& fixture,
    const RootSuccessionStatementV1& statement,
    const std::uint8_t predecessor_count = 2U,
    const std::uint8_t successor_count = 2U) {
    EncodedRootStatement bytes{};
    require(encode_root_statement(statement, bytes), "re-encode root statement");
    return make_envelope(
        bytes,
        fixture.predecessor, predecessor_count,
        fixture.successor, successor_count);
}

void put_u64(std::array<std::uint8_t, 112U>& bytes,
             const std::size_t offset,
             const std::uint64_t value) {
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
        bytes[offset + index] = static_cast<std::uint8_t>(value >> shift);
    }
}

[[nodiscard]] std::array<std::uint8_t, 112U> encode_harness_register(
    const CurrentRootRegisterV1& root_register) {
    std::array<std::uint8_t, 112U> bytes{};
    std::copy(root_register.register_id.begin(), root_register.register_id.end(),
              bytes.begin());
    std::copy(root_register.current_manifest_head.begin(),
              root_register.current_manifest_head.end(), bytes.begin() + 32);
    std::copy(root_register.precommitted_successor_head.begin(),
              root_register.precommitted_successor_head.end(), bytes.begin() + 64);
    put_u64(bytes, 96U, root_register.current_version);
    put_u64(bytes, 104U, root_register.transition_ordinal);
    return bytes;
}

void write_bytes(const std::filesystem::path& path,
                 const std::span<const std::uint8_t> bytes) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(stream), "open binary output " + path.string());
    stream.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    require(static_cast<bool>(stream), "write binary output " + path.string());
}

template <std::size_t N>
void write_bytes(const std::filesystem::path& path,
                 const std::array<std::uint8_t, N>& bytes) {
    write_bytes(path, std::span<const std::uint8_t>(bytes.data(), bytes.size()));
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    require(static_cast<bool>(stream), "open text output " + path.string());
    stream << text;
    require(static_cast<bool>(stream), "write text output " + path.string());
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] std::string reply_cut_name(const ReplyCut cut) {
    return cut == ReplyCut::reply_delivered
        ? "reply_delivered"
        : "reply_lost_after_commit";
}

[[nodiscard]] Case normal_case(
    const std::string& name,
    const CompleteFixture& fixture,
    const ApplyCode apply = ApplyCode::committed,
    const bool committed = true,
    const bool query_only = false,
    const ReplyCut reply_cut = ReplyCut::reply_delivered) {
    Case result;
    result.name = name;
    result.predecessor = fixture.predecessor.encoded;
    result.successor = fixture.successor.encoded;
    result.envelope = fixture.envelope;
    result.root_register = fixture.root_register;
    result.reply_cut = reply_cut;
    result.expected_evidence = EvidenceCode::evidence_valid;
    result.expected_apply = apply;
    result.expected_valid = true;
    result.expected_committed = committed;
    result.expected_query_only = query_only;
    return result;
}

[[nodiscard]] Case invalid_case(
    const std::string& name,
    const CompleteFixture& fixture,
    const EvidenceCode expected) {
    Case result = normal_case(name, fixture);
    result.expected_evidence = expected;
    result.expected_apply = ApplyCode::invalid_evidence;
    result.expected_valid = false;
    result.expected_committed = false;
    result.expected_query_only = false;
    return result;
}

}  // namespace

bool run_root_succession_campaign(
    const std::filesystem::path& output_directory) {
    try {
        std::filesystem::remove_all(output_directory);
        std::filesystem::create_directories(output_directory);

        constexpr std::array<std::string_view, kMaximumKeys> old_labels{{
            "owner-old-a", "owner-old-b", "owner-old-c"}};
        constexpr std::array<std::string_view, kMaximumKeys> new_labels{{
            "owner-new-a", "owner-new-b", "owner-new-c"}};
        constexpr std::array<std::string_view, kMaximumKeys> overlap_new_labels{{
            "owner-old-b", "owner-new-d", "owner-new-e"}};

        const CompleteFixture base = make_fixture(
            "base", old_labels, new_labels);
        const CompleteFixture full_threshold = make_fixture(
            "full-threshold", old_labels, new_labels, 3U, 3U, 3U, 3U);
        const CompleteFixture overlap = make_fixture(
            "overlap", old_labels, overlap_new_labels);

        std::vector<Case> cases;
        cases.push_back(normal_case("valid-2of3-commit", base));
        cases.push_back(normal_case("valid-3of3-commit", full_threshold));
        cases.push_back(normal_case("valid-overlap-keysets-commit", overlap));

        Case stale = normal_case(
            "valid-evidence-stale-register", base,
            ApplyCode::stale_current, false, false);
        stale.root_register.current_manifest_head =
            transaction_dossier::labeled_digest("root-succession/stale-head");
        cases.push_back(stale);

        Case wrong_register = normal_case(
            "valid-evidence-wrong-register-id", base,
            ApplyCode::register_id_mismatch, false, false);
        wrong_register.root_register.register_id =
            transaction_dossier::labeled_digest("root-succession/wrong-register");
        cases.push_back(wrong_register);

        Case wrong_precommit = normal_case(
            "valid-evidence-register-precommit-mismatch", base,
            ApplyCode::register_precommit_mismatch, false, false);
        wrong_precommit.root_register.precommitted_successor_head =
            transaction_dossier::labeled_digest("root-succession/alternate-n-plus-one");
        cases.push_back(wrong_precommit);

        Case already = normal_case(
            "valid-evidence-already-current", base,
            ApplyCode::already_current_query_only, false, true);
        already.root_register.current_manifest_head =
            base.statement.successor_manifest_head;
        already.root_register.current_version = base.statement.successor_version;
        already.root_register.precommitted_successor_head = {};
        already.root_register.transition_ordinal = 1U;
        cases.push_back(already);

        cases.push_back(normal_case(
            "valid-evidence-reply-lost-after-commit", base,
            ApplyCode::uncertain_after_commit_query_only,
            true, true, ReplyCut::reply_lost_after_commit));

        Case invalid_predecessor = invalid_case(
            "invalid-predecessor-manifest", base,
            EvidenceCode::invalid_predecessor_manifest);
        invalid_predecessor.predecessor[0U] ^= 0x01U;
        cases.push_back(invalid_predecessor);

        Case invalid_successor = invalid_case(
            "invalid-successor-manifest", base,
            EvidenceCode::invalid_successor_manifest);
        invalid_successor.successor[0U] ^= 0x01U;
        cases.push_back(invalid_successor);

        Case invalid_envelope = invalid_case(
            "invalid-envelope-integrity", base,
            EvidenceCode::invalid_envelope);
        invalid_envelope.envelope[900U] ^= 0x01U;
        cases.push_back(invalid_envelope);

        Case project_mismatch = invalid_case(
            "project-mismatch", base, EvidenceCode::project_mismatch);
        OwnerManifestV1 project_changed = base.successor.logical;
        project_changed.project_id =
            transaction_dossier::labeled_digest("root-succession/foreign-project");
        require(encode_manifest(project_changed, project_mismatch.successor),
                "encode foreign project manifest");
        cases.push_back(project_mismatch);

        Case chain_mismatch = invalid_case(
            "predecessor-chain-mismatch", base,
            EvidenceCode::predecessor_chain_mismatch);
        OwnerManifestV1 chain_changed = base.successor.logical;
        chain_changed.predecessor_manifest =
            transaction_dossier::labeled_digest("root-succession/wrong-predecessor");
        require(encode_manifest(chain_changed, chain_mismatch.successor),
                "encode wrong predecessor manifest");
        cases.push_back(chain_mismatch);

        Case version_stasis = invalid_case(
            "version-stasis", base, EvidenceCode::version_not_next);
        OwnerManifestV1 stasis_manifest = base.successor.logical;
        stasis_manifest.version = kPredecessorVersion;
        require(encode_manifest(stasis_manifest, version_stasis.successor),
                "encode stasis manifest");
        cases.push_back(version_stasis);

        Case version_skip = invalid_case(
            "version-skip", base, EvidenceCode::version_not_next);
        OwnerManifestV1 skip_manifest = base.successor.logical;
        skip_manifest.version = kPredecessorVersion + 2U;
        require(encode_manifest(skip_manifest, version_skip.successor),
                "encode skip manifest");
        cases.push_back(version_skip);

        Case old_head_mismatch = invalid_case(
            "statement-predecessor-head-mismatch", base,
            EvidenceCode::statement_binding_mismatch);
        RootSuccessionStatementV1 old_head_statement = base.statement;
        old_head_statement.predecessor_manifest_head =
            transaction_dossier::labeled_digest("root-succession/wrong-old-head");
        old_head_mismatch.envelope = resign_statement(base, old_head_statement);
        cases.push_back(old_head_mismatch);

        Case new_head_mismatch = invalid_case(
            "statement-successor-head-mismatch", base,
            EvidenceCode::statement_binding_mismatch);
        RootSuccessionStatementV1 new_head_statement = base.statement;
        new_head_statement.successor_manifest_head =
            transaction_dossier::labeled_digest("root-succession/wrong-new-head");
        new_head_mismatch.envelope = resign_statement(base, new_head_statement);
        cases.push_back(new_head_mismatch);

        Case statement_precommit = invalid_case(
            "statement-precommit-mismatch", base,
            EvidenceCode::statement_precommit_mismatch);
        RootSuccessionStatementV1 precommit_statement = base.statement;
        precommit_statement.precommitted_successor_head =
            transaction_dossier::labeled_digest("root-succession/wrong-precommit");
        statement_precommit.envelope = resign_statement(base, precommit_statement);
        cases.push_back(statement_precommit);

        Case before_window = invalid_case(
            "before-validity-window", base,
            EvidenceCode::time_window_mismatch);
        before_window.observed_time = base.statement.not_before - 1U;
        cases.push_back(before_window);

        Case expired = invalid_case(
            "expired-successor", base,
            EvidenceCode::time_window_mismatch);
        expired.observed_time = base.statement.expires_at;
        cases.push_back(expired);

        Case old_unknown = invalid_case(
            "predecessor-unknown-signer", base,
            EvidenceCode::predecessor_unknown_signer);
        put_digest(old_unknown.envelope, 352U,
                   transaction_dossier::labeled_digest("root-succession/unknown-old-key"));
        rehash_envelope(old_unknown.envelope);
        cases.push_back(old_unknown);

        Case old_duplicate = invalid_case(
            "predecessor-duplicate-signer", base,
            EvidenceCode::predecessor_duplicate_signer);
        std::copy_n(old_duplicate.envelope.begin() + 352,
                    96, old_duplicate.envelope.begin() + 448);
        rehash_envelope(old_duplicate.envelope);
        cases.push_back(old_duplicate);

        Case old_invalid_signature = invalid_case(
            "predecessor-invalid-signature", base,
            EvidenceCode::predecessor_invalid_signature);
        old_invalid_signature.envelope[352U + 32U] ^= 0x01U;
        rehash_envelope(old_invalid_signature.envelope);
        cases.push_back(old_invalid_signature);

        Case old_below = invalid_case(
            "predecessor-below-threshold", base,
            EvidenceCode::predecessor_below_threshold);
        old_below.envelope = make_envelope(
            base.statement_bytes, base.predecessor, 1U, base.successor, 2U);
        cases.push_back(old_below);

        Case new_unknown = invalid_case(
            "successor-unknown-signer", base,
            EvidenceCode::successor_unknown_signer);
        put_digest(new_unknown.envelope, 640U,
                   transaction_dossier::labeled_digest("root-succession/unknown-new-key"));
        rehash_envelope(new_unknown.envelope);
        cases.push_back(new_unknown);

        Case new_duplicate = invalid_case(
            "successor-duplicate-signer", base,
            EvidenceCode::successor_duplicate_signer);
        std::copy_n(new_duplicate.envelope.begin() + 640,
                    96, new_duplicate.envelope.begin() + 736);
        rehash_envelope(new_duplicate.envelope);
        cases.push_back(new_duplicate);

        Case new_invalid_signature = invalid_case(
            "successor-invalid-signature", base,
            EvidenceCode::successor_invalid_signature);
        new_invalid_signature.envelope[640U + 32U] ^= 0x01U;
        rehash_envelope(new_invalid_signature.envelope);
        cases.push_back(new_invalid_signature);

        Case new_below = invalid_case(
            "successor-below-threshold", base,
            EvidenceCode::successor_below_threshold);
        new_below.envelope = make_envelope(
            base.statement_bytes, base.predecessor, 2U, base.successor, 1U);
        cases.push_back(new_below);

        std::string table =
            "case\tpath\tobserved_time\treply_cut\texpected_evidence_code\t"
            "expected_apply_code\texpected_valid\texpected_committed\t"
            "expected_query_only\tcandidate_evidence_code\treference_evidence_code\t"
            "candidate_apply_code\treference_apply_code\tpredecessor_verified\t"
            "successor_verified\treceipt_present\towner_constitution_proved\t"
            "currentness_proved\tindependent_custody_proved\t"
            "protected_transition_proved\tindependent_reopen_proved\t"
            "epoch_exit_proved\tauthority_granted\n";

        std::size_t valid_evidence = 0U;
        std::size_t rejected_evidence = 0U;
        std::size_t committed = 0U;
        std::size_t query_only = 0U;
        std::size_t disagreements = 0U;
        std::size_t authority_true = 0U;

        for (const Case& item : cases) {
            CurrentRootRegisterV1 candidate_register = item.root_register;
            CurrentRootRegisterV1 reference_register = item.root_register;
            const EvidenceReport candidate_evidence = validate_candidate(
                item.predecessor, item.successor, item.envelope, item.observed_time);
            const EvidenceReport reference_evidence = validate_reference(
                item.predecessor, item.successor, item.envelope, item.observed_time);
            const ApplyReport candidate_apply = apply_candidate(
                candidate_register,
                item.predecessor, item.successor, item.envelope,
                item.observed_time, item.reply_cut);
            const ApplyReport reference_apply = apply_reference(
                reference_register,
                item.predecessor, item.successor, item.envelope,
                item.observed_time, item.reply_cut);

            require(candidate_evidence == reference_evidence,
                    item.name + " evidence disagreement");
            require(candidate_apply == reference_apply,
                    item.name + " apply disagreement");
            require(candidate_register == reference_register,
                    item.name + " register disagreement");
            require(candidate_evidence.code == item.expected_evidence,
                    item.name + " unexpected evidence code");
            require(candidate_apply.code == item.expected_apply,
                    item.name + " unexpected apply code");
            require(candidate_evidence.valid == item.expected_valid,
                    item.name + " unexpected validity");
            require(candidate_apply.committed == item.expected_committed,
                    item.name + " unexpected committed state");
            require(candidate_apply.query_only == item.expected_query_only,
                    item.name + " unexpected query-only state");
            require(!candidate_evidence.owner_constitution_proved
                        && !candidate_evidence.currentness_proved
                        && !candidate_evidence.independent_custody_proved
                        && !candidate_evidence.protected_transition_proved
                        && !candidate_evidence.independent_reopen_proved
                        && !candidate_evidence.epoch_exit_proved
                        && !candidate_evidence.authority_granted
                        && !candidate_apply.owner_constitution_proved
                        && !candidate_apply.currentness_proved
                        && !candidate_apply.independent_custody_proved
                        && !candidate_apply.protected_transition_proved
                        && !candidate_apply.independent_reopen_proved
                        && !candidate_apply.epoch_exit_proved
                        && !candidate_apply.authority_granted,
                    item.name + " authority projection");

            const std::filesystem::path relative =
                std::filesystem::path{"cases"} / item.name;
            const std::filesystem::path case_root = output_directory / relative;
            write_bytes(case_root / "predecessor.bin", item.predecessor);
            write_bytes(case_root / "successor.bin", item.successor);
            write_bytes(case_root / "envelope.bin", item.envelope);
            write_bytes(case_root / "register-before.bin",
                        encode_harness_register(item.root_register));
            write_bytes(case_root / "register-after.bin",
                        encode_harness_register(candidate_register));
            if (candidate_apply.receipt_present) {
                RootTransitionReceiptV1 decoded_receipt;
                require(decode_root_receipt(candidate_apply.receipt, decoded_receipt),
                        item.name + " receipt decode");
                write_bytes(case_root / "receipt.bin", candidate_apply.receipt);
            }

            table += item.name + "\t" + relative.generic_string() + "\t"
                + std::to_string(item.observed_time) + "\t"
                + reply_cut_name(item.reply_cut) + "\t"
                + std::string{evidence_code_name(item.expected_evidence)} + "\t"
                + std::string{apply_code_name(item.expected_apply)} + "\t"
                + bool_text(item.expected_valid) + "\t"
                + bool_text(item.expected_committed) + "\t"
                + bool_text(item.expected_query_only) + "\t"
                + std::string{evidence_code_name(candidate_evidence.code)} + "\t"
                + std::string{evidence_code_name(reference_evidence.code)} + "\t"
                + std::string{apply_code_name(candidate_apply.code)} + "\t"
                + std::string{apply_code_name(reference_apply.code)} + "\t"
                + std::to_string(candidate_evidence.predecessor_verified_signatures) + "\t"
                + std::to_string(candidate_evidence.successor_verified_signatures) + "\t"
                + bool_text(candidate_apply.receipt_present) + "\t"
                + "false\tfalse\tfalse\tfalse\tfalse\tfalse\tfalse\n";

            valid_evidence += candidate_evidence.valid ? 1U : 0U;
            rejected_evidence += candidate_evidence.valid ? 0U : 1U;
            committed += candidate_apply.committed ? 1U : 0U;
            query_only += candidate_apply.query_only ? 1U : 0U;
            disagreements += candidate_evidence == reference_evidence
                    && candidate_apply == reference_apply
                ? 0U : 1U;
            authority_true += candidate_evidence.authority_granted
                    || candidate_apply.authority_granted
                ? 1U : 0U;
        }
        write_text(output_directory / "cases.tsv", table);

        CurrentRootRegisterV1 first = base.root_register;
        CurrentRootRegisterV1 second = base.root_register;
        CurrentRootRegisterV1 stale_snapshot = base.root_register;
        const ApplyReport first_apply = apply_candidate(
            first, base.predecessor.encoded, base.successor.encoded,
            base.envelope, kObservedTime, ReplyCut::reply_delivered);
        const ApplyReport second_apply = apply_candidate(
            second, base.predecessor.encoded, base.successor.encoded,
            base.envelope, kObservedTime, ReplyCut::reply_delivered);
        require(first_apply.committed && second_apply.committed,
                "clone countermodel local commits");
        require(first.current_manifest_head == second.current_manifest_head
                    && first.current_manifest_head
                        == base.statement.successor_manifest_head,
                "clone countermodel successor heads");
        require(stale_snapshot.current_manifest_head
                    == base.statement.predecessor_manifest_head,
                "clone countermodel stale snapshot");
        RootTransitionReceiptV1 reopened_receipt;
        require(first_apply.receipt_present
                    && decode_root_receipt(first_apply.receipt, reopened_receipt),
                "same-root receipt reopen");
        write_text(output_directory / "currentness-fork-audit.json",
            "{\n"
            "  \"schema\": \"slopos.rev0914.root-currentness-fork-countermodel.v1\",\n"
            "  \"identical_register_copies\": 3,\n"
            "  \"identical_envelope_copies\": 2,\n"
            "  \"same_root_local_commits\": 2,\n"
            "  \"stale_copy_still_reports_predecessor\": true,\n"
            "  \"same_root_receipt_reopen\": true,\n"
            "  \"single_global_current_head_proved\": false,\n"
            "  \"protected_transition_proved\": false,\n"
            "  \"independent_reopen_proved\": false,\n"
            "  \"authority_granted\": false\n"
            "}\n");

        const std::string audit =
            "{\n"
            "  \"schema\": \"slopos.rev0914.root-succession-campaign.v1\",\n"
            "  \"status\": \"PASS\",\n"
            "  \"manifest_bytes\": 384,\n"
            "  \"statement_bytes\": 320,\n"
            "  \"envelope_bytes\": 1024,\n"
            "  \"signing_message_bytes\": 360,\n"
            "  \"receipt_bytes\": 256,\n"
            "  \"cases\": " + std::to_string(cases.size()) + ",\n"
            "  \"valid_evidence_cases\": " + std::to_string(valid_evidence) + ",\n"
            "  \"rejected_evidence_cases\": " + std::to_string(rejected_evidence) + ",\n"
            "  \"committed_local_transitions\": " + std::to_string(committed) + ",\n"
            "  \"query_only_results\": " + std::to_string(query_only) + ",\n"
            "  \"candidate_reference_disagreements\": "
                + std::to_string(disagreements) + ",\n"
            "  \"real_ed25519\": true,\n"
            "  \"dual_threshold\": true,\n"
            "  \"exact_n_plus_one\": true,\n"
            "  \"precommit_required\": true,\n"
            "  \"signing_api_exposed\": false,\n"
            "  \"owner_constitution_proved\": false,\n"
            "  \"currentness_proved\": false,\n"
            "  \"independent_custody_proved\": false,\n"
            "  \"protected_transition_proved\": false,\n"
            "  \"independent_reopen_proved\": false,\n"
            "  \"epoch_exit_true_results\": 0,\n"
            "  \"authority_true_results\": " + std::to_string(authority_true) + "\n"
            "}\n";
        write_text(output_directory / "campaign-audit.json", audit);

        std::cout << "ROOT_SUCCESSION_CAMPAIGN=PASS cases=" << cases.size()
                  << " valid_evidence=" << valid_evidence
                  << " rejected=" << rejected_evidence
                  << " local_commits=" << committed
                  << " query_only=" << query_only
                  << " disagreements=" << disagreements
                  << " dual_threshold=true exact_n_plus_one=true precommit=true"
                  << " owner_constitution=false currentness=false"
                  << " protected_transition=false independent_reopen=false"
                  << " epoch_exit=false authority=false\n";
        return true;
    } catch (const std::exception& error) {
        std::cerr << "ROOT_SUCCESSION_CAMPAIGN=FAIL detail=" << error.what() << '\n';
        return false;
    }
}

}  // namespace slopos::e0::signed_admission::root_succession
