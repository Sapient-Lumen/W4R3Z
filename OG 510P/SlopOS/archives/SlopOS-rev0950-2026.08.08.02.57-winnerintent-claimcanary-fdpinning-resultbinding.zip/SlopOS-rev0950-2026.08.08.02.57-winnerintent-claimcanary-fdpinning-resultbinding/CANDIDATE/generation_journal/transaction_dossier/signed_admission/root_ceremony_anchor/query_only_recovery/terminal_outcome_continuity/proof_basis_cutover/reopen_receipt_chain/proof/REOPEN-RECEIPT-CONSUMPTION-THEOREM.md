# Reopen receipt publication and consumption theorem

Let `P` be one accepted Exact Predecessor Consumption trace in state `accepted_chain_ready_live_retained`, `C` a complete replacement-only source closure, `R` a durable no-replace reopen receipt over `C`, `A` a separately governed authorization capsule over `R`, and `D` a deletion receipt over the exact target authorized by `A`.

`P` is a still-live prefix: its exact witness, floor, join, cold-reopen, and authorization records are durable and ordered, while its live terminal record remains visible and its deletion effect is absent. A completed/deleted `P` is not a valid premise, because no refinement may resurrect that live bridge.

For crash cuts ordered by `<`, safe reclamation requires:

```text
computed(C) < publish(R) < reopen(R) < publish(A) < reopen(A) < delete(target) < publish(D)
```

and every object must bind the same cutover, request history, terminal outcome, and destructive target. `C` must exclude the live terminal record from its inputs. In addition, the child join, reopen-receipt, and authorization digests must equal the corresponding publication-record digests in `P`; validity of a sibling trace is irrelevant. These equalities are a projection map from the refined child history to `P`, not permission to replay phases after parent deletion.

## Claim 1 — computation is not publication

A process can compute the correct outcome and crash before publishing any durable receipt. Therefore successful computation does not give a later actor a portable fact to consume.

## Claim 2 — publication is not independent reopen

A receipt can appear in the publishing process while its namespace entry, storage order, or source closure is unavailable after restart. Therefore publication must be followed by independent reopen before it can authorize destruction.

## Claim 3 — verifier assertion is not source closure

A concise verifier statement can bind subject and claimed properties while omitting the inputs and procedure needed to reproduce the result. Therefore the receipt must bind a separately inspectable exact source closure.

## Claim 4 — same-cut truth is not predecessor consumption

If receipt publication and authorization are merely true in one recovered row, no fact establishes that authorization consumed a durable predecessor. Without an owner-selected atomicity theorem, same-cut collapse is refused.

## Claim 5 — unauthorized deletion is not eventual repair

After deletion, later publication of a missing receipt cannot restore the lost live bridge or retroactively authorize the destructive act. The state is fail-stop, not repairable refusal.

## Claim 6 — parallel validity is not composition

Two relations can each accept internally consistent traces while referring to different join, reopen, or authorization records. Therefore conjunction in prose is insufficient: the receipt-chain trace must embed the exact-predecessor trace it refines and mechanically compare the consumed record identities.

## Claim 7 — terminal parent completion is not a child starting point

A parent trace whose deletion has already completed cannot serve as the `R0` premise of a child trace that requires the live terminal record. Accepting both would describe deletion, resurrection, and a second deletion while calling the history monotone. The only coherent premise is the exact parent’s accepted ready-live prefix; the child alone owns the destructive extension.

## Corollary

A parent proof-basis summary can be internally consistent yet too coarse for reclamation. The live record remains mandatory until the receipt chain is independently reopened through authorization; deletion is complete only after an exact-target deletion receipt.

Exact predecessor identity is supplied by the embedded Exact Predecessor Consumption V1 ready-live trace; this theorem refines rather than merely accompanies it. All claims are finite hosted relations. External occurrence, authentication roots, durable media, separate administration, currentness, and authority remain premises.
