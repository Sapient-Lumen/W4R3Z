# Signed-admission evidence profile v1

**Status:** hosted Epoch-Zero proof slice. **Authority:** false.

All integers are unsigned big-endian. Every reserved byte is zero. SHA-256
relations use `SHA256(UTF8(label) || 0x00 || payload)`. Ed25519 verification uses
one-shot `EVP_DigestVerify`; no external message digest is selected.

## Owner-manifest observation — 384 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPOM01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `1` |
| 12 | 4 | length `384` |
| 16 | 1 | suite `1` = Ed25519 |
| 17 | 1 | threshold |
| 18 | 1 | key count, `1..3` |
| 19 | 13 | reserved |
| 32 | 32 | project identifier |
| 64 | 32 | constitution identifier observation |
| 96 | 32 | predecessor-manifest digest; zero is hosted genesis |
| 128 | 8 | manifest version |
| 136 | 24 | reserved |
| 160 | 192 | three `(key_id[32], public_key[32])` slots |
| 352 | 32 | integrity digest over bytes `0..351` |

Active keys are strictly ordered by key ID; inactive slots are zero. A key ID is
`SHA256("SlopOS/admission/key-id/v1" || 0x00 || public_key)`. The manifest is an
input observation. Its internal `constitution_id` does not prove that a
constitution ceremony occurred or that any represented actor is a SlopOS owner.

## Admission statement — 512 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPAS01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `2` |
| 12 | 4 | length `512` |
| 16 | 1 | purpose `1` = effect-permit evidence |
| 17 | 1 | terminal scope: effect/no-effect/uncertain/fail-stop |
| 18 | 1 | suite `1` = Ed25519 |
| 19 | 13 | reserved |
| 32 | 384 | twelve SHA-256 bindings listed below |
| 416 | 48 | six unsigned 64-bit values listed below |
| 464 | 16 | reserved |
| 480 | 32 | integrity digest over bytes `0..479` |

The twelve bindings are, in order: project, exact owner-manifest head, admitted
profile, transaction ID, exact R1-R3 prefix, subject, policy, evidence,
appraisal, permit issuer actor, endpoint actor, and reopener actor. The integers
are generation-from, generation-to, dossier nonce, not-before, expires-at, and
ceremony nonce. The terminal scope fixes generation-to semantics.

The R1-R3 prefix digest covers all 1,344 exact bytes. R4's permit field must equal
the statement head. R5 and R6 must preserve that permit through the already
frozen transaction-dossier relation.

## Signed envelope — 1,024 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPAE01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `3` |
| 12 | 4 | length `1024` |
| 16 | 1 | signature count, `1..3` |
| 17 | 1 | suite `1` = Ed25519 |
| 18 | 14 | reserved |
| 32 | 512 | exact canonical statement |
| 544 | 288 | three `(key_id[32], signature[64])` slots |
| 832 | 160 | reserved |
| 992 | 32 | integrity digest over bytes `0..991` |

The fixed signed message is 552 bytes:

```
zero-pad-to-32("SlopOS/signed-admission/v1/PAE")
|| uint64_be(512)
|| exact_statement_bytes
```

The purpose/type bytes are inside the signed statement and the fixed domain is
outside it. Signature-slot key IDs are lookup hints that must resolve to the
supplied manifest; the verifier does not treat a key ID as an authenticated
principal by itself. Duplicate signer IDs do not count twice.

## Acceptance relation

`evidence_valid` requires canonical manifest, envelope, and statement; exact
manifest/project/profile bindings; inclusive not-before and exclusive expiry;
a complete valid R1-R6 dossier; exact statement/dossier field equality; valid
signatures from distinct manifest members; and threshold satisfaction.

The relation deliberately does not accept or infer:

1. owner constitution or external manifest admission;
2. current root or non-rollback status;
3. signer custody independence merely because key IDs differ;
4. global at-most-once spend;
5. process, binary, channel, or OpenSSL custody;
6. an externally operated effect or independent reopen;
7. authority, living-project succession, or epoch exit.

## Corpus

The retained campaign has 43 cases: five valid evidence observations and 38
rejections. It covers all four terminal classes, 2-of-3 and 3-of-3 signatures,
manifest and envelope malformation, statement substitutions, exact dossier
substitutions, time-window failures, unknown and duplicate signers, invalid
signatures, below-threshold evidence, and signed-byte substitution. One valid
case is self-constituted by an attacker. Two restored copies validate locally in
the replay countermodel. Both facts preserve the negative constitution.
