#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <optional>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain {
namespace {

[[nodiscard]] bool digest_is_zero(const Digest& digest) noexcept {
    return std::all_of(digest.begin(), digest.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] bool source_is_well_shaped(const SourceClosure& source) noexcept {
    const std::array<bool, 18U> claims{
        source.canonical,
        source.complete,
        source.independently_locatable,
        source.rollback_external,
        source.replacement_only,
        source.no_hidden_inputs,
        source.includes_live_terminal_record,
        !digest_is_zero(source.closure_digest),
        !digest_is_zero(source.cutover_id),
        !digest_is_zero(source.join_digest),
        !digest_is_zero(source.witness_digest),
        !digest_is_zero(source.floor_digest),
        !digest_is_zero(source.request_id),
        !digest_is_zero(source.transition_digest),
        !digest_is_zero(source.register_incarnation),
        !digest_is_zero(source.terminal_digest),
        !digest_is_zero(source.reopener_incarnation),
        !digest_is_zero(source.verifier_id) || !digest_is_zero(source.verifier_policy_digest),
    };
    return source.present || std::none_of(claims.begin(), claims.end(), [](const bool claim) {
        return claim;
    });
}

[[nodiscard]] bool reopen_is_well_shaped(const ReopenReceipt& receipt) noexcept {
    const std::array<bool, 21U> claims{
        receipt.computed_from_closure,
        receipt.exact_result,
        receipt.authenticated,
        receipt.no_replace_published,
        receipt.durable,
        receipt.directory_entry_durable,
        receipt.single_view,
        receipt.independently_reopenable,
        !digest_is_zero(receipt.receipt_digest),
        !digest_is_zero(receipt.closure_digest),
        !digest_is_zero(receipt.cutover_id),
        !digest_is_zero(receipt.join_digest),
        !digest_is_zero(receipt.witness_digest),
        !digest_is_zero(receipt.floor_digest),
        !digest_is_zero(receipt.request_id),
        !digest_is_zero(receipt.transition_digest),
        !digest_is_zero(receipt.register_incarnation),
        !digest_is_zero(receipt.terminal_digest),
        !digest_is_zero(receipt.reopener_incarnation),
        !digest_is_zero(receipt.verifier_id),
        !digest_is_zero(receipt.verifier_policy_digest),
    };
    return receipt.present || std::none_of(claims.begin(), claims.end(), [](const bool claim) {
        return claim;
    });
}

[[nodiscard]] bool authorization_is_well_shaped(const AuthorizationCapsule& authorization) noexcept {
    const std::array<bool, 12U> claims{
        authorization.authenticated,
        authorization.durable,
        authorization.no_replace_published,
        authorization.single_view,
        authorization.separately_governed,
        authorization.independently_reopenable,
        !digest_is_zero(authorization.authorization_digest),
        !digest_is_zero(authorization.reopen_receipt_digest),
        !digest_is_zero(authorization.cutover_id),
        !digest_is_zero(authorization.target_digest),
        !digest_is_zero(authorization.owner_policy_digest),
        !digest_is_zero(authorization.retention_policy_digest),
    };
    return authorization.present || std::none_of(claims.begin(), claims.end(), [](const bool claim) {
        return claim;
    });
}

[[nodiscard]] bool deletion_is_well_shaped(const DeletionReceipt& deletion) noexcept {
    const std::array<bool, 9U> claims{
        deletion.authenticated,
        deletion.durable,
        deletion.no_replace_published,
        deletion.single_view,
        deletion.target_absence_observed,
        !digest_is_zero(deletion.deletion_receipt_digest),
        !digest_is_zero(deletion.authorization_digest),
        !digest_is_zero(deletion.cutover_id),
        !digest_is_zero(deletion.target_digest),
    };
    return deletion.present || std::none_of(claims.begin(), claims.end(), [](const bool claim) {
        return claim;
    });
}

[[nodiscard]] ReceiptChainReport reject(
    const ReceiptChainCode code,
    const bool exact_predecessor_accepted = false) noexcept {
    ReceiptChainReport report{};
    report.code = code;
    report.exact_predecessor_accepted = exact_predecessor_accepted;
    return report;
}

struct ReferenceFacts final {
    bool predecessor_complete{false};
    bool predecessor_ready{false};
    bool source_valid{false};
    bool reopen_core{false};
    bool reopen_reopen{false};
    bool authorization_core{false};
    bool authorization_reopen{false};
    bool deletion_valid{false};
    bool ordered{false};
    bool source_gap{false};
    bool publication_gap{false};
    bool receipt_reopen_gap{false};
    bool authorization_gap{false};
    bool authorization_reopen_gap{false};
    bool deletion_gap{false};
    bool phase_gap{false};
    bool regression{false};
    bool ready{false};
    bool complete{false};
    bool unauthorized{false};
    bool fail_stop{false};
};

[[nodiscard]] ReceiptChainReport accept(
    const ReceiptChainCode code,
    const ReferenceFacts& facts) noexcept {
    ReceiptChainReport report{};
    report.code = code;
    report.accepted = true;
    report.exact_predecessor_accepted = true;
    report.exact_predecessor_deletion_safe = facts.predecessor_complete;
    report.exact_predecessor_ready = facts.predecessor_ready;
    report.source_closure_valid = facts.source_valid;
    report.reopen_receipt_core_valid = facts.reopen_core;
    report.reopen_receipt_reopen_valid = facts.reopen_reopen;
    report.authorization_core_valid = facts.authorization_core;
    report.authorization_reopen_valid = facts.authorization_reopen;
    report.deletion_receipt_valid = facts.deletion_valid;
    report.all_cuts_ordered = facts.ordered;
    report.source_gap_observed = facts.source_gap;
    report.publication_gap_observed = facts.publication_gap;
    report.receipt_reopen_gap_observed = facts.receipt_reopen_gap;
    report.authorization_gap_observed = facts.authorization_gap;
    report.authorization_reopen_gap_observed = facts.authorization_reopen_gap;
    report.deletion_receipt_gap_observed = facts.deletion_gap;
    report.phase_order_gap_observed = facts.phase_gap;
    report.regression_observed = facts.regression;
    report.reclamation_ready = facts.ready;
    report.reclamation_complete = facts.complete;
    report.unauthorized_deletion = facts.unauthorized;
    report.fail_stopped = facts.fail_stop;
    // A hosted relation never establishes any of the following external facts.
    report.eventual_repair_sufficient = false;
    report.external_occurrence_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

template <typename Projection>
[[nodiscard]] std::array<bool, receipt_cut_count> project_cuts(
    const ReceiptChainTrace& trace,
    Projection projection) noexcept {
    std::array<bool, receipt_cut_count> values{};
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        values[index] = projection(trace.cuts[index]);
    }
    return values;
}

[[nodiscard]] bool ever(const std::array<bool, receipt_cut_count>& values) noexcept {
    return std::any_of(values.begin(), values.end(), [](const bool value) { return value; });
}

[[nodiscard]] std::optional<std::size_t> first_true(
    const std::array<bool, receipt_cut_count>& values) noexcept {
    const auto iterator = std::find(values.begin(), values.end(), true);
    if (iterator == values.end()) {
        return std::nullopt;
    }
    return static_cast<std::size_t>(std::distance(values.begin(), iterator));
}

[[nodiscard]] bool monotonically_present(
    const std::array<bool, receipt_cut_count>& values) noexcept {
    bool observed = false;
    for (const bool value : values) {
        if (observed && !value) {
            return false;
        }
        observed = observed || value;
    }
    return true;
}

[[nodiscard]] bool monotonically_absent_after_loss(
    const std::array<bool, receipt_cut_count>& values) noexcept {
    bool absent = false;
    for (const bool value : values) {
        if (absent && value) {
            return false;
        }
        absent = absent || !value;
    }
    return true;
}

[[nodiscard]] bool strictly_after(
    const std::optional<std::size_t> successor,
    const std::optional<std::size_t> predecessor) noexcept {
    return !successor.has_value()
        || (predecessor.has_value() && predecessor.value() < successor.value());
}

}  // namespace

ReceiptChainReport evaluate_reference(const ReceiptChainTrace& trace) noexcept {
    const auto predecessor = exact_predecessor_consumption::evaluate_reference(trace.predecessor);
    if (!predecessor.accepted) {
        return reject(ReceiptChainCode::exact_predecessor_rejected);
    }

    ReferenceFacts facts{};
    facts.predecessor_complete = predecessor.chain_complete && predecessor.deletion_safe;
    facts.predecessor_ready = predecessor.code
        == exact_predecessor_consumption::ChainCode::accepted_chain_ready_live_retained;
    const bool predecessor_exact = predecessor.receipt_subjects_exact
        && predecessor.receipt_components_exact
        && predecessor.receipt_digests_unique
        && predecessor.exact_predecessor_edges
        && predecessor.durable_publications
        && predecessor.strict_phase_order
        && predecessor.monotone_visibility
        && predecessor.every_prefix_covered;
    // A completed exact predecessor has already deleted the live basis.  This
    // relation may refine only the accepted ready-live prefix, never resurrect it.
    if (!facts.predecessor_ready || facts.predecessor_complete || !predecessor_exact) {
        return reject(ReceiptChainCode::exact_predecessor_not_ready, true);
    }

    const auto& cutover = trace.predecessor.parent;
    const auto& receipts = trace.predecessor.receipts;
    const auto record_digest = [&](const exact_predecessor_consumption::Phase phase) -> const Digest& {
        return receipts[static_cast<std::size_t>(phase)].record_digest;
    };

    if (digest_is_zero(trace.join_digest)) {
        return reject(ReceiptChainCode::join_digest_zero, true);
    }
    if (digest_is_zero(trace.target_digest)) {
        return reject(ReceiptChainCode::target_digest_zero, true);
    }
    if (digest_is_zero(trace.owner_policy_digest)) {
        return reject(ReceiptChainCode::owner_policy_digest_zero, true);
    }
    if (digest_is_zero(trace.retention_policy_digest)) {
        return reject(ReceiptChainCode::retention_policy_digest_zero, true);
    }
    if (trace.join_digest != record_digest(exact_predecessor_consumption::Phase::join_publication)) {
        return reject(ReceiptChainCode::exact_join_receipt_digest_mismatch, true);
    }
    if (trace.reopen.present
        && trace.reopen.receipt_digest
            != record_digest(exact_predecessor_consumption::Phase::cold_reopen_receipt)) {
        return reject(ReceiptChainCode::exact_reopen_receipt_digest_mismatch, true);
    }
    if (trace.authorization.present
        && trace.authorization.authorization_digest
            != record_digest(exact_predecessor_consumption::Phase::deletion_authorization)) {
        return reject(ReceiptChainCode::exact_authorization_receipt_digest_mismatch, true);
    }
    if (trace.reclamation_requested != trace.predecessor.reclamation_requested
        || trace.reclamation_requested != cutover.reclamation_requested) {
        return reject(ReceiptChainCode::reclamation_request_mismatch, true);
    }

    if (!source_is_well_shaped(trace.source)) {
        return reject(ReceiptChainCode::source_shape_invalid, true);
    }
    if (trace.source.present) {
        if (trace.source.cutover_id != cutover.cutover_id) {
            return reject(ReceiptChainCode::source_cutover_id_mismatch, true);
        }
        if (trace.source.join_digest != trace.join_digest) {
            return reject(ReceiptChainCode::source_join_digest_mismatch, true);
        }
        if (trace.source.witness_digest != cutover.witness_digest) {
            return reject(ReceiptChainCode::source_witness_digest_mismatch, true);
        }
        if (trace.source.floor_digest != cutover.floor_digest) {
            return reject(ReceiptChainCode::source_floor_digest_mismatch, true);
        }
        if (trace.source.request_id != cutover.state.request_id) {
            return reject(ReceiptChainCode::source_request_id_mismatch, true);
        }
        if (trace.source.transition_digest != cutover.state.transition_digest) {
            return reject(ReceiptChainCode::source_transition_digest_mismatch, true);
        }
        if (trace.source.register_incarnation != cutover.state.register_incarnation) {
            return reject(ReceiptChainCode::source_register_incarnation_mismatch, true);
        }
        if (trace.source.terminal_digest != cutover.state.terminal_digest) {
            return reject(ReceiptChainCode::source_terminal_digest_mismatch, true);
        }
        if (trace.source.terminal_kind != cutover.state.terminal_kind) {
            return reject(ReceiptChainCode::source_terminal_kind_mismatch, true);
        }
    }

    if (!reopen_is_well_shaped(trace.reopen)) {
        return reject(ReceiptChainCode::reopen_shape_invalid, true);
    }
    if (trace.reopen.present) {
        if (trace.reopen.closure_digest != trace.source.closure_digest) {
            return reject(ReceiptChainCode::reopen_closure_digest_mismatch, true);
        }
        if (trace.reopen.cutover_id != cutover.cutover_id) {
            return reject(ReceiptChainCode::reopen_cutover_id_mismatch, true);
        }
        if (trace.reopen.join_digest != trace.join_digest) {
            return reject(ReceiptChainCode::reopen_join_digest_mismatch, true);
        }
        if (trace.reopen.witness_digest != cutover.witness_digest) {
            return reject(ReceiptChainCode::reopen_witness_digest_mismatch, true);
        }
        if (trace.reopen.floor_digest != cutover.floor_digest) {
            return reject(ReceiptChainCode::reopen_floor_digest_mismatch, true);
        }
        if (trace.reopen.request_id != cutover.state.request_id) {
            return reject(ReceiptChainCode::reopen_request_id_mismatch, true);
        }
        if (trace.reopen.transition_digest != cutover.state.transition_digest) {
            return reject(ReceiptChainCode::reopen_transition_digest_mismatch, true);
        }
        if (trace.reopen.register_incarnation != cutover.state.register_incarnation) {
            return reject(ReceiptChainCode::reopen_register_incarnation_mismatch, true);
        }
        if (trace.reopen.terminal_digest != cutover.state.terminal_digest) {
            return reject(ReceiptChainCode::reopen_terminal_digest_mismatch, true);
        }
        if (trace.reopen.terminal_kind != cutover.state.terminal_kind) {
            return reject(ReceiptChainCode::reopen_terminal_kind_mismatch, true);
        }
        if (trace.reopen.reopener_incarnation != trace.source.reopener_incarnation) {
            return reject(ReceiptChainCode::reopen_reopener_incarnation_mismatch, true);
        }
        if (trace.reopen.verifier_id != trace.source.verifier_id) {
            return reject(ReceiptChainCode::reopen_verifier_id_mismatch, true);
        }
        if (trace.reopen.verifier_policy_digest != trace.source.verifier_policy_digest) {
            return reject(ReceiptChainCode::reopen_policy_digest_mismatch, true);
        }
    }

    if (!authorization_is_well_shaped(trace.authorization)) {
        return reject(ReceiptChainCode::authorization_shape_invalid, true);
    }
    if (trace.authorization.present) {
        if (trace.authorization.reopen_receipt_digest != trace.reopen.receipt_digest) {
            return reject(ReceiptChainCode::authorization_receipt_digest_mismatch, true);
        }
        if (trace.authorization.cutover_id != cutover.cutover_id) {
            return reject(ReceiptChainCode::authorization_cutover_id_mismatch, true);
        }
        if (trace.authorization.target_digest != trace.target_digest) {
            return reject(ReceiptChainCode::authorization_target_digest_mismatch, true);
        }
        if (trace.authorization.owner_policy_digest != trace.owner_policy_digest) {
            return reject(ReceiptChainCode::authorization_owner_policy_mismatch, true);
        }
        if (trace.authorization.retention_policy_digest != trace.retention_policy_digest) {
            return reject(ReceiptChainCode::authorization_retention_policy_mismatch, true);
        }
    }

    if (!deletion_is_well_shaped(trace.deletion)) {
        return reject(ReceiptChainCode::deletion_shape_invalid, true);
    }
    if (trace.deletion.present) {
        if (trace.deletion.authorization_digest != trace.authorization.authorization_digest) {
            return reject(ReceiptChainCode::deletion_authorization_digest_mismatch, true);
        }
        if (trace.deletion.cutover_id != cutover.cutover_id) {
            return reject(ReceiptChainCode::deletion_cutover_id_mismatch, true);
        }
        if (trace.deletion.target_digest != trace.target_digest) {
            return reject(ReceiptChainCode::deletion_target_digest_mismatch, true);
        }
    }

    const auto& first = trace.cuts.front();
    if (!first.live_record_visible || !first.replacement_visible || first.record_deleted) {
        return reject(ReceiptChainCode::trace_initial_state_invalid, true);
    }
    for (const ReceiptCut& cut : trace.cuts) {
        if (cut.live_record_visible && cut.record_deleted) {
            return reject(ReceiptChainCode::trace_deleted_and_live, true);
        }
        if (!cut.live_record_visible && !cut.record_deleted) {
            return reject(ReceiptChainCode::trace_live_absent_without_deletion, true);
        }
    }

    facts.source_valid = trace.source.present
        && !digest_is_zero(trace.source.closure_digest)
        && trace.source.canonical
        && trace.source.complete
        && trace.source.independently_locatable
        && trace.source.rollback_external
        && trace.source.replacement_only
        && trace.source.no_hidden_inputs
        && !trace.source.includes_live_terminal_record;
    facts.reopen_core = facts.source_valid
        && trace.reopen.present
        && !digest_is_zero(trace.reopen.receipt_digest)
        && trace.reopen.computed_from_closure
        && trace.reopen.exact_result
        && trace.reopen.authenticated
        && trace.reopen.no_replace_published
        && trace.reopen.durable
        && trace.reopen.directory_entry_durable
        && trace.reopen.single_view;
    facts.reopen_reopen = facts.reopen_core && trace.reopen.independently_reopenable;
    facts.authorization_core = facts.reopen_reopen
        && trace.authorization.present
        && !digest_is_zero(trace.authorization.authorization_digest)
        && trace.authorization.authenticated
        && trace.authorization.durable
        && trace.authorization.no_replace_published
        && trace.authorization.single_view
        && trace.authorization.separately_governed;
    facts.authorization_reopen = facts.authorization_core
        && trace.authorization.independently_reopenable;
    const bool deletion_core = trace.deletion.present
        && !digest_is_zero(trace.deletion.deletion_receipt_digest)
        && trace.deletion.authenticated
        && trace.deletion.durable
        && trace.deletion.no_replace_published
        && trace.deletion.single_view
        && trace.deletion.target_absence_observed;
    facts.deletion_valid = facts.authorization_reopen && deletion_core;

    const auto starts = project_cuts(trace, [](const ReceiptCut& cut) { return cut.reopener_started; });
    const auto computes = project_cuts(trace, [](const ReceiptCut& cut) { return cut.reconstruction_computed; });
    const auto receipts_visible = project_cuts(trace, [](const ReceiptCut& cut) { return cut.reopen_receipt_visible; });
    const auto receipts_reopened = project_cuts(trace, [](const ReceiptCut& cut) { return cut.reopen_receipt_reopened; });
    const auto authorizations_visible = project_cuts(trace, [](const ReceiptCut& cut) { return cut.authorization_visible; });
    const auto authorizations_reopened = project_cuts(trace, [](const ReceiptCut& cut) { return cut.authorization_reopened; });
    const auto deletions = project_cuts(trace, [](const ReceiptCut& cut) { return cut.record_deleted; });
    const auto deletion_receipts = project_cuts(trace, [](const ReceiptCut& cut) { return cut.deletion_receipt_visible; });
    const auto live_records = project_cuts(trace, [](const ReceiptCut& cut) { return cut.live_record_visible; });
    const auto replacements = project_cuts(trace, [](const ReceiptCut& cut) { return cut.replacement_visible; });

    facts.ordered = strictly_after(first_true(computes), first_true(starts))
        && strictly_after(first_true(receipts_visible), first_true(computes))
        && strictly_after(first_true(receipts_reopened), first_true(receipts_visible))
        && strictly_after(first_true(authorizations_visible), first_true(receipts_reopened))
        && strictly_after(first_true(authorizations_reopened), first_true(authorizations_visible))
        && strictly_after(first_true(deletions), first_true(authorizations_reopened))
        && strictly_after(first_true(deletion_receipts), first_true(deletions));
    facts.phase_gap = !facts.ordered;

    facts.regression = !monotonically_present(starts)
        || !monotonically_present(computes)
        || !monotonically_present(receipts_visible)
        || !monotonically_present(receipts_reopened)
        || !monotonically_present(authorizations_visible)
        || !monotonically_present(authorizations_reopened)
        || !monotonically_present(deletions)
        || !monotonically_present(deletion_receipts)
        || !monotonically_absent_after_loss(live_records)
        || !std::all_of(replacements.begin(), replacements.end(), [](const bool value) { return value; });

    facts.source_gap = ever(starts) && !facts.source_valid;
    facts.publication_gap = (ever(receipts_visible) && !facts.reopen_core)
        || (ever(computes) && !ever(receipts_visible));
    facts.receipt_reopen_gap = (ever(receipts_reopened) && !facts.reopen_reopen)
        || (ever(receipts_visible) && !ever(receipts_reopened));
    facts.authorization_gap = (ever(authorizations_visible) && !facts.authorization_core)
        || (ever(receipts_reopened) && !ever(authorizations_visible));
    facts.authorization_reopen_gap = (ever(authorizations_reopened) && !facts.authorization_reopen)
        || (ever(authorizations_visible) && !ever(authorizations_reopened));
    facts.deletion_gap = ever(deletion_receipts) && !facts.deletion_valid;

    const ReceiptCut& last = trace.cuts.back();
    facts.ready = facts.predecessor_ready
        && !trace.equivocation_observed
        && !facts.regression
        && facts.ordered
        && facts.source_valid
        && facts.reopen_reopen
        && facts.authorization_reopen
        && last.live_record_visible
        && !last.record_deleted
        && last.authorization_reopened
        && trace.reclamation_requested;
    facts.complete = facts.predecessor_ready
        && !trace.equivocation_observed
        && !facts.regression
        && facts.ordered
        && facts.source_valid
        && facts.reopen_reopen
        && facts.authorization_reopen
        && facts.deletion_valid
        && !last.live_record_visible
        && last.record_deleted
        && last.deletion_receipt_visible
        && trace.reclamation_requested;
    facts.unauthorized = last.record_deleted && !facts.complete;

    if (trace.equivocation_observed) {
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = true;
        return accept(ReceiptChainCode::accepted_equivocation_fail_stop, facts);
    }
    if (facts.regression) {
        facts.ordered = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = true;
        return accept(ReceiptChainCode::accepted_regression_fail_stop, facts);
    }
    if (facts.unauthorized) {
        const ReceiptChainCode code = last.deletion_receipt_visible && !deletion_core
            ? ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop
            : ReceiptChainCode::accepted_unauthorized_deletion_fail_stop;
        facts.deletion_gap = !facts.deletion_valid;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = true;
        return accept(code, facts);
    }
    if (facts.complete) {
        facts.source_valid = true;
        facts.reopen_core = true;
        facts.reopen_reopen = true;
        facts.authorization_core = true;
        facts.authorization_reopen = true;
        facts.deletion_valid = true;
        facts.ordered = true;
        facts.source_gap = false;
        facts.publication_gap = false;
        facts.receipt_reopen_gap = false;
        facts.authorization_gap = false;
        facts.authorization_reopen_gap = false;
        facts.deletion_gap = false;
        facts.phase_gap = false;
        facts.regression = false;
        facts.ready = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_chain_complete, facts);
    }
    if (facts.ready) {
        facts.source_valid = true;
        facts.reopen_core = true;
        facts.reopen_reopen = true;
        facts.authorization_core = true;
        facts.authorization_reopen = true;
        facts.ordered = true;
        facts.source_gap = false;
        facts.publication_gap = false;
        facts.receipt_reopen_gap = false;
        facts.authorization_gap = false;
        facts.authorization_reopen_gap = false;
        facts.deletion_gap = false;
        facts.phase_gap = false;
        facts.regression = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_chain_ready_live_retained, facts);
    }
    if (facts.phase_gap) {
        facts.ordered = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_reclamation_refused_order_gap, facts);
    }
    if (!facts.source_valid || facts.source_gap) {
        facts.source_valid = false;
        facts.source_gap = true;
        facts.phase_gap = false;
        facts.regression = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_reclamation_refused_source_closure_gap, facts);
    }
    if (!facts.reopen_core || facts.publication_gap) {
        facts.reopen_core = false;
        facts.source_gap = false;
        facts.publication_gap = true;
        facts.phase_gap = false;
        facts.regression = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_reclamation_refused_publication_gap, facts);
    }
    if (!facts.reopen_reopen || facts.receipt_reopen_gap) {
        facts.reopen_reopen = false;
        facts.source_gap = false;
        facts.publication_gap = false;
        facts.receipt_reopen_gap = true;
        facts.phase_gap = false;
        facts.regression = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_reclamation_refused_receipt_reopen_gap, facts);
    }
    if (!facts.authorization_core || facts.authorization_gap) {
        facts.authorization_core = false;
        facts.source_gap = false;
        facts.publication_gap = false;
        facts.receipt_reopen_gap = false;
        facts.authorization_gap = true;
        facts.phase_gap = false;
        facts.regression = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_reclamation_refused_authorization_gap, facts);
    }
    if (!facts.authorization_reopen || facts.authorization_reopen_gap) {
        facts.authorization_reopen = false;
        facts.source_gap = false;
        facts.publication_gap = false;
        facts.receipt_reopen_gap = false;
        facts.authorization_gap = false;
        facts.authorization_reopen_gap = true;
        facts.phase_gap = false;
        facts.regression = false;
        facts.ready = false;
        facts.complete = false;
        facts.fail_stop = false;
        facts.unauthorized = false;
        return accept(ReceiptChainCode::accepted_reclamation_refused_authorization_reopen_gap, facts);
    }

    facts.source_gap = false;
    facts.publication_gap = false;
    facts.receipt_reopen_gap = false;
    facts.authorization_gap = false;
    facts.authorization_reopen_gap = false;
    facts.phase_gap = false;
    facts.regression = false;
    facts.ready = false;
    facts.complete = false;
    facts.fail_stop = false;
    facts.unauthorized = false;
    return accept(ReceiptChainCode::accepted_live_basis_retained, facts);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain
