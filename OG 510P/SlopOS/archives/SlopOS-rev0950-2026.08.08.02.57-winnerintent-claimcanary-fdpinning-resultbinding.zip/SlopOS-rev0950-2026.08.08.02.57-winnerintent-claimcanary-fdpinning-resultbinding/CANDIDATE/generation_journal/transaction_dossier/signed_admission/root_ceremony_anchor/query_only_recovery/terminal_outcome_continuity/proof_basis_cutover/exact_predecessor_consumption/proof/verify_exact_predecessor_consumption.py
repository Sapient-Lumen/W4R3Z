#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

ZERO = "00" * 32
PHASES = (
    "witness_publication",
    "floor_publication",
    "join_publication",
    "cold_reopen_receipt",
    "deletion_authorization",
)


def fail(detail: str) -> None:
    raise SystemExit(f"EXACT_PREDECESSOR_CONSUMPTION_PY=FAIL detail={detail}")


def flag(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"boolean={value}")
    return value == "true"


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage OUTPUT_DIRECTORY")
    root = Path(sys.argv[1]).resolve()
    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    cases = rows(root / "CASES.tsv")
    cuts = rows(root / "CUTS.tsv")
    receipts = rows(root / "RECEIPTS.tsv")
    if len(cases) != 75 or len(cuts) != 600 or len(receipts) != 375:
        fail("cardinality")
    if summary.get("cases") != 75 or summary.get("crash_cuts") != 600:
        fail("summary cardinality")
    by_cut: dict[str, list[dict[str, str]]] = defaultdict(list)
    by_receipt: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in cuts:
        by_cut[row["case"]].append(row)
    for row in receipts:
        by_receipt[row["case"]].append(row)

    codes: Counter[str] = Counter()
    accepted = 0
    for case in cases:
        name = case["case"]
        if case["expected"] != case["code"] or not flag(case["agreement"]):
            fail(f"agreement={name}")
        if any(flag(case[key]) for key in (
            "mere_visibility_sufficient", "external_occurrence", "currentness",
            "custody", "epoch_exit", "authority",
        )):
            fail(f"forbidden projection={name}")
        accepted += int(flag(case["accepted"]))
        codes[case["code"]] += 1
        one_cuts = sorted(by_cut[name], key=lambda row: int(row["cut"]))
        one_receipts = sorted(by_receipt[name], key=lambda row: int(row["slot"]))
        if [int(row["cut"]) for row in one_cuts] != list(range(8)):
            fail(f"cut order={name}")
        if [int(row["slot"]) for row in one_receipts] != list(range(5)):
            fail(f"receipt order={name}")

        present = [flag(row["present"]) for row in one_receipts]
        subjects = True
        components = True
        expected_basis = (
            case["witness_digest"], case["floor_digest"], case["parent_cutover_id"],
            case["terminal_digest"], case["transition_digest"],
        )
        ids: list[str] = []
        publication = True
        for slot, receipt in enumerate(one_receipts):
            if not present[slot]:
                continue
            if receipt["phase"] != PHASES[slot]:
                subjects = False
            subjects = subjects and all((
                receipt["cutover_id"] == case["parent_cutover_id"],
                receipt["request_id"] == case["request_id"],
                receipt["transition_digest"] == case["transition_digest"],
                receipt["register_incarnation"] == case["register_incarnation"],
                receipt["terminal_digest"] == case["terminal_digest"],
                receipt["witness_digest"] == case["witness_digest"],
                receipt["floor_digest"] == case["floor_digest"],
                receipt["terminal_kind"] == case["terminal_kind"],
            ))
            components = components and receipt["basis_digest"] == expected_basis[slot]
            ids.append(receipt["record_digest"])
            publication = publication and all(flag(receipt[key]) for key in (
                "authenticated", "durable", "single_view", "independently_reopenable",
                "survives_restore", "survives_succession", "published",
            ))
        unique = len(ids) == len(set(ids)) and all(value != ZERO for value in ids)

        edges = True
        if present[0]:
            edges = edges and one_receipts[0]["predecessor_a"] == ZERO and one_receipts[0]["predecessor_b"] == ZERO
        if present[1]:
            edges = edges and one_receipts[1]["predecessor_a"] == ZERO and one_receipts[1]["predecessor_b"] == ZERO
        if present[2]:
            edges = edges and present[0] and present[1]
            edges = edges and one_receipts[2]["predecessor_a"] == one_receipts[0]["record_digest"]
            edges = edges and one_receipts[2]["predecessor_b"] == one_receipts[1]["record_digest"]
        if present[3]:
            edges = edges and present[2]
            edges = edges and one_receipts[3]["predecessor_a"] == one_receipts[2]["record_digest"]
            edges = edges and one_receipts[3]["predecessor_b"] == ZERO
        if present[4]:
            edges = edges and present[3]
            edges = edges and one_receipts[4]["predecessor_a"] == one_receipts[3]["record_digest"]
            edges = edges and one_receipts[4]["predecessor_b"] == ZERO
        any_delete = any(flag(row["deletion_applied"]) for row in one_cuts)
        if any_delete:
            edges = edges and present[4]
            edges = edges and case["deletion_consumed_authorization_digest"] == one_receipts[4]["record_digest"]

        first = [8] * 5
        monotone = True
        seen = [False] * 5
        deleted = False
        absent = False
        first_delete = 8
        for cut_index, cut in enumerate(one_cuts):
            visibility = [flag(cut[key]) for key in (
                "witness_receipt", "floor_receipt", "join_receipt",
                "reopen_receipt", "authorization_receipt",
            )]
            for slot, visible in enumerate(visibility):
                if visible and first[slot] == 8:
                    first[slot] = cut_index
                if seen[slot] and not visible:
                    monotone = False
                seen[slot] = seen[slot] or visible
            is_deleted = flag(cut["deletion_applied"])
            is_live = flag(cut["live_record"])
            if is_deleted and first_delete == 8:
                first_delete = cut_index
            if deleted and not is_deleted:
                monotone = False
            if absent and is_live:
                monotone = False
            deleted = deleted or is_deleted
            absent = absent or not is_live

        order = True
        if first[2] != 8:
            order = first[0] != 8 and first[1] != 8 and first[0] < first[2] and first[1] < first[2]
        if first[3] != 8:
            order = order and first[2] != 8 and first[2] < first[3]
        if first[4] != 8:
            order = order and first[3] != 8 and first[3] < first[4]
        if first_delete != 8:
            order = order and first[4] != 8 and first[4] < first_delete

        prefixes = True
        for cut in one_cuts:
            if not flag(cut["deletion_applied"]):
                prefixes = prefixes and flag(cut["live_record"])
            else:
                all_visible = all(flag(cut[key]) for key in (
                    "witness_receipt", "floor_receipt", "join_receipt",
                    "reopen_receipt", "authorization_receipt",
                ))
                prefixes = prefixes and flag(case["parent_safe"]) and all_visible and edges and publication and order
        final = one_cuts[-1]
        all_final = all(flag(final[key]) for key in (
            "witness_receipt", "floor_receipt", "join_receipt",
            "reopen_receipt", "authorization_receipt",
        ))
        complete = all(present) and all_final and edges and publication and order and monotone
        safe = (flag(case["parent_safe"]) and complete and prefixes and flag(final["deletion_applied"])
                and not flag(final["live_record"]) and not flag(case["fail_stopped"]))

        if flag(case["accepted"]):
            comparisons = {
                "subjects_exact": subjects,
                "components_exact": components,
                "digests_unique": unique,
                "exact_edges": edges,
                "durable_publications": publication,
                "strict_order": order,
                "monotone": monotone,
                "prefixes_covered": prefixes,
                "chain_complete": complete,
                "deletion_safe": safe,
            }
            for key, calculated in comparisons.items():
                if flag(case[key]) != calculated:
                    fail(f"reconstruction={name}:{key}")

    if accepted != summary["accepted_cases"] or 75 - accepted != summary["rejected_cases"]:
        fail("accepted counts")
    expected_codes = {
        "accepted_chain_complete": summary["chain_complete_cases"],
        "accepted_chain_ready_live_retained": summary["chain_ready_live_retained_cases"],
        "accepted_chain_prefix_live_retained": summary["chain_prefix_live_retained_cases"],
        "accepted_reclamation_refused_exact_predecessor": summary["exact_predecessor_refused_cases"],
        "accepted_reclamation_refused_publication": summary["publication_refused_cases"],
        "accepted_reclamation_refused_phase_order": summary["phase_order_refused_cases"],
        "accepted_reclamation_refused_prefix_gap": summary["prefix_gap_refused_cases"],
    }
    for code, count in expected_codes.items():
        if codes[code] != count:
            fail(f"code count={code}")
    required = {
        "refused_join_wrong_witness_predecessor",
        "refused_reopen_skips_join",
        "refused_authorization_not_published",
        "refused_join_same_cut_as_second_component",
        "refused_delete_same_cut_as_authorization",
        "refused_parent_not_reclamation_safe",
        "witness_visibility_regression_fail_stop",
        "reject_subject_incarnation_mismatch",
        "reject_duplicate_receipt_digest",
    }
    names = {row["case"] for row in cases}
    if not required <= names:
        fail(f"countermodels={sorted(required - names)}")
    print(
        "EXACT_PREDECESSOR_CONSUMPTION_PY=PASS cases=75 cuts=600 "
        f"accepted={accepted} rejected={75-accepted} complete={summary['chain_complete_cases']} "
        f"ready={summary['chain_ready_live_retained_cases']} exact_refused={summary['exact_predecessor_refused_cases']} "
        "mere_visibility_sufficient=0 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
