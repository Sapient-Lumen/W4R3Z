#!/usr/bin/env python3
"""Independent byte-level verifier for the Epoch-Zero root-succession capsule.

This verifier deliberately does not import or execute the C++ implementation.  It
reparses every retained fixture, verifies Ed25519 signatures with an independent
library, replays the local root-register transition, and checks retained receipts.
It proves only the finite hosted mechanism described by the capsule; every
owner/currentness/custody/authority projection remains false.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
from dataclasses import dataclass
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ZERO = b"\0" * 32
MAX_U64 = 2**64 - 1
MANIFEST_BYTES = 384
STATEMENT_BYTES = 320
ENVELOPE_BYTES = 1024
SIGNING_MESSAGE_BYTES = 360
RECEIPT_BYTES = 256
REGISTER_BYTES = 112
MAX_KEYS = 3

MANIFEST_MAGIC = b"SLOPOM01"
STATEMENT_MAGIC = b"SLOPRS01"
ENVELOPE_MAGIC = b"SLOPRE01"
RECEIPT_MAGIC = b"SLOPRR01"


def digest(domain: bytes, payload: bytes) -> bytes:
    return hashlib.sha256(domain + b"\0" + payload).digest()


def key_id(public_key: bytes) -> bytes:
    return digest(b"SlopOS/admission/key-id/v1", public_key)


def manifest_head(raw: bytes) -> bytes:
    return digest(b"SlopOS/admission/manifest-head/v1", raw)


def statement_head(raw: bytes) -> bytes:
    return digest(b"SlopOS/root-succession/statement-head/v1", raw)


def signing_message(statement: bytes) -> bytes:
    domain = b"SlopOS/root-succession/v1/DTE"
    result = bytearray(SIGNING_MESSAGE_BYTES)
    result[: len(domain)] = domain
    struct.pack_into(">Q", result, 32, len(statement))
    result[40:] = statement
    return bytes(result)


@dataclass(frozen=True)
class Manifest:
    raw: bytes
    project_id: bytes
    constitution_id: bytes
    predecessor: bytes
    version: int
    threshold: int
    keys: tuple[tuple[bytes, bytes], ...]


@dataclass(frozen=True)
class Statement:
    raw: bytes
    project_id: bytes
    predecessor_head: bytes
    successor_head: bytes
    precommitted_successor_head: bytes
    register_id: bytes
    ceremony_id: bytes
    predecessor_version: int
    successor_version: int
    not_before: int
    expires_at: int
    nonce: int


@dataclass(frozen=True)
class Envelope:
    raw: bytes
    statement: Statement
    predecessor_signatures: tuple[tuple[bytes, bytes], ...]
    successor_signatures: tuple[tuple[bytes, bytes], ...]


@dataclass(frozen=True)
class Register:
    register_id: bytes
    current_head: bytes
    precommit_head: bytes
    current_version: int
    ordinal: int

    def encode(self) -> bytes:
        return b"".join(
            (
                self.register_id,
                self.current_head,
                self.precommit_head,
                struct.pack(">QQ", self.current_version, self.ordinal),
            )
        )


@dataclass(frozen=True)
class Evidence:
    code: str
    valid: bool
    predecessor_verified: int = 0
    successor_verified: int = 0


@dataclass(frozen=True)
class Apply:
    code: str
    register: Register
    committed: bool
    query_only: bool
    receipt: bytes | None


def parse_manifest(raw: bytes) -> Manifest | None:
    if len(raw) != MANIFEST_BYTES:
        return None
    if (
        raw[:8] != MANIFEST_MAGIC
        or struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 1
        or struct.unpack_from(">I", raw, 12)[0] != MANIFEST_BYTES
        or raw[16] != 1
        or raw[19] != 0
        or any(raw[20:32])
        or any(raw[136:160])
        or raw[352:384]
        != digest(b"SlopOS/admission/manifest-integrity/v1", raw[:352])
    ):
        return None
    threshold, key_count = raw[17], raw[18]
    project_id, constitution_id, predecessor = raw[32:64], raw[64:96], raw[96:128]
    version = struct.unpack_from(">Q", raw, 128)[0]
    if (
        project_id == ZERO
        or constitution_id == ZERO
        or version == 0
        or key_count == 0
        or key_count > MAX_KEYS
        or threshold == 0
        or threshold > key_count
    ):
        return None
    keys: list[tuple[bytes, bytes]] = []
    for index in range(MAX_KEYS):
        base = 160 + index * 64
        kid, public_key = raw[base : base + 32], raw[base + 32 : base + 64]
        if index < key_count:
            if kid == ZERO or public_key == ZERO or kid != key_id(public_key):
                return None
            if keys and not keys[-1][0] < kid:
                return None
            keys.append((kid, public_key))
        elif kid != ZERO or public_key != ZERO:
            return None
    return Manifest(raw, project_id, constitution_id, predecessor, version, threshold, tuple(keys))


def parse_statement(raw: bytes) -> Statement | None:
    if len(raw) != STATEMENT_BYTES:
        return None
    if (
        raw[:8] != STATEMENT_MAGIC
        or struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 4
        or struct.unpack_from(">I", raw, 12)[0] != STATEMENT_BYTES
        or raw[16] != 1
        or raw[17] != 1
        or any(raw[18:32])
        or any(raw[264:288])
        or raw[288:320]
        != digest(b"SlopOS/root-succession/statement-integrity/v1", raw[:288])
    ):
        return None
    digests = tuple(raw[offset : offset + 32] for offset in range(32, 224, 32))
    pred_version, succ_version, not_before, expires_at, nonce = struct.unpack_from(">QQQQQ", raw, 224)
    if (
        any(item == ZERO for item in digests)
        or pred_version in (0, MAX_U64)
        or succ_version == 0
        or not_before >= expires_at
        or nonce == 0
    ):
        return None
    return Statement(raw, *digests, pred_version, succ_version, not_before, expires_at, nonce)


def parse_envelope(raw: bytes) -> Envelope | None:
    if len(raw) != ENVELOPE_BYTES:
        return None
    if (
        raw[:8] != ENVELOPE_MAGIC
        or struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 5
        or struct.unpack_from(">I", raw, 12)[0] != ENVELOPE_BYTES
        or raw[18] != 1
        or any(raw[19:32])
        or any(raw[928:992])
        or raw[992:1024]
        != digest(b"SlopOS/root-succession/envelope-integrity/v1", raw[:992])
    ):
        return None
    predecessor_count, successor_count = raw[16], raw[17]
    if not 1 <= predecessor_count <= MAX_KEYS or not 1 <= successor_count <= MAX_KEYS:
        return None
    statement = parse_statement(raw[32:352])
    if statement is None:
        return None

    def slots(offset: int, count: int) -> tuple[tuple[bytes, bytes], ...] | None:
        active: list[tuple[bytes, bytes]] = []
        for index in range(MAX_KEYS):
            base = offset + index * 96
            kid, signature = raw[base : base + 32], raw[base + 32 : base + 96]
            if index < count:
                if kid == ZERO or signature == b"\0" * 64:
                    return None
                active.append((kid, signature))
            elif kid != ZERO or signature != b"\0" * 64:
                return None
        return tuple(active)

    predecessor = slots(352, predecessor_count)
    successor = slots(640, successor_count)
    if predecessor is None or successor is None:
        return None
    return Envelope(raw, statement, predecessor, successor)


def verify_threshold(
    manifest: Manifest,
    signatures: tuple[tuple[bytes, bytes], ...],
    message: bytes,
    side: str,
) -> tuple[bool, int, str]:
    observed: set[bytes] = set()
    public_keys = dict(manifest.keys)
    verified = 0
    for kid, signature in signatures:
        if kid in observed:
            return False, verified, f"{side}_duplicate_signer"
        observed.add(kid)
        public_key = public_keys.get(kid)
        if public_key is None:
            return False, verified, f"{side}_unknown_signer"
        try:
            Ed25519PublicKey.from_public_bytes(public_key).verify(signature, message)
        except (InvalidSignature, ValueError):
            return False, verified, f"{side}_invalid_signature"
        verified += 1
    if verified < manifest.threshold:
        return False, verified, f"{side}_below_threshold"
    return True, verified, "evidence_valid"


def validate(predecessor_raw: bytes, successor_raw: bytes, envelope_raw: bytes, observed_time: int) -> Evidence:
    predecessor = parse_manifest(predecessor_raw)
    if predecessor is None:
        return Evidence("invalid_predecessor_manifest", False)
    successor = parse_manifest(successor_raw)
    if successor is None:
        return Evidence("invalid_successor_manifest", False)
    envelope = parse_envelope(envelope_raw)
    if envelope is None:
        return Evidence("invalid_envelope", False)
    statement = envelope.statement
    # parse_envelope necessarily performed the statement decode.  Retain this
    # branch name in the model for parity with the public C++ enum.
    if statement is None:  # pragma: no cover - structurally unreachable
        return Evidence("invalid_statement", False)
    if predecessor.project_id != successor.project_id or statement.project_id != predecessor.project_id:
        return Evidence("project_mismatch", False)
    predecessor_digest = manifest_head(predecessor_raw)
    successor_digest = manifest_head(successor_raw)
    if successor.predecessor != predecessor_digest:
        return Evidence("predecessor_chain_mismatch", False)
    if (
        predecessor.version == MAX_U64
        or successor.version != predecessor.version + 1
        or statement.predecessor_version != predecessor.version
        or statement.successor_version != successor.version
    ):
        return Evidence("version_not_next", False)
    if statement.predecessor_head != predecessor_digest or statement.successor_head != successor_digest:
        return Evidence("statement_binding_mismatch", False)
    if statement.precommitted_successor_head != successor_digest:
        return Evidence("statement_precommit_mismatch", False)
    if observed_time < statement.not_before or observed_time >= statement.expires_at:
        return Evidence("time_window_mismatch", False)
    message = signing_message(statement.raw)
    ok, predecessor_verified, code = verify_threshold(
        predecessor, envelope.predecessor_signatures, message, "predecessor"
    )
    if not ok:
        return Evidence(code, False, predecessor_verified, 0)
    ok, successor_verified, code = verify_threshold(
        successor, envelope.successor_signatures, message, "successor"
    )
    if not ok:
        return Evidence(code, False, predecessor_verified, successor_verified)
    return Evidence("evidence_valid", True, predecessor_verified, successor_verified)


def parse_register(raw: bytes) -> Register:
    if len(raw) != REGISTER_BYTES:
        raise ValueError(f"register has {len(raw)} bytes, expected {REGISTER_BYTES}")
    return Register(raw[:32], raw[32:64], raw[64:96], *struct.unpack_from(">QQ", raw, 96))


def encode_receipt(statement: Statement, ordinal: int, observed_time: int, disposition: int) -> bytes:
    query_only = disposition != 1
    if disposition not in (1, 2, 3) or ordinal == 0 or observed_time == 0:
        raise ValueError("invalid receipt premise")
    result = bytearray(RECEIPT_BYTES)
    result[:8] = RECEIPT_MAGIC
    struct.pack_into(">HHI", result, 8, 1, 6, RECEIPT_BYTES)
    result[16] = disposition
    result[17] = int(query_only)
    result[32:64] = statement.register_id
    result[64:96] = statement.predecessor_head
    result[96:128] = statement.successor_head
    result[128:160] = statement_head(statement.raw)
    result[160:192] = statement.ceremony_id
    struct.pack_into(
        ">QQQQ",
        result,
        192,
        statement.predecessor_version,
        statement.successor_version,
        ordinal,
        observed_time,
    )
    result[224:256] = digest(b"SlopOS/root-succession/receipt-integrity/v1", bytes(result[:224]))
    return bytes(result)


def parse_receipt(raw: bytes) -> dict[str, object] | None:
    if len(raw) != RECEIPT_BYTES:
        return None
    if (
        raw[:8] != RECEIPT_MAGIC
        or struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 6
        or struct.unpack_from(">I", raw, 12)[0] != RECEIPT_BYTES
        or raw[17] > 1
        or any(raw[18:32])
        or raw[224:256] != digest(b"SlopOS/root-succession/receipt-integrity/v1", raw[:224])
    ):
        return None
    disposition, query_only = raw[16], bool(raw[17])
    pred_version, succ_version, ordinal, observed_time = struct.unpack_from(">QQQQ", raw, 192)
    values = tuple(raw[offset : offset + 32] for offset in range(32, 192, 32))
    if (
        disposition not in (1, 2, 3)
        or query_only != (disposition != 1)
        or any(item == ZERO for item in values)
        or pred_version in (0, MAX_U64)
        or succ_version != pred_version + 1
        or ordinal == 0
        or observed_time == 0
    ):
        return None
    return {
        "disposition": disposition,
        "query_only": query_only,
        "register_id": values[0],
        "predecessor_head": values[1],
        "successor_head": values[2],
        "statement_head": values[3],
        "ceremony_id": values[4],
        "predecessor_version": pred_version,
        "successor_version": succ_version,
        "ordinal": ordinal,
        "observed_time": observed_time,
    }


def apply(
    register: Register,
    predecessor_raw: bytes,
    successor_raw: bytes,
    envelope_raw: bytes,
    observed_time: int,
    reply_cut: str,
) -> Apply:
    evidence = validate(predecessor_raw, successor_raw, envelope_raw, observed_time)
    if not evidence.valid:
        return Apply("invalid_evidence", register, False, False, None)
    envelope = parse_envelope(envelope_raw)
    assert envelope is not None
    statement = envelope.statement
    if register.register_id != statement.register_id:
        return Apply("register_id_mismatch", register, False, False, None)
    if register.current_head == statement.successor_head and register.current_version == statement.successor_version:
        return Apply(
            "already_current_query_only",
            register,
            False,
            True,
            encode_receipt(statement, register.ordinal, observed_time, 2),
        )
    if register.current_head != statement.predecessor_head or register.current_version != statement.predecessor_version:
        return Apply("stale_current", register, False, False, None)
    if register.precommit_head != statement.successor_head:
        return Apply("register_precommit_mismatch", register, False, False, None)
    if register.ordinal == MAX_U64:
        return Apply("stale_current", register, False, False, None)
    after = Register(
        register.register_id,
        statement.successor_head,
        ZERO,
        statement.successor_version,
        register.ordinal + 1,
    )
    if reply_cut == "reply_delivered":
        return Apply("committed", after, True, False, encode_receipt(statement, after.ordinal, observed_time, 1))
    if reply_cut == "reply_lost_after_commit":
        return Apply(
            "uncertain_after_commit_query_only",
            after,
            True,
            True,
            encode_receipt(statement, after.ordinal, observed_time, 3),
        )
    raise ValueError(f"unknown reply cut: {reply_cut}")


def text_bool(value: str) -> bool:
    if value not in ("true", "false"):
        raise ValueError(f"invalid boolean text: {value}")
    return value == "true"


def verify_campaign(root: Path) -> dict[str, object]:
    rows = list(csv.DictReader((root / "cases.tsv").open(newline=""), delimiter="\t"))
    if len(rows) != 28:
        raise ValueError(f"expected 28 cases, found {len(rows)}")
    valid = rejected = committed = query_only = receipts = 0
    for row in rows:
        case_root = root / row["path"]
        predecessor_raw = (case_root / "predecessor.bin").read_bytes()
        successor_raw = (case_root / "successor.bin").read_bytes()
        envelope_raw = (case_root / "envelope.bin").read_bytes()
        before_raw = (case_root / "register-before.bin").read_bytes()
        after_raw = (case_root / "register-after.bin").read_bytes()
        observed_time = int(row["observed_time"])
        evidence = validate(predecessor_raw, successor_raw, envelope_raw, observed_time)
        result = apply(
            parse_register(before_raw),
            predecessor_raw,
            successor_raw,
            envelope_raw,
            observed_time,
            row["reply_cut"],
        )
        expected_valid = text_bool(row["expected_valid"])
        expected_committed = text_bool(row["expected_committed"])
        expected_query_only = text_bool(row["expected_query_only"])
        expected_receipt = text_bool(row["receipt_present"])
        checks = {
            "evidence code": evidence.code == row["expected_evidence_code"] == row["candidate_evidence_code"] == row["reference_evidence_code"],
            "apply code": result.code == row["expected_apply_code"] == row["candidate_apply_code"] == row["reference_apply_code"],
            "valid": evidence.valid == expected_valid,
            "committed": result.committed == expected_committed,
            "query only": result.query_only == expected_query_only,
            "predecessor signatures": evidence.predecessor_verified == int(row["predecessor_verified"]),
            "successor signatures": evidence.successor_verified == int(row["successor_verified"]),
            "register after": result.register.encode() == after_raw,
            "receipt presence": (result.receipt is not None) == expected_receipt,
            "all authority projections false": all(
                row[name] == "false"
                for name in (
                    "owner_constitution_proved",
                    "currentness_proved",
                    "independent_custody_proved",
                    "protected_transition_proved",
                    "independent_reopen_proved",
                    "epoch_exit_proved",
                    "authority_granted",
                )
            ),
        }
        failed = [name for name, ok in checks.items() if not ok]
        if failed:
            raise ValueError(f"{row['case']}: " + ", ".join(failed))
        receipt_path = case_root / "receipt.bin"
        if result.receipt is not None:
            retained = receipt_path.read_bytes()
            if retained != result.receipt or parse_receipt(retained) is None:
                raise ValueError(f"{row['case']}: receipt mismatch or invalid")
            receipts += 1
        elif receipt_path.exists():
            raise ValueError(f"{row['case']}: unexpected retained receipt")
        valid += int(evidence.valid)
        rejected += int(not evidence.valid)
        committed += int(result.committed)
        query_only += int(result.query_only)

    campaign = json.loads((root / "campaign-audit.json").read_text())
    fork = json.loads((root / "currentness-fork-audit.json").read_text())
    expected_campaign = {
        "status": "PASS",
        "manifest_bytes": MANIFEST_BYTES,
        "statement_bytes": STATEMENT_BYTES,
        "envelope_bytes": ENVELOPE_BYTES,
        "signing_message_bytes": SIGNING_MESSAGE_BYTES,
        "receipt_bytes": RECEIPT_BYTES,
        "cases": len(rows),
        "valid_evidence_cases": valid,
        "rejected_evidence_cases": rejected,
        "committed_local_transitions": committed,
        "query_only_results": query_only,
        "candidate_reference_disagreements": 0,
        "real_ed25519": True,
        "dual_threshold": True,
        "exact_n_plus_one": True,
        "precommit_required": True,
        "signing_api_exposed": False,
        "owner_constitution_proved": False,
        "currentness_proved": False,
        "independent_custody_proved": False,
        "protected_transition_proved": False,
        "independent_reopen_proved": False,
        "epoch_exit_true_results": 0,
        "authority_true_results": 0,
    }
    for key, value in expected_campaign.items():
        if campaign.get(key) != value:
            raise ValueError(f"campaign audit {key}: {campaign.get(key)!r} != {value!r}")
    expected_fork = {
        "identical_register_copies": 3,
        "identical_envelope_copies": 2,
        "same_root_local_commits": 2,
        "stale_copy_still_reports_predecessor": True,
        "same_root_receipt_reopen": True,
        "single_global_current_head_proved": False,
        "protected_transition_proved": False,
        "independent_reopen_proved": False,
        "authority_granted": False,
    }
    for key, value in expected_fork.items():
        if fork.get(key) != value:
            raise ValueError(f"fork audit {key}: {fork.get(key)!r} != {value!r}")
    return {
        "schema": "slopos.rev0914.root-succession-python-verification.v1",
        "status": "PASS",
        "cases": len(rows),
        "valid_evidence_cases": valid,
        "rejected_evidence_cases": rejected,
        "committed_local_transitions": committed,
        "query_only_results": query_only,
        "retained_receipts": receipts,
        "candidate_reference_disagreements": 0,
        "independent_byte_parser": True,
        "independent_ed25519_verifier": True,
        "same_root_clone_countermodel_retained": True,
        "owner_constitution_proved": False,
        "currentness_proved": False,
        "independent_custody_proved": False,
        "protected_transition_proved": False,
        "independent_reopen_proved": False,
        "epoch_exit_proved": False,
        "authority_granted": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign_directory", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify_campaign(args.campaign_directory)
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(
        "ROOT_SUCCESSION_PYTHON_VERIFICATION=PASS "
        f"cases={result['cases']} valid={result['valid_evidence_cases']} "
        f"rejected={result['rejected_evidence_cases']} commits={result['committed_local_transitions']} "
        "owner_constitution=false currentness=false protected_transition=false "
        "independent_reopen=false epoch_exit=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
