#pragma once

#include "slopos/e0/signed_admission/root_succession.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor {

using signed_admission::Digest;
using root_succession::EncodedRootStatement;

inline constexpr std::size_t kAnchorBytes = 512U;
using EncodedAnchor = std::array<std::uint8_t, kAnchorBytes>;

struct RootCeremonyAnchorV1 final {
    Digest project_id{};
    Digest register_id{};
    Digest register_incarnation{};
    Digest predecessor_manifest_head{};
    Digest successor_manifest_head{};
    Digest rc0_starting_root_receipt_head{};
    Digest rc1_precommit_receipt_head{};
    Digest precommit_operation_id{};
    Digest policy_head{};
    Digest transition_digest{};
    Digest request_id{};
    std::uint64_t predecessor_version{0U};
    std::uint64_t successor_version{0U};
    std::uint64_t precommit_recorded_at{0U};
    std::uint64_t signing_not_before{0U};
    std::uint64_t expires_at{0U};
    std::uint64_t request_deadline{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const RootCeremonyAnchorV1&,
        const RootCeremonyAnchorV1&) noexcept = default;
};

enum class RelationCode : std::uint8_t {
    relation_valid,
    invalid_anchor,
    invalid_statement,
    missing_identity,
    receipt_collision,
    version_not_next,
    transition_digest_mismatch,
    request_id_mismatch,
    precommit_chronology_invalid,
    time_window_invalid,
    statement_project_mismatch,
    statement_register_mismatch,
    statement_heads_mismatch,
    statement_versions_mismatch,
    statement_precommit_mismatch,
    statement_ceremony_mismatch,
    statement_time_mismatch,
    statement_nonce_mismatch,
    observed_outside_window,
};

struct RelationReport final {
    RelationCode code{RelationCode::invalid_anchor};
    bool valid{false};
    bool canonical_anchor{false};
    bool canonical_statement{false};
    bool external_receipts_bound{false};
    bool register_incarnation_bound{false};
    bool exact_next_version{false};
    bool transition_digest_match{false};
    bool deterministic_request_id{false};
    bool precommit_precedes_signing{false};
    bool statement_bound{false};
    bool observed_in_window{false};
    bool external_receipt_authenticity_proved{false};
    bool owner_constitution_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool protected_transition_proved{false};
    bool independent_reopen_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const RelationReport&, const RelationReport&) noexcept = default;
};

[[nodiscard]] Digest transition_digest_for(const RootCeremonyAnchorV1& value);
[[nodiscard]] Digest request_id_for(const RootCeremonyAnchorV1& value);
[[nodiscard]] Digest anchor_head(const EncodedAnchor& anchor);
[[nodiscard]] std::uint64_t request_nonce(const Digest& request_id) noexcept;

[[nodiscard]] bool encode_anchor(
    const RootCeremonyAnchorV1& value,
    EncodedAnchor& output);
[[nodiscard]] bool decode_anchor(
    const EncodedAnchor& input,
    RootCeremonyAnchorV1& output);

[[nodiscard]] RelationReport validate_candidate(
    const EncodedAnchor& anchor,
    const EncodedRootStatement& statement,
    std::uint64_t observed_time);
[[nodiscard]] RelationReport validate_reference(
    const EncodedAnchor& anchor,
    const EncodedRootStatement& statement,
    std::uint64_t observed_time);

[[nodiscard]] std::string_view relation_code_name(RelationCode value) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor
