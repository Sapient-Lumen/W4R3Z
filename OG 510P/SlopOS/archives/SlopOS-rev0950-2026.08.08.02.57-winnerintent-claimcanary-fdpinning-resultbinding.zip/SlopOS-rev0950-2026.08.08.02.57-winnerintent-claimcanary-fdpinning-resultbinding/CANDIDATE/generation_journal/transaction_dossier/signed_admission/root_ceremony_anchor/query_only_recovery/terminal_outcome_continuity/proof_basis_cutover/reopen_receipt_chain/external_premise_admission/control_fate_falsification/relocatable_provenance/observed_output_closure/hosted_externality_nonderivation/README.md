# Hosted Externality Nonderivation V1

This C++20 child refines one closure-ready Observed Output Closure trace. It constructs byte-identical hosted observations in modeled worlds whose external facts differ, proving a bounded nonderivation statement: hosted bytes cannot by themselves establish the external facts that are not encoded in those bytes.

The child emits four exact objects: a hosted observation, a twin-world countermodel witness, a request-only owner handoff subject, and a premise-deficit certificate. The request is not a response; the certificate keeps every requested premise unresolved.

The child adds no provider, network service, owner registry, signer, database, publisher, deletion worker, or fourth semantic island. It does not prove either modeled world occurred.
