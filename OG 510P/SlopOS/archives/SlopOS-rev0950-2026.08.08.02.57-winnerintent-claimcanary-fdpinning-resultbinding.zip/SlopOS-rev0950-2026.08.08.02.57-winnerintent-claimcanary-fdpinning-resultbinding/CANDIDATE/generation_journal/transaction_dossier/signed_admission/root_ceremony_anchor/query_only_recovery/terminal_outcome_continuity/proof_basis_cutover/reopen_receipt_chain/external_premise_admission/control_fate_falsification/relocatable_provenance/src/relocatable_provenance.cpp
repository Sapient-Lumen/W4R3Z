#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance {
namespace {

constexpr std::array<std::uint8_t, 32U> domain(const std::string_view text) noexcept {
    std::array<std::uint8_t, 32U> value{};
    const std::size_t count = std::min(text.size(), value.size());
    for (std::size_t index = 0U; index < count; ++index) {
        value[index] = static_cast<std::uint8_t>(text[index]);
    }
    return value;
}

inline constexpr auto source_domain = domain("SlopOS/RPC/source-closure/v1");
inline constexpr auto plan_domain = domain("SlopOS/RPC/build-plan/v1");
inline constexpr auto capsule_domain = domain("SlopOS/RPC/provenance-capsule/v1");
inline constexpr auto claim_domain = domain("SlopOS/RPC/build-claim/v1");
inline constexpr auto receipt_domain = domain("SlopOS/RPC/reopen-receipt/v1");

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.begin(), value.end(), [](const std::uint8_t byte) { return byte != 0U; });
}

template <std::size_t N>
class Writer final {
public:
    explicit Writer(std::array<std::uint8_t, N>& bytes) noexcept : bytes_(bytes) { bytes_.fill(0U); }

    void u8(const std::uint8_t value) noexcept {
        if (position_ < body_end()) bytes_[position_++] = value;
        else overflow_ = true;
    }

    void u16(const std::uint16_t value) noexcept {
        u8(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        u8(static_cast<std::uint8_t>(value & 0xffU));
    }

    void u64(const std::uint64_t value) noexcept {
        for (std::size_t shift = 56U;; shift -= 8U) {
            u8(static_cast<std::uint8_t>((value >> shift) & 0xffU));
            if (shift == 0U) break;
        }
    }

    void boolean(const bool value) noexcept { u8(value ? 1U : 0U); }

    template <std::size_t M>
    void fixed(const std::array<std::uint8_t, M>& value) noexcept {
        for (const auto byte : value) u8(byte);
    }

    [[nodiscard]] bool seal() noexcept {
        if (overflow_) return false;
        while (position_ < body_end()) bytes_[position_++] = 0U;
        const Digest integrity = generation_journal::sha256(
            std::span<const std::uint8_t>(bytes_.data(), body_end()));
        std::copy(integrity.begin(), integrity.end(), bytes_.begin() + static_cast<std::ptrdiff_t>(body_end()));
        return true;
    }

private:
    [[nodiscard]] static constexpr std::size_t body_end() noexcept { return N - Digest{}.size(); }
    std::array<std::uint8_t, N>& bytes_;
    std::size_t position_{0U};
    bool overflow_{false};
};

template <std::size_t N>
[[nodiscard]] Digest encoded_identity(const std::array<std::uint8_t, N>& bytes) noexcept {
    return generation_journal::sha256(std::span<const std::uint8_t>(bytes.data(), bytes.size()));
}

[[nodiscard]] bool zero_source_entry(const SourceEntry& value) noexcept {
    return value == SourceEntry{};
}

[[nodiscard]] int path_compare(const SourceEntry& left, const SourceEntry& right) noexcept {
    const std::size_t count = std::min<std::size_t>(left.path_length, right.path_length);
    for (std::size_t index = 0U; index < count; ++index) {
        if (left.path[index] < right.path[index]) return -1;
        if (left.path[index] > right.path[index]) return 1;
    }
    if (left.path_length < right.path_length) return -1;
    if (left.path_length > right.path_length) return 1;
    return 0;
}

[[nodiscard]] bool source_shape(const SourceClosure& value) noexcept {
    if (!value.present || !value.canonical || value.entry_count == 0U
        || value.entry_count > max_source_entries || !nonzero(value.closure_digest)
        || !nonzero(value.logical_root_digest) || !nonzero(value.parent_challenge_receipt_digest)) {
        return false;
    }
    for (std::size_t index = value.entry_count; index < value.entries.size(); ++index) {
        if (!zero_source_entry(value.entries[index])) return false;
    }
    return true;
}

[[nodiscard]] bool source_paths(const SourceClosure& value) noexcept {
    for (std::size_t index = 0U; index < value.entry_count; ++index) {
        if (!portable_path_valid(value.entries[index])) return false;
        if (index > 0U && path_compare(value.entries[index - 1U], value.entries[index]) >= 0) return false;
    }
    return true;
}

[[nodiscard]] bool source_entries(const SourceClosure& value) noexcept {
    for (std::size_t index = 0U; index < value.entry_count; ++index) {
        const auto& entry = value.entries[index];
        if (!entry.present || !entry.regular_file || !nonzero(entry.content_digest)
            || entry.bytes == 0U || (entry.mode != mode_read_only && entry.mode != mode_read_execute)) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool build_shape(const BuildPlan& value) noexcept {
    return value.present && value.canonical && nonzero(value.plan_digest)
        && nonzero(value.build_type_digest) && nonzero(value.toolchain_digest)
        && nonzero(value.flags_digest) && nonzero(value.environment_policy_digest)
        && nonzero(value.dependency_closure_digest) && nonzero(value.output_spec_digest)
        && nonzero(value.deterministic_input_digest);
}

[[nodiscard]] bool capsule_shape(const ProvenanceCapsule& value) noexcept {
    return value.present && value.canonical && nonzero(value.capsule_digest)
        && nonzero(value.parent_challenge_receipt_digest) && nonzero(value.logical_root_digest)
        && nonzero(value.source_closure_digest) && nonzero(value.build_plan_digest)
        && nonzero(value.expected_output_digest) && nonzero(value.claim_policy_digest);
}

[[nodiscard]] bool observation_shape(const BuildObservation& value) noexcept {
    return value.present && nonzero(value.claim_digest) && nonzero(value.capsule_digest)
        && nonzero(value.source_closure_digest) && nonzero(value.build_plan_digest)
        && nonzero(value.output_digest) && nonzero(value.physical_locator_digest)
        && nonzero(value.raw_log_digest) && value.exact_inputs_consumed
        && value.output_set_complete && !value.hidden_input_observed;
}

[[nodiscard]] bool observation_binding(
    const BuildObservation& value,
    const RelocationTrace& trace) noexcept {
    return value.capsule_digest == trace.capsule.capsule_digest
        && value.source_closure_digest == trace.source_closure.closure_digest
        && value.build_plan_digest == trace.build_plan.plan_digest;
}

[[nodiscard]] bool receipt_shape(const ProvenanceReopenReceipt& value) noexcept {
    return value.present && value.durable && value.independently_administered
        && value.exact_subject_reopened && nonzero(value.receipt_digest)
        && nonzero(value.claim_digest) && nonzero(value.capsule_digest)
        && nonzero(value.source_closure_digest) && nonzero(value.build_plan_digest)
        && nonzero(value.output_digest) && nonzero(value.reopener_digest);
}

[[nodiscard]] bool receipt_binding(
    const ProvenanceReopenReceipt& value,
    const BuildObservation& observation,
    const RelocationTrace& trace) noexcept {
    return value.claim_digest == observation.claim_digest
        && value.capsule_digest == trace.capsule.capsule_digest
        && value.source_closure_digest == trace.source_closure.closure_digest
        && value.build_plan_digest == trace.build_plan.plan_digest
        && value.output_digest == observation.output_digest;
}

[[nodiscard]] bool cuts_exact(const RelocationTrace& trace) noexcept {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        ProvenanceCut expected{};
        expected.source_closure_digest = trace.source_closure.closure_digest;
        if (index >= 1U) expected.build_plan_digest = trace.build_plan.plan_digest;
        if (index >= 2U) expected.capsule_digest = trace.capsule.capsule_digest;
        if (index >= 3U) expected.first_claim_digest = trace.first_observation.claim_digest;
        if (index >= 4U) expected.first_receipt_digest = trace.first_receipt.receipt_digest;
        if (index >= 5U) expected.relocated_claim_digest = trace.relocated_observation.claim_digest;
        if (index >= 6U) expected.relocated_receipt_digest = trace.relocated_receipt.receipt_digest;
        if (trace.cuts[index] != expected) return false;
    }
    return true;
}

[[nodiscard]] ProvenanceReport stop(
    const ProvenanceCode code,
    const bool parent_accepted = false,
    const bool parent_clean = false,
    const bool parent_live = false) noexcept {
    ProvenanceReport report{};
    report.code = code;
    report.parent_accepted = parent_accepted;
    report.parent_clean_supplied_closure = parent_clean;
    report.parent_live_record_retained = parent_live;
    return report;
}

}  // namespace

bool portable_path_valid(const SourceEntry& entry) noexcept {
    if (entry.path_length == 0U || entry.path_length > entry.path.size()) return false;
    if (entry.path[0] == static_cast<std::uint8_t>('/')) return false;
    if (entry.path[entry.path_length - 1U] == static_cast<std::uint8_t>('/')) return false;
    std::size_t segment_length = 0U;
    bool segment_single_dot = false;
    bool segment_double_dot = false;
    for (std::size_t index = 0U; index < entry.path_length; ++index) {
        const std::uint8_t byte = entry.path[index];
        const bool allowed = (byte >= static_cast<std::uint8_t>('a') && byte <= static_cast<std::uint8_t>('z'))
            || (byte >= static_cast<std::uint8_t>('0') && byte <= static_cast<std::uint8_t>('9'))
            || byte == static_cast<std::uint8_t>('.') || byte == static_cast<std::uint8_t>('_')
            || byte == static_cast<std::uint8_t>('-') || byte == static_cast<std::uint8_t>('/');
        if (!allowed) return false;
        if (byte == static_cast<std::uint8_t>('/')) {
            if (segment_length == 0U || segment_single_dot || segment_double_dot) return false;
            segment_length = 0U;
            segment_single_dot = false;
            segment_double_dot = false;
            continue;
        }
        ++segment_length;
        segment_single_dot = segment_length == 1U && byte == static_cast<std::uint8_t>('.');
        segment_double_dot = segment_length == 2U && entry.path[index - 1U] == static_cast<std::uint8_t>('.')
            && byte == static_cast<std::uint8_t>('.');
        if (segment_length > 2U) {
            segment_single_dot = false;
            segment_double_dot = false;
        }
    }
    if (segment_length == 0U || segment_single_dot || segment_double_dot) return false;
    for (std::size_t index = entry.path_length; index < entry.path.size(); ++index) {
        if (entry.path[index] != 0U) return false;
    }
    return true;
}

bool encode_source_closure(const SourceClosure& value, EncodedSourceClosure& output) noexcept {
    Writer writer(output);
    writer.fixed(source_domain);
    writer.fixed(value.logical_root_digest);
    writer.fixed(value.parent_challenge_receipt_digest);
    writer.u8(value.entry_count);
    writer.boolean(value.present);
    writer.boolean(value.canonical);
    writer.boolean(value.complete);
    writer.boolean(value.hidden_inputs_absent);
    writer.u8(0U);
    writer.u16(1U);
    for (const auto& entry : value.entries) {
        writer.fixed(entry.path);
        writer.fixed(entry.content_digest);
        writer.u64(entry.bytes);
        writer.u16(entry.mode);
        writer.u8(entry.path_length);
        writer.boolean(entry.present);
        writer.boolean(entry.regular_file);
        writer.u8(0U);
        writer.u16(0U);
    }
    return writer.seal();
}

Digest source_closure_identity(const SourceClosure& value) noexcept {
    EncodedSourceClosure bytes{};
    if (!encode_source_closure(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_build_plan(const BuildPlan& value, EncodedBuildPlan& output) noexcept {
    Writer writer(output);
    writer.fixed(plan_domain);
    writer.fixed(value.build_type_digest);
    writer.fixed(value.toolchain_digest);
    writer.fixed(value.flags_digest);
    writer.fixed(value.environment_policy_digest);
    writer.fixed(value.dependency_closure_digest);
    writer.fixed(value.output_spec_digest);
    writer.fixed(value.deterministic_input_digest);
    writer.boolean(value.present);
    writer.boolean(value.canonical);
    writer.boolean(value.all_behavior_inputs_bound);
    writer.boolean(value.network_inputs_forbidden);
    return writer.seal();
}

Digest build_plan_identity(const BuildPlan& value) noexcept {
    EncodedBuildPlan bytes{};
    if (!encode_build_plan(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_provenance_capsule(const ProvenanceCapsule& value, EncodedProvenanceCapsule& output) noexcept {
    Writer writer(output);
    writer.fixed(capsule_domain);
    writer.fixed(value.parent_challenge_receipt_digest);
    writer.fixed(value.logical_root_digest);
    writer.fixed(value.source_closure_digest);
    writer.fixed(value.build_plan_digest);
    writer.fixed(value.expected_output_digest);
    writer.fixed(value.claim_policy_digest);
    writer.boolean(value.present);
    writer.boolean(value.canonical);
    writer.boolean(value.physical_locator_excluded_from_subject);
    writer.boolean(value.raw_logs_noncanonical);
    writer.boolean(value.ambient_locator_bound);
    writer.u8(0U);
    writer.u16(1U);
    return writer.seal();
}

Digest provenance_capsule_identity(const ProvenanceCapsule& value) noexcept {
    EncodedProvenanceCapsule bytes{};
    if (!encode_provenance_capsule(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_build_claim(const BuildObservation& value, EncodedBuildClaim& output) noexcept {
    Writer writer(output);
    writer.fixed(claim_domain);
    writer.fixed(value.capsule_digest);
    writer.fixed(value.source_closure_digest);
    writer.fixed(value.build_plan_digest);
    writer.fixed(value.output_digest);
    writer.boolean(value.present);
    writer.boolean(value.exact_inputs_consumed);
    writer.boolean(value.output_set_complete);
    writer.boolean(value.locator_used_as_semantic_input);
    writer.boolean(value.hidden_input_observed);
    writer.u8(0U);
    writer.u16(1U);
    return writer.seal();
}

Digest build_claim_identity(const BuildObservation& value) noexcept {
    EncodedBuildClaim bytes{};
    if (!encode_build_claim(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_reopen_receipt(const ProvenanceReopenReceipt& value, EncodedReopenReceipt& output) noexcept {
    Writer writer(output);
    writer.fixed(receipt_domain);
    writer.fixed(value.claim_digest);
    writer.fixed(value.capsule_digest);
    writer.fixed(value.source_closure_digest);
    writer.fixed(value.build_plan_digest);
    writer.fixed(value.output_digest);
    writer.fixed(value.reopener_digest);
    writer.boolean(value.present);
    writer.boolean(value.durable);
    writer.boolean(value.independently_administered);
    writer.boolean(value.exact_subject_reopened);
    return writer.seal();
}

Digest reopen_receipt_identity(const ProvenanceReopenReceipt& value) noexcept {
    EncodedReopenReceipt bytes{};
    if (!encode_reopen_receipt(value, bytes)) return {};
    return encoded_identity(bytes);
}

ProvenanceReport evaluate_candidate(const RelocationTrace& trace) noexcept {
    const auto parent = control_fate_falsification::evaluate_candidate(trace.parent);
    if (!parent.accepted) return stop(ProvenanceCode::parent_rejected);
    const bool parent_clean = parent.code == FateCode::accepted_no_common_fate_found_in_supplied_closure
        && parent.no_common_fate_found_in_supplied_closure;
    if (!parent_clean) return stop(ProvenanceCode::parent_not_clean_supplied_closure, true, false, parent.live_record_must_be_retained);
    if (!parent.live_record_must_be_retained) return stop(ProvenanceCode::parent_live_record_not_retained, true, true, false);

    if (!source_shape(trace.source_closure)) return stop(ProvenanceCode::source_closure_shape_invalid, true, true, true);
    if (trace.source_closure.parent_challenge_receipt_digest != trace.parent.graph.challenge_receipt_digest) {
        return stop(ProvenanceCode::source_closure_shape_invalid, true, true, true);
    }
    for (std::size_t index = 0U; index < trace.source_closure.entry_count; ++index) {
        if (!portable_path_valid(trace.source_closure.entries[index])) {
            return stop(ProvenanceCode::source_path_invalid, true, true, true);
        }
        if (index > 0U) {
            const int comparison = path_compare(trace.source_closure.entries[index - 1U], trace.source_closure.entries[index]);
            if (comparison == 0) return stop(ProvenanceCode::source_path_duplicate, true, true, true);
            if (comparison > 0) return stop(ProvenanceCode::source_path_order_invalid, true, true, true);
        }
    }
    if (!source_entries(trace.source_closure)) return stop(ProvenanceCode::source_entry_invalid, true, true, true);
    if (trace.source_closure.closure_digest != source_closure_identity(trace.source_closure)) {
        return stop(ProvenanceCode::source_closure_digest_mismatch, true, true, true);
    }
    if (!build_shape(trace.build_plan)) return stop(ProvenanceCode::build_plan_shape_invalid, true, true, true);
    if (trace.build_plan.plan_digest != build_plan_identity(trace.build_plan)) {
        return stop(ProvenanceCode::build_plan_digest_mismatch, true, true, true);
    }
    if (!capsule_shape(trace.capsule)) return stop(ProvenanceCode::provenance_capsule_shape_invalid, true, true, true);
    if (trace.capsule.parent_challenge_receipt_digest != trace.parent.graph.challenge_receipt_digest
        || trace.capsule.logical_root_digest != trace.source_closure.logical_root_digest
        || trace.capsule.source_closure_digest != trace.source_closure.closure_digest
        || trace.capsule.build_plan_digest != trace.build_plan.plan_digest) {
        return stop(ProvenanceCode::provenance_capsule_binding_mismatch, true, true, true);
    }
    if (trace.capsule.ambient_locator_bound || nonzero(trace.capsule.ambient_locator_digest)
        || !trace.capsule.physical_locator_excluded_from_subject || !trace.capsule.raw_logs_noncanonical) {
        return stop(ProvenanceCode::ambient_locator_poisoned_capsule, true, true, true);
    }
    if (trace.capsule.capsule_digest != provenance_capsule_identity(trace.capsule)) {
        return stop(ProvenanceCode::provenance_capsule_digest_mismatch, true, true, true);
    }
    if (!observation_shape(trace.first_observation)) return stop(ProvenanceCode::first_observation_shape_invalid, true, true, true);
    if (!observation_binding(trace.first_observation, trace)) return stop(ProvenanceCode::first_claim_binding_mismatch, true, true, true);
    if (trace.first_observation.claim_digest != build_claim_identity(trace.first_observation)) {
        return stop(ProvenanceCode::first_claim_digest_mismatch, true, true, true);
    }
    if (!observation_shape(trace.relocated_observation)) return stop(ProvenanceCode::relocated_observation_shape_invalid, true, true, true);
    if (!observation_binding(trace.relocated_observation, trace)) return stop(ProvenanceCode::relocated_claim_binding_mismatch, true, true, true);
    if (trace.relocated_observation.claim_digest != build_claim_identity(trace.relocated_observation)) {
        return stop(ProvenanceCode::relocated_claim_digest_mismatch, true, true, true);
    }
    if (!receipt_shape(trace.first_receipt)) return stop(ProvenanceCode::first_receipt_shape_invalid, true, true, true);
    if (!receipt_binding(trace.first_receipt, trace.first_observation, trace)) {
        return stop(ProvenanceCode::first_receipt_binding_mismatch, true, true, true);
    }
    if (trace.first_receipt.receipt_digest != reopen_receipt_identity(trace.first_receipt)) {
        return stop(ProvenanceCode::first_receipt_digest_mismatch, true, true, true);
    }
    if (!receipt_shape(trace.relocated_receipt)) return stop(ProvenanceCode::relocated_receipt_shape_invalid, true, true, true);
    if (!receipt_binding(trace.relocated_receipt, trace.relocated_observation, trace)) {
        return stop(ProvenanceCode::relocated_receipt_binding_mismatch, true, true, true);
    }
    if (trace.relocated_receipt.receipt_digest != reopen_receipt_identity(trace.relocated_receipt)) {
        return stop(ProvenanceCode::relocated_receipt_digest_mismatch, true, true, true);
    }
    if (!cuts_exact(trace)) return stop(ProvenanceCode::provenance_cut_order_invalid, true, true, true);

    ProvenanceReport report{};
    report.accepted = true;
    report.parent_accepted = true;
    report.parent_clean_supplied_closure = true;
    report.parent_live_record_retained = true;
    report.source_closure_shape_valid = true;
    report.source_paths_valid = source_paths(trace.source_closure);
    report.source_entries_valid = true;
    report.source_closure_identity_valid = true;
    report.build_plan_shape_valid = true;
    report.build_plan_identity_valid = true;
    report.capsule_shape_valid = true;
    report.capsule_binding_valid = true;
    report.capsule_identity_valid = true;
    report.first_observation_valid = true;
    report.first_claim_identity_valid = true;
    report.relocated_observation_valid = true;
    report.relocated_claim_identity_valid = true;
    report.first_receipt_valid = true;
    report.relocated_receipt_valid = true;
    report.cuts_ordered = true;
    report.source_closure_complete = trace.source_closure.complete && trace.source_closure.hidden_inputs_absent;
    report.build_plan_complete = trace.build_plan.all_behavior_inputs_bound && trace.build_plan.network_inputs_forbidden;
    report.physical_locator_excluded_from_subject = true;
    report.locators_distinct = trace.first_observation.physical_locator_digest
        != trace.relocated_observation.physical_locator_digest;
    report.canonical_claims_equal = trace.first_observation.claim_digest
        == trace.relocated_observation.claim_digest;
    report.outputs_equal = trace.first_observation.output_digest
        == trace.relocated_observation.output_digest;

    if (!report.source_closure_complete) {
        report.code = ProvenanceCode::accepted_refused_source_closure_open;
        return report;
    }
    if (!report.build_plan_complete) {
        report.code = ProvenanceCode::accepted_refused_build_plan_open;
        return report;
    }
    if (trace.first_observation.locator_used_as_semantic_input
        || trace.relocated_observation.locator_used_as_semantic_input) {
        report.code = ProvenanceCode::accepted_refused_locator_influenced_output;
        return report;
    }
    if (!report.canonical_claims_equal || !report.outputs_equal
        || trace.capsule.expected_output_digest != trace.first_observation.output_digest) {
        report.code = ProvenanceCode::accepted_refused_output_not_reproducible;
        return report;
    }
    if (!report.locators_distinct) {
        report.code = ProvenanceCode::accepted_same_locator_no_relocation_witness;
        return report;
    }
    report.code = ProvenanceCode::accepted_relocated_exact_subject;
    report.relocation_witness = true;
    return report;
}

std::string_view provenance_code_name(const ProvenanceCode value) noexcept {
    switch (value) {
        case ProvenanceCode::accepted_relocated_exact_subject: return "accepted_relocated_exact_subject";
        case ProvenanceCode::accepted_same_locator_no_relocation_witness: return "accepted_same_locator_no_relocation_witness";
        case ProvenanceCode::accepted_refused_source_closure_open: return "accepted_refused_source_closure_open";
        case ProvenanceCode::accepted_refused_build_plan_open: return "accepted_refused_build_plan_open";
        case ProvenanceCode::accepted_refused_locator_influenced_output: return "accepted_refused_locator_influenced_output";
        case ProvenanceCode::accepted_refused_output_not_reproducible: return "accepted_refused_output_not_reproducible";
        case ProvenanceCode::parent_rejected: return "parent_rejected";
        case ProvenanceCode::parent_not_clean_supplied_closure: return "parent_not_clean_supplied_closure";
        case ProvenanceCode::parent_live_record_not_retained: return "parent_live_record_not_retained";
        case ProvenanceCode::source_closure_shape_invalid: return "source_closure_shape_invalid";
        case ProvenanceCode::source_path_invalid: return "source_path_invalid";
        case ProvenanceCode::source_path_duplicate: return "source_path_duplicate";
        case ProvenanceCode::source_path_order_invalid: return "source_path_order_invalid";
        case ProvenanceCode::source_entry_invalid: return "source_entry_invalid";
        case ProvenanceCode::source_closure_digest_mismatch: return "source_closure_digest_mismatch";
        case ProvenanceCode::build_plan_shape_invalid: return "build_plan_shape_invalid";
        case ProvenanceCode::build_plan_digest_mismatch: return "build_plan_digest_mismatch";
        case ProvenanceCode::provenance_capsule_shape_invalid: return "provenance_capsule_shape_invalid";
        case ProvenanceCode::provenance_capsule_binding_mismatch: return "provenance_capsule_binding_mismatch";
        case ProvenanceCode::ambient_locator_poisoned_capsule: return "ambient_locator_poisoned_capsule";
        case ProvenanceCode::provenance_capsule_digest_mismatch: return "provenance_capsule_digest_mismatch";
        case ProvenanceCode::first_observation_shape_invalid: return "first_observation_shape_invalid";
        case ProvenanceCode::first_claim_binding_mismatch: return "first_claim_binding_mismatch";
        case ProvenanceCode::first_claim_digest_mismatch: return "first_claim_digest_mismatch";
        case ProvenanceCode::relocated_observation_shape_invalid: return "relocated_observation_shape_invalid";
        case ProvenanceCode::relocated_claim_binding_mismatch: return "relocated_claim_binding_mismatch";
        case ProvenanceCode::relocated_claim_digest_mismatch: return "relocated_claim_digest_mismatch";
        case ProvenanceCode::first_receipt_shape_invalid: return "first_receipt_shape_invalid";
        case ProvenanceCode::first_receipt_binding_mismatch: return "first_receipt_binding_mismatch";
        case ProvenanceCode::first_receipt_digest_mismatch: return "first_receipt_digest_mismatch";
        case ProvenanceCode::relocated_receipt_shape_invalid: return "relocated_receipt_shape_invalid";
        case ProvenanceCode::relocated_receipt_binding_mismatch: return "relocated_receipt_binding_mismatch";
        case ProvenanceCode::relocated_receipt_digest_mismatch: return "relocated_receipt_digest_mismatch";
        case ProvenanceCode::provenance_cut_order_invalid: return "provenance_cut_order_invalid";
    }
    return "unknown";
}

std::string_view provenance_cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, provenance_cut_count> names{{
        "source_closure_durable", "build_plan_durable", "capsule_durable",
        "first_claim_durable", "first_receipt_durable", "relocated_claim_durable",
        "relocated_receipt_durable",
    }};
    return index < names.size() ? names[index] : std::string_view{"unknown"};
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance
