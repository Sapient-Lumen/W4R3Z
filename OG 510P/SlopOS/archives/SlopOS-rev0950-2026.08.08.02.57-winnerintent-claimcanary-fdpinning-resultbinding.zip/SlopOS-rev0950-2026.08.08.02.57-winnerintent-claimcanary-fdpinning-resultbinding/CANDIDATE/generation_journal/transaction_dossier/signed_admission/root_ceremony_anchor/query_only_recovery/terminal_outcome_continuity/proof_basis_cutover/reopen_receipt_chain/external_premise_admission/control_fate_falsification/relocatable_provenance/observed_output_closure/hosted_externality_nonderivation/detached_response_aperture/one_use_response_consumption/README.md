# One-Use Response Consumption Interface V1

A nested C++20 Epoch-Zero relation binding the exact rev0925 detached-response
aperture packet to one coherent compare-and-append consumption history. It proves
local first-use exclusion, exact terminal replay, and query-only recovery while
retaining clone-before-use as an executable countermodel to global one-use.

The exact retry path revalidates the complete plan and one coherent spent-state
witness: response, request, commit, successor head, successor generation, commit
revision, and terminal receipt. Terminal classification precedes appraisal
currentness, so expiry cannot erase a prior outcome while still blocking a new
effect. The query stage is an exact canonical object with a fixed observer-role
binding; it remains model-only and proves no external linearizable read.

Build through the retained evidence tool. This package opens no network, provider,
database, signer, or authority route.
