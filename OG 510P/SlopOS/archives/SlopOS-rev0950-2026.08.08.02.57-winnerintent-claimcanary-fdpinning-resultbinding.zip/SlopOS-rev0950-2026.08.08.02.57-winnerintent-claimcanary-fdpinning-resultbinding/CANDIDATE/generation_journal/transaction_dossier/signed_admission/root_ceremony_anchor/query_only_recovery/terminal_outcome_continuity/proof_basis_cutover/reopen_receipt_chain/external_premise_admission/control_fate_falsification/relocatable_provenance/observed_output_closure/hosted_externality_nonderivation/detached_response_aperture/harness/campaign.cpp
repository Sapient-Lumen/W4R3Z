#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation/detached_response_aperture.hpp"

#include "parent_output_set.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <openssl/evp.h>

#include <cerrno>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation::detached_response_aperture {
namespace {

#ifndef SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX
#error "fixture requires parent claim catalogue"
#endif
#ifndef SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX
#error "fixture requires parent handoff policy"
#endif
#ifndef SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX
#error "fixture requires parent response profile"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX
#error "fixture requires parent linked archive"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
#error "fixture requires parent linked archive bytes"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS
#error "fixture requires parent manifest rows"
#endif
#ifndef SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX
#error "fixture requires RPC source manifest"
#endif
#ifndef SLOPOS_RPC_BUILD_PLAN_SHA256_HEX
#error "fixture requires RPC build plan"
#endif
#ifndef SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX
#error "fixture requires RPC output contract"
#endif
#ifndef SLOPOS_RPC_PARENT_BINDING_SHA256_HEX
#error "fixture requires RPC parent binding"
#endif
#ifndef SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX
#error "fixture requires RPC logical root"
#endif
#ifndef SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX
#error "fixture requires RPC claim policy"
#endif
#ifndef SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX
#error "fixture requires first locator"
#endif
#ifndef SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX
#error "fixture requires relocated locator"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX
#error "fixture requires parent output carrier"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
#error "fixture requires parent output carrier bytes"
#endif
#ifndef SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX
#error "fixture requires reserved namespace policy"
#endif
#ifndef SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "fixture requires parent reopener implementation"
#endif
#ifndef SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX
#error "fixture requires response-shape policy"
#endif
#ifndef SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX
#error "fixture requires trust-configuration policy"
#endif
#ifndef SLOPOS_DRA_CONSUMPTION_FENCE_POLICY_SHA256_HEX
#error "fixture requires consumption-fence policy"
#endif
#ifndef SLOPOS_DRA_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "fixture requires aperture reopener implementation"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX
#error "fixture requires exact rev0924 archive"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_ARCHIVE_BYTES
#error "fixture requires exact rev0924 archive bytes"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_MANIFEST_ROWS
#error "fixture requires exact rev0924 manifest rows"
#endif

struct Case final {
    std::string name;
    ApertureTrace trace;
    ApertureCode expected;
};

[[nodiscard]] Digest digest(const std::string_view label) {
    return generation_journal::sha256(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(label.data()), label.size()));
}

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const std::uint8_t high = hex_nibble(value[index * 2U]);
        const std::uint8_t low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}

[[nodiscard]] std::string hex(const Digest& value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const auto byte : value) out << std::setw(2) << static_cast<unsigned>(byte);
    return out.str();
}

[[nodiscard]] SourceEntry source_entry_exact(
    const std::string_view path,
    const Digest& content_digest,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    SourceEntry output{};
    if (path.size() > output.path.size()) return output;
    for (std::size_t index = 0U; index < path.size(); ++index) output.path[index] = static_cast<std::uint8_t>(path[index]);
    output.path_length = static_cast<std::uint8_t>(path.size());
    output.content_digest = content_digest;
    output.bytes = bytes;
    output.mode = mode;
    output.present = true;
    output.regular_file = true;
    return output;
}

void refresh_parent_source(RelocationTrace& trace) { trace.source_closure.closure_digest = source_closure_identity(trace.source_closure); }
void refresh_parent_plan(RelocationTrace& trace) { trace.build_plan.plan_digest = build_plan_identity(trace.build_plan); }
void refresh_parent_capsule(RelocationTrace& trace) {
    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.capsule_digest = provenance_capsule_identity(trace.capsule);
}
void refresh_parent_observation(BuildObservation& observation, const RelocationTrace& trace) {
    observation.capsule_digest = trace.capsule.capsule_digest;
    observation.source_closure_digest = trace.source_closure.closure_digest;
    observation.build_plan_digest = trace.build_plan.plan_digest;
    observation.claim_digest = build_claim_identity(observation);
}
void refresh_parent_receipt(ProvenanceReopenReceipt& receipt, const BuildObservation& observation, const RelocationTrace& trace) {
    receipt.claim_digest = observation.claim_digest;
    receipt.capsule_digest = trace.capsule.capsule_digest;
    receipt.source_closure_digest = trace.source_closure.closure_digest;
    receipt.build_plan_digest = trace.build_plan.plan_digest;
    receipt.output_digest = observation.output_digest;
    receipt.receipt_digest = reopen_receipt_identity(receipt);
}
void refresh_parent_cuts(RelocationTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].source_closure_digest = trace.source_closure.closure_digest;
        if (index >= 1U) trace.cuts[index].build_plan_digest = trace.build_plan.plan_digest;
        if (index >= 2U) trace.cuts[index].capsule_digest = trace.capsule.capsule_digest;
        if (index >= 3U) trace.cuts[index].first_claim_digest = trace.first_observation.claim_digest;
        if (index >= 4U) trace.cuts[index].first_receipt_digest = trace.first_receipt.receipt_digest;
        if (index >= 5U) trace.cuts[index].relocated_claim_digest = trace.relocated_observation.claim_digest;
        if (index >= 6U) trace.cuts[index].relocated_receipt_digest = trace.relocated_receipt.receipt_digest;
    }
}

[[nodiscard]] RelocationTrace parent_baseline() {
    RelocationTrace trace{};
    trace.parent = control_fate_falsification::make_hosted_clean_fixture();
    const Digest source_manifest = exact_digest(SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX);
    const Digest build_plan_binding = exact_digest(SLOPOS_RPC_BUILD_PLAN_SHA256_HEX);
    const Digest output_contract = exact_digest(SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX);
    const Digest parent_binding = exact_digest(SLOPOS_RPC_PARENT_BINDING_SHA256_HEX);
    const Digest logical_root = exact_digest(SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX);
    const Digest claim_policy = exact_digest(SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX);

    trace.source_closure.logical_root_digest = logical_root;
    trace.source_closure.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.source_closure.entries[0] = source_entry_exact("bindings/build-plan.json", build_plan_binding, SLOPOS_RPC_BUILD_PLAN_BYTES, mode_read_only);
    trace.source_closure.entries[1] = source_entry_exact("bindings/claim-policy.txt", claim_policy, SLOPOS_RPC_CLAIM_POLICY_BYTES, mode_read_only);
    trace.source_closure.entries[2] = source_entry_exact("bindings/logical-root.txt", logical_root, SLOPOS_RPC_LOGICAL_ROOT_BYTES, mode_read_only);
    trace.source_closure.entries[3] = source_entry_exact("bindings/output-contract.json", output_contract, SLOPOS_RPC_OUTPUT_CONTRACT_BYTES, mode_read_only);
    trace.source_closure.entries[4] = source_entry_exact("bindings/parent-binding.json", parent_binding, SLOPOS_RPC_PARENT_BINDING_BYTES, mode_read_only);
    trace.source_closure.entries[5] = source_entry_exact("bindings/source-manifest.tsv", source_manifest, SLOPOS_RPC_SOURCE_MANIFEST_BYTES, mode_read_only);
    trace.source_closure.entry_count = 6U;
    trace.source_closure.present = true;
    trace.source_closure.canonical = true;
    trace.source_closure.complete = true;
    trace.source_closure.hidden_inputs_absent = true;
    refresh_parent_source(trace);

    trace.build_plan.build_type_digest = digest("build-type:release-O0-g0-DNDEBUG");
    trace.build_plan.toolchain_digest = digest("toolchain-policy:cxx20-gcc-clang-hosted-lanes");
    trace.build_plan.flags_digest = digest("flags-policy:prefix-map-source-root-to-logical-root");
    trace.build_plan.environment_policy_digest = claim_policy;
    trace.build_plan.dependency_closure_digest = source_manifest;
    trace.build_plan.output_spec_digest = output_contract;
    trace.build_plan.deterministic_input_digest = build_plan_binding;
    trace.build_plan.present = true;
    trace.build_plan.canonical = true;
    trace.build_plan.all_behavior_inputs_bound = true;
    trace.build_plan.network_inputs_forbidden = true;
    refresh_parent_plan(trace);

    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.expected_output_digest = output_contract;
    trace.capsule.claim_policy_digest = claim_policy;
    trace.capsule.present = true;
    trace.capsule.canonical = true;
    trace.capsule.physical_locator_excluded_from_subject = true;
    trace.capsule.raw_logs_noncanonical = true;
    refresh_parent_capsule(trace);

    trace.first_observation.output_digest = output_contract;
    trace.first_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX);
    trace.first_observation.raw_log_digest = digest("raw-log:first-host-path-bearing-log");
    trace.first_observation.present = true;
    trace.first_observation.exact_inputs_consumed = true;
    trace.first_observation.output_set_complete = true;
    refresh_parent_observation(trace.first_observation, trace);

    trace.relocated_observation = trace.first_observation;
    trace.relocated_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX);
    trace.relocated_observation.raw_log_digest = digest("raw-log:relocated-host-path-bearing-log");
    refresh_parent_observation(trace.relocated_observation, trace);

    trace.first_receipt.reopener_digest = digest("reopener:first-independent-reader");
    trace.first_receipt.present = true;
    trace.first_receipt.durable = true;
    trace.first_receipt.independently_administered = true;
    trace.first_receipt.exact_subject_reopened = true;
    refresh_parent_receipt(trace.first_receipt, trace.first_observation, trace);

    trace.relocated_receipt.reopener_digest = digest("reopener:second-independent-reader");
    trace.relocated_receipt.present = true;
    trace.relocated_receipt.durable = true;
    trace.relocated_receipt.independently_administered = true;
    trace.relocated_receipt.exact_subject_reopened = true;
    refresh_parent_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_parent_cuts(trace);
    return trace;
}

[[nodiscard]] OutputEntry output_entry(
    const std::string_view path,
    const Digest& content,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    OutputEntry entry{};
    if (path.size() > entry.path.size()) return entry;
    for (std::size_t index = 0U; index < path.size(); ++index) entry.path[index] = static_cast<std::uint8_t>(path[index]);
    entry.path_length = static_cast<std::uint8_t>(path.size());
    entry.content_digest = content;
    entry.bytes = bytes;
    entry.mode = mode;
    entry.present = true;
    entry.regular_file = true;
    return entry;
}

[[maybe_unused]] void set_output_path(OutputEntry& entry, const std::string_view path) {
    entry.path.fill(0U);
    if (path.size() > entry.path.size()) { entry.path_length = 0U; return; }
    for (std::size_t index = 0U; index < path.size(); ++index) entry.path[index] = static_cast<std::uint8_t>(path[index]);
    entry.path_length = static_cast<std::uint8_t>(path.size());
}

void refresh_manifest(OutputClosureTrace& trace) { trace.manifest.manifest_digest = output_manifest_identity(trace.manifest); }
void refresh_publication(OutputClosureTrace& trace) {
    trace.publication.manifest_digest = trace.manifest.manifest_digest;
    trace.publication.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.publication.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.publication.receipt_digest = publication_receipt_identity(trace.publication);
}
void refresh_reopen(OutputClosureTrace& trace) {
    trace.reopen.publication_receipt_digest = trace.publication.receipt_digest;
    trace.reopen.manifest_digest = trace.manifest.manifest_digest;
    trace.reopen.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.reopen.receipt_digest = output_reopen_receipt_identity(trace.reopen);
}
void refresh_claim(OutputClosureTrace& trace) {
    trace.claim.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.claim.parent_build_claim_digest = trace.parent.relocated_observation.claim_digest;
    trace.claim.manifest_digest = trace.manifest.manifest_digest;
    trace.claim.publication_receipt_digest = trace.publication.receipt_digest;
    trace.claim.reopen_receipt_digest = trace.reopen.receipt_digest;
    trace.claim.reserved_namespace_policy_digest = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    trace.claim.claim_digest = output_closure_claim_identity(trace.claim);
}
void refresh_cuts(OutputClosureTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
        if (trace.manifest.present && index >= 1U) trace.cuts[index].manifest_digest = trace.manifest.manifest_digest;
        if (trace.publication.present && index >= 2U) trace.cuts[index].publication_receipt_digest = trace.publication.receipt_digest;
        if (trace.reopen.present && index >= 3U) trace.cuts[index].reopen_receipt_digest = trace.reopen.receipt_digest;
        if (trace.claim.present && index >= 4U) trace.cuts[index].closure_claim_digest = trace.claim.claim_digest;
    }
}
[[maybe_unused]] void refresh_from_manifest(OutputClosureTrace& trace) { refresh_manifest(trace); refresh_publication(trace); refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
[[maybe_unused]] void refresh_from_publication(OutputClosureTrace& trace) { refresh_publication(trace); refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
[[maybe_unused]] void refresh_from_reopen(OutputClosureTrace& trace) { refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
[[maybe_unused]] void refresh_from_claim(OutputClosureTrace& trace) { refresh_claim(trace); refresh_cuts(trace); }

[[nodiscard]] OutputClosureTrace parent_output_baseline() {
    OutputClosureTrace trace{};
    trace.parent = parent_baseline();
    trace.manifest.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.manifest.parent_build_claim_digest = trace.parent.relocated_observation.claim_digest;
    trace.manifest.parent_provenance_output_digest = trace.parent.relocated_observation.output_digest;
    trace.manifest.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.manifest.reserved_namespace_policy_digest = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    using slopos::e0::observed_output_closure_generated::parent_output_entries;
    for (std::size_t index = 0U; index < parent_output_entries.size(); ++index) {
        const auto& expected = parent_output_entries[index];
        trace.manifest.entries[index] = output_entry(expected.path, exact_digest(expected.sha256), expected.bytes, expected.mode);
    }
    trace.manifest.entry_count = static_cast<std::uint8_t>(parent_output_entries.size());
    trace.manifest.present = true;
    trace.manifest.canonical = true;
    trace.manifest.exact_prior_set = true;
    trace.manifest.complete = true;
    trace.manifest.reserved_namespace_excluded = true;
    refresh_manifest(trace);

    trace.publication.publisher_digest = digest("publisher:hosted-no-replace-output-manifest-writer");
    trace.publication.carrier_bytes = SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES;
    trace.publication.present = true;
    trace.publication.durable = true;
    trace.publication.no_replace_publication = true;
    trace.publication.single_view_reopened = true;
    trace.publication.exact_carrier_published = true;
    refresh_publication(trace);

    trace.reopen.reopener_digest = digest("reopener:separate-hosted-parent-output-set-rehasher");
    trace.reopen.reopener_implementation_digest = exact_digest(SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX);
    trace.reopen.carrier_bytes = SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES;
    trace.reopen.present = true;
    trace.reopen.durable = true;
    trace.reopen.separate_reopener_role = true;
    trace.reopen.exact_manifest_reopened = true;
    trace.reopen.all_entries_rehashed = true;
    refresh_reopen(trace);

    trace.claim.present = true;
    trace.claim.durable = true;
    trace.claim.exact_prior_output_set_claimed = true;
    trace.claim.child_products_outside_subject = true;
    trace.claim.no_self_digest_transform_claimed = true;
    refresh_claim(trace);
    refresh_cuts(trace);
    return trace;
}


void refresh_observations(ExternalityTrace& trace) {
    trace.left_observation.observation_digest = hosted_observation_identity(trace.left_observation);
    trace.right_observation.observation_digest = hosted_observation_identity(trace.right_observation);
}
void refresh_witness(ExternalityTrace& trace) { trace.witness.witness_digest = twin_world_witness_identity(trace.witness); }
void refresh_request(ExternalityTrace& trace) { trace.request.request_digest = owner_handoff_request_identity(trace.request); }
void refresh_deficit(ExternalityTrace& trace) { trace.deficit.certificate_digest = premise_deficit_certificate_identity(trace.deficit); }
void refresh_externality_cuts(ExternalityTrace& trace) {
    for (std::size_t i = 0U; i < trace.cuts.size(); ++i) {
        trace.cuts[i] = {};
        trace.cuts[i].parent_closure_claim_digest = trace.parent.claim.claim_digest;
        if (i >= 1U && trace.left_observation.present && trace.right_observation.present) {
            trace.cuts[i].observation_digest = trace.left_observation.observation_digest;
        }
        if (i >= 2U && trace.witness.present) trace.cuts[i].witness_digest = trace.witness.witness_digest;
        if (i >= 3U && trace.request.present) trace.cuts[i].request_digest = trace.request.request_digest;
        if (i >= 4U && trace.deficit.present) trace.cuts[i].deficit_certificate_digest = trace.deficit.certificate_digest;
    }
}
[[maybe_unused]] void refresh_child_from_observation(ExternalityTrace& trace) {
    refresh_observations(trace);
    refresh_witness(trace);
    refresh_request(trace);
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}
[[maybe_unused]] void refresh_child_from_witness(ExternalityTrace& trace) {
    refresh_witness(trace);
    refresh_request(trace);
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}
[[maybe_unused]] void refresh_child_from_request(ExternalityTrace& trace) {
    refresh_request(trace);
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}
[[maybe_unused]] void refresh_child_from_deficit(ExternalityTrace& trace) {
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}

[[nodiscard]] ExternalityTrace parent_externality_baseline(const std::uint16_t mask = all_external_claims_mask) {
    ExternalityTrace trace{};
    trace.parent = parent_output_baseline();
    HostedObservation observation{};
    observation.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    observation.parent_manifest_digest = trace.parent.manifest.manifest_digest;
    observation.parent_publication_receipt_digest = trace.parent.publication.receipt_digest;
    observation.parent_reopen_receipt_digest = trace.parent.reopen.receipt_digest;
    observation.linked_parent_archive_digest = exact_digest(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    observation.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    observation.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    observation.linked_parent_archive_bytes = SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES;
    observation.linked_parent_manifest_rows = SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS;
    observation.requested_claim_mask = mask;
    observation.schema_version = externality_schema_version;
    observation.present = true;
    observation.canonical = true;
    observation.hosted_bytes_only = true;
    observation.external_receipt_absent = true;
    trace.left_observation = observation;
    trace.right_observation = observation;
    refresh_observations(trace);

    trace.left_external_facts.true_mask = 0U;
    trace.left_external_facts.canonical = true;
    trace.right_external_facts.true_mask = mask;
    trace.right_external_facts.canonical = true;

    trace.witness.observation_digest = trace.left_observation.observation_digest;
    trace.witness.left_world_label_digest = digest("world:left:external-predicates-false");
    trace.witness.right_world_label_digest = digest("world:right:requested-external-predicates-true");
    trace.witness.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    trace.witness.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    trace.witness.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    trace.witness.requested_claim_mask = mask;
    trace.witness.left_true_mask = 0U;
    trace.witness.right_true_mask = mask;
    trace.witness.schema_version = externality_schema_version;
    trace.witness.present = true;
    trace.witness.canonical = true;
    trace.witness.countermodel_only = true;
    trace.witness.no_external_occurrence_claimed = true;
    refresh_witness(trace);

    trace.request.linked_parent_archive_digest = exact_digest(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    trace.request.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    trace.request.observation_digest = trace.left_observation.observation_digest;
    trace.request.witness_digest = trace.witness.witness_digest;
    trace.request.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    trace.request.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    trace.request.requested_response_profile_digest = exact_digest(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX);
    trace.request.response_namespace_digest = digest("external-response-namespace:owner-handoff-v1");
    trace.request.linked_parent_archive_bytes = SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES;
    trace.request.linked_parent_manifest_rows = SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS;
    trace.request.requested_claim_mask = mask;
    trace.request.schema_version = externality_schema_version;
    trace.request.present = true;
    trace.request.canonical = true;
    trace.request.request_only = true;
    trace.request.no_authority_claim = true;
    refresh_request(trace);

    trace.deficit.observation_digest = trace.left_observation.observation_digest;
    trace.deficit.witness_digest = trace.witness.witness_digest;
    trace.deficit.request_digest = trace.request.request_digest;
    trace.deficit.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    trace.deficit.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    trace.deficit.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    trace.deficit.requested_response_profile_digest = exact_digest(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX);
    trace.deficit.unresolved_claim_mask = mask;
    trace.deficit.schema_version = externality_schema_version;
    trace.deficit.present = true;
    trace.deficit.canonical = true;
    trace.deficit.all_requested_claims_unresolved = true;
    trace.deficit.external_response_absent = true;
    trace.deficit.no_acceptance_or_authority = true;
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
    return trace;
}

[[nodiscard]] PublicKey lab_public_key() {
    constexpr std::array<std::uint8_t, 32U> seed{{
        0x91U,0x25U,0x44U,0x52U,0x41U,0x2dU,0x6cU,0x61U,
        0x62U,0x2dU,0x73U,0x69U,0x67U,0x6eU,0x65U,0x72U,
        0x2dU,0x6eU,0x6fU,0x74U,0x2dU,0x61U,0x2dU,0x72U,
        0x6fU,0x6fU,0x74U,0x2dU,0x76U,0x30U,0x30U,0x31U,
    }};
    using KeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
    KeyPtr key(EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, nullptr, seed.data(), seed.size()), &EVP_PKEY_free);
    PublicKey output{};
    std::size_t output_bytes = output.size();
    if (!key || EVP_PKEY_get_raw_public_key(key.get(), output.data(), &output_bytes) != 1
        || output_bytes != output.size()) return {};
    return output;
}

[[nodiscard]] Signature sign_response(const LabResponseFixture& value) {
    constexpr std::array<std::uint8_t, 32U> seed{{
        0x91U,0x25U,0x44U,0x52U,0x41U,0x2dU,0x6cU,0x61U,
        0x62U,0x2dU,0x73U,0x69U,0x67U,0x6eU,0x65U,0x72U,
        0x2dU,0x6eU,0x6fU,0x74U,0x2dU,0x61U,0x2dU,0x72U,
        0x6fU,0x6fU,0x74U,0x2dU,0x76U,0x30U,0x30U,0x31U,
    }};
    EncodedResponseSigning message{};
    Signature signature{};
    if (!encode_response_signing_message(value, message)) return signature;
    using KeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
    using ContextPtr = std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)>;
    KeyPtr key(EVP_PKEY_new_raw_private_key(EVP_PKEY_ED25519, nullptr, seed.data(), seed.size()), &EVP_PKEY_free);
    ContextPtr context(EVP_MD_CTX_new(), &EVP_MD_CTX_free);
    std::size_t signature_bytes = signature.size();
    if (!key || !context
        || EVP_DigestSignInit(context.get(), nullptr, nullptr, nullptr, key.get()) != 1
        || EVP_DigestSign(context.get(), signature.data(), &signature_bytes, message.data(), message.size()) != 1
        || signature_bytes != signature.size()) return {};
    return signature;
}

void refresh_response(ApertureTrace& trace, const bool resign = true) {
    if (resign) trace.response.signature = sign_response(trace.response);
    trace.response.response_digest = lab_response_identity(trace.response);
}
void refresh_publication_child(ApertureTrace& trace) {
    trace.publication.response_digest = trace.response.response_digest;
    trace.publication.request_digest = trace.parent.request.request_digest;
    trace.publication.linked_parent_archive_digest = exact_digest(SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    trace.publication.carrier_digest = trace.response.response_digest;
    trace.publication.receipt_digest = modeled_publication_receipt_identity(trace.publication);
}
void refresh_reopen_child(ApertureTrace& trace) {
    trace.reopen.publication_receipt_digest = trace.publication.receipt_digest;
    trace.reopen.response_digest = trace.response.response_digest;
    trace.reopen.request_digest = trace.parent.request.request_digest;
    trace.reopen.carrier_digest = trace.response.response_digest;
    trace.reopen.receipt_digest = modeled_reopen_receipt_identity(trace.reopen);
}
void refresh_configuration(TrustConfiguration& value) {
    value.configuration_digest = trust_configuration_identity(value);
}
void refresh_appraisal_child(ApertureTrace& trace) {
    trace.appraisal.response_digest = trace.response.response_digest;
    trace.appraisal.publication_receipt_digest = trace.publication.receipt_digest;
    trace.appraisal.reopen_receipt_digest = trace.reopen.receipt_digest;
    trace.appraisal.accepting_configuration_digest = trace.accepting_configuration.configuration_digest;
    trace.appraisal.policy_reject_configuration_digest = trace.policy_reject_configuration.configuration_digest;
    trace.appraisal.successor_configuration_digest = trace.successor_configuration.configuration_digest;
    trace.appraisal.request_digest = trace.parent.request.request_digest;
    trace.appraisal.accepting_result = appraise_candidate(trace.response, trace.accepting_configuration);
    trace.appraisal.policy_reject_result = appraise_candidate(trace.response, trace.policy_reject_configuration);
    trace.appraisal.successor_result = appraise_candidate(trace.response, trace.successor_configuration);
    trace.appraisal.appraisal_root_version = trace.accepting_configuration.current_root_version;
    trace.appraisal.successor_root_version = trace.successor_configuration.current_root_version;
    trace.appraisal.witness_digest = appraisal_witness_identity(trace.appraisal);
}
void refresh_deficit_child(ApertureTrace& trace) {
    trace.deficit.response_digest = trace.response.response_digest;
    trace.deficit.appraisal_witness_digest = trace.appraisal.witness_digest;
    trace.deficit.accepting_configuration_digest = trace.accepting_configuration.configuration_digest;
    trace.deficit.successor_configuration_digest = trace.successor_configuration.configuration_digest;
    trace.deficit.request_digest = trace.parent.request.request_digest;
    trace.deficit.appraised_owner_root_digest = trace.accepting_configuration.current_owner_root_digest;
    trace.deficit.consumption_owner_root_digest = trace.successor_configuration.current_owner_root_digest;
    trace.deficit.appraisal_root_version = trace.accepting_configuration.current_root_version;
    trace.deficit.consumption_root_version = trace.successor_configuration.current_root_version;
    trace.deficit.appraisal_time = trace.accepting_configuration.evaluation_time;
    trace.deficit.consumption_time = trace.successor_configuration.evaluation_time;
    trace.deficit.deficit_digest = consumption_deficit_identity(trace.deficit);
}
void refresh_aperture_cuts(ApertureTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].parent_request_digest = trace.parent.request.request_digest;
        if (index >= 1U && trace.response.present) trace.cuts[index].response_digest = trace.response.response_digest;
        if (index >= 2U && trace.publication.present) trace.cuts[index].publication_receipt_digest = trace.publication.receipt_digest;
        if (index >= 3U && trace.reopen.present) trace.cuts[index].reopen_receipt_digest = trace.reopen.receipt_digest;
        if (index >= 4U && trace.accepting_configuration.present
            && trace.policy_reject_configuration.present && trace.successor_configuration.present) {
            trace.cuts[index].accepting_configuration_digest = trace.accepting_configuration.configuration_digest;
            trace.cuts[index].policy_reject_configuration_digest = trace.policy_reject_configuration.configuration_digest;
            trace.cuts[index].successor_configuration_digest = trace.successor_configuration.configuration_digest;
        }
        if (index >= 5U && trace.appraisal.present) trace.cuts[index].appraisal_witness_digest = trace.appraisal.witness_digest;
        if (index >= 6U && trace.deficit.present) trace.cuts[index].consumption_deficit_digest = trace.deficit.deficit_digest;
    }
}
void refresh_from_response(ApertureTrace& trace, const bool resign = true) {
    refresh_response(trace, resign); refresh_publication_child(trace); refresh_reopen_child(trace);
    refresh_appraisal_child(trace); refresh_deficit_child(trace); refresh_aperture_cuts(trace);
}
void refresh_from_publication_child(ApertureTrace& trace) {
    refresh_publication_child(trace); refresh_reopen_child(trace); refresh_appraisal_child(trace);
    refresh_deficit_child(trace); refresh_aperture_cuts(trace);
}
void refresh_from_reopen_child(ApertureTrace& trace) {
    refresh_reopen_child(trace); refresh_appraisal_child(trace); refresh_deficit_child(trace); refresh_aperture_cuts(trace);
}
void refresh_from_configurations(ApertureTrace& trace) {
    refresh_configuration(trace.accepting_configuration);
    refresh_configuration(trace.policy_reject_configuration);
    refresh_configuration(trace.successor_configuration);
    refresh_appraisal_child(trace); refresh_deficit_child(trace); refresh_aperture_cuts(trace);
}
void refresh_from_appraisal_child(ApertureTrace& trace) {
    refresh_appraisal_child(trace); refresh_deficit_child(trace); refresh_aperture_cuts(trace);
}
void refresh_from_deficit_child(ApertureTrace& trace) {
    refresh_deficit_child(trace); refresh_aperture_cuts(trace);
}

[[nodiscard]] ApertureTrace baseline() {
    ApertureTrace trace{};
    trace.parent = parent_externality_baseline();

    trace.response.request_digest = trace.parent.request.request_digest;
    trace.response.linked_parent_archive_digest = exact_digest(SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    trace.response.parent_closure_claim_digest = trace.parent.parent.claim.claim_digest;
    trace.response.claim_catalogue_digest = trace.parent.request.claim_catalogue_digest;
    trace.response.requested_response_profile_digest = trace.parent.request.requested_response_profile_digest;
    trace.response.owner_constitution_digest = digest("lab-owner-constitution:v1:not-external");
    trace.response.owner_root_digest = digest("lab-owner-root:version-41:not-external");
    trace.response.appraisal_policy_digest = exact_digest(SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX);
    trace.response.target_digest = digest("target:slopos-epoch-zero-owner-handoff");
    trace.response.response_namespace_digest = trace.parent.request.response_namespace_digest;
    trace.response.signer_public_key = lab_public_key();
    trace.response.linked_parent_archive_bytes = SLOPOS_DRA_LINKED_PARENT_ARCHIVE_BYTES;
    trace.response.linked_parent_manifest_rows = SLOPOS_DRA_LINKED_PARENT_MANIFEST_ROWS;
    trace.response.owner_root_version = 41U;
    trace.response.issued_at = 1000U;
    trace.response.not_before = 900U;
    trace.response.expires_at = 2000U;
    trace.response.accepted_claim_mask = hosted_mechanism_claim_mask;
    trace.response.rejected_claim_mask = 0U;
    trace.response.unresolved_claim_mask = governance_claim_mask;
    trace.response.schema_version = aperture_schema_version;
    trace.response.present = true;
    trace.response.canonical = true;
    trace.response.laboratory_fixture = true;
    trace.response.detached_from_request = true;
    refresh_response(trace);

    trace.publication.publication_namespace_digest = digest("publication:modeled-detached-response-aperture");
    trace.publication.publisher_role_digest = digest("role:modeled-response-publisher");
    trace.publication.publication_policy_digest = exact_digest(SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX);
    trace.publication.sequence = 1U;
    trace.publication.carrier_bytes = encoded_lab_response_bytes;
    trace.publication.schema_version = aperture_schema_version;
    trace.publication.present = true;
    trace.publication.canonical = true;
    trace.publication.durable = true;
    trace.publication.no_replace = true;
    trace.publication.model_only = true;
    refresh_publication_child(trace);

    trace.reopen.reopener_role_digest = digest("role:modeled-detached-response-reopener");
    trace.reopen.reopener_implementation_digest = exact_digest(SLOPOS_DRA_REOPENER_IMPLEMENTATION_SHA256_HEX);
    trace.reopen.reopen_policy_digest = exact_digest(SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX);
    trace.reopen.carrier_bytes = encoded_lab_response_bytes;
    trace.reopen.schema_version = aperture_schema_version;
    trace.reopen.present = true;
    trace.reopen.canonical = true;
    trace.reopen.durable = true;
    trace.reopen.exact_response_rehashed = true;
    trace.reopen.separate_role_label = true;
    trace.reopen.model_only = true;
    refresh_reopen_child(trace);

    TrustConfiguration common{};
    common.owner_constitution_digest = trace.response.owner_constitution_digest;
    common.current_owner_root_digest = trace.response.owner_root_digest;
    common.appraisal_policy_digest = trace.response.appraisal_policy_digest;
    common.target_digest = trace.response.target_digest;
    common.response_namespace_digest = trace.response.response_namespace_digest;
    common.trusted_signer_public_key = trace.response.signer_public_key;
    common.current_root_version = trace.response.owner_root_version;
    common.evaluation_time = 1200U;
    common.required_accept_mask = hosted_mechanism_claim_mask;
    common.forbidden_reject_mask = all_external_claims_mask;
    common.schema_version = aperture_schema_version;
    common.present = true;
    common.canonical = true;
    common.laboratory_configuration = true;

    trace.accepting_configuration = common;
    trace.accepting_configuration.configuration_role_digest = digest("lab-config:accepting-current-root");
    refresh_configuration(trace.accepting_configuration);

    trace.policy_reject_configuration = common;
    trace.policy_reject_configuration.configuration_role_digest = digest("lab-config:requires-governance-claims");
    trace.policy_reject_configuration.required_accept_mask = all_external_claims_mask;
    refresh_configuration(trace.policy_reject_configuration);

    trace.successor_configuration = common;
    trace.successor_configuration.configuration_role_digest = digest("lab-config:successor-root-version-42");
    trace.successor_configuration.current_owner_root_digest = digest("lab-owner-root:version-42:not-external");
    trace.successor_configuration.current_root_version = 42U;
    trace.successor_configuration.evaluation_time = 1300U;
    refresh_configuration(trace.successor_configuration);

    trace.appraisal.appraisal_policy_digest = exact_digest(SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX);
    trace.appraisal.schema_version = aperture_schema_version;
    trace.appraisal.present = true;
    trace.appraisal.canonical = true;
    trace.appraisal.same_response_bytes = true;
    trace.appraisal.opposite_policy_appraisals = true;
    trace.appraisal.successor_currentness_rejected = true;
    trace.appraisal.model_only = true;
    trace.appraisal.no_external_trust_claim = true;
    refresh_appraisal_child(trace);

    trace.deficit.consumption_policy_digest = exact_digest(SLOPOS_DRA_CONSUMPTION_FENCE_POLICY_SHA256_HEX);
    trace.deficit.missing_premise_mask = 0x003fU;
    trace.deficit.schema_version = aperture_schema_version;
    trace.deficit.present = true;
    trace.deficit.canonical = true;
    trace.deficit.prior_appraisal_not_current = true;
    trace.deficit.external_response_absent = true;
    trace.deficit.external_trust_configuration_absent = true;
    trace.deficit.owner_admission_absent = true;
    trace.deficit.no_authority_claim = true;
    refresh_deficit_child(trace);
    refresh_aperture_cuts(trace);
    return trace;
}

[[nodiscard]] ApertureTrace at_stage(const ApertureTrace& complete, const std::size_t stage) {
    ApertureTrace trace = complete;
    if (stage < 6U) trace.deficit = {};
    if (stage < 5U) trace.appraisal = {};
    if (stage < 4U) {
        trace.accepting_configuration = {};
        trace.policy_reject_configuration = {};
        trace.successor_configuration = {};
    }
    if (stage < 3U) trace.reopen = {};
    if (stage < 2U) trace.publication = {};
    if (stage < 1U) trace.response = {};
    refresh_aperture_cuts(trace);
    return trace;
}

void add_case(std::vector<Case>& cases, std::string name, ApertureTrace trace, const ApertureCode expected) {
    cases.push_back(Case{std::move(name), std::move(trace), expected});
}

[[nodiscard]] std::vector<Case> corpus() {
    const auto good = baseline();
    std::vector<Case> cases;
    const std::array<ApertureCode, aperture_cut_count> stage_codes{{
        ApertureCode::accepted_parent_handoff_ready,
        ApertureCode::accepted_lab_response_durable,
        ApertureCode::accepted_modeled_publication_durable,
        ApertureCode::accepted_modeled_reopen_durable,
        ApertureCode::accepted_trust_configurations_durable,
        ApertureCode::accepted_appraisal_witness_durable,
        ApertureCode::accepted_consumption_deficit_durable,
    }};
    for (std::size_t stage = 0U; stage < stage_codes.size(); ++stage) {
        add_case(cases, "durable_stage_" + std::to_string(stage), at_stage(good, stage), stage_codes[stage]);
    }

    { auto t=good; t.parent.parent.parent.parent.graph.graph_digest={}; refresh_aperture_cuts(t); add_case(cases,"parent_rejected",t,ApertureCode::parent_rejected); }
    { auto t=good; t.parent.request={}; t.parent.deficit={}; refresh_externality_cuts(t.parent); refresh_aperture_cuts(t); add_case(cases,"parent_not_handoff_ready",t,ApertureCode::parent_not_handoff_ready); }
    { auto t=at_stage(good,0U); t.publication=good.publication; refresh_aperture_cuts(t); add_case(cases,"response_absent_later_present",t,ApertureCode::response_without_parent); }
    { auto t=good; t.publication={}; refresh_aperture_cuts(t); add_case(cases,"publication_absent_later_present",t,ApertureCode::publication_without_response); }
    { auto t=good; t.reopen={}; refresh_aperture_cuts(t); add_case(cases,"reopen_absent_later_present",t,ApertureCode::reopen_without_publication); }
    { auto t=good; t.accepting_configuration={}; t.policy_reject_configuration={}; t.successor_configuration={}; refresh_aperture_cuts(t); add_case(cases,"configurations_absent_later_present",t,ApertureCode::configurations_without_reopen); }
    { auto t=good; t.appraisal={}; refresh_aperture_cuts(t); add_case(cases,"deficit_without_appraisal",t,ApertureCode::consumption_deficit_without_appraisal); }

    for (std::size_t i=0U;i<8U;++i) {
        auto t=good;
        if(i==0U)t.response.canonical=false;
        if(i==1U)t.response.laboratory_fixture=false;
        if(i==2U)t.response.detached_from_request=false;
        if(i==3U)t.response.external_occurrence_claimed=true;
        if(i==4U)t.response.schema_version=2U;
        if(i==5U)t.response.owner_root_version=0U;
        if(i==6U)t.response.issued_at=t.response.expires_at;
        if(i==7U)t.response.signer_public_key={};
        refresh_from_response(t,true);
        add_case(cases,"response_shape_"+std::to_string(i),t,ApertureCode::response_shape_invalid);
    }
    { auto t=good; t.response.trust_anchor_embedded=true; refresh_from_response(t,true); add_case(cases,"response_self_nominated_trust",t,ApertureCode::response_self_nominated_trust); }
    for (std::size_t i=0U;i<4U;++i) {
        auto t=good;
        if(i==0U)t.response.accepted_claim_mask=0U;
        if(i==1U)t.response.unresolved_claim_mask=0U;
        if(i==2U)t.response.rejected_claim_mask=hosted_mechanism_claim_mask;
        if(i==3U)t.response.accepted_claim_mask=all_external_claims_mask;
        refresh_from_response(t,true);
        add_case(cases,"response_partition_"+std::to_string(i),t,ApertureCode::response_claim_partition_invalid);
    }
    for (std::size_t i=0U;i<6U;++i) {
        auto t=good; const auto wrong=digest("wrong-response-binding-"+std::to_string(i));
        if(i==0U)t.response.request_digest=wrong;
        if(i==1U)t.response.linked_parent_archive_digest=wrong;
        if(i==2U)t.response.parent_closure_claim_digest=wrong;
        if(i==3U)t.response.claim_catalogue_digest=wrong;
        if(i==4U)t.response.requested_response_profile_digest=wrong;
        if(i==5U)t.response.response_namespace_digest=wrong;
        refresh_from_response(t,true);
        add_case(cases,"response_binding_"+std::to_string(i),t,ApertureCode::response_binding_mismatch);
    }
    { auto t=good; t.response.response_digest[0]^=1U; refresh_publication_child(t); refresh_reopen_child(t); refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t); add_case(cases,"response_digest_wrong",t,ApertureCode::response_digest_mismatch); }
    { auto t=good; t.response.signature[0]^=1U; refresh_from_response(t,false); add_case(cases,"response_signature_wrong",t,ApertureCode::response_signature_invalid); }

    for(std::size_t i=0U;i<6U;++i){ auto t=good;
        if(i==0U)t.publication.canonical=false;
        if(i==1U)t.publication.durable=false;
        if(i==2U)t.publication.no_replace=false;
        if(i==3U)t.publication.model_only=false;
        if(i==4U)t.publication.external_occurrence_claimed=true;
        if(i==5U)t.publication.sequence=0U;
        refresh_from_publication_child(t); add_case(cases,"publication_shape_"+std::to_string(i),t,ApertureCode::publication_shape_invalid); }
    for(std::size_t i=0U;i<5U;++i){ auto t=good; auto wrong=digest("wrong-publication-binding-"+std::to_string(i));
        if(i==0U)t.publication.response_digest=wrong;
        if(i==1U)t.publication.request_digest=wrong;
        if(i==2U)t.publication.linked_parent_archive_digest=wrong;
        if(i==3U)t.publication.carrier_digest=wrong;
        if(i==4U)t.publication.publication_policy_digest=wrong;
        t.publication.receipt_digest=modeled_publication_receipt_identity(t.publication); refresh_reopen_child(t); refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t);
        add_case(cases,"publication_binding_"+std::to_string(i),t,ApertureCode::publication_binding_mismatch); }
    { auto t=good; t.publication.receipt_digest[0]^=1U; refresh_reopen_child(t); refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t); add_case(cases,"publication_digest_wrong",t,ApertureCode::publication_digest_mismatch); }

    for(std::size_t i=0U;i<7U;++i){ auto t=good;
        if(i==0U)t.reopen.canonical=false;
        if(i==1U)t.reopen.durable=false;
        if(i==2U)t.reopen.exact_response_rehashed=false;
        if(i==3U)t.reopen.separate_role_label=false;
        if(i==4U)t.reopen.model_only=false;
        if(i==5U)t.reopen.administrative_independence_claimed=true;
        if(i==6U)t.reopen.carrier_bytes=0U;
        refresh_from_reopen_child(t); add_case(cases,"reopen_shape_"+std::to_string(i),t,ApertureCode::reopen_shape_invalid); }
    for(std::size_t i=0U;i<6U;++i){ auto t=good; auto wrong=digest("wrong-reopen-binding-"+std::to_string(i));
        if(i==0U)t.reopen.publication_receipt_digest=wrong;
        if(i==1U)t.reopen.response_digest=wrong;
        if(i==2U)t.reopen.request_digest=wrong;
        if(i==3U)t.reopen.reopener_implementation_digest=wrong;
        if(i==4U)t.reopen.carrier_digest=wrong;
        if(i==5U)t.reopen.reopen_policy_digest=wrong;
        t.reopen.receipt_digest=modeled_reopen_receipt_identity(t.reopen); refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t);
        add_case(cases,"reopen_binding_"+std::to_string(i),t,ApertureCode::reopen_binding_mismatch); }
    { auto t=good; t.reopen.receipt_digest[0]^=1U; refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t); add_case(cases,"reopen_digest_wrong",t,ApertureCode::reopen_digest_mismatch); }

    { auto t=good; t.successor_configuration={}; refresh_aperture_cuts(t); add_case(cases,"configuration_partial_set",t,ApertureCode::configuration_shape_invalid); }
    for(std::size_t i=0U;i<7U;++i){ auto t=good;
        if(i==0U)t.accepting_configuration.canonical=false;
        if(i==1U)t.accepting_configuration.laboratory_configuration=false;
        if(i==2U)t.accepting_configuration.external_provisioning_claimed=true;
        if(i==3U)t.accepting_configuration.current_root_version=0U;
        if(i==4U)t.accepting_configuration.evaluation_time=0U;
        if(i==5U)t.accepting_configuration.required_accept_mask=0U;
        if(i==6U)t.accepting_configuration.trusted_signer_public_key={};
        refresh_from_configurations(t); add_case(cases,"configuration_shape_"+std::to_string(i),t,ApertureCode::configuration_shape_invalid); }
    { auto t=good; t.accepting_configuration.embedded_in_response=true; refresh_from_configurations(t); add_case(cases,"configuration_embedded",t,ApertureCode::configuration_embedded_in_response); }
    { auto t=good; t.accepting_configuration.configuration_digest[0]^=1U; refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t); add_case(cases,"configuration_digest_wrong",t,ApertureCode::configuration_digest_mismatch); }
    { auto t=good; t.policy_reject_configuration=t.accepting_configuration; refresh_appraisal_child(t); refresh_deficit_child(t); refresh_aperture_cuts(t); add_case(cases,"configuration_duplicate",t,ApertureCode::configuration_digest_mismatch); }
    { auto t=good; t.accepting_configuration.current_owner_root_digest=digest("wrong-accepting-root"); refresh_from_configurations(t); add_case(cases,"accepting_configuration_rejects",t,ApertureCode::accepting_configuration_did_not_accept); }
    { auto t=good; t.accepting_configuration.evaluation_time=t.response.issued_at-1U; refresh_from_configurations(t); add_case(cases,"accepting_configuration_before_response_issuance",t,ApertureCode::accepting_configuration_did_not_accept); }
    { auto t=good; t.policy_reject_configuration.required_accept_mask=hosted_mechanism_claim_mask; refresh_from_configurations(t); add_case(cases,"policy_configuration_accepts",t,ApertureCode::policy_reject_configuration_did_not_reject); }
    { auto t=good; t.successor_configuration.current_owner_root_digest=t.response.owner_root_digest; t.successor_configuration.current_root_version=t.response.owner_root_version; refresh_from_configurations(t); add_case(cases,"successor_configuration_accepts",t,ApertureCode::successor_configuration_did_not_reject_currentness); }

    for(std::size_t i=0U;i<7U;++i){ auto t=good;
        if(i==0U)t.appraisal.canonical=false;
        if(i==1U)t.appraisal.same_response_bytes=false;
        if(i==2U)t.appraisal.opposite_policy_appraisals=false;
        if(i==3U)t.appraisal.successor_currentness_rejected=false;
        if(i==4U)t.appraisal.model_only=false;
        if(i==5U)t.appraisal.no_external_trust_claim=false;
        if(i==6U)t.appraisal.successor_root_version=t.appraisal.appraisal_root_version;
        if(i==6U) refresh_aperture_cuts(t); else refresh_from_appraisal_child(t);
        add_case(cases,"appraisal_shape_"+std::to_string(i),t,ApertureCode::appraisal_shape_invalid); }
    for(std::size_t i=0U;i<9U;++i){ auto t=good; auto wrong=digest("wrong-appraisal-binding-"+std::to_string(i));
        if(i==0U)t.appraisal.response_digest=wrong;
        if(i==1U)t.appraisal.publication_receipt_digest=wrong;
        if(i==2U)t.appraisal.reopen_receipt_digest=wrong;
        if(i==3U)t.appraisal.accepting_configuration_digest=wrong;
        if(i==4U)t.appraisal.policy_reject_configuration_digest=wrong;
        if(i==5U)t.appraisal.successor_configuration_digest=wrong;
        if(i==6U)t.appraisal.request_digest=wrong;
        if(i==7U)t.appraisal.appraisal_policy_digest=wrong;
        if(i==8U)t.appraisal.accepting_result=AppraisalResult::signer_untrusted;
        t.appraisal.witness_digest=appraisal_witness_identity(t.appraisal); refresh_deficit_child(t); refresh_aperture_cuts(t);
        add_case(cases,"appraisal_binding_"+std::to_string(i),t,ApertureCode::appraisal_binding_mismatch); }
    { auto t=good; t.appraisal.witness_digest[0]^=1U; refresh_deficit_child(t); refresh_aperture_cuts(t); add_case(cases,"appraisal_digest_wrong",t,ApertureCode::appraisal_digest_mismatch); }

    for(std::size_t i=0U;i<8U;++i){ auto t=good;
        if(i==0U)t.deficit.canonical=false;
        if(i==1U)t.deficit.prior_appraisal_not_current=false;
        if(i==2U)t.deficit.external_response_absent=false;
        if(i==3U)t.deficit.external_trust_configuration_absent=false;
        if(i==4U)t.deficit.owner_admission_absent=false;
        if(i==5U)t.deficit.no_authority_claim=false;
        if(i==6U)t.deficit.missing_premise_mask=0U;
        if(i==7U)t.deficit.consumption_root_version=t.deficit.appraisal_root_version;
        if(i==7U) refresh_aperture_cuts(t); else refresh_from_deficit_child(t);
        add_case(cases,"deficit_shape_"+std::to_string(i),t,ApertureCode::consumption_deficit_shape_invalid); }
    for(std::size_t i=0U;i<9U;++i){ auto t=good; auto wrong=digest("wrong-deficit-binding-"+std::to_string(i));
        if(i==0U)t.deficit.response_digest=wrong;
        if(i==1U)t.deficit.appraisal_witness_digest=wrong;
        if(i==2U)t.deficit.accepting_configuration_digest=wrong;
        if(i==3U)t.deficit.successor_configuration_digest=wrong;
        if(i==4U)t.deficit.request_digest=wrong;
        if(i==5U)t.deficit.appraised_owner_root_digest=wrong;
        if(i==6U)t.deficit.consumption_owner_root_digest=wrong;
        if(i==7U)t.deficit.consumption_policy_digest=wrong;
        if(i==8U)++t.deficit.appraisal_time;
        t.deficit.deficit_digest=consumption_deficit_identity(t.deficit); refresh_aperture_cuts(t);
        add_case(cases,"deficit_binding_"+std::to_string(i),t,ApertureCode::consumption_deficit_binding_mismatch); }
    { auto t=good; t.deficit.deficit_digest[0]^=1U; refresh_aperture_cuts(t); add_case(cases,"deficit_digest_wrong",t,ApertureCode::consumption_deficit_digest_mismatch); }

    { auto t=good; t.promote_fixture_to_external_response=true; add_case(cases,"hosted_response_promotion",t,ApertureCode::hosted_response_promotion_forbidden); }
    { auto t=good; t.promote_appraisal_to_owner_admission=true; add_case(cases,"hosted_admission_promotion",t,ApertureCode::hosted_admission_promotion_forbidden); }
    { auto t=good; t.grant_authority=true; add_case(cases,"authority_promotion",t,ApertureCode::authority_promotion_forbidden); }
    for(std::size_t cut=0U;cut<aperture_cut_count;++cut){ auto t=good; t.cuts[cut].parent_request_digest[0]^=1U; add_case(cases,"cut_order_"+std::to_string(cut),t,ApertureCode::cut_order_invalid); }
    return cases;
}

[[nodiscard]] bool fsync_directory(const std::filesystem::path& directory) noexcept {
    const int flags = O_RDONLY | O_CLOEXEC
#ifdef O_DIRECTORY
        | O_DIRECTORY
#endif
        ;
    const int fd = ::open(directory.c_str(), flags);
    if (fd < 0) return false;
    const bool ok = ::fsync(fd) == 0;
    const bool closed = ::close(fd) == 0;
    return ok && closed;
}

[[nodiscard]] bool write_exclusive(
    const std::filesystem::path& path, const std::span<const std::uint8_t> bytes) noexcept {
    const int fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0644);
    if (fd < 0) return false;
    bool ok = true;
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const auto remaining = bytes.size() - offset;
        const auto written = ::write(fd, bytes.data() + offset, remaining);
        if (written < 0) {
            if (errno == EINTR) continue;
            ok = false;
            break;
        }
        if (written == 0) { ok = false; break; }
        offset += static_cast<std::size_t>(written);
    }
    if (ok && ::fsync(fd) != 0) ok = false;
    if (::close(fd) != 0) ok = false;
    if (!ok) {
        std::error_code ignored;
        std::filesystem::remove(path, ignored);
        return false;
    }
    return fsync_directory(path.parent_path());
}

template <std::size_t N>
[[nodiscard]] bool write_binary(
    const std::filesystem::path& path, const std::array<std::uint8_t, N>& bytes) noexcept {
    return write_exclusive(path, std::span<const std::uint8_t>(bytes.data(), bytes.size()));
}
[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) noexcept {
    const auto* data = reinterpret_cast<const std::uint8_t*>(text.data());
    return write_exclusive(path, std::span<const std::uint8_t>(data, text.size()));
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    if (std::filesystem::exists(output_directory, error) || error) {
        std::cerr << "output directory must be absent\n";
        return false;
    }
    if (!std::filesystem::create_directory(output_directory, error) || error) {
        std::cerr << "cannot create output directory\n";
        return false;
    }
    const auto cases = corpus();
    const auto good = baseline();
    std::size_t accepted=0U,rejected=0U,disagreements=0U,appraisal_ready=0U,deficit_ready=0U;
    std::ostringstream case_rows;
    case_rows << "case\texpected\tcandidate\treference\taccepted\tresponse_valid\tappraisal_valid\tdeficit_valid\n";
    std::ostringstream countermodels;
    countermodels << "case\tboundary\tresult\n";
    for(const auto& item:cases){
        const auto candidate=evaluate_candidate(item.trace); const auto reference=evaluate_reference(item.trace);
        if(candidate!=reference)++disagreements;
        if(candidate.code!=item.expected||reference.code!=item.expected){
            std::cerr<<"unexpected result case="<<item.name<<" expected="<<aperture_code_name(item.expected)
                     <<" candidate="<<aperture_code_name(candidate.code)<<" reference="<<aperture_code_name(reference.code)<<"\n";
            return false;
        }
        if(candidate.accepted)++accepted;else{++rejected;countermodels<<item.name<<'\t'<<aperture_code_name(candidate.code)<<"\tREJECTED\n";}
        if(candidate.appraisal_witness_valid)++appraisal_ready;
        if(candidate.consumption_deficit_valid)++deficit_ready;
        case_rows<<item.name<<'\t'<<aperture_code_name(item.expected)<<'\t'<<aperture_code_name(candidate.code)<<'\t'
                 <<aperture_code_name(reference.code)<<'\t'<<(candidate.accepted?"true":"false")<<'\t'
                 <<(candidate.response_valid?"true":"false")<<'\t'<<(candidate.appraisal_witness_valid?"true":"false")<<'\t'
                 <<(candidate.consumption_deficit_valid?"true":"false")<<'\n';
    }
    if(disagreements!=0U){std::cerr<<"candidate/reference disagreements="<<disagreements<<"\n";return false;}

    std::ostringstream cuts;
    cuts<<"case\tcut\tcut_name\tcandidate\treference\taccepted\n";
    std::size_t cut_rows=0U;
    for(const auto& item:cases){for(std::size_t cut=0U;cut<aperture_cut_count;++cut){
        const auto projected=at_stage(item.trace,cut); const auto candidate=evaluate_candidate(projected); const auto reference=evaluate_reference(projected);
        if(candidate!=reference){std::cerr<<"cut disagreement case="<<item.name<<" cut="<<cut<<"\n";return false;}
        cuts<<item.name<<'\t'<<cut<<'\t'<<aperture_cut_name(cut)<<'\t'<<aperture_code_name(candidate.code)<<'\t'
            <<aperture_code_name(reference.code)<<'\t'<<(candidate.accepted?"true":"false")<<'\n'; ++cut_rows;
    }}

    EncodedLabResponse response{}; EncodedPublicationReceipt publication{}; EncodedReopenReceipt reopen{};
    EncodedTrustConfiguration accepting{},policy_reject{},successor{}; EncodedAppraisalWitness appraisal{}; EncodedConsumptionDeficit deficit{};
    if(!encode_lab_response(good.response,response)||!encode_modeled_publication_receipt(good.publication,publication)
       ||!encode_modeled_reopen_receipt(good.reopen,reopen)||!encode_trust_configuration(good.accepting_configuration,accepting)
       ||!encode_trust_configuration(good.policy_reject_configuration,policy_reject)||!encode_trust_configuration(good.successor_configuration,successor)
       ||!encode_appraisal_witness(good.appraisal,appraisal)||!encode_consumption_deficit(good.deficit,deficit)){
        std::cerr<<"canonical encoding failed\n";return false;
    }
    std::ostringstream identities;
    identities<<"object\tbytes\tsha256\n"
      <<"LAB-RESPONSE-FIXTURE.bin\t"<<response.size()<<'\t'<<hex(good.response.response_digest)<<'\n'
      <<"MODELED-PUBLICATION-RECEIPT.bin\t"<<publication.size()<<'\t'<<hex(good.publication.receipt_digest)<<'\n'
      <<"MODELED-REOPEN-RECEIPT.bin\t"<<reopen.size()<<'\t'<<hex(good.reopen.receipt_digest)<<'\n'
      <<"ACCEPTING-CONFIGURATION.bin\t"<<accepting.size()<<'\t'<<hex(good.accepting_configuration.configuration_digest)<<'\n'
      <<"POLICY-REJECT-CONFIGURATION.bin\t"<<policy_reject.size()<<'\t'<<hex(good.policy_reject_configuration.configuration_digest)<<'\n'
      <<"SUCCESSOR-CONFIGURATION.bin\t"<<successor.size()<<'\t'<<hex(good.successor_configuration.configuration_digest)<<'\n'
      <<"APPRAISAL-WITNESS.bin\t"<<appraisal.size()<<'\t'<<hex(good.appraisal.witness_digest)<<'\n'
      <<"CONSUMPTION-DEFICIT.bin\t"<<deficit.size()<<'\t'<<hex(good.deficit.deficit_digest)<<'\n';
    const std::string laws=
      "law\tstatement\n"
      "L1\tThe sole parent is one exact owner-handoff-ready Hosted Externality trace.\n"
      "L2\tThe detached response is a laboratory fixture signed with real Ed25519 and is not an external occurrence.\n"
      "L3\tSignature validity proves integrity under the embedded public key, not that the key is trusted.\n"
      "L4\tTrust configuration is separately supplied to appraisal and is forbidden from entering the response.\n"
      "L5\tThe same response is accepted by one lab configuration and rejected by another policy configuration.\n"
      "L6\tA successor owner root rejects the prior response even when its signature remains valid.\n"
      "L7\tModeled publication and reopen receipts do not prove external publication or administrative independence.\n"
      "L8\tAn appraisal witness binds response, receipts, configurations, policy, results, and root versions.\n"
      "L9\tAn appraisal at root version N is not current evidence for consumption at version N+1.\n"
      "L10\tThe consumption deficit keeps external response occurrence, external trust provisioning, owner admission, and authority false.\n"
      "L11\tEvery durable prefix is resumable and cannot imply a later stage.\n"
      "L12\tNo provider, network service, signer service, database, owner registry, or fourth semantic island is admitted.\n"
      "L13\tAn appraisal cannot precede the response issued-at time even when not-before permits an earlier validity boundary.\n";
    std::ostringstream summary;
    summary<<"metric\tvalue\n"<<"cases\t"<<cases.size()<<'\n'<<"accepted_classifications\t"<<accepted<<'\n'
      <<"rejected_classifications\t"<<rejected<<'\n'<<"appraisal_witness_ready_cases\t"<<appraisal_ready<<'\n'
      <<"consumption_deficit_ready_cases\t"<<deficit_ready<<'\n'<<"lifecycle_cut_rows\t"<<cut_rows<<'\n'
      <<"durable_stages\t"<<aperture_cut_count<<'\n'<<"canonical_exact_object_bytes\t"<<canonical_exact_object_bytes<<'\n'
      <<"candidate_reference_disagreements\t0\nreal_ed25519_fixture\ttrue\nexternal_response_present\tfalse\n"
      <<"external_trust_configuration_proved\tfalse\nowner_admission_proved\tfalse\nauthority_granted\tfalse\nepoch_exit_proved\tfalse\n";
    std::ostringstream report;
    report<<"DETACHED_RESPONSE_INTAKE_APERTURE=PASS\n"<<"cases="<<cases.size()<<" accepted="<<accepted<<" rejected="<<rejected
      <<" cuts="<<cut_rows<<" appraisal_ready="<<appraisal_ready<<" deficit_ready="<<deficit_ready<<"\n"
      <<"candidate_reference_disagreements=0 exact_objects="<<canonical_exact_object_bytes<<" real_ed25519_fixture=true\n"
      <<"external_response=false external_trust=false external_publication=false owner_admission=false authority=false epoch_exit=false\n";
    const bool written=write_binary(output_directory/"LAB-RESPONSE-FIXTURE.bin",response)
      &&write_binary(output_directory/"MODELED-PUBLICATION-RECEIPT.bin",publication)
      &&write_binary(output_directory/"MODELED-REOPEN-RECEIPT.bin",reopen)
      &&write_binary(output_directory/"ACCEPTING-CONFIGURATION.bin",accepting)
      &&write_binary(output_directory/"POLICY-REJECT-CONFIGURATION.bin",policy_reject)
      &&write_binary(output_directory/"SUCCESSOR-CONFIGURATION.bin",successor)
      &&write_binary(output_directory/"APPRAISAL-WITNESS.bin",appraisal)
      &&write_binary(output_directory/"CONSUMPTION-DEFICIT.bin",deficit)
      &&write_text(output_directory/"CASES.tsv",case_rows.str())&&write_text(output_directory/"CUTS.tsv",cuts.str())
      &&write_text(output_directory/"IDENTITIES.tsv",identities.str())&&write_text(output_directory/"LAWS.tsv",laws)
      &&write_text(output_directory/"COUNTERMODELS.tsv",countermodels.str())&&write_text(output_directory/"SUMMARY.tsv",summary.str())
      &&write_text(output_directory/"REPORT.txt",report.str());
    if (!written) {
        return false;
    }
    std::cout << report.str();
    return true;
}

}  // namespace ...::detached_response_aperture
