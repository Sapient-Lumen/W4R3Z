#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

FIELDS = [
    "case", "initial_phase", "command", "observation", "exact_request",
    "exact_transition", "exact_incarnation", "authenticated", "linearizable",
    "single_view", "durable_result", "retirement_serialized",
    "late_commit_fenced", "retention_covers_reopen", "candidate_code",
    "reference_code", "agreement", "accepted", "next_phase", "outcome",
    "query_only", "terminal", "terminal_no_effect_justified",
    "absence_terminal", "resubmit_allowed", "recovery_mints_first_submit",
    "authority",
]


def fail(detail: str) -> None:
    raise SystemExit(f"QUERY_ONLY_RECOVERY_PY=FAIL detail={detail}")


def b(row: dict[str, str], key: str) -> bool:
    value = row[key]
    if value not in {"true", "false"}:
        fail(f"boolean={key}:{value}")
    return value == "true"


def phase_outcome(phase: str) -> str:
    return {
        "ready": "none",
        "query_only": "uncertain",
        "terminal_effect": "effect",
        "terminal_no_effect": "no_effect",
        "fail_stopped": "fail_stop",
    }[phase]


def result(code: str, accepted: bool, phase: str, outcome: str) -> tuple[str, bool, str, str, bool, bool, bool]:
    return (
        code,
        accepted,
        phase,
        outcome,
        phase == "query_only",
        phase in {"terminal_effect", "terminal_no_effect", "fail_stopped"},
        accepted and phase == "terminal_no_effect",
    )


def reject(row: dict[str, str], code: str) -> tuple[str, bool, str, str, bool, bool, bool]:
    phase = row["initial_phase"]
    return result(code, False, phase, phase_outcome(phase))


def evidence_failure(row: dict[str, str], durable: bool, retention: bool) -> str | None:
    if not b(row, "authenticated"):
        return "authentication_required"
    if not b(row, "linearizable"):
        return "linearizable_observation_required"
    if not b(row, "single_view"):
        return "single_view_required"
    if durable and not b(row, "durable_result"):
        return "durable_result_required"
    if retention and not b(row, "retention_covers_reopen"):
        return "retention_horizon_required"
    return None


def evaluate(row: dict[str, str]) -> tuple[str, bool, str, str, bool, bool, bool]:
    if row["case"] == "zero_state_identity_rejected":
        return reject(row, "invalid_state")
    if not b(row, "exact_request"):
        return reject(row, "request_id_mismatch")
    if not b(row, "exact_transition"):
        return reject(row, "transition_digest_mismatch")
    if not b(row, "exact_incarnation"):
        return reject(row, "register_incarnation_mismatch")

    phase, command, observation = row["initial_phase"], row["command"], row["observation"]
    if phase == "ready":
        if command != "submit_exact":
            return reject(row, "invalid_command_for_phase")
        if observation == "no_reply":
            return result("accepted_submit_uncertain", True, "query_only", "uncertain")
        if observation != "commit_reply":
            return reject(row, "invalid_observation_for_command")
        failure = evidence_failure(row, True, True)
        return reject(row, failure) if failure else result(
            "accepted_submit_commit", True, "terminal_effect", "effect")

    if phase == "query_only":
        if command == "reopen":
            return result("accepted_reopen_query_only", True, "query_only", "uncertain") \
                if observation == "reopen_event" else reject(row, "invalid_observation_for_command")
        if command == "declare_no_effect" and observation == "absent_record":
            return reject(row, "absence_not_terminal")
        if command in {"submit_exact", "clear_latch", "repair"}:
            return reject(row, "query_only_latched")
        if command != "query_exact":
            return reject(row, "invalid_command_for_phase")
        direct = {
            "unavailable": ("accepted_query_unavailable", "query_only", "uncertain"),
            "wrong_incarnation": ("accepted_query_wrong_incarnation_fail_stop", "fail_stopped", "fail_stop"),
            "split_view": ("accepted_query_split_view_fail_stop", "fail_stopped", "fail_stop"),
        }
        if observation in direct:
            code, next_phase, outcome = direct[observation]
            return result(code, True, next_phase, outcome)
        if observation not in {"committed_record", "absent_record", "retired_record"}:
            return reject(row, "invalid_observation_for_command")
        durable = observation in {"committed_record", "retired_record"}
        failure = evidence_failure(row, durable, durable)
        if failure:
            return reject(row, failure)
        if observation == "absent_record":
            return result("accepted_query_absent_unresolved", True, "query_only", "uncertain")
        if observation == "committed_record":
            return result("accepted_query_commit", True, "terminal_effect", "effect")
        if not b(row, "retirement_serialized"):
            return reject(row, "retirement_record_required")
        if not b(row, "late_commit_fenced"):
            return reject(row, "late_commit_fence_required")
        return result("accepted_query_retired", True, "terminal_no_effect", "no_effect")

    if phase == "terminal_effect":
        return result("accepted_reopen_terminal_effect", True, phase, "effect") \
            if command == "reopen" and observation == "reopen_event" else reject(row, "terminal_immutable")
    if phase == "terminal_no_effect":
        return result("accepted_reopen_terminal_no_effect", True, phase, "no_effect") \
            if command == "reopen" and observation == "reopen_event" else reject(row, "terminal_immutable")
    if phase == "fail_stopped":
        return result("accepted_reopen_fail_stop", True, phase, "fail_stop") \
            if command == "reopen" and observation == "reopen_event" else reject(row, "fail_stop_immutable")
    fail(f"phase={phase}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.output.resolve()

    with (root / "CASES.tsv").open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames != FIELDS:
            fail(f"header={reader.fieldnames!r}")
        rows = list(reader)
    if len(rows) != 54 or len({row["case"] for row in rows}) != 54:
        fail("case cardinality")

    accepted = terminal_effect = terminal_no_effect = unresolved = fail_stopped = 0
    for row in rows:
        expected = evaluate(row)
        observed = (
            row["candidate_code"], b(row, "accepted"), row["next_phase"], row["outcome"],
            b(row, "query_only"), b(row, "terminal"), b(row, "terminal_no_effect_justified"),
        )
        if expected != observed:
            fail(f"evaluation={row['case']} expected={expected!r} observed={observed!r}")
        if row["candidate_code"] != row["reference_code"] or not b(row, "agreement"):
            fail(f"differential={row['case']}")
        if any(b(row, key) for key in (
            "absence_terminal", "resubmit_allowed", "recovery_mints_first_submit", "authority")):
            fail(f"forbidden projection={row['case']}")
        accepted += b(row, "accepted")
        terminal_effect += b(row, "accepted") and row["next_phase"] == "terminal_effect"
        terminal_no_effect += b(row, "accepted") and row["next_phase"] == "terminal_no_effect"
        unresolved += b(row, "accepted") and row["next_phase"] == "query_only"
        fail_stopped += b(row, "accepted") and row["next_phase"] == "fail_stopped"

    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    expected_summary = {
        "absence_terminal_cases": 0,
        "accepted_cases": 12,
        "authority_granted": False,
        "candidate_reference_disagreements": 0,
        "cases": 54,
        "currentness_proved": False,
        "epoch_exit_proved": False,
        "external_occurrence_proved": False,
        "fail_stopped_cases": 3,
        "independent_custody_proved": False,
        "independent_reopen_proved": False,
        "late_commit_fence_required": True,
        "query_only_monotone": True,
        "recovery_mints_first_submit_cases": 0,
        "rejected_cases": 42,
        "resubmit_allowed_cases": 0,
        "schema": "slopos.rev0916.query-only-recovery-campaign.v1",
        "terminal_effect_cases": 3,
        "terminal_no_effect_cases": 2,
        "terminal_no_effect_requires_retirement": True,
        "unresolved_query_only_cases": 4,
    }
    if summary != expected_summary:
        fail(f"summary={summary!r}")
    if (accepted, terminal_effect, terminal_no_effect, unresolved, fail_stopped) != (12, 3, 2, 4, 3):
        fail("summary counts")

    with (root / "COUNTERHISTORY.tsv").open(newline="", encoding="utf-8") as handle:
        counter = list(csv.DictReader(handle, delimiter="\t"))
    if [row["row"] for row in counter] != ["P0", "P1", "H0", "H1"]:
        fail("counterhistory rows")
    if counter[1]["visible_register"] != "N" or counter[3]["visible_register"] != "N_plus_1":
        fail("counterhistory values")
    if counter[1]["terminal_no_effect_sound"] != "false" or counter[3]["effect"] != "effect":
        fail("counterhistory theorem")

    invariants = (root / "INVARIANTS.txt").read_text(encoding="utf-8").splitlines()
    required = {
        "ABSENT_WHILE_PENDING_NOT_TERMINAL=true",
        "QUERY_ONLY_LATCH_MONOTONE=true",
        "TERMINAL_NO_EFFECT_REQUIRES_SERIALIZED_RETIREMENT=true",
        "TERMINAL_NO_EFFECT_REQUIRES_LATE_COMMIT_FENCE=true",
        "RETENTION_MUST_COVER_REOPEN=true",
        "RESTORE_DOES_NOT_CLEAR_QUERY_ONLY=true",
        "RESUBMIT_ALLOWED=false",
        "RECOVERY_MINTS_FIRST_SUBMIT=false",
        "AUTHORITY_GRANTED=false",
    }
    if set(invariants) != required:
        fail("invariants")

    print(
        "QUERY_ONLY_RECOVERY_PY=PASS cases=54 accepted=12 rejected=42 "
        "terminal_effect=3 terminal_no_effect=2 unresolved=4 fail_stop=3 "
        "absence_terminal=0 disagreements=0 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
