# Detached Response Intake Aperture V1

## Parent

The sole parent is one accepted Hosted Externality Nonderivation trace whose
owner-handoff request and premise-deficit certificate are exact and whose
`owner_handoff_ready` classification is true.

## Canonical objects

The child emits eight exact objects totaling 2,528 bytes:

1. 512-byte laboratory response fixture;
2. 256-byte modeled no-replace publication receipt;
3. 256-byte modeled exact-rehash receipt;
4. three 288-byte laboratory trust configurations;
5. 320-byte appraisal witness; and
6. 320-byte later-consumption deficit.

The response binds the exact parent request, linked rev0924 transport,
parent closure claim, claim catalogue, response profile, owner constitution,
owner root, appraisal policy, target, and response namespace. Its fifteen claim
bits form a disjoint, exhaustive accepted/rejected/unresolved partition.

## Trust relation

Signature validity is evaluated independently from trust. The same signed
response is accepted by one separately supplied laboratory configuration,
rejected by a configuration requiring unresolved governance claims, and rejected
under a successor root. A configuration is not allowed inside the response and
cannot claim external provisioning.

## Currentness fence

The appraisal witness binds the exact response, receipts, three configurations,
results, policy, request, and root versions. An appraisal time must be at or after
both the response's `not_before` boundary and its `issued_at` time, and must be
strictly before expiry. A retained counterexample rejects appraisal in the gap
between `not_before` and `issued_at`. The consumption-deficit object then records
that the version-41 appraisal is not current for version-42 consumption. A future
consumer requires a fresh appraisal under the then-current root and policy.

## Nonclaims

All response, publication, reopen, trust, and time inputs remain laboratory or
modeled. The construction proves no external occurrence, administrative or
custody independence, owner constitution, owner admission, authority, or epoch
transition. It introduces no provider, network service, signer service,
database, owner registry, deletion worker, or fourth semantic island.
