#include "slopos/e0/generation_journal/local_join.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <sqlite3.h>

#include <algorithm>
#include <array>
#include <barrier>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace slopos::e0::generation_journal {
namespace {

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

template <std::size_t Size>
[[nodiscard]] std::string hex_value(
    const std::array<std::uint8_t, Size>& value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const std::uint8_t byte : value) {
        out << std::setw(2) << static_cast<unsigned int>(byte);
    }
    return out.str();
}

[[nodiscard]] Digest patterned(const std::uint8_t base) noexcept {
    Digest result{};
    for (std::size_t index = 0U; index < result.size(); ++index) {
        result[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return result;
}

[[nodiscard]] SpendRecordV1 make_record(
    const std::uint64_t serial, const FloorPoint& predecessor,
    const std::uint8_t operation_base) noexcept {
    SpendRecordV1 record;
    record.owner_epoch = 3U;
    record.constructor_epoch = 11U;
    record.spend_serial = serial;
    record.generation_from = predecessor.generation;
    record.generation_to = predecessor.generation + 1U;
    record.owner_statement = patterned(1U);
    record.constructor_image = patterned(33U);
    record.provider_subject = patterned(65U);
    record.publication_receipt = patterned(97U);
    record.expectation_record = patterned(129U);
    record.operation = patterned(operation_base);
    record.pending_result = patterned(193U);
    record.predecessor_head = predecessor.head;
    return record;
}

[[nodiscard]] EncodedSpendRecord encoded(const SpendRecordV1& record) {
    EncodedSpendRecord output{};
    require(encode_spend_record(record, output), "encode join spend record");
    SpendRecordV1 roundtrip;
    require(decode_spend_record(output, roundtrip) && roundtrip == record,
            "decode join spend record");
    return output;
}

[[nodiscard]] CompareAppendRequest make_request(
    const Digest& floor_identity, const FloorPoint& expected,
    const EncodedSpendRecord& record) {
    SpendRecordV1 decoded;
    require(decode_spend_record(record, decoded), "decode join request record");
    return CompareAppendRequest{
        floor_identity,
        expected,
        FloorPoint{decoded.generation_to, spend_record_head(record)},
        record,
    };
}

[[nodiscard]] bool exact_base_observation(
    const HostedJoinObservation& observation, const Digest& identity,
    const FloorPoint& base) noexcept {
    return observation.status == HostedJoinReadStatus::available
        && observation.floor_identity == identity
        && observation.current == base
        && !observation.current_record.has_value()
        && observation.endpoint_entries == 0U
        && observation.endpoint_bindings_exact;
}

[[nodiscard]] bool exact_target_observation(
    const HostedJoinObservation& observation, const Digest& identity,
    const CompareAppendRequest& request) noexcept {
    return observation.status == HostedJoinReadStatus::available
        && observation.floor_identity == identity
        && observation.current == request.target
        && observation.current_record.has_value()
        && *observation.current_record == request.record
        && observation.endpoint_entries == 1U
        && observation.endpoint_bindings_exact;
}

struct JoinCaseRow final {
    std::string name;
    HostedJoinStatus status{HostedJoinStatus::malformed};
    bool endpoint_entry_created{false};
    bool endpoint_bindings_exact{false};
    bool query_only{false};
    bool spent{false};
    bool response_authority{false};
    bool fail_stop{true};
    std::uint64_t endpoint_entries{0U};
    std::string detail;
};

struct RaceRow final {
    std::string name;
    std::size_t contenders{0U};
    std::size_t admitted{0U};
    std::size_t already_current{0U};
    std::size_t conflicts{0U};
    std::size_t unavailable{0U};
    std::uint64_t final_entries{0U};
    bool exact_final_state{false};
};

struct CrashRow final {
    HostedJoinFaultCut cut{HostedJoinFaultCut::none};
    int child_exit{0};
    std::string recovered_state;
    std::uint64_t recovered_entries{0U};
    HostedJoinStatus retry_status{HostedJoinStatus::malformed};
    std::uint64_t retry_entries{0U};
    bool clean_read_only_reopen{false};
};

struct LinuxProbe final {
    bool supported{false};
    std::size_t peek_receives{0U};
    std::size_t consume_receives{0U};
    std::size_t installed_descriptor_references{0U};
    std::string shared_offset_sequence;
    bool authority{false};
};

void close_fd(int& descriptor) noexcept {
    if (descriptor >= 0) {
        while (::close(descriptor) != 0 && errno == EINTR) {
        }
        descriptor = -1;
    }
}

[[nodiscard]] bool write_all(const int descriptor, const char* data,
                             const std::size_t size) noexcept {
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t written = ::write(
            descriptor, data + offset, size - offset);
        if (written < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (written == 0) return false;
        offset += static_cast<std::size_t>(written);
    }
    return true;
}

[[nodiscard]] bool send_descriptor(const int socket_fd,
                                   const int sent_fd) noexcept {
    char payload = 'J';
    iovec vector{};
    vector.iov_base = &payload;
    vector.iov_len = 1U;
    alignas(cmsghdr) std::array<char, CMSG_SPACE(sizeof(int))> control{};
    msghdr message{};
    message.msg_iov = &vector;
    message.msg_iovlen = 1U;
    message.msg_control = control.data();
    message.msg_controllen = control.size();
    cmsghdr* header = CMSG_FIRSTHDR(&message);
    if (header == nullptr) return false;
    header->cmsg_level = SOL_SOCKET;
    header->cmsg_type = SCM_RIGHTS;
    header->cmsg_len = CMSG_LEN(sizeof(int));
    std::memcpy(CMSG_DATA(header), &sent_fd, sizeof(sent_fd));
    for (;;) {
        const ssize_t sent = ::sendmsg(socket_fd, &message, MSG_NOSIGNAL);
        if (sent == 1) return true;
        if (sent < 0 && errno == EINTR) continue;
        return false;
    }
}

[[nodiscard]] std::optional<int> receive_descriptor(
    const int socket_fd, const int flags) noexcept {
    char payload = '\0';
    iovec vector{};
    vector.iov_base = &payload;
    vector.iov_len = 1U;
    alignas(cmsghdr) std::array<char, CMSG_SPACE(sizeof(int))> control{};
    msghdr message{};
    message.msg_iov = &vector;
    message.msg_iovlen = 1U;
    message.msg_control = control.data();
    message.msg_controllen = control.size();
    ssize_t received = -1;
    do {
        received = ::recvmsg(socket_fd, &message, flags | MSG_CMSG_CLOEXEC);
    } while (received < 0 && errno == EINTR);
    if (received != 1 || payload != 'J'
        || (message.msg_flags & (MSG_CTRUNC | MSG_TRUNC)) != 0) {
        return std::nullopt;
    }
    int found = -1;
    std::size_t count = 0U;
    for (cmsghdr* header = CMSG_FIRSTHDR(&message); header != nullptr;
         header = CMSG_NXTHDR(&message, header)) {
        if (header->cmsg_level == SOL_SOCKET
            && header->cmsg_type == SCM_RIGHTS
            && header->cmsg_len >= CMSG_LEN(sizeof(int))) {
            const std::size_t payload_bytes =
                static_cast<std::size_t>(header->cmsg_len - CMSG_LEN(0U));
            const std::size_t descriptors = payload_bytes / sizeof(int);
            const auto* values = reinterpret_cast<const int*>(CMSG_DATA(header));
            for (std::size_t index = 0U; index < descriptors; ++index) {
                if (count == 0U) {
                    found = values[index];
                } else {
                    int extra = values[index];
                    close_fd(extra);
                }
                ++count;
            }
        }
    }
    if (count != 1U || found < 0) {
        close_fd(found);
        return std::nullopt;
    }
    return found;
}

[[nodiscard]] LinuxProbe run_linux_probe(
    const std::filesystem::path& work) {
#if defined(__linux__)
    int sockets[2]{-1, -1};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, sockets) == 0,
            "socketpair for SCM_RIGHTS probe");
    const std::filesystem::path file = work / "scm-rights-offset.bin";
    int source = ::open(file.c_str(), O_CREAT | O_EXCL | O_RDWR | O_CLOEXEC,
                        static_cast<mode_t>(0600));
    require(source >= 0, "open SCM_RIGHTS probe file");
    require(write_all(source, "ABC", 3U), "write SCM_RIGHTS probe file");
    require(::lseek(source, 0, SEEK_SET) == 0, "rewind SCM_RIGHTS probe file");
    require(send_descriptor(sockets[0], source), "send SCM_RIGHTS descriptor");
    close_fd(source);

    auto first = receive_descriptor(sockets[1], MSG_PEEK);
    auto second = receive_descriptor(sockets[1], MSG_PEEK);
    auto third = receive_descriptor(sockets[1], 0);
    require(first.has_value() && second.has_value() && third.has_value(),
            "three SCM_RIGHTS descriptor installations");
    std::array<int, 3U> descriptors{{*first, *second, *third}};
    std::string sequence;
    for (int& descriptor : descriptors) {
        char byte = '\0';
        ssize_t count = -1;
        do {
            count = ::read(descriptor, &byte, 1U);
        } while (count < 0 && errno == EINTR);
        require(count == 1, "shared open-file-description offset read");
        sequence.push_back(byte);
        close_fd(descriptor);
    }
    close_fd(sockets[0]);
    close_fd(sockets[1]);
    std::error_code error;
    (void)std::filesystem::remove(file, error);
    require(sequence == "ABC", "SCM_RIGHTS references share one file offset");
    return LinuxProbe{true, 2U, 1U, 3U, sequence, false};
#else
    (void)work;
    return LinuxProbe{};
#endif
}

[[nodiscard]] std::array<std::uint8_t, 8U> generation_bytes(
    const std::uint64_t value) noexcept {
    std::array<std::uint8_t, 8U> bytes{};
    for (std::size_t index = 0U; index < bytes.size(); ++index) {
        const std::size_t shift = (bytes.size() - 1U - index) * 8U;
        bytes[index] = static_cast<std::uint8_t>((value >> shift) & 0xffU);
    }
    return bytes;
}

[[nodiscard]] bool commit_unsafe_split_floor_only(
    const std::filesystem::path& path,
    const CompareAppendRequest& request) noexcept {
    sqlite3* database = nullptr;
    if (sqlite3_open_v2(path.c_str(), &database,
                        SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX,
                        nullptr) != SQLITE_OK) {
        if (database != nullptr) (void)sqlite3_close_v2(database);
        return false;
    }
    const auto close_database = [&]() noexcept {
        (void)sqlite3_close_v2(database);
        database = nullptr;
    };
    if (sqlite3_exec(database, "BEGIN IMMEDIATE;", nullptr, nullptr, nullptr)
        != SQLITE_OK) {
        close_database();
        return false;
    }
    sqlite3_stmt* statement = nullptr;
    const char* sql =
        "UPDATE slopos_floor SET generation_be=?1, head=?2, current_record=?3 "
        "WHERE singleton=1 AND floor_identity=?4 AND generation_be=?5 AND head=?6;";
    if (sqlite3_prepare_v2(database, sql, -1, &statement, nullptr) != SQLITE_OK) {
        (void)sqlite3_exec(database, "ROLLBACK;", nullptr, nullptr, nullptr);
        close_database();
        return false;
    }
    const auto target_generation = generation_bytes(request.target.generation);
    const auto expected_generation = generation_bytes(request.expected.generation);
    const auto bind = [&](const int index, const auto& value) {
        return sqlite3_bind_blob(statement, index, value.data(),
            static_cast<int>(value.size()), SQLITE_TRANSIENT) == SQLITE_OK;
    };
    const bool bound = bind(1, target_generation)
        && bind(2, request.target.head)
        && bind(3, request.record)
        && bind(4, request.floor_identity)
        && bind(5, expected_generation)
        && bind(6, request.expected.head);
    const bool updated = bound && sqlite3_step(statement) == SQLITE_DONE
        && sqlite3_changes(database) == 1;
    (void)sqlite3_finalize(statement);
    const bool committed = updated
        && sqlite3_exec(database, "COMMIT;", nullptr, nullptr, nullptr) == SQLITE_OK;
    if (!committed) {
        (void)sqlite3_exec(database, "ROLLBACK;", nullptr, nullptr, nullptr);
    }
    close_database();
    return committed;
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<JoinCaseRow>& rows) {
    std::ofstream out(output / "join-cases.tsv", std::ios::binary);
    require(out.good(), "open join-cases.tsv");
    out << "case\tstatus\tendpoint_entry_created\tendpoint_bindings_exact"
           "\tquery_only\tspent\tresponse_authority\tfail_stop"
           "\tendpoint_entries\tdetail\n";
    for (const JoinCaseRow& row : rows) {
        out << row.name << '\t' << hosted_join_status_name(row.status) << '\t'
            << bool_text(row.endpoint_entry_created) << '\t'
            << bool_text(row.endpoint_bindings_exact) << '\t'
            << bool_text(row.query_only) << '\t' << bool_text(row.spent) << '\t'
            << bool_text(row.response_authority) << '\t'
            << bool_text(row.fail_stop) << '\t' << row.endpoint_entries << '\t'
            << row.detail << '\n';
    }
}

void write_races(const std::filesystem::path& output,
                 const std::vector<RaceRow>& rows) {
    std::ofstream out(output / "join-races.tsv", std::ios::binary);
    require(out.good(), "open join-races.tsv");
    out << "race\tcontenders\tadmitted\talready_current\tconflicts"
           "\tunavailable\tfinal_entries\texact_final_state\n";
    for (const RaceRow& row : rows) {
        out << row.name << '\t' << row.contenders << '\t' << row.admitted << '\t'
            << row.already_current << '\t' << row.conflicts << '\t'
            << row.unavailable << '\t' << row.final_entries << '\t'
            << bool_text(row.exact_final_state) << '\n';
    }
}

void write_crashes(const std::filesystem::path& output,
                   const std::vector<CrashRow>& rows) {
    std::ofstream out(output / "join-crash-cuts.tsv", std::ios::binary);
    require(out.good(), "open join-crash-cuts.tsv");
    out << "cut\tchild_exit\trecovered_state\trecovered_entries"
           "\tretry_status\tretry_entries\tclean_read_only_reopen\n";
    for (const CrashRow& row : rows) {
        out << hosted_join_fault_cut_name(row.cut) << '\t' << row.child_exit << '\t'
            << row.recovered_state << '\t' << row.recovered_entries << '\t'
            << hosted_join_status_name(row.retry_status) << '\t'
            << row.retry_entries << '\t'
            << bool_text(row.clean_read_only_reopen) << '\n';
    }
}

void write_response_replay(const std::filesystem::path& output,
                           const HostedJoinResult& admitted,
                           const HostedJoinObservation& observation) {
    std::ofstream out(output / "join-response-replay.tsv", std::ios::binary);
    require(out.good(), "open join-response-replay.tsv");
    out << "copies\tcopyable_observation\tresponse_authorities"
           "\tendpoint_entries_before\tendpoint_entries_after"
           "\tnew_endpoint_entries\n";
    const HostedJoinResult first = admitted;
    const HostedJoinResult second = admitted;
    require(!first.response_authority && !second.response_authority,
            "copied join responses remain nonauthority");
    out << "2\ttrue\t0\t" << admitted.endpoint_entries << '\t'
        << observation.endpoint_entries << "\t0\n";
}

void write_rollback_clone(const std::filesystem::path& output,
                          const HostedJoinResult& primary,
                          const HostedJoinResult& clone,
                          const HostedJoinObservation& primary_observation,
                          const HostedJoinObservation& clone_observation) {
    std::ofstream out(output / "join-rollback-clone.tsv", std::ios::binary);
    require(out.good(), "open join-rollback-clone.tsv");
    out << "world\tstatus\tendpoint_entries\texact_state\n";
    out << "primary\t" << hosted_join_status_name(primary.status) << '\t'
        << primary_observation.endpoint_entries << "\ttrue\n";
    out << "pre-spend-clone\t" << hosted_join_status_name(clone.status) << '\t'
        << clone_observation.endpoint_entries << "\ttrue\n";
    out << "combined-hosted-histories\tadmitted\t"
        << primary_observation.endpoint_entries + clone_observation.endpoint_entries
        << "\tfalse\n";
}

void write_split_gap(const std::filesystem::path& output,
                     const HostedJoinObservation& observation) {
    std::ofstream out(output / "join-split-gap.tsv", std::ios::binary);
    require(out.good(), "open join-split-gap.tsv");
    out << "construction\tfloor_successor_committed\tendpoint_entries"
           "\tindependent_observation\tclassification\n";
    out << "unsafe-split-append-then-entry\ttrue\t0\t"
        << hosted_join_read_status_name(observation.status)
        << "\tuncertain-fail-stop\n";
    out << "joined-local-transaction\tfalse\t0\tavailable"
           "\tprecommit-crash-rolls-back\n";
    out << "joined-local-transaction\ttrue\t1\tavailable"
           "\tpostcommit-crash-reopens-exact\n";
}

void write_linux_probe(const std::filesystem::path& output,
                       const LinuxProbe& probe) {
    std::ofstream out(output / "join-linux-probes.tsv", std::ios::binary);
    require(out.good(), "open join-linux-probes.tsv");
    out << "probe\tsupported\tpeek_receives\tconsume_receives"
           "\tinstalled_descriptor_references\tshared_offset_sequence"
           "\tauthority\n";
    out << "scm-rights-msg-peek\t" << bool_text(probe.supported) << '\t'
        << probe.peek_receives << '\t' << probe.consume_receives << '\t'
        << probe.installed_descriptor_references << '\t'
        << (probe.shared_offset_sequence.empty() ? "-" : probe.shared_offset_sequence)
        << '\t' << bool_text(probe.authority) << '\n';
}

void write_summary(const std::filesystem::path& output,
                   const std::size_t cases,
                   const std::vector<RaceRow>& races,
                   const std::vector<CrashRow>& crashes,
                   const LinuxProbe& probe) {
    const auto race = std::find_if(races.begin(), races.end(),
        [](const RaceRow& row) { return row.name == "same-spend-concurrent-16"; });
    require(race != races.end(), "same-spend race summary");
    const std::size_t precommit_rollbacks = static_cast<std::size_t>(std::count_if(
        crashes.begin(), crashes.end(), [](const CrashRow& row) {
            return row.recovered_state == "base";
        }));
    const std::size_t postcommit_exact = static_cast<std::size_t>(std::count_if(
        crashes.begin(), crashes.end(), [](const CrashRow& row) {
            return row.recovered_state == "target";
        }));
    std::ofstream out(output / "join-summary.json", std::ios::binary);
    require(out.good(), "open join-summary.json");
    out << "{\n"
        << "  \"admission_response_authorities\": 0,\n"
        << "  \"cases\": " << cases << ",\n"
        << "  \"crash_cuts\": " << crashes.size() << ",\n"
        << "  \"detached_response_copies\": 2,\n"
        << "  \"joined_split_gap_states\": 0,\n"
        << "  \"local_rollback_clone_admissions\": 2,\n"
        << "  \"postcommit_exact_reopens\": " << postcommit_exact << ",\n"
        << "  \"precommit_rollbacks\": " << precommit_rollbacks << ",\n"
        << "  \"same_spend_admitted\": " << race->admitted << ",\n"
        << "  \"same_spend_already_current\": "
        << race->already_current << ",\n"
        << "  \"same_spend_contenders\": " << race->contenders << ",\n"
        << "  \"scm_rights_installed_references\": "
        << probe.installed_descriptor_references << ",\n"
        << "  \"schema\": \"slopos.rev0894.local-joined-admission-summary.v1\",\n"
        << "  \"status\": \"PASS\"\n"
        << "}\n";
}

}  // namespace

void run_local_join_campaign(const std::filesystem::path& output) {
    const std::filesystem::path work = output / "_join_work";
    require(!std::filesystem::exists(work), "join work path absent");
    std::filesystem::create_directories(work);

    const Digest floor_identity = patterned(217U);
    const FloorPoint base{41U, patterned(17U)};
    const EncodedSpendRecord bytes_a = encoded(make_record(1U, base, 161U));
    const EncodedSpendRecord bytes_b = encoded(make_record(2U, base, 162U));
    const CompareAppendRequest request_a = make_request(
        floor_identity, base, bytes_a);
    const CompareAppendRequest request_b = make_request(
        floor_identity, base, bytes_b);

    std::vector<JoinCaseRow> cases;
    const auto add_case = [&](const std::string& name,
                              const HostedJoinResult& result,
                              const std::string& detail) {
        cases.push_back(JoinCaseRow{
            name, result.status, result.endpoint_entry_created,
            result.endpoint_bindings_exact, result.query_only, result.spent,
            result.response_authority, result.fail_stop,
            result.endpoint_entries, detail,
        });
    };

    const std::filesystem::path basic = work / "basic.sqlite";
    require(initialize_hosted_join(basic, floor_identity, base),
            "initialize basic hosted join");
    const HostedJoinResult admitted = compare_append_and_admit_hosted(
        basic, request_a);
    require(admitted.status == HostedJoinStatus::admitted
            && admitted.endpoint_entry_created
            && admitted.endpoint_bindings_exact
            && admitted.query_only && admitted.spent
            && !admitted.response_authority && !admitted.fail_stop
            && admitted.endpoint_entries == 1U,
            "fresh joined admission");
    add_case("fresh-exact", admitted,
             "one local transaction commits floor successor and fixed entry");

    const HostedJoinResult duplicate = compare_append_and_admit_hosted(
        basic, request_a);
    require(duplicate.status == HostedJoinStatus::already_current
            && !duplicate.endpoint_entry_created
            && duplicate.endpoint_bindings_exact
            && duplicate.query_only && duplicate.spent
            && !duplicate.response_authority && !duplicate.fail_stop
            && duplicate.endpoint_entries == 1U,
            "duplicate joined admission query-only");
    add_case("duplicate-exact", duplicate,
             "exact duplicate observes one existing entry and mints nothing");

    const HostedJoinResult foreign = compare_append_and_admit_hosted(
        basic, request_b);
    require(foreign.status == HostedJoinStatus::conflict
            && foreign.fail_stop && !foreign.spent
            && !foreign.response_authority,
            "foreign joined admission conflict");
    add_case("foreign-after-A", foreign,
             "alternate record at the successor conflicts and fails closed");

    CompareAppendRequest wrong_identity = request_a;
    wrong_identity.floor_identity = patterned(216U);
    const HostedJoinResult identity = compare_append_and_admit_hosted(
        basic, wrong_identity);
    require(identity.status == HostedJoinStatus::identity_mismatch
            && identity.fail_stop && !identity.response_authority,
            "join identity mismatch");
    add_case("identity-mismatch", identity,
             "provider identity mismatch grants no local entry");

    CompareAppendRequest malformed = request_a;
    malformed.target.head = patterned(44U);
    const HostedJoinResult malformed_result = compare_append_and_admit_hosted(
        basic, malformed);
    require(malformed_result.status == HostedJoinStatus::malformed
            && malformed_result.fail_stop
            && !malformed_result.response_authority,
            "malformed joined request");
    add_case("malformed-request", malformed_result,
             "record and target disagreement is rejected before opening the cell");

    const HostedJoinResult unavailable = compare_append_and_admit_hosted(
        work / "absent.sqlite", request_a);
    require(unavailable.status == HostedJoinStatus::unavailable
            && unavailable.fail_stop && !unavailable.response_authority,
            "unavailable joined provider");
    add_case("provider-unavailable", unavailable,
             "unavailable hosted cell grants no fallback");

    const HostedJoinObservation basic_observation = observe_hosted_join(
        basic, floor_identity, HostedJoinOpenMode::read_only);
    require(exact_target_observation(
                basic_observation, floor_identity, request_a),
            "basic independent read-only observation");
    write_response_replay(output, admitted, basic_observation);

    std::vector<RaceRow> races;
    const std::filesystem::path concurrent = work / "concurrent.sqlite";
    require(initialize_hosted_join(concurrent, floor_identity, base),
            "initialize concurrent hosted join");
    constexpr std::size_t kContenders = 16U;
    std::vector<HostedJoinResult> results(kContenders);
    std::barrier gate(static_cast<std::ptrdiff_t>(kContenders));
    std::vector<std::thread> threads;
    threads.reserve(kContenders);
    for (std::size_t index = 0U; index < kContenders; ++index) {
        threads.emplace_back([&, index]() {
            gate.arrive_and_wait();
            results[index] = compare_append_and_admit_hosted(
                concurrent, request_a);
        });
    }
    for (std::thread& thread : threads) thread.join();
    const auto count_status = [&](const HostedJoinStatus status) {
        return static_cast<std::size_t>(std::count_if(
            results.begin(), results.end(), [&](const HostedJoinResult& result) {
                return result.status == status;
            }));
    };
    const HostedJoinObservation concurrent_observation = observe_hosted_join(
        concurrent, floor_identity, HostedJoinOpenMode::read_only);
    const RaceRow same_race{
        "same-spend-concurrent-16", kContenders,
        count_status(HostedJoinStatus::admitted),
        count_status(HostedJoinStatus::already_current),
        count_status(HostedJoinStatus::conflict),
        count_status(HostedJoinStatus::unavailable),
        concurrent_observation.endpoint_entries,
        exact_target_observation(concurrent_observation, floor_identity, request_a),
    };
    require(same_race.admitted == 1U && same_race.already_current == 15U
            && same_race.conflicts == 0U && same_race.unavailable == 0U
            && same_race.final_entries == 1U && same_race.exact_final_state,
            "same-spend concurrent joined race");
    races.push_back(same_race);

    const auto foreign_world = [&](const std::string& name,
                                   const CompareAppendRequest& first,
                                   const CompareAppendRequest& second,
                                   const CompareAppendRequest& winner) {
        const std::filesystem::path path = work / (name + ".sqlite");
        require(initialize_hosted_join(path, floor_identity, base),
                "initialize foreign race " + name);
        const HostedJoinResult first_result = compare_append_and_admit_hosted(
            path, first);
        const HostedJoinResult second_result = compare_append_and_admit_hosted(
            path, second);
        const HostedJoinObservation observation = observe_hosted_join(
            path, floor_identity, HostedJoinOpenMode::read_only);
        const RaceRow row{
            name, 2U,
            static_cast<std::size_t>(first_result.status
                == HostedJoinStatus::admitted)
                + static_cast<std::size_t>(second_result.status
                    == HostedJoinStatus::admitted),
            static_cast<std::size_t>(first_result.status
                == HostedJoinStatus::already_current)
                + static_cast<std::size_t>(second_result.status
                    == HostedJoinStatus::already_current),
            static_cast<std::size_t>(first_result.status
                == HostedJoinStatus::conflict)
                + static_cast<std::size_t>(second_result.status
                    == HostedJoinStatus::conflict),
            static_cast<std::size_t>(first_result.status
                == HostedJoinStatus::unavailable)
                + static_cast<std::size_t>(second_result.status
                    == HostedJoinStatus::unavailable),
            observation.endpoint_entries,
            exact_target_observation(observation, floor_identity, winner),
        };
        require(row.admitted == 1U && row.conflicts == 1U
                && row.final_entries == 1U && row.exact_final_state,
                "foreign joined race " + name);
        return row;
    };
    races.push_back(foreign_world(
        "foreign-A-first", request_a, request_b, request_a));
    races.push_back(foreign_world(
        "foreign-B-first", request_b, request_a, request_b));

    std::vector<CrashRow> crashes;
    constexpr std::array<HostedJoinFaultCut, 4U> cuts{{
        HostedJoinFaultCut::after_begin,
        HostedJoinFaultCut::after_floor_update,
        HostedJoinFaultCut::after_endpoint_insert,
        HostedJoinFaultCut::after_commit_before_reply,
    }};
    for (const HostedJoinFaultCut cut : cuts) {
        const std::filesystem::path path = work /
            (std::string("crash-") + std::string(hosted_join_fault_cut_name(cut))
             + ".sqlite");
        require(initialize_hosted_join(path, floor_identity, base),
                "initialize crash cut");
        const pid_t child = ::fork();
        require(child >= 0, "fork crash cut");
        if (child == 0) {
            (void)compare_append_and_admit_hosted(path, request_a, cut);
            std::_Exit(120);
        }
        int wait_status = 0;
        pid_t waited = -1;
        do {
            waited = ::waitpid(child, &wait_status, 0);
        } while (waited < 0 && errno == EINTR);
        require(waited == child && WIFEXITED(wait_status),
                "wait for crash cut");
        const int child_exit = WEXITSTATUS(wait_status);
        require(child_exit == 80 + static_cast<int>(cut),
                "expected crash-cut exit");
        const HostedJoinObservation recovered = observe_hosted_join(
            path, floor_identity, HostedJoinOpenMode::recovering_read_write);
        const bool committed = cut == HostedJoinFaultCut::after_commit_before_reply;
        if (committed) {
            require(exact_target_observation(recovered, floor_identity, request_a),
                    "postcommit crash recovers target");
        } else {
            require(exact_base_observation(recovered, floor_identity, base),
                    "precommit crash rolls back to base");
        }
        const HostedJoinResult retry = compare_append_and_admit_hosted(
            path, request_a);
        require(retry.status == (committed
                    ? HostedJoinStatus::already_current
                    : HostedJoinStatus::admitted)
                && !retry.response_authority,
                "crash retry classification");
        const HostedJoinObservation clean = observe_hosted_join(
            path, floor_identity, HostedJoinOpenMode::read_only);
        require(exact_target_observation(clean, floor_identity, request_a),
                "clean read-only reopen after crash reconciliation");
        crashes.push_back(CrashRow{
            cut, child_exit, committed ? "target" : "base",
            recovered.endpoint_entries, retry.status,
            retry.endpoint_entries, true,
        });
    }

    const std::filesystem::path primary = work / "rollback-primary.sqlite";
    const std::filesystem::path clone = work / "rollback-clone.sqlite";
    require(initialize_hosted_join(primary, floor_identity, base),
            "initialize rollback primary");
    require(backup_hosted_join_snapshot(primary, clone),
            "backup pre-spend hosted snapshot");
    const HostedJoinResult primary_admit = compare_append_and_admit_hosted(
        primary, request_a);
    const HostedJoinResult clone_admit = compare_append_and_admit_hosted(
        clone, request_a);
    const HostedJoinObservation primary_observation = observe_hosted_join(
        primary, floor_identity, HostedJoinOpenMode::read_only);
    const HostedJoinObservation clone_observation = observe_hosted_join(
        clone, floor_identity, HostedJoinOpenMode::read_only);
    require(primary_admit.status == HostedJoinStatus::admitted
            && clone_admit.status == HostedJoinStatus::admitted
            && exact_target_observation(
                primary_observation, floor_identity, request_a)
            && exact_target_observation(
                clone_observation, floor_identity, request_a),
            "coherent rollback clone remints hosted admission");
    write_rollback_clone(output, primary_admit, clone_admit,
                         primary_observation, clone_observation);

    const std::filesystem::path split = work / "unsafe-split.sqlite";
    require(initialize_hosted_join(split, floor_identity, base),
            "initialize unsafe split counterexample");
    require(commit_unsafe_split_floor_only(split, request_a),
            "commit unsafe split floor-only state");
    const HostedJoinObservation split_observation = observe_hosted_join(
        split, floor_identity, HostedJoinOpenMode::read_only);
    require(split_observation.status == HostedJoinReadStatus::malformed,
            "unsafe split gap independently fails closed");
    write_split_gap(output, split_observation);

    const LinuxProbe probe = run_linux_probe(work);
#if defined(__linux__)
    require(probe.supported && probe.peek_receives == 2U
            && probe.consume_receives == 1U
            && probe.installed_descriptor_references == 3U
            && probe.shared_offset_sequence == "ABC" && !probe.authority,
            "Linux SCM_RIGHTS MSG_PEEK counterprobe");
#endif

    write_cases(output, cases);
    write_races(output, races);
    write_crashes(output, crashes);
    write_linux_probe(output, probe);
    write_summary(output, cases.size(), races, crashes, probe);

    std::error_code remove_error;
    std::filesystem::remove_all(work, remove_error);
    require(!remove_error, "remove local join work directory");

    std::cout << "LOCAL_JOIN_CAMPAIGN=PASS cases=" << cases.size()
              << " concurrent_contenders=16 admitted=1 already_current=15"
              << " foreign_conflicts=2 crash_cuts=" << crashes.size()
              << " precommit_rollbacks=3 postcommit_exact=1"
              << " response_authorities=0 rollback_clone_admissions=2"
              << " scm_rights_refs=" << probe.installed_descriptor_references
              << " authority=false\n";
}

}  // namespace slopos::e0::generation_journal
