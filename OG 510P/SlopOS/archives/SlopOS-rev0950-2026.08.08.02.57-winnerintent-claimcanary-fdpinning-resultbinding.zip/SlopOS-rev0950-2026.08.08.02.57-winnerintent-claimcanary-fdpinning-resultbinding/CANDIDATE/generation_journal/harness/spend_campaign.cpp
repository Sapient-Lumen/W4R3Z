#include "slopos/e0/generation_journal/spend_floor.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"
#include "slopos/e0/generation_journal/spend_reference.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::generation_journal {
namespace {

template <std::size_t Size>
[[nodiscard]] std::string hex_value(
    const std::array<std::uint8_t, Size>& value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const std::uint8_t byte : value) {
        out << std::setw(2) << static_cast<unsigned int>(byte);
    }
    return out.str();
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] Digest patterned(const std::uint8_t base) noexcept {
    Digest result{};
    for (std::size_t index = 0U; index < result.size(); ++index) {
        result[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return result;
}

[[nodiscard]] SpendRecordV1 make_record(
    const std::uint64_t serial, const std::uint64_t generation_from,
    const Digest& predecessor, const std::uint8_t operation_base) noexcept {
    SpendRecordV1 record;
    record.owner_epoch = 3U;
    record.constructor_epoch = 11U;
    record.spend_serial = serial;
    record.generation_from = generation_from;
    record.generation_to = generation_from + 1U;
    record.owner_statement = patterned(1U);
    record.constructor_image = patterned(33U);
    record.provider_subject = patterned(65U);
    record.publication_receipt = patterned(97U);
    record.expectation_record = patterned(129U);
    record.operation = patterned(operation_base);
    record.pending_result = patterned(193U);
    record.predecessor_head = predecessor;
    return record;
}

[[nodiscard]] EncodedSpendRecord encoded(const SpendRecordV1& record) {
    EncodedSpendRecord output{};
    require(encode_spend_record(record, output), "encode spend record");
    SpendRecordV1 roundtrip;
    require(decode_spend_record(output, roundtrip) && roundtrip == record,
            "decode spend record");
    return output;
}

[[nodiscard]] EncodedSpendRecord broken(EncodedSpendRecord value) noexcept {
    value[0U] ^= 1U;
    return value;
}

struct SpendFixture final {
    std::string name;
    SpendRecordV1 record;
    EncodedSpendRecord bytes{};
    Digest head{};
};

struct SpendCase final {
    std::string name;
    LocalSpendObservation local;
    ProtectedFloorObservation floor;
    EncodedSpendRecord candidate{};
    Digest expected_floor_identity{};
    SpendDecision result{};
};

struct BoundaryRow final {
    std::string name;
    AppendStatus response_status{AppendStatus::malformed};
    AppendDecision result{};
    std::string detail;
};

struct RaceRow final {
    std::string race;
    std::size_t contender{0U};
    std::string candidate;
    AppendStatus status{AppendStatus::malformed};
    AppendDecision decision{};
};

class HostedFloor final {
public:
    HostedFloor(Digest identity, FloorPoint initial)
        : identity_(std::move(identity)), current_(std::move(initial)) {}

    [[nodiscard]] CompareAppendResponse submit(
        const CompareAppendRequest& request) noexcept {
        if (request.floor_identity != identity_) {
            return response(AppendStatus::identity_mismatch);
        }
        SpendRecordV1 decoded_record;
        const bool record_valid = decode_spend_record(request.record, decoded_record)
            && request.target.generation == request.expected.generation + 1U
            && decoded_record.generation_from == request.expected.generation
            && decoded_record.generation_to == request.target.generation
            && decoded_record.predecessor_head == request.expected.head
            && spend_record_head(request.record) == request.target.head;
        if (!record_valid) return response(AppendStatus::malformed);
        if (current_ == request.target && record_.has_value()
            && *record_ == request.record) {
            return response(AppendStatus::already_current);
        }
        if (current_ != request.expected) {
            return response(AppendStatus::conflict);
        }
        current_ = request.target;
        record_ = request.record;
        return response(AppendStatus::advanced);
    }

private:
    [[nodiscard]] CompareAppendResponse response(
        const AppendStatus status) const noexcept {
        return CompareAppendResponse{
            status, identity_, current_, true, record_,
        };
    }

    Digest identity_{};
    FloorPoint current_{};
    std::optional<EncodedSpendRecord> record_{};
};

[[nodiscard]] std::size_t mutation_campaign(
    const std::vector<SpendFixture>& fixtures) {
    std::size_t rejected = 0U;
    for (const SpendFixture& fixture : fixtures) {
        for (std::size_t byte = 0U; byte < fixture.bytes.size(); ++byte) {
            for (unsigned int bit = 0U; bit < 8U; ++bit) {
                EncodedSpendRecord mutant = fixture.bytes;
                mutant[byte] ^= static_cast<std::uint8_t>(1U << bit);
                SpendRecordV1 decoded_record;
                if (!decode_spend_record(mutant, decoded_record)) ++rejected;
            }
        }
    }
    return rejected;
}

[[nodiscard]] bool sha256_known_answer() {
    constexpr std::array<std::uint8_t, 3U> input{{'a', 'b', 'c'}};
    constexpr std::array<std::uint8_t, 32U> expected{{
        0xbaU, 0x78U, 0x16U, 0xbfU, 0x8fU, 0x01U, 0xcfU, 0xeaU,
        0x41U, 0x41U, 0x40U, 0xdeU, 0x5dU, 0xaeU, 0x22U, 0x23U,
        0xb0U, 0x03U, 0x61U, 0xa3U, 0x96U, 0x17U, 0x7aU, 0x9cU,
        0xb4U, 0x10U, 0xffU, 0x61U, 0xf2U, 0x00U, 0x15U, 0xadU,
    }};
    return sha256(input) == expected;
}

void write_records(const std::filesystem::path& output,
                   const std::vector<SpendFixture>& fixtures) {
    std::ofstream out(output / "spend-records.tsv", std::ios::binary);
    require(out.good(), "open spend-records.tsv");
    out << "fixture\towner_epoch\tconstructor_epoch\tspend_serial"
           "\tgeneration_from\tgeneration_to\thead_sha256\tbytes\trecord_hex\n";
    for (const SpendFixture& fixture : fixtures) {
        out << fixture.name << '\t' << fixture.record.owner_epoch << '\t'
            << fixture.record.constructor_epoch << '\t'
            << fixture.record.spend_serial << '\t'
            << fixture.record.generation_from << '\t'
            << fixture.record.generation_to << '\t'
            << hex_value(fixture.head) << '\t' << fixture.bytes.size() << '\t'
            << hex_value(fixture.bytes) << '\n';
    }
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<SpendCase>& cases) {
    std::ofstream out(output / "spend-cases.tsv", std::ios::binary);
    require(out.good(), "open spend-cases.tsv");
    out << "case\tlocal_generation\tlocal_head\tpending_present\tpending_hex"
           "\tfloor_status\tfloor_identity\tfloor_generation\tfloor_head"
           "\tfloor_content_bound\tfloor_record_hex\tcandidate_hex"
           "\texpected_floor_identity\trelation\tcompare_append_allowed"
           "\tquery_only\trollback_detected\tfail_stop\n";
    for (const SpendCase& row : cases) {
        out << row.name << '\t' << row.local.confirmed.generation << '\t'
            << hex_value(row.local.confirmed.head) << '\t'
            << bool_text(row.local.pending_present) << '\t'
            << (row.local.pending.has_value()
                    ? hex_value(*row.local.pending) : "-") << '\t'
            << floor_read_status_name(row.floor.status) << '\t'
            << hex_value(row.floor.floor_identity) << '\t'
            << row.floor.current.generation << '\t'
            << hex_value(row.floor.current.head) << '\t'
            << bool_text(row.floor.content_bound) << '\t'
            << (row.floor.current_record.has_value()
                    ? hex_value(*row.floor.current_record) : "-") << '\t'
            << hex_value(row.candidate) << '\t'
            << hex_value(row.expected_floor_identity) << '\t'
            << spend_relation_name(row.result.relation) << '\t'
            << bool_text(row.result.compare_append_allowed) << '\t'
            << bool_text(row.result.query_only) << '\t'
            << bool_text(row.result.rollback_detected) << '\t'
            << bool_text(row.result.fail_stop) << '\n';
    }
}

void write_boundary(const std::filesystem::path& output,
                    const std::vector<BoundaryRow>& rows) {
    std::ofstream out(output / "spend-boundary.tsv", std::ios::binary);
    require(out.good(), "open spend-boundary.tsv");
    out << "check\tresponse_status\tinvoke_once\tquery_only\tspent"
           "\tfail_stop\tdetail\n";
    for (const BoundaryRow& row : rows) {
        out << row.name << '\t' << append_status_name(row.response_status) << '\t'
            << bool_text(row.result.invoke_once) << '\t'
            << bool_text(row.result.query_only) << '\t'
            << bool_text(row.result.spent) << '\t'
            << bool_text(row.result.fail_stop) << '\t' << row.detail << '\n';
    }
}

void write_races(const std::filesystem::path& output,
                 const std::vector<RaceRow>& rows) {
    std::ofstream out(output / "spend-races.tsv", std::ios::binary);
    require(out.good(), "open spend-races.tsv");
    out << "race\tcontender\tcandidate\tappend_status\tinvoke_once"
           "\tquery_only\tspent\tfail_stop\n";
    for (const RaceRow& row : rows) {
        out << row.race << '\t' << row.contender << '\t' << row.candidate << '\t'
            << append_status_name(row.status) << '\t'
            << bool_text(row.decision.invoke_once) << '\t'
            << bool_text(row.decision.query_only) << '\t'
            << bool_text(row.decision.spent) << '\t'
            << bool_text(row.decision.fail_stop) << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output) {
    std::ofstream out(output / "spend-counterexamples.tsv", std::ios::binary);
    require(out.good(), "open spend-counterexamples.tsv");
    out << "counterexample\tworld_a\tworld_b\tshared_observation"
           "\tinvalid_inference\tcorrection\n";
    out << "scalar-floor-not-spend-identity\tspend-A-won\tspend-B-won"
           "\tgeneration=42\tgeneration identifies the winning spend"
           "\tbind the exact successor head and record\n";
    out << "blind-increment-not-compare-append\tA increments 41-to-42"
           "\tstale B increments 42-to-43\tboth calls report success"
           "\tsuccess proves one predecessor admitted at most one spend"
           "\tatomically compare expected generation and expected head\n";
    out << "blind-extend-not-compare-append\tA extends from head-H"
           "\tstale B extends after A\tboth extensions are in history"
           "\textend success grants a unique admission right from H"
           "\treject stale expected-head mismatches\n";
    out << "rollback-exact-head-is-query-only\tlocal image before spend"
           "\tlocal image after pending loss\texternal exact head is spend-A"
           "\tmissing local state permits fresh invocation"
           "\trecover the exact spend as query-only\n";
    out << "rollback-scalar-floor-is-ambiguous\tspend-A committed"
           "\tforeign spend committed\texternal generation=42"
           "\tlocal absence distinguishes the worlds"
           "\tfail stop until exact content is available\n";
    out << "floor-unavailable-no-fallback\tprotected floor unreachable"
           "\tprotected floor partitioned\tlocal state appears fresh"
           "\tlocal freshness grants dispatch"
           "\tunavailability grants no authority\n";
    out << "advanced-response-is-replayable\tone advanced response consumed"
           "\tthe same bytes replayed\tidentical response object"
           "\tresponse bytes are a nonduplicable invocation capability"
           "\tprotected provider must issue and consume the real gate\n";
}

void write_summary(const std::filesystem::path& output,
                   const std::vector<SpendCase>& cases,
                   const std::vector<BoundaryRow>& boundary,
                   const std::vector<RaceRow>& races,
                   const std::size_t mutation_count,
                   const std::size_t replayed_invoke_decisions) {
    const auto count_cases = [&](const auto& predicate) {
        return static_cast<std::size_t>(std::count_if(
            cases.begin(), cases.end(), predicate));
    };
    const auto count_races = [&](const auto& predicate) {
        return static_cast<std::size_t>(std::count_if(
            races.begin(), races.end(), predicate));
    };
    const std::size_t allowed = count_cases([](const SpendCase& row) {
        return row.result.compare_append_allowed;
    });
    const std::size_t query = count_cases([](const SpendCase& row) {
        return row.result.query_only;
    });
    const std::size_t stopped = count_cases([](const SpendCase& row) {
        return row.result.fail_stop;
    });
    const std::size_t same_advanced = count_races([](const RaceRow& row) {
        return row.race == "same-spend-16" && row.status == AppendStatus::advanced;
    });
    const std::size_t same_already = count_races([](const RaceRow& row) {
        return row.race == "same-spend-16"
            && row.status == AppendStatus::already_current;
    });
    const std::size_t same_invokes = count_races([](const RaceRow& row) {
        return row.race == "same-spend-16" && row.decision.invoke_once;
    });
    const std::size_t same_queries = count_races([](const RaceRow& row) {
        return row.race == "same-spend-16" && row.decision.query_only;
    });
    const std::size_t foreign_conflicts = count_races([](const RaceRow& row) {
        return row.race != "same-spend-16" && row.status == AppendStatus::conflict;
    });

    std::ofstream out(output / "spend-summary.json", std::ios::binary);
    require(out.good(), "open spend-summary.json");
    out << "{\n"
        << "  \"authority_granted\": false,\n"
        << "  \"boundary_checks\": " << boundary.size() << ",\n"
        << "  \"candidate_reference_disagreements\": 0,\n"
        << "  \"compare_append_allowed_cases\": " << allowed << ",\n"
        << "  \"counterexamples\": 7,\n"
        << "  \"fail_stop_cases\": " << stopped << ",\n"
        << "  \"foreign_race_conflicts\": " << foreign_conflicts << ",\n"
        << "  \"foreign_race_worlds\": 2,\n"
        << "  \"global_spend_proved\": false,\n"
        << "  \"physical_rollback_resistance_proved\": false,\n"
        << "  \"provider_authenticated\": false,\n"
        << "  \"query_only_cases\": " << query << ",\n"
        << "  \"record_bit_mutations\": " << mutation_count << ",\n"
        << "  \"record_bit_mutations_rejected\": " << mutation_count << ",\n"
        << "  \"record_bytes\": " << kSpendRecordBytes << ",\n"
        << "  \"record_fixtures\": 2,\n"
        << "  \"replayed_advanced_invoke_decisions\": "
        << replayed_invoke_decisions << ",\n"
        << "  \"same_spend_advanced\": " << same_advanced << ",\n"
        << "  \"same_spend_already_current\": " << same_already << ",\n"
        << "  \"same_spend_contenders\": 16,\n"
        << "  \"same_spend_invoke_once\": " << same_invokes << ",\n"
        << "  \"same_spend_query_only\": " << same_queries << ",\n"
        << "  \"schema\": \"slopos.rev0894.spend-floor-summary.v1\",\n"
        << "  \"sha256_known_answer\": true,\n"
        << "  \"spend_cases\": " << cases.size() << ",\n"
        << "  \"status\": \"PASS\"\n"
        << "}\n";
}

}  // namespace

void run_spend_campaign(const std::filesystem::path& output) {
    require(sha256_known_answer(), "SHA-256 known-answer test");

    const Digest predecessor = patterned(17U);
    const Digest floor_identity = patterned(209U);
    const SpendFixture spend_a{
        "spend-A", make_record(7U, 41U, predecessor, 161U), {}, {},
    };
    const SpendFixture spend_b{
        "spend-B", make_record(8U, 41U, predecessor, 162U), {}, {},
    };
    std::vector<SpendFixture> fixtures{spend_a, spend_b};
    for (SpendFixture& fixture : fixtures) {
        fixture.bytes = encoded(fixture.record);
        fixture.head = spend_record_head(fixture.bytes);
    }
    const EncodedSpendRecord bytes_a = fixtures[0U].bytes;
    const EncodedSpendRecord bytes_b = fixtures[1U].bytes;
    const FloorPoint base{41U, predecessor};
    const FloorPoint point_a{42U, fixtures[0U].head};
    const FloorPoint point_b{42U, fixtures[1U].head};

    const SpendRecordV1 next_record = make_record(9U, 42U, point_a.head, 163U);
    const EncodedSpendRecord next_bytes = encoded(next_record);
    SpendRecordV1 wrong_predecessor_record = fixtures[0U].record;
    wrong_predecessor_record.predecessor_head = patterned(18U);
    const EncodedSpendRecord wrong_predecessor = encoded(wrong_predecessor_record);
    const EncodedSpendRecord malformed = broken(bytes_a);

    const LocalSpendObservation local_fresh{base, false, std::nullopt};
    const LocalSpendObservation local_prepared{base, true, bytes_a};
    const ProtectedFloorObservation floor_base{
        FloorReadStatus::available, floor_identity, base, true, std::nullopt};

    std::vector<SpendCase> cases;
    const auto add_case = [&](const std::string& name,
                              const LocalSpendObservation& local,
                              const ProtectedFloorObservation& floor,
                              const EncodedSpendRecord& candidate,
                              const Digest& expected_identity,
                              const SpendDecision& expected) {
        const SpendDecision candidate_result = evaluate_spend(
            local, floor, candidate, expected_identity);
        const SpendDecision reference_result = spend_reference::evaluate_spend(
            local, floor, candidate, expected_identity);
        require(candidate_result == reference_result,
                "spend candidate/reference disagreement " + name);
        require(candidate_result == expected, "unexpected spend decision " + name);
        const auto request = make_compare_append_request(
            local, floor, candidate, expected_identity);
        const auto reference_request = spend_reference::make_compare_append_request(
            local, floor, candidate, expected_identity);
        require(request == reference_request,
                "spend request candidate/reference disagreement " + name);
        require(request.has_value() == expected.compare_append_allowed,
                "spend request authority mismatch " + name);
        cases.push_back(SpendCase{
            name, local, floor, candidate, expected_identity, candidate_result,
        });
    };

    add_case("fresh-exact", local_fresh, floor_base, bytes_a, floor_identity,
             SpendDecision{SpendRelation::fresh, true, false, false, false});
    add_case("prepared-exact", local_prepared, floor_base, bytes_a, floor_identity,
             SpendDecision{SpendRelation::prepared_exact, true, false, false, false});
    add_case("pending-foreign", LocalSpendObservation{base, true, bytes_b},
             floor_base, bytes_a, floor_identity,
             SpendDecision{SpendRelation::foreign_spend, false, false, false, true});
    add_case("pending-malformed", LocalSpendObservation{base, true, malformed},
             floor_base, bytes_a, floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});
    add_case("pending-flag-mismatch", LocalSpendObservation{base, true, std::nullopt},
             floor_base, bytes_a, floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});
    add_case("floor-same-generation-wrong-head", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       FloorPoint{41U, patterned(19U)}, true,
                                       std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::foreign_spend, false, false, false, true});
    add_case("same-spend-committed", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       point_a, true, bytes_a},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::same_spend_committed,
                           false, true, true, false});
    add_case("same-spend-head-only", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       point_a, true, std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::same_spend_committed,
                           false, true, true, false});
    add_case("foreign-spend-committed", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       point_b, true, bytes_b},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::foreign_spend, false, false, true, true});
    add_case("scalar-base", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       FloorPoint{41U, Digest{}}, false,
                                       std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::scalar_ambiguous,
                           false, false, false, true});
    add_case("scalar-ahead", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       FloorPoint{42U, Digest{}}, false,
                                       std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::scalar_ambiguous,
                           false, false, true, true});
    add_case("floor-unavailable", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::unavailable, Digest{},
                                       FloorPoint{}, false, std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::floor_unavailable,
                           false, false, false, true});
    add_case("floor-malformed-status", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::malformed, floor_identity,
                                       base, true, std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});
    add_case("floor-identity-mismatch", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, patterned(208U),
                                       base, true, std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::identity_mismatch,
                           false, false, false, true});
    add_case("local-ahead", LocalSpendObservation{point_a, false, std::nullopt},
             floor_base, next_bytes, floor_identity,
             SpendDecision{SpendRelation::local_ahead, false, false, false, true});
    add_case("generation-jump", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       FloorPoint{43U, patterned(20U)}, true,
                                       std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::generation_jump,
                           false, false, true, true});
    add_case("candidate-wrong-predecessor", local_fresh, floor_base,
             wrong_predecessor, floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});
    add_case("candidate-malformed", local_fresh, floor_base, malformed,
             floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});
    add_case("floor-record-mismatch", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       point_a, true, bytes_b},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});
    add_case("unbound-floor-carries-head", local_fresh,
             ProtectedFloorObservation{FloorReadStatus::available, floor_identity,
                                       base, false, std::nullopt},
             bytes_a, floor_identity,
             SpendDecision{SpendRelation::malformed, false, false, false, true});

    require(cases.size() == 20U, "spend case inventory");

    const auto request_a = make_compare_append_request(
        local_fresh, floor_base, bytes_a, floor_identity);
    const auto request_b = make_compare_append_request(
        local_fresh, floor_base, bytes_b, floor_identity);
    require(request_a.has_value() && request_b.has_value(), "fresh requests");

    std::vector<BoundaryRow> boundary;
    const auto add_boundary = [&](const std::string& name,
                                  const CompareAppendRequest& request,
                                  const CompareAppendResponse& response,
                                  const AppendDecision& expected,
                                  const std::string& detail) {
        const AppendDecision candidate_result = accept_compare_append_response(
            request, response);
        const AppendDecision reference_result =
            spend_reference::accept_compare_append_response(request, response);
        require(candidate_result == reference_result,
                "append candidate/reference disagreement " + name);
        require(candidate_result == expected, "unexpected append decision " + name);
        boundary.push_back(BoundaryRow{
            name, response.status, candidate_result, detail,
        });
    };

    const CompareAppendResponse advanced_exact{
        AppendStatus::advanced, floor_identity, point_a, true, bytes_a};
    const CompareAppendResponse already_exact{
        AppendStatus::already_current, floor_identity, point_a, true, bytes_a};
    add_boundary("advanced-exact", *request_a, advanced_exact,
                 AppendDecision{false, true, true, false},
                 "detached exact advanced bytes are spent observation only");
    add_boundary("already-current-exact", *request_a, already_exact,
                 AppendDecision{false, true, true, false},
                 "duplicate same-spend contender is query-only");
    add_boundary("advanced-missing-record", *request_a,
                 CompareAppendResponse{AppendStatus::advanced, floor_identity,
                                       point_a, true, std::nullopt},
                 AppendDecision{}, "head without returned exact record is insufficient");
    add_boundary("advanced-unbound", *request_a,
                 CompareAppendResponse{AppendStatus::advanced, floor_identity,
                                       FloorPoint{42U, Digest{}}, false,
                                       std::nullopt},
                 AppendDecision{}, "scalar success grants no invocation");
    add_boundary("advanced-foreign", *request_a,
                 CompareAppendResponse{AppendStatus::advanced, floor_identity,
                                       point_b, true, bytes_b},
                 AppendDecision{}, "alternate spend cannot satisfy exact request");
    add_boundary("advanced-identity-mismatch", *request_a,
                 CompareAppendResponse{AppendStatus::advanced, patterned(208U),
                                       point_a, true, bytes_a},
                 AppendDecision{}, "provider identity is part of the response");
    add_boundary("conflict", *request_a,
                 CompareAppendResponse{AppendStatus::conflict, floor_identity,
                                       point_b, true, bytes_b},
                 AppendDecision{}, "conflict is fail-stop, not retry");
    add_boundary("unavailable", *request_a,
                 CompareAppendResponse{AppendStatus::unavailable, floor_identity,
                                       base, true, std::nullopt},
                 AppendDecision{}, "unavailable floor grants no fallback");
    add_boundary("malformed", *request_a,
                 CompareAppendResponse{AppendStatus::malformed, floor_identity,
                                       base, true, std::nullopt},
                 AppendDecision{}, "malformed response grants no right");
    add_boundary("identity-mismatch-status", *request_a,
                 CompareAppendResponse{AppendStatus::identity_mismatch,
                                       patterned(208U), base, true, std::nullopt},
                 AppendDecision{}, "explicit identity mismatch fails closed");
    CompareAppendRequest bad_request = *request_a;
    bad_request.expected.head = patterned(21U);
    add_boundary("malformed-request", bad_request, advanced_exact,
                 AppendDecision{}, "response cannot repair a malformed request");

    const AppendDecision replay_one = accept_compare_append_response(
        *request_a, advanced_exact);
    const AppendDecision replay_two = accept_compare_append_response(
        *request_a, advanced_exact);
    const std::size_t replayed_invokes = static_cast<std::size_t>(
        replay_one.invoke_once) + static_cast<std::size_t>(replay_two.invoke_once);
    require(replayed_invokes == 0U,
            "detached advanced response replay must mint no invoke decision");

    std::vector<RaceRow> races;
    HostedFloor same_floor(floor_identity, base);
    for (std::size_t contender = 1U; contender <= 16U; ++contender) {
        const CompareAppendResponse response = same_floor.submit(*request_a);
        const AppendDecision accepted = accept_compare_append_response(
            *request_a, response);
        races.push_back(RaceRow{
            "same-spend-16", contender, "spend-A", response.status, accepted,
        });
    }

    const auto run_foreign_world = [&](const std::string& name,
                                       const CompareAppendRequest& first,
                                       const std::string& first_name,
                                       const CompareAppendRequest& second,
                                       const std::string& second_name) {
        HostedFloor floor(floor_identity, base);
        const CompareAppendResponse first_response = floor.submit(first);
        const CompareAppendResponse second_response = floor.submit(second);
        races.push_back(RaceRow{
            name, 1U, first_name, first_response.status,
            accept_compare_append_response(first, first_response),
        });
        races.push_back(RaceRow{
            name, 2U, second_name, second_response.status,
            accept_compare_append_response(second, second_response),
        });
    };
    run_foreign_world("foreign-A-first", *request_a, "spend-A",
                      *request_b, "spend-B");
    run_foreign_world("foreign-B-first", *request_b, "spend-B",
                      *request_a, "spend-A");

    require(std::count_if(races.begin(), races.end(), [](const RaceRow& row) {
        return row.race == "same-spend-16" && row.status == AppendStatus::advanced;
    }) == 1, "same-spend exactly one advanced");
    require(std::count_if(races.begin(), races.end(), [](const RaceRow& row) {
        return row.race == "same-spend-16" && row.decision.invoke_once;
    }) == 0, "same-spend detached responses mint no invoke decisions");
    require(std::count_if(races.begin(), races.end(), [](const RaceRow& row) {
        return row.race == "same-spend-16" && row.decision.query_only;
    }) == 16, "same-spend detached responses are observation-only");
    require(std::count_if(races.begin(), races.end(), [](const RaceRow& row) {
        return row.race != "same-spend-16" && row.status == AppendStatus::conflict;
    }) == 2, "foreign races exactly one conflict each");

    const std::size_t expected_mutations = fixtures.size()
        * kSpendRecordBytes * 8U;
    const std::size_t rejected_mutations = mutation_campaign(fixtures);
    require(rejected_mutations == expected_mutations,
            "all one-bit spend-record mutations rejected");

    write_records(output, fixtures);
    write_cases(output, cases);
    write_boundary(output, boundary);
    write_races(output, races);
    write_counterexamples(output);
    write_summary(output, cases, boundary, races,
                  rejected_mutations, replayed_invokes);

    std::cout << "SPEND_FLOOR_CAMPAIGN=PASS cases=" << cases.size()
              << " record_mutations=" << rejected_mutations
              << " same_spend_contenders=16 same_spend_advanced=1"
              << " same_spend_query_only=16 foreign_conflicts=2"
              << " replayed_advanced_invokes=0 authority=false\n";
}

}  // namespace slopos::e0::generation_journal
