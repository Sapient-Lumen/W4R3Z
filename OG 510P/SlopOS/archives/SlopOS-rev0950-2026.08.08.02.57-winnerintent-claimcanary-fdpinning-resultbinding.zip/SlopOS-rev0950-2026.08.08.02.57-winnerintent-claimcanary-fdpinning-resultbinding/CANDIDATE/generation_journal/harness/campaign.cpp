#include "slopos/e0/generation_journal/boundary.hpp"
#include "slopos/e0/generation_journal/machine.hpp"
#include "slopos/e0/generation_journal/record.hpp"
#include "slopos/e0/generation_journal/reference.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::generation_journal {

void run_spend_campaign(const std::filesystem::path& output);
void run_local_join_campaign(const std::filesystem::path& output);

namespace {

struct Edge final {
    std::size_t state_id{};
    std::size_t depth{};
    Event event{};
    Step step{};
    std::size_t next_state_id{};
};

struct RecordFixture final {
    std::string name;
    Record record;
    EncodedRecord encoded{};
};

struct BoundaryCheck final {
    std::string name;
    bool pass{false};
    std::string detail;
};

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] std::string hex_record(const EncodedRecord& record) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const std::uint8_t byte : record) {
        out << std::setw(2) << static_cast<unsigned int>(byte);
    }
    return out.str();
}

[[nodiscard]] std::array<std::uint8_t, 32U> binding(
    const std::uint8_t base) noexcept {
    std::array<std::uint8_t, 32U> value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] std::vector<RecordFixture> record_fixtures() {
    const auto operation = binding(1U);
    const auto spent = binding(161U);
    const auto make = [&](const std::string& name, const RecordKind kind,
                          const std::uint64_t sequence, const Result result,
                          const bool reconciled) {
        RecordFixture fixture;
        fixture.name = name;
        fixture.record.kind = kind;
        fixture.record.sequence = sequence;
        fixture.record.generation_from = 41U;
        fixture.record.generation_to = 42U;
        fixture.record.operation_binding = operation;
        fixture.record.spent_receipt_binding = spent;
        fixture.record.result = result;
        fixture.record.consumed_dispatch = true;
        fixture.record.reconciled = reconciled;
        require(encode_record(fixture.record, fixture.encoded),
                "encode record fixture " + name);
        Record decoded;
        require(decode_record(fixture.encoded, decoded)
                && decoded == fixture.record,
                "decode record fixture " + name);
        return fixture;
    };
    return {
        make("pending-v1", RecordKind::pending, 1U, Result::none, false),
        make("result-effect-v1", RecordKind::result, 1U, Result::effect, false),
        make("result-uncertain-v1", RecordKind::result, 1U, Result::uncertain, false),
        make("publication-uncertain-v1", RecordKind::publication, 1U,
             Result::uncertain, false),
        make("result-effect-v2", RecordKind::result, 2U, Result::effect, true),
        make("publication-effect-v2", RecordKind::publication, 2U,
             Result::effect, true),
    };
}

[[nodiscard]] std::size_t mutation_campaign(
    const std::vector<RecordFixture>& fixtures) {
    std::size_t rejected = 0U;
    for (const RecordFixture& fixture : fixtures) {
        for (std::size_t byte = 0U; byte < fixture.encoded.size(); ++byte) {
            for (unsigned int bit = 0U; bit < 8U; ++bit) {
                EncodedRecord mutant = fixture.encoded;
                mutant[byte] ^= static_cast<std::uint8_t>(1U << bit);
                Record decoded;
                if (!decode_record(mutant, decoded)) ++rejected;
            }
        }
    }
    return rejected;
}

[[nodiscard]] std::vector<BoundaryCheck> boundary_campaign() {
    std::vector<BoundaryCheck> rows;
    const auto add = [&](const std::string& name, const bool pass,
                         const std::string& detail) {
        rows.push_back(BoundaryCheck{name, pass, detail});
        require(pass, "boundary check " + name);
    };

    ExactOperation exact;
    exact.generation_from = 41U;
    exact.generation_to = 42U;
    exact.operation_binding = binding(1U);
    exact.spent_receipt_binding = binding(161U);

    auto receipt = HostedGateFixture::consumed(exact);
    add("hosted-receipt-begins-live", receipt.live(),
        "hosted fixture is explicit proof shape only");
    auto plan = EndpointBoundary::plan(std::move(receipt));
    add("planning-consumes-receipt", !receipt.live(),
        "spent receipt cannot be reused in this process");
    add("planning-is-inert-and-produces-pending", plan.has_value()
        && plan->live(), "no invocation ticket is returned by planning");

    EncodedRecord wrong = plan->intended_record();
    wrong[0U] ^= 1U;
    auto wrong_ticket = EndpointBoundary::activate_after_readback(
        std::move(*plan), wrong);
    add("wrong-readback-creates-no-ticket", !wrong_ticket.has_value(),
        "mismatch fails closed");
    add("wrong-readback-consumes-plan", !plan->live(),
        "activation attempt is one-shot");
    auto retry_ticket = EndpointBoundary::activate_after_readback(
        std::move(*plan), plan->intended_record());
    add("consumed-plan-cannot-retry", !retry_ticket.has_value(),
        "mismatch cannot be followed by exact retry");

    auto receipt2 = HostedGateFixture::consumed(exact);
    auto plan2 = EndpointBoundary::plan(std::move(receipt2));
    require(plan2.has_value(), "fresh plan");
    const EncodedRecord exact_readback = plan2->intended_record();
    auto exact_ticket = EndpointBoundary::activate_after_readback(
        std::move(*plan2), exact_readback);
    add("exact-readback-creates-one-ticket", exact_ticket.has_value()
        && exact_ticket->live(), "ticket follows exact complete readback");
    add("exact-readback-consumes-plan", !plan2->live(),
        "successful activation is one-shot");
    InvocationTicket moved_ticket(std::move(*exact_ticket));
    add("ticket-move-consumes-source", !exact_ticket->live()
        && moved_ticket.live(), "move-only proof shape");

    auto query = EndpointBoundary::recover_query_only(exact);
    add("recovery-creates-query-binding", query.has_value() && query->live(),
        "recovery output is not an invocation ticket");
    QueryOnlyBinding moved_query(std::move(*query));
    add("query-binding-is-move-only", !query->live() && moved_query.live(),
        "one exact query use can be isolated by the future provider");

    ExactOperation invalid{};
    add("invalid-protected-observation-rejected",
        !EndpointBoundary::recover_query_only(invalid).has_value(),
        "zero or discontinuous identity cannot bind recovery");

    ExactOperation wrapped = exact;
    wrapped.generation_from = std::numeric_limits<std::uint64_t>::max();
    wrapped.generation_to = 0U;
    add("wrapped-generation-observation-rejected",
        !EndpointBoundary::recover_query_only(wrapped).has_value(),
        "UINT64_MAX to zero is not a successor generation");

    Record forged;
    forged.kind = RecordKind::result;
    forged.sequence = 1U;
    forged.generation_from = exact.generation_from;
    forged.generation_to = exact.generation_to;
    forged.operation_binding = binding(2U);
    forged.spent_receipt_binding = exact.spent_receipt_binding;
    forged.result = Result::effect;
    forged.consumed_dispatch = true;
    forged.reconciled = false;
    EncodedRecord forged_bytes{};
    Record forged_roundtrip;
    add("recomputed-crc-does-not-authenticate",
        encode_record(forged, forged_bytes)
            && decode_record(forged_bytes, forged_roundtrip)
            && forged_roundtrip == forged
            && forged.operation_binding != exact.operation_binding,
        "a deliberate alternate valid record with a recomputed CRC decodes");

    add("endpoint-is-constant",
        EndpointBoundary::fixed_endpoint_id() == kFixedEndpointId,
        "no route is supplied by caller");
    return rows;
}

void write_states(const std::filesystem::path& output,
                  const std::vector<State>& states,
                  const std::vector<std::size_t>& depths) {
    std::ofstream out(output / "states.tsv", std::ios::binary);
    require(out.good(), "open states.tsv");
    out << "state_id\tdepth\tphase\tendpoint\tresult\tresult_version"
           "\tpublished_version\tinvocation_count\teffect_count"
           "\treceipt_bound\tpending_exact\trecovered\treconciled\tstate_key\n";
    for (std::size_t index = 0U; index < states.size(); ++index) {
        const State& state = states[index];
        out << index << '\t' << depths[index] << '\t'
            << phase_name(state.phase) << '\t'
            << endpoint_name(state.endpoint) << '\t'
            << result_name(state.result) << '\t'
            << static_cast<unsigned int>(state.result_version) << '\t'
            << static_cast<unsigned int>(state.published_version) << '\t'
            << static_cast<unsigned int>(state.invocation_count) << '\t'
            << static_cast<unsigned int>(state.effect_count) << '\t'
            << bool_text(state.receipt_bound) << '\t'
            << bool_text(state.pending_exact) << '\t'
            << bool_text(state.recovered) << '\t'
            << bool_text(state.reconciled) << '\t'
            << state_key(state) << '\n';
    }
}

void write_edges(const std::filesystem::path& output,
                 const std::vector<Edge>& edges,
                 const std::vector<State>& states) {
    std::ofstream out(output / "relation.tsv", std::ios::binary);
    require(out.good(), "open relation.tsv");
    out << "state_id\tdepth\tevent\toutcome\tnext_state_id"
           "\tendpoint_apply_called\tresult_refined\tpublication_appended"
           "\tdispatch_minted\tbefore_key\tafter_key\n";
    for (const Edge& edge : edges) {
        out << edge.state_id << '\t' << edge.depth << '\t'
            << event_name(edge.event) << '\t'
            << outcome_name(edge.step.outcome) << '\t'
            << edge.next_state_id << '\t'
            << bool_text(edge.step.endpoint_apply_called) << '\t'
            << bool_text(edge.step.result_refined) << '\t'
            << bool_text(edge.step.publication_appended) << '\t'
            << bool_text(edge.step.dispatch_minted) << '\t'
            << state_key(states[edge.state_id]) << '\t'
            << state_key(edge.step.state) << '\n';
    }
}

[[nodiscard]] const Edge& find_edge(
    const std::vector<Edge>& edges, const std::vector<State>& states,
    const Event event, const auto& predicate) {
    const auto found = std::find_if(edges.begin(), edges.end(),
        [&](const Edge& edge) {
            return edge.event == event && predicate(states[edge.state_id]);
        });
    if (found == edges.end()) {
        throw std::runtime_error("missing witness "
                                 + std::string(event_name(event)));
    }
    return *found;
}

void write_witnesses(const std::filesystem::path& output,
                     const std::vector<Edge>& edges,
                     const std::vector<State>& states) {
    struct Witness final { std::string name; const Edge* edge; };
    std::vector<Witness> rows;
    const auto add = [&](const std::string& name, const Event event,
                         const auto& predicate) {
        rows.push_back(Witness{name, &find_edge(edges, states, event, predicate)});
    };

    add("recovery_apply_is_rejected", Event::recovery_apply_attempt,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.recovered && s.pending_exact; });
    add("dispatch_mint_is_rejected", Event::mint_dispatch_attempt,
        [](const State& s) { return s.phase == Phase::uncertain; });
    add("route_override_is_rejected", Event::route_override_attempt,
        [](const State& s) { return s.phase == Phase::ready; });
    add("retry_apply_is_rejected", Event::retry_apply_attempt,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.pending_exact; });
    add("published_uncertainty_refines_to_effect_v2",
        Event::query_successor_same,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.endpoint == Endpoint::successor_same
            && s.result == Result::uncertain && s.result_version == 1U
            && s.published_version == 1U && s.pending_exact; });
    add("refined_effect_publication_appends_v2", Event::publish,
        [](const State& s) { return s.phase == Phase::terminal
            && s.result == Result::effect && s.result_version == 2U
            && s.published_version == 1U; });
    add("query_predecessor_refines_no_effect",
        Event::query_predecessor,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.endpoint == Endpoint::predecessor && s.pending_exact; });
    add("query_other_successor_fail_stops",
        Event::query_successor_other,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.endpoint == Endpoint::successor_other && s.pending_exact; });
    add("missing_spent_receipt_preserves_uncertainty",
        Event::recover_spent_receipt_missing,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.recovered && !s.pending_exact; });
    add("exact_spent_receipt_enables_query_only",
        Event::recover_spent_receipt_exact,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.recovered && !s.pending_exact; });
    add("malformed_after_effect_is_uncertain",
        Event::invoke_malformed_after_effect,
        [](const State& s) { return s.phase == Phase::ready
            && s.endpoint == Endpoint::predecessor; });
    add("other_successor_before_invoke_fail_stops",
        Event::invoke_effect_return,
        [](const State& s) { return s.phase == Phase::ready
            && s.endpoint == Endpoint::successor_other; });
    add("query_unavailable_preserves_uncertainty",
        Event::query_unavailable,
        [](const State& s) { return s.phase == Phase::uncertain
            && s.pending_exact; });
    add("stale_publication_is_rejected",
        Event::stale_publication_attempt,
        [](const State& s) { return s.result != Result::none
            && s.published_version == s.result_version; });

    std::ofstream out(output / "witnesses.tsv", std::ios::binary);
    require(out.good(), "open witnesses.tsv");
    out << "name\tstate_id\tevent\toutcome\tnext_state_id"
           "\tbefore_result\tbefore_version\tbefore_published"
           "\tafter_result\tafter_version\tafter_published"
           "\tendpoint_apply_called\tresult_refined\tpublication_appended"
           "\tdispatch_minted\n";
    for (const Witness& witness : rows) {
        const Edge& edge = *witness.edge;
        const State& before = states[edge.state_id];
        const State& after = edge.step.state;
        out << witness.name << '\t' << edge.state_id << '\t'
            << event_name(edge.event) << '\t'
            << outcome_name(edge.step.outcome) << '\t'
            << edge.next_state_id << '\t'
            << result_name(before.result) << '\t'
            << static_cast<unsigned int>(before.result_version) << '\t'
            << static_cast<unsigned int>(before.published_version) << '\t'
            << result_name(after.result) << '\t'
            << static_cast<unsigned int>(after.result_version) << '\t'
            << static_cast<unsigned int>(after.published_version) << '\t'
            << bool_text(edge.step.endpoint_apply_called) << '\t'
            << bool_text(edge.step.result_refined) << '\t'
            << bool_text(edge.step.publication_appended) << '\t'
            << bool_text(edge.step.dispatch_minted) << '\n';
    }
}

void write_records(const std::filesystem::path& output,
                   const std::vector<RecordFixture>& fixtures) {
    std::ofstream out(output / "records.tsv", std::ios::binary);
    require(out.good(), "open records.tsv");
    out << "fixture\tkind\tsequence\tgeneration_from\tgeneration_to"
           "\tresult\treconciled\tbytes\thex\n";
    const auto kind_name = [](const RecordKind kind) {
        switch (kind) {
        case RecordKind::pending: return "pending";
        case RecordKind::result: return "result";
        case RecordKind::publication: return "publication";
        }
        return "invalid";
    };
    for (const RecordFixture& fixture : fixtures) {
        out << fixture.name << '\t' << kind_name(fixture.record.kind) << '\t'
            << fixture.record.sequence << '\t'
            << fixture.record.generation_from << '\t'
            << fixture.record.generation_to << '\t'
            << result_name(fixture.record.result) << '\t'
            << bool_text(fixture.record.reconciled) << '\t'
            << fixture.encoded.size() << '\t'
            << hex_record(fixture.encoded) << '\n';
    }
}

void write_boundary(const std::filesystem::path& output,
                    const std::vector<BoundaryCheck>& rows) {
    std::ofstream out(output / "boundary.tsv", std::ios::binary);
    require(out.good(), "open boundary.tsv");
    out << "check\tstatus\tdetail\n";
    for (const BoundaryCheck& row : rows) {
        out << row.name << '\t' << (row.pass ? "PASS" : "FAIL")
            << '\t' << row.detail << '\n';
    }
}

void write_handoff(const std::filesystem::path& output) {
    std::ofstream out(output / "handoff-counterexample.tsv", std::ios::binary);
    require(out.good(), "open handoff-counterexample.tsv");
    out << "world\tlocal_journal\tprotected_spent_identity\tgate_consumed"
           "\tendpoint_may_have_effect\trecovery_right\n";
    out << "unspent\tabsent\tabsent\tfalse\tfalse\tmay_admit_fresh\n";
    out << "spent_crash_before_bind\tabsent\texact\ttrue\ttrue\tquery_only\n";
}

void write_summary(const std::filesystem::path& output,
                   const std::vector<State>& states,
                   const std::vector<Edge>& edges,
                   const std::size_t mutation_count,
                   const std::size_t boundary_checks) {
    const auto count_edges = [&](const auto& predicate) {
        return static_cast<std::size_t>(std::count_if(
            edges.begin(), edges.end(), predicate));
    };
    const std::size_t applied = count_edges([](const Edge& edge) {
        return edge.step.outcome == Outcome::applied;
    });
    const std::size_t endpoint_calls = count_edges([](const Edge& edge) {
        return edge.step.endpoint_apply_called;
    });
    const std::size_t refinements = count_edges([](const Edge& edge) {
        return edge.step.result_refined;
    });
    const std::size_t publications = count_edges([](const Edge& edge) {
        return edge.step.publication_appended;
    });
    const std::size_t dispatch_mints = count_edges([](const Edge& edge) {
        return edge.step.dispatch_minted;
    });
    const auto maximum_invocation = std::max_element(
        states.begin(), states.end(), [](const State& left, const State& right) {
            return left.invocation_count < right.invocation_count;
        })->invocation_count;
    const auto maximum_effect = std::max_element(
        states.begin(), states.end(), [](const State& left, const State& right) {
            return left.effect_count < right.effect_count;
        })->effect_count;
    const std::size_t version2_states = static_cast<std::size_t>(std::count_if(
        states.begin(), states.end(), [](const State& state) {
            return state.result_version == 2U;
        }));
    const std::size_t published_uncertain = static_cast<std::size_t>(std::count_if(
        states.begin(), states.end(), [](const State& state) {
            return state.result == Result::uncertain
                && state.published_version == 1U;
        }));
    const std::size_t published_revision2 = static_cast<std::size_t>(std::count_if(
        states.begin(), states.end(), [](const State& state) {
            return state.published_version == 2U;
        }));

    std::ofstream out(output / "summary.json", std::ios::binary);
    require(out.good(), "open summary.json");
    out << "{\n"
        << "  \"applied_edges\": " << applied << ",\n"
        << "  \"boundary_checks\": " << boundary_checks << ",\n"
        << "  \"candidate_reference_disagreements\": 0,\n"
        << "  \"dispatch_mints\": " << dispatch_mints << ",\n"
        << "  \"endpoint_apply_edges\": " << endpoint_calls << ",\n"
        << "  \"events_per_state\": " << kEvents.size() << ",\n"
        << "  \"handoff_indistinguishable_local_pairs\": 1,\n"
        << "  \"maximum_effect_count\": "
        << static_cast<unsigned int>(maximum_effect) << ",\n"
        << "  \"maximum_invocation_count\": "
        << static_cast<unsigned int>(maximum_invocation) << ",\n"
        << "  \"publication_append_edges\": " << publications << ",\n"
        << "  \"published_revision2_states\": " << published_revision2 << ",\n"
        << "  \"published_uncertain_states\": " << published_uncertain << ",\n"
        << "  \"record_bit_mutations\": " << mutation_count << ",\n"
        << "  \"record_bit_mutations_rejected\": " << mutation_count << ",\n"
        << "  \"record_bytes\": " << kRecordBytes << ",\n"
        << "  \"record_fixtures\": 6,\n"
        << "  \"result_refinement_edges\": " << refinements << ",\n"
        << "  \"schema\": \"slopos.rev0886.generation-journal-summary.v1\",\n"
        << "  \"states\": " << states.size() << ",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"transitions\": " << edges.size() << ",\n"
        << "  \"version2_states\": " << version2_states << "\n"
        << "}\n";
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    if (std::filesystem::exists(output)) {
        throw std::runtime_error("output must be absent");
    }
    std::filesystem::create_directories(output);

    std::vector<State> states{initial_state()};
    std::vector<std::size_t> depths{0U};
    std::map<State, std::size_t> ids{{states.front(), 0U}};
    std::vector<Edge> edges;
    std::size_t cursor = 0U;
    while (cursor < states.size()) {
        const State before = states[cursor];
        require(invariant(before), "candidate invariant before");
        for (const Event event : kEvents) {
            const Step candidate = step(before, event);
            const Step oracle = reference::step(before, event);
            require(candidate == oracle,
                    "candidate/reference disagreement state="
                    + state_key(before) + " event="
                    + std::string(event_name(event)));
            require(invariant(candidate.state), "candidate invariant after");
            if (candidate.outcome == Outcome::rejected) {
                require(candidate.state == before
                        && !candidate.endpoint_apply_called
                        && !candidate.result_refined
                        && !candidate.publication_appended
                        && !candidate.dispatch_minted,
                        "rejection must preserve complete state");
            }
            auto [found, inserted] = ids.emplace(candidate.state, states.size());
            if (inserted) {
                states.push_back(candidate.state);
                depths.push_back(depths[cursor] + 1U);
            }
            edges.push_back(Edge{cursor, depths[cursor], event, candidate,
                                 found->second});
        }
        ++cursor;
    }

    require(edges.size() == states.size() * kEvents.size(),
            "saturated relation size");
    require(std::all_of(states.begin(), states.end(), invariant),
            "all reachable invariants");
    require(std::none_of(edges.begin(), edges.end(), [](const Edge& edge) {
        return edge.step.dispatch_minted;
    }), "endpoint must never mint dispatch");

    const auto fixtures = record_fixtures();
    const std::size_t expected_mutations =
        fixtures.size() * kRecordBytes * 8U;
    const std::size_t rejected_mutations = mutation_campaign(fixtures);
    require(rejected_mutations == expected_mutations,
            "all one-bit record mutations rejected");
    const auto boundary = boundary_campaign();

    write_states(output, states, depths);
    write_edges(output, edges, states);
    write_witnesses(output, edges, states);
    write_records(output, fixtures);
    write_boundary(output, boundary);
    write_handoff(output);
    write_summary(output, states, edges, rejected_mutations, boundary.size());
    run_spend_campaign(output);
    run_local_join_campaign(output);

    std::cout << "GENERATION_JOURNAL_CAMPAIGN=PASS states=" << states.size()
              << " events=" << kEvents.size()
              << " transitions=" << edges.size()
              << " record_mutations=" << rejected_mutations
              << " boundary_checks=" << boundary.size()
              << " dispatch_mints=0 recovery_apply=0 route_override=0\n";
    return 0;
}

}  // namespace slopos::e0::generation_journal
