# Rooted Shadow Pack operation profile V2

Status: Epoch-Zero bounded storage construction; Linux/C++20 evidence leaf; not
a living-project format, provenance claim, retention decision, or deletion
authority.

## Exact subject

A canonical TSV subject names every regular file and directory below one
implicit root whose mode is exactly `0755`. Each row carries kind, portable
ASCII relative path, permission mode, logical size, and SHA-256 payload
identity. A valid operation must observe or reconstruct that complete record
address set. Equal payloads may share one blob record. Path, kind, mode, size,
and digest records do not collapse merely because payload bytes match.

The operated subject is inherited `EVIDENCE/CXX20`. Loose source files remain in
place. No command deletes, prunes, replaces, or garbage-collects them.

## Canonical object

The binary grammar intentionally remains `SLOPSPK1`, version `1`, to preserve
byte comparability with the independent reference and the forensic donor. All
integers are unsigned little-endian. The fixed 72-byte header is:

| Offset | Bytes | Meaning |
| ---: | ---: | --- |
| 0 | 8 | ASCII magic `SLOPSPK1` |
| 8 | 4 | object version `1` |
| 12 | 4 | zero reserved word |
| 16 | 8 | manifest entry count |
| 24 | 8 | unique blob count |
| 32 | 8 | manifest byte count |
| 40 | 32 | SHA-256 of exact manifest bytes |

Each manifest entry is `kind:u8`, three zero reserved bytes, `mode:u32`,
`size:u64`, 32 digest bytes, `path_length:u32`, then path bytes. Kind `1` is a
directory and requires size zero and an all-zero digest. Kind `2` is a regular
file. Entries are strictly byte-sorted by path.

Each blob record is digest, `size:u64`, then exact payload bytes. Blob records
are strictly digest-sorted. Every file references exactly one present blob of
the same size; every blob is referenced; duplicate records and trailing bytes
are forbidden.

## Path, mode, and resource membrane

Object paths use only `A-Z a-z 0-9 . _ / + -`, are relative and nonempty, are at
most 4096 bytes, have components of 1–255 bytes, and contain neither `.` nor
`..` components. Backslash, colon, NUL, leading slash, trailing slash, duplicate
exact paths, ASCII-casefold collisions, missing parents, and descent through a
file are rejected. Modes contain only permission bits and are between `0400`
and `0777`. A regular file is bounded to 1 GiB and the logical source to 4 GiB
in this profile.

## Descriptor-rooted source intake

The source path is opened component by component from a retained directory
file descriptor with `O_DIRECTORY|O_NOFOLLOW`. Every child is first observed
through `O_PATH|O_NOFOLLOW`, then opened relative to its retained parent; the
opened identity must agree. Symlinks and special objects are rejected without
following them. Directory names are enumerated before and after recursive
processing. Opened directories and regular files must retain device, inode,
type, mode, size, modification time, and change time at the checked boundaries.
Each regular file is read twice through one retained descriptor and the byte
sequences must agree.

This prevents pathname substitution from silently redirecting the operated
read. It does not prove an exclusive writer, freeze a hostile filesystem, or
exclude a mutation that occurs and is perfectly restored between every bounded
observation. Those remain explicit nonclaims.

## Verification and reconstruction

`pack` requires exact source/subject equality and an absent output object.
`verify` parses the entire object and compares its manifest to the exact
subject. `unpack` validates the complete object before creating anything.

Reconstruction opens the destination parent component by component without
symlink traversal, requires the final name to be absent, and creates a random
mode-`0700` hidden sibling stage. Every directory and file is created with
`mkdirat`/`openat` relative to retained descriptors and `O_NOFOLLOW`; files are
written, mode-fixed, synchronized, reread, and identity-checked. Directory
modes are applied from leaves toward the root. The complete stage is published
with Linux `renameat2(RENAME_NOREPLACE)` and the pinned parent is synchronized.
A conflicting destination is preserved. Invalid objects fail before stage
creation.

The resulting regular-file records are independent files, not hard links. The
operation proves complete-before-visible namespace publication in the operated
local Linux profile. It does not prove hardware persistence or remote
filesystem behavior.

## Read-only linked admission

A sealed checkpoint may remove write bits from retained paths. That custody
projection is not part of the object grammar and does not weaken `pack`. The
office adapter may accept only exact path/kind/size/digest identity and either
exact mode or `canonical_mode & ~0222` for every record and root. It reconstructs
canonical modes into an absent transient mirror before invoking the C++ leaf;
it never chmods the sealed source.

## Claim boundary

A SHA-256 digest is a content identifier, not a producer, role, revision,
provenance, signer, owner, or retention decision. The manifest preserves the
operated logical record addresses and reconstructible metadata only. The pack
is self-consistent but unauthenticated unless an expected object digest is
conveyed through separate trusted policy.

This construction proves no collision impossibility, compression ratio,
exclusive writer custody, stable media, remote filesystem semantics,
garbage-collection safety, retention policy, owner ratification, living
admission, authority transfer, or epoch exit.
