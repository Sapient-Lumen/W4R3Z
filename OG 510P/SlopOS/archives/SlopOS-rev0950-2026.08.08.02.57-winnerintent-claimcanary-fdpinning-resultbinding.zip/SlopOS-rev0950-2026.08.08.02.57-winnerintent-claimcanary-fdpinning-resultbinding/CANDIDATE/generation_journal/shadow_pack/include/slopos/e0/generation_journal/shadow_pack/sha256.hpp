#pragma once

#include <array>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>

namespace slopos::e0::generation_journal::shadow_pack {

using Digest = std::array<std::uint8_t, 32>;

[[nodiscard]] Digest sha256(std::span<const std::uint8_t> bytes);
[[nodiscard]] std::string hex_digest(const Digest& digest);
[[nodiscard]] Digest parse_digest(std::string_view text);

}  // namespace slopos::e0::generation_journal::shadow_pack
