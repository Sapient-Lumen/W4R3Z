# Counterexample: content equality is not record identity

Two paths can contain byte-identical payloads while occupying different compiler
lanes, revisions, proof positions, or operator-visible addresses. Replacing both
records with one unnamed “canonical file” loses information even though the
payload survives.

Rooted Shadow Pack therefore deduplicates only payload storage. Its manifest
retains every declared path, kind, mode, size, and digest; exact reconstruction
creates every regular-file record independently. These fields preserve an exact
logical filesystem view. They do **not** authenticate the producer, semantic
role, revision provenance, owner, or authority of any record.

A digest answers “which bytes were observed?” It does not answer “who produced
or admitted them?”, and equal bytes never authorize deletion of either loose
record.
