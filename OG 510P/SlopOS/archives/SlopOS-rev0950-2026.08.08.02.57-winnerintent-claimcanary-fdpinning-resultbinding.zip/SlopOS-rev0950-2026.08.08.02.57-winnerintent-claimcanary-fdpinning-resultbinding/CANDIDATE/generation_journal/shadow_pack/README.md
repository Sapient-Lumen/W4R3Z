# Generation-journal rooted shadow pack

This nested C++20/Linux leaf is the rev0937 non-destructive storage construction.
It encodes one exact declared filesystem subject as a deterministic manifest plus
digest-sorted unique payloads, verifies the complete object, and reconstructs it
through a descriptor-rooted hidden sibling stage before one no-replace
publication into an absent destination.

The object grammar remains `SLOPSPK1` version 1 so the independent Python oracle
and the earlier forensic sibling can be compared byte-for-byte. The operation
profile is V2: every source and destination path component is opened without
symlink traversal; directory traversal is anchored to retained descriptors;
regular files are read twice through one stable descriptor; membership and
identity are checked before and after traversal; output files are written,
mode-fixed, reread, and synchronized through descriptors; and the final logical
tree is exposed only after complete staged construction.

This is not a product target, semantic island, repository migration, provenance
system, garbage collector, owner act, or permission to remove the inherited
loose tree. Operated evidence is under
`EVIDENCE/REV0937/ROOTED-SHADOW-PACK`.

The C++ leaf requires exact canonical source modes, including an implicit root
mode of `0755`. Read-only linked-archive admission is handled outside the leaf:
the verifier permits only all-write-bits-removed projection and constructs an
absent transient canonical-mode mirror. It never changes sealed source.
