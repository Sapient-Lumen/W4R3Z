#pragma once

#include <cstdint>
#include <filesystem>
#include <string>

namespace slopos::e0::generation_journal::shadow_pack {

struct Summary {
  std::uint64_t entries{};
  std::uint64_t blobs{};
  std::uint64_t logical_bytes{};
  std::uint64_t pack_bytes{};
  std::string manifest_sha256;
};

[[nodiscard]] Summary pack_exact_subject(
    const std::filesystem::path& source_root,
    const std::filesystem::path& subject_manifest,
    const std::filesystem::path& absent_output);

[[nodiscard]] Summary verify_exact_subject(
    const std::filesystem::path& pack_path,
    const std::filesystem::path& subject_manifest);

[[nodiscard]] Summary unpack_exact_subject(
    const std::filesystem::path& pack_path,
    const std::filesystem::path& subject_manifest,
    const std::filesystem::path& absent_destination);

}  // namespace slopos::e0::generation_journal::shadow_pack
