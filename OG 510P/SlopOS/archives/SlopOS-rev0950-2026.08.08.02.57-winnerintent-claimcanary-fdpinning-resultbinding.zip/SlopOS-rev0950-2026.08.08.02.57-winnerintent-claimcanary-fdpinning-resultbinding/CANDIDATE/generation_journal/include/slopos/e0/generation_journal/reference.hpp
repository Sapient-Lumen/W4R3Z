#pragma once

#include "slopos/e0/generation_journal/machine.hpp"

namespace slopos::e0::generation_journal::reference {

// Independently spelled transition oracle. It shares only the public value
// vocabulary with the candidate implementation.
[[nodiscard]] Step step(const State& state, Event event) noexcept;

}  // namespace slopos::e0::generation_journal::reference
