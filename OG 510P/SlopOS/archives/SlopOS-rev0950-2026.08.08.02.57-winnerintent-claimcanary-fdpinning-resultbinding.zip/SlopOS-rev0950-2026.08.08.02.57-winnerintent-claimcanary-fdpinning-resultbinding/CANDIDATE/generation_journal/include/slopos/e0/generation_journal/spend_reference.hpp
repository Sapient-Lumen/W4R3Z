#pragma once

#include "slopos/e0/generation_journal/spend_floor.hpp"

namespace slopos::e0::generation_journal::spend_reference {

[[nodiscard]] SpendDecision evaluate_spend(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept;

[[nodiscard]] std::optional<CompareAppendRequest> make_compare_append_request(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept;

[[nodiscard]] AppendDecision accept_compare_append_response(
    const CompareAppendRequest& request,
    const CompareAppendResponse& response) noexcept;

}  // namespace slopos::e0::generation_journal::spend_reference
