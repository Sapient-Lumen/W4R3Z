#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>

namespace slopos::e0::generation_journal {

using Digest = std::array<std::uint8_t, 32U>;

struct SpendRecordV1 final {
    std::uint64_t owner_epoch{0U};
    std::uint64_t constructor_epoch{0U};
    std::uint64_t spend_serial{0U};
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    Digest owner_statement{};
    Digest constructor_image{};
    Digest provider_subject{};
    Digest publication_receipt{};
    Digest expectation_record{};
    Digest operation{};
    Digest pending_result{};
    Digest predecessor_head{};

    [[nodiscard]] friend constexpr bool operator==(
        const SpendRecordV1&, const SpendRecordV1&) noexcept = default;
};

inline constexpr std::size_t kSpendRecordBytes = 352U;
using EncodedSpendRecord = std::array<std::uint8_t, kSpendRecordBytes>;

[[nodiscard]] bool digest_is_zero(const Digest& value) noexcept;
[[nodiscard]] bool spend_record_invariant(const SpendRecordV1& record) noexcept;
[[nodiscard]] Digest sha256(std::span<const std::uint8_t> bytes);
[[nodiscard]] bool encode_spend_record(const SpendRecordV1& record,
                                       EncodedSpendRecord& output) noexcept;
[[nodiscard]] bool decode_spend_record(const EncodedSpendRecord& input,
                                       SpendRecordV1& output) noexcept;
[[nodiscard]] Digest spend_record_head(const EncodedSpendRecord& record);

}  // namespace slopos::e0::generation_journal
