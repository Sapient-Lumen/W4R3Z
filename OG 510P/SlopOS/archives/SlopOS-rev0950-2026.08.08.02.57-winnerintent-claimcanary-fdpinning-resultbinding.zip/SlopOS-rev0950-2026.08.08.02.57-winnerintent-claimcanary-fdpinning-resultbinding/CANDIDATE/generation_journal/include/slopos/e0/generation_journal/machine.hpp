#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <string_view>
#include <tuple>

namespace slopos::e0::generation_journal {

enum class Phase : std::uint8_t {
    empty,
    pending,
    ready,
    uncertain,
    terminal,
    fail_stop,
};

enum class Endpoint : std::uint8_t {
    predecessor,
    successor_same,
    successor_other,
};

enum class Result : std::uint8_t {
    none,
    effect,
    no_effect,
    uncertain,
    fail_stop,
};

enum class Outcome : std::uint8_t { applied, rejected };

enum class Event : std::uint8_t {
    accept_consumed_dispatch,
    accept_wrong_dispatch,
    persist_pending_exact,
    persist_pending_mismatch,
    external_successor_other,
    invoke_effect_return,
    invoke_no_effect_return,
    invoke_nonreturn_before_effect,
    invoke_nonreturn_after_effect,
    invoke_malformed_before_effect,
    invoke_malformed_after_effect,
    restart,
    recover_spent_receipt_exact,
    recover_spent_receipt_mismatch,
    recover_spent_receipt_missing,
    query_predecessor,
    query_successor_same,
    query_successor_other,
    query_unavailable,
    recovery_apply_attempt,
    mint_dispatch_attempt,
    route_override_attempt,
    retry_apply_attempt,
    publish,
    stale_publication_attempt,
};

struct State final {
    Phase phase{Phase::empty};
    Endpoint endpoint{Endpoint::predecessor};
    Result result{Result::none};
    std::uint8_t result_version{0U};
    std::uint8_t published_version{0U};
    std::uint8_t invocation_count{0U};
    std::uint8_t effect_count{0U};
    bool receipt_bound{false};
    bool pending_exact{false};
    bool recovered{false};
    bool reconciled{false};

    [[nodiscard]] friend constexpr bool operator==(
        const State&, const State&) noexcept = default;
    [[nodiscard]] friend constexpr bool operator<(
        const State& lhs, const State& rhs) noexcept {
        return std::tie(lhs.phase, lhs.endpoint, lhs.result,
                        lhs.result_version, lhs.published_version,
                        lhs.invocation_count, lhs.effect_count,
                        lhs.receipt_bound, lhs.pending_exact,
                        lhs.recovered, lhs.reconciled)
             < std::tie(rhs.phase, rhs.endpoint, rhs.result,
                        rhs.result_version, rhs.published_version,
                        rhs.invocation_count, rhs.effect_count,
                        rhs.receipt_bound, rhs.pending_exact,
                        rhs.recovered, rhs.reconciled);
    }
};

struct Step final {
    Outcome outcome{Outcome::rejected};
    State state{};
    bool endpoint_apply_called{false};
    bool result_refined{false};
    bool publication_appended{false};
    bool dispatch_minted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const Step&, const Step&) noexcept = default;
};

inline constexpr std::array<Event, 25U> kEvents{{
    Event::accept_consumed_dispatch,
    Event::accept_wrong_dispatch,
    Event::persist_pending_exact,
    Event::persist_pending_mismatch,
    Event::external_successor_other,
    Event::invoke_effect_return,
    Event::invoke_no_effect_return,
    Event::invoke_nonreturn_before_effect,
    Event::invoke_nonreturn_after_effect,
    Event::invoke_malformed_before_effect,
    Event::invoke_malformed_after_effect,
    Event::restart,
    Event::recover_spent_receipt_exact,
    Event::recover_spent_receipt_mismatch,
    Event::recover_spent_receipt_missing,
    Event::query_predecessor,
    Event::query_successor_same,
    Event::query_successor_other,
    Event::query_unavailable,
    Event::recovery_apply_attempt,
    Event::mint_dispatch_attempt,
    Event::route_override_attempt,
    Event::retry_apply_attempt,
    Event::publish,
    Event::stale_publication_attempt,
}};

[[nodiscard]] State initial_state() noexcept;
[[nodiscard]] bool invariant(const State& state) noexcept;
[[nodiscard]] Step step(const State& state, Event event) noexcept;

[[nodiscard]] std::string_view phase_name(Phase value) noexcept;
[[nodiscard]] std::string_view endpoint_name(Endpoint value) noexcept;
[[nodiscard]] std::string_view result_name(Result value) noexcept;
[[nodiscard]] std::string_view outcome_name(Outcome value) noexcept;
[[nodiscard]] std::string_view event_name(Event value) noexcept;
[[nodiscard]] std::string state_key(const State& state);
[[nodiscard]] std::string local_key(const State& state);

}  // namespace slopos::e0::generation_journal
