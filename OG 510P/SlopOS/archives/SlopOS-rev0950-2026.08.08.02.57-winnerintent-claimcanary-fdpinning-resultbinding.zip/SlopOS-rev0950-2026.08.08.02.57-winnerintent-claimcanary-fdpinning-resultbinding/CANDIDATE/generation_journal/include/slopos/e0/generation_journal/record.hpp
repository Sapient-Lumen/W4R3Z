#pragma once

#include "slopos/e0/generation_journal/machine.hpp"

#include <array>
#include <cstddef>
#include <cstdint>

namespace slopos::e0::generation_journal {

enum class RecordKind : std::uint8_t {
    pending = 1U,
    result = 2U,
    publication = 3U,
};

struct Record final {
    RecordKind kind{RecordKind::pending};
    std::uint64_t sequence{1U};
    std::uint64_t generation_from{1U};
    std::uint64_t generation_to{2U};
    std::array<std::uint8_t, 32U> operation_binding{};
    std::array<std::uint8_t, 32U> spent_receipt_binding{};
    Result result{Result::none};
    bool consumed_dispatch{true};
    bool reconciled{false};

    [[nodiscard]] friend constexpr bool operator==(
        const Record&, const Record&) noexcept = default;
};

inline constexpr std::size_t kRecordBytes = 128U;
inline constexpr std::uint64_t kFixedEndpointId = 0x534c4f50474a3031ULL; // SLOPGJ01
using EncodedRecord = std::array<std::uint8_t, kRecordBytes>;

[[nodiscard]] bool record_invariant(const Record& record) noexcept;
[[nodiscard]] bool encode_record(const Record& record,
                                 EncodedRecord& output) noexcept;
[[nodiscard]] bool decode_record(const EncodedRecord& input,
                                 Record& output) noexcept;
[[nodiscard]] std::uint32_t record_crc32(const std::uint8_t* bytes,
                                         std::size_t length) noexcept;

}  // namespace slopos::e0::generation_journal
