#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <array>
#include <cstdint>
#include <optional>

namespace slopos::e0::generation_journal {

struct ExactOperation final {
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    std::array<std::uint8_t, 32U> operation_binding{};
    std::array<std::uint8_t, 32U> spent_receipt_binding{};

    [[nodiscard]] friend constexpr bool operator==(
        const ExactOperation&, const ExactOperation&) noexcept = default;
};

// Hosted proof-shape tokens. Ordinary process memory does not make these
// nonforgeable. The only public mint is named HostedGateFixture so callers
// cannot confuse test construction with a protected gate.
class ConsumedDispatchReceipt final {
public:
    ConsumedDispatchReceipt(const ConsumedDispatchReceipt&) = delete;
    ConsumedDispatchReceipt& operator=(const ConsumedDispatchReceipt&) = delete;
    ConsumedDispatchReceipt(ConsumedDispatchReceipt&& other) noexcept;
    ConsumedDispatchReceipt& operator=(ConsumedDispatchReceipt&&) = delete;
    ~ConsumedDispatchReceipt() = default;

    [[nodiscard]] bool live() const noexcept { return live_; }

private:
    explicit ConsumedDispatchReceipt(ExactOperation operation) noexcept;
    [[nodiscard]] std::optional<ExactOperation> consume() noexcept;

    ExactOperation operation_{};
    bool live_{true};

    friend class HostedGateFixture;
    friend class EndpointBoundary;
};

class PendingPlan final {
public:
    PendingPlan(const PendingPlan&) = delete;
    PendingPlan& operator=(const PendingPlan&) = delete;
    PendingPlan(PendingPlan&& other) noexcept;
    PendingPlan& operator=(PendingPlan&&) = delete;
    ~PendingPlan() = default;

    [[nodiscard]] bool live() const noexcept { return live_; }
    [[nodiscard]] const EncodedRecord& intended_record() const noexcept {
        return intended_;
    }

private:
    PendingPlan(ExactOperation operation, EncodedRecord intended) noexcept;
    [[nodiscard]] bool consume(ExactOperation& operation,
                               EncodedRecord& intended) noexcept;

    ExactOperation operation_{};
    EncodedRecord intended_{};
    bool live_{true};

    friend class EndpointBoundary;
};

class InvocationTicket final {
public:
    InvocationTicket(const InvocationTicket&) = delete;
    InvocationTicket& operator=(const InvocationTicket&) = delete;
    InvocationTicket(InvocationTicket&& other) noexcept;
    InvocationTicket& operator=(InvocationTicket&&) = delete;
    ~InvocationTicket() = default;

    [[nodiscard]] bool live() const noexcept { return live_; }

private:
    explicit InvocationTicket(ExactOperation operation) noexcept;
    ExactOperation operation_{};
    bool live_{true};

    friend class EndpointBoundary;
};

class QueryOnlyBinding final {
public:
    QueryOnlyBinding(const QueryOnlyBinding&) = delete;
    QueryOnlyBinding& operator=(const QueryOnlyBinding&) = delete;
    QueryOnlyBinding(QueryOnlyBinding&& other) noexcept;
    QueryOnlyBinding& operator=(QueryOnlyBinding&&) = delete;
    ~QueryOnlyBinding() = default;

    [[nodiscard]] bool live() const noexcept { return live_; }

private:
    explicit QueryOnlyBinding(ExactOperation operation) noexcept;
    ExactOperation operation_{};
    bool live_{true};

    friend class EndpointBoundary;
};

class HostedGateFixture final {
public:
    [[nodiscard]] static ConsumedDispatchReceipt consumed(
        ExactOperation operation) noexcept;
};

class EndpointBoundary final {
public:
    // Planning is inert. It consumes an already-spent receipt and returns exact
    // pending bytes, never an invocation ticket.
    [[nodiscard]] static std::optional<PendingPlan> plan(
        ConsumedDispatchReceipt&& receipt) noexcept;

    // Every activation attempt consumes the pending plan. Only exact readback
    // of the complete canonical pending record creates one volatile ticket.
    [[nodiscard]] static std::optional<InvocationTicket> activate_after_readback(
        PendingPlan&& plan, const EncodedRecord& readback) noexcept;

    // Recovery can create only a query binding from an externally protected,
    // exact spent-receipt observation. There is no recovery-to-invocation API.
    [[nodiscard]] static std::optional<QueryOnlyBinding> recover_query_only(
        const ExactOperation& protected_observation) noexcept;

    // The endpoint identifier is fixed in the record profile and is not an
    // argument to planning, activation, invocation, or recovery.
    [[nodiscard]] static constexpr std::uint64_t fixed_endpoint_id() noexcept {
        return kFixedEndpointId;
    }
};

}  // namespace slopos::e0::generation_journal
