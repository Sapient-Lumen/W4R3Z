#pragma once

#include "slopos/e0/generation_journal/spend_floor.hpp"

#include <cstdint>
#include <filesystem>
#include <optional>
#include <string_view>

namespace slopos::e0::generation_journal {

// These statuses describe a hosted fault adapter. They do not mint or carry
// endpoint authority. The only endpoint-admission fact is the row committed in
// the same local transaction as the exact floor successor.
enum class HostedJoinStatus : std::uint8_t {
    admitted,
    already_current,
    conflict,
    unavailable,
    malformed,
    identity_mismatch,
};

enum class HostedJoinReadStatus : std::uint8_t {
    available,
    unavailable,
    malformed,
    identity_mismatch,
};

enum class HostedJoinFaultCut : std::uint8_t {
    none,
    after_begin,
    after_floor_update,
    after_endpoint_insert,
    after_commit_before_reply,
};

enum class HostedJoinOpenMode : std::uint8_t {
    read_only,
    recovering_read_write,
};

struct HostedJoinResult final {
    HostedJoinStatus status{HostedJoinStatus::malformed};
    Digest floor_identity{};
    FloorPoint current{};
    bool endpoint_entry_created{false};
    bool endpoint_bindings_exact{false};
    bool query_only{false};
    bool spent{false};
    bool response_authority{false};
    bool fail_stop{true};
    std::optional<EncodedSpendRecord> current_record{};
    std::uint64_t endpoint_entries{0U};
};

struct HostedJoinObservation final {
    HostedJoinReadStatus status{HostedJoinReadStatus::malformed};
    Digest floor_identity{};
    FloorPoint current{};
    std::optional<EncodedSpendRecord> current_record{};
    std::uint64_t endpoint_entries{0U};
    bool endpoint_bindings_exact{false};
};

// Creates a fresh hosted SQLite image containing one exact content-bound floor.
// The path must not name an existing file. This is a fault adapter, not a
// protected provider and not an authority boundary.
[[nodiscard]] bool initialize_hosted_join(
    const std::filesystem::path& path,
    const Digest& floor_identity,
    const FloorPoint& initial) noexcept;

// In one local SQLite write transaction, compare the exact floor point, append
// the exact spend record, and insert one fixed endpoint-admission row. The
// returned value is deliberately copyable observation data and never authority.
// No API accepts it as a later invocation capability.
[[nodiscard]] HostedJoinResult compare_append_and_admit_hosted(
    const std::filesystem::path& path,
    const CompareAppendRequest& request,
    HostedJoinFaultCut fault_cut = HostedJoinFaultCut::none) noexcept;

// Reads the exact floor and admission count. Recovering mode may take the local
// write lock so SQLite can repair a hot rollback journal after a killed process;
// read_only is used for the independent clean-reopen observation.
[[nodiscard]] HostedJoinObservation observe_hosted_join(
    const std::filesystem::path& path,
    const Digest& expected_floor_identity,
    HostedJoinOpenMode mode = HostedJoinOpenMode::read_only) noexcept;

// Copies a transactionally consistent local SQLite image. The ability to copy
// and later operate both images is intentionally retained as a rollback/global
// spend counterexample: local atomicity is not external nonrollback authority.
[[nodiscard]] bool backup_hosted_join_snapshot(
    const std::filesystem::path& source,
    const std::filesystem::path& destination) noexcept;

[[nodiscard]] std::string_view hosted_join_status_name(
    HostedJoinStatus value) noexcept;
[[nodiscard]] std::string_view hosted_join_read_status_name(
    HostedJoinReadStatus value) noexcept;
[[nodiscard]] std::string_view hosted_join_fault_cut_name(
    HostedJoinFaultCut value) noexcept;

}  // namespace slopos::e0::generation_journal
