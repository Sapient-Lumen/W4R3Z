#pragma once

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <cstdint>
#include <optional>
#include <string_view>

namespace slopos::e0::generation_journal {

struct FloorPoint final {
    std::uint64_t generation{0U};
    Digest head{};

    [[nodiscard]] friend constexpr bool operator==(
        const FloorPoint&, const FloorPoint&) noexcept = default;
};

enum class FloorReadStatus : std::uint8_t {
    available,
    unavailable,
    malformed,
};

struct LocalSpendObservation final {
    FloorPoint confirmed{};
    bool pending_present{false};
    std::optional<EncodedSpendRecord> pending{};
};

struct ProtectedFloorObservation final {
    FloorReadStatus status{FloorReadStatus::unavailable};
    Digest floor_identity{};
    FloorPoint current{};
    bool content_bound{false};
    std::optional<EncodedSpendRecord> current_record{};
};

enum class SpendRelation : std::uint8_t {
    fresh,
    prepared_exact,
    same_spend_committed,
    foreign_spend,
    scalar_ambiguous,
    floor_unavailable,
    local_ahead,
    generation_jump,
    malformed,
    identity_mismatch,
};

struct SpendDecision final {
    SpendRelation relation{SpendRelation::malformed};
    bool compare_append_allowed{false};
    bool query_only{false};
    bool rollback_detected{false};
    bool fail_stop{true};

    [[nodiscard]] friend constexpr bool operator==(
        const SpendDecision&, const SpendDecision&) noexcept = default;
};

struct CompareAppendRequest final {
    Digest floor_identity{};
    FloorPoint expected{};
    FloorPoint target{};
    EncodedSpendRecord record{};

    [[nodiscard]] friend constexpr bool operator==(
        const CompareAppendRequest&, const CompareAppendRequest&) noexcept = default;
};

enum class AppendStatus : std::uint8_t {
    advanced,
    already_current,
    conflict,
    unavailable,
    malformed,
    identity_mismatch,
};

struct CompareAppendResponse final {
    AppendStatus status{AppendStatus::malformed};
    Digest floor_identity{};
    FloorPoint current{};
    bool content_bound{false};
    std::optional<EncodedSpendRecord> current_record{};
};

struct AppendDecision final {
    bool invoke_once{false};
    bool query_only{false};
    bool spent{false};
    bool fail_stop{true};

    [[nodiscard]] friend constexpr bool operator==(
        const AppendDecision&, const AppendDecision&) noexcept = default;
};

[[nodiscard]] SpendDecision evaluate_spend(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept;

[[nodiscard]] std::optional<CompareAppendRequest> make_compare_append_request(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept;

[[nodiscard]] AppendDecision accept_compare_append_response(
    const CompareAppendRequest& request,
    const CompareAppendResponse& response) noexcept;

[[nodiscard]] std::string_view floor_read_status_name(FloorReadStatus value) noexcept;
[[nodiscard]] std::string_view spend_relation_name(SpendRelation value) noexcept;
[[nodiscard]] std::string_view append_status_name(AppendStatus value) noexcept;

}  // namespace slopos::e0::generation_journal
