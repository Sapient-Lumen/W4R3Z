# Generation journal v1

**Status:** hosted Epoch-Zero proofwork. No stable-media, protected capability,
protected endpoint, authenticated query, rollback resistance, independent
actor, or release claim.

## Selected seam

```text
already-consumed exact dispatch receipt
  -> inert pending plan
  -> exact pending record write/readback
  -> one volatile invocation ticket
  -> one fixed predecessor -> successor endpoint call
  -> EFFECT | NO_EFFECT | UNCERTAIN | FAIL_STOP, revision 1
  -> immutable publication of the exact current revision
  -> after uncertainty, exact query only
  -> EFFECT | NO_EFFECT | FAIL_STOP, revision 2
  -> immutable publication of revision 2
```

There is no permit-minting API, route argument, recovery-apply API, retry API,
or overwrite-publication API. The fixed endpoint identity is the constant
`SLOPGJ01` in the exact record profile.

## Laws

1. The package accepts only a receipt that the gate has already consumed.
   `ConsumedDispatchReceipt` is move-only proof shape, not a real capability.
2. Planning is inert. It returns exact pending bytes and cannot call the
   endpoint.
3. Every post-write activation attempt consumes the pending plan. Only exact
   full-record readback can create one volatile invocation ticket.
4. The fixed endpoint changes generation `g` only to `g+1`, with
   `1 <= g < UINT64_MAX`, for the same exact
   operation binding. The caller supplies no route.
5. At most one endpoint invocation and at most one effect occur in every
   reachable state.
6. A nonreturn or malformed return is `UNCERTAIN`, whether the hidden endpoint
   effect occurred or not. It is never narrowed to `NO_EFFECT` by local absence.
7. Recovery never invokes. It may bind an exact protected spent receipt and
   query the fixed endpoint only.
8. Query of the exact predecessor yields `NO_EFFECT`; query of the exact
   successor bound to this operation yields `EFFECT`; a different successor is
   `FAIL_STOP`; unavailable query preserves complete uncertainty.
9. Publication is append-only by result version. Published `UNCERTAIN` revision
   1 can be superseded only by publication of exact revision 2. Revision 1 is
   not overwritten and publication creates no effect or dispatch authority.
10. Stale publication, recovery apply, dispatch mint, route override, and retry
    are explicit state-preserving rejection events.
11. Wrapped generation identity is rejected at both the record and recovery
    boundary. CRC mutation detection is not writer authentication; the campaign
    retains a recomputed-CRC alternate-record counterexample.

## Burn-to-journal handoff theorem

The local pending journal has the same observation—no pending record—in at
least two worlds:

- the gate did not consume an operation; and
- the gate consumed one exact operation, then the process died before pending
  identity was retained.

Those worlds require different resumption behavior. Therefore no deterministic
recovery function over the local journal alone can both preserve first-dispatch
safety and identify the consumed operation. The vertical needs one of:

- one atomic transaction that consumes the capability and retains pending
  identity;
- a separately protected, queryable spent receipt binding the complete
  operation, capability generation, endpoint, and owner epoch; or
- a primitive whose durable spent state already contains that identity.

The finite relation assumes the second form when
`recover_spent_receipt_exact` succeeds. The cloudtainer does not supply it.

## Result-version rule

Revision 0 means no result. Revision 1 is the first exact observed result and
may be `EFFECT`, `NO_EFFECT`, `UNCERTAIN`, or `FAIL_STOP`. Only `UNCERTAIN` may
be refined, exactly once, to revision 2. Revision 2 is `EFFECT`, `NO_EFFECT`, or
`FAIL_STOP`. `published_version <= result_version` always. Publication may
advance from 0 to 1 and later from 1 to 2, but cannot repeat, skip to nonexistent
content, or overwrite an older publication.

## Refinement boundary

This package refines the post-entry portion of core-gate v1:

- core `endpoint_effect` maps to generation-journal revision-1 `EFFECT`;
- core `endpoint_no_effect` maps to revision-1 `NO_EFFECT`;
- core nonreturn and malformed return map to revision-1 `UNCERTAIN`;
- core reconciliation maps to exact query-only revision 2;
- core publication maps to publication of the exact current version.

Core-gate CG18 is closed only at this hosted relation level. The real protected
result service, authenticated endpoint query, storage adapter, rollback floor,
and cross-process handoff remain open.

## Rev0893 spend-floor extension

The original relation begins after a consumed dispatch receipt and therefore
cannot solve its own burn-to-journal handoff theorem. Rev0893 does not rewrite
that relation. It adds the adjacent hosted compare-and-append model specified
in `SPEND-FLOOR-V1.md`.

That model gives an exact API shape for a future protected spent receipt:
expected `(generation, head)`, complete spend record, exact successor head, one
`advanced` winner, exact duplicate convergence to `already_current`, and
fail-stop for foreign, scalar, unavailable, or malformed observations. The
join from `advanced` to the real endpoint is still open because response bytes
are replayable.
