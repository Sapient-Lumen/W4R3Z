# `SLOPGJ01` record v1

The hosted construction uses one canonical 128-byte record. It is not a stable
storage theorem or an authenticated object.

| bytes | width | field | rule |
|---|---:|---|---|
| 0..8 | 8 | magic | ASCII `SLOPGJ01` |
| 8 | 1 | format | `1` |
| 9 | 1 | kind | 1 pending, 2 result, 3 publication |
| 10..12 | 2 | length | little-endian `128` |
| 12..20 | 8 | result sequence | little-endian 1 or 2 |
| 20..28 | 8 | predecessor generation | `1 <= g < UINT64_MAX` |
| 28..36 | 8 | successor generation | predecessor + 1 |
| 36..68 | 32 | exact operation binding | nonzero opaque digest |
| 68..100 | 32 | protected spent-receipt binding | nonzero opaque digest |
| 100..108 | 8 | fixed endpoint | `0x534c4f50474a3031` |
| 108 | 1 | result | none/effect/no-effect/uncertain/fail-stop |
| 109 | 1 | flags | bit 0 consumed; bit 1 reconciled; others zero |
| 110..124 | 14 | reserved | zero |
| 124..128 | 4 | CRC-32 | over bytes 0..124 |

Pending is sequence 1, result none, consumed true, reconciled false. Result and
publication records contain a terminal result. `UNCERTAIN` exists only at
sequence 1. Sequence 2 is reconciled. CRC-32 detects the exercised one-bit mutations. A deliberate alternate valid
record with a recomputed CRC is accepted by the codec, which is retained as a
counterexample: CRC-32 does not authenticate a writer, prove freshness, resist deliberate
replacement, or establish durable media.
