# Hosted joined admission v1

**Status:** executable Epoch-Zero fault adapter. It is not a protected provider,
not a global spend mechanism, not an effect executor, and not living authority.

## Purpose

Rev0893 made one exact content-bound floor successor distinguishable from a
foreign successor, but its `advanced` response was ordinary copyable data. A
caller could replay the same bytes and reproduce an `invoke_once` decision.
That API shape was therefore wrong: observation had been allowed to masquerade
as authority.

This construction removes that interpretation and tests the smallest safer
join available inside the hosted cloudtainer:

```text
compare exact floor predecessor
  + append exact canonical spend record
  + insert one fixed endpoint-admission row
  = one local transaction
```

The returned `HostedJoinResult` is deliberately copyable observation. Every
result has `response_authority=false`. No API accepts it as an endpoint ticket.
The only positive endpoint-admission fact is the row committed inside the same
transaction as the exact floor successor.

## State retained in the local cell

The SQLite image has two strict tables.

`slopos_floor` contains one singleton row:

```text
floor_identity
generation_be
head
current_record
```

`slopos_endpoint_admission` contains the fixed pending-entry projection of the
canonical spend record:

```text
spend_head                 primary key
floor_identity
successor_generation_be    unique
exact_record               unique
provider_subject
publication_receipt
expectation_record
operation
pending_result
```

The admission row does not contain a caller-selected route. Its operation,
provider subject, expectation, publication receipt, and pending-result identity
are copied from one decoded canonical `SLOPSP01` record and checked again on
readback.

## Joined transition

For request `R=(floor_id, expected=(g,H), target=(g+1,H'), record)`:

1. reject malformed record/point relationships before opening the database;
2. open the one named image and begin `BEGIN IMMEDIATE`;
3. read the complete singleton floor and current admission count;
4. reject a provider-identity mismatch;
5. if current is the exact target with the exact record and an exact admission
   row, return `already_current`, caller-query-only;
6. if current is not the expected predecessor, return `conflict`;
7. conditionally update the floor row from the complete expected point;
8. insert the exact fixed endpoint-admission row;
9. commit once;
10. reread and verify the complete floor, complete record, exact entry bindings,
    and entry-count increment;
11. return copyable observation with no response authority.

`admitted` and `already_current` both leave the caller query-only. `conflict`,
`unavailable`, `malformed`, and `identity_mismatch` fail closed. A detached
response never becomes permission to execute an effect.

## Crash classification

The harness kills a child process at four exact cuts and independently reopens
the image:

| cut | clean recovered state | retry classification |
|---|---|---|
| after `BEGIN IMMEDIATE` | predecessor, zero entries | `admitted` |
| after floor update, before entry insert | predecessor, zero entries | `admitted` |
| after entry insert, before commit | predecessor, zero entries | `admitted` |
| after commit, before reply | exact target, one exact entry | `already_current` |

For the three precommit cuts SQLite rollback-journal recovery removes both
uncommitted changes. For the postcommit cut the exact floor and entry survive
together. Across these exercised cuts there is no clean reopened state with
`target` and zero entries.

This is a bounded theorem about this local adapter, filesystem, SQLite build,
and exercised fault cuts. It is not a stable-media or power-loss theorem.

## Race classification

Sixteen concurrent exact contenders open independent connections to the same
local image. Exactly one returns `admitted`; fifteen return `already_current`;
the clean final image contains one exact entry. Two opposite-order foreign
worlds each retain the first exact record and fail the second as `conflict`.

No result object grants endpoint authority. Copying the winning result twice
creates zero new rows.

## Required negative controls

### Unsafe split append then entry

The harness deliberately bypasses the joined API and commits only the floor
update. It reaches the forbidden visible state:

```text
floor = exact target
endpoint entries = 0
```

Independent observation classifies the image malformed/uncertain and fails
closed. Therefore a separately committed append followed by a later enqueue is
not an implementation of this join.

### Coherent local rollback

A transactionally consistent pre-spend snapshot is copied. The same exact
request is then admitted independently in both the original and the clone.
Both images contain one internally exact admission; the combined histories
contain two. Therefore local transaction atomicity does not provide a global
nonrollback spend floor. The authentic provider must live in a rollback domain
that the cloudtainer cannot copy and restore with the candidate.

### Descriptor delivery is duplicable

On the retained Linux host one `SCM_RIGHTS` message is received twice with
`MSG_PEEK` and once normally. The kernel installs three descriptor references.
Reading one byte through each yields `ABC`, demonstrating one shared open-file
description offset. The queued message and each installed descriptor are useful
transport evidence, but neither is a unique one-use authority.

## Deliberate limits

This construction does **not** prove:

- owner-admitted floor genesis or provider identity;
- exclusive writer custody outside the cloudtainer;
- resistance to filesystem, volume, VM, backup, or database rollback;
- stable-media behavior under power loss or device failure;
- independent appraisal of the provider and cell;
- execution by a protected fixed endpoint;
- exact pending/result settlement after endpoint work;
- compromise, rotation, retirement, or successor ceremony;
- global at-most-once effect.

SQLite `synchronous=FULL`, rollback-journal mode, strict tables, and fresh
readback are useful fault-adapter choices. They are not substitutions for those
premises.

## Refinement target

A future authentic provider may refine this shape only if one protected
transition supplies all of the following:

```text
owner-bound provider identity
+ exact expected floor identity/generation/head
+ canonical successor record
+ one fixed endpoint pending-entry identity
+ nonrollback commit classification
+ independent clean reopen
```

The provider response remains observation-only. Endpoint work must be claimed
from protected pending state under a separately proved consume-before-parse
boundary, never from copied response bytes.
