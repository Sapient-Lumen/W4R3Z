# Content-bound compare-and-append spend floor v1

**Status:** hosted Epoch-Zero relation and API shape. No protected provider,
exclusive writer, durable media, physical rollback resistance, nonduplicable
invocation gate, or global spend claim.

## Purpose

The generation journal needs to distinguish three worlds after interruption:

1. this exact spend has not advanced the protected floor;
2. this exact spend already advanced it; and
3. another spend or an unknowable scalar advance occurred.

A monotonic number distinguishes order but not which spend won. The smallest
relation that can answer the question binds both an expected generation and an
expected content head in one atomic compare-and-append operation.

## Floor point and request

A content-bound floor point is `(generation, head)`, where `head` is nonzero.
A request contains:

- the expected protected floor identity;
- exact predecessor point `(g, H)`;
- exact target point `(g+1, H')`;
- one canonical `SLOPSP01` record whose predecessor is `(g, H)` and whose
  computed head is `H'`.

The provider operation required by this relation is:

```text
compare_and_append(floor_id, expected=(g,H), record, target=(g+1,H'))
```

It must atomically return one of:

- `advanced`: this call changed the exact floor from expected to target;
- `already_current`: the floor is already the exact target with the exact
  record;
- `conflict`: the current content is neither expected nor this exact target;
- `unavailable`, `malformed`, or `identity_mismatch`.

A blind increment and a blind extend do not implement this contract. They do
not take the complete expected predecessor point and reject every stale writer
against it.

## Local/floor relation

Given a local confirmed point, optional exact pending record, protected floor
observation, candidate record, and expected floor identity:

| relation | condition | right |
|---|---|---|
| `fresh` | exact floor equals local predecessor; no pending | form one compare-and-append request |
| `prepared_exact` | exact floor equals local predecessor; pending equals candidate | resume the same compare-and-append request |
| `same_spend_committed` | exact floor equals candidate target | query-only; never invoke from recovery |
| `foreign_spend` | exact competing head or pending record | fail-stop |
| `scalar_ambiguous` | generation is visible but exact head is not | fail-stop |
| `floor_unavailable` | protected observation unavailable | fail-stop; no local fallback |
| `local_ahead` | local point is ahead of protected point | fail-stop |
| `generation_jump` | protected point is beyond the candidate successor | fail-stop |
| `malformed` / `identity_mismatch` | malformed bytes or wrong provider identity | fail-stop |

The exact committed successor is query-only even when local pending state was
lost. Local absence never recreates freshness.

## Response refinement

No detached compare-and-append response refines to endpoint authority. An exact
`advanced` or `already_current` response proves only that this exact spend is
observed at the target; both are caller-query-only and both have
`invoke_once=false`. Every other response fails closed. There is no
retry-on-conflict rule.

This corrects the rev0893 counterexample. The same exact `advanced` response can
be replayed indefinitely because it is ordinary data. Rev0894 retains that
copyability but removes the authority interpretation: two replays produce zero
invoke decisions. One endpoint entry must instead be committed inside protected
state by the joined-admission relation in `JOINED-ADMISSION-V1.md`.

## Finite evidence

The C++ candidate and independently spelled C++ reference agree on 20 boundary
cases. Independent Python reconstructs the relation from retained bytes.
Clang, GCC, and sanitizer lanes are byte-identical. The campaign also executes:

- two 352-byte records and all 5,632 one-bit mutations;
- sixteen same-spend contenders: one `advanced`, fifteen `already_current`, zero
  invoke decisions, sixteen observation-only decisions;
- two opposite-order foreign-spend races: one winner and one conflict each;
- seven retained counterexamples.

This proves the finite hosted relation, codec, and harness outputs. It does not
prove that any cloud service, filesystem, TPM, database, process, or machine
actually satisfies the provider contract.

## Provider obligations left open

A future protected provider must prove all of the following together:

1. owner-approved constructor provenance and provider identity;
2. atomic compare of expected generation **and** expected head;
3. exact append/readback of the winning record;
4. exclusive writer custody or equivalent concurrency closure;
5. survival across process loss, machine reset, storage rollback, and restore;
6. an external rollback floor whose own identity and lifecycle are protected;
7. protected refinement of the hosted same-transaction floor/entry join;
8. consume-before-parse claiming of one pending entry by a fixed endpoint;
9. query-only recovery and immutable result retention.

Until those obligations close, `durable_global_spend=false` and
authority remains false.
