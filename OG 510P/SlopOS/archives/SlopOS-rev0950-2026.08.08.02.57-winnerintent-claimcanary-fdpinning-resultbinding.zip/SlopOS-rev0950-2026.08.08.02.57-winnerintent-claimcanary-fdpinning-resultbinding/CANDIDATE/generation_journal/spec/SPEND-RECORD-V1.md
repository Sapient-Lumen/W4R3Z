# `SLOPSP01` spend record v1

**Status:** canonical hosted identity grammar. The SHA-256 fields detect byte
change and bind names together; they do not authenticate a writer, prove
freshness, resist rollback, or make the record a capability.

The record is exactly 352 bytes. All integers are unsigned big-endian.

| bytes | width | field | rule |
|---|---:|---|---|
| 0..8 | 8 | magic | ASCII `SLOPSP01` |
| 8..10 | 2 | version | 1 |
| 10..12 | 2 | kind | 1, spend |
| 12..16 | 4 | length | 352 |
| 16..24 | 8 | owner epoch | positive |
| 24..32 | 8 | constructor epoch | positive |
| 32..40 | 8 | spend serial | positive within the named owner/constructor line |
| 40..48 | 8 | predecessor generation | `1 <= g < UINT64_MAX` |
| 48..56 | 8 | successor generation | exactly `g+1` |
| 56..88 | 32 | owner statement | nonzero digest |
| 88..120 | 32 | constructor image | nonzero digest |
| 120..152 | 32 | provider subject | nonzero digest |
| 152..184 | 32 | publication receipt | nonzero digest |
| 184..216 | 32 | expectation record | nonzero digest |
| 216..248 | 32 | operation | nonzero digest |
| 248..280 | 32 | pending result | nonzero digest |
| 280..312 | 32 | predecessor head | exact expected head, nonzero |
| 312..320 | 8 | reserved | zero |
| 320..352 | 32 | integrity | SHA-256(domain || bytes 0..320) |

The 32-byte integrity domain is the ASCII byte string
`SlopOS/spend/record/v1/integrity`. The successor head is:

```text
SHA-256("SlopOS/spend/record/v1/head" || 0x00 * 5 || complete_record)
```

The head deliberately commits to the integrity digest as well as every field.
The campaign includes two canonical records and rejects all 5,632 one-bit
mutations across them. This establishes the implemented grammar and its
mutation behavior only. A hostile writer can construct a different valid
record and recompute both hashes.

## Identity interpretation

A spend record names one proposed transition from exact floor point `(g, H)` to
`(g+1, SHA-256(record))`. It binds the owner statement, approved constructor,
provider subject, publication receipt, expectation, operation, and pending
result before the floor is advanced. A scalar generation is not a substitute
for any of these fields.

The record does not itself prove that the constructor was owner-approved or
that the provider subject is genuine. Those are verification obligations at
the future protected provider boundary.
