#include "slopos/epoch_zero/configured_pack_expectation.hpp"

#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <span>
#include <string>
#include <string_view>
#include <type_traits>
#include <utility>
#include <vector>

using namespace slopos::epoch_zero::pack;

namespace {

Bytes bytes(std::string_view text) {
  Bytes out;
  out.reserve(text.size());
  for (char c : text) {
    out.push_back(static_cast<Byte>(static_cast<unsigned char>(c)));
  }
  return out;
}

Digest test_digest(std::span<const Byte> input) {
  // Deterministic 256-bit test engine. It is intentionally not cryptographic;
  // production hosts must inject a reviewed digest implementation.
  std::array<std::uint64_t, 4> lanes{
      0xcbf29ce484222325ULL,
      0x84222325cbf29ce4ULL,
      0x9e3779b185ebca87ULL,
      0xd6e8feb86659fd93ULL,
  };
  constexpr std::uint64_t prime = 0x100000001b3ULL;
  for (std::size_t i = 0; i < input.size(); ++i) {
    const auto value = static_cast<std::uint64_t>(std::to_integer<unsigned int>(input[i]));
    for (std::size_t lane = 0; lane < lanes.size(); ++lane) {
      lanes[lane] ^= value + static_cast<std::uint64_t>(i + 1U) * (lane + 17U);
      lanes[lane] *= prime + lane * 2U;
      lanes[lane] = std::rotl(lanes[lane], static_cast<int>(7U + lane * 11U));
    }
  }
  Digest out{};
  for (std::size_t lane = 0; lane < lanes.size(); ++lane) {
    for (std::size_t i = 0; i < 8U; ++i) {
      out[lane * 8U + i] = static_cast<Byte>((lanes[lane] >> (i * 8U)) & 0xffU);
    }
  }
  return out;
}

Digest other_digest(std::span<const Byte> input) {
  auto out = test_digest(input);
  out[0] ^= Byte{0x5a};
  return out;
}

[[noreturn]] void fail(std::string_view message) {
  std::cerr << "FAIL: " << message << '\n';
  std::exit(1);
}

void require(bool condition, std::string_view message) {
  if (!condition) fail(message);
}

std::vector<SealedDescriptor> fixture_descriptors(const DigestFunction& digest = test_digest) {
  auto a = SealedDescriptor::seal("docs/mission.txt", bytes("recover truth, not authority\n"), digest);
  auto b = SealedDescriptor::seal("src/kernel.bin", bytes("epoch-zero-kernel-v1\n"), digest);
  require(static_cast<bool>(a), "fixture A must seal");
  require(static_cast<bool>(b), "fixture B must seal");
  std::vector<SealedDescriptor> descriptors;
  // Deliberately unsorted input; canonical_pack owns ordering.
  descriptors.push_back(std::move(b).take());
  descriptors.push_back(std::move(a).take());
  return descriptors;
}

ConfiguredPackVerifier configured_verifier(
    const std::vector<SealedDescriptor>& descriptors,
    Bytes* mutable_configuration = nullptr) {
  auto expectation = make_host_expectation(descriptors, test_digest);
  require(static_cast<bool>(expectation), "host expectation must build");
  auto config = encode_configured_expectation(expectation.value());
  auto verifier = ConfiguredPackVerifier::from_configured_bytes(config, test_digest);
  require(static_cast<bool>(verifier), "configured verifier must load");
  if (mutable_configuration != nullptr) {
    *mutable_configuration = std::move(config);
  }
  return std::move(verifier).take();
}

void test_exact_candidate_is_accepted() {
  auto descriptors = fixture_descriptors();
  auto pack = canonical_pack(descriptors);
  require(static_cast<bool>(pack), "canonical pack must build");
  auto verifier = configured_verifier(descriptors);
  const auto report = verifier.verify(descriptors, pack.value());
  require(report.accepted, "exact configured candidate must be accepted");
}

void test_producer_cannot_self_pin_existing_verifier() {
  auto configured = fixture_descriptors();
  auto verifier = configured_verifier(configured);

  auto producer_candidate = fixture_descriptors();
  auto replacement = SealedDescriptor::seal(
      "src/kernel.bin", bytes("producer-selected-replacement\n"), test_digest);
  require(static_cast<bool>(replacement), "replacement must seal");
  producer_candidate[0] = std::move(replacement).take();
  auto producer_pack = canonical_pack(producer_candidate);
  require(static_cast<bool>(producer_pack), "producer pack must build");

  // The producer can calculate a digest of its own bytes, but verify() has no
  // expectation parameter through which that digest could replace host state.
  const Digest self_pin = test_digest(producer_pack.value());
  (void)self_pin;
  const auto report = verifier.verify(producer_candidate, producer_pack.value());
  require(!report.accepted, "self-pinned replacement must not alter configured verifier");
  require(report.code == ErrorCode::descriptor_commitment_mismatch,
          "replacement must fail at configured descriptor commitment");
}

void test_config_buffer_is_copied_at_construction() {
  auto descriptors = fixture_descriptors();
  auto pack = canonical_pack(descriptors);
  require(static_cast<bool>(pack), "canonical pack must build");
  Bytes mutable_config;
  auto verifier = configured_verifier(descriptors, &mutable_config);
  for (auto& byte : mutable_config) byte ^= Byte{0xff};
  const auto report = verifier.verify(descriptors, pack.value());
  require(report.accepted, "later mutation of source config buffer must have no effect");
}

void test_seal_owns_observed_bytes() {
  Bytes caller_buffer = bytes("stable observation\n");
  auto sealed = SealedDescriptor::seal("obs/a", Bytes(caller_buffer), test_digest);
  require(static_cast<bool>(sealed), "observation must seal");
  for (auto& byte : caller_buffer) byte ^= Byte{0xff};
  std::vector<SealedDescriptor> descriptors;
  descriptors.push_back(std::move(sealed).take());
  auto pack = canonical_pack(descriptors);
  auto verifier = configured_verifier(descriptors);
  require(static_cast<bool>(pack), "owned observation pack must build");
  require(verifier.verify(descriptors, pack.value()).accepted,
          "mutating caller buffer must not mutate sealed observation");
}

void test_pack_mutation_is_rejected() {
  auto descriptors = fixture_descriptors();
  auto pack = canonical_pack(descriptors);
  require(static_cast<bool>(pack), "canonical pack must build");
  auto verifier = configured_verifier(descriptors);
  pack.value().back() ^= Byte{0x01};
  const auto report = verifier.verify(descriptors, pack.value());
  require(!report.accepted, "mutated pack must be rejected");
  require(report.code == ErrorCode::pack_not_exact_canonical_reconstruction,
          "mutation must fail exact reconstruction before digest comparison");
}

void test_duplicate_paths_are_rejected() {
  auto a = SealedDescriptor::seal("same/path", bytes("a"), test_digest);
  auto b = SealedDescriptor::seal("same/path", bytes("b"), test_digest);
  require(static_cast<bool>(a) && static_cast<bool>(b), "duplicate fixtures must seal alone");
  std::vector<SealedDescriptor> descriptors;
  descriptors.push_back(std::move(a).take());
  descriptors.push_back(std::move(b).take());
  const auto result = canonical_pack(descriptors);
  require(!result, "duplicate logical paths must fail canonicalization");
  require(result.error().code == ErrorCode::duplicate_logical_path,
          "duplicate failure must be typed");
}

void test_cross_engine_descriptor_is_rejected() {
  auto configured = fixture_descriptors();
  auto verifier = configured_verifier(configured);
  auto foreign = fixture_descriptors(other_digest);
  auto foreign_pack = canonical_pack(foreign);
  require(static_cast<bool>(foreign_pack), "foreign pack must build");
  const auto report = verifier.verify(foreign, foreign_pack.value());
  require(!report.accepted, "descriptor sealed under another engine must fail");
  require(report.code == ErrorCode::descriptor_digest_mismatch,
          "cross-engine failure must occur at sealed-byte check");
}

void test_malformed_configuration_is_rejected() {
  auto descriptors = fixture_descriptors();
  auto expectation = make_host_expectation(descriptors, test_digest);
  require(static_cast<bool>(expectation), "expectation must build");
  auto config = encode_configured_expectation(expectation.value());
  config.push_back(Byte{0});
  auto verifier = ConfiguredPackVerifier::from_configured_bytes(config, test_digest);
  require(!verifier, "configuration with trailing bytes must be rejected");
  require(verifier.error().code == ErrorCode::malformed_configuration,
          "malformed configuration failure must be typed");
}

void test_invalid_paths_are_rejected() {
  for (std::string_view path : {"", "/absolute", "a/../b", "a//b", "a\\b", "a/./b"}) {
    auto result = SealedDescriptor::seal(std::string(path), bytes("x"), test_digest);
    require(!result, "non-canonical path must fail sealing");
  }
}

}  // namespace

int main() {
  using VerifyMember = VerificationReport (ConfiguredPackVerifier::*)(
      std::span<const SealedDescriptor>, std::span<const Byte>) const;
  static_assert(std::is_same_v<decltype(&ConfiguredPackVerifier::verify), VerifyMember>,
                "verify API must not grow an expectation argument");

  test_exact_candidate_is_accepted();
  test_producer_cannot_self_pin_existing_verifier();
  test_config_buffer_is_copied_at_construction();
  test_seal_owns_observed_bytes();
  test_pack_mutation_is_rejected();
  test_duplicate_paths_are_rejected();
  test_cross_engine_descriptor_is_rejected();
  test_malformed_configuration_is_rejected();
  test_invalid_paths_are_rejected();
  std::cout << "rev0938 configured-pack expectation tests: PASS\n";
  return 0;
}
