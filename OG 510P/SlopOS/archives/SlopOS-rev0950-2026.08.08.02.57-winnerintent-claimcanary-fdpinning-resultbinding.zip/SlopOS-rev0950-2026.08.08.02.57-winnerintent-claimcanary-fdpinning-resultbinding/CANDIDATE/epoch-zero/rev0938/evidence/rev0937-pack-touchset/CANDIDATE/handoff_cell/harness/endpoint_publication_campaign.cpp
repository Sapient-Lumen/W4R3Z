#include "endpoint_publication_campaign.hpp"

#include "slopos/e0/handoff_cell/fixed_result_query.hpp"
#include "slopos/e0/handoff_cell/provider_endpoint.hpp"
#include "slopos/e0/handoff_cell/provider_expectation.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <dirent.h>
#include <filesystem>
#include <fstream>
#include <limits>
#include <poll.h>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <fcntl.h>
#include <grp.h>
#include <linux/close_range.h>
#include <linux/memfd.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef SO_PASSPIDFD
#define SO_PASSPIDFD 76
#endif
#ifndef SO_PEERPIDFD
#define SO_PEERPIDFD 77
#endif
#ifndef SCM_PIDFD
#define SCM_PIDFD 0x04
#endif

namespace slopos::e0::handoff_cell::harness {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

constexpr uid_t kPublisherUid = 0U;
constexpr gid_t kPublisherGid = 0U;
constexpr uid_t kProviderUid = 21001U;
constexpr gid_t kProviderGid = 21001U;
constexpr uid_t kWrongQueryUid = 21002U;
constexpr gid_t kWrongQueryGid = 21002U;
constexpr uid_t kQueryUid = 21003U;
constexpr gid_t kQueryGid = 21003U;

constexpr int kExecFd = 3;
constexpr int kRootFd = 4;
constexpr int kDirectoryFd = 5;
constexpr int kReportFd = 6;
constexpr int kExpectationRecordFd = 7;
constexpr int kExpectationPidfd = 8;
constexpr int kUnexpectedFd = 9;
constexpr int kAcceptTimeoutMilliseconds = 3000;
constexpr int kMessageTimeoutMilliseconds = 1000;
constexpr int kReportTimeoutMilliseconds = 5000;

constexpr std::size_t kRequestBytes = 16U;
constexpr std::size_t kResponseHeaderBytes = 16U;
constexpr std::size_t kResponseBytes =
    kResponseHeaderBytes + generation_journal::kRecordBytes;

constexpr std::uint8_t kResponseExact = 1U;
constexpr std::uint8_t kResponseRejectedRights = 2U;
constexpr std::uint8_t kResponseRejectedMalformed = 3U;

constexpr std::string_view kProviderWorker =
    "__slopos_e0_endpoint_provider_worker";
constexpr std::string_view kQueryWorker =
    "__slopos_e0_endpoint_query_worker";
constexpr std::string_view kMutationWorker =
    "__slopos_e0_endpoint_mutation_worker";
constexpr std::string_view kReplacementWorker =
    "__slopos_e0_endpoint_replacement_worker";

struct ScopedFd final {
    int value{-1};
    ScopedFd() = default;
    explicit ScopedFd(const int fd) noexcept : value(fd) {}
    ScopedFd(const ScopedFd&) = delete;
    ScopedFd& operator=(const ScopedFd&) = delete;
    ScopedFd(ScopedFd&& other) noexcept
        : value(std::exchange(other.value, -1)) {}
    ScopedFd& operator=(ScopedFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = std::exchange(other.value, -1);
        }
        return *this;
    }
    ~ScopedFd() { if (value >= 0) (void)::close(value); }
    [[nodiscard]] int get() const noexcept { return value; }
    [[nodiscard]] int release() noexcept { return std::exchange(value, -1); }
};

struct WorkerReport final {
    std::int32_t phase{0};
    std::int32_t role{0};
    std::int32_t mode{0};
    std::int32_t uid_ok{0};
    std::int32_t gid_ok{0};
    std::int32_t groups_empty{0};
    std::int32_t no_new_privs{0};
    std::int32_t capability_sets_zero{0};
    std::int32_t descriptor_topology_exact{0};
    std::int32_t connection_topology_exact{0};
    std::int32_t exec_fd_closed{0};
    std::int32_t root_fd_valid{0};
    std::int32_t directory_fd_valid{0};
    std::int32_t report_fd_valid{0};
    std::int32_t unexpected_fd_open{0};
    std::int32_t expectation_descriptors_present{0};
    std::int32_t expectation_imported{0};
    std::int32_t expectation_spent_before_connect{0};
    std::int32_t expected_process_match{0};
    std::uint64_t expectation_serial{0U};
    std::uint64_t expected_process_device{0U};
    std::uint64_t expected_process_inode{0U};
    std::int32_t bind_ok{0};
    std::int32_t bind_error{0};
    std::uint64_t first_device{0U};
    std::uint64_t first_inode{0U};
    std::uint64_t second_device{0U};
    std::uint64_t second_inode{0U};
    std::int32_t connect_ok{0};
    std::int32_t connect_error{0};
    std::int32_t peer_uid{-1};
    std::int32_t peer_gid{-1};
    std::uint64_t peer_process_device{0U};
    std::uint64_t peer_process_inode{0U};
    std::int32_t peer_process_alive_at_connect{0};
    std::int32_t peer_process_exit_observed{0};
    std::int32_t accepted_query_peer{0};
    std::int32_t accepted_wrong_peer{0};
    std::int32_t message_credentials_exact{0};
    std::int32_t message_process_identity_exact{0};
    std::int32_t message_pidfd_cloexec_exact{0};
    std::int32_t valid_requests{0};
    std::int32_t rights_received{0};
    std::int32_t rights_rejections{0};
    std::int32_t topology_restored_after_rights{0};
    std::int32_t malformed_rejections{0};
    std::int32_t fixed_query_disposition{-1};
    std::int32_t exact_response{0};
    std::int32_t response_credentials_exact{0};
    std::int32_t response_process_identity_exact{0};
    std::int32_t response_pidfd_cloexec_exact{0};
    std::int32_t wrong_peer_rejection_observed{0};
    std::int32_t unlink_result{0};
    std::int32_t unlink_error{0};
    std::int32_t rebind_ok{0};
    std::int32_t distinct_live_inodes{0};
    std::int32_t service_completed{0};
};

struct Message final {
    std::vector<std::uint8_t> bytes{};
    bool received{false};
    bool eof{false};
    bool truncated{false};
    bool control_truncated{false};
    bool credential_present{false};
    bool pidfd_present{false};
    bool pidfd_cloexec{false};
    bool unexpected_control{false};
    std::size_t credential_count{0U};
    std::size_t pidfd_count{0U};
    struct ucred credential{};
    EndpointProcessIdentity process{};
    std::vector<int> received_fds{};
    std::vector<int> received_pidfds{};
};

struct CaseRow final {
    std::string name;
    std::string observation;
    bool passed{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

struct StatIdentity final {
    std::uint64_t device{0U};
    std::uint64_t inode{0U};
    uid_t owner{0U};
    mode_t mode{0U};
    nlink_t links{0U};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

constexpr std::uint64_t kExpectationSerial = 8920001U;
constexpr int kExpectationSeals =
    F_SEAL_SEAL | F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE;

void store_u32(
    std::array<std::uint8_t, kProviderExpectationBytes>& bytes,
    const std::size_t offset, const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        bytes[offset + index] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(index * 8U)) & 0xffU);
    }
}

void store_u64(
    std::array<std::uint8_t, kProviderExpectationBytes>& bytes,
    const std::size_t offset, const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        bytes[offset + index] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(index * 8U)) & 0xffU);
    }
}

void pwrite_all(
    const int fd,
    const std::array<std::uint8_t, kProviderExpectationBytes>& bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::pwrite(
            fd, bytes.data() + offset, bytes.size() - offset,
            static_cast<off_t>(offset));
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "write provider expectation record");
        offset += static_cast<std::size_t>(count);
    }
}

struct ExpectationFixture final {
    ScopedFd record{};
    ScopedFd pidfd{};
    EndpointProcessIdentity process{};
    bool exact_seals{false};
    bool tamper_blocked{false};
    bool duplicate_pair_exact{false};
};

[[nodiscard]] ExpectationFixture make_expectation_fixture(
    const pid_t provider_pid) {
#if !defined(SYS_pidfd_open) || !defined(SYS_memfd_create)
    fail("pidfd_open or memfd_create syscall unavailable");
#else
    const long pidfd_result = ::syscall(SYS_pidfd_open, provider_pid, 0U);
    require(pidfd_result >= 0
                && pidfd_result <= static_cast<long>(
                    std::numeric_limits<int>::max()),
            "open provider pidfd for external expectation");
    ExpectationFixture fixture;
    fixture.pidfd = ScopedFd(static_cast<int>(pidfd_result));
    struct stat process_status {};
    require(::fstat(fixture.pidfd.get(), &process_status) == 0,
            "stat expected provider pidfd");
    fixture.process = {
        static_cast<std::uint64_t>(process_status.st_dev),
        static_cast<std::uint64_t>(process_status.st_ino)};
    require(fixture.process.valid(), "expected provider process identity");

    const long record_result = ::syscall(
        SYS_memfd_create, "slopos-e0-provider-expectation",
        static_cast<unsigned int>(MFD_CLOEXEC | MFD_ALLOW_SEALING));
    require(record_result >= 0
                && record_result <= static_cast<long>(
                    std::numeric_limits<int>::max()),
            "create external expectation memfd");
    fixture.record = ScopedFd(static_cast<int>(record_result));

    std::array<std::uint8_t, kProviderExpectationBytes> bytes{};
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'E', 'X', 'P', '1'}};
    std::copy(magic.begin(), magic.end(), bytes.begin());
    store_u32(bytes, 8U, 1U);
    store_u64(bytes, 16U, kExpectationSerial);
    store_u32(bytes, 24U, static_cast<std::uint32_t>(kProviderUid));
    store_u32(bytes, 28U, static_cast<std::uint32_t>(kProviderGid));
    store_u32(bytes, 32U, static_cast<std::uint32_t>(kQueryUid));
    store_u32(bytes, 36U, static_cast<std::uint32_t>(kQueryGid));
    store_u64(bytes, 40U, fixture.process.device);
    store_u64(bytes, 48U, fixture.process.inode);
    for (std::size_t index = 0U;
         index < kProviderExpectationBindingBytes; ++index) {
        bytes[56U + index] = static_cast<std::uint8_t>(0x80U + index);
    }
    pwrite_all(fixture.record.get(), bytes);
    require(::fcntl(fixture.record.get(), F_ADD_SEALS,
                    kExpectationSeals) == 0,
            "seal external expectation record");
    fixture.exact_seals = ::fcntl(
        fixture.record.get(), F_GET_SEALS) == kExpectationSeals;
    errno = 0;
    const std::uint8_t changed = static_cast<std::uint8_t>('X');
    const ssize_t tamper = ::pwrite(
        fixture.record.get(), &changed, sizeof(changed), 0);
    fixture.tamper_blocked = tamper < 0 && errno == EPERM;

    ScopedFd record_copy(::fcntl(
        fixture.record.get(), F_DUPFD_CLOEXEC, 64));
    ScopedFd pidfd_copy(::fcntl(
        fixture.pidfd.get(), F_DUPFD_CLOEXEC, 64));
    struct stat original_record {};
    struct stat copied_record {};
    struct stat copied_process {};
    fixture.duplicate_pair_exact = record_copy.get() >= 0
        && pidfd_copy.get() >= 0
        && ::fstat(fixture.record.get(), &original_record) == 0
        && ::fstat(record_copy.get(), &copied_record) == 0
        && ::fstat(pidfd_copy.get(), &copied_process) == 0
        && original_record.st_dev == copied_record.st_dev
        && original_record.st_ino == copied_record.st_ino
        && static_cast<std::uint64_t>(copied_process.st_dev)
            == fixture.process.device
        && static_cast<std::uint64_t>(copied_process.st_ino)
            == fixture.process.inode
        && ::fcntl(record_copy.get(), F_GET_SEALS) == kExpectationSeals;
    require(fixture.exact_seals && fixture.tamper_blocked
                && fixture.duplicate_pair_exact,
            "sealed expectation fixture invariants");
    return fixture;
#endif
}

[[nodiscard]] bool poll_readable(
    const int fd, const int timeout_milliseconds) noexcept {
    pollfd descriptor{fd, POLLIN | POLLHUP, 0};
    int result = -1;
    do {
        result = ::poll(&descriptor, 1U, timeout_milliseconds);
    } while (result < 0 && errno == EINTR);
    return result == 1
        && (descriptor.revents & static_cast<short>(POLLIN | POLLHUP)) != 0;
}

[[nodiscard]] bool send_packet(
    const int fd, const void* const data, const std::size_t size) noexcept {
    ssize_t count = -1;
    do {
        count = ::send(fd, data, size, MSG_NOSIGNAL);
    } while (count < 0 && errno == EINTR);
    return count == static_cast<ssize_t>(size);
}

[[nodiscard]] bool receive_packet(
    const int fd, void* const data, const std::size_t size,
    const int timeout_milliseconds) noexcept {
    if (!poll_readable(fd, timeout_milliseconds)) return false;
    ssize_t count = -1;
    do {
        count = ::recv(fd, data, size, 0);
    } while (count < 0 && errno == EINTR);
    return count == static_cast<ssize_t>(size);
}

void send_report_or_exit(
    const WorkerReport& report, const int code) noexcept {
    if (!send_packet(kReportFd, &report, sizeof(report))) _exit(code);
}

[[noreturn]] void final_report_and_exit(
    WorkerReport& report, const int exit_code) noexcept {
    report.phase = 2;
    const bool sent = send_packet(kReportFd, &report, sizeof(report));
    (void)::close(kReportFd);
    _exit(sent ? exit_code : 119);
}

[[nodiscard]] WorkerReport receive_report(
    const int fd, const std::string& label) {
    WorkerReport report;
    require(receive_packet(fd, &report, sizeof(report),
                           kReportTimeoutMilliseconds),
            "receive endpoint worker report " + label);
    return report;
}

[[nodiscard]] std::array<std::uint8_t, 32U> binding(
    const std::uint8_t base) noexcept {
    std::array<std::uint8_t, 32U> value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] EncodedRecord expected_result_v2() noexcept {
    Record record;
    record.kind = RecordKind::result;
    record.sequence = 2U;
    record.generation_from = 41U;
    record.generation_to = 42U;
    record.operation_binding = binding(1U);
    record.spent_receipt_binding = binding(161U);
    record.result = Result::effect;
    record.consumed_dispatch = true;
    record.reconciled = true;
    EncodedRecord encoded{};
    if (!generation_journal::encode_record(record, encoded)) encoded.fill(0U);
    return encoded;
}

[[nodiscard]] std::array<std::uint8_t, kRequestBytes>
exact_request() noexcept {
    std::array<std::uint8_t, kRequestBytes> request{};
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'E', 'P', 'Q', '1'}};
    std::copy(magic.begin(), magic.end(), request.begin());
    request[8U] = 1U;
    request[9U] = 2U;
    return request;
}

[[nodiscard]] bool request_is_exact(
    const std::vector<std::uint8_t>& bytes) noexcept {
    const auto expected = exact_request();
    return bytes.size() == expected.size()
        && std::equal(expected.begin(), expected.end(), bytes.begin());
}

[[nodiscard]] std::array<std::uint8_t, kResponseBytes> make_response(
    const std::uint8_t disposition,
    const EncodedRecord* const record = nullptr) noexcept {
    std::array<std::uint8_t, kResponseBytes> response{};
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'E', 'P', 'R', '1'}};
    std::copy(magic.begin(), magic.end(), response.begin());
    response[8U] = disposition;
    if (record != nullptr) {
        std::copy(record->begin(), record->end(),
                  response.begin() + static_cast<std::ptrdiff_t>(
                      kResponseHeaderBytes));
    }
    return response;
}

[[nodiscard]] bool response_is(
    const Message& message, const std::uint8_t disposition,
    const EncodedRecord* const expected = nullptr) noexcept {
    if (!message.received || message.eof || message.truncated
        || message.control_truncated
        || message.bytes.size() != kResponseBytes) {
        return false;
    }
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'E', 'P', 'R', '1'}};
    if (!std::equal(magic.begin(), magic.end(), message.bytes.begin())
        || message.bytes[8U] != disposition) {
        return false;
    }
    for (std::size_t index = 9U; index < kResponseHeaderBytes; ++index) {
        if (message.bytes[index] != 0U) return false;
    }
    const auto begin = message.bytes.begin()
        + static_cast<std::ptrdiff_t>(kResponseHeaderBytes);
    if (expected == nullptr) {
        return std::all_of(begin, message.bytes.end(),
                           [](const std::uint8_t value) {
                               return value == 0U;
                           });
    }
    return std::equal(expected->begin(), expected->end(), begin);
}

[[nodiscard]] Message receive_message(
    const int fd, const std::size_t maximum_bytes,
    const int timeout_milliseconds) noexcept {
    Message result;
    if (!poll_readable(fd, timeout_milliseconds)) return result;
    result.bytes.resize(maximum_bytes);
    std::array<std::uint8_t,
        CMSG_SPACE(sizeof(struct ucred)) + CMSG_SPACE(sizeof(int))
            + CMSG_SPACE(sizeof(int) * 8U)>
        control{};
    iovec vector{result.bytes.data(), result.bytes.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    ssize_t count = -1;
    do {
        count = ::recvmsg(fd, &header, MSG_CMSG_CLOEXEC);
    } while (count < 0 && errno == EINTR);
    if (count < 0) {
        result.bytes.clear();
        return result;
    }
    result.received = true;
    result.eof = count == 0;
    result.bytes.resize(static_cast<std::size_t>(count));
    result.truncated = (header.msg_flags & MSG_TRUNC) != 0;
    result.control_truncated = (header.msg_flags & MSG_CTRUNC) != 0;
    for (cmsghdr* item = CMSG_FIRSTHDR(&header); item != nullptr;
         item = CMSG_NXTHDR(&header, item)) {
        if (item->cmsg_level == SOL_SOCKET
            && item->cmsg_type == SCM_CREDENTIALS
            && item->cmsg_len == CMSG_LEN(sizeof(struct ucred))) {
            ++result.credential_count;
            if (result.credential_count != 1U) {
                result.unexpected_control = true;
                continue;
            }
            std::memcpy(&result.credential, CMSG_DATA(item),
                        sizeof(result.credential));
            result.credential_present = true;
        } else if (item->cmsg_level == SOL_SOCKET
                   && item->cmsg_type == SCM_PIDFD
                   && item->cmsg_len == CMSG_LEN(sizeof(int))) {
            int pidfd = -1;
            std::memcpy(&pidfd, CMSG_DATA(item), sizeof(pidfd));
            ++result.pidfd_count;
            if (pidfd < 0) {
                result.unexpected_control = true;
                continue;
            }
            result.received_pidfds.push_back(pidfd);
            if (result.pidfd_count != 1U) {
                result.unexpected_control = true;
                continue;
            }
            struct stat status {};
            const int flags = ::fcntl(pidfd, F_GETFD);
            if (::fstat(pidfd, &status) != 0 || flags < 0) {
                result.unexpected_control = true;
                continue;
            }
            result.process.device = static_cast<std::uint64_t>(status.st_dev);
            result.process.inode = static_cast<std::uint64_t>(status.st_ino);
            result.pidfd_cloexec = (flags & FD_CLOEXEC) != 0;
            result.pidfd_present = result.process.valid();
            if (!result.pidfd_present || !result.pidfd_cloexec) {
                result.unexpected_control = true;
            }
        } else if (item->cmsg_level == SOL_SOCKET
                   && item->cmsg_type == SCM_RIGHTS
                   && item->cmsg_len >= CMSG_LEN(sizeof(int))) {
            const std::size_t payload = item->cmsg_len - CMSG_LEN(0U);
            if (payload % sizeof(int) != 0U) {
                result.unexpected_control = true;
                continue;
            }
            const std::size_t descriptor_count = payload / sizeof(int);
            const auto* descriptors =
                reinterpret_cast<const int*>(CMSG_DATA(item));
            for (std::size_t index = 0U;
                 index < descriptor_count; ++index) {
                result.received_fds.push_back(descriptors[index]);
            }
        } else {
            result.unexpected_control = true;
        }
    }
    return result;
}

void close_received_fds(Message& message) noexcept {
    for (const int fd : message.received_fds) {
        if (fd >= 0) (void)::close(fd);
    }
    for (const int fd : message.received_pidfds) {
        if (fd >= 0) (void)::close(fd);
    }
    message.received_fds.clear();
    message.received_pidfds.clear();
}

[[nodiscard]] bool exact_sender(
    const Message& message, const uid_t uid, const gid_t gid) noexcept {
    return message.credential_present
        && message.credential_count == 1U
        && !message.unexpected_control
        && message.credential.uid == uid
        && message.credential.gid == gid;
}

[[nodiscard]] bool exact_process_sender(
    const Message& message,
    const EndpointProcessIdentity& expected) noexcept {
    return message.pidfd_present && message.pidfd_count == 1U
        && message.pidfd_cloexec && !message.unexpected_control
        && message.process == expected;
}

[[nodiscard]] bool send_with_rights(
    const int fd,
    const std::array<std::uint8_t, kRequestBytes>& request,
    const int sent_fd) noexcept {
    std::array<std::uint8_t, CMSG_SPACE(sizeof(int))> control{};
    iovec vector{const_cast<std::uint8_t*>(request.data()), request.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    cmsghdr* item = CMSG_FIRSTHDR(&header);
    if (item == nullptr) return false;
    item->cmsg_level = SOL_SOCKET;
    item->cmsg_type = SCM_RIGHTS;
    item->cmsg_len = CMSG_LEN(sizeof(int));
    std::memcpy(CMSG_DATA(item), &sent_fd, sizeof(sent_fd));
    ssize_t result = -1;
    do {
        result = ::sendmsg(fd, &header, MSG_NOSIGNAL);
    } while (result < 0 && errno == EINTR);
    return result == static_cast<ssize_t>(request.size());
}

[[nodiscard]] bool send_response(
    const int fd, const std::uint8_t disposition,
    const EncodedRecord* const record = nullptr) noexcept {
    const auto response = make_response(disposition, record);
    return send_packet(fd, response.data(), response.size());
}

[[nodiscard]] bool fd_is_open(const int fd) noexcept {
    errno = 0;
    return ::fcntl(fd, F_GETFD) >= 0 || errno != EBADF;
}

[[nodiscard]] bool fd_is_directory(
    const int fd, const uid_t owner, const mode_t mode) noexcept {
    struct stat status {};
    return ::fstat(fd, &status) == 0 && S_ISDIR(status.st_mode)
        && status.st_uid == owner
        && (status.st_mode & static_cast<mode_t>(0777)) == mode;
}

[[nodiscard]] bool fd_is_seqpacket(const int fd) noexcept {
    int type = 0;
    socklen_t length = sizeof(type);
    return ::getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &length) == 0
        && length == sizeof(type) && type == SOCK_SEQPACKET;
}

[[nodiscard]] std::set<int> descriptor_inventory() noexcept {
    std::set<int> result;
    DIR* directory = ::opendir("/proc/self/fd");
    if (directory == nullptr) return result;
    const int inventory_fd = ::dirfd(directory);
    for (;;) {
        errno = 0;
        dirent* entry = ::readdir(directory);
        if (entry == nullptr) break;
        std::string_view name(entry->d_name);
        int value = -1;
        const auto parsed = std::from_chars(
            name.data(), name.data() + name.size(), value);
        if (parsed.ec == std::errc{}
            && parsed.ptr == name.data() + name.size()
            && value != inventory_fd) {
            result.insert(value);
        }
    }
    (void)::closedir(directory);
    return result;
}

[[nodiscard]] bool descriptor_matches_process(
    const int fd, const EndpointProcessIdentity& expected) noexcept {
    struct stat status {};
    return expected.valid() && ::fstat(fd, &status) == 0
        && static_cast<std::uint64_t>(status.st_dev) == expected.device
        && static_cast<std::uint64_t>(status.st_ino) == expected.inode;
}

[[nodiscard]] bool connection_inventory_exact(
    const std::set<int>& inventory, const std::size_t expected_size,
    const int data_fd, const EndpointProcessIdentity& peer) noexcept {
    if (inventory.size() != expected_size
        || inventory.find(data_fd) == inventory.end()) {
        return false;
    }
    return std::count_if(
        inventory.begin(), inventory.end(),
        [&peer](const int fd) {
            return descriptor_matches_process(fd, peer);
        }) == 1;
}

[[nodiscard]] bool get_peer_process_identity(
    const int socket_fd, EndpointProcessIdentity& identity,
    int& pidfd) noexcept {
    pidfd = -1;
    socklen_t length = sizeof(pidfd);
    if (::getsockopt(socket_fd, SOL_SOCKET, SO_PEERPIDFD,
                     &pidfd, &length) != 0
        || length != sizeof(pidfd) || pidfd < 0) {
        if (pidfd >= 0) (void)::close(pidfd);
        pidfd = -1;
        return false;
    }
    struct stat status {};
    if (::fstat(pidfd, &status) != 0) {
        (void)::close(pidfd);
        pidfd = -1;
        return false;
    }
    identity.device = static_cast<std::uint64_t>(status.st_dev);
    identity.inode = static_cast<std::uint64_t>(status.st_ino);
    return identity.valid();
}

[[nodiscard]] bool enable_pidfd_messages(const int fd) noexcept {
    const int enabled = 1;
    return ::setsockopt(fd, SOL_SOCKET, SO_PASSCRED,
                        &enabled, sizeof(enabled)) == 0
        && ::setsockopt(fd, SOL_SOCKET, SO_PASSPIDFD,
                        &enabled, sizeof(enabled)) == 0;
}

[[nodiscard]] bool all_capability_sets_zero() noexcept {
    std::ifstream stream("/proc/self/status");
    if (!stream) return false;
    std::set<std::string> seen;
    std::string line;
    while (std::getline(stream, line)) {
        const auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        const std::string key = line.substr(0U, colon);
        if (key != "CapInh" && key != "CapPrm" && key != "CapEff"
            && key != "CapBnd" && key != "CapAmb") {
            continue;
        }
        const auto first = line.find_first_not_of(" \t", colon + 1U);
        if (first == std::string::npos) return false;
        const std::string value = line.substr(first);
        if (value.find_first_not_of("0\r") != std::string::npos) return false;
        seen.insert(key);
    }
    return seen.size() == 5U;
}

[[nodiscard]] WorkerReport base_report(
    const int role, const int mode, const uid_t expected_uid,
    const gid_t expected_gid, const bool root_required,
    const bool expectation_required, const uid_t directory_owner,
    const mode_t directory_mode) noexcept {
    WorkerReport report;
    report.phase = 1;
    report.role = role;
    report.mode = mode;
    uid_t real_uid = 0U;
    uid_t effective_uid = 0U;
    uid_t saved_uid = 0U;
    gid_t real_gid = 0U;
    gid_t effective_gid = 0U;
    gid_t saved_gid = 0U;
    report.uid_ok = ::getresuid(&real_uid, &effective_uid, &saved_uid) == 0
        && real_uid == expected_uid && effective_uid == expected_uid
        && saved_uid == expected_uid ? 1 : 0;
    report.gid_ok = ::getresgid(&real_gid, &effective_gid, &saved_gid) == 0
        && real_gid == expected_gid && effective_gid == expected_gid
        && saved_gid == expected_gid ? 1 : 0;
    report.groups_empty = ::getgroups(0, nullptr) == 0 ? 1 : 0;
    report.no_new_privs = ::prctl(
        PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L) == 1 ? 1 : 0;
    report.capability_sets_zero = all_capability_sets_zero() ? 1 : 0;
    report.exec_fd_closed = !fd_is_open(kExecFd) ? 1 : 0;
    report.root_fd_valid = root_required
        ? (fd_is_directory(kRootFd, kProviderUid,
                           static_cast<mode_t>(0700)) ? 1 : 0)
        : (!fd_is_open(kRootFd) ? 1 : 0);
    report.directory_fd_valid = fd_is_directory(
        kDirectoryFd, directory_owner, directory_mode) ? 1 : 0;
    report.report_fd_valid = fd_is_seqpacket(kReportFd) ? 1 : 0;
    report.unexpected_fd_open = fd_is_open(kUnexpectedFd) ? 1 : 0;
    report.expectation_descriptors_present = expectation_required
        ? (fd_is_open(kExpectationRecordFd)
           && fd_is_open(kExpectationPidfd) ? 1 : 0)
        : (!fd_is_open(kExpectationRecordFd)
           && !fd_is_open(kExpectationPidfd) ? 1 : 0);
    std::set<int> expected = root_required
        ? std::set<int>{0, 1, 2, kRootFd, kDirectoryFd, kReportFd}
        : std::set<int>{0, 1, 2, kDirectoryFd, kReportFd};
    if (expectation_required) {
        expected.insert(kExpectationRecordFd);
        expected.insert(kExpectationPidfd);
    }
    report.descriptor_topology_exact = descriptor_inventory() == expected
        ? 1 : 0;
    return report;
}

[[nodiscard]] StatIdentity stat_leaf(
    const int directory_fd, const char* const leaf) noexcept {
    StatIdentity identity;
    struct stat status {};
    if (::fstatat(directory_fd, leaf, &status,
                  AT_SYMLINK_NOFOLLOW) != 0) {
        return identity;
    }
    identity.device = static_cast<std::uint64_t>(status.st_dev);
    identity.inode = static_cast<std::uint64_t>(status.st_ino);
    identity.owner = status.st_uid;
    identity.mode = status.st_mode;
    identity.links = status.st_nlink;
    return identity;
}

[[nodiscard]] bool report_floor_exact(const WorkerReport& report) noexcept {
    return report.uid_ok == 1 && report.gid_ok == 1
        && report.groups_empty == 1 && report.no_new_privs == 1
        && report.capability_sets_zero == 1
        && report.descriptor_topology_exact == 1
        && report.exec_fd_closed == 1
        && report.root_fd_valid == 1
        && report.directory_fd_valid == 1
        && report.report_fd_valid == 1
        && report.expectation_descriptors_present == 1
        && report.unexpected_fd_open == 0;
}

[[nodiscard]] int provider_worker(const std::string_view mode) noexcept {
    const bool hold = mode == "hold";
    WorkerReport report = base_report(
        1, hold ? 2 : 1, kProviderUid, kProviderGid, true, false,
        kProviderUid, static_cast<mode_t>(0700));
    int error_number = 0;
    auto endpoint = ProviderEndpoint::bind_fixed_stage(
        kDirectoryFd, kProviderUid, kProviderGid, error_number);
    report.bind_ok = endpoint.has_value() ? 1 : 0;
    report.bind_error = error_number;
    const StatIdentity staged = stat_leaf(
        kDirectoryFd, kEndpointStageLeaf);
    report.first_device = staged.device;
    report.first_inode = staged.inode;
    if (!endpoint.has_value() || staged.inode == 0U) {
        final_report_and_exit(report, 40);
    }
    send_report_or_exit(report, 41);

    if (hold) {
        std::uint8_t release = 0U;
        if (!receive_packet(kReportFd, &release, sizeof(release),
                            kReportTimeoutMilliseconds)
            || release != static_cast<std::uint8_t>('X')) {
            final_report_and_exit(report, 42);
        }
        report.service_completed = 1;
        final_report_and_exit(report, 0);
    }

    int accept_error = 0;
    auto valid = endpoint->accept_next(
        kAcceptTimeoutMilliseconds, accept_error);
    if (!valid.has_value()) {
        report.bind_error = accept_error;
        final_report_and_exit(report, 43);
    }
    report.peer_uid = static_cast<std::int32_t>(valid->peer().uid);
    report.peer_gid = static_cast<std::int32_t>(valid->peer().gid);
    report.peer_process_device = valid->peer().process.device;
    report.peer_process_inode = valid->peer().process.inode;
    int liveness_error = 0;
    report.peer_process_alive_at_connect =
        !valid->peer_process_exited(0, liveness_error)
        && liveness_error == 0 ? 1 : 0;
    report.accepted_query_peer =
        valid->peer().uid == kQueryUid
        && valid->peer().gid == kQueryGid
        && valid->peer().process.valid() ? 1 : 0;
    const std::set<int> connected_inventory = descriptor_inventory();
    report.connection_topology_exact = connection_inventory_exact(
        connected_inventory, 9U, valid->native_fd(),
        valid->peer().process) ? 1 : 0;

    for (int index = 0; index < 3; ++index) {
        Message message = receive_message(
            valid->native_fd(), kRequestBytes,
            kMessageTimeoutMilliseconds);
        if (!message.received || message.eof) {
            close_received_fds(message);
            final_report_and_exit(report, 44);
        }
        const bool sender_exact = exact_sender(
            message, kQueryUid, kQueryGid);
        const bool process_exact = exact_process_sender(
            message, valid->peer().process);
        if (!sender_exact || !process_exact) {
            close_received_fds(message);
            final_report_and_exit(report, 45);
        }
        report.message_credentials_exact = 1;
        report.message_process_identity_exact = 1;
        report.message_pidfd_cloexec_exact =
            message.pidfd_cloexec ? 1 : 0;
        if (!message.received_fds.empty() || message.control_truncated
            || message.unexpected_control) {
            report.rights_received += static_cast<std::int32_t>(
                message.received_fds.size());
            close_received_fds(message);
            ++report.rights_rejections;
            report.topology_restored_after_rights =
                descriptor_inventory() == connected_inventory ? 1 : 0;
            if (!send_response(valid->native_fd(),
                               kResponseRejectedRights)) {
                final_report_and_exit(report, 46);
            }
            continue;
        }
        close_received_fds(message);
        if (message.truncated || !request_is_exact(message.bytes)) {
            ++report.malformed_rejections;
            if (!send_response(valid->native_fd(),
                               kResponseRejectedMalformed)) {
                final_report_and_exit(report, 47);
            }
            continue;
        }
        ++report.valid_requests;
        int query_error = 0;
        auto query = FixedResultQuery::open_fixed_beneath(
            kRootFd, kProviderUid, query_error);
        if (!query.has_value()) {
            report.fixed_query_disposition = -2;
            report.bind_error = query_error;
            final_report_and_exit(report, 48);
        }
        const FixedQueryResult result = query->read_exact_result_v2();
        report.fixed_query_disposition = static_cast<std::int32_t>(
            result.disposition);
        if (!result.exact()
            || !send_response(valid->native_fd(),
                              kResponseExact, &result.encoded)) {
            final_report_and_exit(report, 49);
        }
    }
    valid.reset();

    auto wrong = endpoint->accept_next(
        kAcceptTimeoutMilliseconds, accept_error);
    if (!wrong.has_value()) {
        report.bind_error = accept_error;
        final_report_and_exit(report, 50);
    }
    report.accepted_wrong_peer =
        wrong->peer().uid == kWrongQueryUid
        && wrong->peer().gid == kWrongQueryGid
        && wrong->peer().process.valid() ? 1 : 0;
    wrong.reset();
    report.service_completed = report.accepted_query_peer == 1
        && report.accepted_wrong_peer == 1
        && report.connection_topology_exact == 1 ? 1 : 0;
    final_report_and_exit(report,
                          report.service_completed == 1 ? 0 : 51);
}

[[nodiscard]] bool observe_closed_connection(const int fd) noexcept {
    if (!poll_readable(fd, kMessageTimeoutMilliseconds)) return false;
    std::array<std::uint8_t, 1U> byte{};
    ssize_t count = -1;
    do {
        count = ::recv(fd, byte.data(), byte.size(), 0);
    } while (count < 0 && errno == EINTR);
    return count == 0
        || (count < 0 && (errno == ECONNRESET || errno == EPIPE));
}

[[nodiscard]] int query_worker(const std::string_view mode) noexcept {
    const bool valid_mode = mode == "valid";
    const bool stale_mode = mode == "stale";
    const bool probe_mode = mode == "probe";
    const uid_t query_uid = valid_mode || stale_mode || probe_mode
        ? kQueryUid : kWrongQueryUid;
    const gid_t query_gid = valid_mode || stale_mode || probe_mode
        ? kQueryGid : kWrongQueryGid;
    WorkerReport report = base_report(
        2, valid_mode ? 1 : stale_mode ? 3 : probe_mode ? 4 : 2,
        query_uid, query_gid, false, valid_mode, kPublisherUid,
        static_cast<mode_t>(0711));
    int error_number = 0;
    std::optional<EndpointConnection> connection{};
    if (valid_mode) {
        const int record_flags = ::fcntl(kExpectationRecordFd, F_GETFD);
        const int process_flags = ::fcntl(kExpectationPidfd, F_GETFD);
        if (record_flags < 0 || process_flags < 0
            || ::fcntl(kExpectationRecordFd, F_SETFD,
                       record_flags | FD_CLOEXEC) != 0
            || ::fcntl(kExpectationPidfd, F_SETFD,
                       process_flags | FD_CLOEXEC) != 0) {
            final_report_and_exit(report, 59);
        }
        auto expectation = ExpectedProviderProcess::adopt_sealed(
            kExpectationRecordFd, kExpectationPidfd,
            query_uid, query_gid, kProviderUid, kProviderGid,
            error_number);
        report.expectation_imported = expectation.has_value() ? 1 : 0;
        if (!expectation.has_value()) {
            report.connect_error = error_number;
            final_report_and_exit(report, 60);
        }
        report.expectation_serial = expectation->view().serial;
        report.expected_process_device = expectation->view().process.device;
        report.expected_process_inode = expectation->view().process.inode;
        ExpectedProviderConnectResult expected_connection =
            connect_fixed_endpoint_expected(
                kDirectoryFd, query_uid, kPublisherUid,
                kProviderUid, kProviderGid,
                std::move(*expectation), error_number);
        report.expectation_spent_before_connect =
            expected_connection.expectation_spent_before_connect
            && !fd_is_open(kExpectationRecordFd)
            && !fd_is_open(kExpectationPidfd) ? 1 : 0;
        report.expected_process_match =
            expected_connection.expected_process.valid()
            && expected_connection.expected_process
                == expected_connection.observed_process ? 1 : 0;
        connection = std::move(expected_connection.connection);
    } else {
        connection = connect_fixed_endpoint(
            kDirectoryFd, query_uid, kPublisherUid,
            kProviderUid, kProviderGid, error_number);
    }
    report.connect_ok = connection.has_value() ? 1 : 0;
    report.connect_error = error_number;
    if (stale_mode) {
        report.service_completed = !connection.has_value()
            && error_number == ECONNREFUSED ? 1 : 0;
        final_report_and_exit(report,
                              report.service_completed == 1 ? 0 : 60);
    }
    if (!connection.has_value()) final_report_and_exit(report, 61);
    report.peer_uid = static_cast<std::int32_t>(connection->peer().uid);
    report.peer_gid = static_cast<std::int32_t>(connection->peer().gid);
    report.peer_process_device = connection->peer().process.device;
    report.peer_process_inode = connection->peer().process.inode;
    int liveness_error = 0;
    report.peer_process_alive_at_connect =
        !connection->peer_process_exited(0, liveness_error)
        && liveness_error == 0 ? 1 : 0;
    report.connection_topology_exact = connection_inventory_exact(
        descriptor_inventory(), 7U, connection->native_fd(),
        connection->peer().process) ? 1 : 0;
    if (probe_mode) {
        report.service_completed = report.peer_process_alive_at_connect == 1
            && report.connection_topology_exact == 1 ? 1 : 0;
        final_report_and_exit(report,
                              report.service_completed == 1 ? 0 : 69);
    }

    const auto request = exact_request();
    if (!send_packet(connection->native_fd(),
                     request.data(), request.size())) {
        if (!valid_mode && (errno == EPIPE || errno == ECONNRESET)) {
            report.wrong_peer_rejection_observed = 1;
            report.service_completed = 1;
            final_report_and_exit(report, 0);
        }
        final_report_and_exit(report, 62);
    }
    if (!valid_mode) {
        report.wrong_peer_rejection_observed =
            observe_closed_connection(connection->native_fd()) ? 1 : 0;
        report.service_completed =
            report.wrong_peer_rejection_observed;
        final_report_and_exit(report,
                              report.service_completed == 1 ? 0 : 63);
    }

    Message exact = receive_message(
        connection->native_fd(), kResponseBytes,
        kMessageTimeoutMilliseconds);
    const EncodedRecord expected = expected_result_v2();
    report.exact_response = response_is(
        exact, kResponseExact, &expected) ? 1 : 0;
    report.response_credentials_exact = exact_sender(
        exact, kProviderUid, kProviderGid) ? 1 : 0;
    report.response_process_identity_exact = exact_process_sender(
        exact, connection->peer().process) ? 1 : 0;
    report.response_pidfd_cloexec_exact = exact.pidfd_cloexec ? 1 : 0;
    close_received_fds(exact);
    if (report.exact_response != 1
        || report.response_credentials_exact != 1
        || report.response_process_identity_exact != 1
        || report.response_pidfd_cloexec_exact != 1) {
        final_report_and_exit(report, 64);
    }

    if (!send_with_rights(connection->native_fd(), request, 0)) {
        final_report_and_exit(report, 65);
    }
    Message rights = receive_message(
        connection->native_fd(), kResponseBytes,
        kMessageTimeoutMilliseconds);
    const bool rights_ok = response_is(
        rights, kResponseRejectedRights)
        && exact_sender(rights, kProviderUid, kProviderGid)
        && exact_process_sender(rights, connection->peer().process)
        && rights.received_fds.empty();
    close_received_fds(rights);
    if (!rights_ok) final_report_and_exit(report, 66);

    const std::uint8_t malformed = 0x51U;
    if (!send_packet(connection->native_fd(),
                     &malformed, sizeof(malformed))) {
        final_report_and_exit(report, 67);
    }
    Message malformed_response = receive_message(
        connection->native_fd(), kResponseBytes,
        kMessageTimeoutMilliseconds);
    const bool malformed_ok = response_is(
        malformed_response, kResponseRejectedMalformed)
        && exact_sender(malformed_response, kProviderUid, kProviderGid)
        && exact_process_sender(
            malformed_response, connection->peer().process)
        && malformed_response.received_fds.empty();
    close_received_fds(malformed_response);
    if (!malformed_ok) final_report_and_exit(report, 68);

    send_report_or_exit(report, 70);
    int exit_error = 0;
    report.peer_process_exit_observed =
        connection->peer_process_exited(
            kReportTimeoutMilliseconds, exit_error)
        && exit_error == 0 ? 1 : 0;
    report.service_completed = report.peer_process_exit_observed == 1
        && report.connection_topology_exact == 1 ? 1 : 0;
    final_report_and_exit(report,
                          report.service_completed == 1 ? 0 : 71);
}

[[nodiscard]] int mutation_worker() noexcept {
    WorkerReport report = base_report(
        3, 1, kProviderUid, kProviderGid, false, false,
        kPublisherUid, static_cast<mode_t>(0711));
    errno = 0;
    const int result = ::unlinkat(
        kDirectoryFd, kEndpointPublicLeaf, 0);
    report.unlink_result = result;
    report.unlink_error = result == 0 ? 0 : errno;
    report.service_completed = result != 0
        && (report.unlink_error == EACCES
            || report.unlink_error == EPERM) ? 1 : 0;
    final_report_and_exit(report,
                          report.service_completed == 1 ? 0 : 70);
}

[[nodiscard]] int raw_bind_public_leaf() noexcept {
    std::array<char, sizeof(sockaddr_un::sun_path)> path{};
    const int written = std::snprintf(
        path.data(), path.size(), "/proc/self/fd/%d/%s",
        kDirectoryFd, kEndpointPublicLeaf);
    if (written < 0
        || static_cast<std::size_t>(written) >= path.size()) {
        errno = ENAMETOOLONG;
        return -1;
    }
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    const std::size_t path_length = std::strlen(path.data());
    std::memcpy(address.sun_path, path.data(), path_length + 1U);
    const std::size_t address_size = offsetof(sockaddr_un, sun_path)
        + path_length + 1U;
    if (address_size > static_cast<std::size_t>(
            std::numeric_limits<socklen_t>::max())) {
        errno = EOVERFLOW;
        return -1;
    }
    const int fd = ::socket(
        AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0);
    if (fd < 0) return -1;
    if (::bind(fd, reinterpret_cast<const sockaddr*>(&address),
               static_cast<socklen_t>(address_size)) != 0
        || ::listen(fd, 1) != 0) {
        const int observed = errno;
        (void)::close(fd);
        errno = observed;
        return -1;
    }
    return fd;
}

[[nodiscard]] int replacement_worker() noexcept {
    WorkerReport report = base_report(
        4, 1, kProviderUid, kProviderGid, false, false,
        kProviderUid, static_cast<mode_t>(0700));
    ScopedFd first(raw_bind_public_leaf());
    if (first.get() < 0) final_report_and_exit(report, 80);
    const StatIdentity first_identity = stat_leaf(
        kDirectoryFd, kEndpointPublicLeaf);
    report.first_device = first_identity.device;
    report.first_inode = first_identity.inode;
    errno = 0;
    report.unlink_result = ::unlinkat(
        kDirectoryFd, kEndpointPublicLeaf, 0);
    report.unlink_error = report.unlink_result == 0 ? 0 : errno;
    if (report.unlink_result != 0) final_report_and_exit(report, 81);
    ScopedFd second(raw_bind_public_leaf());
    if (second.get() < 0) final_report_and_exit(report, 82);
    const StatIdentity second_identity = stat_leaf(
        kDirectoryFd, kEndpointPublicLeaf);
    report.second_device = second_identity.device;
    report.second_inode = second_identity.inode;
    report.rebind_ok = second_identity.inode != 0U ? 1 : 0;
    report.distinct_live_inodes =
        first_identity.device == second_identity.device
        && first_identity.inode != second_identity.inode ? 1 : 0;
    report.service_completed = report.rebind_ok == 1
        && report.distinct_live_inodes == 1 ? 1 : 0;
    final_report_and_exit(report,
                          report.service_completed == 1 ? 0 : 83);
}

struct SocketpairPidfdResult final {
    bool peer_pidfd_is_creator{false};
    bool message_pidfd_is_sender{false};
    bool identities_are_distinct{false};
};

[[nodiscard]] SocketpairPidfdResult
socketpair_pidfd_counterexample() {
    int pair[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         pair) == 0,
            "pidfd counterexample socketpair");
    ScopedFd parent_end(pair[0]);
    ScopedFd child_end(pair[1]);
    require(enable_pidfd_messages(parent_end.get()),
            "enable pidfd messages on socketpair");
    EndpointProcessIdentity creator_before{};
    int creator_before_fd = -1;
    require(get_peer_process_identity(
                parent_end.get(), creator_before, creator_before_fd),
            "observe socketpair creator pidfd before fork");
    ScopedFd creator_before_guard(creator_before_fd);

    const pid_t child = ::fork();
    require(child >= 0, "fork socketpair pidfd sender");
    if (child == 0) {
        (void)::close(parent_end.get());
        const std::uint8_t byte = static_cast<std::uint8_t>('P');
        _exit(send_packet(child_end.get(), &byte, sizeof(byte)) ? 0 : 120);
    }
    child_end = ScopedFd{};
    EndpointProcessIdentity creator_after{};
    int creator_after_fd = -1;
    require(get_peer_process_identity(
                parent_end.get(), creator_after, creator_after_fd),
            "observe socketpair creator pidfd after fork");
    ScopedFd creator_after_guard(creator_after_fd);
    Message message = receive_message(
        parent_end.get(), 1U, kMessageTimeoutMilliseconds);
    const bool message_sender = message.received && !message.eof
        && message.bytes.size() == 1U
        && message.bytes[0U] == static_cast<std::uint8_t>('P')
        && message.credential_present
        && message.credential.pid == child
        && message.pidfd_present;
    SocketpairPidfdResult result;
    result.peer_pidfd_is_creator = creator_before.valid()
        && creator_before == creator_after;
    result.message_pidfd_is_sender = message_sender;
    result.identities_are_distinct = message_sender
        && !(message.process == creator_after);
    close_received_fds(message);
    int status = 0;
    require(::waitpid(child, &status, 0) == child,
            "wait socketpair pidfd sender");
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "socketpair pidfd sender succeeded");
    return result;
}

[[nodiscard]] int duplicate_high(const int fd) noexcept {
    return ::fcntl(fd, F_DUPFD_CLOEXEC, 64);
}

void duplicate_fixed_or_exit(
    const int source, const int destination,
    const int flags, const int code) noexcept {
    if (::dup3(source, destination, flags) < 0) _exit(code);
}

void drop_bounding_set_or_exit() noexcept {
    for (int capability = 0; capability < 1024; ++capability) {
        errno = 0;
        const int present = ::prctl(
            PR_CAPBSET_READ,
            static_cast<unsigned long>(capability),
            0UL, 0UL, 0UL);
        if (present < 0 && errno == EINVAL) return;
        if (present < 0) _exit(90);
        if (present == 1
            && ::prctl(PR_CAPBSET_DROP,
                       static_cast<unsigned long>(capability),
                       0UL, 0UL, 0UL) != 0) {
            _exit(91);
        }
    }
    _exit(92);
}

void launch_child_or_exit(
    const std::string_view worker, const std::string_view mode,
    const int root_fd, const int directory_fd, const int report_fd,
    const int expectation_record_fd, const int expectation_pidfd,
    const uid_t uid, const gid_t gid) noexcept {
    const int executable = ::open("/proc/self/exe", O_PATH | O_CLOEXEC);
    if (executable < 0) _exit(93);
    const int executable_high = duplicate_high(executable);
    const int root_high = root_fd >= 0 ? duplicate_high(root_fd) : -1;
    const int directory_high = duplicate_high(directory_fd);
    const int report_high = duplicate_high(report_fd);
    const bool expectation_supplied = expectation_record_fd >= 0
        && expectation_pidfd >= 0;
    if ((expectation_record_fd >= 0) != (expectation_pidfd >= 0)) _exit(94);
    const int expectation_record_high = expectation_supplied
        ? duplicate_high(expectation_record_fd) : -1;
    const int expectation_pidfd_high = expectation_supplied
        ? duplicate_high(expectation_pidfd) : -1;
    const int null_high = ::open("/dev/null", O_RDWR | O_CLOEXEC);
    if (executable_high < 0 || (root_fd >= 0 && root_high < 0)
        || directory_high < 0 || report_high < 0 || null_high < 0
        || (expectation_supplied
            && (expectation_record_high < 0 || expectation_pidfd_high < 0))) {
        _exit(94);
    }
    duplicate_fixed_or_exit(null_high, 0, 0, 95);
    duplicate_fixed_or_exit(null_high, 1, 0, 96);
    duplicate_fixed_or_exit(null_high, 2, 0, 97);
    duplicate_fixed_or_exit(executable_high, kExecFd, O_CLOEXEC, 98);
    if (root_fd >= 0) {
        duplicate_fixed_or_exit(root_high, kRootFd, 0, 99);
    } else if (::close(kRootFd) != 0 && errno != EBADF) {
        _exit(100);
    }
    duplicate_fixed_or_exit(directory_high, kDirectoryFd, 0, 101);
    duplicate_fixed_or_exit(report_high, kReportFd, 0, 102);
    if (expectation_supplied) {
        duplicate_fixed_or_exit(
            expectation_record_high, kExpectationRecordFd, 0, 110);
        duplicate_fixed_or_exit(
            expectation_pidfd_high, kExpectationPidfd, 0, 111);
    } else {
        if (::close(kExpectationRecordFd) != 0 && errno != EBADF) _exit(112);
        if (::close(kExpectationPidfd) != 0 && errno != EBADF) _exit(113);
    }
#if defined(SYS_close_range)
    if (::syscall(SYS_close_range, 9U, ~0U,
                  static_cast<unsigned int>(CLOSE_RANGE_UNSHARE)) != 0) {
        _exit(103);
    }
#else
    _exit(104);
#endif
    (void)::umask(0077);
    drop_bounding_set_or_exit();
    if (::setgroups(0U, nullptr) != 0) _exit(105);
    if (::setresgid(gid, gid, gid) != 0) _exit(106);
    if (::setresuid(uid, uid, uid) != 0) _exit(107);
    if (::prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) != 0) _exit(108);

    std::string worker_text(worker);
    std::string mode_text(mode);
    std::array<char*, 4U> arguments{{
        const_cast<char*>("slopos_handoff_cell"),
        worker_text.data(), mode_text.data(), nullptr}};
    std::array<char*, 1U> environment{{nullptr}};
#if defined(SYS_execveat)
    (void)::syscall(SYS_execveat, kExecFd, "", arguments.data(),
                    environment.data(), AT_EMPTY_PATH);
#endif
    _exit(109);
}

[[nodiscard]] pid_t fork_worker(
    const std::string_view worker, const std::string_view mode,
    const int root_fd, const int directory_fd, const int report_fd,
    const int expectation_record_fd, const int expectation_pidfd,
    const uid_t uid, const gid_t gid) {
    const pid_t child = ::fork();
    require(child >= 0, "fork endpoint-publication worker");
    if (child == 0) {
        launch_child_or_exit(worker, mode, root_fd, directory_fd,
                             report_fd, expectation_record_fd,
                             expectation_pidfd, uid, gid);
    }
    return child;
}

void wait_success(const pid_t child, const std::string& label) {
    int status = 0;
    require(::waitpid(child, &status, 0) == child,
            "wait endpoint worker " + label);
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "endpoint worker exit " + label
                + " status=" + std::to_string(status));
}

void create_owned_directory(
    const std::filesystem::path& path, const uid_t uid,
    const gid_t gid, const mode_t mode) {
    require(std::filesystem::create_directory(path),
            "create endpoint directory " + path.string());
    require(::chown(path.c_str(), uid, gid) == 0,
            "chown endpoint directory " + path.string());
    require(::chmod(path.c_str(), mode) == 0,
            "chmod endpoint directory " + path.string());
}

[[nodiscard]] ScopedFd open_directory(
    const std::filesystem::path& path) {
    const int fd = ::open(path.c_str(),
                          O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    require(fd >= 0, "open endpoint directory " + path.string());
    return ScopedFd(fd);
}

struct SingleWorker final {
    pid_t pid{-1};
    ScopedFd report{};
};

[[nodiscard]] SingleWorker launch_single(
    const std::string_view worker, const std::string_view mode,
    const int root_fd, const int directory_fd,
    const uid_t uid, const gid_t gid,
    const int expectation_record_fd = -1,
    const int expectation_pidfd = -1) {
    int report_pair[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         report_pair) == 0,
            "endpoint report socketpair");
    const pid_t child = fork_worker(
        worker, mode, root_fd, directory_fd, report_pair[1],
        expectation_record_fd, expectation_pidfd, uid, gid);
    require(::close(report_pair[1]) == 0,
            "close endpoint child report in parent");
    return {child, ScopedFd(report_pair[0])};
}

[[nodiscard]] WorkerReport finish_single(
    SingleWorker& worker, const std::string& label) {
    const WorkerReport report = receive_report(worker.report.get(), label);
    worker.report = ScopedFd{};
    wait_success(worker.pid, label);
    return report;
}

void write_rows(
    const std::filesystem::path& output,
    const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "endpoint-publication-cases.tsv",
                         std::ios::binary);
    require(stream.good(), "open endpoint-publication-cases.tsv");
    stream << "name\tobservation\tpassed\tretained_counterexample"
              "\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << row.observation << '\t'
               << bool_text(row.passed) << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
    require(stream.good(), "write endpoint-publication-cases.tsv");
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "endpoint-publication-counterexamples.tsv",
        std::ios::binary);
    require(stream.good(),
            "open endpoint-publication-counterexamples.tsv");
    stream << "name\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
    require(stream.good(),
            "write endpoint-publication-counterexamples.tsv");
}

void write_summary(
    const std::filesystem::path& output, const std::size_t cases,
    const std::size_t counterexamples) {
    std::ofstream stream(
        output / "endpoint-publication-summary.json", std::ios::binary);
    require(stream.good(), "open endpoint-publication-summary.json");
    stream
        << "{\n"
        << "  \"administration_plane_closed\": false,\n"
        << "  \"authority_granted\": false,\n"
        << "  \"automatic_endpoint_cleanup_entrypoints\": 0,\n"
        << "  \"cases\": " << cases << ",\n"
        << "  \"connect_time_so_peercred_observed\": true,\n"
        << "  \"connect_time_so_peerpidfd_observed\": true,\n"
        << "  \"expected_process_match_required\": true,\n"
        << "  \"expectation_capsule_duplicate_counterexample\": true,\n"
        << "  \"expectation_constructor_protected\": false,\n"
        << "  \"expectation_record_bytes\": 96,\n"
        << "  \"expectation_record_exact_seals\": true,\n"
        << "  \"expectation_spent_before_connect\": true,\n"
        << "  \"externally_supplied_process_expectation_observed\": true,\n"
        << "  \"globally_unique_expectation_spend_proved\": false,\n"
        << "  \"counterexamples_reproduced\": "
        << counterexamples << ",\n"
        << "  \"endpoint_bind_after_final_principal\": true,\n"
        << "  \"fixed_public_leaf\": \"query.sock\",\n"
        << "  \"fixed_stage_leaf\": \"bound.sock\",\n"
        << "  \"independent_actor\": false,\n"
        << "  \"inherited_query_data_socket\": false,\n"
        << "  \"per_message_scm_pidfd_observed\": true,\n"
        << "  \"peer_pidfd_exit_observed\": true,\n"
        << "  \"owner_admission_authenticated\": false,\n"
        << "  \"pidfd_process_instance_authenticated\": false,\n"
        << "  \"privileged_publisher_can_replace\": true,\n"
        << "  \"process_descriptor_exported_to_caller\": false,\n"
        << "  \"provider_epoch_admitted\": false,\n"
        << "  \"provider_can_mutate_public_directory\": false,\n"
        << "  \"provider_uid\": " << kProviderUid << ",\n"
        << "  \"publisher_uid\": " << kPublisherUid << ",\n"
        << "  \"query_uid\": " << kQueryUid << ",\n"
        << "  \"rename_flag\": \"RENAME_NOREPLACE\",\n"
        << "  \"replacement_process_identity_distinct\": true,\n"
        << "  \"same_uid_writable_directory_replacement_reproduced\": true,\n"
        << "  \"schema\": \"slopos.rev0892.endpoint-process-expectation-evidence.v2\",\n"
        << "  \"sealed_self_assertion_counterexample_reproduced\": true,\n"
        << "  \"socketpair_creator_sender_counterexample_reproduced\": true,\n"
        << "  \"source_to_binary_proved\": false,\n"
        << "  \"stable_endpoint_epoch_proved\": false,\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"stale_public_leaf_blocks_noreplace_restart\": true,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"wrong_query_uid\": " << kWrongQueryUid << "\n"
        << "}\n";
    require(stream.good(), "write endpoint-publication-summary.json");
}

}  // namespace

bool is_internal_endpoint_publication_worker(
    const int argc, char** argv) noexcept {
    if (argc != 3 || argv == nullptr || argv[1] == nullptr) return false;
    const std::string_view worker(argv[1]);
    return worker == kProviderWorker || worker == kQueryWorker
        || worker == kMutationWorker || worker == kReplacementWorker;
}

int run_internal_endpoint_publication_worker(
    const int argc, char** argv) noexcept {
    if (!is_internal_endpoint_publication_worker(argc, argv)) return 2;
    const std::string_view worker(argv[1]);
    const std::string_view mode(argv[2] == nullptr ? "" : argv[2]);
    if (worker == kProviderWorker) return provider_worker(mode);
    if (worker == kQueryWorker) return query_worker(mode);
    if (worker == kMutationWorker) return mutation_worker();
    if (worker == kReplacementWorker) return replacement_worker();
    return 2;
}

EndpointPublicationCampaignCounts run_endpoint_publication_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch) {
    require(::geteuid() == kPublisherUid && ::getegid() == kPublisherGid,
            "endpoint campaign requires root publisher principal");
    const SocketpairPidfdResult socketpair_pidfd =
        socketpair_pidfd_counterexample();
    require(socketpair_pidfd.peer_pidfd_is_creator
            && socketpair_pidfd.message_pidfd_is_sender
            && socketpair_pidfd.identities_are_distinct,
            "socketpair pidfd creation-time counterexample");
    const std::filesystem::path provider_root_path =
        scratch / "principal" / "vertical";
    const ScopedFd provider_root = open_directory(provider_root_path);

    const std::filesystem::path base = scratch / "endpoint-publication";
    require(std::filesystem::create_directory(base),
            "create endpoint-publication scratch");
    const auto stage_path = base / "stage";
    const auto public_path = base / "public";
    const auto fresh_stage_path = base / "fresh-stage";
    const auto replaceable_path = base / "provider-owned-public";
    create_owned_directory(stage_path, kProviderUid, kProviderGid,
                           static_cast<mode_t>(0700));
    create_owned_directory(public_path, kPublisherUid, kPublisherGid,
                           static_cast<mode_t>(0711));
    create_owned_directory(fresh_stage_path, kProviderUid, kProviderGid,
                           static_cast<mode_t>(0700));
    create_owned_directory(replaceable_path, kProviderUid, kProviderGid,
                           static_cast<mode_t>(0700));
    const ScopedFd stage = open_directory(stage_path);
    const ScopedFd public_directory = open_directory(public_path);
    const ScopedFd fresh_stage = open_directory(fresh_stage_path);
    const ScopedFd replaceable = open_directory(replaceable_path);

    SingleWorker provider = launch_single(
        kProviderWorker, "serve", provider_root.get(), stage.get(),
        kProviderUid, kProviderGid);
    const WorkerReport provider_ready = receive_report(
        provider.report.get(), "provider-ready");
    require(provider_ready.phase == 1 && provider_ready.bind_ok == 1,
            "provider ready after staged bind");
    ExpectationFixture provider_expectation =
        make_expectation_fixture(provider.pid);
    const StatIdentity staged = stat_leaf(
        stage.get(), kEndpointStageLeaf);
    require(staged.inode != 0U && S_ISSOCK(staged.mode)
            && staged.owner == kProviderUid
            && (staged.mode & static_cast<mode_t>(0777))
                == static_cast<mode_t>(0222),
            "staged endpoint exact shape");
    const EndpointPublishResult published =
        publish_fixed_endpoint_noreplace(
            stage.get(), public_directory.get(),
            kProviderUid, kPublisherUid);
    require(published.namespace_published(),
            "publish staged endpoint no-replace");
    const StatIdentity public_first = stat_leaf(
        public_directory.get(), kEndpointPublicLeaf);
    require(public_first.device == staged.device
            && public_first.inode == staged.inode,
            "same socket inode published");
    require(stat_leaf(stage.get(), kEndpointStageLeaf).inode == 0U,
            "stage leaf absent after publication");

    SingleWorker mutation = launch_single(
        kMutationWorker, "deny", -1, public_directory.get(),
        kProviderUid, kProviderGid);
    const WorkerReport mutation_report = finish_single(
        mutation, "provider-public-mutation");

    SingleWorker valid_query = launch_single(
        kQueryWorker, "valid", -1, public_directory.get(),
        kQueryUid, kQueryGid, provider_expectation.record.get(),
        provider_expectation.pidfd.get());
    const WorkerReport valid_query_ready = receive_report(
        valid_query.report.get(), "valid-query-ready");
    require(valid_query_ready.phase == 1
            && valid_query_ready.exact_response == 1,
            "valid query ready before provider exit");

    SingleWorker wrong_query = launch_single(
        kQueryWorker, "wrong", -1, public_directory.get(),
        kWrongQueryUid, kWrongQueryGid);
    const WorkerReport wrong_query_report = finish_single(
        wrong_query, "wrong-query");

    const WorkerReport provider_final = receive_report(
        provider.report.get(), "provider-final");
    provider.report = ScopedFd{};
    wait_success(provider.pid, "provider");
    const WorkerReport valid_query_report = receive_report(
        valid_query.report.get(), "valid-query-final");
    valid_query.report = ScopedFd{};
    wait_success(valid_query.pid, "valid-query");
    const StatIdentity stale = stat_leaf(
        public_directory.get(), kEndpointPublicLeaf);
    require(stale.device == public_first.device
            && stale.inode == public_first.inode,
            "provider death leaves public socket inode");

    SingleWorker stale_query = launch_single(
        kQueryWorker, "stale", -1, public_directory.get(),
        kQueryUid, kQueryGid);
    const WorkerReport stale_query_report = finish_single(
        stale_query, "stale-query");

    SingleWorker fresh_provider = launch_single(
        kProviderWorker, "hold", provider_root.get(), fresh_stage.get(),
        kProviderUid, kProviderGid);
    const WorkerReport fresh_ready = receive_report(
        fresh_provider.report.get(), "fresh-provider-ready");
    require(fresh_ready.phase == 1 && fresh_ready.bind_ok == 1,
            "fresh provider staged bind");
    const StatIdentity fresh_staged = stat_leaf(
        fresh_stage.get(), kEndpointStageLeaf);
    require(fresh_staged.inode != 0U,
            "fresh staged endpoint exists");
    const EndpointPublishResult collision =
        publish_fixed_endpoint_noreplace(
            fresh_stage.get(), public_directory.get(),
            kProviderUid, kPublisherUid);
    const StatIdentity public_after_collision = stat_leaf(
        public_directory.get(), kEndpointPublicLeaf);
    const StatIdentity stage_after_collision = stat_leaf(
        fresh_stage.get(), kEndpointStageLeaf);
    require(collision.disposition
                == EndpointPublishDisposition::public_exists
            && collision.error_number == EEXIST,
            "stale public endpoint blocks no-replace publication");
    require(public_after_collision.device == stale.device
            && public_after_collision.inode == stale.inode
            && stage_after_collision.device == fresh_staged.device
            && stage_after_collision.inode == fresh_staged.inode,
            "collision preserves both endpoint inodes");

    require(::unlinkat(public_directory.get(), kEndpointPublicLeaf, 0) == 0,
            "privileged publisher cleanup counterexample");
    const EndpointPublishResult privileged_republish =
        publish_fixed_endpoint_noreplace(
            fresh_stage.get(), public_directory.get(),
            kProviderUid, kPublisherUid);
    require(privileged_republish.namespace_published(),
            "privileged publisher republish counterexample");
    const StatIdentity public_second = stat_leaf(
        public_directory.get(), kEndpointPublicLeaf);
    require(public_second.device == fresh_staged.device
            && public_second.inode == fresh_staged.inode,
            "privileged republish selects fresh endpoint inode");
    SingleWorker fresh_probe = launch_single(
        kQueryWorker, "probe", -1, public_directory.get(),
        kQueryUid, kQueryGid);
    const WorkerReport fresh_probe_report = finish_single(
        fresh_probe, "fresh-provider-probe");
    const std::uint8_t release = static_cast<std::uint8_t>('X');
    require(send_packet(fresh_provider.report.get(),
                        &release, sizeof(release)),
            "release fresh held provider");
    const WorkerReport fresh_final = receive_report(
        fresh_provider.report.get(), "fresh-provider-final");
    fresh_provider.report = ScopedFd{};
    wait_success(fresh_provider.pid, "fresh-provider");

    SingleWorker replacement = launch_single(
        kReplacementWorker, "replace", -1, replaceable.get(),
        kProviderUid, kProviderGid);
    const WorkerReport replacement_report = finish_single(
        replacement, "same-uid-replacement");

    const bool provider_floor = report_floor_exact(provider_ready);
    const bool query_floor = report_floor_exact(valid_query_report);
    const bool provider_bound_after_drop = provider_floor
        && provider_ready.bind_ok == 1
        && provider_ready.first_inode == staged.inode;
    const bool same_inode_publication = published.namespace_published()
        && published.device == staged.device
        && published.inode == staged.inode
        && public_first.inode == staged.inode;
    const bool mutation_denied = report_floor_exact(mutation_report)
        && mutation_report.unlink_result != 0
        && (mutation_report.unlink_error == EACCES
            || mutation_report.unlink_error == EPERM);
    const bool expectation_imported = query_floor
        && valid_query_report.expectation_imported == 1
        && valid_query_report.expectation_serial == kExpectationSerial
        && valid_query_report.expected_process_device
            == provider_expectation.process.device
        && valid_query_report.expected_process_inode
            == provider_expectation.process.inode;
    const bool expectation_spent = expectation_imported
        && valid_query_report.expectation_spent_before_connect == 1;
    const bool expected_process_matched = expectation_spent
        && valid_query_report.expected_process_match == 1;
    const bool expectation_record_immutable =
        provider_expectation.exact_seals
        && provider_expectation.tamper_blocked;
    const bool expectation_duplicate_escape =
        provider_expectation.duplicate_pair_exact;
    const bool query_connected = query_floor
        && expected_process_matched
        && valid_query_report.connect_ok == 1
        && valid_query_report.peer_uid
            == static_cast<std::int32_t>(kProviderUid)
        && valid_query_report.peer_gid
            == static_cast<std::int32_t>(kProviderGid)
        && valid_query_report.peer_process_device
            == provider_expectation.process.device
        && valid_query_report.peer_process_inode
            == provider_expectation.process.inode
        && valid_query_report.peer_process_alive_at_connect == 1
        && valid_query_report.connection_topology_exact == 1;
    const bool provider_peer_exact =
        provider_final.accepted_query_peer == 1
        && provider_final.peer_uid
            == static_cast<std::int32_t>(kQueryUid)
        && provider_final.peer_gid
            == static_cast<std::int32_t>(kQueryGid)
        && provider_final.peer_process_device != 0U
        && provider_final.peer_process_inode != 0U
        && provider_final.peer_process_alive_at_connect == 1
        && provider_final.connection_topology_exact == 1;
    const bool message_credentials =
        provider_final.message_credentials_exact == 1
        && valid_query_report.response_credentials_exact == 1;
    const bool message_process_identity =
        provider_final.message_process_identity_exact == 1
        && provider_final.message_pidfd_cloexec_exact == 1
        && valid_query_report.response_process_identity_exact == 1
        && valid_query_report.response_pidfd_cloexec_exact == 1;
    const bool provider_exit_observed =
        valid_query_report.peer_process_exit_observed == 1;
    const bool replacement_process_distinct =
        report_floor_exact(fresh_probe_report)
        && fresh_probe_report.connect_ok == 1
        && fresh_probe_report.peer_uid
            == static_cast<std::int32_t>(kProviderUid)
        && fresh_probe_report.peer_gid
            == static_cast<std::int32_t>(kProviderGid)
        && fresh_probe_report.peer_process_device != 0U
        && fresh_probe_report.peer_process_inode != 0U
        && (fresh_probe_report.peer_process_device
                != valid_query_report.peer_process_device
            || fresh_probe_report.peer_process_inode
                != valid_query_report.peer_process_inode);
    const bool exact_result =
        provider_final.fixed_query_disposition
            == static_cast<std::int32_t>(
                FixedQueryDisposition::exact_result_v2)
        && provider_final.valid_requests == 1
        && valid_query_report.exact_response == 1;
    const bool rights_rejected = provider_final.rights_received == 1
        && provider_final.rights_rejections == 1
        && provider_final.topology_restored_after_rights == 1;
    const bool malformed_rejected =
        provider_final.malformed_rejections == 1;
    const bool wrong_rejected =
        provider_final.accepted_wrong_peer == 1
        && wrong_query_report.connect_ok == 1
        && wrong_query_report.wrong_peer_rejection_observed == 1;
    const bool stale_persists = stale.inode != 0U
        && stale.inode == public_first.inode;
    const bool stale_connect_fails =
        stale_query_report.connect_ok == 0
        && stale_query_report.connect_error == ECONNREFUSED
        && stale_query_report.service_completed == 1;
    const bool collision_blocks =
        collision.disposition == EndpointPublishDisposition::public_exists
        && collision.error_number == EEXIST;
    const bool collision_preserves =
        public_after_collision.inode == stale.inode
        && stage_after_collision.inode == fresh_staged.inode;
    const bool publisher_replaces =
        privileged_republish.namespace_published()
        && public_second.inode == fresh_staged.inode
        && public_second.inode != stale.inode;
    const bool same_uid_replaces = report_floor_exact(replacement_report)
        && replacement_report.unlink_result == 0
        && replacement_report.rebind_ok == 1
        && replacement_report.distinct_live_inodes == 1;
    const bool fresh_provider_floor = report_floor_exact(fresh_ready)
        && fresh_final.service_completed == 1;

    for (const bool condition : {
             provider_floor, query_floor, provider_bound_after_drop,
             same_inode_publication, mutation_denied,
             expectation_imported, expectation_spent,
             expected_process_matched, expectation_record_immutable,
             expectation_duplicate_escape, query_connected,
             provider_peer_exact, message_credentials,
             message_process_identity, provider_exit_observed,
             replacement_process_distinct, exact_result,
             rights_rejected, malformed_rejected, wrong_rejected,
             stale_persists, stale_connect_fails, collision_blocks,
             collision_preserves, publisher_replaces,
             same_uid_replaces, fresh_provider_floor,
             socketpair_pidfd.peer_pidfd_is_creator,
             socketpair_pidfd.message_pidfd_is_sender,
             socketpair_pidfd.identities_are_distinct,
             provider_final.service_completed == 1,
             valid_query_report.service_completed == 1,
             wrong_query_report.service_completed == 1}) {
        require(condition, "endpoint-publication campaign invariant");
    }

    std::vector<CaseRow> rows{
        {"provider_prebind_descriptor_table_exact",
         "post-exec open={0,1,2,4(provider-root),5(stage-dir),6(report)}; no data socket inherited",
         provider_floor, false,
         "HOSTED_PROVIDER_PREBIND_TOPOLOGY_OBSERVED"},
        {"provider_binds_only_after_final_principal",
         "uid=21001 gid=21001 groups=0 capsets=0 no_new_privs=true before socket bind",
         provider_bound_after_drop, false,
         "BIND_OCCURS_INSIDE_FINAL_HOSTED_PROVIDER_PRINCIPAL"},
        {"provider_binds_fixed_stage_without_unlink",
         "fixed provider-owned 0700 stage/bound.sock; no cleanup or replacement input",
         provider_ready.bind_ok == 1, false,
         "STAGED_LISTENER_CREATED_FAIL_CLOSED"},
        {"bound_socket_inode_moves_to_public_leaf",
         "renameat2 RENAME_NOREPLACE preserves device and inode from bound.sock to query.sock",
         same_inode_publication, false,
         "LISTENER_SURVIVES_SEPARATE_NAMESPACE_PUBLICATION"},
        {"public_directory_is_publisher_custody",
         "public directory uid=0 mode=0711 while socket inode uid=21001 mode=0222",
         public_first.owner == kProviderUid
             && mutation_report.directory_fd_valid == 1,
         false,
         "SOCKET_CREATOR_AND_PUBLIC_NAME_CUSTODIAN_ARE_SPLIT"},
        {"provider_cannot_unlink_public_endpoint",
         "uid21001 unlinkat(public/query.sock) denied by parent-directory DAC",
         mutation_denied, false,
         "PROVIDER_RESTART_CANNOT_SILENTLY_REPLACE_PUBLIC_NAME"},
        {"sealed_expected_provider_record_is_immutable",
         "96-byte memfd has exact write/grow/shrink/seal seals and a post-seal pwrite is denied",
         expectation_record_immutable, false,
         "IMMUTABLE_EXPECTATION_SHAPE_OBSERVED"},
        {"expected_provider_capsule_is_addressed_to_query",
         "record fixes query uid21003/gid21003, provider uid21001/gid21001, serial, opaque binding, and pidfs identity",
         expectation_imported, false,
         "EXTERNAL_EXPECTATION_IS_CANONICAL_AND_PRINCIPAL_ADDRESSED"},
        {"expected_provider_capsule_is_burned_before_connect",
         "record fd7 and pidfd8 are closed before the query creates its AF_UNIX data socket",
         expectation_spent, false,
         "EXPECTED_PROCESS_INPUT_IS_ONE_USE_WITHIN_THIS_ACTOR"},
        {"connected_provider_matches_consumed_expectation",
         "SO_PEERPIDFD pidfs identity equals the already-consumed external expected process before request bytes",
         expected_process_matched, false,
         "BOUNDED_EFFECT_DEPENDS_ON_EXPECTED_PROCESS_MATCH"},
        {"root_harness_self_mints_matching_sealed_expectation",
         "uid0 observes provider pidfd, writes the opaque owner-binding field, seals the record, and the query accepts it",
         expectation_imported && expectation_record_immutable, true,
         "SEALS_AND_PROCESS_EQUALITY_DO_NOT_AUTHENTICATE_OWNER_ADMISSION"},
        {"expectation_record_and_pidfd_are_duplicable",
         "F_DUPFD_CLOEXEC creates a second exact sealed-record/pidfd pair before the actor-local burn",
         expectation_duplicate_escape, true,
         "MOVE_ONLY_WRAPPER_DOES_NOT_PROVE_GLOBALLY_UNIQUE_SPEND"},
        {"query_preconnect_descriptor_table_exact",
         "post-exec open={0,1,2,5(public-dir),6(report),7(sealed-expectation),8(expected-pidfd)}; no data socket inherited",
         query_floor, false,
         "QUERY_CONNECTION_IS_CREATED_AFTER_EXPECTATION_IMPORT"},
        {"query_connects_only_after_noreplace_publication",
         "publisher completes inode-preserving bind before launching uid21003 query actor",
         query_connected && same_inode_publication, false,
         "CONNECT_FOLLOWS_EXPLICIT_ENDPOINT_PUBLICATION"},
        {"renamed_listener_accepts_public_connection",
         "provider-held listener bound in stage accepts connection through renamed public pathname",
         provider_peer_exact, false,
         "BOUND_SOCKET_RENAME_WORKS_ON_RECORDED_LINUX_HOST"},
        {"query_connect_time_peer_is_provider",
         "query-side SO_PEERCRED uid=21001 gid=21001",
         query_connected, false,
         "CONNECT_TIME_PROVIDER_COORDINATE_OBSERVED"},
        {"provider_accept_time_peer_is_query",
         "accepted-socket SO_PEERCRED uid=21003 gid=21003",
         provider_peer_exact, false,
         "CONNECT_TIME_QUERY_COORDINATE_OBSERVED"},
        {"query_connect_peer_pidfd_is_provider_process",
         "query-side SO_PEERPIDFD has a valid pidfs identity and adds exactly one retained process descriptor",
         query_connected, false,
         "CONNECT_TIME_PROVIDER_PROCESS_INSTANCE_PINNED"},
        {"provider_accept_peer_pidfd_is_query_process",
         "accepted-side SO_PEERPIDFD has a valid pidfs identity and exact post-accept topology",
         provider_peer_exact, false,
         "CONNECT_TIME_QUERY_PROCESS_INSTANCE_PINNED"},
        {"message_credentials_agree_with_connect_peers",
         "SCM_CREDENTIALS on request and response agree with accepted/connect-time principals",
         message_credentials, false,
         "CONNECTION_AND_MESSAGE_COORDINATES_CONCUR_IN_HOSTED_RUN"},
        {"request_message_pidfd_agrees_with_accepted_peer",
         "each request SCM_PIDFD pidfs identity equals the accepted SO_PEERPIDFD identity and is close-on-exec",
         provider_final.message_process_identity_exact == 1
             && provider_final.message_pidfd_cloexec_exact == 1,
         false,
         "MESSAGE_SENDER_PROCESS_EQUALS_CONNECT_TIME_QUERY_PROCESS"},
        {"response_message_pidfd_agrees_with_connected_peer",
         "each response SCM_PIDFD pidfs identity equals the connected SO_PEERPIDFD identity and is close-on-exec",
         valid_query_report.response_process_identity_exact == 1
             && valid_query_report.response_pidfd_cloexec_exact == 1,
         false,
         "MESSAGE_SENDER_PROCESS_EQUALS_CONNECT_TIME_PROVIDER_PROCESS"},
        {"fixed_query_returns_exact_result_v2_over_fresh_connection",
         "fixed provider-root/cell/pending/result.2 join; no path/version/retry input",
         exact_result, false,
         "QUERY_ONLY_EXACT_RESULT_RENDEZVOUS_PRESERVED"},
        {"scm_rights_is_rejected_and_closed_before_bytes",
         "received descriptor closed and exact post-close descriptor table restored",
         rights_rejected, false,
         "FRESH_ENDPOINT_DOES_NOT_RELAX_CONTROL_MESSAGE_REJECTION"},
        {"malformed_message_is_rejected",
         "one-byte packet receives fixed malformed rejection",
         malformed_rejected, false,
         "MALFORMED_BYTES_GAIN_NO_RESULT_AUTHORITY"},
        {"wrong_uid_connection_is_rejected_at_accept",
         "uid21002 can reach mode0222 socket but accepted SO_PEERCRED causes immediate close",
         wrong_rejected, false,
         "PATH_REACHABILITY_IS_NOT_QUERY_AUTHORIZATION"},
        {"peer_pidfd_observes_provider_exit",
         "query retains the connect-time provider pidfd until poll reports provider process exit",
         provider_exit_observed, false,
         "PROCESS_LIFETIME_IS_PINNED_WITHOUT_AUTHENTICATING_ENDPOINT_EPOCH"},
        {"provider_death_leaves_stale_public_leaf",
         "listener closes while root-owned public/query.sock inode remains",
         stale_persists, false,
         "PATHNAME_SOCKET_LIFETIME_IS_NOT_PROVIDER_LIFETIME"},
        {"stale_endpoint_connect_fails_closed",
         "uid21003 connect to retained path returns ECONNREFUSED; no retry or unlink",
         stale_connect_fails, false,
         "STALE_ENDPOINT_IS_VISIBLE_FAILURE_NOT_FRESH_EPOCH"},
        {"fresh_provider_can_bind_private_stage_behind_stale_public",
         "new uid21001 worker binds fresh-stage/bound.sock while stale public name remains",
         fresh_provider_floor && fresh_staged.inode != 0U, false,
         "FRESH_PRIVATE_CONSTRUCTION_DOES_NOT_IMPLY_PUBLICATION"},
        {"stale_public_leaf_blocks_noreplace_restart",
         "fresh publication returns EEXIST and preserves stale public plus fresh staged inode",
         collision_blocks && collision_preserves, false,
         "RESTART_REQUIRES_SEPARATE_STALE_ENDPOINT_JUDGMENT"},
        {"privileged_publisher_can_cleanup_and_republish",
         "uid0 unlinkat then no-replace publication selects fresh provider inode",
         publisher_replaces, true,
         "PUBLISHER_ADMINISTRATION_REMAINS_DOMINANT_PREMISE"},
        {"privileged_republication_exposes_distinct_provider_process",
         "same fixed UID/path contract accepts a fresh provider with a different pidfs process identity",
         replacement_process_distinct, true,
         "PIDFD_DISTINGUISHES_REPLACEMENT_BUT_DOES_NOT_ADMIT_THE_RIGHT_EPOCH"},
        {"socketpair_peerpidfd_freezes_creator_while_message_pidfd_tracks_sender",
         "root-created socketpair SO_PEERPIDFD remains the creator while SCM_PIDFD identifies the forked sender",
         socketpair_pidfd.peer_pidfd_is_creator
             && socketpair_pidfd.message_pidfd_is_sender
             && socketpair_pidfd.identities_are_distinct,
         true,
         "CREATION_TIME_PROCESS_REFERENCE_IS_NOT_MESSAGE_SENDER_IDENTITY"},
        {"provider_owned_directory_allows_same_uid_live_replacement",
         "uid21001 unlinks a still-live pathname socket and binds a distinct inode at same leaf",
         same_uid_replaces, true,
         "BIND_AFTER_DROP_ALONE_DOES_NOT_ESTABLISH_ENDPOINT_FRESHNESS"},
    };
    std::vector<CounterexampleRow> counterexamples{
        {"socketpair_peerpidfd_identifies_creator_not_forked_sender",
         socketpair_pidfd.peer_pidfd_is_creator
             && socketpair_pidfd.message_pidfd_is_sender
             && socketpair_pidfd.identities_are_distinct,
         "claim that SO_PEERPIDFD on a pre-created socketpair identifies the current process sending a later message",
         "use connect-time construction for peer process identity and require per-message SCM_PIDFD agreement; neither authenticates owner policy"},
        {"replacement_pidfd_is_distinct_but_not_admitted",
         replacement_process_distinct,
         "claim that observing a stable process instance tells the query actor which provider epoch the owner authorized",
         "compare pidfds only against an independently retained owner-admitted expected process/service identity"},
        {"same_uid_restart_replaces_live_endpoint_in_writable_directory",
         same_uid_replaces,
         "claim that final-principal bind alone prevents a same-principal restart from impersonating a fresh endpoint",
         "separate public-name mutation custody from the provider or supply a stronger endpoint epoch mechanism"},
        {"stale_public_leaf_requires_separate_recovery_authority",
         collision_blocks && stale_connect_fails,
         "claim that unlink-before-bind is harmless restart hygiene",
         "a stale leaf is evidence; cleanup must be separately authorized and must not occur as automatic bind policy"},
        {"root_publisher_can_replace_endpoint_epoch",
         publisher_replaces,
         "claim that the hosted no-replace publisher is a closed protected administration plane",
         "name and constrain publisher cleanup replacement mount ptrace signal and lifecycle authority externally"},
        {"sealed_expected_process_is_root_self_assertion",
         expectation_imported && expectation_record_immutable,
         "claim that a sealed record plus matching pidfd proves which provider process an owner admitted",
         "authenticate the expectation constructor and opaque owner binding from a root independent of the hosted publisher"},
        {"duplicated_capsule_escapes_actor_local_one_use",
         expectation_duplicate_escape,
         "claim that consuming a move-only C++ wrapper proves the expectation can be spent only once system-wide",
         "place record and pidfd custody behind protected nonduplicable admission state with an externally durable spend receipt"},
    };
    require(rows.size() == 35U,
            "endpoint-publication case inventory");
    require(counterexamples.size() == 7U,
            "endpoint-publication counterexample inventory");
    write_rows(output, rows);
    write_counterexamples(output, counterexamples);
    write_summary(output, rows.size(), counterexamples.size());
    return {rows.size(), counterexamples.size()};
}

}  // namespace slopos::e0::handoff_cell::harness
