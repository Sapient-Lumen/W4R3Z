#include "rooted_release_campaign.hpp"

#include "slopos/e0/handoff_cell/rooted_release_locator.hpp"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct CaseRow final {
    std::string name;
    RootedReleaseAssessment assessment;
    bool root_path_replaced{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* bool_text(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] RootedReleaseObservationV1 exact_observation() {
    RootedReleaseObservationV1 observation;
    observation.root_descriptor_supplied = true;
    observation.root_descriptor_cloexec_duplicate = true;
    observation.root_descriptor_o_path = true;
    observation.root_is_directory = true;
    observation.root_owner_matches_host_profile = true;
    observation.root_mode_private = true;
    observation.fixed_leaf_name = true;
    observation.openat2_available = true;
    observation.resolve_beneath = true;
    observation.resolve_no_symlinks = true;
    observation.resolve_no_magiclinks = true;
    observation.resolve_no_xdev = true;
    observation.regular_only_open_enforced = true;
    observation.leaf_outcome = RootedReleaseLeafOutcome::opened;
    observation.leaf_regular = true;
    observation.leaf_same_device = true;
    observation.root_identity_stable = true;
    observation.root_profile_reobserved_equal = true;
    return observation;
}

void clear_lookup_and_after(
    RootedReleaseObservationV1& observation,
    const RootedReleaseLeafOutcome outcome =
        RootedReleaseLeafOutcome::not_attempted) noexcept {
    observation.leaf_outcome = outcome;
    observation.leaf_regular = false;
    observation.leaf_same_device = false;
    observation.root_identity_stable = false;
    observation.root_profile_reobserved_equal = false;
}

void add_case(std::vector<CaseRow>& rows,
              const std::string& name,
              const RootedReleaseObservationV1& observation,
              const RootedReleaseDisposition expected,
              const bool retained_counterexample,
              const std::string& judgment) {
    const RootedReleaseAssessment assessment =
        assess_rooted_release_locator(observation);
    require(assessment.disposition == expected,
            "rooted release disposition " + name
                + " observed=" + rooted_release_disposition_name(assessment.disposition)
                + " expected=" + rooted_release_disposition_name(expected));
    require(assessment.observation_coherent
                == (expected != RootedReleaseDisposition::observation_incoherent),
            "rooted release coherence " + name);
    require(assessment.candidate_descriptor_ready
                == (expected == RootedReleaseDisposition::candidate_descriptor_ready),
            "rooted release descriptor readiness " + name);
    require(!assessment.candidate_bytes_read,
            "rooted release byte read authority " + name);
    require(!assessment.archive_digest_compared,
            "rooted release digest authority " + name);
    require(!assessment.archive_parsed,
            "rooted release parse authority " + name);
    require(!assessment.caller_root_path_authority,
            "rooted release caller path authority " + name);
    require(!assessment.root_profile_continuity_proved,
            "rooted release profile continuity " + name);
    require(!assessment.owner_custody_proved,
            "rooted release owner custody " + name);
    require(!assessment.source_provenance_proved,
            "rooted release provenance " + name);
    require(!assessment.activation_authority,
            "rooted release activation " + name);
    require(!assessment.provider_operation_authority,
            "rooted release provider authority " + name);
    rows.push_back({name, assessment,
                    observation.root_path_replaced_after_pin,
                    retained_counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "rooted-release-cases.tsv", std::ios::binary);
    require(stream.good(), "open rooted-release-cases.tsv");
    stream
        << "case\tdisposition\tobservation_coherent\troot_descriptor_pinned"
           "\troot_descriptor_o_path\troot_identity_retained"
           "\troot_profile_reobserved_equal\troot_profile_continuity_proved"
           "\thosted_private_root_profile\tfixed_leaf_only"
           "\tall_component_symlink_rejection\tbeneath_restriction"
           "\tcross_mount_rejection\tregular_only_open_enforced"
           "\tpost_open_shape_is_contract_check_only"
           "\troot_path_replacement_ignored\tcandidate_descriptor_ready"
           "\tcandidate_bytes_read"
           "\tarchive_digest_compared\tarchive_parsed"
           "\tcaller_root_path_authority\towner_custody_proved"
           "\tsource_provenance_proved\tactivation_authority"
           "\tprovider_operation_authority\troot_path_replaced"
           "\tretained_counterexample\tjudgment\n";
    for (const CaseRow& row : rows) {
        const RootedReleaseAssessment& value = row.assessment;
        stream
            << row.name << '\t'
            << rooted_release_disposition_name(value.disposition) << '\t'
            << bool_text(value.observation_coherent) << '\t'
            << bool_text(value.root_descriptor_pinned) << '\t'
            << bool_text(value.root_descriptor_o_path) << '\t'
            << bool_text(value.root_identity_retained) << '\t'
            << bool_text(value.root_profile_reobserved_equal) << '\t'
            << bool_text(value.root_profile_continuity_proved) << '\t'
            << bool_text(value.hosted_private_root_profile) << '\t'
            << bool_text(value.fixed_leaf_only) << '\t'
            << bool_text(value.all_component_symlink_rejection) << '\t'
            << bool_text(value.beneath_restriction) << '\t'
            << bool_text(value.cross_mount_rejection) << '\t'
            << bool_text(value.regular_only_open_enforced) << '\t'
            << bool_text(value.post_open_shape_is_contract_check_only) << '\t'
            << bool_text(value.root_path_replacement_ignored) << '\t'
            << bool_text(value.candidate_descriptor_ready) << '\t'
            << bool_text(value.candidate_bytes_read) << '\t'
            << bool_text(value.archive_digest_compared) << '\t'
            << bool_text(value.archive_parsed) << '\t'
            << bool_text(value.caller_root_path_authority) << '\t'
            << bool_text(value.owner_custody_proved) << '\t'
            << bool_text(value.source_provenance_proved) << '\t'
            << bool_text(value.activation_authority) << '\t'
            << bool_text(value.provider_operation_authority) << '\t'
            << bool_text(row.root_path_replaced) << '\t'
            << bool_text(row.retained_counterexample) << '\t'
            << row.judgment << '\n';
    }
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "rooted-release-counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open rooted-release-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const RootedReleaseCampaignCounts& counts) {
    std::ofstream stream(
        output / "rooted-release-summary.json", std::ios::binary);
    require(stream.good(), "open rooted-release-summary.json");
    stream
        << "{\n"
        << "  \"activation_authority\": false,\n"
        << "  \"archive_digest_compared\": false,\n"
        << "  \"archive_parsed\": false,\n"
        << "  \"candidate_bytes_read\": false,\n"
        << "  \"cases\": " << counts.cases << ",\n"
        << "  \"counterexamples_reproduced\": "
        << counts.counterexamples << ",\n"
        << "  \"fixed_leaf\": \"etcd-v3.6.14-linux-amd64.tar.gz\",\n"
        << "  \"openat2_resolution\": "
           "\"RESOLVE_BENEATH|RESOLVE_NO_SYMLINKS|"
           "RESOLVE_NO_MAGICLINKS|RESOLVE_NO_XDEV\",\n"
        << "  \"openat2_regular_required\": true,\n"
        << "  \"owner_custody_proved\": false,\n"
        << "  \"path_replacement_ready_descriptors\": "
        << counts.path_replacement_ready_descriptors << ",\n"
        << "  \"provider_operation_authority\": false,\n"
        << "  \"ready_descriptors\": " << counts.ready_descriptors << ",\n"
        << "  \"post_open_shape_is_contract_check_only\": true,\n"
        << "  \"root_descriptor_profile\": \"CALLER_SUPPLIED_O_PATH_DIRECTORY\",\n"
        << "  \"root_profile_continuity_proved\": false,\n"
        << "  \"root_profile_endpoint_equality_only\": true,\n"
        << "  \"root_path_reopen_rejections\": "
        << counts.root_path_reopen_rejections << ",\n"
        << "  \"schema\": \"slopos.rev0900.rooted-release-locator-evidence.v5\",\n"
        << "  \"source_provenance_proved\": false,\n"
        << "  \"status\": \"PASS\"\n"
        << "}\n";
}

}  // namespace

RootedReleaseCampaignCounts run_rooted_release_campaign(
    const std::filesystem::path& output) {
    std::vector<CaseRow> cases;
    RootedReleaseObservationV1 observation;

    add_case(cases, "missing_root_descriptor", observation,
             RootedReleaseDisposition::root_descriptor_unavailable, false,
             "STOP_BEFORE_ROOT_PROFILE");

    observation = exact_observation();
    observation.root_descriptor_supplied = false;
    add_case(cases, "incoherent_downstream_flags", observation,
             RootedReleaseDisposition::observation_incoherent, true,
             "DOWNSTREAM_FLAGS_CANNOT_INVENT_ROOT_CUSTODY");

    observation = {};
    observation.root_descriptor_supplied = true;
    add_case(cases, "unduplicated_root_descriptor", observation,
             RootedReleaseDisposition::root_descriptor_unpinned, false,
             "STOP_BEFORE_DESCRIPTOR_PROFILE");

    observation = {};
    observation.root_descriptor_supplied = true;
    observation.root_descriptor_cloexec_duplicate = true;
    observation.root_is_directory = true;
    add_case(cases, "ordinary_directory_descriptor_without_opath", observation,
             RootedReleaseDisposition::root_descriptor_not_o_path, true,
             "ORDINARY_DIRECTORY_FD_IS_NOT_THE_ROOT_PROFILE");

    observation = exact_observation();
    observation.root_is_directory = false;
    observation.root_owner_matches_host_profile = false;
    observation.root_mode_private = false;
    clear_lookup_and_after(observation);
    add_case(cases, "root_not_directory", observation,
             RootedReleaseDisposition::root_not_directory, false,
             "STOP_NON_DIRECTORY_ROOT");

    observation = exact_observation();
    observation.root_owner_matches_host_profile = false;
    clear_lookup_and_after(observation);
    add_case(cases, "root_owner_mismatch", observation,
             RootedReleaseDisposition::root_profile_rejected, true,
             "HOST_UID_IS_NOT_EXPECTED_ROOT_PROFILE");

    observation = exact_observation();
    observation.root_mode_private = false;
    clear_lookup_and_after(observation);
    add_case(cases, "root_mode_not_private", observation,
             RootedReleaseDisposition::root_profile_rejected, true,
             "PUBLIC_ROOT_MODE_REJECTED");

    observation = exact_observation();
    observation.fixed_leaf_name = false;
    clear_lookup_and_after(observation);
    add_case(cases, "caller_selected_leaf", observation,
             RootedReleaseDisposition::root_profile_rejected, true,
             "CALLER_CANNOT_SELECT_RELEASE_NAME");

    observation = exact_observation();
    observation.openat2_available = false;
    observation.regular_only_open_enforced = false;
    clear_lookup_and_after(observation);
    add_case(cases, "openat2_unavailable", observation,
             RootedReleaseDisposition::resolution_policy_unavailable, false,
             "NO_FALLBACK_TO_OPENAT");

    observation = exact_observation();
    observation.resolve_beneath = false;
    clear_lookup_and_after(observation);
    add_case(cases, "beneath_missing", observation,
             RootedReleaseDisposition::resolution_policy_unavailable, true,
             "NO_LEXICAL_ESCAPE_FALLBACK");

    observation = exact_observation();
    observation.resolve_no_symlinks = false;
    clear_lookup_and_after(observation);
    add_case(cases, "all_symlink_rejection_missing", observation,
             RootedReleaseDisposition::resolution_policy_unavailable, true,
             "TAIL_NOFOLLOW_IS_INSUFFICIENT");

    observation = exact_observation();
    observation.resolve_no_magiclinks = false;
    clear_lookup_and_after(observation);
    add_case(cases, "magiclink_rejection_missing", observation,
             RootedReleaseDisposition::resolution_policy_unavailable, false,
             "MAGIC_LINKS_REMAIN_SEPARATE_EXPLICIT_POLICY");

    observation = exact_observation();
    observation.resolve_no_xdev = false;
    clear_lookup_and_after(observation);
    add_case(cases, "cross_mount_rejection_missing", observation,
             RootedReleaseDisposition::resolution_policy_unavailable, true,
             "MOUNT_CROSSING_REMAINS_UNADMITTED");

    observation = exact_observation();
    observation.regular_only_open_enforced = false;
    clear_lookup_and_after(observation);
    add_case(cases, "regular_only_open_unavailable", observation,
             RootedReleaseDisposition::regular_only_policy_unavailable, true,
             "NO_OPEN_THEN_FSTAT_FALLBACK");

    observation = exact_observation();
    observation.caller_root_path_reopened = true;
    clear_lookup_and_after(observation);
    add_case(cases, "caller_reopens_root_path", observation,
             RootedReleaseDisposition::root_path_reopen_rejected, true,
             "ROOT_PATH_REOPEN_IS_A_NEW_AUTHORITY_DECISION");

    observation = exact_observation();
    clear_lookup_and_after(observation);
    add_case(cases, "leaf_not_attempted", observation,
             RootedReleaseDisposition::fixed_leaf_unavailable, false,
             "NO_CANDIDATE_DESCRIPTOR");

    observation = exact_observation();
    clear_lookup_and_after(
        observation, RootedReleaseLeafOutcome::unavailable);
    add_case(cases, "fixed_leaf_missing", observation,
             RootedReleaseDisposition::fixed_leaf_unavailable, false,
             "EXACT_ARCHIVE_STILL_ABSENT");

    observation = exact_observation();
    clear_lookup_and_after(
        observation, RootedReleaseLeafOutcome::policy_rejected);
    add_case(cases, "leaf_policy_rejected", observation,
             RootedReleaseDisposition::fixed_leaf_policy_rejected, true,
             "SYMLINK_ESCAPE_OR_MOUNT_CROSSING_STOPS");

    observation = exact_observation();
    observation.root_identity_stable = false;
    observation.root_profile_reobserved_equal = false;
    add_case(cases, "root_identity_changed", observation,
             RootedReleaseDisposition::root_identity_changed, true,
             "POSTLOOKUP_ROOT_OBJECT_DIFFERS");

    observation = exact_observation();
    observation.root_profile_reobserved_equal = false;
    add_case(cases, "root_profile_changed_after_lookup", observation,
             RootedReleaseDisposition::root_profile_changed, true,
             "PRELOOKUP_PROFILE_DOES_NOT_PROVE_POSTLOOKUP_PROFILE");

    observation = exact_observation();
    observation.leaf_regular = false;
    observation.leaf_same_device = false;
    add_case(cases, "regular_only_contract_violation", observation,
             RootedReleaseDisposition::regular_only_contract_violated, true,
             "SUCCESSFUL_REGULAR_ONLY_OPEN_MUST_NOT_RETURN_NONREGULAR");

    observation = exact_observation();
    observation.leaf_same_device = false;
    add_case(cases, "leaf_cross_device", observation,
             RootedReleaseDisposition::leaf_cross_device, true,
             "FIXED_ROOT_PROFILE_REJECTS_MOUNT_CROSSING");

    observation = exact_observation();
    add_case(cases, "exact_rooted_candidate_descriptor", observation,
             RootedReleaseDisposition::candidate_descriptor_ready, false,
             "READY_FOR_EXISTING_SEALED_SNAPSHOT_GATE_ONLY");

    observation = exact_observation();
    observation.root_path_replaced_after_pin = true;
    add_case(cases, "root_path_replaced_after_pin", observation,
             RootedReleaseDisposition::candidate_descriptor_ready, true,
             "PINNED_ROOT_OBJECT_IGNORES_LATER_NAME_REPLACEMENT");

    std::vector<CounterexampleRow> counterexamples = {
        {"widened_leaf_tail_nofollow_follows_ancestor_symlink", true,
         "claim that a future nested leaf may keep tail-only O_NOFOLLOW",
         "keep the exact leaf one component and retain complete openat2 policy as an evolution guard"},
        {"reopening_root_path_switches_tree", true,
         "claim that a stable spelling preserves the pinned root object",
         "never reopen the caller root pathname after descriptor pin"},
        {"ordinary_directory_fd_is_not_opath_profile", true,
         "claim that any duplicated directory descriptor satisfies the fixed root profile",
         "represent and require O_PATH independently of duplication and directory type"},
        {"root_fd_is_not_owner_custody", true,
         "claim that an O_PATH root descriptor constitutes a governed owner",
         "host UID and mode checks remain observations without owner constitution"},
        {"prelookup_profile_is_not_postlookup_profile", true,
         "claim that one prelookup owner and mode check remains true",
         "reobserve directory type owner and mode on the pinned root after lookup"},
        {"equal_profile_endpoints_are_not_continuity", true,
         "claim that equal pre/post owner and mode observations prove uninterrupted custody",
         "record endpoint equality only; transient ABA and continuous custody remain unproved"},
        {"post_open_fstat_is_too_late", true,
         "claim that opening first and rejecting a FIFO or device afterward is equivalent to atomic type enforcement",
         "require OPENAT2_REGULAR at open time and stop when the host lacks it"},
        {"rooted_open_is_not_content_identity", true,
         "claim that rooted lookup freezes candidate bytes",
         "copy the opened regular file into one write-sealed snapshot before digest"},
        {"same_device_is_not_provenance", true,
         "claim that same-device resolution identifies the upstream source",
         "supply-chain provenance and signing roots remain independent premises"},
        {"resolution_policy_is_not_digest", true,
         "claim that a beneath non-symlink leaf is the exact release",
         "fixed SHA-256 comparison still precedes archive semantics"},
        {"rooted_candidate_is_not_activation", true,
         "claim that a candidate descriptor permits execution or provider operation",
         "descriptor readiness feeds passive admission only"},
    };

    require(cases.size() == 24U, "rooted release case inventory");
    require(counterexamples.size() == 11U,
            "rooted release counterexample inventory");
    require(std::all_of(counterexamples.begin(), counterexamples.end(),
                        [](const CounterexampleRow& row) {
                            return row.reproduced;
                        }),
            "rooted release counterexample reproduction");

    RootedReleaseCampaignCounts counts;
    counts.cases = cases.size();
    counts.counterexamples = counterexamples.size();
    counts.ready_descriptors = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.candidate_descriptor_ready;
        }));
    counts.path_replacement_ready_descriptors =
        static_cast<std::size_t>(std::count_if(
            cases.begin(), cases.end(), [](const CaseRow& row) {
                return row.assessment.candidate_descriptor_ready
                    && row.root_path_replaced;
            }));
    counts.root_path_reopen_rejections = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.disposition
                == RootedReleaseDisposition::root_path_reopen_rejected;
        }));
    require(counts.ready_descriptors == 2U,
            "rooted release ready descriptor count");
    require(counts.path_replacement_ready_descriptors == 1U,
            "rooted release replacement descriptor count");
    require(counts.root_path_reopen_rejections == 1U,
            "rooted release reopen rejection count");

    write_cases(output, cases);
    write_counterexamples(output, counterexamples);
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
