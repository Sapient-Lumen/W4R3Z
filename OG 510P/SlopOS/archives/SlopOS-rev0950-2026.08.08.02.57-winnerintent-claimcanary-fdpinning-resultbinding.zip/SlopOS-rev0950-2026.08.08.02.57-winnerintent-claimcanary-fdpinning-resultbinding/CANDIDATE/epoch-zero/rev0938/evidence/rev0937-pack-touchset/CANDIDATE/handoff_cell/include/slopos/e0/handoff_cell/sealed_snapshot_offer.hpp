#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

// A bounded descriptor-delivery relation upstream of the V11 sealed-copy
// admission gate. It interprets no candidate bytes. A successful relation
// means only that one exact message, from an actor admitted before readiness
// and before SCM_RIGHTS import, supplied the receiver's first alias to one
// close-on-exec, readable, unlinked, fully write-sealed regular snapshot object. The
// first-alias premise is externally constructed; the observed profile does not prove
// which creation API, process, or release authority produced that object.
enum class SealedSnapshotOfferDisposition : std::uint8_t {
    observation_incoherent,
    socket_descriptor_unavailable,
    socket_descriptor_unpinned,
    socket_family_rejected,
    socket_type_rejected,
    credential_delivery_unavailable,
    pidfd_delivery_unavailable,
    peer_coordinate_unavailable,
    receiver_preoffer_candidate_alias_present,
    acquisition_actor_not_admitted,
    ready_frame_unsent,
    offer_unavailable,
    message_data_truncated,
    message_control_truncated,
    offer_payload_rejected,
    ancillary_shape_rejected,
    process_identity_mismatch,
    credential_mismatch,
    candidate_descriptor_not_cloexec,
    candidate_descriptor_not_readable,
    candidate_descriptor_not_regular,
    candidate_descriptor_linked,
    candidate_seal_query_unavailable,
    candidate_required_seals_missing,
    candidate_size_rejected,
    sealed_snapshot_source_ready,
};

// These fields are an ordered observation prefix. The external actor-admission
// premise must hold before the receiver emits READY and therefore before any
// recvmsg() capable of installing SCM_RIGHTS. Fields concerning the offered
// descriptor are coherent only after one complete, non-truncated, exactly
// shaped ancillary envelope whose control-record cardinality and delivered-
// descriptor cardinality are checked independently. No field grants permission
// to read candidate bytes before the whole prefix has been checked.
struct SealedSnapshotOfferObservationV1 final {
    bool socket_descriptor_supplied{false};
    bool socket_descriptor_cloexec_duplicate{false};
    bool socket_family_unix{false};
    bool socket_type_seqpacket{false};
    bool passcred_enabled{false};
    bool passpidfd_enabled{false};
    bool peer_credentials_observed{false};
    bool peer_pidfd_observed{false};
    // External construction premise: before READY, the receiver owns no
    // descriptor alias to the candidate object. This must be established by
    // lifecycle topology (for example, candidate creation after receiver fork),
    // not inferred from the descriptor number delivered later.
    bool receiver_preoffer_candidate_aliases_zero{false};
    bool acquisition_actor_admitted_before_ready{false};
    bool ready_frame_sent{false};
    bool one_message_received{false};
    bool message_data_truncated{false};
    bool message_control_truncated{false};
    bool offer_payload_exact{false};
    bool exactly_one_rights_record{false};
    bool exactly_one_rights_descriptor{false};
    bool exactly_one_credentials_record{false};
    bool exactly_one_pidfd_record{false};
    bool no_unknown_control_records{false};
    bool message_process_matches_peer{false};
    bool message_credentials_match_peer{false};
    bool candidate_descriptor_cloexec{false};
    // F_GETFL access mode is O_RDONLY or O_RDWR and is not O_PATH.
    // Seals constrain mutation; they do not make a write-only alias readable.
    bool candidate_descriptor_readable{false};
    bool candidate_regular{false};
    bool candidate_unlinked{false};
    bool candidate_seal_query_supported{false};
    bool candidate_seal_write{false};
    bool candidate_seal_grow{false};
    bool candidate_seal_shrink{false};
    bool candidate_seal_seal{false};
    bool candidate_size_bounded{false};
};

// A copyable, authority-negative report. transport_envelope_ready and
// sealed_descriptor_profile_ready are mechanism observations. They do not
// prove creator history, memfd_create provenance, one-use transfer, exclusive
// custody, durable media, activation, provider operation, or living law.
struct SealedSnapshotOfferAssessment final {
    SealedSnapshotOfferDisposition disposition{
        SealedSnapshotOfferDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool socket_descriptor_pinned{false};
    bool exact_message_boundary{false};
    bool peer_coordinate_observed{false};
    bool receiver_preoffer_candidate_aliases_zero{false};
    bool acquisition_actor_admitted{false};
    bool actor_admission_precedes_ready{false};
    bool ancillary_envelope_exact{false};
    bool process_coordinate_agrees{false};
    bool credential_coordinate_agrees{false};
    bool transport_envelope_ready{false};
    bool candidate_descriptor_received{false};
    bool candidate_descriptor_cloexec{false};
    bool candidate_descriptor_readable{false};
    bool candidate_regular_unlinked{false};
    bool candidate_fully_write_sealed{false};
    bool candidate_size_bounded{false};
    bool sealed_descriptor_profile_ready{false};
    bool sealed_snapshot_source_ready{false};
    bool candidate_bytes_read{false};
    bool archive_digest_compared{false};
    bool archive_parsed{false};
    bool one_use_transfer_proved{false};
    bool exclusive_custody_proved{false};
    bool candidate_memfd_creation_proved{false};
    bool source_provenance_proved{false};
    bool durable_media_proved{false};
    bool activation_authority{false};
    bool provider_operation_authority{false};
    bool owner_custody_proved{false};

    [[nodiscard]] constexpr bool ready() const noexcept {
        return disposition
            == SealedSnapshotOfferDisposition::sealed_snapshot_source_ready;
    }
};

[[nodiscard]] SealedSnapshotOfferAssessment assess_sealed_snapshot_offer(
    const SealedSnapshotOfferObservationV1& observation) noexcept;
[[nodiscard]] const char* sealed_snapshot_offer_disposition_name(
    SealedSnapshotOfferDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
