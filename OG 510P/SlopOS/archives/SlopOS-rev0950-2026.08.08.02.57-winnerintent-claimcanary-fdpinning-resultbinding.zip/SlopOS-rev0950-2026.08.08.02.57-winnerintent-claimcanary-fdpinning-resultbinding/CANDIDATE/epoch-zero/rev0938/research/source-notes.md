# External source notes for the configured-expectation cut

Consulted as design constraints, not imported as authority:

- OCI Image Specification, descriptor model: a descriptor carries the digest and size a
  consumer expects for referenced content. The digest is useful only when the descriptor
  itself arrives through a trustworthy context.  
  https://github.com/opencontainers/image-spec/blob/main/descriptor.md
- The Update Framework specification: trusted root metadata and role/threshold rules are
  established before target metadata is accepted; target bytes do not choose their own
  trust root.  
  https://theupdateframework.github.io/specification/latest/

SlopOS rev0938 adopts only the local structural lesson: expectation state must preexist the
candidate verification call. It deliberately does not claim TUF, OCI compliance, a secure
delivery channel, threshold signatures, or an external root of trust.
