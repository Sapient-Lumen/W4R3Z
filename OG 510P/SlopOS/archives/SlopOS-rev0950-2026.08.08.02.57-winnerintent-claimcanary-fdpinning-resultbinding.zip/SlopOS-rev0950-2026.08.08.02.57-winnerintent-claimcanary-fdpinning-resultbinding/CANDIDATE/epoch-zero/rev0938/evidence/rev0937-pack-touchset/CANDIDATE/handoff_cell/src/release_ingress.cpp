#include "slopos/e0/handoff_cell/release_ingress.hpp"

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] bool observation_is_coherent(
    const ReleaseIngressObservationV1& observation) noexcept {
    if (observation.descriptor_pinned && !observation.locator_opened) {
        return false;
    }
    if (observation.regular_file && !observation.descriptor_pinned) {
        return false;
    }
    if (observation.private_snapshot_complete && !observation.regular_file) {
        return false;
    }
    if (observation.private_snapshot_write_sealed
        && !observation.private_snapshot_complete) {
        return false;
    }
    if (observation.digest_compared_before_parse
        && !observation.private_snapshot_write_sealed) {
        return false;
    }
    if (observation.archive_parse_attempted
        && !observation.private_snapshot_write_sealed) {
        return false;
    }
    if (observation.archive_inventory_valid
        && !observation.archive_parse_attempted) {
        return false;
    }
    if (observation.required_binaries_hashed
        && !observation.archive_inventory_valid) {
        return false;
    }
    if (observation.supplied_path_reopened
        && !observation.descriptor_pinned) {
        return false;
    }
    if (observation.pathname_replaced_after_open
        && !observation.descriptor_pinned) {
        return false;
    }
    if ((observation.binary_extraction_attempted
         || observation.binary_execution_attempted)
        && !observation.archive_parse_attempted) {
        return false;
    }
    return true;
}

[[nodiscard]] ReleaseIngressAssessment base_assessment(
    const ReleaseIngressObservationV1& observation) noexcept {
    ReleaseIngressAssessment result;
    result.activation_boundary_observed =
        observation.binary_extraction_attempted
        || observation.binary_execution_attempted;
    result.passive_only = !result.activation_boundary_observed;
    result.supplied_path_authority = false;
    result.activation_authority = false;
    result.provider_operation_authority = false;
    result.cluster_operated = false;
    result.binary_execution_proved = false;
    return result;
}

}  // namespace

ReleaseIngressAssessment assess_release_ingress(
    const ProviderDigest& expected_archive_sha256,
    const ReleaseIngressObservationV1& observation) noexcept {
    ReleaseIngressAssessment result = base_assessment(observation);
    if (!observation_is_coherent(observation)) {
        result.disposition = ReleaseIngressDisposition::observation_incoherent;
        return result;
    }
    result.observation_coherent = true;

    if (!observation.locator_opened) {
        result.disposition = ReleaseIngressDisposition::locator_unavailable;
        return result;
    }
    if (!observation.descriptor_pinned) {
        result.disposition = ReleaseIngressDisposition::descriptor_unpinned;
        return result;
    }
    result.descriptor_identity_retained = true;
    result.pathname_replacement_ignored =
        observation.pathname_replaced_after_open
        && !observation.supplied_path_reopened;

    if (!observation.regular_file) {
        result.disposition = ReleaseIngressDisposition::nonregular_source;
        return result;
    }
    if (!observation.private_snapshot_complete) {
        result.disposition = ReleaseIngressDisposition::snapshot_incomplete;
        return result;
    }
    result.private_snapshot_used = true;
    if (!observation.private_snapshot_write_sealed) {
        result.disposition = ReleaseIngressDisposition::snapshot_unsealed;
        return result;
    }
    result.snapshot_write_sealed = true;
    result.digest_before_parse = observation.digest_compared_before_parse;
    result.exact_release_bytes =
        observation.snapshot_sha256 == expected_archive_sha256;
    if (observation.supplied_path_reopened) {
        result.disposition = ReleaseIngressDisposition::path_reopen_rejected;
        return result;
    }
    // A parser that ran before comparison is an ordering violation even when
    // the subsequently supplied digest is wrong.  Digest mismatch must not
    // mask that archive semantics already crossed the airlock too early.
    if (observation.archive_parse_attempted
        && !observation.digest_compared_before_parse) {
        result.disposition = ReleaseIngressDisposition::digest_order_rejected;
        return result;
    }
    if (!result.exact_release_bytes) {
        result.disposition = ReleaseIngressDisposition::digest_mismatch;
        return result;
    }
    if (!observation.digest_compared_before_parse) {
        result.disposition = ReleaseIngressDisposition::digest_order_rejected;
        return result;
    }
    if (!observation.archive_parse_attempted
        || !observation.archive_inventory_valid
        || !observation.required_binaries_hashed) {
        result.disposition = ReleaseIngressDisposition::archive_rejected;
        return result;
    }
    if (result.activation_boundary_observed) {
        result.disposition =
            ReleaseIngressDisposition::activation_boundary_violated;
        return result;
    }
    result.disposition = ReleaseIngressDisposition::exact_passive_admission;
    return result;
}

const char* release_ingress_disposition_name(
    const ReleaseIngressDisposition value) noexcept {
    switch (value) {
        case ReleaseIngressDisposition::observation_incoherent:
            return "OBSERVATION_INCOHERENT";
        case ReleaseIngressDisposition::locator_unavailable:
            return "LOCATOR_UNAVAILABLE";
        case ReleaseIngressDisposition::descriptor_unpinned:
            return "DESCRIPTOR_UNPINNED";
        case ReleaseIngressDisposition::nonregular_source:
            return "NONREGULAR_SOURCE";
        case ReleaseIngressDisposition::snapshot_incomplete:
            return "SNAPSHOT_INCOMPLETE";
        case ReleaseIngressDisposition::snapshot_unsealed:
            return "SNAPSHOT_UNSEALED";
        case ReleaseIngressDisposition::digest_mismatch:
            return "DIGEST_MISMATCH";
        case ReleaseIngressDisposition::path_reopen_rejected:
            return "PATH_REOPEN_REJECTED";
        case ReleaseIngressDisposition::digest_order_rejected:
            return "DIGEST_ORDER_REJECTED";
        case ReleaseIngressDisposition::archive_rejected:
            return "ARCHIVE_REJECTED";
        case ReleaseIngressDisposition::activation_boundary_violated:
            return "ACTIVATION_BOUNDARY_VIOLATED";
        case ReleaseIngressDisposition::exact_passive_admission:
            return "EXACT_PASSIVE_ADMISSION";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
