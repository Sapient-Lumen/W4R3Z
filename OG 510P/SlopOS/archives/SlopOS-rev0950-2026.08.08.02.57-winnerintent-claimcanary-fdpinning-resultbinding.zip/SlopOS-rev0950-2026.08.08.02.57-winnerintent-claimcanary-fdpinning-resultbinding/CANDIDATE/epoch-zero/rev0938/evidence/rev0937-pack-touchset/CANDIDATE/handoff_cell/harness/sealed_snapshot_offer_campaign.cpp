#include "sealed_snapshot_offer_campaign.hpp"

#include "slopos/e0/handoff_cell/sealed_snapshot_offer.hpp"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct CaseRow final {
    std::string name;
    SealedSnapshotOfferAssessment assessment;
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* bool_text(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] SealedSnapshotOfferObservationV1 exact_observation() {
    SealedSnapshotOfferObservationV1 value;
    value.socket_descriptor_supplied = true;
    value.socket_descriptor_cloexec_duplicate = true;
    value.socket_family_unix = true;
    value.socket_type_seqpacket = true;
    value.passcred_enabled = true;
    value.passpidfd_enabled = true;
    value.peer_credentials_observed = true;
    value.peer_pidfd_observed = true;
    value.receiver_preoffer_candidate_aliases_zero = true;
    value.acquisition_actor_admitted_before_ready = true;
    value.ready_frame_sent = true;
    value.one_message_received = true;
    value.offer_payload_exact = true;
    value.exactly_one_rights_record = true;
    value.exactly_one_rights_descriptor = true;
    value.exactly_one_credentials_record = true;
    value.exactly_one_pidfd_record = true;
    value.no_unknown_control_records = true;
    value.message_process_matches_peer = true;
    value.message_credentials_match_peer = true;
    value.candidate_descriptor_cloexec = true;
    value.candidate_descriptor_readable = true;
    value.candidate_regular = true;
    value.candidate_unlinked = true;
    value.candidate_seal_query_supported = true;
    value.candidate_seal_write = true;
    value.candidate_seal_grow = true;
    value.candidate_seal_shrink = true;
    value.candidate_seal_seal = true;
    value.candidate_size_bounded = true;
    return value;
}

void clear_descriptor(SealedSnapshotOfferObservationV1& value) noexcept {
    value.candidate_descriptor_cloexec = false;
    value.candidate_descriptor_readable = false;
    value.candidate_regular = false;
    value.candidate_unlinked = false;
    value.candidate_seal_query_supported = false;
    value.candidate_seal_write = false;
    value.candidate_seal_grow = false;
    value.candidate_seal_shrink = false;
    value.candidate_seal_seal = false;
    value.candidate_size_bounded = false;
}

void clear_envelope_and_descriptor(
    SealedSnapshotOfferObservationV1& value) noexcept {
    value.offer_payload_exact = false;
    value.exactly_one_rights_record = false;
    value.exactly_one_rights_descriptor = false;
    value.exactly_one_credentials_record = false;
    value.exactly_one_pidfd_record = false;
    value.no_unknown_control_records = false;
    value.message_process_matches_peer = false;
    value.message_credentials_match_peer = false;
    clear_descriptor(value);
}

void clear_from_actor_admission(
    SealedSnapshotOfferObservationV1& value) noexcept {
    value.acquisition_actor_admitted_before_ready = false;
    value.ready_frame_sent = false;
    value.one_message_received = false;
    value.message_data_truncated = false;
    value.message_control_truncated = false;
    clear_envelope_and_descriptor(value);
}

void clear_from_preoffer_alias(
    SealedSnapshotOfferObservationV1& value) noexcept {
    value.receiver_preoffer_candidate_aliases_zero = false;
    clear_from_actor_admission(value);
}

void clear_from_message(SealedSnapshotOfferObservationV1& value) noexcept {
    value.one_message_received = false;
    value.message_data_truncated = false;
    value.message_control_truncated = false;
    clear_envelope_and_descriptor(value);
}

void add_case(std::vector<CaseRow>& rows, const std::string& name,
              const SealedSnapshotOfferObservationV1& observation,
              const SealedSnapshotOfferDisposition expected,
              const bool retained_counterexample,
              const std::string& judgment) {
    const SealedSnapshotOfferAssessment assessment =
        assess_sealed_snapshot_offer(observation);
    require(assessment.disposition == expected,
            "sealed offer disposition " + name + " observed="
            + sealed_snapshot_offer_disposition_name(assessment.disposition)
            + " expected="
            + sealed_snapshot_offer_disposition_name(expected));
    require(assessment.observation_coherent
                == (expected
                    != SealedSnapshotOfferDisposition::observation_incoherent),
            "sealed offer coherence " + name);
    require(assessment.sealed_snapshot_source_ready
                == (expected == SealedSnapshotOfferDisposition::
                    sealed_snapshot_source_ready),
            "sealed offer readiness " + name);
    require(!assessment.candidate_bytes_read,
            "sealed offer candidate bytes " + name);
    require(!assessment.archive_digest_compared,
            "sealed offer digest " + name);
    require(!assessment.archive_parsed,
            "sealed offer parse " + name);
    require(!assessment.one_use_transfer_proved,
            "sealed offer one use " + name);
    require(!assessment.exclusive_custody_proved,
            "sealed offer exclusive custody " + name);
    require(!assessment.candidate_memfd_creation_proved,
            "sealed offer memfd creation provenance " + name);
    require(!assessment.source_provenance_proved,
            "sealed offer provenance " + name);
    require(!assessment.durable_media_proved,
            "sealed offer durable media " + name);
    require(!assessment.activation_authority,
            "sealed offer activation " + name);
    require(!assessment.provider_operation_authority,
            "sealed offer provider authority " + name);
    require(!assessment.owner_custody_proved,
            "sealed offer owner custody " + name);
    rows.push_back({name, assessment, retained_counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "sealed-snapshot-offer-cases.tsv",
                         std::ios::binary);
    require(stream.good(), "open sealed-snapshot-offer-cases.tsv");
    stream
        << "case\tdisposition\tobservation_coherent"
           "\tsocket_descriptor_pinned\texact_message_boundary"
           "\tpeer_coordinate_observed"
           "\treceiver_preoffer_candidate_aliases_zero"
           "\tacquisition_actor_admitted"
           "\tactor_admission_precedes_ready\tancillary_envelope_exact"
           "\tprocess_coordinate_agrees\tcredential_coordinate_agrees"
           "\ttransport_envelope_ready\tcandidate_descriptor_received"
           "\tcandidate_descriptor_cloexec\tcandidate_descriptor_readable"
           "\tcandidate_regular_unlinked"
           "\tcandidate_fully_write_sealed\tcandidate_size_bounded"
           "\tsealed_descriptor_profile_ready"
           "\tsealed_snapshot_source_ready\tcandidate_bytes_read"
           "\tarchive_digest_compared\tarchive_parsed"
           "\tone_use_transfer_proved\texclusive_custody_proved"
           "\tcandidate_memfd_creation_proved\tsource_provenance_proved"
           "\tdurable_media_proved\tactivation_authority"
           "\tprovider_operation_authority\towner_custody_proved"
           "\tretained_counterexample\tjudgment\n";
    for (const CaseRow& row : rows) {
        const auto& value = row.assessment;
        stream << row.name << '\t'
               << sealed_snapshot_offer_disposition_name(value.disposition)
               << '\t' << bool_text(value.observation_coherent)
               << '\t' << bool_text(value.socket_descriptor_pinned)
               << '\t' << bool_text(value.exact_message_boundary)
               << '\t' << bool_text(value.peer_coordinate_observed)
               << '\t'
               << bool_text(value.receiver_preoffer_candidate_aliases_zero)
               << '\t' << bool_text(value.acquisition_actor_admitted)
               << '\t' << bool_text(value.actor_admission_precedes_ready)
               << '\t' << bool_text(value.ancillary_envelope_exact)
               << '\t' << bool_text(value.process_coordinate_agrees)
               << '\t' << bool_text(value.credential_coordinate_agrees)
               << '\t' << bool_text(value.transport_envelope_ready)
               << '\t' << bool_text(value.candidate_descriptor_received)
               << '\t' << bool_text(value.candidate_descriptor_cloexec)
               << '\t' << bool_text(value.candidate_descriptor_readable)
               << '\t' << bool_text(value.candidate_regular_unlinked)
               << '\t' << bool_text(value.candidate_fully_write_sealed)
               << '\t' << bool_text(value.candidate_size_bounded)
               << '\t' << bool_text(value.sealed_descriptor_profile_ready)
               << '\t' << bool_text(value.sealed_snapshot_source_ready)
               << '\t' << bool_text(value.candidate_bytes_read)
               << '\t' << bool_text(value.archive_digest_compared)
               << '\t' << bool_text(value.archive_parsed)
               << '\t' << bool_text(value.one_use_transfer_proved)
               << '\t' << bool_text(value.exclusive_custody_proved)
               << '\t' << bool_text(value.candidate_memfd_creation_proved)
               << '\t' << bool_text(value.source_provenance_proved)
               << '\t' << bool_text(value.durable_media_proved)
               << '\t' << bool_text(value.activation_authority)
               << '\t' << bool_text(value.provider_operation_authority)
               << '\t' << bool_text(value.owner_custody_proved)
               << '\t' << bool_text(row.retained_counterexample)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "sealed-snapshot-offer-counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open sealed-snapshot-offer-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const SealedSnapshotOfferCampaignCounts& counts) {
    std::ofstream stream(
        output / "sealed-snapshot-offer-summary.json", std::ios::binary);
    require(stream.good(), "open sealed-snapshot-offer-summary.json");
    stream
        << "{\n"
        << "  \"acquisition_actor_admission_external\": true,\n"
        << "  \"activation_authority\": false,\n"
        << "  \"actor_admission_precedes_ready\": true,\n"
        << "  \"admitted_ready_sources\": "
        << counts.admitted_ready_sources << ",\n"
        << "  \"archive_digest_compared\": false,\n"
        << "  \"archive_parsed\": false,\n"
        << "  \"candidate_bytes_read\": false,\n"
        << "  \"candidate_memfd_creation_proved\": false,\n"
        << "  \"candidate_readable_required\": true,\n"
        << "  \"cases\": " << counts.cases << ",\n"
        << "  \"counterexamples_reproduced\": "
        << counts.counterexamples << ",\n"
        << "  \"exact_offer_frame\": \"SLOPOS-E0-SEALED-OFFER-V1\",\n"
        << "  \"exclusive_custody_proved\": false,\n"
        << "  \"incoherent_observations\": "
        << counts.incoherent_observations << ",\n"
        << "  \"mechanism_ready_actor_rejections\": "
        << counts.mechanism_ready_actor_rejections << ",\n"
        << "  \"preoffer_alias_rejections\": "
        << counts.preoffer_alias_rejections << ",\n"
        << "  \"post_receive_authority_import_incoherences\": "
        << counts.post_receive_authority_import_incoherences << ",\n"
        << "  \"pre_receive_actor_rejections\": "
        << counts.pre_receive_actor_rejections << ",\n"
        << "  \"one_use_transfer_proved\": false,\n"
        << "  \"owner_custody_proved\": false,\n"
        << "  \"provider_operation_authority\": false,\n"
        << "  \"receiver_preoffer_candidate_aliases_zero_required\": true,\n"
        << "  \"required_seals\": \"F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL\",\n"
        << "  \"schema\": \"slopos.rev0901.sealed-snapshot-offer-campaign.v13\",\n"
        << "  \"socket_profile\": \"AF_UNIX/SOCK_SEQPACKET+SO_PASSCRED+SO_PASSPIDFD\",\n"
        << "  \"source_provenance_proved\": false,\n"
        << "  \"status\": \"PASS\"\n"
        << "}\n";
}

}  // namespace

SealedSnapshotOfferCampaignCounts run_sealed_snapshot_offer_campaign(
    const std::filesystem::path& output) {
    std::vector<CaseRow> rows;
    std::vector<CounterexampleRow> counterexamples;
    const auto exact = exact_observation();
    add_case(rows, "exact_admitted_sealed_offer", exact,
             SealedSnapshotOfferDisposition::sealed_snapshot_source_ready,
             false,
             "one externally admitted actor may offer one exact fully sealed source without candidate-byte interpretation");

    auto value = exact;
    clear_from_actor_admission(value);
    add_case(rows, "actor_not_admitted_before_ready", value,
             SealedSnapshotOfferDisposition::acquisition_actor_not_admitted,
             true,
             "rejection occurs before READY and before any SCM_RIGHTS import");

    value = exact; value.socket_family_unix = false;
    value.passcred_enabled = false; value.passpidfd_enabled = false;
    value.peer_credentials_observed = false; value.peer_pidfd_observed = false;
    clear_from_preoffer_alias(value);
    add_case(rows, "wrong_socket_family", value,
             SealedSnapshotOfferDisposition::socket_family_rejected, true,
             "only local AF_UNIX transport is admitted");
    value = exact; value.socket_type_seqpacket = false;
    value.passcred_enabled = false; value.passpidfd_enabled = false;
    value.peer_credentials_observed = false; value.peer_pidfd_observed = false;
    clear_from_preoffer_alias(value);
    add_case(rows, "wrong_socket_type", value,
             SealedSnapshotOfferDisposition::socket_type_rejected, true,
             "message boundaries are mandatory");
    value = exact; value.passcred_enabled = false;
    value.peer_credentials_observed = false; value.peer_pidfd_observed = false;
    clear_from_preoffer_alias(value);
    add_case(rows, "credential_delivery_missing", value,
             SealedSnapshotOfferDisposition::credential_delivery_unavailable,
             true, "per-message credentials are mandatory");
    value = exact; value.passpidfd_enabled = false;
    value.peer_pidfd_observed = false; clear_from_preoffer_alias(value);
    add_case(rows, "pidfd_delivery_missing", value,
             SealedSnapshotOfferDisposition::pidfd_delivery_unavailable,
             true, "per-message process identity is mandatory");
    value = exact; value.peer_credentials_observed = false;
    clear_from_preoffer_alias(value);
    add_case(rows, "peer_credentials_missing", value,
             SealedSnapshotOfferDisposition::peer_coordinate_unavailable,
             true, "actor admission needs a retained peer credential coordinate");
    value = exact; value.peer_pidfd_observed = false;
    clear_from_preoffer_alias(value);
    add_case(rows, "peer_pidfd_missing", value,
             SealedSnapshotOfferDisposition::peer_coordinate_unavailable,
             true, "pid numbers are not process-instance identity");
    value = exact; clear_from_preoffer_alias(value);
    add_case(rows, "receiver_preoffer_candidate_alias_present", value,
             SealedSnapshotOfferDisposition::
                 receiver_preoffer_candidate_alias_present,
             true,
             "the offer cannot be the receiver's first candidate ingress when a candidate alias already exists");
    value = exact; value.ready_frame_sent = false; clear_from_message(value);
    add_case(rows, "ready_not_sent", value,
             SealedSnapshotOfferDisposition::ready_frame_unsent, true,
             "offer cannot race receiver profile setup");
    value = exact; clear_from_message(value);
    add_case(rows, "offer_absent", value,
             SealedSnapshotOfferDisposition::offer_unavailable, true,
             "no retry or alternate ingress is authorized");

    value = exact; clear_envelope_and_descriptor(value);
    value.message_data_truncated = true;
    add_case(rows, "data_truncated", value,
             SealedSnapshotOfferDisposition::message_data_truncated, true,
             "truncated protocol bytes are never interpreted");
    value = exact; clear_envelope_and_descriptor(value);
    value.message_control_truncated = true;
    add_case(rows, "control_truncated", value,
             SealedSnapshotOfferDisposition::message_control_truncated, true,
             "truncated ancillary state is rejected as a whole");
    value = exact; value.offer_payload_exact = false; clear_descriptor(value);
    add_case(rows, "payload_mismatch", value,
             SealedSnapshotOfferDisposition::offer_payload_rejected, true,
             "no caller-selected metadata enters the protocol");
    value = exact; value.exactly_one_rights_record = false;
    value.exactly_one_rights_descriptor = false;
    clear_descriptor(value);
    add_case(rows, "rights_record_missing_or_multiple", value,
             SealedSnapshotOfferDisposition::ancillary_shape_rejected, true,
             "the accepted envelope contains exactly one SCM_RIGHTS control record");
    value = exact; value.exactly_one_rights_descriptor = false;
    clear_descriptor(value);
    add_case(rows, "one_rights_record_multiple_descriptors", value,
             SealedSnapshotOfferDisposition::ancillary_shape_rejected, true,
             "one SCM_RIGHTS record may carry multiple descriptors; descriptor cardinality is independent");
    value = exact; value.exactly_one_credentials_record = false;
    value.message_credentials_match_peer = false; clear_descriptor(value);
    add_case(rows, "credentials_missing_or_multiple", value,
             SealedSnapshotOfferDisposition::ancillary_shape_rejected, true,
             "credential multiplicity is fail closed");
    value = exact; value.exactly_one_pidfd_record = false;
    value.message_process_matches_peer = false; clear_descriptor(value);
    add_case(rows, "pidfd_missing_or_multiple", value,
             SealedSnapshotOfferDisposition::ancillary_shape_rejected, true,
             "process-coordinate multiplicity is fail closed");
    value = exact; value.no_unknown_control_records = false;
    clear_descriptor(value);
    add_case(rows, "unknown_control_record", value,
             SealedSnapshotOfferDisposition::ancillary_shape_rejected, true,
             "unknown ancillary capability classes are rejected");
    value = exact; value.message_process_matches_peer = false;
    clear_descriptor(value);
    add_case(rows, "message_process_differs", value,
             SealedSnapshotOfferDisposition::process_identity_mismatch, true,
             "socket creation and message sender must identify one process instance");
    value = exact; value.message_credentials_match_peer = false;
    clear_descriptor(value);
    add_case(rows, "message_credentials_differ", value,
             SealedSnapshotOfferDisposition::credential_mismatch, true,
             "creation and message credentials must agree");

    value = exact; value.candidate_descriptor_cloexec = false;
    clear_descriptor(value);
    add_case(rows, "candidate_not_cloexec", value,
             SealedSnapshotOfferDisposition::candidate_descriptor_not_cloexec,
             true, "received rights must be installed close-on-exec");
    value = exact; value.candidate_descriptor_readable = false;
    add_case(rows, "candidate_write_only", value,
             SealedSnapshotOfferDisposition::candidate_descriptor_not_readable,
             true,
             "a fully sealed write-only alias is not a pread-capable V11 source");
    value = exact; value.candidate_regular = false;
    value.candidate_unlinked = false; value.candidate_seal_query_supported = false;
    value.candidate_seal_write = false; value.candidate_seal_grow = false;
    value.candidate_seal_shrink = false; value.candidate_seal_seal = false;
    value.candidate_size_bounded = false;
    add_case(rows, "candidate_nonregular", value,
             SealedSnapshotOfferDisposition::candidate_descriptor_not_regular,
             true, "special objects never reach byte reads");
    value = exact; value.candidate_unlinked = false;
    value.candidate_size_bounded = false;
    add_case(rows, "candidate_linked", value,
             SealedSnapshotOfferDisposition::candidate_descriptor_linked,
             true, "a namespace-visible regular file is outside the snapshot profile");
    value = exact; value.candidate_seal_query_supported = false;
    value.candidate_seal_write = false; value.candidate_seal_grow = false;
    value.candidate_seal_shrink = false; value.candidate_seal_seal = false;
    value.candidate_size_bounded = false;
    add_case(rows, "seal_query_unavailable", value,
             SealedSnapshotOfferDisposition::candidate_seal_query_unavailable,
             true, "regular-file shape does not imply immutable bytes");
    value = exact; value.candidate_seal_write = false;
    add_case(rows, "write_seal_missing", value,
             SealedSnapshotOfferDisposition::candidate_required_seals_missing,
             true, "unrevoked writers defeat digest custody");
    value = exact; value.candidate_seal_grow = false;
    add_case(rows, "grow_seal_missing", value,
             SealedSnapshotOfferDisposition::candidate_required_seals_missing,
             true, "snapshot length cannot remain growable");
    value = exact; value.candidate_seal_shrink = false;
    add_case(rows, "shrink_seal_missing", value,
             SealedSnapshotOfferDisposition::candidate_required_seals_missing,
             true, "snapshot length cannot remain shrinkable");
    value = exact; value.candidate_seal_seal = false;
    add_case(rows, "seal_seal_missing", value,
             SealedSnapshotOfferDisposition::candidate_required_seals_missing,
             true, "the seal set itself must be irreversible");
    value = exact; value.candidate_size_bounded = false;
    add_case(rows, "candidate_size_unbounded", value,
             SealedSnapshotOfferDisposition::candidate_size_rejected,
             true, "resource custody precedes any candidate byte read");

    value = exact; value.receiver_preoffer_candidate_aliases_zero = false;
    add_case(rows, "incoherent_ready_with_preoffer_alias", value,
             SealedSnapshotOfferDisposition::observation_incoherent, true,
             "READY and descriptor observations cannot coexist with a pre-offer candidate alias");
    value = exact; value.acquisition_actor_admitted_before_ready = false;
    add_case(rows, "incoherent_ready_before_actor_admission", value,
             SealedSnapshotOfferDisposition::observation_incoherent, true,
             "READY cannot precede the external actor-admission cut");
    value = exact; value.acquisition_actor_admitted_before_ready = false;
    value.ready_frame_sent = false;
    add_case(rows, "incoherent_descriptor_import_before_actor_admission", value,
             SealedSnapshotOfferDisposition::observation_incoherent, true,
             "descriptor observations cannot exist before actor admission and READY");
    value = exact; value.one_message_received = false;
    add_case(rows, "incoherent_descriptor_before_message", value,
             SealedSnapshotOfferDisposition::observation_incoherent, true,
             "descriptor observations cannot precede message receipt");
    value = exact; value.peer_pidfd_observed = false;
    add_case(rows, "incoherent_process_match_without_peer", value,
             SealedSnapshotOfferDisposition::observation_incoherent, true,
             "identity equality needs both observed endpoints");

    counterexamples = {
        {"arbitrary_regular_fd_is_mutable", true,
         "claim that fstat regular-file shape establishes stable bytes",
         "require an unlinked descriptor with all four inode seals"},
        {"linked_regular_snapshot_has_namespace_writer_surface", true,
         "claim that read-only receipt excludes external mutation",
         "reject linked candidates before reading"},
        {"write_seal_omission_retains_writer", true,
         "claim that unlink plus mode change revokes existing writers",
         "F_SEAL_WRITE is mandatory"},
        {"resize_seal_omission_changes_length", true,
         "claim that write sealing alone freezes the admitted extent",
         "require grow and shrink seals"},
        {"seal_seal_omission_keeps_seal_state_open", true,
         "claim that a mutable seal set is the terminal barrier",
         "require F_SEAL_SEAL"},
        {"one_scm_rights_record_can_carry_multiple_descriptors", true,
         "claim that one SCM_RIGHTS record proves one delivered descriptor",
         "require one record and exactly one descriptor as separate premises"},
        {"fork_inheritance_can_preinstall_candidate_alias", true,
         "claim that a post-fork SCM_RIGHTS receive is necessarily first receiver ingress",
         "construct the receiver before candidate creation or otherwise prove zero pre-offer aliases"},
        {"scm_rights_duplicates_open_file_description", true,
         "claim that descriptor delivery is a one-use transfer",
         "retain one-use and exclusive-custody nonclaims"},
        {"msg_peek_can_duplicate_rights_delivery", true,
         "claim that one datagram means one installed descriptor globally",
         "do not treat transport as a spend primitive"},
        {"stream_socket_erases_message_boundary", true,
         "claim that a byte stream preserves the exact one-offer frame",
         "require SOCK_SEQPACKET"},
        {"control_truncation_loses_ancillary_shape", true,
         "claim that payload bytes may be parsed when MSG_CTRUNC is set",
         "reject and close every delivered descriptor first"},
        {"so_peercred_is_creation_coordinate", true,
         "claim that peer credentials alone identify every later sender",
         "require per-message credentials and pidfd agreement"},
        {"precreated_socketpair_sender_can_change", true,
         "claim that SO_PEERPIDFD always names the process sending a later message",
         "construct after the final actor and require SCM_PIDFD equality"},
        {"privileged_credential_selection_remains", true,
         "claim that kernel-delivered credentials constitute owner policy",
         "actor admission is a separate external premise"},
        {"unknown_cmsg_can_convey_unreviewed_capability", true,
         "claim that unrecognized ancillary records are harmless metadata",
         "reject the whole envelope before payload interpretation"},
        {"sealed_bytes_are_not_upstream_provenance", true,
         "claim that immutability establishes release origin",
         "V11 digest and profile gates remain downstream"},
        {"synthetic_actor_admission_is_not_governance", true,
         "claim that a test fixture constitutes a living acquisition office",
         "retain Epoch Zero and the external actor premise"},
        {"post_receive_actor_check_imports_unadmitted_authority", true,
         "claim that actor admission may occur after recvmsg installs SCM_RIGHTS",
         "admit the peer before READY and before any rights-bearing receive"},
        {"seal_profile_is_not_creation_history", true,
         "claim that F_GET_SEALS plus nlink zero proves who called memfd_create",
         "treat the profile as current inode behavior, never creator provenance"},
        {"fully_sealed_write_only_descriptor_is_not_a_source", true,
         "claim that complete inode seals imply a descriptor can feed pread",
         "require an independently observed readable access mode before source readiness"},
    };

    require(rows.size() == 36U, "sealed offer case inventory");
    require(counterexamples.size() == 20U,
            "sealed offer counterexample inventory");
    write_cases(output, rows);
    write_counterexamples(output, counterexamples);

    SealedSnapshotOfferCampaignCounts counts;
    counts.cases = rows.size();
    counts.counterexamples = static_cast<std::size_t>(std::count_if(
        counterexamples.begin(), counterexamples.end(),
        [](const CounterexampleRow& row) { return row.reproduced; }));
    counts.admitted_ready_sources = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.sealed_snapshot_source_ready;
        }));
    counts.mechanism_ready_actor_rejections =
        static_cast<std::size_t>(std::count_if(
            rows.begin(), rows.end(), [](const CaseRow& row) {
                return row.assessment.transport_envelope_ready
                    && row.assessment.sealed_descriptor_profile_ready
                    && !row.assessment.acquisition_actor_admitted;
            }));
    counts.preoffer_alias_rejections =
        static_cast<std::size_t>(std::count_if(
            rows.begin(), rows.end(), [](const CaseRow& row) {
                return row.name == "receiver_preoffer_candidate_alias_present"
                    && row.assessment.observation_coherent
                    && !row.assessment.transport_envelope_ready
                    && !row.assessment.candidate_descriptor_received;
            }));
    counts.pre_receive_actor_rejections =
        static_cast<std::size_t>(std::count_if(
            rows.begin(), rows.end(), [](const CaseRow& row) {
                return row.name == "actor_not_admitted_before_ready"
                    && row.assessment.observation_coherent
                    && !row.assessment.transport_envelope_ready
                    && !row.assessment.candidate_descriptor_received;
            }));
    counts.post_receive_authority_import_incoherences =
        static_cast<std::size_t>(std::count_if(
            rows.begin(), rows.end(), [](const CaseRow& row) {
                return row.name == "incoherent_ready_before_actor_admission"
                    || row.name ==
                        "incoherent_descriptor_import_before_actor_admission";
            }));
    counts.incoherent_observations = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return !row.assessment.observation_coherent;
        }));
    require(counts.admitted_ready_sources == 1U,
            "one synthetic admitted source");
    require(counts.mechanism_ready_actor_rejections == 0U,
            "no coherent post-receive actor rejection");
    require(counts.preoffer_alias_rejections == 1U,
            "one pre-offer alias rejection");
    require(counts.pre_receive_actor_rejections == 1U,
            "one pre-receive actor rejection");
    require(counts.post_receive_authority_import_incoherences == 2U,
            "two post-receive authority-import incoherences");
    require(counts.incoherent_observations == 5U,
            "five incoherent observations");
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
