#include <cerrno>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <fcntl.h>
#include <linux/openat2.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

namespace {

constexpr std::string_view kArchiveLeaf{
    "etcd-v3.6.14-linux-amd64.tar.gz"};
static_assert(!kArchiveLeaf.empty());
static_assert(kArchiveLeaf != "." && kArchiveLeaf != "..");
static_assert(kArchiveLeaf.find('/') == std::string_view::npos);
constexpr std::uint64_t kResolvePolicy =
    RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS
    | RESOLVE_NO_MAGICLINKS | RESOLVE_NO_XDEV;
// Linux v7.2-rc5 UAPI. The retained host headers and kernel predate it, so the
// proof uses the exact v7.2-rc5 bit value and requires EINVAL to stop.
constexpr std::uint64_t kOpenat2Regular = UINT64_C(1) << 32U;

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail + " errno=" + std::to_string(errno)
                             + " " + std::strerror(errno));
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
    [[nodiscard]] int get() const noexcept { return value; }
};

struct TempTree final {
    std::filesystem::path path;
    TempTree() {
        std::string pattern = "/tmp/slopos-release-rootfd-probe-XXXXXX";
        std::vector<char> storage(pattern.begin(), pattern.end());
        storage.push_back('\0');
        char* result = ::mkdtemp(storage.data());
        if (result == nullptr) fail("mkdtemp");
        path = result;
    }
    ~TempTree() {
        std::error_code ignored;
        std::filesystem::remove_all(path, ignored);
    }
};

[[nodiscard]] bool same_inode(const struct stat& left,
                              const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino;
}

void write_text(const std::filesystem::path& path,
                const std::string_view body) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("open output " + path.string());
    stream << body;
    if (!stream) throw std::runtime_error("write output " + path.string());
}

void create_regular(const std::filesystem::path& path,
                    const std::string_view body) {
    const UniqueFd fd(::open(path.c_str(),
                             O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC,
                             S_IRUSR | S_IWUSR));
    if (fd.get() < 0) fail("create regular");
    std::size_t offset = 0U;
    while (offset < body.size()) {
        const ssize_t count = ::write(fd.get(), body.data() + offset,
                                      body.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) fail("write regular");
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] std::string pread_exact(const int fd,
                                      const std::size_t bytes,
                                      const off_t offset = 0) {
    std::string body(bytes, '\0');
    std::size_t observed = 0U;
    while (observed < bytes) {
        const ssize_t count = ::pread(
            fd, body.data() + observed, bytes - observed,
            offset + static_cast<off_t>(observed));
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) fail("pread exact");
        observed += static_cast<std::size_t>(count);
    }
    return body;
}

[[nodiscard]] int openat2_raw(const int dirfd,
                              const char* path,
                              const std::uint64_t flags,
                              const std::uint64_t resolve) noexcept {
    struct open_how how {};
    how.flags = flags;
    how.mode = 0U;
    how.resolve = resolve;
    return static_cast<int>(::syscall(
        SYS_openat2, dirfd, path, &how, sizeof(how)));
}

[[nodiscard]] bool rejected_errno(const int result,
                                  const int expected) noexcept {
    return result < 0 && errno == expected;
}

[[nodiscard]] UniqueFd open_path_directory(
    const std::filesystem::path& path) {
    const int fd = ::open(
        path.c_str(), O_PATH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) fail("open O_PATH directory");
    return UniqueFd(fd);
}

}  // namespace

int main(const int argc, char** argv) {
    try {
        if (argc != 2) {
            std::cerr << "usage: slopos_release_rootfd_probe OUTPUT_DIRECTORY\n";
            return 2;
        }
        const std::filesystem::path output(argv[1]);
        std::filesystem::create_directories(output);
        TempTree temporary;

        const auto named_root = temporary.path / "candidate-root";
        const auto retained_root = temporary.path / "retained-root";
        const auto replacement_root = temporary.path / "replacement-root";
        const auto outside_root = temporary.path / "outside-root";
        require(::mkdir(named_root.c_str(), 0700) == 0, "mkdir named root");
        require(::mkdir(replacement_root.c_str(), 0700) == 0,
                "mkdir replacement root");
        require(::mkdir(outside_root.c_str(), 0700) == 0,
                "mkdir outside root");

        constexpr std::string_view original_body{"ORIGINAL-ROOT-ARCHIVE"};
        constexpr std::string_view replacement_body{"REPLACEMENT-ROOT-BYTES"};
        constexpr std::string_view outside_body{"ANCESTOR-SYMLINK-ESCAPE"};
        create_regular(named_root / kArchiveLeaf, original_body);
        create_regular(replacement_root / kArchiveLeaf, replacement_body);
        create_regular(outside_root / kArchiveLeaf, outside_body);

        UniqueFd pinned_root = open_path_directory(named_root);
        struct stat root_before {};
        if (::fstat(pinned_root.get(), &root_before) != 0) fail("fstat root before");
        const int root_status_flags = ::fcntl(pinned_root.get(), F_GETFL);
        const int root_descriptor_flags = ::fcntl(pinned_root.get(), F_GETFD);
        if (root_status_flags < 0 || root_descriptor_flags < 0) {
            fail("fcntl root flags");
        }
        const bool root_owner_matches_euid =
            root_before.st_uid == ::geteuid();
        const bool root_descriptor_profile =
            S_ISDIR(root_before.st_mode)
            && (root_status_flags & O_PATH) != 0
            && (root_descriptor_flags & FD_CLOEXEC) != 0
            && root_owner_matches_euid
            && (root_before.st_mode & 0777U) == 0700U;

        errno = 0;
        UniqueFd support(openat2_raw(
            pinned_root.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy));
        const bool openat2_supported = support.get() >= 0;
        require(openat2_supported, "openat2 support");
        const bool initial_open_reads_original =
            pread_exact(support.get(), original_body.size()) == original_body;

        errno = 0;
        const int regular_only_result = openat2_raw(
            pinned_root.get(), kArchiveLeaf.data(),
            static_cast<std::uint64_t>(
                O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK)
                | kOpenat2Regular,
            kResolvePolicy);
        const bool openat2_regular_supported = regular_only_result >= 0;
        const bool openat2_regular_unavailable =
            rejected_errno(regular_only_result, EINVAL);
        if (regular_only_result >= 0) (void)::close(regular_only_result);
        require(!openat2_regular_supported && openat2_regular_unavailable,
                "retained host OPENAT2_REGULAR profile");

        const auto fifo_root = temporary.path / "fifo-root";
        require(::mkdir(fifo_root.c_str(), 0700) == 0, "mkdir fifo root");
        require(::mkfifo((fifo_root / kArchiveLeaf).c_str(), 0600) == 0,
                "mkfifo fixed leaf");
        UniqueFd fifo_root_fd = open_path_directory(fifo_root);
        errno = 0;
        UniqueFd fifo_legacy(openat2_raw(
            fifo_root_fd.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy));
        struct stat fifo_stat {};
        const bool legacy_fifo_opened_before_shape_check =
            fifo_legacy.get() >= 0
            && ::fstat(fifo_legacy.get(), &fifo_stat) == 0
            && S_ISFIFO(fifo_stat.st_mode);
        const bool production_candidate_descriptor_ready =
            openat2_regular_supported;

        require(::rename(named_root.c_str(), retained_root.c_str()) == 0,
                "rename retained root");
        require(::rename(replacement_root.c_str(), named_root.c_str()) == 0,
                "publish replacement root");

        struct stat current_named_root {};
        if (::lstat(named_root.c_str(), &current_named_root) != 0) {
            fail("lstat replaced root path");
        }
        const bool root_path_identity_changed =
            !same_inode(root_before, current_named_root);

        UniqueFd pinned_leaf(openat2_raw(
            pinned_root.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy));
        if (pinned_leaf.get() < 0) fail("open fixed leaf through pinned root");
        const bool pinned_root_reads_original =
            pread_exact(pinned_leaf.get(), original_body.size()) == original_body;

        UniqueFd reopened_root = open_path_directory(named_root);
        UniqueFd reopened_leaf(openat2_raw(
            reopened_root.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy));
        if (reopened_leaf.get() < 0) fail("open fixed leaf through reopened root");
        const bool reopened_root_reads_replacement =
            pread_exact(reopened_leaf.get(), replacement_body.size())
                == replacement_body;

        struct stat root_after {};
        if (::fstat(pinned_root.get(), &root_after) != 0) fail("fstat root after");
        const bool pinned_root_identity_stable = same_inode(root_before, root_after);
        const bool pinned_root_profile_endpoint_equal =
            pinned_root_identity_stable
            && S_ISDIR(root_after.st_mode)
            && root_after.st_uid == ::geteuid()
            && (root_after.st_mode & 0777U) == 0700U;
        struct stat pinned_leaf_status {};
        if (::fstat(pinned_leaf.get(), &pinned_leaf_status) != 0) {
            fail("fstat pinned leaf");
        }
        const bool fixed_leaf_regular_same_device =
            S_ISREG(pinned_leaf_status.st_mode)
            && pinned_leaf_status.st_dev == root_after.st_dev;

        const auto symlink_root = temporary.path / "symlink-root";
        require(::mkdir(symlink_root.c_str(), 0700) == 0, "mkdir symlink root");
        create_regular(symlink_root / "target", "TARGET");
        require(::symlink("target", (symlink_root / kArchiveLeaf).c_str()) == 0,
                "create leaf symlink");
        UniqueFd symlink_root_fd = open_path_directory(symlink_root);
        errno = 0;
        const int symlink_result = openat2_raw(
            symlink_root_fd.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy);
        const bool leaf_symlink_rejected = rejected_errno(symlink_result, ELOOP);
        if (symlink_result >= 0) (void)::close(symlink_result);

        const auto ancestor_root = temporary.path / "ancestor-root";
        require(::mkdir(ancestor_root.c_str(), 0700) == 0,
                "mkdir ancestor root");
        require(::symlink(outside_root.c_str(), (ancestor_root / "alias").c_str()) == 0,
                "create ancestor symlink");
        UniqueFd ancestor_root_fd = open_path_directory(ancestor_root);
        const std::string widened_leaf_path = "alias/" + std::string(kArchiveLeaf);
        errno = 0;
        const int ancestor_openat2 = openat2_raw(
            ancestor_root_fd.get(), widened_leaf_path.c_str(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy);
        const bool widened_leaf_ancestor_symlink_rejected =
            rejected_errno(ancestor_openat2, ELOOP);
        if (ancestor_openat2 >= 0) (void)::close(ancestor_openat2);

        UniqueFd tail_nofollow(::openat(
            ancestor_root_fd.get(), widened_leaf_path.c_str(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK));
        const bool widened_leaf_tail_nofollow_follows_ancestor =
            tail_nofollow.get() >= 0
            && pread_exact(tail_nofollow.get(), outside_body.size()) == outside_body;

        errno = 0;
        const int dotdot_result = openat2_raw(
            ancestor_root_fd.get(), "../outside-root/etcd-v3.6.14-linux-amd64.tar.gz",
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy);
        const bool dotdot_escape_rejected = rejected_errno(dotdot_result, EXDEV);
        if (dotdot_result >= 0) (void)::close(dotdot_result);

        errno = 0;
        const int absolute_result = openat2_raw(
            ancestor_root_fd.get(), "/etc/passwd",
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy);
        const bool absolute_escape_rejected =
            rejected_errno(absolute_result, EXDEV);
        if (absolute_result >= 0) (void)::close(absolute_result);

        UniqueFd filesystem_root = open_path_directory("/");
        errno = 0;
        const int cross_mount_result = openat2_raw(
            filesystem_root.get(), "proc/version",
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy);
        const bool cross_mount_rejected =
            rejected_errno(cross_mount_result, EXDEV);
        if (cross_mount_result >= 0) (void)::close(cross_mount_result);

        errno = 0;
        constexpr std::uint64_t unknown_resolve = UINT64_C(1) << 63U;
        const int unknown_result = openat2_raw(
            pinned_root.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy | unknown_resolve);
        const bool unknown_resolve_rejected = rejected_errno(unknown_result, EINVAL);
        if (unknown_result >= 0) (void)::close(unknown_result);

        const auto profile_drift_root = temporary.path / "profile-drift-root";
        require(::mkdir(profile_drift_root.c_str(), 0700) == 0,
                "mkdir profile drift root");
        create_regular(profile_drift_root / kArchiveLeaf, "PROFILE-DRIFT");
        UniqueFd profile_drift_root_fd = open_path_directory(profile_drift_root);
        struct stat profile_before {};
        if (::fstat(profile_drift_root_fd.get(), &profile_before) != 0) {
            fail("fstat profile before");
        }
        require((profile_before.st_mode & 0777U) == 0700U,
                "profile drift precondition");
        require(::chmod(profile_drift_root.c_str(), 0755) == 0,
                "chmod profile drift root");
        UniqueFd profile_drift_leaf(openat2_raw(
            profile_drift_root_fd.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy));
        if (profile_drift_leaf.get() < 0) fail("open profile drift leaf");
        struct stat profile_after {};
        if (::fstat(profile_drift_root_fd.get(), &profile_after) != 0) {
            fail("fstat profile after");
        }
        const bool root_profile_drift_open_succeeds =
            same_inode(profile_before, profile_after)
            && (profile_after.st_mode & 0777U) == 0755U;

        const auto profile_aba_root = temporary.path / "profile-aba-root";
        require(::mkdir(profile_aba_root.c_str(), 0700) == 0,
                "mkdir profile ABA root");
        create_regular(profile_aba_root / kArchiveLeaf, "PROFILE-ABA");
        UniqueFd profile_aba_root_fd = open_path_directory(profile_aba_root);
        struct stat profile_aba_before {};
        if (::fstat(profile_aba_root_fd.get(), &profile_aba_before) != 0) {
            fail("fstat profile ABA before");
        }
        require((profile_aba_before.st_mode & 0777U) == 0700U,
                "profile ABA precondition");
        require(::chmod(profile_aba_root.c_str(), 0755) == 0,
                "chmod profile ABA away");
        UniqueFd profile_aba_leaf(openat2_raw(
            profile_aba_root_fd.get(), kArchiveLeaf.data(),
            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK,
            kResolvePolicy));
        if (profile_aba_leaf.get() < 0) fail("open profile ABA leaf");
        require(::chmod(profile_aba_root.c_str(), 0700) == 0,
                "chmod profile ABA restore");
        struct stat profile_aba_after {};
        if (::fstat(profile_aba_root_fd.get(), &profile_aba_after) != 0) {
            fail("fstat profile ABA after");
        }
        const bool root_profile_aba_endpoint_equality =
            same_inode(profile_aba_before, profile_aba_after)
            && (profile_aba_before.st_mode & 0777U) == 0700U
            && (profile_aba_after.st_mode & 0777U) == 0700U;

        UniqueFd mutable_writer(::open(
            (retained_root / kArchiveLeaf).c_str(), O_WRONLY | O_CLOEXEC));
        if (mutable_writer.get() < 0) fail("open retained writer");
        constexpr char changed{'M'};
        if (::pwrite(mutable_writer.get(), &changed, 1U, 0) != 1) {
            fail("mutate opened leaf");
        }
        const bool rooted_leaf_still_mutable_before_snapshot =
            pread_exact(pinned_leaf.get(), 1U) == "M";

        const bool pass = root_descriptor_profile && openat2_supported
            && initial_open_reads_original && root_path_identity_changed
            && pinned_root_reads_original && reopened_root_reads_replacement
            && pinned_root_identity_stable && pinned_root_profile_endpoint_equal
            && fixed_leaf_regular_same_device
            && leaf_symlink_rejected && widened_leaf_ancestor_symlink_rejected
            && widened_leaf_tail_nofollow_follows_ancestor
            && dotdot_escape_rejected
            && absolute_escape_rejected && cross_mount_rejected
            && unknown_resolve_rejected && root_profile_drift_open_succeeds
            && root_profile_aba_endpoint_equality
            && rooted_leaf_still_mutable_before_snapshot
            && openat2_regular_unavailable
            && legacy_fifo_opened_before_shape_check
            && !production_candidate_descriptor_ready;
        if (!pass) throw std::runtime_error("rootfd probe predicate failed");

        write_text(output / "release-rootfd-cases.tsv",
            "case\texpected\tobserved\tstatus\n"
            "openat2_supported\tsyscall succeeds\tsyscall succeeds\tPASS\n"
            "openat2_regular_supported\tunsupported host returns EINVAL\tEINVAL\tPASS\n"
            "legacy_fifo_open_before_fstat\told flags return FIFO descriptor\tFIFO descriptor returned before shape check\tPASS\n"
            "production_regular_only_gate\tstop without candidate descriptor\tSTOP HOST_OPENAT2_REGULAR_UNAVAILABLE\tPASS\n"
            "root_descriptor_profile\tO_PATH directory EUID-owned 0700 CLOEXEC\tO_PATH directory EUID-owned 0700 CLOEXEC\tPASS\n"
            "initial_rooted_open\toriginal bytes\toriginal bytes\tPASS\n"
            "root_path_replacement\tdifferent named-root inode\tdifferent named-root inode\tPASS\n"
            "pinned_root_after_replacement\toriginal bytes\toriginal bytes\tPASS\n"
            "reopened_root_after_replacement\treplacement bytes\treplacement bytes\tPASS\n"
            "pinned_root_identity\tstable device and inode\tstable device and inode\tPASS\n"
            "fixed_leaf_shape\tregular same-device leaf\tregular same-device leaf\tPASS\n"
            "leaf_symlink\tELOOP\tELOOP\tPASS\n"
            "widened_leaf_ancestor_symlink_openat2\tELOOP\tELOOP\tPASS\n"
            "widened_leaf_ancestor_symlink_tail_nofollow\tescape bytes observed\tescape bytes observed\tPASS\n"
            "dotdot_escape\tEXDEV\tEXDEV\tPASS\n"
            "absolute_escape\tEXDEV\tEXDEV\tPASS\n"
            "cross_mount\tEXDEV\tEXDEV\tPASS\n"
            "unknown_resolve_bit\tEINVAL\tEINVAL\tPASS\n"
            "root_profile_change_after_pin\topen succeeds and post-profile differs\topen succeeds and mode changed to 0755\tPASS\n"
            "root_profile_aba_between_checks\tpre/post 0700 with transient 0755\tpre/post 0700 and open succeeds after transient drift\tPASS\n"
            "rooted_leaf_before_snapshot\tmutable through another writer\tmutated byte observed\tPASS\n");
        write_text(output / "release-rootfd-counterexamples.tsv",
            "id\ttempting_inference\tcounterexample\tconsequence\n"
            "RF01\tthe fixed leaf may later widen to a nested path while tail O_NOFOLLOW remains sufficient\ta widened two-component fixture lets openat follow an ancestor symlink and read escape bytes\tkeep the production leaf one component and retain complete openat2 resolution as an evolution guard\n"
            "RF02\ta root pathname preserves root identity\treplacing the root pathname makes a later reopen read another tree\tretain and use the supplied root descriptor only\n"
            "RF03\tan O_PATH root constitutes owner custody\tthe same host actor renames the tree and publishes a replacement\towner constitution remains an external premise\n"
            "RF04\trooted lookup freezes candidate bytes\tan independent writer mutates the already-open leaf\tcopy into and seal one private snapshot before digest\n"
            "RF05\tsame-device regular shape proves upstream provenance\tlocal fixtures satisfy the shape without any upstream root\tverify supply-chain identity separately\n"
            "RF06\tRESOLVE_BENEATH alone is an evolution-safe complete policy\twidened ancestor traversal and mount crossing are controlled by independent bits\tretain the complete fixed resolve mask even though the current leaf has one component\n"
            "RF07\ta rooted candidate descriptor authorizes activation\tprobe reads bytes only and exposes no exec or provider call\tfeed passive admission and keep activation separate\n"
            "RF08\ta prelookup 0700 owner check remains stable\tthe pinned directory mode changes while openat2 still succeeds\treobserve the pinned root profile after lookup\n"
            "RF09\tequal pre/post root profile proves continuity\tthe mode changes 0700 to 0755 to 0700 while openat2 succeeds\trecord endpoint equality only; continuous custody remains unproved\n"
            "RF10\tpost-open fstat prevents opening special files\told openat2 flags return a readable FIFO descriptor before fstat can reject it\trequire OPENAT2_REGULAR atomically at open time\n"
            "RF11\tan unsupported regular-only flag may fall back to open-then-fstat\tthe retained 6.12 kernel returns EINVAL for the exact upper-bit flag\tstop before candidate acquisition and never weaken the open policy\n");
        write_text(output / "release-rootfd-summary.json",
            "{\n"
            "  \"activation_authority\": false,\n"
            "  \"archive_digest_compared\": false,\n"
            "  \"archive_parsed\": false,\n"
            "  \"cases\": 21,\n"
            "  \"counterexamples\": 11,\n"
            "  \"cross_mount_rejected\": true,\n"
            "  \"fixed_leaf_components\": 1,\n"
            "  \"fixed_leaf_regular_same_device\": true,\n"
            "  \"fixed_leaf_single_component\": true,\n"
            "  \"leaf_symlink_rejected\": true,\n"
            "  \"legacy_fifo_opened_before_shape_check\": true,\n"
            "  \"openat2_regular_required\": true,\n"
            "  \"openat2_regular_supported\": false,\n"
            "  \"openat2_supported\": true,\n"
            "  \"owner_custody_proved\": false,\n"
            "  \"path_reopen_reads_replacement\": true,\n"
            "  \"post_open_shape_check_is_too_late\": true,\n"
            "  \"production_candidate_descriptor_ready\": false,\n"
            "  \"production_stop_reason\": \"HOST_OPENAT2_REGULAR_UNAVAILABLE\",\n"
            "  \"pinned_root_reads_original\": true,\n"
            "  \"resolve_policy\": \"BENEATH|NO_SYMLINKS|NO_MAGICLINKS|NO_XDEV\",\n"
            "  \"root_descriptor_profile\": \"O_PATH_DIRECTORY_EUID_0700_CLOEXEC\",\n"
            "  \"root_owner_matches_euid\": true,\n"
            "  \"root_identity_stable\": true,\n"
            "  \"root_profile_aba_reproduced\": true,\n"
            "  \"root_profile_continuity_proved\": false,\n"
            "  \"root_profile_drift_open_succeeds\": true,\n"
            "  \"root_profile_endpoint_equality_observed\": true,\n"
            "  \"rooted_leaf_mutable_before_snapshot\": true,\n"
            "  \"schema\": \"slopos.rev0900.release-rootfd-probe.v4\",\n"
            "  \"source_provenance_proved\": false,\n"
            "  \"status\": \"PASS\",\n"
            "  \"widened_leaf_tail_nofollow_ancestor_escape_reproduced\": true,\n"
            "  \"unknown_resolve_bit_rejected\": true\n"
            "}\n");
        std::cout
            << "RELEASE_ROOTFD_PROBE=PASS cases=21 counterexamples=11 "
            << "openat2=true openat2_regular=false production=STOP "
            << "rootfd=O_PATH_PRIVATE fixed_leaf=true "
            << "root_swap=PINNED_ORIGINAL reopen=REPLACEMENT "
            << "widened_leaf_regression=tail_nofollow_escape openat2=ELOOP "
            << "cross_mount=EXDEV fifo_open_before_fstat=true "
            << "profile_drift_open=true profile_aba=true continuity=false mutable_before_snapshot=true "
            << "authority=false\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "RELEASE_ROOTFD_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
