#include "actor_exec_binding_campaign.hpp"

#include "slopos/e0/handoff_cell/actor_exec_binding.hpp"

#include <algorithm>
#include <array>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

using slopos::e0::handoff_cell::ActorExecAssessment;
using slopos::e0::handoff_cell::ActorExecDisposition;
using slopos::e0::handoff_cell::ActorExecObservationV2;
using slopos::e0::handoff_cell::actor_exec_disposition_name;
using slopos::e0::handoff_cell::assess_actor_exec_binding;

constexpr std::array<bool ActorExecObservationV2::*, 49U> kFields = {
    &ActorExecObservationV2::profile_supplied,
    &ActorExecObservationV2::executable_descriptor_supplied,
    &ActorExecObservationV2::executable_regular,
    &ActorExecObservationV2::executable_readable,
    &ActorExecObservationV2::executable_unlinked,
    &ActorExecObservationV2::executable_size_bounded,
    &ActorExecObservationV2::executable_profile_digest_exact,
    &ActorExecObservationV2::executable_seal_query_supported,
    &ActorExecObservationV2::executable_seal_write,
    &ActorExecObservationV2::executable_seal_grow,
    &ActorExecObservationV2::executable_seal_shrink,
    &ActorExecObservationV2::executable_seal_seal,
    &ActorExecObservationV2::child_single_threaded,
    &ActorExecObservationV2::child_file_table_private_until_exec,
    &ActorExecObservationV2::child_address_space_private_until_exec,
    &ActorExecObservationV2::challenge_endpoint_exclusive_to_tracee,
    &ActorExecObservationV2::actor_pidfd_supplied_before_release,
    &ActorExecObservationV2::tracer_established_before_release,
    &ActorExecObservationV2::traceexec_armed_before_release,
    &ActorExecObservationV2::execveat_entry_observed,
    &ActorExecObservationV2::execveat_arch_exact,
    &ActorExecObservationV2::execveat_empty_path,
    &ActorExecObservationV2::execveat_flags_exact,
    &ActorExecObservationV2::execveat_target_fd_exact,
    &ActorExecObservationV2::exec_argument_memory_stable_until_consumed,
    &ActorExecObservationV2::pidfd_getfd_supported,
    &ActorExecObservationV2::target_descriptor_duplicated_while_stopped,
    &ActorExecObservationV2::target_regular,
    &ActorExecObservationV2::target_same_inode_as_sealed_executable,
    &ActorExecObservationV2::target_required_seals_present,
    &ActorExecObservationV2::target_digest_exact,
    &ActorExecObservationV2::exec_event_completes_observed_entry,
    &ActorExecObservationV2::successful_exec_event_observed,
    &ActorExecObservationV2::exactly_one_exec_event,
    &ActorExecObservationV2::challenge_generated_after_exec_event,
    &ActorExecObservationV2::challenge_response_exact,
    &ActorExecObservationV2::runtime_interpreter_and_objects_bound,
    &ActorExecObservationV2::exec_epoch_held_through_actor_admission,
    &ActorExecObservationV2::pre_exec_privilege_floor_exact,
    &ActorExecObservationV2::pre_exec_seccomp_filter_exact,
    &ActorExecObservationV2::v14_dossier_admissible,
    &ActorExecObservationV2::dossier_appraised_after_bound_exec,
    &ActorExecObservationV2::dossier_executable_digest_matches_exec_target,
    &ActorExecObservationV2::dossier_process_coordinate_matches_launch,
    &ActorExecObservationV2::dossier_runtime_objects_match_launch,
    &ActorExecObservationV2::dossier_challenge_matches_post_exec_epoch,
    &ActorExecObservationV2::dossier_launch_envelope_matches_observed_exec,
    &ActorExecObservationV2::dossier_privilege_and_filter_match_launch,
    &ActorExecObservationV2::dossier_inherited_descriptor_inventory_matches_launch,
};

constexpr std::array<std::string_view, 49U> kCutNames = {
    "missing_profile",
    "missing_executable_descriptor",
    "nonregular_executable",
    "unreadable_executable",
    "linked_executable",
    "oversized_executable",
    "executable_profile_digest_mismatch",
    "seal_query_unavailable",
    "write_seal_missing",
    "grow_seal_missing",
    "shrink_seal_missing",
    "seal_seal_missing",
    "single_threaded_child_unproved",
    "private_file_table_unproved",
    "private_address_space_unproved",
    "challenge_endpoint_exclusivity_unproved",
    "actor_pidfd_missing_before_release",
    "tracer_not_established_before_release",
    "traceexec_not_armed_before_release",
    "execveat_entry_unobserved",
    "execveat_architecture_mismatch",
    "execveat_path_not_empty",
    "execveat_flags_not_exact",
    "execveat_target_fd_not_exact",
    "exec_argument_memory_custody_unproved",
    "pidfd_getfd_unavailable",
    "target_descriptor_not_duplicated_while_stopped",
    "target_descriptor_not_regular",
    "target_inode_mismatch",
    "target_required_seals_missing",
    "target_digest_mismatch",
    "exec_event_not_linked_to_observed_entry",
    "successful_exec_event_unobserved",
    "multiple_exec_events",
    "challenge_not_generated_after_exec_event",
    "challenge_response_mismatch",
    "runtime_interpreter_or_objects_unbound",
    "exec_epoch_not_held_through_admission",
    "pre_exec_privilege_floor_unproved",
    "pre_exec_seccomp_filter_unproved",
    "v14_dossier_unavailable",
    "dossier_not_appraised_after_bound_exec",
    "dossier_executable_digest_mismatch",
    "dossier_process_coordinate_mismatch",
    "dossier_runtime_object_mismatch",
    "dossier_challenge_epoch_mismatch",
    "dossier_launch_envelope_mismatch",
    "dossier_privilege_floor_mismatch",
    "dossier_descriptor_inventory_mismatch",
};

constexpr std::array<ActorExecDisposition, 49U> kExpected = {
    ActorExecDisposition::profile_unavailable,
    ActorExecDisposition::executable_descriptor_unavailable,
    ActorExecDisposition::executable_shape_rejected,
    ActorExecDisposition::executable_shape_rejected,
    ActorExecDisposition::executable_shape_rejected,
    ActorExecDisposition::executable_shape_rejected,
    ActorExecDisposition::executable_digest_mismatch,
    ActorExecDisposition::executable_mutability_rejected,
    ActorExecDisposition::executable_mutability_rejected,
    ActorExecDisposition::executable_mutability_rejected,
    ActorExecDisposition::executable_mutability_rejected,
    ActorExecDisposition::executable_mutability_rejected,
    ActorExecDisposition::single_threaded_child_unproved,
    ActorExecDisposition::file_table_custody_unproved,
    ActorExecDisposition::address_space_custody_unproved,
    ActorExecDisposition::challenge_channel_custody_unproved,
    ActorExecDisposition::pidfd_coordinate_unavailable,
    ActorExecDisposition::tracer_unavailable,
    ActorExecDisposition::traceexec_not_armed,
    ActorExecDisposition::execveat_entry_unobserved,
    ActorExecDisposition::execveat_contract_rejected,
    ActorExecDisposition::execveat_contract_rejected,
    ActorExecDisposition::execveat_contract_rejected,
    ActorExecDisposition::execveat_contract_rejected,
    ActorExecDisposition::exec_argument_memory_custody_unproved,
    ActorExecDisposition::target_descriptor_query_unavailable,
    ActorExecDisposition::target_descriptor_unavailable,
    ActorExecDisposition::target_object_mismatch,
    ActorExecDisposition::target_object_mismatch,
    ActorExecDisposition::target_seal_mismatch,
    ActorExecDisposition::target_digest_mismatch,
    ActorExecDisposition::exec_event_not_linked_to_entry,
    ActorExecDisposition::exec_event_unobserved,
    ActorExecDisposition::multiple_exec_events,
    ActorExecDisposition::challenge_order_rejected,
    ActorExecDisposition::challenge_response_rejected,
    ActorExecDisposition::runtime_objects_unbound,
    ActorExecDisposition::exec_epoch_custody_unproved,
    ActorExecDisposition::pre_exec_privilege_floor_unproved,
    ActorExecDisposition::pre_exec_seccomp_filter_unproved,
    ActorExecDisposition::v14_dossier_unavailable,
    ActorExecDisposition::dossier_order_rejected,
    ActorExecDisposition::dossier_executable_mismatch,
    ActorExecDisposition::dossier_process_mismatch,
    ActorExecDisposition::dossier_runtime_mismatch,
    ActorExecDisposition::dossier_challenge_mismatch,
    ActorExecDisposition::dossier_launch_envelope_mismatch,
    ActorExecDisposition::dossier_privilege_floor_mismatch,
    ActorExecDisposition::dossier_descriptor_inventory_mismatch,
};

struct CaseRow final {
    std::string name;
    ActorExecAssessment assessment;
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    std::string defeats;
    std::string retained_law;
};

[[nodiscard]] std::string boolean(const bool value) {
    return value ? "true" : "false";
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] ActorExecObservationV2 prefix_observation(
    const std::size_t count) {
    ActorExecObservationV2 observation;
    for (std::size_t index = 0U; index < count; ++index) {
        observation.*kFields[index] = true;
    }
    return observation;
}

void add_case(std::vector<CaseRow>& rows, const std::string& name,
              const ActorExecObservationV2& observation,
              const ActorExecDisposition expected,
              const bool counterexample, const std::string& judgment) {
    const ActorExecAssessment assessment = assess_actor_exec_binding(observation);
    require(assessment.disposition == expected,
            "actor-exec disposition " + name);
    require(!assessment.complete_process_image_bound
                && !assessment.network_attempted && !assessment.ready_sent
                && !assessment.rights_imported && !assessment.candidate_created
                && !assessment.candidate_bytes_read
                && !assessment.archive_acquired && !assessment.archive_admitted
                && !assessment.source_provenance_proved
                && !assessment.owner_authority && !assessment.living_law,
            "actor-exec authority leak " + name);
    rows.push_back({name, assessment, counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "actor-exec-cases.tsv", std::ios::binary);
    require(stream.good(), "open actor-exec-cases.tsv");
    stream << "case\tdisposition\tobservation_coherent\tsealed_exec_input_exact"
              "\tlaunch_coordinate_custody\ttraceexec_prearmed"
              "\texecveat_contract_observed\ttarget_descriptor_snapshotted"
              "\ttarget_object_exact\ttarget_digest_exact"
              "\tsuccessful_exec_event_exact\tpost_exec_challenge_exact"
              "\texec_input_object_bound\truntime_object_set_bound"
              "\texec_epoch_held\tpre_exec_floor_bound"
              "\tv14_dossier_bound_to_exec_epoch"
              "\teligible_for_v13_actor_premise\tcomplete_process_image_bound"
              "\tnetwork_attempted\tready_sent\trights_imported"
              "\tcandidate_created\tcandidate_bytes_read\tarchive_acquired"
              "\tarchive_admitted\tsource_provenance_proved"
              "\towner_authority\tliving_law\tretained_counterexample"
              "\tjudgment\n";
    for (const CaseRow& row : rows) {
        const ActorExecAssessment& a = row.assessment;
        stream << row.name << '\t' << actor_exec_disposition_name(a.disposition)
               << '\t' << boolean(a.observation_coherent)
               << '\t' << boolean(a.sealed_exec_input_exact)
               << '\t' << boolean(a.launch_coordinate_custody)
               << '\t' << boolean(a.traceexec_prearmed)
               << '\t' << boolean(a.execveat_contract_observed)
               << '\t' << boolean(a.target_descriptor_snapshotted)
               << '\t' << boolean(a.target_object_exact)
               << '\t' << boolean(a.target_digest_exact)
               << '\t' << boolean(a.successful_exec_event_exact)
               << '\t' << boolean(a.post_exec_challenge_exact)
               << '\t' << boolean(a.exec_input_object_bound)
               << '\t' << boolean(a.runtime_object_set_bound)
               << '\t' << boolean(a.exec_epoch_held)
               << '\t' << boolean(a.pre_exec_floor_bound)
               << '\t' << boolean(a.v14_dossier_bound_to_exec_epoch)
               << '\t' << boolean(a.eligible_for_v13_actor_premise)
               << '\t' << boolean(a.complete_process_image_bound)
               << '\t' << boolean(a.network_attempted)
               << '\t' << boolean(a.ready_sent)
               << '\t' << boolean(a.rights_imported)
               << '\t' << boolean(a.candidate_created)
               << '\t' << boolean(a.candidate_bytes_read)
               << '\t' << boolean(a.archive_acquired)
               << '\t' << boolean(a.archive_admitted)
               << '\t' << boolean(a.source_provenance_proved)
               << '\t' << boolean(a.owner_authority)
               << '\t' << boolean(a.living_law)
               << '\t' << boolean(row.retained_counterexample)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "actor-exec-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open actor-exec-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const ActorExecCampaignCounts& counts) {
    std::ofstream stream(output / "actor-exec-summary.json", std::ios::binary);
    require(stream.good(), "open actor-exec-summary.json");
    stream << "{\n"
           << "  \"archive_acquired\": false,\n"
           << "  \"archive_admitted\": false,\n"
           << "  \"candidate_bytes_read\": false,\n"
           << "  \"cases\": " << counts.cases << ",\n"
           << "  \"complete_process_image_bound\": false,\n"
           << "  \"counterexamples_reproduced\": "
           << counts.counterexamples << ",\n"
           << "  \"eligible_for_v13_profiles\": "
           << counts.v13_eligible_profiles << ",\n"
           << "  \"exec_epoch_held_profiles\": "
           << counts.exec_epoch_held_profiles << ",\n"
           << "  \"exec_input_bound_profiles\": "
           << counts.exec_input_bound_profiles << ",\n"
           << "  \"incoherent_observations\": "
           << counts.incoherent_observations << ",\n"
           << "  \"pre_exec_floor_bound_profiles\": "
           << counts.pre_exec_floor_bound_profiles << ",\n"
           << "  \"living_law\": false,\n"
           << "  \"network_attempted\": false,\n"
           << "  \"owner_authority\": false,\n"
           << "  \"ready_sent\": false,\n"
           << "  \"rights_imported\": false,\n"
           << "  \"runtime_object_set_bound_profiles\": "
           << counts.runtime_object_set_bound_profiles << ",\n"
           << "  \"schema\": \"slopos.rev0903.actor-exec-target-binding-campaign.v15\",\n"
           << "  \"source_provenance_proved\": false,\n"
           << "  \"status\": \"PASS\",\n"
           << "  \"v14_alone_eligible_for_v13\": false\n"
           << "}\n";
}

}  // namespace

ActorExecCampaignCounts run_actor_exec_binding_campaign(
    const std::filesystem::path& output) {
    std::vector<CaseRow> rows;
    for (std::size_t cut = 0U; cut < kFields.size(); ++cut) {
        add_case(rows, std::string(kCutNames[cut]), prefix_observation(cut),
                 kExpected[cut], true, "FAIL_CLOSED_AT_ORDERED_CUT");
    }
    ActorExecObservationV2 incoherent;
    incoherent.executable_descriptor_supplied = true;
    add_case(rows, "incoherent_descriptor_without_profile", incoherent,
             ActorExecDisposition::observation_incoherent, true,
             "ORDERED_PREFIX_REJECTED");
    add_case(rows, "synthetic_exact_exec_epoch_and_v14_dossier",
             prefix_observation(kFields.size()),
             ActorExecDisposition::actor_exec_and_dossier_bound, false,
             "V13_ACTOR_PREMISE_ONLY_NO_ACQUISITION_AUTHORITY");

    const std::vector<CounterexampleRow> counterexamples = {
        {"digest_plan_is_running_image", "pinned launch-plan digest as post-exec identity", "observe and bind the execveat input object at the syscall-entry stop"},
        {"pidfd_creds_are_executable_identity", "pidfd credential coordinate as image identity", "process coordinates and exec-input identity are independent"},
        {"exec_event_without_target_binding", "PTRACE_EVENT_EXEC alone as proof of which object supplied exec", "bind the stopped execveat target object before resuming"},
        {"observed_entry_then_different_exec", "an earlier matching execveat entry plus a later unrelated exec event", "the successful event must complete the observed entry"},
        {"target_fd_number_is_object_identity", "raw child descriptor number as durable identity", "duplicate through the pidfd while stopped and compare object facts"},
        {"same_digest_is_same_object", "equal bytes as the same custody object", "require immutable-object identity in addition to digest equality"},
        {"fstat_identity_is_mutability_barrier", "inode equality as immutable exec-input bytes", "require the write grow shrink and seal barrier"},
        {"seal_set_is_source_provenance", "sealed exec input as release provenance", "seals constrain present mutation and say nothing about origin"},
        {"trace_attached_after_exec", "post-exec tracing as proof the transition was observed", "arm TRACEEXEC before the child is released"},
        {"single_threaded_means_private_files", "one thread as closure of CLONE_FILES peers", "prove private file-table custody through the exec event"},
        {"challenge_fd_has_no_helper_alias", "single tracee thread as proof no helper can answer the nonce", "prove exclusive tracee-side challenge-endpoint custody"},
        {"execveat_flags_subset_is_exact", "AT_EMPTY_PATH presence as the exact flag contract", "require exact architecture path flags and descriptor arguments"},
        {"challenge_sent_before_exec_is_fresh", "pre-exec nonce echo as post-exec liveness", "generate the challenge only after the linked exec event"},
        {"challenge_echo_is_image_identity", "nonce response alone as proof of executable bytes", "challenge composes only after target-object and exec-event binding"},
        {"main_elf_object_is_complete_image", "the exec input object as interpreter and shared-object identity", "bind the runtime object set separately or retain the stop"},
        {"dependency_plan_is_loaded_set", "a dossier dependency manifest as proof of objects actually loaded", "runtime objects require their own observation and cross-binding"},
        {"admitted_actor_cannot_exec_again", "one admitted exec epoch as future image custody", "hold the process or block later exec transitions through V13 admission"},
        {"proc_exe_is_production_authority", "host-lab /proc/self/exe fixture as admitted source", "production requires externally supplied sealed descriptor custody"},
        {"pidfd_getfd_is_one_use", "descriptor duplication as move or revocation", "pidfd_getfd duplicates access and leaves the target reference intact"},
        {"pidfd_integer_crossbinds_processes", "equal descriptor numbers in separate appraisers as one process coordinate", "cross-bind the pidfd object and admitted query result not integers"},
        {"tracer_root_is_independent_appraiser", "same-cloudtainer root tracer as independent appraisal", "appraiser root and administration inventory remain V14 premises"},
        {"nonroot_self_report_is_appraisal", "actor-reported uid capabilities or seccomp as independent proof", "query and exact filter reconstruction remain separate"},
        {"one_denied_syscall_is_exact_filter", "finite behavior challenge as complete seccomp identity", "dump or otherwise bind the exact admitted filter program"},
        {"v14_dossier_is_exec_binding", "dossier truth as proof the pinned object crossed exec", "V14 is insufficient without V15"},
        {"v15_exec_input_is_v13_admission", "main exec-input binding as complete acquisition-actor admission", "runtime closure epoch custody V14 and exact cross-binding remain mandatory"},
        {"single_threaded_means_private_address_space", "one thread as closure of CLONE_VM peers", "prove address-space custody independently through syscall argument consumption"},
        {"syscall_entry_registers_are_pointee_custody", "entry-register capture as stability of pathname argv or environment memory", "bind the referenced memory until the kernel consumes it"},
        {"post_exec_floor_is_pre_exec_floor", "new-image privilege reduction as confinement of the pre-exec interval", "establish the privilege and filter floor before actor release"},
        {"v14_truth_is_launch_envelope_binding", "an admissible dossier as proof of argv environment cwd umask and exec flags", "cross-bind the exact launch envelope to the observed transition"},
        {"dossier_privilege_is_launch_privilege", "post-exec appraisal as proof of the pre-exec privilege and seccomp floor", "cross-bind both pre-exec and appraised states"},
        {"dossier_fd_inventory_is_exec_inventory", "an inherited-descriptor dossier as proof of the descriptor table at exec", "cross-bind the admitted inventory to the launched table"},
        {"actor_launch_constitutes_authority", "technical launch witness as network owner or living authority", "network owner constitution and living law remain absent"},
    };

    require(rows.size() == 51U, "actor-exec case inventory");
    require(counterexamples.size() == 32U,
            "actor-exec counterexample inventory");
    write_cases(output, rows);
    write_counterexamples(output, counterexamples);

    ActorExecCampaignCounts counts;
    counts.cases = rows.size();
    counts.counterexamples = counterexamples.size();
    counts.exec_input_bound_profiles = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.exec_input_object_bound;
        }));
    counts.runtime_object_set_bound_profiles = static_cast<std::size_t>(
        std::count_if(rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.runtime_object_set_bound;
        }));
    counts.exec_epoch_held_profiles = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.exec_epoch_held;
        }));
    counts.pre_exec_floor_bound_profiles = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.pre_exec_floor_bound;
        }));
    counts.v13_eligible_profiles = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.eligible_for_v13_actor_premise;
        }));
    counts.incoherent_observations = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return !row.assessment.observation_coherent;
        }));
    require(counts.exec_input_bound_profiles == 14U,
            "fourteen exec-input-bound ordered prefixes");
    require(counts.runtime_object_set_bound_profiles == 13U,
            "thirteen runtime-bound ordered prefixes");
    require(counts.exec_epoch_held_profiles == 12U,
            "twelve held-exec-epoch ordered prefixes");
    require(counts.pre_exec_floor_bound_profiles == 10U,
            "ten pre-exec-floor-bound ordered prefixes");
    require(counts.v13_eligible_profiles == 1U,
            "one synthetic V13-eligible composition");
    require(counts.incoherent_observations == 1U,
            "one incoherent actor-exec row");
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
