#include "release_ingress_campaign.hpp"

#include "slopos/e0/handoff_cell/etcd_history_profile.hpp"
#include "slopos/e0/handoff_cell/release_ingress.hpp"

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct CaseRow final {
    std::string name;
    ReleaseIngressAssessment assessment;
    bool path_replaced{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* bool_text(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] ReleaseIngressObservationV1 exact_observation() {
    ReleaseIngressObservationV1 observation;
    observation.locator_opened = true;
    observation.descriptor_pinned = true;
    observation.regular_file = true;
    observation.private_snapshot_complete = true;
    observation.private_snapshot_write_sealed = true;
    observation.snapshot_sha256 = kEtcdV3614LinuxAmd64ArchiveSha256;
    observation.digest_compared_before_parse = true;
    observation.archive_parse_attempted = true;
    observation.archive_inventory_valid = true;
    observation.required_binaries_hashed = true;
    return observation;
}

void add_case(std::vector<CaseRow>& rows,
              const std::string& name,
              const ReleaseIngressObservationV1& observation,
              const ReleaseIngressDisposition expected,
              const bool retained_counterexample,
              const std::string& judgment) {
    const auto assessment = assess_release_ingress(
        kEtcdV3614LinuxAmd64ArchiveSha256, observation);
    require(assessment.disposition == expected,
            "release ingress disposition " + name);
    const bool activation_attempted =
        observation.binary_extraction_attempted
        || observation.binary_execution_attempted;
    require(assessment.passive_only == !activation_attempted,
            "release ingress passive classification " + name);
    require(assessment.activation_boundary_observed == activation_attempted,
            "release ingress activation observation " + name);
    require(assessment.observation_coherent
                == (expected != ReleaseIngressDisposition::observation_incoherent),
            "release ingress coherence classification " + name);
    require(!assessment.supplied_path_authority,
            "release ingress path authority " + name);
    require(!assessment.activation_authority,
            "release ingress activation authority " + name);
    require(!assessment.provider_operation_authority,
            "release ingress provider authority " + name);
    require(!assessment.cluster_operated,
            "release ingress cluster operation " + name);
    require(!assessment.binary_execution_proved,
            "release ingress execution proof " + name);
    rows.push_back({name, assessment,
                    observation.pathname_replaced_after_open,
                    retained_counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "release-ingress-cases.tsv", std::ios::binary);
    require(stream.good(), "open release-ingress-cases.tsv");
    stream
        << "case\tdisposition\tobservation_coherent\texact_release_bytes"
           "\tdescriptor_identity_retained\tprivate_snapshot_used"
           "\tsnapshot_write_sealed\tdigest_before_parse"
           "\tpathname_replacement_ignored\tactivation_boundary_observed"
           "\tpassive_only\tsupplied_path_authority\tactivation_authority"
           "\tprovider_operation_authority\tcluster_operated"
           "\tbinary_execution_proved\tpath_replaced"
           "\tretained_counterexample\tjudgment\n";
    for (const auto& row : rows) {
        const auto& value = row.assessment;
        stream
            << row.name << '\t'
            << release_ingress_disposition_name(value.disposition) << '\t'
            << bool_text(value.observation_coherent) << '\t'
            << bool_text(value.exact_release_bytes) << '\t'
            << bool_text(value.descriptor_identity_retained) << '\t'
            << bool_text(value.private_snapshot_used) << '\t'
            << bool_text(value.snapshot_write_sealed) << '\t'
            << bool_text(value.digest_before_parse) << '\t'
            << bool_text(value.pathname_replacement_ignored) << '\t'
            << bool_text(value.activation_boundary_observed) << '\t'
            << bool_text(value.passive_only) << '\t'
            << bool_text(value.supplied_path_authority) << '\t'
            << bool_text(value.activation_authority) << '\t'
            << bool_text(value.provider_operation_authority) << '\t'
            << bool_text(value.cluster_operated) << '\t'
            << bool_text(value.binary_execution_proved) << '\t'
            << bool_text(row.path_replaced) << '\t'
            << bool_text(row.retained_counterexample) << '\t'
            << row.judgment << '\n';
    }
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "release-ingress-counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open release-ingress-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const ReleaseIngressCampaignCounts& counts) {
    std::ofstream stream(
        output / "release-ingress-summary.json", std::ios::binary);
    require(stream.good(), "open release-ingress-summary.json");
    stream
        << "{\n"
        << "  \"activation_authority\": false,\n"
        << "  \"activation_boundary_violations\": "
        << counts.activation_boundary_violations << ",\n"
        << "  \"cases\": " << counts.cases << ",\n"
        << "  \"cluster_operated\": false,\n"
        << "  \"counterexamples_reproduced\": "
        << counts.counterexamples << ",\n"
        << "  \"descriptor_opened_once_required\": true,\n"
        << "  \"digest_before_parse_required\": true,\n"
        << "  \"exact_passive_admissions\": "
        << counts.exact_passive_admissions << ",\n"
        << "  \"incoherent_observations_rejected\": "
        << counts.incoherent_observations << ",\n"
        << "  \"operated_binary_execution_attempted\": false,\n"
        << "  \"operated_binary_extraction_attempted\": false,\n"
        << "  \"path_replacement_admissions\": "
        << counts.path_replacement_admissions << ",\n"
        << "  \"private_snapshot_required\": true,\n"
        << "  \"provider_operation_authority\": false,\n"
        << "  \"release_archive_sha256\": "
           "\"ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5\",\n"
        << "  \"release_version\": \"v3.6.14\",\n"
        << "  \"schema\": \"slopos.rev0899.release-ingress-shape-evidence.v2\",\n"
        << "  \"snapshot_write_seal_required\": true,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"supplied_path_authority\": false,\n"
        << "  \"supplied_path_reopened\": false\n"
        << "}\n";
}

}  // namespace

ReleaseIngressCampaignCounts run_release_ingress_campaign(
    const std::filesystem::path& output) {
    std::vector<CaseRow> cases;
    ReleaseIngressObservationV1 observation;

    add_case(cases, "missing_locator", observation,
             ReleaseIngressDisposition::locator_unavailable, false,
             "STOP_BEFORE_DESCRIPTOR");

    observation = exact_observation();
    observation.locator_opened = false;
    add_case(cases, "incoherent_boolean_bag", observation,
             ReleaseIngressDisposition::observation_incoherent, true,
             "DOWNSTREAM_FLAGS_CANNOT_INVENT_AN_UNOBSERVED_PREFIX");

    observation = {};
    observation.locator_opened = true;
    add_case(cases, "unretained_descriptor", observation,
             ReleaseIngressDisposition::descriptor_unpinned, true,
             "PATHNAME_LOOKUP_IS_NOT_CUSTODY");

    observation.descriptor_pinned = true;
    add_case(cases, "fifo_or_directory", observation,
             ReleaseIngressDisposition::nonregular_source, false,
             "NONREGULAR_SOURCE_STOPS");

    observation.regular_file = true;
    add_case(cases, "snapshot_short_read", observation,
             ReleaseIngressDisposition::snapshot_incomplete, false,
             "INCOMPLETE_PRIVATE_SNAPSHOT_STOPS");

    observation.private_snapshot_complete = true;
    add_case(cases, "mutable_snapshot_before_digest_compare", observation,
             ReleaseIngressDisposition::snapshot_unsealed, true,
             "ANONYMOUS_IS_NOT_IMMUTABLE_WRITE_SEAL_BEFORE_COMPARE");

    observation = exact_observation();
    observation.snapshot_sha256[0] ^= 0x01U;
    observation.archive_parse_attempted = false;
    observation.archive_inventory_valid = false;
    observation.required_binaries_hashed = false;
    add_case(cases, "wrong_digest_stops_before_parse", observation,
             ReleaseIngressDisposition::digest_mismatch, false,
             "DIGEST_MISMATCH_HAS_NO_ARCHIVE_SEMANTICS");

    observation = exact_observation();
    observation.snapshot_sha256[0] ^= 0x01U;
    observation.digest_compared_before_parse = false;
    add_case(cases, "wrong_digest_cannot_mask_early_parse", observation,
             ReleaseIngressDisposition::digest_order_rejected, true,
             "EARLY_ARCHIVE_SEMANTICS_DOMINATE_LATER_DIGEST_MISMATCH");

    observation = exact_observation();
    observation.supplied_path_reopened = true;
    observation.archive_parse_attempted = false;
    observation.archive_inventory_valid = false;
    observation.required_binaries_hashed = false;
    add_case(cases, "hash_then_reopen_path", observation,
             ReleaseIngressDisposition::path_reopen_rejected, true,
             "SUPPLIED_PATH_MAY_NOT_REENTER_AFTER_PIN");

    observation = exact_observation();
    observation.digest_compared_before_parse = false;
    add_case(cases, "parse_before_digest", observation,
             ReleaseIngressDisposition::digest_order_rejected, true,
             "ARCHIVE_SEMANTICS_REQUIRE_PRIOR_EXACT_DIGEST_COMPARISON");

    observation = exact_observation();
    observation.archive_parse_attempted = false;
    observation.archive_inventory_valid = false;
    observation.required_binaries_hashed = false;
    add_case(cases, "digest_only_without_inventory", observation,
             ReleaseIngressDisposition::archive_rejected, true,
             "DIGEST_DOES_NOT_REPLACE_STRUCTURAL_INVENTORY");

    observation = exact_observation();
    observation.archive_inventory_valid = false;
    observation.required_binaries_hashed = false;
    add_case(cases, "unsafe_archive_member", observation,
             ReleaseIngressDisposition::archive_rejected, false,
             "ONLY_REGULAR_BENEATH_TOP_MEMBERS");

    observation = exact_observation();
    observation.required_binaries_hashed = false;
    add_case(cases, "required_binary_missing", observation,
             ReleaseIngressDisposition::archive_rejected, false,
             "ALL_REQUIRED_BINARY_BYTES_MUST_BE_HASHED");

    observation = exact_observation();
    observation.binary_extraction_attempted = true;
    add_case(cases, "extraction_crosses_activation_boundary", observation,
             ReleaseIngressDisposition::activation_boundary_violated, true,
             "PASSIVE_ADMISSION_WRITES_NO_EXECUTABLE_PATH");

    observation = exact_observation();
    observation.binary_execution_attempted = true;
    add_case(cases, "version_command_crosses_activation_boundary", observation,
             ReleaseIngressDisposition::activation_boundary_violated, true,
             "BYTE_ADMISSION_NEVER_EXECUTES_SUPPLIED_CODE");

    observation = exact_observation();
    add_case(cases, "exact_write_sealed_snapshot", observation,
             ReleaseIngressDisposition::exact_passive_admission, false,
             "EXACT_SEALED_BYTES_PASSIVE_ONLY");

    observation = exact_observation();
    observation.pathname_replaced_after_open = true;
    add_case(cases, "path_replaced_after_descriptor_pin", observation,
             ReleaseIngressDisposition::exact_passive_admission, true,
             "REPLACEMENT_LOCATOR_BYTES_NEVER_REENTER");

    const std::vector<CounterexampleRow> counterexamples{
        {"unordered_boolean_bag_is_not_proof", true,
         "independent true flags can report custody before their prerequisites",
         "reject every downstream fact whose ordered observation prefix is absent"},
        {"anonymous_snapshot_is_not_immutable", true,
         "an unlinked read-write object can change after streaming digest state",
         "write-seal the complete snapshot then hash the sealed bytes"},
        {"pathname_filename_is_release_identity", true,
         "trusted_filename_or_later_path_lookup_establishes_exact_bytes",
         "the_locator_is_discardable_after_one_descriptor_pin"},
        {"hash_then_reopen_for_parse", true,
         "one_digest_check_authenticates_later_path_resolutions",
         "inventory_must_consume_the_same_private_snapshot"},
        {"parse_before_digest_is_harmless", true,
         "archive_semantics_may_run_before_exact_release-byte_identity",
         "the_exact_digest_comparison_must_precede_every_archive_semantic"},
        {"digest_only_is_complete_admission", true,
         "exact_hash_eliminates_archive_shape_and_required-member checks",
         "digest_precedes_but_does_not_replace_structural_inventory"},
        {"execute_version_to_finish_byte_admission", true,
         "running_supplied_code_is_a_passive_identity_check",
         "activation_is_a_separate_future_authority_boundary"},
        {"passive_release_receipt_implies_operated_provider", true,
         "exact archive bytes prove cluster or provider history operation",
         "release admission grants no provider operation or settlement claim"},
        {"path_replacement_changes_pinned_object", true,
         "a later rename changes bytes already retained by descriptor",
         "replacement affects the locator but not the opened object"},
    };

    ReleaseIngressCampaignCounts counts;
    counts.cases = cases.size();
    counts.counterexamples = counterexamples.size();
    counts.exact_passive_admissions = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.admitted();
        }));
    counts.path_replacement_admissions = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.admitted() && row.path_replaced;
        }));
    counts.activation_boundary_violations = static_cast<std::size_t>(
        std::count_if(cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.disposition
                == ReleaseIngressDisposition::activation_boundary_violated;
        }));
    counts.incoherent_observations = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.disposition
                == ReleaseIngressDisposition::observation_incoherent;
        }));

    require(counts.cases == 17U, "release ingress case inventory");
    require(counts.counterexamples == 9U,
            "release ingress counterexample inventory");
    require(counts.exact_passive_admissions == 2U,
            "release ingress passive admission inventory");
    require(counts.path_replacement_admissions == 1U,
            "release ingress path replacement inventory");
    require(counts.activation_boundary_violations == 2U,
            "release ingress activation violation inventory");
    require(counts.incoherent_observations == 1U,
            "release ingress incoherent observation inventory");

    write_cases(output, cases);
    write_counterexamples(output, counterexamples);
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
