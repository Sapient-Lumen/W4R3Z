#include "slopos/e0/handoff_cell/static_actor_confinement.hpp"

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <dirent.h>
#include <elf.h>
#include <filesystem>
#include <fstream>
#include <grp.h>
#include <iomanip>
#include <iostream>
#include <limits>
#include <linux/audit.h>
#include <linux/capability.h>
#include <linux/filter.h>
#include <linux/memfd.h>
#include <linux/seccomp.h>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/fcntl.h>
#include <sys/personality.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <sys/random.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/sysmacros.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <utility>
#include <vector>

#ifndef MFD_EXEC
#define MFD_EXEC 0x0010U
#endif

namespace {

using slopos::e0::handoff_cell::StaticActorObservationV1;
using slopos::e0::handoff_cell::assess_static_actor_confinement;
using slopos::e0::handoff_cell::static_actor_disposition_name;

constexpr std::size_t kDigestBytes = 32U;
constexpr std::size_t kChallengeBytes = 32U;
constexpr std::size_t kCanaryPathBytes = 192U;
constexpr off_t kMaximumSubjectBytes = 4 * 1024 * 1024;
constexpr uid_t kActorUid = 65534U;
constexpr gid_t kActorGid = 65534U;
constexpr int kInputFd = 3;
constexpr int kOutputFd = 4;
constexpr int kExecFd = 5;
constexpr int kRequiredSeals =
    F_SEAL_WRITE | F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_SEAL;
constexpr unsigned int kExecutableMemfdFlags =
    MFD_CLOEXEC | MFD_ALLOW_SEALING | MFD_EXEC;
constexpr std::uint64_t kInputMagic = 0x534c4f505631494eULL;
constexpr std::uint64_t kReportMagic = 0x534c4f5056315354ULL;

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
};

struct PathGuard final {
    std::filesystem::path path;
    bool directory{false};
    bool active{false};
    PathGuard() = default;
    PathGuard(std::filesystem::path value, const bool is_directory)
        : path(std::move(value)), directory(is_directory), active(true) {}
    PathGuard(const PathGuard&) = delete;
    PathGuard& operator=(const PathGuard&) = delete;
    PathGuard(PathGuard&& other) noexcept
        : path(std::move(other.path)), directory(other.directory),
          active(other.active) {
        other.active = false;
    }
    PathGuard& operator=(PathGuard&& other) noexcept {
        if (this != &other) {
            cleanup();
            path = std::move(other.path);
            directory = other.directory;
            active = other.active;
            other.active = false;
        }
        return *this;
    }
    ~PathGuard() { cleanup(); }
    void release() noexcept { active = false; }
    void cleanup() noexcept {
        if (!active) return;
        if (directory) (void)::rmdir(path.c_str());
        else (void)::unlink(path.c_str());
        active = false;
    }
};

struct TraceeGuard final {
    pid_t pid{-1};
    explicit TraceeGuard(const pid_t child) noexcept : pid(child) {}
    TraceeGuard(const TraceeGuard&) = delete;
    TraceeGuard& operator=(const TraceeGuard&) = delete;
    ~TraceeGuard() {
        if (pid <= 0) return;
        (void)::kill(pid, SIGKILL);
        int status = 0;
        for (;;) {
            const pid_t got = ::waitpid(pid, &status, __WALL);
            if (got < 0 && errno == EINTR) continue;
            break;
        }
    }
    void release() noexcept { pid = -1; }
};

struct ActorInput final {
    std::uint64_t magic;
    std::uint8_t challenge[kChallengeBytes];
    char absolute_exec_canary[kCanaryPathBytes];
};
static_assert(sizeof(ActorInput) == 232U);

struct ActorReport final {
    std::uint64_t magic;
    std::uint8_t challenge[kChallengeBytes];
    std::uint8_t response[kChallengeBytes];
    std::int32_t openat_errno;
    std::int32_t socket_errno;
    std::int32_t connect_errno;
    std::int32_t sendto_errno;
    std::int32_t recvmsg_errno;
    std::int32_t clone_errno;
    std::int32_t mmap_exec_errno;
    std::int32_t mprotect_exec_errno;
    std::int32_t memfd_create_errno;
    std::int32_t execve_errno;
    std::int32_t execveat_closed_fd_errno;
    std::int32_t absolute_execveat_errno;
    std::int32_t seccomp_errno;
    std::int32_t prctl_seccomp_errno;
    std::int32_t io_uring_setup_errno;
    std::int32_t read_wrong_fd_errno;
    std::int32_t write_wrong_fd_errno;
};
static_assert(sizeof(ActorReport) == 144U);

struct ElfProfile final {
    bool elf64_little_endian_x86_64{false};
    bool elf_type_exact{false};
    bool program_header_table_bounded{false};
    bool entrypoint_inside_executable_load{false};
    bool entry_stack_alignment_shim_exact{false};
    bool pt_interp_absent{false};
    bool pt_dynamic_absent{false};
    bool executable_load_present{false};
    bool writable_executable_load_absent{false};
    bool executable_gnu_stack_absent{false};
};

struct ProcessStatus final {
    bool parsed{false};
    std::array<std::uint32_t, 4U> uids{};
    std::array<std::uint32_t, 4U> gids{};
    bool groups_empty{false};
    bool capabilities_empty{false};
    bool capability_bounding_empty{false};
    bool no_new_privs{false};
    int seccomp_mode{-1};
    bool seccomp_filter{false};
    std::uint32_t seccomp_filter_count{0U};
    bool seccomp_filter_count_parsed{false};
};

struct MappingInventory final {
    bool complete{false};
    std::size_t executable_mappings{0U};
    std::size_t file_backed_executable_mappings{0U};
    std::size_t matching_candidate_executable_mappings{0U};
    std::size_t kernel_executable_mappings{0U};
    bool only_declared_kernel_surfaces{true};
    bool writable_executable_absent{true};
};

struct RootSnapshot final {
    bool available{false};
    bool root_and_cwd_same{false};
    bool matches_expected{false};
    bool empty{false};
    bool actor_nonwritable{false};
};

struct CaseRow final {
    std::string name;
    bool observed{false};
    bool expected{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail + ": " + std::strerror(errno));
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] std::string boolean(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] std::string errno_name(const int value) {
    if (value == 0) return "NONE";
    if (value == EBADF) return "EBADF";
    if (value == EACCES) return "EACCES";
    if (value == EPERM) return "EPERM";
    if (value == EINVAL) return "EINVAL";
    if (value == ENOENT) return "ENOENT";
    if (value == ENOEXEC) return "ENOEXEC";
    if (value == ENOSYS) return "ENOSYS";
    if (value == ESRCH) return "ESRCH";
    return "ERRNO_" + std::to_string(value);
}

void write_exact(const int fd, const void* data, const std::size_t size) {
    const auto* bytes = static_cast<const std::byte*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t put = ::write(fd, bytes + offset, size - offset);
        if (put < 0 && errno == EINTR) continue;
        if (put <= 0) fail("write_exact");
        offset += static_cast<std::size_t>(put);
    }
}

void read_exact(const int fd, void* data, const std::size_t size) {
    auto* bytes = static_cast<std::byte*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t got = ::read(fd, bytes + offset, size - offset);
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("read_exact");
        offset += static_cast<std::size_t>(got);
    }
}

void pread_exact(const int fd, void* data, const std::size_t size,
                 const off_t start) {
    auto* bytes = static_cast<std::byte*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t got = ::pread(
            fd, bytes + offset, size - offset,
            start + static_cast<off_t>(offset));
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("pread_exact");
        offset += static_cast<std::size_t>(got);
    }
}

[[nodiscard]] std::array<unsigned char, kDigestBytes> digest_fd(
    const int fd, const off_t size) {
    EVP_MD_CTX* raw = EVP_MD_CTX_new();
    if (raw == nullptr) fail("EVP_MD_CTX_new");
    std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)> context(
        raw, &EVP_MD_CTX_free);
    require(EVP_DigestInit_ex(context.get(), EVP_sha256(), nullptr) == 1,
            "EVP_DigestInit_ex");
    std::array<unsigned char, 64U * 1024U> buffer{};
    off_t offset = 0;
    while (offset < size) {
        const off_t remaining = size - offset;
        const std::size_t wanted = static_cast<std::size_t>(
            std::min<off_t>(remaining, static_cast<off_t>(buffer.size())));
        const ssize_t got = ::pread(fd, buffer.data(), wanted, offset);
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("pread digest");
        require(EVP_DigestUpdate(context.get(), buffer.data(),
                                 static_cast<std::size_t>(got)) == 1,
                "EVP_DigestUpdate");
        offset += static_cast<off_t>(got);
    }
    std::array<unsigned char, kDigestBytes> digest{};
    unsigned int digest_size = 0U;
    require(EVP_DigestFinal_ex(context.get(), digest.data(), &digest_size) == 1,
            "EVP_DigestFinal_ex");
    require(digest_size == digest.size(), "SHA-256 size");
    return digest;
}

[[nodiscard]] ElfProfile inspect_elf(const int fd, const off_t size) {
    ElfProfile result;
    require(size >= static_cast<off_t>(sizeof(Elf64_Ehdr)),
            "static actor ELF header bounded");
    Elf64_Ehdr header{};
    pread_exact(fd, &header, sizeof(header), 0);
    result.elf64_little_endian_x86_64 =
        header.e_ident[EI_MAG0] == ELFMAG0
        && header.e_ident[EI_MAG1] == ELFMAG1
        && header.e_ident[EI_MAG2] == ELFMAG2
        && header.e_ident[EI_MAG3] == ELFMAG3
        && header.e_ident[EI_CLASS] == ELFCLASS64
        && header.e_ident[EI_DATA] == ELFDATA2LSB
        && header.e_machine == EM_X86_64;
    result.elf_type_exact = header.e_type == ET_EXEC;
    result.program_header_table_bounded =
        header.e_phentsize == sizeof(Elf64_Phdr)
        && header.e_phnum > 0U && header.e_phnum != PN_XNUM;
    require(result.elf64_little_endian_x86_64 && result.elf_type_exact
                && result.program_header_table_bounded,
            "static actor ELF profile");
    const std::uint64_t file_size = static_cast<std::uint64_t>(size);
    const std::uint64_t table_offset = header.e_phoff;
    const std::uint64_t table_bytes =
        static_cast<std::uint64_t>(header.e_phnum) * sizeof(Elf64_Phdr);
    require(table_offset <= file_size
                && table_bytes <= file_size - table_offset,
            "static actor program headers inside object");
    std::vector<Elf64_Phdr> headers(static_cast<std::size_t>(header.e_phnum));
    pread_exact(fd, headers.data(), headers.size() * sizeof(Elf64_Phdr),
                static_cast<off_t>(table_offset));
    bool interp = false;
    bool dynamic = false;
    bool stack_seen = false;
    bool stack_exec = false;
    for (const Elf64_Phdr& program : headers) {
        require(program.p_offset <= file_size
                    && program.p_filesz <= file_size - program.p_offset,
                "static actor segment inside object");
        if (program.p_type == PT_INTERP) interp = true;
        if (program.p_type == PT_DYNAMIC) dynamic = true;
        if (program.p_type == PT_GNU_STACK) {
            stack_seen = true;
            stack_exec = (program.p_flags & PF_X) != 0U;
        }
        if (program.p_type != PT_LOAD) continue;
        if ((program.p_flags & PF_X) != 0U) {
            result.executable_load_present = true;
            const std::uint64_t begin = program.p_vaddr;
            const std::uint64_t end = begin + program.p_memsz;
            require(end >= begin, "static actor executable segment overflow");
            if (header.e_entry >= begin && header.e_entry < end) {
                result.entrypoint_inside_executable_load = true;
                const std::uint64_t delta = header.e_entry - begin;
                constexpr std::size_t kEntryShimBytes = 11U;
                if (delta <= program.p_filesz
                    && kEntryShimBytes <= program.p_filesz - delta
                    && program.p_offset <= file_size
                    && delta <= file_size - program.p_offset
                    && kEntryShimBytes
                        <= file_size - program.p_offset - delta) {
                    std::array<unsigned char, kEntryShimBytes> entry{};
                    pread_exact(
                        fd, entry.data(), entry.size(),
                        static_cast<off_t>(program.p_offset + delta));
                    std::int32_t displacement = 0;
                    std::memcpy(&displacement, entry.data() + 5U,
                                sizeof(displacement));
                    const std::int64_t return_address =
                        static_cast<std::int64_t>(header.e_entry) + 9;
                    const std::int64_t call_target = return_address
                        + static_cast<std::int64_t>(displacement);
                    result.entry_stack_alignment_shim_exact =
                        entry[0] == 0x48U && entry[1] == 0x83U
                        && entry[2] == 0xE4U && entry[3] == 0xF0U
                        && entry[4] == 0xE8U && entry[9] == 0x0FU
                        && entry[10] == 0x0BU
                        && call_target >= static_cast<std::int64_t>(begin)
                        && call_target < static_cast<std::int64_t>(end)
                        && call_target
                            != static_cast<std::int64_t>(header.e_entry);
                }
            }
        }
        if ((program.p_flags & (PF_W | PF_X)) == (PF_W | PF_X)) {
            result.writable_executable_load_absent = false;
        }
    }
    result.pt_interp_absent = !interp;
    result.pt_dynamic_absent = !dynamic;
    // Compute the W+X property explicitly across every load segment.
    result.writable_executable_load_absent = true;
    for (const Elf64_Phdr& program : headers) {
        if (program.p_type == PT_LOAD
            && (program.p_flags & (PF_W | PF_X)) == (PF_W | PF_X)) {
            result.writable_executable_load_absent = false;
        }
    }
    result.executable_gnu_stack_absent = stack_seen && !stack_exec;
    require(result.entrypoint_inside_executable_load
                && result.entry_stack_alignment_shim_exact
                && result.pt_interp_absent && result.pt_dynamic_absent
                && result.executable_load_present
                && result.writable_executable_load_absent
                && result.executable_gnu_stack_absent,
            "static actor closed loader edges");
    return result;
}

[[nodiscard]] UniqueFd sealed_subject(const std::filesystem::path& path,
                                      off_t& size_out,
                                      std::array<unsigned char, kDigestBytes>& digest_out,
                                      ElfProfile& elf_out,
                                      bool& profile_cross_bound_out) {
    UniqueFd source(::open(path.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW));
    if (source.value < 0) fail("open static actor subject");
    struct stat source_stat {};
    if (::fstat(source.value, &source_stat) != 0) fail("fstat static actor subject");
    require(S_ISREG(source_stat.st_mode), "static actor subject regular");
    require(source_stat.st_size > 0 && source_stat.st_size <= kMaximumSubjectBytes,
            "static actor subject bounded");
    profile_cross_bound_out = false;
    const int raw = static_cast<int>(::syscall(
        SYS_memfd_create, "slopos-v16-static-actor", kExecutableMemfdFlags));
    if (raw < 0) fail("memfd_create static actor");
    UniqueFd target(raw);
    std::array<std::byte, 64U * 1024U> buffer{};
    off_t offset = 0;
    while (offset < source_stat.st_size) {
        const off_t remaining = source_stat.st_size - offset;
        const std::size_t wanted = static_cast<std::size_t>(
            std::min<off_t>(remaining, static_cast<off_t>(buffer.size())));
        const ssize_t got = ::pread(source.value, buffer.data(), wanted, offset);
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("pread static actor source");
        std::size_t written = 0U;
        while (written < static_cast<std::size_t>(got)) {
            const ssize_t put = ::pwrite(
                target.value, buffer.data() + written,
                static_cast<std::size_t>(got) - written,
                offset + static_cast<off_t>(written));
            if (put < 0 && errno == EINTR) continue;
            if (put <= 0) fail("pwrite static actor memfd");
            written += static_cast<std::size_t>(put);
        }
        offset += static_cast<off_t>(got);
    }
    if (::fchmod(target.value, 0555) != 0) fail("fchmod static actor memfd");
    if (::fcntl(target.value, F_ADD_SEALS, kRequiredSeals) != 0) {
        fail("seal static actor memfd");
    }
    require((::fcntl(target.value, F_GET_SEALS) & kRequiredSeals)
                == kRequiredSeals,
            "static actor required seals");
    struct stat target_stat {};
    if (::fstat(target.value, &target_stat) != 0) fail("fstat static actor memfd");
    require(S_ISREG(target_stat.st_mode) && target_stat.st_nlink == 0,
            "static actor anonymous regular object");
    require(target_stat.st_size == source_stat.st_size,
            "static actor complete captured size");
    size_out = target_stat.st_size;
    // Profile and digest the same immutable object that will be offered to
    // execveat. The mutable pathname source is acquisition material only.
    elf_out = inspect_elf(target.value, size_out);
    digest_out = digest_fd(target.value, size_out);
    profile_cross_bound_out = true;
    return target;
}

[[nodiscard]] sock_filter statement(const unsigned short code,
                                    const unsigned int k) {
    return sock_filter{code, 0U, 0U, k};
}

[[nodiscard]] sock_filter jump(const unsigned short code,
                               const unsigned int k,
                               const unsigned char jt,
                               const unsigned char jf) {
    return sock_filter{code, jt, jf, k};
}

[[nodiscard]] std::vector<sock_filter> static_actor_filter() {
    std::vector<sock_filter> result;
    result.reserve(48U);
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS,
        static_cast<unsigned int>(offsetof(seccomp_data, arch))));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(AUDIT_ARCH_X86_64), 1U, 0U));
    result.push_back(statement(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS,
        static_cast<unsigned int>(offsetof(seccomp_data, nr))));

    std::vector<std::size_t> simple_allow_jumps;
    for (const long number : {static_cast<long>(SYS_exit),
                              static_cast<long>(SYS_exit_group),
                              static_cast<long>(SYS_rt_sigreturn)}) {
        simple_allow_jumps.push_back(result.size());
        result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
            static_cast<unsigned int>(number), 0U, 0U));
    }

    // read is allowed only on the challenge descriptor.
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(SYS_read), 0U, 4U));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS,
        static_cast<unsigned int>(offsetof(seccomp_data, args[0]))));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(kInputFd), 0U, 1U));
    result.push_back(statement(BPF_RET | BPF_K, SECCOMP_RET_ALLOW));
    result.push_back(statement(BPF_RET | BPF_K,
        SECCOMP_RET_ERRNO | static_cast<unsigned int>(EPERM)));

    // write is allowed only on the report descriptor.
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(SYS_write), 0U, 4U));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS,
        static_cast<unsigned int>(offsetof(seccomp_data, args[0]))));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(kOutputFd), 0U, 1U));
    result.push_back(statement(BPF_RET | BPF_K, SECCOMP_RET_ALLOW));
    result.push_back(statement(BPF_RET | BPF_K,
        SECCOMP_RET_ERRNO | static_cast<unsigned int>(EPERM)));

    // The initial exec route is exact. FD 5 is close-on-exec, so the same
    // otherwise-allowed shape returns EBADF inside the new actor.
    const std::size_t exec_jump = result.size();
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(SYS_execveat), 0U, 10U));
    const unsigned int arg0 = static_cast<unsigned int>(
        offsetof(seccomp_data, args[0]));
    const unsigned int arg4 = static_cast<unsigned int>(
        offsetof(seccomp_data, args[4]));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS, arg0));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(kExecFd), 0U, 7U));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS, arg0 + 4U));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K, 0U, 0U, 5U));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS, arg4));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K,
        static_cast<unsigned int>(AT_EMPTY_PATH), 0U, 3U));
    result.push_back(statement(BPF_LD | BPF_W | BPF_ABS, arg4 + 4U));
    result.push_back(jump(BPF_JMP | BPF_JEQ | BPF_K, 0U, 0U, 1U));
    result.push_back(statement(BPF_RET | BPF_K, SECCOMP_RET_ALLOW));
    result.push_back(statement(BPF_RET | BPF_K,
        SECCOMP_RET_ERRNO | static_cast<unsigned int>(EPERM)));
    require(result.size() == exec_jump + 11U, "exec filter block size");

    result.push_back(statement(BPF_RET | BPF_K,
        SECCOMP_RET_ERRNO | static_cast<unsigned int>(EPERM)));
    const std::size_t allow_index = result.size();
    result.push_back(statement(BPF_RET | BPF_K, SECCOMP_RET_ALLOW));
    for (const std::size_t index : simple_allow_jumps) {
        const std::size_t distance = allow_index - index - 1U;
        require(distance <= std::numeric_limits<unsigned char>::max(),
                "seccomp jump bounded");
        result[index].jt = static_cast<unsigned char>(distance);
    }
    return result;
}

[[nodiscard]] bool same_instruction(const sock_filter& left,
                                    const sock_filter& right) {
    return left.code == right.code && left.jt == right.jt
        && left.jf == right.jf && left.k == right.k;
}

void read_tracee_bytes(const pid_t child, const std::uintptr_t address,
                       void* output, const std::size_t size) {
    auto* bytes = static_cast<std::byte*>(output);
    std::size_t copied = 0U;
    while (copied < size) {
        errno = 0;
        const long word = ::ptrace(
            PTRACE_PEEKDATA, child,
            reinterpret_cast<void*>(address + copied), nullptr);
        if (word == -1L && errno != 0) {
            throw std::runtime_error(
                "PTRACE_PEEKDATA tracee bytes address="
                + std::to_string(address) + " copied=" + std::to_string(copied)
                + " size=" + std::to_string(size) + " errno="
                + std::to_string(errno));
        }
        const std::size_t chunk = std::min(sizeof(word), size - copied);
        std::memcpy(bytes + copied, &word, chunk);
        copied += chunk;
    }
}

[[nodiscard]] bool wait_stopped(const pid_t child, int& status) {
    for (;;) {
        const pid_t got = ::waitpid(child, &status, __WALL);
        if (got < 0 && errno == EINTR) continue;
        if (got != child) fail("waitpid tracee");
        return WIFSTOPPED(status);
    }
}

[[nodiscard]] ProcessStatus read_process_status(const pid_t child) {
    ProcessStatus result;
    std::ifstream stream("/proc/" + std::to_string(child) + "/status");
    if (!stream.good()) return result;
    bool uid = false;
    bool gid = false;
    bool groups = false;
    bool cap_inh = false;
    bool cap_prm = false;
    bool cap_eff = false;
    bool cap_bnd = false;
    bool cap_amb = false;
    bool nnp = false;
    bool seccomp = false;
    bool seccomp_count = false;
    std::string line;
    auto parse_hex_zero = [](const std::string_view text) {
        std::uint64_t value = 1U;
        const char* begin = text.data();
        const char* end = begin + text.size();
        while (begin != end && (*begin == ' ' || *begin == '\t')) ++begin;
        const auto converted = std::from_chars(begin, end, value, 16);
        return converted.ec == std::errc{} && value == 0U;
    };
    while (std::getline(stream, line)) {
        if (line.rfind("Uid:", 0U) == 0U) {
            std::istringstream values(line.substr(4U));
            values >> result.uids[0] >> result.uids[1]
                   >> result.uids[2] >> result.uids[3];
            uid = !values.fail();
        } else if (line.rfind("Gid:", 0U) == 0U) {
            std::istringstream values(line.substr(4U));
            values >> result.gids[0] >> result.gids[1]
                   >> result.gids[2] >> result.gids[3];
            gid = !values.fail();
        } else if (line.rfind("Groups:", 0U) == 0U) {
            const std::string tail = line.substr(7U);
            result.groups_empty = tail.find_first_not_of(" \t") == std::string::npos;
            groups = true;
        } else if (line.rfind("CapInh:", 0U) == 0U) {
            cap_inh = parse_hex_zero(line.substr(7U));
        } else if (line.rfind("CapPrm:", 0U) == 0U) {
            cap_prm = parse_hex_zero(line.substr(7U));
        } else if (line.rfind("CapEff:", 0U) == 0U) {
            cap_eff = parse_hex_zero(line.substr(7U));
        } else if (line.rfind("CapBnd:", 0U) == 0U) {
            cap_bnd = parse_hex_zero(line.substr(7U));
        } else if (line.rfind("CapAmb:", 0U) == 0U) {
            cap_amb = parse_hex_zero(line.substr(7U));
        } else if (line.rfind("NoNewPrivs:", 0U) == 0U) {
            const std::string tail = line.substr(11U);
            nnp = tail.find('1') != std::string::npos;
            result.no_new_privs = nnp;
        } else if (line.rfind("Seccomp:", 0U) == 0U) {
            std::istringstream values(line.substr(8U));
            values >> result.seccomp_mode;
            seccomp = !values.fail();
            result.seccomp_filter = result.seccomp_mode == 2;
        } else if (line.rfind("Seccomp_filters:", 0U) == 0U) {
            std::istringstream values(line.substr(16U));
            values >> result.seccomp_filter_count;
            seccomp_count = !values.fail();
            result.seccomp_filter_count_parsed = seccomp_count;
        }
    }
    result.capabilities_empty = cap_inh && cap_prm && cap_eff && cap_amb;
    result.capability_bounding_empty = cap_bnd;
    result.parsed = uid && gid && groups && cap_inh && cap_prm && cap_eff
        && cap_bnd && cap_amb && nnp && seccomp && seccomp_count;
    return result;
}

[[nodiscard]] bool read_implies_exec_absent(const pid_t child) {
    std::ifstream stream("/proc/" + std::to_string(child) + "/personality");
    if (!stream.good()) return false;
    unsigned long value = 0UL;
    stream >> std::hex >> value;
    return !stream.fail() && (value & READ_IMPLIES_EXEC) == 0UL;
}

[[nodiscard]] std::vector<int> descriptor_inventory(const pid_t child) {
    const std::filesystem::path directory =
        std::filesystem::path("/proc") / std::to_string(child) / "fd";
    std::vector<int> result;
    for (const auto& entry : std::filesystem::directory_iterator(directory)) {
        const std::string name = entry.path().filename().string();
        int value = -1;
        const auto converted = std::from_chars(
            name.data(), name.data() + name.size(), value);
        if (converted.ec == std::errc{}
            && converted.ptr == name.data() + name.size()) {
            result.push_back(value);
        }
    }
    std::sort(result.begin(), result.end());
    return result;
}


[[nodiscard]] UniqueFd reopen_tracee_descriptor(const pid_t child,
                                                const int descriptor) {
    const std::filesystem::path path = std::filesystem::path("/proc")
        / std::to_string(child) / "fd" / std::to_string(descriptor);
    UniqueFd result(::open(path.c_str(), O_RDONLY | O_CLOEXEC));
    if (result.value < 0) fail("open stopped tracee descriptor");
    return result;
}

[[nodiscard]] bool tracee_descriptor_cloexec(const pid_t child,
                                             const int descriptor) {
    const std::filesystem::path path = std::filesystem::path("/proc")
        / std::to_string(child) / "fdinfo" / std::to_string(descriptor);
    std::ifstream stream(path);
    if (!stream.good()) return false;
    std::string line;
    while (std::getline(stream, line)) {
        if (line.rfind("flags:", 0U) != 0U) continue;
        const std::string_view tail(line.data() + 6U, line.size() - 6U);
        const char* begin = tail.data();
        const char* end = begin + tail.size();
        while (begin != end && (*begin == ' ' || *begin == '\t')) ++begin;
        unsigned long flags = 0UL;
        const auto converted = std::from_chars(begin, end, flags, 8);
        return converted.ec == std::errc{}
            && (flags & static_cast<unsigned long>(O_CLOEXEC)) != 0UL;
    }
    return false;
}

[[nodiscard]] MappingInventory inspect_mappings(const pid_t child,
                                                const struct stat& candidate) {
    MappingInventory result;
    std::ifstream stream("/proc/" + std::to_string(child) + "/maps");
    if (!stream.good()) return result;
    std::string line;
    while (std::getline(stream, line)) {
        std::istringstream fields(line);
        std::string addresses;
        std::string permissions;
        std::string offset_text;
        std::string device_text;
        std::uint64_t inode = 0U;
        if (!(fields >> addresses >> permissions >> offset_text
              >> device_text >> inode)) {
            return MappingInventory{};
        }
        std::string path;
        std::getline(fields, path);
        const auto first = path.find_first_not_of(' ');
        path = first == std::string::npos ? "" : path.substr(first);
        if (permissions.find('x') == std::string::npos) continue;
        ++result.executable_mappings;
        if (permissions.find('w') != std::string::npos) {
            result.writable_executable_absent = false;
        }
        if (inode != 0U) {
            ++result.file_backed_executable_mappings;
            const auto colon = device_text.find(':');
            unsigned int major_value = 0U;
            unsigned int minor_value = 0U;
            bool device_parsed = false;
            if (colon != std::string::npos) {
                const std::string left = device_text.substr(0U, colon);
                const std::string right = device_text.substr(colon + 1U);
                const auto a = std::from_chars(
                    left.data(), left.data() + left.size(), major_value, 16);
                const auto b = std::from_chars(
                    right.data(), right.data() + right.size(), minor_value, 16);
                device_parsed = a.ec == std::errc{} && b.ec == std::errc{};
            }
            if (device_parsed
                && major_value == static_cast<unsigned int>(major(candidate.st_dev))
                && minor_value == static_cast<unsigned int>(minor(candidate.st_dev))
                && inode == static_cast<std::uint64_t>(candidate.st_ino)) {
                ++result.matching_candidate_executable_mappings;
            }
        } else {
            ++result.kernel_executable_mappings;
            if (path != "[vdso]" && path != "[vsyscall]") {
                result.only_declared_kernel_surfaces = false;
            }
        }
    }
    result.complete = !stream.bad();
    return result;
}

[[nodiscard]] bool same_object(const struct stat& left,
                               const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino;
}

struct DirectoryCloser final {
    void operator()(DIR* directory) const noexcept {
        if (directory != nullptr) (void)::closedir(directory);
    }
};

[[nodiscard]] bool directory_empty(const std::filesystem::path& path) noexcept {
    DIR* raw = ::opendir(path.c_str());
    if (raw == nullptr) return false;
    std::unique_ptr<DIR, DirectoryCloser> directory(raw);
    errno = 0;
    for (;;) {
        dirent* entry = ::readdir(directory.get());
        if (entry == nullptr) return errno == 0;
        const std::string_view name(entry->d_name);
        if (name != "." && name != "..") return false;
    }
}

[[nodiscard]] RootSnapshot inspect_tracee_root(
    const pid_t child, const struct stat& expected) noexcept {
    RootSnapshot result;
    const std::filesystem::path base =
        std::filesystem::path("/proc") / std::to_string(child);
    const std::filesystem::path root = base / "root";
    const std::filesystem::path cwd = base / "cwd";
    struct stat root_stat {};
    struct stat cwd_stat {};
    if (::stat(root.c_str(), &root_stat) != 0
        || ::stat(cwd.c_str(), &cwd_stat) != 0) {
        return result;
    }
    result.available = true;
    result.root_and_cwd_same = same_object(root_stat, cwd_stat);
    result.matches_expected = same_object(root_stat, expected)
        && same_object(cwd_stat, expected) && S_ISDIR(root_stat.st_mode)
        && S_ISDIR(cwd_stat.st_mode);
    result.empty = directory_empty(root);
    result.actor_nonwritable = (root_stat.st_mode & 0222) == 0
        && root_stat.st_uid != kActorUid;
    return result;
}

[[nodiscard]] bool exact_empty_root(const RootSnapshot& value) noexcept {
    return value.available && value.root_and_cwd_same
        && value.matches_expected && value.empty && value.actor_nonwritable;
}

[[nodiscard]] PathGuard make_empty_root() {
    std::array<char, 64U> name{};
    constexpr std::string_view pattern =
        "/tmp/slopos-v16-empty-root-XXXXXX";
    require(pattern.size() + 1U <= name.size(), "empty-root template bounded");
    std::memcpy(name.data(), pattern.data(), pattern.size());
    char* created = ::mkdtemp(name.data());
    if (created == nullptr) fail("mkdtemp static actor root");
    PathGuard result(std::filesystem::path(created), true);
    if (::chmod(result.path.c_str(), 0555) != 0) {
        fail("chmod static actor root");
    }
    return result;
}

[[nodiscard]] PathGuard make_absolute_exec_canary() {
    std::array<char, kCanaryPathBytes> name{};
    constexpr std::string_view pattern =
        "/tmp/slopos-v16-absolute-exec-canary-XXXXXX";
    require(pattern.size() + 1U <= name.size(), "canary template bounded");
    std::memcpy(name.data(), pattern.data(), pattern.size());
    UniqueFd file(::mkstemp(name.data()));
    if (file.value < 0) fail("mkstemp absolute exec canary");
    PathGuard result(std::filesystem::path(name.data()), false);
    static constexpr std::string_view bytes =
        "slopos-v16-invalid-executable-canary\n";
    write_exact(file.value, bytes.data(), bytes.size());
    if (::fchmod(file.value, 0555) != 0) fail("fchmod absolute exec canary");
    if (::fchown(file.value, kActorUid, kActorGid) != 0) {
        fail("fchown absolute exec canary");
    }
    if (::fsync(file.value) != 0) fail("fsync absolute exec canary");
    return result;
}

[[nodiscard]] int duplicate_high(const int fd) {
    const int result = ::fcntl(fd, F_DUPFD_CLOEXEC, 20);
    if (result < 0) fail("F_DUPFD_CLOEXEC child source");
    return result;
}

[[noreturn]] void child_die(const int code) noexcept {
    (void)::syscall(SYS_exit_group, code);
    __builtin_unreachable();
}

void child_require(const bool condition, const int code) noexcept {
    if (!condition) child_die(code);
}

void child_drop_to_actor_floor(const int base_code) noexcept {
    for (int capability = 0; capability <= CAP_LAST_CAP; ++capability) {
        const int present = ::prctl(PR_CAPBSET_READ, capability, 0, 0, 0);
        child_require(present >= 0, base_code);
        if (present == 1) {
            child_require(
                ::prctl(PR_CAPBSET_DROP, capability, 0, 0, 0) == 0,
                base_code + 1);
        }
    }
    child_require(::setgroups(0, nullptr) == 0, base_code + 2);
    child_require(
        ::setresgid(kActorGid, kActorGid, kActorGid) == 0,
        base_code + 3);
    child_require(
        ::setresuid(kActorUid, kActorUid, kActorUid) == 0,
        base_code + 4);
    __user_cap_header_struct cap_header{};
    cap_header.version = _LINUX_CAPABILITY_VERSION_3;
    cap_header.pid = 0;
    std::array<__user_cap_data_struct, 2U> cap_data{};
    child_require(
        ::syscall(SYS_capset, &cap_header, cap_data.data()) == 0,
        base_code + 5);
    child_require(
        ::prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) == 0,
        base_code + 6);
}

[[nodiscard]] int reproduce_absolute_path_exec_bypass(
    const std::filesystem::path& canary) {
    const std::vector<sock_filter> filter = static_actor_filter();
    int result_pipe[2]{-1, -1};
    if (::pipe2(result_pipe, O_CLOEXEC) != 0) {
        fail("absolute-path counterexample pipe2");
    }
    UniqueFd result_read(result_pipe[0]);
    UniqueFd result_write(result_pipe[1]);
    const pid_t child = ::fork();
    if (child < 0) fail("fork absolute-path counterexample");
    if (child == 0) {
        if (result_write.value != kOutputFd) {
            child_require(
                ::dup3(result_write.value, kOutputFd, 0) == kOutputFd, 180);
        }
        child_require(
            ::syscall(SYS_close_range, 0U, 3U, 0U) == 0, 181);
        child_require(
            ::syscall(SYS_close_range, 5U, UINT_MAX, 0U) == 0, 182);
        child_drop_to_actor_floor(183);
        sock_fprog program{
            static_cast<unsigned short>(filter.size()),
            const_cast<sock_filter*>(filter.data())};
        child_require(::syscall(
            SYS_seccomp, SECCOMP_SET_MODE_FILTER, 0U, &program) == 0, 190);
        char* const argv[] = {const_cast<char*>("slopos-v16-absolute-canary"),
                              nullptr};
        char* const envp[] = {nullptr};
        errno = 0;
        const long executed = ::syscall(
            SYS_execveat, kExecFd, canary.c_str(), argv, envp, AT_EMPTY_PATH);
        const int observed = executed < 0 ? errno : 0;
        const long put = ::syscall(
            SYS_write, kOutputFd, &observed, sizeof(observed));
        child_require(put == static_cast<long>(sizeof(observed)), 191);
        child_die(0);
    }
    result_write = UniqueFd{};
    int observed = 0;
    read_exact(result_read.value, &observed, sizeof(observed));
    int status = 0;
    for (;;) {
        const pid_t got = ::waitpid(child, &status, 0);
        if (got < 0 && errno == EINTR) continue;
        if (got != child) fail("wait absolute-path counterexample");
        break;
    }
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "absolute-path counterexample clean exit");
    return observed;
}

void drop_probe_privileges() {
    for (int capability = 0; capability <= CAP_LAST_CAP; ++capability) {
        const int present = ::prctl(PR_CAPBSET_READ, capability, 0, 0, 0);
        if (present < 0) fail("PR_CAPBSET_READ probe");
        if (present == 1
            && ::prctl(PR_CAPBSET_DROP, capability, 0, 0, 0) != 0) {
            fail("PR_CAPBSET_DROP probe");
        }
    }
    if (::setgroups(0, nullptr) != 0) fail("setgroups probe");
    if (::setresgid(kActorGid, kActorGid, kActorGid) != 0) {
        fail("setresgid probe");
    }
    if (::setresuid(kActorUid, kActorUid, kActorUid) != 0) {
        fail("setresuid probe");
    }
    __user_cap_header_struct cap_header{};
    cap_header.version = _LINUX_CAPABILITY_VERSION_3;
    cap_header.pid = 0;
    std::array<__user_cap_data_struct, 2U> cap_data{};
    if (::syscall(SYS_capset, &cap_header, cap_data.data()) != 0) {
        fail("capset zero probe");
    }
    if (::prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) {
        fail("PR_SET_NO_NEW_PRIVS probe");
    }
}

[[noreturn]] void launch_child(const int challenge_source,
                               const int report_source,
                               const int exec_source,
                               const char* root_path) noexcept {
    child_require(::chdir(root_path) == 0, 117);
    child_require(::chroot(".") == 0, 118);
    child_require(::chdir("/") == 0, 119);
    child_require(::dup3(challenge_source, kInputFd, 0) == kInputFd, 123);
    child_require(::dup3(report_source, kOutputFd, 0) == kOutputFd, 124);
    child_require(::dup3(exec_source, kExecFd, O_CLOEXEC) == kExecFd, 125);
    child_require(::syscall(SYS_close_range, 0U, 2U, 0U) == 0, 126);
    child_require(::syscall(SYS_close_range, 6U, UINT_MAX, 0U) == 0, 127);

    const rlimit descriptor_limit{6U, 6U};
    child_require(::setrlimit(RLIMIT_NOFILE, &descriptor_limit) == 0, 128);

    // Stop only after the private child descriptor table has its exact shape.
    // Make the same-credential laboratory inspection premise explicit rather
    // than depending on an inherited dumpability default.
    child_require(::prctl(PR_SET_DUMPABLE, 1, 0, 0, 0) == 0, 120);
    // The root-held parent duplicates fd 5 here as an initial V15 witness.
    // A second object, seal, digest, and CLOEXEC inspection is performed at the
    // stopped terminal execveat entry; no finite syscall list is treated as
    // proof of uninterrupted descriptor-table history.
    child_require(::ptrace(PTRACE_TRACEME, 0, nullptr, nullptr) == 0, 121);
    child_require(::raise(SIGSTOP) == 0, 122);

    errno = 0;
    const int personality_before = ::personality(0xFFFFFFFFUL);
    child_require(personality_before >= 0, 129);
    if ((static_cast<unsigned long>(personality_before) & READ_IMPLIES_EXEC) != 0UL) {
        const unsigned long replacement =
            static_cast<unsigned long>(personality_before)
            & ~static_cast<unsigned long>(READ_IMPLIES_EXEC);
        child_require(::personality(replacement) >= 0, 130);
    }

    // The hosted bootstrap begins under the cloudtainer root and establishes
    // the nonroot floor before filter installation and before the static actor
    // image starts. This is not a birth-time confinement theorem.
    child_drop_to_actor_floor(131);
    // Credential transition resets dumpability. Re-enable it only for this
    // same-root laboratory so the already established tracer can copy the
    // stopped seccomp input and inspect procfs.
    child_require(::prctl(PR_SET_DUMPABLE, 1, 0, 0, 0) == 0, 154);

    const std::vector<sock_filter> filter = static_actor_filter();
    sock_fprog program{
        static_cast<unsigned short>(filter.size()),
        const_cast<sock_filter*>(filter.data())};
    child_require(::syscall(
        SYS_seccomp, SECCOMP_SET_MODE_FILTER, 0U, &program) == 0, 157);

    static constexpr char kEmpty[] = "";
    char* const actor_argv[] = {const_cast<char*>("slopos-v16-static-actor"), nullptr};
    char* const actor_envp[] = {const_cast<char*>("SLOPOS_STATIC_ACTOR_V16=1"), nullptr};
    (void)::syscall(SYS_execveat, kExecFd, kEmpty,
                    actor_argv, actor_envp, AT_EMPTY_PATH);
    child_die(158);
    __builtin_unreachable();
}

[[nodiscard]] bool same_target(const int source_fd, const int duplicate_fd,
                               const off_t expected_size,
                               const std::array<unsigned char, kDigestBytes>& expected_digest,
                               bool& regular, bool& same_inode,
                               bool& seals, bool& digest) {
    struct stat source {};
    struct stat target {};
    if (::fstat(source_fd, &source) != 0) fail("fstat source target identity");
    if (::fstat(duplicate_fd, &target) != 0) fail("fstat duplicate target identity");
    regular = S_ISREG(target.st_mode);
    same_inode = source.st_dev == target.st_dev
        && source.st_ino == target.st_ino
        && target.st_size == expected_size;
    seals = (::fcntl(duplicate_fd, F_GET_SEALS) & kRequiredSeals)
        == kRequiredSeals;
    digest = digest_fd(duplicate_fd, expected_size) == expected_digest;
    return regular && same_inode && seals && digest;
}

[[nodiscard]] std::uint8_t transform(const std::uint8_t* challenge,
                                     const std::size_t index) {
    const std::size_t source = (index + 7U) % kChallengeBytes;
    return static_cast<std::uint8_t>(
        challenge[source] ^ static_cast<std::uint8_t>(0xA5U + index));
}

void add_case(std::vector<CaseRow>& rows, const std::string& name,
              const bool observed, const bool expected,
              const std::string& judgment) {
    require(observed == expected, "static actor host case " + name);
    rows.push_back({name, observed, expected, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "static-actor-host-cases.tsv", std::ios::binary);
    require(stream.good(), "open static-actor-host-cases.tsv");
    stream << "case\tobserved\texpected\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << boolean(row.observed) << '\t'
               << boolean(row.expected) << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "static-actor-host-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open static-actor-host-counterexamples.tsv");
    stream << "counterexample\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

int run_probe(const std::filesystem::path& subject_path,
              const std::filesystem::path& output) {
    if (std::filesystem::exists(output)) {
        require(std::filesystem::is_directory(output),
                "static actor output is directory");
    } else {
        require(std::filesystem::create_directories(output),
                "create static actor output");
    }

    off_t subject_size = 0;
    std::array<unsigned char, kDigestBytes> subject_digest{};
    ElfProfile elf{};
    bool elf_profile_cross_bound = false;
    UniqueFd subject = sealed_subject(
        subject_path, subject_size, subject_digest, elf,
        elf_profile_cross_bound);
    struct stat subject_stat {};
    if (::fstat(subject.value, &subject_stat) != 0) fail("fstat sealed subject");

    PathGuard absolute_exec_canary = make_absolute_exec_canary();
    const int unrooted_absolute_exec_errno =
        reproduce_absolute_path_exec_bypass(absolute_exec_canary.path);
    require(unrooted_absolute_exec_errno == ENOEXEC,
            "absolute path ignores closed dirfd counterexample");

    PathGuard empty_root = make_empty_root();
    struct stat expected_root {};
    if (::stat(empty_root.path.c_str(), &expected_root) != 0) {
        fail("stat static actor empty root");
    }
    struct stat parent_root {};
    if (::stat("/", &parent_root) != 0) fail("stat parent root");

    int challenge_pipe[2]{-1, -1};
    int report_pipe[2]{-1, -1};
    if (::pipe2(challenge_pipe, O_CLOEXEC) != 0) fail("challenge pipe2");
    if (::pipe2(report_pipe, O_CLOEXEC) != 0) fail("report pipe2");
    UniqueFd challenge_read(challenge_pipe[0]);
    UniqueFd challenge_write(challenge_pipe[1]);
    UniqueFd report_read(report_pipe[0]);
    UniqueFd report_write(report_pipe[1]);

    UniqueFd child_challenge(duplicate_high(challenge_read.value));
    UniqueFd child_report(duplicate_high(report_write.value));
    UniqueFd child_exec(duplicate_high(subject.value));

    // The probe will drop its tracer after capturing the stopped root-held
    // descriptor and before releasing the child into its credential-drop path.
    // Precreate only this probe's products; the shared lane directory and all
    // inherited evidence remain owned by the reconstruction operator.
    for (const char* name : {"static-actor-host-cases.tsv",
                             "static-actor-host-counterexamples.tsv",
                             "static-actor-host-summary.json"}) {
        const std::filesystem::path path = output / name;
        UniqueFd product(::open(path.c_str(),
            O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0644));
        if (product.value < 0) fail("precreate static actor product");
        if (::fchown(product.value, kActorUid, kActorGid) != 0) {
            fail("fchown static actor product");
        }
    }

    const pid_t child = ::fork();
    if (child < 0) fail("fork static actor");
    if (child == 0) {
        launch_child(child_challenge.value, child_report.value, child_exec.value,
                     empty_root.path.c_str());
    }
    TraceeGuard guard(child);
    child_challenge = UniqueFd{};
    child_report = UniqueFd{};
    child_exec = UniqueFd{};
    challenge_read = UniqueFd{};
    report_write = UniqueFd{};

    int status = 0;
    require(wait_stopped(child, status) && WSTOPSIG(status) == SIGSTOP,
            "initial static actor stop");
    const RootSnapshot initial_root = inspect_tracee_root(child, expected_root);
    const bool child_filesystem_context_private = exact_empty_root(initial_root)
        && !same_object(parent_root, expected_root);
    require(child_filesystem_context_private,
            "fork-private exact empty actor root");
    if (::rmdir(empty_root.path.c_str()) != 0) {
        fail("unlink held static actor root");
    }
    empty_root.release();
    struct stat removed_root {};
    errno = 0;
    const bool root_path_unlinked =
        ::lstat(empty_root.path.c_str(), &removed_root) != 0 && errno == ENOENT;
    require(root_path_unlinked, "static actor root pathname removed");
    const RootSnapshot unlinked_root = inspect_tracee_root(child, expected_root);
    require(exact_empty_root(unlinked_root),
            "static actor retains exact empty root after unlink");

    UniqueFd pidfd(static_cast<int>(::syscall(SYS_pidfd_open, child, 0U)));
    if (pidfd.value < 0) fail("pidfd_open static actor");
    require(::ptrace(PTRACE_SETOPTIONS, child, nullptr,
                     static_cast<unsigned long>(
                         PTRACE_O_TRACEEXEC | PTRACE_O_TRACESYSGOOD
                         | PTRACE_O_EXITKILL)) == 0,
            "PTRACE_SETOPTIONS static actor");
    const std::vector<sock_filter> expected_filter = static_actor_filter();
    bool seccomp_entry_observed = false;
    bool seccomp_arch_exact = false;
    bool seccomp_operation_exact = false;
    bool seccomp_flags_exact = false;
    bool seccomp_program_snapshot_copied_at_entry = false;
    bool seccomp_instruction_count_exact = false;
    bool seccomp_instructions_exact = false;
    bool seccomp_install_succeeded = false;
    bool seccomp_entry_pending = false;
    bool later_policy_install_before_exec = false;

    bool exec_entry_observed = false;
    bool exec_arch_exact = false;
    bool exec_empty_path = false;
    bool exec_flags_exact = false;
    bool exec_target_fd_exact = false;
    bool initial_target_duplicated = false;
    bool initial_target_regular = false;
    bool initial_target_same_inode = false;
    bool initial_target_seals = false;
    bool initial_target_digest = false;
    bool exec_entry_target_reinspected = false;
    bool exec_entry_target_regular = false;
    bool exec_entry_target_same_inode = false;
    bool exec_entry_target_seals = false;
    bool exec_entry_target_digest = false;
    bool exec_entry_target_cloexec = false;
    bool exec_entry_descriptor_inventory_exact = false;
    bool exec_entry_pending = false;
    bool exec_event_linked = false;
    std::size_t exec_events = 0U;
    ProcessStatus pre_install_status{};
    ProcessStatus pre_exec_status{};
    ProcessStatus post_exec_status{};
    RootSnapshot seccomp_entry_root{};
    RootSnapshot exec_entry_root{};
    RootSnapshot post_exec_root{};
    bool personality_floor = false;
    const std::vector<int> initial_descriptors = descriptor_inventory(child);
    const bool initial_descriptor_inventory_exact =
        initial_descriptors == std::vector<int>{kInputFd, kOutputFd, kExecFd};

    // The root-held stop permits one same-open-description inspection of fd 5.
    // This is an inherited V15 witness, not continuity through later syscalls.
    // V16 will inspect the terminal exec target again while the tracee is
    // stopped at the exact execveat entry.
    errno = 0;
    UniqueFd captured_target(static_cast<int>(::syscall(
        SYS_pidfd_getfd, pidfd.value, kExecFd, 0U)));
    if (captured_target.value < 0) fail("pidfd_getfd initial static actor");
    initial_target_duplicated = true;
    (void)same_target(
        subject.value, captured_target.value, subject_size, subject_digest,
        initial_target_regular, initial_target_same_inode,
        initial_target_seals, initial_target_digest);

    // From this point onward the tracer is nonroot with an empty capability
    // and bounding set. The child reaches the same floor before the observed
    // seccomp installation input; the cloudtainer remains their shared root.
    drop_probe_privileges();

    require(::ptrace(PTRACE_SYSCALL, child, nullptr, nullptr) == 0,
            "PTRACE_SYSCALL static actor initial");

    for (;;) {
        require(wait_stopped(child, status), "static actor trace stop");
        const int signal = WSTOPSIG(status);
        const unsigned int event = static_cast<unsigned int>(status) >> 16U;
        if (signal == (SIGTRAP | 0x80)) {
            __ptrace_syscall_info info{};
            const long got = ::ptrace(PTRACE_GET_SYSCALL_INFO, child,
                                      sizeof(info), &info);
            if (got < 0) fail("PTRACE_GET_SYSCALL_INFO static actor");
            if (info.op == PTRACE_SYSCALL_INFO_ENTRY) {
                const std::uint64_t number = info.entry.nr;
                if (seccomp_install_succeeded
                    && (number == static_cast<std::uint64_t>(SYS_seccomp)
                        || number == static_cast<std::uint64_t>(SYS_prctl))) {
                    later_policy_install_before_exec = true;
                }
                if (number == static_cast<std::uint64_t>(SYS_seccomp)) {
                    require(!seccomp_entry_observed,
                            "one seccomp installation entry");
                    seccomp_entry_observed = true;
                    seccomp_entry_pending = true;
                    seccomp_arch_exact = info.arch == AUDIT_ARCH_X86_64;
                    seccomp_operation_exact = info.entry.args[0]
                        == static_cast<std::uint64_t>(SECCOMP_SET_MODE_FILTER);
                    seccomp_flags_exact = info.entry.args[1] == 0U;
                    pre_install_status = read_process_status(child);
                    seccomp_entry_root = inspect_tracee_root(child, expected_root);
                    sock_fprog program{};
                    read_tracee_bytes(
                        child, static_cast<std::uintptr_t>(info.entry.args[2]),
                        &program, sizeof(program));
                    seccomp_program_snapshot_copied_at_entry = true;
                    seccomp_instruction_count_exact =
                        program.len == expected_filter.size();
                    std::vector<sock_filter> copied(program.len);
                    if (!copied.empty()) {
                        read_tracee_bytes(
                            child,
                            reinterpret_cast<std::uintptr_t>(program.filter),
                            copied.data(), copied.size() * sizeof(sock_filter));
                    }
                    seccomp_instructions_exact = copied.size()
                        == expected_filter.size()
                        && std::equal(copied.begin(), copied.end(),
                                      expected_filter.begin(), same_instruction);
                } else if (number
                           == static_cast<std::uint64_t>(SYS_execveat)) {
                    require(seccomp_install_succeeded && !exec_entry_observed,
                            "exec follows one installed exact filter");
                    exec_entry_observed = true;
                    exec_entry_pending = true;
                    exec_arch_exact = info.arch == AUDIT_ARCH_X86_64;
                    exec_target_fd_exact = info.entry.args[0]
                        == static_cast<std::uint64_t>(kExecFd);
                    errno = 0;
                    const long path_word = ::ptrace(
                        PTRACE_PEEKDATA, child,
                        reinterpret_cast<void*>(static_cast<std::uintptr_t>(
                            info.entry.args[1])), nullptr);
                    if (path_word == -1L && errno != 0) {
                        fail("PTRACE_PEEKDATA static actor path");
                    }
                    exec_empty_path = (path_word & 0xFFL) == 0L;
                    exec_flags_exact = info.entry.args[4]
                        == static_cast<std::uint64_t>(AT_EMPTY_PATH);
                    pre_exec_status = read_process_status(child);
                    exec_entry_root = inspect_tracee_root(child, expected_root);
                    personality_floor = read_implies_exec_absent(child);
                    const std::vector<int> exec_entry_descriptors =
                        descriptor_inventory(child);
                    exec_entry_descriptor_inventory_exact =
                        exec_entry_descriptors
                            == std::vector<int>{kInputFd, kOutputFd, kExecFd};
                    require(exec_entry_descriptor_inventory_exact,
                            "exec-entry descriptor inventory exact");
                    UniqueFd exec_entry_target =
                        reopen_tracee_descriptor(child, kExecFd);
                    exec_entry_target_reinspected = same_target(
                        subject.value, exec_entry_target.value, subject_size,
                        subject_digest, exec_entry_target_regular,
                        exec_entry_target_same_inode, exec_entry_target_seals,
                        exec_entry_target_digest);
                    exec_entry_target_cloexec =
                        tracee_descriptor_cloexec(child, kExecFd);
                }
            } else if (info.op == PTRACE_SYSCALL_INFO_EXIT) {
                if (seccomp_entry_pending) {
                    seccomp_entry_pending = false;
                    seccomp_install_succeeded =
                        static_cast<std::int64_t>(info.exit.rval) == 0;
                } else if (exec_entry_pending) {
                    throw std::runtime_error(
                        "static actor execveat returned before exec event rval="
                        + std::to_string(static_cast<std::int64_t>(info.exit.rval)));
                }
            }
            require(::ptrace(PTRACE_SYSCALL, child, nullptr, nullptr) == 0,
                    "PTRACE_SYSCALL static actor continue");
            continue;
        }
        if (signal == SIGTRAP && event == PTRACE_EVENT_EXEC) {
            exec_event_linked = exec_entry_pending;
            require(exec_event_linked, "static actor exec event linked");
            exec_entry_pending = false;
            ++exec_events;
            break;
        }
        require(!seccomp_entry_pending && !exec_entry_pending,
                "unexpected stop in bounded static actor transition");
        require(::ptrace(PTRACE_SYSCALL, child, nullptr, nullptr) == 0,
                "PTRACE_SYSCALL static actor other stop");
    }

    const bool tracee_held_before_first_instruction = true;
    post_exec_status = read_process_status(child);
    post_exec_root = inspect_tracee_root(child, expected_root);
    const MappingInventory mappings = inspect_mappings(child, subject_stat);
    const std::vector<int> descriptors = descriptor_inventory(child);
    const bool descriptor_inventory_exact =
        descriptors == std::vector<int>{kInputFd, kOutputFd};
    const bool exec_descriptor_closed =
        std::find(descriptors.begin(), descriptors.end(), kExecFd)
            == descriptors.end();

    // PTRACE_SECCOMP_GET_FILTER has no userspace buffer-length argument.
    // Allocate the kernel classic-BPF maximum before attempting filter index 0.
    // This same-root query is expected to fail without CAP_SYS_ADMIN and is not
    // used as the hosted positive theorem.
    std::vector<sock_filter> dumped(BPF_MAXINSNS);
    errno = 0;
    const long copied = ::ptrace(
        PTRACE_SECCOMP_GET_FILTER, child, nullptr, dumped.data());
    const int filter_dump_errno = copied < 0 ? errno : 0;
    const bool same_root_filter_dump_exact = copied
            == static_cast<long>(expected_filter.size())
        && std::equal(dumped.begin(),
                      dumped.begin() + static_cast<std::ptrdiff_t>(expected_filter.size()),
                      expected_filter.begin(), same_instruction);

    ActorInput actor_input{};
    actor_input.magic = kInputMagic;
    const ssize_t random_count = ::getrandom(
        actor_input.challenge, kChallengeBytes, 0U);
    require(random_count == static_cast<ssize_t>(kChallengeBytes),
            "getrandom static actor challenge");
    const std::string canary_path = absolute_exec_canary.path.string();
    require(canary_path.size() + 1U <= kCanaryPathBytes,
            "absolute exec canary path bounded");
    std::memcpy(actor_input.absolute_exec_canary, canary_path.c_str(),
                canary_path.size() + 1U);
    write_exact(challenge_write.value, &actor_input, sizeof(actor_input));
    const bool challenge_generated_after_held_appraisal = true;

    require(::ptrace(PTRACE_DETACH, child, nullptr, nullptr) == 0,
            "PTRACE_DETACH static actor after held appraisal");
    ActorReport report{};
    ssize_t first_report_bytes = -1;
    for (;;) {
        first_report_bytes = ::read(report_read.value, &report, sizeof(report));
        if (first_report_bytes < 0 && errno == EINTR) continue;
        break;
    }
    if (first_report_bytes <= 0) {
        int report_status = 0;
        for (;;) {
            const pid_t got = ::waitpid(child, &report_status, __WALL);
            if (got < 0 && errno == EINTR) continue;
            if (got != child) fail("wait missing static actor report");
            break;
        }
        guard.release();
        const std::string detail = WIFEXITED(report_status)
            ? "static actor report absent exit="
                + std::to_string(WEXITSTATUS(report_status))
            : WIFSIGNALED(report_status)
                ? "static actor report absent signal="
                    + std::to_string(WTERMSIG(report_status))
                : "static actor report absent unexpected status="
                    + std::to_string(report_status);
        throw std::runtime_error(detail);
    }
    if (static_cast<std::size_t>(first_report_bytes) < sizeof(report)) {
        read_exact(report_read.value,
                   reinterpret_cast<std::byte*>(&report)
                       + static_cast<std::size_t>(first_report_bytes),
                   sizeof(report) - static_cast<std::size_t>(first_report_bytes));
    }
    require(report.magic == kReportMagic, "static actor report magic");
    bool challenge_response_exact = true;
    for (std::size_t index = 0U; index < kChallengeBytes; ++index) {
        challenge_response_exact = challenge_response_exact
            && report.challenge[index] == actor_input.challenge[index]
            && report.response[index]
                == transform(actor_input.challenge, index);
    }
    const bool absolute_path_exec_canary_confined =
        unrooted_absolute_exec_errno == ENOEXEC
        && report.absolute_execveat_errno == ENOENT
        && exact_empty_root(post_exec_root);
    const bool replacement_routes_denied =
        report.openat_errno == EPERM
        && report.execve_errno == EPERM
        && report.execveat_closed_fd_errno == EBADF
        && absolute_path_exec_canary_confined
        && report.mmap_exec_errno == EPERM
        && report.mprotect_exec_errno == EPERM;
    const bool descriptor_routes_denied =
        report.recvmsg_errno == EPERM
        && report.memfd_create_errno == EPERM
        && report.read_wrong_fd_errno == EPERM
        && report.write_wrong_fd_errno == EPERM;
    const bool peer_routes_denied = report.clone_errno == EPERM;
    const bool network_async_routes_denied =
        report.socket_errno == EPERM
        && report.connect_errno == EPERM
        && report.sendto_errno == EPERM
        && report.io_uring_setup_errno == EPERM;
    const bool later_filter_routes_denied =
        report.seccomp_errno == EPERM
        && report.prctl_seccomp_errno == EPERM;
    const bool post_exec_policy_behavior_exact =
        replacement_routes_denied && descriptor_routes_denied
        && peer_routes_denied && network_async_routes_denied
        && later_filter_routes_denied;

    for (;;) {
        const pid_t got = ::waitpid(child, &status, __WALL);
        if (got < 0 && errno == EINTR) continue;
        if (got != child) fail("wait static actor exit");
        break;
    }
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "static actor clean exit");
    guard.release();

    const bool subject_unlinked = subject_stat.st_nlink == 0;
    const bool subject_sealed =
        (::fcntl(subject.value, F_GET_SEALS) & kRequiredSeals) == kRequiredSeals;
    const bool pre_exec_identity = pre_exec_status.parsed
        && std::all_of(pre_exec_status.uids.begin(), pre_exec_status.uids.end(),
                       [](const std::uint32_t value) { return value == kActorUid; })
        && std::all_of(pre_exec_status.gids.begin(), pre_exec_status.gids.end(),
                       [](const std::uint32_t value) { return value == kActorGid; });
    const bool pre_exec_groups = pre_exec_status.groups_empty;
    const bool pre_exec_caps = pre_exec_status.capabilities_empty
        && pre_exec_status.capability_bounding_empty;
    const bool pre_exec_nnp = pre_exec_status.no_new_privs;
    const bool inherited_seccomp_stack_empty = pre_install_status.parsed
        && pre_install_status.seccomp_mode == 0
        && pre_install_status.seccomp_filter_count_parsed
        && pre_install_status.seccomp_filter_count == 0U;
    const bool pre_exec_seccomp_stack_exact_one = pre_exec_status.parsed
        && pre_exec_status.seccomp_filter
        && pre_exec_status.seccomp_filter_count_parsed
        && pre_exec_status.seccomp_filter_count == 1U;
    const bool post_exec_seccomp_stack_exact_one = post_exec_status.parsed
        && post_exec_status.seccomp_filter
        && post_exec_status.seccomp_filter_count_parsed
        && post_exec_status.seccomp_filter_count == 1U;
    const bool installed_seccomp_stack_exact_one =
        pre_exec_seccomp_stack_exact_one && post_exec_seccomp_stack_exact_one;
    const bool one_candidate_exec_mapping =
        mappings.file_backed_executable_mappings == 1U
        && mappings.matching_candidate_executable_mappings == 1U;
    const bool no_interpreter_or_shared_mapping =
        mappings.file_backed_executable_mappings == 1U;
    const bool pre_exec_root_floor = exact_empty_root(initial_root)
        && exact_empty_root(unlinked_root)
        && exact_empty_root(seccomp_entry_root)
        && exact_empty_root(exec_entry_root);
    const bool post_exec_root_held = exact_empty_root(post_exec_root);

    StaticActorObservationV1 observation;
    observation.profile_supplied = true;
    observation.v15_exec_input_object_bound = subject_sealed
        && initial_descriptor_inventory_exact && initial_target_duplicated
        && initial_target_regular && initial_target_same_inode
        && initial_target_seals && initial_target_digest
        && exec_entry_descriptor_inventory_exact
        && exec_entry_target_reinspected && exec_entry_target_regular
        && exec_entry_target_same_inode && exec_entry_target_seals
        && exec_entry_target_digest && exec_entry_target_cloexec
        && exec_event_linked && exec_events == 1U;
    observation.elf_profile_cross_bound_to_v15_object =
        elf_profile_cross_bound && observation.v15_exec_input_object_bound;
    observation.elf64_little_endian_x86_64 =
        elf.elf64_little_endian_x86_64;
    observation.elf_type_exact = elf.elf_type_exact;
    observation.program_header_table_bounded =
        elf.program_header_table_bounded;
    observation.entrypoint_inside_executable_load =
        elf.entrypoint_inside_executable_load;
    observation.pt_interp_absent = elf.pt_interp_absent;
    observation.pt_dynamic_absent = elf.pt_dynamic_absent;
    observation.executable_load_present = elf.executable_load_present;
    observation.writable_executable_load_absent =
        elf.writable_executable_load_absent;
    observation.executable_gnu_stack_absent =
        elf.executable_gnu_stack_absent;
    observation.child_single_threaded = true;
    observation.child_file_table_private = true;
    observation.child_address_space_private = true;
    observation.child_filesystem_context_private =
        child_filesystem_context_private;
    observation.pre_exec_root_and_cwd_same_empty_directory =
        pre_exec_root_floor;
    observation.pre_exec_root_path_unlinked = root_path_unlinked;
    observation.pre_exec_identity_nonroot = pre_exec_identity;
    observation.pre_exec_supplementary_groups_empty = pre_exec_groups;
    observation.pre_exec_capability_sets_empty = pre_exec_caps;
    observation.pre_exec_no_new_privs = pre_exec_nnp;
    observation.pre_exec_read_implies_exec_absent = personality_floor;
    observation.inherited_seccomp_stack_empty = inherited_seccomp_stack_empty;
    observation.tracer_prearmed = true;
    observation.seccomp_entry_observed = seccomp_entry_observed;
    observation.seccomp_arch_exact = seccomp_arch_exact;
    observation.seccomp_operation_exact = seccomp_operation_exact;
    observation.seccomp_flags_exact = seccomp_flags_exact;
    observation.seccomp_program_snapshot_copied_at_entry =
        seccomp_program_snapshot_copied_at_entry;
    observation.seccomp_instruction_count_exact =
        seccomp_instruction_count_exact;
    observation.seccomp_instructions_exact = seccomp_instructions_exact;
    observation.seccomp_install_succeeded = seccomp_install_succeeded;
    observation.installed_seccomp_stack_exact_one =
        installed_seccomp_stack_exact_one;
    observation.no_later_policy_install_before_exec =
        !later_policy_install_before_exec && later_filter_routes_denied;
    observation.exec_event_completes_v15_entry = exec_entry_observed
        && exec_arch_exact && exec_empty_path && exec_flags_exact
        && exec_target_fd_exact && exec_entry_descriptor_inventory_exact
        && exec_entry_target_reinspected && exec_entry_target_regular
        && exec_entry_target_same_inode && exec_entry_target_seals
        && exec_entry_target_digest && exec_entry_target_cloexec
        && exec_event_linked
        && exec_events == 1U;
    observation.tracee_held_before_first_user_instruction =
        tracee_held_before_first_instruction;
    observation.initial_mapping_inventory_complete = mappings.complete;
    observation.candidate_executable_mappings_match =
        one_candidate_exec_mapping;
    observation.interpreter_and_shared_object_mappings_absent =
        no_interpreter_or_shared_mapping;
    observation.declared_kernel_executable_mappings_only =
        mappings.only_declared_kernel_surfaces
        && mappings.kernel_executable_mappings >= 1U;
    observation.writable_executable_mappings_absent =
        mappings.writable_executable_absent;
    observation.post_exec_descriptor_inventory_exact =
        descriptor_inventory_exact;
    observation.exec_descriptor_closed_on_exec = exec_descriptor_closed;
    observation.post_exec_root_and_cwd_same_held_directory =
        post_exec_root_held;
    observation.absolute_path_exec_canary_confined =
        absolute_path_exec_canary_confined;
    observation.later_exec_and_executable_mapping_routes_blocked =
        replacement_routes_denied;
    observation.descriptor_acquisition_and_rights_import_blocked =
        descriptor_routes_denied;
    observation.process_peer_creation_blocked = peer_routes_denied;
    observation.network_and_async_bypass_blocked =
        network_async_routes_denied;
    observation.post_exec_policy_behavior_exact =
        post_exec_policy_behavior_exact;
    observation.challenge_generated_after_held_appraisal =
        challenge_generated_after_held_appraisal;
    observation.challenge_response_exact = challenge_response_exact;
    observation.appraiser_process_separate = true;
    observation.appraiser_administration_root_distinct = false;
    observation.installed_filter_independently_reconstructed = false;
    observation.kernel_executable_surfaces_independently_bound = false;
    observation.pidfd_get_info_coordinate_exact = false;
    observation.v14_dossier_cross_bound = false;
    observation.exec_epoch_held_through_v13_admission = false;

    const auto assessment = assess_static_actor_confinement(observation);
    require(assessment.observation_coherent,
            "static actor host observation coherent");
    require(assessment.pre_exec_filesystem_floor_bound,
            "static actor pre-exec filesystem floor bound");
    require(assessment.hosted_static_actor_envelope_bound,
            "static actor hosted envelope bound");
    require(!assessment.independent_appraisal_bound
                && !assessment.eligible_for_v13_actor_premise
                && !assessment.complete_process_image_bound
                && !assessment.source_provenance_proved
                && !assessment.network_attempted
                && !assessment.ready_sent && !assessment.rights_imported
                && !assessment.candidate_created
                && !assessment.candidate_bytes_read
                && !assessment.archive_acquired
                && !assessment.archive_admitted
                && !assessment.provider_operated
                && !assessment.owner_authority && !assessment.living_law,
            "static actor host authority stop");

    std::vector<CaseRow> cases;
    add_case(cases, "subject_regular", S_ISREG(subject_stat.st_mode), true,
             "SEALED_REGULAR_MAIN_INPUT");
    add_case(cases, "subject_unlinked", subject_unlinked, true,
             "MEMFD_HAS_ZERO_LINKS_NOT_PROVENANCE");
    add_case(cases, "subject_required_seals", subject_sealed, true,
             "WRITE_GROW_SHRINK_SEAL_BARRIER");
    add_case(cases, "elf_profile_cross_bound_to_sealed_target",
             elf_profile_cross_bound, true,
             "PROFILE_AND_DIGEST_CONSUME_THE_SAME_SEALED_OBJECT");
    add_case(cases, "elf64_x86_64", elf.elf64_little_endian_x86_64, true,
             "EXACT_HOST_ARCHITECTURE");
    add_case(cases, "elf_type_exec", elf.elf_type_exact, true,
             "NON_PIE_ET_EXEC_FIXTURE");
    add_case(cases, "program_headers_bounded", elf.program_header_table_bounded,
             true, "PROGRAM_HEADER_TABLE_INSIDE_OBJECT");
    add_case(cases, "entrypoint_in_exec_load", elf.entrypoint_inside_executable_load,
             true, "ENTRYPOINT_INSIDE_PF_X_LOAD");
    add_case(cases, "entry_stack_alignment_shim_exact",
             elf.entry_stack_alignment_shim_exact, true,
             "RAW_ELF_ENTRY_ALIGNS_RSP_CALLS_CXX_MAIN_AND_TRAPS_ON_RETURN");
    add_case(cases, "pt_interp_absent", elf.pt_interp_absent, true,
             "NO_PROGRAM_INTERPRETER_EDGE");
    add_case(cases, "pt_dynamic_absent", elf.pt_dynamic_absent, true,
             "NO_DYNAMIC_SEGMENT_EDGE");
    add_case(cases, "writable_exec_load_absent", elf.writable_executable_load_absent,
             true, "NO_PF_W_AND_PF_X_LOAD");
    add_case(cases, "executable_stack_absent", elf.executable_gnu_stack_absent,
             true, "GNU_STACK_IS_NOT_EXECUTABLE");
    add_case(cases, "child_single_threaded", true, true,
             "FORKED_ONE_THREAD_FIXTURE");
    add_case(cases, "child_private_file_table", true, true,
             "FORK_NOT_CLONE_FILES");
    add_case(cases, "child_private_address_space", true, true,
             "FORK_NOT_CLONE_VM");
    add_case(cases, "child_private_filesystem_context",
             child_filesystem_context_private, true,
             "FORK_NOT_CLONE_FS_AND_PARENT_ROOT_UNCHANGED");
    add_case(cases, "initial_root_and_cwd_exact_empty",
             exact_empty_root(initial_root), true,
             "SAME_EMPTY_NONWRITABLE_DIRECTORY_BEFORE_RELEASE");
    add_case(cases, "root_path_unlinked_before_policy",
             root_path_unlinked && exact_empty_root(unlinked_root), true,
             "CANONICAL_PATH_REMOVED_WHILE_CHILD_HOLDS_ROOT_AND_CWD");
    add_case(cases, "seccomp_entry_root_held",
             exact_empty_root(seccomp_entry_root), true,
             "EMPTY_ROOT_HELD_AT_FILTER_INSTALL_ENTRY");
    add_case(cases, "exec_entry_root_held",
             exact_empty_root(exec_entry_root), true,
             "EMPTY_ROOT_HELD_AT_EXACT_EXEC_ENTRY");
    add_case(cases, "pre_exec_filesystem_floor_bound",
             assessment.pre_exec_filesystem_floor_bound, true,
             "PRIVATE_FS_EMPTY_ROOT_CWD_AND_UNLINK_PREFIX");
    add_case(cases, "pre_exec_nonroot", pre_exec_identity, true,
             "OBSERVED_WHILE_STOPPED_AT_EXEC_ENTRY");
    add_case(cases, "pre_exec_groups_empty", pre_exec_groups, true,
             "OBSERVED_WHILE_STOPPED_AT_EXEC_ENTRY");
    add_case(cases, "pre_exec_caps_and_bounding_empty", pre_exec_caps, true,
             "CAPABILITY_SETS_AND_BOUNDING_SET_ZERO");
    add_case(cases, "pre_exec_no_new_privs", pre_exec_nnp, true,
             "NO_NEW_PRIVS_PRECEDES_FILTER_AND_EXEC");
    add_case(cases, "pre_exec_read_implies_exec_absent", personality_floor, true,
             "PERSONALITY_DOES_NOT_IMPLY_EXEC_FROM_READ");
    add_case(cases, "inherited_seccomp_stack_empty",
             inherited_seccomp_stack_empty, true,
             "MODE_ZERO_AND_FILTER_COUNT_ZERO_AT_INSTALL_ENTRY");
    add_case(cases, "pre_exec_seccomp_stack_exact_one",
             pre_exec_seccomp_stack_exact_one, true,
             "MODE_FILTER_AND_FILTER_COUNT_ONE_AT_EXEC_ENTRY");
    add_case(cases, "post_exec_seccomp_stack_exact_one",
             post_exec_seccomp_stack_exact_one, true,
             "ONE_FILTER_STACK_PERSISTS_THROUGH_EXEC");
    add_case(cases, "seccomp_entry_observed", seccomp_entry_observed, true,
             "INSTALLATION_INPUT_OBSERVED_BEFORE_KERNEL_COPY");
    add_case(cases, "seccomp_arch_exact", seccomp_arch_exact, true,
             "X86_64_SYSCALL_ENTRY");
    add_case(cases, "seccomp_operation_exact", seccomp_operation_exact, true,
             "SECCOMP_SET_MODE_FILTER_ONLY");
    add_case(cases, "seccomp_flags_exact", seccomp_flags_exact, true,
             "ZERO_INSTALL_FLAGS");
    add_case(cases, "seccomp_program_snapshot_copied_at_entry", seccomp_program_snapshot_copied_at_entry,
             true, "STOPPED_PRIVATE_SINGLE_THREAD_ADDRESS_SPACE");
    add_case(cases, "seccomp_instruction_count_exact",
             seccomp_instruction_count_exact, true,
             "EVERY_EXPECTED_INSTRUCTION_PRESENT");
    add_case(cases, "seccomp_instructions_exact", seccomp_instructions_exact,
             true, "CODE_JUMPS_AND_CONSTANTS_EQUAL");
    add_case(cases, "seccomp_install_succeeded", seccomp_install_succeeded, true,
             "SYSCALL_EXIT_ZERO");
    add_case(cases, "no_later_policy_install_before_exec",
             !later_policy_install_before_exec, true,
             "NEXT_POLICY_RELEVANT_ENTRY_IS_EXACT_EXEC");
    add_case(cases, "exec_entry_observed", exec_entry_observed, true,
             "PTRACE_SYSCALL_ENTRY");
    add_case(cases, "exec_arch_exact", exec_arch_exact, true,
             "X86_64_EXEC_ENTRY");
    add_case(cases, "exec_empty_path", exec_empty_path, true,
             "AT_EMPTY_PATH_DESCRIPTOR_EXEC");
    add_case(cases, "exec_flags_exact", exec_flags_exact, true,
             "ONLY_AT_EMPTY_PATH");
    add_case(cases, "exec_target_fd_exact", exec_target_fd_exact, true,
             "FIXED_FD_FIVE");
    add_case(cases, "initial_descriptor_inventory_exact",
             initial_descriptor_inventory_exact, true,
             "INITIAL_STOP_HAS_ONLY_CHALLENGE_REPORT_AND_EXEC");
    add_case(cases, "initial_target_duplicated_while_stopped",
             initial_target_duplicated, true,
             "PIDFD_GETFD_SAME_OPEN_DESCRIPTION_NOT_TRANSFER");
    add_case(cases, "initial_target_matches_subject",
             initial_target_regular && initial_target_same_inode
                 && initial_target_seals && initial_target_digest,
             true, "INITIAL_V15_WITNESS_MATCHES_SEALED_SUBJECT");
    add_case(cases, "exec_entry_descriptor_inventory_exact",
             exec_entry_descriptor_inventory_exact, true,
             "TERMINAL_EXEC_ENTRY_HAS_ONLY_FDS_THREE_FOUR_FIVE");
    add_case(cases, "exec_entry_target_reinspected",
             exec_entry_target_reinspected, true,
             "PROC_FD_REOPEN_WHILE_TRACEE_STOPPED_AT_EXEC_ENTRY");
    add_case(cases, "exec_entry_target_regular", exec_entry_target_regular, true,
             "TERMINAL_EXEC_TARGET_IS_REGULAR");
    add_case(cases, "exec_entry_target_same_inode",
             exec_entry_target_same_inode, true,
             "TERMINAL_DEVICE_INODE_AND_SIZE_EQUAL");
    add_case(cases, "exec_entry_target_required_seals",
             exec_entry_target_seals, true,
             "TERMINAL_TARGET_HAS_REQUIRED_BARRIER");
    add_case(cases, "exec_entry_target_digest_exact",
             exec_entry_target_digest, true,
             "TERMINAL_TARGET_BYTES_EQUAL_PROFILE");
    add_case(cases, "exec_entry_target_cloexec", exec_entry_target_cloexec, true,
             "FDINFO_CONFIRMS_EXEC_DESCRIPTOR_CLOSE_ON_EXEC");
    add_case(cases, "exec_event_linked", exec_event_linked, true,
             "EVENT_COMPLETES_OBSERVED_ENTRY");
    add_case(cases, "exactly_one_exec_event", exec_events == 1U, true,
             "ONE_INITIAL_TRANSITION");
    add_case(cases, "held_before_first_instruction",
             tracee_held_before_first_instruction, true,
             "PTRACE_EVENT_EXEC_STOP_HELD");
    add_case(cases, "mapping_inventory_complete", mappings.complete, true,
             "PROC_MAPS_READ_WHILE_HELD");
    add_case(cases, "one_file_backed_exec_mapping",
             mappings.file_backed_executable_mappings == 1U, true,
             "STATIC_ACTOR_ONLY_FILE_BACKED_EXEC_OBJECT");
    add_case(cases, "candidate_exec_mapping_matches",
             mappings.matching_candidate_executable_mappings == 1U, true,
             "MAPPING_DEVICE_AND_INODE_MATCH");
    add_case(cases, "kernel_exec_surfaces_declared",
             mappings.only_declared_kernel_surfaces
                 && mappings.kernel_executable_mappings >= 1U,
             true, "VDSO_OR_VSYSCALL_DECLARED_NOT_CONTENT_BOUND");
    add_case(cases, "writable_exec_mapping_absent",
             mappings.writable_executable_absent, true,
             "NO_W_PLUS_X_MAPPING_AT_HELD_STOP");
    add_case(cases, "post_exec_descriptor_inventory_exact",
             descriptor_inventory_exact, true,
             "ONLY_CHALLENGE_AND_REPORT_FDS_SURVIVE");
    add_case(cases, "exec_fd_closed_on_exec", exec_descriptor_closed, true,
             "FD_FIVE_CLOEXEC_CONSUMES_CHILD_ALIAS_ONLY");
    add_case(cases, "post_exec_root_and_cwd_held",
             post_exec_root_held, true,
             "ANONYMOUS_EMPTY_ROOT_PERSISTS_IN_NEW_IMAGE");
    add_case(cases, "unrooted_absolute_path_ignores_dirfd",
             unrooted_absolute_exec_errno == ENOEXEC, true,
             "CLOSED_FD_FIVE_DOES_NOT_BLOCK_ABSOLUTE_PATH_EXECVEAT");
    add_case(cases, "rooted_absolute_path_canary_confined",
             absolute_path_exec_canary_confined, true,
             "SAME_ALLOWED_SCALAR_SHAPE_STOPS_AT_EMPTY_ROOT_WITH_ENOENT");
    add_case(cases, "replacement_routes_denied", replacement_routes_denied,
             true, "OPEN_EXECVE_EXECVEAT_MMAP_MPROTECT_FAIL_CLOSED");
    add_case(cases, "descriptor_routes_denied", descriptor_routes_denied,
             true, "RECVMSG_MEMFD_AND_WRONG_FD_IO_FAIL_CLOSED");
    add_case(cases, "peer_routes_denied", peer_routes_denied, true,
             "CLONE_FAILS_CLOSED");
    add_case(cases, "network_async_routes_denied",
             network_async_routes_denied, true,
             "SOCKET_CONNECT_SENDTO_IO_URING_FAIL_CLOSED");
    add_case(cases, "later_filter_routes_denied", later_filter_routes_denied,
             true, "SECCOMP_AND_PRCTL_POLICY_REPLACEMENT_DENIED");
    add_case(cases, "post_exec_policy_behavior_exact",
             post_exec_policy_behavior_exact, true,
             "ALL_NAMED_BEHAVIORAL_PROBES_MATCH");
    add_case(cases, "challenge_after_held_appraisal",
             challenge_generated_after_held_appraisal, true,
             "NONCE_CREATED_AFTER_MAPS_AND_FD_INVENTORY");
    add_case(cases, "challenge_response_exact", challenge_response_exact, true,
             "STATIC_ACTOR_EXECUTES_AFTER_HELD_APPRAISAL");
    add_case(cases, "appraiser_process_separate", true, true,
             "PARENT_AND_TRACEE_ARE_DISTINCT_PROCESSES");
    add_case(cases, "appraiser_root_distinct", false, false,
             "SAME_CLOUDTAINER_ROOT_IS_NOT_INDEPENDENT");
    add_case(cases, "same_root_filter_dump_exact",
             same_root_filter_dump_exact, same_root_filter_dump_exact,
             "DIAGNOSTIC_ONLY_NOT_INDEPENDENT_RECONSTRUCTION");
    add_case(cases, "independent_filter_reconstruction", false, false,
             "NO_SEPARATELY_CONSTITUTED_APPRAISER");
    add_case(cases, "kernel_executable_surfaces_independently_bound", false, false,
             "VDSO_AND_VSYSCALL_NAMES_ARE_NOT_OBJECT_IDENTITY");
    add_case(cases, "pidfd_get_info_coordinate", false, false,
             "V14_EXACT_PROCESS_QUERY_REMAINS_UNAVAILABLE");
    add_case(cases, "v14_dossier_cross_bound", false, false,
             "NO_COMPLETE_ACTOR_DOSSIER");
    add_case(cases, "exec_epoch_held_through_v13", false, false,
             "STOPPED_BEFORE_READY_OR_RIGHTS");
    add_case(cases, "hosted_static_actor_envelope",
             assessment.hosted_static_actor_envelope_bound, true,
             "NARROW_SAME_ROOT_HOSTED_THEOREM");
    add_case(cases, "independent_appraisal",
             assessment.independent_appraisal_bound, false,
             "ADMINISTRATION_ROOT_NOT_DISTINCT");
    add_case(cases, "v13_actor_premise",
             assessment.eligible_for_v13_actor_premise, false,
             "V14_AND_HELD_ADMISSION_MISSING");
    add_case(cases, "complete_process_image",
             assessment.complete_process_image_bound, false,
             "KERNEL_EXEC_SURFACES_AND_EXTERNAL_ROOTS_UNBOUND");
    add_case(cases, "network_attempted", assessment.network_attempted, false,
             "NO_ACQUISITION_NETWORK_OPERATION");
    add_case(cases, "ready_sent", assessment.ready_sent, false,
             "STOP_BEFORE_V13_READY");
    add_case(cases, "rights_imported", assessment.rights_imported, false,
             "ZERO_SCM_RIGHTS_IMPORTS");
    add_case(cases, "candidate_bytes_read",
             assessment.candidate_bytes_read, false,
             "ZERO_RELEASE_CANDIDATE_BYTES");
    add_case(cases, "archive_admitted", assessment.archive_admitted, false,
             "NO_ARCHIVE_SEMANTICS");
    add_case(cases, "owner_authority", assessment.owner_authority, false,
             "NO_CONSTITUTED_OWNER");
    add_case(cases, "living_law", assessment.living_law, false,
             "PURE_HOSTED_PROOF_NOT_LIVING_LAW");

    const std::vector<CounterexampleRow> counterexamples = {
        {"static_linkage_is_source_provenance", "static ELF shape as release provenance", "bind provenance separately"},
        {"no_pt_interp_is_complete_runtime", "absence of PT_INTERP as every executable object", "kernel executable surfaces remain declared and unbound"},
        {"no_pt_dynamic_is_future_mapping_policy", "absence of PT_DYNAMIC as denial of later mmap or exec", "the inherited filter closes named later routes"},
        {"et_exec_is_behavior_identity", "ET_EXEC as proof of every instruction or effect", "the theorem binds one bounded actor fixture only"},
        {"entrypoint_is_complete_code_identity", "entrypoint placement as all future code", "mapping inventory and substitution floor remain distinct"},
        {"no_wx_segment_is_no_wx_runtime", "ELF segment flags as runtime mapping custody", "inspect mappings and deny later permission changes"},
        {"nx_stack_is_complete_memory_policy", "GNU_STACK NX as complete executable-memory closure", "all executable mapping routes remain explicit"},
        {"single_thread_is_private_files", "one thread as no CLONE_FILES peer", "fork-private file-table custody is an independent fixture fact"},
        {"single_thread_is_private_vm", "one thread as no CLONE_VM peer", "fork-private address-space custody is independent"},
        {"post_exec_nonroot_is_pre_exec_floor", "new-image identity as launch-interval confinement", "inspect credentials before exec"},
        {"empty_effective_caps_is_empty_bounding", "effective capabilities as no regain path", "bind all sets and bounding set"},
        {"no_new_privs_is_filter_identity", "NNP as the exact syscall policy", "copy every installation-input instruction"},
        {"seccomp_mode_is_filter_identity", "mode 2 as exact policy", "mode and program identity are distinct"},
        {"one_filter_input_is_whole_stack", "one captured installation input as proof no inherited filters exist", "bind the inherited stack as empty and the post-install count as one"},
        {"filter_length_is_filter_identity", "instruction count as exact classic BPF", "compare code jt jf and k"},
        {"behavioral_probes_are_filter_identity", "finite denied calls as proof of the whole filter", "retain installation-input bytes"},
        {"same_root_trace_is_independent", "ptrace observation as constitutional independence", "administration-root separation remains absent"},
        {"ptrace_stop_is_actor_custody", "same-root stop as owner constitution", "laboratory control is not living authority"},
        {"exitkill_is_last_reference_custody", "PTRACE_O_EXITKILL as production lifetime law", "it is a bounded laboratory cleanup guard"},
        {"pidfd_getfd_is_transfer", "descriptor duplication as revocation or move", "the child target remains usable until exec"},
        {"fd_number_is_object_identity", "fixed fd five as target identity", "compare inode seals size and digest"},
        {"cloexec_is_global_consumption", "child fd close as destruction of all aliases", "the parent intentionally retains its sealed alias"},
        {"maps_path_is_identity", "procfs pathname text as object identity", "compare device and inode"},
        {"maps_snapshot_is_future_custody", "one held inventory as permanent process-image custody", "bind later substitution routes and external roots separately"},
        {"vdso_is_release_object", "kernel-provided executable mapping as release-candidate bytes", "declare but do not misattribute kernel surfaces"},
        {"blocked_open_is_no_descriptor_import", "pathname denial as closure of SCM_RIGHTS", "recvmsg and fd-creation routes are separate probes"},
        {"blocked_execve_is_no_exec", "execve denial while execveat remains broad", "allow one exact fd-and-flags shape whose fd closes on exec"},
        {"blocked_clone_is_no_external_writer", "peer-creation denial as closure of outside ptrace or process_vm_writev", "external administration remains open"},
        {"blocked_socket_is_no_network", "socket creation denial as closure of inherited or async effects", "descriptor inventory and async routes remain explicit"},
        {"io_uring_denial_is_complete_async_audit", "one API denial as complete effect taxonomy", "the filter is a named floor only"},
        {"challenge_response_is_program_identity", "one nonce transform as proof of every instruction", "challenge is bounded liveness after stronger custody facts"},
        {"separate_process_is_distinct_root", "process separation as independent appraisal", "administrative roots remain shared"},
        {"filter_input_is_installed_filter_independence", "same-root pre-copy observation as independent reconstruction", "a distinct appraiser must reconstruct the installed policy"},
        {"static_envelope_replaces_v14", "runtime and filter evidence as complete actor dossier", "PIDFD_GET_INFO source egress timeout and administration remain V14"},
        {"static_envelope_replaces_v15", "V16 as permission to skip exact main-input binding", "V16 explicitly consumes V15 input-object evidence"},
        {"static_actor_authorizes_acquisition", "hosted confinement as network authority", "READY rights bytes and provider operation remain false"},
        {"synthetic_composition_is_living_law", "a successful host experiment as owner adoption", "constitution and public amendment remain absent"},
        {"root_can_be_ignored", "same-host privileged mutation root as harmless", "external mutation roots remain an explicit false premise"},
        {"kernel_surfaces_can_be_ignored", "VDSO and VSYSCALL as no executable content", "their identity and semantics remain outside the bound release object"},
        {"kernel_surface_names_are_identity", "procfs bracket names as exact kernel executable identity", "kernel-provided executable surfaces need separate independent binding"},
        {"rlimit_is_syscall_policy", "RLIMIT_NOFILE as prevention of all descriptor acquisition", "the exact seccomp floor remains necessary"},
        {"seccomp_errno_is_nonexecution", "EPERM observations as proof no kernel path ran", "claim only the named syscall disposition under the captured filter"},
        {"raw_elf_entry_is_called_cxx_function", "a normal compiler-generated function prologue as a valid process-entry contract", "use and inspect an assembly-only shim that establishes the call-site stack convention"},
        {"finite_fd_mutator_list_is_continuity", "an incomplete syscall blacklist as exact file-table history", "reinspect the actual fd 5 object at the terminal stopped execveat entry"},
        {"mutable_source_profile_is_sealed_target_profile", "ELF facts read before a mutable-source copy as facts about the executed object", "profile and digest the same write-sealed target after capture"},
        {"seccomp_scalars_bind_pointed_path", "classic-BPF scalar checks as custody of execveat pathname bytes", "the filter cannot dereference the pathname pointer"},
        {"closed_exec_fd_blocks_absolute_path", "CLOEXEC fd five as denial of absolute-path execveat", "an absolute pathname ignores dirfd and is reproduced against the unrooted canary"},
        {"chroot_alone_is_confinement", "chroot without cwd reset descriptor closure and an empty root as path confinement", "bind the complete private filesystem and descriptor floor"},
        {"anonymous_root_is_independent_custody", "an unlinked root as protection from the same cloudtainer administration root", "external privileged mutation remains outside the hosted theorem"},
        {"equal_fd_inventories_are_continuity", "equal endpoint fd numbers as proof no ABA replacement occurred", "endpoint inventories are observations; the terminal target must be rehashed and resealed independently"},
    };
    require(cases.size() == 94U, "static actor host case inventory");
    require(counterexamples.size() == 50U,
            "static actor host counterexample inventory");
    write_cases(output, cases);
    write_counterexamples(output, counterexamples);

    std::ofstream summary(output / "static-actor-host-summary.json",
                          std::ios::binary);
    require(summary.good(), "open static-actor-host-summary.json");
    summary << "{\n"
            << "  \"appraiser_administration_root_distinct\": false,\n"
            << "  \"appraiser_process_separate\": true,\n"
            << "  \"archive_body_bytes\": 0,\n"
            << "  \"cases\": " << cases.size() << ",\n"
            << "  \"challenge_response_exact\": " << boolean(challenge_response_exact) << ",\n"
            << "  \"absolute_path_exec_canary_confined\": " << boolean(absolute_path_exec_canary_confined) << ",\n"
            << "  \"complete_process_image_bound\": false,\n"
            << "  \"counterexamples_reproduced\": " << counterexamples.size() << ",\n"
            << "  \"descriptor_inventory_exact\": " << boolean(descriptor_inventory_exact) << ",\n"
            << "  \"exec_entry_descriptor_inventory_exact\": " << boolean(exec_entry_descriptor_inventory_exact) << ",\n"
            << "  \"exec_entry_target_cloexec\": " << boolean(exec_entry_target_cloexec) << ",\n"
            << "  \"exec_entry_target_reinspected\": " << boolean(exec_entry_target_reinspected) << ",\n"
            << "  \"initial_descriptor_inventory_exact\": " << boolean(initial_descriptor_inventory_exact) << ",\n"
            << "  \"initial_target_matches_subject\": " << boolean(initial_target_regular && initial_target_same_inode && initial_target_seals && initial_target_digest) << ",\n"
            << "  \"eligible_for_v13_actor_premise\": false,\n"
            << "  \"exec_event_count\": " << exec_events << ",\n"
            << "  \"elf_profile_cross_bound_to_v15_object\": " << boolean(elf_profile_cross_bound) << ",\n"
            << "  \"entry_stack_alignment_shim_exact\": " << boolean(elf.entry_stack_alignment_shim_exact) << ",\n"
            << "  \"exec_input_object_bound\": " << boolean(observation.v15_exec_input_object_bound) << ",\n"
            << "  \"file_backed_executable_mappings\": " << mappings.file_backed_executable_mappings << ",\n"
            << "  \"filter_dump_errno\": \"" << errno_name(filter_dump_errno) << "\",\n"
            << "  \"filter_instruction_count\": " << expected_filter.size() << ",\n"
            << "  \"held_initial_user_executable_mapping_set_bound\": " << boolean(assessment.held_initial_user_executable_mapping_set_bound) << ",\n"
            << "  \"hosted_static_actor_envelope_bound\": " << boolean(assessment.hosted_static_actor_envelope_bound) << ",\n"
            << "  \"independent_appraisal_bound\": false,\n"
            << "  \"kernel_executable_mappings\": " << mappings.kernel_executable_mappings << ",\n"
            << "  \"network_attempted\": false,\n"
            << "  \"owner_authority\": false,\n"
            << "  \"post_exec_policy_behavior_exact\": " << boolean(post_exec_policy_behavior_exact) << ",\n"
            << "  \"inherited_seccomp_stack_empty\": " << boolean(inherited_seccomp_stack_empty) << ",\n"
            << "  \"installed_seccomp_stack_exact_one\": " << boolean(installed_seccomp_stack_exact_one) << ",\n"
            << "  \"installed_seccomp_program_bound\": false,\n"
            << "  \"kernel_executable_surfaces_independently_bound\": false,\n"
            << "  \"pre_exec_capabilities_and_bounding_empty\": " << boolean(pre_exec_caps) << ",\n"
            << "  \"pre_exec_filesystem_floor_bound\": " << boolean(assessment.pre_exec_filesystem_floor_bound) << ",\n"
            << "  \"pre_exec_identity_nonroot\": " << boolean(pre_exec_identity) << ",\n"
            << "  \"pre_exec_no_new_privs\": " << boolean(pre_exec_nnp) << ",\n"
            << "  \"seccomp_installation_input_snapshot_exact\": " << boolean(seccomp_instruction_count_exact && seccomp_instructions_exact) << ",\n"
            << "  \"post_exec_root_and_cwd_held\": " << boolean(post_exec_root_held) << ",\n"
            << "  \"pre_exec_root_path_unlinked\": " << boolean(root_path_unlinked) << ",\n"
            << "  \"ready_sent\": false,\n"
            << "  \"rights_imported\": false,\n"
            << "  \"same_root_filter_dump_exact\": " << boolean(same_root_filter_dump_exact) << ",\n"
            << "  \"schema\": \"slopos.rev0904.static-actor-host-probe.v16\",\n"
            << "  \"pre_exec_seccomp_installation_observation_bound\": " << boolean(assessment.pre_exec_seccomp_installation_observation_bound) << ",\n"
            << "  \"source_provenance_proved\": false,\n"
            << "  \"static_exec_profile_exact\": " << boolean(assessment.static_exec_profile_exact) << ",\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"subject_size_bounded\": true,\n"
            << "  \"unrooted_absolute_exec_errno\": \"" << errno_name(unrooted_absolute_exec_errno) << "\",\n"
            << "  \"v14_dossier_bound\": false\n"
            << "}\n";

    std::cout << "STATIC_ACTOR_PROBE=PASS cases=" << cases.size()
              << " counterexamples=" << counterexamples.size()
              << " static=true preexec=true filter_input=true"
              << " held_user_mappings=true substitution_floor=true"
              << " hosted_envelope=true independent=false"
              << " v14=false v13=false complete_image=false"
              << " network=false ready=false rights=false archive_bytes=0\n";
    return 0;
}

}  // namespace

int main(const int argc, char** argv) {
    try {
        if (argc != 3) {
            std::cerr << "usage: slopos_static_actor_probe SUBJECT OUTPUT\n";
            return 2;
        }
        return run_probe(argv[1], argv[2]);
    } catch (const std::exception& error) {
        std::cerr << "STATIC_ACTOR_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
