# SlopOS rev0938: configured expectation and continuity repair

This is a bounded Epoch Zero construction. It does not simulate an owner or promote the
project out of Epoch Zero.

## Open in this order

1. `office/STATE.json`
2. `proof/configured-pack-expectation.md`
3. `proof/predecessor-continuity.md`
4. `repo/living-vault-boundary.md`
5. `office/REOPEN.md`

## Build and test

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./run-gates.sh "/mnt/data/slopos-rev0938-work/extract/SlopOS-rev0938-2026.08.07.00.35-configuredexpectation-sealedobservation-predecessorgate-selfpinningcut" "/mnt/data/SlopOS-rev0937-2026.08.06.21.19-rootedshadowpack-exactinverse-racefence-aliasaddress.zip"
```

The C++ harness is intentionally nested and independently configurable so inherited vault
projects cannot be pulled into the build by a recursive source glob.
