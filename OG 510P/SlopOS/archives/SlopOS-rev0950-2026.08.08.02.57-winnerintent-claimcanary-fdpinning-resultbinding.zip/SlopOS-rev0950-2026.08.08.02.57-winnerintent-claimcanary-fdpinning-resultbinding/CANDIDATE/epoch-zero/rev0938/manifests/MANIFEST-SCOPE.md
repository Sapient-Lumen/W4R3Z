# Manifest scope

`payload.sha256` hashes every regular file under the cube root except itself and
`closure/CLOSURE.json`, which embeds the manifest digest. Symlink targets are retained by
the ZIP container but are not followed or represented as regular-file hashes here.

Verify from the cube root:

```sh
sha256sum --check <path-to-rev0938>/manifests/payload.sha256
```
