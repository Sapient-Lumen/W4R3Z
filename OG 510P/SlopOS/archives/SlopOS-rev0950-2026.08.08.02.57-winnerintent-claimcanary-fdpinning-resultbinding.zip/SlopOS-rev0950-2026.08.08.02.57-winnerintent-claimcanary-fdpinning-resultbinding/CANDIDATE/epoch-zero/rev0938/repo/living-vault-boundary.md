# Repository boundary: living project versus vault

Detected living project root for this close: `CANDIDATE`.  
rev0938 construction root: `CANDIDATE/epoch-zero/rev0938`.

The datacube is not one recursively buildable repository. It has two different semantic
regions even where legacy path names blur them:

- **Living surface:** the smallest active code, proof, test, and office state that may be
  changed and promoted. New rev0938 work is confined to the construction root above plus
  the repaired live predecessor narrative.
- **Vault/evidence surface:** inherited payloads retained to answer provenance, regression,
  and archaeological questions. Presence in the cube does not make a file active, true,
  compiled, or promotable.

## Repository rule set

1. Never glob source recursively from the cube root. Configure an explicitly named living
   CMake root.
2. Never make a vault document authoritative merely by linking to it. Restate the law in
   the living proof map and cite the evidence path.
3. Preserve exact bytes before repairing a live narrative or source leaf.
4. A receipt may identify inherited material without claiming it is a complete snapshot.
5. Destructive deduplication is forbidden during Epoch Zero. First build a content-identity
   map, prove all reopen paths are manifest-addressed, then migrate in a separately ratified act.

The lexical audit labels paths containing words such as `vault`, `archive`, `evidence`, or
`predecessor` as vault-like. That is a measurement heuristic, not authority. Ambiguous paths
are debt to be resolved by explicit manifests rather than mass relocation.
