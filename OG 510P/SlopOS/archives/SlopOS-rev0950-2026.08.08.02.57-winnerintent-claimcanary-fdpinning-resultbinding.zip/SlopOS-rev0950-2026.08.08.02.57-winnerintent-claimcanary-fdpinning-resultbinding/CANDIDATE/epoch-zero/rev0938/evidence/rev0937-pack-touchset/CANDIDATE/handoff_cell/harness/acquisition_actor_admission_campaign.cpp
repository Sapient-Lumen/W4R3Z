#include "acquisition_actor_admission_campaign.hpp"

#include "slopos/e0/handoff_cell/acquisition_actor_admission.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

using slopos::e0::handoff_cell::AcquisitionActorAssessment;
using slopos::e0::handoff_cell::AcquisitionActorDisposition;
using slopos::e0::handoff_cell::AcquisitionActorObservationV1;
using slopos::e0::handoff_cell::acquisition_actor_disposition_name;
using slopos::e0::handoff_cell::assess_acquisition_actor;

using Field = bool AcquisitionActorObservationV1::*;
constexpr std::array<Field, 39U> kFields = {
    &AcquisitionActorObservationV1::profile_supplied,
    &AcquisitionActorObservationV1::executable_descriptor_pinned,
    &AcquisitionActorObservationV1::executable_digest_exact,
    &AcquisitionActorObservationV1::dependency_manifest_exact,
    &AcquisitionActorObservationV1::argv_exact,
    &AcquisitionActorObservationV1::environment_exact,
    &AcquisitionActorObservationV1::working_directory_exact,
    &AcquisitionActorObservationV1::umask_exact,
    &AcquisitionActorObservationV1::uid_nonroot,
    &AcquisitionActorObservationV1::gid_nonroot,
    &AcquisitionActorObservationV1::supplementary_groups_empty,
    &AcquisitionActorObservationV1::capabilities_empty,
    &AcquisitionActorObservationV1::no_new_privs_enabled,
    &AcquisitionActorObservationV1::seccomp_filter_exact,
    &AcquisitionActorObservationV1::inherited_descriptor_inventory_exact,
    &AcquisitionActorObservationV1::fixed_https_source,
    &AcquisitionActorObservationV1::source_host_exact,
    &AcquisitionActorObservationV1::proxy_inputs_absent,
    &AcquisitionActorObservationV1::network_egress_fixed,
    &AcquisitionActorObservationV1::timeout_bounded,
    &AcquisitionActorObservationV1::retry_budget_zero,
    &AcquisitionActorObservationV1::administration_inventory_complete,
    &AcquisitionActorObservationV1::receiver_before_candidate_policy_exact,
    &AcquisitionActorObservationV1::unlinked_sealable_output_only,
    &AcquisitionActorObservationV1::complete_before_seal_required,
    &AcquisitionActorObservationV1::full_seal_barrier_required,
    &AcquisitionActorObservationV1::actor_pidfd_supplied,
    &AcquisitionActorObservationV1::pidfd_get_info_supported,
    &AcquisitionActorObservationV1::pidfd_info_pid_present,
    &AcquisitionActorObservationV1::pidfd_info_creds_present,
    &AcquisitionActorObservationV1::pidfd_pid_matches_peer,
    &AcquisitionActorObservationV1::pidfd_tgid_matches_peer,
    &AcquisitionActorObservationV1::pidfd_euid_matches_profile,
    &AcquisitionActorObservationV1::pidfd_egid_matches_profile,
    &AcquisitionActorObservationV1::pidfd_cgroup_matches_profile,
    &AcquisitionActorObservationV1::appraiser_profile_supplied,
    &AcquisitionActorObservationV1::appraiser_root_distinct,
    &AcquisitionActorObservationV1::appraiser_reconstructed_dossier,
    &AcquisitionActorObservationV1::appraiser_challenge_exact,
};

struct Cut final {
    std::size_t prefix;
    AcquisitionActorDisposition expected;
    const char* name;
};

constexpr std::array<Cut, 26U> kCuts = {{
    {0U, AcquisitionActorDisposition::profile_unavailable, "profile_unavailable"},
    {1U, AcquisitionActorDisposition::executable_descriptor_unpinned, "executable_descriptor_unpinned"},
    {2U, AcquisitionActorDisposition::executable_digest_mismatch, "executable_digest_mismatch"},
    {3U, AcquisitionActorDisposition::dependency_epoch_mismatch, "dependency_epoch_mismatch"},
    {4U, AcquisitionActorDisposition::launch_envelope_rejected, "launch_envelope_rejected"},
    {8U, AcquisitionActorDisposition::privilege_identity_rejected, "privilege_identity_rejected"},
    {10U, AcquisitionActorDisposition::supplementary_groups_rejected, "supplementary_groups_rejected"},
    {11U, AcquisitionActorDisposition::ambient_capabilities_rejected, "ambient_capabilities_rejected"},
    {12U, AcquisitionActorDisposition::no_new_privs_missing, "no_new_privs_missing"},
    {13U, AcquisitionActorDisposition::seccomp_policy_missing, "seccomp_policy_missing"},
    {14U, AcquisitionActorDisposition::inherited_descriptor_inventory_rejected, "inherited_descriptor_inventory_rejected"},
    {15U, AcquisitionActorDisposition::source_policy_rejected, "source_policy_rejected"},
    {18U, AcquisitionActorDisposition::network_policy_rejected, "network_policy_rejected"},
    {19U, AcquisitionActorDisposition::timeout_policy_rejected, "timeout_policy_rejected"},
    {20U, AcquisitionActorDisposition::retry_policy_rejected, "retry_policy_rejected"},
    {21U, AcquisitionActorDisposition::administration_inventory_incomplete, "administration_inventory_incomplete"},
    {22U, AcquisitionActorDisposition::candidate_lifecycle_policy_rejected, "candidate_lifecycle_policy_rejected"},
    {23U, AcquisitionActorDisposition::output_snapshot_policy_rejected, "output_snapshot_policy_rejected"},
    {26U, AcquisitionActorDisposition::pidfd_coordinate_unavailable, "pidfd_coordinate_unavailable"},
    {27U, AcquisitionActorDisposition::pidfd_get_info_unavailable, "pidfd_get_info_unavailable"},
    {28U, AcquisitionActorDisposition::pidfd_info_incomplete, "pidfd_info_incomplete"},
    {30U, AcquisitionActorDisposition::pidfd_coordinate_mismatch, "pidfd_coordinate_mismatch"},
    {35U, AcquisitionActorDisposition::appraiser_unavailable, "appraiser_unavailable"},
    {36U, AcquisitionActorDisposition::appraiser_not_independent, "appraiser_not_independent"},
    {37U, AcquisitionActorDisposition::appraisal_reconstruction_failed, "appraisal_reconstruction_failed"},
    {38U, AcquisitionActorDisposition::appraisal_challenge_failed, "appraisal_challenge_failed"},
}};

struct CaseRow final {
    std::string name;
    AcquisitionActorAssessment assessment;
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    const char* name;
    const char* defeats;
    const char* retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* boolean(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] AcquisitionActorObservationV1 prefix_observation(
    const std::size_t count) noexcept {
    AcquisitionActorObservationV1 result;
    for (std::size_t index = 0U; index < count; ++index) {
        result.*kFields[index] = true;
    }
    return result;
}

void add_case(std::vector<CaseRow>& rows, const char* name,
              const AcquisitionActorObservationV1& observation,
              const AcquisitionActorDisposition expected,
              const bool counterexample, const char* judgment) {
    const AcquisitionActorAssessment assessment =
        assess_acquisition_actor(observation);
    require(assessment.disposition == expected,
            std::string("disposition ") + name + " observed="
                + acquisition_actor_disposition_name(assessment.disposition));
    require(assessment.observation_coherent
                == (expected != AcquisitionActorDisposition::observation_incoherent),
            std::string("coherence ") + name);
    require(assessment.actor_profile_admissible
                == (expected == AcquisitionActorDisposition::actor_profile_admissible),
            std::string("admissibility ") + name);
    require(!assessment.eligible_for_v13_actor_premise,
            std::string("V14 alone must not establish V13 eligibility ") + name);
    require(!assessment.ready_sent && !assessment.rights_imported
                && !assessment.candidate_created
                && !assessment.candidate_bytes_read
                && !assessment.archive_acquired && !assessment.archive_admitted
                && !assessment.source_provenance_proved
                && !assessment.owner_authority && !assessment.living_law,
            std::string("authority leak ") + name);
    rows.push_back({name, assessment, counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "acquisition-actor-cases.tsv", std::ios::binary);
    require(stream.good(), "open acquisition-actor-cases.tsv");
    stream << "case\tdisposition\tobservation_coherent\texecutable_epoch_exact"
              "\tlaunch_envelope_exact\tprivilege_boundary_exact"
              "\tinherited_descriptor_inventory_exact\tsource_policy_exact"
              "\tnetwork_policy_exact\ttimeout_policy_exact\tretry_policy_exact"
              "\tadministration_inventory_exact\tcandidate_lifecycle_policy_exact"
              "\toutput_snapshot_policy_exact\tpidfd_coordinate_observed"
              "\tpidfd_get_info_validated\tprocess_coordinate_matches"
              "\tappraiser_independent\tappraisal_reconstructible"
              "\tactor_profile_admissible\teligible_for_v13_actor_premise"
              "\tready_sent\trights_imported\tcandidate_created"
              "\tcandidate_bytes_read\tarchive_acquired\tarchive_admitted"
              "\tsource_provenance_proved\towner_authority\tliving_law"
              "\tretained_counterexample\tjudgment\n";
    for (const CaseRow& row : rows) {
        const auto& a = row.assessment;
        stream << row.name << '\t'
               << acquisition_actor_disposition_name(a.disposition) << '\t'
               << boolean(a.observation_coherent) << '\t'
               << boolean(a.executable_epoch_exact) << '\t'
               << boolean(a.launch_envelope_exact) << '\t'
               << boolean(a.privilege_boundary_exact) << '\t'
               << boolean(a.inherited_descriptor_inventory_exact) << '\t'
               << boolean(a.source_policy_exact) << '\t'
               << boolean(a.network_policy_exact) << '\t'
               << boolean(a.timeout_policy_exact) << '\t'
               << boolean(a.retry_policy_exact) << '\t'
               << boolean(a.administration_inventory_exact) << '\t'
               << boolean(a.candidate_lifecycle_policy_exact) << '\t'
               << boolean(a.output_snapshot_policy_exact) << '\t'
               << boolean(a.pidfd_coordinate_observed) << '\t'
               << boolean(a.pidfd_get_info_validated) << '\t'
               << boolean(a.process_coordinate_matches) << '\t'
               << boolean(a.appraiser_independent) << '\t'
               << boolean(a.appraisal_reconstructible) << '\t'
               << boolean(a.actor_profile_admissible) << '\t'
               << boolean(a.eligible_for_v13_actor_premise) << '\t'
               << boolean(a.ready_sent) << '\t'
               << boolean(a.rights_imported) << '\t'
               << boolean(a.candidate_created) << '\t'
               << boolean(a.candidate_bytes_read) << '\t'
               << boolean(a.archive_acquired) << '\t'
               << boolean(a.archive_admitted) << '\t'
               << boolean(a.source_provenance_proved) << '\t'
               << boolean(a.owner_authority) << '\t'
               << boolean(a.living_law) << '\t'
               << boolean(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "acquisition-actor-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open acquisition-actor-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const AcquisitionActorCampaignCounts& counts) {
    std::ofstream stream(output / "acquisition-actor-summary.json",
                         std::ios::binary);
    require(stream.good(), "open acquisition-actor-summary.json");
    stream << "{\n"
           << "  \"admissible_profiles\": " << counts.admissible_profiles << ",\n"
           << "  \"appraiser_independence_required\": true,\n"
           << "  \"archive_acquired\": false,\n"
           << "  \"archive_admitted\": false,\n"
           << "  \"candidate_bytes_read\": false,\n"
           << "  \"candidate_created\": false,\n"
           << "  \"cases\": " << counts.cases << ",\n"
           << "  \"counterexamples_reproduced\": " << counts.counterexamples << ",\n"
           << "  \"host_applicable_profiles\": " << counts.host_applicable_profiles << ",\n"
           << "  \"incoherent_observations\": " << counts.incoherent_observations << ",\n"
           << "  \"living_law\": false,\n"
           << "  \"owner_authority\": false,\n"
           << "  \"pidfd_get_info_required\": true,\n"
           << "  \"ready_sent\": false,\n"
           << "  \"retry_budget_zero_required\": true,\n"
           << "  \"rights_imported\": false,\n"
           << "  \"schema\": \"slopos.rev0903.acquisition-actor-admission-campaign.v14-corrected\",\n"
           << "  \"source_provenance_proved\": false,\n"
           << "  \"status\": \"PASS\",\n"
           << "  \"synthetic_v13_eligible_profiles\": 0,\n"
           << "  \"v15_launch_binding_required\": true\n"
           << "}\n";
}

}  // namespace

AcquisitionActorCampaignCounts run_acquisition_actor_admission_campaign(
    const std::filesystem::path& output) {
    std::vector<CaseRow> rows;
    for (const Cut& cut : kCuts) {
        add_case(rows, cut.name, prefix_observation(cut.prefix), cut.expected,
                 true, "FAIL_CLOSED_BEFORE_V13_ACTOR_PREMISE");
    }
    AcquisitionActorObservationV1 incoherent;
    incoherent.executable_descriptor_pinned = true;
    add_case(rows, "incoherent_descriptor_without_profile", incoherent,
             AcquisitionActorDisposition::observation_incoherent, true,
             "ORDERED_PREFIX_REJECTED");
    add_case(rows, "synthetic_exact_dossier", prefix_observation(kFields.size()),
             AcquisitionActorDisposition::actor_profile_admissible, false,
             "DOSSIER_ADMISSIBLE_V15_LAUNCH_BINDING_STILL_REQUIRED");

    const std::vector<CounterexampleRow> counterexamples = {
        {"pidfd_number_is_identity", "raw descriptor number as durable identity", "descriptor numbers are process-local coordinates"},
        {"pidfd_inode_is_constitution", "pidfs inode equality as actor admission", "kernel equality is not governance"},
        {"pidfd_get_info_is_continuity", "one ioctl as uninterrupted custody", "process information is an endpoint observation"},
        {"uid_zero_is_operator_authority", "ambient root as constituted office", "root is an unbounded risk premise"},
        {"digest_alone_is_launch_epoch", "executable hash as exact launch", "dependencies argv environment cwd and umask are independent"},
        {"no_new_privs_is_sandbox", "no_new_privs alone as confinement", "seccomp and capability inventory remain separate"},
        {"seccomp_mode_is_policy_digest", "seccomp presence as exact policy", "the admitted filter program must be pinned"},
        {"https_is_source_provenance", "TLS as release provenance", "digest and provenance appraisal remain downstream"},
        {"timeout_implies_no_effect", "bounded wait as proof no candidate exists", "ambiguous transfer remains uncertain and retry-free"},
        {"zero_retry_is_admin_inventory", "disabled retry as complete administration", "manual and privileged roots remain explicit"},
        {"sealed_output_is_release_identity", "write seals as origin proof", "seals establish present mutability limits only"},
        {"receiver_first_is_zero_alias", "lifecycle policy as observed alias closure", "V13 requires candidate-specific evidence"},
        {"peer_credentials_are_admission", "kernel credentials as owner policy", "credentials are observations"},
        {"same_root_appraiser_is_independent", "self-appraisal as challenge", "appraiser root must be distinct"},
        {"replay_without_challenge_is_appraisal", "reconstruction alone as adversarial review", "one exact challenge remains required"},
        {"classification_sends_ready", "pure result as side-effect authority", "V14 sends no READY and imports no rights"},
        {"classification_proves_archive", "actor admission as archive admission", "V13 and V11 remain separate cuts"},
        {"classification_constitutes_owner", "technical dossier as living law", "owner constitution remains absent"},
    };

    require(rows.size() == 28U, "actor case inventory");
    require(counterexamples.size() == 18U, "actor counterexample inventory");
    write_cases(output, rows);
    write_counterexamples(output, counterexamples);

    AcquisitionActorCampaignCounts counts;
    counts.cases = rows.size();
    counts.counterexamples = counterexamples.size();
    counts.admissible_profiles = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.actor_profile_admissible;
        }));
    counts.incoherent_observations = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return !row.assessment.observation_coherent;
        }));
    counts.host_applicable_profiles = 0U;
    require(counts.admissible_profiles == 1U, "one synthetic dossier");
    require(counts.incoherent_observations == 1U, "one incoherent row");
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
