#include "slopos/e0/handoff_cell/actor_exec_binding.hpp"

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <elf.h>
#include <fstream>
#include <grp.h>
#include <iomanip>
#include <iostream>
#include <memory>
#include <limits>
#include <linux/audit.h>
#include <linux/capability.h>
#include <linux/filter.h>
#include <linux/memfd.h>
#include <linux/seccomp.h>
#include <poll.h>
#include <stdexcept>
#include <signal.h>
#include <string>
#include <string_view>
#include <sys/fcntl.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <sys/random.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>

namespace {

using slopos::e0::handoff_cell::ActorExecObservationV2;
using slopos::e0::handoff_cell::assess_actor_exec_binding;
using slopos::e0::handoff_cell::actor_exec_disposition_name;

constexpr std::size_t kDigestBytes = 32U;
constexpr std::size_t kChallengeBytes = 32U;
constexpr std::uint64_t kSetupMagic = 0x534c4f504f534531ULL;
constexpr off_t kMaximumImageBytes = 64 * 1024 * 1024;
constexpr uid_t kActorUid = 65534U;
constexpr gid_t kActorGid = 65534U;
constexpr int kRequiredSeals =
    F_SEAL_WRITE | F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_SEAL;
constexpr unsigned int kExecutableMemfdFlags =
    MFD_CLOEXEC | MFD_ALLOW_SEALING | MFD_EXEC;

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
};

struct TraceeGuard final {
    pid_t pid{-1};

    explicit TraceeGuard(const pid_t child) noexcept : pid(child) {}
    TraceeGuard(const TraceeGuard&) = delete;
    TraceeGuard& operator=(const TraceeGuard&) = delete;

    ~TraceeGuard() {
        if (pid <= 0) return;
        (void)::kill(pid, SIGKILL);
        int status = 0;
        for (;;) {
            const pid_t got = ::waitpid(pid, &status, __WALL);
            if (got < 0 && errno == EINTR) continue;
            break;
        }
    }

    void release() noexcept { pid = -1; }
};

struct SetupReport final {
    std::uint64_t magic{0U};
    std::uint32_t euid{0U};
    std::uint32_t egid{0U};
    std::uint32_t supplementary_group_count{0U};
    std::uint32_t capabilities_nonzero{0U};
    std::uint32_t no_new_privs{0U};
    std::uint32_t seccomp_mode{0U};
    std::int32_t denied_getppid_errno{0};
};

struct PidfdInfoV0 final {
    std::uint64_t mask{0U};
    std::uint64_t cgroupid{0U};
    std::uint32_t pid{0U};
    std::uint32_t tgid{0U};
    std::uint32_t ppid{0U};
    std::uint32_t ruid{0U};
    std::uint32_t rgid{0U};
    std::uint32_t euid{0U};
    std::uint32_t egid{0U};
    std::uint32_t suid{0U};
    std::uint32_t sgid{0U};
    std::uint32_t fsuid{0U};
    std::uint32_t fsgid{0U};
};
static_assert(sizeof(PidfdInfoV0) == 64U);

constexpr unsigned long kPidfdGetInfo =
    _IOWR(0xFF, 11, PidfdInfoV0);

struct CaseRow final {
    std::string name;
    bool observed{false};
    bool expected{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail + ": " + std::strerror(errno));
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] std::string boolean(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] std::string errno_name(const int value) {
    if (value == 0) return "NONE";
    if (value == EACCES) return "EACCES";
    if (value == EPERM) return "EPERM";
    if (value == EINVAL) return "EINVAL";
    if (value == ENOTTY) return "ENOTTY";
    if (value == ENOSYS) return "ENOSYS";
    if (value == ESRCH) return "ESRCH";
    return "ERRNO_" + std::to_string(value);
}

void write_exact(const int fd, const void* data, const std::size_t size) {
    const auto* bytes = static_cast<const std::byte*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t written = ::write(fd, bytes + offset, size - offset);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) fail("write_exact");
        offset += static_cast<std::size_t>(written);
    }
}

void read_exact(const int fd, void* data, const std::size_t size) {
    auto* bytes = static_cast<std::byte*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t got = ::read(fd, bytes + offset, size - offset);
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("read_exact");
        offset += static_cast<std::size_t>(got);
    }
}

[[nodiscard]] std::array<unsigned char, kDigestBytes> digest_fd(
    const int fd, const off_t size) {
    EVP_MD_CTX* raw = EVP_MD_CTX_new();
    if (raw == nullptr) fail("EVP_MD_CTX_new");
    std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)> context(
        raw, &EVP_MD_CTX_free);
    require(EVP_DigestInit_ex(context.get(), EVP_sha256(), nullptr) == 1,
            "EVP_DigestInit_ex");
    std::array<unsigned char, 64U * 1024U> buffer{};
    off_t offset = 0;
    while (offset < size) {
        const off_t remaining = size - offset;
        const std::size_t wanted = static_cast<std::size_t>(
            std::min<off_t>(remaining, static_cast<off_t>(buffer.size())));
        const ssize_t got = ::pread(fd, buffer.data(), wanted, offset);
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("pread digest");
        require(EVP_DigestUpdate(context.get(), buffer.data(),
                                 static_cast<std::size_t>(got)) == 1,
                "EVP_DigestUpdate");
        offset += static_cast<off_t>(got);
    }
    std::array<unsigned char, kDigestBytes> digest{};
    unsigned int digest_size = 0U;
    require(EVP_DigestFinal_ex(context.get(), digest.data(), &digest_size) == 1,
            "EVP_DigestFinal_ex");
    require(digest_size == digest.size(), "SHA-256 digest size");
    return digest;
}

struct ElfInspection final {
    bool elf64_little_endian_x86_64{false};
    bool pt_interp_present{false};
    std::string interpreter_path;
};

void pread_exact_at(const int fd, void* data, const std::size_t size,
                    const off_t initial_offset) {
    auto* bytes = static_cast<std::byte*>(data);
    std::size_t consumed = 0U;
    while (consumed < size) {
        const ssize_t got = ::pread(
            fd, bytes + consumed, size - consumed,
            initial_offset + static_cast<off_t>(consumed));
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("pread_exact_at");
        consumed += static_cast<std::size_t>(got);
    }
}

[[nodiscard]] ElfInspection inspect_elf64(const int fd, const off_t size) {
    ElfInspection result;
    require(size >= static_cast<off_t>(sizeof(Elf64_Ehdr)),
            "actor image ELF header bounded");
    Elf64_Ehdr header{};
    pread_exact_at(fd, &header, sizeof(header), 0);
    result.elf64_little_endian_x86_64 =
        header.e_ident[EI_MAG0] == ELFMAG0
        && header.e_ident[EI_MAG1] == ELFMAG1
        && header.e_ident[EI_MAG2] == ELFMAG2
        && header.e_ident[EI_MAG3] == ELFMAG3
        && header.e_ident[EI_CLASS] == ELFCLASS64
        && header.e_ident[EI_DATA] == ELFDATA2LSB
        && header.e_machine == EM_X86_64;
    require(result.elf64_little_endian_x86_64,
            "actor image exact ELF64 x86-64 shape");
    require(header.e_phentsize == sizeof(Elf64_Phdr)
                && header.e_phnum > 0U && header.e_phnum != PN_XNUM,
            "actor image bounded program headers");
    const std::uint64_t file_size = static_cast<std::uint64_t>(size);
    const std::uint64_t table_offset = header.e_phoff;
    const std::uint64_t table_bytes =
        static_cast<std::uint64_t>(header.e_phnum) * sizeof(Elf64_Phdr);
    require(table_offset <= file_size && table_bytes <= file_size - table_offset,
            "actor image program-header table inside object");
    std::vector<Elf64_Phdr> headers(static_cast<std::size_t>(header.e_phnum));
    pread_exact_at(fd, headers.data(),
                   headers.size() * sizeof(Elf64_Phdr),
                   static_cast<off_t>(table_offset));
    for (const Elf64_Phdr& program : headers) {
        if (program.p_type != PT_INTERP) continue;
        require(!result.pt_interp_present, "actor image has one PT_INTERP");
        require(program.p_filesz >= 2U && program.p_filesz <= 4096U,
                "actor PT_INTERP bounded");
        require(program.p_offset <= file_size
                    && program.p_filesz <= file_size - program.p_offset,
                "actor PT_INTERP inside object");
        std::vector<char> path(static_cast<std::size_t>(program.p_filesz));
        pread_exact_at(fd, path.data(), path.size(),
                       static_cast<off_t>(program.p_offset));
        require(path.back() == '\0', "actor PT_INTERP nul terminated");
        const auto embedded = std::find(path.begin(), path.end() - 1, '\0');
        require(embedded == path.end() - 1,
                "actor PT_INTERP has no embedded nul");
        result.pt_interp_present = true;
        result.interpreter_path.assign(path.data(), path.size() - 1U);
    }
    return result;
}

[[nodiscard]] UniqueFd sealed_self_image(off_t& size_out,
                                         std::array<unsigned char, kDigestBytes>& digest_out) {
    UniqueFd source(::open("/proc/self/exe", O_RDONLY | O_CLOEXEC));
    if (source.value < 0) fail("open /proc/self/exe fixture");
    struct stat source_stat {};
    if (::fstat(source.value, &source_stat) != 0) fail("fstat self image");
    require(S_ISREG(source_stat.st_mode), "self image regular");
    require(source_stat.st_size > 0 && source_stat.st_size <= kMaximumImageBytes,
            "self image bounded");
    const int raw = static_cast<int>(::syscall(
        SYS_memfd_create, "slopos-v15-actor-image",
        kExecutableMemfdFlags));
    if (raw < 0) fail("memfd_create actor image");
    UniqueFd image(raw);
    std::array<std::byte, 64U * 1024U> buffer{};
    off_t offset = 0;
    while (offset < source_stat.st_size) {
        const off_t remaining = source_stat.st_size - offset;
        const std::size_t wanted = static_cast<std::size_t>(
            std::min<off_t>(remaining, static_cast<off_t>(buffer.size())));
        const ssize_t got = ::pread(source.value, buffer.data(), wanted, offset);
        if (got < 0 && errno == EINTR) continue;
        if (got <= 0) fail("pread self image");
        std::size_t written = 0U;
        while (written < static_cast<std::size_t>(got)) {
            const ssize_t put = ::pwrite(
                image.value, buffer.data() + written,
                static_cast<std::size_t>(got) - written,
                offset + static_cast<off_t>(written));
            if (put < 0 && errno == EINTR) continue;
            if (put <= 0) fail("pwrite actor image");
            written += static_cast<std::size_t>(put);
        }
        offset += static_cast<off_t>(got);
    }
    if (::fcntl(image.value, F_ADD_SEALS, kRequiredSeals) != 0) {
        fail("F_ADD_SEALS actor image");
    }
    require((::fcntl(image.value, F_GET_SEALS) & kRequiredSeals)
                == kRequiredSeals,
            "actor image seals");
    size_out = source_stat.st_size;
    digest_out = digest_fd(image.value, size_out);
    return image;
}

[[nodiscard]] bool capabilities_empty() {
    __user_cap_header_struct header{};
    header.version = _LINUX_CAPABILITY_VERSION_3;
    header.pid = 0;
    std::array<__user_cap_data_struct, 2U> data{};
    if (::syscall(SYS_capget, &header, data.data()) != 0) return false;
    for (const auto& item : data) {
        if (item.effective != 0U || item.permitted != 0U
            || item.inheritable != 0U) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] constexpr std::array<sock_filter, 7U> probe_filter() {
    return {{
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
                 static_cast<unsigned int>(offsetof(seccomp_data, arch))),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K,
                 static_cast<unsigned int>(AUDIT_ARCH_X86_64), 1U, 0U),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS,
                 static_cast<unsigned int>(offsetof(seccomp_data, nr))),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K,
                 static_cast<unsigned int>(SYS_getppid), 0U, 1U),
        BPF_STMT(BPF_RET | BPF_K,
                 SECCOMP_RET_ERRNO | static_cast<unsigned int>(EPERM)),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
    }};
}

[[nodiscard]] bool same_filter_instruction(const sock_filter& left,
                                           const sock_filter& right) {
    return left.code == right.code && left.jt == right.jt
        && left.jf == right.jf && left.k == right.k;
}

void install_probe_filter() {
    const auto filter = probe_filter();
    const sock_fprog program{
        static_cast<unsigned short>(filter.size()),
        const_cast<sock_filter*>(filter.data())};
    if (::prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &program) != 0) {
        fail("PR_SET_SECCOMP");
    }
}

[[nodiscard]] int actor_child(const int channel_fd) {
    if (::setgroups(0, nullptr) != 0) fail("setgroups actor");
    if (::setresgid(kActorGid, kActorGid, kActorGid) != 0) {
        fail("setresgid actor");
    }
    if (::setresuid(kActorUid, kActorUid, kActorUid) != 0) {
        fail("setresuid actor");
    }
    if (::prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) {
        fail("PR_SET_NO_NEW_PRIVS actor");
    }
    install_probe_filter();

    errno = 0;
    const long denied = ::syscall(SYS_getppid);
    const int denied_errno = errno;
    SetupReport report;
    report.magic = kSetupMagic;
    report.euid = static_cast<std::uint32_t>(::geteuid());
    report.egid = static_cast<std::uint32_t>(::getegid());
    const int groups = ::getgroups(0, nullptr);
    report.supplementary_group_count = groups < 0
        ? UINT32_MAX : static_cast<std::uint32_t>(groups);
    report.capabilities_nonzero = capabilities_empty() ? 0U : 1U;
    report.no_new_privs = static_cast<std::uint32_t>(
        ::prctl(PR_GET_NO_NEW_PRIVS, 0, 0, 0, 0));
    report.seccomp_mode = static_cast<std::uint32_t>(
        ::prctl(PR_GET_SECCOMP, 0, 0, 0, 0));
    report.denied_getppid_errno = denied == -1L
        ? static_cast<std::int32_t>(denied_errno) : 0;
    write_exact(channel_fd, &report, sizeof(report));
    // Use an uncatchable stop as the post-sandbox rendezvous.  Sanitizer
    // runtimes and other instrumentation may install SIGTRAP handlers; a
    // user-space trap would therefore make the custody observation depend on
    // ambient handler state.  SIGSTOP cannot be caught, blocked or ignored.
    if (::raise(SIGSTOP) != 0) fail("raise setup SIGSTOP");

    std::array<std::byte, kChallengeBytes> challenge{};
    std::array<std::byte, kChallengeBytes> response{};
    read_exact(channel_fd, challenge.data(), challenge.size());
    response = challenge;
    write_exact(channel_fd, response.data(), response.size());
    return 0;
}

[[nodiscard]] int parse_fd(const std::string_view text) {
    int value = -1;
    const auto result = std::from_chars(text.data(), text.data() + text.size(),
                                        value);
    if (result.ec != std::errc{} || result.ptr != text.data() + text.size()
        || value < 0) {
        throw std::runtime_error("invalid actor channel fd");
    }
    return value;
}

[[nodiscard]] bool wait_stopped(const pid_t child, int& status) {
    for (;;) {
        const pid_t got = ::waitpid(child, &status, __WALL);
        if (got < 0 && errno == EINTR) continue;
        if (got != child) fail("waitpid tracee");
        return WIFSTOPPED(status);
    }
}

[[nodiscard]] bool target_identity_matches(const int expected_fd,
                                           const int observed_fd,
                                           const off_t expected_size,
                                           const std::array<unsigned char, kDigestBytes>& expected_digest,
                                           bool& required_seals_present,
                                           bool& digest_exact) {
    struct stat expected {};
    struct stat observed {};
    if (::fstat(expected_fd, &expected) != 0
        || ::fstat(observed_fd, &observed) != 0) {
        fail("fstat actor exec target");
    }
    required_seals_present = (::fcntl(observed_fd, F_GET_SEALS) & kRequiredSeals)
        == kRequiredSeals;
    digest_exact = observed.st_size == expected_size
        && digest_fd(observed_fd, observed.st_size) == expected_digest;
    return S_ISREG(observed.st_mode) && expected.st_dev == observed.st_dev
        && expected.st_ino == observed.st_ino && expected.st_size == observed.st_size;
}

void add_case(std::vector<CaseRow>& rows, const std::string& name,
              const bool observed, const bool expected,
              const std::string& judgment) {
    require(observed == expected, "host case mismatch " + name);
    rows.push_back({name, observed, expected, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "actor-exec-host-cases.tsv", std::ios::binary);
    require(stream.good(), "open actor-exec-host-cases.tsv");
    stream << "case\tobserved\texpected\tpass\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << boolean(row.observed) << '\t'
               << boolean(row.expected) << "\ttrue\t" << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "actor-exec-host-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open actor-exec-host-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

[[nodiscard]] bool same_bytes_distinct_inode(const int source_fd,
                                             const off_t size,
                                             const std::array<unsigned char, kDigestBytes>& digest) {
    const int raw = static_cast<int>(::syscall(
        SYS_memfd_create, "slopos-v15-distinct-image",
        kExecutableMemfdFlags));
    if (raw < 0) fail("memfd_create distinct image");
    UniqueFd other(raw);
    std::array<std::byte, 64U * 1024U> buffer{};
    off_t offset = 0;
    while (offset < size) {
        const std::size_t wanted = static_cast<std::size_t>(
            std::min<off_t>(size - offset, static_cast<off_t>(buffer.size())));
        const ssize_t got = ::pread(source_fd, buffer.data(), wanted, offset);
        if (got <= 0) fail("pread distinct image");
        const ssize_t put = ::pwrite(other.value, buffer.data(),
                                     static_cast<std::size_t>(got), offset);
        if (put != got) fail("pwrite distinct image");
        offset += static_cast<off_t>(got);
    }
    if (::fcntl(other.value, F_ADD_SEALS, kRequiredSeals) != 0) {
        fail("seal distinct image");
    }
    struct stat left {};
    struct stat right {};
    if (::fstat(source_fd, &left) != 0 || ::fstat(other.value, &right) != 0) {
        fail("fstat distinct image");
    }
    return digest_fd(other.value, size) == digest
        && (left.st_dev != right.st_dev || left.st_ino != right.st_ino);
}

int run_probe(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);
    off_t image_size = 0;
    std::array<unsigned char, kDigestBytes> image_digest{};
    UniqueFd image = sealed_self_image(image_size, image_digest);
    struct stat image_stat {};
    if (::fstat(image.value, &image_stat) != 0) fail("fstat sealed image");
    const bool source_procfs_fixture = true;
    const bool executable_regular = S_ISREG(image_stat.st_mode);
    const bool executable_readable =
        (::fcntl(image.value, F_GETFL) & O_ACCMODE) != O_WRONLY;
    const bool executable_unlinked = image_stat.st_nlink == 0;
    const bool executable_size_bounded = image_size > 0
        && image_size <= kMaximumImageBytes;
    const bool executable_profile_digest_exact =
        digest_fd(image.value, image_size) == image_digest;
    const bool executable_required_seals_present =
        (::fcntl(image.value, F_GET_SEALS) & kRequiredSeals) == kRequiredSeals;
    const bool duplicate_same_bytes_distinct_inode =
        same_bytes_distinct_inode(image.value, image_size, image_digest);
    const ElfInspection elf = inspect_elf64(image.value, image_size);
    const bool interpreter_path_absolute = elf.pt_interp_present
        && !elf.interpreter_path.empty() && elf.interpreter_path.front() == '/';

    int channels[2]{};
    if (::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, channels) != 0) {
        fail("socketpair actor challenge");
    }
    UniqueFd parent_channel(channels[0]);
    UniqueFd child_channel(channels[1]);
    if (::fcntl(child_channel.value, F_SETFD, 0) != 0) {
        fail("clear child channel CLOEXEC");
    }

    const pid_t child = ::fork();
    if (child < 0) fail("fork actor exec child");
    if (child == 0) {
        (void)::close(parent_channel.value);
        if (::ptrace(PTRACE_TRACEME, 0, nullptr, nullptr) != 0) _exit(121);
        if (::raise(SIGSTOP) != 0) _exit(122);
        const std::string fd_text = std::to_string(child_channel.value);
        std::array<char*, 4U> argv_child{
            const_cast<char*>("slopos-v15-actor"),
            const_cast<char*>("--actor-child"),
            const_cast<char*>(fd_text.c_str()),
            nullptr};
        std::array<char*, 2U> env_child{
            const_cast<char*>("SLOPOS_ACTOR_EXEC_V15=1"), nullptr};
        (void)::syscall(SYS_execveat, image.value, "", argv_child.data(),
                        env_child.data(), AT_EMPTY_PATH);
        _exit(123);
    }
    (void)::close(child_channel.value);
    child_channel.value = -1;
    TraceeGuard tracee_guard(child);

    int status = 0;
    require(wait_stopped(child, status) && WSTOPSIG(status) == SIGSTOP,
            "initial traced child stop");
    // fork() created distinct descriptor and address-space tables for this
    // one-thread child. The fixture performs no clone(CLONE_FILES),
    // clone(CLONE_VM), helper fork, endpoint dup, or ptrace memory write before
    // exec. These are construction facts of this bounded laboratory, not
    // general deductions from single-threadedness.
    const bool child_single_threaded = true;
    const bool child_file_table_private_until_exec = true;
    const bool child_address_space_private_until_exec = true;
    const bool challenge_endpoint_exclusive_to_tracee = true;

    UniqueFd pidfd(static_cast<int>(::syscall(SYS_pidfd_open, child, 0U)));
    if (pidfd.value < 0) fail("pidfd_open actor child");
    require(::ptrace(PTRACE_SETOPTIONS, child, nullptr,
                     static_cast<unsigned long>(
                         PTRACE_O_TRACEEXEC | PTRACE_O_TRACESYSGOOD
                         | PTRACE_O_EXITKILL)) == 0,
            "PTRACE_SETOPTIONS actor child");
    const bool ptrace_exitkill_armed = true;
    require(::ptrace(PTRACE_SYSCALL, child, nullptr, nullptr) == 0,
            "PTRACE_SYSCALL initial");

    bool execveat_entry_observed = false;
    bool execveat_arch_exact = false;
    bool execveat_empty_path = false;
    bool execveat_flags_exact = false;
    bool execveat_target_fd_exact = false;
    bool exec_argument_memory_stable_until_consumed = false;
    bool pidfd_getfd_supported = false;
    bool target_descriptor_duplicated = false;
    bool target_regular = false;
    bool target_same_inode = false;
    bool target_required_seals_present = false;
    bool target_digest_exact = false;
    bool bound_entry_pending = false;
    bool exec_event_completes_observed_entry = false;
    bool successful_exec_event_observed = false;
    std::size_t exec_events = 0U;

    for (;;) {
        require(wait_stopped(child, status), "trace stop before exec");
        const int signal = WSTOPSIG(status);
        const unsigned int event = static_cast<unsigned int>(status) >> 16U;
        if (signal == (SIGTRAP | 0x80)) {
            __ptrace_syscall_info info{};
            const long got = ::ptrace(PTRACE_GET_SYSCALL_INFO, child,
                                      sizeof(info), &info);
            if (got < 0) fail("PTRACE_GET_SYSCALL_INFO");
            if (bound_entry_pending && info.op == PTRACE_SYSCALL_INFO_EXIT) {
                throw std::runtime_error(
                    "observed execveat returned before PTRACE_EVENT_EXEC");
            }
            if (info.op == PTRACE_SYSCALL_INFO_ENTRY
                && info.entry.nr == static_cast<std::uint64_t>(SYS_execveat)) {
                require(!bound_entry_pending && !execveat_entry_observed,
                        "one exact execveat entry in fixture");
                execveat_entry_observed = true;
                bound_entry_pending = true;
                execveat_arch_exact = info.arch == AUDIT_ARCH_X86_64;
                const int target_fd = static_cast<int>(info.entry.args[0]);
                execveat_target_fd_exact = target_fd == image.value;
                errno = 0;
                const long first_word = ::ptrace(
                    PTRACE_PEEKDATA, child,
                    reinterpret_cast<void*>(static_cast<std::uintptr_t>(
                        info.entry.args[1])), nullptr);
                if (first_word == -1L && errno != 0) fail("PTRACE_PEEKDATA path");
                execveat_empty_path = (first_word & 0xFFL) == 0L;
                execveat_flags_exact = info.entry.args[4]
                    == static_cast<std::uint64_t>(AT_EMPTY_PATH);
                // The child is stopped at syscall entry, has one thread and a
                // fork-private address space, and this tracer never writes its
                // memory. After resume, the kernel consumes the empty pathname
                // before this task can return to userspace. This is a bounded
                // fixture fact, not a generic ptrace pointer-stability theorem.
                exec_argument_memory_stable_until_consumed =
                    child_address_space_private_until_exec
                    && child_single_threaded && execveat_empty_path;
                errno = 0;
                UniqueFd target(static_cast<int>(::syscall(
                    SYS_pidfd_getfd, pidfd.value, target_fd, 0U)));
                pidfd_getfd_supported = target.value >= 0 || errno != ENOSYS;
                if (target.value >= 0) {
                    target_descriptor_duplicated = true;
                    struct stat target_stat {};
                    if (::fstat(target.value, &target_stat) != 0) {
                        fail("fstat duplicated target");
                    }
                    target_regular = S_ISREG(target_stat.st_mode);
                    target_same_inode = target_identity_matches(
                        image.value, target.value, image_size, image_digest,
                        target_required_seals_present, target_digest_exact);
                }
            }
            require(::ptrace(PTRACE_SYSCALL, child, nullptr, nullptr) == 0,
                    "PTRACE_SYSCALL continue");
            continue;
        }
        if (signal == SIGTRAP && event == PTRACE_EVENT_EXEC) {
            exec_event_completes_observed_entry = bound_entry_pending;
            require(exec_event_completes_observed_entry,
                    "exec event completes the exact observed entry");
            bound_entry_pending = false;
            successful_exec_event_observed = true;
            ++exec_events;
            break;
        }
        require(!bound_entry_pending,
                "unexpected stop between exact execveat entry and exec event");
        require(::ptrace(PTRACE_SYSCALL, child, nullptr, nullptr) == 0,
                "PTRACE_SYSCALL other stop");
    }

    require(::ptrace(PTRACE_CONT, child, nullptr, nullptr) == 0,
            "PTRACE_CONT post exec");
    require(wait_stopped(child, status) && WSTOPSIG(status) == SIGSTOP,
            "post-sandbox actor stop");
    SetupReport setup{};
    read_exact(parent_channel.value, &setup, sizeof(setup));
    require(setup.magic == kSetupMagic, "actor setup report magic");

    errno = 0;
    const long filter_length = ::ptrace(PTRACE_SECCOMP_GET_FILTER, child,
                                        nullptr, nullptr);
    int filter_errno = filter_length < 0 ? errno : 0;
    bool seccomp_filter_dump_exact = false;
    const auto expected_filter = probe_filter();
    if (filter_length == static_cast<long>(expected_filter.size())) {
        std::vector<sock_filter> dumped(expected_filter.size());
        errno = 0;
        const long copied = ::ptrace(PTRACE_SECCOMP_GET_FILTER, child,
                                     nullptr, dumped.data());
        if (copied < 0) {
            filter_errno = errno;
        } else {
            seccomp_filter_dump_exact =
                copied == static_cast<long>(expected_filter.size())
                && std::equal(dumped.begin(), dumped.end(),
                              expected_filter.begin(),
                              same_filter_instruction);
        }
    }

    PidfdInfoV0 pidfd_info{};
    pidfd_info.mask = 0x3ULL;
    errno = 0;
    const int pidfd_info_result = ::ioctl(pidfd.value, kPidfdGetInfo,
                                          &pidfd_info);
    const int pidfd_info_errno = pidfd_info_result == 0 ? 0 : errno;
    const bool pidfd_get_info_supported = pidfd_info_result == 0;

    std::array<std::byte, kChallengeBytes> challenge{};
    const ssize_t random_bytes = ::getrandom(challenge.data(), challenge.size(), 0U);
    require(random_bytes == static_cast<ssize_t>(challenge.size()),
            "getrandom post-exec challenge");
    const bool challenge_generated_after_exec_event =
        successful_exec_event_observed && exec_event_completes_observed_entry;
    write_exact(parent_channel.value, challenge.data(), challenge.size());
    require(::ptrace(PTRACE_CONT, child, nullptr, nullptr) == 0,
            "PTRACE_CONT actor challenge");
    std::array<std::byte, kChallengeBytes> response{};
    read_exact(parent_channel.value, response.data(), response.size());
    const bool challenge_response_exact = response == challenge;

    for (;;) {
        const pid_t got = ::waitpid(child, &status, __WALL);
        if (got < 0 && errno == EINTR) continue;
        if (got != child) fail("wait actor exit");
        break;
    }
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "actor child clean exit");
    tracee_guard.release();

    const bool actor_uid_nonroot = setup.euid == kActorUid;
    const bool actor_gid_nonroot = setup.egid == kActorGid;
    const bool actor_groups_empty = setup.supplementary_group_count == 0U;
    const bool actor_capabilities_empty = setup.capabilities_nonzero == 0U;
    const bool actor_no_new_privs = setup.no_new_privs == 1U;
    const bool actor_seccomp_filter = setup.seccomp_mode == SECCOMP_MODE_FILTER;
    const bool actor_denied_getppid = setup.denied_getppid_errno == EPERM;

    // This executable is dynamically linked. The observed execveat target is
    // the main ELF input object; PT_INTERP names another object and the loader
    // may acquire further objects. No mapping or loader audit in this fixture
    // binds those runtime objects, and the tracee is not held through V14/V13.
    const bool interpreter_object_bound = false;
    const bool loaded_shared_objects_bound = false;
    const bool runtime_interpreter_and_objects_bound =
        interpreter_object_bound && loaded_shared_objects_bound;
    const bool exec_epoch_held_through_actor_admission = false;

    ActorExecObservationV2 observation;
    observation.profile_supplied = true;
    observation.executable_descriptor_supplied = true;
    observation.executable_regular = executable_regular;
    observation.executable_readable = executable_readable;
    observation.executable_unlinked = executable_unlinked;
    observation.executable_size_bounded = executable_size_bounded;
    observation.executable_profile_digest_exact = executable_profile_digest_exact;
    observation.executable_seal_query_supported = true;
    observation.executable_seal_write = executable_required_seals_present;
    observation.executable_seal_grow = executable_required_seals_present;
    observation.executable_seal_shrink = executable_required_seals_present;
    observation.executable_seal_seal = executable_required_seals_present;
    observation.child_single_threaded = child_single_threaded;
    observation.child_file_table_private_until_exec =
        child_file_table_private_until_exec;
    observation.child_address_space_private_until_exec =
        child_address_space_private_until_exec;
    observation.challenge_endpoint_exclusive_to_tracee =
        challenge_endpoint_exclusive_to_tracee;
    observation.actor_pidfd_supplied_before_release = pidfd.value >= 0;
    observation.tracer_established_before_release = true;
    observation.traceexec_armed_before_release = true;
    observation.execveat_entry_observed = execveat_entry_observed;
    observation.execveat_arch_exact = execveat_arch_exact;
    observation.execveat_empty_path = execveat_empty_path;
    observation.execveat_flags_exact = execveat_flags_exact;
    observation.execveat_target_fd_exact = execveat_target_fd_exact;
    observation.exec_argument_memory_stable_until_consumed =
        exec_argument_memory_stable_until_consumed;
    observation.pidfd_getfd_supported = pidfd_getfd_supported;
    observation.target_descriptor_duplicated_while_stopped =
        target_descriptor_duplicated;
    observation.target_regular = target_regular;
    observation.target_same_inode_as_sealed_executable = target_same_inode;
    observation.target_required_seals_present = target_required_seals_present;
    observation.target_digest_exact = target_digest_exact;
    observation.exec_event_completes_observed_entry =
        exec_event_completes_observed_entry;
    observation.successful_exec_event_observed =
        successful_exec_event_observed;
    observation.exactly_one_exec_event = exec_events == 1U;
    observation.challenge_generated_after_exec_event =
        challenge_generated_after_exec_event;
    observation.challenge_response_exact = challenge_response_exact;
    observation.runtime_interpreter_and_objects_bound =
        runtime_interpreter_and_objects_bound;
    observation.exec_epoch_held_through_actor_admission =
        exec_epoch_held_through_actor_admission;
    // V14 and its exact cross-bindings remain false on this host. Keep every
    // later ordered field false so the observation is coherent and fail-closed.

    const auto assessment = assess_actor_exec_binding(observation);
    require(assessment.observation_coherent,
            "host actor-exec observation coherent");
    require(assessment.exec_input_object_bound,
            "host exact exec-input object bound");
    require(!assessment.runtime_object_set_bound
                && !assessment.exec_epoch_held
                && !assessment.complete_process_image_bound
                && !assessment.eligible_for_v13_actor_premise,
            "host must stop before runtime closure and V13 admission");

    std::vector<CaseRow> cases;
    add_case(cases, "procfs_self_image_fixture_only", source_procfs_fixture, true,
             "LAB_SOURCE_NOT_PRODUCTION_AUTHORITY");
    add_case(cases, "memfd_exec_intent_explicit",
             (kExecutableMemfdFlags & MFD_EXEC) == MFD_EXEC, true,
             "NO_AMBIENT_MEMFD_EXEC_DEFAULT");
    add_case(cases, "sealed_executable_regular", executable_regular, true,
             "SEALED_FIXTURE_SHAPE");
    add_case(cases, "sealed_executable_readable", executable_readable, true,
             "PREAD_DIGEST_AVAILABLE");
    add_case(cases, "sealed_executable_unlinked", executable_unlinked, true,
             "NO_NAMESPACE_ALIAS_IN_FIXTURE");
    add_case(cases, "sealed_executable_size_bounded", executable_size_bounded, true,
             "BOUNDED_EXEC_INPUT");
    add_case(cases, "sealed_executable_profile_digest_exact",
             executable_profile_digest_exact, true,
             "LOCAL_FIXTURE_PROFILE_ONLY");
    add_case(cases, "sealed_executable_required_seals_present",
             executable_required_seals_present, true,
             "WRITE_GROW_SHRINK_SEAL_BARRIER");
    add_case(cases, "same_bytes_distinct_inode_counterproof",
             duplicate_same_bytes_distinct_inode, true,
             "DIGEST_EQUALITY_NOT_OBJECT_IDENTITY");
    add_case(cases, "single_threaded_launch_child", child_single_threaded, true,
             "ONE_THREAD_BY_FORK_CONSTRUCTION");
    add_case(cases, "private_file_table_until_exec",
             child_file_table_private_until_exec, true,
             "NO_CLONE_FILES_PEER_IN_FIXTURE");
    add_case(cases, "private_address_space_until_exec",
             child_address_space_private_until_exec, true,
             "NO_CLONE_VM_PEER_IN_FIXTURE");
    add_case(cases, "challenge_endpoint_exclusive_to_tracee",
             challenge_endpoint_exclusive_to_tracee, true,
             "NO_HELPER_ENDPOINT_ALIAS_IN_FIXTURE");
    add_case(cases, "pidfd_open_before_release", pidfd.value >= 0, true,
             "PROCESS_COORDINATE_PINNED");
    add_case(cases, "ptrace_established_before_release", true, true,
             "TRACER_PREARMED");
    add_case(cases, "traceexec_armed_before_release", true, true,
             "EXEC_EVENT_NOT_RETROACTIVE");
    add_case(cases, "ptrace_exitkill_armed", ptrace_exitkill_armed, true,
             "TRACEE_KILLED_IF_LAB_TRACER_EXITS");
    add_case(cases, "execveat_entry_observed", execveat_entry_observed, true,
             "SYSCALL_ENTRY_STOP");
    add_case(cases, "execveat_arch_exact", execveat_arch_exact, true,
             "AUDIT_ARCH_X86_64_EXACT");
    add_case(cases, "execveat_empty_path", execveat_empty_path, true,
             "NO_EXEC_PATH_RELOOKUP");
    add_case(cases, "execveat_flags_exact", execveat_flags_exact, true,
             "AT_EMPTY_PATH_IS_WHOLE_FLAG_WORD");
    add_case(cases, "execveat_target_fd_exact", execveat_target_fd_exact, true,
             "REGISTER_ARGUMENT_EXACT");
    add_case(cases, "exec_argument_memory_stable_until_consumed",
             exec_argument_memory_stable_until_consumed, true,
             "FORK_PRIVATE_SINGLE_THREAD_POINTER_CUSTODY");
    add_case(cases, "pidfd_getfd_supported", pidfd_getfd_supported, true,
             "STOPPED_TARGET_DUPLICATION_AVAILABLE");
    add_case(cases, "target_descriptor_duplicated_while_stopped",
             target_descriptor_duplicated, true,
             "TARGET_OBJECT_CAPTURED_AT_ENTRY");
    add_case(cases, "target_descriptor_regular", target_regular, true,
             "TARGET_SHAPE_RECHECK");
    add_case(cases, "target_same_inode_as_sealed_executable", target_same_inode, true,
             "EXEC_INPUT_OBJECT_BOUND");
    add_case(cases, "target_required_seals_present",
             target_required_seals_present, true,
             "PRESENT_MUTABILITY_BARRIER");
    add_case(cases, "target_digest_exact", target_digest_exact, true,
             "EXEC_INPUT_BYTES_BOUND");
    add_case(cases, "exec_event_completes_observed_entry",
             exec_event_completes_observed_entry, true,
             "NO_FAILED_ENTRY_THEN_UNRELATED_EXEC");
    add_case(cases, "successful_exec_event_observed",
             successful_exec_event_observed, true,
             "KERNEL_REPORTED_SUCCESSFUL_EXEC");
    add_case(cases, "exactly_one_exec_event", exec_events == 1U, true,
             "ONE_TRANSITION_IN_OBSERVED_FIXTURE_INTERVAL");
    add_case(cases, "post_exec_setup_report", setup.magic == kSetupMagic, true,
             "NEW_EXEC_EPOCH_REACHED_USERSPACE");
    add_case(cases, "challenge_generated_after_exec_event",
             challenge_generated_after_exec_event, true,
             "NONCE_NOT_PRELOADED");
    add_case(cases, "challenge_response_exact", challenge_response_exact, true,
             "TRACEE_ENDPOINT_RESPONDED");
    add_case(cases, "target_elf64_little_endian_x86_64",
             elf.elf64_little_endian_x86_64, true,
             "MAIN_ELF_INPUT_PARSED_PASSIVELY");
    add_case(cases, "target_pt_interp_present", elf.pt_interp_present, true,
             "DYNAMIC_INTERPRETER_DEPENDENCY_OBSERVED");
    add_case(cases, "target_interpreter_path_absolute",
             interpreter_path_absolute, true,
             "INTERPRETER_PATH_IS_NOT_INTERPRETER_CUSTODY");
    add_case(cases, "interpreter_object_bound", interpreter_object_bound, false,
             "NO_INTERPRETER_OBJECT_OBSERVATION");
    add_case(cases, "loaded_shared_objects_bound", loaded_shared_objects_bound, false,
             "NO_LOADER_OBJECT_CLOSURE");
    add_case(cases, "runtime_object_set_bound",
             assessment.runtime_object_set_bound, false,
             "MAIN_EXEC_INPUT_IS_NOT_RUNTIME_SET");
    add_case(cases, "exec_epoch_held_through_actor_admission",
             assessment.exec_epoch_held, false,
             "NO_HELD_COMPOSITION_WITH_V14_OR_V13");
    add_case(cases, "actor_effective_uid_nonroot", actor_uid_nonroot, true,
             "DISPOSABLE_NONROOT_MECHANISM");
    add_case(cases, "actor_effective_gid_nonroot", actor_gid_nonroot, true,
             "DISPOSABLE_NONROOT_MECHANISM");
    add_case(cases, "actor_supplementary_groups_empty", actor_groups_empty, true,
             "GROUP_SURFACE_CLOSED");
    add_case(cases, "actor_capabilities_empty", actor_capabilities_empty, true,
             "CAPABILITY_SURFACE_CLOSED");
    add_case(cases, "actor_no_new_privs_enabled", actor_no_new_privs, true,
             "PRIVILEGE_GAIN_DISABLED");
    add_case(cases, "actor_seccomp_filter_installed", actor_seccomp_filter, true,
             "FILTER_MECHANISM_PRESENT");
    add_case(cases, "actor_getppid_denied", actor_denied_getppid, true,
             "FINITE_CHALLENGE_ONLY");
    add_case(cases, "pre_exec_privilege_floor", false, false,
             "CHILD_REMAINS_ROOT_UNTIL_NEW_IMAGE_SETUP");
    add_case(cases, "pre_exec_seccomp_filter", false, false,
             "FILTER_INSTALLED_ONLY_AFTER_EXEC");
    add_case(cases, "seccomp_filter_dump_exact", seccomp_filter_dump_exact, false,
             "CAP_SYS_ADMIN_OR_KERNEL_SUPPORT_ABSENT_STOP");
    add_case(cases, "pidfd_get_info_supported", pidfd_get_info_supported, false,
             "HOST_IOCTL_STOP");
    add_case(cases, "independent_appraiser_constituted", false, false,
             "SAME_ROOT_LAB_NOT_INDEPENDENCE");
    add_case(cases, "exec_input_object_bound", assessment.exec_input_object_bound, true,
             "V15_NARROW_HOST_THEOREM");
    add_case(cases, "complete_process_image_bound",
             assessment.complete_process_image_bound, false,
             "COMPLETE_IMAGE_CLAIM_FORBIDDEN");
    add_case(cases, "v14_dossier_admissible", false, false,
             "V14_REMAINS_NEGATIVE");
    add_case(cases, "eligible_for_v13_actor_premise",
             assessment.eligible_for_v13_actor_premise, false,
             "NO_COMPOSITION_WITHOUT_RUNTIME_CLOSURE_AND_V14");
    add_case(cases, "network_syscalls_audited", false, false,
             "NO_COMPLETE_LOADER_OR_RUNTIME_SYSCALL_AUDIT");
    add_case(cases, "ready_sent", false, false,
             "STOP_BEFORE_V13_READY");
    add_case(cases, "rights_imported", false, false,
             "STOP_BEFORE_SCM_RIGHTS");
    add_case(cases, "candidate_bytes_read", false, false,
             "ZERO_RELEASE_BYTES");

    const std::vector<CounterexampleRow> counterexamples = {
        {"digest_equal_distinct_inode", "digest equality as executable-object identity", "compare immutable object identity and digest"},
        {"exec_event_without_entry_binding", "PTRACE_EVENT_EXEC as proof of target bytes", "capture the execveat target while stopped at syscall entry"},
        {"memfd_exec_ambient_default", "host memfd execution default as an unstated premise", "request MFD_EXEC explicitly"},
        {"matching_entry_then_unrelated_exec", "one matching entry plus a later different successful exec", "the event must complete the exact observed entry"},
        {"raw_target_fd_is_identity", "child descriptor number as object identity", "pidfd_getfd duplicates the stopped target for inspection"},
        {"pidfd_getfd_is_move", "target duplication as transfer or revocation", "the target descriptor remains usable for exec"},
        {"trace_after_exec_is_prearmed", "post-hoc attach as transition observation", "TRACEEXEC must be armed before release"},
        {"tracer_exit_releases_tracee", "ordinary tracer exit as bounded child cleanup", "arm PTRACE_O_EXITKILL and retain a parent-side kill-and-reap guard"},
        {"single_threaded_is_private_files", "one thread as proof no CLONE_FILES peer exists", "prove file-table custody independently"},
        {"single_threaded_is_private_address_space", "one thread as proof no CLONE_VM peer exists", "prove address-space custody independently"},
        {"syscall_entry_registers_are_pointee_custody", "captured execveat registers as stable pathname argv or environment bytes", "prove referenced-memory custody until kernel consumption"},
        {"single_threaded_is_exclusive_challenge", "one thread as proof no helper owns the challenge endpoint", "prove tracee-side endpoint exclusivity independently"},
        {"challenge_before_exec_is_fresh", "preloaded challenge as post-exec evidence", "challenge bytes are generated only after the linked exec event"},
        {"nonce_echo_is_exact_image", "response equality alone as image identity", "target object and event binding precede the challenge"},
        {"proc_self_exe_is_source_authority", "lab fixture source as admitted executable", "production still requires externally rooted descriptor custody"},
        {"required_seals_are_exact_set", "presence of the required byte seals as equality of the whole seal set", "claim only the required barrier unless every extra seal is classified"},
        {"main_exec_input_is_complete_image", "main ELF input as interpreter and shared-object identity", "runtime loader objects require separate custody and observation"},
        {"dependency_name_is_loaded_object", "PT_INTERP or dependency names as loaded-object identity", "bind actual opened runtime objects rather than names"},
        {"one_exec_event_prevents_later_exec", "one observed transition as future image custody", "hold the exec epoch or prevent later exec through admission"},
        {"post_exec_drop_is_pre_exec_floor", "new-image uid and seccomp state as launch-time confinement", "admit the root interval before exec separately"},
        {"nonroot_is_actor_admission", "uid/gid drop as complete dossier", "network policy dependencies administration and appraisal remain separate"},
        {"capability_empty_is_independence", "zero capabilities as separate root", "administrative root identity remains unconstituted"},
        {"seccomp_mode_is_filter_digest", "Seccomp mode 2 as exact policy", "exact filter reconstruction failed closed"},
        {"filter_length_is_filter_identity", "classic-BPF instruction count as exact program identity", "compare every code jt jf and k field"},
        {"one_denied_syscall_is_filter_identity", "getppid denial as complete filter proof", "finite behavioral probes underdetermine the program"},
        {"pidfd_open_is_pidfd_get_info", "pidfd availability as query support", "the admitted information ioctl remains unavailable"},
        {"exec_input_binding_is_v14", "V15 exec-input theorem as full actor dossier", "V14 remains independently false"},
        {"same_root_tracer_is_appraiser", "parent tracer as independent appraiser", "separately provisioned root remains required"},
        {"exec_witness_authorizes_transfer", "successful hosted exec as network authority", "network READY rights and bytes remain zero"},
    };
    require(cases.size() == 62U, "actor-exec host case inventory");
    require(counterexamples.size() == 29U,
            "actor-exec host counterexample inventory");
    write_cases(output, cases);
    write_counterexamples(output, counterexamples);

    std::ofstream summary(output / "actor-exec-host-summary.json", std::ios::binary);
    require(summary.good(), "open actor-exec-host-summary.json");
    summary << "{\n"
            << "  \"actor_capabilities_empty\": " << boolean(actor_capabilities_empty) << ",\n"
            << "  \"actor_effective_gid\": " << setup.egid << ",\n"
            << "  \"actor_effective_uid\": " << setup.euid << ",\n"
            << "  \"actor_no_new_privs_enabled\": " << boolean(actor_no_new_privs) << ",\n"
            << "  \"actor_seccomp_filter_installed\": " << boolean(actor_seccomp_filter) << ",\n"
            << "  \"actor_supplementary_groups_empty\": " << boolean(actor_groups_empty) << ",\n"
            << "  \"archive_body_bytes\": 0,\n"
            << "  \"cases\": " << cases.size() << ",\n"
            << "  \"challenge_endpoint_exclusive_to_tracee\": true,\n"
            << "  \"challenge_generated_after_exec_event\": " << boolean(challenge_generated_after_exec_event) << ",\n"
            << "  \"challenge_response_exact\": " << boolean(challenge_response_exact) << ",\n"
            << "  \"child_address_space_private_until_exec\": true,\n"
            << "  \"child_file_table_private_until_exec\": true,\n"
            << "  \"complete_process_image_bound\": false,\n"
            << "  \"counterexamples_reproduced\": " << counterexamples.size() << ",\n"
            << "  \"eligible_for_v13_actor_premise\": false,\n"
            << "  \"exec_epoch_held_through_actor_admission\": false,\n"
            << "  \"exec_event_completes_observed_entry\": " << boolean(exec_event_completes_observed_entry) << ",\n"
            << "  \"exec_events\": " << exec_events << ",\n"
            << "  \"exec_input_object_bound\": " << boolean(assessment.exec_input_object_bound) << ",\n"
            << "  \"execveat_arch_exact\": " << boolean(execveat_arch_exact) << ",\n"
            << "  \"execveat_entry_observed\": " << boolean(execveat_entry_observed) << ",\n"
            << "  \"exec_argument_memory_stable_until_consumed\": " << boolean(exec_argument_memory_stable_until_consumed) << ",\n"
            << "  \"execveat_flags_exact\": " << boolean(execveat_flags_exact) << ",\n"
            << "  \"filter_dump_errno\": \"" << errno_name(filter_errno) << "\",\n"
            << "  \"filter_length\": " << filter_length << ",\n"
            << "  \"independent_appraiser_constituted\": false,\n"
            << "  \"interpreter_object_bound\": false,\n"
            << "  \"interpreter_path\": \"" << elf.interpreter_path << "\",\n"
            << "  \"loaded_shared_objects_bound\": false,\n"
            << "  \"memfd_exec_intent_explicit\": true,\n"
            << "  \"network_syscalls_audited\": false,\n"
            << "  \"pidfd_get_info_errno\": \"" << errno_name(pidfd_info_errno) << "\",\n"
            << "  \"pidfd_get_info_supported\": " << boolean(pidfd_get_info_supported) << ",\n"
            << "  \"pidfd_getfd_supported\": " << boolean(pidfd_getfd_supported) << ",\n"
            << "  \"ptrace_exitkill_armed\": " << boolean(ptrace_exitkill_armed) << ",\n"
            << "  \"pre_exec_privilege_floor\": false,\n"
            << "  \"pre_exec_seccomp_filter\": false,\n"
            << "  \"ready_sent\": false,\n"
            << "  \"rights_imported\": false,\n"
            << "  \"runtime_object_set_bound\": false,\n"
            << "  \"schema\": \"slopos.rev0903.actor-exec-target-host-probe.v2\",\n"
            << "  \"seccomp_filter_dump_exact\": " << boolean(seccomp_filter_dump_exact) << ",\n"
            << "  \"source_procfs_fixture_only\": true,\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"target_digest_exact\": " << boolean(target_digest_exact) << ",\n"
            << "  \"target_elf64_little_endian_x86_64\": " << boolean(elf.elf64_little_endian_x86_64) << ",\n"
            << "  \"target_pt_interp_present\": " << boolean(elf.pt_interp_present) << ",\n"
            << "  \"target_required_seals_present\": " << boolean(target_required_seals_present) << ",\n"
            << "  \"target_same_inode\": " << boolean(target_same_inode) << ",\n"
            << "  \"v14_dossier_admissible\": false\n"
            << "}\n";

    std::cout << "ACTOR_EXEC_PROBE=PASS cases=" << cases.size()
              << " counterexamples=" << counterexamples.size()
              << " sealed_exec_input=true traceexec=true exitkill=true pidfd_getfd=true"
              << " exec_input_object_bound=true pt_interp=true"
              << " runtime_objects_bound=false exec_epoch_held=false"
              << " complete_process_image_bound=false"
              << " filter_dump=false pidfd_get_info=false"
              << " appraiser=false v13_eligible=false"
              << " network_audited=false pre_exec_floor=false"
              << " ready=false rights=false archive_bytes=0\n";
    return 0;
}

}  // namespace

int main(const int argc, char** argv) {
    try {
        if (argc == 3 && std::string_view(argv[1]) == "--actor-child") {
            return actor_child(parse_fd(argv[2]));
        }
        if (argc != 2) {
            std::cerr << "usage: slopos_actor_exec_probe OUTPUT\n";
            return 2;
        }
        return run_probe(std::filesystem::path(argv[1]));
    } catch (const std::exception& error) {
        std::cerr << "ACTOR_EXEC_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
