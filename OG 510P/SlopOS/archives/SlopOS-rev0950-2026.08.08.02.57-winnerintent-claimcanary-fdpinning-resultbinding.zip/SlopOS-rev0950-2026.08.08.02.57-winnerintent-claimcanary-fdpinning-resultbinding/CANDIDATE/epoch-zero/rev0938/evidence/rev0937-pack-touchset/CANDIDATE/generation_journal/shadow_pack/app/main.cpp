#include "slopos/e0/generation_journal/shadow_pack/pack.hpp"

#include <iostream>
#include <stdexcept>
#include <string_view>

namespace shadow = slopos::e0::generation_journal::shadow_pack;

namespace {
void print_summary(std::string_view operation, const shadow::Summary& summary) {
  std::cout << "SHADOW_PACK=PASS operation=" << operation
            << " entries=" << summary.entries
            << " blobs=" << summary.blobs
            << " logical_bytes=" << summary.logical_bytes
            << " pack_bytes=" << summary.pack_bytes
            << " manifest_sha256=" << summary.manifest_sha256
            << " profile=rooted-v2 descriptor_rooted=true complete_before_visible=true authority=false destructive=false\n";
}
}  // namespace

int main(int argc, char** argv) {
  try {
    if (argc == 5 && std::string_view(argv[1]) == "pack") {
      print_summary("pack", shadow::pack_exact_subject(argv[2], argv[3], argv[4]));
      return 0;
    }
    if (argc == 4 && std::string_view(argv[1]) == "verify") {
      print_summary("verify", shadow::verify_exact_subject(argv[2], argv[3]));
      return 0;
    }
    if (argc == 5 && std::string_view(argv[1]) == "unpack") {
      print_summary("unpack", shadow::unpack_exact_subject(argv[2], argv[3], argv[4]));
      return 0;
    }
    std::cerr << "usage: " << argv[0]
              << " pack SOURCE_ROOT SUBJECT.tsv ABSENT_PACK | verify PACK SUBJECT.tsv | "
                 "unpack PACK SUBJECT.tsv ABSENT_DESTINATION\n";
    return 64;
  } catch (const std::exception& error) {
    std::cerr << "SHADOW_PACK=FAIL detail=" << error.what() << "\n";
    return 1;
  }
}
