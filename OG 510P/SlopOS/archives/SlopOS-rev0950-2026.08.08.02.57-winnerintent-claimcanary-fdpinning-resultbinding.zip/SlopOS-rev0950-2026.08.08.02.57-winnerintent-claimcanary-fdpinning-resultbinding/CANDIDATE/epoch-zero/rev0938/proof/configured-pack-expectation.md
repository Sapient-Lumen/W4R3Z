# Configured pack expectation: the non-self-selection cut

**Revision:** rev0938  
**Epoch decision:** remain in Epoch Zero  
**Construction:** `include/`, `src/`, and `tests/` in this directory

## The defect

A candidate producer that supplies both bytes `C` and the only expected identity
`H(C)` has not been checked against an expectation; it has merely described itself.
The predicate `digest(C) == producer_supplied_digest` is tautological whenever the
producer computes the argument after choosing `C`. Earlier vault work (notably the
rev0862 self-pinning law) already contained this result, but the live pack leaf still
allowed the pack producer to select the identity later treated as its check.

## The bounded correction

`ConfiguredPackVerifier` is constructed from expectation bytes before `verify()` is
invoked. Its verification method accepts only:

1. immutable, owning `SealedDescriptor` observations; and
2. the produced pack bytes.

It has no expected-digest parameter. The verifier checks, in order:

- each sealed descriptor still commits to its owned bytes under the configured digest engine;
- the canonical descriptor-set commitment equals the preconfigured commitment;
- the candidate pack length equals the preconfigured length;
- the candidate bytes are the exact canonical reconstruction of the sealed observations; and
- the candidate digest equals the preconfigured pack digest.

The exact-reconstruction check closes a check/use gap: verification never validates a
path and then re-opens that path later. The admitted bytes are the same owned bytes that
were observed and committed.

## Proof obligations discharged by the harness

| Obligation | Mechanism | Executable witness |
|---|---|---|
| Producer cannot replace the expectation at verify time | `verify()` has no expectation argument | compile-time member-signature assertion and self-pinning rejection test |
| Caller mutation cannot rewrite configured state | configuration is parsed and copied at construction | configuration-buffer mutation test |
| Caller mutation cannot rewrite observed bytes | descriptors own byte vectors | source-buffer mutation test |
| Two logical names cannot alias one pack member | canonical path validation and duplicate rejection | duplicate-path test |
| Representation is exact, not merely semantically similar | canonical encoder byte comparison | pack-mutation test |
| Digest engine mismatch cannot launder a descriptor | verifier re-hashes owned bytes | cross-engine test |
| Malformed expectation envelopes fail closed | fixed magic, version, size, no trailing bytes | malformed-configuration test |

## What this does **not** prove

This is a hosted separation, not external authentication. A single administrator or
process that controls both the configuration slot and the candidate can replace both.
The helper `make_host_expectation()` exists for provisioning and tests; putting it in the
producer request path would recreate the defect. Epoch Zero cannot end until an owner or
independent authority establishes how expectation bytes enter the host and how that act
is durably witnessed.

The test digest is deliberately non-cryptographic. Production integration must inject a
reviewed digest implementation and bind its algorithm identifier into the configured
format before any security claim is made.

## Laws

**L1 — non-self-selection.** For candidate `C`, acceptance is meaningful only when expected
identity `E` is fixed independently of the producer's choice of `C`.

**L2 — sealed observation.** Bytes checked and bytes admitted must be the same owned
observation; a verified pathname is not a verified future read.

**L3 — exact representation.** `candidate_pack == canonical_pack(sealed_descriptors)` is
required in addition to digest agreement.

**L4 — hosted limitation.** Local separation of API roles does not create an owner,
signer, threshold, secure channel, or independent witness.
