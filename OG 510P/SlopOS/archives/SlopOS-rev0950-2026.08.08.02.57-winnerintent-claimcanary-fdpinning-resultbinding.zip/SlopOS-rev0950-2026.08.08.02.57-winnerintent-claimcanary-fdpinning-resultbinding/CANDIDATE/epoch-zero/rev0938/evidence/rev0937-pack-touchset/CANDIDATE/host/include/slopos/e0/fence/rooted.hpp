#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <optional>
#include <span>
#include <string>
#include <vector>

namespace slopos::e0::fence::host {

enum class Area : std::uint8_t {
    journal,
    install,
    floor,
    endpoint,
    effects,
    meta,
};

enum class CreateStatus : std::uint8_t {
    created,
    exact_incumbent,
    conflict,
    failed,
};

struct FileRead final {
    bool ok{};
    bool absent{};
    std::vector<std::uint8_t> bytes{};
    std::string detail{};
};

struct RootIdentity final {
    std::uint64_t device{};
    std::uint64_t inode{};
};

class RootedStore final {
public:
    RootedStore() noexcept = default;
    RootedStore(const RootedStore&) = delete;
    RootedStore& operator=(const RootedStore&) = delete;
    RootedStore(RootedStore&& other) noexcept;
    RootedStore& operator=(RootedStore&& other) noexcept;
    ~RootedStore();

    [[nodiscard]] static std::optional<RootedStore> open(
        const std::filesystem::path& absolute_root,
        std::string& detail) noexcept;

    [[nodiscard]] bool replace(Area area, std::string_view leaf,
                               std::span<const std::uint8_t> bytes,
                               std::string& detail) noexcept;
    [[nodiscard]] CreateStatus create_no_replace(
        Area area, std::string_view leaf,
        std::span<const std::uint8_t> bytes,
        std::string& detail) noexcept;
    [[nodiscard]] bool remove_if_present(Area area, std::string_view leaf,
                                         std::string& detail) noexcept;
    [[nodiscard]] FileRead read(Area area, std::string_view leaf,
                                std::size_t maximum) const noexcept;
    [[nodiscard]] RootIdentity root_identity() const noexcept;
    [[nodiscard]] bool identities_unchanged(std::string& detail) const noexcept;

private:
    int root_fd_{-1};
    int journal_fd_{-1};
    int install_fd_{-1};
    int floor_fd_{-1};
    int endpoint_fd_{-1};
    int effects_fd_{-1};
    int meta_fd_{-1};
    RootIdentity root_identity_{};
    RootIdentity journal_identity_{};
    RootIdentity install_identity_{};
    RootIdentity floor_identity_{};
    RootIdentity endpoint_identity_{};
    RootIdentity effects_identity_{};
    RootIdentity meta_identity_{};

    [[nodiscard]] int area_fd(Area area) const noexcept;
    void close_all() noexcept;
};

struct PathCampaignReport final {
    bool ok{};
    std::size_t cases{};
    std::size_t passed{};
    std::string detail{};
};

[[nodiscard]] PathCampaignReport run_path_campaign(
    const std::filesystem::path& root);

}  // namespace slopos::e0::fence::host
