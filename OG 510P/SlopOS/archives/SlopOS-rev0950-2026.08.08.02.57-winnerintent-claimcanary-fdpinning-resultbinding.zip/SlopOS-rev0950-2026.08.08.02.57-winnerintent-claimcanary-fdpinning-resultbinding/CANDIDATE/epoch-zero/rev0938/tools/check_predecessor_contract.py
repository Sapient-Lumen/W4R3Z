#!/usr/bin/env python3
"""Fail closed when the human predecessor narrative disagrees with the receipt."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

BLOCK = re.compile(
    r"<!--\s*slopos-predecessor-contract\s*\n(?P<body>.*?)\n-->",
    re.DOTALL | re.IGNORECASE,
)

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def parse_block(text: str) -> dict[str, str]:
    match = BLOCK.search(text)
    if not match:
        raise ValueError("PREDECESSOR/README.md lacks machine-readable contract block")
    values: dict[str, str] = {}
    for line in match.group("body").splitlines():
        if not line.strip():
            continue
        if ":" not in line:
            raise ValueError(f"malformed contract line: {line!r}")
        key, value = line.split(":", 1)
        key, value = key.strip(), value.strip()
        if key in values:
            raise ValueError(f"duplicate contract key: {key}")
        values[key] = value
    return values

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cube-root", type=Path, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--parent-archive", type=Path)
    args = parser.parse_args()

    contract = json.loads(args.contract.read_text(encoding="utf-8"))
    readme = args.cube_root / contract["predecessor_readme"]
    if not readme.is_file():
        raise SystemExit(f"missing predecessor narrative: {readme}")
    values = parse_block(readme.read_text(encoding="utf-8"))

    expected = {
        "active_revision": str(contract["active_revision"]),
        "immediate_parent_revision": str(contract["immediate_parent_revision"]),
        "immediate_parent_archive": contract["immediate_parent_archive"],
        "immediate_parent_sha256": contract["immediate_parent_sha256"],
        "predecessor_payload_status": contract["predecessor_payload_status"],
    }
    errors = []
    for key, value in expected.items():
        if values.get(key) != value:
            errors.append(f"{key}: readme={values.get(key)!r}, receipt={value!r}")

    # The first heading is part of the human reopen surface, so check it too.
    first_heading = next((line.strip() for line in readme.read_text(encoding="utf-8").splitlines()
                          if line.lstrip().startswith("#")), "")
    required_heading_terms = [f"rev{contract['active_revision']:04d}",
                              f"rev{contract['immediate_parent_revision']:04d}"]
    for term in required_heading_terms:
        if term not in first_heading:
            errors.append(f"first heading omits {term}: {first_heading!r}")

    if args.parent_archive is not None:
        if not args.parent_archive.is_file():
            errors.append(f"parent archive missing: {args.parent_archive}")
        else:
            if args.parent_archive.name != contract["immediate_parent_archive"]:
                errors.append("parent archive filename differs from receipt")
            observed = sha256(args.parent_archive)
            if observed != contract["immediate_parent_sha256"]:
                errors.append(
                    f"parent archive sha256 differs: observed={observed}, "
                    f"receipt={contract['immediate_parent_sha256']}"
                )

    # Reject the exact stale labels that caused the incident when they appear in
    # the live heading/contract surface. Historical incident files are out of scope.
    live_prefix = "\n".join(readme.read_text(encoding="utf-8").splitlines()[:40])
    for stale in contract.get("forbidden_live_revision_labels", []):
        if stale in live_prefix:
            errors.append(f"forbidden stale revision label remains in live prefix: {stale}")

    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("predecessor continuity contract: PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
