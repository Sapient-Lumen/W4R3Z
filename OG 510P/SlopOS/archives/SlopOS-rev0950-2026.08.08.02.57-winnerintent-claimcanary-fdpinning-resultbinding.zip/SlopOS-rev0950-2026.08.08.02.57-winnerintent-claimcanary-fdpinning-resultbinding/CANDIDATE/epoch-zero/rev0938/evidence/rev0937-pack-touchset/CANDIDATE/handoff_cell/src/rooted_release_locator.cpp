#include "slopos/e0/handoff_cell/rooted_release_locator.hpp"

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] bool resolution_policy_complete(
    const RootedReleaseObservationV1& observation) noexcept {
    return observation.openat2_available
        && observation.resolve_beneath
        && observation.resolve_no_symlinks
        && observation.resolve_no_magiclinks
        && observation.resolve_no_xdev;
}

[[nodiscard]] bool root_prefix_complete(
    const RootedReleaseObservationV1& observation) noexcept {
    return observation.root_descriptor_supplied
        && observation.root_descriptor_cloexec_duplicate
        && observation.root_descriptor_o_path
        && observation.root_is_directory
        && observation.root_owner_matches_host_profile
        && observation.root_mode_private
        && observation.fixed_leaf_name
        && resolution_policy_complete(observation)
        && observation.regular_only_open_enforced
        && !observation.caller_root_path_reopened;
}

[[nodiscard]] bool observation_is_coherent(
    const RootedReleaseObservationV1& observation) noexcept {
    if (observation.root_descriptor_cloexec_duplicate
        && !observation.root_descriptor_supplied) {
        return false;
    }
    if (observation.root_descriptor_o_path
        && !observation.root_descriptor_cloexec_duplicate) {
        return false;
    }
    if (observation.root_is_directory
        && !observation.root_descriptor_cloexec_duplicate) {
        return false;
    }
    if ((observation.root_owner_matches_host_profile
         || observation.root_mode_private)
        && !observation.root_is_directory) {
        return false;
    }
    if (observation.caller_root_path_reopened
        && !observation.root_descriptor_supplied) {
        return false;
    }
    if (observation.root_path_replaced_after_pin
        && (!observation.root_descriptor_cloexec_duplicate
            || !observation.root_descriptor_o_path)) {
        return false;
    }
    if (observation.regular_only_open_enforced
        && !observation.openat2_available) {
        return false;
    }

    const bool leaf_attempted =
        observation.leaf_outcome != RootedReleaseLeafOutcome::not_attempted;
    const bool leaf_opened =
        observation.leaf_outcome == RootedReleaseLeafOutcome::opened;
    if (leaf_attempted && !root_prefix_complete(observation)) {
        return false;
    }
    if ((observation.leaf_regular
         || observation.leaf_same_device
         || observation.root_identity_stable
         || observation.root_profile_reobserved_equal)
        && !leaf_opened) {
        return false;
    }
    if (observation.root_profile_reobserved_equal
        && !observation.root_identity_stable) {
        return false;
    }
    if (observation.leaf_same_device && !observation.leaf_regular) {
        return false;
    }
    return true;
}

[[nodiscard]] RootedReleaseAssessment base_assessment(
    const RootedReleaseObservationV1& observation) noexcept {
    RootedReleaseAssessment result;
    result.root_descriptor_pinned =
        observation.root_descriptor_supplied
        && observation.root_descriptor_cloexec_duplicate;
    result.root_descriptor_o_path =
        result.root_descriptor_pinned && observation.root_descriptor_o_path;
    result.root_identity_retained =
        result.root_descriptor_o_path
        && observation.leaf_outcome == RootedReleaseLeafOutcome::opened
        && observation.root_identity_stable;
    result.root_profile_reobserved_equal =
        result.root_identity_retained
        && observation.root_profile_reobserved_equal;
    result.hosted_private_root_profile =
        result.root_descriptor_o_path
        && observation.root_is_directory
        && observation.root_owner_matches_host_profile
        && observation.root_mode_private
        && result.root_profile_reobserved_equal;
    // Two equal endpoint observations cannot exclude an intervening ABA drift.
    result.root_profile_continuity_proved = false;
    result.fixed_leaf_only = observation.fixed_leaf_name;
    result.all_component_symlink_rejection =
        observation.openat2_available
        && observation.resolve_no_symlinks
        && observation.resolve_no_magiclinks;
    result.beneath_restriction =
        observation.openat2_available && observation.resolve_beneath;
    result.cross_mount_rejection =
        observation.openat2_available && observation.resolve_no_xdev;
    result.regular_only_open_enforced =
        observation.openat2_available
        && observation.regular_only_open_enforced;
    result.post_open_shape_is_contract_check_only =
        result.regular_only_open_enforced
        && observation.leaf_outcome == RootedReleaseLeafOutcome::opened;
    // Explicit nonclaims remain false in every disposition.
    result.root_path_replacement_ignored = false;
    result.candidate_bytes_read = false;
    result.archive_digest_compared = false;
    result.archive_parsed = false;
    result.caller_root_path_authority = false;
    result.owner_custody_proved = false;
    result.source_provenance_proved = false;
    result.activation_authority = false;
    result.provider_operation_authority = false;
    return result;
}

}  // namespace

RootedReleaseAssessment assess_rooted_release_locator(
    const RootedReleaseObservationV1& observation) noexcept {
    RootedReleaseAssessment result = base_assessment(observation);
    if (!observation_is_coherent(observation)) {
        result.disposition = RootedReleaseDisposition::observation_incoherent;
        return result;
    }
    result.observation_coherent = true;

    if (!observation.root_descriptor_supplied) {
        result.disposition = RootedReleaseDisposition::root_descriptor_unavailable;
        return result;
    }
    if (!observation.root_descriptor_cloexec_duplicate) {
        result.disposition = RootedReleaseDisposition::root_descriptor_unpinned;
        return result;
    }
    if (!observation.root_descriptor_o_path) {
        result.disposition = RootedReleaseDisposition::root_descriptor_not_o_path;
        return result;
    }
    if (!observation.root_is_directory) {
        result.disposition = RootedReleaseDisposition::root_not_directory;
        return result;
    }
    if (!observation.root_owner_matches_host_profile
        || !observation.root_mode_private
        || !observation.fixed_leaf_name) {
        result.disposition = RootedReleaseDisposition::root_profile_rejected;
        return result;
    }
    if (!resolution_policy_complete(observation)) {
        result.disposition = RootedReleaseDisposition::resolution_policy_unavailable;
        return result;
    }
    if (!observation.regular_only_open_enforced) {
        result.disposition = RootedReleaseDisposition::regular_only_policy_unavailable;
        return result;
    }
    if (observation.caller_root_path_reopened) {
        result.disposition = RootedReleaseDisposition::root_path_reopen_rejected;
        return result;
    }
    if (observation.leaf_outcome == RootedReleaseLeafOutcome::not_attempted
        || observation.leaf_outcome == RootedReleaseLeafOutcome::unavailable) {
        result.disposition = RootedReleaseDisposition::fixed_leaf_unavailable;
        return result;
    }
    if (observation.leaf_outcome == RootedReleaseLeafOutcome::policy_rejected) {
        result.disposition = RootedReleaseDisposition::fixed_leaf_policy_rejected;
        return result;
    }
    if (!observation.root_identity_stable) {
        result.disposition = RootedReleaseDisposition::root_identity_changed;
        return result;
    }
    if (!observation.root_profile_reobserved_equal) {
        result.disposition = RootedReleaseDisposition::root_profile_changed;
        return result;
    }
    if (!observation.leaf_regular) {
        // A successful OPENAT2_REGULAR open returning a nonregular object would
        // violate the required syscall contract; post-open fstat is only a
        // defensive check and never substitutes for atomic type enforcement.
        result.disposition = RootedReleaseDisposition::regular_only_contract_violated;
        return result;
    }
    if (!observation.leaf_same_device) {
        result.disposition = RootedReleaseDisposition::leaf_cross_device;
        return result;
    }

    result.candidate_descriptor_ready = true;
    result.root_path_replacement_ignored =
        observation.root_path_replaced_after_pin;
    result.disposition = RootedReleaseDisposition::candidate_descriptor_ready;
    return result;
}

const char* rooted_release_disposition_name(
    const RootedReleaseDisposition value) noexcept {
    switch (value) {
        case RootedReleaseDisposition::observation_incoherent:
            return "OBSERVATION_INCOHERENT";
        case RootedReleaseDisposition::root_descriptor_unavailable:
            return "ROOT_DESCRIPTOR_UNAVAILABLE";
        case RootedReleaseDisposition::root_descriptor_unpinned:
            return "ROOT_DESCRIPTOR_UNPINNED";
        case RootedReleaseDisposition::root_descriptor_not_o_path:
            return "ROOT_DESCRIPTOR_NOT_OPATH";
        case RootedReleaseDisposition::root_not_directory:
            return "ROOT_NOT_DIRECTORY";
        case RootedReleaseDisposition::root_profile_rejected:
            return "ROOT_PROFILE_REJECTED";
        case RootedReleaseDisposition::resolution_policy_unavailable:
            return "RESOLUTION_POLICY_UNAVAILABLE";
        case RootedReleaseDisposition::regular_only_policy_unavailable:
            return "REGULAR_ONLY_POLICY_UNAVAILABLE";
        case RootedReleaseDisposition::fixed_leaf_unavailable:
            return "FIXED_LEAF_UNAVAILABLE";
        case RootedReleaseDisposition::fixed_leaf_policy_rejected:
            return "FIXED_LEAF_POLICY_REJECTED";
        case RootedReleaseDisposition::root_path_reopen_rejected:
            return "ROOT_PATH_REOPEN_REJECTED";
        case RootedReleaseDisposition::root_identity_changed:
            return "ROOT_IDENTITY_CHANGED";
        case RootedReleaseDisposition::root_profile_changed:
            return "ROOT_PROFILE_CHANGED";
        case RootedReleaseDisposition::regular_only_contract_violated:
            return "REGULAR_ONLY_CONTRACT_VIOLATED";
        case RootedReleaseDisposition::leaf_cross_device:
            return "LEAF_CROSS_DEVICE";
        case RootedReleaseDisposition::candidate_descriptor_ready:
            return "CANDIDATE_DESCRIPTOR_READY";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
