#include "slopos/e0/handoff_cell/sealed_snapshot_offer.hpp"

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] bool socket_profile_complete(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    return value.socket_descriptor_supplied
        && value.socket_descriptor_cloexec_duplicate
        && value.socket_family_unix
        && value.socket_type_seqpacket;
}

[[nodiscard]] bool delivery_profile_complete(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    return socket_profile_complete(value)
        && value.passcred_enabled
        && value.passpidfd_enabled
        && value.peer_credentials_observed
        && value.peer_pidfd_observed;
}

[[nodiscard]] bool envelope_exact(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    return value.one_message_received
        && !value.message_data_truncated
        && !value.message_control_truncated
        && value.offer_payload_exact
        && value.exactly_one_rights_record
        && value.exactly_one_rights_descriptor
        && value.exactly_one_credentials_record
        && value.exactly_one_pidfd_record
        && value.no_unknown_control_records;
}

[[nodiscard]] bool message_fields_present(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    return value.message_data_truncated
        || value.message_control_truncated
        || value.offer_payload_exact
        || value.exactly_one_rights_record
        || value.exactly_one_rights_descriptor
        || value.exactly_one_credentials_record
        || value.exactly_one_pidfd_record
        || value.no_unknown_control_records
        || value.message_process_matches_peer
        || value.message_credentials_match_peer;
}

[[nodiscard]] bool descriptor_fields_present(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    return value.candidate_descriptor_cloexec
        || value.candidate_descriptor_readable
        || value.candidate_regular
        || value.candidate_unlinked
        || value.candidate_seal_query_supported
        || value.candidate_seal_write
        || value.candidate_seal_grow
        || value.candidate_seal_shrink
        || value.candidate_seal_seal
        || value.candidate_size_bounded;
}

[[nodiscard]] bool observation_is_coherent(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    if (value.socket_descriptor_cloexec_duplicate
        && !value.socket_descriptor_supplied) return false;
    if ((value.socket_family_unix || value.socket_type_seqpacket)
        && !value.socket_descriptor_cloexec_duplicate) return false;
    if ((value.passcred_enabled || value.passpidfd_enabled)
        && !socket_profile_complete(value)) return false;
    if (value.peer_credentials_observed && !value.passcred_enabled) return false;
    if (value.peer_pidfd_observed && !value.passpidfd_enabled) return false;
    if (value.receiver_preoffer_candidate_aliases_zero
        && !delivery_profile_complete(value)) return false;
    if (value.acquisition_actor_admitted_before_ready
        && !(delivery_profile_complete(value)
             && value.receiver_preoffer_candidate_aliases_zero)) return false;
    if (value.ready_frame_sent
        && !value.acquisition_actor_admitted_before_ready) return false;
    if (value.one_message_received && !value.ready_frame_sent) return false;
    if (message_fields_present(value) && !value.one_message_received) return false;
    if (value.exactly_one_rights_descriptor
        && !value.exactly_one_rights_record) return false;
    if (value.message_process_matches_peer
        && !(value.peer_pidfd_observed
             && value.exactly_one_pidfd_record)) return false;
    if (value.message_credentials_match_peer
        && !(value.peer_credentials_observed
             && value.exactly_one_credentials_record)) return false;
    if (descriptor_fields_present(value)
        && !(envelope_exact(value)
             && value.message_process_matches_peer
             && value.message_credentials_match_peer)) return false;
    if ((value.candidate_descriptor_readable || value.candidate_regular
         || value.candidate_unlinked || value.candidate_seal_query_supported)
        && !value.candidate_descriptor_cloexec) return false;
    if ((value.candidate_seal_write || value.candidate_seal_grow
         || value.candidate_seal_shrink || value.candidate_seal_seal)
        && !value.candidate_seal_query_supported) return false;
    if (value.candidate_size_bounded
        && !(value.candidate_regular && value.candidate_unlinked
             && value.candidate_seal_query_supported)) return false;
    return true;
}

[[nodiscard]] SealedSnapshotOfferAssessment base_assessment(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    SealedSnapshotOfferAssessment result;
    result.socket_descriptor_pinned =
        value.socket_descriptor_supplied
        && value.socket_descriptor_cloexec_duplicate;
    result.exact_message_boundary =
        result.socket_descriptor_pinned
        && value.socket_family_unix
        && value.socket_type_seqpacket;
    result.peer_coordinate_observed = delivery_profile_complete(value);
    result.receiver_preoffer_candidate_aliases_zero =
        result.peer_coordinate_observed
        && value.receiver_preoffer_candidate_aliases_zero;
    result.acquisition_actor_admitted =
        result.receiver_preoffer_candidate_aliases_zero
        && value.acquisition_actor_admitted_before_ready;
    result.actor_admission_precedes_ready =
        result.acquisition_actor_admitted;
    result.ancillary_envelope_exact = envelope_exact(value);
    result.process_coordinate_agrees =
        result.ancillary_envelope_exact
        && value.message_process_matches_peer;
    result.credential_coordinate_agrees =
        result.ancillary_envelope_exact
        && value.message_credentials_match_peer;
    result.transport_envelope_ready =
        result.acquisition_actor_admitted
        && value.ready_frame_sent
        && result.process_coordinate_agrees
        && result.credential_coordinate_agrees;
    result.candidate_descriptor_received =
        result.transport_envelope_ready
        && value.exactly_one_rights_record
        && value.exactly_one_rights_descriptor;
    result.candidate_descriptor_cloexec =
        result.candidate_descriptor_received
        && value.candidate_descriptor_cloexec;
    result.candidate_descriptor_readable =
        result.candidate_descriptor_cloexec
        && value.candidate_descriptor_readable;
    result.candidate_regular_unlinked =
        result.candidate_descriptor_readable
        && value.candidate_regular
        && value.candidate_unlinked;
    result.candidate_fully_write_sealed =
        result.candidate_regular_unlinked
        && value.candidate_seal_query_supported
        && value.candidate_seal_write
        && value.candidate_seal_grow
        && value.candidate_seal_shrink
        && value.candidate_seal_seal;
    result.candidate_size_bounded =
        result.candidate_fully_write_sealed
        && value.candidate_size_bounded;
    result.sealed_descriptor_profile_ready = result.candidate_size_bounded;
    // Mandatory nonclaims. SCM_RIGHTS duplicates an open file description;
    // the receiver observes present inode behavior, not creation history.
    result.candidate_bytes_read = false;
    result.archive_digest_compared = false;
    result.archive_parsed = false;
    result.one_use_transfer_proved = false;
    result.exclusive_custody_proved = false;
    result.candidate_memfd_creation_proved = false;
    result.source_provenance_proved = false;
    result.durable_media_proved = false;
    result.activation_authority = false;
    result.provider_operation_authority = false;
    result.owner_custody_proved = false;
    return result;
}

}  // namespace

SealedSnapshotOfferAssessment assess_sealed_snapshot_offer(
    const SealedSnapshotOfferObservationV1& value) noexcept {
    SealedSnapshotOfferAssessment result = base_assessment(value);
    if (!observation_is_coherent(value)) {
        result.disposition =
            SealedSnapshotOfferDisposition::observation_incoherent;
        return result;
    }
    result.observation_coherent = true;
    if (!value.socket_descriptor_supplied) {
        result.disposition =
            SealedSnapshotOfferDisposition::socket_descriptor_unavailable;
    } else if (!value.socket_descriptor_cloexec_duplicate) {
        result.disposition =
            SealedSnapshotOfferDisposition::socket_descriptor_unpinned;
    } else if (!value.socket_family_unix) {
        result.disposition =
            SealedSnapshotOfferDisposition::socket_family_rejected;
    } else if (!value.socket_type_seqpacket) {
        result.disposition =
            SealedSnapshotOfferDisposition::socket_type_rejected;
    } else if (!value.passcred_enabled) {
        result.disposition =
            SealedSnapshotOfferDisposition::credential_delivery_unavailable;
    } else if (!value.passpidfd_enabled) {
        result.disposition =
            SealedSnapshotOfferDisposition::pidfd_delivery_unavailable;
    } else if (!value.peer_credentials_observed
               || !value.peer_pidfd_observed) {
        result.disposition =
            SealedSnapshotOfferDisposition::peer_coordinate_unavailable;
    } else if (!value.receiver_preoffer_candidate_aliases_zero) {
        result.disposition = SealedSnapshotOfferDisposition::
            receiver_preoffer_candidate_alias_present;
    } else if (!value.acquisition_actor_admitted_before_ready) {
        result.disposition =
            SealedSnapshotOfferDisposition::acquisition_actor_not_admitted;
    } else if (!value.ready_frame_sent) {
        result.disposition =
            SealedSnapshotOfferDisposition::ready_frame_unsent;
    } else if (!value.one_message_received) {
        result.disposition =
            SealedSnapshotOfferDisposition::offer_unavailable;
    } else if (value.message_data_truncated) {
        result.disposition =
            SealedSnapshotOfferDisposition::message_data_truncated;
    } else if (value.message_control_truncated) {
        result.disposition =
            SealedSnapshotOfferDisposition::message_control_truncated;
    } else if (!value.offer_payload_exact) {
        result.disposition =
            SealedSnapshotOfferDisposition::offer_payload_rejected;
    } else if (!value.exactly_one_rights_record
               || !value.exactly_one_rights_descriptor
               || !value.exactly_one_credentials_record
               || !value.exactly_one_pidfd_record
               || !value.no_unknown_control_records) {
        result.disposition =
            SealedSnapshotOfferDisposition::ancillary_shape_rejected;
    } else if (!value.message_process_matches_peer) {
        result.disposition =
            SealedSnapshotOfferDisposition::process_identity_mismatch;
    } else if (!value.message_credentials_match_peer) {
        result.disposition =
            SealedSnapshotOfferDisposition::credential_mismatch;
    } else if (!value.candidate_descriptor_cloexec) {
        result.disposition =
            SealedSnapshotOfferDisposition::candidate_descriptor_not_cloexec;
    } else if (!value.candidate_descriptor_readable) {
        result.disposition = SealedSnapshotOfferDisposition::
            candidate_descriptor_not_readable;
    } else if (!value.candidate_regular) {
        result.disposition =
            SealedSnapshotOfferDisposition::candidate_descriptor_not_regular;
    } else if (!value.candidate_unlinked) {
        result.disposition =
            SealedSnapshotOfferDisposition::candidate_descriptor_linked;
    } else if (!value.candidate_seal_query_supported) {
        result.disposition = SealedSnapshotOfferDisposition::
            candidate_seal_query_unavailable;
    } else if (!value.candidate_seal_write
               || !value.candidate_seal_grow
               || !value.candidate_seal_shrink
               || !value.candidate_seal_seal) {
        result.disposition = SealedSnapshotOfferDisposition::
            candidate_required_seals_missing;
    } else if (!value.candidate_size_bounded) {
        result.disposition =
            SealedSnapshotOfferDisposition::candidate_size_rejected;
    } else {
        result.sealed_snapshot_source_ready = true;
        result.disposition =
            SealedSnapshotOfferDisposition::sealed_snapshot_source_ready;
    }
    return result;
}

const char* sealed_snapshot_offer_disposition_name(
    const SealedSnapshotOfferDisposition value) noexcept {
    switch (value) {
        case SealedSnapshotOfferDisposition::observation_incoherent:
            return "OBSERVATION_INCOHERENT";
        case SealedSnapshotOfferDisposition::socket_descriptor_unavailable:
            return "SOCKET_DESCRIPTOR_UNAVAILABLE";
        case SealedSnapshotOfferDisposition::socket_descriptor_unpinned:
            return "SOCKET_DESCRIPTOR_UNPINNED";
        case SealedSnapshotOfferDisposition::socket_family_rejected:
            return "SOCKET_FAMILY_REJECTED";
        case SealedSnapshotOfferDisposition::socket_type_rejected:
            return "SOCKET_TYPE_REJECTED";
        case SealedSnapshotOfferDisposition::credential_delivery_unavailable:
            return "CREDENTIAL_DELIVERY_UNAVAILABLE";
        case SealedSnapshotOfferDisposition::pidfd_delivery_unavailable:
            return "PIDFD_DELIVERY_UNAVAILABLE";
        case SealedSnapshotOfferDisposition::peer_coordinate_unavailable:
            return "PEER_COORDINATE_UNAVAILABLE";
        case SealedSnapshotOfferDisposition::
                receiver_preoffer_candidate_alias_present:
            return "RECEIVER_PREOFFER_CANDIDATE_ALIAS_PRESENT";
        case SealedSnapshotOfferDisposition::acquisition_actor_not_admitted:
            return "ACQUISITION_ACTOR_NOT_ADMITTED";
        case SealedSnapshotOfferDisposition::ready_frame_unsent:
            return "READY_FRAME_UNSENT";
        case SealedSnapshotOfferDisposition::offer_unavailable:
            return "OFFER_UNAVAILABLE";
        case SealedSnapshotOfferDisposition::message_data_truncated:
            return "MESSAGE_DATA_TRUNCATED";
        case SealedSnapshotOfferDisposition::message_control_truncated:
            return "MESSAGE_CONTROL_TRUNCATED";
        case SealedSnapshotOfferDisposition::offer_payload_rejected:
            return "OFFER_PAYLOAD_REJECTED";
        case SealedSnapshotOfferDisposition::ancillary_shape_rejected:
            return "ANCILLARY_SHAPE_REJECTED";
        case SealedSnapshotOfferDisposition::process_identity_mismatch:
            return "PROCESS_IDENTITY_MISMATCH";
        case SealedSnapshotOfferDisposition::credential_mismatch:
            return "CREDENTIAL_MISMATCH";
        case SealedSnapshotOfferDisposition::candidate_descriptor_not_cloexec:
            return "CANDIDATE_DESCRIPTOR_NOT_CLOEXEC";
        case SealedSnapshotOfferDisposition::candidate_descriptor_not_readable:
            return "CANDIDATE_DESCRIPTOR_NOT_READABLE";
        case SealedSnapshotOfferDisposition::candidate_descriptor_not_regular:
            return "CANDIDATE_DESCRIPTOR_NOT_REGULAR";
        case SealedSnapshotOfferDisposition::candidate_descriptor_linked:
            return "CANDIDATE_DESCRIPTOR_LINKED";
        case SealedSnapshotOfferDisposition::candidate_seal_query_unavailable:
            return "CANDIDATE_SEAL_QUERY_UNAVAILABLE";
        case SealedSnapshotOfferDisposition::candidate_required_seals_missing:
            return "CANDIDATE_REQUIRED_SEALS_MISSING";
        case SealedSnapshotOfferDisposition::candidate_size_rejected:
            return "CANDIDATE_SIZE_REJECTED";
        case SealedSnapshotOfferDisposition::sealed_snapshot_source_ready:
            return "SEALED_SNAPSHOT_SOURCE_READY";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
