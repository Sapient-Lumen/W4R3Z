#include "slopos/e0/fence/rooted.hpp"

#include <array>
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <linux/openat2.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

#include <fstream>
#include <string>

namespace slopos::e0::fence::host {
namespace {

constexpr std::uint64_t child_resolve = RESOLVE_BENEATH
    | RESOLVE_NO_MAGICLINKS | RESOLVE_NO_SYMLINKS | RESOLVE_NO_XDEV;
constexpr std::uint64_t root_resolve =
    RESOLVE_NO_MAGICLINKS | RESOLVE_NO_SYMLINKS;

[[nodiscard]] int openat2_raw(const int dirfd, const char* path,
                              const std::uint64_t flags,
                              const std::uint64_t mode,
                              const std::uint64_t resolve) noexcept {
    open_how how{};
    how.flags = flags;
    how.mode = mode;
    how.resolve = resolve;
    return static_cast<int>(::syscall(SYS_openat2, dirfd, path, &how,
                                      sizeof(how)));
}

[[nodiscard]] std::string error_text(const char* action) {
    return std::string(action) + ": " + std::strerror(errno);
}

[[nodiscard]] bool valid_leaf(const std::string_view leaf) noexcept {
    return !leaf.empty() && leaf != "." && leaf != ".."
        && leaf.find('/') == std::string_view::npos
        && leaf.find('\0') == std::string_view::npos;
}

[[nodiscard]] RootIdentity identity(const int fd) noexcept {
    struct stat st{};
    if (::fstat(fd, &st) != 0) return {};
    return RootIdentity{static_cast<std::uint64_t>(st.st_dev),
                        static_cast<std::uint64_t>(st.st_ino)};
}

[[nodiscard]] bool regular_mode(const int fd) noexcept {
    struct stat st{};
    return ::fstat(fd, &st) == 0 && S_ISREG(st.st_mode)
        && (st.st_mode & 0777) == 0600;
}

[[nodiscard]] bool directory_mode(const int fd) noexcept {
    struct stat st{};
    return ::fstat(fd, &st) == 0 && S_ISDIR(st.st_mode)
        && (st.st_mode & 0022) == 0;
}

[[nodiscard]] bool write_all(const int fd,
                             const std::span<const std::uint8_t> bytes,
                             std::string& detail) noexcept {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(fd, bytes.data() + offset,
                                      bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) continue;
            detail = error_text("write");
            return false;
        }
        if (count == 0) {
            detail = "write returned zero";
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    if (::fsync(fd) != 0) {
        detail = error_text("fsync file");
        return false;
    }
    return true;
}

[[nodiscard]] std::string temp_name() {
    static std::uint64_t sequence = 0U;
    ++sequence;
    return ".slopos-tmp-" + std::to_string(static_cast<long long>(::getpid()))
        + "-" + std::to_string(sequence);
}

[[nodiscard]] bool same_identity(const int fd,
                                 const RootIdentity expected) noexcept {
    return identity(fd).device == expected.device
        && identity(fd).inode == expected.inode;
}

[[nodiscard]] bool create_layout(const std::filesystem::path& root,
                                 std::string& detail) {
    std::error_code ec;
    std::filesystem::remove_all(root, ec);
    ec.clear();
    for (const char* name : {"journal", "install", "floor", "endpoint",
                             "effects", "meta"}) {
        std::filesystem::create_directories(root / name, ec);
        if (ec) {
            detail = "create layout: " + ec.message();
            return false;
        }
        std::filesystem::permissions(
            root / name, std::filesystem::perms::owner_all,
            std::filesystem::perm_options::replace, ec);
        if (ec) {
            detail = "chmod child: " + ec.message();
            return false;
        }
    }
    std::filesystem::permissions(
        root, std::filesystem::perms::owner_all,
        std::filesystem::perm_options::replace, ec);
    if (ec) {
        detail = "chmod root: " + ec.message();
        return false;
    }
    return true;
}

[[nodiscard]] std::vector<std::uint8_t> bytes(const std::string& text) {
    return std::vector<std::uint8_t>(text.begin(), text.end());
}

}  // namespace

RootedStore::RootedStore(RootedStore&& other) noexcept { *this = std::move(other); }
RootedStore& RootedStore::operator=(RootedStore&& other) noexcept {
    if (this == &other) return *this;
    close_all();
    root_fd_ = other.root_fd_; other.root_fd_ = -1;
    journal_fd_ = other.journal_fd_; other.journal_fd_ = -1;
    install_fd_ = other.install_fd_; other.install_fd_ = -1;
    floor_fd_ = other.floor_fd_; other.floor_fd_ = -1;
    endpoint_fd_ = other.endpoint_fd_; other.endpoint_fd_ = -1;
    effects_fd_ = other.effects_fd_; other.effects_fd_ = -1;
    meta_fd_ = other.meta_fd_; other.meta_fd_ = -1;
    root_identity_ = other.root_identity_;
    journal_identity_ = other.journal_identity_;
    install_identity_ = other.install_identity_;
    floor_identity_ = other.floor_identity_;
    endpoint_identity_ = other.endpoint_identity_;
    effects_identity_ = other.effects_identity_;
    meta_identity_ = other.meta_identity_;
    return *this;
}
RootedStore::~RootedStore() { close_all(); }
void RootedStore::close_all() noexcept {
    for (int* fd : {&journal_fd_, &install_fd_, &floor_fd_, &endpoint_fd_,
                    &effects_fd_, &meta_fd_, &root_fd_}) {
        if (*fd >= 0) {
            (void)::close(*fd);
            *fd = -1;
        }
    }
}

std::optional<RootedStore> RootedStore::open(
    const std::filesystem::path& absolute_root,
    std::string& detail) noexcept {
    if (!absolute_root.is_absolute()) {
        detail = "root must be absolute";
        return std::nullopt;
    }
    const std::string path = absolute_root.string();
    RootedStore store{};
    store.root_fd_ = openat2_raw(
        AT_FDCWD, path.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC,
        0U, root_resolve);
    if (store.root_fd_ < 0) {
        detail = error_text("openat2 root");
        return std::nullopt;
    }
    if (!directory_mode(store.root_fd_)) {
        detail = "root is not a private directory";
        return std::nullopt;
    }
    struct Entry { const char* name; int* fd; RootIdentity* id; };
    std::array<Entry, 6U> entries{{
        {"journal", &store.journal_fd_, &store.journal_identity_},
        {"install", &store.install_fd_, &store.install_identity_},
        {"floor", &store.floor_fd_, &store.floor_identity_},
        {"endpoint", &store.endpoint_fd_, &store.endpoint_identity_},
        {"effects", &store.effects_fd_, &store.effects_identity_},
        {"meta", &store.meta_fd_, &store.meta_identity_},
    }};
    store.root_identity_ = identity(store.root_fd_);
    for (Entry& entry : entries) {
        *entry.fd = openat2_raw(
            store.root_fd_, entry.name,
            O_RDONLY | O_DIRECTORY | O_CLOEXEC, 0U, child_resolve);
        if (*entry.fd < 0) {
            detail = error_text(entry.name);
            return std::nullopt;
        }
        if (!directory_mode(*entry.fd)) {
            detail = std::string(entry.name) + " is not a private directory";
            return std::nullopt;
        }
        *entry.id = identity(*entry.fd);
        if (entry.id->device != store.root_identity_.device) {
            detail = std::string(entry.name) + " crosses device boundary";
            return std::nullopt;
        }
    }
    detail = "openat2 root and six fixed child directories retained";
    return store;
}

int RootedStore::area_fd(const Area area) const noexcept {
    switch (area) {
        case Area::journal: return journal_fd_;
        case Area::install: return install_fd_;
        case Area::floor: return floor_fd_;
        case Area::endpoint: return endpoint_fd_;
        case Area::effects: return effects_fd_;
        case Area::meta: return meta_fd_;
    }
    return -1;
}

bool RootedStore::replace(const Area area, const std::string_view leaf,
                          const std::span<const std::uint8_t> data,
                          std::string& detail) noexcept {
    if (!valid_leaf(leaf)) {
        detail = "invalid leaf";
        return false;
    }
    const int dirfd = area_fd(area);
    if (dirfd < 0) {
        detail = "invalid area";
        return false;
    }
    const std::string temp = temp_name();
    int fd = openat2_raw(dirfd, temp.c_str(),
                         O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC,
                         0600U, child_resolve);
    if (fd < 0) {
        detail = error_text("create replacement temp");
        return false;
    }
    bool ok = regular_mode(fd) && write_all(fd, data, detail);
    if (::close(fd) != 0 && ok) {
        detail = error_text("close replacement temp");
        ok = false;
    }
    if (!ok) {
        (void)::unlinkat(dirfd, temp.c_str(), 0);
        return false;
    }
    const std::string target(leaf);
    if (::syscall(SYS_renameat2, dirfd, temp.c_str(), dirfd,
                  target.c_str(), 0U) != 0) {
        detail = error_text("renameat2 replace");
        (void)::unlinkat(dirfd, temp.c_str(), 0);
        return false;
    }
    if (::fsync(dirfd) != 0) {
        detail = error_text("fsync containing directory");
        return false;
    }
    const FileRead readback = read(area, leaf, data.size() + 1U);
    if (!readback.ok || readback.absent
        || !std::equal(readback.bytes.begin(), readback.bytes.end(),
                       data.begin(), data.end())) {
        detail = "exact replacement readback mismatch";
        return false;
    }
    detail = "replace+file-fsync+rename+directory-fsync+readback";
    return true;
}

CreateStatus RootedStore::create_no_replace(
    const Area area, const std::string_view leaf,
    const std::span<const std::uint8_t> data,
    std::string& detail) noexcept {
    if (!valid_leaf(leaf)) {
        detail = "invalid leaf";
        return CreateStatus::failed;
    }
    const int dirfd = area_fd(area);
    if (dirfd < 0) {
        detail = "invalid area";
        return CreateStatus::failed;
    }
    const std::string temp = temp_name();
    int fd = openat2_raw(dirfd, temp.c_str(),
                         O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC,
                         0600U, child_resolve);
    if (fd < 0) {
        detail = error_text("create no-replace temp");
        return CreateStatus::failed;
    }
    bool ok = regular_mode(fd) && write_all(fd, data, detail);
    if (::close(fd) != 0 && ok) {
        detail = error_text("close no-replace temp");
        ok = false;
    }
    if (!ok) {
        (void)::unlinkat(dirfd, temp.c_str(), 0);
        return CreateStatus::failed;
    }
    const std::string target(leaf);
    if (::syscall(SYS_renameat2, dirfd, temp.c_str(), dirfd,
                  target.c_str(), RENAME_NOREPLACE) == 0) {
        if (::fsync(dirfd) != 0) {
            detail = error_text("fsync no-replace directory");
            return CreateStatus::failed;
        }
        detail = "created with RENAME_NOREPLACE and directory fsync";
        return CreateStatus::created;
    }
    const int saved = errno;
    (void)::unlinkat(dirfd, temp.c_str(), 0);
    if (saved != EEXIST) {
        errno = saved;
        detail = error_text("renameat2 no-replace");
        return CreateStatus::failed;
    }
    const FileRead incumbent = read(area, leaf, data.size() + 1U);
    if (incumbent.ok && !incumbent.absent
        && incumbent.bytes.size() == data.size()
        && std::equal(incumbent.bytes.begin(), incumbent.bytes.end(),
                      data.begin(), data.end())) {
        detail = "exact incumbent retained";
        return CreateStatus::exact_incumbent;
    }
    detail = "nonmatching incumbent refused";
    return CreateStatus::conflict;
}

bool RootedStore::remove_if_present(const Area area,
                                    const std::string_view leaf,
                                    std::string& detail) noexcept {
    if (!valid_leaf(leaf)) {
        detail = "invalid leaf";
        return false;
    }
    const int dirfd = area_fd(area);
    const std::string target(leaf);
    if (::unlinkat(dirfd, target.c_str(), 0) != 0 && errno != ENOENT) {
        detail = error_text("unlinkat");
        return false;
    }
    if (::fsync(dirfd) != 0) {
        detail = error_text("fsync directory after unlink");
        return false;
    }
    detail = "absent with directory fsync";
    return true;
}

FileRead RootedStore::read(const Area area, const std::string_view leaf,
                           const std::size_t maximum) const noexcept {
    FileRead result{};
    if (!valid_leaf(leaf)) {
        result.detail = "invalid leaf";
        return result;
    }
    const int dirfd = area_fd(area);
    const std::string target(leaf);
    const int fd = openat2_raw(dirfd, target.c_str(),
                               O_RDONLY | O_CLOEXEC | O_NOFOLLOW,
                               0U, child_resolve);
    if (fd < 0) {
        if (errno == ENOENT) {
            result.ok = true;
            result.absent = true;
            result.detail = "absent";
            return result;
        }
        result.detail = error_text("openat2 read");
        return result;
    }
    struct stat before{};
    if (::fstat(fd, &before) != 0 || !S_ISREG(before.st_mode)
        || (before.st_mode & 0777) != 0600
        || before.st_size < 0
        || static_cast<std::uint64_t>(before.st_size) > maximum) {
        result.detail = "invalid file shape";
        (void)::close(fd);
        return result;
    }
    result.bytes.resize(static_cast<std::size_t>(before.st_size));
    std::size_t offset = 0U;
    while (offset < result.bytes.size()) {
        const ssize_t count = ::read(fd, result.bytes.data() + offset,
                                     result.bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) continue;
            result.detail = error_text("read");
            (void)::close(fd);
            return result;
        }
        if (count == 0) break;
        offset += static_cast<std::size_t>(count);
    }
    struct stat after{};
    if (offset != result.bytes.size() || ::fstat(fd, &after) != 0
        || before.st_dev != after.st_dev || before.st_ino != after.st_ino
        || before.st_size != after.st_size) {
        result.detail = "unstable read";
        (void)::close(fd);
        return result;
    }
    if (::close(fd) != 0) {
        result.detail = error_text("close read");
        return result;
    }
    result.ok = true;
    result.detail = "exact stable descriptor-relative read";
    return result;
}

RootIdentity RootedStore::root_identity() const noexcept {
    return root_identity_;
}
bool RootedStore::identities_unchanged(std::string& detail) const noexcept {
    if (!same_identity(root_fd_, root_identity_)
        || !same_identity(journal_fd_, journal_identity_)
        || !same_identity(install_fd_, install_identity_)
        || !same_identity(floor_fd_, floor_identity_)
        || !same_identity(endpoint_fd_, endpoint_identity_)
        || !same_identity(effects_fd_, effects_identity_)
        || !same_identity(meta_fd_, meta_identity_)) {
        detail = "retained directory identity changed";
        return false;
    }
    detail = "retained root and child fd identities unchanged";
    return true;
}

PathCampaignReport run_path_campaign(const std::filesystem::path& campaign) {
    PathCampaignReport report{};
    std::error_code ec;
    std::filesystem::remove_all(campaign, ec);
    std::filesystem::create_directories(campaign, ec);
    if (ec) {
        report.detail = "create campaign: " + ec.message();
        return report;
    }
    std::ofstream table(campaign / "path-custody.tsv",
                        std::ios::binary | std::ios::trunc);
    table << "case\texpected\tobserved\tstatus\n";
    auto record = [&](const char* name, const char* expected,
                      const bool pass, const std::string& observed) {
        ++report.cases;
        if (pass) ++report.passed;
        table << name << '\t' << expected << '\t' << observed << '\t'
              << (pass ? "PASS" : "FAIL") << '\n';
    };

    std::string detail;
    const auto real = std::filesystem::absolute(campaign / "real");
    if (!create_layout(real, detail)) {
        report.detail = detail;
        return report;
    }
    const auto link = campaign / "root-link";
    std::filesystem::create_directory_symlink(real, link, ec);
    std::string open_detail;
    const auto through_link = RootedStore::open(
        std::filesystem::absolute(link), open_detail);
    record("root-symlink", "reject", !through_link.has_value(), open_detail);

    const auto real_parent = campaign / "real-parent";
    if (!create_layout(real_parent / "store", detail)) {
        report.detail = detail;
        return report;
    }
    const auto alias = campaign / "parent-link";
    std::filesystem::create_directory_symlink(real_parent, alias, ec);
    open_detail.clear();
    const auto ancestor_link = RootedStore::open(
        std::filesystem::absolute(alias / "store"), open_detail);
    record("ancestor-symlink", "reject", !ancestor_link.has_value(),
           open_detail);

    const auto child_case = std::filesystem::absolute(campaign / "child-case");
    if (!create_layout(child_case, detail)) {
        report.detail = detail;
        return report;
    }
    std::filesystem::remove(child_case / "journal", ec);
    std::filesystem::create_directory_symlink(child_case / "install",
                                               child_case / "journal", ec);
    open_detail.clear();
    const auto child_link = RootedStore::open(child_case, open_detail);
    record("fixed-child-symlink", "reject", !child_link.has_value(),
           open_detail);

    const auto stable = std::filesystem::absolute(campaign / "stable");
    if (!create_layout(stable, detail)) {
        report.detail = detail;
        return report;
    }
    auto store = RootedStore::open(stable, open_detail);
    if (!store.has_value()) {
        report.detail = open_detail;
        return report;
    }
    const auto payload = bytes("ROOTED-PAYLOAD\n");
    std::string op;
    const bool dotdot = !store->replace(Area::journal, "..", payload, op);
    record("dotdot-leaf", "reject", dotdot, op);
    const bool slash = !store->replace(Area::journal, "a/b", payload, op);
    record("slash-leaf", "reject", slash, op);
    const bool absolute = !store->replace(Area::journal, "/tmp/x", payload, op);
    record("absolute-leaf", "reject", absolute, op);

    std::filesystem::create_symlink("/proc/self/fd/0",
                                    stable / "journal" / "magic", ec);
    const FileRead magic = store->read(Area::journal, "magic", 128U);
    record("magic-or-leaf-symlink", "reject", !magic.ok, magic.detail);

    const RootIdentity captured = store->root_identity();
    const auto moved = campaign / "stable-moved";
    std::filesystem::rename(stable, moved, ec);
    if (!create_layout(stable, detail)) {
        report.detail = detail;
        return report;
    }
    const bool wrote_moved = store->replace(
        Area::journal, "current.bin", payload, op);
    const bool old_has = std::filesystem::exists(moved / "journal/current.bin");
    const bool decoy_has = std::filesystem::exists(stable / "journal/current.bin");
    record("root-path-rebind", "retained-fd-target",
           wrote_moved && old_has && !decoy_has && captured.inode != 0U, op);

    const auto child_old = moved / "journal-old";
    std::filesystem::rename(moved / "journal", child_old, ec);
    std::filesystem::create_directory(moved / "journal", ec);
    std::filesystem::permissions(moved / "journal",
        std::filesystem::perms::owner_all,
        std::filesystem::perm_options::replace, ec);
    const auto child_payload = bytes("CHILD-FD-PAYLOAD\n");
    const bool wrote_child = store->replace(
        Area::journal, "child.bin", child_payload, op);
    record("child-path-rebind", "retained-child-fd-target",
           wrote_child && std::filesystem::exists(child_old / "child.bin")
               && !std::filesystem::exists(moved / "journal/child.bin"), op);

    const auto exact = bytes("IMMUTABLE\n");
    const CreateStatus first = store->create_no_replace(
        Area::effects, "effect.bin", exact, op);
    const CreateStatus second = store->create_no_replace(
        Area::effects, "effect.bin", exact, op);
    record("exact-incumbent", "created-then-exact",
           first == CreateStatus::created
               && second == CreateStatus::exact_incumbent, op);
    const auto wrong = bytes("WRONG\n");
    const CreateStatus conflict = store->create_no_replace(
        Area::effects, "effect.bin", wrong, op);
    record("wrong-incumbent", "conflict",
           conflict == CreateStatus::conflict, op);

    const bool identities = store->identities_unchanged(op);
    record("retained-identities", "unchanged", identities, op);

    report.ok = table.good() && report.cases == report.passed
        && report.cases == 12U;
    report.detail = report.ok
        ? "openat2 all-component rooted profile and fd-rebind campaign passed"
        : "path campaign failure";
    return report;
}

}  // namespace slopos::e0::fence::host
