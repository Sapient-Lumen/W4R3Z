# Close rev0938

From `CANDIDATE/epoch-zero/rev0938`:

```sh
rm -rf build
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
./run-gates.sh "/mnt/data/slopos-rev0938-work/extract/SlopOS-rev0938-2026.08.07.00.35-configuredexpectation-sealedobservation-predecessorgate-selfpinningcut" "/mnt/data/SlopOS-rev0937-2026.08.06.21.19-rootedshadowpack-exactinverse-racefence-aliasaddress.zip"
```

From the cube root, verify the manifest after excluding the manifest and closure files as
specified by `manifests/MANIFEST-SCOPE.md`. Record all return codes in `closure/gates.json`.

A closer may update evidence and test results, but must not change `epoch_decision` to leave
Epoch Zero without an owner-originated authority act and a separately reviewable receipt.
