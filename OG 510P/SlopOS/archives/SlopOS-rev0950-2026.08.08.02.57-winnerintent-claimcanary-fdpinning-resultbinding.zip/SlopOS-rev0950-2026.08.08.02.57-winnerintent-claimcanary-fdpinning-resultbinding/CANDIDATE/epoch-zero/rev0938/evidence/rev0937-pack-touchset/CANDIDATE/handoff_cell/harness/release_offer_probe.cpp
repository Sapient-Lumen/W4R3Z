#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <fcntl.h>
#include <linux/memfd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef SO_PASSPIDFD
#define SO_PASSPIDFD 76
#endif
#ifndef SO_PEERPIDFD
#define SO_PEERPIDFD 77
#endif
#ifndef SCM_PIDFD
#define SCM_PIDFD 0x04
#endif

namespace {

constexpr std::string_view kReady{"SLOPOS-E0-SEALED-READY-V1"};
constexpr std::string_view kOffer{"SLOPOS-E0-SEALED-OFFER-V1"};
constexpr std::string_view kFixture{"rev0901-host-sealed-snapshot-fixture"};
constexpr int kRequiredSeals =
    F_SEAL_WRITE | F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_SEAL;

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() { if (value >= 0) (void)::close(value); }
    [[nodiscard]] int get() const noexcept { return value; }
    [[nodiscard]] int release() noexcept {
        const int result = value;
        value = -1;
        return result;
    }
};

struct Identity final {
    std::uint64_t device{0U};
    std::uint64_t inode{0U};
    [[nodiscard]] bool valid() const noexcept { return inode != 0U; }
    friend bool operator==(const Identity&, const Identity&) = default;
};

struct OfferReport final {
    int socket_seqpacket{0};
    int passcred_enabled{0};
    int passpidfd_enabled{0};
    int peer_credentials_observed{0};
    int peer_pidfd_observed{0};
    int receiver_preoffer_candidate_aliases_zero{0};
    int ready_sent{0};
    int message_received{0};
    int data_truncated{0};
    int control_truncated{0};
    int payload_exact{0};
    int credential_count{0};
    int pidfd_count{0};
    int rights_record_count{0};
    int rights_count{0};
    int unknown_control{0};
    int credentials_equal{0};
    int pidfd_equal{0};
    int candidate_cloexec{0};
    int candidate_readable{0};
    int candidate_regular{0};
    int candidate_unlinked{0};
    int seal_query_supported{0};
    int full_seals{0};
    int size_bounded{0};
    int candidate_bytes_read{0};
    int laboratory_mechanism_ready{0};
    int actor_admitted_before_ready{0};
    int unadmitted_rights_installed{0};
    int production_ingress_ready{0};
};

struct CaseRow final {
    std::string name;
    bool observed{false};
    bool expected{false};
    std::string proves;
    std::string does_not_prove;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* bool_text(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] int make_memfd(const char* name) {
    const long raw = ::syscall(
        SYS_memfd_create, name,
        static_cast<unsigned int>(MFD_CLOEXEC | MFD_ALLOW_SEALING));
    if (raw < 0 || raw > static_cast<long>(INT32_MAX)) return -1;
    return static_cast<int>(raw);
}

void write_all(const int fd, const void* const bytes,
               const std::size_t size) {
    const auto* data = static_cast<const std::byte*>(bytes);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::write(fd, data + offset, size - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "write fixture");
        offset += static_cast<std::size_t>(count);
    }
}

void read_all(const int fd, void* const bytes, const std::size_t size) {
    auto* data = static_cast<std::byte*>(bytes);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::read(fd, data + offset, size - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "read report");
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] UniqueFd sealed_fixture() {
    UniqueFd fd(make_memfd("slopos-rev0901-offer"));
    require(fd.get() >= 0, "memfd_create sealed fixture");
    write_all(fd.get(), kFixture.data(), kFixture.size());
    require(::fcntl(fd.get(), F_ADD_SEALS, kRequiredSeals) == 0,
            "install required seals");
    return fd;
}

[[nodiscard]] bool fully_sealed_write_only_descriptor_reproduced(
    const int source_fd) {
    const std::string path = "/proc/self/fd/" + std::to_string(source_fd);
    UniqueFd write_only(::open(path.c_str(), O_WRONLY | O_CLOEXEC));
    require(write_only.get() >= 0, "open write-only sealed counterproof");
    const int status_flags = ::fcntl(write_only.get(), F_GETFL);
    require(status_flags >= 0, "get write-only status flags");
    const bool write_only_mode = (status_flags & O_ACCMODE) == O_WRONLY;
    struct stat status {};
    require(::fstat(write_only.get(), &status) == 0,
            "fstat write-only sealed counterproof");
    const int seals = ::fcntl(write_only.get(), F_GET_SEALS);
    errno = 0;
    char byte{};
    const ssize_t read_count = ::pread(write_only.get(), &byte, 1U, 0);
    const bool read_rejected = read_count == -1 && errno == EBADF;
    return write_only_mode
        && S_ISREG(status.st_mode)
        && status.st_nlink == 0
        && seals >= 0
        && (seals & kRequiredSeals) == kRequiredSeals
        && read_rejected;
}

[[nodiscard]] Identity identity_of(const int fd) noexcept {
    Identity result;
    struct stat status {};
    if (::fstat(fd, &status) == 0) {
        result.device = static_cast<std::uint64_t>(status.st_dev);
        result.inode = static_cast<std::uint64_t>(status.st_ino);
    }
    return result;
}

[[nodiscard]] bool send_packet(const int fd, const std::string_view packet) {
    ssize_t count = -1;
    do {
        count = ::send(fd, packet.data(), packet.size(), MSG_NOSIGNAL);
    } while (count < 0 && errno == EINTR);
    return count == static_cast<ssize_t>(packet.size());
}

[[nodiscard]] bool recv_exact_packet(const int fd,
                                     const std::string_view expected) {
    std::array<char, 128U> bytes{};
    ssize_t count = -1;
    do {
        count = ::recv(fd, bytes.data(), bytes.size(), 0);
    } while (count < 0 && errno == EINTR);
    return count == static_cast<ssize_t>(expected.size())
        && std::equal(expected.begin(), expected.end(), bytes.begin());
}

[[nodiscard]] bool send_offer(const int fd, const int offered_fd,
                              const bool send_two = false) {
    alignas(struct cmsghdr)
    std::array<char, CMSG_SPACE(sizeof(int) * 2U)> control{};
    iovec vector{const_cast<char*>(kOffer.data()), kOffer.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = send_two
        ? CMSG_SPACE(sizeof(int) * 2U) : CMSG_SPACE(sizeof(int));
    cmsghdr* item = CMSG_FIRSTHDR(&header);
    if (item == nullptr) return false;
    item->cmsg_level = SOL_SOCKET;
    item->cmsg_type = SCM_RIGHTS;
    item->cmsg_len = send_two
        ? CMSG_LEN(sizeof(int) * 2U) : CMSG_LEN(sizeof(int));
    std::array<int, 2U> fds{{offered_fd, offered_fd}};
    std::memcpy(CMSG_DATA(item), fds.data(),
                send_two ? sizeof(int) * 2U : sizeof(int));
    ssize_t count = -1;
    do {
        count = ::sendmsg(fd, &header, MSG_NOSIGNAL);
    } while (count < 0 && errno == EINTR);
    return count == static_cast<ssize_t>(kOffer.size());
}

void close_all(std::vector<int>& fds) noexcept {
    for (const int fd : fds) if (fd >= 0) (void)::close(fd);
    fds.clear();
}

// Deliberately unsafe laboratory ordering. This fixture sends READY and calls
// recvmsg() before any external actor-admission premise exists. It is retained
// only to prove that a post-receive admission check is too late: SCM_RIGHTS has
// already installed capabilities in the receiver by then. This is not a
// production ingress adapter.
[[nodiscard]] OfferReport receive_unadmitted_offer_counterproof(
    const int fd, const bool receiver_preoffer_candidate_aliases_zero) {
    OfferReport result;
    result.receiver_preoffer_candidate_aliases_zero =
        receiver_preoffer_candidate_aliases_zero ? 1 : 0;
    int socket_type = 0;
    socklen_t socket_type_size = sizeof(socket_type);
    result.socket_seqpacket =
        ::getsockopt(fd, SOL_SOCKET, SO_TYPE,
                     &socket_type, &socket_type_size) == 0
        && socket_type_size == sizeof(socket_type)
        && socket_type == SOCK_SEQPACKET ? 1 : 0;

    const int enabled = 1;
    result.passcred_enabled =
        ::setsockopt(fd, SOL_SOCKET, SO_PASSCRED,
                     &enabled, sizeof(enabled)) == 0 ? 1 : 0;
    result.passpidfd_enabled =
        ::setsockopt(fd, SOL_SOCKET, SO_PASSPIDFD,
                     &enabled, sizeof(enabled)) == 0 ? 1 : 0;

    struct ucred peer_credential {};
    socklen_t peer_credential_size = sizeof(peer_credential);
    result.peer_credentials_observed =
        ::getsockopt(fd, SOL_SOCKET, SO_PEERCRED,
                     &peer_credential, &peer_credential_size) == 0
        && peer_credential_size == sizeof(peer_credential) ? 1 : 0;

    int peer_pidfd = -1;
    socklen_t peer_pidfd_size = sizeof(peer_pidfd);
    result.peer_pidfd_observed =
        ::getsockopt(fd, SOL_SOCKET, SO_PEERPIDFD,
                     &peer_pidfd, &peer_pidfd_size) == 0
        && peer_pidfd_size == sizeof(peer_pidfd)
        && peer_pidfd >= 0 ? 1 : 0;
    UniqueFd peer_process(peer_pidfd);
    const Identity peer_identity = identity_of(peer_process.get());

    result.ready_sent = send_packet(fd, kReady) ? 1 : 0;

    std::array<char, 128U> bytes{};
    alignas(struct cmsghdr)
    std::array<std::byte,
        CMSG_SPACE(sizeof(struct ucred)) + CMSG_SPACE(sizeof(int))
        + CMSG_SPACE(sizeof(int) * 4U)> control{};
    iovec vector{bytes.data(), bytes.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    ssize_t count = -1;
    do {
        count = ::recvmsg(fd, &header, MSG_CMSG_CLOEXEC);
    } while (count < 0 && errno == EINTR);
    result.message_received = count >= 0 ? 1 : 0;
    if (count < 0) return result;
    result.data_truncated = (header.msg_flags & MSG_TRUNC) != 0 ? 1 : 0;
    result.control_truncated = (header.msg_flags & MSG_CTRUNC) != 0 ? 1 : 0;
    result.payload_exact =
        count == static_cast<ssize_t>(kOffer.size())
        && std::equal(kOffer.begin(), kOffer.end(), bytes.begin()) ? 1 : 0;

    struct ucred message_credential {};
    Identity message_identity;
    std::vector<int> received_fds;
    std::vector<int> received_pidfds;
    for (cmsghdr* item = CMSG_FIRSTHDR(&header); item != nullptr;
         item = CMSG_NXTHDR(&header, item)) {
        if (item->cmsg_level == SOL_SOCKET
            && item->cmsg_type == SCM_CREDENTIALS
            && item->cmsg_len == CMSG_LEN(sizeof(struct ucred))) {
            ++result.credential_count;
            if (result.credential_count == 1) {
                std::memcpy(&message_credential, CMSG_DATA(item),
                            sizeof(message_credential));
            }
        } else if (item->cmsg_level == SOL_SOCKET
                   && item->cmsg_type == SCM_PIDFD
                   && item->cmsg_len == CMSG_LEN(sizeof(int))) {
            int message_pidfd = -1;
            std::memcpy(&message_pidfd, CMSG_DATA(item), sizeof(message_pidfd));
            ++result.pidfd_count;
            if (message_pidfd >= 0) {
                received_pidfds.push_back(message_pidfd);
                if (result.pidfd_count == 1) {
                    message_identity = identity_of(message_pidfd);
                }
            } else {
                result.unknown_control = 1;
            }
        } else if (item->cmsg_level == SOL_SOCKET
                   && item->cmsg_type == SCM_RIGHTS
                   && item->cmsg_len >= CMSG_LEN(sizeof(int))) {
            ++result.rights_record_count;
            const std::size_t payload = item->cmsg_len - CMSG_LEN(0U);
            if (payload % sizeof(int) != 0U) {
                result.unknown_control = 1;
                continue;
            }
            const std::size_t count_fds = payload / sizeof(int);
            for (std::size_t index = 0U; index < count_fds; ++index) {
                int received_fd = -1;
                std::memcpy(&received_fd,
                            CMSG_DATA(item) + index * sizeof(int),
                            sizeof(received_fd));
                received_fds.push_back(received_fd);
                ++result.rights_count;
            }
        } else {
            result.unknown_control = 1;
        }
    }

    result.credentials_equal =
        result.peer_credentials_observed != 0
        && result.credential_count == 1
        && peer_credential.pid == message_credential.pid
        && peer_credential.uid == message_credential.uid
        && peer_credential.gid == message_credential.gid ? 1 : 0;
    result.pidfd_equal =
        result.peer_pidfd_observed != 0
        && result.pidfd_count == 1
        && peer_identity.valid()
        && message_identity == peer_identity ? 1 : 0;

    if (result.rights_count == 1
        && result.credential_count == 1
        && result.pidfd_count == 1
        && result.unknown_control == 0
        && result.data_truncated == 0
        && result.control_truncated == 0
        && result.payload_exact != 0
        && result.credentials_equal != 0
        && result.pidfd_equal != 0) {
        const int candidate = received_fds.front();
        const int descriptor_flags = ::fcntl(candidate, F_GETFD);
        result.candidate_cloexec =
            descriptor_flags >= 0 && (descriptor_flags & FD_CLOEXEC) != 0
            ? 1 : 0;
        const int status_flags = ::fcntl(candidate, F_GETFL);
        bool candidate_readable = false;
        if (status_flags >= 0) {
            const int access_mode = status_flags & O_ACCMODE;
            candidate_readable =
                access_mode == O_RDONLY || access_mode == O_RDWR;
#ifdef O_PATH
            candidate_readable = candidate_readable
                && (status_flags & O_PATH) == 0;
#endif
        }
        result.candidate_readable = candidate_readable ? 1 : 0;
        struct stat status {};
        if (::fstat(candidate, &status) == 0) {
            result.candidate_regular = S_ISREG(status.st_mode) ? 1 : 0;
            result.candidate_unlinked = status.st_nlink == 0 ? 1 : 0;
            result.size_bounded =
                status.st_size >= 0
                && static_cast<std::uint64_t>(status.st_size)
                    <= UINT64_C(33554432) ? 1 : 0;
        }
        errno = 0;
        const int seals = ::fcntl(candidate, F_GET_SEALS);
        result.seal_query_supported = seals >= 0 ? 1 : 0;
        result.full_seals =
            seals >= 0 && (seals & kRequiredSeals) == kRequiredSeals ? 1 : 0;
    }
    result.candidate_bytes_read = 0;
    result.actor_admitted_before_ready = 0;
    result.unadmitted_rights_installed =
        result.actor_admitted_before_ready == 0
        && result.rights_count > 0 ? 1 : 0;
    result.laboratory_mechanism_ready =
        result.receiver_preoffer_candidate_aliases_zero != 0
        && result.socket_seqpacket != 0
        && result.passcred_enabled != 0
        && result.passpidfd_enabled != 0
        && result.peer_credentials_observed != 0
        && result.peer_pidfd_observed != 0
        && result.ready_sent != 0
        && result.message_received != 0
        && result.data_truncated == 0
        && result.control_truncated == 0
        && result.payload_exact != 0
        && result.credential_count == 1
        && result.pidfd_count == 1
        && result.rights_record_count == 1
        && result.rights_count == 1
        && result.unknown_control == 0
        && result.credentials_equal != 0
        && result.pidfd_equal != 0
        && result.candidate_cloexec != 0
        && result.candidate_readable != 0
        && result.candidate_regular != 0
        && result.candidate_unlinked != 0
        && result.seal_query_supported != 0
        && result.full_seals != 0
        && result.size_bounded != 0 ? 1 : 0;
    result.production_ingress_ready =
        result.actor_admitted_before_ready != 0
        && result.laboratory_mechanism_ready != 0 ? 1 : 0;
    close_all(received_fds);
    close_all(received_pidfds);
    return result;
}

[[nodiscard]] OfferReport cross_process_unadmitted_offer_counterproof() {
    int sockets[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC,
                         0, sockets) == 0,
            "socketpair offer");
    UniqueFd actor_socket(sockets[0]);
    UniqueFd receiver_socket(sockets[1]);
    int report_pipe[2]{};
    require(::pipe2(report_pipe, O_CLOEXEC) == 0, "report pipe");
    UniqueFd report_reader(report_pipe[0]);
    UniqueFd report_writer(report_pipe[1]);
    const pid_t child = ::fork();
    require(child >= 0, "fork receiver");
    if (child == 0) {
        actor_socket = UniqueFd{};
        report_reader = UniqueFd{};
        OfferReport report;
        try {
            report = receive_unadmitted_offer_counterproof(
                receiver_socket.get(), true);
        } catch (...) {
            report = OfferReport{};
        }
        const int writer = report_writer.get();
        const auto* bytes = reinterpret_cast<const std::byte*>(&report);
        std::size_t offset = 0U;
        while (offset < sizeof(report)) {
            const ssize_t count = ::write(
                writer, bytes + offset, sizeof(report) - offset);
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) _exit(121);
            offset += static_cast<std::size_t>(count);
        }
        _exit(0);
    }
    receiver_socket = UniqueFd{};
    report_writer = UniqueFd{};
    // Create the offered object only after fork. The receiver therefore cannot
    // have inherited an alias to this candidate before READY.
    UniqueFd candidate = sealed_fixture();
    require(recv_exact_packet(actor_socket.get(), kReady), "receive ready");
    require(send_offer(actor_socket.get(), candidate.get()), "send offer");
    OfferReport report;
    read_all(report_reader.get(), &report, sizeof(report));
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait receiver");
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "receiver exit status");
    return report;
}

[[nodiscard]] bool fork_inherited_candidate_alias_observed(
    const int candidate_fd) {
    const Identity expected = identity_of(candidate_fd);
    require(expected.valid(), "candidate identity before fork");
    int report_pipe[2]{};
    require(::pipe2(report_pipe, O_CLOEXEC) == 0,
            "fork alias report pipe");
    UniqueFd reader(report_pipe[0]);
    UniqueFd writer(report_pipe[1]);
    const pid_t child = ::fork();
    require(child >= 0, "fork alias counterproof");
    if (child == 0) {
        reader = UniqueFd{};
        const bool inherited = identity_of(candidate_fd) == expected;
        const unsigned char result = inherited ? 1U : 0U;
        write_all(writer.get(), &result, sizeof(result));
        _exit(inherited ? 0 : 122);
    }
    writer = UniqueFd{};
    unsigned char result = 0U;
    read_all(reader.get(), &result, sizeof(result));
    int status = 0;
    require(::waitpid(child, &status, 0) == child,
            "wait fork alias counterproof");
    return result == 1U && WIFEXITED(status) && WEXITSTATUS(status) == 0;
}

[[nodiscard]] std::vector<int> receive_rights(const int fd,
                                              const int flags,
                                              bool& control_truncated) {
    std::array<char, 128U> bytes{};
    alignas(struct cmsghdr)
    std::array<std::byte, CMSG_SPACE(sizeof(int) * 4U)> control{};
    iovec vector{bytes.data(), bytes.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    ssize_t count = -1;
    do {
        count = ::recvmsg(fd, &header, flags | MSG_CMSG_CLOEXEC);
    } while (count < 0 && errno == EINTR);
    require(count >= 0, "receive rights");
    control_truncated = (header.msg_flags & MSG_CTRUNC) != 0;
    std::vector<int> result;
    for (cmsghdr* item = CMSG_FIRSTHDR(&header); item != nullptr;
         item = CMSG_NXTHDR(&header, item)) {
        if (item->cmsg_level == SOL_SOCKET && item->cmsg_type == SCM_RIGHTS) {
            const std::size_t payload = item->cmsg_len - CMSG_LEN(0U);
            require(payload % sizeof(int) == 0U, "rights payload shape");
            const std::size_t count_fds = payload / sizeof(int);
            for (std::size_t index = 0U; index < count_fds; ++index) {
                int received_fd = -1;
                std::memcpy(&received_fd,
                            CMSG_DATA(item) + index * sizeof(int),
                            sizeof(received_fd));
                result.push_back(received_fd);
            }
        }
    }
    return result;
}

[[nodiscard]] bool msg_peek_duplicates_rights(const int candidate_fd) {
    int sockets[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC,
                         0, sockets) == 0,
            "socketpair peek");
    UniqueFd sender(sockets[0]);
    UniqueFd receiver(sockets[1]);
    require(send_offer(sender.get(), candidate_fd), "send peek offer");
    bool first_truncated = false;
    bool second_truncated = false;
    std::vector<int> first = receive_rights(
        receiver.get(), MSG_PEEK, first_truncated);
    std::vector<int> second = receive_rights(
        receiver.get(), 0, second_truncated);
    const bool result = !first_truncated && !second_truncated
        && first.size() == 1U && second.size() == 1U
        && identity_of(first.front()) == identity_of(second.front())
        && identity_of(first.front()) == identity_of(candidate_fd)
        && first.front() != second.front();
    close_all(first);
    close_all(second);
    return result;
}

[[nodiscard]] bool two_rights_observed(const int candidate_fd) {
    int sockets[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC,
                         0, sockets) == 0,
            "socketpair two rights");
    UniqueFd sender(sockets[0]);
    UniqueFd receiver(sockets[1]);
    require(send_offer(sender.get(), candidate_fd, true), "send two rights");
    bool truncated = false;
    std::vector<int> received = receive_rights(receiver.get(), 0, truncated);
    const bool result = !truncated && received.size() == 2U;
    close_all(received);
    return result;
}

[[nodiscard]] bool control_truncation_observed(const int candidate_fd) {
    int sockets[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC,
                         0, sockets) == 0,
            "socketpair truncation");
    UniqueFd sender(sockets[0]);
    UniqueFd receiver(sockets[1]);
    require(send_offer(sender.get(), candidate_fd), "send truncation offer");
    std::array<char, 128U> bytes{};
    iovec vector{bytes.data(), bytes.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    ssize_t count = -1;
    do {
        count = ::recvmsg(receiver.get(), &header, MSG_CMSG_CLOEXEC);
    } while (count < 0 && errno == EINTR);
    require(count >= 0, "receive truncation offer");
    return (header.msg_flags & MSG_CTRUNC) != 0;
}

void write_outputs(const std::filesystem::path& output,
                   const std::vector<CaseRow>& cases,
                   const std::vector<CounterexampleRow>& counterexamples,
                   const OfferReport& report,
                   const bool write_only_sealed_rejected) {
    std::ofstream case_stream(output / "release-offer-cases.tsv",
                              std::ios::binary);
    require(case_stream.good(), "open release-offer-cases.tsv");
    case_stream << "case\tobserved\texpected\tpass\tproves\tdoes_not_prove\n";
    for (const CaseRow& row : cases) {
        case_stream << row.name << '\t' << bool_text(row.observed) << '\t'
                    << bool_text(row.expected) << '\t'
                    << bool_text(row.observed == row.expected) << '\t'
                    << row.proves << '\t' << row.does_not_prove << '\n';
    }
    std::ofstream counter_stream(
        output / "release-offer-counterexamples.tsv", std::ios::binary);
    require(counter_stream.good(), "open release-offer-counterexamples.tsv");
    counter_stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : counterexamples) {
        counter_stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
                       << row.defeats << '\t' << row.retained_law << '\n';
    }
    std::ofstream summary(output / "release-offer-summary.json",
                          std::ios::binary);
    require(summary.good(), "open release-offer-summary.json");
    summary
        << "{\n"
        << "  \"acquisition_actor_admitted_before_ready\": false,\n"
        << "  \"actor_admission_precedes_rights_import\": false,\n"
        << "  \"archive_digest_compared\": false,\n"
        << "  \"archive_parsed\": false,\n"
        << "  \"candidate_bytes_read_before_validation\": false,\n"
        << "  \"candidate_readable_observed\": "
        << bool_text(report.candidate_readable != 0) << ",\n"
        << "  \"cases\": " << cases.size() << ",\n"
        << "  \"counterexamples_reproduced\": "
        << counterexamples.size() << ",\n"
        << "  \"exact_ancillary_shape\": "
        << bool_text(report.credential_count == 1
                     && report.pidfd_count == 1
                     && report.rights_record_count == 1
                     && report.rights_count == 1
                     && report.unknown_control == 0) << ",\n"
        << "  \"fork_inherited_candidate_alias_reproduced\": true,\n"
        << "  \"full_seals_observed\": "
        << bool_text(report.full_seals != 0) << ",\n"
        << "  \"candidate_memfd_creation_provenance_proved\": false,\n"
        << "  \"laboratory_mechanism_ready\": "
        << bool_text(report.laboratory_mechanism_ready != 0) << ",\n"
        << "  \"msg_peek_rights_duplication_reproduced\": true,\n"
        << "  \"one_use_transfer_proved\": false,\n"
        << "  \"owner_custody_proved\": false,\n"
        << "  \"peer_message_credentials_equal\": "
        << bool_text(report.credentials_equal != 0) << ",\n"
        << "  \"peer_message_pidfd_equal\": "
        << bool_text(report.pidfd_equal != 0) << ",\n"
        << "  \"receiver_preoffer_candidate_aliases_zero\": "
        << bool_text(report.receiver_preoffer_candidate_aliases_zero != 0)
        << ",\n"
        << "  \"production_ingress_ready\": "
        << bool_text(report.production_ingress_ready != 0) << ",\n"
        << "  \"provider_operation_authority\": false,\n"
        << "  \"schema\": \"slopos.rev0901.release-offer-host-probe.v2\",\n"
        << "  \"source_provenance_proved\": false,\n"
        << "  \"unadmitted_rights_installed\": "
        << bool_text(report.unadmitted_rights_installed != 0) << ",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"write_only_sealed_descriptor_rejected\": "
        << bool_text(write_only_sealed_rejected) << "\n"
        << "}\n";
}

}  // namespace

int main(const int argc, char** argv) {
    try {
        require(argc == 2, "usage: slopos_release_offer_probe OUTPUT");
        const std::filesystem::path output(argv[1]);
        require(std::filesystem::is_directory(output), "output directory");

        const OfferReport report =
            cross_process_unadmitted_offer_counterproof();
        UniqueFd sealed = sealed_fixture();
        const bool fork_inherited_alias =
            fork_inherited_candidate_alias_observed(sealed.get());
        errno = 0;
        constexpr char changed{'X'};
        const bool retained_writer_rejected =
            ::pwrite(sealed.get(), &changed, 1U, 0) == -1 && errno == EPERM;
        const bool peek_duplicate = msg_peek_duplicates_rights(sealed.get());
        const bool multiple_rights = two_rights_observed(sealed.get());
        const bool control_truncated = control_truncation_observed(sealed.get());
        const bool write_only_sealed_rejected =
            fully_sealed_write_only_descriptor_reproduced(sealed.get());

        UniqueFd unsealed(make_memfd("slopos-rev0901-unsealed"));
        require(unsealed.get() >= 0, "unsealed memfd");
        write_all(unsealed.get(), kFixture.data(), kFixture.size());
        const int unsealed_seals = ::fcntl(unsealed.get(), F_GET_SEALS);
        const bool unsealed_rejected = unsealed_seals >= 0
            && (unsealed_seals & kRequiredSeals) != kRequiredSeals;

        const auto linked_path = output / ".rev0901-linked-offer-fixture";
        UniqueFd linked(::open(linked_path.c_str(),
                               O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC, 0600));
        require(linked.get() >= 0, "linked regular fixture");
        struct stat linked_status {};
        require(::fstat(linked.get(), &linked_status) == 0,
                "fstat linked regular fixture");
        const bool linked_regular_rejected =
            S_ISREG(linked_status.st_mode) && linked_status.st_nlink != 0;
        require(::unlink(linked_path.c_str()) == 0,
                "unlink linked regular fixture");

        int stream_pair[2]{};
        require(::socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC,
                             0, stream_pair) == 0,
                "stream socketpair");
        UniqueFd stream_a(stream_pair[0]);
        UniqueFd stream_b(stream_pair[1]);
        int stream_type = 0;
        socklen_t stream_type_size = sizeof(stream_type);
        const bool stream_rejected =
            ::getsockopt(stream_b.get(), SOL_SOCKET, SO_TYPE,
                         &stream_type, &stream_type_size) == 0
            && stream_type == SOCK_STREAM && stream_type != SOCK_SEQPACKET;

        const std::vector<CaseRow> cases{
            {"socket_seqpacket", report.socket_seqpacket != 0, true,
             "exact message boundary", "actor governance"},
            {"passcred_enabled", report.passcred_enabled != 0, true,
             "automatic per-message credentials available", "owner policy"},
            {"passpidfd_enabled", report.passpidfd_enabled != 0, true,
             "automatic per-message pidfd available", "closed privileged administration"},
            {"peer_credentials_observed", report.peer_credentials_observed != 0, true,
             "socket creation credential coordinate", "future sender identity alone"},
            {"peer_pidfd_observed", report.peer_pidfd_observed != 0, true,
             "socket creation process instance coordinate", "owner admission"},
            {"receiver_preoffer_candidate_aliases_zero",
             report.receiver_preoffer_candidate_aliases_zero != 0, true,
             "offered object was created after receiver fork",
             "exclusive custody outside the receiver"},
            {"ready_sent_before_offer", report.ready_sent != 0, true,
             "receiver profile precedes offer", "source provenance"},
            {"one_message_received", report.message_received != 0, true,
             "one bounded offer arrival", "global one-use"},
            {"data_not_truncated", report.data_truncated == 0, true,
             "complete protocol frame", "candidate digest"},
            {"control_not_truncated", report.control_truncated == 0, true,
             "complete ancillary envelope", "exclusive custody"},
            {"payload_exact", report.payload_exact != 0, true,
             "fixed protocol payload", "archive identity"},
            {"exactly_one_credential", report.credential_count == 1, true,
             "credential cardinality", "owner policy"},
            {"exactly_one_pidfd", report.pidfd_count == 1, true,
             "process cardinality", "non-forgeability against root"},
            {"exactly_one_rights_record", report.rights_record_count == 1, true,
             "SCM_RIGHTS control-record cardinality", "descriptor cardinality"},
            {"exactly_one_rights_descriptor", report.rights_count == 1, true,
             "delivered descriptor cardinality", "one-use transfer"},
            {"no_unknown_control", report.unknown_control == 0, true,
             "closed ancillary vocabulary", "provenance"},
            {"peer_message_credentials_equal", report.credentials_equal != 0, true,
             "creation/message credential agreement", "admitted actor"},
            {"peer_message_pidfd_equal", report.pidfd_equal != 0, true,
             "creation/message process-instance agreement", "admitted actor"},
            {"candidate_cloexec", report.candidate_cloexec != 0, true,
             "received descriptor is close-on-exec", "byte identity"},
            {"candidate_readable", report.candidate_readable != 0, true,
             "received descriptor access mode can feed pread", "archive identity"},
            {"candidate_regular", report.candidate_regular != 0, true,
             "regular descriptor shape", "immutability alone"},
            {"candidate_unlinked", report.candidate_unlinked != 0, true,
             "no filesystem pathname alias", "exclusive open-file-description custody"},
            {"seal_query_supported", report.seal_query_supported != 0, true,
             "inode seal profile observable", "release provenance"},
            {"all_required_seals", report.full_seals != 0, true,
             "write/grow/shrink/seal barrier", "durable media"},
            {"size_bounded", report.size_bounded != 0, true,
             "resource bound before body read", "archive semantics"},
            {"candidate_body_unread", report.candidate_bytes_read == 0, true,
             "all envelope checks precede candidate bytes", "digest equality"},
            {"laboratory_mechanism_ready", report.laboratory_mechanism_ready != 0, true,
             "host can exhibit the bounded descriptor profile", "production admission"},
            {"actor_not_admitted_before_ready",
             report.actor_admitted_before_ready != 0, false,
             "synthetic host probe remains governance-negative", "living acquisition office"},
            {"unadmitted_rights_installed",
             report.unadmitted_rights_installed != 0, true,
             "post-receive admission is too late to prevent capability import",
             "permission to retain or inspect the descriptor"},
            {"production_ingress_ready", report.production_ingress_ready != 0, false,
             "laboratory counterproof cannot cross the V13 production boundary",
             "admitted acquisition ingress"},
            {"retained_writer_rejected", retained_writer_rejected, true,
             "F_SEAL_WRITE revokes writes through retained fd", "source provenance"},
            {"fork_inherited_candidate_alias_observed", fork_inherited_alias, true,
             "creating a candidate before fork preinstalls a receiver alias",
             "first ingress through SCM_RIGHTS"},
            {"msg_peek_duplicates_rights", peek_duplicate, true,
             "SCM_RIGHTS is duplicable even for one packet", "one-use spend"},
            {"multiple_rights_observable", multiple_rights, true,
             "ancillary cardinality must be checked", "harmless extra capabilities"},
            {"control_truncation_observable", control_truncated, true,
             "MSG_CTRUNC is a real fail-closed branch", "partial envelope safety"},
            {"stream_socket_rejected", stream_rejected, true,
             "SOCK_STREAM is outside the profile", "message framing"},
            {"unsealed_memfd_rejected", unsealed_rejected, true,
             "memfd shape alone is insufficient", "immutable bytes"},
            {"linked_regular_rejected", linked_regular_rejected, true,
             "linked regular files remain outside the profile", "namespace writer exclusion"},
            {"fully_sealed_write_only_descriptor_rejected",
             write_only_sealed_rejected, true,
             "complete seals do not imply readable descriptor access",
             "pread-capable source readiness"},
        };
        const std::vector<CounterexampleRow> counterexamples{
            {"fork_inheritance_preinstalls_candidate_alias",
             fork_inherited_alias,
             "claim that every post-fork SCM_RIGHTS receive is first receiver ingress",
             "create the offered object after receiver fork or prove zero aliases"},
            {"scm_rights_sender_retains_descriptor", true,
             "claim that sendmsg consumes the sender descriptor",
             "descriptor transfer is duplication, never spend"},
            {"msg_peek_installs_duplicate_rights", peek_duplicate,
             "claim that one packet can install rights only once",
             "never derive one-use from transport"},
            {"multiple_rights_single_cmsg", multiple_rights,
             "claim that one SCM_RIGHTS record means one descriptor",
             "count descriptors, not just control records"},
            {"control_buffer_absent_sets_msg_ctrunc", control_truncated,
             "claim that payload may be used without ancillary capacity",
             "reject MSG_CTRUNC before any candidate read"},
            {"stream_socket_has_wrong_type", stream_rejected,
             "claim that AF_UNIX alone preserves an offer boundary",
             "require SOCK_SEQPACKET"},
            {"unsealed_memfd_remains_writable", unsealed_rejected,
             "claim that memfd identity implies immutable content",
             "require all four seals"},
            {"linked_regular_has_namespace_alias", linked_regular_rejected,
             "claim that regular shape excludes namespace writers",
             "require nlink zero"},
            {"peer_coordinate_is_not_actor_admission",
             report.laboratory_mechanism_ready != 0,
             "claim that matching kernel coordinates establish governance",
             "actor admission remains an external premise"},
            {"post_receive_actor_check_imports_unadmitted_capability",
             report.unadmitted_rights_installed != 0,
             "claim that actor admission may be checked after recvmsg",
             "admit the actor before READY and every rights-bearing receive"},
            {"sealed_snapshot_is_not_digest_match", report.full_seals != 0,
             "claim that immutability establishes expected archive bytes",
             "V11 digest recomputation remains mandatory"},
            {"seal_profile_is_not_creator_provenance", report.full_seals != 0,
             "claim that present inode seals prove memfd_create history or creator identity",
             "treat the seal profile as present behavior, not provenance"},
            {"sealed_snapshot_is_not_durable_media", report.full_seals != 0,
             "claim that shmem survives host loss",
             "retain durable-media nonclaim"},
            {"host_probe_is_not_living_office",
             report.actor_admitted_before_ready == 0,
             "claim that a synthetic fork constitutes an admitted acquisition actor",
             "remain in Epoch Zero"},
            {"full_seal_profile_does_not_imply_readable_access",
             write_only_sealed_rejected,
             "claim that an unlinked fully sealed regular descriptor is necessarily readable",
             "require F_GETFL access mode suitable for pread and reject O_PATH"},
        };
        require(cases.size() == 39U, "host offer case inventory");
        require(counterexamples.size() == 15U,
                "host offer counterexample inventory");
        require(std::all_of(cases.begin(), cases.end(),
                            [](const CaseRow& row) {
                                return row.observed == row.expected;
                            }),
                "host offer case failure");
        require(std::all_of(counterexamples.begin(), counterexamples.end(),
                            [](const CounterexampleRow& row) {
                                return row.reproduced;
                            }),
                "host offer counterexample failure");
        write_outputs(output, cases, counterexamples, report,
                      write_only_sealed_rejected);
        std::cout
            << "RELEASE_OFFER_PROBE=PASS cases=" << cases.size()
            << " counterexamples=" << counterexamples.size()
            << " laboratory_mechanism_ready="
            << bool_text(report.laboratory_mechanism_ready != 0)
            << " actor_admitted_before_ready=false"
            << " unadmitted_rights_installed="
            << bool_text(report.unadmitted_rights_installed != 0)
            << " production_ingress_ready=false candidate_bytes_read=0"
            << " candidate_readable=true write_only_sealed_rejected="
            << bool_text(write_only_sealed_rejected)
            << " peek_duplicate=" << bool_text(peek_duplicate) << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "RELEASE_OFFER_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
