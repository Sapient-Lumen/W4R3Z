#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "launch_query_campaign.hpp"

#include "slopos/e0/generation_journal/record.hpp"
#include "slopos/e0/handoff_cell/fixed_result_query.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <grp.h>
#include <linux/close_range.h>
#include <poll.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

constexpr uid_t kProviderUid = 21001U;
constexpr gid_t kProviderGid = 21001U;
constexpr uid_t kWrongQueryUid = 21002U;
constexpr gid_t kWrongQueryGid = 21002U;
constexpr uid_t kQueryUid = 21003U;
constexpr gid_t kQueryGid = 21003U;

constexpr int kExecFd = 3;
constexpr int kRootFd = 4;
constexpr int kQueryFd = 5;
constexpr int kReportFd = 6;
constexpr int kUnexpectedFd = 7;
constexpr int kTimeoutMilliseconds = 250;

constexpr std::size_t kRequestBytes = 16U;
constexpr std::size_t kResponseHeaderBytes = 16U;
constexpr std::size_t kResponseBytes =
    kResponseHeaderBytes + generation_journal::kRecordBytes;

constexpr std::uint8_t kResponseExact = 1U;
constexpr std::uint8_t kResponseRejectedCredentials = 2U;
constexpr std::uint8_t kResponseRejectedRights = 3U;
constexpr std::uint8_t kResponseRejectedMalformed = 4U;
constexpr std::uint8_t kResponseInternalError = 5U;

constexpr std::string_view kProviderWorker = "__slopos_e0_provider_query_worker";
constexpr std::string_view kQueryWorker = "__slopos_e0_query_actor_worker";
constexpr std::string_view kProbeWorker = "__slopos_e0_descriptor_probe_worker";

struct ScopedFd final {
    int value{-1};
    ScopedFd() = default;
    explicit ScopedFd(const int fd) noexcept : value(fd) {}
    ScopedFd(const ScopedFd&) = delete;
    ScopedFd& operator=(const ScopedFd&) = delete;
    ScopedFd(ScopedFd&& other) noexcept
        : value(std::exchange(other.value, -1)) {}
    ScopedFd& operator=(ScopedFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = std::exchange(other.value, -1);
        }
        return *this;
    }
    ~ScopedFd() { if (value >= 0) (void)::close(value); }
    [[nodiscard]] int get() const noexcept { return value; }
    [[nodiscard]] int release() noexcept { return std::exchange(value, -1); }
};

struct WorkerReport final {
    std::int32_t role{0};
    std::int32_t mode{0};
    std::int32_t uid_ok{0};
    std::int32_t gid_ok{0};
    std::int32_t groups_empty{0};
    std::int32_t no_new_privs{0};
    std::int32_t capability_sets_zero{0};
    std::int32_t descriptor_topology_exact{0};
    std::int32_t exec_fd_closed{0};
    std::int32_t root_fd_valid{0};
    std::int32_t query_fd_valid{0};
    std::int32_t report_fd_valid{0};
    std::int32_t unexpected_fd_open{0};
    std::int32_t peer_uid{-1};
    std::int32_t peer_gid{-1};
    std::int32_t peer_is_root_creator{0};
    std::int32_t passcred_enabled{0};
    std::int32_t ready_credentials_exact{0};
    std::int32_t valid_requests{0};
    std::int32_t credential_rejections{0};
    std::int32_t rights_rejections{0};
    std::int32_t malformed_rejections{0};
    std::int32_t timeouts{0};
    std::int32_t rights_received{0};
    std::int32_t topology_restored_after_rights{0};
    std::int32_t fixed_query_disposition{-1};
    std::int32_t exact_response{0};
    std::int32_t response_credentials_exact{0};
    std::int32_t forged_credentials_errno{0};
    std::int32_t service_completed{0};
};

struct Message final {
    std::vector<std::uint8_t> bytes{};
    bool received{false};
    bool truncated{false};
    bool control_truncated{false};
    bool credential_present{false};
    bool unexpected_control{false};
    std::size_t credential_count{0U};
    struct ucred credential{};
    std::vector<int> received_fds{};
};

struct LaunchRow final {
    std::string name;
    std::string observation;
    bool passed{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

struct PairReports final {
    WorkerReport provider{};
    WorkerReport query{};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void close_or_exit(const int fd, const int code) noexcept {
    if (fd >= 0 && ::close(fd) != 0) _exit(code);
}

[[nodiscard]] bool send_complete(const int fd, const void* data,
                                 const std::size_t size) noexcept {
    const auto* bytes = static_cast<const std::uint8_t*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::send(fd, bytes + offset, size - offset,
                                     MSG_NOSIGNAL);
        if (count < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (count == 0) return false;
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[nodiscard]] bool receive_complete(const int fd, void* data,
                                    const std::size_t size) noexcept {
    auto* bytes = static_cast<std::uint8_t*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::recv(fd, bytes + offset, size - offset, 0);
        if (count < 0) {
            if (errno == EINTR) continue;
            return false;
        }
        if (count == 0) return false;
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[noreturn]] void report_and_exit(const WorkerReport& report,
                                  const int exit_code) noexcept {
    const bool sent = send_complete(kReportFd, &report, sizeof(report));
    close_or_exit(kReportFd, 119);
    _exit(sent ? exit_code : 118);
}

[[nodiscard]] std::array<std::uint8_t, 32U> binding(
    const std::uint8_t base) noexcept {
    std::array<std::uint8_t, 32U> value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] EncodedRecord expected_result_v2() noexcept {
    Record record;
    record.kind = RecordKind::result;
    record.sequence = 2U;
    record.generation_from = 41U;
    record.generation_to = 42U;
    record.operation_binding = binding(1U);
    record.spent_receipt_binding = binding(161U);
    record.result = Result::effect;
    record.consumed_dispatch = true;
    record.reconciled = true;
    EncodedRecord encoded{};
    if (!generation_journal::encode_record(record, encoded)) encoded.fill(0U);
    return encoded;
}

[[nodiscard]] std::array<std::uint8_t, kRequestBytes> exact_request() noexcept {
    std::array<std::uint8_t, kRequestBytes> request{};
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'Q', 'R', 'Y', '1'}};
    std::copy(magic.begin(), magic.end(), request.begin());
    request[8U] = 1U;
    request[9U] = 2U;
    return request;
}

[[nodiscard]] bool is_exact_request(
    const std::vector<std::uint8_t>& bytes) noexcept {
    const auto expected = exact_request();
    return bytes.size() == expected.size()
        && std::equal(expected.begin(), expected.end(), bytes.begin());
}

[[nodiscard]] std::array<std::uint8_t, kResponseBytes> make_response(
    const std::uint8_t disposition,
    const EncodedRecord* record = nullptr) noexcept {
    std::array<std::uint8_t, kResponseBytes> response{};
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'R', 'S', 'P', '1'}};
    std::copy(magic.begin(), magic.end(), response.begin());
    response[8U] = disposition;
    if (record != nullptr) {
        std::copy(record->begin(), record->end(),
                  response.begin() + static_cast<std::ptrdiff_t>(
                      kResponseHeaderBytes));
    }
    return response;
}

[[nodiscard]] bool response_is(
    const Message& message, const std::uint8_t disposition,
    const EncodedRecord* expected = nullptr) noexcept {
    if (message.truncated || message.control_truncated
        || message.bytes.size() != kResponseBytes) return false;
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'R', 'S', 'P', '1'}};
    if (!std::equal(magic.begin(), magic.end(), message.bytes.begin())
        || message.bytes[8U] != disposition) return false;
    for (std::size_t index = 9U; index < kResponseHeaderBytes; ++index) {
        if (message.bytes[index] != 0U) return false;
    }
    const auto record_begin = message.bytes.begin()
        + static_cast<std::ptrdiff_t>(kResponseHeaderBytes);
    if (expected == nullptr) {
        return std::all_of(record_begin, message.bytes.end(),
                           [](const std::uint8_t value) { return value == 0U; });
    }
    return std::equal(expected->begin(), expected->end(), record_begin);
}

[[nodiscard]] bool poll_readable(const int fd,
                                 const int timeout_milliseconds) noexcept {
    pollfd descriptor{fd, POLLIN, 0};
    int result = -1;
    do {
        result = ::poll(&descriptor, 1U, timeout_milliseconds);
    } while (result < 0 && errno == EINTR);
    return result == 1 && (descriptor.revents & POLLIN) != 0;
}

[[nodiscard]] Message receive_message(const int fd,
                                      const std::size_t maximum_bytes,
                                      const int timeout_milliseconds) noexcept {
    Message result;
    if (!poll_readable(fd, timeout_milliseconds)) return result;
    result.bytes.resize(maximum_bytes);
    std::array<std::uint8_t,
        CMSG_SPACE(sizeof(struct ucred)) + CMSG_SPACE(sizeof(int) * 8U)> control{};
    iovec vector{result.bytes.data(), result.bytes.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    ssize_t count = -1;
    do {
        count = ::recvmsg(fd, &header, MSG_CMSG_CLOEXEC);
    } while (count < 0 && errno == EINTR);
    if (count < 0) {
        result.bytes.clear();
        return result;
    }
    result.received = true;
    result.bytes.resize(static_cast<std::size_t>(count));
    result.truncated = (header.msg_flags & MSG_TRUNC) != 0;
    result.control_truncated = (header.msg_flags & MSG_CTRUNC) != 0;
    for (cmsghdr* item = CMSG_FIRSTHDR(&header); item != nullptr;
         item = CMSG_NXTHDR(&header, item)) {
        if (item->cmsg_level == SOL_SOCKET
            && item->cmsg_type == SCM_CREDENTIALS
            && item->cmsg_len == CMSG_LEN(sizeof(struct ucred))) {
            ++result.credential_count;
            if (result.credential_count != 1U) {
                result.unexpected_control = true;
                continue;
            }
            std::memcpy(&result.credential, CMSG_DATA(item),
                        sizeof(result.credential));
            result.credential_present = true;
        } else if (item->cmsg_level == SOL_SOCKET
                   && item->cmsg_type == SCM_RIGHTS
                   && item->cmsg_len >= CMSG_LEN(sizeof(int))) {
            const std::size_t payload = item->cmsg_len - CMSG_LEN(0U);
            if (payload % sizeof(int) != 0U) {
                result.unexpected_control = true;
                continue;
            }
            const std::size_t count_fds = payload / sizeof(int);
            const auto* fds = reinterpret_cast<const int*>(CMSG_DATA(item));
            for (std::size_t index = 0U; index < count_fds; ++index) {
                result.received_fds.push_back(fds[index]);
            }
        } else {
            result.unexpected_control = true;
        }
    }
    return result;
}

void close_received_fds(Message& message) noexcept {
    for (const int fd : message.received_fds) {
        if (fd >= 0) (void)::close(fd);
    }
    message.received_fds.clear();
}

[[nodiscard]] bool send_with_rights(
    const int fd, const std::array<std::uint8_t, kRequestBytes>& request,
    const int sent_fd) noexcept {
    std::array<std::uint8_t, CMSG_SPACE(sizeof(int))> control{};
    iovec vector{const_cast<std::uint8_t*>(request.data()), request.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    cmsghdr* item = CMSG_FIRSTHDR(&header);
    if (item == nullptr) return false;
    item->cmsg_level = SOL_SOCKET;
    item->cmsg_type = SCM_RIGHTS;
    item->cmsg_len = CMSG_LEN(sizeof(int));
    std::memcpy(CMSG_DATA(item), &sent_fd, sizeof(sent_fd));
    ssize_t result = -1;
    do {
        result = ::sendmsg(fd, &header, MSG_NOSIGNAL);
    } while (result < 0 && errno == EINTR);
    return result == static_cast<ssize_t>(request.size());
}

[[nodiscard]] int forged_credential_send_errno(const int fd) noexcept {
    const auto request = exact_request();
    std::array<std::uint8_t, CMSG_SPACE(sizeof(struct ucred))> control{};
    iovec vector{const_cast<std::uint8_t*>(request.data()), request.size()};
    msghdr header{};
    header.msg_iov = &vector;
    header.msg_iovlen = 1U;
    header.msg_control = control.data();
    header.msg_controllen = control.size();
    cmsghdr* item = CMSG_FIRSTHDR(&header);
    if (item == nullptr) return EINVAL;
    item->cmsg_level = SOL_SOCKET;
    item->cmsg_type = SCM_CREDENTIALS;
    item->cmsg_len = CMSG_LEN(sizeof(struct ucred));
    const struct ucred forged{
        ::getpid(), kProviderUid, kProviderGid};
    std::memcpy(CMSG_DATA(item), &forged, sizeof(forged));
    ssize_t result = -1;
    do {
        result = ::sendmsg(fd, &header, MSG_NOSIGNAL);
    } while (result < 0 && errno == EINTR);
    if (result >= 0) return 0;
    return errno;
}

[[nodiscard]] bool fd_is_open(const int fd) noexcept {
    errno = 0;
    return ::fcntl(fd, F_GETFD) >= 0 || errno != EBADF;
}

[[nodiscard]] bool fd_is_directory(const int fd,
                                   const uid_t owner) noexcept {
    struct stat status {};
    return ::fstat(fd, &status) == 0 && S_ISDIR(status.st_mode)
        && status.st_uid == owner;
}

[[nodiscard]] bool fd_is_seqpacket(const int fd) noexcept {
    int type = 0;
    socklen_t length = sizeof(type);
    return ::getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &length) == 0
        && length == sizeof(type) && type == SOCK_SEQPACKET;
}

[[nodiscard]] std::set<int> descriptor_inventory() noexcept {
    std::set<int> result;
    DIR* directory = ::opendir("/proc/self/fd");
    if (directory == nullptr) return result;
    const int inventory_fd = ::dirfd(directory);
    for (;;) {
        errno = 0;
        dirent* entry = ::readdir(directory);
        if (entry == nullptr) break;
        std::string_view name(entry->d_name);
        int value = -1;
        const auto parsed = std::from_chars(
            name.data(), name.data() + name.size(), value);
        if (parsed.ec == std::errc{}
            && parsed.ptr == name.data() + name.size()
            && value != inventory_fd) {
            result.insert(value);
        }
    }
    (void)::closedir(directory);
    return result;
}

[[nodiscard]] bool all_capability_sets_zero() noexcept {
    std::ifstream stream("/proc/self/status");
    if (!stream) return false;
    std::set<std::string> seen;
    std::string line;
    while (std::getline(stream, line)) {
        const auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        const std::string key = line.substr(0U, colon);
        if (key != "CapInh" && key != "CapPrm" && key != "CapEff"
            && key != "CapBnd" && key != "CapAmb") continue;
        const auto first = line.find_first_not_of(" \t", colon + 1U);
        if (first == std::string::npos) return false;
        const std::string value = line.substr(first);
        if (value.find_first_not_of("0\r") != std::string::npos) return false;
        seen.insert(key);
    }
    return seen.size() == 5U;
}

[[nodiscard]] WorkerReport base_report(const bool provider_role) noexcept {
    WorkerReport report;
    report.role = provider_role ? 1 : 2;
    const uid_t expected_uid = provider_role ? kProviderUid : ::geteuid();
    const gid_t expected_gid = provider_role ? kProviderGid : ::getegid();
    // Check real, effective, and saved identities explicitly; no null-argument
    // probe is part of the evidence path.
    uid_t real_uid = 0U;
    uid_t effective_uid = 0U;
    uid_t saved_uid = 0U;
    gid_t real_gid = 0U;
    gid_t effective_gid = 0U;
    gid_t saved_gid = 0U;
    report.uid_ok = ::getresuid(&real_uid, &effective_uid, &saved_uid) == 0
        && real_uid == expected_uid && effective_uid == expected_uid
        && saved_uid == expected_uid ? 1 : 0;
    report.gid_ok = ::getresgid(&real_gid, &effective_gid, &saved_gid) == 0
        && real_gid == expected_gid && effective_gid == expected_gid
        && saved_gid == expected_gid ? 1 : 0;
    report.groups_empty = ::getgroups(0, nullptr) == 0 ? 1 : 0;
    report.no_new_privs = ::prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L) == 1
        ? 1 : 0;
    report.capability_sets_zero = all_capability_sets_zero() ? 1 : 0;
    report.exec_fd_closed = !fd_is_open(kExecFd) ? 1 : 0;
    report.root_fd_valid = provider_role
        ? (fd_is_directory(kRootFd, kProviderUid) ? 1 : 0)
        : (!fd_is_open(kRootFd) ? 1 : 0);
    report.query_fd_valid = fd_is_seqpacket(kQueryFd) ? 1 : 0;
    report.report_fd_valid = fd_is_seqpacket(kReportFd) ? 1 : 0;
    report.unexpected_fd_open = fd_is_open(kUnexpectedFd) ? 1 : 0;
    const std::set<int> expected = provider_role
        ? std::set<int>{0, 1, 2, kRootFd, kQueryFd, kReportFd}
        : std::set<int>{0, 1, 2, kQueryFd, kReportFd};
    report.descriptor_topology_exact = descriptor_inventory() == expected
        ? 1 : 0;
    struct ucred peer {};
    socklen_t peer_length = sizeof(peer);
    if (::getsockopt(kQueryFd, SOL_SOCKET, SO_PEERCRED,
                     &peer, &peer_length) == 0
        && peer_length == sizeof(peer)) {
        report.peer_uid = static_cast<std::int32_t>(peer.uid);
        report.peer_gid = static_cast<std::int32_t>(peer.gid);
        report.peer_is_root_creator = peer.uid == 0U && peer.gid == 0U ? 1 : 0;
    }
    const int enabled = 1;
    report.passcred_enabled = ::setsockopt(
        kQueryFd, SOL_SOCKET, SO_PASSCRED, &enabled, sizeof(enabled)) == 0
        ? 1 : 0;
    return report;
}

[[nodiscard]] bool exact_sender(const Message& message,
                                const uid_t uid,
                                const gid_t gid) noexcept {
    return message.credential_present
        && message.credential_count == 1U
        && !message.unexpected_control
        && message.credential.uid == uid
        && message.credential.gid == gid;
}

[[nodiscard]] bool send_response(const std::uint8_t disposition,
                                 const EncodedRecord* record = nullptr) noexcept {
    const auto response = make_response(disposition, record);
    return ::send(kQueryFd, response.data(), response.size(), MSG_NOSIGNAL)
        == static_cast<ssize_t>(response.size());
}

[[nodiscard]] int provider_worker(const std::string_view mode) noexcept {
    WorkerReport report = base_report(true);
    report.mode = mode == "valid" ? 1 : mode == "wrong" ? 2
                : mode == "timeout" ? 3 : 0;
    if (report.passcred_enabled != 1) report_and_exit(report, 40);
    const std::uint8_t ready = static_cast<std::uint8_t>('R');
    if (::send(kQueryFd, &ready, 1U, MSG_NOSIGNAL) != 1) {
        report_and_exit(report, 41);
    }

    const int request_count = mode == "valid" ? 3 : 1;
    for (int index = 0; index < request_count; ++index) {
        Message message = receive_message(
            kQueryFd, kRequestBytes, kTimeoutMilliseconds);
        if (!message.received) {
            ++report.timeouts;
            if (mode == "timeout") {
                report.service_completed = 1;
                report_and_exit(report, 0);
            }
            report_and_exit(report, 42);
        }
        const bool sender_ok = exact_sender(message, kQueryUid, kQueryGid);
        if (!sender_ok) {
            ++report.credential_rejections;
            close_received_fds(message);
            if (!send_response(kResponseRejectedCredentials)) {
                report_and_exit(report, 43);
            }
            continue;
        }
        if (!message.received_fds.empty() || message.control_truncated
            || message.unexpected_control) {
            report.rights_received += static_cast<std::int32_t>(
                message.received_fds.size());
            close_received_fds(message);
            ++report.rights_rejections;
            const std::set<int> expected{
                0, 1, 2, kRootFd, kQueryFd, kReportFd};
            report.topology_restored_after_rights =
                descriptor_inventory() == expected ? 1 : 0;
            if (!send_response(kResponseRejectedRights)) {
                report_and_exit(report, 44);
            }
            continue;
        }
        if (message.truncated || !is_exact_request(message.bytes)) {
            ++report.malformed_rejections;
            if (!send_response(kResponseRejectedMalformed)) {
                report_and_exit(report, 45);
            }
            continue;
        }
        ++report.valid_requests;
        int error_number = 0;
        auto query = FixedResultQuery::open_fixed_beneath(
            kRootFd, kProviderUid, error_number);
        if (!query.has_value()) {
            report.fixed_query_disposition = -2;
            (void)send_response(kResponseInternalError);
            report_and_exit(report, 46);
        }
        const FixedQueryResult result = query->read_exact_result_v2();
        report.fixed_query_disposition = static_cast<std::int32_t>(
            result.disposition);
        if (!result.exact() || !send_response(kResponseExact, &result.encoded)) {
            report_and_exit(report, 47);
        }
    }
    report.service_completed = 1;
    report_and_exit(report, 0);
}

[[nodiscard]] Message receive_expected_response() noexcept {
    return receive_message(kQueryFd, kResponseBytes, 2000);
}

[[nodiscard]] int query_worker(const std::string_view mode) noexcept {
    WorkerReport report = base_report(false);
    report.mode = mode == "valid" ? 1 : 2;
    if (report.passcred_enabled != 1) report_and_exit(report, 50);

    Message ready = receive_message(kQueryFd, 1U, 2000);
    report.ready_credentials_exact =
        ready.bytes.size() == 1U
        && ready.bytes[0U] == static_cast<std::uint8_t>('R')
        && exact_sender(ready, kProviderUid, kProviderGid)
        && ready.received_fds.empty() && !ready.truncated
        && !ready.control_truncated ? 1 : 0;
    close_received_fds(ready);
    if (report.ready_credentials_exact != 1) report_and_exit(report, 51);

    if (mode == "valid") {
        report.forged_credentials_errno = forged_credential_send_errno(kQueryFd);
        const auto request = exact_request();
        if (::send(kQueryFd, request.data(), request.size(), MSG_NOSIGNAL)
            != static_cast<ssize_t>(request.size())) {
            report_and_exit(report, 52);
        }
        Message exact = receive_expected_response();
        const EncodedRecord expected = expected_result_v2();
        report.exact_response = response_is(
            exact, kResponseExact, &expected) ? 1 : 0;
        report.response_credentials_exact = exact_sender(
            exact, kProviderUid, kProviderGid) ? 1 : 0;
        close_received_fds(exact);
        if (report.exact_response != 1
            || report.response_credentials_exact != 1) {
            report_and_exit(report, 53);
        }

        if (!send_with_rights(kQueryFd, request, 0)) report_and_exit(report, 54);
        Message rights = receive_expected_response();
        const bool rights_ok = response_is(
            rights, kResponseRejectedRights)
            && exact_sender(rights, kProviderUid, kProviderGid)
            && rights.received_fds.empty();
        close_received_fds(rights);
        if (!rights_ok) report_and_exit(report, 55);

        const std::uint8_t malformed = 0x51U;
        if (::send(kQueryFd, &malformed, 1U, MSG_NOSIGNAL) != 1) {
            report_and_exit(report, 56);
        }
        Message malformed_response = receive_expected_response();
        const bool malformed_ok = response_is(
            malformed_response, kResponseRejectedMalformed)
            && exact_sender(malformed_response, kProviderUid, kProviderGid)
            && malformed_response.received_fds.empty();
        close_received_fds(malformed_response);
        if (!malformed_ok) report_and_exit(report, 57);
        report.service_completed = 1;
        report_and_exit(report, 0);
    }

    const auto request = exact_request();
    if (::send(kQueryFd, request.data(), request.size(), MSG_NOSIGNAL)
        != static_cast<ssize_t>(request.size())) {
        report_and_exit(report, 58);
    }
    Message rejected = receive_expected_response();
    const bool rejected_ok = response_is(
        rejected, kResponseRejectedCredentials)
        && exact_sender(rejected, kProviderUid, kProviderGid)
        && rejected.received_fds.empty();
    close_received_fds(rejected);
    report.response_credentials_exact = rejected_ok ? 1 : 0;
    report.service_completed = rejected_ok ? 1 : 0;
    report_and_exit(report, rejected_ok ? 0 : 59);
}

[[nodiscard]] int probe_worker() noexcept {
    WorkerReport report = base_report(true);
    report.mode = 4;
    report.service_completed = report.descriptor_topology_exact == 0
        && report.unexpected_fd_open == 1 ? 1 : 0;
    report_and_exit(report, report.service_completed == 1 ? 0 : 60);
}

[[nodiscard]] int duplicate_high(const int fd) noexcept {
    return ::fcntl(fd, F_DUPFD_CLOEXEC, 64);
}

void duplicate_fixed_or_exit(const int source, const int destination,
                             const int flags, const int code) noexcept {
    if (::dup3(source, destination, flags) < 0) _exit(code);
}

void drop_bounding_set_or_exit() noexcept {
    for (int capability = 0; capability < 1024; ++capability) {
        errno = 0;
        const int present = ::prctl(PR_CAPBSET_READ,
                                    static_cast<unsigned long>(capability),
                                    0UL, 0UL, 0UL);
        if (present < 0 && errno == EINVAL) return;
        if (present < 0) _exit(70);
        if (present == 1
            && ::prctl(PR_CAPBSET_DROP,
                       static_cast<unsigned long>(capability),
                       0UL, 0UL, 0UL) != 0) {
            _exit(71);
        }
    }
    _exit(72);
}

void launch_child_or_exit(const std::string_view worker,
                          const std::string_view mode,
                          const int root_fd,
                          const int query_fd,
                          const int report_fd,
                          const int unexpected_fd,
                          const uid_t uid,
                          const gid_t gid,
                          const bool preserve_unexpected) noexcept {
    const int executable = ::open("/proc/self/exe", O_PATH | O_CLOEXEC);
    if (executable < 0) _exit(73);
    const int executable_high = duplicate_high(executable);
    const int root_high = root_fd >= 0 ? duplicate_high(root_fd) : -1;
    const int query_high = duplicate_high(query_fd);
    const int report_high = duplicate_high(report_fd);
    const int unexpected_high = preserve_unexpected
        ? duplicate_high(unexpected_fd) : -1;
    const int null_high = ::open("/dev/null", O_RDWR | O_CLOEXEC);
    if (executable_high < 0 || (root_fd >= 0 && root_high < 0)
        || query_high < 0 || report_high < 0
        || (preserve_unexpected && unexpected_high < 0)
        || null_high < 0) {
        _exit(74);
    }

    duplicate_fixed_or_exit(null_high, 0, 0, 75);
    duplicate_fixed_or_exit(null_high, 1, 0, 76);
    duplicate_fixed_or_exit(null_high, 2, 0, 77);
    duplicate_fixed_or_exit(executable_high, kExecFd, O_CLOEXEC, 78);
    if (root_fd >= 0) {
        duplicate_fixed_or_exit(root_high, kRootFd, 0, 79);
    } else if (::close(kRootFd) != 0 && errno != EBADF) {
        _exit(80);
    }
    duplicate_fixed_or_exit(query_high, kQueryFd, 0, 81);
    duplicate_fixed_or_exit(report_high, kReportFd, 0, 82);
    if (preserve_unexpected) {
        duplicate_fixed_or_exit(unexpected_high, kUnexpectedFd, 0, 83);
    }

#if defined(SYS_close_range)
    const unsigned int first = preserve_unexpected ? 8U : 7U;
    if (::syscall(SYS_close_range, first, ~0U,
                  static_cast<unsigned int>(CLOSE_RANGE_UNSHARE)) != 0) {
        _exit(84);
    }
#else
    _exit(85);
#endif

    (void)::umask(0077);
    drop_bounding_set_or_exit();
    if (::setgroups(0U, nullptr) != 0) _exit(86);
    if (::setresgid(gid, gid, gid) != 0) _exit(87);
    if (::setresuid(uid, uid, uid) != 0) _exit(88);
    if (::prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) != 0) _exit(89);

    std::string worker_text(worker);
    std::string mode_text(mode);
    std::array<char*, 4U> arguments{{
        const_cast<char*>("slopos_handoff_cell"),
        worker_text.data(), mode_text.data(), nullptr}};
    std::array<char*, 1U> environment{{nullptr}};
#if defined(SYS_execveat)
    (void)::syscall(SYS_execveat, kExecFd, "", arguments.data(),
                    environment.data(), AT_EMPTY_PATH);
#endif
    _exit(90);
}

[[nodiscard]] WorkerReport receive_report(const int fd,
                                          const std::string& label) {
    WorkerReport report;
    require(receive_complete(fd, &report, sizeof(report)),
            "receive worker report " + label);
    return report;
}

void wait_success(const pid_t child, const std::string& label) {
    int status = 0;
    require(::waitpid(child, &status, 0) == child,
            "wait worker " + label);
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "worker exit " + label + " status=" + std::to_string(status));
}

[[nodiscard]] pid_t fork_worker(const std::string_view worker,
                                const std::string_view mode,
                                const int root_fd,
                                const int query_fd,
                                const int report_fd,
                                const int unexpected_fd,
                                const uid_t uid,
                                const gid_t gid,
                                const bool preserve_unexpected) {
    const pid_t child = ::fork();
    require(child >= 0, "fork launch-query worker");
    if (child == 0) {
        launch_child_or_exit(worker, mode, root_fd, query_fd, report_fd,
                             unexpected_fd, uid, gid,
                             preserve_unexpected);
    }
    return child;
}

void enable_passcred_or_fail(const int fd, const std::string& label) {
    const int enabled = 1;
    require(::setsockopt(fd, SOL_SOCKET, SO_PASSCRED, &enabled,
                         sizeof(enabled)) == 0,
            "enable SO_PASSCRED " + label);
}

[[nodiscard]] PairReports run_pair(const int root_fd,
                                   const bool wrong_query) {
    int channel[2]{};
    int provider_report[2]{};
    int query_report[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         channel) == 0, "query socketpair");
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         provider_report) == 0, "provider report socketpair");
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         query_report) == 0, "query report socketpair");
    enable_passcred_or_fail(channel[0], "provider endpoint");
    enable_passcred_or_fail(channel[1], "query endpoint");

    const pid_t provider = fork_worker(
        kProviderWorker, wrong_query ? "wrong" : "valid",
        root_fd, channel[0], provider_report[1], -1,
        kProviderUid, kProviderGid, false);
    const uid_t query_uid = wrong_query ? kWrongQueryUid : kQueryUid;
    const gid_t query_gid = wrong_query ? kWrongQueryGid : kQueryGid;
    const pid_t query = fork_worker(
        kQueryWorker, wrong_query ? "wrong" : "valid",
        -1, channel[1], query_report[1], -1,
        query_uid, query_gid, false);

    for (const int fd : {channel[0], channel[1], provider_report[1],
                         query_report[1]}) {
        require(::close(fd) == 0, "close child endpoint in parent");
    }
    PairReports reports;
    reports.provider = receive_report(provider_report[0], "provider");
    reports.query = receive_report(query_report[0], "query");
    require(::close(provider_report[0]) == 0, "close provider report parent");
    require(::close(query_report[0]) == 0, "close query report parent");
    wait_success(provider, "provider");
    wait_success(query, "query");
    return reports;
}

[[nodiscard]] WorkerReport run_timeout(const int root_fd) {
    int channel[2]{};
    int report_pair[2]{};
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         channel) == 0, "timeout query socketpair");
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         report_pair) == 0, "timeout report socketpair");
    const pid_t provider = fork_worker(
        kProviderWorker, "timeout", root_fd, channel[0], report_pair[1], -1,
        kProviderUid, kProviderGid, false);
    require(::close(channel[0]) == 0, "close timeout provider endpoint");
    require(::close(report_pair[1]) == 0, "close timeout report child endpoint");
    const WorkerReport report = receive_report(report_pair[0], "timeout");
    require(::close(report_pair[0]) == 0, "close timeout report parent");
    require(::close(channel[1]) == 0, "close timeout idle peer");
    wait_success(provider, "timeout-provider");
    return report;
}

[[nodiscard]] WorkerReport run_bad_descriptor_probe(const int root_fd) {
    int channel[2]{};
    int report_pair[2]{};
    const ScopedFd unexpected(::open("/dev/null", O_RDWR | O_CLOEXEC));
    require(unexpected.get() >= 0, "open unexpected descriptor");
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         channel) == 0, "probe query socketpair");
    require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                         report_pair) == 0, "probe report socketpair");
    const pid_t probe = fork_worker(
        kProbeWorker, "bad-close-range", root_fd, channel[0], report_pair[1],
        unexpected.get(), kProviderUid, kProviderGid, true);
    require(::close(channel[0]) == 0, "close probe child endpoint");
    require(::close(channel[1]) == 0, "close probe peer endpoint");
    require(::close(report_pair[1]) == 0, "close probe report child endpoint");
    const WorkerReport report = receive_report(report_pair[0], "probe");
    require(::close(report_pair[0]) == 0, "close probe report parent");
    wait_success(probe, "descriptor-probe");
    return report;
}

void write_rows(const std::filesystem::path& output,
                const std::vector<LaunchRow>& rows) {
    std::ofstream stream(output / "launch-query-cases.tsv", std::ios::binary);
    require(stream.good(), "open launch-query-cases.tsv");
    stream << "name\tobservation\tpassed\tretained_counterexample\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << row.observation << '\t'
               << bool_text(row.passed) << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
    require(stream.good(), "write launch-query-cases.tsv");
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "launch-query-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open launch-query-counterexamples.tsv");
    stream << "name\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
    require(stream.good(), "write launch-query-counterexamples.tsv");
}

void write_summary(const std::filesystem::path& output,
                   const std::size_t cases,
                   const std::size_t counterexamples) {
    std::ofstream stream(output / "launch-query-summary.json",
                         std::ios::binary);
    require(stream.good(), "open launch-query-summary.json");
    stream
        << "{\n"
        << "  \"administration_plane_closed\": false,\n"
        << "  \"authority_granted\": false,\n"
        << "  \"bounded_query_timeout_milliseconds\": "
        << kTimeoutMilliseconds << ",\n"
        << "  \"capability_bounding_set_empty\": true,\n"
        << "  \"cases\": " << cases << ",\n"
        << "  \"close_range_unshare_used\": true,\n"
        << "  \"counterexamples_reproduced\": " << counterexamples << ",\n"
        << "  \"exact_descriptor_tables_observed\": 2,\n"
        << "  \"exact_result_v2_returned\": true,\n"
        << "  \"execveat_empty_path_used\": true,\n"
        << "  \"fixed_query_mutation_entrypoints\": 0,\n"
        << "  \"independent_actor\": false,\n"
        << "  \"privileged_credential_forgery_closed\": false,\n"
        << "  \"provider_authenticated\": false,\n"
        << "  \"provider_uid\": " << kProviderUid << ",\n"
        << "  \"query_uid\": " << kQueryUid << ",\n"
        << "  \"schema\": \"slopos.rev0889.handoff-launch-query-evidence.v1\",\n"
        << "  \"scm_credentials_per_message_observed\": true,\n"
        << "  \"scm_rights_injection_rejected\": true,\n"
        << "  \"so_peercred_creation_time_counterexample\": true,\n"
        << "  \"source_to_binary_proved\": false,\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"wrong_query_uid\": " << kWrongQueryUid << "\n"
        << "}\n";
    require(stream.good(), "write launch-query-summary.json");
}

}  // namespace

bool is_internal_launch_query_worker(const int argc, char** argv) noexcept {
    if (argc != 3 || argv == nullptr || argv[1] == nullptr) return false;
    const std::string_view worker(argv[1]);
    return worker == kProviderWorker || worker == kQueryWorker
        || worker == kProbeWorker;
}

int run_internal_launch_query_worker(const int argc, char** argv) noexcept {
    if (!is_internal_launch_query_worker(argc, argv)) return 2;
    const std::string_view worker(argv[1]);
    const std::string_view mode(argv[2] == nullptr ? "" : argv[2]);
    if (worker == kProviderWorker) return provider_worker(mode);
    if (worker == kQueryWorker) return query_worker(mode);
    if (worker == kProbeWorker) return probe_worker();
    return 2;
}

LaunchQueryCampaignCounts run_launch_query_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch) {
    const std::filesystem::path provider_root =
        scratch / "principal" / "vertical";
    const ScopedFd root_fd(::open(provider_root.c_str(),
                                  O_RDONLY | O_DIRECTORY | O_CLOEXEC
                                      | O_NOFOLLOW));
    require(root_fd.get() >= 0, "open launch-query provider root");

    const PairReports positive = run_pair(root_fd.get(), false);
    const PairReports wrong = run_pair(root_fd.get(), true);
    const WorkerReport timeout = run_timeout(root_fd.get());
    const WorkerReport bad = run_bad_descriptor_probe(root_fd.get());

    const bool provider_floor = positive.provider.uid_ok == 1
        && positive.provider.gid_ok == 1
        && positive.provider.groups_empty == 1
        && positive.provider.no_new_privs == 1
        && positive.provider.capability_sets_zero == 1;
    const bool query_floor = positive.query.uid_ok == 1
        && positive.query.gid_ok == 1
        && positive.query.groups_empty == 1
        && positive.query.no_new_privs == 1
        && positive.query.capability_sets_zero == 1;
    const bool provider_topology =
        positive.provider.descriptor_topology_exact == 1
        && positive.provider.exec_fd_closed == 1
        && positive.provider.root_fd_valid == 1
        && positive.provider.query_fd_valid == 1
        && positive.provider.report_fd_valid == 1
        && positive.provider.unexpected_fd_open == 0;
    const bool query_topology =
        positive.query.descriptor_topology_exact == 1
        && positive.query.exec_fd_closed == 1
        && positive.query.root_fd_valid == 1
        && positive.query.query_fd_valid == 1
        && positive.query.report_fd_valid == 1
        && positive.query.unexpected_fd_open == 0;
    const bool peercred_counterexample =
        positive.provider.peer_is_root_creator == 1
        && positive.query.peer_is_root_creator == 1
        && positive.provider.peer_uid == 0
        && positive.query.peer_uid == 0;
    const bool current_credentials =
        positive.query.ready_credentials_exact == 1
        && positive.provider.valid_requests == 1
        && positive.query.response_credentials_exact == 1;
    const bool exact_result =
        positive.provider.fixed_query_disposition
            == static_cast<std::int32_t>(
                FixedQueryDisposition::exact_result_v2)
        && positive.query.exact_response == 1;
    const bool forgery_denied = positive.query.forged_credentials_errno == EPERM;
    const bool rights_counterexample =
        positive.provider.rights_received == 1
        && positive.provider.rights_rejections == 1
        && positive.provider.topology_restored_after_rights == 1;
    const bool malformed_rejected =
        positive.provider.malformed_rejections == 1;
    const bool wrong_rejected = wrong.provider.credential_rejections == 1
        && wrong.query.response_credentials_exact == 1
        && wrong.provider.service_completed == 1
        && wrong.query.service_completed == 1;
    const bool timeout_bounded = timeout.timeouts == 1
        && timeout.service_completed == 1;
    const bool bad_cut_counterexample =
        bad.descriptor_topology_exact == 0
        && bad.unexpected_fd_open == 1
        && bad.service_completed == 1;

    for (const bool condition : {
             provider_floor, query_floor, provider_topology, query_topology,
             peercred_counterexample, current_credentials, exact_result,
             forgery_denied, rights_counterexample, malformed_rejected,
             wrong_rejected, timeout_bounded, bad_cut_counterexample,
             positive.provider.service_completed == 1,
             positive.query.service_completed == 1}) {
        require(condition, "launch-query campaign invariant");
    }

    std::vector<LaunchRow> rows{
        {"provider_exec_descriptor_table_exact",
         "open={0,1,2,4(root),5(query),6(report)} execfd3=CLOEXEC ambient>=7=closed",
         provider_topology, false,
         "HOSTED_PROVIDER_LAUNCH_TOPOLOGY_OBSERVED"},
        {"query_exec_descriptor_table_exact",
         "open={0,1,2,5(query),6(report)} root4=closed execfd3=CLOEXEC",
         query_topology, false,
         "HOSTED_QUERY_ACTOR_TOPOLOGY_OBSERVED"},
        {"ambient_descriptors_closed_with_close_range_unshare",
         "close_range(first=7,last=UINT_MAX,CLOSE_RANGE_UNSHARE)",
         provider_topology && query_topology, false,
         "AMBIENT_DESCRIPTOR_RANGE_CLOSED_ON_RECORDED_HOST"},
        {"provider_credential_and_capability_floor",
         "uid=21001 gid=21001 groups=0 capsets=0 no_new_privs=true",
         provider_floor, false,
         "SCOPED_PROVIDER_PROCESS_FLOOR_OBSERVED"},
        {"query_credential_and_capability_floor",
         "uid=21003 gid=21003 groups=0 capsets=0 no_new_privs=true",
         query_floor, false,
         "SCOPED_QUERY_PROCESS_FLOOR_OBSERVED"},
        {"precreated_so_peercred_reports_root_creator",
         "SO_PEERCRED uid=0 after both children drop and exec",
         peercred_counterexample, true,
         "SO_PEERCRED_IS_CREATION_TIME_NOT_CURRENT_SENDER_AUTH"},
        {"passcred_ready_authenticates_current_provider_message",
         "SCM_CREDENTIALS uid=21001 gid=21001 on ready packet",
         positive.query.ready_credentials_exact == 1, false,
         "PER_MESSAGE_PROVIDER_PRINCIPAL_OBSERVED"},
        {"valid_query_authenticates_current_query_sender",
         "SCM_CREDENTIALS uid=21003 gid=21003 on exact request",
         current_credentials, false,
         "PER_MESSAGE_QUERY_PRINCIPAL_OBSERVED"},
        {"fixed_query_returns_exact_result_v2",
         "fixed root/cell/pending/result.2 join; no path version route or mutation input",
         exact_result, false,
         "QUERY_ONLY_EXACT_RESULT_RENDEZVOUS_OBSERVED"},
        {"unprivileged_scm_credential_forgery_is_denied",
         "query uid21003 claims uid21001 sendmsg=EPERM",
         forgery_denied, false,
         "SCOPED_UNPRIVILEGED_FORGERY_REJECTED"},
        {"scm_rights_injection_is_rejected_and_closed",
         "one received descriptor installed then closed; table restored",
         rights_counterexample, true,
         "CONTROL_MESSAGES_CAN_CARRY_AUTHORITY_BEFORE_BYTE_VALIDATION"},
        {"malformed_query_message_is_rejected",
         "one-byte packet returns REJECTED_MALFORMED",
         malformed_rejected, false,
         "MALFORMED_QUERY_NEVER_BECOMES_RESULT_AUTHORITY"},
        {"wrong_uid_query_is_rejected",
         "uid21002 exact bytes return REJECTED_CREDENTIALS",
         wrong_rejected, false,
         "BYTES_ALONE_DO_NOT_AUTHENTICATE_QUERY_ACTOR"},
        {"silent_query_is_time_bounded",
         "no request yields timeout after 250ms and no retry or mutation",
         timeout_bounded, false,
         "QUERY_WAIT_IS_BOUNDED_AND_FAILS_STOP"},
        {"incorrect_close_range_start_retains_fd7",
         "close_range(first=8) leaves undeclared descriptor 7 visible after exec",
         bad_cut_counterexample, true,
         "EXACT_CUT_POINT_NOT_CLOEXEC_FOLKLORE_DEFINES_TOPOLOGY"},
    };
    std::vector<CounterexampleRow> counterexamples{
        {"so_peercred_freezes_socketpair_creator_credentials",
         peercred_counterexample,
         "claim that SO_PEERCRED on a pre-created socketpair identifies a post-drop peer",
         "use per-message credentials or connect-time creation after the intended principal exists"},
        {"scm_rights_arrives_before_query_validation",
         rights_counterexample,
         "claim that a query channel carrying inert bytes cannot inject descriptor authority",
         "reject and close all rights/control surplus before interpreting query bytes"},
        {"off_by_one_close_range_preserves_ambient_descriptor",
         bad_cut_counterexample,
         "claim that best-effort close-on-exec hygiene establishes an exact child table",
         "construct and inspect one explicit table; the first closed descriptor is security-critical"},
    };
    require(rows.size() == 15U, "launch-query case inventory");
    require(counterexamples.size() == 3U,
            "launch-query counterexample inventory");
    write_rows(output, rows);
    write_counterexamples(output, counterexamples);
    write_summary(output, rows.size(), counterexamples.size());
    return {rows.size(), counterexamples.size()};
}

}  // namespace slopos::e0::handoff_cell::harness
