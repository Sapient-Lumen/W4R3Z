#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::epoch_zero::pack {

using Byte = std::byte;
using Bytes = std::vector<Byte>;
using Digest = std::array<Byte, 32>;
using DigestFunction = std::function<Digest(std::span<const Byte>)>;

enum class ErrorCode {
  none = 0,
  invalid_digest_function,
  invalid_logical_path,
  duplicate_logical_path,
  malformed_configuration,
  unsupported_configuration_version,
  descriptor_digest_mismatch,
  descriptor_count_mismatch,
  descriptor_commitment_mismatch,
  pack_size_mismatch,
  pack_not_exact_canonical_reconstruction,
  pack_digest_mismatch,
  arithmetic_overflow,
};

struct Error {
  ErrorCode code{ErrorCode::none};
  std::string detail{};
};

template <typename T>
class Result {
 public:
  static Result success(T value) {
    Result r;
    r.value_.emplace(std::move(value));
    return r;
  }

  static Result failure(Error error) {
    Result r;
    r.error_.emplace(std::move(error));
    return r;
  }

  [[nodiscard]] explicit operator bool() const noexcept { return value_.has_value(); }
  [[nodiscard]] const T& value() const& { return value_.value(); }
  [[nodiscard]] T& value() & { return value_.value(); }
  [[nodiscard]] T&& take() && { return std::move(value_.value()); }
  [[nodiscard]] const Error& error() const { return error_.value(); }

 private:
  std::optional<T> value_{};
  std::optional<Error> error_{};
};

class SealedDescriptor final {
 public:
  static Result<SealedDescriptor> seal(
      std::string logical_path,
      Bytes owned_bytes,
      const DigestFunction& digest);

  [[nodiscard]] std::string_view logical_path() const noexcept { return logical_path_; }
  [[nodiscard]] std::span<const Byte> bytes() const noexcept { return bytes_; }
  [[nodiscard]] const Digest& content_digest() const noexcept { return content_digest_; }
  [[nodiscard]] std::uint64_t byte_size() const noexcept {
    return static_cast<std::uint64_t>(bytes_.size());
  }

  SealedDescriptor(SealedDescriptor&&) noexcept = default;
  SealedDescriptor& operator=(SealedDescriptor&&) noexcept = default;
  SealedDescriptor(const SealedDescriptor&) = delete;
  SealedDescriptor& operator=(const SealedDescriptor&) = delete;

 private:
  SealedDescriptor(std::string logical_path, Bytes owned_bytes, Digest content_digest)
      : logical_path_(std::move(logical_path)),
        bytes_(std::move(owned_bytes)),
        content_digest_(content_digest) {}

  std::string logical_path_;
  Bytes bytes_;
  Digest content_digest_{};
};

struct ConfiguredPackExpectation {
  std::uint32_t format_version{1};
  std::uint64_t descriptor_count{0};
  std::uint64_t pack_size{0};
  Digest descriptor_commitment{};
  Digest pack_digest{};
};

struct VerificationReport {
  bool accepted{false};
  ErrorCode code{ErrorCode::none};
  std::string detail{};
};

// Exact canonical pack bytes. Entries are sorted by logical path. The function
// rejects duplicate or non-canonical paths. It never re-opens filesystem paths:
// all bytes come from the owned SealedDescriptor values supplied by the caller.
Result<Bytes> canonical_pack(std::span<const SealedDescriptor> descriptors);

// Commitment to canonical descriptor metadata and each descriptor's content
// digest. The digest engine is an explicit host dependency.
Result<Digest> descriptor_commitment(
    std::span<const SealedDescriptor> descriptors,
    const DigestFunction& digest);

// Provisioning-side helpers. They are deliberately separate from verify().
// Deployment—not this local type system—must keep producer and host roles apart.
Result<ConfiguredPackExpectation> make_host_expectation(
    std::span<const SealedDescriptor> descriptors,
    const DigestFunction& digest);
Bytes encode_configured_expectation(const ConfiguredPackExpectation& expectation);

class ConfiguredPackVerifier final {
 public:
  // Copies and parses already-configured bytes. Mutating the caller's buffer after
  // construction cannot change the verifier's expectation.
  static Result<ConfiguredPackVerifier> from_configured_bytes(
      std::span<const Byte> configured_bytes,
      DigestFunction digest);

  // Crucial API law: expected digest/identity is NOT a parameter. A producer can
  // offer candidate bytes and sealed observations, but cannot self-select the
  // expectation used by this verifier invocation.
  [[nodiscard]] VerificationReport verify(
      std::span<const SealedDescriptor> descriptors,
      std::span<const Byte> produced_pack) const;

  [[nodiscard]] const ConfiguredPackExpectation& expectation() const noexcept {
    return expectation_;
  }

  ConfiguredPackVerifier(ConfiguredPackVerifier&&) noexcept = default;
  ConfiguredPackVerifier& operator=(ConfiguredPackVerifier&&) noexcept = default;
  ConfiguredPackVerifier(const ConfiguredPackVerifier&) = delete;
  ConfiguredPackVerifier& operator=(const ConfiguredPackVerifier&) = delete;

 private:
  ConfiguredPackVerifier(ConfiguredPackExpectation expectation, DigestFunction digest)
      : expectation_(expectation), digest_(std::move(digest)) {}

  ConfiguredPackExpectation expectation_{};
  DigestFunction digest_{};
};

[[nodiscard]] const char* to_string(ErrorCode code) noexcept;

}  // namespace slopos::epoch_zero::pack
