#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "slopos/e0/handoff_cell/appraiser_receipt.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/ptrace.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <openssl/evp.h>

namespace {

using namespace slopos::e0::handoff_cell;

constexpr std::array<std::uint8_t, 32U> kTestPrivateSeed = {
    0x9dU, 0x61U, 0xb1U, 0x9dU, 0xefU, 0xfdU, 0x5aU, 0x60U,
    0xbaU, 0x84U, 0x4aU, 0xf4U, 0x92U, 0xecU, 0x2cU, 0xc4U,
    0x44U, 0x49U, 0xc5U, 0x69U, 0x7bU, 0x32U, 0x69U, 0x19U,
    0x70U, 0x3bU, 0xacU, 0x03U, 0x1cU, 0xaeU, 0x7fU, 0x60U,
};
constexpr AppraiserPublicKey kTestPublicKey = {
    0xd7U, 0x5aU, 0x98U, 0x01U, 0x82U, 0xb1U, 0x0aU, 0xb7U,
    0xd5U, 0x4bU, 0xfeU, 0xd3U, 0xc9U, 0x64U, 0x07U, 0x3aU,
    0x0eU, 0xe1U, 0x72U, 0xf3U, 0xdaU, 0xa6U, 0x23U, 0x25U,
    0xafU, 0x02U, 0x1aU, 0x68U, 0xf7U, 0x07U, 0x51U, 0x1aU,
};
constexpr std::uint64_t kPidfdInfoPid = 1ULL << 0U;
constexpr std::uint64_t kPidfdInfoCreds = 1ULL << 1U;
constexpr unsigned int kPidfsIoctlMagic = 0xFFU;

struct PidfdInfoV0 final {
    std::uint64_t mask;
    std::uint64_t cgroupid;
    std::uint32_t pid;
    std::uint32_t tgid;
    std::uint32_t ppid;
    std::uint32_t ruid;
    std::uint32_t rgid;
    std::uint32_t euid;
    std::uint32_t egid;
    std::uint32_t suid;
    std::uint32_t sgid;
    std::uint32_t fsuid;
    std::uint32_t fsgid;
    std::uint32_t spare0;
};
static_assert(sizeof(PidfdInfoV0) == 64U);
constexpr unsigned long kPidfdGetInfo =
    _IOWR(kPidfsIoctlMagic, 11, PidfdInfoV0);

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
};

struct CaseRow final {
    const char* name;
    bool observed;
    bool expected;
    const char* judgment;
};

struct CounterexampleRow final {
    const char* name;
    const char* defeats;
    const char* retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* boolean(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] std::string errno_name(const int value) {
    if (value == 0) return "NONE";
    if (value == EINVAL) return "EINVAL";
    if (value == ENOTTY) return "ENOTTY";
    if (value == ENOSYS) return "ENOSYS";
    if (value == EPERM) return "EPERM";
    if (value == EACCES) return "EACCES";
    if (value == ESRCH) return "ESRCH";
    return std::string("ERRNO_") + std::to_string(value);
}

[[nodiscard]] AppraiserBinding binding(const std::uint8_t base) noexcept {
    AppraiserBinding value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] AppraiserReceiptSignature sign_message(
    const AppraiserReceiptBytes& message) {
    AppraiserReceiptSignature signature{};
    EVP_PKEY* key = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, kTestPrivateSeed.data(),
        kTestPrivateSeed.size());
    require(key != nullptr, "create Ed25519 test key");
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    require(context != nullptr, "create signing context");
    std::size_t signature_size = signature.size();
    const bool ok = EVP_DigestSignInit(
        context, nullptr, nullptr, nullptr, key) == 1
        && EVP_DigestSign(context, signature.data(), &signature_size,
                          message.data(), message.size()) == 1;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(key);
    require(ok && signature_size == signature.size(), "sign receipt");
    return signature;
}

void put_u32(std::array<std::uint8_t, 32U>& out, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> (index * 8U)) & 0xFFU);
    }
}

void put_u64(std::array<std::uint8_t, 32U>& out, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> (index * 8U)) & 0xFFU);
    }
}

[[nodiscard]] std::uint32_t get_u32(
    const std::array<std::uint8_t, 32U>& in,
    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value |= static_cast<std::uint32_t>(in[offset + index]) << (index * 8U);
    }
    return value;
}

[[nodiscard]] std::uint64_t get_u64(
    const std::array<std::uint8_t, 32U>& in,
    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value |= static_cast<std::uint64_t>(in[offset + index]) << (index * 8U);
    }
    return value;
}

void send_packet(const int fd, const std::uint8_t* data,
                 const std::size_t size) {
    const ssize_t written = ::send(fd, data, size, MSG_NOSIGNAL);
    require(written == static_cast<ssize_t>(size), "send exact seqpacket");
}

[[nodiscard]] std::size_t receive_packet(const int fd, std::uint8_t* data,
                                         const std::size_t capacity) {
    const ssize_t count = ::recv(fd, data, capacity, 0);
    require(count >= 0, "receive seqpacket");
    return static_cast<std::size_t>(count);
}

[[nodiscard]] UniqueFd open_user_namespace_for_self() {
    return UniqueFd(::open("/proc/self/ns/user", O_RDONLY | O_CLOEXEC));
}

[[nodiscard]] UniqueFd pidfd_open_for(const pid_t pid) {
#ifdef SYS_pidfd_open
    errno = 0;
    const long result = ::syscall(SYS_pidfd_open, pid, 0U);
    if (result < 0L) return UniqueFd{};
    require(result <= static_cast<long>(INT32_MAX), "pidfd range");
    return UniqueFd(static_cast<int>(result));
#else
    (void)pid;
    return UniqueFd{};
#endif
}

[[nodiscard]] bool pidfd_signal(const int pidfd, const int signal_number,
                                int& error_number) noexcept {
#ifdef SYS_pidfd_send_signal
    errno = 0;
    const long result = ::syscall(
        SYS_pidfd_send_signal, pidfd, signal_number, nullptr, 0U);
    error_number = result == 0L ? 0 : errno;
    return result == 0L;
#else
    (void)pidfd;
    (void)signal_number;
    error_number = ENOSYS;
    return false;
#endif
}

[[nodiscard]] bool write_text(const std::filesystem::path& path,
                              const std::string& text,
                              int& error_number) noexcept {
    const int fd = ::open(path.c_str(), O_WRONLY | O_CLOEXEC);
    if (fd < 0) {
        error_number = errno;
        return false;
    }
    std::size_t offset = 0U;
    while (offset < text.size()) {
        const ssize_t count = ::write(fd, text.data() + offset,
                                      text.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) {
            error_number = count < 0 ? errno : EIO;
            (void)::close(fd);
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    const int close_result = ::close(fd);
    if (close_result != 0) {
        error_number = errno;
        return false;
    }
    error_number = 0;
    return true;
}

[[nodiscard]] AppraiserReceiptObservationV1 host_observation() noexcept {
    AppraiserReceiptObservationV1 v;
    v.profile_supplied = true;
    v.v16_hosted_actor_epoch_supplied = true;
    v.appraiser_constitution_supplied = true;
    v.receipt_exact_length = true;
    v.receipt_decoded = true;
    v.receipt_canonical = true;
    v.receipt_domain_exact = true;
    v.receipt_schema_exact = true;
    v.receipt_reserved_zero = true;
    v.receipt_claim_flags_known = true;
    v.report_ordinal_nonzero = true;
    v.challenge_fresh = true;
    v.challenge_binding_exact = true;
    v.constitution_binding_exact = true;
    v.actor_epoch_binding_exact = true;
    v.v15_exec_input_binding_exact = true;
    v.v16_static_envelope_binding_exact = true;
    v.installed_policy_binding_exact = true;
    v.kernel_surface_binding_exact = true;
    v.process_coordinate_binding_exact = true;
    v.v14_dossier_binding_exact = true;
    v.hold_token_binding_exact = true;
    v.observation_order_exact = true;
    v.signature_suite_ed25519 = true;
    v.public_key_pinned = true;
    v.signature_exact_length = true;
    v.signature_verifies = true;
    v.exactly_one_report_consumed = true;
    v.appraiser_process_separate = true;
    // The child namespace and report are created, mapped, fed and terminated by
    // this same cloudtainer root.  Every remaining custody field stays false.
    return v;
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "appraiser-receipt-host-cases.tsv",
                         std::ios::binary);
    require(stream.good(), "open appraiser receipt host cases");
    stream << "case\tobserved\texpected\tpass\tjudgment\n";
    for (const CaseRow& row : rows) {
        stream << row.name << '\t' << boolean(row.observed) << '\t'
               << boolean(row.expected) << '\t'
               << boolean(row.observed == row.expected) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "appraiser-receipt-host-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open appraiser receipt host counterexamples");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

}  // namespace

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_appraiser_receipt_probe OUTPUT\n";
        return 2;
    }
    try {
        const std::filesystem::path output(argv[1]);
        std::filesystem::create_directories(output);

        AppraiserReceiptRecordV1 record;
        record.claim_flags = kAppraiserReceiptKnownClaimMask;
        record.report_ordinal = 23U;
        record.challenge = binding(0x11U);
        record.appraiser_constitution = binding(0x21U);
        record.actor_epoch = binding(0x31U);
        record.v15_exec_input = binding(0x41U);
        record.v16_static_envelope = binding(0x51U);
        record.installed_policy = binding(0x61U);
        record.kernel_surfaces = binding(0x71U);
        record.process_coordinate = binding(0x81U);
        record.v14_dossier = binding(0x91U);
        record.hold_token = binding(0xA1U);
        AppraiserReceiptBytes message{};
        require(encode_appraiser_receipt(record, message), "encode host receipt");
        const AppraiserReceiptSignature signature = sign_message(message);
        const bool parent_signature_verifies = verify_appraiser_receipt_ed25519(
            kTestPublicKey, message, signature);
        const bool portable_replay_reverifies =
            parent_signature_verifies
            && verify_appraiser_receipt_ed25519(
                kTestPublicKey, message, signature);

        UniqueFd parent_ns = open_user_namespace_for_self();
        require(parent_ns.value >= 0, "open parent user namespace");
        struct stat parent_ns_stat {};
        require(::fstat(parent_ns.value, &parent_ns_stat) == 0,
                "stat parent user namespace");

        int sockets[2] = {-1, -1};
        require(::socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0,
                             sockets) == 0,
                "create appraiser socketpair");
        UniqueFd parent_socket(sockets[0]);
        UniqueFd child_socket(sockets[1]);
        const pid_t child = ::fork();
        require(child >= 0, "fork appraiser fixture");
        if (child == 0) {
            parent_socket = UniqueFd{};
            errno = 0;
            const int unshare_result = ::unshare(CLONE_NEWUSER);
            const int unshare_errno = unshare_result == 0 ? 0 : errno;
            UniqueFd child_ns = open_user_namespace_for_self();
            struct stat child_ns_stat {};
            const bool child_ns_stat_ok = child_ns.value >= 0
                && ::fstat(child_ns.value, &child_ns_stat) == 0;
            std::array<std::uint8_t, 32U> ready{};
            ready[0U] = 'R'; ready[1U] = 'D'; ready[2U] = 'Y'; ready[3U] = '1';
            put_u32(ready, 4U, static_cast<std::uint32_t>(unshare_errno));
            put_u64(ready, 8U, child_ns_stat_ok
                ? static_cast<std::uint64_t>(child_ns_stat.st_dev) : 0U);
            put_u64(ready, 16U, child_ns_stat_ok
                ? static_cast<std::uint64_t>(child_ns_stat.st_ino) : 0U);
            put_u32(ready, 24U, static_cast<std::uint32_t>(::getuid()));
            put_u32(ready, 28U, static_cast<std::uint32_t>(::getgid()));
            send_packet(child_socket.value, ready.data(), ready.size());
            if (unshare_result != 0 || !child_ns_stat_ok) _exit(101);

            std::array<std::uint8_t, 448U> envelope{};
            const std::size_t received = receive_packet(
                child_socket.value, envelope.data(), envelope.size());
            AppraiserReceiptBytes child_message{};
            AppraiserReceiptSignature child_signature{};
            if (received == envelope.size()) {
                std::copy_n(envelope.begin(), child_message.size(),
                            child_message.begin());
                std::copy_n(envelope.begin()
                                + static_cast<std::ptrdiff_t>(child_message.size()),
                            child_signature.size(), child_signature.begin());
            }
            AppraiserReceiptRecordV1 child_record;
            const bool decoded = received == envelope.size()
                && decode_appraiser_receipt(child_message, child_record);
            const bool verified = decoded && verify_appraiser_receipt_ed25519(
                kTestPublicKey, child_message, child_signature);
            std::uint8_t extra = 0U;
            errno = 0;
            const ssize_t duplicate_count = ::recv(
                child_socket.value, &extra, 1U, MSG_DONTWAIT);
            const bool no_second_report = duplicate_count < 0
                && (errno == EAGAIN || errno == EWOULDBLOCK);
            std::array<std::uint8_t, 32U> result{};
            result[0U] = 'R'; result[1U] = 'E'; result[2U] = 'S'; result[3U] = '1';
            put_u32(result, 4U, decoded ? 1U : 0U);
            put_u32(result, 8U, verified ? 1U : 0U);
            put_u32(result, 12U, no_second_report ? 1U : 0U);
            put_u32(result, 16U, static_cast<std::uint32_t>(::getuid()));
            put_u32(result, 20U, static_cast<std::uint32_t>(::getgid()));
            put_u32(result, 24U, static_cast<std::uint32_t>(received));
            put_u32(result, 28U, child_record.claim_flags);
            send_packet(child_socket.value, result.data(), result.size());
            for (;;) ::pause();
        }
        child_socket = UniqueFd{};

        std::array<std::uint8_t, 32U> ready{};
        require(receive_packet(parent_socket.value, ready.data(), ready.size())
                    == ready.size(),
                "receive child ready");
        require(ready[0U] == 'R' && ready[1U] == 'D'
                && ready[2U] == 'Y' && ready[3U] == '1',
                "child ready magic");
        const int child_unshare_errno = static_cast<int>(get_u32(ready, 4U));
        const std::uint64_t child_ns_dev = get_u64(ready, 8U);
        const std::uint64_t child_ns_ino = get_u64(ready, 16U);
        const std::uint32_t child_uid_before_map = get_u32(ready, 24U);
        const std::uint32_t child_gid_before_map = get_u32(ready, 28U);
        const bool child_userns_created = child_unshare_errno == 0;
        const bool child_userns_distinct = child_userns_created
            && (child_ns_dev != static_cast<std::uint64_t>(parent_ns_stat.st_dev)
                || child_ns_ino
                    != static_cast<std::uint64_t>(parent_ns_stat.st_ino));

        const std::filesystem::path proc =
            std::filesystem::path("/proc") / std::to_string(child);
        int setgroups_errno = 0;
        const bool parent_wrote_setgroups = write_text(
            proc / "setgroups", "deny", setgroups_errno);
        int uid_map_errno = 0;
        const bool parent_wrote_uid_map = write_text(
            proc / "uid_map",
            "0 " + std::to_string(static_cast<unsigned long>(::geteuid()))
                + " 1\n",
            uid_map_errno);
        int gid_map_errno = 0;
        const bool parent_wrote_gid_map = write_text(
            proc / "gid_map",
            "0 " + std::to_string(static_cast<unsigned long>(::getegid()))
                + " 1\n",
            gid_map_errno);
        require(parent_wrote_setgroups && parent_wrote_uid_map
                    && parent_wrote_gid_map,
                "parent constitutes child user-namespace mappings");

        std::array<std::uint8_t, 448U> envelope{};
        std::copy(message.begin(), message.end(), envelope.begin());
        std::copy(signature.begin(), signature.end(),
                  envelope.begin()
                    + static_cast<std::ptrdiff_t>(message.size()));
        send_packet(parent_socket.value, envelope.data(), envelope.size());
        std::array<std::uint8_t, 32U> child_result{};
        require(receive_packet(parent_socket.value, child_result.data(),
                               child_result.size()) == child_result.size(),
                "receive child result");
        require(child_result[0U] == 'R' && child_result[1U] == 'E'
                && child_result[2U] == 'S' && child_result[3U] == '1',
                "child result magic");
        const bool child_decoded = get_u32(child_result, 4U) == 1U;
        const bool child_verified = get_u32(child_result, 8U) == 1U;
        const bool child_no_second_report = get_u32(child_result, 12U) == 1U;
        const bool child_root_after_parent_map =
            get_u32(child_result, 16U) == 0U
            && get_u32(child_result, 20U) == 0U;
        const bool child_received_exact_envelope =
            get_u32(child_result, 24U) == envelope.size();
        const bool child_claim_flags_exact =
            get_u32(child_result, 28U) == kAppraiserReceiptKnownClaimMask;

        UniqueFd pidfd = pidfd_open_for(child);
        const bool pidfd_open_supported = pidfd.value >= 0;
        PidfdInfoV0 info{};
        info.mask = kPidfdInfoPid | kPidfdInfoCreds;
        errno = 0;
        const int info_result = pidfd_open_supported
            ? ::ioctl(pidfd.value, kPidfdGetInfo, &info) : -1;
        const int pidfd_get_info_errno = info_result == 0 ? 0 : errno;
        const bool pidfd_get_info_supported = info_result == 0;

        errno = 0;
        const long ptrace_result = ::ptrace(
            PTRACE_SEIZE, child, nullptr,
            reinterpret_cast<void*>(static_cast<std::uintptr_t>(PTRACE_O_EXITKILL)));
        const int ptrace_errno = ptrace_result == 0L ? 0 : errno;
        const bool parent_ptrace_seize_control = ptrace_result == 0L;
        bool parent_ptrace_detached_cleanly = false;
        if (parent_ptrace_seize_control) {
            require(::ptrace(PTRACE_INTERRUPT, child, nullptr, nullptr) == 0L,
                    "interrupt seized appraiser");
            int ptrace_status = 0;
            require(::waitpid(child, &ptrace_status, __WALL) == child
                        && WIFSTOPPED(ptrace_status),
                    "observe appraiser ptrace stop");
            require(::ptrace(PTRACE_DETACH, child, nullptr, nullptr) == 0L,
                    "detach appraiser fixture");
            parent_ptrace_detached_cleanly = true;
        } else {
            require(ptrace_errno == EPERM || ptrace_errno == EACCES,
                    "unexpected ptrace failure");
        }

        int signal_errno = 0;
        const bool parent_pidfd_signal_control = pidfd_open_supported
            && pidfd_signal(pidfd.value, SIGTERM, signal_errno);
        require(parent_pidfd_signal_control, "parent pidfd signal control");
        int child_status = 0;
        require(::waitpid(child, &child_status, 0) == child,
                "wait terminated appraiser");
        const bool child_terminated_by_parent =
            WIFSIGNALED(child_status) && WTERMSIG(child_status) == SIGTERM;

        const AppraiserReceiptAssessment assessment =
            assess_appraiser_receipt(host_observation());
        require(assessment.observation_coherent
                && assessment.canonical_receipt_bound
                && assessment.signed_appraiser_statement_bound
                && assessment.one_report_consumption_bound
                && !assessment.independent_appraiser_constitution_bound
                && !assessment.independently_appraised_actor_premise_bound
                && assessment.disposition
                    == AppraiserReceiptDisposition::administration_root_not_distinct,
                "host relation boundary");

        const bool appraiser_process_separate = true;
        const bool appraiser_user_namespace_distinct = child_userns_distinct;
        const bool appraiser_administration_root_distinct = false;
        const bool appraiser_key_custody_independent = false;
        const bool appraiser_input_custody_independent = false;
        const bool installed_policy_independently_reconstructed = false;
        const bool kernel_surfaces_independently_reconstructed = false;
        const bool v14_dossier_independently_reopened = false;
        const bool actor_epoch_held_through_v13 = false;
        const bool portable_replay_excluded = false;
        const bool independent_appraisal = false;
        const bool v13_eligible = false;
        const bool network_attempted = false;
        const bool ready_sent = false;
        const bool rights_imported = false;
        const bool archive_body_bytes_zero = true;
        const bool authority = false;

        const std::vector<CaseRow> cases = {
            {"canonical_receipt_encoded", true, true, "FIXED_384_BYTE_MESSAGE"},
            {"receipt_decoded_and_reencoded", true, true, "CANONICAL_CODEC"},
            {"ed25519_signature_verifies", parent_signature_verifies, true, "REAL_SIGNATURE_PUBLIC_TEST_KEY"},
            {"same_signed_bytes_reverify", portable_replay_reverifies, true, "SIGNATURE_IS_INTRINSICALLY_REPLAYABLE"},
            {"appraiser_process_separate", appraiser_process_separate, true, "FORKED_SINGLE_SHOT_PROCESS"},
            {"child_user_namespace_created", child_userns_created, true, "CLONE_NEWUSER_AVAILABLE"},
            {"child_user_namespace_distinct", appraiser_user_namespace_distinct, true, "NAMESPACE_INODE_DIFFERS"},
            {"child_uid_unmapped_before_parent_map", child_uid_before_map == 65534U, true, "UNMAPPED_ID_IS_OVERFLOW"},
            {"child_gid_unmapped_before_parent_map", child_gid_before_map == 65534U, true, "UNMAPPED_GROUP_IS_OVERFLOW"},
            {"parent_wrote_setgroups_policy", parent_wrote_setgroups, true, "CREATOR_CONTROLS_MAPPING_PREMISE"},
            {"parent_wrote_uid_map", parent_wrote_uid_map, true, "CREATOR_CONSTITUTES_CHILD_UID_ZERO"},
            {"parent_wrote_gid_map", parent_wrote_gid_map, true, "CREATOR_CONSTITUTES_CHILD_GID_ZERO"},
            {"child_root_after_parent_map", child_root_after_parent_map, true, "NAMESPACE_ROOT_IS_PARENT_CREATED"},
            {"child_received_exact_envelope", child_received_exact_envelope, true, "PARENT_OWNS_INPUT_CHANNEL"},
            {"child_receipt_decoded", child_decoded, true, "CHILD_PARSES_EXACT_MESSAGE"},
            {"child_signature_verified", child_verified, true, "CHILD_VERIFIES_PUBLIC_TEST_SIGNATURE"},
            {"child_claim_flags_exact", child_claim_flags_exact, true, "SIGNED_FLAGS_ARE_STATEMENTS_ONLY"},
            {"child_consumed_one_local_report", child_no_second_report, true, "LOCAL_SOCKET_QUEUE_EMPTY_AFTER_ONE_READ"},
            {"pidfd_open_supported", pidfd_open_supported, true, "PROCESS_HANDLE_AVAILABLE"},
            {"pidfd_get_info_supported", pidfd_get_info_supported, false, "ADMITTED_LIFETIME_QUERY_UNAVAILABLE"},
            {"parent_ptrace_seize_control", parent_ptrace_seize_control, true, "SAME_PARENT_CAN_SEIZE_APPRAISER"},
            {"parent_ptrace_detached_cleanly", parent_ptrace_detached_cleanly, true, "CONTROL_EXERCISED_WITHOUT_LEAVING_TRACE_STATE"},
            {"parent_pidfd_signal_control", parent_pidfd_signal_control, true, "CREATOR_CAN_TERMINATE_APPRAISER"},
            {"child_terminated_by_parent", child_terminated_by_parent, true, "NAMESPACE_IS_NOT_ADMINISTRATION_INDEPENDENCE"},
            {"appraiser_administration_root_distinct", appraiser_administration_root_distinct, false, "SAME_CLOUDTAINER_ROOT"},
            {"appraiser_key_custody_independent", appraiser_key_custody_independent, false, "PUBLIC_FIXTURE_PRIVATE_SEED_IN_HARNESS"},
            {"appraiser_input_custody_independent", appraiser_input_custody_independent, false, "PARENT_CREATED_AND_SENT_ALL_BINDINGS"},
            {"installed_policy_independently_reconstructed", installed_policy_independently_reconstructed, false, "NO_POLICY_READBACK"},
            {"kernel_surfaces_independently_reconstructed", kernel_surfaces_independently_reconstructed, false, "NO_INDEPENDENT_KERNEL_OBJECT_SET"},
            {"v14_dossier_independently_reopened", v14_dossier_independently_reopened, false, "NO_INDEPENDENT_DOSSIER_CUSTODY"},
            {"actor_epoch_held_through_v13", actor_epoch_held_through_v13, false, "APPRAISER_TERMINATED_BEFORE_ADMISSION"},
            {"portable_replay_excluded", portable_replay_excluded, false, "SAME_BYTES_VERIFY_AGAIN"},
            {"signed_statement_bound", assessment.signed_appraiser_statement_bound, true, "NARROW_HOSTED_CRYPTOGRAPHIC_THEOREM"},
            {"independent_appraisal_bound", independent_appraisal, false, "ADMINISTRATION_AND_CUSTODY_PREMISES_FAIL"},
            {"v13_actor_premise", v13_eligible, false, "STOP_BEFORE_READY"},
            {"network_attempted", network_attempted, false, "NO_ACQUISITION_IO"},
            {"ready_sent", ready_sent, false, "NO_V13_TRANSITION"},
            {"rights_imported", rights_imported, false, "NO_CAPABILITY_IMPORT"},
            {"archive_body_bytes_zero", archive_body_bytes_zero, true, "NO_RELEASE_BYTES"},
            {"authority", authority, false, "EPOCH_ZERO"},
        };
        for (const CaseRow& row : cases) {
            require(row.observed == row.expected,
                    std::string("host case mismatch=") + row.name);
        }

        const std::vector<CounterexampleRow> counterexamples = {
            {"valid_signature_is_independent_appraisal", "signature verification as administration-root separation", "the host proves only a signed statement"},
            {"fork_is_independent_administration", "separate PID as separate governor", "the parent creates maps inputs and lifetime"},
            {"userns_inode_is_independent_root", "distinct namespace inode as independent administration", "the parent writes both identity maps"},
            {"namespace_root_is_external_root", "uid zero in a child user namespace as external constitution", "the parent explicitly creates that uid-zero mapping"},
            {"separate_userns_blocks_parent_ptrace", "namespace separation as tracer exclusion", "the same parent successfully seizes and releases the appraiser"},
            {"pidfd_signal_is_benign", "creator termination power as irrelevant to appraisal", "lifetime control belongs in the compromise model"},
            {"socketpair_is_input_custody", "parent-owned endpoint as independent source selection", "the parent supplies every receipt byte"},
            {"public_test_key_is_key_custody", "embedded seed as enrolled appraiser key", "the key is deliberately public fixture material"},
            {"one_empty_queue_is_global_nonreuse", "one local read as portable replay exclusion", "the exact signed bytes verify again"},
            {"signed_claim_flags_are_observations", "signed true bits as independently reconstructed facts", "policy kernel V14 and hold remain false"},
            {"pidfd_open_is_lifetime_dossier", "process handle availability as PIDFD_GET_INFO", "the admitted ioctl still fails closed"},
            {"child_root_means_host_root", "nested namespace privilege as host administration", "capabilities are scoped and the parent remains ancestor"},
            {"same_kernel_is_independent_kernel_appraisal", "a second process on one host as independent kernel root", "both are governed by the same cloudtainer kernel and administrator"},
            {"signed_report_is_complete_process_image", "ten digests as every executable and mutable surface", "complete process image remains false"},
            {"appraiser_stop_is_archive_absence", "failed constitution as proof no release exists", "no archive body was attempted"},
            {"appraiser_receipt_is_ready", "a positive signature as V13 READY authority", "the actor premise remains false"},
            {"crypto_success_is_owner_authority", "Ed25519 success as governance", "owner constitution and living law remain absent"},
            {"same_root_fixture_is_living_law", "host experiment as adopted constitution", "the checkpoint remains nonauthoritative Epoch Zero"},
        };

        write_cases(output, cases);
        write_counterexamples(output, counterexamples);
        std::ofstream summary(output / "appraiser-receipt-host-summary.json",
                              std::ios::binary);
        require(summary.good(), "open appraiser receipt host summary");
        summary << "{\n"
                << "  \"appraiser_administration_root_distinct\": false,\n"
                << "  \"appraiser_input_custody_independent\": false,\n"
                << "  \"appraiser_key_custody_independent\": false,\n"
                << "  \"appraiser_process_separate\": true,\n"
                << "  \"appraiser_user_namespace_distinct\": true,\n"
                << "  \"archive_body_bytes\": 0,\n"
                << "  \"authority\": false,\n"
                << "  \"cases\": " << cases.size() << ",\n"
                << "  \"child_root_after_parent_map\": true,\n"
                << "  \"counterexamples_reproduced\": "
                << counterexamples.size() << ",\n"
                << "  \"independent_appraisal_bound\": false,\n"
                << "  \"installed_policy_independently_reconstructed\": false,\n"
                << "  \"kernel_surfaces_independently_reconstructed\": false,\n"
                << "  \"network_attempted\": false,\n"
                << "  \"one_local_report_consumed\": true,\n"
                << "  \"parent_created_identity_maps\": true,\n"
                << "  \"parent_pidfd_signal_control\": true,\n"
                << "  \"parent_ptrace_errno\": \""
                << errno_name(ptrace_errno) << "\",\n"
                << "  \"parent_ptrace_seize_control\": true,\n"
                << "  \"pidfd_get_info_errno\": \""
                << errno_name(pidfd_get_info_errno) << "\",\n"
                << "  \"pidfd_get_info_supported\": false,\n"
                << "  \"portable_replay_excluded\": false,\n"
                << "  \"public_test_key\": true,\n"
                << "  \"ready_sent\": false,\n"
                << "  \"receipt_bytes\": " << kAppraiserReceiptBytes << ",\n"
                << "  \"rights_imported\": false,\n"
                << "  \"schema\": \"slopos.rev0905.appraiser-receipt-host-probe.v17\",\n"
                << "  \"signature_bytes\": "
                << kAppraiserReceiptSignatureBytes << ",\n"
                << "  \"signed_statement_bound\": true,\n"
                << "  \"status\": \"PASS\",\n"
                << "  \"user_namespace_created\": true,\n"
                << "  \"v13_actor_premise\": false,\n"
                << "  \"v14_dossier_independently_reopened\": false\n"
                << "}\n";

        std::cout
            << "APPRAISER_RECEIPT_PROBE=PASS cases=" << cases.size()
            << " counterexamples=" << counterexamples.size()
            << " signed_statement=true separate_process=true"
            << " userns_distinct=true parent_maps=true parent_kill=true"
            << " ptrace_control=true pidfd_get_info=false independent=false"
            << " replay_excluded=false v13=false archive_bytes=0 authority=false\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "APPRAISER_RECEIPT_PROBE=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
