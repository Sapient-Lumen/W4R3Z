#!/usr/bin/env python3
"""Read-only payload identity and duplication audit for a SlopOS cube."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from collections import defaultdict
from pathlib import Path

VAULT = {
    "vault", "archive", "archives", "archaeology", "archaeological", "evidence",
    "predecessor", "old", "legacy", "preserved", "snapshot", "snapshots",
    "attic", "museum", "fossil", "historical", "history", "prior", "previous",
}

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--top", type=int, default=80)
    args = parser.parse_args()
    root = args.root.resolve()
    by_identity: dict[tuple[int, str], list[str]] = defaultdict(list)
    living_files = vault_files = living_bytes = vault_bytes = 0
    errors: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = sorted(d for d in dirnames if d not in {".git", "build", "_build"})
        for filename in sorted(filenames):
            path = Path(dirpath) / filename
            try:
                if path.is_symlink():
                    payload = os.readlink(path).encode("utf-8", errors="surrogateescape")
                    identity = (len(payload), hashlib.sha256(payload).hexdigest())
                else:
                    size = path.stat().st_size
                    identity = (size, digest(path))
                rel = path.relative_to(root).as_posix()
                by_identity[identity].append(rel)
                vaultish = any(part.lower() in VAULT for part in Path(rel).parts)
                if vaultish:
                    vault_files += 1
                    vault_bytes += identity[0]
                else:
                    living_files += 1
                    living_bytes += identity[0]
            except OSError as exc:
                errors.append(f"{path}: {exc}")
    groups = []
    duplicate_bytes = 0
    for (size, sha), paths in by_identity.items():
        if size == 0 or len(paths) < 2:
            continue
        avoidable = size * (len(paths) - 1)
        duplicate_bytes += avoidable
        groups.append({
            "sha256": sha,
            "size": size,
            "copies": len(paths),
            "avoidable_bytes_if_content_addressed": avoidable,
            "paths": paths[:40],
            "paths_truncated": len(paths) > 40,
        })
    groups.sort(key=lambda g: (-g["avoidable_bytes_if_content_addressed"], g["sha256"]))
    report = {
        "schema": "slopos.vault-audit.v1",
        "root": root.name,
        "classification_is_lexical_not_authoritative": True,
        "file_count": living_files + vault_files,
        "byte_count": living_bytes + vault_bytes,
        "living_like": {"files": living_files, "bytes": living_bytes},
        "vault_like": {"files": vault_files, "bytes": vault_bytes},
        "exact_duplicate_groups": len(groups),
        "avoidable_duplicate_bytes_if_migrated_to_cas": duplicate_bytes,
        "top_duplicate_groups": groups[: args.top],
        "errors": errors,
        "destructive_action_taken": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "files": report["file_count"],
        "bytes": report["byte_count"],
        "duplicate_groups": report["exact_duplicate_groups"],
        "avoidable_duplicate_bytes": report["avoidable_duplicate_bytes_if_migrated_to_cas"],
    }, sort_keys=True))
    return 0 if not errors else 2

if __name__ == "__main__":
    raise SystemExit(main())
