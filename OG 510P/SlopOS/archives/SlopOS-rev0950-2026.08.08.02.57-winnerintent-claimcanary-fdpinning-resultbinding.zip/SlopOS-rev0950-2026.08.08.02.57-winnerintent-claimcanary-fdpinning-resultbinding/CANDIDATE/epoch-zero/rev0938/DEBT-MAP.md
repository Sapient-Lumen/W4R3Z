# Debt map after rev0938

**Authority debt:** expectation provisioning is in-process/hosted; no independent principal
or owner receipt exists.

**Algorithm debt:** the configured envelope does not yet bind a digest algorithm identifier;
the harness injects an engine and tests with a non-cryptographic deterministic function.

**Integration debt:** the new verifier is a nested proof harness, not yet wired into the
inherited runtime command surface. Integration must preserve the no-expectation-argument law.

**Vault topology debt:** lexical path names only approximate living versus evidence status.
Explicit manifests must replace inference before compaction.

**Continuity debt:** the immediate parent archive is receipt-bound but not embedded. That is
economical and honest, but long-term custody still requires an independently durable store.
