# Incident: stale predecessor narrative

**Observed in:** inherited rev0937 cube  
**Live file:** `PREDECESSOR/README.md`  
**Exact inherited bytes:** `inherited-README.exact`  
**Inherited SHA-256:** `fc3a921232a8fd4ad8c0ed3920b31b213cd0ca4e1eeb2ba309a262b4908762b1`

The live narrative was multiple revisions behind the parent receipt. The exact bytes are
retained here; the live file was replaced with a receipt-bound contract and a close gate.
No other inherited predecessor payload was rewritten or relabeled.
