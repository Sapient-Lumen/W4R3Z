#include "campaign.hpp"
#include "acquisition_actor_admission_campaign.hpp"
#include "actor_exec_binding_campaign.hpp"
#include "appraiser_receipt_campaign.hpp"
#include "appraiser_receipt_spend_campaign.hpp"
#include "endpoint_claim_campaign.hpp"
#include "endpoint_publication_campaign.hpp"
#include "etcd_history_profile_campaign.hpp"
#include "external_rollback_floor_campaign.hpp"
#include "launch_query_campaign.hpp"
#include "principal_campaign.hpp"
#include "provider_genesis_campaign.hpp"
#include "release_ingress_campaign.hpp"
#include "rooted_release_campaign.hpp"
#include "sealed_snapshot_offer_campaign.hpp"
#include "settlement_campaign.hpp"
#include "static_actor_confinement_campaign.hpp"

#include "slopos/e0/handoff_cell/cell.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) { other.value = -1; }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() { if (value >= 0) (void)::close(value); }
};

struct Shape final {
    bool live{false};
    bool pending{false};
    std::uint64_t live_inode{0U};
    std::uint64_t pending_inode{0U};
    std::uint64_t pending_links{0U};
};

struct CaseRow final {
    std::string name;
    std::string burn;
    std::string validation;
    bool live{false};
    bool pending{false};
    bool same_inode{false};
    unsigned int contenders{0U};
    unsigned int successful_binds{0U};
    bool process_death_cut{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct Counterexample final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] std::array<std::uint8_t, 32U> binding(
    const std::uint8_t base) noexcept {
    std::array<std::uint8_t, 32U> value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] EncodedRecord canonical_pending() {
    Record record;
    record.kind = RecordKind::pending;
    record.sequence = 1U;
    record.generation_from = 41U;
    record.generation_to = 42U;
    record.operation_binding = binding(1U);
    record.spent_receipt_binding = binding(161U);
    record.result = Result::none;
    record.consumed_dispatch = true;
    record.reconciled = false;
    EncodedRecord encoded{};
    require(generation_journal::encode_record(record, encoded),
            "encode canonical pending record");
    return encoded;
}

void write_all(const int fd, const EncodedRecord& bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(fd, bytes.data() + offset,
                                      bytes.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "write fixture");
        offset += static_cast<std::size_t>(count);
    }
}

void write_leaf(const int directory_fd, const char* leaf,
                const EncodedRecord& bytes) {
    const UniqueFd fd(::openat(directory_fd, leaf,
                              O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC,
                              S_IRUSR | S_IWUSR));
    require(fd.value >= 0, std::string("open fixture leaf ") + leaf);
    write_all(fd.value, bytes);
    require(::fdatasync(fd.value) == 0, "fdatasync fixture");
    require(::fsync(directory_fd) == 0, "fsync fixture directory");
}

[[nodiscard]] Shape observe(const int directory_fd) {
    Shape shape;
    struct stat status {};
    if (::fstatat(directory_fd, kLiveLeaf, &status, AT_SYMLINK_NOFOLLOW) == 0) {
        shape.live = true;
        shape.live_inode = static_cast<std::uint64_t>(status.st_ino);
    } else {
        require(errno == ENOENT, "observe live");
    }
    if (::fstatat(directory_fd, kPendingLeaf, &status, AT_SYMLINK_NOFOLLOW) == 0) {
        shape.pending = true;
        shape.pending_inode = static_cast<std::uint64_t>(status.st_ino);
        shape.pending_links = static_cast<std::uint64_t>(status.st_nlink);
    } else {
        require(errno == ENOENT, "observe pending");
    }
    return shape;
}

[[nodiscard]] UniqueFd open_directory(const std::filesystem::path& path) {
    const int fd = ::open(path.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    require(fd >= 0, "open fixture directory");
    return UniqueFd(fd);
}

[[nodiscard]] std::filesystem::path make_cell(
    const std::filesystem::path& scratch, const std::string& name) {
    const auto path = scratch / name;
    require(std::filesystem::create_directory(path), "create cell " + name);
    return path;
}

[[nodiscard]] Cell retain(const int directory_fd) {
    int error_number = 0;
    auto cell = Cell::retain_host_directory(directory_fd, error_number);
    require(cell.has_value(), "retain cell errno=" + std::to_string(error_number));
    return std::move(*cell);
}

[[nodiscard]] std::string pending_result_name(const PendingResult& result) {
    return pending_name(result.disposition);
}

[[nodiscard]] char read_one(const int fd) {
    char value = '\0';
    ssize_t count = -1;
    do {
        count = ::read(fd, &value, 1U);
    } while (count < 0 && errno == EINTR);
    require(count == 1, "read synchronization byte");
    return value;
}

void write_one(const int fd, const char value) {
    ssize_t count = -1;
    do {
        count = ::write(fd, &value, 1U);
    } while (count < 0 && errno == EINTR);
    if (count != 1) _exit(111);
}

void wait_killed(const pid_t child) {
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait killed child");
    require(WIFSIGNALED(status) && WTERMSIG(status) == SIGKILL,
            "child must stop at scheduled SIGKILL cut");
}

[[nodiscard]] CaseRow crash_case(const std::filesystem::path& scratch,
                                 const std::string& name,
                                 const int cut,
                                 const EncodedRecord& expected) {
    const auto path = make_cell(scratch, name);
    const UniqueFd directory = open_directory(path);
    write_leaf(directory.value, kLiveLeaf, expected);
    const Shape before = observe(directory.value);

    int signal_pipe[2]{};
    require(::pipe2(signal_pipe, O_CLOEXEC) == 0, "create crash signal pipe");
    UniqueFd reader(signal_pipe[0]);
    UniqueFd writer(signal_pipe[1]);
    const pid_t child = ::fork();
    require(child >= 0, "fork crash child");
    if (child == 0) {
        (void)::close(reader.value);
        Cell cell = retain(directory.value);
        if (cut == 0) {
            write_one(writer.value, 'R');
        } else {
            const BurnResult burned = cell.burn_before_decode();
            if (!burned.namespace_bound()) _exit(112);
            const bool synced = burned.disposition == BurnDisposition::bound_and_synced;
            if (cut == 1) {
                write_one(writer.value, synced ? 'B' : 'U');
            } else {
                const PendingResult queried = cell.query_pending_exact(expected);
                if (!queried.exact()) _exit(113);
                write_one(writer.value, synced ? 'Q' : 'V');
            }
        }
        for (;;) ::pause();
    }
    (void)::close(writer.value);
    writer.value = -1;
    const char marker = read_one(reader.value);
    const bool valid_marker = cut == 0 ? marker == 'R'
        : cut == 1 ? (marker == 'B' || marker == 'U')
                   : (marker == 'Q' || marker == 'V');
    require(valid_marker, "unexpected crash-cut marker");
    require(::kill(child, SIGKILL) == 0, "kill crash child");
    wait_killed(child);

    const Shape after = observe(directory.value);
    std::string validation = "NOT_QUERIED";
    if (after.pending) {
        Cell cell = retain(directory.value);
        validation = pending_result_name(cell.query_pending_exact(expected));
    }
    const bool expected_shape = cut == 0
        ? (after.live && !after.pending)
        : (!after.live && after.pending);
    require(expected_shape, "scheduled process cut shape " + name);
    return CaseRow{
        name,
        cut == 0 ? "NOT_CALLED"
                 : (marker == 'U' || marker == 'V'
                    ? "BOUND_SYNC_UNCERTAIN" : "BOUND_SYNCED"),
        validation,
        after.live,
        after.pending,
        cut == 0 ? false : before.live_inode == after.pending_inode,
        1U,
        cut == 0 ? 0U : 1U,
        true,
        false,
        cut == 0 ? "PREADMISSION_REMAINS_LIVE"
                 : "POST_RETURN_REOPENS_PENDING",
    };
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "cases.tsv", std::ios::binary);
    require(stream.good(), "open cases.tsv");
    stream << "case\tburn\tvalidation\tlive\tpending\tsame_inode"
              "\tcontenders\tsuccessful_binds\tprocess_death_cut"
              "\tretained_counterexample\tjudgment\n";
    for (const CaseRow& row : rows) {
        stream << row.name << '\t' << row.burn << '\t' << row.validation << '\t'
               << bool_text(row.live) << '\t' << bool_text(row.pending) << '\t'
               << bool_text(row.same_inode) << '\t' << row.contenders << '\t'
               << row.successful_binds << '\t'
               << bool_text(row.process_death_cut) << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<Counterexample>& rows) {
    std::ofstream stream(output / "counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const Counterexample& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_trace(const std::filesystem::path& output) {
    std::ofstream stream(output / "cut-trace.tsv", std::ios::binary);
    require(stream.good(), "open cut-trace.tsv");
    stream << "cut\tlocal_shape\tpermitted_recovery\tproves\n"
           << "before_admission_call\tLIVE\tNO_APPLY"
              "\tprocess_cut_observation_only\n"
           << "after_burn_and_directory_sync_return_before_decode"
              "\tPENDING\tQUERY_PENDING_ONLY"
              "\tcompleted_call_returns_with_pending_name\n"
           << "after_exact_readback\tPENDING\tQUERY_PENDING_ONLY"
              "\tvalidation_does_not_restore_live\n"
           << "after_local_snapshot_restore\tLIVE"
              "\tFAIL_STOP_WITHOUT_EXTERNAL_FLOOR"
              "\tlocal_newestness_is_unprovable\n";
}

void write_summary(const std::filesystem::path& output,
                   const std::size_t case_count,
                   const std::size_t counterexample_count,
                   const PrincipalCampaignCounts& principal,
                   const LaunchQueryCampaignCounts& launch_query,
                   const EndpointPublicationCampaignCounts& endpoint,
                   const EndpointClaimCampaignCounts& endpoint_claim,
                   const SettlementCampaignCounts& settlement,
                   const EtcdHistoryProfileCampaignCounts& etcd_profile,
                   const ReleaseIngressCampaignCounts& release_ingress,
                   const RootedReleaseCampaignCounts& rooted_release,
                   const SealedSnapshotOfferCampaignCounts& sealed_offer,
                   const AcquisitionActorCampaignCounts& acquisition_actor,
                   const ActorExecCampaignCounts& actor_exec,
                   const StaticActorCampaignCounts& static_actor,
                   const AppraiserReceiptCampaignCounts& appraiser_receipt,
                   const AppraiserReceiptSpendCampaignCounts& receipt_spend,
                   const ExternalRollbackFloorCampaignCounts& external_floor) {
    std::ofstream stream(output / "summary.json", std::ios::binary);
    require(stream.good(), "open summary.json");
    stream
        << "{\n"
        << "  \"acquisition_actor_admissible_profiles\": "
        << acquisition_actor.admissible_profiles << ",\n"
        << "  \"acquisition_actor_cases\": " << acquisition_actor.cases << ",\n"
        << "  \"acquisition_actor_counterexamples\": "
        << acquisition_actor.counterexamples << ",\n"
        << "  \"acquisition_actor_host_applicable_profiles\": "
        << acquisition_actor.host_applicable_profiles << ",\n"
        << "  \"acquisition_actor_incoherent_observations\": "
        << acquisition_actor.incoherent_observations << ",\n"
        << "  \"actor_exec_cases\": " << actor_exec.cases << ",\n"
        << "  \"actor_exec_counterexamples\": " << actor_exec.counterexamples << ",\n"
        << "  \"actor_exec_exec_input_bound_profiles\": "
        << actor_exec.exec_input_bound_profiles << ",\n"
        << "  \"actor_exec_runtime_object_set_bound_profiles\": "
        << actor_exec.runtime_object_set_bound_profiles << ",\n"
        << "  \"actor_exec_exec_epoch_held_profiles\": "
        << actor_exec.exec_epoch_held_profiles << ",\n"
        << "  \"actor_exec_pre_exec_floor_bound_profiles\": "
        << actor_exec.pre_exec_floor_bound_profiles << ",\n"
        << "  \"actor_exec_v13_eligible_profiles\": "
        << actor_exec.v13_eligible_profiles << ",\n"
        << "  \"appraiser_receipt_cases\": "
        << appraiser_receipt.cases << ",\n"
        << "  \"appraiser_receipt_counterexamples\": "
        << appraiser_receipt.counterexamples << ",\n"
        << "  \"appraiser_receipt_canonical_profiles\": "
        << appraiser_receipt.canonical_receipt_profiles << ",\n"
        << "  \"appraiser_receipt_signed_statement_profiles\": "
        << appraiser_receipt.signed_statement_profiles << ",\n"
        << "  \"appraiser_receipt_independent_profiles\": "
        << appraiser_receipt.independent_appraisal_profiles << ",\n"
        << "  \"appraiser_receipt_v13_eligible_profiles\": "
        << appraiser_receipt.v13_eligible_profiles << ",\n"
        << "  \"appraiser_receipt_mutation_rejections\": "
        << appraiser_receipt.mutation_rejections << ",\n"
        << "  \"appraiser_receipt_spend_cases\": "
        << receipt_spend.cases << ",\n"
        << "  \"appraiser_receipt_spend_counterexamples\": "
        << receipt_spend.counterexamples << ",\n"
        << "  \"appraiser_receipt_spend_canonical_cross_bound_profiles\": "
        << receipt_spend.canonical_cross_bound_profiles << ",\n"
        << "  \"appraiser_receipt_spend_content_bound_profiles\": "
        << receipt_spend.content_bound_spend_profiles << ",\n"
        << "  \"appraiser_receipt_spend_local_profiles\": "
        << receipt_spend.local_spend_profiles << ",\n"
        << "  \"appraiser_receipt_spend_external_floor_profiles\": "
        << receipt_spend.external_floor_profiles << ",\n"
        << "  \"appraiser_receipt_spend_external_profiles\": "
        << receipt_spend.externally_spent_profiles << ",\n"
        << "  \"appraiser_receipt_spend_mutation_rejections\": "
        << receipt_spend.mutation_rejections << ",\n"
        << "  \"external_floor_cases\": " << external_floor.cases << ",\n"
        << "  \"external_floor_counterexamples\": "
        << external_floor.counterexamples << ",\n"
        << "  \"external_floor_exact_profile_profiles\": "
        << external_floor.exact_profile_profiles << ",\n"
        << "  \"external_floor_v18_spend_profiles\": "
        << external_floor.v18_spend_profiles << ",\n"
        << "  \"external_floor_prestate_certified_profiles\": "
        << external_floor.prestate_certified_profiles << ",\n"
        << "  \"external_floor_extend_request_profiles\": "
        << external_floor.extend_request_profiles << ",\n"
        << "  \"external_floor_poststate_certified_profiles\": "
        << external_floor.poststate_certified_profiles << ",\n"
        << "  \"external_floor_witness_advanced_profiles\": "
        << external_floor.witness_advanced_profiles << ",\n"
        << "  \"external_floor_query_only_profiles\": "
        << external_floor.query_only_profiles << ",\n"
        << "  \"external_floor_complete_transcript_profiles\": "
        << external_floor.complete_transcript_profiles << ",\n"
        << "  \"external_floor_cross_ledger_join_profiles\": "
        << external_floor.cross_ledger_join_profiles << ",\n"
        << "  \"external_floor_bound_profiles\": "
        << external_floor.external_floor_profiles << ",\n"
        << "  \"external_floor_mutation_rejections\": "
        << external_floor.mutation_rejections << ",\n"
        << "  \"static_actor_cases\": " << static_actor.cases << ",\n"
        << "  \"static_actor_counterexamples\": "
        << static_actor.counterexamples << ",\n"
        << "  \"static_actor_static_profile_exact\": "
        << static_actor.static_profile_exact << ",\n"
        << "  \"static_actor_pre_exec_floor_bound\": "
        << static_actor.pre_exec_floor_bound << ",\n"
        << "  \"static_actor_pre_exec_seccomp_installation_observation_bound\": "
        << static_actor.pre_exec_seccomp_installation_observation_bound << ",\n"
        << "  \"static_actor_held_user_mapping_set_bound\": "
        << static_actor.held_user_mapping_set_bound << ",\n"
        << "  \"static_actor_post_exec_floor_bound\": "
        << static_actor.post_exec_floor_bound << ",\n"
        << "  \"static_actor_hosted_envelope_bound\": "
        << static_actor.hosted_envelope_bound << ",\n"
        << "  \"static_actor_independent_appraisal_bound\": "
        << static_actor.independent_appraisal_bound << ",\n"
        << "  \"static_actor_v13_eligible\": "
        << static_actor.v13_eligible << ",\n"
        << "  \"authority_granted\": false,\n"
        << "  \"canonical_record_bytes\": 128,\n"
        << "  \"cases\": " << case_count << ",\n"
        << "  \"counterexamples\": " << counterexample_count << ",\n"
        << "  \"decode_before_burn_calls\": 0,\n"
        << "  \"endpoint_claim_cases\": " << endpoint_claim.cases << ",\n"
        << "  \"endpoint_claim_counterexamples\": "
        << endpoint_claim.counterexamples << ",\n"
        << "  \"endpoint_claim_crash_cuts\": "
        << endpoint_claim.crash_cuts << ",\n"
        << "  \"endpoint_claim_race_contenders\": "
        << endpoint_claim.race_contenders << ",\n"
        << "  \"endpoint_publication_cases\": " << endpoint.cases << ",\n"
        << "  \"endpoint_publication_counterexamples\": "
        << endpoint.counterexamples << ",\n"
        << "  \"etcd_profile_cases\": " << etcd_profile.cases << ",\n"
        << "  \"etcd_profile_counterexamples\": "
        << etcd_profile.counterexamples << ",\n"
        << "  \"etcd_profile_exact_current_observations\": "
        << etcd_profile.exact_current_observations << ",\n"
        << "  \"etcd_profile_operated\": false,\n"
        << "  \"etcd_profile_synthetic_runtime_observations\": "
        << etcd_profile.synthetic_runtime_observations << ",\n"
        << "  \"expected_provider_capsule_bytes\": 96,\n"
        << "  \"expected_provider_process_input_observed\": true,\n"
        << "  \"expected_provider_process_spent_before_connect\": true,\n"
        << "  \"expectation_constructor_protected\": false,\n"
        << "  \"external_rollback_floor\": false,\n"
        << "  \"fixed_live_leaf\": \"live\",\n"
        << "  \"fixed_pending_leaf\": \"pending\",\n"
        << "  \"independent_actor\": false,\n"
        << "  \"launch_query_cases\": " << launch_query.cases << ",\n"
        << "  \"launch_query_counterexamples\": "
        << launch_query.counterexamples << ",\n"
        << "  \"maximum_successful_bind_count\": 1,\n"
        << "  \"globally_unique_expectation_spend_proved\": false,\n"
        << "  \"owner_admitted_provider_process\": false,\n"
        << "  \"physical_power_loss_proved\": false,\n"
        << "  \"principal_cases\": " << principal.principal_cases << ",\n"
        << "  \"principal_counterexamples\": "
        << principal.counterexamples << ",\n"
        << "  \"process_crash_cuts\": 3,\n"
        << "  \"campaign_alone_proves_kernel_atomicity\": false,\n"
        << "  \"kernel_rename_atomicity_contract_relied_on\": true,\n"
        << "  \"process_visible_namespace_partition_observed\": true,\n"
        << "  \"protected_spent_identity\": false,\n"
        << "  \"recovery_apply_entrypoints\": 0,\n"
        << "  \"rename_flag\": \"RENAME_NOREPLACE\",\n"
        << "  \"rollback_counterexample_reproduced\": true,\n"
        << "  \"publication_cases\": " << principal.publication_cases << ",\n"
        << "  \"provider_principal_observed\": true,\n"
        << "  \"hosted_settlement_adapter_implemented\": true,\n"
        << "  \"settlement_cases\": " << settlement.cases << ",\n"
        << "  \"settlement_counterexamples\": "
        << settlement.counterexamples << ",\n"
        << "  \"settlement_crash_cuts\": " << settlement.crash_cuts << ",\n"
        << "  \"settlement_race_contenders\": "
        << settlement.race_contenders << ",\n"
        << "  \"settlement_race_local_claims\": "
        << settlement.race_local_claims << ",\n"
        << "  \"settlement_race_provider_fresh_commits\": "
        << settlement.race_provider_fresh_commits << ",\n"
        << "  \"settlement_race_provider_duplicates\": "
        << settlement.race_provider_duplicates << ",\n"
        << "  \"settlement_race_effects\": "
        << settlement.race_effects << ",\n"
        << "  \"settlement_response_authority\": false,\n"
        << "  \"settlement_retry_authority\": false,\n"
        << "  \"release_ingress_activation_authority\": false,\n"
        << "  \"release_ingress_activation_boundary_violations\": "
        << release_ingress.activation_boundary_violations << ",\n"
        << "  \"release_ingress_cases\": " << release_ingress.cases << ",\n"
        << "  \"release_ingress_counterexamples\": "
        << release_ingress.counterexamples << ",\n"
        << "  \"release_ingress_exact_passive_admissions\": "
        << release_ingress.exact_passive_admissions << ",\n"
        << "  \"release_ingress_incoherent_observations\": "
        << release_ingress.incoherent_observations << ",\n"
        << "  \"release_ingress_path_replacement_admissions\": "
        << release_ingress.path_replacement_admissions << ",\n"
        << "  \"release_ingress_snapshot_write_seal_required\": true,\n"
        << "  \"rooted_release_cases\": " << rooted_release.cases << ",\n"
        << "  \"rooted_release_counterexamples\": "
        << rooted_release.counterexamples << ",\n"
        << "  \"rooted_release_owner_custody_proved\": false,\n"
        << "  \"rooted_release_path_replacement_ready_descriptors\": "
        << rooted_release.path_replacement_ready_descriptors << ",\n"
        << "  \"rooted_release_ready_descriptors\": "
        << rooted_release.ready_descriptors << ",\n"
        << "  \"rooted_release_root_path_reopen_rejections\": "
        << rooted_release.root_path_reopen_rejections << ",\n"
        << "  \"sealed_snapshot_offer_cases\": " << sealed_offer.cases << ",\n"
        << "  \"sealed_snapshot_offer_counterexamples\": "
        << sealed_offer.counterexamples << ",\n"
        << "  \"sealed_snapshot_offer_admitted_ready_sources\": "
        << sealed_offer.admitted_ready_sources << ",\n"
        << "  \"sealed_snapshot_offer_mechanism_ready_actor_rejections\": "
        << sealed_offer.mechanism_ready_actor_rejections << ",\n"
        << "  \"sealed_snapshot_offer_preoffer_alias_rejections\": "
        << sealed_offer.preoffer_alias_rejections << ",\n"
        << "  \"sealed_snapshot_offer_pre_receive_actor_rejections\": "
        << sealed_offer.pre_receive_actor_rejections << ",\n"
        << "  \"sealed_snapshot_offer_post_receive_authority_import_incoherences\": "
        << sealed_offer.post_receive_authority_import_incoherences << ",\n"
        << "  \"schema\": \"slopos.rev0907.handoff-cell-campaign.v19\",\n"
        << "  \"source_to_binary_proved\": false,\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"successful_race_binds\": 1,\n"
        << "  \"writer_custody_counterexample_reproduced\": true\n"
        << "}\n";
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    require(!std::filesystem::exists(output), "output must be absent");
    require(std::filesystem::create_directories(output), "create output");
    const auto scratch = output.parent_path() /
        (output.filename().string() + ".scratch");
    require(!std::filesystem::exists(scratch), "scratch must be absent");
    require(std::filesystem::create_directory(scratch), "create scratch");

    const EncodedRecord expected = canonical_pending();
    std::vector<CaseRow> rows;
    std::vector<Counterexample> counterexamples;

    // 1. Exact pre-staged identity: the same inode moves from live to pending.
    {
        const auto path = make_cell(scratch, "exact");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kLiveLeaf, expected);
        const Shape before = observe(directory.value);
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        require(burned.namespace_bound(), "exact burn");
        const PendingResult pending = cell.query_pending_exact(expected);
        const Shape after = observe(directory.value);
        require(pending.exact() && !after.live && after.pending
                && before.live_inode == after.pending_inode,
                "exact handoff invariant");
        const PendingResult repeated = cell.query_pending_exact(expected);
        require(repeated.exact(), "query-only repeated read");
        rows.push_back({"exact_identity", burn_name(burned.disposition),
                        pending_result_name(pending), after.live, after.pending,
                        before.live_inode == after.pending_inode, 1U, 1U, false,
                        false, "LOCAL_NO_REPLACE_HANDOFF_OBSERVED"});
    }

    // 2. Malformed bytes are consumed before canonical decoding rejects them.
    {
        EncodedRecord malformed = expected;
        malformed[8U] ^= 0x01U;
        const auto path = make_cell(scratch, "malformed");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kLiveLeaf, malformed);
        const Shape before = observe(directory.value);
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        const PendingResult pending = cell.query_pending_exact(malformed);
        const Shape after = observe(directory.value);
        require(burned.namespace_bound()
                && pending.disposition == PendingDisposition::decode_rejected
                && !after.live && after.pending
                && before.live_inode == after.pending_inode,
                "malformed burns before decode");
        rows.push_back({"malformed_burns_before_decode",
                        burn_name(burned.disposition), pending_result_name(pending),
                        after.live, after.pending,
                        before.live_inode == after.pending_inode, 1U, 1U, false,
                        false, "REJECTED_AFTER_ONE_WAY_API_NAME_CUT"});
    }

    // 3. A malformed FIFO is burned, then rejected without a blocking open.
    {
        const auto path = make_cell(scratch, "fifo");
        const UniqueFd directory = open_directory(path);
        require(::mkfifoat(directory.value, kLiveLeaf, S_IRUSR | S_IWUSR) == 0,
                "create FIFO fixture");
        require(::fsync(directory.value) == 0, "fsync FIFO fixture directory");
        const Shape before = observe(directory.value);
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        const PendingResult pending = cell.query_pending_exact(expected);
        const Shape after = observe(directory.value);
        require(burned.namespace_bound()
                && pending.disposition == PendingDisposition::not_regular
                && !after.live && after.pending
                && before.live_inode == after.pending_inode,
                "FIFO burns then fails closed without blocking");
        rows.push_back({"fifo_burns_then_fails_nonregular",
                        burn_name(burned.disposition), pending_result_name(pending),
                        after.live, after.pending,
                        before.live_inode == after.pending_inode, 1U, 1U, false,
                        false, "FAIL_STOP_NONREGULAR_WITHOUT_BLOCK"});
    }

    // 4. Existing pending identity is never overwritten.
    {
        const auto path = make_cell(scratch, "pending-conflict");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kLiveLeaf, expected);
        write_leaf(directory.value, kPendingLeaf, expected);
        const Shape before = observe(directory.value);
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        const Shape after = observe(directory.value);
        require(burned.disposition == BurnDisposition::pending_exists
                && before.live_inode == after.live_inode
                && before.pending_inode == after.pending_inode
                && after.live && after.pending,
                "pending no-replace conflict");
        rows.push_back({"pending_no_replace_conflict", burn_name(burned.disposition),
                        "NOT_QUERIED", after.live, after.pending, false, 1U, 0U,
                        false, false, "FAIL_STOP_NO_OVERWRITE"});
    }

    // 5. Missing live identity cannot be minted by the handoff API.
    {
        const auto path = make_cell(scratch, "missing-live");
        const UniqueFd directory = open_directory(path);
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        const Shape after = observe(directory.value);
        require(burned.disposition == BurnDisposition::live_missing
                && !after.live && !after.pending,
                "missing live does not mint");
        rows.push_back({"missing_live_no_mint", burn_name(burned.disposition),
                        "NOT_QUERIED", false, false, false, 1U, 0U, false, false,
                        "NO_MINT_NO_RETRY"});
    }

    rows.push_back(crash_case(scratch, "crash_before_admission_call", 0, expected));
    rows.push_back(crash_case(scratch, "crash_after_burn_and_sync_return", 1, expected));
    rows.push_back(crash_case(scratch, "crash_after_exact_readback", 2, expected));

    // 9. Sixteen independent processes race the one fixed cut; one binds.
    {
        constexpr unsigned int contenders = 16U;
        const auto path = make_cell(scratch, "race");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kLiveLeaf, expected);
        int start_pipe[2]{};
        int result_pipe[2]{};
        require(::pipe2(start_pipe, O_CLOEXEC) == 0, "race start pipe");
        require(::pipe2(result_pipe, O_CLOEXEC) == 0, "race result pipe");
        UniqueFd start_read(start_pipe[0]);
        UniqueFd start_write(start_pipe[1]);
        UniqueFd result_read(result_pipe[0]);
        UniqueFd result_write(result_pipe[1]);
        std::vector<pid_t> children;
        for (unsigned int index = 0U; index < contenders; ++index) {
            const pid_t child = ::fork();
            require(child >= 0, "fork race child");
            if (child == 0) {
                (void)::close(start_write.value);
                (void)::close(result_read.value);
                (void)read_one(start_read.value);
                Cell cell = retain(directory.value);
                const BurnResult burned = cell.burn_before_decode();
                const char code = burned.namespace_bound() ? 'S'
                    : burned.disposition == BurnDisposition::live_missing ? 'M'
                    : burned.disposition == BurnDisposition::pending_exists ? 'P' : 'E';
                write_one(result_write.value, code);
                _exit(0);
            }
            children.push_back(child);
        }
        (void)::close(start_read.value); start_read.value = -1;
        (void)::close(result_write.value); result_write.value = -1;
        for (unsigned int index = 0U; index < contenders; ++index) {
            write_one(start_write.value, 'G');
        }
        (void)::close(start_write.value); start_write.value = -1;
        unsigned int successes = 0U;
        unsigned int expected_losers = 0U;
        for (unsigned int index = 0U; index < contenders; ++index) {
            const char code = read_one(result_read.value);
            if (code == 'S') ++successes;
            else if (code == 'M' || code == 'P') ++expected_losers;
            else fail("unexpected race result");
        }
        for (const pid_t child : children) {
            int status = 0;
            require(::waitpid(child, &status, 0) == child
                    && WIFEXITED(status) && WEXITSTATUS(status) == 0,
                    "wait race child");
        }
        Cell cell = retain(directory.value);
        const PendingResult pending = cell.query_pending_exact(expected);
        const Shape after = observe(directory.value);
        require(successes == 1U && expected_losers == contenders - 1U
                && pending.exact() && !after.live && after.pending,
                "one successful concurrent bind");
        rows.push_back({"sixteen_process_race", "ONE_BOUND_REST_REJECTED",
                        pending_result_name(pending), after.live, after.pending,
                        true, contenders, successes, false, false,
                        "ONE_NAMESPACE_WINNER"});
    }

    // 10. A hard-link alias survives the name move and is detected while live.
    {
        const auto path = make_cell(scratch, "hardlink-alias");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kLiveLeaf, expected);
        require(::linkat(directory.value, kLiveLeaf, directory.value,
                         "alias", 0) == 0, "create hard-link alias");
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        const PendingResult pending = cell.query_pending_exact(expected);
        const Shape after = observe(directory.value);
        const bool reproduced = burned.namespace_bound()
            && pending.disposition == PendingDisposition::alias_detected
            && after.pending && after.pending_links == 2U;
        require(reproduced, "hard-link alias counterexample");
        rows.push_back({"hardlink_alias_survives", burn_name(burned.disposition),
                        pending_result_name(pending), after.live, after.pending,
                        false, 1U, 1U, false, true,
                        "NAME_BURN_IS_NOT_OBJECT_EXCLUSIVITY"});
        counterexamples.push_back({
            "hard_link_alias_survives_rename", true,
            "claim that consuming one pathname consumes every object reference",
            "protected admission must control aliases and open handles, not only names"});
    }

    // 11. Even nlink==1 does not reveal an already-open writable descriptor.
    {
        const auto path = make_cell(scratch, "retained-writer");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kLiveLeaf, expected);
        const UniqueFd writer(::openat(directory.value, kLiveLeaf,
                                      O_RDWR | O_CLOEXEC));
        require(writer.value >= 0, "open retained writer");
        Cell cell = retain(directory.value);
        const BurnResult burned = cell.burn_before_decode();
        const PendingResult accepted = cell.query_pending_exact(expected);
        require(accepted.exact(), "pending initially exact with retained writer");
        const std::uint8_t changed = static_cast<std::uint8_t>(expected[0U] ^ 1U);
        require(::pwrite(writer.value, &changed, 1U, 0) == 1,
                "mutate through retained writer");
        require(::fdatasync(writer.value) == 0, "sync retained writer mutation");
        const PendingResult changed_result = cell.query_pending_exact(expected);
        const Shape after = observe(directory.value);
        const bool reproduced = burned.namespace_bound()
            && changed_result.disposition == PendingDisposition::exact_mismatch
            && after.pending && after.pending_links == 1U;
        require(reproduced, "retained writer counterexample");
        rows.push_back({"open_writer_survives_rename", burn_name(burned.disposition),
                        pending_result_name(changed_result), after.live, after.pending,
                        false, 1U, 1U, false, true,
                        "EXCLUSIVE_WRITER_CUSTODY_REQUIRED"});
        counterexamples.push_back({
            "open_writable_fd_survives_rename", true,
            "claim that nlink one plus exact readback makes pending immutable",
            "the protected provider must exclude inherited writers across the cut"});
    }

    // 12. A coherent local snapshot can reproduce the pre-burn observation.
    {
        const auto original_path = make_cell(scratch, "rollback-original");
        const UniqueFd original = open_directory(original_path);
        write_leaf(original.value, kLiveLeaf, expected);
        const Shape initial = observe(original.value);
        Cell cell = retain(original.value);
        const BurnResult burned = cell.burn_before_decode();
        require(burned.namespace_bound(), "rollback original burn");
        const auto restored_path = make_cell(scratch, "rollback-restored");
        const UniqueFd restored = open_directory(restored_path);
        write_leaf(restored.value, kLiveLeaf, expected);
        const Shape restored_shape = observe(restored.value);
        const bool reproduced = initial.live && !initial.pending
            && restored_shape.live && !restored_shape.pending;
        require(reproduced, "rollback local shape reproduction");
        rows.push_back({"coherent_snapshot_rollback", burn_name(burned.disposition),
                        "LOCAL_PREBURN_SHAPE_REPRODUCED", restored_shape.live,
                        restored_shape.pending, false, 1U, 1U, false, true,
                        "EXTERNAL_NEWESTNESS_FLOOR_REQUIRED"});
        counterexamples.push_back({
            "coherent_local_snapshot_rollback", true,
            "claim that locally consistent storage proves newest spent state",
            "newestness and anti-replay require an independently rooted monotonic floor"});
    }

    require(rows.size() == 12U, "case inventory");
    require(counterexamples.size() == 3U, "counterexample inventory");
    write_cases(output, rows);
    write_counterexamples(output, counterexamples);
    write_trace(output);
    const PrincipalCampaignCounts principal =
        run_principal_campaign(output, scratch, expected);
    const LaunchQueryCampaignCounts launch_query =
        run_launch_query_campaign(output, scratch);
    const EndpointPublicationCampaignCounts endpoint =
        run_endpoint_publication_campaign(output, scratch);
    const EndpointClaimCampaignCounts endpoint_claim =
        run_endpoint_claim_campaign(output, scratch, expected);
    const SettlementCampaignCounts settlement =
        run_settlement_campaign(output, scratch, expected);
    std::cout << "HANDOFF_CELL_PHASE=provider-genesis\n";
    run_provider_genesis_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=etcd-history-profile\n";
    const EtcdHistoryProfileCampaignCounts etcd_profile =
        run_etcd_history_profile_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=release-ingress\n";
    const ReleaseIngressCampaignCounts release_ingress =
        run_release_ingress_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=rooted-release-locator\n";
    const RootedReleaseCampaignCounts rooted_release =
        run_rooted_release_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=sealed-snapshot-offer\n";
    const SealedSnapshotOfferCampaignCounts sealed_offer =
        run_sealed_snapshot_offer_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=acquisition-actor-admission\n";
    const AcquisitionActorCampaignCounts acquisition_actor =
        run_acquisition_actor_admission_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=actor-exec-binding\n";
    const ActorExecCampaignCounts actor_exec =
        run_actor_exec_binding_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=static-actor-confinement\n";
    const StaticActorCampaignCounts static_actor =
        run_static_actor_confinement_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=appraiser-receipt\n";
    const AppraiserReceiptCampaignCounts appraiser_receipt =
        run_appraiser_receipt_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=appraiser-receipt-spend\n";
    const AppraiserReceiptSpendCampaignCounts receipt_spend =
        run_appraiser_receipt_spend_campaign(output);
    std::cout << "HANDOFF_CELL_PHASE=external-rollback-floor\n";
    const ExternalRollbackFloorCampaignCounts external_floor =
        run_external_rollback_floor_campaign(output);
    write_summary(output, rows.size(), counterexamples.size(), principal,
                  launch_query, endpoint, endpoint_claim, settlement,
                  etcd_profile, release_ingress, rooted_release, sealed_offer,
                  acquisition_actor, actor_exec, static_actor,
                  appraiser_receipt, receipt_spend, external_floor);
    std::filesystem::remove_all(scratch);

    std::cout
        << "HANDOFF_CELL_CAMPAIGN=PASS cases=12 crash_cuts=3 contenders=16 "
        << "successful_binds=1 counterexamples=3 principal_cases="
        << principal.principal_cases << " publication_cases="
        << principal.publication_cases << " principal_counterexamples="
        << principal.counterexamples << " launch_query_cases="
        << launch_query.cases << " launch_query_counterexamples="
        << launch_query.counterexamples << " endpoint_publication_cases="
        << endpoint.cases << " endpoint_publication_counterexamples="
        << endpoint.counterexamples << " endpoint_claim_cases="
        << endpoint_claim.cases << " endpoint_claim_counterexamples="
        << endpoint_claim.counterexamples << " endpoint_claim_crash_cuts="
        << endpoint_claim.crash_cuts << " settlement_cases="
        << settlement.cases << " settlement_counterexamples="
        << settlement.counterexamples << " settlement_crash_cuts="
        << settlement.crash_cuts << " settlement_race_provider_commits="
        << settlement.race_provider_fresh_commits
        << " etcd_profile_cases=" << etcd_profile.cases
        << " release_ingress_cases=" << release_ingress.cases
        << " release_ingress_exact_passive="
        << release_ingress.exact_passive_admissions
        << " rooted_release_cases=" << rooted_release.cases
        << " rooted_release_ready=" << rooted_release.ready_descriptors
        << " acquisition_actor_cases=" << acquisition_actor.cases
        << " acquisition_actor_admissible="
        << acquisition_actor.admissible_profiles
        << " acquisition_actor_host_applicable="
        << acquisition_actor.host_applicable_profiles
        << " actor_exec_cases=" << actor_exec.cases
        << " actor_exec_exec_input_bound=" << actor_exec.exec_input_bound_profiles
        << " actor_exec_runtime_bound="
        << actor_exec.runtime_object_set_bound_profiles
        << " actor_exec_epoch_held=" << actor_exec.exec_epoch_held_profiles
        << " actor_exec_pre_exec_floor="
        << actor_exec.pre_exec_floor_bound_profiles
        << " actor_exec_v13_eligible=" << actor_exec.v13_eligible_profiles
        << " static_actor_cases=" << static_actor.cases
        << " static_actor_hosted_envelope=" << static_actor.hosted_envelope_bound
        << " static_actor_independent=" << static_actor.independent_appraisal_bound
        << " static_actor_v13_eligible=" << static_actor.v13_eligible
        << " appraiser_receipt_cases=" << appraiser_receipt.cases
        << " appraiser_receipt_signed="
        << appraiser_receipt.signed_statement_profiles
        << " appraiser_receipt_independent="
        << appraiser_receipt.independent_appraisal_profiles
        << " appraiser_receipt_v13="
        << appraiser_receipt.v13_eligible_profiles
        << " appraiser_receipt_spend_cases=" << receipt_spend.cases
        << " appraiser_receipt_spend_local="
        << receipt_spend.local_spend_profiles
        << " appraiser_receipt_spend_external="
        << receipt_spend.externally_spent_profiles
        << " external_floor_cases=" << external_floor.cases
        << " external_floor_exact_profiles="
        << external_floor.exact_profile_profiles
        << " external_floor_bound=" << external_floor.external_floor_profiles
        << " etcd_profile_operated=false decode_before_burn=0 "
        << "process_death_cuts=3 process_visible_partition=true "
        << "kernel_atomicity_proved_by_campaign=false protected_identity=false "
        << "stable_media=false authority=false\n";
    return 0;
}

}  // namespace slopos::e0::handoff_cell::harness
