#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

// A descriptor-rooted locator relation. It ends with one read-only candidate
// descriptor only when nonregular objects are rejected atomically by the open
// operation itself. It does not read candidate bytes, compare a digest, parse
// an archive, activate a binary, operate a provider, or establish owner custody.
enum class RootedReleaseLeafOutcome : std::uint8_t {
    not_attempted,
    unavailable,
    policy_rejected,
    opened,
};

enum class RootedReleaseDisposition : std::uint8_t {
    observation_incoherent,
    root_descriptor_unavailable,
    root_descriptor_unpinned,
    root_descriptor_not_o_path,
    root_not_directory,
    root_profile_rejected,
    resolution_policy_unavailable,
    regular_only_policy_unavailable,
    fixed_leaf_unavailable,
    fixed_leaf_policy_rejected,
    root_path_reopen_rejected,
    root_identity_changed,
    root_profile_changed,
    regular_only_contract_violated,
    leaf_cross_device,
    candidate_descriptor_ready,
};

// These fields form an ordered observation prefix. A caller supplies an
// already-open descriptor. The adapter must first duplicate it with
// close-on-exec, independently observe the O_PATH flag and directory type,
// check one hosted private-root profile, and then open one fixed leaf through
// openat2 with every listed resolution restriction plus OPENAT2_REGULAR.
// Post-open fstat is retained as a contract check; it is not the mechanism that
// prevents a FIFO or device from being opened. Leaf and post-lookup fields are
// coherent only after an opened leaf. Equal pre/post profile observations do
// not prove uninterrupted profile continuity.
struct RootedReleaseObservationV1 final {
    bool root_descriptor_supplied{false};
    bool root_descriptor_cloexec_duplicate{false};
    bool root_descriptor_o_path{false};
    bool root_is_directory{false};
    bool root_owner_matches_host_profile{false};
    bool root_mode_private{false};
    bool fixed_leaf_name{false};
    bool openat2_available{false};
    bool resolve_beneath{false};
    bool resolve_no_symlinks{false};
    bool resolve_no_magiclinks{false};
    bool resolve_no_xdev{false};
    bool regular_only_open_enforced{false};
    RootedReleaseLeafOutcome leaf_outcome{
        RootedReleaseLeafOutcome::not_attempted};
    bool leaf_regular{false};
    bool leaf_same_device{false};
    bool root_identity_stable{false};
    bool root_profile_reobserved_equal{false};
    bool root_path_replaced_after_pin{false};
    bool caller_root_path_reopened{false};
};

// A copyable, authority-negative report. Descriptor duplication, O_PATH
// profile, regular-only open enforcement, and pre/post identity agreement are
// distinct observations. Equal endpoint profiles are retained without claiming
// continuous custody. candidate_descriptor_ready means only that the hosted
// locator cut may hand one descriptor to the existing sealed-snapshot gate.
struct RootedReleaseAssessment final {
    RootedReleaseDisposition disposition{
        RootedReleaseDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool root_descriptor_pinned{false};
    bool root_descriptor_o_path{false};
    bool root_identity_retained{false};
    bool root_profile_reobserved_equal{false};
    bool root_profile_continuity_proved{false};
    bool hosted_private_root_profile{false};
    bool fixed_leaf_only{false};
    bool all_component_symlink_rejection{false};
    bool beneath_restriction{false};
    bool cross_mount_rejection{false};
    bool regular_only_open_enforced{false};
    bool post_open_shape_is_contract_check_only{false};
    bool root_path_replacement_ignored{false};
    bool candidate_descriptor_ready{false};
    bool candidate_bytes_read{false};
    bool archive_digest_compared{false};
    bool archive_parsed{false};
    bool caller_root_path_authority{false};
    bool owner_custody_proved{false};
    bool source_provenance_proved{false};
    bool activation_authority{false};
    bool provider_operation_authority{false};

    [[nodiscard]] constexpr bool ready() const noexcept {
        return disposition == RootedReleaseDisposition::candidate_descriptor_ready;
    }
};

[[nodiscard]] RootedReleaseAssessment assess_rooted_release_locator(
    const RootedReleaseObservationV1& observation) noexcept;
[[nodiscard]] const char* rooted_release_disposition_name(
    RootedReleaseDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
