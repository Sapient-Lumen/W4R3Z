# Predecessor continuity incident and gate

The inherited live `PREDECESSOR/README.md` named rev0934/rev0933 while the actual
rev0937 parent receipt named rev0936. A human could follow the wrong branch after reopen;
the narrative therefore failed as office infrastructure even though payload evidence was
still present.

rev0938 makes the relationship explicit and machine checked:

- active revision: rev0938;
- immediate parent archive: `SlopOS-rev0937-2026.08.06.21.19-rootedshadowpack-exactinverse-racefence-aliasaddress.zip`;
- parent SHA-256: `7a388b46a78ef5a9db598eb68c112bd7a3d23892b0eaa139471669001e2d3b4b`;
- exact stale README preserved at `CANDIDATE/epoch-zero/rev0938/incidents/predecessor-readme-drift/inherited-README.exact`;
- live predecessor payload status: receipt-bound inherited material, **not asserted to be
  a complete byte snapshot** of the parent.

`tools/check_predecessor_contract.py` compares the machine receipt, the hidden contract
block, the human heading, forbidden stale labels, and—when supplied—the actual parent
archive bytes. This is local continuity proof only. It does not authenticate who produced
either archive.
