#include "slopos/epoch_zero/configured_pack_expectation.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <numeric>
#include <string>
#include <tuple>
#include <type_traits>

namespace slopos::epoch_zero::pack {
namespace {

constexpr std::array<Byte, 8> kPackMagic{
    static_cast<Byte>(static_cast<unsigned char>('S')), static_cast<Byte>(static_cast<unsigned char>('L')), static_cast<Byte>(static_cast<unsigned char>('O')), static_cast<Byte>(static_cast<unsigned char>('P')), static_cast<Byte>(static_cast<unsigned char>('P')), static_cast<Byte>(static_cast<unsigned char>('K')), static_cast<Byte>(static_cast<unsigned char>('1')), static_cast<Byte>(static_cast<unsigned char>('\\n'))};
constexpr std::array<Byte, 8> kDescriptorMagic{
    static_cast<Byte>(static_cast<unsigned char>('S')), static_cast<Byte>(static_cast<unsigned char>('L')), static_cast<Byte>(static_cast<unsigned char>('O')), static_cast<Byte>(static_cast<unsigned char>('P')), static_cast<Byte>(static_cast<unsigned char>('D')), static_cast<Byte>(static_cast<unsigned char>('S')), static_cast<Byte>(static_cast<unsigned char>('1')), static_cast<Byte>(static_cast<unsigned char>('\\n'))};
constexpr std::array<Byte, 8> kExpectationMagic{
    static_cast<Byte>(static_cast<unsigned char>('S')), static_cast<Byte>(static_cast<unsigned char>('L')), static_cast<Byte>(static_cast<unsigned char>('O')), static_cast<Byte>(static_cast<unsigned char>('P')), static_cast<Byte>(static_cast<unsigned char>('E')), static_cast<Byte>(static_cast<unsigned char>('X')), static_cast<Byte>(static_cast<unsigned char>('1')), static_cast<Byte>(static_cast<unsigned char>('\\n'))};
constexpr std::size_t kExpectationBytes = 8U + 4U + 8U + 8U + 32U + 32U;

Error make_error(ErrorCode code, std::string detail) {
  return Error{code, std::move(detail)};
}

bool valid_path(std::string_view path) {
  if (path.empty() || path.front() == '/' || path.back() == '/') {
    return false;
  }
  std::size_t segment_start = 0;
  for (std::size_t i = 0; i <= path.size(); ++i) {
    const bool end = i == path.size();
    const unsigned char c = end ? static_cast<unsigned char>('/')
                                : static_cast<unsigned char>(path[i]);
    if (!end && (c < 0x21U || c > 0x7eU || c == static_cast<unsigned char>('\\'))) {
      return false;
    }
    if (end || c == static_cast<unsigned char>('/')) {
      const auto segment = path.substr(segment_start, i - segment_start);
      if (segment.empty() || segment == "." || segment == "..") {
        return false;
      }
      segment_start = i + 1U;
    }
  }
  return true;
}

template <typename UInt>
void append_le(Bytes& out, UInt value) {
  static_assert(std::is_unsigned_v<UInt>);
  for (std::size_t i = 0; i < sizeof(UInt); ++i) {
    out.push_back(static_cast<Byte>((value >> (i * 8U)) & static_cast<UInt>(0xffU)));
  }
}

template <typename UInt>
bool read_le(std::span<const Byte> bytes, std::size_t& cursor, UInt& value) {
  static_assert(std::is_unsigned_v<UInt>);
  if (cursor > bytes.size() || bytes.size() - cursor < sizeof(UInt)) {
    return false;
  }
  value = 0;
  for (std::size_t i = 0; i < sizeof(UInt); ++i) {
    value |= static_cast<UInt>(std::to_integer<unsigned int>(bytes[cursor + i])) << (i * 8U);
  }
  cursor += sizeof(UInt);
  return true;
}

void append_span(Bytes& out, std::span<const Byte> bytes) {
  out.insert(out.end(), bytes.begin(), bytes.end());
}

void append_text(Bytes& out, std::string_view text) {
  out.reserve(out.size() + text.size());
  for (const char c : text) {
    out.push_back(static_cast<Byte>(static_cast<unsigned char>(c)));
  }
}

bool constant_time_equal(std::span<const Byte> lhs, std::span<const Byte> rhs) {
  if (lhs.size() != rhs.size()) {
    return false;
  }
  unsigned int difference = 0U;
  for (std::size_t i = 0; i < lhs.size(); ++i) {
    difference |= std::to_integer<unsigned int>(lhs[i] ^ rhs[i]);
  }
  return difference == 0U;
}

Result<std::vector<const SealedDescriptor*>> sorted_unique(
    std::span<const SealedDescriptor> descriptors) {
  std::vector<const SealedDescriptor*> sorted;
  sorted.reserve(descriptors.size());
  for (const auto& descriptor : descriptors) {
    if (!valid_path(descriptor.logical_path())) {
      return Result<std::vector<const SealedDescriptor*>>::failure(
          make_error(ErrorCode::invalid_logical_path,
                     "descriptor has a non-canonical logical path"));
    }
    sorted.push_back(&descriptor);
  }
  std::sort(sorted.begin(), sorted.end(), [](const auto* lhs, const auto* rhs) {
    return lhs->logical_path() < rhs->logical_path();
  });
  for (std::size_t i = 1; i < sorted.size(); ++i) {
    if (sorted[i - 1]->logical_path() == sorted[i]->logical_path()) {
      return Result<std::vector<const SealedDescriptor*>>::failure(
          make_error(ErrorCode::duplicate_logical_path,
                     "two descriptors claim the same logical path"));
    }
  }
  return Result<std::vector<const SealedDescriptor*>>::success(std::move(sorted));
}

Result<Bytes> canonical_descriptor_bytes(std::span<const SealedDescriptor> descriptors) {
  if (descriptors.size() > std::numeric_limits<std::uint32_t>::max()) {
    return Result<Bytes>::failure(
        make_error(ErrorCode::arithmetic_overflow, "descriptor count exceeds wire format"));
  }
  auto sorted_result = sorted_unique(descriptors);
  if (!sorted_result) {
    return Result<Bytes>::failure(sorted_result.error());
  }
  auto sorted = std::move(sorted_result).take();
  Bytes out;
  append_span(out, kDescriptorMagic);
  append_le<std::uint32_t>(out, static_cast<std::uint32_t>(sorted.size()));
  for (const auto* descriptor : sorted) {
    if (descriptor->logical_path().size() > std::numeric_limits<std::uint32_t>::max()) {
      return Result<Bytes>::failure(
          make_error(ErrorCode::arithmetic_overflow, "logical path exceeds wire format"));
    }
    append_le<std::uint32_t>(out,
                             static_cast<std::uint32_t>(descriptor->logical_path().size()));
    append_le<std::uint64_t>(out, descriptor->byte_size());
    append_text(out, descriptor->logical_path());
    append_span(out, descriptor->content_digest());
  }
  return Result<Bytes>::success(std::move(out));
}

VerificationReport reject(ErrorCode code, std::string detail) {
  return VerificationReport{false, code, std::move(detail)};
}

}  // namespace

Result<SealedDescriptor> SealedDescriptor::seal(
    std::string logical_path,
    Bytes owned_bytes,
    const DigestFunction& digest) {
  if (!digest) {
    return Result<SealedDescriptor>::failure(
        make_error(ErrorCode::invalid_digest_function, "digest function is empty"));
  }
  if (!valid_path(logical_path)) {
    return Result<SealedDescriptor>::failure(
        make_error(ErrorCode::invalid_logical_path,
                   "logical path must be relative, printable ASCII, and dot-segment free"));
  }
  const Digest content_digest = digest(owned_bytes);
  return Result<SealedDescriptor>::success(
      SealedDescriptor(std::move(logical_path), std::move(owned_bytes), content_digest));
}

Result<Bytes> canonical_pack(std::span<const SealedDescriptor> descriptors) {
  if (descriptors.size() > std::numeric_limits<std::uint32_t>::max()) {
    return Result<Bytes>::failure(
        make_error(ErrorCode::arithmetic_overflow, "descriptor count exceeds wire format"));
  }
  auto sorted_result = sorted_unique(descriptors);
  if (!sorted_result) {
    return Result<Bytes>::failure(sorted_result.error());
  }
  auto sorted = std::move(sorted_result).take();
  Bytes out;
  append_span(out, kPackMagic);
  append_le<std::uint32_t>(out, static_cast<std::uint32_t>(sorted.size()));
  for (const auto* descriptor : sorted) {
    if (descriptor->logical_path().size() > std::numeric_limits<std::uint32_t>::max()) {
      return Result<Bytes>::failure(
          make_error(ErrorCode::arithmetic_overflow, "logical path exceeds wire format"));
    }
    append_le<std::uint32_t>(out,
                             static_cast<std::uint32_t>(descriptor->logical_path().size()));
    append_le<std::uint64_t>(out, descriptor->byte_size());
    append_text(out, descriptor->logical_path());
    append_span(out, descriptor->bytes());
  }
  return Result<Bytes>::success(std::move(out));
}

Result<Digest> descriptor_commitment(
    std::span<const SealedDescriptor> descriptors,
    const DigestFunction& digest) {
  if (!digest) {
    return Result<Digest>::failure(
        make_error(ErrorCode::invalid_digest_function, "digest function is empty"));
  }
  auto bytes_result = canonical_descriptor_bytes(descriptors);
  if (!bytes_result) {
    return Result<Digest>::failure(bytes_result.error());
  }
  return Result<Digest>::success(digest(bytes_result.value()));
}

Result<ConfiguredPackExpectation> make_host_expectation(
    std::span<const SealedDescriptor> descriptors,
    const DigestFunction& digest) {
  if (!digest) {
    return Result<ConfiguredPackExpectation>::failure(
        make_error(ErrorCode::invalid_digest_function, "digest function is empty"));
  }
  auto pack_result = canonical_pack(descriptors);
  if (!pack_result) {
    return Result<ConfiguredPackExpectation>::failure(pack_result.error());
  }
  auto commitment_result = descriptor_commitment(descriptors, digest);
  if (!commitment_result) {
    return Result<ConfiguredPackExpectation>::failure(commitment_result.error());
  }
  ConfiguredPackExpectation expectation;
  expectation.format_version = 1U;
  expectation.descriptor_count = static_cast<std::uint64_t>(descriptors.size());
  expectation.pack_size = static_cast<std::uint64_t>(pack_result.value().size());
  expectation.descriptor_commitment = commitment_result.value();
  expectation.pack_digest = digest(pack_result.value());
  return Result<ConfiguredPackExpectation>::success(expectation);
}

Bytes encode_configured_expectation(const ConfiguredPackExpectation& expectation) {
  Bytes out;
  out.reserve(kExpectationBytes);
  append_span(out, kExpectationMagic);
  append_le<std::uint32_t>(out, expectation.format_version);
  append_le<std::uint64_t>(out, expectation.descriptor_count);
  append_le<std::uint64_t>(out, expectation.pack_size);
  append_span(out, expectation.descriptor_commitment);
  append_span(out, expectation.pack_digest);
  return out;
}

Result<ConfiguredPackVerifier> ConfiguredPackVerifier::from_configured_bytes(
    std::span<const Byte> configured_bytes,
    DigestFunction digest) {
  if (!digest) {
    return Result<ConfiguredPackVerifier>::failure(
        make_error(ErrorCode::invalid_digest_function, "digest function is empty"));
  }
  if (configured_bytes.size() != kExpectationBytes ||
      !constant_time_equal(configured_bytes.first(kExpectationMagic.size()), kExpectationMagic)) {
    return Result<ConfiguredPackVerifier>::failure(
        make_error(ErrorCode::malformed_configuration,
                   "configured expectation has wrong size or magic"));
  }
  std::size_t cursor = kExpectationMagic.size();
  ConfiguredPackExpectation expectation;
  if (!read_le(configured_bytes, cursor, expectation.format_version) ||
      !read_le(configured_bytes, cursor, expectation.descriptor_count) ||
      !read_le(configured_bytes, cursor, expectation.pack_size)) {
    return Result<ConfiguredPackVerifier>::failure(
        make_error(ErrorCode::malformed_configuration, "truncated configured expectation"));
  }
  if (expectation.format_version != 1U) {
    return Result<ConfiguredPackVerifier>::failure(
        make_error(ErrorCode::unsupported_configuration_version,
                   "only configured expectation format version 1 is accepted"));
  }
  if (cursor + expectation.descriptor_commitment.size() + expectation.pack_digest.size() !=
      configured_bytes.size()) {
    return Result<ConfiguredPackVerifier>::failure(
        make_error(ErrorCode::malformed_configuration, "configured expectation length mismatch"));
  }
  std::copy_n(configured_bytes.begin() + static_cast<std::ptrdiff_t>(cursor),
              expectation.descriptor_commitment.size(),
              expectation.descriptor_commitment.begin());
  cursor += expectation.descriptor_commitment.size();
  std::copy_n(configured_bytes.begin() + static_cast<std::ptrdiff_t>(cursor),
              expectation.pack_digest.size(),
              expectation.pack_digest.begin());
  return Result<ConfiguredPackVerifier>::success(
      ConfiguredPackVerifier(expectation, std::move(digest)));
}

VerificationReport ConfiguredPackVerifier::verify(
    std::span<const SealedDescriptor> descriptors,
    std::span<const Byte> produced_pack) const {
  if (static_cast<std::uint64_t>(descriptors.size()) != expectation_.descriptor_count) {
    return reject(ErrorCode::descriptor_count_mismatch,
                  "candidate descriptor count differs from configured expectation");
  }
  // Re-hash each owned observation with the verifier's configured engine. This
  // prevents a descriptor sealed under another engine from laundering bytes.
  for (const auto& descriptor : descriptors) {
    const Digest observed = digest_(descriptor.bytes());
    if (!constant_time_equal(observed, descriptor.content_digest())) {
      return reject(ErrorCode::descriptor_digest_mismatch,
                    "sealed descriptor digest does not match its owned bytes");
    }
  }
  auto commitment_result = descriptor_commitment(descriptors, digest_);
  if (!commitment_result) {
    return reject(commitment_result.error().code, commitment_result.error().detail);
  }
  if (!constant_time_equal(commitment_result.value(), expectation_.descriptor_commitment)) {
    return reject(ErrorCode::descriptor_commitment_mismatch,
                  "candidate descriptor set differs from configured expectation");
  }
  if (static_cast<std::uint64_t>(produced_pack.size()) != expectation_.pack_size) {
    return reject(ErrorCode::pack_size_mismatch,
                  "produced pack length differs from configured expectation");
  }
  auto exact_result = canonical_pack(descriptors);
  if (!exact_result) {
    return reject(exact_result.error().code, exact_result.error().detail);
  }
  if (!constant_time_equal(produced_pack, exact_result.value())) {
    return reject(ErrorCode::pack_not_exact_canonical_reconstruction,
                  "produced pack is not the exact canonical encoding of sealed observations");
  }
  const Digest observed_pack_digest = digest_(produced_pack);
  if (!constant_time_equal(observed_pack_digest, expectation_.pack_digest)) {
    return reject(ErrorCode::pack_digest_mismatch,
                  "produced pack digest differs from configured expectation");
  }
  return VerificationReport{true, ErrorCode::none,
                            "configured expectation and exact canonical reconstruction agree"};
}

const char* to_string(ErrorCode code) noexcept {
  switch (code) {
    case ErrorCode::none: return "none";
    case ErrorCode::invalid_digest_function: return "invalid_digest_function";
    case ErrorCode::invalid_logical_path: return "invalid_logical_path";
    case ErrorCode::duplicate_logical_path: return "duplicate_logical_path";
    case ErrorCode::malformed_configuration: return "malformed_configuration";
    case ErrorCode::unsupported_configuration_version:
      return "unsupported_configuration_version";
    case ErrorCode::descriptor_digest_mismatch: return "descriptor_digest_mismatch";
    case ErrorCode::descriptor_count_mismatch: return "descriptor_count_mismatch";
    case ErrorCode::descriptor_commitment_mismatch:
      return "descriptor_commitment_mismatch";
    case ErrorCode::pack_size_mismatch: return "pack_size_mismatch";
    case ErrorCode::pack_not_exact_canonical_reconstruction:
      return "pack_not_exact_canonical_reconstruction";
    case ErrorCode::pack_digest_mismatch: return "pack_digest_mismatch";
    case ErrorCode::arithmetic_overflow: return "arithmetic_overflow";
  }
  return "unknown";
}

}  // namespace slopos::epoch_zero::pack
