# Vault excavation checkpoint

The read-only audit saw **10,251 files** totaling
**52,159,573 bytes**. Lexical classification marked
**7,322 files / 29,859,059 bytes** as
vault-like and **2,929 files /
22,300,514 bytes** as living-like.

It found **745 exact duplicate payload groups**. A purely
content-addressed physical representation could avoid up to
**16,030,801 repeated payload bytes** under
this scan. That number is a capacity estimate, not a deletion authorization: path identity,
historical custody, symlink semantics, and reopen dependencies still require proof.

The full capped identity map is `vault-audit.json`; `tools/audit_cube.py` reproduces it.
No inherited payload was deleted or rewritten by the audit.
