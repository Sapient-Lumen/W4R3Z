#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "slopos/e0/generation_journal/shadow_pack/pack.hpp"
#include "slopos/e0/generation_journal/shadow_pack/sha256.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <dirent.h>
#include <fcntl.h>
#include <filesystem>
#include <linux/fs.h>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <span>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <sys/stat.h>
#include <sys/random.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace slopos::e0::generation_journal::shadow_pack {
namespace {

using Bytes = std::vector<std::uint8_t>;

constexpr std::array<std::uint8_t, 8> kMagic = {
    'S', 'L', 'O', 'P', 'S', 'P', 'K', '1'};
constexpr std::uint32_t kVersion = 1U;
constexpr std::size_t kHeaderBytes = 72U;
constexpr std::uint64_t kMaximumEntries = 1'000'000ULL;
constexpr std::uint64_t kMaximumBlobs = 1'000'000ULL;
constexpr std::uint64_t kMaximumManifestBytes = 1ULL << 30U;
constexpr std::uint64_t kMaximumFileBytes = 1ULL << 30U;
constexpr std::uint64_t kMaximumLogicalBytes = 4ULL << 30U;
constexpr std::size_t kMaximumPathBytes = 4096U;
constexpr std::size_t kMaximumComponentBytes = 255U;
constexpr std::uint8_t kDirectory = 1U;
constexpr std::uint8_t kFile = 2U;

struct Entry {
  std::uint8_t kind{};
  std::uint32_t mode{};
  std::uint64_t size{};
  Digest digest{};
  std::string path;
};

struct Decoded {
  std::vector<Entry> entries;
  std::map<Digest, Bytes> blobs;
  Digest manifest_digest{};
  std::uint64_t logical_bytes{};
  std::uint64_t pack_bytes{};
};

class UniqueFd final {
 public:
  UniqueFd() noexcept = default;
  explicit UniqueFd(const int descriptor) noexcept : descriptor_(descriptor) {}
  ~UniqueFd() { reset(); }

  UniqueFd(const UniqueFd&) = delete;
  UniqueFd& operator=(const UniqueFd&) = delete;

  UniqueFd(UniqueFd&& other) noexcept : descriptor_(other.release()) {}
  UniqueFd& operator=(UniqueFd&& other) noexcept {
    if (this != &other) {
      reset(other.release());
    }
    return *this;
  }

  [[nodiscard]] int get() const noexcept { return descriptor_; }
  [[nodiscard]] explicit operator bool() const noexcept { return descriptor_ >= 0; }

  [[nodiscard]] int release() noexcept {
    const int result = descriptor_;
    descriptor_ = -1;
    return result;
  }

  void reset(const int replacement = -1) noexcept {
    if (descriptor_ >= 0) {
      (void)::close(descriptor_);
    }
    descriptor_ = replacement;
  }

 private:
  int descriptor_{-1};
};

struct FileIdentity {
  dev_t device{};
  ino_t inode{};
  mode_t type{};
  mode_t permissions{};
  off_t size{};
  timespec modified{};
  timespec changed{};
};

[[noreturn]] void system_error(const std::string_view operation) {
  throw std::runtime_error(std::string(operation) + ": " + std::strerror(errno));
}

[[nodiscard]] FileIdentity identity_of(const struct stat& status) noexcept {
  return FileIdentity{
      status.st_dev,
      status.st_ino,
      status.st_mode & S_IFMT,
      status.st_mode & 0777U,
      status.st_size,
      status.st_mtim,
      status.st_ctim,
  };
}

[[nodiscard]] bool same_identity(const FileIdentity& left,
                                 const FileIdentity& right) noexcept {
  return left.device == right.device && left.inode == right.inode
      && left.type == right.type && left.permissions == right.permissions
      && left.size == right.size
      && left.modified.tv_sec == right.modified.tv_sec
      && left.modified.tv_nsec == right.modified.tv_nsec
      && left.changed.tv_sec == right.changed.tv_sec
      && left.changed.tv_nsec == right.changed.tv_nsec;
}

[[nodiscard]] FileIdentity fstat_identity(const int descriptor,
                                          const std::string_view operation) {
  struct stat status {};
  if (::fstat(descriptor, &status) != 0) {
    system_error(operation);
  }
  return identity_of(status);
}

[[nodiscard]] std::vector<std::string> path_components(
    const std::filesystem::path& path) {
  std::vector<std::string> result;
  for (const auto& component : path) {
    const std::string value = component.string();
    if (value.empty() || value == "/" || value == ".") {
      continue;
    }
    if (value == "..") {
      throw std::runtime_error("path traversal component is forbidden");
    }
    if (value.size() > kMaximumComponentBytes) {
      throw std::runtime_error("filesystem path component exceeds bound");
    }
    result.push_back(value);
  }
  return result;
}

[[nodiscard]] UniqueFd open_directory_path_no_symlinks(
    const std::filesystem::path& path) {
  const bool absolute = path.is_absolute();
  UniqueFd current(::open(absolute ? "/" : ".", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
  if (!current) {
    system_error("open directory path anchor");
  }
  for (const std::string& component : path_components(path)) {
    const int next = ::openat(
        current.get(), component.c_str(),
        O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (next < 0) {
      system_error("open descriptor-rooted directory component");
    }
    current.reset(next);
  }
  return current;
}

struct ParentAndName {
  UniqueFd parent;
  std::string name;
};

[[nodiscard]] ParentAndName open_parent_and_name_no_symlinks(
    const std::filesystem::path& path) {
  const std::filesystem::path filename = path.filename();
  const std::string name = filename.string();
  if (name.empty() || name == "." || name == ".." || name.find('/') != std::string::npos
      || name.size() > kMaximumComponentBytes) {
    throw std::runtime_error("final filesystem path component is not admissible");
  }
  std::filesystem::path parent = path.parent_path();
  if (parent.empty()) {
    parent = ".";
  }
  return ParentAndName{open_directory_path_no_symlinks(parent), name};
}

[[nodiscard]] Bytes read_fd_exact(const int descriptor, const FileIdentity& expected,
                                  const std::string_view operation) {
  if (expected.type != S_IFREG || expected.size < 0) {
    throw std::runtime_error(std::string(operation) + ": object is not a regular file");
  }
  const auto size = static_cast<std::uint64_t>(expected.size);
  if (size > kMaximumFileBytes
      || size > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
    throw std::runtime_error(std::string(operation) + ": regular file exceeds bound");
  }
  Bytes result(static_cast<std::size_t>(size));
  std::size_t offset = 0U;
  while (offset < result.size()) {
    const ssize_t count = ::pread(
        descriptor, result.data() + offset, result.size() - offset,
        static_cast<off_t>(offset));
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      system_error(operation);
    }
    if (count == 0) {
      throw std::runtime_error(std::string(operation) + ": short read");
    }
    offset += static_cast<std::size_t>(count);
  }
  std::uint8_t trailing{};
  for (;;) {
    const ssize_t count = ::pread(
        descriptor, &trailing, 1U, static_cast<off_t>(result.size()));
    if (count < 0 && errno == EINTR) {
      continue;
    }
    if (count < 0) {
      system_error(operation);
    }
    if (count != 0) {
      throw std::runtime_error(std::string(operation) + ": file grew during read");
    }
    break;
  }
  return result;
}

[[nodiscard]] Bytes read_regular_descriptor_twice(
    const int descriptor, const FileIdentity& opened,
    const std::string_view operation) {
  const Bytes first = read_fd_exact(descriptor, opened, operation);
  const FileIdentity middle = fstat_identity(descriptor, operation);
  const Bytes second = read_fd_exact(descriptor, middle, operation);
  const FileIdentity after = fstat_identity(descriptor, operation);
  if (!same_identity(opened, middle) || !same_identity(opened, after) || first != second) {
    throw std::runtime_error(std::string(operation) + ": regular file was unstable");
  }
  return first;
}

[[nodiscard]] Bytes read_file(const std::filesystem::path& path) {
  ParentAndName location = open_parent_and_name_no_symlinks(path);
  UniqueFd descriptor(::openat(
      location.parent.get(), location.name.c_str(), O_RDONLY | O_NOFOLLOW | O_CLOEXEC));
  if (!descriptor) {
    system_error("open descriptor-rooted regular file");
  }
  const FileIdentity opened = fstat_identity(descriptor.get(), "stat regular file");
  return read_regular_descriptor_twice(descriptor.get(), opened, "read regular file");
}

[[nodiscard]] std::string ascii_casefold(const std::string_view value) {
  std::string result(value);
  for (char& character : result) {
    if (character >= 'A' && character <= 'Z') {
      character = static_cast<char>(character - 'A' + 'a');
    }
  }
  return result;
}

[[nodiscard]] bool allowed_path_character(const char value) noexcept {
  return (value >= 'A' && value <= 'Z') || (value >= 'a' && value <= 'z')
      || (value >= '0' && value <= '9') || value == '.' || value == '_'
      || value == '/' || value == '+' || value == '-';
}

void validate_path(const std::string_view path) {
  if (path.empty() || path.size() > kMaximumPathBytes || path.front() == '/'
      || path.back() == '/') {
    throw std::runtime_error("path length or root form is not canonical");
  }
  std::size_t component_start = 0U;
  for (std::size_t index = 0U; index <= path.size(); ++index) {
    if (index < path.size() && !allowed_path_character(path[index])) {
      throw std::runtime_error("path contains a forbidden byte");
    }
    if (index == path.size() || path[index] == '/') {
      const std::size_t length = index - component_start;
      if (length == 0U || length > kMaximumComponentBytes) {
        throw std::runtime_error("path component length is not canonical");
      }
      const std::string_view component = path.substr(component_start, length);
      if (component == "." || component == "..") {
        throw std::runtime_error("dot path component is forbidden");
      }
      component_start = index + 1U;
    }
  }
}

[[nodiscard]] std::string parent_path(const std::string_view path) {
  const std::size_t separator = path.rfind('/');
  if (separator == std::string_view::npos) {
    return {};
  }
  return std::string(path.substr(0U, separator));
}

[[nodiscard]] bool digest_is_zero(const Digest& digest) noexcept {
  return std::all_of(digest.begin(), digest.end(), [](const std::uint8_t byte) {
    return byte == 0U;
  });
}

void checked_add(std::uint64_t& value, const std::uint64_t addition,
                 const std::string_view label) {
  if (addition > std::numeric_limits<std::uint64_t>::max() - value) {
    throw std::runtime_error(std::string(label) + " overflow");
  }
  value += addition;
}

void validate_entries(const std::vector<Entry>& entries) {
  if (entries.size() > static_cast<std::size_t>(kMaximumEntries)) {
    throw std::runtime_error("entry count exceeds format limit");
  }
  std::set<std::string> exact;
  std::set<std::string> folded;
  std::map<std::string, std::uint8_t> kinds;
  std::string previous;
  bool first = true;
  for (const Entry& entry : entries) {
    validate_path(entry.path);
    if (!first && !(previous < entry.path)) {
      throw std::runtime_error("manifest paths are not strictly byte-sorted");
    }
    first = false;
    previous = entry.path;
    if (!exact.insert(entry.path).second) {
      throw std::runtime_error("duplicate manifest path");
    }
    if (!folded.insert(ascii_casefold(entry.path)).second) {
      throw std::runtime_error("ASCII-casefold path collision");
    }
    if (entry.mode < 0400U || entry.mode > 0777U || (entry.mode & ~0777U) != 0U) {
      throw std::runtime_error("mode is outside the portable permission membrane");
    }
    if (entry.kind == kDirectory) {
      if (entry.size != 0U || !digest_is_zero(entry.digest)) {
        throw std::runtime_error("directory carries payload fields");
      }
    } else if (entry.kind == kFile) {
      // Empty regular files are valid and still carry the SHA-256 of empty bytes.
    } else {
      throw std::runtime_error("unknown manifest kind");
    }
    kinds.emplace(entry.path, entry.kind);
  }
  for (const Entry& entry : entries) {
    const std::string parent = parent_path(entry.path);
    if (!parent.empty()) {
      const auto found = kinds.find(parent);
      if (found == kinds.end()) {
        throw std::runtime_error("manifest parent directory is missing");
      }
      if (found->second != kDirectory) {
        throw std::runtime_error("manifest path descends through a regular file");
      }
    }
  }
}

[[nodiscard]] std::uint32_t parse_mode(const std::string_view text) {
  if (text.size() != 4U || text.front() != '0') {
    throw std::runtime_error("subject mode must be four octal digits");
  }
  std::uint32_t result = 0U;
  for (const char value : text) {
    if (value < '0' || value > '7') {
      throw std::runtime_error("subject mode is not octal");
    }
    result = result * 8U + static_cast<std::uint32_t>(value - '0');
  }
  return result;
}

[[nodiscard]] std::uint64_t parse_decimal(const std::string_view text) {
  if (text.empty()) {
    throw std::runtime_error("empty decimal field");
  }
  std::uint64_t result = 0U;
  for (const char value : text) {
    if (value < '0' || value > '9') {
      throw std::runtime_error("decimal field contains a non-digit");
    }
    const std::uint64_t digit = static_cast<std::uint64_t>(value - '0');
    if (result > (std::numeric_limits<std::uint64_t>::max() - digit) / 10U) {
      throw std::runtime_error("decimal field overflow");
    }
    result = result * 10U + digit;
  }
  return result;
}

[[nodiscard]] std::vector<std::string> split_tabs(const std::string_view line) {
  std::vector<std::string> result;
  std::size_t start = 0U;
  for (;;) {
    const std::size_t position = line.find('\t', start);
    if (position == std::string_view::npos) {
      result.emplace_back(line.substr(start));
      break;
    }
    result.emplace_back(line.substr(start, position - start));
    start = position + 1U;
  }
  return result;
}

[[nodiscard]] std::vector<Entry> read_subject(const std::filesystem::path& path) {
  const Bytes bytes = read_file(path);
  if (std::find(bytes.begin(), bytes.end(), static_cast<std::uint8_t>('\r')) != bytes.end()
      || std::find(bytes.begin(), bytes.end(), static_cast<std::uint8_t>(0U)) != bytes.end()) {
    throw std::runtime_error("subject contains CR or NUL");
  }
  const std::string text(reinterpret_cast<const char*>(bytes.data()), bytes.size());
  std::istringstream stream(text);
  std::string line;
  if (!std::getline(stream, line)
      || line != "kind\tpath\tmode\tsize\tsha256") {
    throw std::runtime_error("subject header is not canonical");
  }
  std::vector<Entry> result;
  while (std::getline(stream, line)) {
    if (line.empty()) {
      throw std::runtime_error("subject contains a blank row");
    }
    const std::vector<std::string> fields = split_tabs(line);
    if (fields.size() != 5U) {
      throw std::runtime_error("subject row does not have five fields");
    }
    Entry entry;
    if (fields[0] == "D") {
      entry.kind = kDirectory;
    } else if (fields[0] == "F") {
      entry.kind = kFile;
    } else {
      throw std::runtime_error("subject kind is neither D nor F");
    }
    entry.path = fields[1];
    entry.mode = parse_mode(fields[2]);
    entry.size = parse_decimal(fields[3]);
    if (entry.kind == kDirectory) {
      if (fields[4] != "-") {
        throw std::runtime_error("directory subject digest must be '-'");
      }
    } else {
      entry.digest = parse_digest(fields[4]);
    }
    result.push_back(std::move(entry));
  }
  if (result.empty()) {
    throw std::runtime_error("subject has no entries");
  }
  validate_entries(result);
  return result;
}

void append_u32(Bytes& output, const std::uint32_t value) {
  for (unsigned int shift = 0U; shift < 32U; shift += 8U) {
    output.push_back(static_cast<std::uint8_t>(value >> shift));
  }
}

void append_u64(Bytes& output, const std::uint64_t value) {
  for (unsigned int shift = 0U; shift < 64U; shift += 8U) {
    output.push_back(static_cast<std::uint8_t>(value >> shift));
  }
}

[[nodiscard]] Bytes encode_manifest(const std::vector<Entry>& entries) {
  Bytes output;
  for (const Entry& entry : entries) {
    output.push_back(entry.kind);
    output.insert(output.end(), 3U, 0U);
    append_u32(output, entry.mode);
    append_u64(output, entry.size);
    output.insert(output.end(), entry.digest.begin(), entry.digest.end());
    if (entry.path.size() > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) {
      throw std::runtime_error("path exceeds binary length field");
    }
    append_u32(output, static_cast<std::uint32_t>(entry.path.size()));
    output.insert(output.end(), entry.path.begin(), entry.path.end());
  }
  return output;
}

class Reader final {
 public:
  explicit Reader(const std::span<const std::uint8_t> bytes) : bytes_(bytes) {}

  [[nodiscard]] std::size_t remaining() const noexcept { return bytes_.size() - position_; }

  [[nodiscard]] std::uint8_t u8() {
    require(1U);
    return bytes_[position_++];
  }

  [[nodiscard]] std::uint32_t u32() {
    require(4U);
    std::uint32_t value = 0U;
    for (unsigned int shift = 0U; shift < 32U; shift += 8U) {
      value |= static_cast<std::uint32_t>(bytes_[position_++]) << shift;
    }
    return value;
  }

  [[nodiscard]] std::uint64_t u64() {
    require(8U);
    std::uint64_t value = 0U;
    for (unsigned int shift = 0U; shift < 64U; shift += 8U) {
      value |= static_cast<std::uint64_t>(bytes_[position_++]) << shift;
    }
    return value;
  }

  [[nodiscard]] Digest digest() {
    const auto bytes = take(32U);
    Digest result{};
    std::copy(bytes.begin(), bytes.end(), result.begin());
    return result;
  }

  [[nodiscard]] std::span<const std::uint8_t> take(const std::size_t size) {
    require(size);
    const auto result = bytes_.subspan(position_, size);
    position_ += size;
    return result;
  }

 private:
  void require(const std::size_t size) const {
    if (size > remaining()) {
      throw std::runtime_error("truncated shadow pack");
    }
  }

  std::span<const std::uint8_t> bytes_;
  std::size_t position_{};
};

[[nodiscard]] std::size_t bounded_size(const std::uint64_t value,
                                       const std::size_t remaining,
                                       const std::string_view label) {
  if (value > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())
      || value > static_cast<std::uint64_t>(remaining)) {
    throw std::runtime_error(std::string(label) + " exceeds remaining object bytes");
  }
  return static_cast<std::size_t>(value);
}

[[nodiscard]] Decoded decode_pack(const Bytes& bytes) {
  if (bytes.size() < kHeaderBytes) {
    throw std::runtime_error("shadow pack is shorter than its fixed header");
  }
  Reader input(std::span<const std::uint8_t>(bytes.data(), bytes.size()));
  for (const std::uint8_t expected : kMagic) {
    if (input.u8() != expected) {
      throw std::runtime_error("shadow pack magic mismatch");
    }
  }
  if (input.u32() != kVersion) {
    throw std::runtime_error("shadow pack version mismatch");
  }
  if (input.u32() != 0U) {
    throw std::runtime_error("shadow pack reserved header word is nonzero");
  }
  const std::uint64_t entry_count = input.u64();
  const std::uint64_t blob_count = input.u64();
  const std::uint64_t manifest_size_raw = input.u64();
  const Digest declared_manifest_digest = input.digest();
  if (entry_count == 0U || entry_count > kMaximumEntries) {
    throw std::runtime_error("shadow pack entry count is outside bounds");
  }
  if (blob_count > kMaximumBlobs) {
    throw std::runtime_error("shadow pack blob count is outside bounds");
  }
  if (manifest_size_raw > kMaximumManifestBytes) {
    throw std::runtime_error("shadow pack manifest is outside bounds");
  }
  const std::size_t manifest_size = bounded_size(
      manifest_size_raw, input.remaining(), "manifest length");
  const auto manifest_span = input.take(manifest_size);
  if (sha256(manifest_span) != declared_manifest_digest) {
    throw std::runtime_error("shadow pack manifest digest mismatch");
  }

  Reader manifest(manifest_span);
  std::vector<Entry> entries;
  entries.reserve(static_cast<std::size_t>(entry_count));
  for (std::uint64_t index = 0U; index < entry_count; ++index) {
    Entry entry;
    entry.kind = manifest.u8();
    if (manifest.u8() != 0U || manifest.u8() != 0U || manifest.u8() != 0U) {
      throw std::runtime_error("manifest entry reserved bytes are nonzero");
    }
    entry.mode = manifest.u32();
    entry.size = manifest.u64();
    entry.digest = manifest.digest();
    const std::uint32_t path_length = manifest.u32();
    if (path_length == 0U || path_length > kMaximumPathBytes) {
      throw std::runtime_error("manifest path length is outside bounds");
    }
    const auto raw_path = manifest.take(static_cast<std::size_t>(path_length));
    entry.path.assign(reinterpret_cast<const char*>(raw_path.data()), raw_path.size());
    entries.push_back(std::move(entry));
  }
  if (manifest.remaining() != 0U) {
    throw std::runtime_error("manifest contains trailing bytes");
  }
  validate_entries(entries);

  std::map<Digest, Bytes> blobs;
  Digest previous_digest{};
  bool first_blob = true;
  for (std::uint64_t index = 0U; index < blob_count; ++index) {
    const Digest digest = input.digest();
    if (!first_blob && !(previous_digest < digest)) {
      throw std::runtime_error("blob records are not strictly digest-sorted");
    }
    first_blob = false;
    previous_digest = digest;
    const std::uint64_t size_raw = input.u64();
    const std::size_t size = bounded_size(size_raw, input.remaining(), "blob length");
    const auto payload_span = input.take(size);
    if (sha256(payload_span) != digest) {
      throw std::runtime_error("blob payload digest mismatch");
    }
    Bytes payload(payload_span.begin(), payload_span.end());
    if (!blobs.emplace(digest, std::move(payload)).second) {
      throw std::runtime_error("duplicate blob digest");
    }
  }
  if (input.remaining() != 0U) {
    throw std::runtime_error("shadow pack contains trailing bytes");
  }

  std::set<Digest> referenced;
  std::uint64_t logical_bytes = 0U;
  for (const Entry& entry : entries) {
    if (entry.kind != kFile) {
      continue;
    }
    const auto found = blobs.find(entry.digest);
    if (found == blobs.end()) {
      throw std::runtime_error("file manifest references a missing blob");
    }
    if (static_cast<std::uint64_t>(found->second.size()) != entry.size) {
      throw std::runtime_error("file manifest size disagrees with blob");
    }
    referenced.insert(entry.digest);
    checked_add(logical_bytes, entry.size, "logical byte count");
  }
  if (referenced.size() != blobs.size()) {
    throw std::runtime_error("shadow pack contains an unused blob");
  }

  return Decoded{
      std::move(entries), std::move(blobs), declared_manifest_digest,
      logical_bytes, static_cast<std::uint64_t>(bytes.size())};
}

[[nodiscard]] bool entries_equal(const Entry& left, const Entry& right) noexcept {
  return left.kind == right.kind && left.mode == right.mode && left.size == right.size
      && left.digest == right.digest && left.path == right.path;
}

void require_subject(const std::vector<Entry>& actual,
                     const std::vector<Entry>& expected) {
  if (actual.size() != expected.size()) {
    throw std::runtime_error("pack entry count disagrees with exact subject");
  }
  for (std::size_t index = 0U; index < actual.size(); ++index) {
    if (!entries_equal(actual[index], expected[index])) {
      throw std::runtime_error("pack manifest disagrees with exact subject at row "
                               + std::to_string(index + 1U));
    }
  }
}

[[nodiscard]] std::vector<std::string> directory_names(const int descriptor) {
  UniqueFd scan(::openat(descriptor, ".", O_RDONLY | O_DIRECTORY | O_CLOEXEC));
  if (!scan) {
    system_error("open directory enumeration descriptor");
  }
  DIR* raw = ::fdopendir(scan.release());
  if (raw == nullptr) {
    system_error("fdopendir descriptor-rooted directory");
  }
  const std::unique_ptr<DIR, int (*)(DIR*)> stream(raw, ::closedir);
  std::vector<std::string> result;
  for (;;) {
    errno = 0;
    dirent* item = ::readdir(stream.get());
    if (item == nullptr) {
      if (errno != 0) {
        system_error("readdir descriptor-rooted directory");
      }
      break;
    }
    const std::string name(item->d_name);
    if (name == "." || name == "..") {
      continue;
    }
    if (name.empty() || name.size() > kMaximumComponentBytes
        || name.find('/') != std::string::npos) {
      throw std::runtime_error("source tree contains an inadmissible name");
    }
    result.push_back(name);
  }
  std::sort(result.begin(), result.end());
  if (std::adjacent_find(result.begin(), result.end()) != result.end()) {
    throw std::runtime_error("directory enumeration returned a duplicate name");
  }
  return result;
}

[[nodiscard]] FileIdentity child_path_identity(const int parent,
                                               const std::string& name) {
  struct stat status {};
  if (::fstatat(parent, name.c_str(), &status, AT_SYMLINK_NOFOLLOW) != 0) {
    system_error("stat descriptor-rooted child path");
  }
  return identity_of(status);
}

[[nodiscard]] UniqueFd open_observed_child(const int parent, const std::string& name,
                                           FileIdentity& observed) {
  UniqueFd path_descriptor(::openat(parent, name.c_str(), O_PATH | O_NOFOLLOW | O_CLOEXEC));
  if (!path_descriptor) {
    system_error("open descriptor-rooted child observation");
  }
  observed = fstat_identity(path_descriptor.get(), "stat child observation");
  int flags = O_RDONLY | O_NOFOLLOW | O_CLOEXEC;
  if (observed.type == S_IFDIR) {
    flags |= O_DIRECTORY;
  } else if (observed.type != S_IFREG) {
    if (observed.type == S_IFLNK) {
      throw std::runtime_error("source tree contains a symlink");
    }
    throw std::runtime_error("source tree contains a special filesystem object");
  }
  UniqueFd opened(::openat(parent, name.c_str(), flags));
  if (!opened) {
    system_error("open descriptor-rooted child");
  }
  const FileIdentity actual = fstat_identity(opened.get(), "stat opened child");
  if (!same_identity(observed, actual)) {
    throw std::runtime_error("source child changed between observation and open");
  }
  return opened;
}

void read_source_directory(
    const int directory, const std::string& prefix, std::vector<Entry>& entries,
    std::map<Digest, Bytes>& blobs, std::uint64_t& logical_bytes) {
  const FileIdentity directory_before = fstat_identity(directory, "stat source directory");
  if (directory_before.type != S_IFDIR) {
    throw std::runtime_error("opened source directory is no longer a directory");
  }
  const std::vector<std::string> names_before = directory_names(directory);
  for (const std::string& name : names_before) {
    Entry entry;
    entry.path = prefix.empty() ? name : prefix + "/" + name;
    validate_path(entry.path);

    FileIdentity observed{};
    UniqueFd child = open_observed_child(directory, name, observed);
    entry.mode = static_cast<std::uint32_t>(observed.permissions);
    if (observed.type == S_IFDIR) {
      entry.kind = kDirectory;
      entries.push_back(entry);
      read_source_directory(child.get(), entry.path, entries, blobs, logical_bytes);
      const FileIdentity child_after = fstat_identity(child.get(), "stat traversed source directory");
      const FileIdentity path_after = child_path_identity(directory, name);
      if (!same_identity(observed, child_after) || !same_identity(observed, path_after)) {
        throw std::runtime_error("source directory changed during descriptor-rooted traversal");
      }
      continue;
    }

    entry.kind = kFile;
    Bytes payload = read_regular_descriptor_twice(
        child.get(), observed, "read descriptor-rooted source file");
    const FileIdentity path_after = child_path_identity(directory, name);
    const FileIdentity child_after = fstat_identity(child.get(), "stat read source file");
    if (!same_identity(observed, path_after) || !same_identity(observed, child_after)) {
      throw std::runtime_error("source file changed during descriptor-rooted traversal");
    }
    entry.size = static_cast<std::uint64_t>(payload.size());
    checked_add(logical_bytes, entry.size, "source logical byte count");
    if (logical_bytes > kMaximumLogicalBytes) {
      throw std::runtime_error("source logical byte count exceeds bound");
    }
    entry.digest = sha256(std::span<const std::uint8_t>(payload.data(), payload.size()));
    const auto found = blobs.find(entry.digest);
    if (found == blobs.end()) {
      blobs.emplace(entry.digest, std::move(payload));
    } else if (found->second != payload) {
      throw std::runtime_error("SHA-256 collision encountered between unequal source payloads");
    }
    entries.push_back(std::move(entry));
  }
  const std::vector<std::string> names_after = directory_names(directory);
  const FileIdentity directory_after = fstat_identity(directory, "restat source directory");
  if (names_before != names_after || !same_identity(directory_before, directory_after)) {
    throw std::runtime_error("source directory membership changed during traversal");
  }
}

[[nodiscard]] std::pair<std::vector<Entry>, std::map<Digest, Bytes>>
read_source(const std::filesystem::path& root) {
  UniqueFd root_descriptor = open_directory_path_no_symlinks(root);
  const FileIdentity root_before = fstat_identity(root_descriptor.get(), "stat source root");
  if (root_before.type != S_IFDIR) {
    throw std::runtime_error("source root is not a descriptor-rooted directory");
  }
  if (root_before.permissions != 0755U) {
    throw std::runtime_error("source root mode is not the canonical implicit 0755");
  }
  std::vector<Entry> entries;
  std::map<Digest, Bytes> blobs;
  std::uint64_t logical_bytes = 0U;
  read_source_directory(root_descriptor.get(), "", entries, blobs, logical_bytes);
  const FileIdentity root_after = fstat_identity(root_descriptor.get(), "restat source root");
  if (!same_identity(root_before, root_after)) {
    throw std::runtime_error("source root changed during descriptor-rooted traversal");
  }
  std::sort(entries.begin(), entries.end(), [](const Entry& left, const Entry& right) {
    return left.path < right.path;
  });
  validate_entries(entries);
  return {std::move(entries), std::move(blobs)};
}

[[nodiscard]] Bytes encode_pack(const std::vector<Entry>& entries,
                                const std::map<Digest, Bytes>& blobs) {
  const Bytes manifest = encode_manifest(entries);
  const Digest manifest_digest = sha256(
      std::span<const std::uint8_t>(manifest.data(), manifest.size()));
  Bytes output;
  std::uint64_t total = static_cast<std::uint64_t>(kHeaderBytes);
  checked_add(total, static_cast<std::uint64_t>(manifest.size()), "pack byte count");
  for (const auto& [digest, payload] : blobs) {
    static_cast<void>(digest);
    checked_add(total, 40U, "pack byte count");
    checked_add(total, static_cast<std::uint64_t>(payload.size()), "pack byte count");
  }
  if (total > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
    throw std::runtime_error("pack exceeds addressable memory");
  }
  output.reserve(static_cast<std::size_t>(total));
  output.insert(output.end(), kMagic.begin(), kMagic.end());
  append_u32(output, kVersion);
  append_u32(output, 0U);
  append_u64(output, static_cast<std::uint64_t>(entries.size()));
  append_u64(output, static_cast<std::uint64_t>(blobs.size()));
  append_u64(output, static_cast<std::uint64_t>(manifest.size()));
  output.insert(output.end(), manifest_digest.begin(), manifest_digest.end());
  output.insert(output.end(), manifest.begin(), manifest.end());
  for (const auto& [digest, payload] : blobs) {
    output.insert(output.end(), digest.begin(), digest.end());
    append_u64(output, static_cast<std::uint64_t>(payload.size()));
    output.insert(output.end(), payload.begin(), payload.end());
  }
  if (output.size() != static_cast<std::size_t>(total)) {
    throw std::runtime_error("pack encoder byte-count disagreement");
  }
  return output;
}

void write_all(const int descriptor, const std::span<const std::uint8_t> bytes) {
  std::size_t offset = 0U;
  while (offset < bytes.size()) {
    const ssize_t wrote = ::write(descriptor, bytes.data() + offset, bytes.size() - offset);
    if (wrote < 0) {
      if (errno == EINTR) {
        continue;
      }
      system_error("write exact object");
    }
    if (wrote == 0) {
      throw std::runtime_error("zero-length write to exact object");
    }
    offset += static_cast<std::size_t>(wrote);
  }
}

[[nodiscard]] bool same_object(const FileIdentity& left,
                               const FileIdentity& right) noexcept {
  return left.device == right.device && left.inode == right.inode
      && left.type == right.type;
}

void write_exclusive(const std::filesystem::path& path, const Bytes& bytes,
                     const std::uint32_t mode) {
  ParentAndName location = open_parent_and_name_no_symlinks(path);
  UniqueFd descriptor(::openat(
      location.parent.get(), location.name.c_str(),
      O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600));
  if (!descriptor) {
    system_error("create descriptor-rooted absent output");
  }
  const FileIdentity created = fstat_identity(descriptor.get(), "stat created output");
  bool keep = false;
  try {
    write_all(descriptor.get(), std::span<const std::uint8_t>(bytes.data(), bytes.size()));
    if (::fchmod(descriptor.get(), static_cast<mode_t>(mode)) != 0) {
      system_error("chmod exact object");
    }
    if (::fsync(descriptor.get()) != 0) {
      system_error("fsync exact object after mode");
    }
    const FileIdentity completed = fstat_identity(descriptor.get(), "stat completed output");
    if (completed.type != S_IFREG || completed.permissions != mode
        || completed.size < 0
        || static_cast<std::uint64_t>(completed.size) != bytes.size()) {
      throw std::runtime_error("created exact object has wrong type, mode, or size");
    }
    const Bytes observed = read_regular_descriptor_twice(
        descriptor.get(), completed, "reread created exact object");
    if (observed != bytes) {
      throw std::runtime_error("created exact object reread disagreement");
    }
    const FileIdentity path_identity = child_path_identity(
        location.parent.get(), location.name);
    if (!same_object(created, path_identity)) {
      throw std::runtime_error("created exact object path was replaced");
    }
    keep = true;
  } catch (...) {
    const int saved = errno;
    try {
      const FileIdentity path_identity = child_path_identity(
          location.parent.get(), location.name);
      if (same_object(created, path_identity)) {
        (void)::unlinkat(location.parent.get(), location.name.c_str(), 0);
      }
    } catch (...) {
      // Never remove an object whose identity cannot still be proved to be ours.
    }
    errno = saved;
    throw;
  }
  if (!keep) {
    throw std::runtime_error("exact output publication did not reach keep state");
  }
}

[[nodiscard]] Summary summary_of(const Decoded& decoded) {
  return Summary{
      static_cast<std::uint64_t>(decoded.entries.size()),
      static_cast<std::uint64_t>(decoded.blobs.size()),
      decoded.logical_bytes,
      decoded.pack_bytes,
      hex_digest(decoded.manifest_digest)};
}

[[nodiscard]] std::string random_stage_name(const std::string& destination_name) {
  std::array<std::uint8_t, 16> random{};
  std::size_t offset = 0U;
  while (offset < random.size()) {
    const ssize_t count = ::getrandom(random.data() + offset, random.size() - offset, 0U);
    if (count < 0) {
      if (errno == EINTR) {
        continue;
      }
      system_error("getrandom unpack stage name");
    }
    if (count == 0) {
      throw std::runtime_error("getrandom returned no stage-name bytes");
    }
    offset += static_cast<std::size_t>(count);
  }
  constexpr char hex[] = "0123456789abcdef";
  std::string suffix;
  suffix.reserve(random.size() * 2U);
  for (const std::uint8_t byte : random) {
    suffix.push_back(hex[byte >> 4U]);
    suffix.push_back(hex[byte & 0x0fU]);
  }
  std::string stem = destination_name;
  if (stem.size() > 80U) {
    stem.resize(80U);
  }
  return "." + stem + ".slopos-shadow-stage-" + suffix;
}

void cleanup_stage_tree(const int directory) noexcept {
  try {
    for (const std::string& name : directory_names(directory)) {
      struct stat status {};
      if (::fstatat(directory, name.c_str(), &status, AT_SYMLINK_NOFOLLOW) != 0) {
        continue;
      }
      if (S_ISDIR(status.st_mode)) {
        UniqueFd child(::openat(
            directory, name.c_str(), O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC));
        if (child) {
          cleanup_stage_tree(child.get());
        }
        (void)::unlinkat(directory, name.c_str(), AT_REMOVEDIR);
      } else {
        (void)::unlinkat(directory, name.c_str(), 0);
      }
    }
  } catch (...) {
    // Best-effort cleanup is bounded to the descriptor-rooted random stage.
  }
}

void write_materialized_file(const int parent, const std::string& name,
                             const Bytes& payload, const std::uint32_t mode) {
  UniqueFd descriptor(::openat(
      parent, name.c_str(), O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600));
  if (!descriptor) {
    system_error("create descriptor-rooted reconstructed file");
  }
  const FileIdentity created = fstat_identity(descriptor.get(), "stat reconstructed file");
  write_all(descriptor.get(), std::span<const std::uint8_t>(payload.data(), payload.size()));
  if (::fchmod(descriptor.get(), static_cast<mode_t>(mode)) != 0) {
    system_error("chmod reconstructed file");
  }
  if (::fsync(descriptor.get()) != 0) {
    system_error("fsync reconstructed file after mode");
  }
  const FileIdentity complete = fstat_identity(descriptor.get(), "restat reconstructed file");
  if (complete.type != S_IFREG || complete.permissions != mode || complete.size < 0
      || static_cast<std::uint64_t>(complete.size) != payload.size()) {
    throw std::runtime_error("reconstructed file has wrong type, mode, or size");
  }
  const Bytes observed = read_regular_descriptor_twice(
      descriptor.get(), complete, "reread reconstructed file");
  if (observed != payload) {
    throw std::runtime_error("reconstructed file payload reread disagreement");
  }
  const FileIdentity path_identity = child_path_identity(parent, name);
  if (!same_object(created, path_identity)) {
    throw std::runtime_error("reconstructed file path was replaced");
  }
}

void rename_noreplace(const int parent, const std::string& from,
                      const std::string& to) {
  const long result = ::syscall(
      SYS_renameat2, parent, from.c_str(), parent, to.c_str(), RENAME_NOREPLACE);
  if (result != 0L) {
    system_error("rename descriptor-rooted complete reconstruction without replacement");
  }
}

void materialize(const Decoded& decoded, const std::filesystem::path& destination) {
  ParentAndName location = open_parent_and_name_no_symlinks(destination);
  struct stat existing {};
  if (::fstatat(
          location.parent.get(), location.name.c_str(), &existing,
          AT_SYMLINK_NOFOLLOW) == 0) {
    throw std::runtime_error("unpack destination already exists");
  }
  if (errno != ENOENT) {
    system_error("inspect absent unpack destination");
  }

  std::string stage_name;
  for (unsigned int attempt = 0U; attempt < 32U; ++attempt) {
    stage_name = random_stage_name(location.name);
    if (::mkdirat(location.parent.get(), stage_name.c_str(), 0700) == 0) {
      break;
    }
    if (errno != EEXIST) {
      system_error("create random descriptor-rooted unpack stage");
    }
    stage_name.clear();
  }
  if (stage_name.empty()) {
    throw std::runtime_error("could not allocate an absent unpack stage");
  }

  UniqueFd stage(::openat(
      location.parent.get(), stage_name.c_str(),
      O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC));
  if (!stage) {
    system_error("open created unpack stage");
  }
  const FileIdentity stage_identity = fstat_identity(stage.get(), "stat unpack stage");
  const FileIdentity stage_path_identity = child_path_identity(
      location.parent.get(), stage_name);
  if (!same_object(stage_identity, stage_path_identity)) {
    throw std::runtime_error("unpack stage changed before materialization");
  }

  bool stage_live = true;
  try {
    const int root_copy = ::dup(stage.get());
    if (root_copy < 0) {
      system_error("duplicate unpack root descriptor");
    }
    std::map<std::string, UniqueFd> directories;
    directories.emplace("", UniqueFd(root_copy));

    for (const Entry& entry : decoded.entries) {
      const std::string parent = parent_path(entry.path);
      const std::size_t separator = entry.path.rfind('/');
      const std::string name = separator == std::string::npos
          ? entry.path : entry.path.substr(separator + 1U);
      const auto parent_found = directories.find(parent);
      if (parent_found == directories.end()) {
        throw std::runtime_error("reconstruction parent descriptor is missing");
      }
      const int parent_descriptor = parent_found->second.get();
      if (entry.kind == kDirectory) {
        if (::mkdirat(parent_descriptor, name.c_str(), 0700) != 0) {
          system_error("create declared descriptor-rooted directory");
        }
        UniqueFd child(::openat(
            parent_descriptor, name.c_str(),
            O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC));
        if (!child) {
          system_error("open declared descriptor-rooted directory");
        }
        const FileIdentity opened = fstat_identity(child.get(), "stat created directory");
        const FileIdentity path_identity = child_path_identity(parent_descriptor, name);
        if (!same_object(opened, path_identity) || opened.permissions != 0700U) {
          throw std::runtime_error("created directory identity or staging mode disagrees");
        }
        directories.emplace(entry.path, std::move(child));
      } else {
        const auto found = decoded.blobs.find(entry.digest);
        if (found == decoded.blobs.end()) {
          throw std::runtime_error("internal missing blob during materialization");
        }
        write_materialized_file(parent_descriptor, name, found->second, entry.mode);
      }
    }

    for (auto iterator = decoded.entries.rbegin(); iterator != decoded.entries.rend(); ++iterator) {
      if (iterator->kind != kDirectory) {
        continue;
      }
      const auto found = directories.find(iterator->path);
      if (found == directories.end()) {
        throw std::runtime_error("reconstructed directory descriptor disappeared");
      }
      if (::fchmod(found->second.get(), static_cast<mode_t>(iterator->mode)) != 0) {
        system_error("chmod reconstructed directory");
      }
      if (::fsync(found->second.get()) != 0) {
        system_error("fsync reconstructed directory after mode");
      }
    }
    if (::fchmod(stage.get(), 0755) != 0) {
      system_error("chmod reconstructed root");
    }
    if (::fsync(stage.get()) != 0) {
      system_error("fsync reconstructed root");
    }

    const FileIdentity complete_stage = fstat_identity(stage.get(), "restat complete unpack stage");
    const FileIdentity complete_path = child_path_identity(location.parent.get(), stage_name);
    if (!same_object(stage_identity, complete_stage)
        || !same_object(stage_identity, complete_path)
        || complete_stage.permissions != 0755U) {
      throw std::runtime_error("complete unpack stage identity or root mode disagrees");
    }

    rename_noreplace(location.parent.get(), stage_name, location.name);
    stage_live = false;
    const FileIdentity final_identity = child_path_identity(
        location.parent.get(), location.name);
    if (!same_object(stage_identity, final_identity)) {
      throw std::runtime_error("published reconstruction identity disagrees with stage");
    }
    if (::fsync(location.parent.get()) != 0) {
      system_error("fsync reconstruction parent after no-replace publication");
    }
  } catch (...) {
    const int saved = errno;
    if (stage_live) {
      cleanup_stage_tree(stage.get());
      try {
        const FileIdentity current = child_path_identity(location.parent.get(), stage_name);
        if (same_object(stage_identity, current)) {
          (void)::unlinkat(location.parent.get(), stage_name.c_str(), AT_REMOVEDIR);
        }
      } catch (...) {
        // A stage path whose identity changed is preserved rather than deleted.
      }
    }
    errno = saved;
    throw;
  }
}

}  // namespace

Summary pack_exact_subject(const std::filesystem::path& source_root,
                           const std::filesystem::path& subject_manifest,
                           const std::filesystem::path& absent_output) {
  const std::vector<Entry> subject = read_subject(subject_manifest);
  auto [source_entries, blobs] = read_source(source_root);
  require_subject(source_entries, subject);
  const Bytes encoded = encode_pack(subject, blobs);
  const Decoded decoded = decode_pack(encoded);
  require_subject(decoded.entries, subject);
  write_exclusive(absent_output, encoded, 0444U);
  return summary_of(decoded);
}

Summary verify_exact_subject(const std::filesystem::path& pack_path,
                             const std::filesystem::path& subject_manifest) {
  const std::vector<Entry> subject = read_subject(subject_manifest);
  const Bytes encoded = read_file(pack_path);
  const Decoded decoded = decode_pack(encoded);
  require_subject(decoded.entries, subject);
  return summary_of(decoded);
}

Summary unpack_exact_subject(const std::filesystem::path& pack_path,
                             const std::filesystem::path& subject_manifest,
                             const std::filesystem::path& absent_destination) {
  const std::vector<Entry> subject = read_subject(subject_manifest);
  const Bytes encoded = read_file(pack_path);
  const Decoded decoded = decode_pack(encoded);
  require_subject(decoded.entries, subject);
  materialize(decoded, absent_destination);
  return summary_of(decoded);
}

}  // namespace slopos::e0::generation_journal::shadow_pack
