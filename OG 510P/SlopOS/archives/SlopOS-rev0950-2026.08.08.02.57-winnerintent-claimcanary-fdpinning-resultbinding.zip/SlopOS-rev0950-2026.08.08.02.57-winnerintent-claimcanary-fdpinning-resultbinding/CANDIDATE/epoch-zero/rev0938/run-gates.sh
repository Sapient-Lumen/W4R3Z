#!/usr/bin/env sh
set -eu
cube_root=${1:?usage: run-gates.sh CUBE_ROOT [PARENT_ARCHIVE]}
parent_archive=${2:-}
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
rm -rf "$here/build"
cmake -S "$here" -B "$here/build" -DCMAKE_BUILD_TYPE=Release
cmake --build "$here/build" --parallel
ctest --test-dir "$here/build" --output-on-failure
if [ -n "$parent_archive" ]; then
  python3 "$here/tools/check_predecessor_contract.py" \
    --cube-root "$cube_root" \
    --contract "$here/office/predecessor-contract.json" \
    --parent-archive "$parent_archive"
else
  python3 "$here/tools/check_predecessor_contract.py" \
    --cube-root "$cube_root" \
    --contract "$here/office/predecessor-contract.json"
fi
python3 "$here/tools/audit_cube.py" "$cube_root" \
  --output "$here/excavation/vault-audit.reproduced.json"
echo "rev0938 gates: PASS"
