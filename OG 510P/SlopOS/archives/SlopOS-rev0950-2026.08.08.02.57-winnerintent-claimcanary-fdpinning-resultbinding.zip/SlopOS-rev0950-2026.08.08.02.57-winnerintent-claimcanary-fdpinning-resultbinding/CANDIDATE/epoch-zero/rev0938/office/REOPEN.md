# Reopen rev0938

1. Read `STATE.json`; do not infer authority from the volume of the vault.
2. Verify `../manifests/payload.sha256` from the cube root using the command recorded in
   `CLOSE.md`.
3. Run `../run-gates.sh` with the cube root and the exact rev0937 archive when available.
4. Build only this nested CMake project, not the entire datacube.
5. Continue the single next obligation in `STATE.json`: a real two-principal expectation
   provisioning boundary. Keep it hosted and explicit unless an owner actually ratifies a
   stronger trust model.

Stop rather than improvise if the parent hash, predecessor contract, manifest, or test
output disagrees. Preserve the disagreement as a new incident before repair.
