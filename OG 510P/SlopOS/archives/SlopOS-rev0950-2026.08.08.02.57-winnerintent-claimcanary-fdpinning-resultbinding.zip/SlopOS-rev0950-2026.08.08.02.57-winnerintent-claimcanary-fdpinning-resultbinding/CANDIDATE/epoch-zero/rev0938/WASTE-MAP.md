# Waste map and correction order

The cube's dominant avoidable cost is repeated byte payload, not the small amount of new
proof code. The generated `excavation/vault-audit.json` measures exact duplicate payloads
by `(size, SHA-256)` and reports potential savings under a content-addressed representation.

**Do not delete duplicates now.** Repeated paths may still carry historical meaning, and
old reopen instructions may be path-addressed. The safe correction order is:

1. identity-map all payloads without changing paths;
2. classify which paths are evidence aliases and which are semantically distinct records;
3. make every living reopen edge manifest-addressed;
4. prove a reversible materializer from content identity to the old path view;
5. migrate one bounded vault stratum; and
6. only then remove physical duplicate payloads under an owner-ratified retention rule.

rev0938 performs step 1 and supplies the audit tool. It intentionally performs no deletion.
