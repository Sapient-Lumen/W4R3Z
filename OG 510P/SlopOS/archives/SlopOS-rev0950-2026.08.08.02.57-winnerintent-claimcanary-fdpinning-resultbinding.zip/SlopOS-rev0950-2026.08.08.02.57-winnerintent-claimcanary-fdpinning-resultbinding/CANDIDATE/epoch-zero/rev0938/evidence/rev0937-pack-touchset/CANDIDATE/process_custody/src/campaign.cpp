#include "slopos/e0/process_custody/custody.hpp"
#include "slopos/e0/trace_subject/subject.hpp"

#include <fcntl.h>
#include <grp.h>
#include <linux/capability.h>
#include <linux/sched.h>
#include <poll.h>
#include <signal.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <charconv>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <limits>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <tuple>
#include <utility>
#include <vector>

#ifndef P_PIDFD
#define P_PIDFD static_cast<idtype_t>(3)
#endif

extern char** environ;

namespace slopos::e0::process_custody {
namespace {

using trace_subject::sha256_hex;

struct ScopedFd {
    int value{-1};
    ScopedFd() = default;
    explicit ScopedFd(const int fd) : value(fd) {}
    ScopedFd(const ScopedFd&) = delete;
    ScopedFd& operator=(const ScopedFd&) = delete;
    ScopedFd(ScopedFd&& other) noexcept : value(std::exchange(other.value, -1)) {}
    ScopedFd& operator=(ScopedFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) close(value);
            value = std::exchange(other.value, -1);
        }
        return *this;
    }
    ~ScopedFd() { if (value >= 0) close(value); }
    [[nodiscard]] int get() const { return value; }
    [[nodiscard]] int release() { return std::exchange(value, -1); }
};

struct LiveConfig {
    std::string name{};
    unsigned stdio_mask{7U};
    bool absolute_exec{};
    bool next_exec{};
    bool leak_fd{};
    bool wrong_report{};
    bool expect_candidate{};
    bool expect_fail_closed{};
    bool expect_path_rebind{};
};

struct LiveResult {
    std::string name{};
    std::string disposition{};
    bool launch_closed_candidate{};
    bool fail_closed{};
    bool pidfd_bound{};
    bool same_process_lifetime{};
    bool descriptor_selected_exec{};
    bool path_rebind_retained_inode{};
    bool absolute_path_bypassed_dirfd{};
    bool executable_replaced{};
    bool no_new_privs_persisted{};
    bool nonroot_zero_capability_floor{};
    bool stdio_normalized{};
    bool descriptor_topology_closed{};
    bool exact_executable_join{};
    bool parser_agreement{};
    bool terminal_wait_by_pidfd{};
    bool provider_authenticated{};
    bool authority_granted{};
};

struct LaunchInput {
    std::filesystem::path worker_a{};
    std::filesystem::path worker_b{};
    int retained_exec_fd{-1};
    LiveConfig config{};
};

[[noreturn]] void child_die(const int code) { _exit(code); }

[[nodiscard]] std::vector<std::uint8_t> read_file(const std::filesystem::path& path) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error("open: " + path.string());
    return std::vector<std::uint8_t>(std::istreambuf_iterator<char>(stream), {});
}

[[nodiscard]] std::string file_sha256(const std::filesystem::path& path) {
    const auto bytes = read_file(path);
    return sha256_hex(std::span<const std::uint8_t>(bytes.data(), bytes.size()));
}

[[nodiscard]] int open_exec(const std::filesystem::path& path) {
    const int fd = open(path.c_str(), O_PATH | O_CLOEXEC);
    if (fd < 0) throw std::runtime_error("open_exec: " + path.string() + ": " + std::strerror(errno));
    return fd;
}

[[nodiscard]] std::string recv_packet(const int fd) {
    pollfd descriptor{fd, POLLIN, 0};
    int ready;
    do { ready = poll(&descriptor, 1U, 5000); } while (ready < 0 && errno == EINTR);
    if (ready != 1 || (descriptor.revents & POLLIN) == 0) {
        throw std::runtime_error("report timeout");
    }
    std::array<char, 8192> buffer{};
    const ssize_t count = recv(fd, buffer.data(), buffer.size(), 0);
    if (count <= 0) throw std::runtime_error("report receive");
    return std::string(buffer.data(), static_cast<std::size_t>(count));
}

void acknowledge(const int fd) {
    const char ack = 'K';
    if (send(fd, &ack, 1U, MSG_NOSIGNAL) != 1) throw std::runtime_error("report ack");
}

[[nodiscard]] std::uint64_t proc_starttime(const pid_t pid) {
    std::ifstream stream("/proc/" + std::to_string(pid) + "/stat");
    std::string line;
    std::getline(stream, line);
    const auto close_paren = line.rfind(')');
    if (!stream || close_paren == std::string::npos || close_paren + 2U >= line.size()) {
        throw std::runtime_error("proc stat");
    }
    std::istringstream fields(line.substr(close_paren + 2U));
    std::string token;
    for (int index = 0; index <= 19; ++index) {
        if (!(fields >> token)) throw std::runtime_error("proc starttime field");
    }
    std::uint64_t value{};
    const auto result = std::from_chars(token.data(), token.data() + token.size(), value);
    if (result.ec != std::errc{} || result.ptr != token.data() + token.size()) {
        throw std::runtime_error("proc starttime parse");
    }
    return value;
}

[[nodiscard]] std::string proc_exe_sha256(const pid_t pid) {
    return file_sha256("/proc/" + std::to_string(pid) + "/exe");
}

[[nodiscard]] std::map<std::string, std::string> proc_status(const pid_t pid) {
    std::ifstream stream("/proc/" + std::to_string(pid) + "/status");
    if (!stream) throw std::runtime_error("proc status");
    std::map<std::string, std::string> result;
    std::string line;
    while (std::getline(stream, line)) {
        const auto colon = line.find(':');
        if (colon == std::string::npos) continue;
        const auto first = line.find_first_not_of(" \t", colon + 1U);
        result.emplace(line.substr(0U, colon),
                       first == std::string::npos ? std::string{} : line.substr(first));
    }
    return result;
}

[[nodiscard]] bool status_uid_gid_nonroot(const std::map<std::string, std::string>& status) {
    const auto uid = status.find("Uid");
    const auto gid = status.find("Gid");
    if (uid == status.end() || gid == status.end()) return false;
    return uid->second.rfind("65534\t65534\t65534\t65534", 0U) == 0U &&
           gid->second.rfind("65534\t65534\t65534\t65534", 0U) == 0U;
}

[[nodiscard]] bool status_caps_zero(const std::map<std::string, std::string>& status) {
    for (const char* key : {"CapInh", "CapPrm", "CapEff", "CapBnd", "CapAmb"}) {
        const auto item = status.find(key);
        if (item == status.end() || item->second.empty() ||
            item->second.find_first_not_of('0') != std::string::npos) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool status_nnp(const std::map<std::string, std::string>& status) {
    const auto item = status.find("NoNewPrivs");
    return item != status.end() && item->second == "1";
}

void normalize_stdio(const unsigned mask) {
    // Exercise all inherited-open/closed combinations before forcing the same
    // controlled topology. The mask itself is not trusted evidence.
    for (int fd = 0; fd < 3; ++fd) {
        const unsigned bit = 1U << static_cast<unsigned>(fd);
        if ((mask & bit) == 0U) close(fd);
    }
    for (int fd = 0; fd < 3; ++fd) close(fd);
    const int input = open("/dev/null", O_RDONLY);
    const int output = open("/dev/null", O_WRONLY);
    const int error = open("/dev/null", O_WRONLY);
    if (input != 0 || output != 1 || error != 2) child_die(71);
}

void close_except(const std::set<int>& retained) {
    const long raw_limit = sysconf(_SC_OPEN_MAX);
    const int limit = raw_limit < 0L ? 65536 :
        static_cast<int>(std::min<long>(raw_limit, 65536L));
    for (int fd = 3; fd < limit; ++fd) {
        if (!retained.contains(fd)) close(fd);
    }
}

void enter_campaign_floor(const std::filesystem::path& output) {
    if (geteuid() == 0) {
        if (chown(output.c_str(), 65534, 65534) != 0) {
            throw std::runtime_error(std::string("chown campaign output: ") + std::strerror(errno));
        }
        if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) {
            throw std::runtime_error("campaign no_new_privs");
        }
#ifdef PR_CAP_AMBIENT
        if (prctl(PR_CAP_AMBIENT, PR_CAP_AMBIENT_CLEAR_ALL, 0, 0, 0) != 0 && errno != EINVAL) {
            throw std::runtime_error("campaign ambient clear");
        }
#endif
        std::ifstream cap_stream("/proc/sys/kernel/cap_last_cap");
        int cap_last = -1;
        cap_stream >> cap_last;
        if (!cap_stream || cap_last < 0 || cap_last > 4096) {
            throw std::runtime_error("campaign cap_last_cap");
        }
        for (int cap = 0; cap <= cap_last; ++cap) {
            if (prctl(PR_CAPBSET_DROP, cap, 0, 0, 0) != 0) {
                throw std::runtime_error("campaign bounding drop");
            }
        }
        if (setgroups(0U, nullptr) != 0 ||
            setresgid(65534, 65534, 65534) != 0 ||
            setresuid(65534, 65534, 65534) != 0) {
            throw std::runtime_error("campaign credential drop");
        }
        __user_cap_header_struct header{};
        header.version = _LINUX_CAPABILITY_VERSION_3;
        header.pid = 0;
        std::array<__user_cap_data_struct, 2> data{};
        if (syscall(SYS_capset, &header, data.data()) != 0) {
            throw std::runtime_error("campaign capset");
        }
    }
    if (geteuid() != 65534 || getegid() != 65534 ||
        prctl(PR_GET_NO_NEW_PRIVS, 0, 0, 0, 0) != 1) {
        throw std::runtime_error("campaign floor identity");
    }
    const auto status = proc_status(getpid());
    if (!status_uid_gid_nonroot(status) || !status_caps_zero(status)) {
        throw std::runtime_error("campaign floor status");
    }
}

void assert_child_floor(const pid_t expected_parent) {
    if (prctl(PR_SET_PDEATHSIG, SIGKILL, 0, 0, 0) != 0) child_die(72);
    if (getppid() != expected_parent) child_die(73);
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0) child_die(74);
    if (geteuid() != 65534 || getegid() != 65534) child_die(75);
}

[[noreturn]] void launch_child(
    const LaunchInput& input,
    const int child_socket,
    const int exec_a_fd,
    const int exec_b_fd,
    const pid_t expected_parent) {
    normalize_stdio(input.config.stdio_mask);
    if (dup3(child_socket, kReportFd, 0) < 0) child_die(82);
    std::set<int> retained{0, 1, 2, kReportFd};
    if (input.config.next_exec) {
        if (dup3(exec_b_fd, kNextExecFd, 0) < 0) child_die(83);
        retained.insert(kNextExecFd);
    }
    if (!input.config.absolute_exec) {
        if (dup3(exec_a_fd, kInitialExecFd, O_CLOEXEC) < 0) child_die(84);
        retained.insert(kInitialExecFd);
    }
    if (input.config.leak_fd) {
        const int leak = open("/dev/null", O_RDONLY);
        if (leak < 0 || dup3(leak, 13, 0) < 0) child_die(85);
        if (leak != 13) close(leak);
        retained.insert(13);
    }
    close_except(retained);
    assert_child_floor(expected_parent);

    if (setenv("SLOPOS_REPORT_FD", "10", 1) != 0) child_die(86);
    if (input.config.next_exec) {
        if (setenv("SLOPOS_NEXT_EXEC_FD", "11", 1) != 0) child_die(87);
    } else {
        unsetenv("SLOPOS_NEXT_EXEC_FD");
    }
    if (input.config.wrong_report) {
        if (setenv("SLOPOS_REPORT_ID_OVERRIDE", "worker-b", 1) != 0) child_die(88);
    } else {
        unsetenv("SLOPOS_REPORT_ID_OVERRIDE");
    }
    char arg0[] = "slopos-process-worker-a";
    char* const argv[] = {arg0, nullptr};
    if (input.config.absolute_exec) {
        syscall(SYS_execveat, -1, input.worker_a.c_str(), argv, ::environ, 0);
    } else {
        syscall(SYS_execveat, kInitialExecFd, "", argv, ::environ, AT_EMPTY_PATH);
    }
    child_die(89);
}

[[nodiscard]] bool report_floor_ok(const Report& report, const bool allow_next,
                                   const bool expect_leak) {
    return report.uid == 65534U && report.gid == 65534U && report.no_new_privs &&
           report.cap_inheritable_zero && report.cap_permitted_zero &&
           report.cap_effective_zero && report.cap_bounding_zero &&
           report.cap_ambient_zero && report.fd0_normalized && report.fd1_normalized &&
           report.fd2_normalized && report.report_fd_present &&
           report.next_exec_fd_present == allow_next &&
           report.unexpected_fd_count == (expect_leak ? 1U : 0U);
}

[[nodiscard]] LiveResult run_launch(const LaunchInput& input) {
    ScopedFd owned_a(input.retained_exec_fd >= 0 ? -1 : open_exec(input.worker_a));
    const int exec_a_fd = input.retained_exec_fd >= 0 ? input.retained_exec_fd : owned_a.get();
    ScopedFd exec_b(input.config.next_exec ? open_exec(input.worker_b) : -1);
    int sockets[2] = {-1, -1};
    if (socketpair(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0, sockets) != 0) {
        throw std::runtime_error("socketpair");
    }
    ScopedFd parent_socket(sockets[0]);
    ScopedFd child_socket(sockets[1]);
    int pidfd = -1;
    clone_args args{};
    args.flags = CLONE_PIDFD;
    args.pidfd = reinterpret_cast<std::uint64_t>(&pidfd);
    args.exit_signal = SIGCHLD;
    const pid_t parent_pid = getpid();
    const long clone_result = syscall(SYS_clone3, &args, sizeof(args));
    if (clone_result < 0) throw std::runtime_error(std::string("clone3: ") + std::strerror(errno));
    if (clone_result == 0) {
        const int ignored_parent_fd = parent_socket.release();
        (void)ignored_parent_fd;
        launch_child(input, child_socket.get(), exec_a_fd, exec_b.get(), parent_pid);
    }
    const pid_t pid = static_cast<pid_t>(clone_result);
    ScopedFd process_handle(pidfd);
    child_socket = ScopedFd{};
    owned_a = ScopedFd{};
    exec_b = ScopedFd{};

    const std::string expected_a_digest = file_sha256(input.worker_a);
    const std::string expected_b_digest = file_sha256(input.worker_b);
    const std::string first_bytes = recv_packet(parent_socket.get());
    const auto first_strict = parse_report_strict(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(first_bytes.data()), first_bytes.size()));
    const auto first_reference = parse_report_reference(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(first_bytes.data()), first_bytes.size()));
    const bool first_agree = first_strict.ok == first_reference.ok &&
        first_strict.code == first_reference.code &&
        (!first_strict.ok || first_strict.report == first_reference.report);
    const std::uint64_t start_a = proc_starttime(pid);
    const std::string proc_a_digest = proc_exe_sha256(pid);
    const auto status_a = proc_status(pid);
    const bool status_floor_a = status_uid_gid_nonroot(status_a) && status_caps_zero(status_a) &&
                                status_nnp(status_a);
    acknowledge(parent_socket.get());

    bool same_lifetime = true;
    bool exact_b = true;
    bool nnp_b = true;
    bool floor_b = true;
    bool second_agree = true;
    bool second_floor = true;
    if (input.config.next_exec) {
        const std::string second_bytes = recv_packet(parent_socket.get());
        const auto second_strict = parse_report_strict(std::span<const std::uint8_t>(
            reinterpret_cast<const std::uint8_t*>(second_bytes.data()), second_bytes.size()));
        const auto second_reference = parse_report_reference(std::span<const std::uint8_t>(
            reinterpret_cast<const std::uint8_t*>(second_bytes.data()), second_bytes.size()));
        second_agree = second_strict.ok == second_reference.ok &&
            second_strict.code == second_reference.code &&
            (!second_strict.ok || second_strict.report == second_reference.report);
        const std::uint64_t start_b = proc_starttime(pid);
        const std::string proc_b_digest = proc_exe_sha256(pid);
        const auto status_b = proc_status(pid);
        same_lifetime = start_a == start_b && first_strict.ok && second_strict.ok &&
                        first_strict.report.pid == second_strict.report.pid &&
                        first_strict.report.pid == static_cast<std::uint64_t>(pid);
        exact_b = proc_b_digest == expected_b_digest && second_strict.ok &&
                  second_strict.report.executable_id == "worker-b";
        nnp_b = second_strict.ok && second_strict.report.no_new_privs && status_nnp(status_b);
        floor_b = status_uid_gid_nonroot(status_b) && status_caps_zero(status_b);
        second_floor = second_strict.ok && report_floor_ok(second_strict.report, false, false);
        acknowledge(parent_socket.get());
    }

    siginfo_t info{};
    if (waitid(P_PIDFD, static_cast<id_t>(process_handle.get()), &info, WEXITED) != 0) {
        throw std::runtime_error(std::string("waitid pidfd: ") + std::strerror(errno));
    }
    const bool terminal_wait = info.si_code == CLD_EXITED && info.si_status == 0;
    const bool parser_agreement = first_agree && second_agree;
    const bool exact_a = proc_a_digest == expected_a_digest && first_strict.ok &&
                         first_strict.report.pid == static_cast<std::uint64_t>(pid) &&
                         first_strict.report.executable_id == "worker-a";
    const bool first_floor = first_strict.ok &&
                             report_floor_ok(first_strict.report, input.config.next_exec,
                                             input.config.leak_fd);
    const bool descriptor_closed = first_strict.ok &&
        first_strict.report.unexpected_fd_count == 0U &&
        (!input.config.next_exec || second_floor);
    const bool floor_ok = first_floor && status_floor_a && floor_b && second_floor;
    const bool exact_join = exact_a && exact_b;

    bool candidate = parser_agreement && process_handle.get() >= 0 && terminal_wait &&
                     floor_ok && descriptor_closed && exact_join &&
                     !input.config.absolute_exec && !input.config.next_exec &&
                     !input.config.leak_fd && !input.config.wrong_report;
    const bool fail_closed = !candidate &&
        (input.config.leak_fd || input.config.wrong_report);
    if (input.config.expect_candidate != candidate ||
        input.config.expect_fail_closed != fail_closed) {
        throw std::runtime_error("case disposition mismatch: " + input.config.name);
    }

    return LiveResult{
        input.config.name,
        candidate ? "HOSTED_LAUNCH_CLOSED_CANDIDATE" :
            (fail_closed ? "FAIL_CLOSED" : "COUNTEREXAMPLE_OBSERVED"),
        candidate,
        fail_closed,
        process_handle.get() >= 0,
        same_lifetime,
        !input.config.absolute_exec,
        input.config.expect_path_rebind && exact_a,
        input.config.absolute_exec && exact_a,
        input.config.next_exec,
        !input.config.next_exec || nnp_b,
        floor_ok,
        first_strict.ok && first_strict.report.fd0_normalized &&
            first_strict.report.fd1_normalized && first_strict.report.fd2_normalized,
        descriptor_closed,
        exact_join,
        parser_agreement,
        terminal_wait,
        false,
        false,
    };
}

[[nodiscard]] Report fixed_report() {
    return Report{
        std::string(kReportSchema), "ENTRY", "worker-a", 1234U, 1200U,
        65534U, 65534U, true, true, true, true, true, true,
        true, true, true, true, false, 0U,
    };
}

[[nodiscard]] std::string replace_once(std::string text, const std::string& needle,
                                       const std::string& replacement) {
    const auto pos = text.find(needle);
    if (pos == std::string::npos) throw std::runtime_error("fixture needle");
    text.replace(pos, needle.size(), replacement);
    return text;
}

struct ParserFixture {
    std::string name{};
    std::string bytes{};
    bool accepted{};
};

[[nodiscard]] std::vector<ParserFixture> parser_fixtures() {
    Report base = fixed_report();
    const std::string valid = serialize_report(base);
    Report next = base; next.next_exec_fd_present = true;
    Report worker_b = base; worker_b.executable_id = "worker-b";
    Report leak = base; leak.unexpected_fd_count = 1U;
    std::vector<ParserFixture> fixtures{
        {"valid-worker-a", valid, true},
        {"valid-worker-a-next", serialize_report(next), true},
        {"valid-worker-b", serialize_report(worker_b), true},
        {"valid-observed-leak", serialize_report(leak), true},
        {"missing-terminal-newline", valid.substr(0U, valid.size() - 1U), false},
        {"carriage-return", replace_once(valid, "phase\tENTRY\n", "phase\tENTRY\r\n"), false},
        {"embedded-nul", replace_once(valid, "worker-a", std::string("worker\0a", 8U)), false},
        {"wrong-schema", replace_once(valid, std::string(kReportSchema), "slopos.process-report.v2"), false},
        {"wrong-phase", replace_once(valid, "phase\tENTRY", "phase\tEXIT"), false},
        {"unknown-executable", replace_once(valid, "worker-a", "worker-c"), false},
        {"zero-pid", replace_once(valid, "pid\t1234", "pid\t0"), false},
        {"leading-zero-pid", replace_once(valid, "pid\t1234", "pid\t01234"), false},
        {"negative-uid", replace_once(valid, "uid\t65534", "uid\t-1"), false},
        {"invalid-bool", replace_once(valid, "no_new_privs\t1", "no_new_privs\t2"), false},
        {"missing-field", replace_once(valid, "cap_ambient_zero\t1\n", ""), false},
        {"duplicate-field", replace_once(valid, "phase\tENTRY\n", "phase\tENTRY\nphase\tENTRY\n"), false},
        {"swapped-fields", replace_once(valid, "pid\t1234\nppid\t1200\n", "ppid\t1200\npid\t1234\n"), false},
        {"unknown-field", valid + "future\t1\n", false},
        {"extra-tab", replace_once(valid, "phase\tENTRY", "phase\tENTRY\textra"), false},
        {"empty", "", false},
        {"blank-line", replace_once(valid, "phase\tENTRY\n", "phase\tENTRY\n\n"), false},
        {"oversized", std::string(4097U, 'x'), false},
    };
    return fixtures;
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("write: " + path.string());
    stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    if (!stream) throw std::runtime_error("write incomplete: " + path.string());
}

[[nodiscard]] std::string bool_text(const bool value) { return value ? "true" : "false"; }

[[nodiscard]] std::string state_key(const State& state) {
    return phase_name(state.phase) + "|" + bool_text(state.pidfd_bound) + "|" +
           bool_text(state.no_new_privs) + "|" + bool_text(state.initial_launch_closed) + "|" +
           bool_text(state.executable_replaced) + "|" +
           bool_text(state.executable_continuity_bound) + "|" +
           bool_text(state.provider_authenticated) + "|" + bool_text(state.authority_granted);
}

}  // namespace

CampaignReport run_campaign(const std::filesystem::path& output,
                            const std::filesystem::path& worker_a,
                            const std::filesystem::path& worker_b) {
    try {
        if (std::filesystem::exists(output)) return {false, "output-exists"};
        if (!std::filesystem::is_regular_file(worker_a) ||
            !std::filesystem::is_regular_file(worker_b)) {
            return {false, "worker-missing"};
        }
        std::filesystem::create_directories(output);
        enter_campaign_floor(output);

        std::vector<LiveResult> live;
        for (unsigned mask = 0U; mask < 8U; ++mask) {
            LiveConfig config;
            std::ostringstream name;
            name << "stdio-topology-" << ((mask & 4U) ? '1' : '0')
                 << ((mask & 2U) ? '1' : '0') << ((mask & 1U) ? '1' : '0');
            config.name = name.str();
            config.stdio_mask = mask;
            config.expect_candidate = true;
            live.push_back(run_launch({worker_a, worker_b, -1, config}));
        }

        // Descriptor-selected execution survives a pathname rebind.
        const auto scratch = std::filesystem::temp_directory_path() /
            ("slopos-process-rebind-" + std::to_string(getpid()));
        std::filesystem::remove_all(scratch);
        std::filesystem::create_directory(scratch);
        const auto selected = scratch / "selected";
        const auto displaced = scratch / "displaced";
        std::filesystem::copy_file(worker_a, selected);
        std::filesystem::permissions(selected,
            std::filesystem::perms::owner_read | std::filesystem::perms::owner_exec |
            std::filesystem::perms::group_read | std::filesystem::perms::group_exec |
            std::filesystem::perms::others_read | std::filesystem::perms::others_exec,
            std::filesystem::perm_options::replace);
        ScopedFd retained(open_exec(selected));
        std::filesystem::rename(selected, displaced);
        std::filesystem::copy_file(worker_b, selected);
        std::filesystem::permissions(selected,
            std::filesystem::perms::owner_read | std::filesystem::perms::owner_exec |
            std::filesystem::perms::group_read | std::filesystem::perms::group_exec |
            std::filesystem::perms::others_read | std::filesystem::perms::others_exec,
            std::filesystem::perm_options::replace);
        LiveConfig rebind{"path-rebind-retained-execfd", 7U, false, false, false, false,
                          true, false, true};
        live.push_back(run_launch({displaced, worker_b, retained.get(), rebind}));
        retained = ScopedFd{};
        std::filesystem::remove_all(scratch);

        LiveConfig absolute{"absolute-execveat-ignores-dirfd", 7U, true, false, false, false,
                            false, false, false};
        live.push_back(run_launch({std::filesystem::absolute(worker_a), worker_b, -1, absolute}));

        LiveConfig replacement{"pidfd-spans-exec-replacement", 7U, false, true, false, false,
                               false, false, false};
        live.push_back(run_launch({worker_a, worker_b, -1, replacement}));

        LiveConfig nnp{"no-new-privs-persists-across-exec", 3U, false, true, false, false,
                       false, false, false};
        live.push_back(run_launch({worker_a, worker_b, -1, nnp}));

        LiveConfig leak{"unexpected-descriptor-fails-closed", 7U, false, false, true, false,
                        false, true, false};
        live.push_back(run_launch({worker_a, worker_b, -1, leak}));

        LiveConfig wrong{"report-executable-mismatch-fails-closed", 7U, false, false, false, true,
                         false, true, false};
        live.push_back(run_launch({worker_a, worker_b, -1, wrong}));

        std::ostringstream live_table;
        live_table << "case\tdisposition\tlaunch_closed_candidate\tfail_closed\tpidfd_bound"
                   << "\tsame_process_lifetime\tdescriptor_selected_exec"
                   << "\tpath_rebind_retained_inode\tabsolute_path_bypassed_dirfd"
                   << "\texecutable_replaced\tno_new_privs_persisted"
                   << "\tnonroot_zero_capability_floor\tstdio_normalized"
                   << "\tdescriptor_topology_closed\texact_executable_join"
                   << "\tparser_agreement\tterminal_wait_by_pidfd"
                   << "\tprovider_authenticated\tauthority_granted\n";
        std::size_t candidates = 0U;
        std::size_t fail_closed = 0U;
        for (const auto& row : live) {
            candidates += row.launch_closed_candidate ? 1U : 0U;
            fail_closed += row.fail_closed ? 1U : 0U;
            live_table << row.name << '\t' << row.disposition << '\t'
                       << bool_text(row.launch_closed_candidate) << '\t'
                       << bool_text(row.fail_closed) << '\t'
                       << bool_text(row.pidfd_bound) << '\t'
                       << bool_text(row.same_process_lifetime) << '\t'
                       << bool_text(row.descriptor_selected_exec) << '\t'
                       << bool_text(row.path_rebind_retained_inode) << '\t'
                       << bool_text(row.absolute_path_bypassed_dirfd) << '\t'
                       << bool_text(row.executable_replaced) << '\t'
                       << bool_text(row.no_new_privs_persisted) << '\t'
                       << bool_text(row.nonroot_zero_capability_floor) << '\t'
                       << bool_text(row.stdio_normalized) << '\t'
                       << bool_text(row.descriptor_topology_closed) << '\t'
                       << bool_text(row.exact_executable_join) << '\t'
                       << bool_text(row.parser_agreement) << '\t'
                       << bool_text(row.terminal_wait_by_pidfd) << '\t'
                       << bool_text(row.provider_authenticated) << '\t'
                       << bool_text(row.authority_granted) << '\n';
        }
        write_text(output / "live-cases.tsv", live_table.str());

        const auto fixtures = parser_fixtures();
        std::ostringstream parser_table;
        parser_table << "case\texpected_accepted\tstrict_accepted\treference_accepted"
                     << "\tstrict_code\treference_code\tagree\n";
        std::size_t parser_disagreements = 0U;
        for (const auto& fixture : fixtures) {
            const auto bytes = std::span<const std::uint8_t>(
                reinterpret_cast<const std::uint8_t*>(fixture.bytes.data()), fixture.bytes.size());
            const auto strict = parse_report_strict(bytes);
            const auto reference = parse_report_reference(bytes);
            const bool agree = strict.ok == reference.ok && strict.code == reference.code &&
                (!strict.ok || strict.report == reference.report);
            if (!agree || strict.ok != fixture.accepted) ++parser_disagreements;
            parser_table << fixture.name << '\t' << bool_text(fixture.accepted) << '\t'
                         << bool_text(strict.ok) << '\t' << bool_text(reference.ok) << '\t'
                         << report_code_name(strict.code) << '\t'
                         << report_code_name(reference.code) << '\t' << bool_text(agree) << '\n';
        }
        write_text(output / "parser-cases.tsv", parser_table.str());
        if (parser_disagreements != 0U) {
            return {false, "parser-disagreement-or-expectation"};
        }

        std::vector<State> states{initial_state()};
        std::map<std::string, std::size_t> state_ids{{state_key(states.front()), 0U}};
        for (std::size_t index = 0U; index < states.size(); ++index) {
            for (const auto event : all_events()) {
                const auto transition = step_core(states[index], event);
                if (transition.outcome == Outcome::applied) {
                    const std::string key = state_key(transition.state);
                    if (!state_ids.contains(key)) {
                        state_ids.emplace(key, states.size());
                        states.push_back(transition.state);
                    }
                }
            }
        }
        std::ostringstream relation;
        relation << "state_id\tphase\tpidfd_bound\tno_new_privs\tinitial_launch_closed"
                 << "\texecutable_replaced\texecutable_continuity_bound"
                 << "\tprovider_authenticated\tauthority_granted\tevent\toutcome"
                 << "\tnext_state_id\tnext_phase\n";
        std::size_t applied = 0U;
        std::size_t rejected = 0U;
        for (std::size_t index = 0U; index < states.size(); ++index) {
            if (!invariant(states[index])) return {false, "state-invariant"};
            for (const auto event : all_events()) {
                const auto core = step_core(states[index], event);
                const auto reference = step_reference(states[index], event);
                if (core.outcome != reference.outcome || core.state != reference.state ||
                    !invariant(core.state)) {
                    return {false, "model-disagreement"};
                }
                applied += core.outcome == Outcome::applied ? 1U : 0U;
                rejected += core.outcome == Outcome::rejected ? 1U : 0U;
                const auto next = state_ids.at(state_key(core.state));
                relation << index << '\t' << phase_name(states[index].phase) << '\t'
                         << bool_text(states[index].pidfd_bound) << '\t'
                         << bool_text(states[index].no_new_privs) << '\t'
                         << bool_text(states[index].initial_launch_closed) << '\t'
                         << bool_text(states[index].executable_replaced) << '\t'
                         << bool_text(states[index].executable_continuity_bound) << '\t'
                         << bool_text(states[index].provider_authenticated) << '\t'
                         << bool_text(states[index].authority_granted) << '\t'
                         << event_name(event) << '\t' << outcome_name(core.outcome) << '\t'
                         << next << '\t' << phase_name(core.state.phase) << '\n';
            }
        }
        write_text(output / "relation.tsv", relation.str());

        std::ostringstream counterexamples;
        counterexamples << "id\tobserved\tproves\tresult\n"
            << "PIDFD_NOT_EXEC_EPOCH\tsame pidfd and start time span worker-a to worker-b"
            << "\texecutable continuity\tfalse\n"
            << "ABSOLUTE_EXECVEAT_BYPASSES_DIRFD\tabsolute path executes with invalid dirfd"
            << "\tdirfd-selected execution\tfalse\n"
            << "PATH_IS_NOT_EXECUTED_INODE\tretained descriptor executes worker-a after path names worker-b"
            << "\tpath identity equals executed inode\tfalse\n"
            << "NO_NEW_PRIVS_NOT_EXEC_CLOSURE\tno_new_privs remains set across worker-a to worker-b"
            << "\texec replacement prohibited\tfalse\n"
            << "TRANSCRIPT_NOT_PROVIDER_AUTH\tcanonical process report is forgeable ordinary bytes"
            << "\tprovider authentication\tfalse\n";
        write_text(output / "counterexamples.tsv", counterexamples.str());

        std::ostringstream certificate;
        certificate << "{\n"
            << "  \"authority_bearing_results\": 0,\n"
            << "  \"counterexamples\": 5,\n"
            << "  \"executable_continuity_bound\": false,\n"
            << "  \"fail_closed_cases\": " << fail_closed << ",\n"
            << "  \"fixture_transcript_provider_authenticated\": false,\n"
            << "  \"launch_closed_candidates\": " << candidates << ",\n"
            << "  \"live_cases\": " << live.size() << ",\n"
            << "  \"model_applied\": " << applied << ",\n"
            << "  \"model_events_per_state\": " << all_events().size() << ",\n"
            << "  \"model_rejected\": " << rejected << ",\n"
            << "  \"model_states\": " << states.size() << ",\n"
            << "  \"model_transitions\": " << states.size() * all_events().size() << ",\n"
            << "  \"parser_cases\": " << fixtures.size() << ",\n"
            << "  \"parser_disagreements\": 0,\n"
            << "  \"process_custody_results\": 0,\n"
            << "  \"provider_authenticated_results\": 0,\n"
            << "  \"schema\": \"slopos.rev0883.process-custody-campaign.v1\",\n"
            << "  \"status\": \"PASS\"\n"
            << "}\n";
        write_text(output / "certificate.json", certificate.str());

        return CampaignReport{
            true, "ok", live.size(), candidates, fail_closed, fixtures.size(), 0U,
            states.size(), states.size() * all_events().size(), applied, rejected, 5U,
            0U, 0U, 0U,
        };
    } catch (const std::exception& error) {
        return {false, error.what()};
    }
}

}  // namespace slopos::e0::process_custody
