#include "slopos/e0/crash_image/profile.hpp"

#include "slopos/e0/fence/core.hpp"
#include "slopos/e0/journal/durable_cut.hpp"

#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <stdexcept>
#include <utility>

namespace slopos::e0::crash_image {
namespace {

namespace fence = slopos::e0::fence;
namespace journal = slopos::e0::journal;

enum class LocalClass : std::uint8_t {
    c1,
    c2,
    c3_no_effect,
    c3_effect,
    c3_uncertain,
    c4_no_effect,
    c4_effect,
    c4_uncertain,
    invalid,
};

enum class FloorClass : std::uint8_t { predecessor, successor, invalid };
enum class ResultClass : std::uint8_t { absent, no_effect, effect, invalid };
enum class EffectClass : std::uint8_t { absent, present, invalid };

struct Canonical final {
    Block zero{};
    Block header{};
    Block floor_predecessor{};
    Block floor_successor{};
    Block effect{};
    Block result_no_effect{};
    Block result_effect{};
};

void put_u64(Block& block, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t i = 0U; i < 8U; ++i) {
        const unsigned int shift = static_cast<unsigned int>(i * 8U);
        block[offset + i] = static_cast<std::uint8_t>(value >> shift);
    }
}

void put_tag(Block& block, const std::string_view tag) noexcept {
    const std::size_t limit = std::min(tag.size(), static_cast<std::size_t>(31U));
    for (std::size_t i = 0U; i < limit; ++i) {
        block[i] = static_cast<std::uint8_t>(tag[i]);
    }
}

template <typename Array>
void put_array(Block& block, const std::size_t offset,
               const Array& value) noexcept {
    for (std::size_t i = 0U; i < value.size(); ++i) {
        block[offset + i] = value[i];
    }
}

[[nodiscard]] Canonical make_canonical() {
    Canonical c{};
    const fence::Fixtures& f = fence::fixtures();

    put_tag(c.header, "SLOPOS-CRASH-IMAGE-V1");
    put_u64(c.header, 32U, 1U);
    put_u64(c.header, 40U, static_cast<std::uint64_t>(kBlockSize));
    put_u64(c.header, 48U, static_cast<std::uint64_t>(kBlockCount));
    put_u64(c.header, 56U, f.descriptor.operation_id);
    put_array(c.header, 64U, journal::admission_digest_v1(f.descriptor));

    put_tag(c.floor_predecessor, "SLOPOS-FLOOR-V1");
    put_u64(c.floor_predecessor, 32U, f.predecessor.generation);
    put_array(c.floor_predecessor, 64U, f.floor_identity);
    put_array(c.floor_predecessor, 96U, f.predecessor.state_digest);

    put_tag(c.floor_successor, "SLOPOS-FLOOR-V1");
    put_u64(c.floor_successor, 32U, f.successor.generation);
    put_array(c.floor_successor, 64U, f.floor_identity);
    put_array(c.floor_successor, 96U, f.successor.state_digest);

    put_tag(c.effect, "SLOPOS-EFFECT-V1");
    put_u64(c.effect, 32U, f.descriptor.operation_id);
    put_array(c.effect, 64U, journal::admission_digest_v1(f.descriptor));
    put_array(c.effect, 96U, f.descriptor.payload_digest);

    put_tag(c.result_no_effect, "SLOPOS-RESULT-V1");
    c.result_no_effect[31U] = 1U;
    put_u64(c.result_no_effect, 32U, f.descriptor.operation_id);
    put_array(c.result_no_effect, 64U,
              journal::admission_digest_v1(f.descriptor));
    put_array(c.result_no_effect, 96U,
              journal::completion_digest_v1(
                  journal::admission_digest_v1(f.descriptor),
                  f.no_effect_completion));

    put_tag(c.result_effect, "SLOPOS-RESULT-V1");
    c.result_effect[31U] = 2U;
    put_u64(c.result_effect, 32U, f.descriptor.operation_id);
    put_array(c.result_effect, 64U,
              journal::admission_digest_v1(f.descriptor));
    put_array(c.result_effect, 96U,
              journal::completion_digest_v1(
                  journal::admission_digest_v1(f.descriptor),
                  f.effect_completion));
    return c;
}

[[nodiscard]] const Canonical& canonical() {
    static const Canonical value = make_canonical();
    return value;
}

[[nodiscard]] Block get_block(const Image& image, const std::size_t index) {
    Block result{};
    const std::size_t offset = index * kBlockSize;
    std::copy_n(image.begin() + static_cast<std::ptrdiff_t>(offset),
                static_cast<std::ptrdiff_t>(kBlockSize), result.begin());
    return result;
}

void set_block(Image& image, const std::size_t index,
               const Block& block) noexcept {
    const std::size_t offset = index * kBlockSize;
    std::copy(block.begin(), block.end(),
              image.begin() + static_cast<std::ptrdiff_t>(offset));
}

[[nodiscard]] journal::DurableCutV1Image local_image(const Image& image) {
    journal::DurableCutV1Image local{};
    std::copy_n(image.begin() + static_cast<std::ptrdiff_t>(kBlockSize),
                static_cast<std::ptrdiff_t>(local.size()), local.begin());
    return local;
}

[[nodiscard]] std::string local_name(const LocalClass value) {
    switch (value) {
        case LocalClass::c1: return "C1";
        case LocalClass::c2: return "C2";
        case LocalClass::c3_no_effect: return "C3_NO_EFFECT";
        case LocalClass::c3_effect: return "C3_EFFECT";
        case LocalClass::c3_uncertain: return "C3_UNCERTAIN";
        case LocalClass::c4_no_effect: return "C4_NO_EFFECT";
        case LocalClass::c4_effect: return "C4_EFFECT";
        case LocalClass::c4_uncertain: return "C4_UNCERTAIN";
        case LocalClass::invalid: return "INVALID";
    }
    return "INVALID";
}

[[nodiscard]] FloorClass floor_class(const Image& image) {
    const Block value = get_block(image, 3U);
    if (value == canonical().floor_predecessor) return FloorClass::predecessor;
    if (value == canonical().floor_successor) return FloorClass::successor;
    return FloorClass::invalid;
}

[[nodiscard]] std::string floor_name(const FloorClass value) {
    switch (value) {
        case FloorClass::predecessor: return "PREDECESSOR";
        case FloorClass::successor: return "SUCCESSOR";
        case FloorClass::invalid: return "INVALID";
    }
    return "INVALID";
}

[[nodiscard]] ResultClass result_class(const Image& image) {
    const Block value = get_block(image, 5U);
    if (value == canonical().zero) return ResultClass::absent;
    if (value == canonical().result_no_effect) return ResultClass::no_effect;
    if (value == canonical().result_effect) return ResultClass::effect;
    return ResultClass::invalid;
}

[[nodiscard]] std::string result_name(const ResultClass value) {
    switch (value) {
        case ResultClass::absent: return "ABSENT";
        case ResultClass::no_effect: return "NO_EFFECT";
        case ResultClass::effect: return "EFFECT";
        case ResultClass::invalid: return "INVALID";
    }
    return "INVALID";
}

[[nodiscard]] EffectClass effect_class(const Image& image) {
    const Block value = get_block(image, 4U);
    if (value == canonical().zero) return EffectClass::absent;
    if (value == canonical().effect) return EffectClass::present;
    return EffectClass::invalid;
}

[[nodiscard]] LocalClass completion_class(const journal::Record& record,
                                          const bool published) {
    const fence::Fixtures& f = fence::fixtures();
    if (record.completion == f.no_effect_completion) {
        return published ? LocalClass::c4_no_effect
                         : LocalClass::c3_no_effect;
    }
    if (record.completion == f.effect_completion) {
        return published ? LocalClass::c4_effect : LocalClass::c3_effect;
    }
    if (record.completion == f.uncertain_completion) {
        return published ? LocalClass::c4_uncertain
                         : LocalClass::c3_uncertain;
    }
    return LocalClass::invalid;
}

[[nodiscard]] LocalClass sealed_local_class(const Image& image) {
    const journal::RecoveryResult recovered =
        journal::recover_image_v1(local_image(image));
    if (recovered.status != journal::RecoveryStatus::recovered
        || !recovered.has_record) {
        return LocalClass::invalid;
    }
    const journal::Record& record = recovered.record;
    switch (record.phase) {
        case journal::Phase::admitted: return LocalClass::c1;
        case journal::Phase::dispatch_started: return LocalClass::c2;
        case journal::Phase::completed:
            return completion_class(record, false);
        case journal::Phase::published:
            return completion_class(record, true);
    }
    return LocalClass::invalid;
}

struct ExactSlot final {
    bool known{false};
    bool empty{false};
    std::uint64_t generation{0U};
    LocalClass local{LocalClass::invalid};
};

[[nodiscard]] Block fixture_slot(
    const journal::DurableCutV1Image& image, const std::size_t slot) {
    Block block{};
    const std::size_t offset = slot * kBlockSize;
    std::copy_n(image.begin() + static_cast<std::ptrdiff_t>(offset),
                static_cast<std::ptrdiff_t>(kBlockSize), block.begin());
    return block;
}

[[nodiscard]] ExactSlot exact_slot_class(const Block& block,
                                         const std::size_t slot) {
    const fence::Fixtures& f = fence::fixtures();
    if (block == Block{}) return ExactSlot{true, true, 0U, LocalClass::invalid};
    if (slot == 0U) {
        if (block == fixture_slot(f.c2, 0U)) {
            return ExactSlot{true, false, 2U, LocalClass::c2};
        }
        if (block == fixture_slot(f.c4_no_effect, 0U)) {
            return ExactSlot{true, false, 4U, LocalClass::c4_no_effect};
        }
        if (block == fixture_slot(f.c4_effect, 0U)) {
            return ExactSlot{true, false, 4U, LocalClass::c4_effect};
        }
        if (block == fixture_slot(f.c4_uncertain, 0U)) {
            return ExactSlot{true, false, 4U, LocalClass::c4_uncertain};
        }
    } else if (slot == 1U) {
        if (block == fixture_slot(f.c1, 1U)) {
            return ExactSlot{true, false, 1U, LocalClass::c1};
        }
        if (block == fixture_slot(f.c3_no_effect, 1U)) {
            return ExactSlot{true, false, 3U, LocalClass::c3_no_effect};
        }
        if (block == fixture_slot(f.c3_effect, 1U)) {
            return ExactSlot{true, false, 3U, LocalClass::c3_effect};
        }
        if (block == fixture_slot(f.c3_uncertain, 1U)) {
            return ExactSlot{true, false, 3U, LocalClass::c3_uncertain};
        }
    }
    return ExactSlot{};
}

[[nodiscard]] bool exact_successor(const LocalClass before,
                                   const LocalClass after) noexcept {
    if (before == LocalClass::c1) return after == LocalClass::c2;
    if (before == LocalClass::c2) {
        return after == LocalClass::c3_no_effect
            || after == LocalClass::c3_effect
            || after == LocalClass::c3_uncertain;
    }
    if (before == LocalClass::c3_no_effect) {
        return after == LocalClass::c4_no_effect;
    }
    if (before == LocalClass::c3_effect) {
        return after == LocalClass::c4_effect;
    }
    if (before == LocalClass::c3_uncertain) {
        return after == LocalClass::c4_uncertain;
    }
    return false;
}

[[nodiscard]] LocalClass exact_local_class(const Image& image) {
    const ExactSlot first = exact_slot_class(get_block(image, 1U), 0U);
    const ExactSlot second = exact_slot_class(get_block(image, 2U), 1U);
    if (!first.known || !second.known) return LocalClass::invalid;
    if (first.empty && second.empty) return LocalClass::invalid;
    if (first.empty) return second.local;
    if (second.empty) return first.local;
    const ExactSlot& older = first.generation < second.generation ? first : second;
    const ExactSlot& newer = first.generation < second.generation ? second : first;
    if (newer.generation != older.generation + 1U
        || !exact_successor(older.local, newer.local)) {
        return LocalClass::invalid;
    }
    return newer.local;
}

[[nodiscard]] bool is_no_effect_local(const LocalClass value) noexcept {
    return value == LocalClass::c3_no_effect
        || value == LocalClass::c4_no_effect;
}

[[nodiscard]] bool is_effect_local(const LocalClass value) noexcept {
    return value == LocalClass::c3_effect || value == LocalClass::c4_effect;
}

[[nodiscard]] bool is_uncertain_local(const LocalClass value) noexcept {
    return value == LocalClass::c3_uncertain
        || value == LocalClass::c4_uncertain;
}

[[nodiscard]] Classification fail(const LocalClass local,
                                  const FloorClass floor,
                                  const ResultClass result,
                                  const EffectClass effect,
                                  std::string detail) {
    return Classification{Outcome::fail_stop, local_name(local),
                          floor_name(floor), result_name(result),
                          effect == EffectClass::present, std::move(detail)};
}

[[nodiscard]] Operation journal_transition(
    const journal::DurableCutV1Image& before,
    const journal::DurableCutV1Image& after,
    std::string label) {
    std::vector<std::size_t> changed{};
    for (std::size_t block = 0U; block < 2U; ++block) {
        const auto begin = block * kBlockSize;
        const bool equal = std::equal(
            before.begin() + static_cast<std::ptrdiff_t>(begin),
            before.begin() + static_cast<std::ptrdiff_t>(begin + kBlockSize),
            after.begin() + static_cast<std::ptrdiff_t>(begin));
        if (!equal) changed.push_back(block);
    }
    if (changed.size() != 1U) {
        throw std::runtime_error("journal transition must change one slot");
    }
    Block bytes{};
    const std::size_t offset = changed.front() * kBlockSize;
    std::copy_n(after.begin() + static_cast<std::ptrdiff_t>(offset),
                static_cast<std::ptrdiff_t>(kBlockSize), bytes.begin());
    return Operation{OperationKind::write, Device::local,
                     1U + changed.front(), bytes, std::move(label)};
}

[[nodiscard]] Operation journal_block_write(
    const journal::DurableCutV1Image& image, const std::size_t slot,
    std::string label) {
    if (slot >= 2U) throw std::runtime_error("journal slot out of range");
    Block bytes{};
    const std::size_t offset = slot * kBlockSize;
    std::copy_n(image.begin() + static_cast<std::ptrdiff_t>(offset),
                static_cast<std::ptrdiff_t>(kBlockSize), bytes.begin());
    return Operation{OperationKind::write, Device::local, 1U + slot, bytes,
                     std::move(label)};
}

[[nodiscard]] Operation write_operation(const Device device,
                                        const std::size_t block,
                                        const Block& bytes,
                                        std::string label) {
    return Operation{OperationKind::write, device, block, bytes,
                     std::move(label)};
}

[[nodiscard]] Operation flush_operation(const Device device,
                                        std::string label) {
    return Operation{OperationKind::flush, device, 0U, Block{},
                     std::move(label)};
}

[[nodiscard]] Operation mark_operation(std::string label) {
    return Operation{OperationKind::mark, Device::local, 0U, Block{},
                     std::move(label)};
}

}  // namespace

std::string_view device_name(const Device value) noexcept {
    switch (value) {
        case Device::local: return "LOCAL";
        case Device::floor: return "FLOOR";
        case Device::endpoint: return "ENDPOINT";
    }
    return "UNKNOWN";
}

std::string_view operation_name(const OperationKind value) noexcept {
    switch (value) {
        case OperationKind::write: return "WRITE";
        case OperationKind::flush: return "FLUSH";
        case OperationKind::mark: return "MARK";
    }
    return "UNKNOWN";
}

std::string_view outcome_name(const Outcome value) noexcept {
    switch (value) {
        case Outcome::effect: return "EFFECT";
        case Outcome::no_effect: return "NO_EFFECT";
        case Outcome::uncertain: return "UNCERTAIN";
        case Outcome::fail_stop: return "FAIL_STOP";
    }
    return "FAIL_STOP";
}

Image initial_image() {
    Image image{};
    set_block(image, 0U, canonical().header);
    const journal::DurableCutV1Image& c1 = fence::fixtures().c1;
    std::copy(c1.begin(), c1.end(),
              image.begin() + static_cast<std::ptrdiff_t>(kBlockSize));
    set_block(image, 3U, canonical().floor_predecessor);
    return image;
}

std::vector<Trace> traces() {
    const fence::Fixtures& f = fence::fixtures();
    const Operation c2 = journal_transition(f.c1, f.c2, "write-c2-slot");
    const Operation c3_effect =
        journal_transition(f.c2, f.c3_effect, "write-c3-effect-slot");
    const Operation c4_effect =
        journal_transition(f.c3_effect, f.c4_effect, "write-c4-effect-slot");
    const Operation c3_no =
        journal_transition(f.c2, f.c3_no_effect, "write-c3-no-effect-slot");
    const Operation c4_no = journal_transition(
        f.c3_no_effect, f.c4_no_effect, "write-c4-no-effect-slot");

    Trace good_effect{"good-effect", {
        c2,
        mark_operation("mark-c2-observed"),
        flush_operation(Device::local, "flush-local-c2"),
        write_operation(Device::floor, 3U, canonical().floor_successor,
                        "write-floor-successor"),
        flush_operation(Device::floor, "flush-floor-successor"),
        write_operation(Device::endpoint, 4U, canonical().effect,
                        "write-endpoint-effect"),
        flush_operation(Device::endpoint, "flush-endpoint-effect"),
        write_operation(Device::endpoint, 5U, canonical().result_effect,
                        "write-result-effect"),
        flush_operation(Device::endpoint, "flush-result-effect"),
        c3_effect,
        flush_operation(Device::local, "flush-local-c3-effect"),
        c4_effect,
        flush_operation(Device::local, "flush-local-c4-effect"),
        mark_operation("mark-good-effect-end"),
    }};

    Trace good_no_effect{"good-no-effect", {
        c2,
        flush_operation(Device::local, "flush-local-c2"),
        write_operation(Device::floor, 3U, canonical().floor_successor,
                        "write-floor-successor"),
        flush_operation(Device::floor, "flush-floor-successor"),
        write_operation(Device::endpoint, 5U, canonical().result_no_effect,
                        "write-result-no-effect"),
        flush_operation(Device::endpoint, "flush-result-no-effect"),
        c3_no,
        flush_operation(Device::local, "flush-local-c3-no-effect"),
        c4_no,
        flush_operation(Device::local, "flush-local-c4-no-effect"),
        mark_operation("mark-good-no-effect-end"),
    }};

    Trace bad_mark{"bad-mark-is-not-flush", {
        c2,
        mark_operation("mark-c2-without-flush"),
        write_operation(Device::floor, 3U, canonical().floor_successor,
                        "write-floor-successor"),
        flush_operation(Device::floor, "flush-floor-successor"),
        write_operation(Device::endpoint, 4U, canonical().effect,
                        "write-endpoint-effect"),
        flush_operation(Device::endpoint, "flush-endpoint-effect"),
        write_operation(Device::endpoint, 5U, canonical().result_effect,
                        "write-result-effect"),
        flush_operation(Device::endpoint, "flush-result-effect"),
        mark_operation("mark-bad-order-end"),
    }};

    Trace bad_result{"bad-result-after-local-completion", {
        c2,
        flush_operation(Device::local, "flush-local-c2"),
        write_operation(Device::floor, 3U, canonical().floor_successor,
                        "write-floor-successor"),
        flush_operation(Device::floor, "flush-floor-successor"),
        c3_no,
        flush_operation(Device::local,
                        "flush-local-c3-before-result"),
        mark_operation("mark-local-completion-without-result"),
        write_operation(Device::endpoint, 5U, canonical().result_no_effect,
                        "write-result-no-effect-late"),
        flush_operation(Device::endpoint, "flush-result-no-effect-late"),
        mark_operation("mark-late-result-end"),
    }};

    Trace bad_rollback{"bad-whole-image-rollback", {
        c2,
        flush_operation(Device::local, "flush-local-c2"),
        write_operation(Device::floor, 3U, canonical().floor_successor,
                        "write-floor-successor"),
        flush_operation(Device::floor, "flush-floor-successor"),
        write_operation(Device::endpoint, 4U, canonical().effect,
                        "write-endpoint-effect"),
        flush_operation(Device::endpoint, "flush-endpoint-effect"),
        write_operation(Device::endpoint, 5U, canonical().result_effect,
                        "write-result-effect"),
        flush_operation(Device::endpoint, "flush-result-effect"),
        c3_effect,
        flush_operation(Device::local, "flush-local-c3-effect"),
        c4_effect,
        flush_operation(Device::local, "flush-local-c4-effect"),
        journal_block_write(f.c1, 0U, "rollback-local-slot-0"),
        journal_block_write(f.c1, 1U, "rollback-local-slot-1"),
        flush_operation(Device::local, "flush-rollback-local-c1"),
        write_operation(Device::floor, 3U, canonical().floor_predecessor,
                        "rollback-floor-predecessor"),
        flush_operation(Device::floor, "flush-rollback-floor"),
        write_operation(Device::endpoint, 4U, canonical().zero,
                        "rollback-effect-absent"),
        write_operation(Device::endpoint, 5U, canonical().zero,
                        "rollback-result-absent"),
        flush_operation(Device::endpoint, "flush-rollback-endpoint"),
        mark_operation("mark-whole-image-rollback-end"),
    }};

    return {std::move(good_effect), std::move(good_no_effect),
            std::move(bad_mark), std::move(bad_result),
            std::move(bad_rollback)};
}

Classification classify_with_sealed_recovery(const Image& image) {
    const LocalClass local = sealed_local_class(image);
    const FloorClass floor = floor_class(image);
    const ResultClass result = result_class(image);
    const EffectClass effect = effect_class(image);
    if (get_block(image, 0U) != canonical().header) {
        return fail(local, floor, result, effect, "header mismatch");
    }
    if (local == LocalClass::invalid || floor == FloorClass::invalid
        || result == ResultClass::invalid || effect == EffectClass::invalid) {
        return fail(local, floor, result, effect, "malformed component");
    }
    if (local == LocalClass::c1) {
        if (floor == FloorClass::predecessor
            && result == ResultClass::absent
            && effect == EffectClass::absent) {
            return Classification{Outcome::uncertain, local_name(local),
                                  floor_name(floor), result_name(result), false,
                                  "C1 image alone cannot exclude whole-image rollback"};
        }
        return fail(local, floor, result, effect,
                    "endpoint or floor advanced without durable C2");
    }
    if (local == LocalClass::c2) {
        if (floor == FloorClass::predecessor
            && (result != ResultClass::absent
                || effect != EffectClass::absent)) {
            return fail(local, floor, result, effect,
                        "endpoint evidence precedes floor advancement");
        }
        if (result == ResultClass::absent) {
            return Classification{Outcome::uncertain, local_name(local),
                                  floor_name(floor), result_name(result),
                                  effect == EffectClass::present,
                                  "C2 without exact result remains uncertain"};
        }
        if (floor != FloorClass::successor) {
            return fail(local, floor, result, effect,
                        "exact result requires successor floor");
        }
        if (result == ResultClass::effect
            && effect == EffectClass::present) {
            return Classification{Outcome::effect, local_name(local),
                                  floor_name(floor), result_name(result), true,
                                  "exact endpoint result locates effect"};
        }
        if (result == ResultClass::no_effect
            && effect == EffectClass::absent) {
            return Classification{Outcome::no_effect, local_name(local),
                                  floor_name(floor), result_name(result), false,
                                  "exact endpoint result locates no-effect"};
        }
        return fail(local, floor, result, effect,
                    "endpoint result contradicts effect image");
    }
    if (floor != FloorClass::successor) {
        return fail(local, floor, result, effect,
                    "terminal local state requires successor floor");
    }
    if (is_no_effect_local(local)) {
        if (result == ResultClass::no_effect
            && effect == EffectClass::absent) {
            return Classification{Outcome::no_effect, local_name(local),
                                  floor_name(floor), result_name(result), false,
                                  "local narrowing is backed by exact result"};
        }
        return fail(local, floor, result, effect,
                    "local no-effect lacks matching result witness");
    }
    if (is_effect_local(local)) {
        if (result == ResultClass::effect
            && effect == EffectClass::present) {
            return Classification{Outcome::effect, local_name(local),
                                  floor_name(floor), result_name(result), true,
                                  "local effect is backed by exact result"};
        }
        return fail(local, floor, result, effect,
                    "local effect lacks matching result witness");
    }
    if (is_uncertain_local(local)) {
        if (result == ResultClass::absent) {
            return Classification{Outcome::uncertain, local_name(local),
                                  floor_name(floor), result_name(result),
                                  effect == EffectClass::present,
                                  "published uncertainty remains uncertainty"};
        }
        if (result == ResultClass::effect
            && effect == EffectClass::present) {
            return Classification{Outcome::effect, local_name(local),
                                  floor_name(floor), result_name(result), true,
                                  "later exact result narrows uncertainty"};
        }
        if (result == ResultClass::no_effect
            && effect == EffectClass::absent) {
            return Classification{Outcome::no_effect, local_name(local),
                                  floor_name(floor), result_name(result), false,
                                  "later exact result narrows uncertainty"};
        }
        return fail(local, floor, result, effect,
                    "uncertain local state conflicts with exact result");
    }
    return fail(local, floor, result, effect, "unclassified local phase");
}

Classification classify_with_exact_map(const Image& image) {
    const LocalClass local = exact_local_class(image);
    const Block header = get_block(image, 0U);
    const Block floor_block = get_block(image, 3U);
    const Block effect_block = get_block(image, 4U);
    const Block result_block = get_block(image, 5U);

    FloorClass floor = FloorClass::invalid;
    if (floor_block == canonical().floor_predecessor) {
        floor = FloorClass::predecessor;
    } else if (floor_block == canonical().floor_successor) {
        floor = FloorClass::successor;
    }
    ResultClass result = ResultClass::invalid;
    if (result_block == canonical().zero) {
        result = ResultClass::absent;
    } else if (result_block == canonical().result_no_effect) {
        result = ResultClass::no_effect;
    } else if (result_block == canonical().result_effect) {
        result = ResultClass::effect;
    }
    EffectClass effect = EffectClass::invalid;
    if (effect_block == canonical().zero) {
        effect = EffectClass::absent;
    } else if (effect_block == canonical().effect) {
        effect = EffectClass::present;
    }

    const auto make = [&](const Outcome out, std::string detail) {
        return Classification{out, local_name(local), floor_name(floor),
                              result_name(result),
                              effect == EffectClass::present,
                              std::move(detail)};
    };
    if (header != canonical().header || local == LocalClass::invalid
        || floor == FloorClass::invalid || result == ResultClass::invalid
        || effect == EffectClass::invalid) {
        return make(Outcome::fail_stop, "exact-map component mismatch");
    }
    if (local == LocalClass::c1) {
        return (floor == FloorClass::predecessor
                && result == ResultClass::absent
                && effect == EffectClass::absent)
            ? make(Outcome::uncertain,
                   "exact-map C1 cannot exclude whole-image rollback")
            : make(Outcome::fail_stop,
                   "exact-map C1 conflicts with advanced component");
    }
    if (local == LocalClass::c2) {
        if (floor == FloorClass::predecessor
            && (result != ResultClass::absent
                || effect != EffectClass::absent)) {
            return make(Outcome::fail_stop,
                        "exact-map endpoint precedes floor");
        }
        if (result == ResultClass::absent) {
            return make(Outcome::uncertain,
                        "exact-map C2 lacks result witness");
        }
        if (floor != FloorClass::successor) {
            return make(Outcome::fail_stop,
                        "exact-map result lacks successor floor");
        }
        if (result == ResultClass::effect
            && effect == EffectClass::present) {
            return make(Outcome::effect, "exact-map effect result agrees");
        }
        if (result == ResultClass::no_effect
            && effect == EffectClass::absent) {
            return make(Outcome::no_effect,
                        "exact-map no-effect result agrees");
        }
        return make(Outcome::fail_stop,
                    "exact-map endpoint result contradiction");
    }
    if (floor != FloorClass::successor) {
        return make(Outcome::fail_stop,
                    "exact-map terminal local lacks successor floor");
    }
    if (local == LocalClass::c3_no_effect
        || local == LocalClass::c4_no_effect) {
        return (result == ResultClass::no_effect
                && effect == EffectClass::absent)
            ? make(Outcome::no_effect,
                   "exact-map local no-effect has result witness")
            : make(Outcome::fail_stop,
                   "exact-map local no-effect missing result witness");
    }
    if (local == LocalClass::c3_effect
        || local == LocalClass::c4_effect) {
        return (result == ResultClass::effect
                && effect == EffectClass::present)
            ? make(Outcome::effect,
                   "exact-map local effect has result witness")
            : make(Outcome::fail_stop,
                   "exact-map local effect missing result witness");
    }
    if (local == LocalClass::c3_uncertain
        || local == LocalClass::c4_uncertain) {
        if (result == ResultClass::absent) {
            return make(Outcome::uncertain,
                        "exact-map uncertainty remains open");
        }
        if (result == ResultClass::effect
            && effect == EffectClass::present) {
            return make(Outcome::effect,
                        "exact-map late effect result narrows");
        }
        if (result == ResultClass::no_effect
            && effect == EffectClass::absent) {
            return make(Outcome::no_effect,
                        "exact-map late no-effect result narrows");
        }
        return make(Outcome::fail_stop,
                    "exact-map uncertain state conflicts with result");
    }
    return make(Outcome::fail_stop, "exact-map unclassified state");
}

bool read_image(const std::filesystem::path& path, Image& image,
                std::string& detail) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) {
        detail = "open image";
        return false;
    }
    stream.read(reinterpret_cast<char*>(image.data()),
                static_cast<std::streamsize>(image.size()));
    if (stream.gcount() != static_cast<std::streamsize>(image.size())) {
        detail = "wrong image size";
        return false;
    }
    char extra = 0;
    if (stream.get(extra)) {
        detail = "trailing image bytes";
        return false;
    }
    detail = "exact image";
    return true;
}

bool dump_schema(const std::filesystem::path& output, std::string& detail) {
    std::error_code ec;
    std::filesystem::remove_all(output, ec);
    ec.clear();
    std::filesystem::create_directories(output, ec);
    if (ec) {
        detail = "create schema: " + ec.message();
        return false;
    }
    const auto write = [&](const std::filesystem::path& name,
                           const auto& bytes) -> bool {
        std::ofstream stream(output / name,
                             std::ios::binary | std::ios::trunc);
        if (!stream) return false;
        stream.write(reinterpret_cast<const char*>(bytes.data()),
                     static_cast<std::streamsize>(bytes.size()));
        return stream.good();
    };
    const fence::Fixtures& f = fence::fixtures();
    if (!write("header.bin", canonical().header)
        || !write("floor-predecessor.bin", canonical().floor_predecessor)
        || !write("floor-successor.bin", canonical().floor_successor)
        || !write("endpoint-effect.bin", canonical().effect)
        || !write("result-no-effect.bin", canonical().result_no_effect)
        || !write("result-effect.bin", canonical().result_effect)
        || !write("zero.bin", canonical().zero)
        || !write("journal-c1.bin", f.c1)
        || !write("journal-c2.bin", f.c2)
        || !write("journal-c3-no-effect.bin", f.c3_no_effect)
        || !write("journal-c3-effect.bin", f.c3_effect)
        || !write("journal-c3-uncertain.bin", f.c3_uncertain)
        || !write("journal-c4-no-effect.bin", f.c4_no_effect)
        || !write("journal-c4-effect.bin", f.c4_effect)
        || !write("journal-c4-uncertain.bin", f.c4_uncertain)
        || !write("initial-image.bin", initial_image())) {
        detail = "write schema";
        return false;
    }
    detail = "bounded crash-image schema dumped";
    return true;
}

}  // namespace slopos::e0::crash_image
