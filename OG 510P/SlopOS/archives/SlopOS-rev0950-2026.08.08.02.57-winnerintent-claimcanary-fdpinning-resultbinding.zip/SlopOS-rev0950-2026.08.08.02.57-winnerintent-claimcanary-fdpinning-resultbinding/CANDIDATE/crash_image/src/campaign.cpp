#include "slopos/e0/crash_image/profile.hpp"

#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::crash_image {
namespace {

struct PendingWrite final {
    std::size_t block{0U};
    Block bytes{};
};

struct Simulator final {
    Image stable{};
    std::array<std::vector<PendingWrite>, 3U> pending{};
};

struct Record final {
    std::size_t id{0U};
    std::string trace{};
    std::size_t cut{0U};
    std::string operation{};
    OperationKind kind{OperationKind::mark};
    Device device{Device::local};
    std::array<std::size_t, 3U> pending{};
    std::array<std::uint64_t, 3U> masks{};
    std::size_t image_id{0U};
    std::uint64_t fnv1a64{0U};
    Classification sealed{};
    Classification exact{};
    std::string witness{};
};

[[nodiscard]] std::size_t device_index(const Device value) noexcept {
    switch (value) {
        case Device::local: return 0U;
        case Device::floor: return 1U;
        case Device::endpoint: return 2U;
    }
    return 0U;
}

void set_block(Image& image, const std::size_t block,
               const Block& bytes) noexcept {
    const std::size_t offset = block * kBlockSize;
    for (std::size_t i = 0U; i < kBlockSize; ++i) {
        image[offset + i] = bytes[i];
    }
}

void apply_operation(Simulator& simulator, const Operation& operation) {
    const std::size_t index = device_index(operation.device);
    switch (operation.kind) {
        case OperationKind::write:
            simulator.pending[index].push_back(
                PendingWrite{operation.block, operation.bytes});
            return;
        case OperationKind::flush:
            for (const PendingWrite& write : simulator.pending[index]) {
                set_block(simulator.stable, write.block, write.bytes);
            }
            simulator.pending[index].clear();
            return;
        case OperationKind::mark:
            return;
    }
}

[[nodiscard]] std::uint64_t subset_count(const std::size_t size) {
    if (size >= 63U) return 0U;
    return UINT64_C(1) << static_cast<unsigned int>(size);
}

[[nodiscard]] Image crash_image(
    const Simulator& simulator,
    const std::array<std::uint64_t, 3U>& masks) {
    Image image = simulator.stable;
    for (std::size_t device = 0U; device < simulator.pending.size(); ++device) {
        const auto& pending = simulator.pending[device];
        for (std::size_t i = 0U; i < pending.size(); ++i) {
            const std::uint64_t bit = UINT64_C(1)
                << static_cast<unsigned int>(i);
            if ((masks[device] & bit) != 0U) {
                set_block(image, pending[i].block, pending[i].bytes);
            }
        }
    }
    return image;
}

[[nodiscard]] std::uint64_t fnv1a64(const Image& image) noexcept {
    std::uint64_t value = UINT64_C(14695981039346656037);
    for (const std::uint8_t byte : image) {
        value ^= static_cast<std::uint64_t>(byte);
        value *= UINT64_C(1099511628211);
    }
    return value;
}

[[nodiscard]] std::string hex64(const std::uint64_t value) {
    std::ostringstream stream;
    stream << std::hex << std::setfill('0') << std::setw(16) << value;
    return stream.str();
}

[[nodiscard]] std::string image_name(const std::size_t id) {
    std::ostringstream stream;
    stream << "image-" << std::setfill('0') << std::setw(4) << id << ".bin";
    return stream.str();
}

[[nodiscard]] bool write_image(const std::filesystem::path& path,
                               const Image& image) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) return false;
    stream.write(reinterpret_cast<const char*>(image.data()),
                 static_cast<std::streamsize>(image.size()));
    return stream.good();
}

[[nodiscard]] std::string witness_for(const std::string& trace,
                                      const std::string& operation,
                                      const Classification& classification) {
    if (trace == "bad-mark-is-not-flush"
        && operation == "flush-result-effect"
        && classification.local == "C1"
        && classification.endpoint_result == "EFFECT"
        && classification.effect_present
        && classification.outcome == Outcome::fail_stop) {
        return "MARK_IS_NOT_FLUSH";
    }
    if (trace == "bad-result-after-local-completion"
        && operation == "flush-local-c3-before-result"
        && classification.local == "C3_NO_EFFECT"
        && classification.endpoint_result == "ABSENT"
        && classification.outcome == Outcome::fail_stop) {
        return "RESULT_MUST_PRECEDE_LOCAL_NARROWING";
    }
    if (trace == "bad-whole-image-rollback"
        && operation == "mark-whole-image-rollback-end"
        && classification.local == "C1"
        && classification.floor == "PREDECESSOR"
        && classification.endpoint_result == "ABSENT"
        && !classification.effect_present
        && classification.outcome == Outcome::uncertain) {
        return "ROLLBACK_IMAGE_COLLIDES_WITH_INITIAL";
    }
    return "";
}

[[nodiscard]] bool equivalent(const Classification& lhs,
                              const Classification& rhs) noexcept {
    return lhs.outcome == rhs.outcome && lhs.local == rhs.local
        && lhs.floor == rhs.floor
        && lhs.endpoint_result == rhs.endpoint_result
        && lhs.effect_present == rhs.effect_present;
}

void count_outcome(CampaignReport& report, const Outcome outcome) noexcept {
    switch (outcome) {
        case Outcome::effect: ++report.effect; return;
        case Outcome::no_effect: ++report.no_effect; return;
        case Outcome::uncertain: ++report.uncertain; return;
        case Outcome::fail_stop: ++report.fail_stop; return;
    }
}

[[nodiscard]] std::set<Image> images_for_cut(
    const std::vector<Record>& records,
    const std::map<std::size_t, Image>& by_id,
    const std::string& trace,
    const std::string& operation) {
    std::set<Image> result{};
    for (const Record& record : records) {
        if (record.trace == trace && record.operation == operation) {
            result.insert(by_id.at(record.image_id));
        }
    }
    return result;
}

}  // namespace

CampaignReport run_campaign(const std::filesystem::path& supplied_output) {
    CampaignReport report{};
    const std::filesystem::path output =
        std::filesystem::absolute(supplied_output);
    std::error_code ec;
    std::filesystem::remove_all(output, ec);
    ec.clear();
    std::filesystem::create_directories(output / "images", ec);
    if (ec) {
        report.detail = "create output: " + ec.message();
        return report;
    }
    std::string schema_detail;
    if (!dump_schema(output / "schema", schema_detail)) {
        report.detail = schema_detail;
        return report;
    }

    std::map<Image, std::size_t> image_ids{};
    std::map<std::size_t, Image> images_by_id{};
    std::vector<Record> records{};
    const auto intern = [&](const Image& image) -> std::size_t {
        const auto found = image_ids.find(image);
        if (found != image_ids.end()) return found->second;
        const std::size_t id = image_ids.size();
        image_ids.emplace(image, id);
        images_by_id.emplace(id, image);
        return id;
    };

    const std::vector<Trace> all_traces = traces();
    report.traces = all_traces.size();
    std::ofstream operations(output / "operations.tsv",
                             std::ios::binary | std::ios::trunc);
    if (!operations) {
        report.detail = "open operations table";
        return report;
    }
    operations << "trace\tindex\tkind\tdevice\tblock\tlabel\n";

    for (const Trace& trace : all_traces) {
        Simulator simulator{initial_image(), {}};
        std::size_t cut = 0U;
        const auto enumerate = [&](const std::string& label,
                                   const OperationKind kind,
                                   const Device device,
                                   const std::size_t current_cut) {
            const std::array<std::uint64_t, 3U> counts{{
                subset_count(simulator.pending[0].size()),
                subset_count(simulator.pending[1].size()),
                subset_count(simulator.pending[2].size()),
            }};
            for (std::uint64_t local = 0U; local < counts[0]; ++local) {
                for (std::uint64_t floor = 0U; floor < counts[1]; ++floor) {
                    for (std::uint64_t endpoint = 0U;
                         endpoint < counts[2]; ++endpoint) {
                        const std::array<std::uint64_t, 3U> masks{{
                            local, floor, endpoint}};
                        const Image image = crash_image(simulator, masks);
                        const Classification sealed =
                            classify_with_sealed_recovery(image);
                        const Classification exact =
                            classify_with_exact_map(image);
                        Record record{};
                        record.id = records.size();
                        record.trace = trace.name;
                        record.cut = current_cut;
                        record.operation = label;
                        record.kind = kind;
                        record.device = device;
                        record.pending = {{simulator.pending[0].size(),
                                           simulator.pending[1].size(),
                                           simulator.pending[2].size()}};
                        record.masks = masks;
                        record.image_id = intern(image);
                        record.fnv1a64 = fnv1a64(image);
                        record.sealed = sealed;
                        record.exact = exact;
                        record.witness = witness_for(trace.name, label, sealed);
                        records.push_back(std::move(record));
                    }
                }
            }
        };

        enumerate("START", OperationKind::mark, Device::local, cut);
        ++report.cuts;
        for (std::size_t index = 0U; index < trace.operations.size(); ++index) {
            const Operation& operation = trace.operations[index];
            operations << trace.name << '\t' << index << '\t'
                       << operation_name(operation.kind) << '\t'
                       << device_name(operation.device) << '\t'
                       << operation.block << '\t' << operation.label << '\n';
            apply_operation(simulator, operation);
            ++cut;
            enumerate(operation.label, operation.kind, operation.device, cut);
            ++report.cuts;
        }
    }
    if (!operations.good()) {
        report.detail = "write operations table";
        return report;
    }

    for (const auto& [id, image] : images_by_id) {
        if (!write_image(output / "images" / image_name(id), image)) {
            report.detail = "write image";
            return report;
        }
    }

    std::ofstream index(output / "index.tsv",
                        std::ios::binary | std::ios::trunc);
    if (!index) {
        report.detail = "open index";
        return report;
    }
    index << "record_id\ttrace\tcut\toperation\tkind\tdevice"
             "\tpending_local\tpending_floor\tpending_endpoint"
             "\tmask_local\tmask_floor\tmask_endpoint\timage"
             "\tfnv1a64\tclass_sealed\tclass_exact\tlocal\tfloor"
             "\tendpoint_result\teffect_present\twitness\n";

    for (const Record& record : records) {
        ++report.classifications;
        count_outcome(report, record.sealed.outcome);
        if (!equivalent(record.sealed, record.exact)) ++report.disagreements;
        if (record.sealed.local == "C2"
            && record.sealed.endpoint_result == "ABSENT"
            && record.sealed.outcome == Outcome::no_effect) {
            report.detail = "C2 absence narrowed to no-effect";
            return report;
        }
        if (record.witness == "MARK_IS_NOT_FLUSH") {
            report.mark_not_flush_witness = true;
        }
        if (record.witness == "RESULT_MUST_PRECEDE_LOCAL_NARROWING") {
            report.result_before_completion_witness = true;
        }
        if (record.witness == "ROLLBACK_IMAGE_COLLIDES_WITH_INITIAL") {
            report.rollback_image_collision_witness = true;
        }
        if (record.trace == "good-effect"
            && record.operation == "mark-good-effect-end"
            && record.sealed.outcome == Outcome::effect) {
            report.final_effect = true;
        }
        if (record.trace == "good-no-effect"
            && record.operation == "mark-good-no-effect-end"
            && record.sealed.outcome == Outcome::no_effect) {
            report.final_no_effect = true;
        }
        index << record.id << '\t' << record.trace << '\t' << record.cut
              << '\t' << record.operation << '\t'
              << operation_name(record.kind) << '\t'
              << device_name(record.device) << '\t'
              << record.pending[0] << '\t' << record.pending[1] << '\t'
              << record.pending[2] << '\t' << record.masks[0] << '\t'
              << record.masks[1] << '\t' << record.masks[2] << '\t'
              << image_name(record.image_id) << '\t'
              << hex64(record.fnv1a64) << '\t'
              << outcome_name(record.sealed.outcome) << '\t'
              << outcome_name(record.exact.outcome) << '\t'
              << record.sealed.local << '\t' << record.sealed.floor << '\t'
              << record.sealed.endpoint_result << '\t'
              << (record.sealed.effect_present ? 1 : 0) << '\t'
              << (record.witness.empty() ? "-" : record.witness) << '\n';
    }
    if (!index.good()) {
        report.detail = "write index";
        return report;
    }

    const std::set<Image> before_mark = images_for_cut(
        records, images_by_id, "bad-mark-is-not-flush", "write-c2-slot");
    const std::set<Image> after_mark = images_for_cut(
        records, images_by_id, "bad-mark-is-not-flush",
        "mark-c2-without-flush");
    report.mark_stutters = !before_mark.empty() && before_mark == after_mark;
    report.records = records.size();
    report.unique_images = image_ids.size();

    std::ofstream witnesses(output / "witnesses.tsv",
                            std::ios::binary | std::ios::trunc);
    if (!witnesses) {
        report.detail = "open witnesses";
        return report;
    }
    witnesses << "witness\ttrace\toperation\timage\tclassification\n";
    for (const Record& record : records) {
        if (!record.witness.empty()) {
            witnesses << record.witness << '\t' << record.trace << '\t'
                      << record.operation << '\t'
                      << image_name(record.image_id) << '\t'
                      << outcome_name(record.sealed.outcome) << '\n';
        }
    }
    if (!witnesses.good()) {
        report.detail = "write witnesses";
        return report;
    }

    report.ok = report.traces == 5U && report.disagreements == 0U
        && report.mark_stutters && report.mark_not_flush_witness
        && report.result_before_completion_witness
        && report.rollback_image_collision_witness && report.final_effect
        && report.final_no_effect && report.records > 0U
        && report.unique_images > 0U;
    report.detail = report.ok
        ? "bounded logical crash images preserve flush and result ordering"
        : "campaign invariant failure";

    std::ofstream summary(output / "summary.json",
                          std::ios::binary | std::ios::trunc);
    if (!summary) {
        report.ok = false;
        report.detail = "open summary";
        return report;
    }
    summary << "{\n"
            << "  \"schema\": \"slopos.rev0880.crash-image-summary.v1\",\n"
            << "  \"status\": \"" << (report.ok ? "PASS" : "FAIL")
            << "\",\n"
            << "  \"profile\": \"bounded-logical-flush-order-v1\",\n"
            << "  \"physical_power_loss_claim\": false,\n"
            << "  \"dm_log_writes_capture\": false,\n"
            << "  \"block_size\": " << kBlockSize << ",\n"
            << "  \"block_count\": " << kBlockCount << ",\n"
            << "  \"image_size\": " << kImageSize << ",\n"
            << "  \"traces\": " << report.traces << ",\n"
            << "  \"cuts\": " << report.cuts << ",\n"
            << "  \"records\": " << report.records << ",\n"
            << "  \"unique_images\": " << report.unique_images << ",\n"
            << "  \"classifications\": " << report.classifications
            << ",\n"
            << "  \"cross_reopener_disagreements\": "
            << report.disagreements << ",\n"
            << "  \"outcomes\": {\n"
            << "    \"EFFECT\": " << report.effect << ",\n"
            << "    \"NO_EFFECT\": " << report.no_effect << ",\n"
            << "    \"UNCERTAIN\": " << report.uncertain << ",\n"
            << "    \"FAIL_STOP\": " << report.fail_stop << "\n"
            << "  },\n"
            << "  \"mark_stutters\": "
            << (report.mark_stutters ? "true" : "false") << ",\n"
            << "  \"mark_not_flush_witness\": "
            << (report.mark_not_flush_witness ? "true" : "false") << ",\n"
            << "  \"result_before_completion_witness\": "
            << (report.result_before_completion_witness ? "true" : "false")
            << ",\n"
            << "  \"rollback_image_collision_witness\": "
            << (report.rollback_image_collision_witness ? "true" : "false")
            << ",\n"
            << "  \"final_effect\": "
            << (report.final_effect ? "true" : "false") << ",\n"
            << "  \"final_no_effect\": "
            << (report.final_no_effect ? "true" : "false") << "\n"
            << "}\n";
    if (!summary.good()) {
        report.ok = false;
        report.detail = "write summary";
    }
    return report;
}

}  // namespace slopos::e0::crash_image
