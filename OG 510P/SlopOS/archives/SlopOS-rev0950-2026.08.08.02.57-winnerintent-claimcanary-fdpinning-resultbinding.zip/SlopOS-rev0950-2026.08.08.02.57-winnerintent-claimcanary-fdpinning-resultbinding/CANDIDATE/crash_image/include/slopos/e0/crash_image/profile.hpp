#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::crash_image {

inline constexpr std::size_t kBlockSize = 512U;
inline constexpr std::size_t kBlockCount = 6U;
inline constexpr std::size_t kImageSize = kBlockSize * kBlockCount;

using Block = std::array<std::uint8_t, kBlockSize>;
using Image = std::array<std::uint8_t, kImageSize>;

enum class Device : std::uint8_t { local, floor, endpoint };
enum class OperationKind : std::uint8_t { write, flush, mark };
enum class Outcome : std::uint8_t { effect, no_effect, uncertain, fail_stop };

struct Operation final {
    OperationKind kind{OperationKind::mark};
    Device device{Device::local};
    std::size_t block{0U};
    Block bytes{};
    std::string label{};
};

struct Trace final {
    std::string name{};
    std::vector<Operation> operations{};
};

struct Classification final {
    Outcome outcome{Outcome::fail_stop};
    std::string local{};
    std::string floor{};
    std::string endpoint_result{};
    bool effect_present{false};
    std::string detail{};

    [[nodiscard]] friend bool operator==(
        const Classification&, const Classification&) = default;
};

struct CampaignReport final {
    bool ok{false};
    std::size_t traces{0U};
    std::size_t cuts{0U};
    std::size_t records{0U};
    std::size_t unique_images{0U};
    std::size_t classifications{0U};
    std::size_t disagreements{0U};
    std::size_t effect{0U};
    std::size_t no_effect{0U};
    std::size_t uncertain{0U};
    std::size_t fail_stop{0U};
    bool mark_stutters{false};
    bool mark_not_flush_witness{false};
    bool result_before_completion_witness{false};
    bool rollback_image_collision_witness{false};
    bool final_effect{false};
    bool final_no_effect{false};
    std::string detail{};
};

[[nodiscard]] std::string_view device_name(Device value) noexcept;
[[nodiscard]] std::string_view operation_name(OperationKind value) noexcept;
[[nodiscard]] std::string_view outcome_name(Outcome value) noexcept;
[[nodiscard]] Image initial_image();
[[nodiscard]] std::vector<Trace> traces();
[[nodiscard]] Classification classify_with_sealed_recovery(const Image& image);
[[nodiscard]] Classification classify_with_exact_map(const Image& image);
[[nodiscard]] CampaignReport run_campaign(const std::filesystem::path& output);
[[nodiscard]] bool dump_schema(const std::filesystem::path& output,
                               std::string& detail);
[[nodiscard]] bool read_image(const std::filesystem::path& path,
                              Image& image, std::string& detail);

}  // namespace slopos::e0::crash_image
