# License note

No project-wide SlopOS license or release authority has been constituted. This
candidate is retained for internal construction and review only. Exact imported
rev0874 files preserve source custody but are not relicensed by inclusion here.
Public distribution remains blocked on provenance, third-party notices, static
linkage review, owner authority, and an explicit project license.
