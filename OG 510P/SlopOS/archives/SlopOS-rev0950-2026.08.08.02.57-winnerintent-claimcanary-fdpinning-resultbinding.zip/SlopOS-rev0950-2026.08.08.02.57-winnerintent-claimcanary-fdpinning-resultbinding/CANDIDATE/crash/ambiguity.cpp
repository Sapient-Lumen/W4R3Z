#include "slopos/e0/fence/ambiguity.hpp"

#include <algorithm>
#include <array>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace slopos::e0::fence {
namespace {

enum class Marker { absent, exact, malformed };
enum class Endpoint { unavailable, exact_no_effect, exact_effect, malformed };
struct History final {
    const char* name;
    bool effect;
    Marker marker;
    Endpoint endpoint;
};

constexpr std::array<History, 8U> histories{{
    {"crash-before-dispatch", false, Marker::absent, Endpoint::unavailable},
    {"dispatch-entered-no-return-no-effect", false, Marker::absent,
     Endpoint::unavailable},
    {"effect-occurred-marker-not-stable", true, Marker::absent,
     Endpoint::unavailable},
    {"effect-occurred-marker-malformed", true, Marker::malformed,
     Endpoint::unavailable},
    {"effect-occurred-marker-exact", true, Marker::exact,
     Endpoint::unavailable},
    {"endpoint-exact-no-effect", false, Marker::absent,
     Endpoint::exact_no_effect},
    {"endpoint-exact-effect", true, Marker::absent, Endpoint::exact_effect},
    {"endpoint-malformed-after-effect", true, Marker::absent,
     Endpoint::malformed},
}};

[[nodiscard]] const char* name(const Marker value) noexcept {
    switch (value) {
        case Marker::absent: return "absent";
        case Marker::exact: return "exact";
        case Marker::malformed: return "malformed";
    }
    return "unknown";
}
[[nodiscard]] const char* name(const Endpoint value) noexcept {
    switch (value) {
        case Endpoint::unavailable: return "unavailable";
        case Endpoint::exact_no_effect: return "exact-no-effect";
        case Endpoint::exact_effect: return "exact-effect";
        case Endpoint::malformed: return "malformed";
    }
    return "unknown";
}
[[nodiscard]] std::string local_key(const History& h) {
    return std::string("c2|") + name(h.marker);
}
[[nodiscard]] std::string extended_key(const History& h) {
    return local_key(h) + "|" + name(h.endpoint);
}

}  // namespace

AmbiguityReport explore_observation_ambiguity(
    const std::string& table_path, const std::string& certificate_path) {
    AmbiguityReport report{};
    std::map<std::string, std::set<bool>> local;
    std::map<std::string, std::set<bool>> extended;
    for (const History& h : histories) {
        local[local_key(h)].insert(h.effect);
        extended[extended_key(h)].insert(h.effect);
    }
    report.hidden_histories = histories.size();
    report.local_observation_classes = local.size();
    for (const auto& [key, values] : local) {
        if (values.size() > 1U) {
            ++report.ambiguous_local_classes;
            if (report.witness.empty()) {
                std::vector<std::string> names;
                for (const History& h : histories) {
                    if (local_key(h) == key) names.emplace_back(h.name);
                }
                report.witness = key + " <- ";
                for (std::size_t i = 0; i < names.size(); ++i) {
                    if (i != 0U) report.witness += ",";
                    report.witness += names[i];
                }
            }
        }
    }
    for (const auto& [key, values] : extended) {
        (void)key;
        if (values.size() == 1U) ++report.exact_extended_classes;
    }

    if (!table_path.empty()) {
        std::ofstream out(table_path, std::ios::binary | std::ios::trunc);
        if (!out) {
            report.detail = "cannot open ambiguity table";
            return report;
        }
        out << "history\teffect_occurred\tdurable\tlocal_marker"
               "\tendpoint_result\tlocal_observation\textended_observation\n";
        for (const History& h : histories) {
            out << h.name << '\t' << (h.effect ? 1 : 0) << "\tc2\t"
                << name(h.marker) << '\t' << name(h.endpoint) << '\t'
                << local_key(h) << '\t' << extended_key(h) << '\n';
        }
        if (!out) {
            report.detail = "ambiguity table write failed";
            return report;
        }
    }

    report.ok = report.ambiguous_local_classes >= 1U
        && local["c2|absent"].size() == 2U;
    report.detail = report.ok
        ? "same retained C2 plus absent local marker admits effect and no-effect histories"
        : "required observational collision missing";

    if (!certificate_path.empty()) {
        std::ofstream out(certificate_path,
                          std::ios::binary | std::ios::trunc);
        if (!out) {
            report.ok = false;
            report.detail = "cannot open ambiguity certificate";
            return report;
        }
        out << "{\n"
            << "  \"schema\": \"slopos.rev0879.observation-ambiguity.v1\",\n"
            << "  \"status\": \"" << (report.ok ? "PASS" : "FAIL") << "\",\n"
            << "  \"hidden_histories\": " << report.hidden_histories << ",\n"
            << "  \"local_observation_classes\": "
            << report.local_observation_classes << ",\n"
            << "  \"ambiguous_local_classes\": "
            << report.ambiguous_local_classes << ",\n"
            << "  \"exact_extended_classes\": "
            << report.exact_extended_classes << ",\n"
            << "  \"witness\": \"" << report.witness << "\"\n"
            << "}\n";
    }
    return report;
}

}  // namespace slopos::e0::fence
