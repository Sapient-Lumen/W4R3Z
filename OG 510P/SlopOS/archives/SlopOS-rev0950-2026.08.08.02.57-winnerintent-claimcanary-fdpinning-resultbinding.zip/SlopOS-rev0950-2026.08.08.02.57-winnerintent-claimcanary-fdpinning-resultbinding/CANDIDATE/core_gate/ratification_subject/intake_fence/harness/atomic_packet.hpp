#pragma once

#include <filesystem>
#include <string_view>

namespace slopos::e0::core_gate::ratification_subject::intake_fence::harness {

// A namespace publication helper for campaign artifacts. It deliberately makes
// no stable-media or writer-authenticity claim: every file is closed in a
// same-directory staging tree, then the complete tree is exposed with one
// Linux RENAME_NOREPLACE operation.
class AtomicPacket final {
public:
    explicit AtomicPacket(std::filesystem::path final_path);
    ~AtomicPacket() noexcept;

    AtomicPacket(const AtomicPacket&) = delete;
    AtomicPacket& operator=(const AtomicPacket&) = delete;
    AtomicPacket(AtomicPacket&&) = delete;
    AtomicPacket& operator=(AtomicPacket&&) = delete;

    [[nodiscard]] std::filesystem::path artifact(std::string_view leaf) const;
    [[nodiscard]] const std::filesystem::path& staging_path() const noexcept;
    [[nodiscard]] const std::filesystem::path& final_path() const noexcept;

    // Commit is no-replace. A concurrent or pre-existing final path is an
    // error; it is never removed, replaced, or merged.
    void commit();

private:
    std::filesystem::path final_path_;
    std::filesystem::path staging_path_;
    bool committed_{false};
};

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence::harness
