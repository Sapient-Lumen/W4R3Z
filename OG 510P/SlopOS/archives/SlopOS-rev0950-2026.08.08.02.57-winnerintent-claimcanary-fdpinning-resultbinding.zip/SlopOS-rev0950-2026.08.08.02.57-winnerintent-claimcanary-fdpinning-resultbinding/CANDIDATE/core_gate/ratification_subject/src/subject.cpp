#include "slopos/e0/core_gate/ratification_subject/subject.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slopos::e0::core_gate::ratification_subject {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{{'S','L','O','P','R','A','T','1'}};
constexpr std::uint64_t kSchemaVersion = 1U;
constexpr std::string_view kCommitmentDomain = "SlopOS/e0/ratification-subject/v1";
constexpr std::array<std::uint32_t, 64U> kRound{{
    0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
    0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
    0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
    0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
    0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
    0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
    0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
    0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U,
}};

[[nodiscard]] constexpr std::uint32_t rotr(std::uint32_t value, unsigned int count) noexcept {
    return (value >> count) | (value << (32U - count));
}

class Sha256 final {
public:
    void update(const std::uint8_t* data, std::size_t size) noexcept {
        total_ += static_cast<std::uint64_t>(size);
        while (size != 0U) {
            const std::size_t take = std::min(size, block_.size() - used_);
            std::copy_n(data, take, block_.begin() + static_cast<std::ptrdiff_t>(used_));
            data += take;
            size -= take;
            used_ += take;
            if (used_ == block_.size()) {
                transform(block_);
                used_ = 0U;
            }
        }
    }

    [[nodiscard]] Digest finish() noexcept {
        const std::uint64_t bits = total_ * 8U;
        block_[used_++] = 0x80U;
        if (used_ > 56U) {
            std::fill(block_.begin() + static_cast<std::ptrdiff_t>(used_), block_.end(), 0U);
            transform(block_);
            used_ = 0U;
        }
        std::fill(block_.begin() + static_cast<std::ptrdiff_t>(used_), block_.begin() + 56, 0U);
        for (std::size_t index = 0U; index < 8U; ++index) {
            const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
            block_[56U + index] = static_cast<std::uint8_t>(bits >> shift);
        }
        transform(block_);
        Digest result{};
        for (std::size_t index = 0U; index < state_.size(); ++index) {
            result[index * 4U] = static_cast<std::uint8_t>(state_[index] >> 24U);
            result[index * 4U + 1U] = static_cast<std::uint8_t>(state_[index] >> 16U);
            result[index * 4U + 2U] = static_cast<std::uint8_t>(state_[index] >> 8U);
            result[index * 4U + 3U] = static_cast<std::uint8_t>(state_[index]);
        }
        return result;
    }

private:
    void transform(const std::array<std::uint8_t, 64U>& block) noexcept {
        std::array<std::uint32_t, 64U> words{};
        for (std::size_t index = 0U; index < 16U; ++index) {
            const std::size_t at = index * 4U;
            words[index] = (static_cast<std::uint32_t>(block[at]) << 24U)
                | (static_cast<std::uint32_t>(block[at + 1U]) << 16U)
                | (static_cast<std::uint32_t>(block[at + 2U]) << 8U)
                | static_cast<std::uint32_t>(block[at + 3U]);
        }
        for (std::size_t index = 16U; index < words.size(); ++index) {
            const std::uint32_t s0 = rotr(words[index - 15U], 7U)
                ^ rotr(words[index - 15U], 18U) ^ (words[index - 15U] >> 3U);
            const std::uint32_t s1 = rotr(words[index - 2U], 17U)
                ^ rotr(words[index - 2U], 19U) ^ (words[index - 2U] >> 10U);
            words[index] = words[index - 16U] + s0 + words[index - 7U] + s1;
        }
        std::uint32_t a = state_[0]; std::uint32_t b = state_[1];
        std::uint32_t c = state_[2]; std::uint32_t d = state_[3];
        std::uint32_t e = state_[4]; std::uint32_t f = state_[5];
        std::uint32_t g = state_[6]; std::uint32_t h = state_[7];
        for (std::size_t index = 0U; index < words.size(); ++index) {
            const std::uint32_t big1 = rotr(e, 6U) ^ rotr(e, 11U) ^ rotr(e, 25U);
            const std::uint32_t choose = (e & f) ^ ((~e) & g);
            const std::uint32_t temp1 = h + big1 + choose + kRound[index] + words[index];
            const std::uint32_t big0 = rotr(a, 2U) ^ rotr(a, 13U) ^ rotr(a, 22U);
            const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temp2 = big0 + majority;
            h = g; g = f; f = e; e = d + temp1;
            d = c; c = b; b = a; a = temp1 + temp2;
        }
        state_[0] += a; state_[1] += b; state_[2] += c; state_[3] += d;
        state_[4] += e; state_[5] += f; state_[6] += g; state_[7] += h;
    }

    std::array<std::uint32_t, 8U> state_{{
        0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,
        0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U,
    }};
    std::array<std::uint8_t, 64U> block_{};
    std::size_t used_{0U};
    std::uint64_t total_{0U};
};

template <std::size_t N>
class Writer final {
public:
    explicit Writer(std::array<std::uint8_t, N>& output) noexcept : output_(output) {}
    void byte(std::uint8_t value) noexcept { output_[cursor_++] = value; }
    void u16(std::uint16_t value) noexcept {
        byte(static_cast<std::uint8_t>(value >> 8U)); byte(static_cast<std::uint8_t>(value));
    }
    void u32(std::uint32_t value) noexcept {
        for (unsigned int shift : {24U,16U,8U,0U}) byte(static_cast<std::uint8_t>(value >> shift));
    }
    void u64(std::uint64_t value) noexcept {
        for (unsigned int shift : {56U,48U,40U,32U,24U,16U,8U,0U}) byte(static_cast<std::uint8_t>(value >> shift));
    }
    template <std::size_t M> void array(const std::array<std::uint8_t, M>& value) noexcept {
        for (std::uint8_t item : value) byte(item);
    }
    [[nodiscard]] std::size_t cursor() const noexcept { return cursor_; }
private:
    std::array<std::uint8_t, N>& output_;
    std::size_t cursor_{0U};
};

template <std::size_t N>
class Reader final {
public:
    explicit Reader(const std::array<std::uint8_t, N>& input) noexcept : input_(input) {}
    [[nodiscard]] std::uint8_t byte() noexcept { return input_[cursor_++]; }
    [[nodiscard]] std::uint16_t u16() noexcept {
        return static_cast<std::uint16_t>((static_cast<std::uint16_t>(byte()) << 8U) | byte());
    }
    [[nodiscard]] std::uint32_t u32() noexcept {
        std::uint32_t value = 0U; for (int i = 0; i < 4; ++i) value = (value << 8U) | byte(); return value;
    }
    [[nodiscard]] std::uint64_t u64() noexcept {
        std::uint64_t value = 0U; for (int i = 0; i < 8; ++i) value = (value << 8U) | byte(); return value;
    }
    template <std::size_t M> void array(std::array<std::uint8_t, M>& value) noexcept {
        for (std::uint8_t& item : value) item = byte();
    }
    [[nodiscard]] std::size_t cursor() const noexcept { return cursor_; }
private:
    const std::array<std::uint8_t, N>& input_;
    std::size_t cursor_{0U};
};

[[nodiscard]] std::array<const Digest*, binding_digest_count> digests(const Subject& s) noexcept {
    return {{
        &s.checkpoint_digest, &s.parent_checkpoint_digest, &s.trust_context_digest,
        &s.owner_constitution_digest, &s.owner_set_digest, &s.decision_domain_digest,
        &s.current_root_digest, &s.current_policy_digest, &s.encoding_profile_digest,
        &s.membrane_commitment, &s.dossier_commitment, &s.transaction_id_digest,
        &s.claim_digest, &s.effect_digest, &s.effect_target_digest,
        &s.spend_coordinate_digest, &s.retry_contract_digest, &s.terminal_query_digest,
        &s.independent_reopen_digest, &s.control_profile_digest,
        &s.reconfiguration_digest, &s.compromise_response_digest, &s.stop_rule_digest,
        &s.release_constitution_digest, &s.living_target_checkpoint_digest,
    }};
}

[[nodiscard]] std::array<Digest*, binding_digest_count> digests(Subject& s) noexcept {
    return {{
        &s.checkpoint_digest, &s.parent_checkpoint_digest, &s.trust_context_digest,
        &s.owner_constitution_digest, &s.owner_set_digest, &s.decision_domain_digest,
        &s.current_root_digest, &s.current_policy_digest, &s.encoding_profile_digest,
        &s.membrane_commitment, &s.dossier_commitment, &s.transaction_id_digest,
        &s.claim_digest, &s.effect_digest, &s.effect_target_digest,
        &s.spend_coordinate_digest, &s.retry_contract_digest, &s.terminal_query_digest,
        &s.independent_reopen_digest, &s.control_profile_digest,
        &s.reconfiguration_digest, &s.compromise_response_digest, &s.stop_rule_digest,
        &s.release_constitution_digest, &s.living_target_checkpoint_digest,
    }};
}

[[nodiscard]] bool requirement_valid(Requirement value) noexcept {
    return value == Requirement::must_separate || value == Requirement::may_share || value == Requirement::not_required;
}
[[nodiscard]] bool state_valid(ControlState value) noexcept {
    return value == ControlState::separate || value == ControlState::shared
        || value == ControlState::unknown || value == ControlState::not_applicable;
}
[[nodiscard]] bool all_zero(const Digest& value) noexcept { return cut0::is_zero(value); }

[[nodiscard]] Evaluation result(Status status, Fault fault, std::uint8_t axes,
                                std::uint8_t fields, const Digest& commitment) noexcept {
    return Evaluation{status, fault, axes, fields, commitment};
}

[[nodiscard]] Fault shape_fault(const Subject& s, std::uint8_t& axes) noexcept {
    if (s.owner_count == 0U) return Fault::owner_count_zero;
    if (s.owner_threshold == 0U || s.owner_threshold > s.owner_count) return Fault::owner_threshold_invalid;
    if (s.root_version == 0U || s.policy_version == 0U) return Fault::root_or_policy_version_zero;
    if (s.valid_from_sequence == 0U || s.valid_until_sequence < s.valid_from_sequence) return Fault::validity_interval_invalid;
    const auto values = digests(s);
    for (std::size_t index = 0U; index < 23U; ++index) {
        if (all_zero(*values[index])) return Fault::required_digest_zero;
    }
    if (s.consequence == Consequence::experimental) {
        if (!all_zero(s.release_constitution_digest) || !all_zero(s.living_target_checkpoint_digest))
            return Fault::experimental_release_target_nonzero;
    } else if (s.consequence == Consequence::living_transition_request) {
        if (all_zero(s.release_constitution_digest) || all_zero(s.living_target_checkpoint_digest))
            return Fault::living_transition_target_missing;
    } else {
        return Fault::consequence_invalid;
    }
    if (s.effect_class != EffectClass::harmless_monotonic) return Fault::effect_class_invalid;
    if (s.uncertainty_mode != UncertaintyMode::query_only) return Fault::uncertainty_mode_invalid;
    if (s.assertion_mask != 0U) return Fault::assertion_mask_nonzero;
    axes = 0U;
    for (const ControlDeclaration& control : s.controls) {
        if (!requirement_valid(control.requirement)) return Fault::control_requirement_invalid;
        if (!state_valid(control.state)) return Fault::control_state_invalid;
        const bool evidence = !all_zero(control.evidence_digest);
        if (control.requirement == Requirement::must_separate) {
            if (control.state != ControlState::separate || !evidence) return Fault::control_evidence_invalid;
        } else if (control.requirement == Requirement::may_share) {
            if ((control.state != ControlState::separate && control.state != ControlState::shared) || !evidence)
                return Fault::control_evidence_invalid;
        } else if (control.state != ControlState::not_applicable || evidence) {
            return Fault::control_evidence_invalid;
        }
        ++axes;
    }
    return Fault::none;
}

[[nodiscard]] bool expected_digest_zero(const ExpectedContext& e) noexcept {
    return all_zero(e.checkpoint_digest) || all_zero(e.parent_checkpoint_digest)
        || all_zero(e.trust_context_digest) || all_zero(e.owner_constitution_digest)
        || all_zero(e.owner_set_digest) || all_zero(e.decision_domain_digest)
        || all_zero(e.current_root_digest) || all_zero(e.current_policy_digest)
        || all_zero(e.encoding_profile_digest) || all_zero(e.membrane_commitment)
        || all_zero(e.dossier_commitment);
}

}  // namespace

SubjectImage encode_subject(const Subject& s) noexcept {
    SubjectImage image{};
    Writer<subject_image_size> w(image);
    w.array(kMagic); w.u64(kSchemaVersion); w.u16(s.owner_count); w.u16(s.owner_threshold); w.u32(0U);
    w.u64(s.root_version); w.u64(s.policy_version); w.u64(s.valid_from_sequence); w.u64(s.valid_until_sequence);
    for (const Digest* value : digests(s)) w.array(*value);
    for (const ControlDeclaration& control : s.controls) {
        w.byte(static_cast<std::uint8_t>(control.requirement));
        w.byte(static_cast<std::uint8_t>(control.state));
        w.u16(0U); w.array(control.evidence_digest);
    }
    w.byte(static_cast<std::uint8_t>(s.consequence));
    w.byte(static_cast<std::uint8_t>(s.effect_class));
    w.byte(static_cast<std::uint8_t>(s.uncertainty_mode));
    w.byte(s.assertion_mask); w.u32(0U);
    (void)w.cursor();
    return image;
}

bool decode_subject(const SubjectImage& image, Subject& s, Fault& fault) noexcept {
    Reader<subject_image_size> r(image);
    std::array<std::uint8_t, 8U> magic{}; r.array(magic);
    if (magic != kMagic) { fault = Fault::bad_magic; return false; }
    if (r.u64() != kSchemaVersion) { fault = Fault::bad_schema_version; return false; }
    s.owner_count = r.u16(); s.owner_threshold = r.u16();
    if (r.u32() != 0U) { fault = Fault::reserved_nonzero; return false; }
    s.root_version = r.u64(); s.policy_version = r.u64();
    s.valid_from_sequence = r.u64(); s.valid_until_sequence = r.u64();
    for (Digest* value : digests(s)) r.array(*value);
    for (ControlDeclaration& control : s.controls) {
        control.requirement = static_cast<Requirement>(r.byte());
        control.state = static_cast<ControlState>(r.byte());
        if (r.u16() != 0U) { fault = Fault::reserved_nonzero; return false; }
        r.array(control.evidence_digest);
    }
    s.consequence = static_cast<Consequence>(r.byte());
    s.effect_class = static_cast<EffectClass>(r.byte());
    s.uncertainty_mode = static_cast<UncertaintyMode>(r.byte());
    s.assertion_mask = r.byte();
    if (r.u32() != 0U || r.cursor() != subject_image_size) { fault = Fault::reserved_nonzero; return false; }
    for (const auto& control : s.controls) {
        if (!requirement_valid(control.requirement)) { fault = Fault::control_requirement_invalid; return false; }
        if (!state_valid(control.state)) { fault = Fault::control_state_invalid; return false; }
    }
    if (s.consequence != Consequence::experimental && s.consequence != Consequence::living_transition_request) {
        fault = Fault::consequence_invalid; return false;
    }
    if (s.effect_class != EffectClass::harmless_monotonic) { fault = Fault::effect_class_invalid; return false; }
    if (s.uncertainty_mode != UncertaintyMode::query_only) { fault = Fault::uncertainty_mode_invalid; return false; }
    fault = Fault::none;
    return true;
}

Digest image_commitment(const SubjectImage& image) noexcept {
    Sha256 hash;
    hash.update(reinterpret_cast<const std::uint8_t*>(kCommitmentDomain.data()), kCommitmentDomain.size());
    const std::uint8_t separator = 0U; hash.update(&separator, 1U);
    hash.update(image.data(), image.size());
    return hash.finish();
}

Digest subject_commitment(const Subject& subject) noexcept { return image_commitment(encode_subject(subject)); }

Evaluation evaluate(const Subject& s, const ExpectedContext& e) noexcept {
    const Digest commitment = subject_commitment(s);
    std::uint8_t axes = 0U;
    const Fault shape = shape_fault(s, axes);
    if (shape != Fault::none) {
        const Status status = (shape == Fault::control_requirement_invalid || shape == Fault::control_state_invalid
                               || shape == Fault::control_evidence_invalid)
            ? Status::control_vector_rejected : Status::subject_shape_rejected;
        return result(status, shape, axes, 0U, commitment);
    }
    if (s.consequence == Consequence::living_transition_request && !e.allow_living_transition)
        return result(Status::configured_context_mismatch, Fault::living_transition_not_allowed, axes, 0U, commitment);
    if (all_zero(e.expected_subject_commitment))
        return result(Status::configured_context_missing, Fault::expected_commitment_zero, axes, 0U, commitment);
    if (e.owner_count == 0U || e.owner_threshold == 0U || e.root_version == 0U || e.policy_version == 0U
        || e.maximum_validity_span == 0U || expected_digest_zero(e))
        return result(Status::configured_context_missing, Fault::expected_context_field_zero, axes, 0U, commitment);
    if (e.current_sequence < s.valid_from_sequence || e.current_sequence > s.valid_until_sequence)
        return result(Status::configured_context_mismatch, Fault::current_sequence_outside_interval, axes, 0U, commitment);
    if ((s.valid_until_sequence - s.valid_from_sequence) > e.maximum_validity_span)
        return result(Status::configured_context_mismatch, Fault::validity_span_exceeded, axes, 0U, commitment);
    const bool scalar_match = s.owner_count == e.owner_count && s.owner_threshold == e.owner_threshold
        && s.root_version == e.root_version && s.policy_version == e.policy_version;
    const bool digest_match = s.checkpoint_digest == e.checkpoint_digest
        && s.parent_checkpoint_digest == e.parent_checkpoint_digest
        && s.trust_context_digest == e.trust_context_digest
        && s.owner_constitution_digest == e.owner_constitution_digest
        && s.owner_set_digest == e.owner_set_digest
        && s.decision_domain_digest == e.decision_domain_digest
        && s.current_root_digest == e.current_root_digest
        && s.current_policy_digest == e.current_policy_digest
        && s.encoding_profile_digest == e.encoding_profile_digest
        && s.membrane_commitment == e.membrane_commitment
        && s.dossier_commitment == e.dossier_commitment;
    if (!scalar_match || !digest_match)
        return result(Status::configured_context_mismatch, Fault::expected_context_field_mismatch, axes, 0U, commitment);
    if (commitment != e.expected_subject_commitment)
        return result(Status::configured_context_mismatch, Fault::expected_commitment_mismatch, axes, 15U, commitment);
    return result(Status::configured_subject_bound, Fault::none, axes, 16U, commitment);
}

std::string_view axis_name(Axis value) noexcept {
    switch (value) {
        case Axis::governance: return "G"; case Axis::credentials: return "K";
        case Axis::storage: return "S"; case Axis::execution: return "E";
        case Axis::administration: return "A"; case Axis::recovery: return "R";
        case Axis::rollback: return "B"; case Axis::query: return "Q";
    }
    return "?";
}

std::string_view status_name(Status value) noexcept {
    switch (value) {
        case Status::subject_shape_rejected: return "subject_shape_rejected";
        case Status::control_vector_rejected: return "control_vector_rejected";
        case Status::configured_context_missing: return "configured_context_missing";
        case Status::configured_context_mismatch: return "configured_context_mismatch";
        case Status::configured_subject_bound: return "configured_subject_bound";
    }
    return "invalid";
}

std::string_view fault_name(Fault value) noexcept {
    switch (value) {
        case Fault::none: return "none"; case Fault::bad_magic: return "bad_magic";
        case Fault::bad_schema_version: return "bad_schema_version"; case Fault::reserved_nonzero: return "reserved_nonzero";
        case Fault::owner_count_zero: return "owner_count_zero"; case Fault::owner_threshold_invalid: return "owner_threshold_invalid";
        case Fault::root_or_policy_version_zero: return "root_or_policy_version_zero";
        case Fault::validity_interval_invalid: return "validity_interval_invalid";
        case Fault::validity_span_exceeded: return "validity_span_exceeded";
        case Fault::required_digest_zero: return "required_digest_zero";
        case Fault::experimental_release_target_nonzero: return "experimental_release_target_nonzero";
        case Fault::living_transition_target_missing: return "living_transition_target_missing";
        case Fault::consequence_invalid: return "consequence_invalid";
        case Fault::living_transition_not_allowed: return "living_transition_not_allowed";
        case Fault::effect_class_invalid: return "effect_class_invalid";
        case Fault::uncertainty_mode_invalid: return "uncertainty_mode_invalid";
        case Fault::assertion_mask_nonzero: return "assertion_mask_nonzero";
        case Fault::control_requirement_invalid: return "control_requirement_invalid";
        case Fault::control_state_invalid: return "control_state_invalid";
        case Fault::control_evidence_invalid: return "control_evidence_invalid";
        case Fault::expected_commitment_zero: return "expected_commitment_zero";
        case Fault::expected_context_field_zero: return "expected_context_field_zero";
        case Fault::expected_context_field_mismatch: return "expected_context_field_mismatch";
        case Fault::current_sequence_outside_interval: return "current_sequence_outside_interval";
        case Fault::expected_commitment_mismatch: return "expected_commitment_mismatch";
    }
    return "invalid";
}

static_assert(subject_image_size == 8U + 8U + 2U + 2U + 4U + 4U * 8U
    + binding_digest_count * 32U + control_axis_count * 36U + 8U);

}  // namespace slopos::e0::core_gate::ratification_subject
