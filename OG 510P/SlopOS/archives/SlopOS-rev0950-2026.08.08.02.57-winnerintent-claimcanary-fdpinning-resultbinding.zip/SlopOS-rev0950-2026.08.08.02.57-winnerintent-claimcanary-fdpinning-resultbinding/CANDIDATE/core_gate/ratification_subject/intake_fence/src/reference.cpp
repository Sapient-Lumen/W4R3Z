#include "slopos/e0/core_gate/ratification_subject/intake_fence/reference.hpp"

#include "slopos/e0/core_gate/ratification_subject/reference.hpp"

namespace slopos::e0::core_gate::ratification_subject::intake_fence::reference {

IntakeResult decode_exact(
    const std::span<const std::uint8_t> wire, Subject& subject) noexcept {
    if (wire.size() != subject_image_size) {
        return {false, IntakeFault::wrong_wire_length, Fault::none};
    }
    SubjectImage image{};
    for (std::size_t index = 0U; index < subject_image_size; ++index) {
        image[index] = wire[index];
    }
    Subject decoded{};
    Fault fault = Fault::none;
    if (!ratification_subject::reference::decode_subject(image, decoded, fault)) {
        return {false, IntakeFault::subject_decode_rejected, fault};
    }
    subject = decoded;
    return {true, IntakeFault::none, Fault::none};
}

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence::reference
