#include "slopos/e0/core_gate/ratification_subject/reference.hpp"
#include "slopos/e0/core_gate/ratification_subject/subject.hpp"

#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"
#include "slopos/e0/core_gate/nonpromotion_kernel_reference.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::core_gate::ratification_subject {
namespace {

namespace np = nonpromotion;

[[nodiscard]] Digest digest(std::uint8_t marker) {
    Digest value{}; value.fill(marker); return value;
}

[[nodiscard]] std::string hex(const Digest& value) {
    std::ostringstream stream;
    stream << std::hex << std::setfill('0');
    for (const std::uint8_t byte : value) stream << std::setw(2) << static_cast<unsigned int>(byte);
    return stream.str();
}

[[nodiscard]] constexpr std::string_view boolean(bool value) noexcept { return value ? "true" : "false"; }

[[nodiscard]] cut0::Packet complete_membrane() {
    cut0::Packet packet{};
    packet.subject = cut0::SubjectRecord{digest(1U), digest(2U), digest(3U), 931U};
    packet.evidence = cut0::EvidenceRecord{digest(4U), packet.subject.id, digest(5U), digest(6U)};
    packet.appraisal = cut0::AppraisalRecord{digest(7U), packet.subject.id, packet.evidence.id,
        packet.subject.appraisal_policy_digest, cut0::AppraisalVerdict::pass};
    packet.permit = cut0::PermitRecord{true, digest(8U), packet.subject.id, packet.appraisal.id,
        digest(9U), digest(10U), 1U};
    packet.terminal = cut0::TerminalRecord{true, digest(11U), packet.permit.id,
        packet.permit.effect_digest, digest(12U), cut0::TerminalClass::effect, 1U};
    packet.reopen = cut0::ReopenRecord{true, packet.terminal.id, packet.terminal.terminal_class,
        digest(13U), digest(14U), digest(15U)};
    return packet;
}

[[nodiscard]] np::Dossier complete_dossier() {
    np::Dossier dossier{}; dossier.membrane = complete_membrane();
    const Digest membrane = np::membrane_commitment(dossier.membrane);
    for (std::size_t index = 0U; index < np::edge_count; ++index) {
        dossier.external_records[index] = np::PremiseRecord{
            true, static_cast<np::Edge>(index), dossier.membrane.subject.id, membrane,
            digest(static_cast<std::uint8_t>(20U + index)),
            digest(static_cast<std::uint8_t>(40U + index)),
            static_cast<std::uint64_t>(index) + 1U};
    }
    return dossier;
}

[[nodiscard]] std::array<Digest*, binding_digest_count> subject_digests(Subject& s) noexcept {
    return {{&s.checkpoint_digest,&s.parent_checkpoint_digest,&s.trust_context_digest,
        &s.owner_constitution_digest,&s.owner_set_digest,&s.decision_domain_digest,
        &s.current_root_digest,&s.current_policy_digest,&s.encoding_profile_digest,
        &s.membrane_commitment,&s.dossier_commitment,&s.transaction_id_digest,
        &s.claim_digest,&s.effect_digest,&s.effect_target_digest,&s.spend_coordinate_digest,
        &s.retry_contract_digest,&s.terminal_query_digest,&s.independent_reopen_digest,
        &s.control_profile_digest,&s.reconfiguration_digest,&s.compromise_response_digest,
        &s.stop_rule_digest,&s.release_constitution_digest,&s.living_target_checkpoint_digest}};
}

[[nodiscard]] Subject baseline_subject(const Digest& membrane, const Digest& dossier) {
    Subject s{};
    s.owner_count = 5U; s.owner_threshold = 3U;
    s.root_version = 7U; s.policy_version = 11U;
    s.valid_from_sequence = 100U; s.valid_until_sequence = 140U;
    auto fields = subject_digests(s);
    for (std::size_t i = 0U; i < 23U; ++i)
        *fields[i] = digest(static_cast<std::uint8_t>(60U + i));
    s.membrane_commitment = membrane;
    s.dossier_commitment = dossier;
    s.release_constitution_digest = Digest{};
    s.living_target_checkpoint_digest = Digest{};
    for (std::size_t i = 0U; i < s.controls.size(); ++i) {
        s.controls[i].requirement = Requirement::must_separate;
        s.controls[i].state = ControlState::separate;
        s.controls[i].evidence_digest = digest(static_cast<std::uint8_t>(100U + i));
    }
    s.consequence = Consequence::experimental;
    s.effect_class = EffectClass::harmless_monotonic;
    s.uncertainty_mode = UncertaintyMode::query_only;
    s.assertion_mask = 0U;
    return s;
}

[[nodiscard]] ExpectedContext context_for(const Subject& s) {
    ExpectedContext e{};
    e.expected_subject_commitment = subject_commitment(s);
    e.checkpoint_digest = s.checkpoint_digest;
    e.parent_checkpoint_digest = s.parent_checkpoint_digest;
    e.trust_context_digest = s.trust_context_digest;
    e.owner_constitution_digest = s.owner_constitution_digest;
    e.owner_set_digest = s.owner_set_digest;
    e.decision_domain_digest = s.decision_domain_digest;
    e.current_root_digest = s.current_root_digest;
    e.current_policy_digest = s.current_policy_digest;
    e.encoding_profile_digest = s.encoding_profile_digest;
    e.membrane_commitment = s.membrane_commitment;
    e.dossier_commitment = s.dossier_commitment;
    e.owner_count = s.owner_count; e.owner_threshold = s.owner_threshold;
    e.root_version = s.root_version; e.policy_version = s.policy_version;
    e.current_sequence = s.valid_from_sequence + (s.valid_until_sequence - s.valid_from_sequence) / 2U;
    e.maximum_validity_span = 100U;
    e.allow_living_transition = s.consequence == Consequence::living_transition_request;
    return e;
}

struct Observed final { Evaluation candidate; Evaluation reference; };

[[nodiscard]] Observed observe(const Subject& s, const ExpectedContext& e) {
    const Evaluation candidate = evaluate(s, e);
    const Evaluation independent = reference::evaluate(s, e);
    if (!(candidate == independent)) throw std::runtime_error("candidate-reference-evaluation-disagreement");
    if (owner_ratification_proved(candidate) || effect_occurrence_proved(candidate)
        || independent_reopen_proved(candidate) || living_admission_proved(candidate)
        || configured_context_externality_proved(candidate) || authority_granted(candidate)
        || epoch_exit_proved(candidate))
        throw std::runtime_error("nonpromotion-invariant-broken");
    return Observed{candidate, independent};
}

class Tsv final {
public:
    Tsv(const std::filesystem::path& path, std::string_view header) : stream_(path) {
        if (!stream_) { throw std::runtime_error("open-output"); }
        stream_ << header << '\n';
    }
    template <typename... Args> void row(const Args&... args) {
        bool first = true;
        auto emit = [&](const auto& value) { if (!first) stream_ << '\t'; first = false; stream_ << value; };
        (emit(args), ...); stream_ << '\n'; ++rows_;
    }
    [[nodiscard]] std::size_t rows() const noexcept { return rows_; }
private:
    std::ofstream stream_;
    std::size_t rows_{0U};
};

void require(const Evaluation& observed, Status status, Fault fault, std::string_view name) {
    if (observed.status != status || observed.fault != fault)
        throw std::runtime_error(std::string("unexpected-") + std::string(name));
}

struct SubjectCase final {
    std::string name;
    std::function<void(Subject&, ExpectedContext&)> mutate;
    Status expected_status;
    Fault expected_fault;
};

[[nodiscard]] std::vector<SubjectCase> subject_cases() {
    std::vector<SubjectCase> result;
    result.push_back({"baseline", [](Subject&,ExpectedContext&){}, Status::configured_subject_bound, Fault::none});
    result.push_back({"owner_count_zero", [](Subject& s,ExpectedContext&){s.owner_count=0U;}, Status::subject_shape_rejected, Fault::owner_count_zero});
    result.push_back({"threshold_zero", [](Subject& s,ExpectedContext&){s.owner_threshold=0U;}, Status::subject_shape_rejected, Fault::owner_threshold_invalid});
    result.push_back({"threshold_over_count", [](Subject& s,ExpectedContext&){s.owner_threshold=6U;}, Status::subject_shape_rejected, Fault::owner_threshold_invalid});
    result.push_back({"root_version_zero", [](Subject& s,ExpectedContext&){s.root_version=0U;}, Status::subject_shape_rejected, Fault::root_or_policy_version_zero});
    result.push_back({"policy_version_zero", [](Subject& s,ExpectedContext&){s.policy_version=0U;}, Status::subject_shape_rejected, Fault::root_or_policy_version_zero});
    result.push_back({"valid_from_zero", [](Subject& s,ExpectedContext&){s.valid_from_sequence=0U;}, Status::subject_shape_rejected, Fault::validity_interval_invalid});
    result.push_back({"validity_reversed", [](Subject& s,ExpectedContext&){s.valid_until_sequence=99U;}, Status::subject_shape_rejected, Fault::validity_interval_invalid});
    for (std::size_t index = 0U; index < 23U; ++index) {
        result.push_back({"required_digest_zero_" + std::to_string(index), [index](Subject& s,ExpectedContext&){*subject_digests(s)[index]=Digest{};}, Status::subject_shape_rejected, Fault::required_digest_zero});
    }
    result.push_back({"experimental_release_nonzero", [](Subject& s,ExpectedContext&){s.release_constitution_digest=digest(230U);}, Status::subject_shape_rejected, Fault::experimental_release_target_nonzero});
    result.push_back({"experimental_target_nonzero", [](Subject& s,ExpectedContext&){s.living_target_checkpoint_digest=digest(231U);}, Status::subject_shape_rejected, Fault::experimental_release_target_nonzero});
    result.push_back({"living_targets_missing", [](Subject& s,ExpectedContext& e){s.consequence=Consequence::living_transition_request;e.allow_living_transition=true;}, Status::subject_shape_rejected, Fault::living_transition_target_missing});
    result.push_back({"living_release_only", [](Subject& s,ExpectedContext& e){s.consequence=Consequence::living_transition_request;s.release_constitution_digest=digest(232U);e.allow_living_transition=true;}, Status::subject_shape_rejected, Fault::living_transition_target_missing});
    result.push_back({"living_target_only", [](Subject& s,ExpectedContext& e){s.consequence=Consequence::living_transition_request;s.living_target_checkpoint_digest=digest(233U);e.allow_living_transition=true;}, Status::subject_shape_rejected, Fault::living_transition_target_missing});
    result.push_back({"living_not_allowed", [](Subject& s,ExpectedContext& e){s.consequence=Consequence::living_transition_request;s.release_constitution_digest=digest(232U);s.living_target_checkpoint_digest=digest(233U);e=context_for(s);e.allow_living_transition=false;}, Status::configured_context_mismatch, Fault::living_transition_not_allowed});
    result.push_back({"living_locally_configured", [](Subject& s,ExpectedContext& e){s.consequence=Consequence::living_transition_request;s.release_constitution_digest=digest(232U);s.living_target_checkpoint_digest=digest(233U);e=context_for(s);e.allow_living_transition=true;}, Status::configured_subject_bound, Fault::none});
    result.push_back({"consequence_invalid", [](Subject& s,ExpectedContext&){s.consequence=static_cast<Consequence>(9U);}, Status::subject_shape_rejected, Fault::consequence_invalid});
    result.push_back({"effect_class_invalid", [](Subject& s,ExpectedContext&){s.effect_class=static_cast<EffectClass>(9U);}, Status::subject_shape_rejected, Fault::effect_class_invalid});
    result.push_back({"uncertainty_invalid", [](Subject& s,ExpectedContext&){s.uncertainty_mode=static_cast<UncertaintyMode>(9U);}, Status::subject_shape_rejected, Fault::uncertainty_mode_invalid});
    for (std::uint8_t mask : std::array<std::uint8_t, 6U>{{1U,2U,4U,8U,16U,255U}})
        result.push_back({"assertion_mask_" + std::to_string(mask), [mask](Subject& s,ExpectedContext&){s.assertion_mask=mask;}, Status::subject_shape_rejected, Fault::assertion_mask_nonzero});
    return result;
}

struct ContextCase final {
    std::string name;
    std::function<void(Subject&, ExpectedContext&)> mutate;
    Status status;
    Fault fault;
};

[[nodiscard]] std::vector<ContextCase> context_cases() {
    std::vector<ContextCase> result;
    result.push_back({"expected_commitment_zero", [](Subject&,ExpectedContext& e){e.expected_subject_commitment=Digest{};}, Status::configured_context_missing, Fault::expected_commitment_zero});
    result.push_back({"expected_checkpoint_zero", [](Subject&,ExpectedContext& e){e.checkpoint_digest=Digest{};}, Status::configured_context_missing, Fault::expected_context_field_zero});
    result.push_back({"expected_owner_count_zero", [](Subject&,ExpectedContext& e){e.owner_count=0U;}, Status::configured_context_missing, Fault::expected_context_field_zero});
    result.push_back({"expected_threshold_zero", [](Subject&,ExpectedContext& e){e.owner_threshold=0U;}, Status::configured_context_missing, Fault::expected_context_field_zero});
    result.push_back({"expected_root_version_zero", [](Subject&,ExpectedContext& e){e.root_version=0U;}, Status::configured_context_missing, Fault::expected_context_field_zero});
    result.push_back({"expected_policy_version_zero", [](Subject&,ExpectedContext& e){e.policy_version=0U;}, Status::configured_context_missing, Fault::expected_context_field_zero});
    result.push_back({"expected_span_zero", [](Subject&,ExpectedContext& e){e.maximum_validity_span=0U;}, Status::configured_context_missing, Fault::expected_context_field_zero});
    result.push_back({"current_before", [](Subject& s,ExpectedContext& e){e.current_sequence=s.valid_from_sequence-1U;}, Status::configured_context_mismatch, Fault::current_sequence_outside_interval});
    result.push_back({"current_after", [](Subject& s,ExpectedContext& e){e.current_sequence=s.valid_until_sequence+1U;}, Status::configured_context_mismatch, Fault::current_sequence_outside_interval});
    result.push_back({"span_exceeded", [](Subject&,ExpectedContext& e){e.maximum_validity_span=39U;}, Status::configured_context_mismatch, Fault::validity_span_exceeded});
    result.push_back({"owner_count_mismatch", [](Subject&,ExpectedContext& e){e.owner_count=6U;}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"threshold_mismatch", [](Subject&,ExpectedContext& e){e.owner_threshold=2U;}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"root_version_mismatch", [](Subject&,ExpectedContext& e){e.root_version=8U;}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"policy_version_mismatch", [](Subject&,ExpectedContext& e){e.policy_version=12U;}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"checkpoint_mismatch", [](Subject&,ExpectedContext& e){e.checkpoint_digest=digest(240U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"parent_mismatch", [](Subject&,ExpectedContext& e){e.parent_checkpoint_digest=digest(241U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"trust_context_mismatch", [](Subject&,ExpectedContext& e){e.trust_context_digest=digest(242U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"owner_constitution_mismatch", [](Subject&,ExpectedContext& e){e.owner_constitution_digest=digest(243U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"owner_set_mismatch", [](Subject&,ExpectedContext& e){e.owner_set_digest=digest(244U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"decision_domain_mismatch", [](Subject&,ExpectedContext& e){e.decision_domain_digest=digest(245U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"current_root_mismatch", [](Subject&,ExpectedContext& e){e.current_root_digest=digest(246U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"current_policy_mismatch", [](Subject&,ExpectedContext& e){e.current_policy_digest=digest(247U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"encoding_profile_mismatch", [](Subject&,ExpectedContext& e){e.encoding_profile_digest=digest(248U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"membrane_mismatch", [](Subject&,ExpectedContext& e){e.membrane_commitment=digest(249U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"dossier_mismatch", [](Subject&,ExpectedContext& e){e.dossier_commitment=digest(250U);}, Status::configured_context_mismatch, Fault::expected_context_field_mismatch});
    result.push_back({"whole_subject_commitment_mismatch", [](Subject& s,ExpectedContext&){s.claim_digest=digest(251U);}, Status::configured_context_mismatch, Fault::expected_commitment_mismatch});
    return result;
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);
    const np::Dossier dossier = complete_dossier();
    const Digest membrane_candidate = np::membrane_commitment(dossier.membrane);
    const Digest membrane_reference = np::reference::membrane_commitment(dossier.membrane);
    const Digest dossier_candidate = np::dossier_commitment(dossier);
    const Digest dossier_reference = np::reference::dossier_commitment(dossier);
    if (membrane_candidate != membrane_reference || dossier_candidate != dossier_reference)
        throw std::runtime_error("upstream-v2-commitment-disagreement");
    const Subject baseline = baseline_subject(membrane_candidate, dossier_candidate);
    const ExpectedContext baseline_context = context_for(baseline);
    if (encode_subject(baseline) != reference::encode_subject(baseline)
        || subject_commitment(baseline) != reference::subject_commitment(baseline))
        throw std::runtime_error("baseline-encoding-disagreement");

    Tsv curated(output / "curated.tsv",
        "case\texpected_status\texpected_fault\tcandidate_status\tcandidate_fault\treference_status\treference_fault\tbound_axes\tconfigured_fields\towner_ratification_proved\teffect_occurrence_proved\tindependent_reopen_proved\tliving_admission_proved\tconfigured_context_externality_proved\tauthority_granted\tepoch_exit_proved");
    for (const SubjectCase& item : subject_cases()) {
        Subject s = baseline; ExpectedContext e = baseline_context; item.mutate(s,e);
        if (item.name != "living_not_allowed" && item.name != "living_locally_configured") {
            const Digest before = e.expected_subject_commitment;
            if (item.expected_status == Status::configured_subject_bound && subject_commitment(s) != before) e = context_for(s);
        }
        const Observed o = observe(s,e); require(o.candidate,item.expected_status,item.expected_fault,item.name);
        curated.row(item.name,status_name(item.expected_status),fault_name(item.expected_fault),
            status_name(o.candidate.status),fault_name(o.candidate.fault),status_name(o.reference.status),fault_name(o.reference.fault),
            static_cast<unsigned int>(o.candidate.bound_control_axes),static_cast<unsigned int>(o.candidate.configured_fields_bound),
            "false","false","false","false","false","false","false");
    }

    Tsv controls(output / "control-masks.tsv",
        "mask\tmust_separate_axes\tnot_required_axes\tcandidate_status\treference_status\tbound_axes\tauthority_granted\tepoch_exit_proved");
    for (std::uint16_t mask = 0U; mask < 256U; ++mask) {
        Subject s = baseline; unsigned int separated = 0U;
        for (std::size_t axis = 0U; axis < s.controls.size(); ++axis) {
            if ((mask & static_cast<std::uint16_t>(1U << axis)) != 0U) {
                s.controls[axis].requirement=Requirement::must_separate;
                s.controls[axis].state=ControlState::separate;
                s.controls[axis].evidence_digest=digest(static_cast<std::uint8_t>(100U+axis)); ++separated;
            } else {
                s.controls[axis].requirement=Requirement::not_required;
                s.controls[axis].state=ControlState::not_applicable;
                s.controls[axis].evidence_digest=Digest{};
            }
        }
        const ExpectedContext e=context_for(s); const Observed o=observe(s,e);
        require(o.candidate,Status::configured_subject_bound,Fault::none,"control-mask");
        controls.row(mask,separated,8U-separated,status_name(o.candidate.status),status_name(o.reference.status),
            static_cast<unsigned int>(o.candidate.bound_control_axes),"false","false");
    }

    Tsv control_faults(output / "control-faults.tsv",
        "axis\tmutation\tcandidate_status\tcandidate_fault\treference_status\treference_fault\tauthority_granted\tepoch_exit_proved");
    struct FaultMutation { std::string_view name; std::function<void(ControlDeclaration&)> apply; };
    const std::vector<FaultMutation> faults{
        {"invalid_requirement",[](ControlDeclaration& c){c.requirement=static_cast<Requirement>(9U);}},
        {"invalid_state",[](ControlDeclaration& c){c.state=static_cast<ControlState>(9U);}},
        {"must_shared",[](ControlDeclaration& c){c.requirement=Requirement::must_separate;c.state=ControlState::shared;}},
        {"must_unknown",[](ControlDeclaration& c){c.requirement=Requirement::must_separate;c.state=ControlState::unknown;}},
        {"must_not_applicable",[](ControlDeclaration& c){c.requirement=Requirement::must_separate;c.state=ControlState::not_applicable;}},
        {"must_zero_evidence",[](ControlDeclaration& c){c.requirement=Requirement::must_separate;c.state=ControlState::separate;c.evidence_digest=Digest{};}},
        {"may_unknown",[](ControlDeclaration& c){c.requirement=Requirement::may_share;c.state=ControlState::unknown;}},
        {"may_not_applicable",[](ControlDeclaration& c){c.requirement=Requirement::may_share;c.state=ControlState::not_applicable;}},
        {"may_zero_evidence",[](ControlDeclaration& c){c.requirement=Requirement::may_share;c.state=ControlState::shared;c.evidence_digest=Digest{};}},
        {"not_required_separate",[](ControlDeclaration& c){c.requirement=Requirement::not_required;c.state=ControlState::separate;c.evidence_digest=Digest{};}},
        {"not_required_shared",[](ControlDeclaration& c){c.requirement=Requirement::not_required;c.state=ControlState::shared;c.evidence_digest=Digest{};}},
        {"not_required_unknown",[](ControlDeclaration& c){c.requirement=Requirement::not_required;c.state=ControlState::unknown;c.evidence_digest=Digest{};}},
        {"not_required_nonzero",[](ControlDeclaration& c){c.requirement=Requirement::not_required;c.state=ControlState::not_applicable;c.evidence_digest=digest(220U);}},
    };
    for (std::size_t axis=0U;axis<control_axis_count;++axis) {
        for (const FaultMutation& mutation:faults) {
            Subject s=baseline; mutation.apply(s.controls[axis]); const ExpectedContext e=context_for(s); const Observed o=observe(s,e);
            const Fault expected = mutation.name=="invalid_requirement" ? Fault::control_requirement_invalid
                : mutation.name=="invalid_state" ? Fault::control_state_invalid : Fault::control_evidence_invalid;
            require(o.candidate,Status::control_vector_rejected,expected,"control-fault");
            control_faults.row(axis_name(static_cast<Axis>(axis)),mutation.name,status_name(o.candidate.status),fault_name(o.candidate.fault),
                status_name(o.reference.status),fault_name(o.reference.fault),"false","false");
        }
    }

    Tsv contexts(output / "context-substitution.tsv",
        "case\texpected_status\texpected_fault\tcandidate_status\tcandidate_fault\treference_status\treference_fault\tauthority_granted\tepoch_exit_proved");
    for(const ContextCase& item:context_cases()) {
        Subject s=baseline;ExpectedContext e=baseline_context;item.mutate(s,e);const Observed o=observe(s,e);
        require(o.candidate,item.status,item.fault,item.name);
        contexts.row(item.name,status_name(item.status),fault_name(item.fault),status_name(o.candidate.status),fault_name(o.candidate.fault),
            status_name(o.reference.status),fault_name(o.reference.fault),"false","false");
    }

    Tsv flips(output / "bit-flips.tsv",
        "offset\tbit\tcandidate_decode\treference_decode\tdecode_fault\tevaluation_status\tevaluation_fault\tcommitment_changed\tcandidate_reference_commitment_equal\tauthority_granted\tepoch_exit_proved");
    const SubjectImage baseline_image=encode_subject(baseline); const Digest baseline_commitment=image_commitment(baseline_image);
    for(std::size_t offset=0U;offset<baseline_image.size();++offset) {
      for(std::uint8_t bit=0U;bit<8U;++bit) {
        SubjectImage mutated=baseline_image;mutated[offset]^=static_cast<std::uint8_t>(1U << bit);
        const Digest cc=image_commitment(mutated);const Digest rc=reference::image_commitment(mutated);
        if(cc!=rc||cc==baseline_commitment) throw std::runtime_error("byte-flip-commitment");
        Subject cs{},rs{};Fault cf=Fault::none,rf=Fault::none;
        const bool cd=decode_subject(mutated,cs,cf);const bool rd=reference::decode_subject(mutated,rs,rf);
        if(cd!=rd||cf!=rf) throw std::runtime_error("byte-flip-decode-disagreement");
        Status observed_status=Status::subject_shape_rejected;Fault observed_fault=cf;
        if(cd) {
            if(encode_subject(cs)!=mutated||reference::encode_subject(rs)!=mutated) throw std::runtime_error("decode-noncanonical");
            const Observed o=observe(cs,baseline_context);observed_status=o.candidate.status;observed_fault=o.candidate.fault;
            if(observed_status==Status::configured_subject_bound) throw std::runtime_error("byte-flip-promoted");
        }
        flips.row(offset,static_cast<unsigned int>(bit),boolean(cd),boolean(rd),fault_name(cf),status_name(observed_status),fault_name(observed_fault),
            "true","true","false","false");
      }
    }

    Tsv self(output / "self-selection.tsv",
        "world\tcontext_origin\tcandidate_status\treference_status\tconfigured_context_externality_proved\towner_ratification_proved\tauthority_granted\tepoch_exit_proved");
    Subject shifted=baseline;shifted.current_policy_digest=digest(240U);shifted.claim_digest=digest(241U);
    const Observed fixed=observe(shifted,baseline_context);require(fixed.candidate,Status::configured_context_mismatch,Fault::expected_context_field_mismatch,"fixed-world");
    self.row("fixed_context","preconfigured_baseline",status_name(fixed.candidate.status),status_name(fixed.reference.status),"false","false","false","false");
    ExpectedContext self_selected=context_for(shifted);const Observed selected=observe(shifted,self_selected);
    require(selected.candidate,Status::configured_subject_bound,Fault::none,"self-selected-world");
    self.row("self_selected_context","derived_from_same_mutated_subject",status_name(selected.candidate.status),status_name(selected.reference.status),"false","false","false","false");

    {
        std::ofstream binary(output / "subject.bin",std::ios::binary);
        binary.write(reinterpret_cast<const char*>(baseline_image.data()),static_cast<std::streamsize>(baseline_image.size()));
    }
    {
        std::ofstream json(output / "subject.json");
        json << "{\n"
             << "  \"schema\": \"slopos.rev0932.configured-ratification-subject.v1\",\n"
             << "  \"status\": \"PASS\",\n"
             << "  \"subject_bytes\": " << subject_image_size << ",\n"
             << "  \"subject_commitment\": \"" << hex(baseline_commitment) << "\",\n"
             << "  \"membrane_commitment\": \"" << hex(membrane_candidate) << "\",\n"
             << "  \"dossier_commitment\": \"" << hex(dossier_candidate) << "\",\n"
             << "  \"owner_count\": 5,\n  \"owner_threshold\": 3,\n"
             << "  \"root_version\": 7,\n  \"policy_version\": 11,\n"
             << "  \"valid_from_sequence\": 100,\n  \"valid_until_sequence\": 140,\n"
             << "  \"consequence\": \"experimental\",\n"
             << "  \"highest_local_status\": \"configured_subject_bound\",\n"
             << "  \"configured_context_externality_proved\": false,\n"
             << "  \"owner_ratification_proved\": false,\n"
             << "  \"effect_occurrence_proved\": false,\n"
             << "  \"independent_reopen_proved\": false,\n"
             << "  \"living_admission_proved\": false,\n"
             << "  \"authority_granted\": false,\n"
             << "  \"epoch_exit_proved\": false\n}\n";
    }
    {
        const std::size_t total=curated.rows()+controls.rows()+control_faults.rows()+contexts.rows()+flips.rows()+self.rows();
        std::ofstream json(output / "summary.json");
        json << "{\n"
             << "  \"schema\": \"slopos.rev0932.configured-ratification-subject-campaign.v1\",\n"
             << "  \"status\": \"PASS\",\n"
             << "  \"subject_bytes\": " << subject_image_size << ",\n"
             << "  \"binding_digests\": " << binding_digest_count << ",\n"
             << "  \"control_axes\": " << control_axis_count << ",\n"
             << "  \"curated_cases\": " << curated.rows() << ",\n"
             << "  \"control_masks\": " << controls.rows() << ",\n"
             << "  \"control_fault_cases\": " << control_faults.rows() << ",\n"
             << "  \"context_substitution_cases\": " << contexts.rows() << ",\n"
             << "  \"bit_flip_cases\": " << flips.rows() << ",\n"
             << "  \"self_selection_worlds\": " << self.rows() << ",\n"
             << "  \"total_cases\": " << total << ",\n"
             << "  \"candidate_reference_disagreements\": 0,\n"
             << "  \"exact_v2_membrane_bound\": true,\n"
             << "  \"exact_v2_dossier_bound\": true,\n"
             << "  \"all_single_bit_mutations_rejected_by_fixed_context\": true,\n"
             << "  \"self_selected_context_can_match_locally\": true,\n"
             << "  \"self_selected_context_proves_externality\": false,\n"
             << "  \"highest_local_status\": \"configured_subject_bound\",\n"
             << "  \"owner_ratification_proved\": false,\n"
             << "  \"authority_granted\": false,\n"
             << "  \"epoch_exit_proved\": false\n}\n";
    }
    std::cout << "CONFIGURED_RATIFICATION_SUBJECT_CAMPAIGN=PASS subject_bytes=" << subject_image_size
              << " curated=" << curated.rows() << " masks=" << controls.rows()
              << " control_faults=" << control_faults.rows() << " contexts=" << contexts.rows()
              << " bit_flips=" << flips.rows() << " self_selection=" << self.rows()
              << " authority=false epoch_exit=false\n";
    return 0;
}

}  // namespace slopos::e0::core_gate::ratification_subject
