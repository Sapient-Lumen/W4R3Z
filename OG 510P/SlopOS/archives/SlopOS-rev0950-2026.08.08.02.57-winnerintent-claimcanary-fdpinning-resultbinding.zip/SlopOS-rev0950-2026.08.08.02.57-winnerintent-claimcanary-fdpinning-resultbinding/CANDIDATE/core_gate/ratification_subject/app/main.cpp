#include <filesystem>
#include <iostream>
#include <string_view>

namespace slopos::e0::core_gate::ratification_subject {
int run_campaign(const std::filesystem::path& output);
}

int main(int argc, char** argv) {
    if (argc != 3 || std::string_view(argv[1]) != "campaign") {
        std::cerr << "usage: slopos_configured_ratification_subject campaign OUTPUT\n";
        return 64;
    }
    try {
        return slopos::e0::core_gate::ratification_subject::run_campaign(argv[2]);
    } catch (const std::exception& error) {
        std::cerr << "CONFIGURED_RATIFICATION_SUBJECT_CAMPAIGN=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
