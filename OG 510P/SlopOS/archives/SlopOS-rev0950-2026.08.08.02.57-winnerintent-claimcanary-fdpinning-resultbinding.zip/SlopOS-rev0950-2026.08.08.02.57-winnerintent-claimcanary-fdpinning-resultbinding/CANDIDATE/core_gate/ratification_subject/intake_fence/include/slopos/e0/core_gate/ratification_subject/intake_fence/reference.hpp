#pragma once

#include "slopos/e0/core_gate/ratification_subject/intake_fence/intake.hpp"

namespace slopos::e0::core_gate::ratification_subject::intake_fence::reference {

[[nodiscard]] IntakeResult decode_exact(
    std::span<const std::uint8_t> wire, Subject& subject) noexcept;

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence::reference
