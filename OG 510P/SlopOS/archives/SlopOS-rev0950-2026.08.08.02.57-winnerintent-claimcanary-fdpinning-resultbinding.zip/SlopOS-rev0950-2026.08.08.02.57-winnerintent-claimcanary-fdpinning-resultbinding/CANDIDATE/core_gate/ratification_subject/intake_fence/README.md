# Ratification Subject Intake Fence

This nested C++20 proof retains the exact 1,152-byte intake and commit-on-success
semantics from rev0933. Rev0934 changes only the campaign harness publication
boundary: four result artifacts are closed in a sibling stage and exposed as a
complete final directory through Linux `renameat2(RENAME_NOREPLACE)`.

Build directly with CMake. The executable supports:

```sh
slopos_ratification_subject_intake_fence campaign SUBJECT_BIN ABSENT_OUTPUT
slopos_ratification_subject_intake_fence crash-after SUBJECT_BIN ABSENT_OUTPUT 1
slopos_ratification_subject_intake_fence collision-before-commit SUBJECT_BIN ABSENT_OUTPUT
```

The retained rev0933 semantic evidence remains immutable. Rev0934 evidence
proves seven publication cuts and stores no second copy of the four large
semantic payloads. Namespace atomicity is not stable-media durability, owner
ratification, or authority.
