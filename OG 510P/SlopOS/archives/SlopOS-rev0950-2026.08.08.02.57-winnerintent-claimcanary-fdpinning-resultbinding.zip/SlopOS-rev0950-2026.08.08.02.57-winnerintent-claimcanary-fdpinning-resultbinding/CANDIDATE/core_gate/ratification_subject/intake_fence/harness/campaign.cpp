#include "harness/campaign.hpp"

#include "harness/atomic_packet.hpp"
#include "slopos/e0/core_gate/ratification_subject/intake_fence/intake.hpp"
#include "slopos/e0/core_gate/ratification_subject/intake_fence/reference.hpp"
#include "slopos/e0/core_gate/ratification_subject/reference.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::core_gate::ratification_subject::intake_fence {
namespace {

constexpr std::array<std::string_view, 4> artifact_names{
    "exact-baseline.tsv",
    "length-fence.tsv",
    "bit-flip-atomicity.tsv",
    "summary.json",
};

std::vector<std::uint8_t> read_bytes(const std::filesystem::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        throw std::runtime_error("open-subject");
    }
    return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) {
        throw std::runtime_error("open-output");
    }
    out << text;
    out.flush();
    if (!out) {
        throw std::runtime_error("write-output");
    }
}

Subject sentinel() {
    Subject subject{};
    subject.owner_count = 0x1357U;
    subject.owner_threshold = 0x2468U;
    subject.root_version = 0x0102030405060708ULL;
    subject.policy_version = 0x1112131415161718ULL;
    subject.assertion_mask = 0xa5U;
    subject.checkpoint_digest.fill(0x5aU);
    subject.controls[0].evidence_digest.fill(0xc3U);
    subject.controls[0].requirement = static_cast<Requirement>(0xfeU);
    subject.controls[0].state = static_cast<ControlState>(0xfdU);
    subject.consequence = static_cast<Consequence>(0xfcU);
    subject.effect_class = static_cast<EffectClass>(0xfbU);
    subject.uncertainty_mode = static_cast<UncertaintyMode>(0xfaU);
    return subject;
}

bool same(const Subject& left, const Subject& right) noexcept {
    return encode_subject(left) == encode_subject(right);
}

SubjectImage image(const std::vector<std::uint8_t>& bytes) {
    if (bytes.size() != subject_image_size) {
        throw std::runtime_error("image-size");
    }
    SubjectImage result{};
    std::copy(bytes.begin(), bytes.end(), result.begin());
    return result;
}

const char* intake_name(const IntakeFault fault) {
    switch (fault) {
        case IntakeFault::none:
            return "none";
        case IntakeFault::wrong_wire_length:
            return "wrong_wire_length";
        case IntakeFault::subject_decode_rejected:
            return "subject_decode_rejected";
    }
    return "invalid";
}

const char* boolean(const bool value) {
    return value ? "true" : "false";
}

[[noreturn]] void simulated_crash(const std::size_t artifact_count) {
    std::cerr
        << "RATIFICATION_SUBJECT_PACKET_SIMULATED_CRASH=YES artifacts_closed="
        << artifact_count
        << " final_visible=false durability_claimed=false\n";
    std::cerr.flush();
    std::_Exit(75);
}

void after_artifact(const CampaignControl& control,
                    const std::size_t artifact_count) {
    if (control.crash_after_artifact &&
        *control.crash_after_artifact == artifact_count) {
        simulated_crash(artifact_count);
    }
}

void require_complete_stage(const harness::AtomicPacket& packet) {
    std::size_t regular_files = 0U;
    for (const auto& entry : std::filesystem::directory_iterator(packet.staging_path())) {
        const auto status = entry.symlink_status();
        if (!entry.is_regular_file() || std::filesystem::is_symlink(status)) {
            throw std::runtime_error("stage-special-or-nonregular");
        }
        ++regular_files;
    }
    if (regular_files != artifact_names.size()) {
        throw std::runtime_error("stage-artifact-count");
    }
    for (const auto name : artifact_names) {
        if (!std::filesystem::is_regular_file(packet.artifact(name))) {
            throw std::runtime_error("stage-artifact-missing");
        }
    }
}

}  // namespace

int run_campaign(const std::filesystem::path& subject_path,
                 const std::filesystem::path& output,
                 const CampaignControl control) {
    const auto baseline = read_bytes(subject_path);
    if (baseline.size() != subject_image_size) {
        throw std::runtime_error("baseline-size");
    }

    // The final path is required to be absent. All campaign artifacts remain
    // under an uncommitted sibling staging directory until one no-replace
    // namespace transition publishes the complete packet.
    harness::AtomicPacket packet(output);

    Subject candidate = sentinel();
    Subject reference_subject = sentinel();
    const auto candidate_outcome = decode_exact(baseline, candidate);
    const auto reference_outcome = reference::decode_exact(baseline, reference_subject);
    if (!candidate_outcome.accepted || candidate_outcome != reference_outcome ||
        encode_subject(candidate) != image(baseline) ||
        ratification_subject::reference::encode_subject(reference_subject) != image(baseline)) {
        throw std::runtime_error("baseline");
    }
    write_text(
        packet.artifact("exact-baseline.tsv"),
        "case\twire_length\tcandidate_accepted\treference_accepted\tcommitted_exact_image\tauthority_granted\tepoch_exit_proved\n"
        "exact_baseline\t1152\ttrue\ttrue\ttrue\tfalse\tfalse\n");
    after_artifact(control, 1U);

    std::ostringstream lengths;
    lengths
        << "wire_length\tcandidate_accepted\treference_accepted\tcandidate_fault\treference_fault\tcandidate_output_unchanged\treference_output_unchanged\tauthority_granted\tepoch_exit_proved\n";
    std::size_t length_cases = 0U;
    for (std::size_t length = 0U; length <= subject_image_size * 2U; ++length) {
        if (length == subject_image_size) {
            continue;
        }
        std::vector<std::uint8_t> wire(length, 0xa7U);
        std::copy_n(baseline.begin(), std::min(length, baseline.size()), wire.begin());
        Subject candidate_subject = sentinel();
        Subject reference_value = sentinel();
        const Subject candidate_before = candidate_subject;
        const Subject reference_before = reference_value;
        const auto candidate_result = decode_exact(wire, candidate_subject);
        const auto reference_result = reference::decode_exact(wire, reference_value);
        if (candidate_result.accepted || candidate_result != reference_result ||
            candidate_result.intake_fault != IntakeFault::wrong_wire_length ||
            !same(candidate_subject, candidate_before) ||
            !same(reference_value, reference_before)) {
            throw std::runtime_error("length-fence");
        }
        lengths << length << "\tfalse\tfalse\t"
                << intake_name(candidate_result.intake_fault) << '\t'
                << intake_name(reference_result.intake_fault)
                << "\ttrue\ttrue\tfalse\tfalse\n";
        ++length_cases;
    }
    write_text(packet.artifact("length-fence.tsv"), lengths.str());
    after_artifact(control, 2U);

    std::ostringstream flips;
    flips
        << "offset\tbit\tcandidate_accepted\treference_accepted\tcandidate_intake_fault\treference_intake_fault\tcandidate_subject_fault\treference_subject_fault\tcandidate_output_unchanged_on_reject\treference_output_unchanged_on_reject\taccepted_output_reencodes_exact_wire\tauthority_granted\tepoch_exit_proved\n";
    std::size_t accepted = 0U;
    std::size_t rejected = 0U;
    std::size_t flip_cases = 0U;
    for (std::size_t offset = 0U; offset < subject_image_size; ++offset) {
        for (std::uint8_t bit = 0U; bit < 8U; ++bit) {
            auto wire = baseline;
            wire[offset] ^= static_cast<std::uint8_t>(1U << bit);
            Subject candidate_subject = sentinel();
            Subject reference_value = sentinel();
            const Subject candidate_before = candidate_subject;
            const Subject reference_before = reference_value;
            const auto candidate_result = decode_exact(wire, candidate_subject);
            const auto reference_result = reference::decode_exact(wire, reference_value);
            if (candidate_result != reference_result) {
                throw std::runtime_error("flip-disagreement");
            }
            const bool candidate_unchanged =
                !candidate_result.accepted && same(candidate_subject, candidate_before);
            const bool reference_unchanged =
                !reference_result.accepted && same(reference_value, reference_before);
            bool reencodes = false;
            if (candidate_result.accepted) {
                const auto expected_image = image(wire);
                reencodes = encode_subject(candidate_subject) == expected_image &&
                            ratification_subject::reference::encode_subject(reference_value) ==
                                expected_image;
                if (!reencodes) {
                    throw std::runtime_error("flip-commit");
                }
                ++accepted;
            } else {
                if (!candidate_unchanged || !reference_unchanged) {
                    throw std::runtime_error("flip-atomicity");
                }
                ++rejected;
            }
            flips << offset << '\t' << static_cast<unsigned int>(bit) << '\t'
                  << boolean(candidate_result.accepted) << '\t'
                  << boolean(reference_result.accepted) << '\t'
                  << intake_name(candidate_result.intake_fault) << '\t'
                  << intake_name(reference_result.intake_fault) << '\t'
                  << ratification_subject::fault_name(candidate_result.subject_fault) << '\t'
                  << ratification_subject::fault_name(reference_result.subject_fault) << '\t'
                  << boolean(candidate_unchanged) << '\t'
                  << boolean(reference_unchanged) << '\t'
                  << boolean(reencodes) << "\tfalse\tfalse\n";
            ++flip_cases;
        }
    }
    write_text(packet.artifact("bit-flip-atomicity.tsv"), flips.str());
    after_artifact(control, 3U);

    std::ostringstream summary;
    summary << "{\n"
            << "  \"schema\": \"slopos.rev0933.ratification-subject-intake-fence.campaign.v1\",\n"
            << "  \"subject_bytes\": 1152,\n"
            << "  \"exact_baseline_cases\": 1,\n"
            << "  \"wrong_length_cases\": " << length_cases << ",\n"
            << "  \"single_bit_cases\": " << flip_cases << ",\n"
            << "  \"single_bit_accepted\": " << accepted << ",\n"
            << "  \"single_bit_rejected\": " << rejected << ",\n"
            << "  \"total_cases\": " << 1U + length_cases + flip_cases << ",\n"
            << "  \"candidate_reference_disagreements\": 0,\n"
            << "  \"all_wrong_lengths_rejected_before_decode\": true,\n"
            << "  \"all_rejections_preserve_caller_output\": true,\n"
            << "  \"all_acceptances_commit_exact_wire_image\": true,\n"
            << "  \"authority_granted\": false,\n"
            << "  \"epoch_exit_proved\": false\n"
            << "}\n";
    write_text(packet.artifact("summary.json"), summary.str());
    after_artifact(control, 4U);

    require_complete_stage(packet);
    if (control.create_commit_collision) {
        if (!std::filesystem::create_directory(output)) {
            throw std::runtime_error("collision-fixture-create");
        }
        write_text(output / "collision-sentinel.txt", "preexisting-final-must-survive\n");
    }
    packet.commit();

    std::cout
        << "RATIFICATION_SUBJECT_INTAKE_FENCE_CAMPAIGN=PASS subject_bytes=1152 exact=1 wrong_lengths="
        << length_cases << " bit_flips=" << flip_cases
        << " accepted_flips=" << accepted << " rejected_flips=" << rejected
        << " total=" << 1U + length_cases + flip_cases
        << " disagreements=0 packet=rename_noreplace complete_before_visible=true"
        << " stable_media=false authority=false epoch_exit=false\n";
    return 0;
}

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence
