#include "slopos/e0/core_gate/ratification_subject/reference.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>
#include <vector>

namespace slopos::e0::core_gate::ratification_subject::reference {
namespace {

constexpr std::array<std::uint8_t, 8U> tag{{'S','L','O','P','R','A','T','1'}};
constexpr std::string_view domain = "SlopOS/e0/ratification-subject/v1";
constexpr std::array<std::uint32_t, 64U> constants{{
    0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
    0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
    0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
    0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
    0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
    0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
    0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
    0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U,
}};

[[nodiscard]] constexpr std::uint32_t rotate(std::uint32_t x, unsigned int n) noexcept {
    return (x >> n) | (x << (32U - n));
}

[[nodiscard]] Digest sha256(const std::vector<std::uint8_t>& input) noexcept {
    std::vector<std::uint8_t> bytes = input;
    const std::uint64_t length = static_cast<std::uint64_t>(bytes.size()) * 8U;
    bytes.push_back(0x80U);
    while ((bytes.size() % 64U) != 56U) bytes.push_back(0U);
    for (unsigned int shift : {56U,48U,40U,32U,24U,16U,8U,0U})
        bytes.push_back(static_cast<std::uint8_t>(length >> shift));

    std::array<std::uint32_t, 8U> h{{
        0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,
        0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U,
    }};
    for (std::size_t offset = 0U; offset < bytes.size(); offset += 64U) {
        std::array<std::uint32_t, 64U> w{};
        for (std::size_t i = 0U; i < 16U; ++i) {
            const std::size_t p = offset + i * 4U;
            w[i] = (static_cast<std::uint32_t>(bytes[p]) << 24U)
                | (static_cast<std::uint32_t>(bytes[p + 1U]) << 16U)
                | (static_cast<std::uint32_t>(bytes[p + 2U]) << 8U)
                | static_cast<std::uint32_t>(bytes[p + 3U]);
        }
        for (std::size_t i = 16U; i < 64U; ++i) {
            const std::uint32_t a = rotate(w[i - 15U], 7U) ^ rotate(w[i - 15U], 18U) ^ (w[i - 15U] >> 3U);
            const std::uint32_t b = rotate(w[i - 2U], 17U) ^ rotate(w[i - 2U], 19U) ^ (w[i - 2U] >> 10U);
            w[i] = w[i - 16U] + a + w[i - 7U] + b;
        }
        std::uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],z=h[7];
        for (std::size_t i = 0U; i < 64U; ++i) {
            const std::uint32_t e_sigma = rotate(e,6U) ^ rotate(e,11U) ^ rotate(e,25U);
            const std::uint32_t choose = (e & f) ^ ((~e) & g);
            const std::uint32_t t1 = z + e_sigma + choose + constants[i] + w[i];
            const std::uint32_t a_sigma = rotate(a,2U) ^ rotate(a,13U) ^ rotate(a,22U);
            const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t t2 = a_sigma + majority;
            z=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=z;
    }
    Digest out{};
    for (std::size_t i = 0U; i < h.size(); ++i) {
        out[i*4U]=static_cast<std::uint8_t>(h[i]>>24U);
        out[i*4U+1U]=static_cast<std::uint8_t>(h[i]>>16U);
        out[i*4U+2U]=static_cast<std::uint8_t>(h[i]>>8U);
        out[i*4U+3U]=static_cast<std::uint8_t>(h[i]);
    }
    return out;
}

[[nodiscard]] std::array<const Digest*, binding_digest_count> const_fields(const Subject& s) noexcept {
    return {{&s.checkpoint_digest,&s.parent_checkpoint_digest,&s.trust_context_digest,
        &s.owner_constitution_digest,&s.owner_set_digest,&s.decision_domain_digest,
        &s.current_root_digest,&s.current_policy_digest,&s.encoding_profile_digest,
        &s.membrane_commitment,&s.dossier_commitment,&s.transaction_id_digest,
        &s.claim_digest,&s.effect_digest,&s.effect_target_digest,&s.spend_coordinate_digest,
        &s.retry_contract_digest,&s.terminal_query_digest,&s.independent_reopen_digest,
        &s.control_profile_digest,&s.reconfiguration_digest,&s.compromise_response_digest,
        &s.stop_rule_digest,&s.release_constitution_digest,&s.living_target_checkpoint_digest}};
}
[[nodiscard]] std::array<Digest*, binding_digest_count> mutable_fields(Subject& s) noexcept {
    return {{&s.checkpoint_digest,&s.parent_checkpoint_digest,&s.trust_context_digest,
        &s.owner_constitution_digest,&s.owner_set_digest,&s.decision_domain_digest,
        &s.current_root_digest,&s.current_policy_digest,&s.encoding_profile_digest,
        &s.membrane_commitment,&s.dossier_commitment,&s.transaction_id_digest,
        &s.claim_digest,&s.effect_digest,&s.effect_target_digest,&s.spend_coordinate_digest,
        &s.retry_contract_digest,&s.terminal_query_digest,&s.independent_reopen_digest,
        &s.control_profile_digest,&s.reconfiguration_digest,&s.compromise_response_digest,
        &s.stop_rule_digest,&s.release_constitution_digest,&s.living_target_checkpoint_digest}};
}
[[nodiscard]] bool zero(const Digest& d) noexcept { return cut0::is_zero(d); }
[[nodiscard]] bool valid_requirement(Requirement r) noexcept {
    return r==Requirement::must_separate || r==Requirement::may_share || r==Requirement::not_required;
}
[[nodiscard]] bool valid_state(ControlState s) noexcept {
    return s==ControlState::separate || s==ControlState::shared || s==ControlState::unknown || s==ControlState::not_applicable;
}

void put8(SubjectImage& out, std::size_t& p, std::uint8_t v) noexcept { out[p++]=v; }
void put16(SubjectImage& out, std::size_t& p, std::uint16_t v) noexcept {
    put8(out,p,static_cast<std::uint8_t>(v>>8U)); put8(out,p,static_cast<std::uint8_t>(v));
}
void put32(SubjectImage& out, std::size_t& p, std::uint32_t v) noexcept {
    put8(out,p,static_cast<std::uint8_t>(v>>24U)); put8(out,p,static_cast<std::uint8_t>(v>>16U));
    put8(out,p,static_cast<std::uint8_t>(v>>8U)); put8(out,p,static_cast<std::uint8_t>(v));
}
void put64(SubjectImage& out, std::size_t& p, std::uint64_t v) noexcept {
    for (unsigned int shift : {56U,48U,40U,32U,24U,16U,8U,0U}) put8(out,p,static_cast<std::uint8_t>(v>>shift));
}
template<std::size_t N> void put_array(SubjectImage& out,std::size_t& p,const std::array<std::uint8_t,N>& a) noexcept {
    for (const std::uint8_t v : a) put8(out,p,v);
}
[[nodiscard]] std::uint8_t get8(const SubjectImage& in,std::size_t& p) noexcept { return in[p++]; }
[[nodiscard]] std::uint16_t get16(const SubjectImage& in,std::size_t& p) noexcept {
    const auto a=get8(in,p); const auto b=get8(in,p);
    return static_cast<std::uint16_t>((static_cast<std::uint16_t>(a)<<8U)|b);
}
[[nodiscard]] std::uint32_t get32(const SubjectImage& in,std::size_t& p) noexcept {
    std::uint32_t v=0U; for(int i=0;i<4;++i) v=(v<<8U)|get8(in,p); return v;
}
[[nodiscard]] std::uint64_t get64(const SubjectImage& in,std::size_t& p) noexcept {
    std::uint64_t v=0U; for(int i=0;i<8;++i) v=(v<<8U)|get8(in,p); return v;
}
template<std::size_t N> void get_array(const SubjectImage& in,std::size_t& p,std::array<std::uint8_t,N>& a) noexcept {
    for (std::uint8_t& v : a) v=get8(in,p);
}

[[nodiscard]] Evaluation make(Status s,Fault f,std::uint8_t a,std::uint8_t fields,const Digest& c) noexcept {
    Evaluation out{}; out.status=s; out.fault=f; out.bound_control_axes=a; out.configured_fields_bound=fields; out.subject_commitment=c; return out;
}

[[nodiscard]] Fault validate(const Subject& s,std::uint8_t& axes) noexcept {
    if(s.owner_count==0U) return Fault::owner_count_zero;
    if(s.owner_threshold==0U || s.owner_threshold>s.owner_count) return Fault::owner_threshold_invalid;
    if(s.root_version==0U || s.policy_version==0U) return Fault::root_or_policy_version_zero;
    if(s.valid_from_sequence==0U || s.valid_until_sequence<s.valid_from_sequence) return Fault::validity_interval_invalid;
    const auto f=const_fields(s); for(std::size_t i=0U;i<23U;++i) if(zero(*f[i])) return Fault::required_digest_zero;
    if(s.consequence==Consequence::experimental) {
        if(!zero(s.release_constitution_digest)||!zero(s.living_target_checkpoint_digest)) return Fault::experimental_release_target_nonzero;
    } else if(s.consequence==Consequence::living_transition_request) {
        if(zero(s.release_constitution_digest)||zero(s.living_target_checkpoint_digest)) return Fault::living_transition_target_missing;
    } else return Fault::consequence_invalid;
    if(s.effect_class!=EffectClass::harmless_monotonic) return Fault::effect_class_invalid;
    if(s.uncertainty_mode!=UncertaintyMode::query_only) return Fault::uncertainty_mode_invalid;
    if(s.assertion_mask!=0U) return Fault::assertion_mask_nonzero;
    axes=0U;
    for(const auto& c:s.controls) {
        if(!valid_requirement(c.requirement)) return Fault::control_requirement_invalid;
        if(!valid_state(c.state)) return Fault::control_state_invalid;
        const bool has=!zero(c.evidence_digest);
        switch(c.requirement) {
            case Requirement::must_separate: {
                if(c.state!=ControlState::separate || !has) return Fault::control_evidence_invalid;
                break;
            }
            case Requirement::may_share: {
                if((c.state!=ControlState::separate && c.state!=ControlState::shared)||!has) return Fault::control_evidence_invalid;
                break;
            }
            case Requirement::not_required: {
                if(c.state!=ControlState::not_applicable || has) return Fault::control_evidence_invalid;
                break;
            }
        }
        ++axes;
    }
    return Fault::none;
}

[[nodiscard]] bool expected_zero(const ExpectedContext& e) noexcept {
    return zero(e.checkpoint_digest)||zero(e.parent_checkpoint_digest)||zero(e.trust_context_digest)
        ||zero(e.owner_constitution_digest)||zero(e.owner_set_digest)||zero(e.decision_domain_digest)
        ||zero(e.current_root_digest)||zero(e.current_policy_digest)||zero(e.encoding_profile_digest)
        ||zero(e.membrane_commitment)||zero(e.dossier_commitment);
}

}  // namespace

SubjectImage encode_subject(const Subject& s) noexcept {
    SubjectImage out{}; std::size_t p=0U;
    put_array(out,p,tag); put64(out,p,1U); put16(out,p,s.owner_count); put16(out,p,s.owner_threshold); put32(out,p,0U);
    put64(out,p,s.root_version); put64(out,p,s.policy_version); put64(out,p,s.valid_from_sequence); put64(out,p,s.valid_until_sequence);
    for(const Digest* d:const_fields(s)) put_array(out,p,*d);
    for(const auto& c:s.controls) { put8(out,p,static_cast<std::uint8_t>(c.requirement)); put8(out,p,static_cast<std::uint8_t>(c.state)); put16(out,p,0U); put_array(out,p,c.evidence_digest); }
    put8(out,p,static_cast<std::uint8_t>(s.consequence)); put8(out,p,static_cast<std::uint8_t>(s.effect_class));
    put8(out,p,static_cast<std::uint8_t>(s.uncertainty_mode)); put8(out,p,s.assertion_mask); put32(out,p,0U);
    (void)p; return out;
}

bool decode_subject(const SubjectImage& in, Subject& s, Fault& fault) noexcept {
    std::size_t p=0U; std::array<std::uint8_t,8U> observed{}; get_array(in,p,observed);
    if(observed!=tag){fault=Fault::bad_magic;return false;} if(get64(in,p)!=1U){fault=Fault::bad_schema_version;return false;}
    s.owner_count=get16(in,p); s.owner_threshold=get16(in,p); if(get32(in,p)!=0U){fault=Fault::reserved_nonzero;return false;}
    s.root_version=get64(in,p); s.policy_version=get64(in,p); s.valid_from_sequence=get64(in,p); s.valid_until_sequence=get64(in,p);
    for(Digest* d:mutable_fields(s)) get_array(in,p,*d);
    for(auto& c:s.controls){c.requirement=static_cast<Requirement>(get8(in,p));c.state=static_cast<ControlState>(get8(in,p));if(get16(in,p)!=0U){fault=Fault::reserved_nonzero;return false;}get_array(in,p,c.evidence_digest);}
    s.consequence=static_cast<Consequence>(get8(in,p));s.effect_class=static_cast<EffectClass>(get8(in,p));s.uncertainty_mode=static_cast<UncertaintyMode>(get8(in,p));s.assertion_mask=get8(in,p);
    if(get32(in,p)!=0U || p!=subject_image_size){fault=Fault::reserved_nonzero;return false;}
    for(const auto& c:s.controls){if(!valid_requirement(c.requirement)){fault=Fault::control_requirement_invalid;return false;}if(!valid_state(c.state)){fault=Fault::control_state_invalid;return false;}}
    if(s.consequence!=Consequence::experimental && s.consequence!=Consequence::living_transition_request){fault=Fault::consequence_invalid;return false;}
    if(s.effect_class!=EffectClass::harmless_monotonic){fault=Fault::effect_class_invalid;return false;}
    if(s.uncertainty_mode!=UncertaintyMode::query_only){fault=Fault::uncertainty_mode_invalid;return false;}
    fault=Fault::none;return true;
}

Digest image_commitment(const SubjectImage& image) noexcept {
    std::vector<std::uint8_t> bytes; bytes.reserve(domain.size()+1U+image.size());
    for(char c:domain) { bytes.push_back(static_cast<std::uint8_t>(c)); }
    bytes.push_back(0U);
    bytes.insert(bytes.end(),image.begin(),image.end()); return sha256(bytes);
}
Digest subject_commitment(const Subject& s) noexcept { return reference::image_commitment(reference::encode_subject(s)); }

Evaluation evaluate(const Subject& s,const ExpectedContext& e) noexcept {
    const Digest c=reference::subject_commitment(s); std::uint8_t axes=0U; const Fault f=validate(s,axes);
    if(f!=Fault::none){const bool control=f==Fault::control_requirement_invalid||f==Fault::control_state_invalid||f==Fault::control_evidence_invalid;return make(control?Status::control_vector_rejected:Status::subject_shape_rejected,f,axes,0U,c);}
    if(s.consequence==Consequence::living_transition_request&&!e.allow_living_transition) return make(Status::configured_context_mismatch,Fault::living_transition_not_allowed,axes,0U,c);
    if(zero(e.expected_subject_commitment)) return make(Status::configured_context_missing,Fault::expected_commitment_zero,axes,0U,c);
    if(e.owner_count==0U||e.owner_threshold==0U||e.root_version==0U||e.policy_version==0U||e.maximum_validity_span==0U||expected_zero(e)) return make(Status::configured_context_missing,Fault::expected_context_field_zero,axes,0U,c);
    if(e.current_sequence<s.valid_from_sequence||e.current_sequence>s.valid_until_sequence) return make(Status::configured_context_mismatch,Fault::current_sequence_outside_interval,axes,0U,c);
    if(s.valid_until_sequence-s.valid_from_sequence>e.maximum_validity_span) return make(Status::configured_context_mismatch,Fault::validity_span_exceeded,axes,0U,c);
    const bool scalar=s.owner_count==e.owner_count&&s.owner_threshold==e.owner_threshold&&s.root_version==e.root_version&&s.policy_version==e.policy_version;
    const bool exact=s.checkpoint_digest==e.checkpoint_digest&&s.parent_checkpoint_digest==e.parent_checkpoint_digest&&s.trust_context_digest==e.trust_context_digest&&s.owner_constitution_digest==e.owner_constitution_digest&&s.owner_set_digest==e.owner_set_digest&&s.decision_domain_digest==e.decision_domain_digest&&s.current_root_digest==e.current_root_digest&&s.current_policy_digest==e.current_policy_digest&&s.encoding_profile_digest==e.encoding_profile_digest&&s.membrane_commitment==e.membrane_commitment&&s.dossier_commitment==e.dossier_commitment;
    if(!scalar||!exact) return make(Status::configured_context_mismatch,Fault::expected_context_field_mismatch,axes,0U,c);
    if(c!=e.expected_subject_commitment) return make(Status::configured_context_mismatch,Fault::expected_commitment_mismatch,axes,15U,c);
    return make(Status::configured_subject_bound,Fault::none,axes,16U,c);
}

}  // namespace slopos::e0::core_gate::ratification_subject::reference
