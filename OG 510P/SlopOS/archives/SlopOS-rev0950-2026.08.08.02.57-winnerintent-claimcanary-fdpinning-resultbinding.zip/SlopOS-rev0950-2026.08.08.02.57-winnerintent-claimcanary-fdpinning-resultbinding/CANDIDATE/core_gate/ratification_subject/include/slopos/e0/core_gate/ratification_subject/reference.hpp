#pragma once

#include "slopos/e0/core_gate/ratification_subject/subject.hpp"

namespace slopos::e0::core_gate::ratification_subject::reference {

// Independent fixed-width encoder, decoder, SHA-256 implementation, and
// evaluator. These functions do not call candidate implementations.
[[nodiscard]] SubjectImage encode_subject(const Subject& subject) noexcept;
[[nodiscard]] bool decode_subject(
    const SubjectImage& image, Subject& subject, Fault& fault) noexcept;
[[nodiscard]] Digest image_commitment(const SubjectImage& image) noexcept;
[[nodiscard]] Digest subject_commitment(const Subject& subject) noexcept;
[[nodiscard]] Evaluation evaluate(
    const Subject& subject, const ExpectedContext& expected) noexcept;

}  // namespace slopos::e0::core_gate::ratification_subject::reference
