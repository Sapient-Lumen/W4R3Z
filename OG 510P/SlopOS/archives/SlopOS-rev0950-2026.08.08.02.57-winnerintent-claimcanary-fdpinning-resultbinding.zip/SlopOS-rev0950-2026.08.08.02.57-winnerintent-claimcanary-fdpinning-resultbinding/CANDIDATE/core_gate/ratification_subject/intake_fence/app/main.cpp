#include <charconv>
#include <cstddef>
#include <filesystem>
#include <iostream>
#include <optional>
#include <string_view>

#include "harness/campaign.hpp"

namespace {

std::optional<std::size_t> parse_count(const std::string_view value) {
    std::size_t result = 0U;
    const auto parsed = std::from_chars(
        value.data(), value.data() + value.size(), result);
    if (parsed.ec != std::errc{} || parsed.ptr != value.data() + value.size()) {
        return std::nullopt;
    }
    return result;
}

void usage() {
    std::cerr
        << "usage:\n"
        << "  slopos_ratification_subject_intake_fence campaign SUBJECT_BIN OUTPUT\n"
        << "  slopos_ratification_subject_intake_fence crash-after SUBJECT_BIN OUTPUT ARTIFACT_COUNT\n"
        << "  slopos_ratification_subject_intake_fence collision-before-commit SUBJECT_BIN OUTPUT\n";
}

}  // namespace

int main(int argc, char** argv) {
    using slopos::e0::core_gate::ratification_subject::intake_fence::CampaignControl;
    CampaignControl control{};

    if (argc == 4 && std::string_view(argv[1]) == "campaign") {
        // Default control.
    } else if (argc == 5 && std::string_view(argv[1]) == "crash-after") {
        const auto count = parse_count(argv[4]);
        if (!count || *count < 1U || *count > 4U) {
            usage();
            return 64;
        }
        control.crash_after_artifact = *count;
    } else if (argc == 4 &&
               std::string_view(argv[1]) == "collision-before-commit") {
        control.create_commit_collision = true;
    } else {
        usage();
        return 64;
    }

    try {
        return slopos::e0::core_gate::ratification_subject::intake_fence::run_campaign(
            argv[2], argv[3], control);
    } catch (const std::exception& error) {
        std::cerr << "RATIFICATION_SUBJECT_INTAKE_FENCE_CAMPAIGN=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
