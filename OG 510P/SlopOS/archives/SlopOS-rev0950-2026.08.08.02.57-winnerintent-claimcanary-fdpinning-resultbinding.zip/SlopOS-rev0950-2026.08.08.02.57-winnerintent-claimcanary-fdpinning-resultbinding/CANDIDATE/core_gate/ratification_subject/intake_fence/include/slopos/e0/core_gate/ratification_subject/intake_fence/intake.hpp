#pragma once

#include "slopos/e0/core_gate/ratification_subject/subject.hpp"

#include <cstdint>
#include <span>

namespace slopos::e0::core_gate::ratification_subject::intake_fence {

enum class IntakeFault : std::uint8_t {
    none,
    wrong_wire_length,
    subject_decode_rejected,
};

struct IntakeResult final {
    bool accepted{false};
    IntakeFault intake_fault{IntakeFault::wrong_wire_length};
    Fault subject_fault{Fault::none};

    [[nodiscard]] friend constexpr bool operator==(
        const IntakeResult&, const IntakeResult&) noexcept = default;
};

// Caller output is a commit target, never parser scratch storage.
[[nodiscard]] IntakeResult decode_exact(
    std::span<const std::uint8_t> wire, Subject& subject) noexcept;

[[nodiscard]] constexpr bool owner_ratification_proved(const IntakeResult&) noexcept { return false; }
[[nodiscard]] constexpr bool effect_occurrence_proved(const IntakeResult&) noexcept { return false; }
[[nodiscard]] constexpr bool independent_reopen_proved(const IntakeResult&) noexcept { return false; }
[[nodiscard]] constexpr bool living_admission_proved(const IntakeResult&) noexcept { return false; }
[[nodiscard]] constexpr bool authority_granted(const IntakeResult&) noexcept { return false; }
[[nodiscard]] constexpr bool epoch_exit_proved(const IntakeResult&) noexcept { return false; }

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence
