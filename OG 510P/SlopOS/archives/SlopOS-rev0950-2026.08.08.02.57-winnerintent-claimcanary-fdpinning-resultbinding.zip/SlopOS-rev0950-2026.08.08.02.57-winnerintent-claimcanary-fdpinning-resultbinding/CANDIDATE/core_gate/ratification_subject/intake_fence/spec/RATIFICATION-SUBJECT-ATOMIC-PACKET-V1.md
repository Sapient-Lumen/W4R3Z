# Ratification Subject Atomic Packet V1

## Question

Can the existing Intake Fence campaign expose its retained result set as one
complete namespace object, rather than creating the final evidence directory
before all four artifacts exist?

## Operated profile

The profile is Linux C++20. The final path must be absent and its direct parent
must already be a real directory. A sibling staging directory is created under
that same parent. The campaign closes exactly four simple-leaf artifacts in the
staging directory, verifies the complete set, and performs one
`renameat2(..., RENAME_NOREPLACE)` from stage to final.

`RENAME_NOREPLACE` is required. A pre-existing or concurrently created final
path causes failure; the campaign does not remove, merge, or replace it. A
successful final packet contains the byte-identical rev0933 semantic output
set.

## Crash and restart model

The bounded campaign terminates the process after each possible artifact-close
cut, one through four. At every cut the final path is absent and the partial
files remain under a staging name. A fresh process may choose a new stage and
commit a complete packet while the old stage remains visibly non-final.

Staging residue is not evidence and is not silently cleaned by a later writer.
That rule avoids interpreting an untrusted same-prefix directory as owned
state. Cleanup remains a separate workspace operation.

## Claims

Within the operated local filesystem profile:

- final visibility follows completion of all four closed artifacts;
- the final transition is one no-replace namespace operation;
- abrupt process termination before that transition leaves no partial final;
- a new run can publish a complete packet despite stale non-final residue;
- commit collision and duplicate publication preserve the existing final; and
- publication mechanics do not alter the frozen semantic output bytes.

## Mandatory nonclaims

This construction proves namespace atomicity, not stable media. It does not
establish file-data or directory-entry persistence across power loss, parent-path custody, writer authenticity, malicious ancestor
resistance, network-filesystem semantics, external evidence occurrence,
configured trust, owner ratification, effect occurrence, independent reopen,
living admission, authority, or epoch exit.
