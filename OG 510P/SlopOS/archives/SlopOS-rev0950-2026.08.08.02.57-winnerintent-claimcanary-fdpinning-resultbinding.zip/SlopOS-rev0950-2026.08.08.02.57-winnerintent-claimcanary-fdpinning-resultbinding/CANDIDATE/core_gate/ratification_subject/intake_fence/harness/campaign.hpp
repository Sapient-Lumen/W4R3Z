#pragma once

#include <cstddef>
#include <filesystem>
#include <optional>

namespace slopos::e0::core_gate::ratification_subject::intake_fence {

struct CampaignControl {
    std::optional<std::size_t> crash_after_artifact;
    bool create_commit_collision{false};
};

int run_campaign(const std::filesystem::path& subject_image,
                 const std::filesystem::path& output,
                 CampaignControl control = {});

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence
