#pragma once

#include "slopos/e0/core_gate/nonpromotion_kernel.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slopos::e0::core_gate::ratification_subject {

using Digest = nonpromotion::Digest;

inline constexpr std::size_t binding_digest_count = 25U;
inline constexpr std::size_t control_axis_count = 8U;
inline constexpr std::size_t subject_image_size = 1152U;
using SubjectImage = std::array<std::uint8_t, subject_image_size>;

// G governance, K credentials, S storage, E execution, A administration,
// R recovery, B rollback/backup, Q observation/query.
enum class Axis : std::uint8_t {
    governance = 0U,
    credentials = 1U,
    storage = 2U,
    execution = 3U,
    administration = 4U,
    recovery = 5U,
    rollback = 6U,
    query = 7U,
};

enum class Requirement : std::uint8_t {
    must_separate = 1U,
    may_share = 2U,
    not_required = 3U,
};

enum class ControlState : std::uint8_t {
    separate = 1U,
    shared = 2U,
    unknown = 3U,
    not_applicable = 4U,
};

enum class Consequence : std::uint8_t {
    experimental = 1U,
    living_transition_request = 2U,
};

enum class EffectClass : std::uint8_t {
    harmless_monotonic = 1U,
};

enum class UncertaintyMode : std::uint8_t {
    query_only = 1U,
};

enum class Status : std::uint8_t {
    subject_shape_rejected,
    control_vector_rejected,
    configured_context_missing,
    configured_context_mismatch,
    configured_subject_bound,
};

enum class Fault : std::uint8_t {
    none,
    bad_magic,
    bad_schema_version,
    reserved_nonzero,
    owner_count_zero,
    owner_threshold_invalid,
    root_or_policy_version_zero,
    validity_interval_invalid,
    validity_span_exceeded,
    required_digest_zero,
    experimental_release_target_nonzero,
    living_transition_target_missing,
    consequence_invalid,
    living_transition_not_allowed,
    effect_class_invalid,
    uncertainty_mode_invalid,
    assertion_mask_nonzero,
    control_requirement_invalid,
    control_state_invalid,
    control_evidence_invalid,
    expected_commitment_zero,
    expected_context_field_zero,
    expected_context_field_mismatch,
    current_sequence_outside_interval,
    expected_commitment_mismatch,
};

struct ControlDeclaration final {
    Requirement requirement{Requirement::must_separate};
    ControlState state{ControlState::unknown};
    Digest evidence_digest{};

    [[nodiscard]] friend constexpr bool operator==(
        const ControlDeclaration&, const ControlDeclaration&) noexcept = default;
};

struct Subject final {
    std::uint16_t owner_count{0U};
    std::uint16_t owner_threshold{0U};
    std::uint64_t root_version{0U};
    std::uint64_t policy_version{0U};
    std::uint64_t valid_from_sequence{0U};
    std::uint64_t valid_until_sequence{0U};

    Digest checkpoint_digest{};
    Digest parent_checkpoint_digest{};
    Digest trust_context_digest{};
    Digest owner_constitution_digest{};
    Digest owner_set_digest{};
    Digest decision_domain_digest{};
    Digest current_root_digest{};
    Digest current_policy_digest{};
    Digest encoding_profile_digest{};
    Digest membrane_commitment{};
    Digest dossier_commitment{};
    Digest transaction_id_digest{};
    Digest claim_digest{};
    Digest effect_digest{};
    Digest effect_target_digest{};
    Digest spend_coordinate_digest{};
    Digest retry_contract_digest{};
    Digest terminal_query_digest{};
    Digest independent_reopen_digest{};
    Digest control_profile_digest{};
    Digest reconfiguration_digest{};
    Digest compromise_response_digest{};
    Digest stop_rule_digest{};
    Digest release_constitution_digest{};
    Digest living_target_checkpoint_digest{};

    std::array<ControlDeclaration, control_axis_count> controls{};
    Consequence consequence{Consequence::experimental};
    EffectClass effect_class{EffectClass::harmless_monotonic};
    UncertaintyMode uncertainty_mode{UncertaintyMode::query_only};
    std::uint8_t assertion_mask{0U};
};

// This is configuration supplied separately from the subject. A local match
// establishes only configured binding. It does not establish that this context
// came from constituted owners or from independently governed current state.
struct ExpectedContext final {
    Digest expected_subject_commitment{};
    Digest checkpoint_digest{};
    Digest parent_checkpoint_digest{};
    Digest trust_context_digest{};
    Digest owner_constitution_digest{};
    Digest owner_set_digest{};
    Digest decision_domain_digest{};
    Digest current_root_digest{};
    Digest current_policy_digest{};
    Digest encoding_profile_digest{};
    Digest membrane_commitment{};
    Digest dossier_commitment{};
    std::uint16_t owner_count{0U};
    std::uint16_t owner_threshold{0U};
    std::uint64_t root_version{0U};
    std::uint64_t policy_version{0U};
    std::uint64_t current_sequence{0U};
    std::uint64_t maximum_validity_span{0U};
    bool allow_living_transition{false};
};

struct Evaluation final {
    Status status{Status::subject_shape_rejected};
    Fault fault{Fault::bad_magic};
    std::uint8_t bound_control_axes{0U};
    std::uint8_t configured_fields_bound{0U};
    Digest subject_commitment{};

    [[nodiscard]] friend constexpr bool operator==(
        const Evaluation&, const Evaluation&) noexcept = default;
};

[[nodiscard]] SubjectImage encode_subject(const Subject& subject) noexcept;
[[nodiscard]] bool decode_subject(
    const SubjectImage& image, Subject& subject, Fault& fault) noexcept;
[[nodiscard]] Digest image_commitment(const SubjectImage& image) noexcept;
[[nodiscard]] Digest subject_commitment(const Subject& subject) noexcept;
[[nodiscard]] Evaluation evaluate(
    const Subject& subject, const ExpectedContext& expected) noexcept;

[[nodiscard]] std::string_view axis_name(Axis value) noexcept;
[[nodiscard]] std::string_view status_name(Status value) noexcept;
[[nodiscard]] std::string_view fault_name(Fault value) noexcept;

// Nonpromotion invariants. No subject or separately supplied expected context
// can turn these into an owner decision, a world event, a reopened history, or
// a living-lineage admission.
[[nodiscard]] constexpr bool owner_ratification_proved(const Evaluation&) noexcept { return false; }
[[nodiscard]] constexpr bool effect_occurrence_proved(const Evaluation&) noexcept { return false; }
[[nodiscard]] constexpr bool independent_reopen_proved(const Evaluation&) noexcept { return false; }
[[nodiscard]] constexpr bool living_admission_proved(const Evaluation&) noexcept { return false; }
[[nodiscard]] constexpr bool configured_context_externality_proved(const Evaluation&) noexcept { return false; }
[[nodiscard]] constexpr bool authority_granted(const Evaluation&) noexcept { return false; }
[[nodiscard]] constexpr bool epoch_exit_proved(const Evaluation&) noexcept { return false; }

}  // namespace slopos::e0::core_gate::ratification_subject
