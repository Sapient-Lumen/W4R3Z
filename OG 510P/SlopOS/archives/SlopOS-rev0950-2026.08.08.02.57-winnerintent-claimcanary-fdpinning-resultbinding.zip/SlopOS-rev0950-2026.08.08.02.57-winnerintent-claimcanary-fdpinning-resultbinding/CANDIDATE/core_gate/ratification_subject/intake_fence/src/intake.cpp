#include "slopos/e0/core_gate/ratification_subject/intake_fence/intake.hpp"

#include <algorithm>

namespace slopos::e0::core_gate::ratification_subject::intake_fence {

IntakeResult decode_exact(
    const std::span<const std::uint8_t> wire, Subject& subject) noexcept {
    if (wire.size() != subject_image_size) {
        return {false, IntakeFault::wrong_wire_length, Fault::none};
    }
    SubjectImage image{};
    std::copy(wire.begin(), wire.end(), image.begin());
    Subject decoded{};
    Fault fault = Fault::none;
    if (!decode_subject(image, decoded, fault)) {
        return {false, IntakeFault::subject_decode_rejected, fault};
    }
    subject = decoded;
    return {true, IntakeFault::none, Fault::none};
}

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence
