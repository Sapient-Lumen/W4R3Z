#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import struct
import sys
from pathlib import Path

EXPECTED_MEMBRANE = "24b85d6d3e0240153c948747104ae9aa8384f5488782e959ef8cfcd15f536867"
EXPECTED_DOSSIER = "fb44c954876ad294642df720d2991f106f93c7fb8f8147e5922eb15eaee81a92"
DOMAIN = b"SlopOS/e0/ratification-subject/v1\0"
FILES = (
    "bit-flips.tsv",
    "context-substitution.tsv",
    "control-faults.tsv",
    "control-masks.tsv",
    "curated.tsv",
    "self-selection.tsv",
    "subject.bin",
    "subject.json",
    "summary.json",
)


def fail(detail: str) -> None:
    raise SystemExit(f"CONFIGURED_RATIFICATION_SUBJECT_PROOF=FAIL detail={detail}")


def rows(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != fields:
            fail(f"header={path.name}:{reader.fieldnames!r}")
        result = list(reader)
    if any(any(value is None for value in row.values()) for row in result):
        fail(f"short-row={path.name}")
    return result


def verify_image(output: Path) -> dict[str, object]:
    image = (output / "subject.bin").read_bytes()
    if len(image) != 1152:
        fail(f"subject-bytes={len(image)}")
    if image[:8] != b"SLOPRAT1" or struct.unpack(">Q", image[8:16])[0] != 1:
        fail("subject-header")
    owner_count, threshold, reserved = struct.unpack(">HHI", image[16:24])
    root_version, policy_version, valid_from, valid_until = struct.unpack(">QQQQ", image[24:56])
    if (owner_count, threshold, reserved) != (5, 3, 0):
        fail("owner-header")
    if (root_version, policy_version, valid_from, valid_until) != (7, 11, 100, 140):
        fail("version-interval")
    digests = [image[56 + index * 32 : 56 + (index + 1) * 32] for index in range(25)]
    if any(not any(value) for value in digests[:23]):
        fail("required-digest-zero")
    if digests[9].hex() != EXPECTED_MEMBRANE or digests[10].hex() != EXPECTED_DOSSIER:
        fail("v2-commitments")
    if any(digests[23]) or any(digests[24]):
        fail("experimental-target-nonzero")
    controls = image[856:1144]
    for index in range(8):
        item = controls[index * 36 : (index + 1) * 36]
        if item[:4] != b"\x01\x01\x00\x00" or not any(item[4:]):
            fail(f"control={index}")
    if image[1144:] != b"\x01\x01\x01\x00\x00\x00\x00\x00":
        fail("tail")
    subject = json.loads((output / "subject.json").read_text(encoding="utf-8"))
    commitment = hashlib.sha256(DOMAIN + image).hexdigest()
    expected = {
        "schema": "slopos.rev0932.configured-ratification-subject.v1",
        "status": "PASS",
        "subject_bytes": 1152,
        "subject_commitment": commitment,
        "membrane_commitment": EXPECTED_MEMBRANE,
        "dossier_commitment": EXPECTED_DOSSIER,
        "owner_count": 5,
        "owner_threshold": 3,
        "root_version": 7,
        "policy_version": 11,
        "valid_from_sequence": 100,
        "valid_until_sequence": 140,
        "consequence": "experimental",
        "highest_local_status": "configured_subject_bound",
        "configured_context_externality_proved": False,
        "owner_ratification_proved": False,
        "effect_occurrence_proved": False,
        "independent_reopen_proved": False,
        "living_admission_proved": False,
        "authority_granted": False,
        "epoch_exit_proved": False,
    }
    if subject != expected:
        fail("subject-json")
    return {"commitment": commitment, "image": image}


def verify(output: Path) -> dict[str, object]:
    if not output.is_dir() or tuple(sorted(path.name for path in output.iterdir() if path.is_file())) != FILES:
        fail(f"files={tuple(sorted(path.name for path in output.iterdir() if path.is_file())) if output.exists() else 'missing'}")
    image = verify_image(output)
    summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "schema": "slopos.rev0932.configured-ratification-subject-campaign.v1",
        "status": "PASS",
        "subject_bytes": 1152,
        "binding_digests": 25,
        "control_axes": 8,
        "curated_cases": 47,
        "control_masks": 256,
        "control_fault_cases": 104,
        "context_substitution_cases": 26,
        "bit_flip_cases": 9216,
        "self_selection_worlds": 2,
        "total_cases": 9651,
        "candidate_reference_disagreements": 0,
        "exact_v2_membrane_bound": True,
        "exact_v2_dossier_bound": True,
        "all_single_bit_mutations_rejected_by_fixed_context": True,
        "self_selected_context_can_match_locally": True,
        "self_selected_context_proves_externality": False,
        "highest_local_status": "configured_subject_bound",
        "owner_ratification_proved": False,
        "authority_granted": False,
        "epoch_exit_proved": False,
    }
    if summary != expected_summary:
        fail("summary")

    curated = rows(output / "curated.tsv", [
        "case", "expected_status", "expected_fault", "candidate_status", "candidate_fault",
        "reference_status", "reference_fault", "bound_axes", "configured_fields",
        "owner_ratification_proved", "effect_occurrence_proved", "independent_reopen_proved",
        "living_admission_proved", "configured_context_externality_proved", "authority_granted",
        "epoch_exit_proved",
    ])
    if len(curated) != 47 or curated[0]["case"] != "baseline":
        fail("curated-count")
    for row in curated:
        if row["candidate_status"] != row["expected_status"] or row["reference_status"] != row["expected_status"]:
            fail(f"curated-status={row['case']}")
        if row["candidate_fault"] != row["expected_fault"] or row["reference_fault"] != row["expected_fault"]:
            fail(f"curated-fault={row['case']}")
        if any(row[key] != "false" for key in row if key.endswith("proved") or key in {"authority_granted", "epoch_exit_proved"}):
            fail(f"curated-promotion={row['case']}")

    masks = rows(output / "control-masks.tsv", [
        "mask", "must_separate_axes", "not_required_axes", "candidate_status", "reference_status",
        "bound_axes", "authority_granted", "epoch_exit_proved",
    ])
    if [int(row["mask"]) for row in masks] != list(range(256)):
        fail("control-mask-domain")
    for row in masks:
        mask = int(row["mask"])
        if int(row["must_separate_axes"]) != mask.bit_count() or int(row["not_required_axes"]) != 8 - mask.bit_count():
            fail(f"control-mask-count={mask}")
        if row["candidate_status"] != "configured_subject_bound" or row["reference_status"] != "configured_subject_bound" or row["bound_axes"] != "8":
            fail(f"control-mask-status={mask}")
        if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
            fail(f"control-mask-promotion={mask}")

    faults = rows(output / "control-faults.tsv", [
        "axis", "mutation", "candidate_status", "candidate_fault", "reference_status",
        "reference_fault", "authority_granted", "epoch_exit_proved",
    ])
    if len(faults) != 104 or {row["axis"] for row in faults} != set("GKSEARBQ"):
        fail("control-fault-domain")
    for row in faults:
        if row["candidate_status"] != "control_vector_rejected" or row["reference_status"] != "control_vector_rejected":
            fail("control-fault-status")
        if row["candidate_fault"] != row["reference_fault"] or row["candidate_fault"] not in {
            "control_requirement_invalid", "control_state_invalid", "control_evidence_invalid"
        }:
            fail("control-fault-reason")
        if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
            fail("control-fault-promotion")

    contexts = rows(output / "context-substitution.tsv", [
        "case", "expected_status", "expected_fault", "candidate_status", "candidate_fault",
        "reference_status", "reference_fault", "authority_granted", "epoch_exit_proved",
    ])
    if len(contexts) != 26:
        fail("context-count")
    for row in contexts:
        if row["candidate_status"] != row["expected_status"] or row["reference_status"] != row["expected_status"]:
            fail(f"context-status={row['case']}")
        if row["candidate_fault"] != row["expected_fault"] or row["reference_fault"] != row["expected_fault"]:
            fail(f"context-fault={row['case']}")
        if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
            fail(f"context-promotion={row['case']}")

    flips = rows(output / "bit-flips.tsv", [
        "offset", "bit", "candidate_decode", "reference_decode", "decode_fault", "evaluation_status",
        "evaluation_fault", "commitment_changed", "candidate_reference_commitment_equal",
        "authority_granted", "epoch_exit_proved",
    ])
    expected_pairs = [(offset, bit) for offset in range(1152) for bit in range(8)]
    if [(int(row["offset"]), int(row["bit"])) for row in flips] != expected_pairs:
        fail("flip-domain")
    for row in flips:
        if row["candidate_decode"] != row["reference_decode"] or row["evaluation_status"] == "configured_subject_bound":
            fail(f"flip-result={row['offset']}")
        if row["commitment_changed"] != "true" or row["candidate_reference_commitment_equal"] != "true":
            fail(f"flip-commitment={row['offset']}")
        if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
            fail(f"flip-promotion={row['offset']}")

    worlds = rows(output / "self-selection.tsv", [
        "world", "context_origin", "candidate_status", "reference_status",
        "configured_context_externality_proved", "owner_ratification_proved", "authority_granted",
        "epoch_exit_proved",
    ])
    if worlds != [
        {
            "world": "fixed_context", "context_origin": "preconfigured_baseline",
            "candidate_status": "configured_context_mismatch", "reference_status": "configured_context_mismatch",
            "configured_context_externality_proved": "false", "owner_ratification_proved": "false",
            "authority_granted": "false", "epoch_exit_proved": "false",
        },
        {
            "world": "self_selected_context", "context_origin": "derived_from_same_mutated_subject",
            "candidate_status": "configured_subject_bound", "reference_status": "configured_subject_bound",
            "configured_context_externality_proved": "false", "owner_ratification_proved": "false",
            "authority_granted": "false", "epoch_exit_proved": "false",
        },
    ]:
        fail("self-selection")

    obligations = Path(__file__).with_name("OBLIGATIONS.tsv")
    obligation_rows = rows(obligations, ["id", "obligation", "mechanism", "falsification", "status", "authoritative"])
    if len(obligation_rows) != 27 or any(row["status"] != "PASS" or row["authoritative"] != "false" for row in obligation_rows):
        fail("obligations")
    return {"summary": summary, "commitment": image["commitment"], "obligations": len(obligation_rows)}


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage")
    result = verify(Path(sys.argv[1]).resolve())
    summary = result["summary"]
    assert isinstance(summary, dict)
    print(
        "CONFIGURED_RATIFICATION_SUBJECT_PROOF=PASS "
        f"cases={summary['total_cases']} bytes={summary['subject_bytes']} obligations={result['obligations']} "
        f"commitment={result['commitment']} authority=false epoch_exit=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
