#include "atomic_packet.hpp"

#include <cerrno>
#include <chrono>
#include <cstdint>
#include <fcntl.h>
#include <stdexcept>
#include <string>
#include <system_error>
#include <sys/syscall.h>
#include <unistd.h>

#ifndef RENAME_NOREPLACE
#define RENAME_NOREPLACE (1U << 0U)
#endif

namespace slopos::e0::core_gate::ratification_subject::intake_fence::harness {
namespace {

[[nodiscard]] bool is_simple_leaf(const std::string_view leaf) noexcept {
    if (leaf.empty() || leaf == "." || leaf == "..") {
        return false;
    }
    for (const char value : leaf) {
        if (value == '/' || value == '\\' || value == '\0') {
            return false;
        }
    }
    return true;
}

[[nodiscard]] std::filesystem::path make_staging_path(
    const std::filesystem::path& final_path) {
    const auto parent = final_path.parent_path().empty()
                            ? std::filesystem::path{"."}
                            : final_path.parent_path();
    const auto filename = final_path.filename().string();
    const auto ticks = static_cast<std::uint64_t>(
        std::chrono::steady_clock::now().time_since_epoch().count());
    const auto process = static_cast<std::uint64_t>(::getpid());

    for (std::uint64_t attempt = 0U; attempt < 128U; ++attempt) {
        const auto leaf = "." + filename + ".slopos-stage-" +
                          std::to_string(process) + "-" +
                          std::to_string(ticks) + "-" +
                          std::to_string(attempt);
        const auto candidate = parent / leaf;
        std::error_code error;
        if (std::filesystem::create_directory(candidate, error)) {
            return candidate;
        }
        if (error && error != std::errc::file_exists) {
            throw std::filesystem::filesystem_error(
                "create-staging-directory", candidate, error);
        }
    }
    throw std::runtime_error("staging-name-exhausted");
}

}  // namespace

AtomicPacket::AtomicPacket(std::filesystem::path final_path)
    : final_path_(std::move(final_path)) {
    if (final_path_.empty() || final_path_.filename().empty()) {
        throw std::invalid_argument("invalid-final-path");
    }
    const auto parent = final_path_.parent_path().empty()
                            ? std::filesystem::path{"."}
                            : final_path_.parent_path();
    std::error_code error;
    const auto parent_status = std::filesystem::symlink_status(parent, error);
    if (error || !std::filesystem::is_directory(parent_status)) {
        throw std::runtime_error("final-parent-not-direct-directory");
    }
    error.clear();
    const auto final_status = std::filesystem::symlink_status(final_path_, error);
    if (error && error != std::errc::no_such_file_or_directory) {
        throw std::filesystem::filesystem_error(
            "inspect-final-path", final_path_, error);
    }
    if (!error && final_status.type() != std::filesystem::file_type::not_found) {
        throw std::runtime_error("final-path-exists");
    }
    staging_path_ = make_staging_path(final_path_);
}

AtomicPacket::~AtomicPacket() noexcept {
    if (!committed_ && !staging_path_.empty()) {
        std::error_code ignored;
        std::filesystem::remove_all(staging_path_, ignored);
    }
}

std::filesystem::path AtomicPacket::artifact(const std::string_view leaf) const {
    if (!is_simple_leaf(leaf)) {
        throw std::invalid_argument("artifact-name-not-simple-leaf");
    }
    return staging_path_ / std::string{leaf};
}

const std::filesystem::path& AtomicPacket::staging_path() const noexcept {
    return staging_path_;
}

const std::filesystem::path& AtomicPacket::final_path() const noexcept {
    return final_path_;
}

void AtomicPacket::commit() {
    if (committed_) {
        throw std::logic_error("packet-already-committed");
    }
#if defined(SYS_renameat2)
    const long result = ::syscall(
        SYS_renameat2,
        AT_FDCWD,
        staging_path_.c_str(),
        AT_FDCWD,
        final_path_.c_str(),
        static_cast<unsigned int>(RENAME_NOREPLACE));
    if (result != 0L) {
        const int saved_errno = errno;
        throw std::system_error(
            saved_errno,
            std::generic_category(),
            "renameat2-rename-noreplace");
    }
    committed_ = true;
#else
    throw std::runtime_error("renameat2-unavailable");
#endif
}

}  // namespace slopos::e0::core_gate::ratification_subject::intake_fence::harness
