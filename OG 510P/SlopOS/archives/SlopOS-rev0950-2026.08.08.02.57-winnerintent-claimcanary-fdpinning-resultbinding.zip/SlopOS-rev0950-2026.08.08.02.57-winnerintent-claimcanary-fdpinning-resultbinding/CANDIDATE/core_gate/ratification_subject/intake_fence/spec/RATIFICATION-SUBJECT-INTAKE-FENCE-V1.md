# Ratification Subject Intake Fence V1

## Bounded claim

For Configured Ratification Subject V1, exactly 1,152 bytes:

* input is a `std::span<const uint8_t>` so received length remains observable;
* all other lengths are rejected before fixed-image copy or decoder entry;
* exact-length bytes are parsed into a local temporary;
* caller output is unchanged on rejection; and
* accepted output re-encodes to the exact accepted wire image.

Coverage is exhaustive for lengths 0–2,304 excluding 1,152 and for every
single-bit mutation of the canonical 1,152-byte image. It is not a proof about
all byte strings, all parser implementations, authenticity, owner intent, or
world effects.

## Nonpromotion and placement

This direct proof executable is nested below
`CANDIDATE/core_gate/ratification_subject`; it is absent from the five product
targets and does not create a fourth semantic island. Every authority and
Epoch-Zero-exit predicate remains constant false.
