# Configured Ratification Subject V1

## Status

Epoch-Zero proof construction. This is an **unsigned subject to be ratified**, not
ratification, authorization, effect occurrence, independent reopen, living
admission, or an epoch transition.

The name corrects the promotion-prone phrase “owner ratification capsule.” An
artifact made entirely inside this office is **not the owner act** and cannot
honestly contain the external act that would ratify it.

## The theorem at this cut

Let `S` be the exact 1,152-byte subject image, `H(S)` its domain-separated
SHA-256 commitment, and `C` a separately supplied expected context, represented in C++ as
`ExpectedContext`. The local machine may establish:

`well_formed(S) ∧ configured_fields(S,C) ∧ H(S)=C.expected_commitment`

and name that bounded result `configured_subject_bound`.

It may not derive any of the following:

`external(C)`, `owner_ratified(S)`, `effect_occurred(S)`,
`independent_reopen(S)`, `living_admitted(S)`, `authority`, or `epoch_exit`.

The decisive countermodel is executable. A mutated subject fails against a
fixed expected context, yet passes when the expected context is derived from the
same mutated subject. The second world is locally coherent and still proves no
externality. Therefore a subject cannot carry the trust needed to accept itself.

## Canonical image

All integers are unsigned big-endian. Digests are exactly 32 bytes. Enums and
booleans occupy one byte. Reserved bytes must be zero.

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 8 | magic `SLOPRAT1` |
| 8 | 8 | schema version, exactly `1` |
| 16 | 2 | owner count |
| 18 | 2 | owner threshold |
| 20 | 4 | reserved zero |
| 24 | 8 | root version |
| 32 | 8 | policy version |
| 40 | 8 | valid-from sequence |
| 48 | 8 | valid-until sequence |
| 56 | 800 | 25 ordered binding digests |
| 856 | 288 | eight 36-byte control declarations |
| 1144 | 1 | consequence |
| 1145 | 1 | effect class |
| 1146 | 1 | uncertainty mode |
| 1147 | 1 | assertion mask, exactly zero |
| 1148 | 4 | reserved zero |

The 25 digests, in order, bind checkpoint, parent checkpoint, trust context,
owner constitution, owner set, decision domain, current root, current policy,
encoding profile, exact Nonpromotion Kernel V2 membrane, exact V2 dossier,
transaction ID, claim, harmless effect, effect target, protected spend
coordinate, retry contract, terminal query, independent reopen subject, control
declaration, reconfiguration, compromise response, stop rule, release
constitution, and living target checkpoint.

For an experimental consequence, release constitution and living target must be
zero. A living-transition request merely encodes a request: both must be nonzero
and a separate local configuration bit must permit evaluation. Even then,
`living_admission_proved` remains constant false.

The global `control_profile_digest` identifies the externally selected control-policy/profile definition. It is not a digest of the eight records below. Each embedded claim-relative control declaration is:

`requirement:1 | state:1 | reserved:2 | evidence_digest:32`

for `G,K,S,E,A,R,B,Q`: governance, credentials, storage, execution,
administration, recovery, rollback/backup, and observation/query.

- `MUST_SEPARATE` requires `SEPARATE` and a nonzero evidence digest.
- `MAY_SHARE` permits `SEPARATE` or `SHARED` and requires evidence.
- `NOT_REQUIRED` requires `NOT_APPLICABLE` and zero evidence.

These are claim-relative declarations. A passing vector does not prove the
declared control facts or their external governance.

## Commitment

`SHA-256("SlopOS/e0/ratification-subject/v1" || 0x00 || exact_image)`

The expected subject commitment is supplied separately from the image. The
configured context also repeats owner threshold, versions, current sequence,
validity-span bound, and eleven current identity digests so diagnostics do not
collapse every mismatch into one opaque hash failure.

## Effects and uncertainty

V1 admits only a harmless monotonic effect class and query-only uncertainty.
The assertion mask must be zero; bits that claim owner ratification, occurrence,
independent reopen, living admission, or authority are rejected rather than
stored as caller-supplied truth.

## Proof campaign

The retained campaign executes independent candidate and reference encoders,
decoders, SHA-256 implementations, and evaluators through GCC, Clang, and
ASan/UBSan lanes. It covers:

- 47 curated shape, consequence, and nonclaim cases;
- all 256 control requirement masks;
- 104 axis-specific control falsifications;
- 26 configured-context substitutions;
- all 9,216 one-bit image mutations against one fixed context; and
- the two-world self-selection countermodel.

Only one byte-identical canonical payload set is retained. Compiler lane receipts
and transitive compiler dependency capture remain separate evidence.

## Explicit absences

No private key, fixture signer, owner signature, threshold ceremony, protected
state service, effect endpoint, independent reopener, license decision, privacy
policy, public identity, or living-lineage admission is shipped here.
