# Configured ratification subject

Nested direct-build proof inside the `core_gate` semantic island. It is absent
from the top-level product target manifest and does not create a fourth island or
sixth product executable.

Build and run:

```sh
cmake -S CANDIDATE/core_gate/ratification_subject -B /tmp/slopos-rat -G Ninja \
  -DCMAKE_CXX_COMPILER=g++ -DCMAKE_BUILD_TYPE=Debug
cmake --build /tmp/slopos-rat --target slopos_configured_ratification_subject -- -j1
/tmp/slopos-rat/slopos_configured_ratification_subject campaign /tmp/slopos-rat-out
python3 -B CANDIDATE/core_gate/ratification_subject/proof/verify_ratification_subject.py \
  /tmp/slopos-rat-out
```

Highest result: `configured_subject_bound`. All authority-bearing predicates are
constant false. See `spec/CONFIGURED-RATIFICATION-SUBJECT-V1.md`.
