#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <string_view>
#include <tuple>

namespace slopos::e0::core_gate {

enum class Phase : std::uint8_t {
    empty,
    evidenced,
    appraised,
    decided,
    permit_live,
    entered,
    terminal,
    published,
};

enum class Subject : std::uint8_t { none, alpha, beta };
enum class Appraisal : std::uint8_t { none, allow, deny };
enum class Decision : std::uint8_t { none, allow, deny };
enum class Dispatch : std::uint8_t { not_issued, live, entered, burned, terminal };
enum class Result : std::uint8_t { none, effect, no_effect, uncertain, fail_stop };
enum class Outcome : std::uint8_t { applied, rejected };

enum class Event : std::uint8_t {
    bind_evidence_alpha,
    bind_evidence_beta,
    appraise_allow_alpha,
    appraise_allow_beta,
    appraise_deny_alpha,
    appraise_deny_beta,
    decide_allow_alpha,
    decide_allow_beta,
    decide_deny_alpha,
    decide_deny_beta,
    mint_permit,
    enter_exact,
    enter_subject_mismatch,
    enter_malformed,
    enter_route_override,
    endpoint_effect,
    endpoint_no_effect,
    endpoint_nonreturn,
    endpoint_malformed,
    reconcile_effect,
    reconcile_no_effect,
    reconcile_mismatch,
    publish,
    restart,
    recover_mint_attempt,
    proposer_route_override,
};

struct State final {
    Phase phase{Phase::empty};
    Subject evidence_subject{Subject::none};
    Subject appraisal_subject{Subject::none};
    Appraisal appraisal{Appraisal::none};
    Subject decision_subject{Subject::none};
    Decision decision{Decision::none};
    Dispatch dispatch{Dispatch::not_issued};
    Result result{Result::none};
    bool published{false};
    bool recovered{false};
    std::uint8_t effect_count{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const State&, const State&) noexcept = default;
    [[nodiscard]] friend constexpr bool operator<(
        const State& lhs, const State& rhs) noexcept {
        return std::tie(lhs.phase, lhs.evidence_subject,
                        lhs.appraisal_subject, lhs.appraisal,
                        lhs.decision_subject, lhs.decision, lhs.dispatch,
                        lhs.result, lhs.published, lhs.recovered,
                        lhs.effect_count)
             < std::tie(rhs.phase, rhs.evidence_subject,
                        rhs.appraisal_subject, rhs.appraisal,
                        rhs.decision_subject, rhs.decision, rhs.dispatch,
                        rhs.result, rhs.published, rhs.recovered,
                        rhs.effect_count);
    }
};

struct Step final {
    Outcome outcome{Outcome::rejected};
    State state{};
    bool effect_emitted{false};
    bool permit_consumed{false};

    [[nodiscard]] friend constexpr bool operator==(
        const Step&, const Step&) noexcept = default;
};

inline constexpr std::array<Event, 26U> kEvents{{
    Event::bind_evidence_alpha,
    Event::bind_evidence_beta,
    Event::appraise_allow_alpha,
    Event::appraise_allow_beta,
    Event::appraise_deny_alpha,
    Event::appraise_deny_beta,
    Event::decide_allow_alpha,
    Event::decide_allow_beta,
    Event::decide_deny_alpha,
    Event::decide_deny_beta,
    Event::mint_permit,
    Event::enter_exact,
    Event::enter_subject_mismatch,
    Event::enter_malformed,
    Event::enter_route_override,
    Event::endpoint_effect,
    Event::endpoint_no_effect,
    Event::endpoint_nonreturn,
    Event::endpoint_malformed,
    Event::reconcile_effect,
    Event::reconcile_no_effect,
    Event::reconcile_mismatch,
    Event::publish,
    Event::restart,
    Event::recover_mint_attempt,
    Event::proposer_route_override,
}};

[[nodiscard]] State initial_state() noexcept;
[[nodiscard]] bool invariant(const State& state) noexcept;
[[nodiscard]] Step step(const State& state, Event event) noexcept;

[[nodiscard]] std::string_view phase_name(Phase value) noexcept;
[[nodiscard]] std::string_view subject_name(Subject value) noexcept;
[[nodiscard]] std::string_view appraisal_name(Appraisal value) noexcept;
[[nodiscard]] std::string_view decision_name(Decision value) noexcept;
[[nodiscard]] std::string_view dispatch_name(Dispatch value) noexcept;
[[nodiscard]] std::string_view result_name(Result value) noexcept;
[[nodiscard]] std::string_view outcome_name(Outcome value) noexcept;
[[nodiscard]] std::string_view event_name(Event value) noexcept;
[[nodiscard]] std::string state_key(const State& state);

}  // namespace slopos::e0::core_gate
