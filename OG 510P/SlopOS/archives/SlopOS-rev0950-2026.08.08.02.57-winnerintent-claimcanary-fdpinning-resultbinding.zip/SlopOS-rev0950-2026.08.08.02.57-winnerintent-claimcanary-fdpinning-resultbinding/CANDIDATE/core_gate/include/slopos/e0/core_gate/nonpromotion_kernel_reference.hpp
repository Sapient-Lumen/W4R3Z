#pragma once

#include "slopos/e0/core_gate/nonpromotion_kernel.hpp"

namespace slopos::e0::core_gate::nonpromotion::reference {

// Independently controlled V2 encoder, SHA-256 implementation, and evaluator.
// These functions do not call the candidate encoder, commitment, or evaluator.
[[nodiscard]] MembraneImage encode_membrane(
    const cut0::Packet& packet) noexcept;
[[nodiscard]] Digest membrane_commitment(
    const cut0::Packet& packet) noexcept;
[[nodiscard]] DossierImage encode_dossier(
    const Dossier& dossier) noexcept;
[[nodiscard]] Digest dossier_commitment(
    const Dossier& dossier) noexcept;
[[nodiscard]] Evaluation evaluate(const Dossier& dossier) noexcept;

}  // namespace slopos::e0::core_gate::nonpromotion::reference
