#pragma once

#include "slopos/e0/core_gate/membrane_cut0.hpp"

namespace slopos::e0::core_gate::cut0::reference {

// Independently controlled evaluator for the same public six-record vocabulary.
// It intentionally does not call the candidate evaluator or its private helpers.
[[nodiscard]] Evaluation evaluate(const Packet& packet) noexcept;

}  // namespace slopos::e0::core_gate::cut0::reference
