#pragma once

#include <array>
#include <cstdint>
#include <string_view>

namespace slopos::e0::core_gate::cut0 {

using Digest = std::array<std::uint8_t, 32U>;

enum class AppraisalVerdict : std::uint8_t {
    pass,
    deny,
    indeterminate,
};

enum class TerminalClass : std::uint8_t {
    none,
    effect,
    no_effect,
    uncertain,
    fail_stop,
};

enum class Status : std::uint8_t {
    rejected,
    closed_deny,
    closed_indeterminate,
    appraisal_pass_no_permit,
    permit_record_bound,
    terminal_record_bound,
    reopen_record_bound,
};

enum class Fault : std::uint8_t {
    none,
    subject_incomplete,
    evidence_incomplete,
    evidence_subject_mismatch,
    appraisal_incomplete,
    appraisal_subject_mismatch,
    appraisal_evidence_mismatch,
    appraisal_policy_mismatch,
    appraisal_verdict_invalid,
    post_closed_material,
    terminal_without_permit,
    reopen_without_terminal,
    permit_incomplete,
    permit_subject_mismatch,
    permit_appraisal_mismatch,
    terminal_incomplete,
    terminal_permit_mismatch,
    terminal_effect_mismatch,
    terminal_class_invalid,
    reopen_incomplete,
    reopen_terminal_mismatch,
    reopen_class_mismatch,
    reopen_same_administration_label,
};

struct SubjectRecord final {
    Digest id{};
    Digest artifact_digest{};
    Digest appraisal_policy_digest{};
    std::uint64_t revision{0U};
};

struct EvidenceRecord final {
    Digest id{};
    Digest subject_id{};
    Digest evidence_digest{};
    Digest acquisition_context_digest{};
};

struct AppraisalRecord final {
    Digest id{};
    Digest subject_id{};
    Digest evidence_id{};
    Digest policy_digest{};
    AppraisalVerdict verdict{AppraisalVerdict::indeterminate};
};

struct PermitRecord final {
    bool present{false};
    Digest id{};
    Digest subject_id{};
    Digest appraisal_id{};
    Digest effect_digest{};
    Digest spend_coordinate_digest{};
    std::uint64_t serial{0U};
};

struct TerminalRecord final {
    bool present{false};
    Digest id{};
    Digest permit_id{};
    Digest effect_digest{};
    Digest predecessor_digest{};
    TerminalClass terminal_class{TerminalClass::none};
    std::uint64_t sequence{0U};
};

struct ReopenRecord final {
    bool present{false};
    Digest terminal_id{};
    TerminalClass terminal_class{TerminalClass::none};
    Digest producer_administration_label_digest{};
    Digest reopener_administration_label_digest{};
    Digest receipt_digest{};
};

struct Packet final {
    SubjectRecord subject{};
    EvidenceRecord evidence{};
    AppraisalRecord appraisal{};
    PermitRecord permit{};
    TerminalRecord terminal{};
    ReopenRecord reopen{};
};

struct Evaluation final {
    Status status{Status::rejected};
    Fault fault{Fault::none};
    bool permit_record_bound{false};
    bool terminal_record_bound{false};
    bool administration_labels_distinct{false};

    [[nodiscard]] friend constexpr bool operator==(
        const Evaluation&, const Evaluation&) noexcept = default;
};

[[nodiscard]] bool is_zero(const Digest& value) noexcept;
[[nodiscard]] Evaluation evaluate(const Packet& packet) noexcept;
[[nodiscard]] std::string_view status_name(Status value) noexcept;
[[nodiscard]] std::string_view fault_name(Fault value) noexcept;
[[nodiscard]] std::string_view appraisal_name(AppraisalVerdict value) noexcept;
[[nodiscard]] std::string_view terminal_name(TerminalClass value) noexcept;

}  // namespace slopos::e0::core_gate::cut0
