#pragma once

#include "slopos/e0/core_gate/membrane_cut0.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slopos::e0::core_gate::nonpromotion {

using Digest = cut0::Digest;

// These are external authority edges from the current membrane ledger. A
// record bearing one of these labels is still only caller-supplied structure.
enum class Edge : std::uint8_t {
    owner_constitution = 0U,
    acquisition_and_appraisal_enrollment = 1U,
    current_policy_selection = 2U,
    protected_one_use_spend = 3U,
    authenticated_effect_and_query = 4U,
    independent_terminal_reopen = 5U,
    owner_admission = 6U,
    release_constitution = 7U,
    none = 255U,
};

inline constexpr std::size_t edge_count = 8U;

// Canonical V2 byte images bind logical fields rather than C++ object layout.
// Booleans and enums occupy one byte; integers are unsigned big-endian; every
// digest is exactly 32 bytes. Optional-record payload is encoded even when its
// presence bit is false so no supplied input can hide outside the commitment.
inline constexpr std::size_t membrane_image_size = 814U;
inline constexpr std::size_t premise_record_image_size = 138U;
inline constexpr std::size_t dossier_image_size =
    16U + membrane_image_size + edge_count * premise_record_image_size;
static_assert(dossier_image_size == 1934U);

using MembraneImage = std::array<std::uint8_t, membrane_image_size>;
using DossierImage = std::array<std::uint8_t, dossier_image_size>;

// The highest status says that eight external-witness records join one exact
// hosted R1-R6 packet. It deliberately does not say the witnesses are true,
// current, independently controlled, owner-admitted, or authoritative.
enum class Status : std::uint8_t {
    membrane_rejected,
    membrane_prefix_incomplete,
    premise_record_missing,
    premise_record_incomplete,
    premise_edge_mismatch,
    premise_subject_mismatch,
    premise_membrane_mismatch,
    premise_sequence_mismatch,
    external_record_set_bound,
};

enum class Fault : std::uint8_t {
    none,
    membrane_relation_rejected,
    membrane_reopen_record_absent,
    premise_missing,
    premise_incomplete,
    premise_edge_mismatch,
    premise_subject_mismatch,
    premise_membrane_mismatch,
    premise_sequence_mismatch,
};

struct PremiseRecord final {
    bool present{false};
    Edge edge{Edge::none};
    Digest subject_id{};
    Digest membrane_commitment{};
    Digest witness_digest{};
    Digest source_identity_digest{};
    std::uint64_t sequence{0U};
};

using PremiseRecords = std::array<PremiseRecord, edge_count>;

struct Dossier final {
    cut0::Packet membrane{};
    PremiseRecords external_records{};
};

struct Evaluation final {
    Status status{Status::membrane_rejected};
    Fault fault{Fault::membrane_relation_rejected};
    std::uint8_t bound_premise_records{0U};
    Edge first_open_edge{Edge::owner_constitution};
    bool membrane_reopen_record_bound{false};
    bool all_external_records_bound{false};
    Digest membrane_commitment{};
    Digest dossier_commitment{};

    [[nodiscard]] friend constexpr bool operator==(
        const Evaluation&, const Evaluation&) noexcept = default;
};

[[nodiscard]] MembraneImage encode_membrane(
    const cut0::Packet& packet) noexcept;
[[nodiscard]] Digest membrane_commitment(
    const cut0::Packet& packet) noexcept;
[[nodiscard]] DossierImage encode_dossier(
    const Dossier& dossier) noexcept;
[[nodiscard]] Digest dossier_commitment(
    const Dossier& dossier) noexcept;
[[nodiscard]] Evaluation evaluate(const Dossier& dossier) noexcept;
[[nodiscard]] std::string_view edge_name(Edge value) noexcept;
[[nodiscard]] std::string_view status_name(Status value) noexcept;
[[nodiscard]] std::string_view fault_name(Fault value) noexcept;

// Nonpromotion is an API invariant rather than a caller-populated result bit.
// No hosted input can make either function return true.
[[nodiscard]] constexpr bool authority_granted(const Evaluation&) noexcept {
    return false;
}

[[nodiscard]] constexpr bool epoch_exit_proved(const Evaluation&) noexcept {
    return false;
}

}  // namespace slopos::e0::core_gate::nonpromotion
