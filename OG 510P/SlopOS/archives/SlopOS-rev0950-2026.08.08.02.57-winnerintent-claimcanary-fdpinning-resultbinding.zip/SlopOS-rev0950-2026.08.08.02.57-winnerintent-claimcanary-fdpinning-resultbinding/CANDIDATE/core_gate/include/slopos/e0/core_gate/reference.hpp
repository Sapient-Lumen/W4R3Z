#pragma once

#include "slopos/e0/core_gate/machine.hpp"

namespace slopos::e0::core_gate::reference {

// Independently spelled transition oracle. It shares only the public value
// vocabulary with the candidate implementation.
[[nodiscard]] Step step(const State& state, Event event) noexcept;

}  // namespace slopos::e0::core_gate::reference
