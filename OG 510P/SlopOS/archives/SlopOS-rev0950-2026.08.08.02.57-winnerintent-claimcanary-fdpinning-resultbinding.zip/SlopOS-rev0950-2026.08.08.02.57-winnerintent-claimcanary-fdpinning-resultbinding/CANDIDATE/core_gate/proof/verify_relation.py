#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import deque
from dataclasses import dataclass, replace
from pathlib import Path

EVENTS = (
    "bind_evidence_alpha", "bind_evidence_beta",
    "appraise_allow_alpha", "appraise_allow_beta",
    "appraise_deny_alpha", "appraise_deny_beta",
    "decide_allow_alpha", "decide_allow_beta",
    "decide_deny_alpha", "decide_deny_beta",
    "mint_permit", "enter_exact", "enter_subject_mismatch",
    "enter_malformed", "enter_route_override", "endpoint_effect",
    "endpoint_no_effect", "endpoint_nonreturn", "endpoint_malformed",
    "reconcile_effect", "reconcile_no_effect", "reconcile_mismatch",
    "publish", "restart", "recover_mint_attempt", "proposer_route_override",
)


@dataclass(frozen=True, order=True)
class State:
    phase: str = "empty"
    evidence_subject: str = "none"
    appraisal_subject: str = "none"
    appraisal: str = "none"
    decision_subject: str = "none"
    decision: str = "none"
    dispatch: str = "not_issued"
    result: str = "none"
    published: bool = False
    recovered: bool = False
    effect_count: int = 0

    def key(self) -> str:
        return "|".join((
            self.phase, self.evidence_subject, self.appraisal_subject,
            self.appraisal, self.decision_subject, self.decision,
            self.dispatch, self.result,
            "1" if self.published else "0",
            "1" if self.recovered else "0", str(self.effect_count),
        ))


@dataclass(frozen=True)
class Step:
    outcome: str
    state: State
    effect_emitted: bool = False
    permit_consumed: bool = False


def subject(event: str) -> str:
    if event.endswith("_alpha"):
        return "alpha"
    if event.endswith("_beta"):
        return "beta"
    return "none"


def reject(state: State) -> Step:
    return Step("rejected", state)


def transition(before: State, event: str) -> Step:
    if event in {"bind_evidence_alpha", "bind_evidence_beta"}:
        if before.phase != "empty":
            return reject(before)
        return Step("applied", replace(
            before, phase="evidenced", evidence_subject=subject(event)))

    if event.startswith("appraise_"):
        named = subject(event)
        if before.phase != "evidenced" or before.evidence_subject != named:
            return reject(before)
        appraisal = "allow" if "_allow_" in event else "deny"
        return Step("applied", replace(
            before, phase="appraised", appraisal_subject=named,
            appraisal=appraisal))

    if event.startswith("decide_"):
        named = subject(event)
        allow = "_allow_" in event
        if before.phase != "appraised" or before.evidence_subject != named:
            return reject(before)
        if allow and before.appraisal != "allow":
            return reject(before)
        return Step("applied", replace(
            before, phase="decided", decision_subject=named,
            decision="allow" if allow else "deny"))

    if event == "mint_permit":
        exact = (
            before.phase == "decided"
            and before.appraisal == "allow"
            and before.decision == "allow"
            and before.evidence_subject == before.appraisal_subject
            and before.evidence_subject == before.decision_subject
            and before.dispatch == "not_issued"
        )
        if not exact:
            return reject(before)
        return Step("applied", replace(
            before, phase="permit_live", dispatch="live"))

    if event in {"enter_exact", "enter_subject_mismatch",
                 "enter_malformed", "enter_route_override"}:
        if before.phase != "permit_live" or before.dispatch != "live":
            return reject(before)
        if event == "enter_exact":
            after = replace(before, phase="entered", dispatch="entered")
        else:
            after = replace(before, phase="terminal", dispatch="burned",
                            result="fail_stop")
        return Step("applied", after, permit_consumed=True)

    if event in {"endpoint_effect", "endpoint_no_effect",
                 "endpoint_nonreturn", "endpoint_malformed"}:
        if before.phase != "entered" or before.dispatch != "entered":
            return reject(before)
        if event == "endpoint_effect":
            return Step("applied", replace(
                before, phase="terminal", dispatch="terminal",
                result="effect", effect_count=1), effect_emitted=True)
        if event == "endpoint_no_effect":
            return Step("applied", replace(
                before, phase="terminal", dispatch="terminal",
                result="no_effect"))
        return Step("applied", replace(
            before, phase="terminal", dispatch="burned",
            result="uncertain"))

    if event in {"reconcile_effect", "reconcile_no_effect"}:
        if (before.phase != "terminal" or before.result != "uncertain"
                or before.dispatch != "burned"):
            return reject(before)
        if event == "reconcile_effect":
            return Step("applied", replace(
                before, dispatch="terminal", result="effect", effect_count=1))
        return Step("applied", replace(
            before, dispatch="terminal", result="no_effect", effect_count=0))

    if event == "publish":
        if before.phase != "terminal" or before.result == "none":
            return reject(before)
        return Step("applied", replace(
            before, phase="published", published=True))

    if event == "restart":
        live = before.phase == "permit_live" and before.dispatch == "live"
        entered = before.phase == "entered" and before.dispatch == "entered"
        if not live and not entered:
            return reject(before)
        return Step("applied", replace(
            before, phase="terminal", dispatch="burned",
            result="uncertain", recovered=True), permit_consumed=live)

    # Mismatched reconciliation, recovery minting, and proposer route
    # selection are explicit state-preserving denials.
    return reject(before)


def invariant(s: State) -> bool:
    if s.effect_count not in (0, 1):
        return False
    if s.published != (s.phase == "published"):
        return False
    if s.effect_count == 1 and s.result != "effect":
        return False
    if s.result == "effect" and s.effect_count != 1:
        return False
    if s.result != "none" and s.phase not in {"terminal", "published"}:
        return False
    if s.phase in {"terminal", "published"} and s.result == "none":
        return False
    if s.phase == "empty":
        return s == State()
    if s.evidence_subject == "none":
        return False
    if s.phase == "evidenced":
        return (s.appraisal_subject == "none" and s.appraisal == "none"
                and s.decision_subject == "none" and s.decision == "none"
                and s.dispatch == "not_issued" and s.result == "none"
                and not s.recovered)
    if s.appraisal_subject != s.evidence_subject or s.appraisal == "none":
        return False
    if s.phase == "appraised":
        return (s.decision_subject == "none" and s.decision == "none"
                and s.dispatch == "not_issued" and s.result == "none"
                and not s.recovered)
    if s.decision_subject != s.evidence_subject or s.decision == "none":
        return False
    if s.decision == "allow" and s.appraisal != "allow":
        return False
    if s.phase == "decided":
        return s.dispatch == "not_issued" and s.result == "none" and not s.recovered
    if s.phase == "permit_live":
        return (s.decision == "allow" and s.dispatch == "live"
                and s.result == "none" and not s.recovered)
    if s.phase == "entered":
        return (s.decision == "allow" and s.dispatch == "entered"
                and s.result == "none" and not s.recovered)
    if s.result == "fail_stop":
        return s.dispatch == "burned" and not s.recovered
    if s.result == "uncertain":
        return s.dispatch == "burned"
    if s.result == "no_effect":
        return s.dispatch == "terminal" and s.effect_count == 0
    if s.result == "effect":
        return s.dispatch == "terminal" and s.effect_count == 1
    return False


def enumerate_relation() -> tuple[list[State], list[int], list[dict[str, str]]]:
    initial = State()
    states = [initial]
    depths = [0]
    ids = {initial: 0}
    edges: list[dict[str, str]] = []
    cursor = 0
    while cursor < len(states):
        before = states[cursor]
        assert invariant(before)
        for event in EVENTS:
            step = transition(before, event)
            assert invariant(step.state)
            if step.outcome == "rejected":
                assert step.state == before
                assert not step.effect_emitted and not step.permit_consumed
            if step.state not in ids:
                ids[step.state] = len(states)
                states.append(step.state)
                depths.append(depths[cursor] + 1)
            edges.append({
                "state_id": str(cursor),
                "depth": str(depths[cursor]),
                "event": event,
                "outcome": step.outcome,
                "next_state_id": str(ids[step.state]),
                "effect_emitted": str(step.effect_emitted).lower(),
                "permit_consumed": str(step.permit_consumed).lower(),
                "before_key": before.key(),
                "after_key": step.state.key(),
            })
        cursor += 1
    return states, depths, edges


def read_tsv(path: Path, header: list[str]) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != header:
            raise ValueError(f"header {path.name}: {reader.fieldnames}")
        rows = list(reader)
    if any(any(value is None for value in row.values()) for row in rows):
        raise ValueError(f"short row {path.name}")
    return rows


def expected_state_rows(states: list[State], depths: list[int]) -> list[dict[str, str]]:
    result = []
    for index, (s, depth) in enumerate(zip(states, depths, strict=True)):
        result.append({
            "state_id": str(index), "depth": str(depth), "phase": s.phase,
            "evidence_subject": s.evidence_subject,
            "appraisal_subject": s.appraisal_subject,
            "appraisal": s.appraisal,
            "decision_subject": s.decision_subject,
            "decision": s.decision, "dispatch": s.dispatch,
            "result": s.result, "published": str(s.published).lower(),
            "recovered": str(s.recovered).lower(),
            "effect_count": str(s.effect_count), "state_key": s.key(),
        })
    return result


def witness_edge(edges: list[dict[str, str]], states: list[State], *,
                 phase: str, result: str, recovered: bool,
                 event: str) -> dict[str, str]:
    for edge in edges:
        state = states[int(edge["state_id"])]
        if (state.phase == phase and state.result == result
                and state.recovered == recovered and edge["event"] == event):
            return edge
    raise ValueError(f"missing witness {event}")


def expected_witnesses(edges: list[dict[str, str]], states: list[State]) -> list[dict[str, str]]:
    specs = (
        ("entry_subject_mismatch_burns_permit", "permit_live", "none", False, "enter_subject_mismatch"),
        ("entry_malformed_burns_permit", "permit_live", "none", False, "enter_malformed"),
        ("entry_route_override_burns_permit", "permit_live", "none", False, "enter_route_override"),
        ("restart_live_permit_becomes_uncertain", "permit_live", "none", False, "restart"),
        ("restart_after_entry_becomes_uncertain", "entered", "none", False, "restart"),
        ("reconciliation_mismatch_preserves_uncertainty", "terminal", "uncertain", True, "reconcile_mismatch"),
        ("exact_reconciliation_can_establish_no_effect", "terminal", "uncertain", True, "reconcile_no_effect"),
        ("endpoint_effect_emits_once", "entered", "none", False, "endpoint_effect"),
        ("recovery_mint_is_rejected", "terminal", "uncertain", True, "recover_mint_attempt"),
    )
    rows = []
    for name, phase, result, recovered, event in specs:
        edge = witness_edge(edges, states, phase=phase, result=result,
                            recovered=recovered, event=event)
        after = states[int(edge["next_state_id"])]
        rows.append({
            "name": name,
            "state_id": edge["state_id"],
            "event": edge["event"],
            "outcome": edge["outcome"],
            "next_state_id": edge["next_state_id"],
            "permit_consumed": edge["permit_consumed"],
            "effect_emitted": edge["effect_emitted"],
            "after_result": after.result,
        })
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Independently reconstruct the rev0885 core-gate relation.")
    parser.add_argument("--campaign", required=True, type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()

    states, depths, edges = enumerate_relation()
    observed_states = read_tsv(campaign / "states.tsv", [
        "state_id", "depth", "phase", "evidence_subject",
        "appraisal_subject", "appraisal", "decision_subject", "decision",
        "dispatch", "result", "published", "recovered", "effect_count",
        "state_key",
    ])
    observed_edges = read_tsv(campaign / "relation.tsv", [
        "state_id", "depth", "event", "outcome", "next_state_id",
        "effect_emitted", "permit_consumed", "before_key", "after_key",
    ])
    observed_witnesses = read_tsv(campaign / "witnesses.tsv", [
        "name", "state_id", "event", "outcome", "next_state_id",
        "permit_consumed", "effect_emitted", "after_result",
    ])
    if observed_states != expected_state_rows(states, depths):
        raise SystemExit("CORE_GATE_AUDIT=FAIL detail=state relation divergence")
    if observed_edges != edges:
        raise SystemExit("CORE_GATE_AUDIT=FAIL detail=edge relation divergence")
    if observed_witnesses != expected_witnesses(edges, states):
        raise SystemExit("CORE_GATE_AUDIT=FAIL detail=witness divergence")

    summary = json.loads((campaign / "summary.json").read_text(encoding="utf-8"))
    applied = sum(row["outcome"] == "applied" for row in edges)
    permit_consuming = sum(row["permit_consumed"] == "true" for row in edges)
    failed_burn = sum(
        row["permit_consumed"] == "true"
        and row["event"] in {"enter_subject_mismatch", "enter_malformed", "enter_route_override"}
        for row in edges
    )
    expected_summary = {
        "schema": "slopos.rev0885.core-gate-summary.v1",
        "status": "PASS",
        "states": len(states),
        "transitions": len(edges),
        "events_per_state": len(EVENTS),
        "applied": applied,
        "rejected": len(edges) - applied,
        "maximum_depth": max(depths),
        "candidate_reference_disagreements": 0,
        "permit_consuming_edges": permit_consuming,
        "failed_entry_burn_edges": failed_burn,
        "maximum_effect_count": max(s.effect_count for s in states),
        "recovery_mints": 0,
        "proposer_selected_routes": 0,
        "authenticated_evidence": False,
        "protected_effect": False,
        "durable_storage_proved": False,
        "independent_actor": False,
    }
    if summary != expected_summary:
        raise SystemExit("CORE_GATE_AUDIT=FAIL detail=summary divergence")

    # Global proof obligations over all edges and reachable states.
    for state in states:
        if not invariant(state) or state.effect_count > 1:
            raise SystemExit("CORE_GATE_AUDIT=FAIL detail=invariant")
    for edge in edges:
        before = states[int(edge["state_id"])]
        after = states[int(edge["next_state_id"])]
        if edge["outcome"] == "rejected" and before != after:
            raise SystemExit("CORE_GATE_AUDIT=FAIL detail=rejection mutation")
        if edge["event"] in {"enter_subject_mismatch", "enter_malformed", "enter_route_override"} \
                and before.phase == "permit_live":
            if not (edge["permit_consumed"] == "true" and after.result == "fail_stop"
                    and after.dispatch == "burned"):
                raise SystemExit("CORE_GATE_AUDIT=FAIL detail=entry burn")
        if before.recovered and edge["event"] in {"mint_permit", "recover_mint_attempt"} \
                and edge["outcome"] != "rejected":
            raise SystemExit("CORE_GATE_AUDIT=FAIL detail=recovery mint")
        if before.result == "uncertain" and edge["event"] == "reconcile_mismatch" \
                and before != after:
            raise SystemExit("CORE_GATE_AUDIT=FAIL detail=uncertain narrowed by mismatch")

    audit = {
        "schema": "slopos.rev0885.core-gate-audit.v1",
        "status": "PASS",
        "states": len(states),
        "transitions": len(edges),
        "events_per_state": len(EVENTS),
        "candidate_reference_disagreements": 0,
        "python_relation_disagreements": 0,
        "maximum_effect_count": 1,
        "failed_entry_burn_edges": failed_burn,
        "recovery_mints": 0,
        "proposer_selected_routes": 0,
        "protected_effect": False,
        "authenticated_evidence": False,
        "independent_actor": False,
    }
    if args.json is not None:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "CORE_GATE_AUDIT=PASS "
        f"states={len(states)} transitions={len(edges)} events={len(EVENTS)} "
        f"failed_entry_burn_edges={failed_burn} max_effect=1 "
        "recovery_mints=0 authority=false protected_effect=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
