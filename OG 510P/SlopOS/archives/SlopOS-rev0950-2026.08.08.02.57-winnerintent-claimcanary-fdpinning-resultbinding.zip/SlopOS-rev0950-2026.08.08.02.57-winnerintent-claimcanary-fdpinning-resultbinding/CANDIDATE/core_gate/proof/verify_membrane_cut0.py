#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import os
import tempfile
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
CORE = HERE.parent

EXPECTED: dict[str, tuple[str, str, bool, bool, bool]] = {
    "closed_deny": ("closed_deny", "none", False, False, False),
    "closed_indeterminate": ("closed_indeterminate", "none", False, False, False),
    "appraisal_pass_no_permit": ("appraisal_pass_no_permit", "none", False, False, False),
    "permit_record_bound": ("permit_record_bound", "none", True, False, False),
    "terminal_effect": ("terminal_record_bound", "none", True, True, False),
    "terminal_no_effect": ("terminal_record_bound", "none", True, True, False),
    "terminal_uncertain": ("terminal_record_bound", "none", True, True, False),
    "terminal_fail_stop": ("terminal_record_bound", "none", True, True, False),
    "reopen_record_bound": ("reopen_record_bound", "none", True, True, True),
    "reject_subject_incomplete": ("rejected", "subject_incomplete", False, False, False),
    "reject_evidence_incomplete": ("rejected", "evidence_incomplete", False, False, False),
    "reject_evidence_subject_mismatch": ("rejected", "evidence_subject_mismatch", False, False, False),
    "reject_appraisal_incomplete": ("rejected", "appraisal_incomplete", False, False, False),
    "reject_appraisal_subject_mismatch": ("rejected", "appraisal_subject_mismatch", False, False, False),
    "reject_appraisal_evidence_mismatch": ("rejected", "appraisal_evidence_mismatch", False, False, False),
    "reject_appraisal_policy_mismatch": ("rejected", "appraisal_policy_mismatch", False, False, False),
    "reject_appraisal_verdict_invalid": ("rejected", "appraisal_verdict_invalid", False, False, False),
    "reject_post_closed_material": ("rejected", "post_closed_material", False, False, False),
    "reject_terminal_without_permit": ("rejected", "terminal_without_permit", False, False, False),
    "reject_reopen_without_terminal": ("rejected", "reopen_without_terminal", False, False, False),
    "reject_permit_incomplete": ("rejected", "permit_incomplete", False, False, False),
    "reject_permit_subject_mismatch": ("rejected", "permit_subject_mismatch", False, False, False),
    "reject_permit_appraisal_mismatch": ("rejected", "permit_appraisal_mismatch", False, False, False),
    "reject_terminal_incomplete": ("rejected", "terminal_incomplete", False, False, False),
    "reject_terminal_permit_mismatch": ("rejected", "terminal_permit_mismatch", False, False, False),
    "reject_terminal_effect_mismatch": ("rejected", "terminal_effect_mismatch", False, False, False),
    "reject_terminal_class_invalid": ("rejected", "terminal_class_invalid", False, False, False),
    "reject_reopen_incomplete": ("rejected", "reopen_incomplete", False, False, False),
    "reject_reopen_terminal_mismatch": ("rejected", "reopen_terminal_mismatch", False, False, False),
    "reject_reopen_class_mismatch": ("rejected", "reopen_class_mismatch", False, False, False),
    "reject_reopen_same_administration_label": ("rejected", "reopen_same_administration_label", False, False, False),
}


def fail(detail: str) -> None:
    raise SystemExit(f"MEMBRANE_CUT0_PROOF=FAIL detail={detail}")


def truth(value: bool) -> str:
    return "true" if value else "false"


def independent_mutation_counts() -> dict[str, int]:
    # Each nonzero mask activates at least one rejection predicate. Protocol
    # order selects the fault, but status counts need no candidate implementation.
    counts: Counter[str] = Counter()
    for mask in range(1 << 12):
        counts["reopen_record_bound" if mask == 0 else "rejected"] += 1
    return dict(counts)


def verify_source_separation() -> None:
    candidate = (CORE / "src/membrane_cut0.cpp").read_text(encoding="utf-8")
    reference = (CORE / "src/membrane_cut0_reference.cpp").read_text(encoding="utf-8")
    if "membrane_cut0_reference.hpp" in candidate or "reference::evaluate" in candidate:
        fail("candidate-imports-reference")
    if "membrane_cut0.cpp" in reference:
        fail("reference-imports-candidate-source")
    if "return cut0::evaluate" in reference or "return ::slopos::e0::core_gate::cut0::evaluate" in reference:
        fail("reference-calls-candidate")
    if candidate == reference:
        fail("identical-source")


def verify_obligations() -> None:
    with (HERE / "MEMBRANE-CUT0-OBLIGATIONS.tsv").open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != ["id", "claim", "witness", "status", "limit"]:
            fail("obligation-header")
        rows = list(reader)
    if len(rows) != 18:
        fail(f"obligations={len(rows)}")
    if [row["id"] for row in rows] != [f"C0-{number:02d}" for number in range(1, 19)]:
        fail("obligation-ids")
    if any(row["status"] != "PASS" or not row["claim"] or not row["witness"] or not row["limit"] for row in rows):
        fail("obligation-status-or-empty-field")


def audit(output: Path) -> dict[str, object]:
    summary = json.loads((output / "summary.json").read_text(encoding="utf-8"))
    scalar: dict[str, object] = {
        "schema": "slopos.rev0929.membrane-cut0.campaign.v1",
        "status": "PASS",
        "record_classes": 6,
        "curated_cases": 31,
        "mutation_cases": 4096,
        "total_cases": 4127,
        "candidate_reference_disagreements": 0,
        "curated_expectation_failures": 0,
        "authority_granted": False,
        "current_policy_proved": False,
        "permit_authority_proved": False,
        "effect_occurrence_proved": False,
        "external_occurrence_proved": False,
        "administrative_independence_proved": False,
        "global_one_use_proved": False,
        "epoch_exit_proved": False,
    }
    for key, value in scalar.items():
        if summary.get(key) != value:
            fail(f"summary={key}:{summary.get(key)!r}")
    expected_mutations = independent_mutation_counts()
    if summary.get("mutation_status_counts") != expected_mutations:
        fail("mutation-status-counts")

    with (output / "curated.tsv").open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        wanted_header = [
            "name", "expected_status", "expected_fault", "candidate_status",
            "candidate_fault", "reference_status", "reference_fault",
            "permit_record_bound", "terminal_record_bound",
            "administration_labels_distinct",
        ]
        if reader.fieldnames != wanted_header:
            fail("curated-header")
        rows = list(reader)
    if len(rows) != len(EXPECTED) or {row["name"] for row in rows} != set(EXPECTED):
        fail("curated-case-set")
    for row in rows:
        status, fault, permit_bound, terminal_bound, labels_distinct = EXPECTED[row["name"]]
        wanted = {
            "expected_status": status,
            "expected_fault": fault,
            "candidate_status": status,
            "candidate_fault": fault,
            "reference_status": status,
            "reference_fault": fault,
            "permit_record_bound": truth(permit_bound),
            "terminal_record_bound": truth(terminal_bound),
            "administration_labels_distinct": truth(labels_distinct),
        }
        for key, value in wanted.items():
            if row.get(key) != value:
                fail(f"curated={row['name']}:{key}:{row.get(key)!r}")

    verify_source_separation()
    verify_obligations()
    return {
        "schema": "slopos.rev0929.membrane-cut0.audit.v1",
        "status": "PASS",
        "record_classes": 6,
        "curated_cases": 31,
        "mutation_cases": 4096,
        "total_cases": 4127,
        "candidate_reference_disagreements": 0,
        "curated_expectation_failures": 0,
        "obligations": 18,
        "mutation_status_counts": expected_mutations,
        "candidate_reference_source_separated": True,
        "authority_granted": False,
        "current_policy_proved": False,
        "permit_authority_proved": False,
        "effect_occurrence_proved": False,
        "administrative_independence_proved": False,
        "global_one_use_proved": False,
        "epoch_exit_proved": False,
    }


def write_new(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(path, flags, 0o644)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        os.close(fd)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path, help="campaign output directory")
    parser.add_argument("--json", type=Path, help="write deterministic audit JSON to an absent path")
    args = parser.parse_args()
    result = audit(args.output.resolve())
    if args.json is not None:
        payload = (json.dumps(result, indent=2, sort_keys=True) + "\n").encode("utf-8")
        write_new(args.json.resolve(), payload)
    print(
        "MEMBRANE_CUT0_PROOF=PASS revision=rev0929 records=6 curated=31 "
        "mutations=4096 total=4127 candidate_reference_disagreements=0 "
        "obligations=18 authority=false current_policy=false permit_authority=false "
        "effect_occurrence=false administrative_independence=false global_one_use=false epoch_zero=true"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
