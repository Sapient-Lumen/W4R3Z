#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any

MEMBRANE_DOMAIN = b"SlopOS/e0/nonpromotion/membrane/v2"
DOSSIER_DOMAIN = b"SlopOS/e0/nonpromotion/dossier/v2"
MEMBRANE_BYTES = 814
PREMISE_BYTES = 138
DOSSIER_BYTES = 1934
EDGES = (
    "owner_constitution",
    "acquisition_and_appraisal_enrollment",
    "current_policy_selection",
    "protected_one_use_spend",
    "authenticated_effect_and_query",
    "independent_terminal_reopen",
    "owner_admission",
    "release_constitution",
)
MUTATIONS = (
    "missing",
    "edge_mismatch",
    "subject_zero",
    "membrane_zero",
    "witness_zero",
    "source_zero",
    "sequence_zero",
    "subject_mismatch",
    "membrane_mismatch",
    "sequence_mismatch",
)
TRACE_MUTATIONS = (
    "subject_identity_chain",
    "subject_artifact_digest",
    "appraisal_policy_chain",
    "subject_revision",
    "evidence_identity_chain",
    "evidence_payload_digest",
    "acquisition_context_digest",
    "appraisal_identity_chain",
    "permit_identity_chain",
    "effect_digest_chain",
    "spend_coordinate_digest",
    "permit_serial",
    "terminal_identity_chain",
    "terminal_predecessor_digest",
    "terminal_class_chain",
    "terminal_sequence",
    "producer_administration_label",
    "reopener_administration_label",
    "reopen_receipt_digest",
)
EXPECTED_INPUTS = (
    "commitment-vectors.tsv",
    "curated.tsv",
    "presence.tsv",
    "summary.json",
    "trace-binding.tsv",
)


def fail(detail: str) -> None:
    raise SystemExit(f"NONPROMOTION_KERNEL_PROOF=FAIL detail={detail}")


def d(marker: int) -> bytes:
    if not 0 <= marker <= 255:
        fail(f"digest-marker={marker}")
    return bytes([marker]) * 32


def u64(value: int) -> bytes:
    return value.to_bytes(8, "big", signed=False)


def domain_hash(domain: bytes, image: bytes) -> bytes:
    return hashlib.sha256(domain + b"\0" + image).digest()


def packet() -> dict[str, Any]:
    return {
        "subject": {"id": d(1), "artifact": d(2), "policy": d(3), "revision": 931},
        "evidence": {"id": d(4), "subject": d(1), "payload": d(5), "context": d(6)},
        "appraisal": {
            "id": d(7), "subject": d(1), "evidence": d(4),
            "policy": d(3), "verdict": 0,
        },
        "permit": {
            "present": True, "id": d(8), "subject": d(1), "appraisal": d(7),
            "effect": d(9), "spend": d(10), "serial": 1,
        },
        "terminal": {
            "present": True, "id": d(11), "permit": d(8), "effect": d(9),
            "predecessor": d(12), "class": 1, "sequence": 1,
        },
        "reopen": {
            "present": True, "terminal": d(11), "class": 1,
            "producer": d(13), "reopener": d(14), "receipt": d(15),
        },
    }


def encode_membrane(p: dict[str, Any]) -> bytes:
    s = p["subject"]
    e = p["evidence"]
    a = p["appraisal"]
    permit = p["permit"]
    terminal = p["terminal"]
    reopen = p["reopen"]
    image = b"".join((
        b"SLOPMEM2", u64(2),
        s["id"], s["artifact"], s["policy"], u64(s["revision"]),
        e["id"], e["subject"], e["payload"], e["context"],
        a["id"], a["subject"], a["evidence"], a["policy"], bytes([a["verdict"]]),
        bytes([int(permit["present"])]), permit["id"], permit["subject"],
        permit["appraisal"], permit["effect"], permit["spend"], u64(permit["serial"]),
        bytes([int(terminal["present"])]), terminal["id"], terminal["permit"],
        terminal["effect"], terminal["predecessor"], bytes([terminal["class"]]),
        u64(terminal["sequence"]),
        bytes([int(reopen["present"])]), reopen["terminal"], bytes([reopen["class"]]),
        reopen["producer"], reopen["reopener"], reopen["receipt"],
    ))
    if len(image) != MEMBRANE_BYTES:
        fail(f"python-membrane-size={len(image)}")
    return image


def make_dossier() -> dict[str, Any]:
    p = packet()
    membrane = domain_hash(MEMBRANE_DOMAIN, encode_membrane(p))
    records = []
    for index in range(8):
        records.append({
            "present": True,
            "edge": index,
            "subject": p["subject"]["id"],
            "membrane": membrane,
            "witness": d(20 + index),
            "source": d(40 + index),
            "sequence": index + 1,
        })
    return {"membrane": p, "records": records}


def encode_dossier(value: dict[str, Any]) -> bytes:
    chunks = [b"SLOPDOS2", u64(2), encode_membrane(value["membrane"])]
    for record in value["records"]:
        chunks.extend((
            bytes([int(record["present"])]),
            bytes([record["edge"]]),
            record["subject"], record["membrane"], record["witness"], record["source"],
            u64(record["sequence"]),
        ))
    image = b"".join(chunks)
    if len(image) != DOSSIER_BYTES:
        fail(f"python-dossier-size={len(image)}")
    return image


def membrane_commitment(value: dict[str, Any]) -> bytes:
    return domain_hash(MEMBRANE_DOMAIN, encode_membrane(value["membrane"]))


def dossier_commitment(value: dict[str, Any]) -> bytes:
    return domain_hash(DOSSIER_DOMAIN, encode_dossier(value))


def apply_record_mutation(value: dict[str, Any], slot: int, mutation: str) -> None:
    record = value["records"][slot]
    if mutation == "missing":
        record["present"] = False
    elif mutation == "edge_mismatch":
        record["edge"] = 255
    elif mutation == "subject_zero":
        record["subject"] = bytes(32)
    elif mutation == "membrane_zero":
        record["membrane"] = bytes(32)
    elif mutation == "witness_zero":
        record["witness"] = bytes(32)
    elif mutation == "source_zero":
        record["source"] = bytes(32)
    elif mutation == "sequence_zero":
        record["sequence"] = 0
    elif mutation == "subject_mismatch":
        record["subject"] = d(160 + slot)
    elif mutation == "membrane_mismatch":
        record["membrane"] = d(180 + slot)
    elif mutation == "sequence_mismatch":
        record["sequence"] = slot + 9
    else:
        fail(f"unknown-mutation={mutation}")


def apply_trace_mutation(value: dict[str, Any], mutation: str) -> None:
    p = value["membrane"]
    if mutation == "subject_identity_chain":
        replacement = d(101)
        p["subject"]["id"] = replacement
        p["evidence"]["subject"] = replacement
        p["appraisal"]["subject"] = replacement
        p["permit"]["subject"] = replacement
        for record in value["records"]:
            record["subject"] = replacement
    elif mutation == "subject_artifact_digest":
        p["subject"]["artifact"] = d(102)
    elif mutation == "appraisal_policy_chain":
        p["subject"]["policy"] = d(103)
        p["appraisal"]["policy"] = d(103)
    elif mutation == "subject_revision":
        p["subject"]["revision"] = 932
    elif mutation == "evidence_identity_chain":
        p["evidence"]["id"] = d(104)
        p["appraisal"]["evidence"] = d(104)
    elif mutation == "evidence_payload_digest":
        p["evidence"]["payload"] = d(105)
    elif mutation == "acquisition_context_digest":
        p["evidence"]["context"] = d(106)
    elif mutation == "appraisal_identity_chain":
        p["appraisal"]["id"] = d(107)
        p["permit"]["appraisal"] = d(107)
    elif mutation == "permit_identity_chain":
        p["permit"]["id"] = d(108)
        p["terminal"]["permit"] = d(108)
    elif mutation == "effect_digest_chain":
        p["permit"]["effect"] = d(109)
        p["terminal"]["effect"] = d(109)
    elif mutation == "spend_coordinate_digest":
        p["permit"]["spend"] = d(110)
    elif mutation == "permit_serial":
        p["permit"]["serial"] = 2
    elif mutation == "terminal_identity_chain":
        p["terminal"]["id"] = d(111)
        p["reopen"]["terminal"] = d(111)
    elif mutation == "terminal_predecessor_digest":
        p["terminal"]["predecessor"] = d(112)
    elif mutation == "terminal_class_chain":
        p["terminal"]["class"] = 2
        p["reopen"]["class"] = 2
    elif mutation == "terminal_sequence":
        p["terminal"]["sequence"] = 2
    elif mutation == "producer_administration_label":
        p["reopen"]["producer"] = d(113)
    elif mutation == "reopener_administration_label":
        p["reopen"]["reopener"] = d(114)
    elif mutation == "reopen_receipt_digest":
        p["reopen"]["receipt"] = d(115)
    else:
        fail(f"unknown-trace-mutation={mutation}")


def record_expectation(mutation: str, slot: int) -> tuple[str, str, int, str]:
    if mutation == "missing":
        return "premise_record_missing", "premise_missing", slot, EDGES[slot]
    if mutation == "edge_mismatch":
        return "premise_edge_mismatch", "premise_edge_mismatch", slot, EDGES[slot]
    if mutation in {"subject_zero", "membrane_zero", "witness_zero", "source_zero", "sequence_zero"}:
        return "premise_record_incomplete", "premise_incomplete", slot, EDGES[slot]
    if mutation == "subject_mismatch":
        return "premise_subject_mismatch", "premise_subject_mismatch", slot, EDGES[slot]
    if mutation == "membrane_mismatch":
        return "premise_membrane_mismatch", "premise_membrane_mismatch", slot, EDGES[slot]
    if mutation == "sequence_mismatch":
        return "premise_sequence_mismatch", "premise_sequence_mismatch", slot, EDGES[slot]
    fail(f"expectation-mutation={mutation}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        result = list(reader)
    if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
        fail(f"header={path.name}")
    return result


def same_eval(row: dict[str, str], expected: tuple[str, str, int, str], *, flags: tuple[str, str]) -> None:
    status, fault, bound, first_open = expected
    for key in ("expected_status", "candidate_status", "reference_status"):
        if row[key] != status:
            fail(f"{key}={row.get('case', row.get('mask', '?'))}:{row[key]}")
    for key in ("expected_fault", "candidate_fault", "reference_fault"):
        if row[key] != fault:
            fail(f"{key}={row.get('case', row.get('mask', '?'))}:{row[key]}")
    for key in ("expected_bound", "candidate_bound", "reference_bound"):
        if row[key] != str(bound):
            fail(f"{key}={row.get('case', row.get('mask', '?'))}:{row[key]}")
    for key in ("expected_first_open", "candidate_first_open", "reference_first_open"):
        if row[key] != first_open:
            fail(f"{key}={row.get('case', row.get('mask', '?'))}:{row[key]}")
    if row.get("membrane_reopen_record_bound") != flags[0] \
            or row.get("all_external_records_bound") != flags[1]:
        fail(f"flags={row.get('case', '?')}")
    if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
        fail(f"promotion={row.get('case', row.get('mask', '?'))}")


def require_hex(value: str, size: int, label: str) -> bytes:
    if not re.fullmatch(r"[0-9a-f]+", value) or len(value) != size * 2:
        fail(f"hex={label}")
    return bytes.fromhex(value)


def verify_vectors(directory: Path, baseline: dict[str, Any]) -> tuple[str, str, int]:
    vector_rows = rows(directory / "commitment-vectors.tsv")
    if [row["vector"] for row in vector_rows] != [
        "baseline_membrane", "baseline_dossier", "absent_payload_a", "absent_payload_b"
    ]:
        fail("vector-order")

    absent_a = deepcopy(baseline)
    absent_a["records"][0]["present"] = False
    absent_b = deepcopy(absent_a)
    absent_b["records"][0]["witness"] = d(240)
    expected = (
        ("membrane", encode_membrane(baseline["membrane"]), membrane_commitment(baseline)),
        ("dossier", encode_dossier(baseline), dossier_commitment(baseline)),
        ("dossier", encode_dossier(absent_a), dossier_commitment(absent_a)),
        ("dossier", encode_dossier(absent_b), dossier_commitment(absent_b)),
    )
    for row, (kind, image, commitment) in zip(vector_rows, expected, strict=True):
        if row["object"] != kind or int(row["bytes"]) != len(image):
            fail(f"vector-shape={row['vector']}")
        if require_hex(row["image_hex"], len(image), row["vector"]) != image:
            fail(f"vector-image={row['vector']}")
        if require_hex(row["commitment"], 32, row["vector"]) != commitment:
            fail(f"vector-commitment={row['vector']}")
    if expected[2][2] == expected[3][2]:
        fail("absent-payload-unbound")

    baseline_image = expected[0][1]
    baseline_hash = expected[0][2]
    byte_flip_checks = 0
    for index in range(len(baseline_image)):
        mutated = bytearray(baseline_image)
        mutated[index] ^= 0x01
        if domain_hash(MEMBRANE_DOMAIN, bytes(mutated)) == baseline_hash:
            fail(f"byte-flip-collision={index}")
        byte_flip_checks += 1
    return expected[0][2].hex(), expected[1][2].hex(), byte_flip_checks


def verify_curated(directory: Path, baseline: dict[str, Any]) -> None:
    curated = rows(directory / "curated.tsv")
    if len(curated) != 83 or len({row["case"] for row in curated}) != 83:
        fail(f"curated-count={len(curated)}")

    expected_rows: list[tuple[str, dict[str, Any], tuple[str, str, int, str], tuple[str, str]]] = []
    expected_rows.append((
        "all_external_records_bound", deepcopy(baseline),
        ("external_record_set_bound", "none", 8, "none"), ("true", "true")))
    rejected = deepcopy(baseline)
    rejected["membrane"]["subject"]["id"] = bytes(32)
    expected_rows.append((
        "membrane_relation_rejected", rejected,
        ("membrane_rejected", "membrane_relation_rejected", 0, EDGES[0]),
        ("false", "false")))
    prefix = deepcopy(baseline)
    prefix["membrane"]["reopen"]["present"] = False
    expected_rows.append((
        "membrane_reopen_absent", prefix,
        ("membrane_prefix_incomplete", "membrane_reopen_record_absent", 0, EDGES[0]),
        ("false", "false")))
    for slot, edge in enumerate(EDGES):
        for mutation in MUTATIONS:
            value = deepcopy(baseline)
            apply_record_mutation(value, slot, mutation)
            expected_rows.append((
                f"{mutation}_{edge}", value, record_expectation(mutation, slot),
                ("true", "false")))

    for row, (name, value, expected, flags) in zip(curated, expected_rows, strict=True):
        if row["case"] != name:
            fail(f"curated-order={row['case']}:{name}")
        same_eval(row, expected, flags=flags)
        if require_hex(row["membrane_commitment"], 32, f"curated-membrane:{name}") \
                != membrane_commitment(value):
            fail(f"curated-membrane={name}")
        if require_hex(row["dossier_commitment"], 32, f"curated-dossier:{name}") \
                != dossier_commitment(value):
            fail(f"curated-dossier={name}")


def verify_presence(directory: Path) -> None:
    presence = rows(directory / "presence.tsv")
    if len(presence) != 256 or [int(row["mask"]) for row in presence] != list(range(256)):
        fail(f"presence-inventory={len(presence)}")
    successes = 0
    for row in presence:
        mask = int(row["mask"])
        missing = next((index for index in range(8) if not (mask & (1 << index))), None)
        if missing is None:
            expected = ("external_record_set_bound", "none", 8, "none")
            successes += 1
        else:
            expected = ("premise_record_missing", "premise_missing", missing, EDGES[missing])
        # Presence rows omit the two bound booleans; validate the common fields directly.
        status, fault, bound, first_open = expected
        for key in ("expected_status", "candidate_status", "reference_status"):
            if row[key] != status:
                fail(f"presence-status={mask}:{key}")
        for key in ("expected_bound", "candidate_bound", "reference_bound"):
            if row[key] != str(bound):
                fail(f"presence-bound={mask}:{key}")
        for key in ("expected_first_open", "candidate_first_open", "reference_first_open"):
            if row[key] != first_open:
                fail(f"presence-open={mask}:{key}")
        if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
            fail(f"presence-promotion={mask}")
    if successes != 1:
        fail(f"presence-successes={successes}")


def verify_trace(directory: Path, baseline: dict[str, Any]) -> None:
    trace = rows(directory / "trace-binding.tsv")
    if [row["case"] for row in trace] != list(TRACE_MUTATIONS):
        fail("trace-order")
    baseline_commitment = membrane_commitment(baseline)
    for row, name in zip(trace, TRACE_MUTATIONS, strict=True):
        value = deepcopy(baseline)
        apply_trace_mutation(value, name)
        mutated_membrane = membrane_commitment(value)
        mutated_dossier = dossier_commitment(value)
        if mutated_membrane == baseline_commitment:
            fail(f"trace-unchanged={name}")
        if row["cut0_status"] != "reopen_record_bound":
            fail(f"trace-cut0={name}")
        for key in ("expected_status", "candidate_status", "reference_status"):
            if row[key] != "premise_membrane_mismatch":
                fail(f"trace-status={name}:{key}")
        if require_hex(row["baseline_membrane_commitment"], 32, f"trace-base:{name}") \
                != baseline_commitment:
            fail(f"trace-base={name}")
        if require_hex(row["mutated_membrane_commitment"], 32, f"trace-membrane:{name}") \
                != mutated_membrane:
            fail(f"trace-membrane={name}")
        if require_hex(row["mutated_dossier_commitment"], 32, f"trace-dossier:{name}") \
                != mutated_dossier:
            fail(f"trace-dossier={name}")
        if row["commitment_changed"] != "true" \
                or row["authority_granted"] != "false" \
                or row["epoch_exit_proved"] != "false":
            fail(f"trace-flags={name}")


def verify_source(root: Path | None) -> None:
    if root is None:
        return
    header = root / "CANDIDATE/core_gate/include/slopos/e0/core_gate/nonpromotion_kernel.hpp"
    if not header.is_file():
        fail("header-missing")
    text = header.read_text(encoding="utf-8")
    for function in ("authority_granted", "epoch_exit_proved"):
        pattern = rf"constexpr bool {function}\([^)]*\) noexcept \{{\s*return false;\s*\}}"
        if re.search(pattern, text) is None:
            fail(f"nonpromotion-api={function}")
    for token in (
        "membrane_image_size = 814U", "premise_record_image_size = 138U",
        "dossier_image_size == 1934U", "premise_membrane_mismatch",
        "Digest membrane_commitment", "Digest dossier_commitment",
    ):
        if token not in text:
            fail(f"header-token={token}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    if not directory.is_dir():
        fail("output-directory")
    observed_inputs = tuple(sorted(path.name for path in directory.iterdir() if path.is_file()))
    if observed_inputs != EXPECTED_INPUTS:
        fail(f"input-set={observed_inputs}")

    if hashlib.sha256(b"abc").hexdigest() \
            != "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad":
        fail("sha256-known-answer")
    if DOSSIER_BYTES != 16 + MEMBRANE_BYTES + 8 * PREMISE_BYTES:
        fail("image-size-equation")

    summary = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "absent_payload_committed": True,
        "authority_granted": False,
        "candidate_reference_disagreements": 0,
        "canonical_dossier_bytes": 1934,
        "canonical_membrane_bytes": 814,
        "commitment_vectors": 4,
        "curated_cases": 83,
        "epoch_exit_proved": False,
        "external_premise_records": 8,
        "external_witness_truth_proved": False,
        "highest_status": "external_record_set_bound",
        "owner_admission_proved": False,
        "presence_cases": 256,
        "schema": "slopos.rev0931.nonpromotion-kernel-campaign.v2",
        "status": "PASS",
        "trace_binding_cases": 19,
        "total_cases": 360,
    }
    if summary != expected_summary:
        fail("summary")

    baseline = make_dossier()
    baseline_membrane, baseline_dossier, byte_flip_checks = verify_vectors(directory, baseline)
    verify_curated(directory, baseline)
    verify_presence(directory)
    verify_trace(directory, baseline)
    verify_source(args.root.resolve() if args.root else None)

    audit = {
        "absent_payload_committed": True,
        "authority_granted": False,
        "baseline_dossier_commitment": baseline_dossier,
        "baseline_membrane_commitment": baseline_membrane,
        "canonical_dossier_bytes": DOSSIER_BYTES,
        "canonical_membrane_bytes": MEMBRANE_BYTES,
        "curated_cases_verified": 83,
        "domain_separation_verified": True,
        "epoch_exit_proved": False,
        "fips_sha256_known_answer_verified": True,
        "image_byte_flip_checks": byte_flip_checks,
        "independent_python_encoder": True,
        "presence_cases_verified": 256,
        "schema": "slopos.rev0931.nonpromotion-kernel-proof.v2",
        "status": "PASS",
        "trace_binding_cases_verified": 19,
        "total_campaign_cases_verified": 360,
    }
    output = args.json or (directory / "audit.json")
    output.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "NONPROMOTION_KERNEL_PROOF=PASS curated=83 presence=256 trace_binding=19 "
        f"total=360 membrane_bytes=814 dossier_bytes=1934 byte_flips={byte_flip_checks} "
        "sha256_kat=true absent_payload_committed=true authority=false epoch_zero=true"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyError, ValueError, OSError, json.JSONDecodeError, csv.Error) as error:
        fail(f"exception={type(error).__name__}:{error}")
