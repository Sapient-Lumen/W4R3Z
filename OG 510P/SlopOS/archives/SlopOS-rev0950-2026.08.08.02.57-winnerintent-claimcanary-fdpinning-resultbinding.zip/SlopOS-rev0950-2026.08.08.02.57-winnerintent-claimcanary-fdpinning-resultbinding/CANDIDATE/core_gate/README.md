# Epoch-Zero core gate

`core_gate` is the smallest active hosted construction of the prospective SlopOS
authority membrane. It is one of three semantic islands, not an acquisition,
provider, owner, witness, signer, or release service.

Product targets:

- `slopos_core_gate` — inherited finite transition relation;
- `slopos_membrane_cut0` — six-record R1–R6 conformance relation;
- `slopos_nonpromotion_kernel` — V2 exact membrane/dossier binding around X1–X8.

Nested direct-build proof targets, absent from the product dispatcher:

- `mutation_closure/` — 3,859-case ordered pairwise final-state proof;
- `ratification_subject/` — exact 1,152-byte configured subject and
  non-self-selection proof.

The ratification subject recomputes the exact V2 membrane and dossier commitments
from current candidate and independent reference sources. Its 9,651-case
campaign checks every bit position at every byte offset, all control requirement
masks, malformed controls, context substitutions, and the self-selected-context
countermodel.

All outputs remain hosted evidence. Highest local status is
`configured_subject_bound`. Owner ratification, configured-context externality,
effect occurrence, independent reopen, living admission, authority, and epoch
exit are constant false. No path here supplies configured owner trust, protected
external state, an effect operator, or a release/living decision.
