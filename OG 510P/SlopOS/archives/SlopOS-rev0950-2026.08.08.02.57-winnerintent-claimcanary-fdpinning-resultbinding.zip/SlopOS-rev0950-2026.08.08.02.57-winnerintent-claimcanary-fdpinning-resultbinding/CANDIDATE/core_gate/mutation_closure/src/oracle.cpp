#include "slopos/e0/core_gate/mutation_closure/oracle.hpp"

#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>

namespace slopos::e0::core_gate::mutation_closure::oracle {
namespace {

using nonpromotion::Digest;
using nonpromotion::Edge;
using nonpromotion::Evaluation;
using nonpromotion::Fault;
using nonpromotion::Status;

inline constexpr std::array<Edge, nonpromotion::edge_count> kEdges{{
    Edge::owner_constitution,
    Edge::acquisition_and_appraisal_enrollment,
    Edge::current_policy_selection,
    Edge::protected_one_use_spend,
    Edge::authenticated_effect_and_query,
    Edge::independent_terminal_reopen,
    Edge::owner_admission,
    Edge::release_constitution,
}};

[[nodiscard]] bool all_zero(const Digest& value) noexcept {
    return std::all_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] constexpr Evaluation make(
    const Status status,
    const Fault fault,
    const std::size_t count,
    const Edge open,
    const bool membrane_bound,
    const bool all_bound,
    const Digest& exact_membrane,
    const Digest& exact_dossier) noexcept {
    return Evaluation{
        status,
        fault,
        static_cast<std::uint8_t>(count),
        open,
        membrane_bound,
        all_bound,
        exact_membrane,
        exact_dossier,
    };
}

}  // namespace

nonpromotion::Evaluation evaluate(
    const nonpromotion::Dossier& dossier,
    const nonpromotion::Digest& exact_membrane,
    const nonpromotion::Digest& exact_dossier) noexcept {
    const cut0::Evaluation membrane =
        cut0::reference::evaluate(dossier.membrane);
    if (membrane.status == cut0::Status::rejected) {
        return make(Status::membrane_rejected,
                    Fault::membrane_relation_rejected,
                    0U, Edge::owner_constitution, false, false,
                    exact_membrane, exact_dossier);
    }
    if (membrane.status != cut0::Status::reopen_record_bound) {
        return make(Status::membrane_prefix_incomplete,
                    Fault::membrane_reopen_record_absent,
                    0U, Edge::owner_constitution, false, false,
                    exact_membrane, exact_dossier);
    }

    for (std::size_t index = 0U; index < kEdges.size(); ++index) {
        const nonpromotion::PremiseRecord& record =
            dossier.external_records[index];
        const Edge expected = kEdges[index];
        if (!record.present) {
            return make(Status::premise_record_missing,
                        Fault::premise_missing,
                        index, expected, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.edge != expected) {
            return make(Status::premise_edge_mismatch,
                        Fault::premise_edge_mismatch,
                        index, expected, true, false,
                        exact_membrane, exact_dossier);
        }
        if (all_zero(record.subject_id)
            || all_zero(record.membrane_commitment)
            || all_zero(record.witness_digest)
            || all_zero(record.source_identity_digest)
            || record.sequence == 0U) {
            return make(Status::premise_record_incomplete,
                        Fault::premise_incomplete,
                        index, expected, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.subject_id != dossier.membrane.subject.id) {
            return make(Status::premise_subject_mismatch,
                        Fault::premise_subject_mismatch,
                        index, expected, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.membrane_commitment != exact_membrane) {
            return make(Status::premise_membrane_mismatch,
                        Fault::premise_membrane_mismatch,
                        index, expected, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.sequence != static_cast<std::uint64_t>(index) + 1U) {
            return make(Status::premise_sequence_mismatch,
                        Fault::premise_sequence_mismatch,
                        index, expected, true, false,
                        exact_membrane, exact_dossier);
        }
    }

    return make(Status::external_record_set_bound, Fault::none,
                kEdges.size(), Edge::none, true, true,
                exact_membrane, exact_dossier);
}

}  // namespace slopos::e0::core_gate::mutation_closure::oracle
