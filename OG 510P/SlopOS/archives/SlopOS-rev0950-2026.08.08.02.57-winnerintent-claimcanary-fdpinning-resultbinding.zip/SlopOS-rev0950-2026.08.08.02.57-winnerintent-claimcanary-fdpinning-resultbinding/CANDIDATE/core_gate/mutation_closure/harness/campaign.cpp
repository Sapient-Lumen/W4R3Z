#include "slopos/e0/core_gate/mutation_closure/oracle.hpp"

#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"
#include "slopos/e0/core_gate/nonpromotion_kernel.hpp"
#include "slopos/e0/core_gate/nonpromotion_kernel_reference.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>

namespace slopos::e0::core_gate::mutation_closure {
namespace {

namespace np = nonpromotion;

enum class Mutation : std::uint8_t {
    missing,
    edge_mismatch,
    subject_zero,
    membrane_zero,
    witness_zero,
    source_zero,
    sequence_zero,
    subject_mismatch,
    membrane_mismatch,
    sequence_mismatch,
};

inline constexpr std::array<Mutation, 10U> kMutations{{
    Mutation::missing,
    Mutation::edge_mismatch,
    Mutation::subject_zero,
    Mutation::membrane_zero,
    Mutation::witness_zero,
    Mutation::source_zero,
    Mutation::sequence_zero,
    Mutation::subject_mismatch,
    Mutation::membrane_mismatch,
    Mutation::sequence_mismatch,
}};

struct Observed final {
    np::Evaluation candidate;
    np::Evaluation reference;
    np::Evaluation closure_oracle;
};

[[nodiscard]] np::Digest digest(const std::uint8_t marker) {
    np::Digest value{};
    value.fill(marker);
    return value;
}

[[nodiscard]] cut0::Packet complete_membrane() {
    cut0::Packet packet{};
    packet.subject = cut0::SubjectRecord{
        digest(1U), digest(2U), digest(3U), 931U};
    packet.evidence = cut0::EvidenceRecord{
        digest(4U), packet.subject.id, digest(5U), digest(6U)};
    packet.appraisal = cut0::AppraisalRecord{
        digest(7U), packet.subject.id, packet.evidence.id,
        packet.subject.appraisal_policy_digest, cut0::AppraisalVerdict::pass};
    packet.permit = cut0::PermitRecord{
        true, digest(8U), packet.subject.id, packet.appraisal.id,
        digest(9U), digest(10U), 1U};
    packet.terminal = cut0::TerminalRecord{
        true, digest(11U), packet.permit.id, packet.permit.effect_digest,
        digest(12U), cut0::TerminalClass::effect, 1U};
    packet.reopen = cut0::ReopenRecord{
        true, packet.terminal.id, packet.terminal.terminal_class,
        digest(13U), digest(14U), digest(15U)};
    return packet;
}

[[nodiscard]] np::Dossier complete_dossier() {
    np::Dossier dossier{};
    dossier.membrane = complete_membrane();
    const np::Digest exact_membrane =
        np::membrane_commitment(dossier.membrane);
    for (std::size_t index = 0U; index < np::edge_count; ++index) {
        dossier.external_records[index] = np::PremiseRecord{
            true,
            static_cast<np::Edge>(index),
            dossier.membrane.subject.id,
            exact_membrane,
            digest(static_cast<std::uint8_t>(20U + index)),
            digest(static_cast<std::uint8_t>(40U + index)),
            static_cast<std::uint64_t>(index) + 1U,
        };
    }
    return dossier;
}

[[nodiscard]] constexpr std::string_view mutation_name(
    const Mutation mutation) noexcept {
    switch (mutation) {
        case Mutation::missing: return "missing";
        case Mutation::edge_mismatch: return "edge_mismatch";
        case Mutation::subject_zero: return "subject_zero";
        case Mutation::membrane_zero: return "membrane_zero";
        case Mutation::witness_zero: return "witness_zero";
        case Mutation::source_zero: return "source_zero";
        case Mutation::sequence_zero: return "sequence_zero";
        case Mutation::subject_mismatch: return "subject_mismatch";
        case Mutation::membrane_mismatch: return "membrane_mismatch";
        case Mutation::sequence_mismatch: return "sequence_mismatch";
    }
    return "invalid";
}

void apply_mutation(np::PremiseRecord& record,
                    const Mutation mutation,
                    const std::size_t edge_index) {
    switch (mutation) {
        case Mutation::missing:
            record.present = false;
            break;
        case Mutation::edge_mismatch:
            record.edge = np::Edge::none;
            break;
        case Mutation::subject_zero:
            record.subject_id = np::Digest{};
            break;
        case Mutation::membrane_zero:
            record.membrane_commitment = np::Digest{};
            break;
        case Mutation::witness_zero:
            record.witness_digest = np::Digest{};
            break;
        case Mutation::source_zero:
            record.source_identity_digest = np::Digest{};
            break;
        case Mutation::sequence_zero:
            record.sequence = 0U;
            break;
        case Mutation::subject_mismatch:
            record.subject_id = digest(
                static_cast<std::uint8_t>(160U + edge_index));
            break;
        case Mutation::membrane_mismatch:
            record.membrane_commitment = digest(
                static_cast<std::uint8_t>(180U + edge_index));
            break;
        case Mutation::sequence_mismatch:
            record.sequence = static_cast<std::uint64_t>(edge_index) + 9U;
            break;
    }
}

[[nodiscard]] constexpr np::Evaluation make(
    const np::Status status,
    const np::Fault fault,
    const std::size_t count,
    const np::Edge open,
    const bool membrane_bound,
    const bool all_bound,
    const np::Digest& exact_membrane,
    const np::Digest& exact_dossier) noexcept {
    return np::Evaluation{
        status,
        fault,
        static_cast<std::uint8_t>(count),
        open,
        membrane_bound,
        all_bound,
        exact_membrane,
        exact_dossier,
    };
}

[[nodiscard]] np::Evaluation derive_from_resulting_state(
    const np::Dossier& dossier,
    const np::Digest& exact_membrane,
    const np::Digest& exact_dossier) noexcept {
    const cut0::Evaluation membrane =
        cut0::reference::evaluate(dossier.membrane);
    if (membrane.status == cut0::Status::rejected) {
        return make(np::Status::membrane_rejected,
                    np::Fault::membrane_relation_rejected,
                    0U, np::Edge::owner_constitution, false, false,
                    exact_membrane, exact_dossier);
    }
    if (membrane.status != cut0::Status::reopen_record_bound) {
        return make(np::Status::membrane_prefix_incomplete,
                    np::Fault::membrane_reopen_record_absent,
                    0U, np::Edge::owner_constitution, false, false,
                    exact_membrane, exact_dossier);
    }

    for (std::size_t index = 0U; index < np::edge_count; ++index) {
        const np::PremiseRecord& record = dossier.external_records[index];
        const np::Edge edge = static_cast<np::Edge>(index);
        if (!record.present) {
            return make(np::Status::premise_record_missing,
                        np::Fault::premise_missing,
                        index, edge, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.edge != edge) {
            return make(np::Status::premise_edge_mismatch,
                        np::Fault::premise_edge_mismatch,
                        index, edge, true, false,
                        exact_membrane, exact_dossier);
        }
        const bool incomplete = cut0::is_zero(record.subject_id)
            || cut0::is_zero(record.membrane_commitment)
            || cut0::is_zero(record.witness_digest)
            || cut0::is_zero(record.source_identity_digest)
            || record.sequence == 0U;
        if (incomplete) {
            return make(np::Status::premise_record_incomplete,
                        np::Fault::premise_incomplete,
                        index, edge, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.subject_id != dossier.membrane.subject.id) {
            return make(np::Status::premise_subject_mismatch,
                        np::Fault::premise_subject_mismatch,
                        index, edge, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.membrane_commitment != exact_membrane) {
            return make(np::Status::premise_membrane_mismatch,
                        np::Fault::premise_membrane_mismatch,
                        index, edge, true, false,
                        exact_membrane, exact_dossier);
        }
        if (record.sequence != static_cast<std::uint64_t>(index) + 1U) {
            return make(np::Status::premise_sequence_mismatch,
                        np::Fault::premise_sequence_mismatch,
                        index, edge, true, false,
                        exact_membrane, exact_dossier);
        }
    }

    return make(np::Status::external_record_set_bound, np::Fault::none,
                np::edge_count, np::Edge::none, true, true,
                exact_membrane, exact_dossier);
}

void enforce_nonpromotion(const np::Evaluation& value,
                          const std::string_view label) {
    if (np::authority_granted(value) || np::epoch_exit_proved(value)) {
        throw std::runtime_error(
            "nonpromotion invariant failed: " + std::string(label));
    }
}

[[nodiscard]] Observed observe(const np::Dossier& dossier,
                               const std::string_view family) {
    const np::MembraneImage candidate_membrane =
        np::encode_membrane(dossier.membrane);
    const np::MembraneImage reference_membrane =
        np::reference::encode_membrane(dossier.membrane);
    const np::DossierImage candidate_dossier = np::encode_dossier(dossier);
    const np::DossierImage reference_dossier =
        np::reference::encode_dossier(dossier);
    const np::Digest exact_membrane =
        np::membrane_commitment(dossier.membrane);
    const np::Digest reference_membrane_digest =
        np::reference::membrane_commitment(dossier.membrane);
    const np::Digest exact_dossier = np::dossier_commitment(dossier);
    const np::Digest reference_dossier_digest =
        np::reference::dossier_commitment(dossier);
    if (candidate_membrane != reference_membrane
        || candidate_dossier != reference_dossier
        || exact_membrane != reference_membrane_digest
        || exact_dossier != reference_dossier_digest) {
        throw std::runtime_error(
            "image or commitment disagreement in " + std::string(family));
    }

    const Observed observed{
        np::evaluate(dossier),
        np::reference::evaluate(dossier),
        oracle::evaluate(dossier, exact_membrane, exact_dossier),
    };
    if (observed.candidate != observed.reference
        || observed.candidate != observed.closure_oracle) {
        throw std::runtime_error(
            "evaluation disagreement in " + std::string(family));
    }
    const np::Evaluation expected =
        derive_from_resulting_state(dossier, exact_membrane, exact_dossier);
    if (observed.candidate != expected) {
        throw std::runtime_error(
            "resulting-state expectation mismatch in " + std::string(family));
    }
    enforce_nonpromotion(observed.candidate, family);
    enforce_nonpromotion(observed.reference, family);
    enforce_nonpromotion(observed.closure_oracle, family);
    return observed;
}

void open_output(std::ofstream& stream, const std::filesystem::path& path) {
    stream.open(path, std::ios::out | std::ios::trunc);
    if (!stream.is_open()) {
        throw std::runtime_error("cannot open output: " + path.string());
    }
    stream.exceptions(std::ios::badbit | std::ios::failbit);
}

void write_evaluation_columns(std::ofstream& stream,
                              const Observed& observed) {
    stream
        << np::status_name(observed.candidate.status) << '\t'
        << np::status_name(observed.candidate.status) << '\t'
        << np::status_name(observed.reference.status) << '\t'
        << np::status_name(observed.closure_oracle.status) << '\t'
        << np::fault_name(observed.candidate.fault) << '\t'
        << np::fault_name(observed.candidate.fault) << '\t'
        << np::fault_name(observed.reference.fault) << '\t'
        << np::fault_name(observed.closure_oracle.fault) << '\t'
        << static_cast<unsigned int>(observed.candidate.bound_premise_records) << '\t'
        << static_cast<unsigned int>(observed.candidate.bound_premise_records) << '\t'
        << static_cast<unsigned int>(observed.reference.bound_premise_records) << '\t'
        << static_cast<unsigned int>(observed.closure_oracle.bound_premise_records) << '\t'
        << np::edge_name(observed.candidate.first_open_edge) << '\t'
        << np::edge_name(observed.candidate.first_open_edge) << '\t'
        << np::edge_name(observed.reference.first_open_edge) << '\t'
        << np::edge_name(observed.closure_oracle.first_open_edge) << '\t'
        << "false\tfalse\n";
}

void write_header(std::ofstream& stream, const std::string_view prefix) {
    stream << prefix
        << "expected_status\tcandidate_status\treference_status\toracle_status"
        << "\texpected_fault\tcandidate_fault\treference_fault\toracle_fault"
        << "\texpected_bound\tcandidate_bound\treference_bound\toracle_bound"
        << "\texpected_first_open\tcandidate_first_open\treference_first_open"
        << "\toracle_first_open\tauthority_granted\tepoch_exit_proved\n";
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    if (std::filesystem::exists(output)) {
        throw std::runtime_error("output already exists");
    }
    std::filesystem::create_directories(output);

    std::uint64_t atomic_count = 0U;
    std::ofstream atomic;
    open_output(atomic, output / "atomic.tsv");
    write_header(atomic, "case\tslot\tmutation\t");

    np::Dossier dossier = complete_dossier();
    Observed observed = observe(dossier, "atomic-baseline");
    atomic << "baseline\t-\t-\t";
    write_evaluation_columns(atomic, observed);
    ++atomic_count;

    dossier = complete_dossier();
    dossier.membrane.subject.id = np::Digest{};
    observed = observe(dossier, "atomic-membrane-rejected");
    atomic << "membrane_relation_rejected\t-\t-\t";
    write_evaluation_columns(atomic, observed);
    ++atomic_count;

    dossier = complete_dossier();
    dossier.membrane.reopen.present = false;
    observed = observe(dossier, "atomic-membrane-prefix");
    atomic << "membrane_reopen_absent\t-\t-\t";
    write_evaluation_columns(atomic, observed);
    ++atomic_count;

    for (std::size_t slot = 0U; slot < np::edge_count; ++slot) {
        for (const Mutation mutation : kMutations) {
            dossier = complete_dossier();
            apply_mutation(dossier.external_records[slot], mutation, slot);
            observed = observe(dossier, "atomic-record");
            atomic
                << "record_mutation\t" << slot << '\t'
                << mutation_name(mutation) << '\t';
            write_evaluation_columns(atomic, observed);
            ++atomic_count;
        }
    }
    atomic.close();
    if (atomic_count != 83U) {
        throw std::runtime_error("atomic inventory mismatch");
    }

    constexpr std::uint32_t presence_case_count = 1U << np::edge_count;
    std::uint64_t presence_count = 0U;
    std::uint64_t complete_presence_sets = 0U;
    std::ofstream presence;
    open_output(presence, output / "presence.tsv");
    write_header(presence, "mask\t");
    for (std::uint32_t mask = 0U; mask < presence_case_count; ++mask) {
        dossier = complete_dossier();
        for (std::size_t slot = 0U; slot < np::edge_count; ++slot) {
            const std::uint32_t bit = 1U << slot;
            dossier.external_records[slot].present = (mask & bit) != 0U;
        }
        observed = observe(dossier, "presence");
        if (observed.candidate.status == np::Status::external_record_set_bound) {
            ++complete_presence_sets;
        }
        presence << mask << '\t';
        write_evaluation_columns(presence, observed);
        ++presence_count;
    }
    presence.close();
    if (presence_count != presence_case_count || complete_presence_sets != 1U) {
        throw std::runtime_error("presence inventory mismatch");
    }

    std::uint64_t intraslot_count = 0U;
    std::ofstream intraslot;
    open_output(intraslot, output / "intraslot-ordered.tsv");
    write_header(intraslot, "slot\tfirst_mutation\tsecond_mutation\t");
    for (std::size_t slot = 0U; slot < np::edge_count; ++slot) {
        for (const Mutation first : kMutations) {
            for (const Mutation second : kMutations) {
                if (first == second) {
                    continue;
                }
                dossier = complete_dossier();
                apply_mutation(dossier.external_records[slot], first, slot);
                apply_mutation(dossier.external_records[slot], second, slot);
                observed = observe(dossier, "intraslot-ordered");
                intraslot
                    << slot << '\t' << mutation_name(first) << '\t'
                    << mutation_name(second) << '\t';
                write_evaluation_columns(intraslot, observed);
                ++intraslot_count;
            }
        }
    }
    intraslot.close();
    if (intraslot_count != 720U) {
        throw std::runtime_error("ordered intraslot inventory mismatch");
    }

    std::uint64_t cross_edge_count = 0U;
    std::ofstream cross;
    open_output(cross, output / "cross-edge.tsv");
    write_header(
        cross,
        "earlier_slot\tearlier_mutation\tlater_slot\tlater_mutation\t");
    for (std::size_t earlier = 0U; earlier < np::edge_count; ++earlier) {
        for (std::size_t later = earlier + 1U; later < np::edge_count; ++later) {
            for (const Mutation first : kMutations) {
                for (const Mutation second : kMutations) {
                    dossier = complete_dossier();
                    apply_mutation(
                        dossier.external_records[earlier], first, earlier);
                    apply_mutation(
                        dossier.external_records[later], second, later);
                    observed = observe(dossier, "cross-edge");
                    cross
                        << earlier << '\t' << mutation_name(first) << '\t'
                        << later << '\t' << mutation_name(second) << '\t';
                    write_evaluation_columns(cross, observed);
                    ++cross_edge_count;
                }
            }
        }
    }
    cross.close();
    if (cross_edge_count != 2800U) {
        throw std::runtime_error("cross-edge inventory mismatch");
    }

    const std::uint64_t total_cases = atomic_count + presence_count
        + intraslot_count + cross_edge_count;
    if (total_cases != 3859U) {
        throw std::runtime_error("total inventory mismatch");
    }

    std::ofstream summary;
    open_output(summary, output / "summary.json");
    summary
        << "{\n"
        << "  \"atomic_cases\": " << atomic_count << ",\n"
        << "  \"authority_granted\": false,\n"
        << "  \"candidate_reference_oracle_disagreements\": 0,\n"
        << "  \"cross_edge_pairs\": " << cross_edge_count << ",\n"
        << "  \"epoch_exit_proved\": false,\n"
        << "  \"expectation_source\": \"resulting_record_state\",\n"
        << "  \"external_premise_records\": " << np::edge_count << ",\n"
        << "  \"highest_status\": \"external_record_set_bound\",\n"
        << "  \"mutation_kinds\": " << kMutations.size() << ",\n"
        << "  \"ordered_intraslot_pairs\": " << intraslot_count << ",\n"
        << "  \"presence_cases\": " << presence_count << ",\n"
        << "  \"schema\": \"slopos.rev0931.nonpromotion-mutation-closure.v1\",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"total_cases\": " << total_cases << "\n"
        << "}\n";
    summary.close();

    std::cout
        << "NONPROMOTION_MUTATION_CLOSURE_CAMPAIGN=PASS atomic=" << atomic_count
        << " presence=" << presence_count
        << " intraslot_ordered=" << intraslot_count
        << " cross_edge=" << cross_edge_count
        << " total=" << total_cases
        << " disagreements=0 expectation_failures=0 authority=false epoch_zero=true\n";
    return 0;
}

}  // namespace slopos::e0::core_gate::mutation_closure
