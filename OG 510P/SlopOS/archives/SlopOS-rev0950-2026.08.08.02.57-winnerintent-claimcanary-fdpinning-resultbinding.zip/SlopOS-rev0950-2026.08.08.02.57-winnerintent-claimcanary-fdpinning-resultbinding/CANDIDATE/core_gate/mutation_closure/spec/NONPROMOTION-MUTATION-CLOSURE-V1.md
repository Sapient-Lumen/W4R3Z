# Nonpromotion mutation closure V1

## Question

Does the V2 external-record evaluator implement its stated first-fault relation
for bounded combinations, including cases where a later mutation overwrites a
field changed by an earlier mutation?

The unfinished rev0931 worktree originally answered pair precedence from mutation
labels. That was wrong: `subject_zero` followed by `subject_mismatch` leaves a
nonzero mismatching subject, while the reverse order leaves zero. Sequence and
membrane commitment have the same overwrite property. The expected result must
be derived from the resulting record state, not from a ranking assigned to the
names of operations that produced it.

## Scope

The ten mutation kinds are:

```text
missing, edge_mismatch,
subject_zero, membrane_zero, witness_zero, source_zero, sequence_zero,
subject_mismatch, membrane_mismatch, sequence_mismatch
```

The campaign executes 3,859 inputs:

| Family | Cases | Construction |
|---|---:|---|
| atomic | 83 | baseline + two membrane cases + 8 × 10 mutations |
| presence | 256 | every eight-slot presence mask |
| ordered intraslot | 720 | 8 × 10 × 9 distinct ordered mutation pairs |
| cross-edge | 2,800 | C(8,2) × 10 × 10 mutation pairs |

Both orders are mandatory for same-slot pairs. The 720 cases include 48 rows in
24 slot/pair families whose reverse order has a different expected status.

## Oracles

1. the V2 candidate evaluator;
2. the independently spelled V2 C++ reference;
3. a third C++ external-record oracle that receives commitments only after the
   two encoders and digest implementations agree;
4. a Python verifier that reconstructs every final record state directly from
   the case coordinates.

The C++ campaign also derives its expectation from the resulting dossier. It is
forbidden to use a mutation rank or a `dominant_same_slot` label rule.

## Boundary

This is pairwise closure of a finite implementation surface, not the full
`11^8` state product and not a proof of arbitrary program correctness. It does
not prove external witness truth, cryptographic authenticity, currentness,
control separation, one-use, owner decision, effect, terminal occurrence,
living admission, authority, or epoch exit.

The subproject is a nested proof target inside `core_gate`. It is intentionally
not a top-level product selector and does not create a fourth semantic island.
