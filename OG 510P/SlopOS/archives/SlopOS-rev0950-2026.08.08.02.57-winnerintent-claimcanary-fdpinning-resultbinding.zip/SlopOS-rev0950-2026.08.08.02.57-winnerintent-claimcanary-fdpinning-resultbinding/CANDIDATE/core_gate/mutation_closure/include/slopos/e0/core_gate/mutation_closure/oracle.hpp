#pragma once

#include "slopos/e0/core_gate/nonpromotion_kernel.hpp"

namespace slopos::e0::core_gate::mutation_closure::oracle {

// Third evaluator for the external-record layer. The caller supplies commitments
// only after candidate/reference byte images and digests agree. This oracle then
// spells the precedence relation independently; cross-language hashing is owned
// by proof/verify_mutation_closure.py and the V2 kernel verifier.
[[nodiscard]] nonpromotion::Evaluation evaluate(
    const nonpromotion::Dossier& dossier,
    const nonpromotion::Digest& exact_membrane,
    const nonpromotion::Digest& exact_dossier) noexcept;

}  // namespace slopos::e0::core_gate::mutation_closure::oracle
