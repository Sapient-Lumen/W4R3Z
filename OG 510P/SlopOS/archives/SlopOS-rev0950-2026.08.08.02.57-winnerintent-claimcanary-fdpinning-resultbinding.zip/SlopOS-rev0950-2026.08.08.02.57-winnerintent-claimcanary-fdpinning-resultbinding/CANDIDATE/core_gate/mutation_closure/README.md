# Nonpromotion mutation closure

This nested C++20 proof subproject closes the V2 external-record mutation surface
without creating a product target or fourth semantic island. It compiles the
exact current `core_gate` candidate and reference, adds a third independently
spelled precedence oracle, and verifies 3,859 bounded cases.

Build directly:

```sh
cmake -S CANDIDATE/core_gate/mutation_closure -B /tmp/slopos-mc -G Ninja
cmake --build /tmp/slopos-mc --target slopos_nonpromotion_mutation_closure
/tmp/slopos-mc/slopos_nonpromotion_mutation_closure campaign /tmp/slopos-mc-out
python3 -B CANDIDATE/core_gate/mutation_closure/proof/verify_mutation_closure.py \
  /tmp/slopos-mc-out --root .
```

Read `spec/NONPROMOTION-MUTATION-CLOSURE-V1.md` before interpreting the green
result. Pairwise closure is not the full state product, and no supplied record
becomes truth, permission, authority, effect, admission, or epoch exit.
