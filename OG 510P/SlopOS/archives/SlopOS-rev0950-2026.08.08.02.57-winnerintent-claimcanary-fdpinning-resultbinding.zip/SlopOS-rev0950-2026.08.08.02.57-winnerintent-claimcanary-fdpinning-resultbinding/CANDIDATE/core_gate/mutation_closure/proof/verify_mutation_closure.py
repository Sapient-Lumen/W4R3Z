#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

EDGES = (
    "owner_constitution",
    "acquisition_and_appraisal_enrollment",
    "current_policy_selection",
    "protected_one_use_spend",
    "authenticated_effect_and_query",
    "independent_terminal_reopen",
    "owner_admission",
    "release_constitution",
)
MUTATIONS = (
    "missing",
    "edge_mismatch",
    "subject_zero",
    "membrane_zero",
    "witness_zero",
    "source_zero",
    "sequence_zero",
    "subject_mismatch",
    "membrane_mismatch",
    "sequence_mismatch",
)
EXPECTED_INPUTS = (
    "atomic.tsv", "cross-edge.tsv", "intraslot-ordered.tsv",
    "presence.tsv", "summary.json",
)
EVAL_PREFIXES = ("expected", "candidate", "reference", "oracle")


def fail(detail: str) -> None:
    raise SystemExit(f"NONPROMOTION_MUTATION_CLOSURE_PROOF=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        result = list(reader)
    if not reader.fieldnames or len(reader.fieldnames) != len(set(reader.fieldnames)):
        fail(f"header={path.name}")
    return result


def fresh_record(slot: int) -> dict[str, object]:
    return {
        "present": True,
        "edge_ok": True,
        "subject": "match",
        "membrane": "match",
        "witness_nonzero": True,
        "source_nonzero": True,
        "sequence": "match",
        "slot": slot,
    }


def apply(record: dict[str, object], mutation: str) -> None:
    if mutation == "missing":
        record["present"] = False
    elif mutation == "edge_mismatch":
        record["edge_ok"] = False
    elif mutation == "subject_zero":
        record["subject"] = "zero"
    elif mutation == "membrane_zero":
        record["membrane"] = "zero"
    elif mutation == "witness_zero":
        record["witness_nonzero"] = False
    elif mutation == "source_zero":
        record["source_nonzero"] = False
    elif mutation == "sequence_zero":
        record["sequence"] = "zero"
    elif mutation == "subject_mismatch":
        record["subject"] = "mismatch"
    elif mutation == "membrane_mismatch":
        record["membrane"] = "mismatch"
    elif mutation == "sequence_mismatch":
        record["sequence"] = "mismatch"
    else:
        fail(f"mutation={mutation}")


def classify(records: list[dict[str, object]]) -> tuple[str, str, int, str]:
    for slot, record in enumerate(records):
        if not record["present"]:
            return "premise_record_missing", "premise_missing", slot, EDGES[slot]
        if not record["edge_ok"]:
            return "premise_edge_mismatch", "premise_edge_mismatch", slot, EDGES[slot]
        if record["subject"] == "zero" \
                or record["membrane"] == "zero" \
                or not record["witness_nonzero"] \
                or not record["source_nonzero"] \
                or record["sequence"] == "zero":
            return "premise_record_incomplete", "premise_incomplete", slot, EDGES[slot]
        if record["subject"] == "mismatch":
            return "premise_subject_mismatch", "premise_subject_mismatch", slot, EDGES[slot]
        if record["membrane"] == "mismatch":
            return "premise_membrane_mismatch", "premise_membrane_mismatch", slot, EDGES[slot]
        if record["sequence"] == "mismatch":
            return "premise_sequence_mismatch", "premise_sequence_mismatch", slot, EDGES[slot]
    return "external_record_set_bound", "none", 8, "none"


def validate_eval(row: dict[str, str], expected: tuple[str, str, int, str], label: str) -> None:
    status, fault, bound, open_edge = expected
    for prefix in EVAL_PREFIXES:
        if row[f"{prefix}_status"] != status:
            fail(f"status={label}:{prefix}:{row[f'{prefix}_status']}")
        if row[f"{prefix}_fault"] != fault:
            fail(f"fault={label}:{prefix}:{row[f'{prefix}_fault']}")
        if row[f"{prefix}_bound"] != str(bound):
            fail(f"bound={label}:{prefix}:{row[f'{prefix}_bound']}")
        if row[f"{prefix}_first_open"] != open_edge:
            fail(f"open={label}:{prefix}:{row[f'{prefix}_first_open']}")
    if row["authority_granted"] != "false" or row["epoch_exit_proved"] != "false":
        fail(f"promotion={label}")


def verify_atomic(directory: Path) -> None:
    data = rows(directory / "atomic.tsv")
    if len(data) != 83:
        fail(f"atomic-count={len(data)}")
    expected_order: list[tuple[str, str, str, tuple[str, str, int, str]]] = [
        ("baseline", "-", "-", ("external_record_set_bound", "none", 8, "none")),
        ("membrane_relation_rejected", "-", "-", (
            "membrane_rejected", "membrane_relation_rejected", 0, EDGES[0])),
        ("membrane_reopen_absent", "-", "-", (
            "membrane_prefix_incomplete", "membrane_reopen_record_absent", 0, EDGES[0])),
    ]
    for slot in range(8):
        for mutation in MUTATIONS:
            records = [fresh_record(index) for index in range(8)]
            apply(records[slot], mutation)
            expected_order.append(("record_mutation", str(slot), mutation, classify(records)))
    for index, (row, expected) in enumerate(zip(data, expected_order, strict=True)):
        case, slot, mutation, evaluation = expected
        if (row["case"], row["slot"], row["mutation"]) != (case, slot, mutation):
            fail(f"atomic-order={index}")
        validate_eval(row, evaluation, f"atomic:{index}")


def verify_presence(directory: Path) -> None:
    data = rows(directory / "presence.tsv")
    if len(data) != 256 or [int(row["mask"]) for row in data] != list(range(256)):
        fail(f"presence-count={len(data)}")
    successes = 0
    for mask, row in enumerate(data):
        records = [fresh_record(index) for index in range(8)]
        for slot in range(8):
            records[slot]["present"] = bool(mask & (1 << slot))
        expected = classify(records)
        validate_eval(row, expected, f"presence:{mask}")
        if expected[0] == "external_record_set_bound":
            successes += 1
    if successes != 1:
        fail(f"presence-successes={successes}")


def verify_intraslot(directory: Path) -> tuple[int, int]:
    data = rows(directory / "intraslot-ordered.tsv")
    if len(data) != 720:
        fail(f"intraslot-count={len(data)}")
    expected_keys: list[tuple[int, str, str]] = []
    for slot in range(8):
        for first in MUTATIONS:
            for second in MUTATIONS:
                if first != second:
                    expected_keys.append((slot, first, second))
    observed_keys = [
        (int(row["slot"]), row["first_mutation"], row["second_mutation"])
        for row in data
    ]
    if observed_keys != expected_keys or len(set(observed_keys)) != 720:
        fail("intraslot-inventory")

    by_key: dict[tuple[int, str, str], tuple[str, str, int, str]] = {}
    for row, (slot, first, second) in zip(data, expected_keys, strict=True):
        records = [fresh_record(index) for index in range(8)]
        apply(records[slot], first)
        apply(records[slot], second)
        expected = classify(records)
        validate_eval(row, expected, f"intraslot:{slot}:{first}>{second}")
        by_key[(slot, first, second)] = expected

    sensitive_families = (
        ("subject_zero", "subject_mismatch"),
        ("membrane_zero", "membrane_mismatch"),
        ("sequence_zero", "sequence_mismatch"),
    )
    order_sensitive_families = 0
    order_sensitive_rows = 0
    for slot in range(8):
        for first, second in sensitive_families:
            forward = by_key[(slot, first, second)]
            reverse = by_key[(slot, second, first)]
            if forward == reverse:
                fail(f"order-insensitive={slot}:{first}:{second}")
            order_sensitive_families += 1
            order_sensitive_rows += 2
    return order_sensitive_families, order_sensitive_rows


def verify_cross_edge(directory: Path) -> None:
    data = rows(directory / "cross-edge.tsv")
    if len(data) != 2800:
        fail(f"cross-count={len(data)}")
    expected_keys: list[tuple[int, str, int, str]] = []
    for earlier in range(8):
        for later in range(earlier + 1, 8):
            for first in MUTATIONS:
                for second in MUTATIONS:
                    expected_keys.append((earlier, first, later, second))
    observed_keys = [
        (
            int(row["earlier_slot"]), row["earlier_mutation"],
            int(row["later_slot"]), row["later_mutation"],
        )
        for row in data
    ]
    if observed_keys != expected_keys or len(set(observed_keys)) != 2800:
        fail("cross-inventory")
    for row, (earlier, first, later, second) in zip(data, expected_keys, strict=True):
        records = [fresh_record(index) for index in range(8)]
        apply(records[earlier], first)
        apply(records[later], second)
        validate_eval(row, classify(records), f"cross:{earlier}:{first}:{later}:{second}")


def verify_source(root: Path | None) -> None:
    if root is None:
        return
    campaign = root / "CANDIDATE/core_gate/mutation_closure/harness/campaign.cpp"
    oracle = root / "CANDIDATE/core_gate/mutation_closure/src/oracle.cpp"
    if not campaign.is_file() or not oracle.is_file():
        fail("source-missing")
    campaign_text = campaign.read_text(encoding="utf-8")
    oracle_text = oracle.read_text(encoding="utf-8")
    for forbidden in ("mutation_rank", "dominant_same_slot"):
        if forbidden in campaign_text:
            fail(f"stale-label-precedence={forbidden}")
    for required in (
        "derive_from_resulting_state", "if (first == second)",
        "intraslot_count != 720U", "cross_edge_count != 2800U",
    ):
        if required not in campaign_text:
            fail(f"campaign-token={required}")
    for required in (
        "record.membrane_commitment", "exact_membrane", "exact_dossier",
        "premise_membrane_mismatch",
    ):
        if required not in oracle_text:
            fail(f"oracle-token={required}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--json", type=Path)
    args = parser.parse_args()
    directory = args.directory.resolve()
    if not directory.is_dir():
        fail("directory")
    observed = tuple(sorted(path.name for path in directory.iterdir() if path.is_file()))
    if observed != EXPECTED_INPUTS:
        fail(f"input-set={observed}")

    summary = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "atomic_cases": 83,
        "authority_granted": False,
        "candidate_reference_oracle_disagreements": 0,
        "cross_edge_pairs": 2800,
        "epoch_exit_proved": False,
        "expectation_source": "resulting_record_state",
        "external_premise_records": 8,
        "highest_status": "external_record_set_bound",
        "mutation_kinds": 10,
        "ordered_intraslot_pairs": 720,
        "presence_cases": 256,
        "schema": "slopos.rev0931.nonpromotion-mutation-closure.v1",
        "status": "PASS",
        "total_cases": 3859,
    }
    if summary != expected_summary:
        fail("summary")

    verify_atomic(directory)
    verify_presence(directory)
    sensitive_families, sensitive_rows = verify_intraslot(directory)
    verify_cross_edge(directory)
    verify_source(args.root.resolve() if args.root else None)

    audit = {
        "atomic_cases_verified": 83,
        "authority_granted": False,
        "cross_edge_pairs_verified": 2800,
        "epoch_exit_proved": False,
        "expectations_reconstructed_from_resulting_state": True,
        "independent_python_oracle": True,
        "mutation_kinds_verified": 10,
        "ordered_intraslot_pairs_verified": 720,
        "order_sensitive_pair_families_verified": sensitive_families,
        "order_sensitive_rows_verified": sensitive_rows,
        "presence_cases_verified": 256,
        "schema": "slopos.rev0931.nonpromotion-mutation-closure-proof.v1",
        "status": "PASS",
        "total_cases_verified": 3859,
    }
    output = args.json or (directory / "audit.json")
    output.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "NONPROMOTION_MUTATION_CLOSURE_PROOF=PASS atomic=83 presence=256 "
        "intraslot_ordered=720 cross_edge=2800 total=3859 "
        f"order_sensitive_families={sensitive_families} order_sensitive_rows={sensitive_rows} "
        "disagreements=0 expectation_failures=0 authority=false epoch_zero=true"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyError, ValueError, OSError, json.JSONDecodeError, csv.Error) as error:
        fail(f"exception={type(error).__name__}:{error}")
