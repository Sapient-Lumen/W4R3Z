#include <filesystem>
#include <iostream>
#include <string>

namespace slopos::e0::core_gate {
int run_campaign(const std::filesystem::path& output);
}

int main(const int argc, char** argv) {
    try {
        if (argc != 3 || std::string(argv[1]) != "campaign") {
            std::cerr << "usage: slopos_core_gate campaign OUTPUT\n";
            return 2;
        }
        return slopos::e0::core_gate::run_campaign(
            std::filesystem::path(argv[2]));
    } catch (const std::exception& error) {
        std::cerr << "CORE_GATE_CAMPAIGN=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
