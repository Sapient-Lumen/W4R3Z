#include <filesystem>
#include <iostream>
#include <string_view>

namespace slopos::e0::core_gate::cut0 {
int run_campaign(const std::filesystem::path& output);
}

int main(const int argc, char** argv) {
    try {
        if (argc != 3 || std::string_view(argv[1]) != "campaign") {
            std::cerr << "usage: slopos_membrane_cut0 campaign OUTPUT\n";
            return 2;
        }
        return slopos::e0::core_gate::cut0::run_campaign(
            std::filesystem::path(argv[2]));
    } catch (const std::exception& error) {
        std::cerr << "MEMBRANE_CUT0_CAMPAIGN=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
