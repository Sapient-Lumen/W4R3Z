#include <exception>
#include <filesystem>
#include <iostream>
#include <string_view>

namespace slopos::e0::core_gate::nonpromotion {
int run_campaign(const std::filesystem::path& output);
}

int main(const int argc, char** argv) {
    try {
        if (argc != 3 || std::string_view(argv[1]) != "campaign") {
            std::cerr << "usage: slopos_nonpromotion_kernel campaign OUTPUT\n";
            return 2;
        }
        return slopos::e0::core_gate::nonpromotion::run_campaign(
            std::filesystem::path(argv[2]));
    } catch (const std::exception& error) {
        std::cerr << "NONPROMOTION_KERNEL_CAMPAIGN=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
