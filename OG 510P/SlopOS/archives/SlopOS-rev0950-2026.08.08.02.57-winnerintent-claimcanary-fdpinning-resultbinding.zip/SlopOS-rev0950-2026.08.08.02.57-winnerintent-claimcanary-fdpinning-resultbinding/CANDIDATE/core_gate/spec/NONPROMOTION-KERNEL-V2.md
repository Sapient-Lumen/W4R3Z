# Nonpromotion Kernel V2 — exact membrane and dossier binding

## Purpose

V2 repairs one demonstrated V1 traceability defect without changing the authority
claim. V1 let each X1–X8 premise record name the membrane subject identifier, but
it did not require the record to bind the exact R1–R6 packet. A witness record
could therefore remain structurally acceptable after an otherwise coherent
change to evidence, appraisal, permit, terminal, or reopen bytes.

V2 gives the packet and complete dossier deterministic logical byte images,
computes domain-separated SHA-256 commitments, and requires every premise record
to carry the exact membrane commitment. The highest result remains
`external_record_set_bound`. The API still makes `authority_granted` and
`epoch_exit_proved` constant false.

This is a trace-binding repair. It does not authenticate any digest, verify a
signature, constitute an owner, establish currentness, prove administrative
independence, serialize a spend, operate an effect, or admit a living revision.

## Logical images, not C++ object layout

The encoder never hashes object memory. The image is field-by-field:

- booleans and enum discriminants are one octet;
- every unsigned integer is eight-octet big-endian;
- every digest is exactly 32 octets;
- fields appear in the order below;
- record payload remains encoded when `present == false`;
- no padding, host endianness, pointer, allocator, or ABI bytes enter the image.

This fixed V2 representation is intentionally smaller than adopting a general
wire format inside the proof kernel. A future network protocol may use a
standard deterministic encoding, but it must name a new domain and prove the
mapping rather than silently reusing these bytes.

## Membrane image

Magic is ASCII `SLOPMEM2`; version is unsigned 2. Total size is 814 bytes.

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 8 | magic |
| 8 | 8 | image version |
| 16 | 32 | subject id |
| 48 | 32 | subject artifact digest |
| 80 | 32 | subject appraisal-policy digest |
| 112 | 8 | subject revision |
| 120 | 32 | evidence id |
| 152 | 32 | evidence subject id |
| 184 | 32 | evidence payload digest |
| 216 | 32 | acquisition-context digest |
| 248 | 32 | appraisal id |
| 280 | 32 | appraisal subject id |
| 312 | 32 | appraisal evidence id |
| 344 | 32 | appraisal policy digest |
| 376 | 1 | appraisal verdict |
| 377 | 1 | permit present |
| 378 | 32 | permit id |
| 410 | 32 | permit subject id |
| 442 | 32 | permit appraisal id |
| 474 | 32 | permit effect digest |
| 506 | 32 | permit spend-coordinate digest |
| 538 | 8 | permit serial |
| 546 | 1 | terminal present |
| 547 | 32 | terminal id |
| 579 | 32 | terminal permit id |
| 611 | 32 | terminal effect digest |
| 643 | 32 | terminal predecessor digest |
| 675 | 1 | terminal class |
| 676 | 8 | terminal sequence |
| 684 | 1 | reopen present |
| 685 | 32 | reopen terminal id |
| 717 | 1 | reopen terminal class |
| 718 | 32 | producer administration-label digest |
| 750 | 32 | reopener administration-label digest |
| 782 | 32 | reopen receipt digest |

The commitment is:

```text
SHA-256("SlopOS/e0/nonpromotion/membrane/v2" || 0x00 || membrane_image)
```

## Premise-record and dossier images

A premise record is 138 bytes:

```text
present:1 || edge:1 || subject_id:32 || membrane_commitment:32
|| witness_digest:32 || source_identity_digest:32 || sequence_be64:8
```

The dossier is 1,934 bytes:

```text
"SLOPDOS2":8 || version_be64(2):8 || membrane_image:814
|| premise_record[0]:138 || ... || premise_record[7]:138
```

Its commitment is:

```text
SHA-256("SlopOS/e0/nonpromotion/dossier/v2" || 0x00 || dossier_image)
```

The dossier commitment is diagnostic input identity. It is returned for every
result, including rejection. It is not a signature, receipt, admission, or
currentness witness.

## Evaluation order

The evaluator first runs Membrane Cut-0. A rejected packet returns
`membrane_rejected`; any accepted prefix below `reopen_record_bound` returns
`membrane_prefix_incomplete`. External records are not allowed to repair either
result.

For slots 0 through 7, the first open slot is classified in this order:

1. missing record;
2. wrong canonical edge;
3. zero subject, membrane commitment, witness, source identity, or sequence;
4. subject mismatch;
5. exact membrane-commitment mismatch;
6. one-based sequence mismatch.

Only eight records passing all checks yield `external_record_set_bound`.
Ordering is part of the finite relation so a later attractive record cannot hide
an earlier open edge.

## Proof surface

The current campaign executes:

- 83 curated cases: baseline, two membrane failures, and ten atomic mutations at
  each of eight external slots;
- all 256 presence masks;
- 19 coherent R1–R6 mutations that retain `reopen_record_bound` but must make X1
  fail with `premise_membrane_mismatch`;
- two absent-record inputs with equal evaluation but different hidden payload,
  proving that absence does not move payload outside the dossier commitment.

Candidate and independently spelled C++ reference implementations must agree on
both byte images, both commitments, and every evaluation. The Python proof
reconstructs the images without calling either implementation, checks a SHA-256
known-answer vector, verifies all campaign rows, and flips one bit at each of the
814 membrane-image byte positions.

A bit-flip campaign is finite implementation evidence, not a cryptographic proof
of collision resistance. SHA-256 strength is an explicit external assumption.

## Exact V1 custody

The V1 source closure is preserved under
`EXCAVATION/ACTIVE-SURFACE-MIGRATION-REV0931/EXACT/`. Rev0930 evidence must reopen
against those exact bytes. V2 does not rewrite the historical result and does not
claim V1 bound more than the subject identifier.
