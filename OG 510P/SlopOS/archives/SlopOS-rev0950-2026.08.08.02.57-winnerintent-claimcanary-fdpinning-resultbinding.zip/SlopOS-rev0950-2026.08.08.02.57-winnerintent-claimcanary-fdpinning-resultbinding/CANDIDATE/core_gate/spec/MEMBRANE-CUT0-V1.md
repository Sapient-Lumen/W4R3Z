# Membrane Cut-0 V1 — six-record conformance relation

## Purpose

Membrane Cut-0 is a small executable relation distilled from the old vault's
repeated nonpromotion laws. It asks one narrow question:

> Do six supplied records preserve the required local identity joins from a
> subject record through a reopen record, while refusing to describe those
> joins as authority, occurrence, one-use, currentness, or independence?

It lives inside the existing `core_gate` semantic island. It is not a fourth
island, owner service, signer, provider adapter, database, network protocol, or
effect executor. It does not compute or authenticate digests. Every 32-byte
value is an opaque caller-supplied label; the relation checks only equality,
nonzeroness, record order, and finite enum membership.

## Six record classes

The packet has one fixed vocabulary and order.

1. **SubjectRecord** — record id, artifact digest, appraisal-policy digest, and
   nonzero revision.
2. **EvidenceRecord** — record id, exact subject id, evidence digest, and
   acquisition-context digest.
3. **AppraisalRecord** — record id, exact subject and evidence ids, exact
   appraisal-policy digest, and `pass`, `deny`, or `indeterminate`.
4. **PermitRecord** — optional record id binding the exact subject, appraisal,
   effect label, spend-coordinate digest, and nonzero serial.
5. **TerminalRecord** — optional record id binding the exact permit, effect
   label, predecessor digest, one terminal class, and nonzero sequence.
6. **ReopenRecord** — optional receipt binding the exact terminal id and class,
   two administration-label digests, and a receipt digest.

These are record classes, not claims that the represented events occurred. A
future owner-governed protocol can bind richer authenticated objects to this
shape; the hosted relation cannot supply that external meaning.

## Ordered evaluation

Evaluation is deterministic and fail-closed.

- Subject, evidence, and appraisal are required and checked in that order.
- `deny` and `indeterminate` close locally. Any later permit, terminal, or reopen
  material is rejected as `post_closed_material`.
- `pass` without a permit is `appraisal_pass_no_permit`; it grants nothing.
- A present permit must bind the exact subject and appraisal and carry nonzero
  id, effect, spend-coordinate, and serial fields.
- A terminal record cannot appear without a permit. It must bind the permit id
  and effect label exactly and select `effect`, `no_effect`, `uncertain`, or
  `fail_stop`.
- A reopen record cannot appear without a terminal. It must repeat the exact
  terminal id and class.
- Equal producer and reopener administration-label digests are rejected. Unequal
  values establish only that two opaque fields differ.

Fault precedence is part of V1. An earlier record class dominates later faults,
so a packet with several defects receives one stable diagnosis.

## Result vocabulary

- `closed_deny`, `closed_indeterminate`, and
  `appraisal_pass_no_permit` bind no permit record.
- `permit_record_bound` means only that the supplied fields through R4 join.
- `terminal_record_bound` means only that the supplied fields through R5 join.
- `reopen_record_bound` means only that the supplied fields through R6 join.

The exported booleans are equally narrow: `permit_record_bound`,
`terminal_record_bound`, and `administration_labels_distinct`. None means
permission, trusted terminal knowledge, external effect occurrence, or
independent administration.

## Harness and proof shape

Two C++20 evaluators share only the public value vocabulary:

- `src/membrane_cut0.cpp` is an ordered candidate evaluator;
- `src/membrane_cut0_reference.cpp` is a separately spelled predicate evaluator
  that does not call the candidate.

The campaign checks 31 named cases covering every status and every fault, then
checks all 4,096 combinations of twelve cross-record mutations. The Python
proof checker independently fixes the named oracle, expected mutation counts,
source-separation checks, and the 18-row obligation register. Rev0929 retains
compiler-lane evidence, but compiler diversity remains mechanism diversity in
one cloudtainer—not administrative independence.

## Hard nonclaims

Membrane Cut-0 proves none of the following:

- digest integrity, signatures, signer identity, trusted time, or freshness;
- owner constitution, current policy selection, or relying-party appraisal;
- permit authority, protected capability custody, or a usable effect right;
- external occurrence, effect execution, harmlessness, or terminal truth;
- non-cloned serialization, global one-use, rollback resistance, or lineage
  uniqueness;
- independent administration merely because two supplied labels differ;
- living-project admission, release authority, Epoch-One genesis, or general
  SlopOS authority.

This is Epoch-Zero proofwork: a compact normative join surface and a falsifiable
hosted checker, not a substitute for External Ceremony V14.
