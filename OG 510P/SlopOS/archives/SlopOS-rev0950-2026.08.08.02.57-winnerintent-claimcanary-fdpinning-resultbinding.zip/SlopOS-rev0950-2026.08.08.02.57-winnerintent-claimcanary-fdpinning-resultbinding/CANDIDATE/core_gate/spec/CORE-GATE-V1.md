# Core gate v1

## Selected product seam

```text
bound subject evidence
  -> separately typed appraisal
  -> relying-party decision
  -> one live permit
  -> gate entry (permit burns first)
  -> fixed endpoint observation
  -> EFFECT | NO_EFFECT | UNCERTAIN | FAIL_STOP
  -> publication of that exact retained result
```

The route is the system-fixed generation journal. No event lets the proposer
select it. Subject `alpha` and `beta` are finite identifiers used to expose join
failures; they are not principals or authenticated machine identities.

## Laws exercised

1. Evidence cannot mint a permit and cannot substitute for appraisal.
2. An allow decision requires an allow appraisal over the same exact subject.
3. A relying party may deny even an allowed appraisal.
4. Permit minting occurs once and only after the complete allow join.
5. Every presented entry attempt consumes the live permit before subject,
   encoding, or route checks. Failed entry becomes exact `FAIL_STOP`; no retry
   authority survives.
6. Exact entry can produce at most one fixed endpoint effect.
7. Endpoint nonreturn or malformed return becomes `UNCERTAIN`, never
   `NO_EFFECT`.
8. Restart with a live permit or after entry erases volatile authority and
   widens to reconciliation-only `UNCERTAIN`.
9. Recovery cannot mint first-dispatch authority.
10. Only exact reconciliation may narrow uncertainty to `EFFECT` or
    `NO_EFFECT`; mismatch preserves the complete uncertain state.
11. Publication adds no effect authority and reproduces only a terminal result.
12. A relying-party deny is an inert decision sink in v1: it can mint no permit
    and emit no effect. Denial-response publication belongs to a separate
    response surface and must not be encoded as endpoint `NO_EFFECT`.
13. Publication is a closing edge in this finite v1 relation. It intentionally
    does not model a later reconciliation that supersedes already-published
    `UNCERTAIN`; the generation-journal/result interface must specify versioned
    publication or an explicit no-supersession rule before refinement.

## Boundary

The finite relation is hosted proofwork. Its denial-response and
post-publication reconciliation interfaces are deliberately incomplete. Its
booleans and enums are not
nonforgeable capabilities, protected principal identity, stable-media state, a
TPM acquisition, an isolated endpoint, or a release claim. The construction is
admissible in Epoch Zero because it consolidates a previously sealed central
law into the prospective core rather than adding horizontal assurance surface.
