#include "slopos/e0/core_gate/nonpromotion_kernel_reference.hpp"

#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slopos::e0::core_gate::nonpromotion::reference {
namespace {

constexpr std::array<std::uint8_t, 8U> membrane_tag{{
    'S', 'L', 'O', 'P', 'M', 'E', 'M', '2',
}};
constexpr std::array<std::uint8_t, 8U> dossier_tag{{
    'S', 'L', 'O', 'P', 'D', 'O', 'S', '2',
}};
constexpr std::string_view membrane_hash_domain =
    "SlopOS/e0/nonpromotion/membrane/v2";
constexpr std::string_view dossier_hash_domain =
    "SlopOS/e0/nonpromotion/dossier/v2";

constexpr std::array<std::uint32_t, 64U> round_constants{{
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
    0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
    0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
    0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
    0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
    0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
    0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
    0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
    0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U,
}};

[[nodiscard]] constexpr std::uint32_t rr(
    const std::uint32_t value, const unsigned int count) noexcept {
    return (value >> count) | (value << (32U - count));
}

template <std::size_t Size>
void append_array(std::array<std::uint8_t, Size>& output,
                  std::size_t& cursor,
                  const auto& input) noexcept {
    for (const std::uint8_t value : input) {
        output[cursor++] = value;
    }
}

template <std::size_t Size>
void append_u64(std::array<std::uint8_t, Size>& output,
                std::size_t& cursor,
                const std::uint64_t value) noexcept {
    for (unsigned int shift = 56U;; shift -= 8U) {
        output[cursor++] = static_cast<std::uint8_t>(value >> shift);
        if (shift == 0U) {
            break;
        }
    }
}

template <std::size_t Size>
void append_byte(std::array<std::uint8_t, Size>& output,
                 std::size_t& cursor,
                 const std::uint8_t value) noexcept {
    output[cursor++] = value;
}

template <std::size_t Size>
[[nodiscard]] Digest sha256_domain_image(
    const std::string_view domain,
    const std::array<std::uint8_t, Size>& image) noexcept {
    // 128 bytes is more than the largest possible SHA-256 padding expansion.
    std::array<std::uint8_t, Size + 128U> message{};
    std::size_t payload_bytes = 0U;
    for (const char value : domain) {
        message[payload_bytes++] = static_cast<std::uint8_t>(value);
    }
    message[payload_bytes++] = 0U;
    for (const std::uint8_t value : image) {
        message[payload_bytes++] = value;
    }
    const std::uint64_t bit_length =
        static_cast<std::uint64_t>(payload_bytes) * 8U;
    message[payload_bytes] = 0x80U;
    const std::size_t padded_bytes =
        ((payload_bytes + 9U + 63U) / 64U) * 64U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift =
            static_cast<unsigned int>((7U - index) * 8U);
        message[padded_bytes - 8U + index] =
            static_cast<std::uint8_t>(bit_length >> shift);
    }

    std::array<std::uint32_t, 8U> digest_state{{
        0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
        0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U,
    }};
    for (std::size_t block = 0U; block < padded_bytes; block += 64U) {
        std::array<std::uint32_t, 64U> schedule{};
        for (std::size_t word = 0U; word < 16U; ++word) {
            const std::size_t base = block + word * 4U;
            schedule[word] =
                (static_cast<std::uint32_t>(message[base]) << 24U)
                | (static_cast<std::uint32_t>(message[base + 1U]) << 16U)
                | (static_cast<std::uint32_t>(message[base + 2U]) << 8U)
                | static_cast<std::uint32_t>(message[base + 3U]);
        }
        for (std::size_t word = 16U; word < schedule.size(); ++word) {
            const std::uint32_t left = rr(schedule[word - 15U], 7U)
                ^ rr(schedule[word - 15U], 18U)
                ^ (schedule[word - 15U] >> 3U);
            const std::uint32_t right = rr(schedule[word - 2U], 17U)
                ^ rr(schedule[word - 2U], 19U)
                ^ (schedule[word - 2U] >> 10U);
            schedule[word] = schedule[word - 16U] + left
                + schedule[word - 7U] + right;
        }

        std::array<std::uint32_t, 8U> work = digest_state;
        for (std::size_t round = 0U; round < schedule.size(); ++round) {
            const std::uint32_t sigma1 = rr(work[4U], 6U)
                ^ rr(work[4U], 11U) ^ rr(work[4U], 25U);
            const std::uint32_t choose =
                (work[4U] & work[5U]) ^ ((~work[4U]) & work[6U]);
            const std::uint32_t first = work[7U] + sigma1 + choose
                + round_constants[round] + schedule[round];
            const std::uint32_t sigma0 = rr(work[0U], 2U)
                ^ rr(work[0U], 13U) ^ rr(work[0U], 22U);
            const std::uint32_t majority =
                (work[0U] & work[1U]) ^ (work[0U] & work[2U])
                ^ (work[1U] & work[2U]);
            const std::uint32_t second = sigma0 + majority;
            work[7U] = work[6U];
            work[6U] = work[5U];
            work[5U] = work[4U];
            work[4U] = work[3U] + first;
            work[3U] = work[2U];
            work[2U] = work[1U];
            work[1U] = work[0U];
            work[0U] = first + second;
        }
        for (std::size_t index = 0U; index < digest_state.size(); ++index) {
            digest_state[index] += work[index];
        }
    }

    Digest result{};
    for (std::size_t index = 0U; index < digest_state.size(); ++index) {
        result[index * 4U] =
            static_cast<std::uint8_t>(digest_state[index] >> 24U);
        result[index * 4U + 1U] =
            static_cast<std::uint8_t>(digest_state[index] >> 16U);
        result[index * 4U + 2U] =
            static_cast<std::uint8_t>(digest_state[index] >> 8U);
        result[index * 4U + 3U] =
            static_cast<std::uint8_t>(digest_state[index]);
    }
    return result;
}

[[nodiscard]] constexpr std::array<Edge, edge_count> canonical_edges() noexcept {
    return {
        Edge::owner_constitution,
        Edge::acquisition_and_appraisal_enrollment,
        Edge::current_policy_selection,
        Edge::protected_one_use_spend,
        Edge::authenticated_effect_and_query,
        Edge::independent_terminal_reopen,
        Edge::owner_admission,
        Edge::release_constitution,
    };
}

[[nodiscard]] constexpr Evaluation make_result(
    const Status status,
    const Fault fault,
    const std::size_t count,
    const Edge open,
    const bool membrane_bound,
    const bool all_bound,
    const Digest& membrane_digest,
    const Digest& dossier_digest) noexcept {
    return Evaluation{
        status,
        fault,
        static_cast<std::uint8_t>(count),
        open,
        membrane_bound,
        all_bound,
        membrane_digest,
        dossier_digest,
    };
}

}  // namespace

MembraneImage encode_membrane(const cut0::Packet& packet) noexcept {
    MembraneImage image{};
    std::size_t cursor = 0U;
    append_array(image, cursor, membrane_tag);
    append_u64(image, cursor, 2U);

    append_array(image, cursor, packet.subject.id);
    append_array(image, cursor, packet.subject.artifact_digest);
    append_array(image, cursor, packet.subject.appraisal_policy_digest);
    append_u64(image, cursor, packet.subject.revision);

    append_array(image, cursor, packet.evidence.id);
    append_array(image, cursor, packet.evidence.subject_id);
    append_array(image, cursor, packet.evidence.evidence_digest);
    append_array(image, cursor, packet.evidence.acquisition_context_digest);

    append_array(image, cursor, packet.appraisal.id);
    append_array(image, cursor, packet.appraisal.subject_id);
    append_array(image, cursor, packet.appraisal.evidence_id);
    append_array(image, cursor, packet.appraisal.policy_digest);
    append_byte(image, cursor,
                static_cast<std::uint8_t>(packet.appraisal.verdict));

    append_byte(image, cursor, packet.permit.present ? 1U : 0U);
    append_array(image, cursor, packet.permit.id);
    append_array(image, cursor, packet.permit.subject_id);
    append_array(image, cursor, packet.permit.appraisal_id);
    append_array(image, cursor, packet.permit.effect_digest);
    append_array(image, cursor, packet.permit.spend_coordinate_digest);
    append_u64(image, cursor, packet.permit.serial);

    append_byte(image, cursor, packet.terminal.present ? 1U : 0U);
    append_array(image, cursor, packet.terminal.id);
    append_array(image, cursor, packet.terminal.permit_id);
    append_array(image, cursor, packet.terminal.effect_digest);
    append_array(image, cursor, packet.terminal.predecessor_digest);
    append_byte(image, cursor,
                static_cast<std::uint8_t>(packet.terminal.terminal_class));
    append_u64(image, cursor, packet.terminal.sequence);

    append_byte(image, cursor, packet.reopen.present ? 1U : 0U);
    append_array(image, cursor, packet.reopen.terminal_id);
    append_byte(image, cursor,
                static_cast<std::uint8_t>(packet.reopen.terminal_class));
    append_array(image, cursor,
                 packet.reopen.producer_administration_label_digest);
    append_array(image, cursor,
                 packet.reopen.reopener_administration_label_digest);
    append_array(image, cursor, packet.reopen.receipt_digest);
    (void)cursor;
    return image;
}

Digest membrane_commitment(const cut0::Packet& packet) noexcept {
    return sha256_domain_image(membrane_hash_domain, encode_membrane(packet));
}

DossierImage encode_dossier(const Dossier& dossier) noexcept {
    DossierImage image{};
    std::size_t cursor = 0U;
    append_array(image, cursor, dossier_tag);
    append_u64(image, cursor, 2U);
    append_array(image, cursor, reference::encode_membrane(dossier.membrane));
    for (const PremiseRecord& item : dossier.external_records) {
        append_byte(image, cursor, item.present ? 1U : 0U);
        append_byte(image, cursor, static_cast<std::uint8_t>(item.edge));
        append_array(image, cursor, item.subject_id);
        append_array(image, cursor, item.membrane_commitment);
        append_array(image, cursor, item.witness_digest);
        append_array(image, cursor, item.source_identity_digest);
        append_u64(image, cursor, item.sequence);
    }
    (void)cursor;
    return image;
}

Digest dossier_commitment(const Dossier& dossier) noexcept {
    return sha256_domain_image(
        dossier_hash_domain, reference::encode_dossier(dossier));
}

Evaluation evaluate(const Dossier& dossier) noexcept {
    const Digest packet_digest = reference::membrane_commitment(dossier.membrane);
    const Digest input_digest = reference::dossier_commitment(dossier);
    const cut0::Evaluation membrane = cut0::reference::evaluate(dossier.membrane);
    if (membrane.status != cut0::Status::reopen_record_bound) {
        const bool rejected = membrane.status == cut0::Status::rejected;
        return make_result(
            rejected ? Status::membrane_rejected
                     : Status::membrane_prefix_incomplete,
            rejected ? Fault::membrane_relation_rejected
                     : Fault::membrane_reopen_record_absent,
            0U,
            Edge::owner_constitution,
            false,
            false,
            packet_digest,
            input_digest);
    }

    constexpr auto expected = canonical_edges();
    for (std::size_t index = 0U; index < expected.size(); ++index) {
        const PremiseRecord& item = dossier.external_records.at(index);
        const Edge open = expected.at(index);
        if (!item.present) {
            return make_result(Status::premise_record_missing,
                               Fault::premise_missing,
                               index, open, true, false,
                               packet_digest, input_digest);
        }
        if (item.edge != open) {
            return make_result(Status::premise_edge_mismatch,
                               Fault::premise_edge_mismatch,
                               index, open, true, false,
                               packet_digest, input_digest);
        }
        const bool empty = cut0::is_zero(item.subject_id)
            || cut0::is_zero(item.membrane_commitment)
            || cut0::is_zero(item.witness_digest)
            || cut0::is_zero(item.source_identity_digest)
            || item.sequence == 0U;
        if (empty) {
            return make_result(Status::premise_record_incomplete,
                               Fault::premise_incomplete,
                               index, open, true, false,
                               packet_digest, input_digest);
        }
        if (!(item.subject_id == dossier.membrane.subject.id)) {
            return make_result(Status::premise_subject_mismatch,
                               Fault::premise_subject_mismatch,
                               index, open, true, false,
                               packet_digest, input_digest);
        }
        if (!(item.membrane_commitment == packet_digest)) {
            return make_result(Status::premise_membrane_mismatch,
                               Fault::premise_membrane_mismatch,
                               index, open, true, false,
                               packet_digest, input_digest);
        }
        if (item.sequence != static_cast<std::uint64_t>(index) + 1U) {
            return make_result(Status::premise_sequence_mismatch,
                               Fault::premise_sequence_mismatch,
                               index, open, true, false,
                               packet_digest, input_digest);
        }
    }

    return make_result(Status::external_record_set_bound, Fault::none,
                       expected.size(), Edge::none, true, true,
                       packet_digest, input_digest);
}

}  // namespace slopos::e0::core_gate::nonpromotion::reference
