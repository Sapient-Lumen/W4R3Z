#include "slopos/e0/core_gate/nonpromotion_kernel.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slopos::e0::core_gate::nonpromotion {
namespace {

constexpr std::array<std::uint8_t, 8U> kMembraneMagic{{
    'S', 'L', 'O', 'P', 'M', 'E', 'M', '2',
}};
constexpr std::array<std::uint8_t, 8U> kDossierMagic{{
    'S', 'L', 'O', 'P', 'D', 'O', 'S', '2',
}};
constexpr std::uint64_t kImageVersion = 2U;
constexpr std::string_view kMembraneDomain =
    "SlopOS/e0/nonpromotion/membrane/v2";
constexpr std::string_view kDossierDomain =
    "SlopOS/e0/nonpromotion/dossier/v2";

constexpr std::array<std::uint32_t, 64U> kRound{{
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
    0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
    0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
    0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
    0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
    0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
    0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
    0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
    0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U,
}};

[[nodiscard]] constexpr std::uint32_t rotate_right(
    const std::uint32_t value, const unsigned int count) noexcept {
    return (value >> count) | (value << (32U - count));
}

class Sha256 final {
public:
    void update(const std::uint8_t* bytes, const std::size_t size) noexcept {
        total_bytes_ += static_cast<std::uint64_t>(size);
        std::size_t consumed = 0U;
        while (consumed < size) {
            const std::size_t available = buffer_.size() - buffered_;
            const std::size_t remaining = size - consumed;
            const std::size_t take = std::min(available, remaining);
            for (std::size_t index = 0U; index < take; ++index) {
                buffer_[buffered_ + index] = bytes[consumed + index];
            }
            buffered_ += take;
            consumed += take;
            if (buffered_ == buffer_.size()) {
                transform(buffer_);
                buffered_ = 0U;
            }
        }
    }

    [[nodiscard]] Digest finish() noexcept {
        const std::uint64_t bit_length = total_bytes_ * 8U;
        buffer_[buffered_++] = 0x80U;
        if (buffered_ > 56U) {
            while (buffered_ < buffer_.size()) {
                buffer_[buffered_++] = 0U;
            }
            transform(buffer_);
            buffered_ = 0U;
        }
        while (buffered_ < 56U) {
            buffer_[buffered_++] = 0U;
        }
        for (std::size_t index = 0U; index < 8U; ++index) {
            const unsigned int shift =
                static_cast<unsigned int>((7U - index) * 8U);
            buffer_[56U + index] =
                static_cast<std::uint8_t>(bit_length >> shift);
        }
        transform(buffer_);

        Digest output{};
        for (std::size_t index = 0U; index < state_.size(); ++index) {
            output[index * 4U] =
                static_cast<std::uint8_t>(state_[index] >> 24U);
            output[index * 4U + 1U] =
                static_cast<std::uint8_t>(state_[index] >> 16U);
            output[index * 4U + 2U] =
                static_cast<std::uint8_t>(state_[index] >> 8U);
            output[index * 4U + 3U] =
                static_cast<std::uint8_t>(state_[index]);
        }
        return output;
    }

private:
    void transform(const std::array<std::uint8_t, 64U>& block) noexcept {
        std::array<std::uint32_t, 64U> words{};
        for (std::size_t index = 0U; index < 16U; ++index) {
            const std::size_t base = index * 4U;
            words[index] =
                (static_cast<std::uint32_t>(block[base]) << 24U)
                | (static_cast<std::uint32_t>(block[base + 1U]) << 16U)
                | (static_cast<std::uint32_t>(block[base + 2U]) << 8U)
                | static_cast<std::uint32_t>(block[base + 3U]);
        }
        for (std::size_t index = 16U; index < words.size(); ++index) {
            const std::uint32_t small0 =
                rotate_right(words[index - 15U], 7U)
                ^ rotate_right(words[index - 15U], 18U)
                ^ (words[index - 15U] >> 3U);
            const std::uint32_t small1 =
                rotate_right(words[index - 2U], 17U)
                ^ rotate_right(words[index - 2U], 19U)
                ^ (words[index - 2U] >> 10U);
            words[index] = words[index - 16U] + small0
                + words[index - 7U] + small1;
        }

        std::uint32_t a = state_[0U];
        std::uint32_t b = state_[1U];
        std::uint32_t c = state_[2U];
        std::uint32_t d = state_[3U];
        std::uint32_t e = state_[4U];
        std::uint32_t f = state_[5U];
        std::uint32_t g = state_[6U];
        std::uint32_t h = state_[7U];
        for (std::size_t index = 0U; index < words.size(); ++index) {
            const std::uint32_t big1 = rotate_right(e, 6U)
                ^ rotate_right(e, 11U) ^ rotate_right(e, 25U);
            const std::uint32_t choose = (e & f) ^ ((~e) & g);
            const std::uint32_t temporary1 = h + big1 + choose
                + kRound[index] + words[index];
            const std::uint32_t big0 = rotate_right(a, 2U)
                ^ rotate_right(a, 13U) ^ rotate_right(a, 22U);
            const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temporary2 = big0 + majority;
            h = g;
            g = f;
            f = e;
            e = d + temporary1;
            d = c;
            c = b;
            b = a;
            a = temporary1 + temporary2;
        }
        state_[0U] += a;
        state_[1U] += b;
        state_[2U] += c;
        state_[3U] += d;
        state_[4U] += e;
        state_[5U] += f;
        state_[6U] += g;
        state_[7U] += h;
    }

    std::array<std::uint32_t, 8U> state_{{
        0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
        0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U,
    }};
    std::array<std::uint8_t, 64U> buffer_{};
    std::size_t buffered_{0U};
    std::uint64_t total_bytes_{0U};
};

template <std::size_t Size>
class Writer final {
public:
    explicit Writer(std::array<std::uint8_t, Size>& output) noexcept
        : output_(output) {}

    void byte(const std::uint8_t value) noexcept {
        output_[offset_++] = value;
    }

    void boolean(const bool value) noexcept {
        byte(value ? 1U : 0U);
    }

    void u64(const std::uint64_t value) noexcept {
        for (std::size_t index = 0U; index < 8U; ++index) {
            const unsigned int shift =
                static_cast<unsigned int>((7U - index) * 8U);
            byte(static_cast<std::uint8_t>(value >> shift));
        }
    }

    template <std::size_t Count>
    void bytes(const std::array<std::uint8_t, Count>& values) noexcept {
        for (const std::uint8_t value : values) {
            byte(value);
        }
    }

    [[nodiscard]] std::size_t size() const noexcept {
        return offset_;
    }

private:
    std::array<std::uint8_t, Size>& output_;
    std::size_t offset_{0U};
};

template <std::size_t Size>
[[nodiscard]] Digest digest_image(
    const std::string_view domain,
    const std::array<std::uint8_t, Size>& image) noexcept {
    Sha256 hash;
    hash.update(
        reinterpret_cast<const std::uint8_t*>(domain.data()), domain.size());
    constexpr std::uint8_t separator = 0U;
    hash.update(&separator, 1U);
    hash.update(image.data(), image.size());
    return hash.finish();
}

[[nodiscard]] constexpr Edge edge_at(const std::size_t index) noexcept {
    return static_cast<Edge>(index);
}

[[nodiscard]] constexpr Evaluation result(
    const Status status,
    const Fault fault,
    const std::size_t bound,
    const Edge open,
    const bool membrane_bound,
    const bool all_bound,
    const Digest& membrane_digest,
    const Digest& dossier_digest) noexcept {
    return Evaluation{
        status,
        fault,
        static_cast<std::uint8_t>(bound),
        open,
        membrane_bound,
        all_bound,
        membrane_digest,
        dossier_digest,
    };
}

}  // namespace

MembraneImage encode_membrane(const cut0::Packet& packet) noexcept {
    MembraneImage output{};
    Writer<membrane_image_size> writer(output);
    writer.bytes(kMembraneMagic);
    writer.u64(kImageVersion);

    writer.bytes(packet.subject.id);
    writer.bytes(packet.subject.artifact_digest);
    writer.bytes(packet.subject.appraisal_policy_digest);
    writer.u64(packet.subject.revision);

    writer.bytes(packet.evidence.id);
    writer.bytes(packet.evidence.subject_id);
    writer.bytes(packet.evidence.evidence_digest);
    writer.bytes(packet.evidence.acquisition_context_digest);

    writer.bytes(packet.appraisal.id);
    writer.bytes(packet.appraisal.subject_id);
    writer.bytes(packet.appraisal.evidence_id);
    writer.bytes(packet.appraisal.policy_digest);
    writer.byte(static_cast<std::uint8_t>(packet.appraisal.verdict));

    writer.boolean(packet.permit.present);
    writer.bytes(packet.permit.id);
    writer.bytes(packet.permit.subject_id);
    writer.bytes(packet.permit.appraisal_id);
    writer.bytes(packet.permit.effect_digest);
    writer.bytes(packet.permit.spend_coordinate_digest);
    writer.u64(packet.permit.serial);

    writer.boolean(packet.terminal.present);
    writer.bytes(packet.terminal.id);
    writer.bytes(packet.terminal.permit_id);
    writer.bytes(packet.terminal.effect_digest);
    writer.bytes(packet.terminal.predecessor_digest);
    writer.byte(static_cast<std::uint8_t>(packet.terminal.terminal_class));
    writer.u64(packet.terminal.sequence);

    writer.boolean(packet.reopen.present);
    writer.bytes(packet.reopen.terminal_id);
    writer.byte(static_cast<std::uint8_t>(packet.reopen.terminal_class));
    writer.bytes(packet.reopen.producer_administration_label_digest);
    writer.bytes(packet.reopen.reopener_administration_label_digest);
    writer.bytes(packet.reopen.receipt_digest);

    (void)writer.size();
    return output;
}

Digest membrane_commitment(const cut0::Packet& packet) noexcept {
    return digest_image(kMembraneDomain, encode_membrane(packet));
}

DossierImage encode_dossier(const Dossier& dossier) noexcept {
    DossierImage output{};
    Writer<dossier_image_size> writer(output);
    writer.bytes(kDossierMagic);
    writer.u64(kImageVersion);
    writer.bytes(encode_membrane(dossier.membrane));
    for (const PremiseRecord& record : dossier.external_records) {
        writer.boolean(record.present);
        writer.byte(static_cast<std::uint8_t>(record.edge));
        writer.bytes(record.subject_id);
        writer.bytes(record.membrane_commitment);
        writer.bytes(record.witness_digest);
        writer.bytes(record.source_identity_digest);
        writer.u64(record.sequence);
    }
    (void)writer.size();
    return output;
}

Digest dossier_commitment(const Dossier& dossier) noexcept {
    return digest_image(kDossierDomain, encode_dossier(dossier));
}

Evaluation evaluate(const Dossier& dossier) noexcept {
    const Digest exact_membrane = membrane_commitment(dossier.membrane);
    const Digest exact_dossier = dossier_commitment(dossier);
    const cut0::Evaluation membrane = cut0::evaluate(dossier.membrane);
    if (membrane.status == cut0::Status::rejected) {
        return result(
            Status::membrane_rejected,
            Fault::membrane_relation_rejected,
            0U,
            Edge::owner_constitution,
            false,
            false,
            exact_membrane,
            exact_dossier);
    }
    if (membrane.status != cut0::Status::reopen_record_bound) {
        return result(
            Status::membrane_prefix_incomplete,
            Fault::membrane_reopen_record_absent,
            0U,
            Edge::owner_constitution,
            false,
            false,
            exact_membrane,
            exact_dossier);
    }

    for (std::size_t index = 0U; index < edge_count; ++index) {
        const PremiseRecord& record = dossier.external_records[index];
        const Edge expected = edge_at(index);
        if (!record.present) {
            return result(Status::premise_record_missing, Fault::premise_missing,
                          index, expected, true, false,
                          exact_membrane, exact_dossier);
        }
        if (record.edge != expected) {
            return result(Status::premise_edge_mismatch,
                          Fault::premise_edge_mismatch,
                          index, expected, true, false,
                          exact_membrane, exact_dossier);
        }
        if (cut0::is_zero(record.subject_id)
            || cut0::is_zero(record.membrane_commitment)
            || cut0::is_zero(record.witness_digest)
            || cut0::is_zero(record.source_identity_digest)
            || record.sequence == 0U) {
            return result(Status::premise_record_incomplete,
                          Fault::premise_incomplete,
                          index, expected, true, false,
                          exact_membrane, exact_dossier);
        }
        if (record.subject_id != dossier.membrane.subject.id) {
            return result(Status::premise_subject_mismatch,
                          Fault::premise_subject_mismatch,
                          index, expected, true, false,
                          exact_membrane, exact_dossier);
        }
        if (record.membrane_commitment != exact_membrane) {
            return result(Status::premise_membrane_mismatch,
                          Fault::premise_membrane_mismatch,
                          index, expected, true, false,
                          exact_membrane, exact_dossier);
        }
        if (record.sequence != index + 1U) {
            return result(Status::premise_sequence_mismatch,
                          Fault::premise_sequence_mismatch,
                          index, expected, true, false,
                          exact_membrane, exact_dossier);
        }
    }

    return result(Status::external_record_set_bound, Fault::none,
                  edge_count, Edge::none, true, true,
                  exact_membrane, exact_dossier);
}

std::string_view edge_name(const Edge value) noexcept {
    switch (value) {
        case Edge::owner_constitution:
            return "owner_constitution";
        case Edge::acquisition_and_appraisal_enrollment:
            return "acquisition_and_appraisal_enrollment";
        case Edge::current_policy_selection:
            return "current_policy_selection";
        case Edge::protected_one_use_spend:
            return "protected_one_use_spend";
        case Edge::authenticated_effect_and_query:
            return "authenticated_effect_and_query";
        case Edge::independent_terminal_reopen:
            return "independent_terminal_reopen";
        case Edge::owner_admission:
            return "owner_admission";
        case Edge::release_constitution:
            return "release_constitution";
        case Edge::none:
            return "none";
    }
    return "invalid";
}

std::string_view status_name(const Status value) noexcept {
    switch (value) {
        case Status::membrane_rejected:
            return "membrane_rejected";
        case Status::membrane_prefix_incomplete:
            return "membrane_prefix_incomplete";
        case Status::premise_record_missing:
            return "premise_record_missing";
        case Status::premise_record_incomplete:
            return "premise_record_incomplete";
        case Status::premise_edge_mismatch:
            return "premise_edge_mismatch";
        case Status::premise_subject_mismatch:
            return "premise_subject_mismatch";
        case Status::premise_membrane_mismatch:
            return "premise_membrane_mismatch";
        case Status::premise_sequence_mismatch:
            return "premise_sequence_mismatch";
        case Status::external_record_set_bound:
            return "external_record_set_bound";
    }
    return "invalid";
}

std::string_view fault_name(const Fault value) noexcept {
    switch (value) {
        case Fault::none:
            return "none";
        case Fault::membrane_relation_rejected:
            return "membrane_relation_rejected";
        case Fault::membrane_reopen_record_absent:
            return "membrane_reopen_record_absent";
        case Fault::premise_missing:
            return "premise_missing";
        case Fault::premise_incomplete:
            return "premise_incomplete";
        case Fault::premise_edge_mismatch:
            return "premise_edge_mismatch";
        case Fault::premise_subject_mismatch:
            return "premise_subject_mismatch";
        case Fault::premise_membrane_mismatch:
            return "premise_membrane_mismatch";
        case Fault::premise_sequence_mismatch:
            return "premise_sequence_mismatch";
    }
    return "invalid";
}

}  // namespace slopos::e0::core_gate::nonpromotion
