#include "slopos/e0/core_gate/machine.hpp"

#include <sstream>

namespace slopos::e0::core_gate {
namespace {

[[nodiscard]] constexpr Subject event_subject(const Event event) noexcept {
    switch (event) {
        case Event::bind_evidence_alpha:
        case Event::appraise_allow_alpha:
        case Event::appraise_deny_alpha:
        case Event::decide_allow_alpha:
        case Event::decide_deny_alpha:
            return Subject::alpha;
        case Event::bind_evidence_beta:
        case Event::appraise_allow_beta:
        case Event::appraise_deny_beta:
        case Event::decide_allow_beta:
        case Event::decide_deny_beta:
            return Subject::beta;
        default:
            return Subject::none;
    }
}

[[nodiscard]] constexpr bool is_appraise_allow(const Event event) noexcept {
    return event == Event::appraise_allow_alpha
        || event == Event::appraise_allow_beta;
}

[[nodiscard]] constexpr bool is_decide_allow(const Event event) noexcept {
    return event == Event::decide_allow_alpha
        || event == Event::decide_allow_beta;
}

[[nodiscard]] Step applied(const State& state,
                           const bool effect = false,
                           const bool consumed = false) noexcept {
    return Step{Outcome::applied, state, effect, consumed};
}

[[nodiscard]] Step rejected(const State& state) noexcept {
    return Step{Outcome::rejected, state, false, false};
}

}  // namespace

State initial_state() noexcept { return State{}; }

bool invariant(const State& s) noexcept {
    if (s.effect_count > 1U) return false;
    if (s.published != (s.phase == Phase::published)) return false;
    if (s.published && s.result == Result::none) return false;
    if (s.effect_count == 1U && s.result != Result::effect) return false;
    if (s.result == Result::effect && s.effect_count != 1U) return false;
    if (s.result != Result::none
        && s.phase != Phase::terminal && s.phase != Phase::published) return false;
    if ((s.phase == Phase::terminal || s.phase == Phase::published)
        && s.result == Result::none) return false;
    if (s.phase == Phase::empty) {
        return s.evidence_subject == Subject::none
            && s.appraisal_subject == Subject::none
            && s.appraisal == Appraisal::none
            && s.decision_subject == Subject::none
            && s.decision == Decision::none
            && s.dispatch == Dispatch::not_issued
            && s.result == Result::none && !s.recovered;
    }
    if (s.evidence_subject == Subject::none) return false;
    if (s.phase == Phase::evidenced) {
        return s.appraisal_subject == Subject::none
            && s.appraisal == Appraisal::none
            && s.decision_subject == Subject::none
            && s.decision == Decision::none
            && s.dispatch == Dispatch::not_issued
            && s.result == Result::none && !s.recovered;
    }
    if (s.appraisal_subject != s.evidence_subject
        || s.appraisal == Appraisal::none) return false;
    if (s.phase == Phase::appraised) {
        return s.decision_subject == Subject::none
            && s.decision == Decision::none
            && s.dispatch == Dispatch::not_issued
            && s.result == Result::none && !s.recovered;
    }
    if (s.decision_subject != s.evidence_subject
        || s.decision == Decision::none) return false;
    if (s.decision == Decision::allow && s.appraisal != Appraisal::allow) return false;
    if (s.phase == Phase::decided) {
        return s.dispatch == Dispatch::not_issued
            && s.result == Result::none && !s.recovered;
    }
    if (s.phase == Phase::permit_live) {
        return s.decision == Decision::allow
            && s.dispatch == Dispatch::live
            && s.result == Result::none && !s.recovered;
    }
    if (s.phase == Phase::entered) {
        return s.decision == Decision::allow
            && s.dispatch == Dispatch::entered
            && s.result == Result::none && !s.recovered;
    }
    if (s.result == Result::uncertain && !s.recovered) {
        // An endpoint nonreturn is an uncertainty even before process recovery.
        return s.dispatch == Dispatch::burned;
    }
    if (s.result == Result::fail_stop) {
        return s.dispatch == Dispatch::burned && !s.recovered;
    }
    if (s.result == Result::no_effect) {
        return s.dispatch == Dispatch::terminal && s.effect_count == 0U;
    }
    if (s.result == Result::effect) {
        return s.dispatch == Dispatch::terminal && s.effect_count == 1U;
    }
    if (s.result == Result::uncertain && s.recovered) {
        return s.dispatch == Dispatch::burned;
    }
    return false;
}

Step step(const State& before, const Event event) noexcept {
    State next = before;
    switch (event) {
        case Event::bind_evidence_alpha:
        case Event::bind_evidence_beta:
            if (before.phase != Phase::empty) return rejected(before);
            next.phase = Phase::evidenced;
            next.evidence_subject = event_subject(event);
            return applied(next);

        case Event::appraise_allow_alpha:
        case Event::appraise_allow_beta:
        case Event::appraise_deny_alpha:
        case Event::appraise_deny_beta:
            if (before.phase != Phase::evidenced
                || before.evidence_subject != event_subject(event)) {
                return rejected(before);
            }
            next.phase = Phase::appraised;
            next.appraisal_subject = event_subject(event);
            next.appraisal = is_appraise_allow(event)
                ? Appraisal::allow : Appraisal::deny;
            return applied(next);

        case Event::decide_allow_alpha:
        case Event::decide_allow_beta:
        case Event::decide_deny_alpha:
        case Event::decide_deny_beta:
            if (before.phase != Phase::appraised
                || before.evidence_subject != event_subject(event)) {
                return rejected(before);
            }
            if (is_decide_allow(event) && before.appraisal != Appraisal::allow) {
                return rejected(before);
            }
            next.phase = Phase::decided;
            next.decision_subject = event_subject(event);
            next.decision = is_decide_allow(event)
                ? Decision::allow : Decision::deny;
            return applied(next);

        case Event::mint_permit:
            if (before.phase != Phase::decided
                || before.decision != Decision::allow
                || before.dispatch != Dispatch::not_issued) {
                return rejected(before);
            }
            next.phase = Phase::permit_live;
            next.dispatch = Dispatch::live;
            return applied(next);

        case Event::enter_exact:
            if (before.phase != Phase::permit_live
                || before.dispatch != Dispatch::live) {
                return rejected(before);
            }
            next.phase = Phase::entered;
            next.dispatch = Dispatch::entered;
            return applied(next, false, true);

        case Event::enter_subject_mismatch:
        case Event::enter_malformed:
        case Event::enter_route_override:
            if (before.phase != Phase::permit_live
                || before.dispatch != Dispatch::live) {
                return rejected(before);
            }
            // Consumption is deliberately before subject, encoding, or route
            // appraisal. Failure cannot preserve retry authority.
            next.phase = Phase::terminal;
            next.dispatch = Dispatch::burned;
            next.result = Result::fail_stop;
            return applied(next, false, true);

        case Event::endpoint_effect:
            if (before.phase != Phase::entered
                || before.dispatch != Dispatch::entered) {
                return rejected(before);
            }
            next.phase = Phase::terminal;
            next.dispatch = Dispatch::terminal;
            next.result = Result::effect;
            next.effect_count = 1U;
            return applied(next, true, false);

        case Event::endpoint_no_effect:
            if (before.phase != Phase::entered
                || before.dispatch != Dispatch::entered) {
                return rejected(before);
            }
            next.phase = Phase::terminal;
            next.dispatch = Dispatch::terminal;
            next.result = Result::no_effect;
            return applied(next);

        case Event::endpoint_nonreturn:
        case Event::endpoint_malformed:
            if (before.phase != Phase::entered
                || before.dispatch != Dispatch::entered) {
                return rejected(before);
            }
            next.phase = Phase::terminal;
            next.dispatch = Dispatch::burned;
            next.result = Result::uncertain;
            return applied(next);

        case Event::reconcile_effect:
            if (before.phase != Phase::terminal
                || before.result != Result::uncertain) {
                return rejected(before);
            }
            next.dispatch = Dispatch::terminal;
            next.result = Result::effect;
            next.effect_count = 1U;
            return applied(next);

        case Event::reconcile_no_effect:
            if (before.phase != Phase::terminal
                || before.result != Result::uncertain) {
                return rejected(before);
            }
            next.dispatch = Dispatch::terminal;
            next.result = Result::no_effect;
            next.effect_count = 0U;
            return applied(next);

        case Event::reconcile_mismatch:
            return rejected(before);

        case Event::publish:
            if (before.phase != Phase::terminal
                || before.result == Result::none || before.published) {
                return rejected(before);
            }
            next.phase = Phase::published;
            next.published = true;
            return applied(next);

        case Event::restart:
            if (before.phase != Phase::permit_live
                && before.phase != Phase::entered) {
                return rejected(before);
            }
            next.phase = Phase::terminal;
            next.dispatch = Dispatch::burned;
            next.result = Result::uncertain;
            next.recovered = true;
            return applied(next, false, before.phase == Phase::permit_live);

        case Event::recover_mint_attempt:
        case Event::proposer_route_override:
            return rejected(before);
    }
    return rejected(before);
}

std::string_view phase_name(const Phase value) noexcept {
    switch (value) {
        case Phase::empty: return "empty";
        case Phase::evidenced: return "evidenced";
        case Phase::appraised: return "appraised";
        case Phase::decided: return "decided";
        case Phase::permit_live: return "permit_live";
        case Phase::entered: return "entered";
        case Phase::terminal: return "terminal";
        case Phase::published: return "published";
    }
    return "invalid";
}

std::string_view subject_name(const Subject value) noexcept {
    switch (value) {
        case Subject::none: return "none";
        case Subject::alpha: return "alpha";
        case Subject::beta: return "beta";
    }
    return "invalid";
}

std::string_view appraisal_name(const Appraisal value) noexcept {
    switch (value) {
        case Appraisal::none: return "none";
        case Appraisal::allow: return "allow";
        case Appraisal::deny: return "deny";
    }
    return "invalid";
}

std::string_view decision_name(const Decision value) noexcept {
    switch (value) {
        case Decision::none: return "none";
        case Decision::allow: return "allow";
        case Decision::deny: return "deny";
    }
    return "invalid";
}

std::string_view dispatch_name(const Dispatch value) noexcept {
    switch (value) {
        case Dispatch::not_issued: return "not_issued";
        case Dispatch::live: return "live";
        case Dispatch::entered: return "entered";
        case Dispatch::burned: return "burned";
        case Dispatch::terminal: return "terminal";
    }
    return "invalid";
}

std::string_view result_name(const Result value) noexcept {
    switch (value) {
        case Result::none: return "none";
        case Result::effect: return "effect";
        case Result::no_effect: return "no_effect";
        case Result::uncertain: return "uncertain";
        case Result::fail_stop: return "fail_stop";
    }
    return "invalid";
}

std::string_view outcome_name(const Outcome value) noexcept {
    switch (value) {
        case Outcome::applied: return "applied";
        case Outcome::rejected: return "rejected";
    }
    return "invalid";
}

std::string_view event_name(const Event value) noexcept {
    switch (value) {
        case Event::bind_evidence_alpha: return "bind_evidence_alpha";
        case Event::bind_evidence_beta: return "bind_evidence_beta";
        case Event::appraise_allow_alpha: return "appraise_allow_alpha";
        case Event::appraise_allow_beta: return "appraise_allow_beta";
        case Event::appraise_deny_alpha: return "appraise_deny_alpha";
        case Event::appraise_deny_beta: return "appraise_deny_beta";
        case Event::decide_allow_alpha: return "decide_allow_alpha";
        case Event::decide_allow_beta: return "decide_allow_beta";
        case Event::decide_deny_alpha: return "decide_deny_alpha";
        case Event::decide_deny_beta: return "decide_deny_beta";
        case Event::mint_permit: return "mint_permit";
        case Event::enter_exact: return "enter_exact";
        case Event::enter_subject_mismatch: return "enter_subject_mismatch";
        case Event::enter_malformed: return "enter_malformed";
        case Event::enter_route_override: return "enter_route_override";
        case Event::endpoint_effect: return "endpoint_effect";
        case Event::endpoint_no_effect: return "endpoint_no_effect";
        case Event::endpoint_nonreturn: return "endpoint_nonreturn";
        case Event::endpoint_malformed: return "endpoint_malformed";
        case Event::reconcile_effect: return "reconcile_effect";
        case Event::reconcile_no_effect: return "reconcile_no_effect";
        case Event::reconcile_mismatch: return "reconcile_mismatch";
        case Event::publish: return "publish";
        case Event::restart: return "restart";
        case Event::recover_mint_attempt: return "recover_mint_attempt";
        case Event::proposer_route_override: return "proposer_route_override";
    }
    return "invalid";
}

std::string state_key(const State& s) {
    std::ostringstream out;
    out << phase_name(s.phase) << '|'
        << subject_name(s.evidence_subject) << '|'
        << subject_name(s.appraisal_subject) << '|'
        << appraisal_name(s.appraisal) << '|'
        << subject_name(s.decision_subject) << '|'
        << decision_name(s.decision) << '|'
        << dispatch_name(s.dispatch) << '|'
        << result_name(s.result) << '|'
        << (s.published ? '1' : '0') << '|'
        << (s.recovered ? '1' : '0') << '|'
        << static_cast<unsigned int>(s.effect_count);
    return out.str();
}

}  // namespace slopos::e0::core_gate
