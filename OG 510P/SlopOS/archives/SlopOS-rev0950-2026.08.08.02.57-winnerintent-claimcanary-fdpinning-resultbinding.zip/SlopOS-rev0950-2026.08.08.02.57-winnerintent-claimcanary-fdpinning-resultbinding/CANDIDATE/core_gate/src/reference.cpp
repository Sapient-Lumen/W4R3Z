#include "slopos/e0/core_gate/reference.hpp"

namespace slopos::e0::core_gate::reference {
namespace {

[[nodiscard]] Step reject(const State& state) noexcept {
    return Step{Outcome::rejected, state, false, false};
}

[[nodiscard]] Step accept(const State& state,
                          const bool effect = false,
                          const bool consumed = false) noexcept {
    return Step{Outcome::applied, state, effect, consumed};
}

[[nodiscard]] constexpr Subject named_subject(const Event event) noexcept {
    if (event == Event::bind_evidence_alpha
        || event == Event::appraise_allow_alpha
        || event == Event::appraise_deny_alpha
        || event == Event::decide_allow_alpha
        || event == Event::decide_deny_alpha) return Subject::alpha;
    if (event == Event::bind_evidence_beta
        || event == Event::appraise_allow_beta
        || event == Event::appraise_deny_beta
        || event == Event::decide_allow_beta
        || event == Event::decide_deny_beta) return Subject::beta;
    return Subject::none;
}

[[nodiscard]] constexpr bool one_of(const Event value,
                                    const Event a,
                                    const Event b) noexcept {
    return value == a || value == b;
}

}  // namespace

Step step(const State& before, const Event event) noexcept {
    State after = before;

    if (one_of(event, Event::bind_evidence_alpha,
               Event::bind_evidence_beta)) {
        if (before.phase != Phase::empty) return reject(before);
        after.phase = Phase::evidenced;
        after.evidence_subject = named_subject(event);
        return accept(after);
    }

    const bool appraisal_allow = one_of(
        event, Event::appraise_allow_alpha, Event::appraise_allow_beta);
    const bool appraisal_deny = one_of(
        event, Event::appraise_deny_alpha, Event::appraise_deny_beta);
    if (appraisal_allow || appraisal_deny) {
        const Subject subject = named_subject(event);
        if (before.phase != Phase::evidenced
            || before.evidence_subject != subject) return reject(before);
        after.phase = Phase::appraised;
        after.appraisal_subject = subject;
        after.appraisal = appraisal_allow ? Appraisal::allow : Appraisal::deny;
        return accept(after);
    }

    const bool decision_allow = one_of(
        event, Event::decide_allow_alpha, Event::decide_allow_beta);
    const bool decision_deny = one_of(
        event, Event::decide_deny_alpha, Event::decide_deny_beta);
    if (decision_allow || decision_deny) {
        const Subject subject = named_subject(event);
        const bool exact = before.phase == Phase::appraised
            && before.evidence_subject == subject
            && before.appraisal_subject == subject;
        if (!exact || (decision_allow && before.appraisal != Appraisal::allow)) {
            return reject(before);
        }
        after.phase = Phase::decided;
        after.decision_subject = subject;
        after.decision = decision_allow ? Decision::allow : Decision::deny;
        return accept(after);
    }

    if (event == Event::mint_permit) {
        const bool authorized = before.phase == Phase::decided
            && before.appraisal == Appraisal::allow
            && before.decision == Decision::allow
            && before.evidence_subject == before.appraisal_subject
            && before.evidence_subject == before.decision_subject
            && before.dispatch == Dispatch::not_issued;
        if (!authorized) return reject(before);
        after.phase = Phase::permit_live;
        after.dispatch = Dispatch::live;
        return accept(after);
    }

    const bool entry_attempt = event == Event::enter_exact
        || event == Event::enter_subject_mismatch
        || event == Event::enter_malformed
        || event == Event::enter_route_override;
    if (entry_attempt) {
        if (before.phase != Phase::permit_live
            || before.dispatch != Dispatch::live) return reject(before);
        if (event == Event::enter_exact) {
            after.phase = Phase::entered;
            after.dispatch = Dispatch::entered;
        } else {
            after.phase = Phase::terminal;
            after.dispatch = Dispatch::burned;
            after.result = Result::fail_stop;
        }
        return accept(after, false, true);
    }

    const bool endpoint_return = event == Event::endpoint_effect
        || event == Event::endpoint_no_effect
        || event == Event::endpoint_nonreturn
        || event == Event::endpoint_malformed;
    if (endpoint_return) {
        if (before.phase != Phase::entered
            || before.dispatch != Dispatch::entered) return reject(before);
        after.phase = Phase::terminal;
        if (event == Event::endpoint_effect) {
            after.dispatch = Dispatch::terminal;
            after.result = Result::effect;
            after.effect_count = 1U;
            return accept(after, true, false);
        }
        if (event == Event::endpoint_no_effect) {
            after.dispatch = Dispatch::terminal;
            after.result = Result::no_effect;
            return accept(after);
        }
        after.dispatch = Dispatch::burned;
        after.result = Result::uncertain;
        return accept(after);
    }

    if (event == Event::reconcile_effect
        || event == Event::reconcile_no_effect) {
        if (before.phase != Phase::terminal
            || before.result != Result::uncertain
            || before.dispatch != Dispatch::burned) return reject(before);
        after.dispatch = Dispatch::terminal;
        if (event == Event::reconcile_effect) {
            after.result = Result::effect;
            after.effect_count = 1U;
        } else {
            after.result = Result::no_effect;
            after.effect_count = 0U;
        }
        return accept(after);
    }

    if (event == Event::publish) {
        if (before.phase != Phase::terminal
            || before.result == Result::none) return reject(before);
        after.phase = Phase::published;
        after.published = true;
        return accept(after);
    }

    if (event == Event::restart) {
        const bool live = before.phase == Phase::permit_live
            && before.dispatch == Dispatch::live;
        const bool entered = before.phase == Phase::entered
            && before.dispatch == Dispatch::entered;
        if (!live && !entered) return reject(before);
        after.phase = Phase::terminal;
        after.dispatch = Dispatch::burned;
        after.result = Result::uncertain;
        after.recovered = true;
        return accept(after, false, live);
    }

    // Reconciliation mismatch, recovery mint, and proposer route selection
    // are explicit negative operations and preserve the complete state.
    return reject(before);
}

}  // namespace slopos::e0::core_gate::reference
