#include "slopos/e0/core_gate/membrane_cut0.hpp"

#include <algorithm>

namespace slopos::e0::core_gate::cut0 {
namespace {

[[nodiscard]] constexpr Evaluation reject(const Fault fault) noexcept {
    return Evaluation{Status::rejected, fault, false, false, false};
}

[[nodiscard]] constexpr bool valid_appraisal(
    const AppraisalVerdict value) noexcept {
    switch (value) {
        case AppraisalVerdict::pass:
        case AppraisalVerdict::deny:
        case AppraisalVerdict::indeterminate:
            return true;
    }
    return false;
}

[[nodiscard]] constexpr bool valid_terminal(
    const TerminalClass value) noexcept {
    switch (value) {
        case TerminalClass::effect:
        case TerminalClass::no_effect:
        case TerminalClass::uncertain:
        case TerminalClass::fail_stop:
            return true;
        case TerminalClass::none:
            return false;
    }
    return false;
}

}  // namespace

bool is_zero(const Digest& value) noexcept {
    return std::all_of(value.begin(), value.end(),
                       [](const std::uint8_t byte) { return byte == 0U; });
}

Evaluation evaluate(const Packet& p) noexcept {
    if (is_zero(p.subject.id) || is_zero(p.subject.artifact_digest)
        || is_zero(p.subject.appraisal_policy_digest)
        || p.subject.revision == 0U) {
        return reject(Fault::subject_incomplete);
    }

    if (is_zero(p.evidence.id) || is_zero(p.evidence.evidence_digest)
        || is_zero(p.evidence.acquisition_context_digest)) {
        return reject(Fault::evidence_incomplete);
    }
    if (p.evidence.subject_id != p.subject.id) {
        return reject(Fault::evidence_subject_mismatch);
    }

    if (is_zero(p.appraisal.id) || is_zero(p.appraisal.policy_digest)) {
        return reject(Fault::appraisal_incomplete);
    }
    if (p.appraisal.subject_id != p.subject.id) {
        return reject(Fault::appraisal_subject_mismatch);
    }
    if (p.appraisal.evidence_id != p.evidence.id) {
        return reject(Fault::appraisal_evidence_mismatch);
    }
    if (p.appraisal.policy_digest != p.subject.appraisal_policy_digest) {
        return reject(Fault::appraisal_policy_mismatch);
    }
    if (!valid_appraisal(p.appraisal.verdict)) {
        return reject(Fault::appraisal_verdict_invalid);
    }

    if (p.appraisal.verdict != AppraisalVerdict::pass) {
        if (p.permit.present || p.terminal.present || p.reopen.present) {
            return reject(Fault::post_closed_material);
        }
        const Status closed = p.appraisal.verdict == AppraisalVerdict::deny
            ? Status::closed_deny : Status::closed_indeterminate;
        return Evaluation{closed, Fault::none, false, false, false};
    }

    if (!p.permit.present) {
        if (p.terminal.present) return reject(Fault::terminal_without_permit);
        if (p.reopen.present) return reject(Fault::reopen_without_terminal);
        return Evaluation{Status::appraisal_pass_no_permit, Fault::none,
                          false, false, false};
    }
    if (is_zero(p.permit.id) || is_zero(p.permit.effect_digest)
        || is_zero(p.permit.spend_coordinate_digest) || p.permit.serial == 0U) {
        return reject(Fault::permit_incomplete);
    }
    if (p.permit.subject_id != p.subject.id) {
        return reject(Fault::permit_subject_mismatch);
    }
    if (p.permit.appraisal_id != p.appraisal.id) {
        return reject(Fault::permit_appraisal_mismatch);
    }

    if (!p.terminal.present) {
        if (p.reopen.present) return reject(Fault::reopen_without_terminal);
        return Evaluation{Status::permit_record_bound, Fault::none,
                          true, false, false};
    }
    if (is_zero(p.terminal.id) || is_zero(p.terminal.predecessor_digest)
        || p.terminal.sequence == 0U) {
        return reject(Fault::terminal_incomplete);
    }
    if (p.terminal.permit_id != p.permit.id) {
        return reject(Fault::terminal_permit_mismatch);
    }
    if (p.terminal.effect_digest != p.permit.effect_digest) {
        return reject(Fault::terminal_effect_mismatch);
    }
    if (!valid_terminal(p.terminal.terminal_class)) {
        return reject(Fault::terminal_class_invalid);
    }

    if (!p.reopen.present) {
        return Evaluation{Status::terminal_record_bound, Fault::none,
                          true, true, false};
    }
    if (is_zero(p.reopen.receipt_digest)
        || is_zero(p.reopen.producer_administration_label_digest)
        || is_zero(p.reopen.reopener_administration_label_digest)) {
        return reject(Fault::reopen_incomplete);
    }
    if (p.reopen.terminal_id != p.terminal.id) {
        return reject(Fault::reopen_terminal_mismatch);
    }
    if (p.reopen.terminal_class != p.terminal.terminal_class) {
        return reject(Fault::reopen_class_mismatch);
    }
    if (p.reopen.producer_administration_label_digest
        == p.reopen.reopener_administration_label_digest) {
        return reject(Fault::reopen_same_administration_label);
    }
    return Evaluation{Status::reopen_record_bound, Fault::none,
                      true, true, true};
}

std::string_view status_name(const Status value) noexcept {
    switch (value) {
        case Status::rejected: return "rejected";
        case Status::closed_deny: return "closed_deny";
        case Status::closed_indeterminate: return "closed_indeterminate";
        case Status::appraisal_pass_no_permit: return "appraisal_pass_no_permit";
        case Status::permit_record_bound:
            return "permit_record_bound";
        case Status::terminal_record_bound:
            return "terminal_record_bound";
        case Status::reopen_record_bound:
            return "reopen_record_bound";
    }
    return "invalid_status";
}

std::string_view fault_name(const Fault value) noexcept {
    switch (value) {
        case Fault::none: return "none";
        case Fault::subject_incomplete: return "subject_incomplete";
        case Fault::evidence_incomplete: return "evidence_incomplete";
        case Fault::evidence_subject_mismatch:
            return "evidence_subject_mismatch";
        case Fault::appraisal_incomplete: return "appraisal_incomplete";
        case Fault::appraisal_subject_mismatch:
            return "appraisal_subject_mismatch";
        case Fault::appraisal_evidence_mismatch:
            return "appraisal_evidence_mismatch";
        case Fault::appraisal_policy_mismatch:
            return "appraisal_policy_mismatch";
        case Fault::appraisal_verdict_invalid:
            return "appraisal_verdict_invalid";
        case Fault::post_closed_material: return "post_closed_material";
        case Fault::terminal_without_permit:
            return "terminal_without_permit";
        case Fault::reopen_without_terminal:
            return "reopen_without_terminal";
        case Fault::permit_incomplete: return "permit_incomplete";
        case Fault::permit_subject_mismatch:
            return "permit_subject_mismatch";
        case Fault::permit_appraisal_mismatch:
            return "permit_appraisal_mismatch";
        case Fault::terminal_incomplete: return "terminal_incomplete";
        case Fault::terminal_permit_mismatch:
            return "terminal_permit_mismatch";
        case Fault::terminal_effect_mismatch:
            return "terminal_effect_mismatch";
        case Fault::terminal_class_invalid:
            return "terminal_class_invalid";
        case Fault::reopen_incomplete: return "reopen_incomplete";
        case Fault::reopen_terminal_mismatch:
            return "reopen_terminal_mismatch";
        case Fault::reopen_class_mismatch:
            return "reopen_class_mismatch";
        case Fault::reopen_same_administration_label:
            return "reopen_same_administration_label";
    }
    return "invalid_fault";
}

std::string_view appraisal_name(const AppraisalVerdict value) noexcept {
    switch (value) {
        case AppraisalVerdict::pass: return "pass";
        case AppraisalVerdict::deny: return "deny";
        case AppraisalVerdict::indeterminate: return "indeterminate";
    }
    return "invalid_appraisal";
}

std::string_view terminal_name(const TerminalClass value) noexcept {
    switch (value) {
        case TerminalClass::none: return "none";
        case TerminalClass::effect: return "effect";
        case TerminalClass::no_effect: return "no_effect";
        case TerminalClass::uncertain: return "uncertain";
        case TerminalClass::fail_stop: return "fail_stop";
    }
    return "invalid_terminal";
}

}  // namespace slopos::e0::core_gate::cut0
