#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"

#include <algorithm>

namespace slopos::e0::core_gate::cut0::reference {
namespace {

[[nodiscard]] bool empty(const Digest& d) noexcept {
    return std::find_if(d.cbegin(), d.cend(),
                        [](const std::uint8_t v) { return v != 0U; })
        == d.cend();
}

[[nodiscard]] Evaluation bad(const Fault why) noexcept {
    Evaluation result{};
    result.status = Status::rejected;
    result.fault = why;
    return result;
}

[[nodiscard]] bool appraisal_member(const AppraisalVerdict verdict) noexcept {
    const auto raw = static_cast<unsigned int>(verdict);
    return raw <= static_cast<unsigned int>(AppraisalVerdict::indeterminate);
}

[[nodiscard]] bool terminal_member(const TerminalClass value) noexcept {
    const auto raw = static_cast<unsigned int>(value);
    return raw >= static_cast<unsigned int>(TerminalClass::effect)
        && raw <= static_cast<unsigned int>(TerminalClass::fail_stop);
}

}  // namespace

Evaluation evaluate(const Packet& q) noexcept {
    const std::array<bool, 4U> subject_fields{{
        !empty(q.subject.id), !empty(q.subject.artifact_digest),
        !empty(q.subject.appraisal_policy_digest), q.subject.revision != 0U}};
    if (!std::all_of(subject_fields.cbegin(), subject_fields.cend(),
                     [](const bool value) { return value; })) {
        return bad(Fault::subject_incomplete);
    }

    const std::array<bool, 3U> evidence_fields{{
        !empty(q.evidence.id), !empty(q.evidence.evidence_digest),
        !empty(q.evidence.acquisition_context_digest)}};
    if (!std::all_of(evidence_fields.cbegin(), evidence_fields.cend(),
                     [](const bool value) { return value; })) {
        return bad(Fault::evidence_incomplete);
    }
    if (!(q.evidence.subject_id == q.subject.id)) {
        return bad(Fault::evidence_subject_mismatch);
    }

    if (empty(q.appraisal.id) || empty(q.appraisal.policy_digest)) {
        return bad(Fault::appraisal_incomplete);
    }
    if (!(q.appraisal.subject_id == q.subject.id)) {
        return bad(Fault::appraisal_subject_mismatch);
    }
    if (!(q.appraisal.evidence_id == q.evidence.id)) {
        return bad(Fault::appraisal_evidence_mismatch);
    }
    if (!(q.appraisal.policy_digest == q.subject.appraisal_policy_digest)) {
        return bad(Fault::appraisal_policy_mismatch);
    }
    if (!appraisal_member(q.appraisal.verdict)) {
        return bad(Fault::appraisal_verdict_invalid);
    }

    const bool appraisal_closed = q.appraisal.verdict != AppraisalVerdict::pass;
    if (appraisal_closed) {
        const bool forbidden_tail = q.permit.present || q.terminal.present
            || q.reopen.present;
        if (forbidden_tail) return bad(Fault::post_closed_material);
        Evaluation result{};
        result.status = q.appraisal.verdict == AppraisalVerdict::deny
            ? Status::closed_deny : Status::closed_indeterminate;
        return result;
    }

    if (!q.permit.present) {
        if (q.terminal.present) return bad(Fault::terminal_without_permit);
        if (q.reopen.present) return bad(Fault::reopen_without_terminal);
        Evaluation result{};
        result.status = Status::appraisal_pass_no_permit;
        return result;
    }

    const std::array<bool, 4U> permit_fields{{
        !empty(q.permit.id), !empty(q.permit.effect_digest),
        !empty(q.permit.spend_coordinate_digest), q.permit.serial != 0U}};
    if (!std::all_of(permit_fields.cbegin(), permit_fields.cend(),
                     [](const bool value) { return value; })) {
        return bad(Fault::permit_incomplete);
    }
    if (!(q.permit.subject_id == q.subject.id)) {
        return bad(Fault::permit_subject_mismatch);
    }
    if (!(q.permit.appraisal_id == q.appraisal.id)) {
        return bad(Fault::permit_appraisal_mismatch);
    }

    if (!q.terminal.present) {
        if (q.reopen.present) return bad(Fault::reopen_without_terminal);
        Evaluation result{};
        result.status = Status::permit_record_bound;
        result.permit_record_bound = true;
        return result;
    }

    if (empty(q.terminal.id) || empty(q.terminal.predecessor_digest)
        || q.terminal.sequence == 0U) {
        return bad(Fault::terminal_incomplete);
    }
    if (!(q.terminal.permit_id == q.permit.id)) {
        return bad(Fault::terminal_permit_mismatch);
    }
    if (!(q.terminal.effect_digest == q.permit.effect_digest)) {
        return bad(Fault::terminal_effect_mismatch);
    }
    if (!terminal_member(q.terminal.terminal_class)) {
        return bad(Fault::terminal_class_invalid);
    }

    if (!q.reopen.present) {
        Evaluation result{};
        result.status = Status::terminal_record_bound;
        result.permit_record_bound = true;
        result.terminal_record_bound = true;
        return result;
    }

    const bool reopen_fields = !empty(q.reopen.receipt_digest)
        && !empty(q.reopen.producer_administration_label_digest)
        && !empty(q.reopen.reopener_administration_label_digest);
    if (!reopen_fields) return bad(Fault::reopen_incomplete);
    if (!(q.reopen.terminal_id == q.terminal.id)) {
        return bad(Fault::reopen_terminal_mismatch);
    }
    if (q.reopen.terminal_class != q.terminal.terminal_class) {
        return bad(Fault::reopen_class_mismatch);
    }
    if (q.reopen.producer_administration_label_digest
        == q.reopen.reopener_administration_label_digest) {
        return bad(Fault::reopen_same_administration_label);
    }

    Evaluation result{};
    result.status = Status::reopen_record_bound;
    result.permit_record_bound = true;
    result.terminal_record_bound = true;
    result.administration_labels_distinct = true;
    return result;
}

}  // namespace slopos::e0::core_gate::cut0::reference
