#include "slopos/e0/core_gate/machine.hpp"
#include "slopos/e0/core_gate/reference.hpp"

#include <algorithm>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::core_gate {
namespace {

struct Edge final {
    std::size_t state_id{};
    std::size_t depth{};
    Event event{};
    Step step{};
    std::size_t next_state_id{};
};

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

void write_states(const std::filesystem::path& output,
                  const std::vector<State>& states,
                  const std::vector<std::size_t>& depths) {
    std::ofstream out(output / "states.tsv", std::ios::binary);
    require(out.good(), "open states.tsv");
    out << "state_id\tdepth\tphase\tevidence_subject\tappraisal_subject\tappraisal"
           "\tdecision_subject\tdecision\tdispatch\tresult\tpublished\trecovered"
           "\teffect_count\tstate_key\n";
    for (std::size_t index = 0; index < states.size(); ++index) {
        const State& s = states[index];
        out << index << '\t' << depths[index] << '\t'
            << phase_name(s.phase) << '\t'
            << subject_name(s.evidence_subject) << '\t'
            << subject_name(s.appraisal_subject) << '\t'
            << appraisal_name(s.appraisal) << '\t'
            << subject_name(s.decision_subject) << '\t'
            << decision_name(s.decision) << '\t'
            << dispatch_name(s.dispatch) << '\t'
            << result_name(s.result) << '\t'
            << bool_text(s.published) << '\t'
            << bool_text(s.recovered) << '\t'
            << static_cast<unsigned int>(s.effect_count) << '\t'
            << state_key(s) << '\n';
    }
}

void write_edges(const std::filesystem::path& output,
                 const std::vector<Edge>& edges,
                 const std::vector<State>& states) {
    std::ofstream out(output / "relation.tsv", std::ios::binary);
    require(out.good(), "open relation.tsv");
    out << "state_id\tdepth\tevent\toutcome\tnext_state_id\teffect_emitted"
           "\tpermit_consumed\tbefore_key\tafter_key\n";
    for (const Edge& edge : edges) {
        out << edge.state_id << '\t' << edge.depth << '\t'
            << event_name(edge.event) << '\t'
            << outcome_name(edge.step.outcome) << '\t'
            << edge.next_state_id << '\t'
            << bool_text(edge.step.effect_emitted) << '\t'
            << bool_text(edge.step.permit_consumed) << '\t'
            << state_key(states[edge.state_id]) << '\t'
            << state_key(edge.step.state) << '\n';
    }
}

[[nodiscard]] const Edge& find_edge(const std::vector<Edge>& edges,
                                    const std::vector<State>& states,
                                    const Phase phase,
                                    const Result result,
                                    const bool recovered,
                                    const Event event) {
    const auto found = std::find_if(edges.begin(), edges.end(),
        [&](const Edge& edge) {
            const State& before = states[edge.state_id];
            return before.phase == phase && before.result == result
                && before.recovered == recovered && edge.event == event;
        });
    if (found == edges.end()) throw std::runtime_error("missing witness edge");
    return *found;
}

void write_witnesses(const std::filesystem::path& output,
                     const std::vector<Edge>& edges,
                     const std::vector<State>& states) {
    std::ofstream out(output / "witnesses.tsv", std::ios::binary);
    require(out.good(), "open witnesses.tsv");
    out << "name\tstate_id\tevent\toutcome\tnext_state_id\tpermit_consumed"
           "\teffect_emitted\tafter_result\n";

    const auto emit = [&](const std::string& name, const Edge& edge) {
        out << name << '\t' << edge.state_id << '\t'
            << event_name(edge.event) << '\t'
            << outcome_name(edge.step.outcome) << '\t'
            << edge.next_state_id << '\t'
            << bool_text(edge.step.permit_consumed) << '\t'
            << bool_text(edge.step.effect_emitted) << '\t'
            << result_name(edge.step.state.result) << '\n';
    };

    emit("entry_subject_mismatch_burns_permit",
         find_edge(edges, states, Phase::permit_live, Result::none, false,
                   Event::enter_subject_mismatch));
    emit("entry_malformed_burns_permit",
         find_edge(edges, states, Phase::permit_live, Result::none, false,
                   Event::enter_malformed));
    emit("entry_route_override_burns_permit",
         find_edge(edges, states, Phase::permit_live, Result::none, false,
                   Event::enter_route_override));
    emit("restart_live_permit_becomes_uncertain",
         find_edge(edges, states, Phase::permit_live, Result::none, false,
                   Event::restart));
    emit("restart_after_entry_becomes_uncertain",
         find_edge(edges, states, Phase::entered, Result::none, false,
                   Event::restart));
    emit("reconciliation_mismatch_preserves_uncertainty",
         find_edge(edges, states, Phase::terminal, Result::uncertain, true,
                   Event::reconcile_mismatch));
    emit("exact_reconciliation_can_establish_no_effect",
         find_edge(edges, states, Phase::terminal, Result::uncertain, true,
                   Event::reconcile_no_effect));
    emit("endpoint_effect_emits_once",
         find_edge(edges, states, Phase::entered, Result::none, false,
                   Event::endpoint_effect));
    emit("recovery_mint_is_rejected",
         find_edge(edges, states, Phase::terminal, Result::uncertain, true,
                   Event::recover_mint_attempt));
}

void write_summary(const std::filesystem::path& output,
                   const std::vector<State>& states,
                   const std::vector<std::size_t>& depths,
                   const std::vector<Edge>& edges,
                   const std::size_t applied,
                   const std::size_t rejected,
                   const std::size_t permit_consuming_edges,
                   const std::size_t failed_entry_burn_edges,
                   const std::size_t disagreements) {
    const std::size_t max_depth = *std::max_element(depths.begin(), depths.end());
    const auto max_effect = std::max_element(
        states.begin(), states.end(),
        [](const State& lhs, const State& rhs) {
            return lhs.effect_count < rhs.effect_count;
        });
    std::ofstream out(output / "summary.json", std::ios::binary);
    require(out.good(), "open summary.json");
    out << "{\n"
        << "  \"schema\": \"slopos.rev0885.core-gate-summary.v1\",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"states\": " << states.size() << ",\n"
        << "  \"transitions\": " << edges.size() << ",\n"
        << "  \"events_per_state\": " << kEvents.size() << ",\n"
        << "  \"applied\": " << applied << ",\n"
        << "  \"rejected\": " << rejected << ",\n"
        << "  \"maximum_depth\": " << max_depth << ",\n"
        << "  \"candidate_reference_disagreements\": " << disagreements << ",\n"
        << "  \"permit_consuming_edges\": " << permit_consuming_edges << ",\n"
        << "  \"failed_entry_burn_edges\": " << failed_entry_burn_edges << ",\n"
        << "  \"maximum_effect_count\": "
        << static_cast<unsigned int>(max_effect->effect_count) << ",\n"
        << "  \"recovery_mints\": 0,\n"
        << "  \"proposer_selected_routes\": 0,\n"
        << "  \"authenticated_evidence\": false,\n"
        << "  \"protected_effect\": false,\n"
        << "  \"durable_storage_proved\": false,\n"
        << "  \"independent_actor\": false\n"
        << "}\n";
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    require(!std::filesystem::exists(output), "output directory already exists");
    std::filesystem::create_directories(output);

    std::vector<State> states{initial_state()};
    std::vector<std::size_t> depths{0U};
    std::map<State, std::size_t> ids{{states.front(), 0U}};
    std::vector<Edge> edges;
    std::size_t applied_count = 0U;
    std::size_t rejected_count = 0U;
    std::size_t permit_consuming_edges = 0U;
    std::size_t failed_entry_burn_edges = 0U;
    std::size_t disagreements = 0U;

    for (std::size_t state_id = 0; state_id < states.size(); ++state_id) {
        const State before = states[state_id];
        require(invariant(before), "candidate state invariant");
        for (const Event event : kEvents) {
            const Step candidate = step(before, event);
            const Step oracle = reference::step(before, event);
            if (!(candidate == oracle)) ++disagreements;
            require(candidate == oracle, "candidate/reference disagreement");
            require(invariant(candidate.state), "next state invariant");
            if (candidate.outcome == Outcome::rejected) {
                require(candidate.state == before, "rejection changed state");
                require(!candidate.effect_emitted, "rejection emitted effect");
                require(!candidate.permit_consumed, "ordinary rejection consumed permit");
                ++rejected_count;
            } else {
                ++applied_count;
            }
            if (candidate.permit_consumed) ++permit_consuming_edges;
            if (candidate.permit_consumed
                && (event == Event::enter_subject_mismatch
                    || event == Event::enter_malformed
                    || event == Event::enter_route_override)) {
                ++failed_entry_burn_edges;
            }

            std::size_t next_id = state_id;
            const auto known = ids.find(candidate.state);
            if (known == ids.end()) {
                next_id = states.size();
                ids.emplace(candidate.state, next_id);
                states.push_back(candidate.state);
                depths.push_back(depths[state_id] + 1U);
            } else {
                next_id = known->second;
            }
            edges.push_back(Edge{state_id, depths[state_id], event,
                                 candidate, next_id});
        }
    }

    require(disagreements == 0U, "disagreements");
    require(edges.size() == states.size() * kEvents.size(), "relation saturation");
    write_states(output, states, depths);
    write_edges(output, edges, states);
    write_witnesses(output, edges, states);
    write_summary(output, states, depths, edges, applied_count,
                  rejected_count, permit_consuming_edges,
                  failed_entry_burn_edges, disagreements);
    std::cout << "CORE_GATE_CAMPAIGN=PASS states=" << states.size()
              << " transitions=" << edges.size()
              << " events=" << kEvents.size()
              << " disagreements=" << disagreements
              << " max_effect=1 authority=false protected_effect=false\n";
    return 0;
}

}  // namespace slopos::e0::core_gate
