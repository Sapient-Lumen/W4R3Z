#include "slopos/e0/core_gate/nonpromotion_kernel.hpp"
#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"
#include "slopos/e0/core_gate/nonpromotion_kernel_reference.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::core_gate::nonpromotion {
namespace {

struct ExpectedShape final {
    Status status{Status::membrane_rejected};
    Fault fault{Fault::membrane_relation_rejected};
    std::size_t bound{0U};
    Edge first_open{Edge::owner_constitution};
    bool membrane_bound{false};
    bool all_bound{false};
};

struct CuratedCase final {
    std::string name;
    Dossier dossier;
    ExpectedShape expected;
};

struct Observation final {
    Evaluation candidate;
    Evaluation independent;
    MembraneImage candidate_membrane_image;
    MembraneImage reference_membrane_image;
    DossierImage candidate_dossier_image;
    DossierImage reference_dossier_image;
    Digest candidate_membrane_commitment;
    Digest reference_membrane_commitment;
    Digest candidate_dossier_commitment;
    Digest reference_dossier_commitment;
};

enum class RecordMutation : std::uint8_t {
    missing,
    edge_mismatch,
    subject_zero,
    membrane_zero,
    witness_zero,
    source_zero,
    sequence_zero,
    subject_mismatch,
    membrane_mismatch,
    sequence_mismatch,
};

inline constexpr std::array<RecordMutation, 10U> kRecordMutations{{
    RecordMutation::missing,
    RecordMutation::edge_mismatch,
    RecordMutation::subject_zero,
    RecordMutation::membrane_zero,
    RecordMutation::witness_zero,
    RecordMutation::source_zero,
    RecordMutation::sequence_zero,
    RecordMutation::subject_mismatch,
    RecordMutation::membrane_mismatch,
    RecordMutation::sequence_mismatch,
}};

enum class TraceMutation : std::uint8_t {
    subject_identity_chain,
    subject_artifact_digest,
    appraisal_policy_chain,
    subject_revision,
    evidence_identity_chain,
    evidence_payload_digest,
    acquisition_context_digest,
    appraisal_identity_chain,
    permit_identity_chain,
    effect_digest_chain,
    spend_coordinate_digest,
    permit_serial,
    terminal_identity_chain,
    terminal_predecessor_digest,
    terminal_class_chain,
    terminal_sequence,
    producer_administration_label,
    reopener_administration_label,
    reopen_receipt_digest,
};

inline constexpr std::array<TraceMutation, 19U> kTraceMutations{{
    TraceMutation::subject_identity_chain,
    TraceMutation::subject_artifact_digest,
    TraceMutation::appraisal_policy_chain,
    TraceMutation::subject_revision,
    TraceMutation::evidence_identity_chain,
    TraceMutation::evidence_payload_digest,
    TraceMutation::acquisition_context_digest,
    TraceMutation::appraisal_identity_chain,
    TraceMutation::permit_identity_chain,
    TraceMutation::effect_digest_chain,
    TraceMutation::spend_coordinate_digest,
    TraceMutation::permit_serial,
    TraceMutation::terminal_identity_chain,
    TraceMutation::terminal_predecessor_digest,
    TraceMutation::terminal_class_chain,
    TraceMutation::terminal_sequence,
    TraceMutation::producer_administration_label,
    TraceMutation::reopener_administration_label,
    TraceMutation::reopen_receipt_digest,
}};

[[nodiscard]] Digest digest(const std::uint8_t marker) {
    Digest value{};
    value.fill(marker);
    return value;
}

[[nodiscard]] std::string hex(const auto& bytes) {
    constexpr std::array<char, 16U> digits{{
        '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', 'a', 'b', 'c', 'd', 'e', 'f',
    }};
    std::string result;
    result.reserve(bytes.size() * 2U);
    for (const std::uint8_t byte : bytes) {
        result.push_back(digits[static_cast<std::size_t>(byte >> 4U)]);
        result.push_back(digits[static_cast<std::size_t>(byte & 0x0fU)]);
    }
    return result;
}

[[nodiscard]] cut0::Packet complete_membrane() {
    cut0::Packet packet{};
    packet.subject = cut0::SubjectRecord{
        digest(1U), digest(2U), digest(3U), 931U};
    packet.evidence = cut0::EvidenceRecord{
        digest(4U), packet.subject.id, digest(5U), digest(6U)};
    packet.appraisal = cut0::AppraisalRecord{
        digest(7U), packet.subject.id, packet.evidence.id,
        packet.subject.appraisal_policy_digest, cut0::AppraisalVerdict::pass};
    packet.permit = cut0::PermitRecord{
        true, digest(8U), packet.subject.id, packet.appraisal.id,
        digest(9U), digest(10U), 1U};
    packet.terminal = cut0::TerminalRecord{
        true, digest(11U), packet.permit.id, packet.permit.effect_digest,
        digest(12U), cut0::TerminalClass::effect, 1U};
    packet.reopen = cut0::ReopenRecord{
        true, packet.terminal.id, packet.terminal.terminal_class,
        digest(13U), digest(14U), digest(15U)};
    return packet;
}

[[nodiscard]] Dossier complete_dossier() {
    Dossier dossier{};
    dossier.membrane = complete_membrane();
    const Digest exact_membrane = membrane_commitment(dossier.membrane);
    for (std::size_t index = 0U; index < edge_count; ++index) {
        dossier.external_records[index] = PremiseRecord{
            true,
            static_cast<Edge>(index),
            dossier.membrane.subject.id,
            exact_membrane,
            digest(static_cast<std::uint8_t>(20U + index)),
            digest(static_cast<std::uint8_t>(40U + index)),
            static_cast<std::uint64_t>(index) + 1U,
        };
    }
    return dossier;
}

[[nodiscard]] constexpr ExpectedShape shape(
    const Status status,
    const Fault fault,
    const std::size_t bound,
    const Edge first_open,
    const bool membrane_bound,
    const bool all_bound) noexcept {
    return ExpectedShape{
        status, fault, bound, first_open, membrane_bound, all_bound};
}

[[nodiscard]] constexpr std::string_view mutation_name(
    const RecordMutation mutation) noexcept {
    switch (mutation) {
        case RecordMutation::missing: return "missing";
        case RecordMutation::edge_mismatch: return "edge_mismatch";
        case RecordMutation::subject_zero: return "subject_zero";
        case RecordMutation::membrane_zero: return "membrane_zero";
        case RecordMutation::witness_zero: return "witness_zero";
        case RecordMutation::source_zero: return "source_zero";
        case RecordMutation::sequence_zero: return "sequence_zero";
        case RecordMutation::subject_mismatch: return "subject_mismatch";
        case RecordMutation::membrane_mismatch: return "membrane_mismatch";
        case RecordMutation::sequence_mismatch: return "sequence_mismatch";
    }
    return "invalid";
}

[[nodiscard]] constexpr ExpectedShape expected_for(
    const RecordMutation mutation,
    const std::size_t index) noexcept {
    const Edge edge = static_cast<Edge>(index);
    switch (mutation) {
        case RecordMutation::missing:
            return shape(Status::premise_record_missing,
                         Fault::premise_missing, index, edge, true, false);
        case RecordMutation::edge_mismatch:
            return shape(Status::premise_edge_mismatch,
                         Fault::premise_edge_mismatch, index, edge, true, false);
        case RecordMutation::subject_zero:
        case RecordMutation::membrane_zero:
        case RecordMutation::witness_zero:
        case RecordMutation::source_zero:
        case RecordMutation::sequence_zero:
            return shape(Status::premise_record_incomplete,
                         Fault::premise_incomplete, index, edge, true, false);
        case RecordMutation::subject_mismatch:
            return shape(Status::premise_subject_mismatch,
                         Fault::premise_subject_mismatch, index, edge, true, false);
        case RecordMutation::membrane_mismatch:
            return shape(Status::premise_membrane_mismatch,
                         Fault::premise_membrane_mismatch, index, edge, true, false);
        case RecordMutation::sequence_mismatch:
            return shape(Status::premise_sequence_mismatch,
                         Fault::premise_sequence_mismatch, index, edge, true, false);
    }
    return {};
}

void apply_record_mutation(PremiseRecord& record,
                           const RecordMutation mutation,
                           const std::size_t index) {
    switch (mutation) {
        case RecordMutation::missing:
            record.present = false;
            break;
        case RecordMutation::edge_mismatch:
            record.edge = Edge::none;
            break;
        case RecordMutation::subject_zero:
            record.subject_id = Digest{};
            break;
        case RecordMutation::membrane_zero:
            record.membrane_commitment = Digest{};
            break;
        case RecordMutation::witness_zero:
            record.witness_digest = Digest{};
            break;
        case RecordMutation::source_zero:
            record.source_identity_digest = Digest{};
            break;
        case RecordMutation::sequence_zero:
            record.sequence = 0U;
            break;
        case RecordMutation::subject_mismatch:
            record.subject_id = digest(
                static_cast<std::uint8_t>(160U + index));
            break;
        case RecordMutation::membrane_mismatch:
            record.membrane_commitment = digest(
                static_cast<std::uint8_t>(180U + index));
            break;
        case RecordMutation::sequence_mismatch:
            record.sequence = static_cast<std::uint64_t>(index) + 9U;
            break;
    }
}

[[nodiscard]] constexpr std::string_view trace_name(
    const TraceMutation mutation) noexcept {
    switch (mutation) {
        case TraceMutation::subject_identity_chain: return "subject_identity_chain";
        case TraceMutation::subject_artifact_digest: return "subject_artifact_digest";
        case TraceMutation::appraisal_policy_chain: return "appraisal_policy_chain";
        case TraceMutation::subject_revision: return "subject_revision";
        case TraceMutation::evidence_identity_chain: return "evidence_identity_chain";
        case TraceMutation::evidence_payload_digest: return "evidence_payload_digest";
        case TraceMutation::acquisition_context_digest: return "acquisition_context_digest";
        case TraceMutation::appraisal_identity_chain: return "appraisal_identity_chain";
        case TraceMutation::permit_identity_chain: return "permit_identity_chain";
        case TraceMutation::effect_digest_chain: return "effect_digest_chain";
        case TraceMutation::spend_coordinate_digest: return "spend_coordinate_digest";
        case TraceMutation::permit_serial: return "permit_serial";
        case TraceMutation::terminal_identity_chain: return "terminal_identity_chain";
        case TraceMutation::terminal_predecessor_digest: return "terminal_predecessor_digest";
        case TraceMutation::terminal_class_chain: return "terminal_class_chain";
        case TraceMutation::terminal_sequence: return "terminal_sequence";
        case TraceMutation::producer_administration_label: return "producer_administration_label";
        case TraceMutation::reopener_administration_label: return "reopener_administration_label";
        case TraceMutation::reopen_receipt_digest: return "reopen_receipt_digest";
    }
    return "invalid";
}

void apply_trace_mutation(Dossier& dossier, const TraceMutation mutation) {
    cut0::Packet& packet = dossier.membrane;
    switch (mutation) {
        case TraceMutation::subject_identity_chain: {
            const Digest replacement = digest(101U);
            packet.subject.id = replacement;
            packet.evidence.subject_id = replacement;
            packet.appraisal.subject_id = replacement;
            packet.permit.subject_id = replacement;
            for (PremiseRecord& record : dossier.external_records) {
                record.subject_id = replacement;
            }
            break;
        }
        case TraceMutation::subject_artifact_digest:
            packet.subject.artifact_digest = digest(102U);
            break;
        case TraceMutation::appraisal_policy_chain: {
            const Digest replacement = digest(103U);
            packet.subject.appraisal_policy_digest = replacement;
            packet.appraisal.policy_digest = replacement;
            break;
        }
        case TraceMutation::subject_revision:
            packet.subject.revision = 932U;
            break;
        case TraceMutation::evidence_identity_chain:
            packet.evidence.id = digest(104U);
            packet.appraisal.evidence_id = packet.evidence.id;
            break;
        case TraceMutation::evidence_payload_digest:
            packet.evidence.evidence_digest = digest(105U);
            break;
        case TraceMutation::acquisition_context_digest:
            packet.evidence.acquisition_context_digest = digest(106U);
            break;
        case TraceMutation::appraisal_identity_chain:
            packet.appraisal.id = digest(107U);
            packet.permit.appraisal_id = packet.appraisal.id;
            break;
        case TraceMutation::permit_identity_chain:
            packet.permit.id = digest(108U);
            packet.terminal.permit_id = packet.permit.id;
            break;
        case TraceMutation::effect_digest_chain:
            packet.permit.effect_digest = digest(109U);
            packet.terminal.effect_digest = packet.permit.effect_digest;
            break;
        case TraceMutation::spend_coordinate_digest:
            packet.permit.spend_coordinate_digest = digest(110U);
            break;
        case TraceMutation::permit_serial:
            packet.permit.serial = 2U;
            break;
        case TraceMutation::terminal_identity_chain:
            packet.terminal.id = digest(111U);
            packet.reopen.terminal_id = packet.terminal.id;
            break;
        case TraceMutation::terminal_predecessor_digest:
            packet.terminal.predecessor_digest = digest(112U);
            break;
        case TraceMutation::terminal_class_chain:
            packet.terminal.terminal_class = cut0::TerminalClass::no_effect;
            packet.reopen.terminal_class = packet.terminal.terminal_class;
            break;
        case TraceMutation::terminal_sequence:
            packet.terminal.sequence = 2U;
            break;
        case TraceMutation::producer_administration_label:
            packet.reopen.producer_administration_label_digest = digest(113U);
            break;
        case TraceMutation::reopener_administration_label:
            packet.reopen.reopener_administration_label_digest = digest(114U);
            break;
        case TraceMutation::reopen_receipt_digest:
            packet.reopen.receipt_digest = digest(115U);
            break;
    }
}

void open_output(std::ofstream& stream, const std::filesystem::path& path) {
    stream.open(path, std::ios::out | std::ios::trunc);
    if (!stream.is_open()) {
        throw std::runtime_error("cannot open output: " + path.string());
    }
    stream.exceptions(std::ios::badbit | std::ios::failbit);
}

void require_nonpromotion(const Evaluation& value,
                          const std::string_view label) {
    if (authority_granted(value) || epoch_exit_proved(value)) {
        throw std::runtime_error(
            "nonpromotion API invariant failed: " + std::string(label));
    }
}

[[nodiscard]] Observation observe(const Dossier& dossier,
                                  const std::string_view label) {
    Observation observed{
        evaluate(dossier),
        reference::evaluate(dossier),
        encode_membrane(dossier.membrane),
        reference::encode_membrane(dossier.membrane),
        encode_dossier(dossier),
        reference::encode_dossier(dossier),
        membrane_commitment(dossier.membrane),
        reference::membrane_commitment(dossier.membrane),
        dossier_commitment(dossier),
        reference::dossier_commitment(dossier),
    };
    if (observed.candidate_membrane_image != observed.reference_membrane_image) {
        throw std::runtime_error(
            "membrane image disagreement: " + std::string(label));
    }
    if (observed.candidate_dossier_image != observed.reference_dossier_image) {
        throw std::runtime_error(
            "dossier image disagreement: " + std::string(label));
    }
    if (observed.candidate_membrane_commitment
            != observed.reference_membrane_commitment
        || observed.candidate_dossier_commitment
            != observed.reference_dossier_commitment) {
        throw std::runtime_error(
            "commitment disagreement: " + std::string(label));
    }
    if (observed.candidate != observed.independent) {
        throw std::runtime_error(
            "evaluation disagreement: " + std::string(label));
    }
    if (observed.candidate.membrane_commitment
            != observed.candidate_membrane_commitment
        || observed.candidate.dossier_commitment
            != observed.candidate_dossier_commitment) {
        throw std::runtime_error(
            "evaluation commitment mismatch: " + std::string(label));
    }
    require_nonpromotion(observed.candidate, label);
    require_nonpromotion(observed.independent, label);
    return observed;
}

void require_shape(const Evaluation& value,
                   const ExpectedShape& expected,
                   const std::string_view label) {
    if (value.status != expected.status
        || value.fault != expected.fault
        || value.bound_premise_records != expected.bound
        || value.first_open_edge != expected.first_open
        || value.membrane_reopen_record_bound != expected.membrane_bound
        || value.all_external_records_bound != expected.all_bound) {
        throw std::runtime_error(
            "expectation mismatch: " + std::string(label));
    }
}

void add(std::vector<CuratedCase>& cases,
         const std::string& name,
         const Dossier& dossier,
         const ExpectedShape& expected) {
    cases.push_back(CuratedCase{name, dossier, expected});
}

[[nodiscard]] std::vector<CuratedCase> curated_cases() {
    std::vector<CuratedCase> cases;
    cases.reserve(83U);

    Dossier dossier = complete_dossier();
    add(cases, "all_external_records_bound", dossier,
        shape(Status::external_record_set_bound, Fault::none,
              edge_count, Edge::none, true, true));

    dossier = complete_dossier();
    dossier.membrane.subject.id = Digest{};
    add(cases, "membrane_relation_rejected", dossier,
        shape(Status::membrane_rejected, Fault::membrane_relation_rejected,
              0U, Edge::owner_constitution, false, false));

    dossier = complete_dossier();
    dossier.membrane.reopen.present = false;
    add(cases, "membrane_reopen_absent", dossier,
        shape(Status::membrane_prefix_incomplete,
              Fault::membrane_reopen_record_absent,
              0U, Edge::owner_constitution, false, false));

    for (std::size_t index = 0U; index < edge_count; ++index) {
        for (const RecordMutation mutation : kRecordMutations) {
            dossier = complete_dossier();
            apply_record_mutation(dossier.external_records[index], mutation, index);
            const std::string name = std::string(mutation_name(mutation))
                + "_" + std::string(edge_name(static_cast<Edge>(index)));
            add(cases, name, dossier, expected_for(mutation, index));
        }
    }
    return cases;
}

void write_common_columns(std::ofstream& stream,
                          const ExpectedShape& expected,
                          const Observation& observed) {
    stream
        << status_name(expected.status) << '\t'
        << status_name(observed.candidate.status) << '\t'
        << status_name(observed.independent.status) << '\t'
        << fault_name(expected.fault) << '\t'
        << fault_name(observed.candidate.fault) << '\t'
        << fault_name(observed.independent.fault) << '\t'
        << expected.bound << '\t'
        << static_cast<unsigned int>(observed.candidate.bound_premise_records) << '\t'
        << static_cast<unsigned int>(observed.independent.bound_premise_records) << '\t'
        << edge_name(expected.first_open) << '\t'
        << edge_name(observed.candidate.first_open_edge) << '\t'
        << edge_name(observed.independent.first_open_edge) << '\t'
        << (observed.candidate.membrane_reopen_record_bound ? "true" : "false") << '\t'
        << (observed.candidate.all_external_records_bound ? "true" : "false") << '\t'
        << hex(observed.candidate_membrane_commitment) << '\t'
        << hex(observed.candidate_dossier_commitment) << '\t'
        << "false\tfalse\n";
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    if (std::filesystem::exists(output)) {
        throw std::runtime_error("output already exists");
    }
    std::filesystem::create_directories(output);

    const std::vector<CuratedCase> cases = curated_cases();
    if (cases.size() != 83U) {
        throw std::runtime_error("curated case inventory mismatch");
    }

    std::ofstream curated;
    open_output(curated, output / "curated.tsv");
    curated
        << "case\texpected_status\tcandidate_status\treference_status"
        << "\texpected_fault\tcandidate_fault\treference_fault"
        << "\texpected_bound\tcandidate_bound\treference_bound"
        << "\texpected_first_open\tcandidate_first_open\treference_first_open"
        << "\tmembrane_reopen_record_bound\tall_external_records_bound"
        << "\tmembrane_commitment\tdossier_commitment"
        << "\tauthority_granted\tepoch_exit_proved\n";
    for (const CuratedCase& item : cases) {
        const Observation observed = observe(item.dossier, item.name);
        require_shape(observed.candidate, item.expected, item.name);
        curated << item.name << '\t';
        write_common_columns(curated, item.expected, observed);
    }
    curated.close();

    constexpr std::uint32_t presence_cases = 1U << edge_count;
    std::uint64_t complete_presence_sets = 0U;
    std::ofstream presence;
    open_output(presence, output / "presence.tsv");
    presence
        << "mask\texpected_status\tcandidate_status\treference_status"
        << "\texpected_bound\tcandidate_bound\treference_bound"
        << "\texpected_first_open\tcandidate_first_open\treference_first_open"
        << "\tauthority_granted\tepoch_exit_proved\n";
    for (std::uint32_t mask = 0U; mask < presence_cases; ++mask) {
        Dossier dossier = complete_dossier();
        std::size_t first_missing = edge_count;
        for (std::size_t index = 0U; index < edge_count; ++index) {
            const std::uint32_t bit = 1U << index;
            const bool present = (mask & bit) != 0U;
            dossier.external_records[index].present = present;
            if (!present && first_missing == edge_count) {
                first_missing = index;
            }
        }
        const ExpectedShape expected = first_missing == edge_count
            ? shape(Status::external_record_set_bound, Fault::none,
                    edge_count, Edge::none, true, true)
            : shape(Status::premise_record_missing, Fault::premise_missing,
                    first_missing, static_cast<Edge>(first_missing), true, false);
        const Observation observed = observe(dossier, "presence");
        require_shape(observed.candidate, expected, "presence");
        if (observed.candidate.status == Status::external_record_set_bound) {
            ++complete_presence_sets;
        }
        presence
            << mask << '\t'
            << status_name(expected.status) << '\t'
            << status_name(observed.candidate.status) << '\t'
            << status_name(observed.independent.status) << '\t'
            << expected.bound << '\t'
            << static_cast<unsigned int>(observed.candidate.bound_premise_records) << '\t'
            << static_cast<unsigned int>(observed.independent.bound_premise_records) << '\t'
            << edge_name(expected.first_open) << '\t'
            << edge_name(observed.candidate.first_open_edge) << '\t'
            << edge_name(observed.independent.first_open_edge) << '\t'
            << "false\tfalse\n";
    }
    presence.close();
    if (complete_presence_sets != 1U) {
        throw std::runtime_error("presence closure mismatch");
    }

    const Dossier baseline = complete_dossier();
    const Observation baseline_observed = observe(baseline, "trace-baseline");
    std::ofstream trace;
    open_output(trace, output / "trace-binding.tsv");
    trace
        << "case\tcut0_status\texpected_status\tcandidate_status\treference_status"
        << "\tbaseline_membrane_commitment\tmutated_membrane_commitment"
        << "\tmutated_dossier_commitment\tcommitment_changed"
        << "\tauthority_granted\tepoch_exit_proved\n";
    for (const TraceMutation mutation : kTraceMutations) {
        Dossier dossier = baseline;
        apply_trace_mutation(dossier, mutation);
        const cut0::Evaluation membrane_candidate = cut0::evaluate(dossier.membrane);
        const cut0::Evaluation membrane_reference =
            cut0::reference::evaluate(dossier.membrane);
        if (membrane_candidate != membrane_reference
            || membrane_candidate.status != cut0::Status::reopen_record_bound) {
            throw std::runtime_error(
                "trace mutation broke membrane relation: "
                + std::string(trace_name(mutation)));
        }
        const Observation observed = observe(dossier, trace_name(mutation));
        const ExpectedShape expected = shape(
            Status::premise_membrane_mismatch,
            Fault::premise_membrane_mismatch,
            0U, Edge::owner_constitution, true, false);
        require_shape(observed.candidate, expected, trace_name(mutation));
        if (observed.candidate_membrane_commitment
            == baseline_observed.candidate_membrane_commitment) {
            throw std::runtime_error(
                "trace commitment unchanged: "
                + std::string(trace_name(mutation)));
        }
        trace
            << trace_name(mutation) << '\t'
            << cut0::status_name(membrane_candidate.status) << '\t'
            << status_name(expected.status) << '\t'
            << status_name(observed.candidate.status) << '\t'
            << status_name(observed.independent.status) << '\t'
            << hex(baseline_observed.candidate_membrane_commitment) << '\t'
            << hex(observed.candidate_membrane_commitment) << '\t'
            << hex(observed.candidate_dossier_commitment) << '\t'
            << "true\tfalse\tfalse\n";
    }
    trace.close();

    Dossier absent_a = baseline;
    absent_a.external_records[0U].present = false;
    Dossier absent_b = absent_a;
    absent_b.external_records[0U].witness_digest = digest(240U);
    const Observation absent_a_observed = observe(absent_a, "absent-payload-a");
    const Observation absent_b_observed = observe(absent_b, "absent-payload-b");
    const ExpectedShape absent_expected = shape(
        Status::premise_record_missing, Fault::premise_missing,
        0U, Edge::owner_constitution, true, false);
    require_shape(absent_a_observed.candidate, absent_expected, "absent-payload-a");
    require_shape(absent_b_observed.candidate, absent_expected, "absent-payload-b");
    if (absent_a_observed.candidate_dossier_commitment
        == absent_b_observed.candidate_dossier_commitment) {
        throw std::runtime_error("absent payload escaped dossier commitment");
    }

    std::ofstream vectors;
    open_output(vectors, output / "commitment-vectors.tsv");
    vectors << "vector\tobject\tbytes\timage_hex\tcommitment\n";
    vectors
        << "baseline_membrane\tmembrane\t" << membrane_image_size << '\t'
        << hex(baseline_observed.candidate_membrane_image) << '\t'
        << hex(baseline_observed.candidate_membrane_commitment) << '\n'
        << "baseline_dossier\tdossier\t" << dossier_image_size << '\t'
        << hex(baseline_observed.candidate_dossier_image) << '\t'
        << hex(baseline_observed.candidate_dossier_commitment) << '\n'
        << "absent_payload_a\tdossier\t" << dossier_image_size << '\t'
        << hex(absent_a_observed.candidate_dossier_image) << '\t'
        << hex(absent_a_observed.candidate_dossier_commitment) << '\n'
        << "absent_payload_b\tdossier\t" << dossier_image_size << '\t'
        << hex(absent_b_observed.candidate_dossier_image) << '\t'
        << hex(absent_b_observed.candidate_dossier_commitment) << '\n';
    vectors.close();

    const std::uint64_t total_cases = static_cast<std::uint64_t>(cases.size())
        + presence_cases + static_cast<std::uint64_t>(kTraceMutations.size())
        + 2U;
    std::ofstream summary;
    open_output(summary, output / "summary.json");
    summary
        << "{\n"
        << "  \"absent_payload_committed\": true,\n"
        << "  \"authority_granted\": false,\n"
        << "  \"candidate_reference_disagreements\": 0,\n"
        << "  \"canonical_dossier_bytes\": " << dossier_image_size << ",\n"
        << "  \"canonical_membrane_bytes\": " << membrane_image_size << ",\n"
        << "  \"commitment_vectors\": 4,\n"
        << "  \"curated_cases\": " << cases.size() << ",\n"
        << "  \"epoch_exit_proved\": false,\n"
        << "  \"external_premise_records\": " << edge_count << ",\n"
        << "  \"external_witness_truth_proved\": false,\n"
        << "  \"highest_status\": \"external_record_set_bound\",\n"
        << "  \"owner_admission_proved\": false,\n"
        << "  \"presence_cases\": " << presence_cases << ",\n"
        << "  \"schema\": \"slopos.rev0931.nonpromotion-kernel-campaign.v2\",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"trace_binding_cases\": " << kTraceMutations.size() << ",\n"
        << "  \"total_cases\": " << total_cases << "\n"
        << "}\n";
    summary.close();

    std::cout
        << "NONPROMOTION_KERNEL_CAMPAIGN=PASS curated=" << cases.size()
        << " presence=" << presence_cases
        << " trace_binding=" << kTraceMutations.size()
        << " absent_payload=2 total=" << total_cases
        << " disagreements=0 exact_images=true authority=false epoch_zero=true\n";
    return 0;
}

}  // namespace slopos::e0::core_gate::nonpromotion
