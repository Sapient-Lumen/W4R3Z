#include "slopos/e0/core_gate/membrane_cut0.hpp"
#include "slopos/e0/core_gate/membrane_cut0_reference.hpp"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::core_gate::cut0 {
namespace {

struct CuratedCase final {
    std::string name;
    Packet packet;
    Evaluation expected;
};

[[nodiscard]] Digest digest(const std::uint8_t marker) {
    Digest value{};
    value.fill(marker);
    return value;
}

[[nodiscard]] Packet complete_packet(
    const TerminalClass terminal_class = TerminalClass::effect) {
    Packet p{};
    p.subject = SubjectRecord{digest(1U), digest(2U), digest(3U), 29U};
    p.evidence = EvidenceRecord{
        digest(4U), p.subject.id, digest(5U), digest(6U)};
    p.appraisal = AppraisalRecord{
        digest(7U), p.subject.id, p.evidence.id,
        p.subject.appraisal_policy_digest, AppraisalVerdict::pass};
    p.permit = PermitRecord{
        true, digest(8U), p.subject.id, p.appraisal.id,
        digest(9U), digest(10U), 1U};
    p.terminal = TerminalRecord{
        true, digest(11U), p.permit.id, p.permit.effect_digest,
        digest(12U), terminal_class, 1U};
    p.reopen = ReopenRecord{
        true, p.terminal.id, terminal_class,
        digest(13U), digest(14U), digest(15U)};
    return p;
}

[[nodiscard]] Evaluation expected(const Status status,
                                  const Fault fault = Fault::none,
                                  const bool permit_bound = false,
                                  const bool terminal_bound = false,
                                  const bool labels_distinct = false) {
    return Evaluation{status, fault, permit_bound, terminal_bound, labels_distinct};
}

void add_case(std::vector<CuratedCase>& cases,
              const std::string_view name,
              const Packet& packet,
              const Evaluation& result) {
    cases.push_back(CuratedCase{std::string(name), packet, result});
}

[[nodiscard]] std::vector<CuratedCase> curated_cases() {
    std::vector<CuratedCase> cases;
    cases.reserve(31U);

    Packet p = complete_packet();
    p.appraisal.verdict = AppraisalVerdict::deny;
    p.permit.present = false;
    p.terminal.present = false;
    p.reopen.present = false;
    add_case(cases, "closed_deny", p, expected(Status::closed_deny));

    p.appraisal.verdict = AppraisalVerdict::indeterminate;
    add_case(cases, "closed_indeterminate", p,
             expected(Status::closed_indeterminate));

    p = complete_packet();
    p.permit.present = false;
    p.terminal.present = false;
    p.reopen.present = false;
    add_case(cases, "appraisal_pass_no_permit", p,
             expected(Status::appraisal_pass_no_permit));

    p = complete_packet();
    p.terminal.present = false;
    p.reopen.present = false;
    add_case(cases, "permit_record_bound", p,
             expected(Status::permit_record_bound, Fault::none, true));

    for (const auto terminal_class : {
             TerminalClass::effect, TerminalClass::no_effect,
             TerminalClass::uncertain, TerminalClass::fail_stop}) {
        p = complete_packet(terminal_class);
        p.reopen.present = false;
        add_case(cases,
                 std::string("terminal_")
                     + std::string(terminal_name(terminal_class)),
                 p,
                 expected(Status::terminal_record_bound,
                          Fault::none, true, true));
    }

    p = complete_packet();
    add_case(cases, "reopen_record_bound", p,
             expected(Status::reopen_record_bound,
                      Fault::none, true, true, true));

    p = complete_packet();
    p.subject.id = Digest{};
    add_case(cases, "reject_subject_incomplete", p,
             expected(Status::rejected, Fault::subject_incomplete));

    p = complete_packet();
    p.evidence.evidence_digest = Digest{};
    add_case(cases, "reject_evidence_incomplete", p,
             expected(Status::rejected, Fault::evidence_incomplete));

    p = complete_packet();
    p.evidence.subject_id = digest(40U);
    add_case(cases, "reject_evidence_subject_mismatch", p,
             expected(Status::rejected, Fault::evidence_subject_mismatch));

    p = complete_packet();
    p.appraisal.id = Digest{};
    add_case(cases, "reject_appraisal_incomplete", p,
             expected(Status::rejected, Fault::appraisal_incomplete));

    p = complete_packet();
    p.appraisal.subject_id = digest(41U);
    add_case(cases, "reject_appraisal_subject_mismatch", p,
             expected(Status::rejected, Fault::appraisal_subject_mismatch));

    p = complete_packet();
    p.appraisal.evidence_id = digest(42U);
    add_case(cases, "reject_appraisal_evidence_mismatch", p,
             expected(Status::rejected, Fault::appraisal_evidence_mismatch));

    p = complete_packet();
    p.appraisal.policy_digest = digest(43U);
    add_case(cases, "reject_appraisal_policy_mismatch", p,
             expected(Status::rejected, Fault::appraisal_policy_mismatch));

    p = complete_packet();
    p.appraisal.verdict = static_cast<AppraisalVerdict>(255U);
    add_case(cases, "reject_appraisal_verdict_invalid", p,
             expected(Status::rejected, Fault::appraisal_verdict_invalid));

    p = complete_packet();
    p.appraisal.verdict = AppraisalVerdict::deny;
    add_case(cases, "reject_post_closed_material", p,
             expected(Status::rejected, Fault::post_closed_material));

    p = complete_packet();
    p.permit.present = false;
    p.reopen.present = false;
    add_case(cases, "reject_terminal_without_permit", p,
             expected(Status::rejected, Fault::terminal_without_permit));

    p = complete_packet();
    p.terminal.present = false;
    add_case(cases, "reject_reopen_without_terminal", p,
             expected(Status::rejected, Fault::reopen_without_terminal));

    p = complete_packet();
    p.permit.spend_coordinate_digest = Digest{};
    add_case(cases, "reject_permit_incomplete", p,
             expected(Status::rejected, Fault::permit_incomplete));

    p = complete_packet();
    p.permit.subject_id = digest(44U);
    add_case(cases, "reject_permit_subject_mismatch", p,
             expected(Status::rejected, Fault::permit_subject_mismatch));

    p = complete_packet();
    p.permit.appraisal_id = digest(45U);
    add_case(cases, "reject_permit_appraisal_mismatch", p,
             expected(Status::rejected, Fault::permit_appraisal_mismatch));

    p = complete_packet();
    p.terminal.predecessor_digest = Digest{};
    add_case(cases, "reject_terminal_incomplete", p,
             expected(Status::rejected, Fault::terminal_incomplete));

    p = complete_packet();
    p.terminal.permit_id = digest(46U);
    add_case(cases, "reject_terminal_permit_mismatch", p,
             expected(Status::rejected, Fault::terminal_permit_mismatch));

    p = complete_packet();
    p.terminal.effect_digest = digest(47U);
    add_case(cases, "reject_terminal_effect_mismatch", p,
             expected(Status::rejected, Fault::terminal_effect_mismatch));

    p = complete_packet();
    p.terminal.terminal_class = TerminalClass::none;
    add_case(cases, "reject_terminal_class_invalid", p,
             expected(Status::rejected, Fault::terminal_class_invalid));

    p = complete_packet();
    p.reopen.receipt_digest = Digest{};
    add_case(cases, "reject_reopen_incomplete", p,
             expected(Status::rejected, Fault::reopen_incomplete));

    p = complete_packet();
    p.reopen.terminal_id = digest(48U);
    add_case(cases, "reject_reopen_terminal_mismatch", p,
             expected(Status::rejected, Fault::reopen_terminal_mismatch));

    p = complete_packet();
    p.reopen.terminal_class = TerminalClass::no_effect;
    add_case(cases, "reject_reopen_class_mismatch", p,
             expected(Status::rejected, Fault::reopen_class_mismatch));

    p = complete_packet();
    p.reopen.reopener_administration_label_digest =
        p.reopen.producer_administration_label_digest;
    add_case(cases, "reject_reopen_same_administration_label", p,
             expected(Status::rejected, Fault::reopen_same_administration_label));

    return cases;
}

void apply_mutations(Packet& p, const std::uint32_t mask) {
    if ((mask & (1U << 0U)) != 0U) p.subject.artifact_digest = Digest{};
    if ((mask & (1U << 1U)) != 0U) p.evidence.subject_id = digest(50U);
    if ((mask & (1U << 2U)) != 0U) p.appraisal.evidence_id = digest(51U);
    if ((mask & (1U << 3U)) != 0U) p.appraisal.policy_digest = digest(52U);
    if ((mask & (1U << 4U)) != 0U) p.permit.subject_id = digest(53U);
    if ((mask & (1U << 5U)) != 0U) p.permit.appraisal_id = digest(54U);
    if ((mask & (1U << 6U)) != 0U) p.terminal.permit_id = digest(55U);
    if ((mask & (1U << 7U)) != 0U) p.terminal.effect_digest = digest(56U);
    if ((mask & (1U << 8U)) != 0U) p.reopen.terminal_id = digest(57U);
    if ((mask & (1U << 9U)) != 0U) {
        p.reopen.terminal_class = TerminalClass::no_effect;
    }
    if ((mask & (1U << 10U)) != 0U) {
        p.reopen.reopener_administration_label_digest =
            p.reopen.producer_administration_label_digest;
    }
    if ((mask & (1U << 11U)) != 0U) p.permit.spend_coordinate_digest = Digest{};
}

void require_absent_output(const std::filesystem::path& output) {
    if (std::filesystem::exists(output)) {
        throw std::runtime_error("output already exists");
    }
    if (!std::filesystem::create_directories(output)) {
        throw std::runtime_error("cannot create output");
    }
}

}  // namespace

int run_campaign(const std::filesystem::path& output) {
    require_absent_output(output);

    const auto cases = curated_cases();
    std::ofstream table(output / "curated.tsv", std::ios::binary);
    if (!table) throw std::runtime_error("cannot open curated.tsv");
    table << "name\texpected_status\texpected_fault\tcandidate_status"
             "\tcandidate_fault\treference_status\treference_fault"
             "\tpermit_record_bound\tterminal_record_bound"
             "\tadministration_labels_distinct\n";

    std::uint64_t disagreements = 0U;
    std::uint64_t expectation_failures = 0U;
    for (const auto& item : cases) {
        const Evaluation candidate = evaluate(item.packet);
        const Evaluation oracle = reference::evaluate(item.packet);
        if (candidate != oracle) ++disagreements;
        if (candidate != item.expected) ++expectation_failures;
        table << item.name << '\t'
              << status_name(item.expected.status) << '\t'
              << fault_name(item.expected.fault) << '\t'
              << status_name(candidate.status) << '\t'
              << fault_name(candidate.fault) << '\t'
              << status_name(oracle.status) << '\t'
              << fault_name(oracle.fault) << '\t'
              << (candidate.permit_record_bound ? "true" : "false")
              << '\t' << (candidate.terminal_record_bound ? "true" : "false")
              << '\t'
              << (candidate.administration_labels_distinct
                      ? "true" : "false")
              << '\n';
    }
    table.close();
    if (!table) throw std::runtime_error("cannot finish curated.tsv");

    constexpr std::uint32_t mutation_count = 1U << 12U;
    std::map<Status, std::uint64_t> status_counts;
    for (std::uint32_t mask = 0U; mask < mutation_count; ++mask) {
        Packet packet = complete_packet();
        apply_mutations(packet, mask);
        const Evaluation candidate = evaluate(packet);
        const Evaluation oracle = reference::evaluate(packet);
        if (candidate != oracle) ++disagreements;
        ++status_counts[candidate.status];
    }

    std::ofstream summary(output / "summary.json", std::ios::binary);
    if (!summary) throw std::runtime_error("cannot open summary.json");
    summary << "{\n"
            << "  \"schema\": \"slopos.rev0929.membrane-cut0.campaign.v1\",\n"
            << "  \"status\": \""
            << ((disagreements == 0U && expectation_failures == 0U)
                    ? "PASS" : "FAIL") << "\",\n"
            << "  \"record_classes\": 6,\n"
            << "  \"curated_cases\": " << cases.size() << ",\n"
            << "  \"mutation_cases\": " << mutation_count << ",\n"
            << "  \"total_cases\": "
            << (static_cast<std::uint64_t>(cases.size()) + mutation_count)
            << ",\n"
            << "  \"candidate_reference_disagreements\": "
            << disagreements << ",\n"
            << "  \"curated_expectation_failures\": "
            << expectation_failures << ",\n"
            << "  \"mutation_status_counts\": {\n";
    std::size_t emitted = 0U;
    for (const auto& [status, count] : status_counts) {
        summary << "    \"" << status_name(status) << "\": " << count;
        ++emitted;
        summary << (emitted == status_counts.size() ? "\n" : ",\n");
    }
    summary << "  },\n"
            << "  \"authority_granted\": false,\n"
            << "  \"current_policy_proved\": false,\n"
            << "  \"permit_authority_proved\": false,\n"
            << "  \"effect_occurrence_proved\": false,\n"
            << "  \"external_occurrence_proved\": false,\n"
            << "  \"administrative_independence_proved\": false,\n"
            << "  \"global_one_use_proved\": false,\n"
            << "  \"epoch_exit_proved\": false\n"
            << "}\n";
    summary.close();
    if (!summary) throw std::runtime_error("cannot finish summary.json");

    if (disagreements != 0U || expectation_failures != 0U) {
        throw std::runtime_error("candidate/reference or expected result drift");
    }
    std::cout << "MEMBRANE_CUT0_CAMPAIGN=PASS curated=" << cases.size()
              << " mutations=" << mutation_count
              << " disagreements=0 expectation_failures=0"
              << " authority=false external_occurrence=false"
              << " administrative_independence=false epoch_zero=true\n";
    return 0;
}

}  // namespace slopos::e0::core_gate::cut0
