#include "slopos/e0/fence/harness.hpp"

#include <iostream>
#include <string>

int main(int argc, char** argv) {
    std::string certificate;
    std::string relation;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--certificate" && i + 1 < argc) certificate = argv[++i];
        else if (arg == "--relation" && i + 1 < argc) relation = argv[++i];
        else {
            std::cerr << "usage: slopos_crash_refinement_explore "
                         "[--certificate PATH] [--relation PATH]\n";
            return 2;
        }
    }
    const auto r = slopos::e0::fence::explore(certificate, relation);
    std::cout << "EXPLORE=" << (r.ok ? "PASS" : "FAIL")
              << " states=" << r.states
              << " transitions=" << r.transitions
              << " events_per_state=" << r.events_per_state
              << " max_depth=" << r.maximum_depth
              << " effect_edges=" << r.effect_edges
              << " recovered_first_effect_edges="
              << r.recovered_first_effect_edges
              << " unknown_no_effect_completion_edges="
              << r.unknown_no_effect_completion_edges
              << " uncertainty_completion_edges="
              << r.uncertainty_completion_edges
              << " rollback_counterexample="
              << (r.duplicate_effect_with_floor_regression ? "retained" : "missing")
              << " monotone_floor_duplicate="
              << (r.duplicate_effect_under_floor_monotonicity ? "yes" : "no")
              << " relation_fnv1a64=" << r.relation_fnv1a64
              << " detail=" << r.detail << '\n';
    if (r.duplicate_effect_with_floor_regression) {
        std::cout << "ROLLBACK_WITNESS=" << r.rollback_counterexample << '\n';
    }
    return r.ok ? 0 : 1;
}
