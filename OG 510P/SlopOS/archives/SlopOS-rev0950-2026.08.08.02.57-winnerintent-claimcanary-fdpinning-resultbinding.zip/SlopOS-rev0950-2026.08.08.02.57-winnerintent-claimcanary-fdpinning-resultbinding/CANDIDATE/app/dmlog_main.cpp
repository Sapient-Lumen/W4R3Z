#include "slopos/e0/trace_intake/dmlog.hpp"

#include <filesystem>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 3 || std::string(argv[1]) != "campaign") {
        std::cerr << "usage: slopos_dmlog_intake campaign OUTPUT\n";
        return 2;
    }
    const auto report = slopos::e0::trace_intake::run_dmlog_campaign(
        std::filesystem::path(argv[2]));
    if (!report.ok) {
        std::cerr << "DMLOG_CAMPAIGN=FAIL detail=" << report.detail << "\n";
        return 1;
    }
    std::cout << "DMLOG_CAMPAIGN=PASS cases=" << report.cases
              << " accepted=" << report.accepted
              << " rejected=" << report.rejected
              << " entries=" << report.accepted_entries
              << " prefixes=" << report.replay_prefixes
              << " images=" << report.unique_images
              << " disagreements=" << report.parser_disagreements
              << " synthetic=true authentic_acquisition=false"
              << " physical_power_loss_claim=false authority_granted=false\n";
    return 0;
}
