#include "slopos/e0/process_custody/custody.hpp"

#include <filesystem>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 5 || std::string(argv[1]) != "campaign") {
        std::cerr << "usage: slopos_process_custody campaign OUTPUT WORKER_A WORKER_B\n";
        return 2;
    }
    const auto report = slopos::e0::process_custody::run_campaign(
        std::filesystem::path(argv[2]),
        std::filesystem::path(argv[3]),
        std::filesystem::path(argv[4]));
    if (!report.ok) {
        std::cerr << "PROCESS_CUSTODY_CAMPAIGN=FAIL detail=" << report.detail << "\n";
        return 1;
    }
    std::cout << "PROCESS_CUSTODY_CAMPAIGN=PASS live_cases=" << report.live_cases
              << " launch_closed_candidates=" << report.launch_closed_candidates
              << " fail_closed=" << report.fail_closed_cases
              << " parser_cases=" << report.parser_cases
              << " parser_disagreements=" << report.parser_disagreements
              << " model_states=" << report.model_states
              << " transitions=" << report.model_transitions
              << " counterexamples=" << report.counterexamples
              << " process_custody_results=0 provider_authenticated=0 authority_granted=0\n";
    return 0;
}
