#include "slopos/e0/fence/host.hpp"
#include "slopos/e0/fence/rooted.hpp"

#include <iostream>
#include <string>

namespace h = slopos::e0::fence::host;

namespace {
void usage() {
    std::cerr << "usage:\n"
              << "  slopos_hosted_wedge campaign OUT\n"
              << "  slopos_hosted_wedge path-campaign OUT\n"
              << "  slopos_hosted_wedge materialize CUT ROOT\n"
              << "  slopos_hosted_wedge classify ROOT\n"
              << "  slopos_hosted_wedge recover ROOT\n"
              << "  slopos_hosted_wedge dump-schema OUT\n";
}
}  // namespace

int main(int argc, char** argv) {
    if (argc < 3) { usage(); return 2; }
    const std::string command = argv[1];
    if (command == "campaign" && argc == 3) {
        const h::CampaignReport r = h::run_campaign(argv[2], argv[0]);
        std::cout << "HOST_CAMPAIGN=" << (r.ok ? "PASS" : "FAIL")
                  << " cuts=" << r.cuts
                  << " classifications=" << r.classifications
                  << " recoveries=" << r.recoveries
                  << " recovery_created_effects="
                  << r.recovery_created_effects
                  << " uncertainty_publications=" << r.uncertainty_publications
                  << " no_effect_publications=" << r.no_effect_publications
                  << " effect_publications=" << r.effect_publications
                  << " detail=" << r.detail << '\n';
        return r.ok ? 0 : 1;
    }
    if (command == "path-campaign" && argc == 3) {
        const h::PathCampaignReport r = h::run_path_campaign(argv[2]);
        std::cout << "PATH_CAMPAIGN=" << (r.ok ? "PASS" : "FAIL")
                  << " cases=" << r.cases << " passed=" << r.passed
                  << " detail=" << r.detail << '\n';
        return r.ok ? 0 : 1;
    }
    if (command == "materialize" && argc == 4) {
        h::Cut cut{};
        if (!h::parse_cut(argv[2], cut)) {
            std::cerr << "unknown cut\n";
            return 2;
        }
        std::string detail;
        const bool ok = h::materialize_cut(argv[3], cut, detail);
        std::cout << "MATERIALIZE=" << (ok ? "PASS" : "FAIL")
                  << " cut=" << h::cut_name(cut)
                  << " detail=" << detail << '\n';
        return ok ? 0 : 1;
    }
    if (command == "classify" && argc == 3) {
        const h::Classification r = h::classify(argv[2]);
        std::cout << "CLASSIFY=" << (r.ok ? "PASS" : "FAIL")
                  << " label=" << r.label << " durable=" << r.durable
                  << " external_phase=" << r.external_phase
                  << " endpoint_result=" << r.endpoint_result
                  << " effect=" << (r.effect_present ? 1 : 0)
                  << " detail=" << r.detail << '\n';
        return r.ok ? 0 : 1;
    }
    if (command == "recover" && argc == 3) {
        const h::RecoveryResult r = h::recover_without_first_effect(argv[2]);
        std::cout << "RECOVER=" << (r.ok ? "PASS" : "FAIL")
                  << " before_effect=" << (r.effect_before ? 1 : 0)
                  << " after_effect=" << (r.effect_after ? 1 : 0)
                  << " created_first_effect="
                  << (r.created_first_effect ? 1 : 0)
                  << " after_class=" << r.after.label
                  << " detail=" << r.detail << '\n';
        return r.ok ? 0 : 1;
    }
    if (command == "dump-schema" && argc == 3) {
        std::string detail;
        const bool ok = h::dump_schema(argv[2], detail);
        std::cout << "DUMP_SCHEMA=" << (ok ? "PASS" : "FAIL")
                  << " detail=" << detail << '\n';
        return ok ? 0 : 1;
    }
    usage();
    return 2;
}
