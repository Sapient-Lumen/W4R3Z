#include "slopos/e0/fence/ambiguity.hpp"

#include <iostream>
#include <string>

int main(int argc, char** argv) {
    std::string table;
    std::string certificate;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--table" && i + 1 < argc) table = argv[++i];
        else if (arg == "--certificate" && i + 1 < argc) certificate = argv[++i];
        else {
            std::cerr << "usage: slopos_observation_ambiguity "
                         "[--table PATH] [--certificate PATH]\n";
            return 2;
        }
    }
    const auto r = slopos::e0::fence::explore_observation_ambiguity(
        table, certificate);
    std::cout << "AMBIGUITY=" << (r.ok ? "PASS" : "FAIL")
              << " histories=" << r.hidden_histories
              << " local_classes=" << r.local_observation_classes
              << " ambiguous_local_classes=" << r.ambiguous_local_classes
              << " witness=" << r.witness
              << " detail=" << r.detail << '\n';
    return r.ok ? 0 : 1;
}
