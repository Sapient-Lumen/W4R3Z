#include "slopos/e0/process_custody/custody.hpp"

#include <dirent.h>
#include <fcntl.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

#include <array>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <limits>
#include <optional>
#include <string>
#include <string_view>

#ifndef SLOPOS_WORKER_ID
#error "SLOPOS_WORKER_ID is required"
#endif

namespace pc = slopos::e0::process_custody;

namespace {

[[noreturn]] void die(const int code) {
    _exit(code);
}

[[nodiscard]] bool fd_present(const int fd) {
    errno = 0;
    return fcntl(fd, F_GETFD) >= 0 || errno != EBADF;
}

[[nodiscard]] bool normalized_fd(const int fd, const int expected_access) {
    const int flags = fcntl(fd, F_GETFL);
    if (flags < 0 || (flags & O_ACCMODE) != expected_access) return false;
    struct stat st {};
    return fstat(fd, &st) == 0 && S_ISCHR(st.st_mode);
}

[[nodiscard]] bool status_hex_zero(const std::string_view key) {
    std::ifstream stream("/proc/self/status");
    std::string line;
    const std::string prefix = std::string(key) + ":";
    while (std::getline(stream, line)) {
        if (line.rfind(prefix, 0U) != 0U) continue;
        const auto value_pos = line.find_first_not_of(" \t", prefix.size());
        if (value_pos == std::string::npos) return false;
        const std::string value = line.substr(value_pos);
        return value.find_first_not_of('0') == std::string::npos;
    }
    return false;
}

[[nodiscard]] std::uint64_t unexpected_fds(const bool allow_next) {
    DIR* directory = opendir("/proc/self/fd");
    if (directory == nullptr) return std::numeric_limits<std::uint64_t>::max();
    const int enumeration_fd = dirfd(directory);
    std::uint64_t count = 0U;
    while (const dirent* entry = readdir(directory)) {
        if (entry->d_name[0] == '.') continue;
        char* end = nullptr;
        const long value = std::strtol(entry->d_name, &end, 10);
        if (end == nullptr || *end != '\0' || value < 0L ||
            value > static_cast<long>(std::numeric_limits<int>::max())) {
            ++count;
            continue;
        }
        const int fd = static_cast<int>(value);
        if (fd == enumeration_fd || fd == 0 || fd == 1 || fd == 2 ||
            fd == pc::kReportFd || (allow_next && fd == pc::kNextExecFd)) {
            continue;
        }
        ++count;
    }
    closedir(directory);
    return count;
}

[[nodiscard]] int environment_fd(const char* key) {
    const char* text = std::getenv(key);
    if (text == nullptr || *text == '\0') return -1;
    char* end = nullptr;
    const long value = std::strtol(text, &end, 10);
    if (end == nullptr || *end != '\0' || value < 0L ||
        value > static_cast<long>(std::numeric_limits<int>::max())) {
        return -1;
    }
    return static_cast<int>(value);
}

[[nodiscard]] bool send_all(const int fd, const std::string& bytes) {
    const ssize_t sent = send(fd, bytes.data(), bytes.size(), MSG_NOSIGNAL);
    return sent == static_cast<ssize_t>(bytes.size());
}

[[nodiscard]] bool wait_ack(const int fd) {
    char value = 0;
    const ssize_t received = recv(fd, &value, 1U, 0);
    return received == 1 && value == 'K';
}

}  // namespace

int main() {
    const int report_fd = environment_fd("SLOPOS_REPORT_FD");
    if (report_fd != pc::kReportFd || !fd_present(report_fd)) die(91);
    const int next_fd = environment_fd("SLOPOS_NEXT_EXEC_FD");
    const bool has_next = next_fd == pc::kNextExecFd && fd_present(next_fd);

    pc::Report report;
    report.schema = std::string(pc::kReportSchema);
    report.phase = "ENTRY";
    const char* override_id = std::getenv("SLOPOS_REPORT_ID_OVERRIDE");
    report.executable_id = override_id == nullptr ? SLOPOS_WORKER_ID : override_id;
    report.pid = static_cast<std::uint64_t>(getpid());
    report.ppid = static_cast<std::uint64_t>(getppid());
    report.uid = static_cast<std::uint64_t>(getuid());
    report.gid = static_cast<std::uint64_t>(getgid());
    report.no_new_privs = prctl(PR_GET_NO_NEW_PRIVS, 0, 0, 0, 0) == 1;
    report.cap_inheritable_zero = status_hex_zero("CapInh");
    report.cap_permitted_zero = status_hex_zero("CapPrm");
    report.cap_effective_zero = status_hex_zero("CapEff");
    report.cap_bounding_zero = status_hex_zero("CapBnd");
    report.cap_ambient_zero = status_hex_zero("CapAmb");
    report.fd0_normalized = normalized_fd(0, O_RDONLY);
    report.fd1_normalized = normalized_fd(1, O_WRONLY);
    report.fd2_normalized = normalized_fd(2, O_WRONLY);
    report.report_fd_present = fd_present(pc::kReportFd);
    report.next_exec_fd_present = has_next;
    report.unexpected_fd_count = unexpected_fds(has_next);

    const std::string bytes = pc::serialize_report(report);
    if (!send_all(report_fd, bytes) || !wait_ack(report_fd)) die(92);

    if (has_next) {
        if (fcntl(next_fd, F_SETFD, FD_CLOEXEC) < 0) die(93);
        unsetenv("SLOPOS_NEXT_EXEC_FD");
        unsetenv("SLOPOS_REPORT_ID_OVERRIDE");
        char arg0[] = "slopos-process-worker-b";
        char* const argv[] = {arg0, nullptr};
        extern char** environ;
        syscall(SYS_execveat, next_fd, "", argv, environ, AT_EMPTY_PATH);
        die(94);
    }
    return 0;
}
