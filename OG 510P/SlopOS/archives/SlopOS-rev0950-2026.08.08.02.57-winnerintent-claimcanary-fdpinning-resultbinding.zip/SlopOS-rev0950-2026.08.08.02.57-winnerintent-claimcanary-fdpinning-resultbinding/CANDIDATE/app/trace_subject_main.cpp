#include "slopos/e0/trace_subject/subject.hpp"

#include <filesystem>
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 3 || std::string(argv[1]) != "campaign") {
        std::cerr << "usage: slopos_trace_subject campaign OUTPUT\n";
        return 2;
    }
    const auto report = slopos::e0::trace_subject::run_trace_subject_campaign(
        std::filesystem::path(argv[2]));
    if (!report.ok) {
        std::cerr << "TRACE_SUBJECT_CAMPAIGN=FAIL detail=" << report.detail << "\n";
        return 1;
    }
    std::cout << "TRACE_SUBJECT_CAMPAIGN=PASS packet_cases=" << report.packet_cases
              << " accepted=" << report.packet_accepted
              << " rejected=" << report.packet_rejected
              << " export_closed_candidates=" << report.export_closed_candidates
              << " capture_bound=" << report.capture_bound_results
              << " ceremony_states=" << report.ceremony_states
              << " transitions=" << report.ceremony_transitions
              << " parser_disagreements=" << report.parser_disagreements
              << " native_capture=false authority_granted=false\n";
    return 0;
}
