#include "slopos/e0/crash_image/profile.hpp"

#include <iostream>
#include <string>

namespace crash = slopos::e0::crash_image;

namespace {
void usage() {
    std::cerr << "usage:\n"
              << "  slopos_crash_image campaign OUT\n"
              << "  slopos_crash_image dump-schema OUT\n"
              << "  slopos_crash_image classify IMAGE\n";
}
}  // namespace

int main(int argc, char** argv) {
    if (argc != 3) {
        usage();
        return 2;
    }
    const std::string command = argv[1];
    if (command == "campaign") {
        const crash::CampaignReport report = crash::run_campaign(argv[2]);
        std::cout << "CRASH_IMAGE_CAMPAIGN="
                  << (report.ok ? "PASS" : "FAIL")
                  << " traces=" << report.traces
                  << " cuts=" << report.cuts
                  << " records=" << report.records
                  << " unique_images=" << report.unique_images
                  << " classifications=" << report.classifications
                  << " disagreements=" << report.disagreements
                  << " effect=" << report.effect
                  << " no_effect=" << report.no_effect
                  << " uncertain=" << report.uncertain
                  << " fail_stop=" << report.fail_stop
                  << " mark_stutters=" << (report.mark_stutters ? 1 : 0)
                  << " mark_not_flush_witness="
                  << (report.mark_not_flush_witness ? 1 : 0)
                  << " result_before_completion_witness="
                  << (report.result_before_completion_witness ? 1 : 0)
                  << " rollback_image_collision_witness="
                  << (report.rollback_image_collision_witness ? 1 : 0)
                  << " detail=" << report.detail << '\n';
        return report.ok ? 0 : 1;
    }
    if (command == "dump-schema") {
        std::string detail;
        const bool ok = crash::dump_schema(argv[2], detail);
        std::cout << "CRASH_IMAGE_SCHEMA=" << (ok ? "PASS" : "FAIL")
                  << " detail=" << detail << '\n';
        return ok ? 0 : 1;
    }
    if (command == "classify") {
        crash::Image image{};
        std::string detail;
        if (!crash::read_image(argv[2], image, detail)) {
            std::cout << "CRASH_IMAGE_CLASSIFY=FAIL detail=" << detail << '\n';
            return 1;
        }
        const crash::Classification sealed =
            crash::classify_with_sealed_recovery(image);
        const crash::Classification exact =
            crash::classify_with_exact_map(image);
        const bool agree = sealed.outcome == exact.outcome
            && sealed.local == exact.local && sealed.floor == exact.floor
            && sealed.endpoint_result == exact.endpoint_result
            && sealed.effect_present == exact.effect_present;
        std::cout << "CRASH_IMAGE_CLASSIFY=" << (agree ? "PASS" : "FAIL")
                  << " outcome=" << crash::outcome_name(sealed.outcome)
                  << " local=" << sealed.local
                  << " floor=" << sealed.floor
                  << " endpoint_result=" << sealed.endpoint_result
                  << " effect_present=" << (sealed.effect_present ? 1 : 0)
                  << " reopener_agreement=" << (agree ? 1 : 0)
                  << " detail=" << sealed.detail << '\n';
        return agree ? 0 : 1;
    }
    usage();
    return 2;
}
