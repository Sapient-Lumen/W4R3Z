# Build surface — Repository V58

The top-level CMake dispatcher is fail-closed. No default island exists. An operator must select one of the three current islands; the five product targets are enumerated by `CANDIDATE/ACTIVE-BUILD.tsv`. Legacy targets are excluded.

The current nested proof leaves are direct-built and do not enter the product manifest.

Atomic Packet V1:

```sh
cmake -S CANDIDATE/core_gate/ratification_subject/intake_fence -B BUILD-packet -G Ninja
cmake --build BUILD-packet
BUILD-packet/slopos_ratification_subject_intake_fence campaign SUBJECT_BIN ABSENT_OUTPUT
```

Checkpoint Transport Commit V2:

```sh
cmake -S CANDIDATE/generation_journal/checkpoint_transport_commit -B BUILD-transport -G Ninja
cmake --build BUILD-transport
BUILD-transport/slopos_checkpoint_transport_commit publish COMPLETE_CANDIDATE.zip ABSENT_FINAL.zip
BUILD-transport/slopos_checkpoint_transport_commit reconcile COMPLETE_CANDIDATE.zip EXISTING_EXACT_FINAL.zip
```

Rooted Shadow Pack V2:

```sh
cmake -S CANDIDATE/generation_journal/shadow_pack -B BUILD-shadow -G Ninja
cmake --build BUILD-shadow
BUILD-shadow/slopos_shadow_pack pack SOURCE_ROOT SUBJECT.tsv OUTPUT.spk
BUILD-shadow/slopos_shadow_pack verify OUTPUT.spk
BUILD-shadow/slopos_shadow_pack unpack OUTPUT.spk ABSENT_DESTINATION_ROOT
```

`pack` and `unpack` require the operated Linux descriptor-rooted profile. `unpack` cannot replace an existing destination. The leaf is not a daemon, provider client, signer, storage authority, product target, or fourth island. `CANDIDATE/PATH-ROLES.tsv` remains the exhaustive immediate-child authority.
