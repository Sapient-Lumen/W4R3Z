# Active candidate surface

Repository V58 has three semantic islands:

- `generation_journal`
- `handoff_cell`
- `core_gate`

The five product executables remain exactly those named by `CANDIDATE/ACTIVE-BUILD.tsv`. Three nested proofs are current without being product targets:

1. `core_gate/ratification_subject/intake_fence` freezes decode semantics and exposes a complete-or-absent four-artifact packet.
2. `generation_journal/checkpoint_transport_commit` provides absent-destination no-progressive-final publication and explicit exact-existing query-only reconciliation.
3. `generation_journal/shadow_pack` provides descriptor-rooted deterministic packing and a staged no-replace exact inverse for logical record addresses, modes, and bytes.

Fourteen adjacent legacy immediate children are retained and unselectable. `PATH-ROLES.tsv` accounts for every immediate child.

Local maxima include `complete_local_namespace_packet_visible`, `exact_existing_reconciled_without_replacement`, and `exact_logical_record_inverse_visible_without_replacement`. All are bounded local observations. None proves provenance, exclusive writers, prior synchronization, stable media, independent retention, writer authenticity, owner ratification, living admission, authority, or epoch exit.
