# Changelog

## Revised23 (2026-03-22)
- add a repair-gate posture so repeated failures can cool down, become repair-required, and stay explainable without freezing a giant retry-policy language
- refresh Steward research around CrashLoopBackOff resets, restart intensity and respawn limits, launchd throttle intervals, and maintenance/clear semantics while keeping the archive decision-light
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised22 (2026-03-21)
- add a context-handoff posture so command frames, exact output slices, receipts, and concrete runs can be exported as bounded evidence bundles instead of scraped scrollback
- refresh Steward research around VS Code terminal-command attachments and collapsible sections, command status details, and exact command/output selection patterns while keeping the archive decision-light
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised21 (2026-03-21)
- add a mode-baseline posture so prompt markers, cwd freshness, cursor shape, bracketed paste, and other prompt-critical shell/terminal semantics can be freshly reasserted or visibly repaired after hops, TUIs, or broken-state detours
- refresh Steward research around xterm reset behavior, iTerm2's tmux crash repair guidance, Ghostty's explicit reset action, kitty's prompt-local cursor semantics, and fish's fresh-prompt reassertion lessons
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised20 (2026-03-21)
- add a chrome-lane posture so badges, status bars, sticky headers, tab titles, and progress chrome stay observational, freshness-scoped, and clearly separate from the canonical transcript
- refresh Steward research around iTerm2 status bars and badges, WezTerm right-status, Windows Terminal smart tab titles, and VS Code's exact command/output attachment patterns while keeping the archive decision-light
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised19 (2026-03-21)
- add a target-anchor posture so shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without scraping rendered text or leaking raw capability
- refresh Steward research around iTerm2 command selection and command URLs, explicit OSC 8 hyperlinks, kitty open-actions, tmux control-mode pane identity, and VS Code link-confidence lessons while keeping the archive decision-light
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised18 (2026-03-21)
- add an attention-hint posture so shell/terminal UX can surface command-finished, needs-input, warning, and progress-like cues without turning terminal ergonomics into hidden lifecycle control
- refresh Steward research around Ghostty command-finish notifications, kitty desktop-notification filtering, WezTerm focus-aware toast handling, and capability-gated terminal progress hints
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised17 (2026-03-21)
- add a provisional-state posture so shell/terminal UX can show predictive or incomplete local state without letting tentative markers or actions masquerade as confirmed lifecycle truth
- refresh Steward research around Mosh-style predictive local echo, later confidence refinement, and explicit confirmation boundaries while keeping the archive decision-light
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated context/review artifacts, linting, and a clean packaged release

## Revised16 (2026-03-21)
- add an observation-confidence posture so Steward can keep shell/terminal exactness, provenance, and trusted-ness explicit without pretending every marker or target is equally reliable
- refresh Steward research around VS Code's low/medium/high confidence model, nonce-bound trust, fresh marker refinement, and action-gating lessons while keeping the archive decision-light
- tighten shell/terminal ideas, historical lessons, and SlopOS datacube guidance while keeping repo hygiene strong through regenerated context/review artifacts, linting, and a clean packaged release

## Revised15 (2026-03-21)
- add a hop-lineage posture so shell/terminal semantics can stay remote-aware, host-scoped, and honest about what path a frame, history entry, or action target actually came through
- refresh Steward research around WezTerm pane user vars, kitty's SSH shell-integration path, Ghostty's SSH semantics, and per-hop remote-aware UX ideas while keeping the archive decision-light
- tighten shell/terminal ideas, lessons, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised14 (2026-03-21)
- add a semantic-epoch posture so shell/terminal frames, actions, and subscriptions can stale-fence cleanly after hops, resync, or shell reset without freezing more lifecycle control
- deepen the shell/terminal research around fresh resync, live capability reporting, nonce-bound command confidence, and command-finish semantics while keeping the archive decision-light
- refresh the SlopOS datacube evaluation and maintain repo hygiene by regenerating context/review artifacts, linting, and packaging a verified release

## Revised13 (2026-03-21)
- add a capability-handshake posture so Steward can enable richer shell/terminal semantics from fresh observed support instead of trusting `TERM` folklore or stale remembered success
- refresh Steward research around terminal feature reporting, progressive enhancement, safe-ignore behavior, and per-hop capability honesty while keeping the shell/terminal direction idea-rich and decision-light
- tighten lessons, shell/terminal ideas, and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised12 (2026-03-21)
- add a precision-fence posture so Steward can make shell/terminal trust drift, capability downgrade, and resync boundaries explicit instead of preserving stale certainty across hops
- refresh Steward research around terminal compatibility honesty, progressive enhancement, kitty keyboard semantics, and synchronized rendering hints while keeping the shell/terminal direction idea-rich and decision-light
- tighten shell/terminal ideas and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised11 (2026-03-21)
- add an observation-subscription posture so Steward can support bounded snapshot-plus-change views without polling or a hidden event/control bus
- refresh Steward research around tmux control-mode subscriptions, D-Bus API design patterns, prompt freshness, and text-friendly remote-safe observation streams while keeping shell/terminal evolution idea-rich and decision-light
- tighten shell/terminal ideas and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised10 (2026-03-21)
- add an action-surface posture so Steward can support explicit terminal hyperlinks, chips, and palette entries without turning shell UX into hidden ambient control
- refresh Steward research around launchd's anti-speculation cautions, kitty's minimal terminal-extension stance, kitty open-actions, and Ghostty command-palette direction while keeping shell/terminal evolution idea-rich and decision-light
- tighten shell/terminal ideas and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised9 (2026-03-21)
- add a termination-cause posture so Steward can explain why a concrete runtime cycle ended without freezing a giant fault taxonomy or collapsing back into PID/log folklore
- refresh Steward research around systemd result categories, Fuchsia stop payloads, semantic shell fences, and trusted command-finish notifications while keeping the shell/terminal direction observation-first
- tighten shell/terminal ideas and SlopOS datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised8 (2026-03-21)
- add a runtime-cycle witness posture so Steward can name concrete service runs, correlate receipts/status/command frames, and explore stale-action fences without freezing a giant control API
- refresh Steward research around per-runtime-cycle invocation identity, transaction-fenced stop behavior, semantic prompt ancestry, and terminal-side parseable metadata transport
- tighten shell/terminal ideas and SlopOS datacube evaluation while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised7 (2026-03-21)
- add a transient-promotion posture so long-running shell work can become an explicit Steward-tracked object without freezing a giant transient-unit grammar
- refresh Steward research around D-Bus system activation, official systemd transient units, Mosh-style remote-shell resilience, and Ghostty command-finish notification ideas
- tighten shell/terminal and datacube guidance while keeping repo hygiene strong through refreshed source locks, regenerated review/context artifacts, and a clean packaged release

## Revised6 (2026-03-21)
- add activity-accounting posture so Steward can name in-flight work, idle hints, and drain state without freezing a fake universal idle model
- refresh Steward research around XPC transaction boundaries, Shepherd's transient service maker manual, OpenRC supervise-daemon, fish terminal compatibility, exact command reporting, and subscription-friendly observation ideas
- tighten shell/terminal and datacube guidance while keeping repo hygiene strong through updated source locks, regenerated review/context artifacts, and a clean packaged release

## Revised5 (2026-03-21)
- add command-frame posture and tighten shell/terminal notes around parseable side channels, transient-service inspiration, and explicit input semantics without freezing a giant terminal protocol
- refresh external research with Dinit readiness semantics, GNU Shepherd transient services, tmux control mode, Ghostty shell integration, kitty keyboard handling, xterm bracketed paste, and fish's OSC 7/133 work
- improve repo hygiene by syncing the external-source head register to the source-lock set, regenerating review/context artifacts, and packaging a clean verified release

## Revised4 (2026-03-21)
- add lifecycle-observation and status-channel posture notes so Steward can freeze a small observational vocabulary before inventing broader control surfaces
- sharpen readiness and shell/terminal notes around shallow versus declared-work readiness, trusted semantic markers, and command-frame confidence rather than blind ANSI folklore
- refresh external research and repo hygiene around Fuchsia lifecycle states, official Windows Terminal shell integration docs, VS Code shell-marker trust, updated source locks, and regenerated review/context artifacts

## Revised3 (2026-03-21)
- add a freeze-late non-decisions posture, richer shell/terminal semantics notes, and sharper lessons on status channels, transaction/idle boundaries, and oneshot accountability without expanding Steward into a giant service-manager spec
- refresh external research with sd_notify state/barrier semantics, VS Code and Windows Terminal shell integration, OSC 133 prompt markers, OSC 8 hyperlinks, s6-rc transition handling, and XPC transaction hints
- improve repo hygiene with bibliography↔source-lock sync linting, refreshed source locks/review queue, and a more explicit evaluation of which SlopOS datacube habits Steward should copy now versus defer

## Revised2 (2026-03-21)
- deepen Steward research with daemontools, runit, launchd socket details, and command-block terminal ideas; refresh source locks and automate the source review queue
- add design-principles v0 and tighten supervision plus shell/terminal posture around foreground services, bounded restart discipline, command frames, and remote-aware semantic transport
- expand lessons-from-the-past, steal-these-ideas, shell-terminal-ideas, and the SlopOS datacube evaluation while keeping the archive intentionally lighter than the parent design repo

## Revised1 (2026-03-21)
- establish the first Steward datacube archive with release hygiene, context-pack generation, and self-verifying zip packaging
- capture the initial Steward architecture frame around component-rooted supervision, supervisor-owned activation, explicit readiness, cooperative quiesce, and semantic shell/terminal integration
- add curated research notes on lessons from prior service managers and runtimes, stealable ideas for Steward, shell/terminal design opportunities, and an evaluation of what to copy versus simplify from the larger SlopOS datacube

## Revised0 (2026-03-21)
- repo seeded
