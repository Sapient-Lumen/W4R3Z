# Runtime-cycle witness posture v0

Purpose: define a narrow, explicit way to name **one concrete runtime cycle** of a Steward-managed component without collapsing back into PID folklore or freezing a giant control protocol.

## Posture
1. **Each fresh active cycle may have a fresh opaque witness**
   - When a component moves from inactive into activating/active, Steward may mint a new runtime-cycle witness for that concrete cycle.
   - A restart, crash-relaunch, or explicit stop/start should normally produce a different witness even when the component identity is unchanged.
2. **The witness is for equality and correlation first**
   - The most important portable operation is equality: “is this still the same concrete run I was looking at?”
   - Phase 1 should not require global ordering, timestamp meaning, or human-decoded structure.
3. **Component identity and cycle identity stay separate**
   - Component identity answers “what component is this?”
   - Runtime-cycle witness answers “which concrete live/recent run of that component am I talking about?”
4. **Receipts, status, and shell frames may carry the witness**
   - Compact status, lifecycle receipts, transcript slices, and command frames should be allowed to attach a runtime-cycle witness when it helps attribution.
   - This is especially useful when one command frame launched or inspected a component that later restarted.
5. **Expected-witness fences are promising**
   - A future stop/restart/explain action may optionally carry an expected runtime-cycle witness as a stale-action fence.
   - If the component has already restarted into a different cycle, Steward should be able to fail clearly instead of silently acting on the wrong run.
6. **The witness must not collapse back into ambient process semantics**
   - A runtime-cycle witness is not a promise that there is one stable PID, one immutable process tree, or one universally meaningful host handle.
   - Hosts may implement the witness however they like behind the membrane.
7. **Continuity escrow does not preserve cycle identity**
   - A same-component restart may legitimately preserve allowlisted handles or state.
   - That does not make it the same runtime cycle; the witness should still change.
8. **Shell-to-service bridges should preserve both origin and cycle**
   - When a shell command is promoted into a transient Steward-tracked object, the originating command frame and the eventual runtime-cycle witness are both worth keeping.
   - They answer different questions and should not be conflated.
9. **Keep the portable contract smaller than a full generation API**
   - Phase 1 likely needs only an opaque witness plus optional equality/fence use.
   - Avoid freezing counters, globally sortable IDs, or a mandatory query matrix before real pressure exists.

## Phase-1 non-goals
- promising that every implementation uses UUIDs, counters, or hashes in the same way;
- requiring monotonic ordering across restarts or across different components;
- exposing a generic PID/process inventory API as the meaning of a runtime cycle;
- making the witness a replacement for receipts, transcripts, or explicit component identity;
- requiring every user-facing command to display the witness all the time.

## Adjacent docs
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `activation-posture-v0.md`
- `command-frame-posture-v0.md`
- `transient-promotion-posture-v0.md`
- `termination-cause-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-EXEC
- REF-SD-NOTIFY
- REF-FUCHSIA-LIFECYCLE
