# Activation posture v0

Purpose: keep restart continuity narrow and reviewable.

## Posture
1. **Activation handles are supervisor-owned**
   - Components serve on delivered handles; they do not ambiently recreate their public surface however they like.
2. **Activation is primarily inbound continuity**
   - Phase 1 activation is for stable inbound endpoints and bounded same-component continuity.
3. **Continuity escrow is allowlisted**
   - If continuity escrow exists, it is bounded by manifest allowlists and counts.
4. **No generic handle broker**
   - No list/search/watch/mailbox/export surface is implied.
5. **No hidden process resurrection claim**
   - Large mutable state belongs elsewhere; activation is not generic checkpoint/restore.
6. **Restart ownership stays with Steward**
   - Old instances do not self-upgrade by handing their world to arbitrary successors off the books.

## Phase-1 non-goals
- generic descriptor escrow broker;
- cross-component handle exchange through activation;
- app-visible inventory of stored activation material;
- full state migration.

## Adjacent docs
- `component-manifest-schema-v0.md`
- `activation-set-schema-v0.md`
- `supervision-posture-v0.md`

## References
- REF-SYSTEMD-SOCKET-ACTIVATION
- REF-SYSTEMD-SD-LISTEN-FDS
- REF-SYSTEMD-FDSTORE
- REF-LAUNCHD-JOBS
- REF-FUCHSIA-IDLE-STOP
