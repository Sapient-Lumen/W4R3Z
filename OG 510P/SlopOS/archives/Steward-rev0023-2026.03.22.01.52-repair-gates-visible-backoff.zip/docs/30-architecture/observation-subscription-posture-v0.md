# Observation-subscription posture v0

Purpose: define a narrow, explicitly observational **subscription stream** so terminals, UIs, and tools can follow Steward state changes without polling, screen scraping, or accidentally creating a hidden control bus.

## Posture
1. **Subscriptions are observational, not mutating**
   - The subscription surface exists to report status / lifecycle changes, command-frame-adjacent observations, and recent receipt-like facts.
   - It must not become an ambient mutation channel.
2. **A subscription targets explicit objects or views**
   - Subscriptions should bind to a concrete component id, explicit watch set, or explicit view such as compact status, recent lifecycle observations, or command-frame observations.
   - Avoid “watch whatever this pane probably means right now.”
3. **Snapshot plus change notices is a promising default shape**
   - A subscriber often needs an initial bounded snapshot plus later change notices.
   - This is usually safer than making clients reconstruct truth only from a stream of deltas.
4. **The stream should stay compact and coalescible**
   - Status-like observations should be allowed to coalesce.
   - A subscriber that falls behind should receive an explicit overflow / resync signal instead of forcing Steward to buffer an unbounded event log.
5. **Subscriptions should reduce polling, not replace explicit reads**
   - A subscription is a hint that something changed.
   - Authoritative inspection should still be available via explicit reads of status, receipts, or transcript slices.
6. **Per-run identity should be allowed in change notices**
   - When relevant, a change notice may carry runtime-cycle witness and compact termination-cause information.
   - That helps terminals and UIs avoid stale actions without rebuilding a giant process API.
7. **Keep the portable envelope tiny at first**
   - A useful phase-1 envelope likely needs only:
     - watched target / view id,
     - change kind,
     - optional compact payload,
     - optional runtime-cycle witness,
     - optional dropped / resync-needed indicator.
   - Avoid freezing a final full event schema too early.
8. **Backpressure and fairness matter**
   - A slow subscriber must not force unbounded buffering or make one chatty target starve everything else.
   - Coalescing, pause/resume, and resync are better than pretending every consumer can keep up forever.
9. **Subscriptions should survive simple transports**
   - A text-friendly stream that survives SSH-like hops and multiplexers is more valuable than a rich local-only API.
   - Steward should prefer transports that degrade honestly across local/remote boundaries.
10. **Versioning and explicit interface description are worth planning early**
   - If Steward grows a formal subscription API, it should have an explicit interface description and version story.
   - Do not rely on folklore clients parsing undocumented change strings forever.

## Phase-1 non-goals
- a universal event bus for every runtime and host detail;
- an always-on firehose of logs or traces;
- requiring lossless delivery of every change forever;
- a hidden mutation/control channel piggybacking on observation transport;
- forcing a single transport or serialization choice before real pressure exists.

## Adjacent docs
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `termination-cause-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `provisional-state-posture-v0.md`
- `action-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-TMUX-CONTROL-MODE
- REF-TMUX-CHANGES
- REF-DBUS-API-DESIGN
- REF-KITTY-PROTOCOL-EXTENSIONS
