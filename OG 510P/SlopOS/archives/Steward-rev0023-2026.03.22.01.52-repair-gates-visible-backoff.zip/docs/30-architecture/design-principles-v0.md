# Design principles v0

Purpose: compress the current Steward research into the **smallest stable set of guardrails** while SlopOS itself is still in design.

This document is intentionally lighter than a full architecture spec. It is meant to keep future revisions coherent without forcing early decisions that the archive has not yet earned.

## Principles

1. **Keep lifecycle authority explicit**
   - If Steward owns a lifecycle action, the target component and the authority to act on it should be explicit and reviewable.
   - Steward should not depend on ambient session, process-tree, or terminal folklore for its portable meaning.

2. **Keep lifecycle roots component-shaped, not PID-shaped**
   - Steward should supervise explicit component identities and lifecycle roots, not arbitrary host processes.
   - Process trees may exist underneath an implementation, but they are not the portable product contract.

3. **Keep supervised services foreground and accountable**
   - A supervised service should present one directly accountable runtime root to Steward.
   - Self-daemonizing, double-fork, and “the real process escaped somewhere else” patterns are exactly the kind of folklore Steward should avoid.

4. **Keep the stable public face manager-owned**
   - Activation, listener identity, and public continuity should belong to the system fabric and be handed to component instances.
   - Restart should not mean “the process gets to recreate the whole outside world however it likes.”

5. **Keep supervision smaller than orchestration**
   - Supervision, planning, activation, readiness, quiesce, and runtime-specific launching are related, but they are not all one thing.
   - Steward should prefer visible seams over one giant manager that silently accumulates every policy in the system.

6. **Keep health vocabulary split on purpose**
   - Startup, control-ready, readiness, liveness, crash, quiesce, idle, and stopping are different states with different operational consequences.
   - Steward should not guess readiness from spawn success or hide overload/recovery state behind generic “running” language.

7. **Keep continuity bounded and allowlisted**
   - Continuity across restart should be an explicit escrow story for specifically allowed handles or state.
   - Steward should resist promising full-process resurrection or generic hidden state preservation.

8. **Keep evidence close to lifecycle actions**
   - Lifecycle operations should be receipt-capable and transcript-friendly.
   - Steward should prefer compact evidence and bounded summaries over log scraping and folklore reconstruction.

9. **Keep shell and terminal semantics explicit**
   - Prompt boundaries, command frames, marks, working directory, hyperlinks, and lifecycle receipts should travel on explicit semantic channels when available.
   - Semantic markers should carry provenance or trust signals when practical instead of being treated as automatically authoritative.
   - PTY bytes remain useful, but they are not the only truth.

10. **Standardize observations before mutations**
   - It is healthier to freeze small observational/status protocols before freezing broad mutation/control planes.
   - Lifecycle observation vocabulary, readiness/status channels, shell/terminal integrations, and receipts can harden earlier than giant admin buses, timer DSLs, or orchestration grammars.

11. **Delay generic control languages until pressure is real**
   - Giant global unit DSLs, generic timer languages, broad admin buses, and process-inventory surfaces should only appear if they become truly necessary.
   - Until then, narrow posture docs, explicit non-decisions, and visible open questions are healthier than speculative frameworks.

12. **Keep activity accounting explicit and local**
   - In-flight work, drain state, busy/idle hints, and keepalive claims should be explicit when they exist.
   - Steward should not guess idleness from low CPU, quiet logs, or silence on the wire, and it should not freeze a fake universal request-count model.

## Phase-1 non-goals
- a final dependency-planner DSL;
- a generic timer/schedule language;
- a generic process inventory or adoption API;
- a promise that all SlopOS runtimes share one execution model;
- a giant shell/terminal RPC fabric before a small semantic channel is proven useful.

## Adjacent docs
- `architecture-overview.md`
- `non-decisions-v0.md`
- `supervision-posture-v0.md`
- `activation-posture-v0.md`
- `readiness-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `quiesce-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-LAUNCHD-JOBS
- REF-DAEMONTOOLS-SUPERVISE
- REF-ERLANG-OTP-SUPERVISOR
- REF-S6-RC-WHY
- REF-SD-NOTIFY
- REF-K8S-PROBES
- REF-FUCHSIA-RUNNER
- REF-FUCHSIA-IDLE-STOP
- REF-FUCHSIA-LIFECYCLE
- REF-XPC-TRANSACTION-END
- REF-GNU-SHEPHERD-TRANSIENT-MAKER
- REF-WEZTERM-SHELL-INTEGRATION
- REF-OSC133-SPEC
- REF-VSCODE-SHELL-TRUST
- REF-PLAN9-PLUMBING
