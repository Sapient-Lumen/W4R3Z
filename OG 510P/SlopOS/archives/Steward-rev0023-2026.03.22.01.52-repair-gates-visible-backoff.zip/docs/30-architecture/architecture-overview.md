# Architecture overview

Steward is the **component lifecycle and activation fabric** for SlopOS.

The current compression of the architecture is in [`design-principles-v0.md`](design-principles-v0.md). Those principles intentionally stop short of freezing a giant service-manager worldview while SlopOS itself is still moving.

The matching refusal set is in [`non-decisions-v0.md`](non-decisions-v0.md). That file exists to keep “not decided yet” explicit instead of letting accidental defaults harden into architecture.

## What Steward probably owns
- component identity and lifecycle roots;
- component start / stop / restart policy;
- foreground lifecycle accountability;
- supervisor-owned activation delivery;
- lifecycle observation vocabulary, compact status reporting, and bounded observation subscriptions;
- explicit provisional-state semantics so lag-hiding shell/terminal UX stays visibly tentative until confirmation;
- explicit attention hints so command-finished, needs-input, warning, and progress-like shell/terminal cues stay user-filterable, freshness-scoped, and non-authoritative;
- optional runtime-cycle witnesses for correlating concrete runs;
- compact end-of-cycle cause / termination observations for explaining why a concrete run ended;
- bounded repeated-failure cooldown and optional repair-gate semantics so crash loops become explicit evidence instead of hidden retry folklore;
- bounded continuity escrow;
- readiness, activity accounting, and quiesce semantics;
- lifecycle transcripts / receipts;
- shell/terminal semantic integration for lifecycle-aware UX;
- command-frame observations and receipt-friendly terminal ergonomics;
- explicit shell/terminal attention-hint surfaces for focus-aware alerts, badges, and progress-ish cues without hidden control;
- an optional shell/terminal chrome lane for status bars, sticky headers, tab titles, and other non-transcript presentation surfaces that remain observational and freshness-scoped;
- compact confidence / provenance / trust annotations for shell/terminal observations and action gating;
- explicit user-invoked action surfaces for hyperlinks, chips, and palette affordances tied to explicit Steward targets;
- explicit target anchors so higher-value shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs instead of visible-text scraping;
- explicit bounded context handoff so exact command frames, output slices, receipts, and concrete runs can be attached or exported without ambient whole-scrollback sharing;
- explicit precision fences for shell/terminal trust and capability drift across hops or fallback paths;
- an explicit shell/terminal mode baseline and repair seam so prompt-critical markers, cursor modes, paste handling, and other UX-critical state can be freshly reasserted instead of left to folklore;
- explicit capability handshakes so richer shell/terminal semantics can be enabled from fresh observed support instead of compatibility folklore;
- explicit semantic epochs so stale shell/terminal certainty can be fenced after hops, resync, or shell reset;
- explicit shell/terminal hop lineage so remote-aware context, histories, and action targets stay scoped to the actual path rather than a flat PTY fiction;
- explicit promotion of selected shell-launched long-running work into transient accountable objects.

## What Steward probably does not own
- generic deferred work scheduling (that stays adjacent to jobs/background seams);
- a generic global timer language;
- a monolithic logging system;
- a generic process inventory API;
- a general-purpose host service-manager compatibility layer as native meaning;
- every shell/runtime semantic in SlopOS.

## Design stance
Steward should cover the **responsibility areas** people expect from a competent modern service fabric, but not inherit the integrated, ambient, host-global worldview of a traditional Unix service manager.

That means:
- narrow public semantics,
- foreground, directly accountable lifecycle roots,
- host-specific implementation freedom under the membrane,
- visible non-decisions while SlopOS itself is still converging,
- open questions kept visible until pressure justifies freezing them,
- observational/state protocols and bounded subscription views hardening before giant mutation/control surfaces;
- repeated-failure quieting becoming explainable before any giant retry-policy language hardens.
