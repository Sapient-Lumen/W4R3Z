# Capability handshake posture v0

Purpose: make shell/terminal feature discovery explicit, progressive, and honest instead of trusting `TERM` folklore or stale remembered success.

## Posture
1. **Observed capability beats declared compatibility**
   - `TERM` strings, terminfo entries, and past success are weak hints, not ground truth.
   - Steward should prefer fresh observed capability signals when enabling richer shell/terminal affordances.
2. **Prefer a small explicit handshake over giant static baselines**
   - A shell/terminal stack should be able to exchange a compact capability view for semantic markers, hyperlinks, richer input, redraw batching, and observation side channels.
   - Phase 1 should keep that view narrow and optional.
3. **Progressive enhancement is the default**
   - Unknown sequences and unsupported features should degrade safely.
   - Richer affordances should make the experience better when present, without becoming correctness dependencies.
4. **Requested features and live capability must stay separate**
   - The UI may *want* exact command markers, cwd refresh, synchronized redraw, or richer input.
   - The system must still record what the current path has actually proven it can do.
5. **Capability scope should be local and refreshable**
   - Capability knowledge may differ by terminal, tab, pane, hop, or multiplexer layer.
   - Steward should allow resync or renegotiation instead of assuming one machine-wide truth.
6. **Downgrade should be visible, not silent**
   - If an SSH hop, nested shell, or multiplexer loses a feature, the shell/terminal stack should leave an explicit downgrade or precision fence.
   - That is healthier than silently preserving stale certainty.
7. **Feature use should be target-specific where risk differs**
   - Low-risk affordances such as hyperlinks or redraw hints can be enabled aggressively.
   - Higher-risk affordances such as exact command reporting or action descriptors should require stronger evidence and clearer provenance.
8. **Capability negotiation is observational first**
   - The handshake should describe what semantic UX is available.
   - It should not quietly become a hidden lifecycle control API.
9. **Unknown or partial support is normal**
   - Some terminals ignore unknown sequences correctly; some do not; some layers preserve a subset of features only.
   - Steward should be built around that messy reality instead of a fantasy uniform terminal substrate.

## Phase-1 non-goals
- inventing a giant universal terminal feature ontology;
- assuming terminfo or `TERM` is sufficient proof of exact semantics;
- requiring every shell, terminal, and multiplexer layer to implement the full handshake before any semantic UX works;
- turning feature negotiation into a hidden remote-control plane.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `action-surface-posture-v0.md`
- `precision-fence-posture-v0.md`
- `observation-subscription-posture-v0.md`

## References
- REF-ITERM2-FEATURE-REPORTING
- REF-KITTY-PROTOCOL-EXTENSIONS
- REF-KITTY-KEYBOARD-PROTOCOL
- REF-FISH-TERMINAL-COMPAT
- REF-FISH-OSC-MARKERS
- REF-NCURSES-FAQ
- REF-XTERM-FAQ
- REF-WEZTERM-SYNC-RENDER
