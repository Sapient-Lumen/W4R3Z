# Shell + terminal integration posture v0

Purpose: identify how Steward can make the custom SlopOS shell+terminal unusually good without letting PTY folklore become lifecycle semantics.

## Posture
1. **Use an explicit semantic side channel**
   - Prompt boundaries, command start/finish, working directory, hyperlinks, marks, and structured receipts should travel on an explicit shell/terminal channel, not be inferred from raw text alone.
2. **Expose prompt / input / output / command-frame boundaries**
   - Prompt, input, and output zones should be inspectable and navigable.
   - The shell and terminal may also treat a full command interaction as one semantic frame/block for navigation, copy, bookmarking, and receipt attachment.
3. **Keep stdout/stderr as program output**
   - Semantic metadata should not require rewriting ordinary command output.
4. **Prefer a parseable side channel over buffer archaeology**
   - A machine-friendly companion channel for marks, frame boundaries, or pane state is healthier than re-parsing rendered bytes and hoping for the best.
   - tmux control mode is a good reminder that a text protocol can stay parseable and SSH-friendly without replacing the terminal stream.
5. **Prefer small interoperable marker sets first**
   - Phase 1 should happily reuse small building blocks such as working-directory markers, prompt/output markers, marks, and hyperlinks where they fit.
   - A giant custom RPC is a later option, not the starting point.
6. **Command receipts beat log scraping**
   - When lifecycle-aware commands run, the shell should be able to attach a compact receipt or sidecar summary rather than forcing the terminal to guess what happened.
7. **Runtime-cycle witnesses and component ids are good plumbing material**
   - When a command starts, inspects, or promotes a component, the shell/terminal stack should be able to carry component identity and optional runtime-cycle witness information alongside the frame.
   - That makes “is this still the same run?” and “what did that command actually act on?” much less guessy.
8. **Fresh cwd and prompt metadata should win over stale guesses**
   - The shell should be willing to report cwd on each fresh prompt and provide prompt-end / command-start markers when available so terminals do not preserve stale remote context after hops or subprocesses.
9. **Remote-aware semantic transport matters**
   - Shell integration should survive SSH-like hops well enough to preserve cwd, prompt marks, command-frame boundaries, and selected pane state when possible.
10. **Hop lineage should stay explicit where remote-aware UX matters**
   - Remote host, multiplexer, and preserved-semantic path hints are worth carrying explicitly when available.
   - That helps keep cwd, histories, actions, and titles scoped to the actual path instead of a flat PTY fiction.
11. **Pane-scoped state is promising, but should stay observational first**
   - Extra shell state such as remote identity, active component, or last receipt digest may be useful as pane-scoped metadata.
   - That metadata must not silently widen authority or become the only truth.
12. **Marker provenance and confidence matter**
   - Explicit shell-reported command data is better than blind terminal scraping.
   - When a shell/terminal pair can bind semantic markers to a session nonce or equivalent trust signal, replay and rerun UX can become safer.
   - Buffer-derived guesses should remain visibly lower-confidence and non-authoritative.
13. **Confidence should be allowed to refine over time**
   - Fresh prompt resync, command completion, or receipt arrival may let the shell/terminal pair upgrade an earlier guess.
   - Steward should allow later exactness to replace earlier approximation without rewriting history about how the first guess was obtained.
14. **Plumbing is a first-class opportunity**
   - File names, digests, URLs, component ids, error locations, and receipt pointers should be plumbable through rules, not only copied by hand.
15. **Keyboard, paste, and click semantics deserve explicit handling**
   - Bracketed paste and enhanced key/click reporting are the same kind of win as prompt markers: they reduce ambiguity without silently changing authority.
   - Steward should steal the lesson of explicit input-side semantics before inventing shell-local hacks.
16. **Layer boundaries should have explicit semantic fences**
   - SSH-like hops, tmux-like layers, or shell restarts should be able to declare “semantic precision may have dropped here.”
   - That is better than silently preserving stale cwd, command, or trust assumptions across layers.
17. **Fresh resync should be first-class**
   - When a shell, hop layer, or terminal gets confused, the preferred recovery is to emit fresh prompt/cwd/capability state and establish a new semantic epoch.
   - That is healthier than mutating stale certainty in place.
18. **Capability handshakes should beat compatibility folklore**
   - `TERM`, terminfo, or remembered success are useful hints but not proof of exact support.
   - Where richer semantics matter, the shell/terminal stack should prefer fresh explicit capability signals and keep them scoped to the actual pane/hop path.
19. **Progressive enhancement should beat giant mandatory baselines**
   - Small optional features such as richer keyboard input, synchronized rendering, prompt markers, and cwd reporting should be treated as capabilities that can be used when present and ignored safely when absent.
   - Steward should not require every shell, terminal, and multiplexer to agree on a giant perfect baseline before semantic UX becomes useful.
20. **Command-finish UX should prefer explicit finish data**
   - Notifications, marks, and “show me the last finished command” affordances should attach to explicit command-frame completion and Steward receipts when available.
   - They should not guess command completion from arbitrary output patterns.
21. **Attention cues should stay explicit, focus-aware, and user-filterable**
   - Bells, badges, progress rings, and command-finished notifications are genuinely useful once command frames are explicit.
   - They should remain bounded hints tied to fresh semantic state rather than a hidden automation or notification bus.
22. **Action surfaces should stay explicit and user-invoked**
   - Hyperlinks, frame-local chips, context menus, and command-palette entries are promising, but they should bind to explicit Steward targets and remain user-invoked.
   - They must not become a hidden ambient mutation bus.
23. **Terminal UX is not lifecycle authority**
   - Marks, alerts, semantic zones, hyperlinks, and command blocks are observational and ergonomic; they must not become implicit permission to kill/restart/reconfigure components.

## Phase-1 non-goals
- parsing every shell language feature;
- letting the terminal issue lifecycle mutations without explicit user action and authorization;
- inventing a giant shell/terminal RPC protocol before small semantic channels are tried;
- making command blocks or semantic frames the only representation of terminal history;
- treating replayable shell markers as trusted control input without provenance.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `supervision-posture-v0.md`
- `activation-posture-v0.md`
- `readiness-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `command-frame-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `provisional-state-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `termination-cause-posture-v0.md`
- `action-surface-posture-v0.md`
- `precision-fence-posture-v0.md`
- `attention-hint-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `mode-baseline-posture-v0.md`

## References
- REF-NUSHELL-PIPELINES
- REF-PLAN9-PLUMBING
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-SHELL-INTEGRATION
- REF-KITTY-SHELL-INTEGRATION
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-ESCAPE-CODES
- REF-OSC133-SPEC
- REF-WARP-BLOCKS
- REF-TMUX-CONTROL-MODE
- REF-GHOSTTY-SHELL-INTEGRATION
- REF-KITTY-KEYBOARD-PROTOCOL
- REF-XTERM-BRACKETED-PASTE
- REF-FISH-OSC-MARKERS
- REF-FISH-TERMINAL-COMPAT
- REF-GHOSTTY-RELEASE-130
- REF-WEZTERM-SYNC-RENDER
- REF-ITERM2-FEATURE-REPORTING
- REF-WEZTERM-PANE-USER-VARS
- REF-KITTY-SSH
- REF-NCURSES-FAQ
- REF-XTERM-FAQ
