# Non-decisions posture v0

Purpose: make Steward's **intentional non-decisions** explicit while SlopOS itself is still in design.

This file is not a lack of rigor. It is a guardrail against freezing giant semantics before Steward has earned them.

## Posture
1. **No portable global unit language in v0**
   - Steward does not yet freeze a full dependency/unit/timer/orchestration grammar.
   - Local start-order constraints may exist, but a host-global declarative empire is intentionally deferred.
2. **No portable process inventory or adopt-arbitrary-process API**
   - Steward supervises declared component roots, not “anything with a PID.”
3. **No final runner taxonomy yet**
   - The seam between supervision and runtime-specific launch should stay visible, but Steward does not yet freeze the complete universe of runner kinds or plugin contracts.
4. **No final restart-budget grammar yet**
   - Bounded restart intent matters, but the exact public tuning vocabulary should stay small until real operating experience accumulates.
5. **No generic timer language yet**
   - SlopOS already has adjacent jobs/background design pressure; Steward should not preemptively absorb it.
6. **No broad remote admin/control bus yet**
   - Status/receipt and explicit local control matter sooner than a big ambient management plane.
7. **No commitment yet on service-package shape**
   - A service-as-directory or bundle discipline might be useful, but packaging should not become accidental lifecycle meaning too early.
8. **No universal shell/terminal protocol contract yet**
   - OSC 7, OSC 8, OSC 133, pane-scoped user variables, and receipts are promising building blocks, but Steward should keep the baseline negotiable and observational first.
9. **No assumption that one idle model fits all runtimes**
   - Some components will have strong idle/transaction boundaries; others will not. Steward should not pretend otherwise by freezing fake precision.
10. **No final transient-command-to-service seam yet**
    - Long-running shell-launched work may eventually have a first-class transient-service story, but Steward should not freeze that public contract before jobs/background and shell ergonomics settle.
11. **No final portable activity-accounting grammar yet**
    - Steward should make room for busy/idle and in-flight-work hints without freezing one fake universal request-count or keepalive model.
12. **No final health-check contract yet**
    - Local adapters may use health checks, but Steward should not let them become the only portable truth about liveness or readiness.
13. **No final terminal input protocol choice yet**
    - Enhanced keyboard, paste, click, and mouse reporting are promising, but Steward should not overcommit to one protocol family too early.
14. **No promise that the terminal is a control authority**
    - The shell+terminal can become unusually good at navigation, explanation, and explicit actions without becoming an ambient lifecycle control plane.

## Why this refusal matters
- SlopOS is still moving in adjacent seams like jobs, background presence, capshell, turns, and portals.
- If Steward freezes broad semantics too early, it will accidentally become the place where unresolved SlopOS architecture congeals.
- Explicit non-decisions are healthier than hidden defaults.

## Adjacent docs
- `architecture-overview.md`
- `design-principles-v0.md`
- `decision-map.md`
- `supervision-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `activity-accounting-posture-v0.md`

## References
- REF-S6-RC-WHY
- REF-FUCHSIA-RUNNER
- REF-VSCODE-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-GNU-SHEPHERD-TRANSIENT
- REF-KITTY-KEYBOARD-PROTOCOL
- REF-OPENRC-SUPERVISE-DAEMON
