# Interface registry

| ID | Surface |
| --- | --- |
| IF-STEWARD | the user-space Steward lifecycle manager itself |
| IF-ACTIVATE | activation delivery path |
| IF-STATUS | compact current-state/status path |
| IF-REPAIR | repeated-failure cooldown / repair-gate observation and explicit clear path |
| IF-SUBS | bounded snapshot-plus-change subscription path for observation views, including explicit resync/overflow hints when exact continuity is lost |
| IF-OBS | observation / transcript export |
| IF-SHELLTERM | shell and terminal semantic side channel |
| IF-CMDFRAME | command-frame observation path for prompt/input/output boundaries and receipts |
| IF-HANDSHAKE | shell/terminal capability-handshake and downgrade-observation path |
| IF-MODEBASE | shell/terminal prompt-critical mode-baseline and repair-observation path |
| IF-EPOCH | shell/terminal semantic-epoch freshness and stale-fence path |
| IF-HOPS | shell/terminal hop-lineage observation path for remote and multiplexer-aware context |
| IF-ACTIONS | explicit shell/terminal action-surface path for chips, hyperlinks, and palette entries bound to Steward targets |
| IF-ANCHORS | bounded exact-target anchor path for command frames, receipts, transcript spans, and concrete runs used by shell/terminal affordances |
| IF-HANDOFF | bounded command/context handoff path for exact command frames, output slices, receipts, and concrete runs |
| IF-ATTN | shell/terminal attention-hint path for command-finished, needs-input, warning, error, and progress-like cues |
| IF-CHROME | shell/terminal chrome lane for observational badges, tab titles, sticky headers, status cells, and similar non-transcript presentation surfaces |
| IF-TRANSIENT | explicit promotion path from shell work to transient Steward-tracked object |
