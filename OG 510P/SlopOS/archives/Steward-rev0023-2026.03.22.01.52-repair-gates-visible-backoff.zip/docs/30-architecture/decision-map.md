# Decision map

Guiding compression: `design-principles-v0.md`.
Refusal / freeze-late companion: `non-decisions-v0.md`.

## D-SUPV
How component-rooted supervision works; see `supervision-posture-v0.md`.

## D-ACTIVATE
How activation handles and continuity escrow work; see `activation-posture-v0.md`.

## D-READY
How startup, readiness, and liveness stay distinct; see `readiness-posture-v0.md`.

## D-ACTIVITY
How in-flight work, idle hints, and drain accounting stay explicit without pretending every runtime fits one idle model; see `activity-accounting-posture-v0.md`.

## D-LIFECYCLEOBS
How Steward names and surfaces minimal lifecycle observations; see `lifecycle-observation-posture-v0.md`.

## D-STATUS
How compact current-state reporting stays separate from logs and receipts; see `status-channel-posture-v0.md`.

## D-SUBSCRIBE
How bounded observation subscriptions can provide snapshot-plus-change views without polling or a hidden control bus; see `observation-subscription-posture-v0.md`.

## D-PROVISIONAL
How shell/terminal UX may surface tentative local state and later confirmation without turning prediction into lifecycle truth; see `provisional-state-posture-v0.md`.

## D-ATTENTION
How shell/terminal attention hints stay focus-aware, freshness-scoped, and non-authoritative instead of devolving into bell/title folklore; see `attention-hint-posture-v0.md`.

## D-CHROME
How shell/terminal status bars, badges, sticky headers, titles, and progress chrome stay observational, freshness-scoped, and separate from the canonical transcript; see `chrome-lane-posture-v0.md`.

## D-CYCLE
How concrete runtime cycles may carry an opaque witness for attribution and stale-action fences; see `runtime-cycle-witness-posture-v0.md`.

## D-TERMCAUSE
How Steward observes and explains why one concrete runtime cycle ended without freezing a giant fault taxonomy; see `termination-cause-posture-v0.md`.

## D-REPAIR
How repeated-failure cooldown and repair-required quieting stay explicit without freezing a giant retry-policy language; see `repair-gate-posture-v0.md`.

## D-QUIESCE
How cooperative drain/gating works; see `quiesce-posture-v0.md`.

## D-SHELLTERM
How shell and terminal exchange semantic lifecycle metadata; see `shell-terminal-integration-posture-v0.md`.

## D-CMDFRAME
How explicit command-frame observations stay useful without becoming a control bus; see `command-frame-posture-v0.md`.

## D-CONFIDENCE
How shell/terminal observations carry compact confidence, provenance, and trusted-ness without pretending every marker is equally exact; see `observation-confidence-posture-v0.md`.

## D-ACTIONS
How explicit shell/terminal action surfaces stay user-invoked, target-bound, and stale-fenced instead of becoming hidden ambient control; see `action-surface-posture-v0.md`.

## D-ANCHORS
How explicit shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without visible-text scraping or raw-capability leakage; see `target-anchor-posture-v0.md`.

## D-HANDOFF
How explicit command/context handoff stays bounded, exact when possible, and separate from ambient whole-scrollback sharing; see `context-handoff-posture-v0.md`.

## D-EPOCH
How shell/terminal observations and affordances admit “that belonged to an older semantic world” after hops, restarts, or resync; see `semantic-epoch-posture-v0.md`.

## D-HOPLINEAGE
How shell/terminal semantics can stay explicitly scoped to the actual remote/multiplexer path instead of a flat PTY fiction; see `hop-lineage-posture-v0.md`.

## D-FENCES
How shell/terminal layers admit precision loss, capability drift, and resync boundaries instead of silently preserving stale certainty; see `precision-fence-posture-v0.md`.

## D-MODEBASE
How shell/terminal prompt-critical modes can return to a small known baseline or surface visible repair needs instead of relying on folklore and manual `reset` rituals; see `mode-baseline-posture-v0.md`.

## D-TRANSIENT
How long-running shell work may be promoted into transient Steward-tracked objects without freezing a giant transient-unit language; see `transient-promotion-posture-v0.md`.

## D-FREEZELATE
What Steward should intentionally leave unfrozen while SlopOS is still moving; see `non-decisions-v0.md`.

## Open questions
- OQ-0001 through OQ-0032 in `docs/00-meta/trajectory-map.md`.
