# Evaluating the SlopOS datacube for Steward

This note evaluates the uploaded SlopOS datacube as a template for Steward after another pass through both the parent archive and current Steward needs.

## What is excellent and should be copied now
- **archive hygiene from day 1**: changelog discipline, context pack, lint, package-release, verify-release;
- **explicit REF/EVID culture**: it makes research accumulative instead of repetitive;
- **posture docs**: the “small seam, explicit refusal set, adjacent docs” pattern is strong;
- **anti-ambient worldview**: the best thing in the SlopOS archive is how consistently it refuses accidental Unix inheritance;
- **amnesia resistors**: the parent archive’s runbook / trajectory / roadmap pattern is genuinely useful and worth keeping;
- **workflow-first thinking**: capshell, jobs, background leases, and portal notes are all reminders that SlopOS wants explicit workflows rather than ambient hidden channels.

## What Steward should copy, but in lighter form
- **promotion discipline**: the parent repo’s RFC-to-ADR promotion logic is good, but Steward should keep it informal until more than a handful of real design branches exist;
- **profile pressure awareness**: SlopOS’s profile-posture matrix is valuable, but Steward should first survive with prose notes before it grows its own matrix;
- **resolved history**: useful once Steward has several superseded positions, but not necessary to invent early;
- **micro-automation for hygiene**: small generated artifacts like source review queues and lock-sync checks are worth copying before bigger document families;
- **observations-before-mutations discipline**: the parent archive is strongest when it first pins meanings and refusal sets, then later grows richer interfaces. Steward should imitate that by freezing observation/state vocabulary before inventing broader control surfaces.

## What Steward should postpone until the seam count truly explodes
- full boundary-family and adjunct-index machinery;
- large singleton indexes whose main job is to route around archive size;
- a must-read set so large that every revision feels like booting a planet;
- tool proliferation whose main job is to police complexity Steward does not yet have;
- schema families for every lifecycle/status wrinkle before real operating pressure exists.

## What Steward should probably not copy at all unless reality forces it
- archive surface area that outruns the actual number of stable portable seams;
- highly granular doc families for variations that are still mostly thought experiments;
- any tendency to let repo structure imply architectural certainty that the design has not earned.

## What Steward should preserve culturally
- explicit non-goals;
- visible open questions;
- strong packaging discipline;
- no raw-URL sprawl;
- archive text that is small enough to be reloaded mentally;
- source-intake hygiene that stays lightweight enough to keep using;
- an explicit place for “not decided yet” so unresolved SlopOS questions do not harden by accident;
- a bias toward tiny observational protocols before giant mutation/control languages.

## Another lesson from the parent archive
SlopOS is very good at keeping **descriptive live truth** separate from **requested policy** and at refusing to let a convenience API quietly become the real constitution of the system. Steward should keep stealing that move. The new termination-cause seam is strongest when it stays observational: “why did that concrete run end?” is valuable; “therefore here is the universal portable fault ontology and restart policy grammar” would be premature.

A second current lesson is process-related: the parent archive earns most of its complexity by long accumulation, not by one big up-front structure dump. Steward should keep copying the discipline but continue resisting the temptation to prebuild large family machinery until three or more genuinely stable seams want the same structure.

## Current recommendation
Steward should remain a **lighter datacube than SlopOS** while both systems are still in design.

That means:
- keep the source-lock / evidence / handoff discipline;
- keep posture docs small and specific;
- add principles before APIs;
- add observation vocabulary before broad control surfaces;
- add non-decisions before large frameworks;
- add automation that removes paper cuts before adding new document families;
- let the archive get denser only when Steward’s public seam count really earns it.

## What this pass through SlopOS adds
The parent archive keeps reinforcing that Steward should align most closely with SlopOS's capshell, plumb, background, and quiesce seams rather than with a host-global init worldview. In practice that means the shell/terminal work should stay closely adjacent to SlopOS's existing ideas about explicit CLI intents, request contexts, and capability-safe automation, while lifecycle work stays adjacent to activation and quiesce instead of trying to absorb jobs/background wholesale.

## Why this matters specifically now
SlopOS is still designing many adjacent seams—jobs, background leases, capshell, activation, turns, constructor policy. If Steward hardens too fast, it will accidentally become the place where unresolved parent-architecture decisions congeal. The archive should therefore stay **decision-light but idea-rich** for a while longer.

The newest lesson from the parent archive is that Steward should keep copying SlopOS's habit of separating **descriptive live truth** from **requested policy**. That matters for activity accounting especially: a component can honestly report “busy”, “idle”, or “draining” without that report itself becoming a broad control plane or an excuse to freeze global scheduler semantics too early.

A second current lesson from the parent archive is structural: SlopOS has a strong singleton-boundary discipline for not exploding a family of docs too early. Steward should imitate the spirit of that rule even if it does not copy the full machinery yet. The new transient-promotion posture is a good example of the right size: one narrow seam, explicit refusals, open questions still visible elsewhere.

A third current lesson is that SlopOS is already comfortable with **revision/epoch explicitness** where stale authority would otherwise be dangerous. That makes a small opaque runtime-cycle witness feel culturally aligned with the parent archive: not a giant process API, just enough identity to keep receipts, shell actions, and later explanations attached to the right concrete run.

A fourth current lesson is that Steward should probably copy SlopOS’s habit of naming **small explanatory vocabularies** before inventing broad mutation surfaces. A compact termination-cause seam is in that spirit: first make “requested stop / clean exit / crash / timeout / policy kill / unknown” explicit, then only later decide whether any broader event protocol is warranted.


A fifth current lesson is UI-related: SlopOS is healthiest when affordances remain explicit about what object they point at and what authority they do *not* grant. Steward's new action-surface seam fits that culture well as long as it stays tiny — one posture for explicit chips/hyperlinks/palette entries bound to concrete targets — instead of turning into a hidden terminal control bus.

A sixth current lesson is interface-shape discipline. SlopOS tends to prefer explicit small schemas and named observational surfaces over undocumented side channels. Steward's new observation-subscription seam should imitate that: one tiny posture, one tiny interface registry entry, and explicit non-goals, rather than a sprawling generic event bus before there is evidence it is needed.


A seventh current lesson is interface honesty across degradation paths. SlopOS is strongest when it refuses to let a convenience name or stale request state masquerade as live truth. Steward's new precision-fence seam fits that cultural rule: a shell hop, multiplexer layer, or fallback terminal mode should be allowed to say "precision degraded here" rather than silently carrying old certainty forward. That feels much more aligned with SlopOS than pretending TERM folklore or remembered cwd is good enough.


An eighth current lesson is about capability truth. SlopOS repeatedly separates descriptive live truth from requested or remembered policy state. Steward's new capability-handshake seam fits that habit well: the UI may request rich shell/terminal semantics, but the archive should keep a place to record what the current pane/hop path has actually proven it supports. That is a better match for SlopOS than letting `TERM`, a cached host profile, or last week's successful session harden into current truth.

## Fresh evaluation note
One SlopOS habit Steward should copy more aggressively is the distinction between requested policy and live descriptive truth. A semantic-epoch seam is a shell/terminal version of that same discipline: old observations remain visible, but the system is allowed to say that they no longer describe the current semantic world exactly.

## Fresh evaluation note
Another thing Steward should borrow from the SlopOS parent archive is its refusal to let **path convenience** harden into **live truth**. The new hop-lineage seam fits that culture well: remote host, cwd authority, and preserved semantics can be described explicitly for shell UX, but those hints should remain observational and freshness-scoped instead of becoming ambient authority or transport mythology.

## Fresh evaluation note
Another SlopOS habit Steward should borrow is its refusal to flatten *all* state into one confidence bucket. The parent archive repeatedly separates descriptive live truth from requests, intents, and remembered policy. A tiny observation-confidence seam fits that culture well: command text, cwd, and action targets can each admit their own exactness and trust level instead of inheriting one pane-wide story.


## Fresh evaluation note
Another SlopOS habit Steward should copy is the refusal to let a convenient live hint silently become the system's real constitutional truth. A tiny provisional-state seam fits that culture well: optimistic shell UX can exist, but the archive keeps a place to say which observations are still pending confirmation and which later became the durable live story.

A ninth current lesson is UI-contract discipline. SlopOS is strongest when ergonomic affordances remain explicit about what they observe and what they do *not* authorize. The new attention-hint seam fits that culture well: “this frame finished”, “this pane needs input”, or “this long-running task is 60% done” are useful descriptive hints, but they should remain observational and user-filterable rather than silently becoming ambient workflow control.

## Fresh evaluation note
Another SlopOS habit Steward should borrow is the refusal to treat whichever representation happens to be convenient in the UI as the system's real truth. A tiny target-anchor seam fits that culture well: the user can click or act on a frame, receipt, or transcript span, but the archive keeps a place to say what exact object that affordance referred to and when that binding went stale.

## Fresh evaluation note
A second related parent-archive lesson is that descriptive naming and authority should stay separated. Steward's target-anchor seam should remain descriptive and freshness-scoped: it can say *which exact object* a shell affordance points at without quietly smuggling in permission to mutate that object.


## Fresh evaluation note
Another SlopOS habit Steward should borrow is the refusal to let the most convenient UI surface become the system's constitutional truth. A tiny chrome-lane seam fits that culture well: badges, sticky headers, titles, and side status cells can stay useful, but they remain freshness-scoped observational summaries over the real command/output/receipt record rather than a new ambient authority channel.

## Fresh evaluation note
Another SlopOS habit Steward should borrow is the refusal to let a convenient remembered mode stand in for live truth. A tiny mode-baseline seam fits that culture well: the current shell/terminal path can explicitly reassert what prompt-critical semantics are live now, while stale leftovers from a TUI, crash, or hop remain just that—leftovers, not constitutional truth.


## Fresh evaluation note
Another SlopOS habit Steward should borrow is the refusal to let a convenience export become the system's real truth. The parent archive's result-sidecar and output-normal-form work points toward a good Steward rule: when shell or lifecycle context is handed off, it should prefer exact bounded bundles with explicit refs and digests over “copy whatever happened to be on screen.” That feels much closer to SlopOS than ambient whole-scrollback sharing.

## Fresh evaluation note
Another SlopOS habit Steward should borrow is the refusal to let repeated failure disappear into ambient retry policy. The parent archive is healthiest when denied, degraded, or not-currently-true states stay explicit and evidence-backed. A tiny repair-gate seam fits that culture well: the system can say “cooling down” or “repair required” with exact recent-cycle evidence instead of silently hammering the same component forever.
