# Steal these ideas

## Ideas worth stealing almost directly
- **Foreground supervision discipline**: managed services should stay directly accountable to the supervisor rather than daemonizing away.
- **Manager-owned activation handles**: keep the public listener/end-point identity system-owned.
- **Name-keyed activation lookups**: D-Bus system activation is a good reminder that a privileged helper can accept a validated name instead of a mutable path-and-environment blob.
- **Bounded continuity escrow**: allowlisted, same-component continuity only.
- **Explicit child specifications and ordered shutdown**: OTP’s “start in order, stop in reverse order” is still a great small idea.
- **Restart intensity + period thinking**: make crash-loop tolerance explicit and bounded instead of purely heuristic.
- **Offline planning when possible**: s6-rc's argument for precompiled dependency analysis is compelling even if Steward later adopts only a small version of it.
- **Explicit startup/readiness/liveness split**: Kubernetes got the vocabulary right even if the surrounding platform is much larger than Steward.
- **Shallow-vs-deep readiness naming**: keep “control/status path is up” distinct from “component can do declared work.”
- **Restarters/runners as explicit seams**: do not make every runtime launch path part of one giant core.
- **Status channels separate from logs**: explicit ready/stopping/status notifications are much easier to reason about than “grep the logs and squint.”
- **Opaque per-runtime-cycle witnesses**: keep one small piece of data that says “this exact run” without pretending PIDs or process trees are the portable truth.
- **Accountable oneshot transitions**: let transition helpers run under the lifecycle fabric’s accountability model rather than as floating admin children.
- **Idle / transaction hints**: where components can meaningfully say “I am idle” or “I have in-flight work,” that can unlock bounded stop/escrow behavior.
- **Explicit begin/end keepalive brackets**: XPC-style transaction boundaries are a compelling small model for “don’t stop me yet” without a giant scheduler contract.
- **Transient services for shell-launched work**: Shepherd's `spawn transient` idea and systemd-run both show a useful accountability pattern for long-running commands.
- **Structured shell output hooks**: Nushell shows the value of structured pipeline results even in an interactive shell.
- **Plan 9 style plumbing**: route meaningful objects and intents instead of only raw text.
- **Prompt / command / output markers**: OSC 133 style markers are small, practical, and already useful.
- **Working-directory side channels**: OSC 7 style cwd reporting pays for itself quickly.
- **Explicit hyperlinks**: OSC 8 style hyperlinks are a great fit for receipt pointers, digests, docs, and error locations.
- **Short-lived exact-target anchors**: let high-value shell/terminal affordances bind to concrete frames, receipts, transcript spans, or runs instead of re-parsing visible text.
- **Per-host/per-pane state memory**: recent directories, command history, and small user variables keyed by host/pane are powerful shell ergonomics.
- **Marker trust and confidence**: explicit nonce-bound shell reports are safer than re-parsing scrollback and hoping the result is right.
- **Per-field confidence badges**: command text, cwd, remote-path hints, and action targets should be allowed to carry their own precision/trust annotations instead of inheriting one pane-wide myth.
- **Precision fences across hops and fallbacks**: when a layer downgrades exact cwd/command/trust knowledge, leave a visible fence instead of pretending certainty survived.
- **Optional synchronized rendering**: use redraw batching when a terminal supports it so prompt/frame/status refresh feels atomic without making the feature mandatory.
- **Capability honesty**: treat TERM names and past success as weak hints, then prefer fresh feature use and safe ignore behavior over compatibility folklore.
- **Tiny capability handshakes**: a compact feature-reporting layer for prompt markers, cwd refresh, richer input, hyperlinks, and redraw hints can keep semantic UX grounded in observed support.
- **Per-hop capability ledgers**: SSH hops, multiplexers, and nested shells should be able to say what semantic features they preserved, dropped, or only partially trust.
- **Small mode baselines with explicit repair**: prompt markers, cwd freshness, cursor shape, bracketed paste, and focus-reporting should be allowed to reassert at a fresh prompt or admit that repair is needed.
- **Light resync versus hard reset**: a custom shell+terminal should clearly separate semantic resync, baseline reassertion, and full emergency reset instead of relying on one folklore hammer.
- **Semantic epochs for freshness**: when a shell restarts, a hop lands, or a resync happens, old command frames and actions should still exist but should no longer pretend to be current.
- **Control-ready versus service-ready vocabulary**: Dinit's distinction is exactly the kind of observational honesty Steward should copy.
- **Machine-friendly side protocols**: tmux control mode is a compelling reminder that parseable, asynchronous text protocols can coexist with terminal rendering.
- **Subscriptions for observational state**: a tiny subscription path for pane or component observations can beat polling without becoming an admin bus.
- **Input-side explicitness**: bracketed paste and richer keyboard/click reporting are worth stealing just as much as prompt markers.
- **Focus-aware command notifications**: once command boundaries exist, command-finished notifications become cheap and high-value.
- **Predictive local echo on bad links**: Mosh demonstrates that latency-hiding and visibly provisional local echo are worth studying for a custom remote shell stack.
- **Provisional badges with later confirmation**: prompt-local shell metadata can be tentatively useful before it is confirmed, as long as the UI can later mark it confirmed, revised, or withdrawn.
- **Non-transcript chrome lanes**: badges, status bars, sticky headers, tab titles, and progress rings are a better home for live context than polluting prompts or command output.

## Ideas to steal, but only after narrowing them
- **Pane-scoped user vars / metadata**: useful for showing remote identity, active component, or receipt digests, but dangerous if they silently become policy truth.
- **Marks and decorations**: great for navigation and failure visibility, but they should remain observational.
- **Remote-aware cwd propagation**: excellent ergonomics, but it needs explicit transport boundaries and failure modes.
- **Idle-stop behavior**: compelling for some runtimes; dangerous as a universal assumption.
- **Open command output in pager / select exact output**: a big UX win, but it needs stable command-frame boundaries.
- **Lifecycle state/status chips in the terminal**: promising, but only if backed by explicit current-state channels and receipt provenance.
- **Chrome should stay copy-safe**: exporting transcript text should not silently smuggle badge/status/title ornament that was only meant for glanceable UI chrome.
- **Selection-to-anchor promotion**: very promising for “copy exact output”, “open transcript for this frame”, and “act on the same concrete run”, but it needs bounded lifetime and safe downgrade rules.
- **Shell-originated prompt/cwd markers**: fish and Ghostty suggest the shell should participate directly in semantic reporting instead of leaving it all to the terminal.
- **Exact command reporting with trusted nonce support**: VS Code’s `OSC 633` model is a strong precedent for exact command lines plus a separate trust bit.
- **Post-finish confidence upgrades**: command metadata that begins approximate should be allowed to become more exact after completion, receipt arrival, or prompt refresh.
- **Prompt-local click/URL metadata**: fish’s `click_events` and `cmdline_url` style extensions hint at lightweight ways to make prompts and command frames more navigable.
- **Transient promotion from command frames**: strong idea, but the boundary between a plain command, a transient service, and a background lease still needs care.
- **Per-cycle end-cause chips**: showing compact “requested stop / clean exit / timeout / resource kill” results next to a command frame or receipt feels high value, but only if the data is explicit and not scraped from logs.
- **Semantic fences across hops**: shells, SSH hops, and multiplexers should be able to mark where cwd/command/trust precision degraded instead of silently carrying stale certainty forward.
- **Roaming session resilience**: shell transport that survives sleep, IP changes, or spotty links could be wonderful, but it should not be mistaken for lifecycle continuity of the remote component.

## Things to admire without importing wholesale
- systemd's breadth;
- Kubernetes' orchestration ambition;
- terminal-specific remote-control protocols;
- giant service-unit grammars.

The useful pattern is to steal the small clear seam, not the whole worldview around it.

## Fresh ideas from this pass
- **Witness-fenced action chips**: command frames, receipts, and status lines could surface tiny actions such as “open transcript”, “inspect component”, or “stop same run”, but only when they carry explicit target refs and expected cycle witnesses.
- **Palette entries from terminal semantics**: Ghostty's command-palette direction hints at a lovely future where terminal programs can expose explicit actions to the palette. Steward should steal the idea cautiously: tiny descriptor, user-invoked only, no ambient mutation.
- **Hyperlink/open-action rules for receipts and digests**: kitty-style open-action routing is a great precedent for making digests, transcript refs, and docs clickable/plumbable without forcing the terminal to parse prose heuristically.
- **Minimal terminal extension posture**: kitty's “small and unobtrusive” protocol stance is a design lesson in its own right. Steward's terminal semantics should win by adding a few sharp capabilities, not by redesigning the universe.

## Subscription-backed views instead of polling
Steward should explore a tiny subscription model that starts with a bounded snapshot and then emits compact change notices for status/lifecycle views. tmux control mode subscriptions and D-Bus `PropertiesChanged` / `ObjectManager` patterns suggest a good shape: explicit watched objects, coalesced changes, and an honest resync path when the client falls behind.
References: REF-TMUX-CONTROL-MODE, REF-TMUX-CHANGES, REF-DBUS-API-DESIGN.

## Another fresh idea from this pass
A tiny terminal capability handshake could mirror Steward's broader design instinct: separate *requested UX* from *live proven support*. That feels culturally aligned with SlopOS, because it refuses to let a convenience label such as `TERM=xterm-256color` masquerade as current truth.
References: REF-ITERM2-FEATURE-REPORTING, REF-XTERM-FAQ, REF-FISH-TERMINAL-COMPAT.

## Fresh ideas from this pass
- **Remote-aware path chips**: a shell/terminal stack that can show current host, cwd authority, tmux/SSH preservation, and confidence in one compact strip would make remote work feel first-class without hidden control.
- **Same-host same-directory spawn**: kitty's SSH path is a strong precedent for opening a new pane/window already on the same remote host and directory when the path semantics were explicit.
- **Per-hop histories**: command history, recent directories, and recent Steward objects should be keyed by the actual hop path, not just by a flat local terminal identity.
- **Hop-aware action fences**: explicit actions like “inspect component” or “open transcript” can be safer if they remember not just a component/cycle target but also the expected host/path context.

## Another fresh idea from this pass
A tiny hop-lineage descriptor fits Steward's overall design stance well: it separates **where this semantic context came through** from **what authority the user currently has**. That feels much closer to SlopOS than pretending a remote-aware terminal should infer host/path truth from scrollback or ambient session ancestry.
References: REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-KITTY-SSH, REF-GHOSTTY-RELEASE-120.

## Another fresh idea from this pass
A tiny provisional-state descriptor feels like a very SlopOS-compatible steal: it separates **what the UI is optimistically showing right now** from **what has actually been confirmed by the shell/runtime path**. That keeps remote shell UX fast without letting tentative markers or action targets harden into authority-bearing truth.
References: REF-MOSH, REF-MOSH-PAPER, REF-VSCODE-SHELL-TRUST.

## Fresh steals from this pass
- **watch-this-command attention flow**: let the user explicitly watch one command frame and choose bell, toast, badge, or silent completion based on focus state and duration rather than a blanket terminal policy.
- **capability-gated progress chrome**: if the live terminal handshake says progress is supported, allow a tiny ring/bar in tab or taskbar chrome for long-running work; otherwise fall back cleanly.
- **filterable notification classes**: copy kitty's idea that notification sources/types should be classifiable so users can suppress noisy classes without disabling everything.

References: REF-KITTY-DESKTOP-NOTIFICATIONS, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-NOTIFICATION-HANDLING, REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-FEATURE-REPORTING.

## Another fresh idea from this pass
A tiny target-anchor seam fits Steward's overall design stance well: it separates **what exact object an affordance refers to** from **what authority the current user or client has to act on it**. That feels much closer to SlopOS than treating whichever text happens to be on screen as the real API.
References: REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-HYPERLINKS, REF-KITTY-OPEN-ACTIONS, REF-VSCODE-TERMINAL-BASICS, REF-TMUX-CONTROL-MODE.

## Fresh ideas from the mode-baseline pass
- **self-healing prompt ownership**: let the shell explicitly reclaim prompt-local cursor shape, cwd freshness, and marker state when it returns, instead of expecting every program to clean up perfectly.
- **repair badges, not silent lies**: when the semantic path is confused, show a tiny “needs resync” or “baseline repaired” badge rather than pretending the current prompt state is unquestionably exact.
- **mode repair should stay local**: a user-invoked emergency reset is valuable, but it should repair the terminal path, not masquerade as component lifecycle control.

References: REF-XTERM-MANPAGE, REF-ITERM2-TMUX-INTEGRATION, REF-GHOSTTY-RESET-ACTION, REF-KITTY-CONF, REF-FISH-OSC-MARKERS.

## Fresh ideas from the chrome pass
- **Transcript truth, chrome glanceability**: make the durable record live in frames/receipts/transcripts, then let badges, sticky headers, and tab chrome summarize it for fast navigation.
- **Sticky command headers with exact anchors**: if a command is partially scrolled away, a sticky header should carry the exact frame anchor and confidence bits rather than a guessed text summary.
- **Remote-aware titles without prompt pollution**: current host, cwd summary, or active component should prefer badge/tab/status surfaces over adding more mutable text to the prompt itself.
- **Exportable chrome snapshots only by request**: if users want the current badge/status/title state preserved, capture it explicitly as a receipt/transcript annotation instead of mixing it into ordinary copy.

References: REF-ITERM2-STATUS-BAR, REF-ITERM2-BADGES, REF-WEZTERM-RIGHT-STATUS, REF-WINDOWS-TERMINAL-TIPS, REF-VSCODE-UPDATE-1106.

## Fresh ideas from the context-handoff pass
- **Attach exact command bundles, not loose paste**: make “share the last failed command” produce a bounded bundle with command text, exact output, exit code, duration, cwd, confidence, witnesses, and receipt refs instead of dumping the whole pane.
- **Collapsed frames should preserve exact reveal**: summary cards or collapsed command sections are great for scanability as long as the exact frame/output/receipt record stays one click away.
- **Share flows should be target-anchor first**: handoff should resolve through exact frame anchors and transcript spans when possible, then degrade visibly to plain text only when that precision is unavailable.

References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1110, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh steals from the repair-gate pass
- **repair bundle, not mystery silence**: when repeated failures quiet a component, make “explain why retries stopped” and “attach the last failure bundle” first-class affordances.
- **clear is a named action**: copy the best historical lesson from SMF and systemd — leaving a failed/repair-required state should be explicit enough that the user knows whether they cleared history, retried once, or actually changed the configuration.
- **successful-run reset should be visible**: if a healthy run resets recent-failure pressure, show that as an explicit state transition rather than letting users think the system forgot its own history magically.

References: REF-SMF-MAINTENANCE, REF-SYSTEMD-UNIT, REF-K8S-POD-LIFECYCLE, REF-ERLANG-OTP-SUPERVISOR.
