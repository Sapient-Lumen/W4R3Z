# Shell + terminal ideas for Steward

## High-value ideas
1. **Command frames / blocks with stable IDs**
   - Treat one command plus its output as an explicit navigable unit.
   - That makes copy, bookmark, replay, receipt attachment, and “share exactly this interaction” much easier.
2. **Prompt / input / output zones**
   - Support semantic zones so the terminal can jump between prompts, copy exact command output, and alert when a command completes.
3. **Working-directory side channel**
   - The shell should report cwd changes explicitly instead of relying on guesswork.
4. **Explicit hyperlinks for receipts and docs**
   - Use terminal hyperlinks for digests, transcript slices, component docs, and error locations so the terminal can be rich without parsing arbitrary prose.
5. **Command receipts**
   - Lifecycle-aware commands should be able to emit a small structured sidecar: component id, action, outcome, digest, duration, maybe a transcript pointer.
6. **Plumbing rules**
   - File paths, URLs, digests, component ids, error locations, and object references should be plumbable to editors, viewers, or Steward introspection tools.
7. **Structured shell values**
   - The shell should preserve typed tables/records where possible and only render late.
8. **Marks, decorations, alerts, and failure tinting**
   - Long-running commands should set marks the terminal can navigate by, and failures should be visible at the command-frame level rather than buried in text.
9. **Recent directories and command history keyed by remote identity**
   - Good terminals remember more than text; they remember which directory and host a command belonged to.
10. **Pane-scoped metadata**
   - Small pane variables like remote host, active component, or last receipt digest can power titles, tooltips, status bars, and safe explicit actions.
11. **Transcript slices**
   - One keystroke should attach the exact input/output/receipt slice for the last command to a bug report or approval request.
12. **Remote-aware semantic transport**
   - Shell integration should survive SSH-like hops rather than being purely local magic.
13. **Glitch-free prompt redraw**
   - Prompt-aware resizing and redraw reduce terminal jank and make rich prompts less fragile.
14. **Inline lifecycle explainers**
   - “Why is this component waiting?”, “why is it quiesced?”, and “what was restarted?” should be answerable inline from receipt/state metadata instead of log archaeology.
15. **Pluggable action chips, not hidden control planes**
   - A digest, component id, or error span can expose explicit actions like “open transcript” or “inspect component”, but only as clear user-invoked operations.
16. **Component + cycle witness chips**
   - If a command starts or inspects a component, the frame can remember the component id and optional runtime-cycle witness so later actions can answer “same run or newer run?” without guesswork.
17. **Stale-action fences for explicit buttons**
   - A visible “stop”, “tail status”, or “explain this wait” affordance can carry the expected cycle witness and fail safely if the component has already restarted.
18. **Trust-marked command frames**
   - Command boundaries should carry a provenance bit or confidence level: explicit shell-reported and nonce-bound is best, scrollback-inferred is second-best, manual selection is fallback.
19. **Lifecycle state/status strip**
   - A pane-local strip or tooltip can show compact Steward state, last receipt, remote identity, and current component without scraping the prompt.
20. **A parseable machine side channel**
   - The shell/terminal stack should have an SSH-friendly, text-oriented observation channel for frame boundaries, pane metadata, notifications, and subscriptions instead of forcing every tool to scrape ANSI output.
21. **Transient service affordances for long-running commands**
   - A shell command like a build, watch, or local server could be promoted explicitly into a transient Steward-tracked service with status, logs, and receipts.
22. **Explicit input semantics**
   - Bracketed paste, richer keyboard events, and click reporting should be treated as first-class protocol choices, not optional hacks.
23. **Shell-owned marker support**
   - The shell itself should happily emit cwd and prompt markers, including prompt-end markers, so terminal UX does not depend on fragile heuristics.
24. **Predictive local echo with visible provisional state**
   - For remote shells over weak links, the terminal could show immediate local editing feedback while visually marking unconfirmed predictions.
25. **Focus-aware command-finish notifications**
   - When a command frame ends, notify only if the pane is unfocused or the command opted in; this is a tiny semantic hook with big payoff.
26. **Roam/sleep tolerant remote sessions**
   - A future remote shell transport could survive IP changes, laptop sleep, and short outages without treating that as magical continuity of the remote workload.
27. **Command-frame to transient-object bridge**
   - A completed shell action should be able to say “this became transient object X” so status and explain UX stay connected to the originating frame.
28. **Latency-aware prompt interaction**
   - Prompt-local click-to-move, safer cursor navigation, and minimal round trips for line editing can make the shell feel local even when it is not.
29. **Semantic fences across hops and multiplexers**
   - SSH, tmux-like layers, shell restarts, or trust downgrades should be able to leave explicit fences in frame metadata so the terminal can say “precision changed here” instead of pretending nothing happened.
30. **Per-frame finish notifications with receipt provenance**
   - Long-running commands should be able to notify on completion using explicit frame boundaries and optional receipt/cycle data, not guessed output endings.
31. **Compact end-of-cycle badges**
   - A frame or pane strip can show “requested stop”, “clean exit”, “signal/crash”, “timeout”, or “policy/resource kill” when Steward knows it, giving users fast context without sending them to logs first.
32. **Synchronized rendering hints for frame redraws**
   - When a terminal supports DECSET 2026 or equivalent batching, command-frame redraws, prompt refreshes, and status-strip updates can flush atomically and feel much less janky.
33. **Precision fences as first-class UX**
   - Hops, multiplexers, shell restarts, or missing capabilities should leave visible precision fences so the UI can admit “exact command/cwd trust changed here.”
34. **Capability honesty beats TERM folklore**
   - The shell+terminal stack should treat TERM strings and old assumptions as weak hints, then prefer fresh markers and explicit feature reporting before enabling richer affordances.
35. **A tiny feature-reporting handshake**
   - The terminal and shell should be able to exchange a compact view of supported semantics such as prompt markers, cwd refresh, hyperlinks, exact command reporting, keyboard richness, and redraw batching.
36. **Per-hop capability ledgers**
   - Capability knowledge should be scoped to the actual terminal/pane/hop path so nested shells, SSH, and multiplexers can say what they preserved and what they dropped.
37. **Safe-ignore rich semantics**
   - New markers and hints should be chosen so unsupported layers mostly ignore them safely, preserving a usable baseline stream rather than exploding.
38. **Explicit resync affordance**
   - When a layer gets confused, the shell/terminal pair should be able to force a fresh prompt/cwd/capability resync instead of relying on magic recovery.
39. **Hyperlink/open-action rules for Steward objects**
   - Receipts, transcript slices, digests, docs, and file/error locations should be routable through explicit hyperlink/open-action rules instead of prose scraping.
40. **Risk-tiered affordances**
   - Low-confidence data may justify copy/open actions; high-confidence data may justify inspect/explain; only explicitly fenced high-confidence targets should light up stop/restart-like actions.
41. **Semantic epochs for stale-action fences**
   - A prompt/cwd/capability resync, nested shell, or SSH hop should be allowed to mint a new semantic epoch so command frames, palette actions, and subscriptions can admit “that target belonged to an older semantic world.”
42. **Fresh resync beats stale certainty**
   - When the shell or terminal gets confused, it should favor a tiny explicit resync that refreshes prompt boundaries, cwd, capability, and trust rather than preserving half-stale markers forever.
43. **Explicit hop chips and remote path strips**
   - The terminal should be able to show the current semantic path: local pane, tmux-like layer, remote host, and whether cwd/markers were preserved.
44. **Same-host same-directory spawn that respects semantics**
   - New panes, tabs, or windows should be able to inherit remote host and cwd when the current hop path proved them explicitly.
45. **Per-hop history and recent-object memory**
   - Command history, recent directories, and recent Steward objects should be allowed to key off the remote/multiplexer path so unrelated contexts do not bleed together.
46. **Small prompt-critical mode baselines**
   - The shell/terminal pair should keep a tiny explicit baseline for things like prompt markers, cwd freshness, bracketed paste, focus-reporting, and prompt-local cursor shape instead of hoping every program leaves the tty in a good state.
47. **Fresh-prompt reassertion**
   - When the shell regains control, it should be able to restate the current semantic baseline so stale state from `ssh`, tmux-like layers, or TUIs does not linger invisibly.
48. **Light resync versus hard reset**
   - A custom terminal should distinguish “refresh prompt semantics”, “reassert baseline”, and “nuclear terminal reset” instead of collapsing them into one mystery ritual.
49. **Self-healing prompt chrome**
   - Cursor shape, prompt-local click behavior, and shell badges should reappear because the shell restated them, not because the terminal guessed them from whatever text happens to be on screen.

50. **Short-lived exact-target anchors**
   - Command frames, receipts, transcript spans, and concrete runs should be allowed to mint opaque short-lived anchors so affordances can point at the exact thing the user means instead of re-parsing visible text.
51. **Selection-to-anchor promotion**
   - Selecting a command or exact output zone should be promotable to a real anchor-backed object so later copy/share/open/explain actions stay bound to the same concrete slice.
52. **Risk-tiered target binding**
   - Low-risk navigation and copy can tolerate weaker anchors or link-detection fallbacks; inspect/restart/stop-the-same-run should require fresher exact anchors and stale fences.
53. **Anchor-aware notifications and chips**
   - A command-finished toast, tab badge, hyperlink, or palette entry should be able to carry an anchor to the exact frame/receipt/run it refers to rather than only focusing the whole pane.
54. **Safe downgrade to human-usable fallbacks**
   - When an exact anchor cannot cross a hop, copy boundary, or unsupported terminal, the system should degrade to plain text or hyperlink while admitting the precision loss.
55. **Observational chrome separate from transcript**
   - Badges, sticky headers, tab titles, side status cells, and progress chrome should summarize live state without pretending to be part of the canonical command/output transcript.
56. **Copy-safe chrome**
   - Copying text or exporting a transcript should default to the underlying command/output/receipt record, not silently include whatever badge or sticky header happened to be visible.
57. **Sticky headers with exact frame anchors**
   - A sticky command header should carry the exact frame anchor, confidence, and freshness bits so scrolling UX stays honest.
58. **Prompt pollution is fallback, not the goal**
   - Prefer richer chrome surfaces for remote host, cwd summary, active component, and progress when the live path supports them; fall back to prompt text only when necessary.

## Shell-specific opportunities
- make Steward verbs return structured values first and pretty text second;
- let the shell understand component ids, receipt ids, digests, transcript refs, and cycle witnesses as first-class typed atoms;
- offer a tiny “why” verb family so users can ask why something is waiting, restarting, quiesced, or denied without leaving the shell;
- keep a local notebook of the last interesting lifecycle actions, keyed by receipt digest rather than by brittle log positions;
- offer an explicit “promote to transient service” affordance for commands that turn into watches, local servers, or background loops;
- let trusted command-frame metadata make re-run, copy-exact-output, “open transcript for that command”, and “act on the same concrete run” safer and less guessy;
- carry per-host and per-hop command history, cwd, and recent-object memory across terminals;
- let remote-aware shell transports preserve semantic markers, trust levels, and capability ledgers instead of collapsing everything back to raw PTY bytes;
- use synchronized rendering as an optional redraw hint for prompt/frame/status updates instead of making users watch intermediate repaint noise;
- keep a visible “precision fence” model so the shell can admit when a hop, multiplexer, or fallback path downgraded what it knows about cwd, command lines, trust, or capabilities;
- let trusted command-finish signals carry compact end-of-cycle results and receipt pointers when a command launched or inspected a Steward-managed component;
- let frames/receipts surface tiny explicit action chips that stay target-bound, user-invoked, and stale-fenced instead of guessing what the pane “means”;
- use hyperlink/open-action rules to route receipts, digests, transcript refs, and docs to the right local or remote tool without inventing prose parsers;
- let the shell request or refresh a tiny capability handshake so richer UX comes from observed support instead of TERM folklore;
- let the shell/terminal pair mint a fresh semantic epoch after hops, resync, or shell reset so exact actions can stale-fence honestly.
- let the terminal surface current remote host, cwd summary, active component, warning/progress state, and sticky command headers in a separate chrome lane instead of forcing all live context into the prompt or transcript.
- keep transcript export and ordinary copy semantics anchored to the underlying frame/receipt truth, with chrome snapshots only when the user asks for them explicitly.
- let the shell attach compact provenance/confidence/trust metadata to command frames, cwd reports, and explicit targets so richer affordances can stay honest about what they really know.
- let a finished frame upgrade from approximate to exact metadata when the shell later reports a higher-confidence command line, exit status, or receipt link.
- let exact command/output selections promote into short-lived target anchors so later copy/open/explain/act-on-same-run affordances stay bound to the same concrete object instead of whatever text is still visible.
- let prompt-local predictive feedback stay visibly provisional until the remote shell confirms it, so weak-link UX can improve without making tentative state look authoritative.
- let the shell/terminal pair record whether a command-frame field was provisional, later confirmed, revised, or withdrawn.

## Big architectural move
Treat the shell+terminal pair as a first-class Steward client. That means:
- the shell knows when it invoked a lifecycle action;
- the shell can declare trusted command frames and their confidence level;
- the terminal knows where commands and outputs begin/end;
- both can preserve command frames, receipt refs, and explicit action targets as navigable objects;
- both can admit when precision or capability was downgraded by a hop, a multiplexer, or a fallback path;
- both can negotiate a small observed capability view instead of pretending compatibility folklore is the same as exact support;
- both can mint and consume tiny exact-target anchors so receipts, transcript spans, command frames, and concrete runs can survive beyond a single visible text scrape.

## Why this matters
If Steward wants to feel like a real next-generation operating environment, the shell and terminal cannot be an afterthought. They are where users will actually experience the difference between:
- ambient Unix folklore, and
- explicit lifecycle-aware ergonomics.

The opportunity is to make the terminal feel **smarter, safer, and more exact** without turning it into a hidden authority channel.


46. **Visible provisional badges for latency-hiding UX**
   - Predictive local echo, inferred command metadata, or pending finish cues should be able to show a small provisional badge until the shell confirms them.
47. **Commit / revise / withdraw transitions for shell metadata**
   - Exact command lines, exit status, and receipt links should be allowed to upgrade or correct earlier tentative frame metadata instead of pretending the first guess was perfect.
48. **Prompt-local optimism, transcript-level honesty**
   - The shell can feel faster by offering prompt-local feedback early, but the durable transcript should still remember what was tentative versus confirmed.
49. **Low-latency remote editing without false authority**
   - Remote shell transports should explore immediate local editing feel, but stop/restart/explain actions should stay fenced until explicit confirmation arrives.

## Attention and progress ideas worth stealing
- Add a **watch this command** affordance that binds to the current command frame and can later escalate from nothing → badge → bell → toast based on duration, focus state, and user preference.
- Let command-finished and needs-input hints target the frame, not just the pane, so the user can jump straight to the relevant interaction instead of a generic bell.
- When the capability handshake says progress is supported, let long-running tasks publish a tiny tab/taskbar progress ring or indeterminate busy state; otherwise degrade to ordinary status text.
- Keep every attention hint explicitly suppressible by kind, source, or focus state so the smart terminal does not become an annoying terminal.
- Make stale attention visible: if a hop changed, a semantic epoch rolled, or trust dropped, old “job finished” chips should admit they refer to an older semantic world rather than pretending they still apply.

References: REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE, REF-ITERM2-SHELL-INTEGRATION, REF-KITTY-DESKTOP-NOTIFICATIONS, REF-WEZTERM-NOTIFICATION-HANDLING, REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-FEATURE-REPORTING.

## Fresh ideas from the context-handoff pass
- **Attach last failure as evidence, not as paste**: the shell/terminal should be able to hand off a bounded exact bundle for the last failed command—including command line, exact output, exit code, duration, cwd, witnesses, and receipt refs—without exporting unrelated scrollback.
- **Redaction-before-share should be part of the affordance**: before a handoff leaves the local pane, users should be able to drop or mask exact fields such as cwd, host path, or selected output lines without breaking the bundle shape.
- **Collapsed frame summaries should still be anchorable**: a compact summary card is great UX, but it should still point at the exact frame/output/receipt record underneath instead of becoming the only surviving truth.

References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1110, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh ideas from the repair-gate pass
- **attach last failure bundle**: one keystroke should gather the most recent failed command or component cycle with exact output slice, end cause, restart/cooldown state, and any repair-required note instead of asking users to hunt through scrollback.
- **quieted-for-a-reason chrome**: when Steward has stopped retrying, show a tiny freshness-scoped badge like cooling down or repair required, with an exact anchor to recent cycles rather than a mysterious dead prompt.
- **retry with explanation, not blind rerun**: higher-risk “try again” affordances should first show what changed since the repair gate, what witness/run they point at, and whether the action is a true clear, a config revision, or just a plain rerun.

References: REF-VSCODE-UPDATE-1106, REF-ITERM2-COMMAND-SELECTION, REF-K8S-POD-LIFECYCLE, REF-SMF-MAINTENANCE.
