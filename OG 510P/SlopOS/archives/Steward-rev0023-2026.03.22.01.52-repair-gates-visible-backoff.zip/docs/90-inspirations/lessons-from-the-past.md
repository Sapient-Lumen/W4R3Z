# Lessons from the past

These are the lessons Steward probably **must** learn before it hardens its semantics.

## 1. Services supervised by the fabric should stay foreground and accountable
launchd, daemontools, and runit all point to the same operational lesson: if the manager is responsible for lifecycle, the “real service” should not disappear behind daemonizing or double-fork folklore. Steward should not build a portable contract around backgrounding tricks and PID guessing.
References: REF-LAUNCHD-JOBS, REF-DAEMONTOOLS-SUPERVISE, REF-RUNIT-OVERVIEW.

## 2. Activation is powerful, but the stable public face should belong to the manager
systemd and launchd both show the value of manager-owned activation. The lesson to steal is not “inherit everything”; it is that the stable listener/end-point identity can belong to the system and be handed to a fresh instance.
References: REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-SD-LISTEN-FDS, REF-LAUNCHD-JOBS, REF-LAUNCHD-SOCKETS.

## 3. Name-based activation can be safer than path-and-environment folklore
D-Bus system activation is a sharp reminder that a launcher can accept only a validated service name, clear environment state, and keep the privileged helper extremely narrow. Steward should remember that activation identity can be a named object or capability key rather than “run this path with whatever session baggage we inherited.”
References: REF-DBUS-SYSTEM-ACTIVATION.

## 4. Keep supervision smaller than the total service-manager problem
Erlang/OTP, Solaris SMF, s6, daemontools, and runit all make it easier to reason when “keep this thing alive” is not collapsed into every other machine-state concern. That is a strong argument for Steward to keep component supervision narrow and resist becoming a giant dependency/admin/timer language too early.
References: REF-ERLANG-OTP-SUPERVISOR, REF-SOLARIS-SMF-RESTARTER, REF-S6-RC-WHY, REF-DAEMONTOOLS-SUPERVISE, REF-RUNIT-OVERVIEW.

## 5. Readiness is not the same thing as spawn success
s6 explicitly calls out the race between “daemon exec'd” and “service is really ready,” and Kubernetes institutionalized a clean split between startup, readiness, and liveness. Steward should not regress to guessing readiness from process birth.
References: REF-S6-READY, REF-K8S-PROBES.

## 6. Shallow readiness is real and should be named honestly
Historical systems often have a useful but weaker notion of “the control plane is listening” or “the supervisor can accept commands” before the real service can serve work. s6's shallow readiness warning and Dinit's readiness handling both suggest Steward should keep `control-ready` separate from declared-work ready when that distinction matters.
References: REF-S6-SHALLOW-READINESS, REF-S6-READY, REF-DINIT-SERVICE.

## 7. Restart loops need bounded semantics, not vibes
Historical supervisors all grow some response to crash loops: daemontools pauses after immediate failure, launchd warns about respawning too fast, and OTP makes restart intensity and period explicit. Steward should expose bounded restart intent and keep crash-loop handling explainable.
References: REF-DAEMONTOOLS-SUPERVISE, REF-LAUNCHD-JOBS, REF-ERLANG-OTP-SUPERVISOR.

## 8. Status deserves its own compact channel
systemd's notify protocol is useful not only for `READY=1` but also for `STATUS=...`, `STOPPING=1`, and barriers that close attribution races. The lesson is not “copy sd_notify whole”; it is that state/status updates should be compact, explicit, and distinct from log archaeology.
References: REF-SD-NOTIFY.

## 9. Continuity should be bounded escrow, not magical resurrection
systemd's fd store and Fuchsia's idle-stop escrow both point toward a narrow continuity story: preserve exactly what matters, in bounded ways, instead of promising whole-process resurrection semantics.
References: REF-SYSTEMD-FDSTORE, REF-FUCHSIA-IDLE-STOP.

## 10. Persistent state can outlive execution without implying that the component is still “running”
Fuchsia's lifecycle docs make a useful point: component instances may keep isolated persistent state while they are not running. Steward should be able to express continuity and restart-adjacent persistence without implying that execution never really stopped.
References: REF-FUCHSIA-LIFECYCLE.

## 11. Runners and restarters are a useful seam
Fuchsia's runner model and Solaris restarters both demonstrate the value of separating framework-owned lifecycle meaning from how a particular runtime is launched. Steward should keep that seam visible.
References: REF-FUCHSIA-RUNNER, REF-SOLARIS-SMF-RESTARTER.

## 12. Oneshot transitions need accountability too
s6-rc's transition model is a good reminder that one-shot start/stop work should still be reproducible, bounded, and attributable to the lifecycle fabric rather than disappearing as random helper children of whatever happened to invoke them.
References: REF-S6-RC-TRANSITIONS.

## 13. Idleness needs explicit activity boundaries, not wishful heuristics
Apple's XPC transactions and Fuchsia's idle-stop flow both suggest the same lesson: the interesting question is not “is the process alive?” but “is work still in flight, and if not, what narrow state can be escrowed safely?” Steward should learn from explicit begin/end or drain/idle hints instead of pretending CPU quiet or log silence means “safe to stop”.
References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-FUCHSIA-IDLE-STOP.

## 14. Health checks are useful, but they are an adjunct, not the primary portable truth
OpenRC's supervise-daemon shows that periodic health checks and unhealthy hooks can be operationally useful. The cautionary lesson for Steward is to keep such checks as local adapter policy unless and until a narrow portable contract is truly earned.
References: REF-OPENRC-SUPERVISE-DAEMON.

## 15. A user-service manager can be a good source of ideas without becoming the architecture
Dinit is a useful reminder that there is a middle ground between tiny supervise-only suites and giant integrated managers. Its split between manager control readiness and per-service ready notification is especially relevant to Steward's observation vocabulary.
References: REF-DINIT-OVERVIEW, REF-DINIT-SERVICE.

## 16. Transient work can still be accountable work
GNU Shepherd's transient services and systemd-run's transient units show that “run this now” does not have to mean “lose all lifecycle accountability.” Steward should steal the accountability lesson while refusing to inherit a giant transient-unit property language by default.
References: REF-GNU-SHEPHERD-OVERVIEW, REF-GNU-SHEPHERD-TRANSIENT, REF-GNU-SHEPHERD-TRANSIENT-MAKER, REF-SYSTEMD-RUN.

## 17. Parseable side channels beat terminal scraping
tmux control mode demonstrates that a terminal-adjacent tool can expose command output, notifications, flow control, and subscriptions over a simple textual protocol that survives SSH, instead of forcing consumers to reverse-engineer the rendered screen.
References: REF-TMUX-CONTROL-MODE, REF-TMUX-CHANGES.

## 18. Good terminals are semantic, not only textual
WezTerm, kitty, iTerm2, VS Code, Windows Terminal, and Ghostty all demonstrate that prompt marks, cwd reporting, command frames, hyperlinks, and exact output selection materially improve shell UX. The lesson for Steward is to make those semantics explicit while keeping them observational.
References: REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION, REF-ITERM2-SHELL-INTEGRATION, REF-OSC133-SPEC, REF-ITERM2-ESCAPE-CODES, REF-GHOSTTY-SHELL-INTEGRATION.

## 19. Semantic shell markers need provenance, not just syntax
VS Code's shell integration trust model is a sharp lesson: a terminal can distinguish between guessed command boundaries and explicitly reported, nonce-bound command data. Steward should steal the idea that semantic shell markers can have confidence levels and trusted provenance instead of pretending every escape sequence is equally believable.
References: REF-VSCODE-SHELL-TRUST, REF-VSCODE-SHELL-INTEGRATION.

## 20. Fresh prompt metadata matters more than clever stale heuristics
Recent fish shell work and Ghostty's integration posture are a good reminder that shells should proactively report cwd and prompt boundaries on fresh prompts to avoid stale terminal state after nested shells or SSH hops. Steward's shell story should prefer explicit refresh over terminal-side guesswork.
References: REF-FISH-OSC-MARKERS, REF-FISH-TERMINAL-COMPAT, REF-GHOSTTY-SHELL-INTEGRATION.

## 21. Input ambiguity deserves the same respect as output ambiguity
Bracketed paste and enhanced keyboard protocols solve real ambiguity: pasted text is not the same as typed text, and ambiguous escape timings are not a great basis for a modern interactive shell. Steward's custom terminal should steal those lessons early.
References: REF-XTERM-BRACKETED-PASTE, REF-KITTY-KEYBOARD-PROTOCOL.

## 22. Focus-aware notifications are a real quality-of-life feature
Ghostty's command-finish notifications, iTerm2's mark-based alerting, and WezTerm's focus-sensitive notification handling all point to the same lesson: once command boundaries are explicit, the terminal can notify at the right moment and only as loudly as current focus really warrants. Steward should remember that tiny semantic hooks can produce outsized UX wins.
References: REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE, REF-ITERM2-SHELL-INTEGRATION, REF-WEZTERM-NOTIFICATION-HANDLING.


## 23. Users need filtering and suppression, not just more bells
kitty's desktop-notification protocol and Ghostty's command-finish settings both reinforce an operational lesson: once notifications exist, users must be able to filter classes, suppress noise, and decide whether a cue becomes a bell, a toast, or nothing at all. Steward should steal the filtering lesson early rather than inventing one noisy default.
References: REF-KITTY-DESKTOP-NOTIFICATIONS, REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE.

## 24. Progress deserves a tiny capability-scoped hint instead of screen scraping
Windows Terminal's OSC 9;4 progress support and iTerm2's feature-reporting `PROGRESS` bit suggest a useful modern pattern: long-running commands can expose compact progress or indeterminate-busy state in tab/taskbar chrome when the terminal explicitly says it supports it. Steward should keep any progress story small, optional, and capability-gated.
References: REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-FEATURE-REPORTING.

## 25. Remote shell UX can be made resilient without lying about state
Mosh proves that roaming, intermittent connectivity, and predictive local echo can materially improve shell feel without requiring every remote program to be rewritten. Steward should at least explore which parts of that resilience belong in a SlopOS shell/terminal stack.
References: REF-MOSH.

## 26. Snapshot-plus-change subscriptions beat polling and bespoke per-property signals
D-Bus API guidance and tmux's newer control-mode work point at the same lesson: bounded snapshot-plus-change interfaces reduce polling, coalesce better than ad hoc change signals, and remain easier to version than undocumented streams. Steward should prefer a tiny explicit observation-subscription seam over terminal scraping or dozens of one-off watcher hooks.
References: REF-DBUS-API-DESIGN, REF-TMUX-CONTROL-MODE, REF-TMUX-CHANGES.

## 27. Avoid speculative start and filesystem-trigger folklore
launchd's own man page warns that `RunAtLoad` should be avoided because speculative launches hurt boot/login, and it explicitly discourages path-watching keys because filesystem monitoring is race-prone and lossy. Steward should prefer activation, explicit jobs/background seams, and accountable requests over “watch this path and hope”.
References: REF-LAUNCHD-SOCKETS.

## 28. Small terminal extensions age better than “re-imagine the TTY” projects
kitty's protocol-extension design goal is refreshingly modest: add small unobtrusive capabilities, keep the TTY a byte stream, and move the minimum extra logic into the terminal. Steward should steal that restraint for its shell+terminal side channel.
References: REF-KITTY-PROTOCOL-EXTENSIONS.

## 29. Action surfaces are powerful when they stay explicit, local, and user-invoked
kitty's hyperlink open-actions and Ghostty's command-palette direction both suggest a good rule: rich terminal actions are useful, but they should stay explicit affordances over concrete targets, not become silent control semantics hidden in scrollback.
References: REF-KITTY-OPEN-ACTIONS, REF-GHOSTTY-RELEASE-120.

## 30. Stop policy should respect explicit in-flight boundaries, not vibes
launchd's transaction and Pressured Exit semantics are a useful reminder that “safe to stop now” and “currently inactive enough to reclaim” are not the same as a boolean process-alive check. Steward should keep that lesson narrow: explicit activity hints and stale-action fences are healthier than inferred safety from logs or terminal silence.
References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-LAUNCHD-XPC.

## 31. Per-run identity is worth stealing, but keep it opaque
systemd’s invocation identity and journal linkage are a useful reminder that “which concrete run was this?” is a different question from “which component is this?”. Steward should keep that distinction, but without letting it turn back into a portable PID/process-tree contract.
References: REF-SYSTEMD-EXEC, REF-SYSTEMD-SERVICE.

## 32. End-of-cycle cause should be explicit, compact, and humble
Fuchsia’s stop payloads and systemd’s result categories both suggest the same lesson: a lifecycle fabric is healthier when it can say “requested stop”, “clean exit”, “signal/crash”, “timeout/watchdog”, or “resource/policy kill” directly. Steward should steal the compact vocabulary, not a giant universal fault matrix.
References: REF-FUCHSIA-COMPONENT-RUNNER, REF-FUCHSIA-LIFECYCLE, REF-SYSTEMD-SERVICE.

## 33. Shell semantics get better when layer boundaries are admitted instead of hidden
OSC 133 prompt markers, tmux control mode, and VS Code’s nonce-bound command reporting all point the same way: a semantic shell/terminal stack should be willing to say when it knows something exactly, when it knows it approximately, and when a hop or multiplexer degraded precision.
References: REF-OSC133-SPEC, REF-TMUX-CONTROL-MODE, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-SHELL-TRUST.

## 34. Terminal capability names are not the same as terminal truth
The xterm and ncurses documentation are blunt about a long-running problem: many terminals claim xterm compatibility while differing in important behavior, and terminal descriptions sometimes must omit or pessimistically treat capabilities because support is uneven. Steward should learn the cultural lesson: prefer fresh markers, explicit capability use, and visible downgrade over folklore like “TERM says xterm, so it must work.”
References: REF-NCURSES-FAQ, REF-XTERM-FAQ, REF-FISH-TERMINAL-COMPAT.

## 35. Progressive enhancement beats giant mandatory baselines
fish compatibility docs, iTerm2 feature reporting, and kitty's keyboard/protocol work all point in the same direction: optional features can be discovered or ignored safely, and richer semantics should improve the experience without breaking the baseline stream. Steward should steal that approach for shell/terminal evolution.
References: REF-FISH-TERMINAL-COMPAT, REF-FISH-OSC-MARKERS, REF-ITERM2-FEATURE-REPORTING, REF-KITTY-KEYBOARD-PROTOCOL, REF-KITTY-PROTOCOL-EXTENSIONS.

## 36. Capability handshakes should report live support, not desired UX
Modern terminals still live with a messy substrate of nested shells, multiplexers, and partial compatibility. A small explicit feature-reporting or capability-handshake layer is useful precisely because desired affordances such as exact command reporting, hyperlinks, or synchronized redraw are not the same as what the current path has actually proven it can do.
References: REF-ITERM2-FEATURE-REPORTING, REF-FISH-TERMINAL-COMPAT, REF-XTERM-FAQ.

## 37. Atomic redraw hints are worth stealing even when they are not universal
WezTerm's support for synchronized rendering is a nice reminder that not every terminal improvement has to be semantic metadata; reducing redraw tearing during prompt, frame, or status updates can make a shell feel dramatically more solid. Steward should treat this as an optional hint, not as a correctness dependency.
References: REF-WEZTERM-SYNC-RENDER.

## 38. Giant integrated managers accumulate hidden policy
This is the main cautionary lesson from classic service-manager evolution: once timers, readiness, logging, dependencies, sandboxes, environment shaping, socket activation, and admin UX all live in one product contract, it becomes hard to tell which semantics are essential and which are historical accidents. Steward should fight that drift from day 1.

## 39. Fresh resync is better than stale semantic confidence
VS Code's nonce-bound command reporting, iTerm2's live feature reporting, tmux's parseable control path, and Ghostty's command-finish UX all suggest the same lesson: shell semantics are most useful when they can be refreshed explicitly after a hop, restart, or confusion. Steward should prefer a tiny new semantic epoch over quietly carrying forward stale trust.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-SHELL-TRUST, REF-ITERM2-FEATURE-REPORTING, REF-TMUX-CONTROL-MODE, REF-GHOSTTY-CONFIG-REFERENCE.

## 40. Remote-aware shell semantics get much better when hop boundaries are explicit
WezTerm pane/user-var plumbing, kitty's SSH shell-integration path, and Ghostty's recent SSH integration work all point to the same lesson: host/path-aware shell UX improves sharply when remote host, cwd authority, and preserved markers are reported explicitly per path instead of guessed from prompts or ambient session ancestry. Steward should steal the explicit path hints, not a giant remote-control worldview.
References: REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-KITTY-SSH, REF-GHOSTTY-RELEASE-120.

## 41. Good shell UX should grade certainty instead of hiding it
VS Code's shell integration model is unusually clear about a helpful truth: command lines can be low, medium, or high confidence, and only nonce-verified high-confidence reports are safe to treat as trusted for rerun-sensitive UX. Steward should steal that honesty and extend it beyond command text to cwd, remote path hints, and action targets.
References: REF-VSCODE-SHELL-TRUST, REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.


## 42. Latency-hiding UX should stay visibly tentative until confirmation
Mosh is a sharp reminder that predictive local echo and line editing can make remote shells feel dramatically better on weak links, but the deeper lesson for Steward is about honesty: prompt-local optimism is useful only if the system can later confirm, refine, or visibly roll back what was tentative. VS Code's shell execution model points in the same direction by allowing command details to become more accurate later and treating nonce-verified reports differently from weaker observations.
References: REF-MOSH, REF-MOSH-PAPER, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-SHELL-TRUST.


## 43. Exact target anchors beat scraping rendered text
iTerm2 command selection, OSC 8 hyperlinks, kitty open-actions, tmux pane IDs in control mode, and VS Code's link-confidence ordering all reinforce the same lesson: if the user is meant to act on a specific command, output region, file, receipt, or concrete run, Steward should prefer an explicit target anchor over reconstructing intent from whatever text happens to be visible.
References: REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-HYPERLINKS, REF-KITTY-OPEN-ACTIONS, REF-TMUX-CONTROL-MODE, REF-VSCODE-TERMINAL-BASICS.

## 44. Riskier actions deserve stronger anchors than low-risk navigation
History already shows the difference between “open this link” and “run or mutate something over there.” iTerm2 command URLs, VS Code's low-confidence word links, and kitty's configurable open-actions all suggest the same caution: open/copy/reveal can tolerate weaker binding, but rerun/stop/act-on-same-run should demand fresher exact anchors, explicit confirmation, or both.
References: REF-ITERM2-COMMAND-SELECTION, REF-VSCODE-TERMINAL-BASICS, REF-KITTY-OPEN-ACTIONS.


## 45. The best terminal chrome is observational and separate from the durable transcript
iTerm2's status bar and badges, WezTerm's right-status area, Windows Terminal's smart tab titles and progress strings, and VS Code's command decorations/sticky-scroll style overlays all point to the same lesson: live shell context is often best shown in non-transcript chrome. Steward should steal that separation. Let the durable transcript stay command/output/receipt truth, and let chrome be a freshness-scoped summary layer that can clear, resync, or downgrade without rewriting history.
References: REF-ITERM2-STATUS-BAR, REF-ITERM2-BADGES, REF-WEZTERM-RIGHT-STATUS, REF-VSCODE-TERMINAL-BASICS, REF-VSCODE-UPDATE-1106, REF-WINDOWS-TERMINAL-TIPS, REF-WINDOWS-TERMINAL-PROGRESS.

## 46. Terminal modes and prompt semantics need a repair path
xterm's reset behavior, iTerm2's tmux-crash guidance, and Ghostty's explicit reset action all point to the same operational truth: shells and terminal programs leave state behind, and sometimes that state wedges. Steward should not pretend shell semantics are robust if the only repair story is folklore and manual incantation.
References: REF-XTERM-MANPAGE, REF-ITERM2-TMUX-INTEGRATION, REF-GHOSTTY-RESET-ACTION.

## 47. Fresh prompt reassertion beats trusting leftover terminal state
fish reporting cwd on every fresh prompt, and kitty letting shell integration reassert prompt-local cursor shape, reinforce a great small lesson: when the shell regains control, it should restate the semantic baseline it cares about instead of assuming intermediate programs left the terminal in the right mode.
References: REF-FISH-OSC-MARKERS, REF-KITTY-CONF.


## 48. Exact handoff bundles beat whole-scrollback folklore
Modern terminal UX is getting sharply better when users can share *the exact command interaction* rather than pasting random scrollback. VS Code's terminal command attachments now share the command line, captured output, and exit code as explicit context, later versions add compact status details and collapsible command sections, and iTerm2/WezTerm keep reinforcing the value of exact command or output-region selection. Steward should steal the bounded exact handoff idea, not an ambient “share the whole pane” habit.
References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1110, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SHELL-INTEGRATION.

## 49. Repeated failure should quiet visibly before it becomes invisible damage
OTP restart intensity, launchd throttle intervals, systemd start-rate limiting, Kubernetes CrashLoopBackOff, SMF maintenance, and Shepherd respawn limits all point to the same lesson: a lifecycle fabric needs a small, explicit answer to “what happens when this keeps failing?” Steward should steal the visibility, bounded retry, and explicit repair/clear lesson without freezing a giant portable policy grammar too early.
References: REF-ERLANG-OTP-SUPERVISOR, REF-LAUNCHD-SOCKETS, REF-SYSTEMD-SERVICE, REF-SYSTEMD-UNIT, REF-K8S-POD-LIFECYCLE, REF-SMF-MAINTENANCE, REF-GNU-SHEPHERD-MANUAL.
