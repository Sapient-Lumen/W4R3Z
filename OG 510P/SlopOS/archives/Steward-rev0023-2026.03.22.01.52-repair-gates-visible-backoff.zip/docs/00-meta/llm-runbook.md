# LLM runbook

This runbook exists to reduce archive amnesia and premature architecture freeze.

## Non-negotiables
1. **No ambient lifecycle authority**: if Steward controls something, that target and authority should be explicit.
2. **Do not clone systemd by inertia**: cover the responsibility set, but keep the semantics narrow and reviewable.
3. **Readiness is not spawn success**: keep startup, readiness, liveness, and crash distinct.
4. **Activation is supervisor-owned**: do not drift into “process recreates its whole public world however it likes.”
5. **Foreground accountability matters**: supervised services must not disappear behind daemonizing folklore.
6. **Shell and terminal must not smuggle authority through PTY folklore**.
7. **Keep the repo lighter than the parent SlopOS archive until the seams are truly stable**.
8. **Freeze observations before broad mutations when possible**.

## Must-read set (refresh before making changes)
- `README.md`
- `docs/README.md`
- `docs/00-meta/charter.md`
- `docs/00-meta/archive-policy.md`
- `docs/00-meta/trajectory-map.md`
- `docs/00-meta/roadmap.md`
- `docs/00-meta/bibliography.md`
- `docs/00-meta/evidence-index.md`
- `docs/10-threat-model/threat-model.md`
- `docs/20-assurance/claim-registry.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/30-architecture/architecture-overview.md`
- `docs/30-architecture/design-principles-v0.md`
- `docs/30-architecture/non-decisions-v0.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/posture-index.md`
- `docs/30-architecture/component-manifest-schema-v0.md`
- `docs/30-architecture/activation-set-schema-v0.md`
- `docs/30-architecture/supervision-posture-v0.md`
- `docs/30-architecture/activation-posture-v0.md`
- `docs/30-architecture/readiness-posture-v0.md`
- `docs/30-architecture/activity-accounting-posture-v0.md`
- `docs/30-architecture/lifecycle-observation-posture-v0.md`
- `docs/30-architecture/status-channel-posture-v0.md`
- `docs/30-architecture/runtime-cycle-witness-posture-v0.md`
- `docs/30-architecture/termination-cause-posture-v0.md`
- `docs/30-architecture/quiesce-posture-v0.md`
- `docs/30-architecture/shell-terminal-integration-posture-v0.md`
- `docs/30-architecture/command-frame-posture-v0.md`
- `docs/30-architecture/observation-confidence-posture-v0.md`
- `docs/30-architecture/action-surface-posture-v0.md`
- `docs/30-architecture/target-anchor-posture-v0.md`
- `docs/30-architecture/context-handoff-posture-v0.md`
- `docs/30-architecture/attention-hint-posture-v0.md`
- `docs/30-architecture/chrome-lane-posture-v0.md`
- `docs/30-architecture/transient-promotion-posture-v0.md`
- `docs/90-inspirations/lessons-from-the-past.md`
- `docs/90-inspirations/steal-these-ideas.md`
- `docs/90-inspirations/shell-terminal-ideas.md`
- `docs/90-inspirations/slopos-datacube-evaluation.md`

## Editing rules
- Prefer tightening an existing posture doc over creating a new family of docs.
- Keep open questions visible in `trajectory-map.md` and `decision-map.md`.
- If a new external source matters, register a REF and source lock in the same revision.
- Refresh `out/context_pack.md` after changing the top changelog entry.
- Refresh `docs/00-meta/external-source-review-queue.md` with `make source-review-queue` whenever the lock file changes.

## Packaging
- make source-review-queue
- make lint
- make context-pack
- make handoff-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>
