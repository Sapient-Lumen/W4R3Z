# Trajectory map

## Current thesis

Steward should provide the **minimum coherent lifecycle fabric** for SlopOS:
- explicit component roots,
- foreground, accountable lifecycle ownership,
- supervisor-owned activation,
- deterministic restart and stop semantics,
- readiness that is not guessed from spawn success,
- explicit but narrow activity accounting for in-flight work and drain state,
- a small observational lifecycle/state vocabulary,
- bounded observation subscriptions that can carry snapshot-plus-change views without a hidden control bus,
- an optional opaque runtime-cycle witness for correlating concrete runs without PID folklore,
- a compact end-of-cycle cause vocabulary so concrete runs can end with an explicit explanation instead of raw host trivia,
- compact status that is not log archaeology,
- cooperative quiesce,
- shell/terminal integration with semantic boundaries rather than PTY folklore,
- an explicit action-surface posture so shell/terminal affordances stay target-bound and user-invoked,
- explicit precision fences so shell/terminal layers can admit capability or trust downgrade instead of preserving stale certainty,
- an explicit tiny mode-baseline and repair seam so prompt-critical shell/terminal state can be freshly reasserted instead of assumed after crashes, hops, or TUI detours,
- an explicit promotion path for selected long-running shell work that deserves first-class lifecycle accountability,
- explicit capability handshakes so richer shell/terminal semantics come from fresh observed support instead of compatibility folklore,
- explicit semantic epochs so shell/terminal markers, subscriptions, and actions can admit “that belonged to an older semantic world” after a hop or resync,
- explicit shell/terminal hop lineage so remote host, multiplexer, and preserved-semantic context stay scoped to the actual path rather than guessed from a flat PTY,
- compact confidence / provenance / trust annotations so shell/terminal observations can admit exactly how exact and rerun-safe they are,
- explicit provisional-state semantics so predictive local echo and incomplete shell metadata can stay useful without pretending tentative state is already confirmed,
- explicit attention hints so command-finished, needs-input, warning, and progress-like shell/terminal cues can stay focus-aware, freshness-scoped, and non-authoritative,
- an explicit shell/terminal chrome lane so badges, sticky headers, tab titles, and side status cells can stay observational, freshness-scoped, and clearly separate from the canonical transcript,
- explicit target anchors so shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without rendered-text scraping or raw-capability leakage,
- explicit bounded context handoff so exact command frames, output slices, receipts, and concrete runs can be exported or attached without ambient whole-scrollback sharing,
- explicit repair-gate semantics so repeated failures can cool down, become repair-required, and stay explainable instead of hiding behind ambient restart folklore.

The current architecture compression is in [`../30-architecture/design-principles-v0.md`](../30-architecture/design-principles-v0.md).
The current freeze-late refusal set is in [`../30-architecture/non-decisions-v0.md`](../30-architecture/non-decisions-v0.md).

## Open questions (tracked as decision surfaces)
- **OQ-0001 activation allowlist shape**: how much activation-key structure belongs in `CH-COMP v0`, and how much should stay provider-local?
- **OQ-0002 readiness vocabulary**: what is the smallest closed set of startup/control-ready/readiness/liveness states that remains useful?
- **OQ-0003 dependency planning**: does phase 1 need an offline planner layer, or only local start-order constraints?
- **OQ-0004 continuity escrow**: what kinds of handles or state can legally survive restart, and how are they allowlisted?
- **OQ-0005 quiesce evidence**: what exact transcript/receipt shape should explain “why is this component not taking new work?”
- **OQ-0006 shell/terminal side channel**: what exact semantic markers, command-frame fields, and receipts should exist between shell and terminal?
- **OQ-0007 admin surface**: what external control surface, if any, is needed before phase 1 is real?
- **OQ-0008 compat membrane**: how much host init/service-manager behavior can live behind a compat membrane without leaking into Steward semantics?
- **OQ-0009 service package shape**: does Steward benefit from a minimal service-as-directory / bundle discipline, or should packaging stay entirely outside the portable contract?
- **OQ-0010 restart-loop posture**: how much restart-budget / cooldown vocabulary is phase-1-portable, and how much should remain implementation policy?
- **OQ-0011 status channel**: what compact state/status vocabulary should components report beyond ready/not-ready without recreating a giant ad hoc logging protocol?
- **OQ-0012 idle / transaction semantics**: which kinds of components deserve explicit idle or in-flight work accounting, and how much of that belongs in Steward versus runtime-specific adapters?
- **OQ-0013 shell marker provenance**: what minimum provenance or trust model should shell/terminal semantic markers use so rerun/copy/receipt UX stays helpful without becoming spoofable authority?
- **OQ-0014 transient command seam**: when should long-running shell-launched work stay a plain command, and when should it become a first-class transient service or lease-bearing background object?
- **OQ-0015 terminal input protocol**: what minimum keyboard/paste/click reporting should the custom shell+terminal standardize so interactive UX is explicit instead of timing-hack folklore?
- **OQ-0016 resilient remote shell transport**: how much roaming/local-echo/offline tolerance belongs in the shell+terminal contract versus a host-local transport layer?
- **OQ-0017 runtime-cycle witness**: what is the smallest portable cycle-identity/fence shape that helps avoid stale actions without implying a giant process API?
- **OQ-0018 termination-cause vocabulary**: what is the smallest portable end-of-cycle cause vocabulary that remains useful without pretending every runtime exposes the same exit/fault detail?
- **OQ-0019 action surfaces**: what tiny portable descriptor should explicit shell/terminal actions use so they stay user-invoked, target-bound, and stale-fenced across local/remote hops?

- **OQ-0020 observation subscriptions**: what tiny portable snapshot-plus-change subscription shape is worth freezing so terminals and UIs can avoid polling without creating a giant event bus?
- **OQ-0021 precision fences**: what minimum portable vocabulary should say when hops, multiplexers, or fallback paths downgraded cwd/command/trust precision, and how should resync work?
- **OQ-0022 capability handshake**: what is the smallest portable way for shells, terminals, and hop layers to report fresh semantic-feature support without trusting `TERM` folklore or creating a giant negotiation protocol?
- **OQ-0023 semantic epochs**: what is the smallest portable freshness-token shape that lets shell/terminal frames, actions, and subscriptions say “this belonged to an older semantic world” after hops, resync, or shell reset?
- **OQ-0024 hop lineage**: what is the smallest portable remote/multiplexer path hint that helps scope histories, titles, actions, and capability truth to the actual host/path without implying authentication or a giant transport graph?
- **OQ-0025 observation confidence**: what is the smallest portable low/medium/high plus trusted/provenance model that remains useful across shells, hops, and fallback parsers without pretending confidence is the same as authorization?
- **OQ-0026 provisional state**: what is the smallest portable pending/confirmed/revised/withdrawn model that lets shell/terminal UX hide latency without turning prediction into lifecycle truth?
- **OQ-0027 attention hints**: what is the smallest portable command-finished / needs-input / warning / progress hint model that stays user-filterable, focus-aware, and freshness-scoped without becoming a hidden control or notification bus?
- **OQ-0028 target anchors**: what is the smallest portable way to bind shell/terminal affordances to exact frames, receipts, transcript spans, and concrete runs without scraping rendered text or leaking raw capability into copied/exported output?
- **OQ-0029 chrome lane**: what is the smallest portable observational chrome surface for badges, titles, sticky headers, and side status cells, and how should it stay freshness-scoped, copy-safe, and clearly separate from the canonical transcript?
- **OQ-0030 mode baseline**: what is the smallest portable prompt-critical shell/terminal baseline worth naming explicitly, and how should light resync, baseline reassertion, and user-invoked hard reset stay distinct?
- **OQ-0031 context handoff**: what is the smallest portable bounded bundle for “attach/share this exact command interaction” so command text, exact output, exit data, cwd, witnesses, and receipt refs can be handed off without exporting a whole pane or inventing a giant transcript schema?
- **OQ-0032 repair gates**: what is the smallest portable active / cooling-down / repair-required model, and what exact explicit signal should clear or reset a repair gate without sneaking ambient policy in through the side door?

## Recently resolved (keep short)
- **OQ-0000 naming**: the project name is **Steward**.

## Revision 22 focus
Add a narrow context-handoff seam so exact command frames, output slices, receipts, and concrete runs can be exported as bounded evidence bundles rather than scraped scrollback, then tighten the lesson that a great custom shell+terminal should make “share exactly what happened” effortless without turning the terminal into an ambient exfiltration surface.