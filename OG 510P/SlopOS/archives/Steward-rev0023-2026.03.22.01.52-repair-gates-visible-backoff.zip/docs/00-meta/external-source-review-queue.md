# External source review queue

Generated from `external-source-locks.json`.

| reference ID | Retrieved | Review by | Reason |
| --- | --- | --- | --- |
| REF-SYSTEMD-SOCKET-ACTIVATION | 2026-03-21 | 2026-06-21 | socket activation semantics |
| REF-SYSTEMD-SD-LISTEN-FDS | 2026-03-21 | 2026-06-21 | listener handoff |
| REF-SYSTEMD-FDSTORE | 2026-03-21 | 2026-06-21 | bounded continuity-store precedent |
| REF-SYSTEMD-EXEC | 2026-03-21 | 2026-06-21 | per-runtime-cycle invocation identity and execution environment |
| REF-SD-NOTIFY | 2026-03-21 | 2026-06-21 | ready/status/stopping plus barrier semantics |
| REF-LAUNCHD-JOBS | 2026-03-21 | 2026-09-21 | launchd job lifecycle and no-daemonize lesson |
| REF-LAUNCHD-SOCKETS | 2026-03-21 | 2026-09-21 | socket activation, Pressured Exit, and cautions about RunAtLoad/WatchPaths/KeepAlive folklore |
| REF-LAUNCHD-XPC | 2026-03-21 | 2026-09-21 | activation and IPC adjacency |
| REF-XPC-TRANSACTION-BEGIN | 2026-03-21 | 2026-09-21 | explicit in-flight transaction hint for idle policy |
| REF-ERLANG-OTP-SUPERVISOR | 2026-03-21 | 2026-09-21 | supervision model and restart intensity |
| REF-SOLARIS-SMF-RESTARTER | 2026-03-21 | 2026-09-21 | restarter pattern |
| REF-FUCHSIA-RUNNER | 2026-03-21 | 2026-06-21 | runner separation |
| REF-FUCHSIA-IDLE-STOP | 2026-03-21 | 2026-06-21 | escrowed idle stop |
| REF-FUCHSIA-LIFECYCLE | 2026-03-21 | 2026-06-21 | major lifecycle states and persistent state across restarts |
| REF-S6-READY | 2026-03-21 | 2026-09-21 | readiness is not spawn success |
| REF-S6-SHALLOW-READINESS | 2026-03-21 | 2026-09-21 | shallow readiness warning and control-plane readiness distinction |
| REF-S6-RC-WHY | 2026-03-21 | 2026-09-21 | service-manager decomposition lesson |
| REF-S6-RC-TRANSITIONS | 2026-03-21 | 2026-09-21 | transition accounting and known-down-state lessons |
| REF-K8S-PROBES | 2026-03-21 | 2026-06-21 | startup/readiness/liveness split |
| REF-DAEMONTOOLS-SUPERVISE | 2026-03-21 | 2026-09-21 | minimal supervision and restart-loop lessons |
| REF-RUNIT-OVERVIEW | 2026-03-21 | 2026-09-21 | small service-supervision precedent |
| REF-DINIT-OVERVIEW | 2026-03-21 | 2026-06-21 | middle-ground service manager and compact scope |
| REF-DINIT-SERVICE | 2026-03-21 | 2026-06-21 | service ready notification and restart limits |
| REF-GNU-SHEPHERD-OVERVIEW | 2026-03-21 | 2026-06-21 | user and system service manager with socket activation and timers |
| REF-GNU-SHEPHERD-TRANSIENT | 2026-03-21 | 2026-06-21 | transient service maker and richer status ideas |
| REF-NUSHELL-PIPELINES | 2026-03-21 | 2026-09-21 | structured shell ideas |
| REF-PLAN9-PLUMBING | 2026-03-21 | 2026-09-21 | message plumbing |
| REF-VSCODE-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | command detection, cwd, navigation, decorations |
| REF-VSCODE-SHELL-TRUST | 2026-03-21 | 2026-06-21 | trusted shell marker provenance and confidence model |
| REF-VSCODE-TERMINAL-BASICS | 2026-03-21 | 2026-06-21 | terminal link priorities and low-confidence word links |
| REF-WINDOWS-TERMINAL-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | prompt/output markers and exact output selection |
| REF-WEZTERM-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | semantic terminal zones and pane vars |
| REF-WEZTERM-PANE-USER-VARS | 2026-03-21 | 2026-06-21 | pane user vars and tmux-passthrough remote metadata |
| REF-WEZTERM-HYPERLINKS | 2026-03-21 | 2026-06-21 | OSC 8 explicit hyperlinks without visible URL text |
| REF-KITTY-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | prompt-aware terminal and remote cwd ideas |
| REF-KITTY-SSH | 2026-03-21 | 2026-06-21 | remote shell integration, same-host same-dir spawn, and remote-aware UX |
| REF-GHOSTTY-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | prompt-aware UX and command output selection |
| REF-ITERM2-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | marks, command history, and recent-directory ideas |
| REF-ITERM2-COMMAND-SELECTION | 2026-03-21 | 2026-06-21 | command-scoped selection, info, bookmarking, and command URLs |
| REF-ITERM2-ESCAPE-CODES | 2026-03-21 | 2026-06-21 | explicit terminal hyperlink precedent |
| REF-OSC133-SPEC | 2026-03-21 | 2026-06-21 | prompt/input/output marker vocabulary |
| REF-WARP-BLOCKS | 2026-03-21 | 2026-06-21 | command-plus-output block idea |
| REF-TMUX-CONTROL-MODE | 2026-03-21 | 2026-06-21 | parseable text protocol with notifications and flow control |
| REF-KITTY-KEYBOARD-PROTOCOL | 2026-03-21 | 2026-06-21 | enhanced key event protocol with broader terminal adoption |
| REF-XTERM-BRACKETED-PASTE | 2026-03-21 | 2026-09-21 | explicit pasted-input delimiting |
| REF-FISH-OSC-MARKERS | 2026-03-21 | 2026-06-21 | OSC 7 cwd reporting, OSC 133 prompt markers, and click-aware prompt input |
| REF-XPC-TRANSACTION-END | 2026-03-21 | 2026-09-21 | explicit end of in-flight transaction hint |
| REF-GNU-SHEPHERD-TRANSIENT-MAKER | 2026-03-21 | 2026-06-21 | manual for transient service maker and background promotion ideas |
| REF-OPENRC-SUPERVISE-DAEMON | 2026-03-21 | 2026-09-21 | healthcheck and restart-adjunct guidance |
| REF-FISH-TERMINAL-COMPAT | 2026-03-21 | 2026-06-21 | OSC 7/133 details, click_events, cmdline_url, and bracketed-paste expectations |
| REF-SYSTEMD-RUN | 2026-03-21 | 2026-06-21 | official transient service/scope unit precedent |
| REF-DBUS-SYSTEM-ACTIVATION | 2026-03-21 | 2026-06-21 | validated-name activation helper and cleared environment lesson |
| REF-MOSH | 2026-03-21 | 2026-06-21 | roaming, intermittent connectivity, and predictive local echo ideas |
| REF-MOSH-PAPER | 2026-03-21 | 2026-06-21 | predictive client-side echo, application-layer framing, and intermittent-connectivity design lessons |
| REF-GHOSTTY-CONFIG-REFERENCE | 2026-03-21 | 2026-06-21 | notify-on-command-finish and prompt-local click interaction ideas |
| REF-SYSTEMD-SERVICE | 2026-03-21 | 2026-06-21 | service result categories and restart outcome semantics |
| REF-FUCHSIA-COMPONENT-RUNNER | 2026-03-21 | 2026-06-21 | OnStop payload and escrow lifecycle details |
| REF-GHOSTTY-RELEASE-130 | 2026-03-21 | 2026-06-21 | command-finished notification ideas |
| REF-KITTY-PROTOCOL-EXTENSIONS | 2026-03-21 | 2026-06-21 | small unobtrusive terminal extension philosophy and extensibility ideas |
| REF-KITTY-OPEN-ACTIONS | 2026-03-21 | 2026-06-21 | hyperlink/open-action routing ideas for explicit terminal affordances |
| REF-GHOSTTY-RELEASE-120 | 2026-03-21 | 2026-06-21 | command palette evolution and terminal action exposure ideas |
| REF-TMUX-CHANGES | 2026-03-21 | 2026-06-21 | control-mode subscription and pause/resume fairness lessons |
| REF-DBUS-API-DESIGN | 2026-03-21 | 2026-06-21 | snapshot-plus-change, PropertiesChanged, ObjectManager, and explicit interface/versioning lessons |
| REF-WEZTERM-SYNC-RENDER | 2026-03-21 | 2026-06-21 | DECSET 2026 synchronized rendering as optional redraw batching hint |
| REF-NCURSES-FAQ | 2026-03-21 | 2026-09-21 | terminal capability mismatch and pessimistic compatibility lessons |
| REF-XTERM-FAQ | 2026-03-21 | 2026-09-21 | TERM=xterm compatibility folklore cautions and terminal-description drift lessons |
| REF-ITERM2-FEATURE-REPORTING | 2026-03-21 | 2026-06-21 | explicit feature reporting as a replacement for TERM folklore |
| REF-KITTY-DESKTOP-NOTIFICATIONS | 2026-03-21 | 2026-06-21 | OSC 99 desktop notification protocol, filtering, and click/close semantics for attention-hint ideas |
| REF-WEZTERM-NOTIFICATION-HANDLING | 2026-03-21 | 2026-06-21 | focus-aware toast notification handling and OSC 9 / 777 examples for attention-hint ideas |
| REF-WINDOWS-TERMINAL-PROGRESS | 2026-03-21 | 2026-09-21 | OSC 9;4 progress ring/taskbar progress support as capability-gated progress hint precedent |
| REF-ITERM2-STATUS-BAR | 2026-03-21 | 2026-06-21 | scriptable observational status-bar components and interactive chrome kept separate from transcript text |
| REF-ITERM2-BADGES | 2026-03-21 | 2026-06-21 | large session badge surface for dynamic observational status via explicit escape sequence |
| REF-WEZTERM-RIGHT-STATUS | 2026-03-21 | 2026-06-21 | right status area in tab bar using pane cwd/hostname, including remote host via OSC 7 |
| REF-WINDOWS-TERMINAL-TIPS | 2026-03-21 | 2026-06-21 | smart tab titles and chrome-oriented shell integration tips separate from transcript output |
| REF-VSCODE-UPDATE-1106 | 2026-03-21 | 2026-06-21 | attach terminal command to chat with command line, captured output, and exit code; hidden terminal reveal UX |
| REF-XTERM-MANPAGE | 2026-03-21 | 2026-06-21 | full reset behavior including bracketed paste and title/pointer mode reset |
| REF-ITERM2-TMUX-INTEGRATION | 2026-03-21 | 2026-06-21 | tmux client crash can require stty sane to restore terminal state |
| REF-GHOSTTY-RESET-ACTION | 2026-03-21 | 2026-06-21 | explicit terminal reset action for broken terminal state |
| REF-KITTY-CONF | 2026-03-21 | 2026-06-21 | shell integration can set prompt-local cursor shape and config can disable that |
| REF-VSCODE-UPDATE-1107 | 2026-03-21 | 2026-06-21 | command status details in chat terminals, including start time, duration, and exit code |
| REF-VSCODE-UPDATE-1110 | 2026-03-21 | 2026-06-21 | collapsible terminal command sections for scanable exact command/output review |
| REF-SYSTEMD-UNIT | 2026-03-22 | 2026-06-22 | failed-state reset and start-rate-limit context |
| REF-K8S-POD-LIFECYCLE | 2026-03-22 | 2026-06-22 | CrashLoopBackOff backoff and reset-after-success lesson |
| REF-SMF-MAINTENANCE | 2026-03-22 | 2026-09-22 | maintenance state and explicit clear/repair semantics |
| REF-GNU-SHEPHERD-MANUAL | 2026-03-22 | 2026-06-22 | respawn limits, delays, and service status history |
