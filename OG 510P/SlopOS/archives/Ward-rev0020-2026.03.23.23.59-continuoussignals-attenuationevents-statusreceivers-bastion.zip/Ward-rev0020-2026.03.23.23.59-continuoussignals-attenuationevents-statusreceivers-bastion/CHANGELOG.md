## rev0020 — continuous signals, attenuation events, and status receivers
- added pass XX research synthesis and pass XX datacube evaluation;
- added specimen flow 17 around continuous signals, attenuation events, and status receivers;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0020 — root epochs, threshold resets, and delegation freezes
- added pass XIX research synthesis and pass XIX datacube evaluation;
- added specimen flow 16 around root epochs, threshold resets, and delegation freezes;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0019 — selective proofs, unlinkability, and status braids
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 15 around selective proofs, unlinkability, and status braids;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0019 — event streams, subject braids, and incident watches
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 14 around event streams, subject braids, and incident watches;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0016 — status carriers, suspension rails, and refresh notices
- added pass XVI research synthesis and pass XVI datacube evaluation;
- added specimen flow 13 around status carriers, suspension rails, and refresh notices;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0015 — state anchors, fork alarms, and successor audits
- added pass XV research synthesis and pass XV datacube evaluation;
- added specimen flow 12 around state anchor fork alarm and successor audit;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0014 — receipt distrust, bundle half-life, and watch duty
- added pass XIV research synthesis and pass XIV datacube evaluation;
- added specimen flow 11 around receipt distrust, bundle half-life, and watch duty;
- refreshed ledgers, context pack, manifests, and archive index for the new release.

# Changelog

## rev0013 — 2026-03-23
- continued online research with a stronger focus on receipt half-life, history watches, and quarantine-braid hygiene
- added a pass XII datacube evaluation, a pass XII research synthesis, and a ninth specimen selected to preserve optionality
- refreshed lessons, inspirations, ledgers, manifests, and context surfaces; then reran repo hygiene checks

## rev0011 — 2026-03-23
- continued online research with a stronger focus on history braids, receipt skepticism, and quarantine-gate hygiene;
- added a pass XI datacube evaluation, a pass XI research synthesis, and an eighth specimen selected to preserve optionality;
- refreshed lessons, inspirations, queues, manifests, and context surfaces; cleaned duplicate sections from prior passes; and reran repo hygiene checks.

## rev0008 — 2026-03-23
- continued online research with a stronger focus on transparency receipts, accountable key history, and the difference between public-facing admission and high-risk spend;
- added a pass VIII datacube evaluation, a pass VIII research synthesis, and a fifth specimen selected to preserve optionality;
- refreshed lessons, queues, manifests, and context surfaces; repaired duplicate lesson sections; and reran repo hygiene checks.

## rev0007 — 2026-03-23
- continued online research with a stronger focus on threshold roots, provenance witness material, and the difference between verification and local admission;
- added a pass VII datacube evaluation, a pass VII research synthesis, and a fourth specimen selected to preserve optionality;
- repaired changelog drift, refreshed queues/ledgers/manifests, and reran repo hygiene checks.

## rev0006 — 2026-03-23
- continued online research with a stronger focus on lessons from cross-device flows, dynamic routing, session hardening, capability routing, restore-time humility, and explicit rebound/reacquire patterns;
- added a pass VI datacube evaluation, a pass VI research synthesis, and a third specimen selected to preserve optionality;
- cleaned registry/ledger identifiers, refreshed bibliography and release metadata, and reran repo hygiene checks.

## rev0005 — 2026-03-23
- continued online research with a stronger focus on lessons worth stealing from mature ecosystems and current standards;
- added a pass V datacube evaluation, a pass V research synthesis, and a second specimen selected to preserve optionality;
- refreshed repo/process surfaces, queues, ledgers, bibliography, and release metadata while keeping the cube embryonic.

## rev0004 — 2026-03-23
- continued online research with a focus on anti-lessons, specimen flows, and option-preserving architecture moves;
- added a pass IV datacube evaluation plus a new research synthesis and a first concrete specimen document;
- refreshed lessons, inspiration, queues, ledgers, bibliography, and repo hygiene/process surfaces.

## rev0003 — 2026-03-23
- continued online research and a deeper readthrough of SlopOS plus companion cubes;
- added a lessons-from-the-past file, a datacube evaluation pass, and promotion gates/specimen tests;
- added followthrough/irreversible-decision hygiene surfaces and a runnable repo check.

## rev0002 — 2026-03-23
- deepened the founding embryo after reading the current cube ecology and official outside sources;
- sharpened the cube’s internal separations and neighbor boundaries;
- added roadmap, trajectory, ledgers, ADRs, and expanded architecture notes.
