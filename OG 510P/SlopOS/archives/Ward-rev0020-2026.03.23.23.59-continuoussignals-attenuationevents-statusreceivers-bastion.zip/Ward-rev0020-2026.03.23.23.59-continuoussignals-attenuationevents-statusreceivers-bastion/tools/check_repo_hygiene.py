#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    'README.md',
    'START_HERE.md',
    'ARCHIVE_INDEX.md',
    'RELEASE-MANIFEST.json',
    'REVISION-RECEIPT.json',
    'SURFACE-STATUS.json',
    'QUESTION-REGISTRY.json',
    'ASSUMPTION-LEDGER.json',
    'FOREIGN-PRESSURE-LEDGER.json',
    'FOLLOWTHROUGH-QUEUE.json',
    'IRREVERSIBLE-DECISION-LEDGER.json',
    'docs/00-meta/charter.md',
    'docs/00-meta/roadmap.md',
    'docs/30-architecture/architecture-overview.md',
    'docs/90-inspirations/steal-these-ideas.md',
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    print('Missing required surfaces:')
    for m in missing:
        print(' -', m)
    sys.exit(1)
actual = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '.git' not in p.parts)
index = (ROOT / 'ARCHIVE_INDEX.md').read_text(errors='ignore').splitlines()
listed = sorted(line.split('`')[1] for line in index if line.strip().startswith('- `') and '`' in line)
if actual != listed:
    print('Archive index drift detected.')
    only_actual = [p for p in actual if p not in listed]
    only_listed = [p for p in listed if p not in actual]
    if only_actual:
        print('Unlisted files:')
        for p in only_actual:
            print(' -', p)
    if only_listed:
        print('Missing on disk:')
        for p in only_listed:
            print(' -', p)
    sys.exit(1)
print('Repo hygiene check passed for', ROOT.name)
