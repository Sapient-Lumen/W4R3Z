# Tools

This embryo now ships with a minimal hygiene checker.
Run `make check` to verify that required surfaces exist and that `ARCHIVE_INDEX.md`
matches the actual file set.

Keep automation tiny until the object model settles.
