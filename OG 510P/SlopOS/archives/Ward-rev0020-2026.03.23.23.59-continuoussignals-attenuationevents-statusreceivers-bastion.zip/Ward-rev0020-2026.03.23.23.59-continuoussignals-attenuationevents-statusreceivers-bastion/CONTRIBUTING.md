# Contributing

Keep additions small and typed.
Prefer strengthening one existing distinction over inventing a new umbrella abstraction.
New documents should usually justify themselves as a decision surface, a registry, a specimen proof cut, or a hygiene/process surface.
Before adding a new permanent noun, ask whether it can survive at least one specimen test without borrowing hidden truth from a sibling cube.
