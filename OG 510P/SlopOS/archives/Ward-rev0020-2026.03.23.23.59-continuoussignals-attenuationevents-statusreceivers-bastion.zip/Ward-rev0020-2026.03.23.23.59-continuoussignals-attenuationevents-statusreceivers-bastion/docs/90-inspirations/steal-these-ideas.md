# Steal these ideas

## From outside systems
- WebAuthn: scoped credentials, user consent, and separate backup-eligibility / backup-state facts.
- RATS: evidence, endorsements, appraisal, and results are different roles for a reason.
- TUF: threshold roots, delegations, and expiry keep ultimate trust away from one convenient online key.
- SLSA provenance: build claims are valuable witness material without becoming automatic approval.
- DBSC: session hardening deserves its own lane rather than quietly impersonating identity.
- SCITT: transparency receipts create accountability without promising honesty.
- Key Transparency: accountable key history and stability are useful trust inputs without becoming trust verdicts.
- Sigstore keyless signing: short-lived identity-backed witness flows can be convenient and strong without replacing local approval.

## From sibling cubes
- Harbor: callback or route success should remain weaker than durable spend.
- Helm: trust consequences should have inspectable user-facing surfaces.
- Schell: operational convenience channels often need explicit adoption.
- ViewFS: imported material and locally admitted material are different strengths.
- Foundry: runtime evidence remains smaller than local verdict.

## New steals for rev0008
1. **Stability card** — a compact witness about how steady an account→key relation has been.
2. **Receipt pack** — grouped transparency/provenance/verification receipts without fake completeness.
3. **Admission profile ladder** — different local profiles for public-facing acceptance and high-risk spend.
4. **History witness** — accountable history kept smaller than verdict.
5. **Spend profile** — a policy object that explains what must be true before consequence becomes spendable.
## New steals for rev0011
1. **Receipt skepticism** — verification receipts stay smaller than spend approval.
2. **History braid** — compact linkage among current binding, prior binding history, and watch pointers.
3. **Quarantine gate** — preserve earlier verification history while blocking present spend.
4. **Watch duty** — explicit ownership that someone must keep monitoring after first admission.
5. **Invalidity horizon** — the earliest point from which later compromise should change consequence.

## New steals for rev0013
1. **Receipt half-life** — how long a bundle may straightforwardly support spend before recheck is expected.
2. **History watch** — explicit ongoing monitoring duty after first admission.
3. **Quarantine braid** — linkage among earlier verification, later suspicion, and current narrowed consequence.
4. **Re-anchoring prompt** — a small card saying stronger witness material or fresher receipts are now required.
5. **Watch handoff** — make the owner of post-admission monitoring visible.


- **state watch** — explicit record of how much continuity the client still remembers.
- **auditor lag card** — how fresh the outside witness must remain.
- **successor root card** — continuity object for a new epoch that does not erase rollover risk.

## New steals for rev0014
- **receipt distrust notice** — later skepticism without historical erasure.
- **bundle half-life** — a visible age class for grouped verification material.
- **watch duty** — explicit ownership for later recheck and drift monitoring.
- **successor skepticism card** — continuity that remains weaker than final approval.
- **quarantine without amnesia** — narrow spend while preserving earlier truth.

## New steals for rev0015
- **state anchor** — a local continuity memory for what was last checked or accepted.
- **fork alarm** — a narrow warning that history or monitoring continuity is no longer comfortably linear.
- **successor audit** — explicit work required before a rolled-forward service can influence spend again.
- **witness carry-forward** — keep historical residue available without treating it as present approval.
- **continuity weaker than freshness** — a standing anti-regrowth rule.

## New steals for rev0016
- **status carrier** — grouped status material that stays smaller than final spend approval.
- **suspension rail** — reversible narrowing distinct from permanent invalidation.
- **refresh notice** — advisory status that says replace this without saying it was false.
- **status authority split** — explicit residue when status governance differs from issuance.
- **privacy-friendly staple** — holder-provided status that still leaves room for fresher local checks.

## New steals for rev0019
- **incident watch** — signed stream of later trust-relevant facts.
- **subject braid** — typed continuity across original bundles, status carriers, and later event streams.
- **local spend hold** — explicit local narrowing triggered by later incident facts.
- **watch lease** — visible ownership and freshness duty for an event stream.
- **fact smaller than command** — a standing anti-regrowth rule.

## New steals for rev0019
- **derived proof** — holder-generated proof smaller than the base witness.
- **unlinkability rail** — explicit note that repeated successful presentations need not be correlatable.
- **disclosure dial** — visible choice about how much of the base witness is revealed.
- **status braid** — continuity across base witness, derived proof, and later status/freshness checks.
- **proof smaller than custody** — a standing anti-regrowth rule.

## Pass XIX additions
- **root epoch** — durable label for trusted root lineage.
- **delegation freeze** — local hold for withdrawn delegated trust.
- **recovery lane** — explicit out-of-band path after threshold compromise.


## Pass XX additions
- **attenuation event** — signed status update that narrows or revisits local consequence.
- **receiver stance** — explicit local posture about what a continuous event may do here.
- **subject drift** — residue about ambiguity in subject mapping over time.
- **status receiver** — lane for accepted, queued, quarantined, or ignored trust-change signals.
