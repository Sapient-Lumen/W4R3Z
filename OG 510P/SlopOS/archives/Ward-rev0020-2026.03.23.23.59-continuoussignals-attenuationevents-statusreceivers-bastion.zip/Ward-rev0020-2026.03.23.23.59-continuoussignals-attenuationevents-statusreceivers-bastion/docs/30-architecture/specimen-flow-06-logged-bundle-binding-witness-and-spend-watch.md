# Specimen flow 06 — logged bundle, binding witness, and spend watch

This specimen exists to test whether Ward can use grouped verification material and later monitoring without pretending that accountability history is the same as local approval.

## Scenario
A local system must admit an artifact or account relation for modest use today while preserving a path for higher-risk spend later. It has:
- a grouped verification bundle,
- accountable identity→key binding history,
- and access to later transparency-log events.

## Flow
1. The local verifier receives a **bundle pack** containing the material needed to verify one signed claim or artifact.
2. In parallel, it obtains a **binding witness** about the relevant identity→key relation.
3. Ward performs local appraisal and decides whether the result is:
   - only inspectable,
   - admissible for low-risk use,
   - or eligible to cross a higher spend gate.
4. If admitted, Ward may also assign a **spend watch**:
   - later log events,
   - later binding changes,
   - later revocation or expiry evidence.
5. A later event can raise a **regression alarm** without falsifying the fact that the original verification did happen.

## What this specimen is trying to preserve
- Grouped verification material remains smaller than verdict.
- Binding history remains smaller than approval.
- First verification and later monitoring stay different acts.
- Spend eligibility can differ by profile.
- Drift can change posture without rewriting history.

## Candidate nouns under pressure
- **bundle pack**
- **binding witness**
- **spend watch**
- **regression alarm**
- **watcher duty**

## Kill criteria
Reject these nouns if any of the following happens:
- the bundle pack starts implying approval by itself;
- the binding witness starts implying user intent, custody, or durable account linkage;
- spend watch becomes inseparable from every low-risk admission;
- regression alarm cannot express “watch posture changed” without pretending the past never happened.

## If Ward survives the specimen
If Ward *can* survive it, then pass X has found a promising smaller set:
- grouped verification material smaller than verdict,
- accountable binding history smaller than approval,
- and a distinct watch lane that can tighten or relax spend posture over time.
