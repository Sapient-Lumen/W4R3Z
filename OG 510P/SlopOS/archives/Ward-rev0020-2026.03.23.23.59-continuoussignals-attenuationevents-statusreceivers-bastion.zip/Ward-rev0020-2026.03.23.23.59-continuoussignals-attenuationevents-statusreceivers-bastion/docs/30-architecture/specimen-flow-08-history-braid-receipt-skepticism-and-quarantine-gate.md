# Specimen flow 08 — history braid, receipt skepticism, and quarantine gate

This specimen exists to test whether Ward can preserve successful verification while still making room for later watch duty and later quarantine.

## Scenario
A local system verifies a signed artifact or account-binding event using a grouped verification bundle. It also consults a transparency-backed history view of the relevant key or identity binding. Later, new information suggests compromise or conflicting history.

## Flow
1. Ward gathers a **receipt pack** containing the verification material needed for the initial check.
2. Ward records a **history braid** that links:
   - the current accepted binding or signer,
   - the known prior binding/history view,
   - the pointer to later watch/monitor sources.
3. Local policy may allow initial admission or a limited spend profile based on that material.
4. Ward records an **invalidity horizon** describing the earliest point from which later compromise should start changing consequence if new evidence appears.
5. A later event arrives: a key-history regression, transparency/log issue, compromise disclosure, or other witness that changes posture.
6. Ward enters a **quarantine gate**:
   - earlier verification remains a real historical fact,
   - present spend is blocked or narrowed,
   - review/watch duty becomes explicit.
7. Any later reinstatement must be a new local act; it cannot silently inherit the old spend consequence.

## What this specimen is trying to preserve
- grouped verification material remains smaller than spendable approval;
- history witness remains smaller than verdict;
- later quarantine does not falsify the fact that earlier verification happened;
- watch duty becomes explicit instead of magical background responsibility.

## Candidate nouns under pressure
- **receipt pack**
- **history braid**
- **receipt skepticism**
- **quarantine gate**
- **invalidity horizon**

## Kill criteria
Reject these nouns if any of the following happens:
- receipt packs start impersonating approval;
- history braids collapse into a universal verdict object;
- quarantine gates erase the difference between “was verified” and “is spendable now”;
- Ward starts swallowing Harbor route truth or Foundry runtime evidence semantics.

## If Ward survives the specimen
If Ward *can* survive it, then pass XI has found a promising smaller set:
- one grouped verification object,
- one historical/accountability witness,
- and one typed quarantine posture that can change present consequence without rewriting history.
