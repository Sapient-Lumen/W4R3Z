# Architecture overview

Ward is built around layered trust artifacts.

1. **custody objects** — passkeys, keys, wallets, certificates, secret handles, or similar holders of trust-bearing capability;
2. **claims and evidence** — what authenticators, attesters, issuers, builders, or runtimes assert;
3. **endorsement inputs** — trust roots, reference values, policy inputs, freshness and revocation side material;
4. **local appraisal** — what the local environment concludes now;
5. **spendable consequences** — grants, badges, allow/deny outcomes, narrowed powers, or review warrants minted from appraisal.

Ward’s strength is keeping those five layers visible instead of flattening them into “auth succeeded”.

## rev0003 posture additions
- keep snapshot, callback, and provider success signals visibly weaker than durable local consequence;
- prefer one or two specimen artifacts before inventing family-wide registries;
- track downgrade and freshness as first-class modifiers instead of folding them into a success bit.
