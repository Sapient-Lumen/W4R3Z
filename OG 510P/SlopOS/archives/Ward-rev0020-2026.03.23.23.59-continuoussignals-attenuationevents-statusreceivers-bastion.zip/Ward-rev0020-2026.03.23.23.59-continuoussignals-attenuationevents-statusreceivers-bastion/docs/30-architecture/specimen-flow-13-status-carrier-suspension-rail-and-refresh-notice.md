# Specimen flow 13 — status carrier, suspension rail, and refresh notice

Goal: keep original witness material, later status material, and local spend consequence visibly separate.

## Scenario
A credential or provenance bundle verifies cleanly.
Later, the verifier receives or is shown a separate status list indicating one of several typed statuses.
The status list may come from a different authority than the original issuer.
Local policy narrows consequence differently depending on whether the status says `suspension`, `refresh`, or `revocation`.

## Proposed Ward objects
1. **status carrier**
   - grouped status material smaller than the original witness bundle and smaller than final local verdict;
   - can be holder-provided for privacy without pretending to be ultimate freshness truth.

2. **status authority split**
   - explicit residue when the authority changing status is not the original issuer;
   - keeps that governance fact inspectable instead of burying it in one green/red result.

3. **suspension rail**
   - reversible narrowing posture distinct from permanent invalidation;
   - preserves history while preventing ordinary spend.

4. **refresh notice**
   - advisory residue that says a new credential or witness should be acquired;
   - smaller than revocation and smaller than proof that the original witness was false.

## Why this specimen matters
It pressure-tests whether Ward can remain honest when:
- original verification succeeds,
- later status is privacy-preserving and maybe holder-provided,
- status may be governed by a different authority,
- and local consequence depends on the typed status purpose rather than a universal invalid bit.

## Promotion rule
Do not promote `status carrier`, `suspension rail`, `refresh notice`, or `status authority split` unless they improve:
- one reversible suspension specimen,
- one refresh-without-invalidation specimen,
- and one split-authority status specimen.
