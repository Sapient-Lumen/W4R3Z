# Specimen flow 10 — auditor lag, state watch, and successor root

Goal: keep a once-valid verification history visible while honestly narrowing present trust when local state, auditor recency, or log continuity weakens.

## Scenario
A client verifies a signed statement using:
- a verification bundle,
- a recent third-party auditor signature,
- and local state recording the last secure log point.

Later:
- the client loses some local watch state,
- the latest auditor signature exceeds the acceptable lag,
- and the service rotates to a successor network that endorses earlier receipts.

## Proposed Ward objects
1. **state watch**
   - records how much local continuity the client still retains;
   - can degrade without erasing the earlier successful verification event.

2. **auditor lag card**
   - states whether the newest outside witness is still within the acceptable window.

3. **successor root card**
   - records continuity from an earlier log or network epoch into a new one without pretending the trust root is unchanged.

4. **current spend gate**
   - narrows present consequence until watch state, auditor freshness, or successor auditing becomes adequate again.

## Why this specimen matters
It pressure-tests whether Ward can say:
- “this verified under stronger conditions before,”
- “our current watch position is weaker now,”
- “continuity exists, but present spend is narrower.”

## Promotion rule
Do not promote `state watch`, `auditor lag card`, or `successor root card` unless they improve one key-history specimen, one receipt/transparency specimen, and one attestation/rollover specimen.
