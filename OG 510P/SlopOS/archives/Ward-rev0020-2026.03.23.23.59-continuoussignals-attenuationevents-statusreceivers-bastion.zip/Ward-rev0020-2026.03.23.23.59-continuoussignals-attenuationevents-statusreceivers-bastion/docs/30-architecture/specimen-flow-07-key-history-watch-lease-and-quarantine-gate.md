# Specimen flow 07 — key history, watch lease, and quarantine gate

This specimen exists to test whether Ward can acknowledge later drift without flattening earlier verification into either eternal safety or total erasure.

## Scenario
A local system verifies a signed claim or account relation using a grouped bundle. It also has accountable identity→key history and a hardened session. Later, a binding change or receipt-signing-key compromise is discovered.

## Flow
1. Ward receives a grouped bundle and verifies it successfully for a modest action.
2. Ward records a **history braid** linking:
   - bundle material,
   - relevant identity→key witness history,
   - and the current session-hardening posture.
3. Local appraisal may mint consequence for low-risk use, but also attaches a **watch lease** for higher-risk spend.
4. Later, one of the following happens:
   - an unexpected identity→key change appears,
   - a receipt-signing key is declared compromised,
   - or a weak recovery path reduces confidence.
5. Ward raises a **quarantine gate**. Earlier verification remains historically real, but higher-risk spend is blocked pending fresh witness material or renewed appraisal.
6. Ward may also compute an **invalidity horizon** describing from when later compromise meaningfully affects consequence.

## What this specimen is trying to preserve
- First verification remains a real event.
- Later drift can change spend posture without rewriting history.
- Session hardening remains smaller than custody and spend approval.
- Recovery weakness can matter without destroying all low-risk use.
- Watch duty is explicit instead of implicit folklore.

## Candidate nouns under pressure
- **watch lease**
- **history braid**
- **quarantine gate**
- **invalidity horizon**
- **recovery drag**

## Kill criteria
Reject these nouns if any of the following happens:
- the history braid starts implying approval by itself;
- watch lease becomes mandatory for every harmless action;
- quarantine gate cannot distinguish “historically verified” from “currently spendable”;
- invalidity horizon pretends to know more than the evidence actually supports.

## If Ward survives the specimen
If Ward *can* survive it, then pass X has found a promising smaller set:
- accountable history smaller than approval,
- explicit watch duty smaller than consequence,
- and a quarantine posture that constrains spend without falsifying the past.
