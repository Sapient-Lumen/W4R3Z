# Specimen flow 09 — receipt half-life, history watch, and quarantine braid

Goal: let a clean verification remain real while still allowing later skepticism to narrow present spend.

## Scenario
A local system verifies a signed artifact or credential presentation using:
- a verification bundle,
- one or more transparency receipts,
- binding history material,
- and local spend policy.

Weeks later, a transparency service discloses receipt-signing compromise and a history monitor spots a surprising key transition.

## Proposed Ward objects
1. **verification bundle**
   - grouped material used for the initial successful check;
   - preserved as history even if later spend narrows.

2. **receipt half-life**
   - how long the current verification bundle may support uncomplicated spend before recheck or re-anchoring is expected.

3. **history watch**
   - explicit ongoing observation duty for transparency/binding drift.

4. **quarantine braid**
   - links original successful verification, later compromise/suspicion, and the narrowed present consequence.

## Why this specimen matters
It pressure-tests whether Ward can say:
- “yes, this verified then,”
- “yes, we still know how it verified,”
- “no, that does not currently justify full spend.”

## Promotion rule
Do not promote `receipt half-life`, `history watch`, or `quarantine braid` unless they improve one passkey/session specimen, one provenance/receipt specimen, and one key-history specimen.
