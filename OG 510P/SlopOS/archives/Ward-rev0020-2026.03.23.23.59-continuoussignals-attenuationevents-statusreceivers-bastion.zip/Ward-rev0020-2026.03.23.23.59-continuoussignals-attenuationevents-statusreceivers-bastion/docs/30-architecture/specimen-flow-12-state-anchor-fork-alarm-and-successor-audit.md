# Specimen flow 12 — state anchor, fork alarm, and successor audit

Goal: keep historical verification, continuity memory, and rolled-forward trust distinct.

## Scenario
A local system previously verified a binding or artifact and stored grouped verification material.
Later:
- the client loses or rotates some continuity state,
- a transparency service or key-history service rolls forward to a successor instance,
- and a high-risk operation wants to rely on the earlier history.

## Proposed Ward objects
1. **state anchor**
   - records the local continuity point that future checks build from;
   - makes state loss visible instead of silently retrying from scratch.

2. **fork alarm**
   - records detected inconsistency, lag, or monitoring weakness;
   - narrows spend without erasing historical witness material.

3. **successor audit**
   - records the explicit work needed before a successor service may contribute to local approval;
   - keeps continuity and inheritance visibly different.

4. **witness carry-forward**
   - preserves historically real bundles, receipts, or timestamps even while present approval is blocked.

## Why this specimen matters
It pressure-tests whether Ward can remain honest when:
- earlier verification was real,
- continuity memory is partially missing,
- and a successor service claims to preserve history.

## Promotion rule
Do not promote `state anchor`, `fork alarm`, or `successor audit` unless they improve:
- one key-history specimen,
- one transparency-receipt specimen,
- and one successor-ledger specimen.
