# Specimen flow 16 — root epoch, threshold reset, and delegation freeze

Goal: keep routine trust updates, delegated-role withdrawal, and severe compromise recovery visibly separate.

## Scenario
A local verifier trusts an artifact history through a delegated role under a current root epoch.
A delegated targets role is later withdrawn for one artifact family, which should freeze local spend for that family without abolishing the whole root lineage.
Later, enough root keys are suspected compromised that ordinary rotation is no longer enough and the verifier must wait for an out-of-band trust reset before resuming spend.

## Proposed Ward objects
1. **root epoch**
   - durable label for the currently trusted root lineage;
   - stronger than a single receipt and weaker than timeless trust.

2. **delegation freeze**
   - local hold triggered because a delegated trust lane was removed or distrusted;
   - stronger than a warning and weaker than total history deletion.

3. **threshold reset**
   - recovery object for the case where compromise severity exceeds routine key rotation;
   - stronger than normal refresh and weaker than rebuilding the whole system story.

4. **recovery lane**
   - explicit out-of-band path for re-establishing trust after severe compromise;
   - important because silent background healing would hide too much consequence.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- some trust changes are routine,
- some only freeze a delegated lane,
- and some demand a different class of recovery altogether.

## Promotion rule
Do not promote `root epoch`, `delegation freeze`, `threshold reset`, or `recovery lane` unless they improve:
- one delegated-role withdrawal specimen,
- one sub-threshold compromise specimen,
- and one out-of-band recovery specimen that cannot be mistaken for ordinary verification success.
