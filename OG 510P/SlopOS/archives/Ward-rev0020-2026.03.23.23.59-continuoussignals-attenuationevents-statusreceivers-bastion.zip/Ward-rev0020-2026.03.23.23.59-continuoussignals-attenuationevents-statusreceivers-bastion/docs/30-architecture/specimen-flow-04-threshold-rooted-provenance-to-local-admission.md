# Specimen flow 04 — threshold-rooted provenance to local admission

This specimen exists to test whether Ward can describe software trust material without flattening it into one giant verdict.

## Story

A local system receives an artifact plus trust material:
- delegated metadata rooted in a threshold-capable trust set,
- a provenance attestation describing how the artifact was produced,
- and optional transparency or verification evidence.

The local system wants to decide whether to inspect, admit, install, or release something on the artifact’s behalf.

## Candidate objects

- **custody object** — which local actor holds or refers to the trust roots and policy.
- **threshold root pack** — plural trust roots, delegations, expiry, and quorum requirements.
- **provenance witness card** — a typed statement about how an artifact was produced.
- **verification result** — what checked out cryptographically or structurally.
- **admission gate** — the local policy point where verified material becomes an allowed consequence.
- **spendable consequence** — inspect-only, admit, install, secret-release, or another local outcome.

## Flow

1. Imported trust material enters Ward as an evidence bundle, not as a verdict.
2. Ward verifies:
   - threshold/delegation/expiry expectations for metadata,
   - provenance authenticity and shape,
   - optional transparency or supporting material.
3. Ward records **verification results** without yet claiming local approval.
4. A local **admission gate** evaluates the verified material against policy.
5. Only then does Ward mint a **spendable consequence** such as:
   - inspectable but not admissible,
   - admissible for local use,
   - installable,
   - or eligible to trigger a release in another cube.
6. Downstream cubes consume the spendable consequence, not the raw evidence bundle.

## Anti-collapses this specimen protects

- signed ≠ admitted
- provenance present ≠ safe to spend
- online key ≠ ultimate trust root
- verification result ≠ install approval
- one “verified” badge ≠ every downstream consequence

## What to watch

If Ward cannot describe this specimen without flattening threshold roots, provenance witness material, verification results, and spendable consequence into one trust blob, the cube is still deciding too much too early.
