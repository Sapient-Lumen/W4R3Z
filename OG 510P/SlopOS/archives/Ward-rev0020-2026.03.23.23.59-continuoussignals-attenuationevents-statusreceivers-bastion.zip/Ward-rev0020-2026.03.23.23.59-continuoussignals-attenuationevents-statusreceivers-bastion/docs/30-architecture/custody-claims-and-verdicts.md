# Custody, claims, and verdicts

Ward begins by refusing three common collapses:

- **custody** is not **identity claim**;
- **identity claim** is not **attestation evidence**;
- **evidence** is not **local verdict**.

A user may hold a passkey, a machine may hold an attestation-capable key, and a builder may produce signed provenance.
Those may eventually contribute to a local allow or deny decision, but Ward should make the chain inspectable.

## Low-regret objects
- `CustodyObject`
- `ClaimSet`
- `EvidenceBundle`
- `EndorsementSet`
- `AppraisalRecord`
- `TrustConsequence`

The consequence of a trust decision should be explicit and often narrow: a one-shot grant, a review badge, a policy-waived route, or a spendable approval.
