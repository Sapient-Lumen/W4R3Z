# Specimen flow 01 — scoped credential to local verdict

This is a **specimen**, not a frozen architecture. It exists to stress the emerging Ward vocabulary against a concrete human-facing trust flow.

## Purpose

Test whether Ward can represent a credential and its consequences without collapsing these layers:
- relying-party scope;
- custody / recovery posture;
- account binding;
- session anti-theft material;
- local trust verdict.

## Candidate objects

1. **credential record**
   - scope / relying party;
   - device-bound or sync-capable;
   - backup eligibility;
   - backup state if known;
   - recovery/admin posture if known.

2. **binding note**
   - which local account relation, if any, this credential may establish;
   - whether the relation is proposed, active, suspended, or denied.

3. **session-binding note**
   - optional separate DBSC-like or equivalent anti-theft material;
   - never treated as identity proof by itself.

4. **local appraisal**
   - policy basis;
   - freshness scope;
   - acceptable / unacceptable / review-required.

5. **spendable consequence**
   - allow sign-in;
   - allow stronger action;
   - require extra review;
   - deny;
   - deny but keep credential on file.

## What this specimen refuses to decide yet

- whether passkeys and machine identities share one root object type or merely interoperable sibling types;
- whether backup/recovery posture becomes a reusable family of custody facets across all trust objects;
- whether spendable consequence is one family or several related families.

## Why this specimen matters

If Ward cannot survive this flow without turning everything into one giant trust badge, the cube is not ready for broader registries.
