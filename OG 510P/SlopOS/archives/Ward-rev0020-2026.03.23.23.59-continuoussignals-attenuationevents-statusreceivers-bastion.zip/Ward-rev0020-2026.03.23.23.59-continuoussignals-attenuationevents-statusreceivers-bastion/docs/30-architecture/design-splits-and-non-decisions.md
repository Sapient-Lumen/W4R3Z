# Design splits and non-decisions

## Splits Ward is freezing early
- custody object versus account binding;
- claim or evidence versus endorsement material;
- endorsement input versus local appraisal;
- appraisal result versus spendable consequence;
- recent success versus durable trust state.

## Non-decisions still open
- whether passkeys and non-web credentials should share one custody object shape;
- how much appraisal history should be retained as first-class archive state;
- whether spendable consequences need one shared expiration model or a family of them;
- how much of revocation and freshness checking lives inside Ward versus imported side services;
- whether multi-party endorsement sets deserve their own sub-registry now or later.

## Process non-decisions
- do not create a boundary-family map until at least three recurring seams have earned it;
- do not create a giant registry or schema family until at least two specimen tests need it;
- do not let a convenience integration define the cube’s permanent object model.

## rev0019 pressure note
- original witness material versus later incident streams;
- event statement versus remote command;
- watch ownership versus final local spend consequence.
