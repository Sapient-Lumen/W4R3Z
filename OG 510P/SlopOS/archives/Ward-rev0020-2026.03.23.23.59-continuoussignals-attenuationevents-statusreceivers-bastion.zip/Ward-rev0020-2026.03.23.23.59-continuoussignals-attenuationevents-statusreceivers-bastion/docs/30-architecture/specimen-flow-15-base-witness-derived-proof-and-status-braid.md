# Specimen flow 15 — base witness, derived proof, and status braid

Goal: keep source custody, selective presentment, and later status/freshness visibly separate.

## Scenario
A holder keeps a full credential or other base witness in local custody.
When a verifier asks for only a small subset of facts, the holder generates a selectively disclosed derived proof instead of presenting the entire original witness.
The verifier validates the derived proof and then checks status/freshness through a separate privacy-preserving status channel.
Later presentments can reveal the same fact pattern again without being linkable to the original base signature.

## Proposed Ward objects
1. **derived proof**
   - holder-generated witness smaller than the base credential or base attestation package;
   - stronger than unauthenticated claims and weaker than custody of the whole source witness.

2. **unlinkability rail**
   - explicit reminder that repeated successful presentments need not be correlatable;
   - useful because trust and privacy should not be forced into one tradeoff bucket by default.

3. **disclosure dial**
   - a visible choice about which statements become presentment material;
   - keeps least-disclosure honest rather than folklore.

4. **status braid**
   - typed continuity across source witness, derived proof, and later status/freshness checks;
   - stronger than “it verified once” and weaker than timeless trust.

## Why this specimen matters
It pressure-tests whether Ward can remain honest when:
- the holder owns more witness material than the verifier needs,
- the verifier gets only a smaller derived proof,
- repeated success should not automatically become correlation,
- and status/freshness still deserves a separate check.

## Promotion rule
Do not promote `derived proof`, `unlinkability rail`, `disclosure dial`, or `status braid` unless they improve:
- one minimum-disclosure specimen,
- one repeated-presentment unlinkability specimen,
- and one status/freshness specimen that remains separate from source custody.
