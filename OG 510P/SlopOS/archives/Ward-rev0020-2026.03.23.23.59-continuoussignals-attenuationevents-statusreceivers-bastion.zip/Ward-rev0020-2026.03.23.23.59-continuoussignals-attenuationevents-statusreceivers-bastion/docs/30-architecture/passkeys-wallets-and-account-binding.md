# Passkeys, wallets, and account binding

Ward needs one archive because user credentials and machine credentials are siblings, but not twins.

Useful splits:
- a **passkey** is scoped credential material tied to an RP or equivalent origin domain;
- a **wallet** is a custody and mediation surface that may hold many credentials or key references;
- an **account binding** is a local or provider-side relationship that may be established using one or more credentials;
- a recent **successful login** is not the same as a durable local trust state.

Ward should therefore avoid exporting “logged in” as if that were a universally meaningful trust fact.
Better exports are narrow and typed:
- account-binding evidence,
- credential-present confirmation,
- recent-user-presence witness,
- or a spendable local approval.
