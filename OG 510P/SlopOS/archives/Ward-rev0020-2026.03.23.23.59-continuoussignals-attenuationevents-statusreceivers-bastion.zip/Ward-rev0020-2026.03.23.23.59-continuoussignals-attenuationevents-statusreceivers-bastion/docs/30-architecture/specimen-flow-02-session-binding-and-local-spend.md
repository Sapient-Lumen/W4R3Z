# Specimen flow 02 — session binding to local spend

This specimen is meant to prove that Ward can handle meaningful trust consequence without leaning on a giant identity narrative.

## Flow sketch

### 1. Session-binding material arrives
A browser or platform supplies proof that the current session is bound to a device-held key or browser-managed secret. This may be DBSC-like or platform-local.

Ward records it as **session-binding evidence** only.

### 2. Local appraisal evaluates the evidence
The local system checks:
- expected site / relying-party scope,
- freshness requirements,
- current revocation / rotation era,
- and the allowed consequence class.

The output is an **appraisal result**, not an account identity assertion.

### 3. Ward mints a narrow warrant
If policy allows it, Ward mints a **session-binding warrant** that can be spent only for narrow downstream actions such as:
- continuing an existing session,
- refreshing a short-lived grant,
- or authorizing a bounded operation inside an already-established account relation.

It must not be reusable as:
- proof of identity creation,
- account recovery proof,
- or a general durable credential.

### 4. Downstream consequence is labeled
The local consequence should be one of a small visible set:
- continue session,
- limited refresh,
- hold for stronger proof,
- deny,
- or review required.

## What this specimen is testing
- Can Ward handle meaningful session security without turning sessions into identity?
- Can one vocabulary keep evidence, appraisal, warrant, and downstream spend separate?
- Can the warrant expire or be invalidated on policy-era or revocation-era changes without collapsing the entire local account story?

## Non-decisions preserved
- no universal credential registry;
- no universal trust badge;
- no assumption that session-binding evidence is stronger than all passkey or attestation evidence;
- no forced unification between session security and account recovery.
