# Specimen flow 14 — SET watch stream, subject braid, and local spend hold

Goal: keep prior verification, later incident streams, and local spend consequence visibly separate.

## Scenario
A credential, attestation, or provenance bundle verifies cleanly.
Later, the verifier subscribes to or polls a signed Security Event Token stream about the same subject.
The stream uses typed subject identifiers and can deliver security events asynchronously.
A received event narrows local spend or triggers re-check without pretending to command the relying party.

## Proposed Ward objects
1. **incident watch**
   - a signed stream of later trust-relevant facts about a subject;
   - lives alongside bundles and status carriers without becoming final verdict.

2. **subject braid**
   - typed subject continuity across original witness material, status material, and later SET events;
   - keeps identity continuity visible instead of hiding it in one string field.

3. **local spend hold**
   - explicit local narrowing that pauses or reduces spend after an incident event;
   - preserves prior verification history while refusing to overclaim current safety.

4. **command-vs-fact split**
   - standing reminder that a strong incoming event is still a statement of fact, not a remote command.

## Why this specimen matters
It pressure-tests whether Ward can remain honest when:
- earlier verification succeeded,
- later incident facts arrive asynchronously,
- subject continuity needs typed residue,
- and local action must remain local.

## Promotion rule
Do not promote `incident watch`, `subject braid`, `local spend hold`, or `command-vs-fact split` unless they improve:
- one poll-based watch specimen,
- one push-style stream specimen,
- and one event-driven local narrowing specimen.

