# Promotion gates and specimen tests

Ward should not promote a new durable noun unless it survives at least one specimen flow.

## Promotion gates
1. A proposed object must identify which stronger judgments it refuses to make.
2. It must keep custody, evidence, endorsement, appraisal, and spendable consequence visibly separate.
3. It must survive at least one human credential flow and one machine-evidence flow.
4. It must say whether freshness, backup, sync, or recovery posture materially changes its meaning.

## First specimen tests
- synced-passkey versus device-bound-passkey custody comparison;
- attestation evidence plus endorsement plus local appraisal plus freshness-labeled verdict;
- provenance review where artifact signature, provenance existence, and local admission stay separate;
- device-bound session hardening case that improves theft resistance without pretending to be broad identity proof.
