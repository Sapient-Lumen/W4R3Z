# Specimen flow 11 — receipt distrust, bundle half-life, and watch duty

Goal: keep earlier successful verification visible while still letting later compromise or drift narrow spend.

## Scenario
A local system verifies an artifact or binding using a grouped verification bundle. Later:
- the receipt-signing key is reported compromised,
- the relevant key/binding history develops lag or conflict,
- and policy now requires a fresh review before any high-risk spend.

## Proposed Ward objects
1. **bundle half-life**
   - records when the grouped verification material is becoming operationally weaker, even if it still describes a real earlier event.

2. **receipt distrust notice**
   - says later compromise or service rollover means old receipts should no longer be used blindly for spend.

3. **watch duty**
   - records who or what is responsible for rechecking drift, compromise, lag, or successor roots.

4. **quarantine gate**
   - narrows or blocks spend without erasing that earlier verification happened.

## Why this specimen matters
It pressure-tests whether Ward can remain honest when:
- verification was once real,
- later information narrows its usefulness,
- and the system still needs explicit ownership for rechecking.

## Promotion rule
Do not promote `bundle half-life`, `receipt distrust notice`, or `watch duty` unless they improve:
- one transparency-receipt specimen,
- one key-history specimen,
- and one provenance/session-admission specimen.
