# Specimen flow 05 — transparent key history to local spend profile

This specimen is intentionally narrow. It exists to pressure-test one modern trust-shaped lane without deciding that Ward owns every directory, ledger, or transparency service.

## The situation

A local system needs to decide whether an account or artifact relation is strong enough for:
- basic public-facing admission,
- elevated local approval,
- or high-risk spend.

Outside systems increasingly offer:
- transparent public key history,
- transparency receipts,
- provenance and signing witnesses,
- and session hardening.

Ward should learn from that without collapsing everything into one glowing badge.

## Candidate Ward objects

### 1) History witness (candidate)
A compact statement about account→key history:
- which key is current,
- whether there is accountable history,
- whether the relation appears stable,
- and how fresh the history observation is.

It is still weaker than approval.

### 2) Receipt pack (candidate)
A grouped set of transparency/provenance/verification receipts that:
- improves accountability,
- helps local appraisal,
- does not claim completeness,
- does not force a global reconciliation rule.

### 3) Admission profile (candidate)
A local profile for low-friction public-facing acceptance.
It may allow synced passkeys or weaker history if the product context needs that trade.

### 4) Spend profile (candidate)
A stricter local profile for higher-risk consequence.
It may require a stronger custody facet, fresher challenge, device-bound step-up, or additional quorum.

### 5) Spend gate (candidate)
The point where verified material becomes locally spendable.
Ward already leans in this direction; pass VIII tests whether spend profiles sharpen it.

## Walkthrough

1. The system discovers an account or artifact identity relation.
2. It gathers accountable history:
   - transparency receipt,
   - key history observation,
   - provenance or signature witness,
   - optional session warrant.
3. Ward evaluates those as inputs, not verdicts.
4. Local policy chooses an admission profile:
   - public-facing allow,
   - elevated inspect/review,
   - or high-risk spend profile.
5. If a higher-risk spend is requested, Ward may demand stronger custody or fresher proof.
6. Ward records what happened:
   - witness material observed,
   - profile selected,
   - spend gate result,
   - residual uncertainty.

## The anti-collapse rules

- Logged is not approved.
- Stable is not approved.
- Verified is not automatically spendable.
- Keyless witness material is not the same as a long-lived trust root.
- Public-facing admission policy is not the same as high-risk spend policy.

## Why this specimen matters
If Ward cannot survive this specimen without turning into a generic transparency or identity directory cube, then the candidate nouns are too big.

If Ward *can* survive it, then pass VIII has found a promising smaller set:
- history witness,
- receipt pack,
- admission profile,
- spend profile,
- spend gate.

That is still only a candidate set, but it is far healthier than one universal verdict bit.
