# Research synthesis — 2026-03-23 pass X

This pass focused on a trust failure mode older ecosystems keep repeating: they verify something once, then quietly act as if future drift, later log evidence, or changing bindings no longer matter.

## New lessons from outside systems

### 1) A bundle is useful because it groups verification material, not because it is final approval
Sigstore’s bundle format is explicitly “everything required to verify a signature on an artifact.” Ward should steal the grouping habit: a **bundle pack** can be strong and useful while remaining smaller than local approval to spend.

### 2) Transparency event streams suggest a separate watch duty
Rekor’s event stream exists so consumers can monitor new log entries in real time. Ward should keep **watch duty** separate from **verification act**. A statement can verify cleanly now while still demanding later monitoring for regression, replacement, or key-history change.

### 3) KEYTRANS sharpens the identity→key binding story
The KEYTRANS working group’s goal is verifiability for identity-to-public-key bindings in an authentication service. That is a beautiful Ward lesson: a **binding witness** can be accountable and searchable without automatically becoming a local verdict.

### 4) TUF remains a warning against universalizing the trust shape
The current TUF specification still states that it is not trying to create a universal update system. Ward should steal that humility. It should not rush toward one universal trust object either.

## New lessons from SlopOS and companions

### SlopOS
- `verification-material-discovery-boundary-v0.md` remains the right brace for bundle packs: discovery and grouping stay smaller than verdict.
- `transparency-proof-import-boundary-v0.md` strongly supports watch-duty separation; imported transparency material is useful witness material, not native consequence by itself.
- `account-binding-export-boundary-v0.md` and the wallet/cryptosvc cuts continue to reinforce that identity relation, custody posture, and spend remain different objects.

### Siblings
- Harbor keeps the “one successful turn is not the whole story” warning alive on the route side.
- Foundry mirrors pass X well: package/evidence can verify now while later ground drift still matters.
- Helm wants spend and regression posture to stay visible to people rather than buried in invisible trust folklore.

## Brilliant ideas worth stealing carefully

1. **Bundle pack** — grouped verification material smaller than verdict.
2. **Binding witness** — accountable identity→key history smaller than approval.
3. **Spend watch** — an ongoing monitor posture distinct from first verification.
4. **Regression alarm** — a typed signal that later evidence changes local spend posture.
5. **Watcher duty** — explicit responsibility for ongoing observation after admission.

## Current recommendation
Ward still should not freeze a universal trust verdict.

The safer move is:
- keep grouped verification material, binding history, local appraisal, watch duty, and spend consequence separate;
- use specimen flow 06 to test whether bundle pack, binding witness, and spend watch deserve first-class Ward vocabulary;
- and promote only the nouns that survive both account-binding and artifact-admission style pressure without pretending future drift is irrelevant.
