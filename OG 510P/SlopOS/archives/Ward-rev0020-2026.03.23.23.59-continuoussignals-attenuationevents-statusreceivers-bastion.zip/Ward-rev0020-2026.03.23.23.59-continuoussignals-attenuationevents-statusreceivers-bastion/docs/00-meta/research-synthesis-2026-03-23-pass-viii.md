# Research synthesis — 2026-03-23 pass VIII

This pass focused on another recurring trust failure: public accountability and local approval are both valuable, but systems get in trouble when they are mistaken for the same thing.

## New lessons from outside systems

### 1) Transparency is accountability, not local approval
SCITT keeps teaching a subtle but powerful lesson: signed statements can be made transparent by attaching a receipt showing registration in a transparency service, and that transparency holds issuers accountable rather than magically making them honest. Ward should keep **receipt**, **history**, **appraisal**, and **local consequence** visibly separate.

### 2) Key history is a trust input, not a trust verdict
Key Transparency provides a public, tamper-proof audit log of record changes and lets account owners and senders inspect what keys have been associated with an account and how stable that association has been. Ward should steal the idea of a **stability card** or **history witness** while resisting the urge to treat “stable long enough” as automatic approval.

### 3) Public-facing passkey policy and high-risk spend policy should not collapse
NIST’s syncable-authenticator guidance is a good restraint on overfitting Ward to one elite custody posture. Verifiers may use backup state to restrict synced authenticators, but public-facing applications are cautioned not to make that one flag a universal acceptance gate. Ward should keep **admission profile** and **spend profile** visibly different.

### 4) Keyless witness systems shrink signing burden without replacing local trust
Sigstore’s keyless signing model is useful because it shifts emphasis toward identity tokens, transparency, and verification flows rather than requiring every actor to guard long-lived signing keys. Ward should steal the convenience while keeping keyless witness material smaller than final local spend.

## New lessons from SlopOS and companions

### SlopOS
- `transparency-proof-import-boundary-v0.md` continues to argue that transparency evidence is useful imported material, not a native all-purpose verdict.
- `verification-material-discovery-boundary-v0.md` and `verification-verdict-boundary-v0.md` remain a strong brace against collapsing discovery, verification, and consequence.
- `wallet-posture-v0.md`, `cryptosvc-verification-boundary-v0.md`, and `account-binding-export-boundary-v0.md` still support the pass VIII split between custody, verification, account relation, and spend.
- `provenance-container-selection-boundary-v0.md` remains an excellent reminder that statement selection and reconciliation stay verifier-local.

### Siblings
- Harbor keeps Ward honest by showing how easily route success can overclaim.
- Foundry reinforces that logged or attested runtime material is still smaller than local release or adoption.
- ViewFS remains the object-strength analogy: imported witness material is not the same as locally admitted truth.
- Helm still wants inspectable consequence surfaces instead of magic trust glow.

## Brilliant ideas worth stealing carefully

1. **Stability card** — a compact witness about how long an account→key relation has remained unchanged.
2. **Receipt pack** — transparency, provenance, endorsement, and verification receipts grouped without pretending completeness.
3. **Admission profile ladder** — separate public-facing acceptance, elevated approval, and high-risk spend profiles.
4. **History witness** — a typed object for accountable key or statement history that remains smaller than a verdict.
5. **Spend profile** — a local policy object that explains what extra custody, freshness, or quorum is required before spend.

## Current recommendation
Ward still should not freeze a universal trust verdict.

The safer move is:
- keep history witnesses, transparency receipts, provenance material, threshold roots, session warrants, and spend profiles separate;
- use specimen flow 05 to test whether stability/history deserves first-class Ward vocabulary;
- and only promote the nouns that survive both account-bootstrap and artifact-admission style specimens.
