# Research synthesis — 2026-03-23 pass VI

This pass focused on trust failures that appear when one strong signal is allowed to swallow the others.

## New lessons from outside systems

### 1) Cross-device approval is a trust trap if the relying context is weak
The current OAuth cross-device security work highlights a serious historical lesson: a user can present legitimate credentials or wallet material on one device while the session that gets authorized lives on another, attacker-controlled device. Ward should therefore keep:
- **approval locus**,
- **credential class**,
- **session claimant**,
- **local account relation**, and
- **spendable consequence**
distinct, even when the user experience wants to compress them into “you signed in”.

### 2) Scoped credentials are a feature, not an inconvenience
WebAuthn’s recent text still makes the right move explicit: credentials are created for a relying party, subject to user consent, and can only be used by origins belonging to that relying party. Ward should steal that narrowness as a design habit: trust material is healthier when its scope is crisp.

### 3) Synced and device-bound passkeys tell different custody stories
FIDO’s public passkey guidance continues to be useful because it keeps the synced/device-bound distinction in the open. The lesson is not “pick a winner”; it is “make custody, recovery, portability, and sharing posture inspectable.”

### 4) Session hardening deserves its own lane
DBSC is a powerful reminder that stolen-session resistance is worth doing as an explicit mechanism. But it is a separate thing from identity proof, account recovery, or durable trust consequence. Ward should steal the **session warrant** idea without letting it dominate the whole cube.

### 5) Threshold roots and provenance verification still matter because they refuse one-key myths
TUF keeps role splits, threshold signatures, and expiry visible; SLSA v1.0 sharpens the need for provenance verification instead of mere provenance presence. Ward should continue to refuse the common collapse from “signed by something” to “good enough to spend”.

## New lessons from SlopOS and companions

### SlopOS
- `attestation-boundary-index.md` continues to validate the separation between evidence, endorsements, freshness, identity, and results.
- `wallet-posture-v0.md`, `authagent-provider-role-boundary-v0.md`, and `verification-verdict-boundary-v0.md` collectively suggest that provider role, custody, and local verdict should stay visibly distinct.
- `account-binding-export-boundary-v0.md` keeps reminding Ward that account relation is real but narrower than total trust posture.
- `vault-posture-v0.md` suggests that durable trust consequence may often end in spendable release or session posture rather than a badge.

### Siblings
- Harbor keeps reinforcing that browser success and callback proof are not enough for durable trust.
- ViewFS offers a valuable externalized analogue: provenance-bearing material still needs local admission before it becomes usable truth.
- Foundry keeps runtime evidence and local verdict apart, which is exactly Ward’s job at the trust layer.

## Brilliant ideas worth stealing carefully

1. **Approval locus card** — record where the human approval actually occurred, without pretending that locus alone decides trust.
2. **Session warrant** — a typed object that says “this session is presently hardened against theft in a particular way” without claiming stronger identity or recovery facts.
3. **Recovery ladder** — a visible ladder for synced passkey, device-bound passkey, hardware key, delegated recovery, and emergency override postures.
4. **Spend gate** — a local object that translates verified inputs into a concrete consequence, making the last step inspectable instead of mystical.
5. **Threshold root pack** — keep trust roots plural and expiring instead of letting one successful key narrative flatten the archive.

## Current recommendation
Ward should still avoid a giant trust taxonomy. The next safe pressure test is three specimens:
- scoped credential to local verdict,
- session binding to local spend,
- and cross-device approval that returns only a weak local consequence until rebound or secondary verification happens.

If the same custody, appraisal, and spend nouns survive those three, they deserve promotion.
