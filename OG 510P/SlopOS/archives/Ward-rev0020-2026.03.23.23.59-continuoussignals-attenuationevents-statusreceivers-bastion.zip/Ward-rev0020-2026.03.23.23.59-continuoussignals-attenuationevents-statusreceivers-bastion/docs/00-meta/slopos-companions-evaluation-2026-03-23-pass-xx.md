# SlopOS / companions evaluation — pass XX

This pass re-checks Ward against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps proof, local policy, and later consequence separated.
- **Helm** reminds us that user-facing account/session surfaces are not the same as trust truth.
- **Schell** keeps long-lived workflow status and local adoption gates visible.
- **ViewFS** shows that stable handles and current reachability should not be confused.
- **Steward** keeps retries, countdowns, and followthrough typed rather than magical.

## Ward consequence
Continuous status belongs in Ward, but only as a narrow outer lane for trust change after earlier proof.
The new move is therefore small: add one specimen about attenuation events and receiver stance without deciding a universal streaming trust substrate.

## Still-not-yet decisions
- Whether receiver stance should be a family of policies or a typed residue object.
- Whether subject drift belongs in Ward proper or later becomes shared infrastructure with Harbor.
- Whether continuous status should stay event-shaped or eventually compress behind a calmer “watch” family.
