# LLM runbook

- Re-read charter, trajectory, roadmap, and current architecture docs before making changes.
- Strengthen distinctions first.
- Avoid silently importing sibling or outside terminology as settled product truth.
- Update ledgers when a change alters assumptions, open questions, or outside pressure.
