# Research synthesis — pass XV

This pass keeps Ward narrow and learns one more thing from outside trust systems: **continuity evidence deserves its own local memory, and successor histories deserve skepticism instead of automatic inheritance**.

## Outside lessons
1. **Key Transparency treats client state as a security factor.**  
   State loss weakens what a user or auditor can detect later. Ward should steal that lesson and keep local continuity anchors visible instead of assuming that a fresh online query tells the whole story.

2. **SCITT receipts profiles make successor service continuity auditable but not automatic.**  
   A successor ledger with a distinct identity can preserve service continuity while still requiring explicit auditing and attestation checks. Ward should preserve successor skepticism instead of letting continuity become inheritance.

3. **Sigstore bundles prove that grouped verification residue can survive certificate expiry.**  
   Timestamped, logged verification material remains useful over time, but it still stops short of local approval. Ward should keep that separation intact.

4. **The uploaded cubes still reward explicit ownership of watch duty.**  
   SlopOS repeatedly favors explicit receipts, leases, and evidence anchors; the companion cubes repeatedly keep review, import, and runtime evidence separate from final trust consequence.

## Resulting Ward move
Do not decide yet whether the durable noun is `state anchor`, `fork alarm`, or `successor audit`.
For now, keep all three alive as specimen nouns and demand that they improve:
- one key-history specimen,
- one transparency-receipt specimen,
- and one rolled-forward or successor-ledger specimen.

## Fresh ideas worth stealing
- **state anchor** — a local continuity memory for what was last verified or observed.
- **fork alarm** — a narrow object saying later history is inconsistent, lagged, or no longer safe to spend through blindly.
- **successor audit** — explicit work required before continuity through a rolled-forward service may influence local spend.
- **witness carry-forward** — keep historical residue available without forcing present approval.
