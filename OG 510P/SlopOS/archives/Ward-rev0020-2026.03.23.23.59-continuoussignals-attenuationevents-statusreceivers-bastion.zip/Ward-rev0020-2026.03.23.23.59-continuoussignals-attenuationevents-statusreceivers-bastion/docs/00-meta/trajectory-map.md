# Trajectory map

## Current thesis

Ward should begin as a **small, high-signal companion cube** whose main job is to metabolize a missing class of cross-pressure before it can leak confusion into the rest of the ecology.

## Non-negotiables
1. Ward owns a distinct pressure class and should not merely duplicate a sibling cube.
2. The cube may converse with sibling companions, but its public text stays clean of the sealed primary.
3. Early documents should freeze separations and non-decisions, not pretend a giant implementation stack already exists.
4. Outside examples are teachers, not templates.

## Immediate direction
- tighten the object model,
- keep the strongest distinctions visible,
- export compact artifacts that neighboring cubes could plausibly consume later,
- and grow only the subfamilies that survive repeated pressure.
