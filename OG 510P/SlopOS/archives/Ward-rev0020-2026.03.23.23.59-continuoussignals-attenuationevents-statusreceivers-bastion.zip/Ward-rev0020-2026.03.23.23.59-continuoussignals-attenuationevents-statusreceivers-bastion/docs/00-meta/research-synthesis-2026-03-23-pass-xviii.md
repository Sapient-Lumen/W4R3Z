# Research synthesis — pass XVIII

This pass keeps Ward narrow and learns one more thing from outside trust systems: **a holder can present a smaller, unlinkable proof than the original witness, and Ward should not collapse that proof, the source credential, and later status into one object**.

## Outside lessons
1. **Verifiable Credential Data Integrity 1.0 is about proofs as a layered mechanism, not only signatures on whole documents.**  
   The Recommendation frames proofs as reusable integrity/authenticity material with explicit privacy considerations such as unlinkability and selective disclosure.

2. **The BBS cryptosuite makes the split operational.**  
   A holder can take a BBS-signed credential, selectively disclose only chosen statements, and generate a derived proof that is not linkable to the original signature. Ward should preserve a base-witness / derived-proof distinction instead of assuming the verifier always sees the whole original artifact.

3. **Bitstring Status List keeps status as its own privacy-preserving channel.**  
   Suspension or revocation can be published in a compact, privacy-preserving list. Ward should keep status/freshness distinct from both custody of the original credential and verification of a derived proof.

4. **The uploaded cube ecology wants this restraint.**  
   SlopOS already keeps attestation identity, result, collateral status, and cryptosvc layers separate. Ward can therefore add selective-disclosure and unlinkability pressure without turning one proof into universal trust.

## Resulting Ward move
Do not decide yet whether the durable nouns are `derived proof`, `unlinkability rail`, and `status braid`, or whether one of them later hides behind a smaller presentment family.
For now, keep all three alive as specimen nouns and demand that they improve:
- one minimum-disclosure presentment specimen,
- one repeated-presentment unlinkability specimen,
- and one status/freshness specimen that remains separate from source custody.

## Fresh ideas worth stealing
- **derived proof** — holder-generated witness smaller than the original source.
- **unlinkability rail** — residue showing repeated success need not imply correlatability.
- **disclosure dial** — explicit choice of what to reveal.
- **status braid** — typed continuity across source witness, derived proof, and later freshness/status material.
