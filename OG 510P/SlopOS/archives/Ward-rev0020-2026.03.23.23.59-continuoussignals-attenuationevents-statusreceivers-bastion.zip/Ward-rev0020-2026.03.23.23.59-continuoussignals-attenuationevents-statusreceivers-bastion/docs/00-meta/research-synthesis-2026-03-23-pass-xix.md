# Research synthesis — pass XIX

This pass keeps Ward narrow and learns one more thing from mature trust-update systems: **recovery from compromise needs its own truthful objects, and threshold/root changes should not masquerade as ordinary verification success**.

## Outside lessons
1. **TUF keeps root keys offline for a reason.**  
   The root role delegates trust to the top-level keys, clients ship with trusted root keys, and the root private keys are expected to stay highly protected and offline. Ward should keep root custody visibly different from ordinary evidence or receipts.

2. **Threshold compromise changes the recovery path.**  
   If fewer than a threshold of root keys are compromised, normal rotation can revoke trust in the bad keys. If a threshold is compromised, recovery becomes out-of-band and far more severe. Ward should steal that distinction instead of flattening all key changes into one status event.

3. **Delegation is revocable without abolishing the delegator.**  
   TUF delegated roles can be revoked simply by publishing new metadata that removes the delegation. Ward should keep delegation withdrawal as its own local object class.

4. **SCITT reinforces the need for explicit compromise communication.**  
   When receipt-signing keys are compromised, relying parties may need to ignore receipts and wait for fresh credentials or sequences. Ward should therefore keep compromise horizons separate from ordinary history.

## Resulting Ward move
Do not decide yet whether the durable nouns are `root epoch`, `threshold reset`, `delegation freeze`, and `recovery lane`, or whether one later hides behind a smaller status family.
For now, keep them alive as specimen nouns and demand that they improve:
- one ordinary delegated-role revocation specimen,
- one threshold-not-crossed recovery specimen,
- and one threshold-crossed event that forces an out-of-band reset.

## Fresh ideas worth stealing
- **root epoch** — durable label for the currently trusted root lineage.
- **threshold reset** — compromise recovery that is more serious than routine rotation.
- **delegation freeze** — local spend/adopt hold triggered by delegated-role distrust.
- **recovery lane** — explicit path for out-of-band re-trust rather than silent background healing.
