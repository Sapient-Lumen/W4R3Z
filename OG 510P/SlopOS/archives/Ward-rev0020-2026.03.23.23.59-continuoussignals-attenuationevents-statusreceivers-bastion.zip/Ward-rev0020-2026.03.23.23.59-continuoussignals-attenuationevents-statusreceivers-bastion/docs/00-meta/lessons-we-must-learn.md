# Lessons we must learn

Ward should begin by learning from mistakes that old identity, attestation, and trust systems keep making.

## 1) Possession is not the same as trust
A key, token, certificate, or attestation blob can be real and still not justify the consequence someone wants. Ward must therefore keep custody, evidence, endorsements, local appraisal, and spendable consequence distinct.

## 2) Convenience credentials change the custody story
Passkeys are excellent, but synced passkeys and device-bound credentials do not have the same recovery, portability, or administrative control story. Ward should not flatten them into one “credential object” too early.

## 3) Evidence is not endorsement; endorsement is not verdict
RATS exists partly because prior systems kept muddling who says what and who decides what. Ward should preserve those roles even when the final UX wants a single green badge.

## 4) Provenance presence is not the end of verification
Supply-chain ecosystems repeatedly show that signed metadata and provenance are useful inputs, not self-justifying approval. Ward must keep “provenance exists”, “metadata verified”, and “locally acceptable to use” as different facts.

## 5) Recovery and backup are first-class trust facts
Systems often hide recovery posture until after an incident. Ward should do the opposite: recovery method, sync fabric, device binding, and administrative escape hatches all belong in the custody story.

## 6) Session-binding is not the same as identity or consent
Mechanisms that harden sessions against theft are valuable, but they are not identical to login, identity proof, or broad user intent. Ward should learn from them without letting them swallow the whole cube.

## 7) Backup eligibility and backup state are different facts
WebAuthn’s BE/BS distinction is a superb warning: “could be backed up” and “has been backed up” are not interchangeable. Ward should steal that habit for custody facets more broadly.

## 8) Threshold roles beat one omnipotent signing key
TUF’s role split and threshold signatures are a reminder that trust roots and update/provenance ecosystems get healthier when no single metadata key silently becomes the whole system.

## 9) Freshness is not one universal clock
Challenge-bound attestation freshness, revocation freshness, account-binding age, and supply-chain recency are different time stories. Ward should resist any attempt to collapse them into one generic “fresh” bit.

## rev0005 additions
- Backup eligibility and current backup state are different facts; Ward should never compress them into a vague “synced” bit.
- Threshold roles, metadata expiry, and provenance inputs are strong reminders that trust roots and trust material age differently.
- Session theft resistance is not identity proof; session-binding deserves its own lane and its own warrants.

## rev0007 additions
- Cross-device approval is dangerous because a legitimate credential presentation can still authorize the wrong claimant or session.
- Session theft resistance deserves an explicit lane and a typed warrant instead of being quietly merged into login or identity.
- Recovery posture should be inspectable before spend, not discovered only after an incident.
- Threshold roots and delegations stay valuable because they keep ultimate trust away from online or overly-convenient keys.
- Provenance is a witness about how an artifact was produced; it should not silently become local approval or safe-to-spend status.
- Local admission and spend deserve their own inspectable gate even after evidence, endorsements, provenance, or sessions verify cleanly.

## rev0008 additions
- Transparency receipts and public key history are excellent accountability tools, but logged or stable is still weaker than locally approved to spend.
- Public-facing acceptance posture and high-risk spend posture may need different rules; one global credential policy is often a product smell.
- Keyless identity/provenance systems are most useful when they shrink long-lived signing burden without letting short-lived witness material impersonate final trust.
## rev0011 additions
- Grouped verification receipts are valuable precisely because they remain grouped verification material rather than becoming automatic approval.
- Accountable key/binding history should stay available as witness material without flattening into a final verdict.
- Later quarantine should narrow or block present spend without erasing the reality of earlier successful verification.

## rev0013 additions
- Receipt material can remain historically valid while becoming operationally weaker; Ward should not force a false choice between timeless trust and total erasure.
- Bundled verification residue is healthier when it keeps timestamps, log evidence, and key/binding context grouped but still smaller than local spend.
- Long-lived trust requires explicit watch duty; otherwise every system quietly assumes someone else is monitoring compromise, drift, and invalidation.


- Trust systems fail quietly when client state loss is treated as irrelevant.
- Successor logs or networks can preserve continuity and still deserve fresh skepticism.

## rev0014 additions
- Receipt material can stay historically meaningful while becoming operationally too weak to spend through safely.
- Bundle age, service compromise, and auditor lag are different reasons for later skepticism and should stay visibly distinct.
- Trust systems stay healthier when someone explicitly owns later watch duty instead of assuming the log or verifier solved everything forever.

## rev0015 additions
- Trust systems lose important detection power when client continuity state is treated as disposable.
- Successor logs or services may preserve useful history and still require fresh auditing before local spend.
- Historical witness material can remain meaningful even when current approval is quarantined.

## rev0016 additions
- Status is not one universal invalid bit; suspension, refresh, revocation, and message semantics should stay visibly different.
- The authority that changes status can legitimately differ from the authority that issued the original witness material.
- Holder-provided status improves privacy but still leaves room for local freshness skepticism and watch duty.

## rev0019 additions
- Later trust change often arrives as signed statements of fact about a subject, not as a replacement for the original witness.
- Event delivery posture matters; owning a watch stream is different from receiving a one-off status carrier.
- Remote incidents can justify local narrowing without becoming remote commands.

## rev0019 additions
- A holder can prove less than they know; Ward should preserve source witness, derived proof, and local verdict as different strengths of fact.
- Unlinkable derived proofs are a reminder that later successful verification may intentionally resist correlation with the original credential presentation.
- Privacy-preserving status is still its own layer; selective disclosure should not swallow freshness, suspension, or watch duty.

## Pass XIX addition
- Do not flatten routine key rotation, delegation withdrawal, and severe root compromise into one status shape. Recovery severity matters.

## Pass XX additions
- Trust changes arrive over time; local attenuation needs its own truthful lane.
- Session revocation, credential change, device compliance change, and risk change are neighboring but non-identical events.
- A signed event can be genuine while still mapping ambiguously to local subject state.
- The receiver’s local stance should stay visible instead of masquerading as the transmitter’s will.
