# Charter

        **Mission:** Ward is the companion cube for durable trust material: passkeys, keys, wallets, attestation evidence, endorsements, trust roots, identity bindings, and local verdicts.

        ## North-star sentence
        Ward must let strong trust material exist without making every login, credential, signature, or attestation look like the same kind of truth.

        ## Non-goals
        - becoming a browser detour or callback choreography cube
- collapsing all identity into accounts or all trust into cryptography alone
- treating runtime confinement and trust appraisal as the same problem
- becoming the generic policy engine for every sibling cube


        ## Sibling pressure map
        - **Harbor**: browser detours and callbacks arrive here only after Harbor has made them legible
- **Helm**: shell review surfaces need badges, warrants, and visible trust consequences
- **Schell**: operator flows need narrow trust affordances instead of giant ambient secret folklore
- **ViewFS**: provenance-bearing artifacts and imported material need explicit trust interpretation
- **Foundry**: runtime evidence and foreign-ground measurements need local appraisal without becoming substrate truth
