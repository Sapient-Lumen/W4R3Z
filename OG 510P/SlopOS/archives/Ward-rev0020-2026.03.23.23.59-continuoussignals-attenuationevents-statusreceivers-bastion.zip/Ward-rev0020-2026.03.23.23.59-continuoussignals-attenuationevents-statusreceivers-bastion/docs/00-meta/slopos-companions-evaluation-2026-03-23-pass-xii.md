# SlopOS and companion evaluation — pass XII

The current archives keep teaching that “verified” is smaller than “admitted”, and “admitted” is smaller than “spendable under all later conditions”.

## What the current archives are teaching Ward
- SlopOS's attestation family and auth/export cuts keep evidence, identity, result, login state, and account binding distinct. Ward should continue absorbing that discipline instead of smoothing it away for nicer badges.
- Helm and Steward both reward typed consequences and explicit aftermath. That pressure supports Ward's refusal to let receipt presence or session hardening impersonate durable local spend.
- Foundry exports runtime evidence and foreign-ground measurements as smaller-than-verdict material, which is exactly the shape Ward needs.

## Most useful pressure for the next pass
Ward should pressure-test whether **receipt half-life** and **history watch** deserve first-class objects or should remain annotations on bundles and quarantine gates.
