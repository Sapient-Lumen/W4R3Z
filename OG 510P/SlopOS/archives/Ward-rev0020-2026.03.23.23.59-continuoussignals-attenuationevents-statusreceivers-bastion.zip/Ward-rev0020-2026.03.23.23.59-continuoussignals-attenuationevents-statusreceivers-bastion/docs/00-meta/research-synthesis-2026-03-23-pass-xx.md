# Research synthesis — pass XX

This pass keeps Ward narrow and learns one more thing from mature status-sharing systems: **revocation is only one kind of trust change, and receivers need a truthful lane for attenuating local consequence as new status arrives over time**.

## Outside lessons
1. **SSF 1.0 is explicitly a framework for signals and events between cooperating peers.**  
   It profiles SETs, subject principals, subject claims, and transmitter configuration metadata. Ward should steal the idea that ongoing status-sharing has its own surfaces instead of hiding inside one final verdict.

2. **CAEP 1.0 makes attenuation the core verb.**  
   CAEP says transmitters may send continuous updates so receivers can attenuate access for shared users, devices, sessions, and applications. Its event family includes session revocation, token-claims change, credential change, assurance-level change, device-compliance change, session establishment/presentation, and risk-level change.

3. **RISC 1.0 keeps incident facts concrete.**  
   It defines events such as account disabled/enabled, credential compromise, recovery activated, recovery information changed, and sessions revoked. Ward should therefore preserve incident facts separately from local receiver action.

4. **The uploaded cube ecology wants post-verification honesty.**  
   SlopOS and the sibling cubes repeatedly preserve aftermath and followthrough as first-class truths. Ward can therefore add continuous status lanes without collapsing them into timeless trust or remote control.

## Resulting Ward move
Do not decide yet whether the durable nouns are `attenuation event`, `receiver stance`, `subject drift`, and `status receiver`, or whether one later compresses behind a smaller continuous-status family.
For now, keep them alive as specimen nouns and demand that they improve:
- one session-revoked narrowing,
- one device-compliance or assurance change,
- and one ambiguous subject-mapping case that must quarantine instead of silently over-applying.

## Fresh ideas worth stealing
- **attenuation event** — signed status update that asks for local narrowing rather than total replacement of trust.
- **receiver stance** — explicit local posture about what the event can change here.
- **subject drift** — residue about mismatch between transmitted subject and local subject state.
- **status receiver** — a durable lane for queued, applied, quarantined, or ignored continuous signals.
