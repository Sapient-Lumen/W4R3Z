# SlopOS and companions evaluation — pass XVIII

This pass keeps Ward aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** already keeps attestation results, identity export, authorization-context export, and local-auth status surfaces separate. That strongly supports treating event streams as a distinct Ward layer instead of hiding them inside one generic trust status.
- **SlopOS** also keeps cryptosvc and attestation boundary families enumerable, which argues for typed subject/event residue rather than folklore.
- **Helm** still wants inspectable trust surfaces, which means incident material should be legible without automatically becoming spend.
- **Schell** still wants adoption gates and live-checkout truth; later event streams are therefore operationally relevant, not only archival.
- **ViewFS** keeps delta truth and apply ladders explicit, which argues for preserving later trust change as typed watch material.
- **Steward** still benefits from typed aftermath and followthrough, which makes event watch ownership a real sibling concern rather than a hidden timer.

## Pressure on Ward
Ward should not decide yet whether event streams belong inside status carriers, witness bundles, or a separate small family.
The stronger move is to keep one more specimen where:
1. prior verification succeeds,
2. later signed events arrive about the same subject,
3. local spend narrows or pauses without erasing historical truth,
4. and event delivery posture remains visible.

## Promotion restraint
Do not promote `incident watch`, `subject braid`, or `local spend hold` unless they improve:
- one poll-based watch specimen,
- one push-style stream specimen,
- and one event-driven local narrowing specimen.

