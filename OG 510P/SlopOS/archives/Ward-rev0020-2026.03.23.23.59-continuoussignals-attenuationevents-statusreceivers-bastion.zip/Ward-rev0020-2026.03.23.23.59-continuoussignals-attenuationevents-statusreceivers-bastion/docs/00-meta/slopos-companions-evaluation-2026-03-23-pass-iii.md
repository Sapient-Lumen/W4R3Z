# SlopOS and companion-cube evaluation — 2026-03-23 pass III

## Lessons to steal from SlopOS
- The attestation material already models evidence, endorsements, verifier policy, and results as different seams. Ward should absolutely steal that posture.
- SlopOS repeatedly keeps durable grants separate from weak observations. Ward should keep the same discipline for trust consequences.
- The archive’s boundary-family discipline is worth stealing later, but only after Ward has enough real seams to earn a family map.

## Lessons to steal from siblings
- **ViewFS**: local admission and durable object identity should not be smuggled in by provenance labels alone.
- **Helm**: badges and user-facing summaries should sit on top of typed truth, not replace it.
- **Schell**: keep open questions and irreversible decisions explicit.
- **Steward**: prefer exact consequence surfaces to sprawling policy mythology.

## Resulting process choice
Ward should add **followthrough items and promotion gates** before it adds a large trust taxonomy.
