# SlopOS / companions evaluation — 2026-03-23 pass VIII

This pass evaluated how Ward should react to transparency and key-history ideas without turning the cube into a generic ledger service or a public-key directory.

## SlopOS lessons that matter right now

### 1) Imported transparency evidence is still imported evidence
`transparency-proof-import-boundary-v0.md` strongly supports Ward’s pass VIII restraint. Receipts, proofs, and history are worth importing, but they should remain smaller than native durable verdicts.

### 2) Discovery, verification, and verdict already have healthy separation
`verification-material-discovery-boundary-v0.md` and `verification-verdict-boundary-v0.md` are still among the best local warnings in the ecology. Ward should keep that split, especially now that pass VIII adds accountability and history inputs.

### 3) Wallet and account posture remain separate lanes
SlopOS already refuses to collapse wallet posture, cryptographic verification, and account relation into one thing. Ward should keep that habit while exploring stability cards and spend profiles.

### 4) Selection stays local
`provenance-container-selection-boundary-v0.md` is exactly the kind of warning Ward needs when studying transparency and key-history systems: multiple statements may exist, but reconciliation and preference stay local.

## Companion-cube effects

### Harbor
Harbor keeps reminding Ward that the initiator/session story and the trust/consequence story are adjacent but separate. A callback-proof or DPoP-bound return is still smaller than a spend profile.

### Helm
Helm should likely own the visible explanation of spend profiles and stability/history signals without turning them into magical UI badges.

### Schell
Schell makes the operational cost of bad trust compression obvious. Automation wants simple answers; Ward has to resist by keeping inspectable ladders and typed gates.

### ViewFS
ViewFS keeps providing the clean analogy: a witnessed object is not the same thing as a locally admitted object.

### Foundry
Foundry mirrors pass VIII neatly. Runtime history, attestation history, and artifact history can all be accountable without becoming one local verdict.

## Recommendation for Ward rev0008
Keep these candidate nouns alive, but only as candidates:
- stability card;
- history witness;
- receipt pack;
- admission profile ladder;
- spend profile.

Do **not** decide yet:
- whether a public key history object belongs inside Ward proper or only as imported witness material;
- whether spend profiles are Ward’s core object or a downstream policy surface shared with neighbors;
- whether keyless witness systems should be modeled as a separate custody posture or merely one evidence-production lane.

The pass VIII specimen should exist to kill weak or over-wide versions of those ideas early.
