# Archive policy

- Prefer editing existing files over spawning near-duplicates.
- Keep one canonical document per concept family whenever possible.
- Ledgers should carry open uncertainty; prose should not pretend unsettled areas are decided.
- Outside systems are cited as pressure sources, not as templates to clone.
