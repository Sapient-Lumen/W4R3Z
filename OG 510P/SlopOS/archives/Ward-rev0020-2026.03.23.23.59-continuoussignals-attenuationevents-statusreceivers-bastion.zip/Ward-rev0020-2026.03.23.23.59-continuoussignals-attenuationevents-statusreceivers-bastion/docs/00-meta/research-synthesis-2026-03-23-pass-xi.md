# Research synthesis — 2026-03-23 pass XI

This pass focused on a Ward failure mode that old trust systems keep repeating: they treat successful verification as the end of the story instead of the start of accountability, watch duty, and possible later quarantine.

## New lessons from outside systems

### 1) SCITT says receipt-bearing transparency is accountability infrastructure, not final approval
The current SCITT architecture keeps a transparency service, receipts, and verification interfaces in view without pretending that a receipt equals local approval. Ward should steal that shape. A **receipt pack** can be strong verification material and still remain smaller than a local spend verdict.

### 2) KEYTRANS makes history a first-class witness
The latest KEYTRANS architecture continues to treat identity→key change over time as something that can be audited and monitored. Ward should keep **history braids** or similar witness objects available without flattening them into approval.

### 3) Sigstore bundles show the value of grouped verification material
Sigstore bundle guidance keeps the materials needed to verify a signature together. Ward should keep grouped verification material as grouped verification material, not as a disguised final verdict.

### 4) TUF keeps trust healthy by assuming later compromise and later expiry are normal
TUF’s split roles, thresholds, delegations, and expiry are still a hard reminder that a good verification event can later age, regress, or be overruled by newer information. Ward should keep **quarantine gates** and **invalidity horizons** available rather than pretending verification is timeless.

## New lessons from SlopOS and companions

### SlopOS
- The attestation, endorsement, freshness, result, and account-binding families still reward separate strengths of fact rather than one total verdict object.
- The many boundary-index cuts still imply that public evidence and local spend consequence should remain different export strengths.
- Because the primary remains in design phase, Ward should preserve optionality by pressure-testing witness and quarantine shapes rather than declaring a universal trust lattice.

### Siblings
- Harbor keeps reminding Ward that route success and provider-local proof are weaker than spend.
- Foundry keeps reminding Ward that runtime evidence and release policy are different layers.
- Helm wants inspectable user-facing status, which argues for visible history and quarantine surfaces.
- Steward wants accountable followthrough, which supports explicit watch duty after first verification.
- ViewFS continues to distinguish imported evidence from locally admitted material.

## Brilliant ideas worth stealing carefully

1. **Receipt skepticism** — keep “verified once” smaller than “safe to spend now”.
2. **History braid** — a compact linkage among current binding, prior binding history, and watch pointers.
3. **Quarantine gate** — preserve the fact that earlier verification happened while blocking present spend.
4. **Watch duty** — explicit ownership that someone or something must keep monitoring after first admission.
5. **Invalidity horizon** — the earliest moment from which later compromise should start changing consequence.

## What pass XI should not decide yet

Ward still should not decide:
- whether receipt packs and history braids belong to one witness family or two visibly different families;
- whether quarantine gates should live inside the spend family or as a sibling aftermath/status family;
- whether watch duty is always required after admission or only for selected trust classes.
