# SlopOS and companions evaluation — pass XVIII

This pass keeps Ward aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** keeps cryptosvc, wallet, attestation identity, freshness, collateral status, and result surfaces distinct. That strongly supports separating source witness, derived proof, and later status.
- **SlopOS** also keeps local authorization context and local auth status smaller than generic trust, which matches the idea that a verifier can accept a derived proof without learning or owning the whole base credential.
- **Helm** still wants legible trust surfaces, making a disclosure dial and status braid more useful than one opaque green badge.
- **Schell** still wants adoption gates, which means successful verification of a derived proof should remain smaller than spend.
- **ViewFS** keeps source objects, placements, and receipts apart; Ward can borrow that discipline for source witness versus presentment.
- **Steward** still benefits from typed aftermath and local hold semantics.

## Pressure on Ward
Ward should not decide yet whether derived proofs belong inside bundles, status carriers, or spend gates.
The stronger move is to keep one more specimen where:
1. a source credential remains under holder custody,
2. the holder derives a smaller proof for one verifier,
3. repeated presentments can resist linkage,
4. and status/freshness still remains a separate local check.

## Promotion restraint
Do not promote `derived proof`, `unlinkability rail`, or `status braid` unless they improve:
- one minimum-disclosure specimen,
- one repeated-presentment unlinkability specimen,
- and one status/freshness specimen that remains separate from source custody.
