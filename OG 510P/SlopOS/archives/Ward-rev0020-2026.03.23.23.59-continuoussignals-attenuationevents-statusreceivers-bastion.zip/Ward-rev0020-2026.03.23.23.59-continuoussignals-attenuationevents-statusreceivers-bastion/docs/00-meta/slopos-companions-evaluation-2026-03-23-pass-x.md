# SlopOS / companions evaluation — 2026-03-23 pass X

This pass evaluated whether Ward can absorb history-quarantine and watch-lease ideas without turning into either a transparency-log product or a universal security verdict engine.

## SlopOS pressure that matters most now

The attestation, endorsement, and result boundary families remain the strongest native brace. SlopOS continues to separate input witness material, local appraisal, and exported result.

The cryptosvc and wallet-related cuts matter more under pass X. They make it easier to keep custody posture, possession-binding, and spend consequence visibly distinct.

The broader posture of SlopOS still warns against over-unification: if Ward invents one giant verdict object that swallows recovery, log history, session binding, and spend, it will be out of step with the primary cube’s own shape.

## Sibling pressure that matters most now

### Harbor
Harbor keeps the arrival side honest: successful detour return is not yet durable trust.

### Foundry
Foundry keeps foreign runtime evidence smaller than release and approval, which helps Ward avoid substrate capture.

### Helm and Schell
Both continue to want typed, inspectable consequences instead of ambient security folklore.

## Recommendation for Ward rev0011

Keep these candidate nouns provisional:
- **watch lease**
- **history braid**
- **quarantine gate**
- **invalidity horizon**
- **recovery drag**

The pass X specimen should exist to kill the over-wide versions early:
- if watch lease becomes mandatory for every low-risk action, it is too wide;
- if quarantine gate rewrites history instead of constraining spend, it is too strong;
- if invalidity horizon becomes a fake time oracle, it is too frozen.

Ward is healthiest when it can say “this verified then, this is what changed later, and this is what remains spendable now.”
