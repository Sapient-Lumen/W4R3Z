# Research synthesis — 2026-03-23 pass X

This pass focused on a Ward failure mode that older trust stacks keep repeating: they verify once, then fail to model what happens when later history makes that earlier result less safe to spend.

## New lessons from outside systems

### 1) Key transparency is really about later detectability
The current KEYTRANS architecture work is valuable because it makes identity→key binding changes auditable over time. Ward should steal that pressure directly: accountable history should remain visible and queryable without pretending it was local approval all along.

### 2) Receipts can become quarantine-worthy without rewriting the past
The current SCITT architecture work is explicit that compromised receipt-signing keys can force relying parties to ignore receipts until new trust material exists. Ward should steal a **quarantine gate** instead of pretending compromise only means “all past facts evaporate” or “nothing changes.”

### 3) TUF still teaches threshold and expiry humility
The latest TUF specification still relies on role separation, thresholds, and expiry discipline. Ward should keep separate objects for witness material, local appraisal, and spend consequence rather than rushing toward one universal trust token.

### 4) Device-bound session work is stronger than bearer sessions but still smaller than high-risk spend
DBSC is a useful reminder that possession-binding can harden a session without answering every recovery, custody, or approval question. Ward should keep session hardening smaller than durable spend consequence.

## New lessons from SlopOS and companions

### SlopOS
- The attestation, transparency-proof, and account-binding boundary families still push in the same healthy direction: imported witness material stays smaller than verdict.
- The wallet/cryptosvc cuts continue to argue that custody posture and spend policy should remain separate.
- SlopOS’s registry-heavy boundary discipline still rewards small explicit trust objects over one umbrella result.

### Siblings
- Harbor keeps showing that one successful turn does not settle later consequence.
- Foundry keeps runtime evidence smaller than local approval.
- Helm and Schell both continue to support inspectable, typed trust residue instead of ambient “green state”.

## Brilliant ideas worth stealing carefully

1. **Watch lease** — an explicit period during which later drift must still be monitored before higher-risk spend remains allowed.
2. **History braid** — a compact combination of bundle material, binding history, and later watch pointers without collapsing them.
3. **Quarantine gate** — a typed posture where previous evidence is still historically real but temporarily not spendable.
4. **Invalidity horizon** — a way to say when later compromise or expiry begins to affect consequence.
5. **Recovery drag** — a visible penalty on spend posture after weak recovery or cross-device fallback.

## What pass X should not decide yet

Ward still should not decide:
- whether watch leases are separate first-class objects or just a spend-profile field;
- whether quarantine gates live as verdict states or as overlays on spend consequence;
- whether invalidity horizon belongs in witness material, appraisal output, or both.
