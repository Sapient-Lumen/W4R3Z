# Research synthesis — 2026-03-23 pass VII

This pass focused on another recurring trust failure: systems collect strong evidence but then quietly skip the part where someone local decides what that evidence is worth.

## New lessons from outside systems

### 1) Threshold roots matter because they keep ultimate trust away from convenience
The latest TUF specification continues to stress multi-key roles, threshold/quorum trust, and the danger of using online keys for roles clients ultimately trust for installable files. Ward should steal that anti-myth whole: **ultimate trust should stay plural, delegated, and expiring**.

### 2) Provenance is witness material, not automatic approval
SLSA provenance says a build platform produced a set of artifacts through a given build definition. That is extremely useful, but it is still a statement about production, not a final local approval. Ward should keep **provenance witness**, **verification result**, and **local admission/spend** visibly separate.

### 3) Session hardening is worth doing precisely because it is narrower than identity
DBSC remains valuable because it reduces session theft by binding session authentication to device-held keys, but it does not replace identity proof, recovery posture, or durable authorization. Ward should keep the **session warrant** lane narrow and explicit.

### 4) Scoped credentials are still one of the healthiest trust habits
WebAuthn’s relying-party scoping, user consent, and BE/BS distinction continue to be excellent examples of how strong trust material can stay bounded instead of ambient. Ward should keep stealing that narrowness.

## New lessons from SlopOS and companions

### SlopOS
- `verification-material-discovery-boundary-v0.md` and `verification-verdict-boundary-v0.md` still support the separation between discovered material, verified material, and local consequence.
- `provenance-attestation-schema-v0.md` and the attestation family keep reminding Ward that evidence bundles can be rich and still remain smaller than local approval.
- `cryptosvc-verification-boundary-v0.md`, `wallet-posture-v0.md`, and `account-binding-export-boundary-v0.md` together suggest a healthy split between custody, verification, account relation, and spend.
- `transparency-proof-import-boundary-v0.md` adds a useful pressure: transparency evidence is informative, but not the whole verdict.

### Siblings
- Harbor keeps reinforcing that callback or provider success is weaker than durable trust spend.
- ViewFS offers a sharp analogy: imported provenance-bearing material still needs explicit local admission.
- Foundry keeps runtime evidence smaller than final verdict, which is exactly Ward’s job at the trust layer.
- Helm keeps consequence surfaces inspectable instead of magical.

## Brilliant ideas worth stealing carefully

1. **Threshold root pack** — a compact object representing plural, delegated, expiring trust roots instead of one omnipotent key.
2. **Provenance witness card** — a typed object for build/production claims that remains smaller than local approval.
3. **Admission gate** — an explicit local gate that transforms verified trust material into a spendable consequence.
4. **Consequence ladder** — local outcomes such as inspect, admit, install, release, or spend should remain visibly different.
5. **Expiry braid** — custody expiry, provenance recency, attestation freshness, and session warrant age should remain distinct clocks.

## Current recommendation
Ward still should not freeze a universal trust verdict.

The safer move is:
- keep threshold roots, provenance witness material, session warrants, account relations, and spend gates separate;
- use specimen flow 04 to test whether provenance and threshold-root language belongs inside Ward’s durable vocabulary;
- and only promote the nouns that survive both login-style and artifact-admission-style specimens.
