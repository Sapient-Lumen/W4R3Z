# Research synthesis — pass XIII

This pass focuses on what Ward owes **after** initial verification when logs, auditors, or receipt issuers are long-lived but clients are not.

## Fresh outside lessons
1. **Client state loss is a real security boundary.**
   The current Key Transparency architecture draft warns that users who lose local state in Contact Monitoring or Third-Party Auditing deployment modes have a reduced ability to detect forks or obscured data, and recommends Third-Party Management or conservative consumption policies when state is ephemeral. Ward should treat local state continuity as part of trust posture, not as an implementation footnote.

2. **Auditor lag must stay visible.**
   Key Transparency also makes third-party auditing explicit, including a maximum acceptable lag and a configured start point for auditing. That is a good clue for Ward: “audited” is too coarse; some receipts and bindings are only secure if the watch horizon is still acceptable.

3. **Successor networks preserve continuity while widening skepticism.**
   The current SCITT receipts CCF profile says operators can start successor networks with distinct identities that endorse receipts from earlier instances, but clients should mitigate rollback risk by auditing the successor ledger and its attestation information. Ward should therefore separate historical continuity from current full confidence.

4. **Third-party or threshold help changes the trust shape, not just the speed.**
   Key Transparency describes third-party auditing and threshold signatures as ways to reduce collusion or make monitoring tractable. Ward should steal this as a lesson about plural witness shape, not just operational convenience.

## Resulting Ward pressure
Ward should likely preserve at least four distinct things:
- **state watch**: what local continuity the client still holds;
- **auditor lag card**: how stale the latest third-party witness is allowed to be;
- **successor root card**: continuity claim from one log or network epoch into the next;
- **current spend gate**: the local consequence that is actually allowed right now.

## Brilliant ideas worth stealing
- **state watch** — explicit accounting of how much local continuity the client still retains;
- **auditor lag card** — a bounded statement of how recent the current outside witness must be;
- **successor root card** — continuity without pretending that a new root is the old root.
