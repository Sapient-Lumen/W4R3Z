# Research synthesis — pass XII

This pass focuses on what happens **after** something verifies cleanly.

## Fresh outside lessons
1. **Receipts can decay without erasing history.**
   The SCITT architecture explicitly contemplates cases where receipt-signing keys are compromised and old receipts may need to be ignored. That suggests Ward should keep successful verification, later skepticism, and current spendability as separate facts.

2. **Verification bundles are strongest when they remain bundles.**
   Sigstore bundles collect verification material, transparency log evidence, and timestamps so later verification can happen even after short-lived certificates expire. The idea to steal is not “one giant verdict object”, but “grouped verification residue with an explicit shelf life”.

3. **History is versioned, not static.**
   Key Transparency models a label-version story rather than a single timeless identity→key truth. Ward should preserve lineages and watch pointers instead of flattening everything into the current binding.

4. **Session hardening still solves a narrower problem.**
   DBSC continues to be useful as anti-cookie-theft machinery. That makes it a good source of ideas about narrow warrants and post-verification binding, not a reason to collapse session, identity, and spend into one plane.

## Resulting Ward pressure
Ward should probably preserve at least four distinct things:
- **verification bundle**: what was checked and with what material;
- **history watch**: what ongoing observation or recheck duty remains;
- **quarantine braid**: how later compromise or suspicion narrows present spend without rewriting history;
- **current spend gate**: the local consequence that is actually in force now.

## Brilliant ideas worth stealing
- **receipt half-life** — how long a verification bundle can be treated as straightforwardly spend-supporting before recheck or re-anchoring is expected;
- **history watch** — explicit ownership that binding history or transparency signals still need monitoring after first acceptance;
- **quarantine braid** — linkage among original verification, later skepticism, and current narrowed consequence.
