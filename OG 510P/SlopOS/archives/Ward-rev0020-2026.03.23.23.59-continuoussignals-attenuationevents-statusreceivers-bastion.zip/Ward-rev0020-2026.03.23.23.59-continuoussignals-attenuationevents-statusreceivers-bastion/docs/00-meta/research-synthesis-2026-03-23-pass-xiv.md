# Research synthesis — pass XIV

This pass keeps Ward narrow and learns one more thing from outside trust systems: **verification residue ages, and sometimes it must become actively suspect**.

## Outside lessons
1. **SCITT explicitly allows later distrust of receipts.**  
   If receipt-signing keys are compromised, relying parties may need to ignore receipts. Ward should steal that humility instead of treating transparency receipts as timeless approval.

2. **Sigstore bundles are grouped verification material, not final local policy.**  
   They carry certificates, transparency-log material, and timestamps so that verification can still make sense after short-lived certificates expire. That is a powerful reminder that bundled verification residue is useful precisely because it stays smaller than spend approval.

3. **Key Transparency makes continuity and watch duty visible.**  
   State loss and auditor lag both weaken what a user can detect later. Ward should therefore keep history continuity and watch duty inspectable instead of hiding them inside one verification checkmark.

4. **WebAuthn and DBSC still show that narrow success should stay narrow.**  
   Strong credentials and session binding matter, but they do not dissolve the need for later recovery, local appraisal, or spend gating.

## Resulting Ward move
Do not decide yet whether the durable noun is `bundle half-life`, `receipt distrust notice`, or `watch duty`.  
For now, keep all three alive as specimen nouns and demand that they improve:
- one key-history specimen,
- one transparency/receipt specimen,
- and one session- or provenance-admission specimen.

## Fresh ideas worth stealing
- **receipt distrust notice** — a compact local statement that says earlier verification residue still exists but is no longer safe to spend through blindly.
- **bundle half-life** — an honest age class for verification material after which recheck pressure rises sharply.
- **watch duty** — a declared responsibility for later drift, compromise, successor roots, or lagging auditors.
- **successor skepticism card** — continuity information for a rolled-forward log/service that is still weaker than a final green verdict.
