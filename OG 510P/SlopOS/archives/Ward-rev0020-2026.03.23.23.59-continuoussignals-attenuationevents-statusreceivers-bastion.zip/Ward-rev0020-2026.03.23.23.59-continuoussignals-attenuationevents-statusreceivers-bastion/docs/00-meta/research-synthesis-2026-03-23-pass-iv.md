# Research synthesis — 2026-03-23 pass IV

This pass tightened Ward around three sources of pressure:
1. a reread of the most relevant SlopOS cuts, especially attestation, cryptosvc, account-binding, and export/result boundaries;
2. fresh official material on WebAuthn Level 3, passkey custody, RATS, TUF, SLSA provenance, and DBSC;
3. the process constraint that Ward must collect powerful trust ideas without pretending they already fit one total object model.

## What the datacubes reinforced
- SlopOS repeatedly separates evidence, endorsements, local appraisal, exported result, and spendable downstream consequence.
- SlopOS’s attestation and cryptosvc materials suggest that “what happened cryptographically” and “what the system is willing to do next” should stay visibly different.
- ViewFS is a useful trust teacher: provenance-bearing material still needs local admission, and imported identity should not be laundered into native truth.
- Foundry is a constant warning that runtime evidence and resumed-state observations are not yet verdicts.

## What the outside sources reinforced
- WebAuthn remains scoped to a relying party and subject to user consent, which is a strong reason not to over-universalize credentials.
- WebAuthn’s backup eligibility and backup state flags are exactly the kind of narrow custody facets Ward should prefer over giant credential mythology.
- FIDO’s current passkey material keeps the synced-versus-device-bound split explicit; that is good pressure on Ward’s custody model.
- RATS continues to be the cleanest architecture for keeping evidence, endorsements, appraisal policy, and relying-party use apart.
- TUF’s role split and threshold signatures model how trust-root and metadata systems can resist silent centralization.
- SLSA provenance stays useful precisely because it says where/when/how something was produced without pretending to answer every approval decision.
- DBSC is strong evidence that session anti-theft should be modeled as its own object family rather than smuggled into login.

## Brilliant ideas worth stealing carefully
1. **Custody facets**: backup-eligible, backup-state-known, device-bound, sync-fabric-known, recovery-admin-known.
2. **Threshold-root packs**: small explicit role bundles for trust roots rather than one monolithic signer.
3. **Freshness labels with scope**: challenge-bound, generation-bound, revocation-bound, or review-age only.
4. **Separate session-binding objects**: cryptographically meaningful but not allowed to impersonate identity proof.

## Current recommendation
Ward should keep building **freshness-labeled specimens before registries**. The next promotions should happen only after one vocabulary survives all three: passkey custody, attestation appraisal, and supply-chain provenance review.
