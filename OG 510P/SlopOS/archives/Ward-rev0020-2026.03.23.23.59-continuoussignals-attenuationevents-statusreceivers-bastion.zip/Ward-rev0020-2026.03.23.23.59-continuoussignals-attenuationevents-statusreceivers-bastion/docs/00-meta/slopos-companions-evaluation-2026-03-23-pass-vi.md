# SlopOS and companion-cube evaluation — 2026-03-23 pass VI

## What SlopOS keeps teaching Ward
- `attestation-boundary-index.md` remains Ward’s clearest warning label: evidence, endorsements, freshness, identity, and result each need separate names or the archive will lie.
- `verification-verdict-boundary-v0.md` says the quiet part out loud: verification output is already a distinct boundary and should not be submerged under provider success.
- `wallet-posture-v0.md` and the cryptosvc boundaries suggest that custody stories belong beside, not inside, appraisal stories.
- `account-binding-export-boundary-v0.md` keeps account relation visible as a real but narrower export than total local trust.
- `vault-posture-v0.md` suggests that the practical endpoint of trust is often a release, spend, or local grant—not a generic green badge.

## What the siblings sharpened this pass
- **Harbor** contributes the strongest current anti-lesson: cross-device and provider-mediated returns can be operationally useful while still being too weak for durable local consequence.
- **Helm** contributes the need for inspectable consequence surfaces rather than hidden trust upgrades.
- **ViewFS** contributes the habit of keeping provenance-bearing material and local admission separate.
- **Foundry** contributes the discipline that runtime evidence should not pretend to be the final verdict.
- **Schell** contributes a useful operational wrinkle: operator convenience channels often need explicit adoption before they should count as trust.

## Pass-VI result
Ward should not promote a universal credential object or a universal trust verdict.

The sharper move is:
- add a specimen where cross-device approval yields only a weak or partial local consequence;
- keep approval locus, custody posture, session warrant, and spend gate visibly separate;
- and let threshold roots, expiry, and provenance verification stay boringly explicit instead of magically implicit.
