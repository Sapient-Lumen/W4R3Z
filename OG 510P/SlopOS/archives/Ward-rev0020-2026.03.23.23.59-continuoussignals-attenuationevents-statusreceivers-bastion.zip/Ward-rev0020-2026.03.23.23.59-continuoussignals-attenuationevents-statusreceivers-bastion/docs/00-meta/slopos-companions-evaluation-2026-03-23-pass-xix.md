# SlopOS / companions evaluation — pass XIX

Ward still looks justified as its own companion cube.

## What the current cube ecology keeps proving
- **SlopOS** repeatedly distinguishes attestation, credential, claim, endorsement, and local adoption. Root epochs and threshold resets strengthen that distinction.
- **Helm** benefits because user-facing trust repair should not look like ordinary sign-in success.
- **Schell** benefits because automation needs a typed way to halt spend or rollout when delegation trust changes.
- **ViewFS** benefits because imported objects may remain intact while their trust lineage freezes.
- **Steward** benefits because activation or release work may need to pause on delegation distrust without rewriting the original artifact history.
- **Harbor** should stay distinct: getting to the right place is weaker than re-trusting a new root epoch.
- **Foundry** should stay distinct: foreign execution can carry evidence, but root and delegation custody are Ward’s job.

## Current recommendation
Keep the new Ward nouns provisional. They are useful only if they preserve the split between:
1. witness material,
2. trust root lineage,
3. delegated-role authority,
4. and local spend/adopt consequence.
