# Bibliography

- **EXT-WEBAUTHN-3** — W3C Web Authentication: Level 3 — https://www.w3.org/TR/webauthn-3/
- **EXT-RFC-9334** — IETF RFC 9334, RATS Architecture — https://www.rfc-editor.org/rfc/rfc9334.html
- **EXT-RFC-9711** — IETF RFC 9711, The Entity Attestation Token (EAT) — https://www.rfc-editor.org/rfc/rfc9711.html
- **EXT-TUF-DOCS** — TUF roles and metadata — https://theupdateframework.io/docs/metadata/
- **EXT-TUF-SPEC-2026** — The Update Framework specification — https://theupdateframework.github.io/specification/latest/
- **EXT-SLSA-PROVENANCE** — SLSA Build Provenance — https://slsa.dev/spec/draft/build-provenance
- **EXT-DBSC** — W3C Device Bound Session Credentials — https://www.w3.org/TR/dbsc/
- **EXT-FIDO-PASSKEYS** — FIDO Alliance, Passkeys — https://fidoalliance.org/passkeys/
- **EXT-FIDO-DPCS** — FIDO Alliance, Device-bound passkeys overview — https://passkeycentral.org/introduction-to-passkeys/passkey-types
- **EXT-NIST-SYNCABLE** — NIST syncable authenticators guidance — https://pages.nist.gov/800-63-4/sp800-63b/syncable/
- **EXT-NIST-63B-SUP1** — NIST SP 800-63B Supplement 1 — https://csrc.nist.gov/pubs/sp/800/63/b/sup/final
- **EXT-SLSA-PROVENANCE-APPROVED** — SLSA provenance overview — https://slsa.dev/provenance
- **EXT-SLSA-PROVENANCE-SPEC** — SLSA provenance spec — https://slsa.dev/spec/v1.0/provenance
- **EXT-DBSC-CHROME** — Chrome DBSC overview — https://developer.chrome.com/docs/web-platform/device-bound-session-credentials
- **EXT-OAUTH-CROSS-DEVICE-2025** — IETF draft, Cross-Device Flows: Security Best Current Practice — https://datatracker.ietf.org/doc/draft-ietf-oauth-cross-device-security/
- **EXT-WEBAUTHN-3-2026** — W3C WebAuthn Level 3 — https://www.w3.org/TR/webauthn-3/
- **EXT-FIDO-PASSKEYS-2025** — FIDO Alliance, Passkeys — https://fidoalliance.org/passkeys/
- **EXT-DBSC-2025** — Chrome Developers, Device Bound Session Credentials — https://developer.chrome.com/docs/web-platform/device-bound-session-credentials
- **EXT-SLSA-V1** — SLSA Provenance v1.0 — https://slsa.dev/spec/v1.0/provenance
- **EXT-TUF-ROLES-2025** — TUF roles and metadata — https://theupdateframework.io/docs/metadata/
- **EXT-TUF-SPEC-LATEST-2026** — The Update Framework specification — https://theupdateframework.github.io/specification/latest/
- **EXT-SLSA-PROVENANCE-V1** — SLSA provenance v1.0 — https://slsa.dev/spec/v1.0/provenance

- **EXT-SCITT-ARCH-2026** — IETF SCITT architecture draft — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
- **EXT-KEYTRANSPARENCY** — Google Key Transparency — https://github.com/google/keytransparency
- **EXT-SIGSTORE-KEYLESS** — Sigstore keyless signing overview — https://docs.sigstore.dev/cosign/signing/overview/

- **EXT-SIGSTORE-BUNDLE** — Sigstore bundle format — https://docs.sigstore.dev/about/bundle/
- **EXT-REKOR-EVENT-STREAM** — Sigstore Rekor event stream — https://docs.sigstore.dev/logging/event_stream/
- **EXT-KEYTRANS-WG** — IETF KEYTRANS working group goals — https://datatracker.ietf.org/wg/keytrans/about/
- **EXT-KEYTRANS-ARCH-2026** — IETF KEYTRANS architecture draft — https://datatracker.ietf.org/doc/draft-ietf-keytrans-architecture/

- **EXT-SCITT-SCRAPI-2026** — IETF SCITT Reference APIs draft — https://datatracker.ietf.org/doc/draft-ietf-scitt-scrapi/

- **EXT-SCITT-RECEIPTS-CCF-2026** — IETF SCITT receipts CCF profile draft — https://datatracker.ietf.org/doc/draft-ietf-scitt-receipts-ccf-profile/

- **EXT-SIGSTORE-BUNDLE-2025** — Sigstore bundle format — https://docs.sigstore.dev/about/bundle/

- **EXT-KEYTRANS-PROTOCOL-2026** — IETF Key Transparency Protocol draft — https://ietf-wg-keytrans.github.io/draft-protocol/draft-ietf-keytrans-protocol.html
- **EXT-SCITT-ARCH-2026-LATEST** — IETF SCITT architecture draft (latest) — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
- **EXT-SIGSTORE-SECURITY** — Sigstore security model — https://docs.sigstore.dev/about/security/

- **EXT-VC-BITSTRING-STATUS-LIST** — W3C Bitstring Status List v1.0 — https://www.w3.org/TR/vc-bitstring-status-list/
- **EXT-VC-DATA-MODEL-2-0** — W3C Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/
- **EXT-VC-DATA-INTEGRITY** — W3C Verifiable Credential Data Integrity 1.0 — https://www.w3.org/TR/vc-data-integrity/
- **EXT-VC-DI-BBS** — W3C Data Integrity BBS Cryptosuites v1.0 — https://www.w3.org/TR/vc-di-bbs/
- **EXT-OPENID-SSF-2025** — OpenID Shared Signals Framework 1.0 — https://openid.net/specs/openid-sharedsignals-framework-1_0.html
- **EXT-OPENID-CAEP-2025** — OpenID Continuous Access Evaluation Profile 1.0 — https://openid.net/specs/openid-caep-1_0-final.html
- **EXT-OPENID-RISC-2025** — OpenID RISC Profile Specification 1.0 — https://openid.net/specs/openid-risc-1_0-final.html
