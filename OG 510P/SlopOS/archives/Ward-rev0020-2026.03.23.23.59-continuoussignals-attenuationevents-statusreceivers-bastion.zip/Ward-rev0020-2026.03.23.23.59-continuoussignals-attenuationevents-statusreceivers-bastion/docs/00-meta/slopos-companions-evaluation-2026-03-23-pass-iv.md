# SlopOS and companion-cube evaluation — 2026-03-23 pass IV

## Lessons to steal from SlopOS
- The attestation and cryptosvc boundary families in SlopOS already encode the most important Ward instinct: do not let evidence, provider mechanics, freshness, result export, and local consequence disappear into one object.
- SlopOS’s account-binding and auth-result materials suggest Ward should keep “identity relation minted locally” separate from any callback or provider success signal imported from elsewhere.
- The microVM attestation-reacquire posture is especially useful to Ward: generation changes can invalidate freshness-bound trust material without forcing every local secret or credential to be destroyed.

## Lessons to steal from siblings
- **Harbor**: browser detours and provider UI are inputs to trust, not the whole trust story.
- **ViewFS**: provenance-bearing material still needs local admission and can have weaker or stronger identity stories.
- **Schell** and **Helm**: typed operator-visible consequences are better than giant ambient “secure” badges.
- **Foundry**: runtime evidence and substrate identity should arrive here as appraisable material, not as already-spendable trust.

## Process result
Ward should keep promoting **small verdict specimens** and custody facets before it promotes any shared registry that pretends to cover every credential and every trust flow.
