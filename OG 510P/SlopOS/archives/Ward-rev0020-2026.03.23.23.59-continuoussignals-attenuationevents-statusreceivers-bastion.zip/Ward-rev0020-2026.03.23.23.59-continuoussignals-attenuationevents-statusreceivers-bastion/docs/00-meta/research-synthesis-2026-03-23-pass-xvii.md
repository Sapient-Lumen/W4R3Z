# Research synthesis — pass XVIII

This pass keeps Ward narrow and learns one more thing from outside trust systems: **later trust change is often best expressed as signed event statements about a subject, delivered on a watch stream, and still interpreted locally rather than obeyed as commands**.

## Outside lessons
1. **RFC 8417 defines Security Event Tokens as statements of fact, not commands.**  
   A SET is a JWT about a subject and an event that occurred to or about that subject. Recipients validate and interpret the event, then decide what independent action to take, if any. Ward should steal the discipline: incident material can be authoritative and still remain smaller than local spend or durable verdict.

2. **RFC 8936 gives those events a pollable delivery rail with explicit queue/ack behavior.**  
   Poll-based delivery over TLS lets recipients fetch zero or more SETs, then acknowledge what they received and poll again. Ward should preserve watch ownership and delivery posture instead of flattening everything into one static status bit.

3. **RFC 9493 makes subjects structured instead of folklore.**  
   Subject identifiers are named, structured JSON forms rather than one universal string. Ward should keep subject identity in event streams explicit and typed.

4. **OpenID SSF 1.0 shows the modern direction.**  
   SSF profiles SETs, subject principals, and both push/poll event-stream delivery, then adds management/discovery surfaces for those streams. Ward should treat event streams as a sibling of status carriers and witness bundles, not as an implementation detail.

## Resulting Ward move
Do not decide yet whether the durable nouns are `incident watch`, `subject braid`, and `local spend hold`, or whether one of them later hides behind status or verdict families.
For now, keep all three alive as specimen nouns and demand that they improve:
- one poll-based watch specimen,
- one push-style stream specimen,
- and one event that narrows local spend without pretending to command it.

## Fresh ideas worth stealing
- **incident watch** — a signed stream of later trust-relevant facts.
- **subject braid** — typed subject continuity across receipts, status, and later events.
- **local spend hold** — explicit local narrowing triggered by events without erasing prior verification.
- **command-vs-fact split** — events can be strong facts and still remain non-command residue.

