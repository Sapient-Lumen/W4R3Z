# Research synthesis — pass XVI

This pass keeps Ward narrow and learns one more thing from outside trust systems: **status is its own trust layer, and it can be reversible, advisory, privacy-sensitive, or even governed by a different authority than the one that issued the original claim**.

## Outside lessons
1. **Bitstring Status List v1.0 keeps status purpose typed.**  
   `revocation`, `suspension`, `refresh`, and `message` are different semantics. Ward should steal the discipline: status should not collapse into one generic invalid bit.

2. **Status authority can differ from original credential authority.**  
   The status-list issuer may differ from the original credential issuer. Ward should treat that as a useful warning that witness material and status material can legitimately come from different places.

3. **Holder-provided status can improve privacy without becoming absolute freshness truth.**  
   The status list can be carried by the holder so the verifier need not contact the issuer, but the verifier may still prefer a fresher list. Ward should therefore keep privacy-friendly status carriage separate from final freshness appraisal.

4. **Status itself can create correlation pressure.**  
   The spec warns that long-lived status indices can be monitored over time and suggests periodic reissue. Ward should preserve watch duty and reissue cadence instead of pretending status is free.

## Resulting Ward move
Do not decide yet whether the durable noun is `status carrier`, `suspension rail`, or `refresh notice`.
For now, keep all three alive as specimen nouns and demand that they improve:
- one reversible-suspension specimen,
- one refresh-without-invalidation specimen,
- and one specimen where the status authority is not the original issuer.

## Fresh ideas worth stealing
- **status carrier** — grouped status material that remains smaller than final spend approval.
- **suspension rail** — a reversible narrowing lane distinct from permanent revocation.
- **refresh notice** — advisory status that says “replace this” without saying “this was false”.
- **status authority split** — explicit residue when the entity changing status is not the entity that issued the original witness.
