# SlopOS + companions evaluation — pass XIII

This pass reads SlopOS and the siblings as pressure for Ward to become better at **trust continuity under partial forgetting**.

## Lessons from the datacubes
1. **SlopOS already splits attestation freshness, endorsement, identity, and result.**
   Ward should keep borrowing that discipline: later skepticism, current spend, and historical verification residue should not collapse back together.

2. **Schell and Steward both care about leases and countdown rails.**
   That sibling pressure suggests Ward should not pretend trust is timeless. Auditor lag, receipt half-life, and watch windows should stay user-legible rather than hiding behind one green badge.

3. **Helm's endorsement surfaces and ViewFS's delta-truth posture both reward historical honesty.**
   Ward should tell the truth about “verified then, maybe narrower now” instead of overwriting the past.

4. **Foundry's foreign-ground work makes successor-root skepticism more important.**
   When transparency or attestation infrastructure itself rolls forward, Ward needs a vocabulary for continuity that does not erase rollover risk.

## Resulting cube move
Do not decide yet whether `state watch` belongs inside verification bundles or beside them. Keep it as a separate specimen noun until it improves one passkey/binding specimen, one receipt/transparency specimen, and one attestation-successor specimen.
