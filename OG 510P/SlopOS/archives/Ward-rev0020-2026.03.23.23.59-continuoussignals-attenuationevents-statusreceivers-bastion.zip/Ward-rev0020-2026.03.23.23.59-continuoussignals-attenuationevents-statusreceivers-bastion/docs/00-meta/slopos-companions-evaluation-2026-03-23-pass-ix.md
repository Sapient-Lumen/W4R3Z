# SlopOS / companions evaluation — 2026-03-23 pass X

This pass evaluated whether Ward can learn from grouped verification and watch-duty patterns without collapsing into a generic transparency platform.

## SlopOS pressure that matters most now

`verification-material-discovery-boundary-v0.md` and `verification-verdict-boundary-v0.md` remain the strongest local warnings. Ward can group verification material more cleanly, but it must not let grouped material impersonate a verdict.

`transparency-proof-import-boundary-v0.md` still strongly supports pass X. Transparency proofs, receipts, and history are importable witness material; they are not the final local consequence.

`account-binding-export-boundary-v0.md`, `wallet-posture-v0.md`, and the cryptosvc boundaries continue to argue that binding relation, custody posture, and spend remain distinct. That is exactly why a binding witness should stay smaller than approval.

## Sibling pressure that matters most now

### Harbor
Harbor mirrors the same problem on the route side: one successful turn is not the whole story. That keeps Ward honest about later drift and later monitoring.

### Foundry
Foundry is the best sibling for watch-duty pressure. Foreign-ground evidence can be valid at one moment and still require later re-evaluation. Ward should preserve the same humility for trust material.

### Helm and ViewFS
Helm wants inspectable consequence surfaces; ViewFS wants imported witness material to remain weaker than durable admitted state. Both support pass X.

## Recommendation for Ward rev0011

Ward should keep these candidate nouns provisional:
- **bundle pack**
- **binding witness**
- **spend watch**
- **regression alarm**

The pass X specimen should exist to kill weak versions early:
- if bundle pack becomes synonymous with approval, it is too strong;
- if binding witness starts implying custody or consent, it is too wide;
- if spend watch becomes mandatory surveillance doctrine rather than a typed responsibility, it is too frozen.

Ward is healthiest when it keeps first verification, later drift, and final spend visibly distinct.
