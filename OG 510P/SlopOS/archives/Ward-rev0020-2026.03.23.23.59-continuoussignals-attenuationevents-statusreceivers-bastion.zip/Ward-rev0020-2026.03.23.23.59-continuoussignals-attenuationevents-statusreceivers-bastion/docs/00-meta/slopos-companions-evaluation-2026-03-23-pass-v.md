# SlopOS and companion-cube evaluation — 2026-03-23 pass V

## Lessons to steal from SlopOS
- The attestation family and cryptosvc family already show the right shape: evidence input, provider facts, freshness, verification, result export, and spendable local consequence stay split.
- `account-binding-export-boundary-v0.md` and the auth-result cuts suggest that any local relationship minted after a login or credential event should remain visibly local.
- `microvm-attestation-reacquire-posture-v0.md` is a major Ward lesson: generation changes can invalidate freshness classes or secret-release sessions without erasing every longer-lived identity relation.
- `capability-wallet-schema-v0.md` and adjacent provider-selection cuts hint that custody, inventory, and selector posture are different pressures.

## Lessons to steal from siblings
- **Harbor** reminds Ward that return-path proof and browser success are merely inputs.
- **ViewFS** reminds Ward that provenance-bearing artifacts, imported refs, and local handles still need local admission.
- **Helm** and **Schell** remind Ward that operator-visible consequences should be typed and inspectable, not flattened into a vague secure/not-secure story.
- **Foundry** reminds Ward that runtime measurements and platform evidence arrive as appraisable material, not ready-made verdicts.

## Process result
Ward still should not choose one master trust object. The pass-V outcome is narrower:
- keep custody tuples separate from appraisal outputs,
- keep appraisal outputs separate from spendable consequences,
- and keep session-binding warrants explicitly separate from identity proof.
