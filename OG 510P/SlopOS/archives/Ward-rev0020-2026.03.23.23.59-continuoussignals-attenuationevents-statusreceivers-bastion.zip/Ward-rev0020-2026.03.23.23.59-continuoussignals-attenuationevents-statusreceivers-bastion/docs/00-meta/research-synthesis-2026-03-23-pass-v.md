# Research synthesis — 2026-03-23 pass V

This pass was guided by one question: how do we learn from mature trust systems without inheriting their flattening habits?

## What the past keeps teaching Ward
- WebAuthn still teaches the most valuable constraint: credentials are scoped to a relying party, created with user involvement, and should not be generalized into a universal proof of personhood.
- WebAuthn Level 3 and NIST’s syncable-authenticator guidance sharpen a subtle but crucial lesson: **backup eligible** does not mean **backed up**, and syncability is not identical to current replication state.
- RATS remains the cleanest architecture for keeping Evidence, Endorsements, appraisal policy, and Attestation Results distinct. Ward should keep stealing that separation.
- TUF is a model case for trust-root humility: different roles sign different metadata, thresholds matter, and metadata expires. Ward should steal the role split, not just the signatures.
- SLSA provenance is valuable precisely because it describes where, when, and how something was produced. It does not solve every approval decision.
- DBSC is one of the nicest recent reminders that session anti-theft is its own object family. A session-bound proof of possession should not masquerade as identity proof, account recovery proof, or broad trust pedigree.

## What the cubes reinforced
- SlopOS repeatedly separates result export from local consequence. Ward should keep that stance even when UI or product pressure wants one big “trusted” badge.
- SlopOS’s capability-wallet and cryptosvc materials suggest that selection, custody, mechanism, and provider choice each deserve their own pressure surface.
- Harbor keeps providing the right warning: browser success and callback proof are inputs to appraisal, not the appraisal itself.
- Foundry keeps proving that runtime measurements and continuity signals still need local interpretation.

## Brilliant ideas worth stealing carefully
1. **Custody tuple** — backup eligible, current backup state known, device-bound, recovery-admin known, sync-fabric known, and export posture. A narrow tuple is better than credential mythology.
2. **Appraisal shelf life** — every verdict or warrant should carry not only freshness but what kind of freshness it depends on: challenge-bound, revocation-bound, generation-bound, review-age only, or policy-era only.
3. **Threshold root pack** — a compact object holding a role split and threshold requirement rather than one giant signer or one global trust root.
4. **Session-binding warrant** — a spend-limited warrant derived from session possession proof, explicitly forbidden from impersonating identity proof.
5. **Local spend class** — admit, warn-and-admit, deny, hold-for-review, or mint-limited-grant should be visibly distinct downstream consequences.
6. **Provenance as appraisable material** — import provenance and build evidence as material for a local verdict, never as the verdict itself.

## Current recommendation
Ward should promote a second specimen from a clearly different family before it promotes any shared registry. The best candidate is a session-binding / local-spend specimen because it pressure-tests whether Ward can talk about trust consequence without pretending every consequence came from identity.
