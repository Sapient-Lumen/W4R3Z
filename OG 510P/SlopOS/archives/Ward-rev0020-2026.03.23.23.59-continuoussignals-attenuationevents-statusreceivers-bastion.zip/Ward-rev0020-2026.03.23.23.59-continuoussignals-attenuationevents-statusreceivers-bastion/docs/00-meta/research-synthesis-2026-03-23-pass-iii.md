# Research synthesis — 2026-03-23 pass III

This pass tightened Ward around three sources of pressure:
1. a deeper reread of SlopOS and the current companion cubes;
2. fresh official material on passkeys, attestation roles, update metadata, provenance, and device-bound sessions;
3. the explicit constraint that the primary cube must stay pressure-sterile.

## What the datacubes reinforced
- SlopOS keeps evidence, endorsements, verifier policy, and exported results visibly separate.
- ViewFS reminds us that provenance, live handles, and local admission are different classes of fact.
- Schell and Helm both punish vague success badges and reward modest typed surfaces.
- Steward rewards tiny exact outcome surfaces over giant “trust status” mythology.

## What the outside sources reinforced
- WebAuthn remains strongly scoped to relying-party origins and user consent;
- RATS still provides the best crisp reminder that evidence, endorsements, appraisal, and relying-party use are different roles;
- TUF keeps metadata roles separate to resist mix-and-match attacks;
- SLSA treats provenance as an attestation about how artifacts were produced, not as the final local policy answer;
- newer device-bound-session work shows that protecting sessions from export is related to trust, but is not identical to identity or general consent.

## Founding result
Ward should stay small and add **freshness-labeled specimen verdicts before registries**. The archive should especially resist inventing one giant credential or verdict object before it survives both human and machine trust flows.
