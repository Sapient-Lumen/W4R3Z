# ADR 0001: Ward keeps trust layers separate

- Status: accepted

Ward will keep custody, evidence, endorsement, appraisal, and trust consequences as different first-class layers.
