# ADR template

- Status: proposed
- Context:
- Decision:
- Consequences:
