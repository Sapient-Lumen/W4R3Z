# ADR 0002: Success signals do not equal durable trust

- Status: accepted

A successful callback, login, or attestation exchange may contribute to local trust, but it is not itself the durable verdict.
