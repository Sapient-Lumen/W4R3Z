ADR index placeholder
