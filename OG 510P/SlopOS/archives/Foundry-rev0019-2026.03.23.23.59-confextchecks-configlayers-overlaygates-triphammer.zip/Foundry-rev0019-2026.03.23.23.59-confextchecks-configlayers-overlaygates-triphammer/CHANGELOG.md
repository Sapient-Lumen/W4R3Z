## rev0019 — confext checks, config layers, and overlay gates
- added pass XIX research synthesis and pass XIX datacube evaluation;
- added specimen flow 16 around confext checks, config layers, and overlay gates;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0018 — metadata seals, payload roots, and bootstrap debt
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 15 around metadata seals, payload roots, and bootstrap debt;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0018 — compat witnesses, detachable layers, and backing cargo
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 14 around compat witnesses, detachable layers, and backing cargo;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0016 — lazy hydration, prefetch witnesses, and cold-read debt
- added pass XVI research synthesis and pass XVI datacube evaluation;
- added specimen flow 13 around lazy hydration, prefetch witnesses, and cold-read debt;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0015 — void routes, borrow rails, and secret latches
- added pass XV research synthesis and pass XV datacube evaluation;
- added specimen flow 12 around void route borrow rail and secret latch;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0014 — owned-handle swaps, availability floors, and restore-duty ledgers
- added pass XIV research synthesis and pass XIV datacube evaluation;
- added specimen flow 11 around owned-handle swaps, availability floors, and restore-duty ledgers;
- refreshed ledgers, context pack, manifests, and archive index for the new release.

# Changelog

## rev0013 — 2026-03-23
- continued online research with a stronger focus on restore hooks, availability classes, and referrer-fallback hygiene
- added a pass XII datacube evaluation, a pass XII research synthesis, and a ninth specimen selected to preserve optionality
- refreshed lessons, inspirations, ledgers, manifests, and context surfaces; then reran repo hygiene checks

## rev0011 — 2026-03-23
- continued online research with a stronger focus on subject spines, resource handles, and policy-capsule hygiene;
- added a pass XI datacube evaluation, a pass XI research synthesis, and an eighth specimen selected to preserve optionality;
- refreshed lessons, inspirations, queues, manifests, and context surfaces; cleaned duplicate sections from prior passes; and reran repo hygiene checks.

## rev0008 — 2026-03-23
- continued online research with a stronger focus on OCI-style subject-attached sidecars, repository-scoped evidence attachment, and measured policy input;
- added a pass VIII datacube evaluation, a pass VIII research synthesis, and a fifth specimen selected to preserve optionality;
- refreshed lessons, queues, manifests, and context surfaces; repaired duplicate lesson sections; and reran repo hygiene checks.

## rev0007 — 2026-03-23
- continued online research with a stronger focus on policy split, init-data integrity, explicit foreign capability routing, and attested adoption;
- added a pass VII datacube evaluation, a pass VII research synthesis, and a fourth specimen selected to preserve optionality;
- repaired changelog drift, refreshed queues/ledgers/manifests, and reran repo hygiene checks.

## rev0006 — 2026-03-23
- continued online research with a stronger focus on lessons from cross-device flows, dynamic routing, session hardening, capability routing, restore-time humility, and explicit rebound/reacquire patterns;
- added a pass VI datacube evaluation, a pass VI research synthesis, and a third specimen selected to preserve optionality;
- cleaned registry/ledger identifiers, refreshed bibliography and release metadata, and reran repo hygiene checks.

## rev0005 — 2026-03-23
- continued online research with a stronger focus on lessons worth stealing from mature ecosystems and current standards;
- added a pass V datacube evaluation, a pass V research synthesis, and a second specimen selected to preserve optionality;
- refreshed repo/process surfaces, queues, ledgers, bibliography, and release metadata while keeping the cube embryonic.

## rev0004 — 2026-03-23
- continued online research with a focus on anti-lessons, specimen flows, and option-preserving architecture moves;
- added a pass IV datacube evaluation plus a new research synthesis and a first concrete specimen document;
- refreshed lessons, inspiration, queues, ledgers, bibliography, and repo hygiene/process surfaces.

## rev0003 — 2026-03-23
- continued online research and a deeper readthrough of SlopOS plus companion cubes;
- added a lessons-from-the-past file, a datacube evaluation pass, and promotion gates/specimen tests;
- added followthrough/irreversible-decision hygiene surfaces and a runnable repo check.

## rev0002 — 2026-03-23
- deepened the founding embryo after reading the current cube ecology and official outside sources;
- sharpened the cube’s internal separations and neighbor boundaries;
- added roadmap, trajectory, ledgers, ADRs, and expanded architecture notes.
