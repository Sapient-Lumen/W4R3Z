# Steal these ideas

## From outside systems
- OCI: keep image/index/bundle/config distinct instead of flattening “what shipped” into “what ran”.
- Wasm component model: make packages, interfaces, and worlds explicit so foreign contracts stay honest.
- Fuchsia capability routing: route virtualization and foreign-power explicitly into products/sessions.
- Qubes qrexec: explicit cross-domain service routes beat ambient reachability.
- Confidential Containers: keep attestation/admission policy separate from resource-release policy; bind init-data integrity into the story.
- Firecracker and SnapStart: restore is valuable, but continuity, uniqueness, and network state still need humility.
- OCI referrers/artifacts: attach nearby evidence and contract artifacts to a digest subject without bloating the primary.
- Repository-scoped referrers: keep operational grouping close without confusing shared scope for final approval.

## From sibling cubes
- Harbor: foreign entry and return need truthful membrane receipts.
- Ward: evidence remains smaller than verdict or release.
- Helm: visibly foreign surfaces are a product virtue.
- Schell: helpers and sidecars deserve explicit adoption.
- ViewFS: artifact carriers, live instances, and durable references are different strengths.

## New steals for rev0008
1. **Subject spine** — a stable anchor for nearby sidecars without fake completeness.
2. **Sidecar pack** — grouped nearby evidence/contract artifacts that stay visibly partial.
3. **Measured policy capsule** — record which policy input was integrity-bound into realization.
4. **Adoption rail** — started, attested, reviewed, adopted remain separate even with neat sidecars.
5. **Repository-scope warning** — shared access scope is convenience, not verdict.
## New steals for rev0011
1. **Subject spine** — the primary artifact plus its attached nearby evidence neighborhood, still smaller than realization.
2. **Resource handle** — a typed exterior handle to something implemented across the boundary.
3. **Policy capsule** — compact account of which policy inputs governed admission or release.
4. **Secret-release latch** — explicit state showing that release of stronger foreign power is separately gated.
5. **Availability split** — required versus optional routed foreign power stays visible.

## New steals for rev0013
1. **Restore obligation card** — post-resume duties kept visible until discharged.
2. **Availability class** — required, optional, unavailable as a first-class foreign-power status.
3. **Referrer fallback card** — nearby sidecars discovered through a degraded path instead of native referrers.
4. **After-restore rail** — resumed is not the same as ready.
5. **Auxiliary-capability dimmer** — optional foreign power should degrade features without falsifying the whole realization.


- **borrowed handle card** — explicit note that a useful thing still lives elsewhere.
- **restore budget** — what a resumed realization may spend before its readiness claim narrows.
- **capability grade** — required/optional/degraded/absent rather than yes/no.

## New steals for rev0014
- **owned-handle swap** — record whether foreign utility is still borrowed or has been replaced/re-owned elsewhere.
- **availability floor** — the weakest still-true routed power posture.
- **restore duty ledger** — explicit after-restore obligations before strong readiness claims.
- **fallback lease** — honest degraded attachment discovery.
- **foreign utility without fake locality** — a standing anti-regrowth rule.

## New steals for rev0015
- **void route** — explicit absence for optional or product-specific power.
- **borrow rail** — a visible lane for useful handles that remain foreign-backed and borrowed.
- **secret latch** — release posture separated from attestation and base readiness.
- **degraded readiness class** — running, but still weaker than fully adopted or fully provisioned.
- **absence is a fact** — a standing anti-regrowth rule.

## New steals for rev0016
- **hydration frontier** — how much of the artifact is materially local right now.
- **prefetch witness** — compact residue about what was intentionally fetched early.
- **cold-read debt** — the remaining cost of later on-demand hydration.
- **lazy-locality grade** — a truthful class for “works now, still not fully local”.
- **launch smaller than locality** — a standing anti-regrowth rule.

## New steals for rev0018
- **extension witness** — compact compatibility residue for a foreign layer.
- **detachable layer** — attachable foreign merge that remains rollback-capable.
- **backing cargo** — content store distinct from the mountable structural layer.
- **structure/cargo split** — separate integrity and locality stories for layer versus data.
- **attach smaller than assimilate** — a standing anti-regrowth rule.

## New steals for rev0018
- **metadata seal** — explicit integrity story for names, structure, permissions, and directory shape.
- **payload root** — compact witness for foreign-backed file content.
- **bootstrap debt** — what still remains non-local even though startup can begin.
- **seal split** — keep structure assurance and payload assurance visibly different.
- **started smaller than sealed** — a standing anti-regrowth rule.

## Pass XIX additions
- **config layer** — foreign configuration surface distinct from runtime cargo.
- **compat witness** — compact compatibility proof for an overlay.
- **overlay gate** — typed refusal when merge compatibility is insufficient.
