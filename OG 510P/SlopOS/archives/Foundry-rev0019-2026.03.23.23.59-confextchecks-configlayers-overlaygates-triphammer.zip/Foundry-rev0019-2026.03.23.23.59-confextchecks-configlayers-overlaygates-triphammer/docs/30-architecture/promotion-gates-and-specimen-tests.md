# Promotion gates and specimen tests

Foundry should not promote a new durable noun unless it survives at least one specimen flow.

## Promotion gates
1. A proposed object must say whether it describes a package, runtime contract, live realization, or continuity claim.
2. It must survive at least one OCI-style flow and one component-model flow without changing meaning.
3. It must declare which downgrade or foreignness signals remain visible.
4. It must identify which trust questions are exported to Ward rather than answered locally.

## First specimen tests
- OCI image versus runtime bundle versus live VM-backed container;
- Wasm world/interface contract versus ambient host assumption;
- snapshot restore with explicit uniqueness/network/ephemeral-data hazards;
- confidential runtime flow where evidence is exported but verdict stays outside Foundry.
