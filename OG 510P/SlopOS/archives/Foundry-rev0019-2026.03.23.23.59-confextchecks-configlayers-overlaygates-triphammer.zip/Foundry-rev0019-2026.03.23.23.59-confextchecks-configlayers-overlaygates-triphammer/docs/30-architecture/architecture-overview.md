# Architecture overview

Foundry studies how native meaning survives when enacted on foreign ground.

The founding model has five layers:

1. **artifact basis** — image, package, component, template, snapshot, or similar carrier;
2. **declared interface or world** — what the artifact says it needs and offers;
3. **runtime ground** — container host, microVM, guest kernel, component host, TEE, or compatibility layer;
4. **live realization** — what is actually instantiated, attached, resumed, degraded, or mediated now;
5. **continuity evidence** — what can be restored, reacquired, cloned, or must instead be freshly re-realized.

Foundry’s job is to keep those layers from collapsing into “it runs somewhere else”.

## rev0003 posture additions
- keep snapshot, callback, and provider success signals visibly weaker than durable local consequence;
- prefer one or two specimen artifacts before inventing family-wide registries;
- track downgrade and freshness as first-class modifiers instead of folding them into a success bit.
