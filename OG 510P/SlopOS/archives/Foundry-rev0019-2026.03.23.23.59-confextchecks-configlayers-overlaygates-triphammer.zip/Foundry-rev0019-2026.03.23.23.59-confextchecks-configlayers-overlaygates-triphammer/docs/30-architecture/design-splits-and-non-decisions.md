# Design splits and non-decisions

## Splits Foundry is freezing early
- artifact basis versus runtime ground;
- declared world or interface versus observed realization;
- compat membrane versus native semantics;
- restore versus reacquire versus reattach;
- runtime evidence versus trust verdict.

## Non-decisions still open
- whether Foundry needs one common artifact descriptor across OCI, snapshots, and component packages;
- how much host-specific runtime detail should be preserved as first-class archive truth;
- whether confidentiality grounds deserve a distinct subfamily from ordinary VM-backed grounds;
- how to represent degraded but acceptable compat paths without laundering them into native truth;
- where the boundary lies between Foundry continuity evidence and Harbor aftermath receipts.

## Process non-decisions
- do not create a boundary-family map until at least three recurring seams have earned it;
- do not create a giant registry or schema family until at least two specimen tests need it;
- do not let a convenience integration define the cube’s permanent object model.

## rev0018 pressure note
- compatibility witness versus successful attach;
- detachable layer versus native base assimilation;
- structural layer versus backing cargo.
