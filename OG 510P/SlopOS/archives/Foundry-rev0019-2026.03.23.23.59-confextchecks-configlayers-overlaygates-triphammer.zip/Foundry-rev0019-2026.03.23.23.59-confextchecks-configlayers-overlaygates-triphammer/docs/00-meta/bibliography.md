# Bibliography

- **EXT-OCI-IMAGE-SPEC** — OCI Image Specification — https://specs.opencontainers.org/image-spec/
- **EXT-OCI-IMAGE-INDEX** — OCI Image Index Specification — https://specs.opencontainers.org/image-spec/image-index/
- **EXT-OCI-RUNTIME-SPEC** — OCI Runtime Specification — https://github.com/opencontainers/runtime-spec
- **EXT-WASM-WORLDS** — WIT Worlds — https://component-model.bytecodealliance.org/design/worlds.html
- **EXT-WASM-INTERFACES** — WIT Interfaces — https://component-model.bytecodealliance.org/design/interfaces.html
- **EXT-WASM-PACKAGES** — WIT Packages — https://component-model.bytecodealliance.org/design/packages.html
- **EXT-WASM-CANONICAL-ABI** — Canonical ABI — https://component-model.bytecodealliance.org/advanced/canonical-abi.html
- **EXT-WASM-WIT** — WIT overview — https://component-model.bytecodealliance.org/design/wit.html
- **EXT-KATA** — Kata Containers — https://katacontainers.io/
- **EXT-COCO-ATTEST** — Confidential Containers attestation with Trustee — https://confidentialcontainers.org/docs/attestation/
- **EXT-COCO-POLICIES** — Confidential Containers Trustee policies — https://confidentialcontainers.org/docs/attestation/policies/
- **EXT-FIRECRACKER-SNAPSHOT** — Firecracker snapshot support — https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/snapshot-support.md
- **EXT-FIRECRACKER-VMGENID** — Firecracker random for clones / VMGenID — https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/random-for-clones.md
- **EXT-AWS-SNAPSTART-UNIQUENESS** — AWS Lambda SnapStart uniqueness guidance — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-uniqueness.html
- **EXT-OCI-RUNTIME-CONFIG** — OCI Runtime Spec config — https://specs.opencontainers.org/runtime-spec/config/
- **EXT-QUbes-QREXEC** — Qubes qrexec secure communication — https://doc.qubes-os.org/en/latest/developer/services/qrexec.html
- **EXT-FUCHSIA-CAPABILITIES** — Fuchsia component capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities
- **EXT-FUCHSIA-VIRT-ROUTING** — Fuchsia virtualization capability routing RFC — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0210_virtualization_capability_routing
- **EXT-WASI-INTERFACES** — WASI interfaces and component model — https://wasi.dev/interfaces
- **EXT-OCI-IMAGE-INDEX-2025** — OCI Image Index Spec — https://specs.opencontainers.org/image-spec/image-index/
- **EXT-OCI-RUNTIME-BUNDLE-2025** — OCI Runtime Bundle Spec — https://specs.opencontainers.org/runtime-spec/bundle/?v=v1.3.0
- **EXT-WASM-COMPONENT-MODEL** — The WebAssembly Component Model — https://component-model.bytecodealliance.org/
- **EXT-QUBES-QREXEC** — Qubes OS qrexec — https://doc.qubes-os.org/en/latest/developer/services/qrexec.html
- **EXT-LAMBDA-SNAPSTART-RESTORE** — AWS Lambda execution environment lifecycle / SnapStart restore — https://docs.aws.amazon.com/lambda/latest/dg/lambda-runtime-environment.html
- **EXT-COCO-INITDATA** — Confidential Containers Init-Data — https://confidentialcontainers.org/docs/features/initdata/
- **EXT-COCO-INITDATA-2026** — Confidential Containers init-data — https://confidentialcontainers.org/docs/features/initdata/
- **EXT-COCO-POLICIES-2026** — Confidential Containers Trustee policies — https://confidentialcontainers.org/docs/attestation/policies/
- **EXT-FIRECRACKER-NET-CLONES** — Firecracker network connectivity for clones — https://cocalc.com/github/aos/firecracker/blob/main/docs/snapshotting/network-for-clones.md

- **EXT-OCI-REFERRERS** — ORAS artifacts spec, referrers API — https://github.com/oras-project/artifacts-spec/blob/main/manifest-referrers-api.md

- **EXT-WIT-RESOURCES** — Using WIT resources — https://component-model.bytecodealliance.org/using-wit-resources.html
- **EXT-FUCHSIA-CAPABILITY-AVAILABILITY** — Fuchsia capability availability — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/availability
- **EXT-FUCHSIA-VIRT-ROUTING-2025** — Fuchsia RFC 0210, virtualization capability routing — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0210_virtualization_capability_routing
- **EXT-FUCHSIA-CONFIG-CAPABILITIES** — Fuchsia configuration capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/configuration

- **EXT-OCI-11-BLOG-2024** — OCI Image and Distribution Specs v1.1 Releases — https://opencontainers.org/posts/blog/2024-03-13-image-and-distribution-1-1/

- **EXT-AWS-SNAPSTART-HOOKS** — AWS Lambda SnapStart runtime hooks — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-runtime-hooks.html

- **EXT-OCI-DISTRIBUTION-SPEC-REFERRERS** — OCI Distribution Spec referrers behavior — https://github.com/opencontainers/distribution-spec/blob/main/spec.md
- **EXT-WIT-REFERENCE** — WIT reference — https://component-model.bytecodealliance.org/design/wit.html
- **EXT-FUCHSIA-BUILD-COMPONENTS** — Fuchsia component build and source availability — https://fuchsia.dev/fuchsia-src/development/components/build
- **EXT-COCO-DESIGN-OVERVIEW** — Confidential Containers design overview — https://confidentialcontainers.org/docs/architecture/design-overview/

- **EXT-STARGZ-SNAPSHOTTER** — containerd stargz-snapshotter overview — https://github.com/containerd/stargz-snapshotter
- **EXT-NERDCTL-STARGZ** — containerd/nerdctl lazy-pulling with Stargz Snapshotter — https://github.com/containerd/nerdctl/blob/main/docs/stargz.md
- **EXT-COMPOSEFS** — composefs project overview — https://github.com/composefs/composefs
- **EXT-FS-VERITY** — Linux kernel fs-verity documentation — https://docs.kernel.org/filesystems/fsverity.html
- **EXT-NYDUS-DESIGN** — Nydus design overview — https://github.com/dragonflyoss/nydus/blob/master/docs/nydus-design.md
