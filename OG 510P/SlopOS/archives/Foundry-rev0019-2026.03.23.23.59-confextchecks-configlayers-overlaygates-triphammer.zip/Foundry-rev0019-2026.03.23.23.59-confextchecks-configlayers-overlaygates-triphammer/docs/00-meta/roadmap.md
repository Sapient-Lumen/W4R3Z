# Roadmap

Current revision focus (`rev0013`): borrowed handles, restore budgets, and capability-grade honesty.

## Phase 0 — found the language
- freeze the first durable separations;
- keep the assumption, pressure, and question ledgers alive;
- sharpen neighbor boundaries with Helm, Schell, ViewFS, Steward, and the other new cubes.

## Phase 1 — specimen cuts
- design 2–4 specimen flows or artifacts that prove the cube’s vocabulary earns its keep;
- create the first typed receipts / warrants / descriptors / continuity evidence objects, depending on the cube;
- identify which sibling surfaces would consume them.

## Phase 2 — narrow registries
- only after the specimen cuts survive pressure, grow registries, schemas, and promotion criteria.

## Phase 3 — operational proof
- require at least one end-to-end example where Foundry absorbs real outside pressure without flattening a sibling cube.
