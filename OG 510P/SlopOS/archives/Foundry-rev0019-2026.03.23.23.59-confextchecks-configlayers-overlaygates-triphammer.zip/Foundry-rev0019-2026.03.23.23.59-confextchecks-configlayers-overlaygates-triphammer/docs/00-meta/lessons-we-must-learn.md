# Lessons we must learn

Foundry should begin by learning from mistakes that old container, VM, compatibility, and snapshot systems keep making.

## 1) Packaging is not realization
Systems that blur image, bundle, template, runtime config, and live instance make it almost impossible to say what actually ran. Foundry must keep these layers separate.

## 2) “Feels like a container” is not enough truth
Kata-style and confidential-container systems are valuable partly because they reveal how much substrate difference can hide behind a familiar interface. Foundry should not launder that difference away.

## 3) Restore is where overclaiming gets easy
Snapshot and resume systems are useful, but they regularly trip over uniqueness, entropy, time, network state, and stale secrets. Foundry should assume restored continuity is a distinct class of claim, not just “started faster”.

## 4) Interface contracts beat ambient host folklore
Component-model work is compelling because it makes imports, exports, and worlds explicit. Foundry should steal that clarity instead of inheriting giant invisible host assumptions.

## 5) Runtime evidence is not local verdict
Confidential and attested runtimes generate valuable evidence, but the decision about what it means still belongs elsewhere. Foundry should export evidence cleanly and stop there.

## 6) Compat success should stay visibly foreign
A path that “works” through emulation, shims, or helpers can still carry different guarantees. Foundry should keep downgrade posture explicit instead of rewarding every compat success with native status.

## 7) Snapshot files and managers are part of the trust story
Firecracker is an important reminder that snapshot load/resume can be fast while snapshot files and their lifecycle still need separate protection and management. Foundry should not pretend persistence or transport of snapshots is a solved side detail.

## 8) Resume class beats “similar enough” folklore
If a warm image or snapshot is only valid for a reviewed class of hosts, CPU features, or transport surfaces, that class should be explicit. Foundry should prefer reviewed resume classes over best-effort similarity stories.

## 9) Generation witnesses are valuable even when they are not authority
VMGenID-style signals are a useful humility tool: they can tell a guest that continuity changed without claiming that all trust has been re-established.

## rev0005 additions
- Fast restore is not continuity magic; uniqueness, entropy, network assumptions, and freshness-bound evidence may all need reacquire.
- Package format, contract surface, runtime configuration, and live instance lifecycle should stay visibly different even when products want one deployment noun.
- Explicit capability routing and cross-domain policy are more honest than ambient host reachability.

## rev0007 additions
- Smooth cross-ground service use should stay explicit and policy-shaped instead of dissolving into ambient networking or host folklore.
- Generation-change signals are valuable precisely because they force re-evaluation instead of magical continuity.
- Runtime policy inputs and their integrity belong in the story whenever the foreign ground depends on them.
- Foreign-ground capability creation should be routed explicitly into a product or session rather than assumed ambiently.
- Integrity of runtime policy input belongs in the realization story even when confidentiality does not.
- Attestation success and secret/resource release should stay visibly different because they are often governed by different policies.

## rev0008 additions
- Subject-attached sidecars are often healthier than bloating the primary artifact, but attachment is still not the same as completeness or approval.
- Repository-scoped attachment and access control are useful because they keep related material close, not because they prove the foreign realization is acceptable.
- Measured policy input should remain inspectable as part of realization even when the runtime makes the foreign ground feel smooth.
## rev0011 additions
- Subject-attached sidecars are healthier when they stay explicitly attached to a primary artifact instead of impersonating the live realization story.
- Foreign-backed resource handles should remain visibly exterior even when the use-site feels smooth and local.
- Launch/admission success and secret/resource release success should stay visibly different because they are often governed by different policies.

## rev0013 additions
- Resume should expose its repair duties explicitly; otherwise systems overclaim freshness and readiness after restore.
- Foreign power is often variably available across products and configurations, so availability belongs in the meaning model rather than in deployment folklore.
- Nearby attachments need explicit fallback stories; discovery degradation is a first-class truth, not just an implementation detail.


- Smooth access is often a borrowed handle, not a copied local fact.
- Restore obligations need budget and readiness honesty, not hidden amortization folklore.

## rev0014 additions
- Borrowed and owned handle posture matters because a useful foreign thing is not automatically a local thing.
- Availability deserves a floor object: the weakest still-true capability posture after routing or product degradation.
- Restore hooks are a warning that repair work belongs in the public model, not in hidden readiness folklore.

## rev0015 additions
- Missing optional power can be a designed posture, not just a failure, and the model should say so.
- Borrowed foreign handles stay foreign even when the API feels smooth and local.
- Secret or resource release often deserves a separate latch even after attestation and partial readiness succeed.

## rev0016 additions
- Successful launch does not imply full locality when bytes or chunks are still hydrating on demand.
- Prefetch can narrow first-use pain without erasing the remaining locality debt.
- OCI compatibility of packaging does not settle readiness or locality of realization.

## rev0018 additions
- Compatibility should be witnessed explicitly rather than inferred from “it mounted” or “it started”.
- A foreign layer can be useful and still remain detachable, rollback-capable, and visibly non-native.
- Structure and backing cargo often have different locality, sharing, and integrity stories; they should not collapse into one blob.

## rev0018 additions
- Authentic payload bytes and authentic structure are different victories; Foundry should preserve both instead of smearing them into one “verified image” bit.
- Fast start often comes from metadata/bootstrap locality while payload bytes remain elsewhere; bootstrap speed is not full realization.
- Backing stores and Merkle-rooted payload checks are useful, but they still need a separate public story for directory/metadata integrity and later cold reads.

## Pass XIX addition
- Do not collapse configuration overlays into base/runtime cargo. Config-layer compatibility and attach/detach truth deserve their own surface.
