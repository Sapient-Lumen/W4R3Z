# Docs map

- `00-meta/` keeps charter, roadmap, trajectory, bibliography, lessons, datacube evaluation, and research synthesis.
- `30-architecture/` carries the founding seam docs, promotion gates, and non-decisions.
- `90-inspirations/` harvests stealable moves from outside systems and adjacent companion cubes.

Latest additions in rev0007:
- `docs/00-meta/research-synthesis-2026-03-23-pass-vii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-03-23-pass-vii.md`
- `docs/30-architecture/specimen-flow-04-policy-split-attested-foreign-adoption.md`
