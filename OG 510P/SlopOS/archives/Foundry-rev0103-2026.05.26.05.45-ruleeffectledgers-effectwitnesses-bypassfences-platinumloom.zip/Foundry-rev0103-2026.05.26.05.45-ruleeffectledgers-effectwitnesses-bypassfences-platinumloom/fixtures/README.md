# Fixtures

These fixtures make the late Foundry datacube specimens falsifiable.

- `specimen-70-query-result-validation/` exercises query contract, result envelope, and validation witness residue.
- `specimen-71-rollup-aggregation/` exercises hierarchy scope, rollup path, and aggregation guard residue.
- `specimen-72-materialization-reuse/` exercises materialization cut, refresh witness, and reuse fence residue.
- `specimen-73-disclosure-differencing/` exercises disclosure cut, suppression witness, and differencing fence residue.
- `specimen-74-observedness-adjustment/` exercises observation-status card, adjustment witness, and as-observed fence residue.
- `specimen-75-reconciliation-balance/` exercises control-total card, reconciliation witness, and balance fence residue.
- `specimen-76-classification-drift/` exercises classification pin, crosswalk witness, and code-drift fence residue.
- `slopos-support-card-residue-survival/` binds the specimens together in one tiny SlopOS-shaped support table.
- `specimen-78-egress-conformance/` exercises refusal receipt, egress manifest, and conformance gate residue.
- `specimen-79-semantic-regression/` exercises semantic diff manifest, regression lock, and tamper corpus gate residue.
- `specimen-80-semantic-exceptions/` exercises waiver warrant, expiry witness, and exception replay gate residue.
- `specimen-81-consumer-portability/` exercises consumer passport, portability witness, and interpretation gate residue.
- `specimen-82-delegation-boundaries/` exercises delegation warrant, reliance receipt, and transitive-use fence residue.
- `specimen-83-revocation-recall/` exercises revocation notice, recall receipt, and stale-reliance fence residue.
- `specimen-84-remediation-readmission/` exercises remediation packet, replacement witness, and readmission gate residue.
- `specimen-85-distribution-adoption/` exercises distribution manifest, adoption receipt, and orphan-copy fence residue.
- `specimen-86-surface-inventory/` exercises surface inventory sweep, reachability witness, and coverage-gap fence residue.
- `specimen-87-exposure-accounting/` exercises exposure ledger, audience witness, and purpose fence residue.
- `specimen-88-obligation-accounting/` exercises obligation ledger, acknowledgment witness, and obligation-drift fence residue.
- `specimen-89-fulfillment-accounting/` exercises fulfillment receipt, completion witness, and nonfulfillment fence residue.
- `specimen-90-verification-audit/` exercises verification audit, evidence sample, and false-closure fence residue.
- `specimen-91-recheck-drift/` exercises recheck cadence, drift signal, and stale-verification fence residue.
- `specimen-92-escalation-routing/` exercises escalation packet, routing witness, and unresolved-signal fence residue.
- `specimen-93-disposition-resolution/` exercises disposition ledger, resolution witness, and premature-closure fence residue.
- `schema-fixture-coverage/` exercises executable-surface coverage for schemas, fixtures, checkers, and runner registration.
- `specimen-doc-coverage/` exercises promoted-specimen doc/rulebook/fixture/schema/checker/docs-map coverage.
- `negative-case-coverage/` exercises fixture negative-case/rulebook/checker coverage.

The fixtures are deliberately tiny. They exist to catch semantic flattening, anonymous refusal, silent regression, exception drift, consumer interpretation drift, delegated-authority drift, stale-reliance drift, replacement-as-repair drift, readmission-as-distribution drift, distribution-as-inventory drift, inventory-as-exposure-approval drift, exposure-as-obligation-satisfaction drift, acknowledgment-as-fulfillment drift, and completion-as-verification drift, verified-as-still-fresh drift, and schema/fixture/checker coverage drift, and specimen-doc coverage drift, not to model a production warehouse, API gateway, migration framework, audit product, authorization engine, consent system, public-release workflow, compliance framework, or cryptographic proof system.
