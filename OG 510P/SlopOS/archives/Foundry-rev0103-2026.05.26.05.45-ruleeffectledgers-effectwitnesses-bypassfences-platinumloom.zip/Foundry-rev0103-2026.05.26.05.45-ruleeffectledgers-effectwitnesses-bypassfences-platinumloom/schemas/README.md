# Schemas

These schemas are intentionally small v0 validation aids for fixtures, egress tests, regression tests, waiver tests, portability tests, delegation-boundary tests, revocation/recall tests, remediation/readmission tests, distribution/adoption tests, surface-inventory tests, exposure-accounting tests, obligation-accounting tests, fulfillment-accounting tests, verification-audit tests, recheck/drift tests, escalation/routing tests, disposition/resolution tests, rule-promotion tests, rule-collision tests, schema/fixture coverage tests, specimen-doc coverage tests, negative-case coverage tests, lifecycle-transition coverage tests, and rule-surface index tests.

They are **not** Foundry's permanent ontology.

- `foundry-result-envelope-v0.schema.json` validates the compact query/result/validation carrier from specimen 70.
- `foundry-semantic-sidecar-v0.schema.json` validates the compact egress residue sidecar from specimen 77.
- `foundry-egress-manifest-v0.schema.json` validates the compact batch-local ledger of egress attempts from specimen 78.
- `foundry-refusal-receipt-v0.schema.json` validates the compact machine-readable refusal record from specimen 78.
- `foundry-semantic-diff-v0.schema.json` validates the compact revision-to-revision diff carrier from specimen 79.
- `foundry-regression-lock-v0.schema.json` validates the compact fixture-local invariant carrier from specimen 79.
- `foundry-semantic-waiver-v0.schema.json` validates the compact bounded-exception warrant from specimen 80.
- `foundry-exception-replay-gate-v0.schema.json` validates the compact replay trigger carrier from specimen 80.
- `foundry-consumer-passport-v0.schema.json` validates the compact target-consumer purpose/audience/residue carrier from specimen 81.
- `foundry-portability-witness-v0.schema.json` validates the compact cross-consumer residue-portability carrier from specimen 81.
- `foundry-interpretation-gate-v0.schema.json` validates the compact target-consumer recheck/refusal carrier from specimen 81.
- `foundry-delegation-warrant-v0.schema.json` validates the compact bounded semantic-act delegation carrier from specimen 82.
- `foundry-reliance-receipt-v0.schema.json` validates the compact relying-consumer receipt from specimen 82.
- `foundry-transitive-use-fence-v0.schema.json` validates the compact redelegation/widening refusal carrier from specimen 82.
- `foundry-revocation-notice-v0.schema.json` validates the compact carrier-status invalidation notice from specimen 83.
- `foundry-recall-receipt-v0.schema.json` validates the compact consumer acknowledgment/quarantine/replay carrier from specimen 83.
- `foundry-stale-reliance-fence-v0.schema.json` validates the compact stale-use refusal carrier from specimen 83.
- `foundry-remediation-packet-v0.schema.json` validates the compact recalled-carrier remediation envelope from specimen 84.
- `foundry-replacement-witness-v0.schema.json` validates the compact old/new carrier replacement witness from specimen 84.
- `foundry-readmission-gate-v0.schema.json` validates the compact consumer-local reuse gate from specimen 84.
- `foundry-distribution-manifest-v0.schema.json` validates the compact post-readmission distribution envelope from specimen 85.
- `foundry-adoption-receipt-v0.schema.json` validates the compact consumer/surface adoption posture from specimen 85.
- `foundry-orphan-copy-fence-v0.schema.json` validates the compact stale-copy refusal carrier from specimen 85.
- `foundry-surface-inventory-sweep-v0.schema.json` validates the compact scoped discovery carrier from specimen 86.
- `foundry-reachability-witness-v0.schema.json` validates the compact observed-surface/alias carrier from specimen 86.
- `foundry-coverage-gap-fence-v0.schema.json` validates the compact missing/unknown/unreachable-surface fence from specimen 86.
- `foundry-exposure-ledger-v0.schema.json` validates the compact scoped audience/purpose exposure carrier from specimen 87.
- `foundry-audience-witness-v0.schema.json` validates the compact observed audience/surface carrier from specimen 87.
- `foundry-purpose-fence-v0.schema.json` validates the compact audience/purpose/access/public/inherited exposure fence from specimen 87.
- `foundry-obligation-ledger-v0.schema.json` validates the compact post-exposure obligation carrier from specimen 88.
- `foundry-acknowledgment-witness-v0.schema.json` validates the compact consumer-local obligation acknowledgment carrier from specimen 88.
- `foundry-obligation-drift-fence-v0.schema.json` validates the compact dropped/downgraded/missing obligation fence from specimen 88.
- `foundry-fulfillment-receipt-v0.schema.json` validates the compact post-obligation fulfillment closure carrier from specimen 89.
- `foundry-completion-witness-v0.schema.json` validates the compact consumer-local completion evidence carrier from specimen 89.
- `foundry-nonfulfillment-fence-v0.schema.json` validates the compact missing/late/partial/wrong-scope fulfillment fence from specimen 89.
- `foundry-verification-audit-v0.schema.json` validates the compact verification review packet from specimen 90.
- `foundry-evidence-sample-v0.schema.json` validates the compact scoped probe/sample carrier from specimen 90.
- `foundry-false-closure-fence-v0.schema.json` validates the compact contradicted/stale/self-verified closure fence from specimen 90.
- `foundry-recheck-cadence-v0.schema.json` validates the compact post-verification recheck cadence carrier from specimen 91.
- `foundry-drift-signal-v0.schema.json` validates the compact scoped drift/probe signal carrier from specimen 91.
- `foundry-stale-verification-fence-v0.schema.json` validates the compact missed/stale/flapping/paused freshness fence from specimen 91.
- `foundry-schema-fixture-coverage-v0.schema.json` validates the compact schema/fixture/checker coverage manifest from rev0097.

- `foundry-escalation-packet-v0.schema.json` validates the compact post-drift escalation carrier from specimen 92.
- `foundry-routing-witness-v0.schema.json` validates the compact route/delivery/acknowledgment carrier from specimen 92.
- `foundry-unresolved-signal-fence-v0.schema.json` validates the compact missing/misrouted/stale/inhibited/dedupe-loss route fence from specimen 92.
- `foundry-specimen-doc-coverage-v0.schema.json` validates the compact specimen-doc/rulebook/fixture/schema/checker coverage manifest from rev0098.
- `foundry-disposition-ledger-v0.schema.json` validates the compact post-routing disposition carrier from specimen 93.
- `foundry-resolution-witness-v0.schema.json` validates the compact post-routing closure/deferral/transfer witness from specimen 93.
- `foundry-premature-closure-fence-v0.schema.json` validates the compact false-resolution/authority-laundering fence from specimen 93.
- `foundry-negative-case-coverage-v0.schema.json` validates the compact fixture negative-case coverage manifest from rev0099.
- `foundry-precedent-ledger-v0.schema.json` validates the compact post-disposition precedent carrier from specimen 94.
- `foundry-rule-promotion-witness-v0.schema.json` validates the compact local rule-promotion evidence carrier from specimen 94.
- `foundry-overgeneralization-fence-v0.schema.json` validates the compact precedent-widening refusal carrier from specimen 94.
- `foundry-lifecycle-transition-coverage-v0.schema.json` validates the compact late-specimen handoff coverage manifest from rev0100.
- `foundry-rule-collision-ledger-v0.schema.json` validates the compact promoted-rule overlap carrier from specimen 95.
- `foundry-precedence-witness-v0.schema.json` validates the compact scoped precedence evidence carrier from specimen 95.
- `foundry-ambiguity-fence-v0.schema.json` validates the compact unresolved/contradictory rule-overlap refusal carrier from specimen 95.
- `foundry-rule-surface-index-v0.schema.json` validates the compact rulebook/rule/checker index manifest from rev0101.

A later revision may replace or retire them if specimen pressure shows the shape is wrong.
