#!/usr/bin/env python3
"""Check Foundry remediation/readmission fixtures.

Specimen 84 is about replacing and re-admitting recalled semantic carriers
without turning Foundry into repair custody, external remediation status,
audit approval, policy authorization, or source truth.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-READMIT-001-REMEDIATION-PACKET",
    "R-READMIT-002-REVOCATION-LINKAGE",
    "R-READMIT-003-QUARANTINE-PERSISTENCE",
    "R-READMIT-004-REPLACEMENT-WITNESS",
    "R-READMIT-005-HISTORY-PRESERVATION",
    "R-READMIT-006-GATE-REPLAY-BEFORE-READMISSION",
    "R-READMIT-007-CONSUMER-SCOPED-READMISSION",
    "R-READMIT-008-PARTIAL-REPAIR-NO-OVERCLAIM",
    "R-READMIT-009-AUTHORITY-LAUNDERING-FENCE",
    "R-READMIT-010-REPLACEMENT-REJECTION",
    "R-READMIT-011-NO-SILENT-READMISSION",
    "R-READMIT-012-REOPEN-ON-NEW-NOTICE",
}

REQUIRED_FAILURE_CODES = {
    "remediation_packet_required",
    "revocation_linkage_required",
    "replacement_witness_required",
    "readmission_gate_required",
    "quarantine_release_requires_gate",
    "replacement_digest_mismatch_refused",
    "old_history_rewrite_refused",
    "source_truth_laundering_refused",
    "missing_replayed_gate_refused",
    "consumer_scope_mismatch_refused",
    "active_revocation_unresolved_refused",
    "partial_repair_overclaim_refused",
    "candidate_without_witness_refused",
    "repair_action_without_evidence_refused",
    "readmission_as_harbor_remediation_refused",
    "readmission_as_helm_repair_completion_refused",
    "silent_readmission_refused",
    "new_notice_reopens_packet",
}

PACKET_STATUSES = {"open", "quarantined", "partial", "blocked", "readmitted", "retired"}
WITNESS_STATUSES = {"candidate", "accepted", "rejected", "partial"}
GATE_RESULTS = {"admitted", "refused", "quarantined", "conditional"}
AUTHORITY_WORDS = {"truth", "verdict", "approval", "audit_opinion", "permission", "remediation", "repair", "risk_acceptance"}


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("remediation_packets"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No remediation_packets fixture found for specimen 84.")

packet_count = 0
witness_count = 0
accepted_witnesses = 0
rejected_witnesses = 0
readmission_gates = 0
admitted_gates = 0
refused_gates = 0
conditional_gates = 0
reopened_packets = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    consumer_ids = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    notice_ids = {n.get("notice_id") for n in data.get("revocation_notice_refs", []) if n.get("notice_id")}
    packets = data.get("remediation_packets") or []
    witnesses = data.get("replacement_witnesses") or []
    gates = data.get("readmission_gates") or []

    if not packets:
        errors.append(f"{rel}: remediation_packets must be non-empty")

    packets_by_id = {}
    for packet in packets:
        packet_count += 1
        pid = packet.get("packet_id", "<missing>")
        if pid in packets_by_id:
            errors.append(f"{rel}: duplicate packet_id {pid}")
        packets_by_id[pid] = packet
        if packet.get("packet_family") != "foundry_remediation_packet_v0":
            errors.append(f"{rel}: packet {pid} has wrong packet_family")
        if not str(packet.get("packet_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: packet {pid} missing sha256 packet_digest")
        if packet.get("packet_status") not in PACKET_STATUSES:
            errors.append(f"{rel}: packet {pid} has unknown packet_status {packet.get('packet_status')!r}")
        if not parse_time(packet.get("opened_at")):
            errors.append(f"{rel}: packet {pid} missing/unparsable opened_at")
        triggers = set(packet.get("triggered_by_notices") or [])
        if not triggers:
            errors.append(f"{rel}: packet {pid} missing triggered_by_notices")
        if notice_ids and triggers - notice_ids:
            errors.append(f"{rel}: packet {pid} references unknown notices: {', '.join(sorted(triggers - notice_ids))}")
        for key in ["affected_carriers", "affected_consumers", "quarantined_artifacts", "repair_actions", "required_witnesses", "required_gates", "authority_boundaries"]:
            if not isinstance(packet.get(key), list) or not packet.get(key):
                errors.append(f"{rel}: packet {pid} missing {key}")
        affected = set(packet.get("affected_consumers") or [])
        if consumer_ids and affected - consumer_ids:
            errors.append(f"{rel}: packet {pid} names unknown affected consumers: {', '.join(sorted(affected - consumer_ids))}")
        boundary_text = " ".join(packet.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: packet {pid} must state negative authority boundaries")
        if any("reopen" in a for a in packet.get("repair_actions", [])):
            reopened_packets += 1

    witnesses_by_packet = {}
    accepted_artifacts_by_packet = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if witness.get("witness_family") != "foundry_replacement_witness_v0":
            errors.append(f"{rel}: replacement witness {wid} has wrong witness_family")
        pid = witness.get("packet_id")
        if pid not in packets_by_id:
            errors.append(f"{rel}: replacement witness {wid} references missing packet {pid}")
        witnesses_by_packet.setdefault(pid, []).append(witness)
        if not str(witness.get("old_artifact_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: replacement witness {wid} missing sha256 old_artifact_digest")
        if not str(witness.get("replacement_artifact_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: replacement witness {wid} missing sha256 replacement_artifact_digest")
        status = witness.get("replacement_status")
        if status not in WITNESS_STATUSES:
            errors.append(f"{rel}: replacement witness {wid} has unknown replacement_status {status!r}")
        if status == "accepted":
            accepted_witnesses += 1
            accepted_artifacts_by_packet.setdefault(pid, set()).add(witness.get("replacement_artifact_id"))
        if status == "rejected":
            rejected_witnesses += 1
        for key in ["old_artifact_family", "old_artifact_id", "replacement_artifact_family", "replacement_artifact_id", "correction_classes", "evidence_refs", "gates_replayed", "non_promises"]:
            if not witness.get(key):
                errors.append(f"{rel}: replacement witness {wid} missing {key}")
        if witness.get("old_history_preserved") is not True:
            errors.append(f"{rel}: replacement witness {wid} must preserve old history")
        if witness.get("source_rows_rewritten") is not False:
            errors.append(f"{rel}: replacement witness {wid} must not rewrite source rows")
        non_promises = " ".join(witness.get("non_promises") or []).lower()
        if not any(word in non_promises for word in ["truth", "verdict", "opinion", "remediation", "repair", "readmitted"]):
            errors.append(f"{rel}: replacement witness {wid} must include authority/refusal non_promises")
        if status in {"accepted", "partial"} and not witness.get("residual_risks"):
            errors.append(f"{rel}: replacement witness {wid} must name residual_risks when accepted/partial")

    gate_results_by_packet = {}
    for gate in gates:
        readmission_gates += 1
        gid = gate.get("gate_id", "<missing>")
        if gate.get("gate_family") != "foundry_readmission_gate_v0":
            errors.append(f"{rel}: readmission gate {gid} has wrong gate_family")
        pid = gate.get("packet_id")
        if pid not in packets_by_id:
            errors.append(f"{rel}: readmission gate {gid} references missing packet {pid}")
        cid = gate.get("consumer_id")
        if not cid:
            errors.append(f"{rel}: readmission gate {gid} missing consumer_id")
        elif consumer_ids and cid not in consumer_ids:
            errors.append(f"{rel}: readmission gate {gid} names unknown consumer {cid}")
        packet = packets_by_id.get(pid, {})
        if cid and packet.get("affected_consumers") and cid not in packet.get("affected_consumers"):
            # adjacent observers are allowed only if the gate refuses; admitted/conditional must be scoped to affected consumers
            if gate.get("gate_result") in {"admitted", "conditional"}:
                errors.append(f"{rel}: readmission gate {gid} admits consumer {cid} outside packet scope")
        result = gate.get("gate_result")
        if result not in GATE_RESULTS:
            errors.append(f"{rel}: readmission gate {gid} has unknown gate_result {result!r}")
        gate_results_by_packet.setdefault(pid, set()).add(result)
        if result == "admitted":
            admitted_gates += 1
            if gate.get("quarantine_release") is not True:
                errors.append(f"{rel}: admitted gate {gid} must release quarantine explicitly")
            if not gate.get("admitted_uses"):
                errors.append(f"{rel}: admitted gate {gid} must name admitted_uses")
        if result == "refused":
            refused_gates += 1
            if not gate.get("failure_code"):
                errors.append(f"{rel}: refused gate {gid} must include failure_code")
            if gate.get("quarantine_release") is not False:
                errors.append(f"{rel}: refused gate {gid} must keep quarantine_release=false")
        if result == "conditional":
            conditional_gates += 1
            if gate.get("quarantine_release") is not False:
                errors.append(f"{rel}: conditional gate {gid} must not fully release quarantine")
        for key in ["candidate_artifacts", "required_inputs", "replayed_rules", "blocked_uses", "refused_inferences"]:
            if not isinstance(gate.get(key), list) or not gate.get(key):
                errors.append(f"{rel}: readmission gate {gid} missing {key}")
        if gate.get("notice_status_checked") is not True:
            errors.append(f"{rel}: readmission gate {gid} must set notice_status_checked=true")
        if not any(rule.startswith("R-READMIT-") for rule in gate.get("replayed_rules", [])):
            errors.append(f"{rel}: readmission gate {gid} must replay at least one R-READMIT rule")
        refused_text = " ".join(gate.get("refused_inferences") or []).lower()
        if not any(word in refused_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: readmission gate {gid} must refuse at least one authority-like inference")

    for pid, packet in packets_by_id.items():
        if packet.get("packet_status") == "readmitted":
            if not any(w.get("replacement_status") == "accepted" for w in witnesses_by_packet.get(pid, [])):
                errors.append(f"{rel}: readmitted packet {pid} needs an accepted replacement witness")
            if "admitted" not in gate_results_by_packet.get(pid, set()):
                errors.append(f"{rel}: readmitted packet {pid} needs at least one admitted readmission gate")
        if packet.get("packet_status") in {"blocked", "quarantined"}:
            if "refused" not in gate_results_by_packet.get(pid, set()) and not any(w.get("replacement_status") == "rejected" for w in witnesses_by_packet.get(pid, [])):
                errors.append(f"{rel}: blocked/quarantined packet {pid} needs a refused gate or rejected witness")
        if packet.get("packet_status") == "partial" and "conditional" not in gate_results_by_packet.get(pid, set()):
            errors.append(f"{rel}: partial packet {pid} needs a conditional gate")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if packet_count < 1:
    errors.append("Specimen 84 needs at least one remediation packet.")
if accepted_witnesses < 1 or rejected_witnesses < 1:
    errors.append("Specimen 84 needs accepted and rejected replacement witness examples.")
if admitted_gates < 1 or refused_gates < 1 or conditional_gates < 1:
    errors.append("Specimen 84 needs admitted, refused, and conditional readmission gate examples.")
if reopened_packets < 1:
    errors.append("Specimen 84 needs a reopened remediation packet example.")

rulebook = ROOT / "docs/30-architecture/remediation-readmission-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing remediation/readmission rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = sorted(rule for rule in REQUIRED_RULES if rule not in text)
    if missing_rules:
        errors.append("Remediation/readmission rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry remediation/readmission check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry remediation/readmission check passed for {len(fixtures)} fixture file(s), {packet_count} remediation packet(s), {witness_count} replacement witness(es), and {readmission_gates} readmission gate(s)")
