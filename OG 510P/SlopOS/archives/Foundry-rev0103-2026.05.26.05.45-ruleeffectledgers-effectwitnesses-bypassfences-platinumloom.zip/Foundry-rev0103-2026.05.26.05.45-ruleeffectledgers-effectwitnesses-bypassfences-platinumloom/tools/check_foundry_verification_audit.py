#!/usr/bin/env python3
"""Check Foundry verification-audit fixtures.

Specimen 90 proves that Foundry can distinguish completion evidence from
verified completion evidence without becoming an external audit product,
compliance framework, cryptographic proof system, supply-chain verifier,
authorization system, custody model, repair workflow, or sibling-cube verdict.
"""
from pathlib import Path
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover - direct execution fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

REQUIRED_FAILURE_CODES = {
    "verification_audit_required",
    "source_fulfillment_required",
    "evidence_sample_required",
    "required_sample_missing_refused",
    "completion_as_verification_refused",
    "self_verification_unfenced_refused",
    "verifier_conflict_refused",
    "audit_scope_mismatch_refused",
    "sample_scope_mismatch_refused",
    "stale_sample_accepted_refused",
    "contradiction_ignored_refused",
    "partial_audit_as_passed_refused",
    "sample_digest_mismatch_refused",
    "public_link_verification_unfenced_refused",
    "inherited_verification_unbound_refused",
    "verification_as_authorization_refused",
    "verification_as_legal_compliance_refused",
    "verification_as_audit_opinion_refused",
    "verification_as_cryptographic_proof_refused",
    "verification_sibling_verdict_laundering_refused",
    "harness_coverage_drift_refused",
}

AUDIT_STATUSES = {"passed", "partial", "blocked", "pending", "superseded", "retired"}
SAMPLE_STATES = {"verified", "contradicted", "inconclusive", "stale", "unavailable", "quarantined", "superseded"}
RISKY_SAMPLE_STATES = SAMPLE_STATES - {"verified"}
FENCE_REASONS = {
    "contradicted_completion",
    "contradicted_no_reexport",
    "contradicted_recheck_timing",
    "digest_mismatch",
    "inconclusive_boundary_sample",
    "missing_sample",
    "public_link_failure",
    "sampling_scope_gap",
    "stale_inherited_scope",
    "unavailable_recall_route",
    "verifier_conflict",
}
AUTHORITY_WORDS = {
    "authorization", "legal", "compliance", "audit", "opinion", "proof", "verdict",
    "custody", "release", "deletion", "retention", "repair", "finality", "truth"
}

fixture_paths = sorted(FIXTURES.glob("specimen-90-verification-audit/fixture.json"))
if not fixture_paths:
    print("No specimen 90 verification-audit fixture found")
    sys.exit(1)

errors = []
fixture_count = audit_count = sample_count = fence_count = 0
status_counts = {status: 0 for status in AUDIT_STATUSES}
sample_state_counts = {state: 0 for state in SAMPLE_STATES}

for fixture_path in fixture_paths:
    fixture_count += 1
    rel = fixture_path.relative_to(ROOT)
    fixture = load_json(fixture_path)
    if fixture.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if fixture.get("specimen_id") != "90":
        errors.append(f"{rel}: specimen_id must be 90")

    consumers = {item.get("consumer_id") for item in fixture.get("consumer_refs") or []}
    source_refs = {item.get("fulfillment_receipt_id"): item for item in fixture.get("source_fulfillment_refs") or []}
    source_receipts = set(source_refs)
    source_completions = {cid for item in source_refs.values() for cid in item.get("completion_witness_ids") or []}
    source_fences = {fid for item in source_refs.values() for fid in item.get("nonfulfillment_fence_ids") or []}
    source_carriers = {cid for item in source_refs.values() for cid in item.get("carrier_ids") or []}
    source_obligations = {oid for item in source_refs.values() for oid in item.get("obligation_ids") or []}
    carrier_refs = {item.get("carrier_id"): item for item in fixture.get("carrier_refs") or []}

    audits = fixture.get("verification_audits") or []
    samples = fixture.get("evidence_samples") or []
    fences = fixture.get("false_closure_fences") or []
    if not audits:
        errors.append(f"{rel}: missing verification_audits")
    if not samples:
        errors.append(f"{rel}: missing evidence_samples")
    if not fences:
        errors.append(f"{rel}: missing false_closure_fences")

    negative_codes = {case.get("must_fail_with") or case.get("failure_code") for case in fixture.get("negative_cases") or []}
    missing_codes = sorted(REQUIRED_FAILURE_CODES - negative_codes)
    if missing_codes:
        errors.append(f"{rel}: missing required negative cases: {', '.join(missing_codes)}")

    audit_by_id = {}
    audit_windows = {}
    required_samples = {}
    required_fences = {}
    for audit in audits:
        audit_count += 1
        aid = audit.get("audit_id", "<missing>")
        if aid in audit_by_id:
            errors.append(f"{rel}: duplicate audit_id {aid}")
        audit_by_id[aid] = audit
        if audit.get("audit_family") != "foundry_verification_audit_v0":
            errors.append(f"{rel}: audit {aid} has wrong audit_family")
        if not require_sha256(audit.get("audit_digest")):
            errors.append(f"{rel}: audit {aid} missing sha256 audit_digest")
        status = audit.get("audit_status")
        if status not in AUDIT_STATUSES:
            errors.append(f"{rel}: audit {aid} has unknown status {status!r}")
        else:
            status_counts[status] += 1
        initiated = parse_time(audit.get("initiated_at"))
        completed = parse_time(audit.get("completed_at"))
        if not initiated or not completed or not initiated <= completed:
            errors.append(f"{rel}: audit {aid} has invalid initiated/completed window")
        else:
            audit_windows[aid] = (initiated, completed)
        for key in ["source_fulfillment_receipt_ids", "source_completion_witness_ids", "carrier_ids", "verification_scope", "sampling_basis", "verifier", "required_evidence_samples", "authority_boundaries"]:
            if not audit.get(key):
                errors.append(f"{rel}: audit {aid} missing {key}")
        if status in {"partial", "blocked"} and not audit.get("required_false_closure_fences"):
            errors.append(f"{rel}: partial/blocked audit {aid} must require false-closure fences")
        for rid in audit.get("source_fulfillment_receipt_ids") or []:
            if rid not in source_receipts:
                errors.append(f"{rel}: audit {aid} references unknown source fulfillment receipt {rid}")
        for cid in audit.get("source_completion_witness_ids") or []:
            if cid not in source_completions:
                errors.append(f"{rel}: audit {aid} references unknown source completion witness {cid}")
        for fid in audit.get("source_nonfulfillment_fence_ids") or []:
            if fid not in source_fences:
                errors.append(f"{rel}: audit {aid} references unknown source nonfulfillment fence {fid}")
        for carrier_id in audit.get("carrier_ids") or []:
            if carrier_id not in carrier_refs or carrier_id not in source_carriers:
                errors.append(f"{rel}: audit {aid} references unknown carrier {carrier_id}")
        scope = audit.get("verification_scope") or {}
        unknown_consumers = set(scope.get("consumers") or []) - consumers
        if unknown_consumers:
            errors.append(f"{rel}: audit {aid} scopes unknown consumers: {', '.join(sorted(unknown_consumers))}")
        unknown_obligations = set(scope.get("obligations") or []) - source_obligations
        if unknown_obligations:
            errors.append(f"{rel}: audit {aid} scopes unknown obligations: {', '.join(sorted(unknown_obligations))}")
        basis = audit.get("sampling_basis") or {}
        for key in ["method", "population_refs", "sample_size", "selection_rule", "blocked_inferences"]:
            if not basis.get(key):
                errors.append(f"{rel}: audit {aid} sampling_basis missing {key}")
        if basis.get("non_exhaustive") is not True:
            errors.append(f"{rel}: audit {aid} must state non_exhaustive=true")
        verifier = audit.get("verifier") or {}
        if not verifier.get("verifier_id") or not verifier.get("independence_basis"):
            errors.append(f"{rel}: audit {aid} verifier missing id or independence_basis")
        boundary_text = " ".join(audit.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: audit {aid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: audit {aid} authority boundaries should name refused authority")
        required_samples[aid] = set(audit.get("required_evidence_samples") or [])
        required_fences[aid] = set(audit.get("required_false_closure_fences") or [])

    fence_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate false closure fence_id {fid}")
        fence_by_id[fid] = fence
        aid = fence.get("audit_id")
        if fence.get("fence_family") != "foundry_false_closure_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if aid not in audit_by_id:
            errors.append(f"{rel}: fence {fid} references missing audit {aid}")
        if fence.get("fence_reason") not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {fence.get('fence_reason')!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        for cid in fence.get("affected_completion_witness_ids") or []:
            if cid not in source_completions:
                errors.append(f"{rel}: fence {fid} references unknown completion witness {cid}")
        for key in ["affected_completion_witness_ids", "blocked_uses", "required_replay_or_clearance", "authority_boundaries"]:
            if not fence.get(key):
                errors.append(f"{rel}: fence {fid} missing {key}")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must name refused authority boundary")

    samples_by_id = {}
    samples_by_audit = {}
    for sample in samples:
        sample_count += 1
        sid = sample.get("sample_id", "<missing>")
        if sid in samples_by_id:
            errors.append(f"{rel}: duplicate evidence sample_id {sid}")
        samples_by_id[sid] = sample
        aid = sample.get("audit_id")
        samples_by_audit.setdefault(aid, set()).add(sid)
        if sample.get("sample_family") != "foundry_evidence_sample_v0":
            errors.append(f"{rel}: sample {sid} has wrong sample_family")
        if aid not in audit_by_id:
            errors.append(f"{rel}: sample {sid} references missing audit {aid}")
            audit = {}
            scope = {}
        else:
            audit = audit_by_id[aid]
            scope = audit.get("verification_scope") or {}
        if not require_sha256(sample.get("sample_digest")):
            errors.append(f"{rel}: sample {sid} missing sha256 sample_digest")
        state = sample.get("sample_state")
        if state not in SAMPLE_STATES:
            errors.append(f"{rel}: sample {sid} has unknown sample_state {state!r}")
        else:
            sample_state_counts[state] += 1
        observed = parse_time(sample.get("observed_at"))
        if not observed:
            errors.append(f"{rel}: sample {sid} missing/unparsable observed_at")
        elif aid in audit_windows:
            initiated, completed = audit_windows[aid]
            if not initiated <= observed <= completed:
                errors.append(f"{rel}: sample {sid} observed outside audit window")
        if sample.get("completion_witness_id") not in source_completions:
            errors.append(f"{rel}: sample {sid} references unknown completion witness")
        if sample.get("fulfillment_id") not in source_obligations:
            errors.append(f"{rel}: sample {sid} references unknown fulfillment_id")
        if sample.get("consumer_id") not in consumers:
            errors.append(f"{rel}: sample {sid} names unknown consumer")
        if audit:
            if sample.get("consumer_id") not in set(scope.get("consumers") or []):
                errors.append(f"{rel}: sample {sid} consumer outside audit scope")
            if sample.get("surface_id") not in set(scope.get("surfaces") or []):
                errors.append(f"{rel}: sample {sid} surface outside audit scope")
            if sample.get("audience_id") not in set(scope.get("audiences") or []):
                errors.append(f"{rel}: sample {sid} audience outside audit scope")
            if sample.get("fulfillment_id") not in set(scope.get("obligations") or []):
                errors.append(f"{rel}: sample {sid} obligation outside audit scope")
        carrier_id = sample.get("carrier_id")
        if carrier_id:
            if carrier_id not in carrier_refs:
                errors.append(f"{rel}: sample {sid} references unknown carrier {carrier_id}")
            elif sample.get("carrier_digest") != carrier_refs[carrier_id].get("carrier_digest"):
                errors.append(f"{rel}: sample {sid} carrier digest mismatch")
        for key in ["probe_basis", "verifier_id", "completion_author_id", "evidence_refs", "residue_checked", "blocked_uses", "non_promises"]:
            if not sample.get(key):
                errors.append(f"{rel}: sample {sid} missing {key}")
        if sample.get("verifier_id") == sample.get("completion_author_id") and not sample.get("false_closure_fence_refs"):
            errors.append(f"{rel}: self-verifying sample {sid} must reference a false-closure fence")
        if state in RISKY_SAMPLE_STATES and not sample.get("false_closure_fence_refs"):
            errors.append(f"{rel}: risky sample {sid} must reference a false-closure fence")
        if sample.get("contradictions") and not sample.get("false_closure_fence_refs"):
            errors.append(f"{rel}: sample {sid} has contradictions without fence refs")
        for fid in sample.get("false_closure_fence_refs") or []:
            if fid not in fence_by_id:
                errors.append(f"{rel}: sample {sid} references unknown false-closure fence {fid}")
        np = " ".join(sample.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: sample {sid} must include authority/refusal non_promises")

    for aid, needed in required_samples.items():
        observed = samples_by_audit.get(aid, set())
        missing = sorted(needed - observed)
        if missing:
            errors.append(f"{rel}: audit {aid} missing required evidence samples: {', '.join(missing)}")
    for aid, needed in required_fences.items():
        fence_ids_for_audit = {fid for fid, fence in fence_by_id.items() if fence.get("audit_id") == aid}
        missing = sorted(needed - fence_ids_for_audit)
        if missing:
            errors.append(f"{rel}: audit {aid} missing required false-closure fences: {', '.join(missing)}")

    if not fixture.get("harness_audit"):
        errors.append(f"{rel}: missing harness_audit section")
    else:
        harness = fixture["harness_audit"]
        checked = set(harness.get("checked_surfaces") or [])
        for surface in [
            "tools/check_foundry_all.py",
            "tools/foundry_checklib.py",
            "tools/check_foundry_verification_audit.py",
            "docs/30-architecture/specimen-flow-index.md",
            "ARCHIVE_INDEX.md",
        ]:
            if surface not in checked:
                errors.append(f"{rel}: harness audit missing checked surface {surface}")
        if not any("not_audit" in item or "not_test" in item for item in harness.get("blocked_inferences") or []):
            errors.append(f"{rel}: harness audit must refuse audit/test-certification inference")

if status_counts["passed"] < 1 or status_counts["partial"] < 1 or status_counts["blocked"] < 1:
    errors.append("specimen 90 must include passed, partial, and blocked verification audits")
for state in ["verified", "contradicted", "inconclusive", "stale", "unavailable", "quarantined"]:
    if sample_state_counts[state] < 1:
        errors.append(f"specimen 90 must include at least one {state} evidence sample")

fail(errors)
print(
    f"Foundry verification audit check passed for {fixture_count} fixture file(s), "
    f"{audit_count} verification audit(s), {sample_count} evidence sample(s), "
    f"and {fence_count} false-closure fence(s)"
)
