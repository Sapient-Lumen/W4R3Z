#!/usr/bin/env python3
"""Check Foundry obligation-accounting fixtures.

Specimen 88 proves that Foundry can account for semantic obligations after
exposure without becoming a rights-expression language, authorization engine,
privacy-law framework, consent registry, public-release workflow, deletion
system, audit product, custody model, or sibling-cube verdict.
"""
from pathlib import Path
from datetime import datetime
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_FAILURE_CODES = {
    "obligation_ledger_required",
    "source_exposure_required",
    "obligation_pin_required",
    "acknowledgment_witness_required",
    "required_acknowledgment_missing_refused",
    "sidecar_requirement_dropped_refused",
    "classification_pin_requirement_dropped_refused",
    "recall_route_missing_refused",
    "no_reexport_downgraded_refused",
    "acknowledgment_scope_mismatch_refused",
    "wrong_consumer_acknowledgment_refused",
    "partial_ack_as_full_refused",
    "obligation_expired_without_recheck_refused",
    "public_link_obligation_unfenced_refused",
    "inherited_obligation_unbound_refused",
    "obligation_as_authorization_refused",
    "obligation_as_legal_compliance_refused",
    "obligation_as_consent_refused",
    "acknowledgment_digest_mismatch_refused",
    "waiver_without_replay_refused",
    "sibling_verdict_laundering_refused",
}

LEDGER_STATUSES = {"complete", "partial", "blocked", "superseded", "retired"}
OBLIGATION_TYPES = {"carry_residue", "display_warning", "no_reexport", "recall_route", "recheck_before_reuse", "quarantine", "preserve_boundary"}
OBLIGATION_STATUSES = {"active", "partial", "blocked", "retired"}
ACK_STATES = {"acknowledged", "partial", "refused", "quarantined", "missing", "expired", "superseded"}
FENCE_TYPES = {"acknowledgment_missing", "obligation_dropped", "obligation_downgraded", "recall_route_missing", "no_reexport_downgraded", "classification_pin_dropped", "sidecar_detached", "observation_status_hidden", "consumer_scope_mismatch", "public_link_obligation", "inherited_obligation_unbound", "expired_obligation", "sibling_boundary_laundering", "waiver_without_replay"}
FENCE_RESULTS = {"blocked", "quarantined", "recheck_required", "monitor_only", "retired_as_history"}
RISKY_ACK_STATES = {"partial", "refused", "quarantined", "missing", "expired"}
AUTHORITY_WORDS = {"authorization", "permission", "consent", "policy", "privacy", "legal", "verdict", "custody", "release", "deletion", "proof", "truth", "audit", "compliance"}


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("obligation_ledgers"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No obligation_ledgers fixture found for specimen 88.")

ledger_count = 0
ack_count = 0
fence_count = 0
complete_ledgers = partial_ledgers = blocked_ledgers = 0
acknowledged = partial_ack = refused_ack = quarantined_ack = missing_ack = 0
blocked_fences = quarantined_fences = recheck_fences = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    consumer_ids = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    carrier_refs = {c.get("carrier_id"): c for c in data.get("carrier_refs", []) if c.get("carrier_id")}
    exposure_refs = {e.get("ledger_id"): e for e in data.get("source_exposure_refs", []) if e.get("ledger_id")}
    source_audience_ids = set()
    source_purpose_fence_ids = set()
    source_surfaces = set()
    for exp in data.get("source_exposure_refs", []):
        source_audience_ids.update(exp.get("audience_witness_ids") or [])
        source_purpose_fence_ids.update(exp.get("purpose_fence_ids") or [])
        source_surfaces.update(exp.get("surface_ids") or [])

    ledgers = data.get("obligation_ledgers") or []
    acks = data.get("acknowledgment_witnesses") or []
    fences = data.get("obligation_drift_fences") or []
    if not ledgers:
        errors.append(f"{rel}: obligation_ledgers must be non-empty")

    ledgers_by_id = {}
    ledger_windows = {}
    obligations_by_ledger = {}
    required_acks_by_ledger = {}
    required_fences_by_ledger = {}

    for ledger in ledgers:
        ledger_count += 1
        lid = ledger.get("ledger_id", "<missing>")
        if lid in ledgers_by_id:
            errors.append(f"{rel}: duplicate ledger_id {lid}")
        ledgers_by_id[lid] = ledger
        if ledger.get("ledger_family") != "foundry_obligation_ledger_v0":
            errors.append(f"{rel}: ledger {lid} has wrong ledger_family")
        if not str(ledger.get("ledger_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: ledger {lid} missing sha256 ledger_digest")
        status = ledger.get("ledger_status")
        if status not in LEDGER_STATUSES:
            errors.append(f"{rel}: ledger {lid} has unknown ledger_status {status!r}")
        if status == "complete": complete_ledgers += 1
        if status == "partial": partial_ledgers += 1
        if status == "blocked": blocked_ledgers += 1
        issued = parse_time(ledger.get("issued_at"))
        completed = parse_time(ledger.get("completed_at"))
        if not issued or not completed or not issued <= completed:
            errors.append(f"{rel}: ledger {lid} has invalid issue/completion window")
        else:
            ledger_windows[lid] = (issued, completed)
        for key in ["source_exposure_ledger_ids", "source_audience_witness_ids", "carrier_ids", "obligation_scope", "obligations", "required_acknowledgment_witnesses", "authority_boundaries"]:
            if not ledger.get(key):
                errors.append(f"{rel}: ledger {lid} missing {key}")
        if status in {"partial", "blocked"} and not ledger.get("source_purpose_fence_ids"):
            errors.append(f"{rel}: partial/blocked ledger {lid} must link source purpose fences")
        if status in {"partial", "blocked"} and not ledger.get("required_obligation_drift_fences"):
            errors.append(f"{rel}: partial/blocked ledger {lid} must require drift fences")
        for eid in ledger.get("source_exposure_ledger_ids") or []:
            if eid not in exposure_refs:
                errors.append(f"{rel}: ledger {lid} references unknown source exposure ledger {eid}")
        for awid in ledger.get("source_audience_witness_ids") or []:
            if awid not in source_audience_ids:
                errors.append(f"{rel}: ledger {lid} references unknown source audience witness {awid}")
        for pfid in ledger.get("source_purpose_fence_ids") or []:
            if pfid not in source_purpose_fence_ids:
                errors.append(f"{rel}: ledger {lid} references unknown source purpose fence {pfid}")
        for carrier_id in ledger.get("carrier_ids") or []:
            if carrier_id not in carrier_refs:
                errors.append(f"{rel}: ledger {lid} references unknown carrier {carrier_id}")
        scope = ledger.get("obligation_scope") or {}
        unknown_consumers = set(scope.get("consumers") or []) - consumer_ids
        if unknown_consumers:
            errors.append(f"{rel}: ledger {lid} scopes unknown consumers: {', '.join(sorted(unknown_consumers))}")
        unknown_surfaces = set(scope.get("surfaces") or []) - source_surfaces
        if unknown_surfaces:
            errors.append(f"{rel}: ledger {lid} scopes surfaces not seen in source exposure refs: {', '.join(sorted(unknown_surfaces))}")
        obligations = {}
        for obl in ledger.get("obligations") or []:
            oid = obl.get("obligation_id")
            if not oid:
                errors.append(f"{rel}: ledger {lid} has obligation without id")
                continue
            if oid in obligations:
                errors.append(f"{rel}: ledger {lid} duplicates obligation {oid}")
            obligations[oid] = obl
            if obl.get("obligation_type") not in OBLIGATION_TYPES:
                errors.append(f"{rel}: obligation {oid} has unknown type {obl.get('obligation_type')!r}")
            if obl.get("obligation_status") not in OBLIGATION_STATUSES:
                errors.append(f"{rel}: obligation {oid} has unknown status {obl.get('obligation_status')!r}")
            for key in ["trigger", "required_residue", "applies_to", "blocked_inferences"]:
                if not obl.get(key):
                    errors.append(f"{rel}: obligation {oid} missing {key}")
            applies = obl.get("applies_to") or {}
            if not set(applies.get("surfaces") or []) <= set(scope.get("surfaces") or []):
                errors.append(f"{rel}: obligation {oid} applies to surface outside ledger scope")
            if not set(applies.get("audiences") or []) <= set(scope.get("audiences") or []):
                errors.append(f"{rel}: obligation {oid} applies to audience outside ledger scope")
            if not set(applies.get("purposes") or []) <= set(scope.get("purpose_classes") or []):
                errors.append(f"{rel}: obligation {oid} applies to purpose outside ledger scope")
        obligations_by_ledger[lid] = obligations
        required_acks_by_ledger[lid] = set(ledger.get("required_acknowledgment_witnesses") or [])
        required_fences_by_ledger[lid] = set(ledger.get("required_obligation_drift_fences") or [])
        boundary_text = " ".join(ledger.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: ledger {lid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: ledger {lid} authority boundaries should name refused authority")

    acks_by_id = {}
    acked_obligations_by_ledger = {}
    for ack in acks:
        ack_count += 1
        wid = ack.get("witness_id", "<missing>")
        if wid in acks_by_id:
            errors.append(f"{rel}: duplicate acknowledgment witness_id {wid}")
        acks_by_id[wid] = ack
        lid = ack.get("ledger_id")
        if ack.get("witness_family") != "foundry_acknowledgment_witness_v0":
            errors.append(f"{rel}: acknowledgment witness {wid} has wrong witness_family")
        if lid not in ledgers_by_id:
            errors.append(f"{rel}: acknowledgment witness {wid} references missing ledger {lid}")
            ledger = {}
            obligations = {}
        else:
            ledger = ledgers_by_id[lid]
            obligations = obligations_by_ledger[lid]
        state = ack.get("ack_state")
        if state not in ACK_STATES:
            errors.append(f"{rel}: acknowledgment witness {wid} has unknown ack_state {state!r}")
        if state == "acknowledged": acknowledged += 1
        if state == "partial": partial_ack += 1
        if state == "refused": refused_ack += 1
        if state == "quarantined": quarantined_ack += 1
        if state == "missing": missing_ack += 1
        cid = ack.get("consumer_id")
        if cid not in consumer_ids:
            errors.append(f"{rel}: acknowledgment witness {wid} names unknown consumer {cid}")
        scope = ledger.get("obligation_scope") or {}
        if ledger and cid not in set(scope.get("consumers") or []):
            errors.append(f"{rel}: acknowledgment witness {wid} consumer outside ledger scope")
        if ledger and ack.get("surface_id") not in set(scope.get("surfaces") or []):
            errors.append(f"{rel}: acknowledgment witness {wid} surface outside ledger scope")
        if ledger and ack.get("audience_id") not in set(scope.get("audiences") or []):
            errors.append(f"{rel}: acknowledgment witness {wid} audience outside ledger scope")
        observed = parse_time(ack.get("observed_at"))
        if not observed:
            errors.append(f"{rel}: acknowledgment witness {wid} missing/unparsable observed_at")
        elif lid in ledger_windows:
            issued, completed = ledger_windows[lid]
            if not (issued <= observed <= completed):
                errors.append(f"{rel}: acknowledgment witness {wid} observed outside ledger window")
        if ack.get("source_audience_witness_id") not in source_audience_ids:
            errors.append(f"{rel}: acknowledgment witness {wid} references unknown source audience witness")
        for key in ["obligation_ids", "acknowledgment_evidence", "residue_carried", "blocked_uses", "non_promises"]:
            if not ack.get(key):
                errors.append(f"{rel}: acknowledgment witness {wid} missing {key}")
        for oid in ack.get("obligation_ids") or []:
            if oid not in obligations:
                errors.append(f"{rel}: acknowledgment witness {wid} references obligation outside ledger: {oid}")
            else:
                acked_obligations_by_ledger.setdefault(lid, set()).add(oid)
        carrier_id = ack.get("carrier_id")
        if carrier_id:
            if carrier_id not in carrier_refs:
                errors.append(f"{rel}: acknowledgment witness {wid} references unknown carrier {carrier_id}")
            elif ack.get("carrier_digest") != carrier_refs[carrier_id].get("carrier_digest"):
                errors.append(f"{rel}: acknowledgment witness {wid} carrier digest mismatch")
        if state in RISKY_ACK_STATES and not ack.get("drift_fence_refs"):
            errors.append(f"{rel}: risky acknowledgment witness {wid} must reference a drift fence")
        np = " ".join(ack.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: acknowledgment witness {wid} must include authority/refusal non_promises")

    fences_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fences_by_id:
            errors.append(f"{rel}: duplicate obligation drift fence_id {fid}")
        fences_by_id[fid] = fence
        lid = fence.get("ledger_id")
        if fence.get("fence_family") != "foundry_obligation_drift_fence_v0":
            errors.append(f"{rel}: obligation drift fence {fid} has wrong fence_family")
        if lid not in ledgers_by_id:
            errors.append(f"{rel}: obligation drift fence {fid} references missing ledger {lid}")
            ledger = {}
            obligations = {}
        else:
            ledger = ledgers_by_id[lid]
            obligations = obligations_by_ledger[lid]
        if fence.get("obligation_id") not in obligations:
            errors.append(f"{rel}: obligation drift fence {fid} references missing obligation {fence.get('obligation_id')}")
        if fence.get("fence_type") not in FENCE_TYPES:
            errors.append(f"{rel}: obligation drift fence {fid} has unknown fence_type {fence.get('fence_type')!r}")
        result = fence.get("fence_result")
        if result not in FENCE_RESULTS:
            errors.append(f"{rel}: obligation drift fence {fid} has unknown fence_result {result!r}")
        if result == "blocked": blocked_fences += 1
        if result == "quarantined": quarantined_fences += 1
        if result == "recheck_required": recheck_fences += 1
        scope = ledger.get("obligation_scope") or {}
        if ledger and fence.get("affected_consumer_id") not in set(scope.get("consumers") or []):
            errors.append(f"{rel}: obligation drift fence {fid} consumer outside ledger scope")
        if ledger and fence.get("affected_surface_id") not in set(scope.get("surfaces") or []):
            errors.append(f"{rel}: obligation drift fence {fid} surface outside ledger scope")
        if ledger and fence.get("affected_audience_id") not in set(scope.get("audiences") or []):
            errors.append(f"{rel}: obligation drift fence {fid} audience outside ledger scope")
        detected = parse_time(fence.get("detected_at"))
        if not detected:
            errors.append(f"{rel}: obligation drift fence {fid} missing/unparsable detected_at")
        elif lid in ledger_windows:
            issued, completed = ledger_windows[lid]
            if not (issued <= detected <= completed):
                errors.append(f"{rel}: obligation drift fence {fid} detected outside ledger window")
        for key in ["missing_evidence", "required_clearance", "blocked_uses", "non_promises"]:
            if not fence.get(key):
                errors.append(f"{rel}: obligation drift fence {fid} missing {key}")
        if result in {"blocked", "quarantined", "recheck_required"} and not fence.get("recheck_after"):
            errors.append(f"{rel}: obligation drift fence {fid} needs recheck_after for {result}")
        np = " ".join(fence.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: obligation drift fence {fid} must include authority/refusal non_promises")

    ack_ids = set(acks_by_id)
    fence_ids = set(fences_by_id)
    for lid, ledger in ledgers_by_id.items():
        missing_acks = required_acks_by_ledger.get(lid, set()) - ack_ids
        if missing_acks:
            errors.append(f"{rel}: ledger {lid} missing required acknowledgment witnesses: {', '.join(sorted(missing_acks))}")
        missing_fences = required_fences_by_ledger.get(lid, set()) - fence_ids
        if missing_fences:
            errors.append(f"{rel}: ledger {lid} missing required obligation drift fences: {', '.join(sorted(missing_fences))}")
        if ledger.get("ledger_status") == "complete":
            active = {oid for oid, obl in obligations_by_ledger.get(lid, {}).items() if obl.get("obligation_status") == "active"}
            missing_active_ack = active - acked_obligations_by_ledger.get(lid, set())
            if missing_active_ack:
                errors.append(f"{rel}: complete ledger {lid} has active obligations without acknowledgment: {', '.join(sorted(missing_active_ack))}")

    for ack in acks:
        for fid in ack.get("drift_fence_refs") or []:
            if fid not in fences_by_id:
                errors.append(f"{rel}: acknowledgment witness {ack.get('witness_id')} references unknown drift fence {fid}")
            elif fences_by_id[fid].get("ledger_id") != ack.get("ledger_id"):
                errors.append(f"{rel}: acknowledgment witness {ack.get('witness_id')} drift fence {fid} belongs to another ledger")

    seen_codes = {case.get("failure_code") for case in data.get("negative_cases", []) if case.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - seen_codes
    if missing_codes:
        errors.append(f"{rel}: missing required negative failure codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if not (complete_ledgers and partial_ledgers and blocked_ledgers):
    errors.append("Specimen 88 must include complete, partial, and blocked obligation ledgers.")
if not (acknowledged and partial_ack and refused_ack and quarantined_ack and missing_ack):
    errors.append("Specimen 88 must include acknowledged, partial, refused, quarantined, and missing acknowledgment witnesses.")
if not (blocked_fences and quarantined_fences and recheck_fences):
    errors.append("Specimen 88 must include blocked, quarantined, and recheck-required obligation drift fences.")

if errors:
    print("Foundry obligation accounting check failed:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(
    f"Foundry obligation accounting check passed for {len(fixtures)} fixture file(s), "
    f"{ledger_count} obligation ledger(s), {ack_count} acknowledgment witness(es), "
    f"and {fence_count} obligation drift fence(s)"
)
