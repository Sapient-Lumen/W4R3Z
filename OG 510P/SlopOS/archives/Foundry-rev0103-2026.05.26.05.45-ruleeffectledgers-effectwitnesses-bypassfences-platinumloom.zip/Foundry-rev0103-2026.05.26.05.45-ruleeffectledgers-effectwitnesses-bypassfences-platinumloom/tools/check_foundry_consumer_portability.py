#!/usr/bin/env python3
"""Check Foundry consumer-portability fixtures.

Specimen 81 is about cross-consumer interpretation honesty. It deliberately
checks a small passport/witness/gate seam rather than becoming a catalog,
policy engine, audit framework, trust exchange, or sibling-cube verdict system.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-PORT-001-CONSUMER-PASSPORT",
    "R-PORT-002-PURPOSE-AUDIENCE",
    "R-PORT-003-REQUIRED-RESIDUE",
    "R-PORT-004-SIBLING-AUTHORITY-BOUNDARY",
    "R-PORT-005-PORTABILITY-WITNESS",
    "R-PORT-006-INTERPRETATION-GATE",
    "R-PORT-007-CONSUMER-SPECIFIC-LOSS",
    "R-PORT-008-NO-VERDICT-TRANSFER",
    "R-PORT-009-WAIVER-SCOPE-RECHECK",
    "R-PORT-010-NON-PORTABLE-REFUSAL",
}

REQUIRED_FAILURE_CODES = {
    "consumer_passport_required",
    "consumer_purpose_required",
    "consumer_required_residue_missing",
    "portability_witness_required",
    "interpretation_gate_required",
    "sibling_authority_transfer_refused",
    "verdict_transfer_refused",
    "waiver_scope_recheck_required",
    "consumer_specific_semantics_unpinned",
    "non_portable_residue_refused",
    "audience_widening_requires_gate",
    "source_consumer_digest_reuse_refused",
}

REQUIRED_GATE_EVENTS = {"before_first_use", "after_revision_change"}
REQUIRED_BOUNDARY_CUBES = {"Foundry"}
FORBIDDEN_TRANSFER_TRUE = {"verdict_transfer_allowed", "sibling_authority_transfer_allowed"}

errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("consumer_passports"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No consumer_passports fixture found for specimen 81.")

non_slopos_consumers = set()
portability_witness_count = 0
for path, data in fixtures:
    rel = path.relative_to(ROOT)
    passports = data.get("consumer_passports") or []
    if not passports:
        errors.append(f"{rel}: consumer_passports must be non-empty")
    consumer_ids = set()
    for passport in passports:
        pid = passport.get("passport_id", "<missing>")
        if passport.get("passport_family") != "foundry_consumer_passport_v0":
            errors.append(f"{rel}: passport {pid} has wrong passport_family")
        cid = passport.get("consumer_id")
        if not cid:
            errors.append(f"{rel}: passport {pid} missing consumer_id")
        else:
            consumer_ids.add(cid)
        for key in ["consumer_kind", "purpose", "audience"]:
            if not passport.get(key):
                errors.append(f"{rel}: passport {pid} missing {key}")
        if not isinstance(passport.get("accepted_surface_kinds"), list) or not passport.get("accepted_surface_kinds"):
            errors.append(f"{rel}: passport {pid} must name accepted_surface_kinds")
        residue = set(passport.get("required_residue_families") or [])
        if not residue:
            errors.append(f"{rel}: passport {pid} must name required_residue_families")
        if "semantic_sidecar" not in residue:
            errors.append(f"{rel}: passport {pid} should require semantic_sidecar residue")
        boundaries = passport.get("authority_boundaries") or {}
        missing_boundaries = REQUIRED_BOUNDARY_CUBES - set(boundaries)
        if missing_boundaries:
            errors.append(f"{rel}: passport {pid} missing authority boundaries for: {', '.join(sorted(missing_boundaries))}")
        forbidden = set(passport.get("forbidden_inferences") or [])
        if not forbidden:
            errors.append(f"{rel}: passport {pid} must name forbidden_inferences")
        if not any("waiver" in item or "verdict" in item or "truth" in item for item in forbidden):
            errors.append(f"{rel}: passport {pid} forbidden_inferences should cover waiver/verdict/truth overread")
        policy = passport.get("portability_policy") or {}
        if policy.get("requires_witness") is not True or policy.get("requires_interpretation_gate") is not True:
            errors.append(f"{rel}: passport {pid} portability_policy must require witness and interpretation gate")
        if passport.get("non_slopos") is True or passport.get("consumer_kind") not in {"slopos_operator_surface", "slopos_support_surface"}:
            non_slopos_consumers.add(cid)

    gates = data.get("interpretation_gates") or []
    gate_ids = {g.get("gate_id") for g in gates if g.get("gate_id")}
    for gate in gates:
        gid = gate.get("gate_id", "<missing>")
        if gate.get("gate_family") != "foundry_interpretation_gate_v0":
            errors.append(f"{rel}: gate {gid} has wrong gate_family")
        if gate.get("target_consumer_id") not in consumer_ids:
            errors.append(f"{rel}: gate {gid} targets unknown consumer {gate.get('target_consumer_id')!r}")
        events = set(gate.get("required_on") or [])
        if not REQUIRED_GATE_EVENTS.issubset(events):
            errors.append(f"{rel}: gate {gid} must run before first use and after revision change")
        rules = set(gate.get("must_recheck_rules") or [])
        if not any(rule.startswith("R-PORT-") for rule in rules):
            errors.append(f"{rel}: gate {gid} must recheck at least one R-PORT rule")
        if not isinstance(gate.get("must_preserve_residue"), list) or not gate.get("must_preserve_residue"):
            errors.append(f"{rel}: gate {gid} must name must_preserve_residue")
        if not isinstance(gate.get("must_refuse_if_missing"), list) or not gate.get("must_refuse_if_missing"):
            errors.append(f"{rel}: gate {gid} must name must_refuse_if_missing")
        refused = set(gate.get("refused_interpretations") or [])
        if not refused:
            errors.append(f"{rel}: gate {gid} must name refused_interpretations")
        if not any("verdict" in item or "approval" in item or "truth" in item or "opinion" in item for item in refused):
            errors.append(f"{rel}: gate {gid} refused_interpretations should cover verdict/approval/truth/opinion transfer")

    witnesses = data.get("portability_witnesses") or []
    portability_witness_count += len(witnesses)
    for witness in witnesses:
        wid = witness.get("witness_id", "<missing>")
        if witness.get("witness_family") != "foundry_portability_witness_v0":
            errors.append(f"{rel}: witness {wid} has wrong witness_family")
        source = witness.get("source_consumer_id")
        target = witness.get("target_consumer_id")
        if source not in consumer_ids or target not in consumer_ids:
            errors.append(f"{rel}: witness {wid} source/target must be known consumers")
        if source == target:
            errors.append(f"{rel}: witness {wid} should be cross-consumer, not same-consumer")
        if witness.get("portability_class") not in {"bounded", "refused", "same_consumer_only", "requires_review"}:
            errors.append(f"{rel}: witness {wid} has unknown portability_class")
        if not isinstance(witness.get("artifact_ids"), list) or not witness.get("artifact_ids"):
            errors.append(f"{rel}: witness {wid} must name artifact_ids")
        if not isinstance(witness.get("portable_residue"), list) or not witness.get("portable_residue"):
            errors.append(f"{rel}: witness {wid} must name portable_residue")
        if not isinstance(witness.get("non_portable_residue"), list) or not witness.get("non_portable_residue"):
            errors.append(f"{rel}: witness {wid} must name non_portable_residue")
        if not isinstance(witness.get("required_gates"), list) or not witness.get("required_gates"):
            errors.append(f"{rel}: witness {wid} must name required_gates")
        for gid in witness.get("required_gates") or []:
            if gid not in gate_ids:
                errors.append(f"{rel}: witness {wid} references unknown gate {gid}")
        for key in FORBIDDEN_TRANSFER_TRUE:
            if witness.get(key) is not False:
                errors.append(f"{rel}: witness {wid} must set {key}=false")
        if not any("waiver" in item or "verdict" in item or "authority" in item or "approval" in item for item in witness.get("non_portable_residue") or []):
            errors.append(f"{rel}: witness {wid} should name authority/verdict/waiver non-portable residue")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if not non_slopos_consumers:
    errors.append("Specimen 81 needs at least one non-SlopOS consumer passport.")
if portability_witness_count < 1:
    errors.append("Specimen 81 needs at least one portability witness.")

rulebook = ROOT / "docs/30-architecture/consumer-portability-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing consumer portability rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = [rule for rule in sorted(REQUIRED_RULES) if rule not in text]
    if missing_rules:
        errors.append("Consumer portability rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry consumer portability check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry consumer portability check passed for {len(fixtures)} fixture file(s), {len(non_slopos_consumers)} non-SlopOS consumer(s), and {portability_witness_count} portability witness(es)")
