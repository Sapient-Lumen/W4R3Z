#!/usr/bin/env python3
"""Check Foundry revocation/recall fixtures.

Specimen 83 is about invalidating previously emitted semantic carriers without
turning Foundry into authorization revocation, credential status, PKI, update
security, cache-control, legal-hold, or sibling-verdict infrastructure.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-RECALL-001-REVOCATION-NOTICE",
    "R-RECALL-002-AFFECTED-SCOPE",
    "R-RECALL-003-REVOCATION-REASON",
    "R-RECALL-004-RECALL-RECEIPT",
    "R-RECALL-005-CACHE-QUARANTINE",
    "R-RECALL-006-STALE-RELIANCE-FENCE",
    "R-RECALL-007-CONSUMER-PROPAGATION",
    "R-RECALL-008-NO-SILENT-SUPERSEDE",
    "R-RECALL-009-NO-AUTHORITY-LAUNDERING",
    "R-RECALL-010-REPLAY-BEFORE-REUSE",
    "R-RECALL-011-DELEGATION-WAIVER-RECHECK",
    "R-RECALL-012-PROPAGATION-WINDOW",
}

REQUIRED_FAILURE_CODES = {
    "revocation_notice_required",
    "revocation_reason_required",
    "affected_scope_required",
    "revocation_digest_required",
    "recall_receipt_required",
    "cache_quarantine_required",
    "stale_reliance_fence_required",
    "stale_reliance_refused",
    "revoked_sidecar_reuse_refused",
    "revoked_warrant_reuse_refused",
    "revoked_waiver_reuse_refused",
    "missing_consumer_ack",
    "silent_supersession_refused",
    "notice_audience_mismatch",
    "notice_propagation_window_expired",
    "replay_before_reuse_required",
    "authority_status_laundering_refused",
    "revocation_as_deletion_refused",
}

FORBIDDEN_AUTHORITY_WORDS = {"approval", "verdict", "truth", "audit_opinion", "permission", "risk_acceptance"}
ACTIVE_NOTICE_STATUSES = {"active"}
INACTIVE_NOTICE_STATUSES = {"superseded", "rescinded", "informational"}


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("revocation_notices"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No revocation_notices fixture found for specimen 83.")

active_notices = 0
inactive_notices = 0
recall_receipts = 0
stale_fences = 0
quarantine_receipts = 0
replacement_receipts = 0
refused_receipts = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    now = parse_time(data.get("fixture_now")) or datetime.now(timezone.utc)
    consumer_ids = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}

    notices = data.get("revocation_notices") or []
    receipts = data.get("recall_receipts") or []
    fences = data.get("stale_reliance_fences") or []
    notices_by_id = {}
    active_notice_consumers = {}

    if not notices:
        errors.append(f"{rel}: revocation_notices must be non-empty")

    for notice in notices:
        nid = notice.get("notice_id", "<missing>")
        if nid in notices_by_id:
            errors.append(f"{rel}: duplicate notice_id {nid}")
        notices_by_id[nid] = notice
        if notice.get("notice_family") != "foundry_revocation_notice_v0":
            errors.append(f"{rel}: notice {nid} has wrong notice_family")
        if not str(notice.get("notice_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: notice {nid} missing sha256 notice_digest")
        if not str(notice.get("revoked_artifact_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: notice {nid} missing sha256 revoked_artifact_digest")
        status = notice.get("notice_status")
        if status in ACTIVE_NOTICE_STATUSES:
            active_notices += 1
        elif status in INACTIVE_NOTICE_STATUSES:
            inactive_notices += 1
        else:
            errors.append(f"{rel}: notice {nid} has unknown notice_status {status!r}")
        for key in ["issuer_consumer_id", "revoked_artifact_family", "revoked_artifact_id", "reason_class", "issued_at", "effective_at"]:
            if not notice.get(key):
                errors.append(f"{rel}: notice {nid} missing {key}")
        if not notice.get("reason_summary"):
            errors.append(f"{rel}: notice {nid} missing reason_summary")
        issued_at = parse_time(notice.get("issued_at"))
        effective_at = parse_time(notice.get("effective_at"))
        deadline = parse_time(notice.get("propagation_deadline"))
        if not issued_at or not effective_at:
            errors.append(f"{rel}: notice {nid} has unparsable issued/effective time")
        if notice.get("notice_status") == "active" and not deadline:
            errors.append(f"{rel}: active notice {nid} requires propagation_deadline")
        if deadline and issued_at and deadline < issued_at:
            errors.append(f"{rel}: notice {nid} propagation_deadline precedes issued_at")
        affected = set(notice.get("affected_consumers") or [])
        if not affected:
            errors.append(f"{rel}: notice {nid} missing affected_consumers")
        if consumer_ids and affected - consumer_ids:
            errors.append(f"{rel}: notice {nid} names unknown affected consumers: {', '.join(sorted(affected - consumer_ids))}")
        if notice.get("notice_status") == "active":
            active_notice_consumers[nid] = affected
        if not isinstance(notice.get("affected_surfaces"), list) or not notice.get("affected_surfaces"):
            errors.append(f"{rel}: notice {nid} missing affected_surfaces")
        actions = set(notice.get("required_actions") or [])
        if not actions:
            errors.append(f"{rel}: notice {nid} missing required_actions")
        if notice.get("notice_status") == "active" and "emit_recall_receipt" not in actions:
            errors.append(f"{rel}: active notice {nid} must require emit_recall_receipt")
        boundaries = set(notice.get("authority_boundaries") or [])
        if not boundaries:
            errors.append(f"{rel}: notice {nid} missing authority_boundaries")
        boundary_text = " ".join(sorted(boundaries)).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: notice {nid} must state negative authority boundaries")
        if notice.get("notice_status") == "active" and notice.get("effective_at") and effective_at and effective_at > now:
            errors.append(f"{rel}: active notice {nid} effective_at is in the future relative to fixture_now")

    receipt_consumers_by_notice = {}
    for receipt in receipts:
        recall_receipts += 1
        rid = receipt.get("receipt_id", "<missing>")
        if receipt.get("receipt_family") != "foundry_recall_receipt_v0":
            errors.append(f"{rel}: recall receipt {rid} has wrong receipt_family")
        nid = receipt.get("notice_id")
        if nid not in notices_by_id:
            errors.append(f"{rel}: recall receipt {rid} references missing notice {nid}")
        cid = receipt.get("consumer_id")
        if not cid:
            errors.append(f"{rel}: recall receipt {rid} missing consumer_id")
        elif consumer_ids and cid not in consumer_ids:
            errors.append(f"{rel}: recall receipt {rid} names unknown consumer {cid}")
        receipt_consumers_by_notice.setdefault(nid, set()).add(cid)
        received_at = parse_time(receipt.get("received_at"))
        processed_at = parse_time(receipt.get("processed_at"))
        if not received_at or not processed_at:
            errors.append(f"{rel}: recall receipt {rid} has unparsable received/processed time")
        elif processed_at < received_at:
            errors.append(f"{rel}: recall receipt {rid} processed before received")
        actions = set(receipt.get("actions_taken") or [])
        if not actions:
            errors.append(f"{rel}: recall receipt {rid} missing actions_taken")
        if any("quarantine" in a for a in actions):
            quarantine_receipts += 1
        if receipt.get("replacement_artifacts"):
            replacement_receipts += 1
        if receipt.get("recall_result") == "refused_stale_use":
            refused_receipts += 1
        if not isinstance(receipt.get("replayed_gates"), list) or not receipt.get("replayed_gates"):
            errors.append(f"{rel}: recall receipt {rid} must list replayed_gates")
        refused = set(receipt.get("refused_inferences") or [])
        if not refused:
            errors.append(f"{rel}: recall receipt {rid} missing refused_inferences")
        if not (refused & FORBIDDEN_AUTHORITY_WORDS or any("truth" in x or "verdict" in x or "approval" in x for x in refused)):
            errors.append(f"{rel}: recall receipt {rid} must refuse at least one authority/verdict/truth inference")

    fence_consumers_by_notice = {}
    for fence in fences:
        stale_fences += 1
        fid = fence.get("fence_id", "<missing>")
        if fence.get("fence_family") != "foundry_stale_reliance_fence_v0":
            errors.append(f"{rel}: stale reliance fence {fid} has wrong fence_family")
        nid = fence.get("notice_id")
        if nid not in notices_by_id:
            errors.append(f"{rel}: stale reliance fence {fid} references missing notice {nid}")
        cid = fence.get("consumer_id")
        if not cid:
            errors.append(f"{rel}: stale reliance fence {fid} missing consumer_id")
        fence_consumers_by_notice.setdefault(nid, set()).add(cid)
        if not isinstance(fence.get("blocked_artifacts"), list) or not fence.get("blocked_artifacts"):
            errors.append(f"{rel}: stale reliance fence {fid} missing blocked_artifacts")
        if not isinstance(fence.get("blocked_uses"), list) or not fence.get("blocked_uses"):
            errors.append(f"{rel}: stale reliance fence {fid} missing blocked_uses")
        if not parse_time(fence.get("stale_after")):
            errors.append(f"{rel}: stale reliance fence {fid} missing/unparsable stale_after")
        if not isinstance(fence.get("required_recheck"), list) or not fence.get("required_recheck"):
            errors.append(f"{rel}: stale reliance fence {fid} missing required_recheck")
        if not fence.get("failure_code"):
            errors.append(f"{rel}: stale reliance fence {fid} missing failure_code")

    for nid, consumers in active_notice_consumers.items():
        satisfied = receipt_consumers_by_notice.get(nid, set()) | fence_consumers_by_notice.get(nid, set())
        missing = consumers - satisfied
        if missing:
            errors.append(f"{rel}: active notice {nid} has affected consumers without recall receipt or stale fence: {', '.join(sorted(missing))}")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if active_notices < 1:
    errors.append("Specimen 83 needs at least one active revocation notice.")
if inactive_notices < 1:
    errors.append("Specimen 83 needs at least one inactive/superseded/rescinded/informational notice.")
if recall_receipts < 1:
    errors.append("Specimen 83 needs at least one recall receipt.")
if stale_fences < 1:
    errors.append("Specimen 83 needs at least one stale-reliance fence.")
if quarantine_receipts < 1 or replacement_receipts < 1 or refused_receipts < 1:
    errors.append("Specimen 83 needs quarantine, replacement, and refused-stale-use receipt examples.")

rulebook = ROOT / "docs/30-architecture/revocation-recall-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing revocation/recall rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = sorted(rule for rule in REQUIRED_RULES if rule not in text)
    if missing_rules:
        errors.append("Revocation/recall rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry revocation/recall check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry revocation/recall check passed for {len(fixtures)} fixture file(s), {active_notices} active notice(s), {inactive_notices} inactive notice(s), {recall_receipts} recall receipt(s), and {stale_fences} stale fence(s)")
