#!/usr/bin/env python3
"""Check Foundry exposure-accounting fixtures.

Specimen 87 proves that Foundry can account for who can see a semantic
surface and for which purpose without becoming an authorization engine,
consent framework, privacy-policy system, access-control product, deletion
system, Ward verdict, Harbor public-status workflow, ViewFS custody model, or
SlopOS proof claim.
"""
from pathlib import Path
from datetime import datetime
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-EXP-001-EXPOSURE-LEDGER",
    "R-EXP-002-SOURCE-INVENTORY-LINKAGE",
    "R-EXP-003-INTENDED-AUDIENCE-PIN",
    "R-EXP-004-AUDIENCE-WITNESS",
    "R-EXP-005-PURPOSE-AND-ACCESS-MODE-CHECK",
    "R-EXP-006-UNKNOWN-OR-PUBLIC-FENCE",
    "R-EXP-007-INHERITED-PERMISSION-HUMILITY",
    "R-EXP-008-LEDGER-WINDOW-AND-RECENCY",
    "R-EXP-009-CONSUMER-SCOPE-BOUNDARY",
    "R-EXP-010-NON-TRANSITIVE-EXPOSURE",
    "R-EXP-011-AUTHORITY-LAUNDERING-FENCE",
    "R-EXP-012-RECHECK-HOOK",
}

REQUIRED_FAILURE_CODES = {
    "exposure_ledger_required",
    "source_inventory_required",
    "audience_witness_required",
    "intended_audience_unaccounted_refused",
    "unknown_audience_unfenced_refused",
    "public_link_unfenced_refused",
    "purpose_widening_refused",
    "access_mode_widening_refused",
    "inherited_permission_without_witness_refused",
    "ledger_window_expired_refused",
    "overexposed_surface_as_adopted_refused",
    "audience_as_authorization_refused",
    "exposure_as_consent_refused",
    "exposure_as_deletion_refused",
    "consumer_scope_mismatch_refused",
    "exposure_witness_digest_mismatch_refused",
    "purpose_fence_required",
}

LEDGER_STATUSES = {"complete", "partial", "blocked", "superseded", "retired"}
EXPOSURE_STATES = {"within_scope", "overexposed", "unknown", "public_link", "inherited", "quarantined", "retired_as_history"}
FENCE_TYPES = {"audience_widening", "purpose_widening", "access_mode_widening", "unknown_audience", "public_link", "external_share", "permission_inheritance", "expired_exposure_check", "no_authority_evidence", "audience_evidence_missing"}
FENCE_RESULTS = {"blocked", "quarantined", "recheck_required", "monitor_only", "retired_as_history"}
RISKY_STATES = {"overexposed", "unknown", "public_link", "inherited"}
AUTHORITY_WORDS = {"authorization", "permission", "consent", "policy", "privacy", "verdict", "custody", "release", "deletion", "proof", "truth", "audit"}


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("exposure_ledgers"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No exposure_ledgers fixture found for specimen 87.")

ledger_count = 0
witness_count = 0
fence_count = 0
complete_ledgers = 0
partial_ledgers = 0
blocked_ledgers = 0
within_scope_witnesses = 0
risky_witnesses = 0
public_witnesses = 0
unknown_witnesses = 0
inherited_witnesses = 0
blocked_fences = 0
quarantined_fences = 0
recheck_fences = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    consumer_ids = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    carrier_refs = {c.get("carrier_id"): c for c in data.get("carrier_refs", []) if c.get("carrier_id")}
    inventory_refs = {s.get("sweep_id"): s for s in data.get("surface_inventory_refs", []) if s.get("sweep_id")}
    reachability_ids = set()
    surface_to_inventory_consumers = {}
    for sweep in data.get("surface_inventory_refs", []):
        sid = sweep.get("sweep_id")
        for wid in sweep.get("reachability_witness_ids") or []:
            reachability_ids.add(wid)
        for surface in sweep.get("surface_ids") or []:
            surface_to_inventory_consumers.setdefault(surface, set()).update(sweep.get("consumer_ids") or [])

    ledgers = data.get("exposure_ledgers") or []
    witnesses = data.get("audience_witnesses") or []
    fences = data.get("purpose_fences") or []
    if not ledgers:
        errors.append(f"{rel}: exposure_ledgers must be non-empty")

    ledgers_by_id = {}
    ledger_windows = {}
    intended_by_ledger = {}
    required_witnesses_by_ledger = {}
    required_fences_by_ledger = {}

    for ledger in ledgers:
        ledger_count += 1
        lid = ledger.get("ledger_id", "<missing>")
        if lid in ledgers_by_id:
            errors.append(f"{rel}: duplicate ledger_id {lid}")
        ledgers_by_id[lid] = ledger
        if ledger.get("ledger_family") != "foundry_exposure_ledger_v0":
            errors.append(f"{rel}: ledger {lid} has wrong ledger_family")
        if not str(ledger.get("ledger_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: ledger {lid} missing sha256 ledger_digest")
        status = ledger.get("ledger_status")
        if status not in LEDGER_STATUSES:
            errors.append(f"{rel}: ledger {lid} has unknown ledger_status {status!r}")
        if status == "complete":
            complete_ledgers += 1
        if status == "partial":
            partial_ledgers += 1
        if status == "blocked":
            blocked_ledgers += 1
        issued = parse_time(ledger.get("issued_at"))
        completed = parse_time(ledger.get("completed_at"))
        if not issued or not completed or not issued <= completed:
            errors.append(f"{rel}: ledger {lid} has invalid issue/completion window")
        else:
            ledger_windows[lid] = (issued, completed)
        for key in ["source_inventory_sweep_ids", "source_reachability_witness_ids", "carrier_ids", "exposure_scope", "intended_audiences", "observed_surface_ids", "discovery_sources", "method_limits", "required_audience_witnesses", "authority_boundaries"]:
            if not ledger.get(key):
                errors.append(f"{rel}: ledger {lid} missing {key}")
        for sweep_id in ledger.get("source_inventory_sweep_ids") or []:
            if sweep_id not in inventory_refs:
                errors.append(f"{rel}: ledger {lid} references unknown inventory sweep {sweep_id}")
        for witness_id in ledger.get("source_reachability_witness_ids") or []:
            if witness_id not in reachability_ids:
                errors.append(f"{rel}: ledger {lid} references unknown reachability witness {witness_id}")
        for carrier_id in ledger.get("carrier_ids") or []:
            if carrier_id not in carrier_refs:
                errors.append(f"{rel}: ledger {lid} references unknown carrier {carrier_id}")
        scope = ledger.get("exposure_scope") or {}
        scope_consumers = set(scope.get("consumers") or [])
        unknown_consumers = scope_consumers - consumer_ids
        if unknown_consumers:
            errors.append(f"{rel}: ledger {lid} scopes unknown consumers: {', '.join(sorted(unknown_consumers))}")
        scope_surfaces = set(scope.get("surfaces") or [])
        observed_surfaces = set(ledger.get("observed_surface_ids") or [])
        if not observed_surfaces <= scope_surfaces:
            errors.append(f"{rel}: ledger {lid} observes surfaces outside exposure_scope: {', '.join(sorted(observed_surfaces - scope_surfaces))}")
        intended = {}
        for item in ledger.get("intended_audiences") or []:
            aid = item.get("audience_id")
            if not aid:
                errors.append(f"{rel}: ledger {lid} has intended audience without id")
                continue
            if aid in intended:
                errors.append(f"{rel}: ledger {lid} duplicates intended audience {aid}")
            intended[aid] = item
            if not item.get("allowed_purposes") or not item.get("allowed_access_modes"):
                errors.append(f"{rel}: ledger {lid} intended audience {aid} missing allowed purpose/access modes")
        intended_by_ledger[lid] = intended
        required_witnesses_by_ledger[lid] = set(ledger.get("required_audience_witnesses") or [])
        required_fences_by_ledger[lid] = set(ledger.get("required_purpose_fences") or [])
        boundary_text = " ".join(ledger.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: ledger {lid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: ledger {lid} authority boundaries should name refused authority")
        if status in {"partial", "blocked"} and not ledger.get("required_purpose_fences"):
            errors.append(f"{rel}: partial/blocked ledger {lid} must name required purpose fences")

    witnesses_by_id = {}
    witnessed_audiences_by_ledger = {}
    witnessed_surfaces_by_ledger = {}
    risky_witnesses_without_fence = []
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if wid in witnesses_by_id:
            errors.append(f"{rel}: duplicate witness_id {wid}")
        witnesses_by_id[wid] = witness
        lid = witness.get("ledger_id")
        if witness.get("witness_family") != "foundry_audience_witness_v0":
            errors.append(f"{rel}: audience witness {wid} has wrong witness_family")
        if lid not in ledgers_by_id:
            errors.append(f"{rel}: audience witness {wid} references missing ledger {lid}")
            ledger = {}
            intended = {}
        else:
            ledger = ledgers_by_id[lid]
            intended = intended_by_ledger[lid]
        cid = witness.get("consumer_id")
        surface = witness.get("surface_id")
        aid = witness.get("audience_id")
        if cid not in consumer_ids:
            errors.append(f"{rel}: audience witness {wid} names unknown consumer {cid}")
        scope = ledger.get("exposure_scope") or {}
        if ledger and cid not in set(scope.get("consumers") or []):
            errors.append(f"{rel}: audience witness {wid} consumer {cid} outside ledger consumer scope")
        if ledger and surface not in set(ledger.get("observed_surface_ids") or []):
            errors.append(f"{rel}: audience witness {wid} surface {surface} outside ledger observed surfaces")
        if surface in surface_to_inventory_consumers and cid not in surface_to_inventory_consumers[surface] and cid != "slopos_operator_console":
            errors.append(f"{rel}: audience witness {wid} consumer {cid} does not match inventory owner for surface {surface}")
        observed = parse_time(witness.get("observed_at"))
        if not observed:
            errors.append(f"{rel}: audience witness {wid} missing/unparsable observed_at")
        elif lid in ledger_windows:
            issued, completed = ledger_windows[lid]
            if not (issued <= observed <= completed):
                errors.append(f"{rel}: audience witness {wid} observed outside ledger window")
        state = witness.get("exposure_state")
        if state not in EXPOSURE_STATES:
            errors.append(f"{rel}: audience witness {wid} has unknown exposure_state {state!r}")
        if state == "within_scope":
            within_scope_witnesses += 1
        if state in RISKY_STATES:
            risky_witnesses += 1
        if state == "public_link":
            public_witnesses += 1
        if state == "unknown":
            unknown_witnesses += 1
        if state == "inherited":
            inherited_witnesses += 1
        for key in ["audience_evidence", "access_modes", "purposes_seen", "residue_seen", "blocked_uses", "non_promises"]:
            if not witness.get(key):
                errors.append(f"{rel}: audience witness {wid} missing {key}")
        cidr = witness.get("carrier_id")
        if cidr:
            if cidr not in carrier_refs:
                errors.append(f"{rel}: audience witness {wid} references unknown carrier {cidr}")
            elif witness.get("carrier_digest") != carrier_refs[cidr].get("carrier_digest"):
                errors.append(f"{rel}: audience witness {wid} carrier digest mismatch")
        for rw in witness.get("reachability_witness_refs") or []:
            if rw not in reachability_ids:
                errors.append(f"{rel}: audience witness {wid} references unknown reachability witness {rw}")
            if lid in ledgers_by_id and rw not in set(ledgers_by_id[lid].get("source_reachability_witness_ids") or []):
                errors.append(f"{rel}: audience witness {wid} reachability ref {rw} is outside ledger source witnesses")
        witnessed_audiences_by_ledger.setdefault(lid, set()).add(aid)
        witnessed_surfaces_by_ledger.setdefault(lid, set()).add(surface)
        if state == "within_scope":
            if aid not in intended:
                errors.append(f"{rel}: within-scope witness {wid} audience {aid} is not intended")
            else:
                allowed_purposes = set(intended[aid].get("allowed_purposes") or [])
                allowed_access = set(intended[aid].get("allowed_access_modes") or [])
                purposes = set(witness.get("purposes_seen") or [])
                access = set(witness.get("access_modes") or [])
                if not purposes <= allowed_purposes:
                    errors.append(f"{rel}: within-scope witness {wid} uses non-intended purposes: {', '.join(sorted(purposes - allowed_purposes))}")
                if not access <= allowed_access:
                    errors.append(f"{rel}: within-scope witness {wid} uses non-intended access modes: {', '.join(sorted(access - allowed_access))}")
        if state in RISKY_STATES and not witness.get("purpose_fence_refs"):
            risky_witnesses_without_fence.append(wid)
        np = " ".join(witness.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: audience witness {wid} must include authority/refusal non_promises")
        if any(word in " ".join(witness.get("blocked_uses") or []).lower() for word in ["grant", "consent", "public", "verdict", "authorize", "permission"]):
            if not any(word in np for word in ["authorization", "consent", "release", "verdict", "permission"]):
                errors.append(f"{rel}: audience witness {wid} blocks authority use but non_promises do not name it")

    for wid in risky_witnesses_without_fence:
        errors.append(f"{rel}: risky audience witness {wid} must reference a purpose fence")

    fences_by_id = {}
    fences_by_ledger = {}
    fences_by_witness = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fences_by_id:
            errors.append(f"{rel}: duplicate fence_id {fid}")
        fences_by_id[fid] = fence
        lid = fence.get("ledger_id")
        fences_by_ledger.setdefault(lid, set()).add(fid)
        if fence.get("fence_family") != "foundry_purpose_fence_v0":
            errors.append(f"{rel}: purpose fence {fid} has wrong fence_family")
        if lid not in ledgers_by_id:
            errors.append(f"{rel}: purpose fence {fid} references missing ledger {lid}")
            ledger = {}
        else:
            ledger = ledgers_by_id[lid]
        if fence.get("fence_type") not in FENCE_TYPES:
            errors.append(f"{rel}: purpose fence {fid} has unknown fence_type {fence.get('fence_type')!r}")
        result = fence.get("fence_result")
        if result not in FENCE_RESULTS:
            errors.append(f"{rel}: purpose fence {fid} has unknown fence_result {result!r}")
        if result == "blocked":
            blocked_fences += 1
        if result == "quarantined":
            quarantined_fences += 1
        if result == "recheck_required":
            recheck_fences += 1
        cid = fence.get("affected_consumer_id")
        surface = fence.get("affected_surface_id")
        if cid not in consumer_ids:
            errors.append(f"{rel}: purpose fence {fid} names unknown consumer {cid}")
        scope = ledger.get("exposure_scope") or {}
        if ledger and cid not in set(scope.get("consumers") or []):
            errors.append(f"{rel}: purpose fence {fid} consumer {cid} outside ledger scope")
        if ledger and surface not in set(ledger.get("observed_surface_ids") or []):
            errors.append(f"{rel}: purpose fence {fid} surface {surface} outside ledger observed surfaces")
        detected = parse_time(fence.get("detected_at"))
        if not detected:
            errors.append(f"{rel}: purpose fence {fid} missing/unparsable detected_at")
        elif lid in ledger_windows:
            issued, completed = ledger_windows[lid]
            if not (issued <= detected <= completed):
                errors.append(f"{rel}: purpose fence {fid} detected outside ledger window")
        for key in ["missing_evidence", "required_clearance", "blocked_uses", "non_promises"]:
            if not fence.get(key):
                errors.append(f"{rel}: purpose fence {fid} missing {key}")
        if result in {"blocked", "quarantined", "recheck_required"} and not fence.get("recheck_after"):
            errors.append(f"{rel}: purpose fence {fid} needs recheck_after for {result}")
        np = " ".join(fence.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: purpose fence {fid} must include authority/refusal non_promises")

    # Validate required witness/fence ids and intended-audience coverage.
    witness_ids = set(witnesses_by_id)
    fence_ids = set(fences_by_id)
    for lid, ledger in ledgers_by_id.items():
        missing_required_witnesses = required_witnesses_by_ledger.get(lid, set()) - witness_ids
        if missing_required_witnesses:
            errors.append(f"{rel}: ledger {lid} missing required audience witnesses: {', '.join(sorted(missing_required_witnesses))}")
        missing_required_fences = required_fences_by_ledger.get(lid, set()) - fence_ids
        if missing_required_fences:
            errors.append(f"{rel}: ledger {lid} missing required purpose fences: {', '.join(sorted(missing_required_fences))}")
        for aid in intended_by_ledger.get(lid, {}):
            if aid not in witnessed_audiences_by_ledger.get(lid, set()):
                errors.append(f"{rel}: ledger {lid} intended audience {aid} has no audience witness")
        observed_surfaces = set(ledger.get("observed_surface_ids") or [])
        accounted_surfaces = witnessed_surfaces_by_ledger.get(lid, set()) | {fences_by_id[f].get("affected_surface_id") for f in fences_by_ledger.get(lid, set()) if f in fences_by_id}
        if ledger.get("ledger_status") == "complete" and not observed_surfaces <= accounted_surfaces:
            errors.append(f"{rel}: complete ledger {lid} has unaccounted surfaces: {', '.join(sorted(observed_surfaces - accounted_surfaces))}")

    for witness in witnesses:
        for fid in witness.get("purpose_fence_refs") or []:
            if fid not in fences_by_id:
                errors.append(f"{rel}: audience witness {witness.get('witness_id')} references unknown purpose fence {fid}")
            elif fences_by_id[fid].get("ledger_id") != witness.get("ledger_id"):
                errors.append(f"{rel}: audience witness {witness.get('witness_id')} purpose fence {fid} belongs to another ledger")

    seen_rules = set(data.get("rule_ids", []))
    # Rule docs may live outside fixtures; allow fixtures not to list rule ids but require negative cases.
    seen_codes = {case.get("failure_code") for case in data.get("negative_cases", []) if case.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - seen_codes
    if missing_codes:
        errors.append(f"{rel}: missing required negative failure codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if not (complete_ledgers and partial_ledgers and blocked_ledgers):
    errors.append("Specimen 87 must include complete, partial, and blocked exposure ledgers.")
if not (within_scope_witnesses and risky_witnesses and public_witnesses and unknown_witnesses and inherited_witnesses):
    errors.append("Specimen 87 must include within-scope, risky, public-link, unknown, and inherited audience witnesses.")
if not (blocked_fences and quarantined_fences and recheck_fences):
    errors.append("Specimen 87 must include blocked, quarantined, and recheck-required purpose fences.")

if errors:
    print("Foundry exposure accounting check failed:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(
    f"Foundry exposure accounting check passed for {len(fixtures)} fixture file(s), "
    f"{ledger_count} exposure ledger(s), {witness_count} audience witness(es), "
    f"and {fence_count} purpose fence(s)"
)
