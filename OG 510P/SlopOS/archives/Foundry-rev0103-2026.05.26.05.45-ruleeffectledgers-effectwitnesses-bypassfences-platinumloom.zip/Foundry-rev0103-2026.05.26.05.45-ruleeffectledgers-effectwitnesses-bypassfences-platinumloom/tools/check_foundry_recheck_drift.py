#!/usr/bin/env python3
"""Check Foundry recheck/drift fixtures.

Specimen 91 keeps point-in-time verification from becoming continuing freshness,
monitoring truth, audit opinion, authorization, or sibling-cube verdict.
"""
from pathlib import Path
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover - direct execution fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

REQUIRED_FAILURE_CODES = {
    "recheck_cadence_required",
    "source_verification_required",
    "drift_signal_required",
    "required_signal_missing_refused",
    "stale_signal_accepted_refused",
    "flapping_signal_unfenced_refused",
    "missed_recheck_unfenced_refused",
    "cadence_scope_mismatch_refused",
    "signal_scope_mismatch_refused",
    "signal_digest_mismatch_refused",
    "paused_cadence_as_active_refused",
    "clear_signal_as_exhaustive_refused",
    "alert_as_truth_refused",
    "freshness_as_authorization_refused",
    "recheck_as_audit_opinion_refused",
    "monitoring_as_sibling_verdict_refused",
    "schema_fixture_coverage_drift_refused",
}

CADENCE_STATUSES = {"active", "warning", "paused", "blocked", "retired", "superseded"}
SIGNAL_STATES = {"clear", "warning", "firing", "stale", "missing", "flapping", "superseded", "quarantined"}
RISKY_SIGNAL_STATES = SIGNAL_STATES - {"clear"}
FENCE_REASONS = {
    "warning_boundary_ambiguity",
    "stale_inherited_scope",
    "flapping_signal",
    "firing_no_reexport_missing",
    "missing_recall_route",
    "paused_cadence_reuse",
    "scope_widening",
    "digest_mismatch",
    "missed_recheck",
}
AUTHORITY_WORDS = {
    "authorization", "legal", "compliance", "audit", "opinion", "proof", "verdict",
    "custody", "release", "deletion", "retention", "repair", "finality", "truth",
    "slo", "sla", "monitoring", "incident", "consent", "public"
}

fixture_paths = sorted(FIXTURES.glob("specimen-91-recheck-drift/fixture.json"))
if not fixture_paths:
    print("No specimen 91 recheck/drift fixture found")
    sys.exit(1)

errors = []
fixture_count = cadence_count = signal_count = fence_count = 0
cadence_status_counts = {status: 0 for status in CADENCE_STATUSES}
signal_state_counts = {state: 0 for state in SIGNAL_STATES}

for fixture_path in fixture_paths:
    fixture_count += 1
    rel = fixture_path.relative_to(ROOT)
    fixture = load_json(fixture_path)
    if fixture.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if fixture.get("specimen_id") != "91":
        errors.append(f"{rel}: specimen_id must be 91")

    consumers = {item.get("consumer_id") for item in fixture.get("consumer_refs") or []}
    source_refs = {item.get("audit_id"): item for item in fixture.get("source_verification_refs") or []}
    source_audits = set(source_refs)
    source_samples = {sid for item in source_refs.values() for sid in item.get("evidence_sample_ids") or []}
    source_fences = {fid for item in source_refs.values() for fid in item.get("false_closure_fence_ids") or []}
    source_carriers = {cid for item in source_refs.values() for cid in item.get("carrier_ids") or []}
    carrier_refs = {item.get("carrier_id"): item for item in fixture.get("carrier_refs") or []}

    cadences = fixture.get("recheck_cadences") or []
    signals = fixture.get("drift_signals") or []
    fences = fixture.get("stale_verification_fences") or []
    if not cadences:
        errors.append(f"{rel}: missing recheck_cadences")
    if not signals:
        errors.append(f"{rel}: missing drift_signals")
    if not fences:
        errors.append(f"{rel}: missing stale_verification_fences")

    negative_codes = {case.get("must_fail_with") or case.get("failure_code") for case in fixture.get("negative_cases") or []}
    missing_codes = sorted(REQUIRED_FAILURE_CODES - negative_codes)
    if missing_codes:
        errors.append(f"{rel}: missing required negative cases: {', '.join(missing_codes)}")

    cadence_by_id = {}
    required_signals = {}
    required_fences = {}
    cadence_scopes = {}
    for cadence in cadences:
        cadence_count += 1
        cid = cadence.get("cadence_id", "<missing>")
        if cid in cadence_by_id:
            errors.append(f"{rel}: duplicate cadence_id {cid}")
        cadence_by_id[cid] = cadence
        if cadence.get("cadence_family") != "foundry_recheck_cadence_v0":
            errors.append(f"{rel}: cadence {cid} has wrong cadence_family")
        if not require_sha256(cadence.get("cadence_digest")):
            errors.append(f"{rel}: cadence {cid} missing sha256 cadence_digest")
        status = cadence.get("cadence_status")
        if status not in CADENCE_STATUSES:
            errors.append(f"{rel}: cadence {cid} has unknown status {status!r}")
        else:
            cadence_status_counts[status] += 1
        for key in ["source_verification_audit_ids", "source_evidence_sample_ids", "carrier_ids", "cadence_scope", "cadence_basis", "recheck_window", "required_drift_signals", "escalation", "authority_boundaries"]:
            if not cadence.get(key):
                errors.append(f"{rel}: cadence {cid} missing {key}")
        if status in {"warning", "blocked", "paused"} and not cadence.get("required_stale_verification_fences"):
            errors.append(f"{rel}: {status} cadence {cid} must require stale-verification fences")
        for aid in cadence.get("source_verification_audit_ids") or []:
            if aid not in source_audits:
                errors.append(f"{rel}: cadence {cid} references unknown source verification audit {aid}")
        for sid in cadence.get("source_evidence_sample_ids") or []:
            if sid not in source_samples:
                errors.append(f"{rel}: cadence {cid} references unknown source evidence sample {sid}")
        for fid in cadence.get("source_false_closure_fence_ids") or []:
            if fid not in source_fences:
                errors.append(f"{rel}: cadence {cid} references unknown source false-closure fence {fid}")
        for carrier_id in cadence.get("carrier_ids") or []:
            if carrier_id not in carrier_refs or carrier_id not in source_carriers:
                errors.append(f"{rel}: cadence {cid} references unknown carrier {carrier_id}")
        scope = cadence.get("cadence_scope") or {}
        cadence_scopes[cid] = scope
        unknown_consumers = set(scope.get("consumers") or []) - consumers
        if unknown_consumers:
            errors.append(f"{rel}: cadence {cid} scopes unknown consumers: {', '.join(sorted(unknown_consumers))}")
        source_allowed = {"consumers": set(), "surfaces": set(), "audiences": set(), "purpose_classes": set()}
        for aid in cadence.get("source_verification_audit_ids") or []:
            src = source_refs.get(aid) or {}
            for key in source_allowed:
                source_allowed[key].update(src.get(key) or [])
        for key in source_allowed:
            scoped = set(scope.get(key) or [])
            extra = scoped - source_allowed[key]
            if extra:
                errors.append(f"{rel}: cadence {cid} scope {key} exceeds source audit scope: {', '.join(sorted(extra))}")
        basis = cadence.get("cadence_basis") or {}
        for key in ["mode", "interval", "triggers", "grace_window", "first_check_at", "last_check_at", "next_check_due_at", "blocked_inferences"]:
            if not basis.get(key):
                errors.append(f"{rel}: cadence {cid} cadence_basis missing {key}")
        if basis.get("non_exhaustive") is not True:
            errors.append(f"{rel}: cadence {cid} must state non_exhaustive=true")
        window = cadence.get("recheck_window") or {}
        for key in ["fresh_until", "stale_after", "keep_firing_after_drift"]:
            if not window.get(key):
                errors.append(f"{rel}: cadence {cid} recheck_window missing {key}")
        if not cadence.get("escalation"):
            errors.append(f"{rel}: cadence {cid} must include escalation posture")
        boundary_text = " ".join(cadence.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: cadence {cid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: cadence {cid} authority boundaries should name refused authority")
        required_signals[cid] = set(cadence.get("required_drift_signals") or [])
        required_fences[cid] = set(cadence.get("required_stale_verification_fences") or [])

    fence_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate stale verification fence_id {fid}")
        fence_by_id[fid] = fence
        cid = fence.get("cadence_id")
        if fence.get("fence_family") != "foundry_stale_verification_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if not require_sha256(fence.get("fence_digest")):
            errors.append(f"{rel}: fence {fid} missing sha256 fence_digest")
        if cid not in cadence_by_id:
            errors.append(f"{rel}: fence {fid} references missing cadence {cid}")
        if fence.get("fence_reason") not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {fence.get('fence_reason')!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        for aid in fence.get("affected_verification_audit_ids") or []:
            if aid not in source_audits:
                errors.append(f"{rel}: fence {fid} references unknown verification audit {aid}")
        for key in ["affected_signal_ids", "affected_verification_audit_ids", "blocked_uses", "required_recheck_or_clearance", "authority_boundaries"]:
            if not fence.get(key):
                errors.append(f"{rel}: fence {fid} missing {key}")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must name refused authority boundary")

    signals_by_id = {}
    signals_by_cadence = {}
    for signal in signals:
        signal_count += 1
        sid = signal.get("signal_id", "<missing>")
        if sid in signals_by_id:
            errors.append(f"{rel}: duplicate drift signal_id {sid}")
        signals_by_id[sid] = signal
        cid = signal.get("cadence_id")
        signals_by_cadence.setdefault(cid, set()).add(sid)
        if signal.get("signal_family") != "foundry_drift_signal_v0":
            errors.append(f"{rel}: signal {sid} has wrong signal_family")
        if cid not in cadence_by_id:
            errors.append(f"{rel}: signal {sid} references missing cadence {cid}")
            scope = {}
        else:
            scope = cadence_scopes.get(cid) or {}
        if not require_sha256(signal.get("signal_digest")):
            errors.append(f"{rel}: signal {sid} missing sha256 signal_digest")
        state = signal.get("signal_state")
        if state not in SIGNAL_STATES:
            errors.append(f"{rel}: signal {sid} has unknown signal_state {state!r}")
        else:
            signal_state_counts[state] += 1
        if not parse_time(signal.get("observed_at")):
            errors.append(f"{rel}: signal {sid} missing/unparsable observed_at")
        if signal.get("consumer_id") not in consumers:
            errors.append(f"{rel}: signal {sid} names unknown consumer")
        if scope:
            if signal.get("consumer_id") not in set(scope.get("consumers") or []):
                errors.append(f"{rel}: signal {sid} consumer outside cadence scope")
            if signal.get("surface_id") not in set(scope.get("surfaces") or []):
                errors.append(f"{rel}: signal {sid} surface outside cadence scope")
            if signal.get("audience_id") not in set(scope.get("audiences") or []):
                errors.append(f"{rel}: signal {sid} audience outside cadence scope")
            if signal.get("purpose_class") not in set(scope.get("purpose_classes") or []):
                errors.append(f"{rel}: signal {sid} purpose outside cadence scope")
        carrier_id = signal.get("carrier_id")
        if carrier_id:
            if carrier_id not in carrier_refs:
                errors.append(f"{rel}: signal {sid} references unknown carrier {carrier_id}")
            elif signal.get("carrier_digest") != carrier_refs[carrier_id].get("carrier_digest"):
                errors.append(f"{rel}: signal {sid} carrier digest mismatch")
        for key in ["probe_basis", "evidence_refs", "residue_checked", "blocked_uses", "non_promises"]:
            if not signal.get(key):
                errors.append(f"{rel}: signal {sid} missing {key}")
        if state in RISKY_SIGNAL_STATES and not signal.get("stale_verification_fence_refs"):
            errors.append(f"{rel}: risky signal {sid} must reference a stale-verification fence")
        for fid in signal.get("stale_verification_fence_refs") or []:
            if fid not in fence_by_id:
                errors.append(f"{rel}: signal {sid} references unknown stale-verification fence {fid}")
        np = " ".join(signal.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: signal {sid} must include authority/refusal non_promises")

    for fid, fence in fence_by_id.items():
        for sid in fence.get("affected_signal_ids") or []:
            if sid not in signals_by_id:
                errors.append(f"{rel}: fence {fid} references unknown signal {sid}")

    for cid, needed in required_signals.items():
        observed = signals_by_cadence.get(cid, set())
        missing = sorted(needed - observed)
        if missing:
            errors.append(f"{rel}: cadence {cid} missing required drift signals: {', '.join(missing)}")
    for cid, needed in required_fences.items():
        fence_ids_for_cadence = {fid for fid, fence in fence_by_id.items() if fence.get("cadence_id") == cid}
        missing = sorted(needed - fence_ids_for_cadence)
        if missing:
            errors.append(f"{rel}: cadence {cid} missing required stale-verification fences: {', '.join(missing)}")

    note = fixture.get("coverage_refactor_note") or {}
    for path in ["fixtures/schema-fixture-coverage/coverage.json", "tools/check_foundry_schema_fixture_coverage.py"]:
        if path not in {note.get("coverage_manifest"), note.get("checker")}: 
            errors.append(f"{rel}: coverage_refactor_note must name {path}")
    if not any("not" in item for item in note.get("blocked_inferences") or []):
        errors.append(f"{rel}: coverage_refactor_note must refuse overbroad coverage inference")

for status in ["active", "warning", "paused", "blocked"]:
    if cadence_status_counts[status] < 1:
        errors.append(f"specimen 91 must include at least one {status} recheck cadence")
for state in ["clear", "warning", "firing", "stale", "missing", "flapping", "superseded", "quarantined"]:
    if signal_state_counts[state] < 1:
        errors.append(f"specimen 91 must include at least one {state} drift signal")

fail(errors)
print(
    f"Foundry recheck/drift check passed for {fixture_count} fixture file(s), "
    f"{cadence_count} recheck cadence(s), {signal_count} drift signal(s), "
    f"and {fence_count} stale-verification fence(s)"
)
