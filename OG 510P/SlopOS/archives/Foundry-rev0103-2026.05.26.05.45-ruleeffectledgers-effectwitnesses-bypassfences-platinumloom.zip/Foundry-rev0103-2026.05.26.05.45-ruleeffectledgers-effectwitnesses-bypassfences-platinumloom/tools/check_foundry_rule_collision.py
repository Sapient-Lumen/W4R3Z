#!/usr/bin/env python3
"""Check Foundry specimen 95 rule-collision fixtures."""
from pathlib import Path
import json
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

FIXTURE_DIR = FIXTURES / "specimen-95-rule-collision"
LEDGER_STATUSES = {"detected", "precedence_assigned", "unresolved", "quarantined", "superseded", "non_conflict"}
WITNESS_STATUSES = {"applied", "partial", "refused", "shadow_only", "expired", "superseded"}
FENCE_REASONS = {
    "equal_priority_overlap",
    "contradictory_outcome",
    "missing_precedence_witness",
    "stale_rule_surface",
    "deprecated_rule_activation",
    "checker_rulebook_divergence",
    "scope_widening",
    "public_release_laundering",
    "authority_laundering",
    "sibling_boundary_laundering",
}
AUTHORITY_WORDS = ["authority", "authorize", "authorization", "audit", "release", "repair", "lifecycle", "verdict", "truth", "policy"]
SCOPE_KEYS = ["consumers", "surfaces", "audiences", "purpose_classes", "carriers", "rule_targets"]

errors = []
fixture_files = sorted(FIXTURE_DIR.glob("*.json"))
if not fixture_files:
    print("Missing specimen 95 fixture")
    sys.exit(1)

# Optional-but-required-in-this-revision rule surface index: it is the refactor twin of specimen 95.
rule_index_path = FIXTURES / "rule-surface-index" / "index.json"
known_rule_ids = set()
known_rulebook_paths = set()
known_checker_paths = set()
if rule_index_path.exists():
    index = load_json(rule_index_path)
    for surface in index.get("rulebook_surfaces") or []:
        known_rulebook_paths.add(surface.get("rulebook"))
        known_checker_paths.update(surface.get("checker_refs") or [])
        known_rule_ids.update(surface.get("rule_ids") or [])
else:
    errors.append("fixtures/rule-surface-index/index.json is required for specimen 95 collision checks")

ledger_count = witness_count = fence_count = 0
ledger_status_counts = {s: 0 for s in LEDGER_STATUSES}
witness_status_counts = {s: 0 for s in WITNESS_STATUSES}

for path in fixture_files:
    rel = path.relative_to(ROOT)
    data = load_json(path)
    if data.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if str(data.get("specimen_id")) != "95":
        errors.append(f"{rel}: wrong specimen_id")
    if not parse_time(data.get("fixture_now")):
        errors.append(f"{rel}: missing/unparsable fixture_now")

    source_ledgers = {l.get("ledger_id"): l for l in data.get("source_precedent_ledger_refs") or []}
    source_witnesses = {w.get("witness_id"): w for w in data.get("source_rule_promotion_witness_refs") or []}
    source_fences = {f.get("fence_id"): f for f in data.get("source_overgeneralization_fence_refs") or []}
    rule_refs = {r.get("rule_ref_id"): r for r in data.get("rule_surface_refs") or []}
    ledgers = data.get("rule_collision_ledgers") or []
    witnesses = data.get("precedence_witnesses") or []
    fences = data.get("ambiguity_fences") or []

    for name, index in [
        ("source precedent ledgers", source_ledgers),
        ("source promotion witnesses", source_witnesses),
        ("source overgeneralization fences", source_fences),
        ("rule surface refs", rule_refs),
    ]:
        if not index:
            errors.append(f"{rel}: missing {name}")

    for rid, ref in rule_refs.items():
        if not rid:
            errors.append(f"{rel}: rule ref missing rule_ref_id")
            continue
        if ref.get("rule_id") not in known_rule_ids:
            errors.append(f"{rel}: rule ref {rid} uses rule id not present in rule-surface index: {ref.get('rule_id')}")
        if ref.get("rulebook_path") not in known_rulebook_paths:
            errors.append(f"{rel}: rule ref {rid} uses unindexed rulebook {ref.get('rulebook_path')}")
        if ref.get("checker_path") not in known_checker_paths:
            errors.append(f"{rel}: rule ref {rid} uses unindexed checker {ref.get('checker_path')}")
        if ref.get("source_ledger_id") not in source_ledgers:
            errors.append(f"{rel}: rule ref {rid} points at unknown source ledger {ref.get('source_ledger_id')}")
        if ref.get("rule_status") in {"active", "candidate", "shadow", "deprecated", "superseded", "rejected", "quarantined"}:
            pass
        else:
            errors.append(f"{rel}: rule ref {rid} has unknown rule_status {ref.get('rule_status')!r}")

    ledger_by_id = {}
    required_witnesses = {}
    required_fences = {}
    for ledger in ledgers:
        ledger_count += 1
        lid = ledger.get("ledger_id", "<missing>")
        if lid in ledger_by_id:
            errors.append(f"{rel}: duplicate rule collision ledger_id {lid}")
        ledger_by_id[lid] = ledger
        if ledger.get("ledger_family") != "foundry_rule_collision_ledger_v0":
            errors.append(f"{rel}: ledger {lid} has wrong ledger_family")
        if not require_sha256(ledger.get("ledger_digest")):
            errors.append(f"{rel}: ledger {lid} missing sha256 ledger_digest")
        status = ledger.get("collision_status")
        if status not in LEDGER_STATUSES:
            errors.append(f"{rel}: ledger {lid} has unknown collision_status {status!r}")
        else:
            ledger_status_counts[status] += 1
        if not parse_time(ledger.get("detected_at")):
            errors.append(f"{rel}: ledger {lid} missing/unparsable detected_at")
        for key in ["source_precedent_ledger_ids", "source_rule_promotion_witness_ids", "conflicting_rule_refs", "collision_class", "overlap_scope", "required_precedence_witnesses", "required_ambiguity_fences", "authority_boundaries"]:
            if not ledger.get(key):
                errors.append(f"{rel}: ledger {lid} missing {key}")
        for sid in ledger.get("source_precedent_ledger_ids") or []:
            if sid not in source_ledgers:
                errors.append(f"{rel}: ledger {lid} references unknown source precedent ledger {sid}")
        for wid in ledger.get("source_rule_promotion_witness_ids") or []:
            if wid not in source_witnesses:
                errors.append(f"{rel}: ledger {lid} references unknown source promotion witness {wid}")
            elif source_witnesses[wid].get("ledger_id") not in set(ledger.get("source_precedent_ledger_ids") or []):
                errors.append(f"{rel}: ledger {lid} witness {wid} is not for a source precedent ledger in the collision")
        for fid in ledger.get("source_overgeneralization_fence_ids") or []:
            if fid not in source_fences:
                errors.append(f"{rel}: ledger {lid} references unknown source overgeneralization fence {fid}")
            elif source_fences[fid].get("ledger_id") not in set(ledger.get("source_precedent_ledger_ids") or []):
                errors.append(f"{rel}: ledger {lid} source fence {fid} is not for a source precedent ledger in the collision")
        for rrid in ledger.get("conflicting_rule_refs") or []:
            if rrid not in rule_refs:
                errors.append(f"{rel}: ledger {lid} references unknown rule ref {rrid}")
            elif rule_refs[rrid].get("source_ledger_id") not in set(ledger.get("source_precedent_ledger_ids") or []):
                errors.append(f"{rel}: ledger {lid} rule ref {rrid} is not sourced by this collision's precedent ledgers")
        scope = ledger.get("overlap_scope") or {}
        for skey in ["consumers", "surfaces", "audiences", "purpose_classes"]:
            if not scope.get(skey):
                errors.append(f"{rel}: ledger {lid} overlap_scope missing {skey}")
        required_witnesses[lid] = set(ledger.get("required_precedence_witnesses") or [])
        required_fences[lid] = set(ledger.get("required_ambiguity_fences") or [])
        boundary_text = " ".join(ledger.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: ledger {lid} must name refused authority boundary")

    fence_by_id = {}
    fences_by_ledger = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate ambiguity fence_id {fid}")
        fence_by_id[fid] = fence
        lid = fence.get("ledger_id")
        fences_by_ledger.setdefault(lid, set()).add(fid)
        if fence.get("fence_family") != "foundry_ambiguity_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if lid not in ledger_by_id:
            errors.append(f"{rel}: fence {fid} references missing ledger {lid}")
        if not require_sha256(fence.get("fence_digest")):
            errors.append(f"{rel}: fence {fid} missing sha256 fence_digest")
        if fence.get("fence_reason") not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {fence.get('fence_reason')!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        if not fence.get("blocked_actions") or not fence.get("required_clearance") or not fence.get("authority_boundaries"):
            errors.append(f"{rel}: fence {fid} missing blocked_actions/required_clearance/authority_boundaries")
        known_for_ledger = set((ledger_by_id.get(lid) or {}).get("conflicting_rule_refs") or [])
        for rrid in fence.get("affected_rule_refs") or []:
            if rrid not in rule_refs:
                errors.append(f"{rel}: fence {fid} references unknown rule ref {rrid}")
            elif known_for_ledger and rrid not in known_for_ledger:
                errors.append(f"{rel}: fence {fid} affected rule {rrid} is outside ledger {lid}'s conflict refs")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must name refused authority boundary")

    witness_by_id = {}
    witnesses_by_ledger = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if wid in witness_by_id:
            errors.append(f"{rel}: duplicate precedence witness_id {wid}")
        witness_by_id[wid] = witness
        lid = witness.get("ledger_id")
        witnesses_by_ledger.setdefault(lid, set()).add(wid)
        if witness.get("witness_family") != "foundry_precedence_witness_v0":
            errors.append(f"{rel}: witness {wid} has wrong witness_family")
        if lid not in ledger_by_id:
            errors.append(f"{rel}: witness {wid} references missing ledger {lid}")
            ledger_scope = {}
        else:
            ledger_scope = ledger_by_id[lid].get("overlap_scope") or {}
        if not require_sha256(witness.get("witness_digest")):
            errors.append(f"{rel}: witness {wid} missing sha256 witness_digest")
        status = witness.get("precedence_status")
        if status not in WITNESS_STATUSES:
            errors.append(f"{rel}: witness {wid} has unknown precedence_status {status!r}")
        else:
            witness_status_counts[status] += 1
        if not parse_time(witness.get("observed_at")):
            errors.append(f"{rel}: witness {wid} missing/unparsable observed_at")
        for key in ["resolver_role", "scope_echo", "basis_refs", "negative_case_ids", "blocked_inferences", "authority_boundaries"]:
            if not witness.get(key):
                errors.append(f"{rel}: witness {wid} missing {key}")
        if status in {"applied", "partial", "superseded"} and not witness.get("winning_rule_refs"):
            errors.append(f"{rel}: witness {wid} with status {status} must name winning_rule_refs")
        if status in {"applied", "partial"} and not witness.get("losing_rule_refs"):
            errors.append(f"{rel}: witness {wid} with status {status} must name losing_rule_refs")
        if status in {"refused", "shadow_only", "expired"} and not witness.get("residual_fence_refs"):
            errors.append(f"{rel}: witness {wid} with status {status} must preserve residual_fence_refs")
        ledger_rule_refs = set((ledger_by_id.get(lid) or {}).get("conflicting_rule_refs") or [])
        for rrid in (witness.get("winning_rule_refs") or []) + (witness.get("losing_rule_refs") or []):
            if rrid not in rule_refs:
                errors.append(f"{rel}: witness {wid} references unknown rule ref {rrid}")
            elif ledger_rule_refs and rrid not in ledger_rule_refs:
                errors.append(f"{rel}: witness {wid} rule ref {rrid} outside ledger {lid}'s conflict refs")
        echo = witness.get("scope_echo") or {}
        for skey in SCOPE_KEYS:
            extra = set(echo.get(skey) or []) - set(ledger_scope.get(skey) or [])
            if extra:
                errors.append(f"{rel}: witness {wid} scope_echo {skey} exceeds overlap scope: {', '.join(sorted(extra))}")
        for bid in witness.get("basis_refs") or []:
            if bid not in source_ledgers and bid not in source_witnesses and bid not in source_fences and bid not in fence_by_id:
                errors.append(f"{rel}: witness {wid} references unknown basis {bid}")
        for fid in witness.get("residual_fence_refs") or []:
            if fid not in fence_by_id and fid not in source_fences:
                errors.append(f"{rel}: witness {wid} references unknown residual fence {fid}")
        if status in {"applied", "partial"} and len(witness.get("negative_case_ids") or []) < 2:
            errors.append(f"{rel}: applied/partial witness {wid} must preserve at least two negative_case_ids")
        boundary_text = " ".join(witness.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: witness {wid} must name refused authority boundary")

    for lid, required in required_witnesses.items():
        missing = required - set(witness_by_id)
        if missing:
            errors.append(f"{rel}: ledger {lid} missing required precedence witnesses: {', '.join(sorted(missing))}")
        if not witnesses_by_ledger.get(lid):
            errors.append(f"{rel}: ledger {lid} has no precedence witness")
    for lid, required in required_fences.items():
        missing = required - set(fence_by_id)
        if missing:
            errors.append(f"{rel}: ledger {lid} missing required ambiguity fences: {', '.join(sorted(missing))}")
        if not fences_by_ledger.get(lid):
            errors.append(f"{rel}: ledger {lid} has no ambiguity fence")

    if not all(ledger_status_counts[s] for s in ["detected", "precedence_assigned", "unresolved", "quarantined", "superseded", "non_conflict"]):
        errors.append(f"{rel}: fixture must include detected, precedence_assigned, unresolved, quarantined, superseded, and non_conflict ledgers")
    if not all(witness_status_counts[s] for s in ["applied", "partial", "refused", "shadow_only", "expired", "superseded"]):
        errors.append(f"{rel}: fixture must include applied, partial, refused, shadow_only, expired, and superseded witnesses")
    reasons = {f.get("fence_reason") for f in fences}
    for required_reason in ["equal_priority_overlap", "contradictory_outcome", "missing_precedence_witness", "stale_rule_surface", "deprecated_rule_activation", "checker_rulebook_divergence", "public_release_laundering", "authority_laundering", "sibling_boundary_laundering"]:
        if required_reason not in reasons:
            errors.append(f"{rel}: fixture missing fence reason {required_reason}")

    negative_cases = data.get("negative_cases") or []
    if len(negative_cases) < 24:
        errors.append(f"{rel}: specimen 95 should include at least 24 negative cases")
    case_ids = [c.get("case_id") for c in negative_cases]
    if len(case_ids) != len(set(case_ids)):
        errors.append(f"{rel}: duplicate negative case ids")
    modes = " ".join((c.get("failure_mode", "") + " " + c.get("failure_code", "")) for c in negative_cases).lower()
    for phrase in ["equal", "contradictory", "order", "shadow", "deprecated", "stale", "checker", "authorization", "audit", "public", "sibling", "index"]:
        if phrase not in modes:
            errors.append(f"{rel}: negative cases should include {phrase} coverage")

fail(errors)
print(
    f"Foundry rule-collision check passed for {len(fixture_files)} fixture file(s), "
    f"{ledger_count} rule-collision ledger(s), {witness_count} precedence witness(es), and {fence_count} ambiguity fence(s)"
)
