#!/usr/bin/env python3
"""Check Foundry specimen 96 rule-evaluation fixtures."""
from pathlib import Path
import json
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

FIXTURE_DIR = FIXTURES / "specimen-96-rule-evaluation"
TRACE_STATUSES = {"applied", "refused", "partial", "skipped", "quarantined", "informational"}
WITNESS_STATUSES = {"applicable", "not_applicable", "partial", "ambiguous", "expired", "shadow_only"}
FENCE_REASONS = {
    "wrong_context",
    "scope_widening",
    "missing_applicability_witness",
    "skipped_rule_erasure",
    "stale_context",
    "deprecated_rule_activation",
    "shadow_rule_activation",
    "default_as_decision",
    "ambiguity_fence_ignored",
    "public_release_laundering",
    "authority_laundering",
    "repair_lifecycle_laundering",
    "sibling_boundary_laundering",
    "checker_contract_index_drift",
}
SCOPE_KEYS = ["consumers", "surfaces", "audiences", "purpose_classes", "carriers", "rule_targets"]
AUTHORITY_WORDS = ["author", "audit", "release", "repair", "lifecycle", "verdict", "truth", "approval", "policy", "proof"]

errors = []
fixture_files = sorted(FIXTURE_DIR.glob("*.json"))
if not fixture_files:
    print("Missing specimen 96 fixture")
    sys.exit(1)

# Rule surface index is the global rulebook/rule/checker inventory introduced in rev0101.
rule_index_path = FIXTURES / "rule-surface-index" / "index.json"
known_rule_ids = set()
known_rulebooks = set()
known_checkers = set()
if rule_index_path.exists():
    idx = load_json(rule_index_path)
    for surface in idx.get("rulebook_surfaces") or []:
        known_rulebooks.add(surface.get("rulebook"))
        known_checkers.update(surface.get("checker_refs") or [])
        known_rule_ids.update(surface.get("rule_ids") or [])
else:
    errors.append("fixtures/rule-surface-index/index.json is required for specimen 96")

# Specimen 95 is the immediate predecessor: rule evaluation must not detach from collision/precedence residue.
source_fixture_path = FIXTURES / "specimen-95-rule-collision" / "fixture.json"
source_ledgers = {}
source_witnesses = {}
source_fences = {}
source_rule_refs = {}
if source_fixture_path.exists():
    source = load_json(source_fixture_path)
    source_ledgers = {l.get("ledger_id"): l for l in source.get("rule_collision_ledgers") or []}
    source_witnesses = {w.get("witness_id"): w for w in source.get("precedence_witnesses") or []}
    source_fences = {f.get("fence_id"): f for f in source.get("ambiguity_fences") or []}
    source_rule_refs = {r.get("rule_ref_id"): r for r in source.get("rule_surface_refs") or []}
else:
    errors.append("fixtures/specimen-95-rule-collision/fixture.json is required for specimen 96")

trace_count = witness_count = fence_count = 0
trace_status_counts = {s: 0 for s in TRACE_STATUSES}
witness_status_counts = {s: 0 for s in WITNESS_STATUSES}

for path in fixture_files:
    rel = path.relative_to(ROOT)
    data = load_json(path)
    if data.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if str(data.get("specimen_id")) != "96":
        errors.append(f"{rel}: wrong specimen_id")
    if not parse_time(data.get("fixture_now")):
        errors.append(f"{rel}: missing/unparsable fixture_now")

    local_ledgers = {l.get("ledger_id"): l for l in data.get("source_rule_collision_ledger_refs") or []}
    local_precedence = {w.get("witness_id"): w for w in data.get("source_precedence_witness_refs") or []}
    local_ambiguity = {f.get("fence_id"): f for f in data.get("source_ambiguity_fence_refs") or []}
    rule_refs = {r.get("rule_ref_id"): r for r in data.get("rule_surface_refs") or []}
    subjects = {s.get("subject_id"): s for s in data.get("evaluation_subjects") or []}
    traces = data.get("rule_evaluation_traces") or []
    witnesses = data.get("applicability_witnesses") or []
    fences = data.get("misapplication_fences") or []
    negative_cases = data.get("negative_cases") or []

    for name, index in [
        ("source rule-collision ledger refs", local_ledgers),
        ("source precedence witness refs", local_precedence),
        ("source ambiguity fence refs", local_ambiguity),
        ("rule surface refs", rule_refs),
        ("evaluation subjects", subjects),
    ]:
        if not index:
            errors.append(f"{rel}: missing {name}")

    for lid, ledger in local_ledgers.items():
        if lid not in source_ledgers:
            errors.append(f"{rel}: source ledger ref {lid} is not present in specimen 95")
        if not require_sha256(ledger.get("ledger_digest")):
            errors.append(f"{rel}: source ledger ref {lid} missing sha256 digest")
    for wid, witness in local_precedence.items():
        if wid not in source_witnesses:
            errors.append(f"{rel}: precedence witness ref {wid} is not present in specimen 95")
        elif witness.get("ledger_id") != source_witnesses[wid].get("ledger_id"):
            errors.append(f"{rel}: precedence witness ref {wid} ledger mismatch")
        if witness.get("ledger_id") not in local_ledgers:
            errors.append(f"{rel}: precedence witness ref {wid} points outside local source ledgers")
        if not require_sha256(witness.get("witness_digest")):
            errors.append(f"{rel}: precedence witness ref {wid} missing sha256 digest")
    for fid, fence in local_ambiguity.items():
        if fid not in source_fences:
            errors.append(f"{rel}: ambiguity fence ref {fid} is not present in specimen 95")
        elif fence.get("ledger_id") != source_fences[fid].get("ledger_id"):
            errors.append(f"{rel}: ambiguity fence ref {fid} ledger mismatch")
        if fence.get("ledger_id") not in local_ledgers:
            errors.append(f"{rel}: ambiguity fence ref {fid} points outside local source ledgers")

    for rid, ref in rule_refs.items():
        if not rid:
            errors.append(f"{rel}: rule surface ref missing rule_ref_id")
            continue
        if rid not in source_rule_refs:
            errors.append(f"{rel}: rule surface ref {rid} is not present in specimen 95")
        if ref.get("rule_id") not in known_rule_ids:
            errors.append(f"{rel}: rule surface ref {rid} uses unindexed rule id {ref.get('rule_id')}")
        if ref.get("rulebook_path") not in known_rulebooks:
            errors.append(f"{rel}: rule surface ref {rid} uses unindexed rulebook {ref.get('rulebook_path')}")
        if ref.get("checker_path") not in known_checkers:
            errors.append(f"{rel}: rule surface ref {rid} uses unindexed checker {ref.get('checker_path')}")
        if ref.get("rule_status") not in {"active", "candidate", "shadow", "deprecated", "superseded", "rejected", "quarantined"}:
            errors.append(f"{rel}: rule surface ref {rid} has unknown rule_status {ref.get('rule_status')!r}")

    trace_by_id = {}
    required_fences = {}
    for trace in traces:
        trace_count += 1
        tid = trace.get("trace_id", "<missing>")
        if tid in trace_by_id:
            errors.append(f"{rel}: duplicate trace_id {tid}")
        trace_by_id[tid] = trace
        if trace.get("trace_family") != "foundry_rule_evaluation_trace_v0":
            errors.append(f"{rel}: trace {tid} has wrong trace_family")
        if not require_sha256(trace.get("trace_digest")):
            errors.append(f"{rel}: trace {tid} missing sha256 trace_digest")
        status = trace.get("evaluation_status")
        if status not in TRACE_STATUSES:
            errors.append(f"{rel}: trace {tid} has unknown evaluation_status {status!r}")
        else:
            trace_status_counts[status] += 1
        if not parse_time(trace.get("evaluated_at")):
            errors.append(f"{rel}: trace {tid} missing/unparsable evaluated_at")
        subject_id = trace.get("subject_ref")
        if subject_id not in subjects:
            errors.append(f"{rel}: trace {tid} references unknown subject {subject_id}")
        for key in ["source_collision_ledger_ids", "source_precedence_witness_ids", "source_ambiguity_fence_ids", "candidate_rule_refs", "evaluation_context", "applicability_witness_ids", "required_misapplication_fences", "output_decision", "blocked_inferences", "authority_boundaries"]:
            if not trace.get(key):
                errors.append(f"{rel}: trace {tid} missing {key}")
        for lid in trace.get("source_collision_ledger_ids") or []:
            if lid not in local_ledgers:
                errors.append(f"{rel}: trace {tid} references unknown source ledger {lid}")
        for wid in trace.get("source_precedence_witness_ids") or []:
            if wid not in local_precedence:
                errors.append(f"{rel}: trace {tid} references unknown precedence witness {wid}")
            elif local_precedence[wid].get("ledger_id") not in set(trace.get("source_collision_ledger_ids") or []):
                errors.append(f"{rel}: trace {tid} precedence witness {wid} is not tied to trace source ledgers")
        for fid in trace.get("source_ambiguity_fence_ids") or []:
            if fid not in local_ambiguity:
                errors.append(f"{rel}: trace {tid} references unknown ambiguity fence {fid}")
            elif local_ambiguity[fid].get("ledger_id") not in set(trace.get("source_collision_ledger_ids") or []):
                errors.append(f"{rel}: trace {tid} ambiguity fence {fid} is not tied to trace source ledgers")
        for rrid in (trace.get("candidate_rule_refs") or []) + (trace.get("selected_rule_refs") or []) + (trace.get("skipped_rule_refs") or []):
            if rrid not in rule_refs:
                errors.append(f"{rel}: trace {tid} references unknown rule ref {rrid}")
        if set(trace.get("selected_rule_refs") or []) - set(trace.get("candidate_rule_refs") or []):
            errors.append(f"{rel}: trace {tid} selected rules must be a subset of candidate rules")
        if set(trace.get("skipped_rule_refs") or []) - set(trace.get("candidate_rule_refs") or []):
            errors.append(f"{rel}: trace {tid} skipped rules must be a subset of candidate rules")
        if not (set(trace.get("selected_rule_refs") or []) | set(trace.get("skipped_rule_refs") or [])):
            errors.append(f"{rel}: trace {tid} must have selected or skipped rules")
        context = trace.get("evaluation_context") or {}
        for skey in SCOPE_KEYS:
            if not context.get(skey):
                errors.append(f"{rel}: trace {tid} evaluation_context missing {skey}")
        subj = subjects.get(subject_id) or {}
        if subj:
            expected = {
                "consumers": subj.get("consumer"),
                "surfaces": subj.get("surface"),
                "audiences": subj.get("audience"),
                "purpose_classes": subj.get("purpose_class"),
                "carriers": subj.get("carrier_id"),
                "rule_targets": subj.get("rule_target"),
            }
            for key, value in expected.items():
                if value and value not in (context.get(key) or []):
                    errors.append(f"{rel}: trace {tid} context {key} does not echo subject {value}")
            if context.get("input_digest") != subj.get("carrier_digest"):
                errors.append(f"{rel}: trace {tid} input_digest does not match subject carrier_digest")
        decision_text = json.dumps(trace.get("output_decision") or {}).lower()
        if not any(word in decision_text for word in ["refuse", "quarantine", "skip", "record", "partial"]):
            errors.append(f"{rel}: trace {tid} output_decision should be bounded/refusal-like")
        boundary_text = " ".join((trace.get("blocked_inferences") or []) + (trace.get("authority_boundaries") or [])).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: trace {tid} must block authority/audit/release/repair/lifecycle/sibling inferences")
        required_fences[tid] = set(trace.get("required_misapplication_fences") or [])

    witness_by_id = {}
    witnesses_by_trace_rule = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if wid in witness_by_id:
            errors.append(f"{rel}: duplicate applicability witness_id {wid}")
        witness_by_id[wid] = witness
        tid = witness.get("trace_id")
        rule_ref = witness.get("rule_ref")
        witnesses_by_trace_rule[(tid, rule_ref)] = witness
        if witness.get("witness_family") != "foundry_applicability_witness_v0":
            errors.append(f"{rel}: witness {wid} has wrong witness_family")
        if tid not in trace_by_id:
            errors.append(f"{rel}: witness {wid} references missing trace {tid}")
        if rule_ref not in rule_refs:
            errors.append(f"{rel}: witness {wid} references unknown rule ref {rule_ref}")
        if witness.get("subject_ref") not in subjects:
            errors.append(f"{rel}: witness {wid} references unknown subject {witness.get('subject_ref')}")
        if not require_sha256(witness.get("witness_digest")):
            errors.append(f"{rel}: witness {wid} missing sha256 witness_digest")
        status = witness.get("applicability_status")
        if status not in WITNESS_STATUSES:
            errors.append(f"{rel}: witness {wid} has unknown applicability_status {status!r}")
        else:
            witness_status_counts[status] += 1
        if not parse_time(witness.get("observed_at")):
            errors.append(f"{rel}: witness {wid} missing/unparsable observed_at")
        for key in ["context_echo", "required_inputs", "basis_refs", "negative_case_ids", "blocked_inferences", "authority_boundaries"]:
            if not witness.get(key):
                errors.append(f"{rel}: witness {wid} missing {key}")
        context = witness.get("context_echo") or {}
        for skey in SCOPE_KEYS:
            if not context.get(skey):
                errors.append(f"{rel}: witness {wid} context_echo missing {skey}")
        trace = trace_by_id.get(tid) or {}
        if trace:
            if witness.get("witness_id") not in (trace.get("applicability_witness_ids") or []):
                errors.append(f"{rel}: witness {wid} is not listed on trace {tid}")
            if witness.get("subject_ref") != trace.get("subject_ref"):
                errors.append(f"{rel}: witness {wid} subject does not match trace {tid}")
            if context != (trace.get("evaluation_context") or {}):
                errors.append(f"{rel}: witness {wid} context_echo does not match trace {tid} evaluation_context")
        if status == "applicable" and witness.get("missing_inputs"):
            errors.append(f"{rel}: witness {wid} is applicable but has missing_inputs")
        if status in {"not_applicable", "partial", "ambiguous", "expired", "shadow_only"} and not witness.get("residual_fence_refs"):
            errors.append(f"{rel}: witness {wid} needs residual fences for non-applicable/partial/ambiguous/expired/shadow-only status")
        boundary_text = " ".join((witness.get("blocked_inferences") or []) + (witness.get("authority_boundaries") or [])).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: witness {wid} must block authority/audit/release/repair/lifecycle/sibling inferences")

    fence_by_id = {}
    fences_by_trace = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate misapplication fence_id {fid}")
        fence_by_id[fid] = fence
        tid = fence.get("trace_id")
        fences_by_trace.setdefault(tid, set()).add(fid)
        if fence.get("fence_family") != "foundry_misapplication_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if tid not in trace_by_id:
            errors.append(f"{rel}: fence {fid} references missing trace {tid}")
        if not require_sha256(fence.get("fence_digest")):
            errors.append(f"{rel}: fence {fid} missing sha256 fence_digest")
        if fence.get("fence_reason") not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {fence.get('fence_reason')!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        for key in ["affected_rule_refs", "subject_refs", "blocked_actions", "required_clearance", "authority_boundaries"]:
            if not fence.get(key):
                errors.append(f"{rel}: fence {fid} missing {key}")
        trace_rules = set((trace_by_id.get(tid) or {}).get("candidate_rule_refs") or [])
        for rrid in fence.get("affected_rule_refs") or []:
            if rrid not in rule_refs:
                errors.append(f"{rel}: fence {fid} references unknown rule ref {rrid}")
            elif trace_rules and rrid not in trace_rules:
                errors.append(f"{rel}: fence {fid} affects rule {rrid} outside trace {tid} candidate rules")
        for sid in fence.get("subject_refs") or []:
            if sid not in subjects:
                errors.append(f"{rel}: fence {fid} references unknown subject {sid}")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must block authority/audit/release/repair/lifecycle/sibling inferences")

    for trace in traces:
        tid = trace.get("trace_id")
        listed_wids = set(trace.get("applicability_witness_ids") or [])
        for wid in listed_wids:
            if wid not in witness_by_id:
                errors.append(f"{rel}: trace {tid} lists missing applicability witness {wid}")
        for rrid in (trace.get("selected_rule_refs") or []) + (trace.get("skipped_rule_refs") or []):
            if (tid, rrid) not in witnesses_by_trace_rule:
                errors.append(f"{rel}: trace {tid} lacks applicability witness for rule {rrid}")
        if not required_fences.get(tid, set()).issubset(fences_by_trace.get(tid, set())):
            missing = sorted(required_fences.get(tid, set()) - fences_by_trace.get(tid, set()))
            errors.append(f"{rel}: trace {tid} missing required misapplication fences: {', '.join(missing)}")
        if trace.get("evaluation_status") in {"applied", "partial"} and not trace.get("selected_rule_refs"):
            errors.append(f"{rel}: trace {tid} has {trace.get('evaluation_status')} without selected_rule_refs")
        if trace.get("evaluation_status") in {"refused", "quarantined"} and not trace.get("required_misapplication_fences"):
            errors.append(f"{rel}: trace {tid} refused/quarantined without required fences")

    case_ids = [c.get("case_id") for c in negative_cases]
    if len(case_ids) != len(set(case_ids)):
        errors.append(f"{rel}: duplicate negative case ids")
    if len(negative_cases) < 20:
        errors.append(f"{rel}: specimen 96 must carry at least 20 negative cases")
    for case in negative_cases:
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")
        if not case.get("failure_code") or not case.get("failure_mode") or not case.get("expected_failure"):
            errors.append(f"{rel}: negative case {case.get('case_id')} missing failure_code/failure_mode/expected_failure")
    negative_text = " ".join((c.get("failure_code", "") + " " + c.get("failure_mode", "")) for c in negative_cases).lower()
    for word in ["precedence", "applicability", "context", "default", "deprecated", "shadow", "public", "authorization", "audit", "repair", "lifecycle", "sibling", "checker"]:
        if word not in negative_text:
            errors.append(f"{rel}: negative cases should cover {word}")

# Status distribution keeps the specimen from being all happy path.
for status in ["applied", "refused", "partial", "quarantined", "skipped", "informational"]:
    if trace_status_counts.get(status, 0) == 0:
        errors.append(f"specimen 96 needs at least one {status} trace")
for status in ["applicable", "not_applicable", "partial", "ambiguous", "expired", "shadow_only"]:
    if witness_status_counts.get(status, 0) == 0:
        errors.append(f"specimen 96 needs at least one {status} applicability witness")

fail(errors)
print(
    f"Foundry rule-evaluation check passed for {len(fixture_files)} fixture file(s), "
    f"{trace_count} evaluation trace(s), {witness_count} applicability witness(es), and {fence_count} misapplication fence(s)"
)
