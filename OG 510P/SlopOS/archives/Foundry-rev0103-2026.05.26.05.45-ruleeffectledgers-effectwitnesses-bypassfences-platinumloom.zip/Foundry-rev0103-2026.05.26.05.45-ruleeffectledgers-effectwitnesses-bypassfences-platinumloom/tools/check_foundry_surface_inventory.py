#!/usr/bin/env python3
"""Check Foundry surface-inventory fixtures.

Specimen 86 is about proving that post-distribution inventory found or fenced
reachable semantic carriers without turning Foundry into a catalog, CMDB,
object-store inventory, lineage graph, cache-control system, cleanup system,
SBOM, or sibling-cube authority.
"""
from pathlib import Path
from datetime import datetime
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-INV-001-SURFACE-INVENTORY-SWEEP",
    "R-INV-002-SCOPE-AND-SEED",
    "R-INV-003-REACHABILITY-WITNESS",
    "R-INV-004-ALTERNATE-ID-RESOLUTION",
    "R-INV-005-EXPECTED-SURFACE-COVERAGE",
    "R-INV-006-COVERAGE-GAP-FENCE",
    "R-INV-007-SWEEP-WINDOW-AND-RECENCY",
    "R-INV-008-PARTIAL-SWEEP-NO-CLOSURE",
    "R-INV-009-UNKNOWN-SURFACE-NO-ADOPTION",
    "R-INV-010-OWNER-BOUNDARY",
    "R-INV-011-AUTHORITY-LAUNDERING-FENCE",
    "R-INV-012-RECHECK-HOOK",
}

REQUIRED_FAILURE_CODES = {
    "surface_inventory_sweep_required",
    "seed_manifest_required",
    "reachability_witness_required",
    "expected_surface_unaccounted_refused",
    "unknown_surface_unfenced_refused",
    "alternate_identifier_unresolved_refused",
    "sweep_window_expired_refused",
    "partial_sweep_as_complete_refused",
    "owner_scope_mismatch_refused",
    "gap_fence_required",
    "witness_digest_mismatch_refused",
    "discovered_copy_as_adopted_refused",
    "inventory_as_catalog_refused",
    "inventory_as_truth_refused",
    "permission_denied_without_recheck_refused",
    "duplicate_surface_accounting_refused",
}

SWEEP_STATUSES = {"complete", "partial", "blocked", "superseded", "retired"}
REACHABILITY_STATES = {"reachable", "quarantined", "retired_as_history", "unknown", "permission_denied", "not_reachable"}
GAP_TYPES = {"unobserved_expected_surface", "unknown_surface", "unlinked_copy", "digest_mismatch", "permission_denied", "ambiguous_owner", "duplicate_accounting", "expired_sweep"}
GAP_RESULTS = {"blocked", "quarantined", "recheck_required", "retired_as_history", "monitor_only"}
AUTHORITY_WORDS = {"truth", "catalog", "approval", "opinion", "permission", "custody", "deletion", "repair", "remediation", "cache", "proof"}


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("surface_inventory_sweeps"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No surface_inventory_sweeps fixture found for specimen 86.")

sweep_count = 0
witness_count = 0
fence_count = 0
complete_sweeps = 0
partial_sweeps = 0
blocked_sweeps = 0
reachable_witnesses = 0
quarantined_witnesses = 0
retired_witnesses = 0
permission_or_unknown_witnesses = 0
blocked_fences = 0
quarantined_fences = 0
recheck_fences = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    consumer_ids = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    distribution_ids = {d.get("manifest_id") for d in data.get("distribution_refs", []) if d.get("manifest_id")}
    carriers = {c.get("carrier_id"): c for c in data.get("carrier_refs", []) if c.get("carrier_id")}

    sweeps = data.get("surface_inventory_sweeps") or []
    witnesses = data.get("reachability_witnesses") or []
    fences = data.get("coverage_gap_fences") or []
    if not sweeps:
        errors.append(f"{rel}: surface_inventory_sweeps must be non-empty")

    sweeps_by_id = {}
    sweep_windows = {}
    for sweep in sweeps:
        sweep_count += 1
        sid = sweep.get("sweep_id", "<missing>")
        if sid in sweeps_by_id:
            errors.append(f"{rel}: duplicate sweep_id {sid}")
        sweeps_by_id[sid] = sweep
        if sweep.get("sweep_family") != "foundry_surface_inventory_sweep_v0":
            errors.append(f"{rel}: sweep {sid} has wrong sweep_family")
        if not str(sweep.get("sweep_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: sweep {sid} missing sha256 sweep_digest")
        status = sweep.get("sweep_status")
        if status not in SWEEP_STATUSES:
            errors.append(f"{rel}: sweep {sid} has unknown sweep_status {status!r}")
        if status == "complete":
            complete_sweeps += 1
        if status == "partial":
            partial_sweeps += 1
        if status == "blocked":
            blocked_sweeps += 1
        issued = parse_time(sweep.get("issued_at"))
        completed = parse_time(sweep.get("completed_at"))
        if not issued or not completed or issued > completed:
            errors.append(f"{rel}: sweep {sid} has invalid issued_at/completed_at")
        else:
            sweep_windows[sid] = (issued, completed)
        for key in ["source_distribution_manifest_ids", "seed_carrier_ids", "inventory_scope", "expected_surface_ids", "discovery_sources", "method_limits", "required_reachability_witnesses", "authority_boundaries"]:
            if not sweep.get(key):
                errors.append(f"{rel}: sweep {sid} missing {key}")
        missing_manifests = set(sweep.get("source_distribution_manifest_ids") or []) - distribution_ids
        if missing_manifests:
            errors.append(f"{rel}: sweep {sid} references unknown distribution manifests: {', '.join(sorted(missing_manifests))}")
        missing_carriers = set(sweep.get("seed_carrier_ids") or []) - set(carriers)
        if missing_carriers:
            errors.append(f"{rel}: sweep {sid} references unknown seed carriers: {', '.join(sorted(missing_carriers))}")
        scope = sweep.get("inventory_scope") or {}
        scope_consumers = set(scope.get("consumers") or [])
        unknown_consumers = scope_consumers - consumer_ids
        if unknown_consumers:
            errors.append(f"{rel}: sweep {sid} scopes unknown consumers: {', '.join(sorted(unknown_consumers))}")
        scope_surfaces = set(scope.get("surfaces") or [])
        expected_surfaces = set(sweep.get("expected_surface_ids") or [])
        if not expected_surfaces <= scope_surfaces:
            errors.append(f"{rel}: sweep {sid} has expected surfaces outside inventory_scope.surfaces: {', '.join(sorted(expected_surfaces - scope_surfaces))}")
        boundary_text = " ".join(sweep.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: sweep {sid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: sweep {sid} authority boundaries should name a refused authority")
        if status in {"partial", "blocked"} and not any(word in boundary_text for word in ["partial", "blocked", "not_complete"]):
            errors.append(f"{rel}: sweep {sid} partial/blocked status must refuse complete closure")

    witnesses_by_id = {}
    accounted_by_sweep = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        sid = witness.get("sweep_id")
        if wid in witnesses_by_id:
            errors.append(f"{rel}: duplicate witness_id {wid}")
        witnesses_by_id[wid] = witness
        if witness.get("witness_family") != "foundry_reachability_witness_v0":
            errors.append(f"{rel}: reachability witness {wid} has wrong witness_family")
        if sid not in sweeps_by_id:
            errors.append(f"{rel}: reachability witness {wid} references missing sweep {sid}")
            sweep = {}
        else:
            sweep = sweeps_by_id[sid]
        if not str(witness.get("artifact_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: reachability witness {wid} missing sha256 artifact_digest")
        state = witness.get("reachability_state")
        if state not in REACHABILITY_STATES:
            errors.append(f"{rel}: reachability witness {wid} has unknown reachability_state {state!r}")
        if state == "reachable":
            reachable_witnesses += 1
        if state == "quarantined":
            quarantined_witnesses += 1
        if state == "retired_as_history":
            retired_witnesses += 1
        if state in {"unknown", "permission_denied", "not_reachable"}:
            permission_or_unknown_witnesses += 1
        cid = witness.get("consumer_id")
        if cid not in consumer_ids:
            errors.append(f"{rel}: reachability witness {wid} names unknown consumer {cid}")
        if sweep:
            scope = sweep.get("inventory_scope") or {}
            if cid not in set(scope.get("consumers") or []):
                errors.append(f"{rel}: reachability witness {wid} consumer {cid} is outside sweep scope")
            surface = witness.get("surface_id")
            if surface not in set(scope.get("surfaces") or []):
                errors.append(f"{rel}: reachability witness {wid} surface {surface} is outside sweep scope")
            observed = parse_time(witness.get("observed_at"))
            if not observed:
                errors.append(f"{rel}: reachability witness {wid} missing/unparsable observed_at")
            elif sid in sweep_windows:
                opened, closed = sweep_windows[sid]
                if not (opened <= observed <= closed):
                    errors.append(f"{rel}: reachability witness {wid} observed outside sweep window")
            if surface:
                accounted_by_sweep.setdefault(sid, set()).add(surface)
        cid_ref = witness.get("carrier_id")
        if cid_ref:
            if cid_ref not in carriers:
                errors.append(f"{rel}: reachability witness {wid} references unknown carrier {cid_ref}")
            elif witness.get("carrier_digest") != carriers[cid_ref].get("carrier_digest"):
                errors.append(f"{rel}: reachability witness {wid} carrier digest mismatch")
        for key in ["discovery_path", "alternate_identifiers", "residue_seen", "blocked_uses", "non_promises"]:
            if not witness.get(key):
                errors.append(f"{rel}: reachability witness {wid} missing {key}")
        aliases = witness.get("alternate_identifiers") or []
        if not any(alias.get("canonical_surface_id") == witness.get("surface_id") for alias in aliases if isinstance(alias, dict)):
            errors.append(f"{rel}: reachability witness {wid} lacks canonical alternate identifier evidence")
        np = " ".join(witness.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: reachability witness {wid} must include authority/refusal non_promises")
        if state in {"permission_denied", "unknown", "not_reachable"} and not any(word in " ".join(witness.get("blocked_uses") or []).lower() for word in ["absence", "claim", "adoption"]):
            errors.append(f"{rel}: witness {wid} with {state} must block absence/adoption overclaim")

    fences_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        sid = fence.get("sweep_id")
        if fid in fences_by_id:
            errors.append(f"{rel}: duplicate coverage gap fence {fid}")
        fences_by_id[fid] = fence
        if fence.get("fence_family") != "foundry_coverage_gap_fence_v0":
            errors.append(f"{rel}: coverage-gap fence {fid} has wrong fence_family")
        if sid not in sweeps_by_id:
            errors.append(f"{rel}: coverage-gap fence {fid} references missing sweep {sid}")
            sweep = {}
        else:
            sweep = sweeps_by_id[sid]
        gap_type = fence.get("gap_type")
        if gap_type not in GAP_TYPES:
            errors.append(f"{rel}: coverage-gap fence {fid} has unknown gap_type {gap_type!r}")
        result = fence.get("gap_result")
        if result not in GAP_RESULTS:
            errors.append(f"{rel}: coverage-gap fence {fid} has unknown gap_result {result!r}")
        if result == "blocked":
            blocked_fences += 1
        if result == "quarantined":
            quarantined_fences += 1
        if result == "recheck_required":
            recheck_fences += 1
        owner = fence.get("affected_consumer_id")
        if owner not in consumer_ids:
            errors.append(f"{rel}: coverage-gap fence {fid} names unknown affected_consumer_id {owner}")
        if sweep:
            scope = sweep.get("inventory_scope") or {}
            if owner not in set(scope.get("consumers") or []):
                errors.append(f"{rel}: coverage-gap fence {fid} owner {owner} is outside sweep scope")
            surface = fence.get("affected_surface_id")
            if surface not in set(scope.get("surfaces") or []):
                errors.append(f"{rel}: coverage-gap fence {fid} surface {surface} is outside sweep scope")
            if surface:
                accounted_by_sweep.setdefault(sid, set()).add(surface)
        detected = parse_time(fence.get("detected_at"))
        if not detected:
            errors.append(f"{rel}: coverage-gap fence {fid} missing/unparsable detected_at")
        elif sid in sweep_windows:
            opened, closed = sweep_windows[sid]
            if not (opened <= detected <= closed):
                errors.append(f"{rel}: coverage-gap fence {fid} detected outside sweep window")
        if fence.get("discovered_artifact_digest") and not str(fence.get("discovered_artifact_digest")).startswith("sha256:"):
            errors.append(f"{rel}: coverage-gap fence {fid} has malformed discovered_artifact_digest")
        for key in ["missing_evidence", "required_clearance", "blocked_uses", "non_promises"]:
            if not fence.get(key):
                errors.append(f"{rel}: coverage-gap fence {fid} missing {key}")
        if gap_type == "permission_denied" and not fence.get("recheck_after"):
            errors.append(f"{rel}: permission-denied fence {fid} must name recheck_after")
        np = " ".join(fence.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: coverage-gap fence {fid} must refuse authority overclaims")

    for sid, sweep in sweeps_by_id.items():
        expected = set(sweep.get("expected_surface_ids") or [])
        accounted = accounted_by_sweep.get(sid, set())
        missing = expected - accounted
        if missing:
            errors.append(f"{rel}: sweep {sid} lacks reachability witness or gap fence for expected surfaces: {', '.join(sorted(missing))}")
        missing_witnesses = set(sweep.get("required_reachability_witnesses") or []) - set(witnesses_by_id)
        if missing_witnesses:
            errors.append(f"{rel}: sweep {sid} lists missing required reachability witnesses: {', '.join(sorted(missing_witnesses))}")
        missing_fences = set(sweep.get("required_gap_fences") or []) - set(fences_by_id)
        if missing_fences:
            errors.append(f"{rel}: sweep {sid} lists missing required gap fences: {', '.join(sorted(missing_fences))}")
        for wid in sweep.get("required_reachability_witnesses") or []:
            if wid in witnesses_by_id and witnesses_by_id[wid].get("sweep_id") != sid:
                errors.append(f"{rel}: sweep {sid} required witness {wid} belongs to another sweep")
        for fid in sweep.get("required_gap_fences") or []:
            if fid in fences_by_id and fences_by_id[fid].get("sweep_id") != sid:
                errors.append(f"{rel}: sweep {sid} required gap fence {fid} belongs to another sweep")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if complete_sweeps < 1 or partial_sweeps < 1 or blocked_sweeps < 1:
    errors.append("Specimen 86 needs complete, partial, and blocked surface inventory sweep examples.")
if reachable_witnesses < 1 or quarantined_witnesses < 1 or retired_witnesses < 1 or permission_or_unknown_witnesses < 1:
    errors.append("Specimen 86 needs reachable, quarantined, retired_as_history, and permission/unknown reachability examples.")
if blocked_fences < 1 or quarantined_fences < 1 or recheck_fences < 1:
    errors.append("Specimen 86 needs blocked, quarantined, and recheck_required coverage gap fences.")

rulebook = ROOT / "docs/30-architecture/surface-inventory-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing surface inventory rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = sorted(rule for rule in REQUIRED_RULES if rule not in text)
    if missing_rules:
        errors.append("Surface inventory rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry surface inventory check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry surface inventory check passed for {len(fixtures)} fixture file(s), {sweep_count} surface inventory sweep(s), {witness_count} reachability witness(es), and {fence_count} coverage gap fence(s)")
