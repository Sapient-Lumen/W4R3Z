#!/usr/bin/env python3
"""Check Foundry egress refusal receipts.

This intentionally validates semantic survival properties, not full JSON Schema.
Specimen 78 requires every refused egress attempt to have a digest-addressed
receipt with a rule id, problem-details object, named semantic loss, repair
escapes, and non-retryable-without residue.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-EGRESS-001-SIDECAR-OR-INBAND",
    "R-EGRESS-002-NAMED-SEMANTIC-LOSS",
    "R-EGRESS-003-REPAIR-ESCAPE",
    "R-EGRESS-004-CLASSIFICATION-PINS",
    "R-EGRESS-005-CUT-MISMATCH",
    "R-EGRESS-006-STATUS-PRESERVATION",
}

errors = []
manifests = []
receipts_by_id = {}
receipt_paths = {}
seen_rules = set()

for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("egress_manifest"), dict):
        manifests.append((path, data["egress_manifest"]))
    if isinstance(data, dict):
        for receipt in data.get("refusal_receipts", []) or []:
            rid = receipt.get("receipt_id")
            if rid in receipts_by_id:
                errors.append(f"duplicate receipt_id: {rid}")
            receipts_by_id[rid] = receipt
            receipt_paths[rid] = path
            if receipt.get("rule_id"):
                seen_rules.add(receipt["rule_id"])

if not manifests:
    errors.append("No foundry_egress_manifest_v0 manifest found in fixtures.")
if not receipts_by_id:
    errors.append("No foundry_refusal_receipt_v0 receipts found in fixtures.")

for path, manifest in manifests:
    rel = path.relative_to(ROOT)
    if manifest.get("manifest_family") != "foundry_egress_manifest_v0":
        errors.append(f"{rel}: manifest_family must be foundry_egress_manifest_v0")
    if not str(manifest.get("manifest_digest", "")).startswith("sha256:"):
        errors.append(f"{rel}: manifest_digest must be sha256-prefixed")
    if not str(manifest.get("rule_suite_digest", "")).startswith("sha256:"):
        errors.append(f"{rel}: rule_suite_digest must be sha256-prefixed")
    if not manifest.get("source_result"):
        errors.append(f"{rel}: source_result is required")
    attempts = manifest.get("attempts")
    if not isinstance(attempts, list) or not attempts:
        errors.append(f"{rel}: attempts must be a non-empty list")
        continue
    for attempt in attempts:
        aid = attempt.get("attempt_id", "<missing>")
        outcome = attempt.get("outcome")
        if outcome not in {"passed", "refused", "out_of_scope"}:
            errors.append(f"{rel}: attempt {aid} has unknown outcome {outcome!r}")
        surface = attempt.get("requested_surface") or {}
        if not surface.get("kind") or not surface.get("surface_id"):
            errors.append(f"{rel}: attempt {aid} must name requested_surface.kind and surface_id")
        if outcome == "passed":
            if not (str(attempt.get("sidecar_digest", "")).startswith("sha256:") or attempt.get("in_band_residue_declared") is True):
                errors.append(f"{rel}: passed attempt {aid} must carry sidecar_digest or in_band_residue_declared=true")
        if outcome == "refused":
            rid = attempt.get("receipt_id")
            if not rid:
                errors.append(f"{rel}: refused attempt {aid} must reference receipt_id")
            elif rid not in receipts_by_id:
                errors.append(f"{rel}: refused attempt {aid} references missing receipt {rid}")

referenced = set()
for _, manifest in manifests:
    for attempt in manifest.get("attempts", []) or []:
        if attempt.get("outcome") == "refused" and attempt.get("receipt_id"):
            referenced.add(attempt["receipt_id"])

for rid, receipt in receipts_by_id.items():
    rel = receipt_paths[rid].relative_to(ROOT)
    if receipt.get("receipt_family") != "foundry_refusal_receipt_v0":
        errors.append(f"{rel}: receipt {rid} has wrong receipt_family")
    if not str(receipt.get("receipt_digest", "")).startswith("sha256:"):
        errors.append(f"{rel}: receipt {rid} must have sha256 receipt_digest")
    rule_id = receipt.get("rule_id", "")
    if not rule_id.startswith("R-EGRESS-"):
        errors.append(f"{rel}: receipt {rid} rule_id must start R-EGRESS-")
    surface = receipt.get("requested_surface") or {}
    if not surface.get("kind") or not surface.get("surface_id"):
        errors.append(f"{rel}: receipt {rid} must name requested surface kind and id")
    if not receipt.get("refused_reason"):
        errors.append(f"{rel}: receipt {rid} is missing refused_reason")
    if not isinstance(receipt.get("semantic_loss"), list) or not receipt.get("semantic_loss"):
        errors.append(f"{rel}: receipt {rid} must name semantic_loss")
    if not isinstance(receipt.get("required_escape"), list) or not receipt.get("required_escape"):
        errors.append(f"{rel}: receipt {rid} must name required_escape")
    if not isinstance(receipt.get("non_retryable_without"), list) or not receipt.get("non_retryable_without"):
        errors.append(f"{rel}: receipt {rid} must name non_retryable_without")
    details = receipt.get("problem_details") or {}
    for key in ["type", "title", "status", "detail", "instance"]:
        if key not in details or details.get(key) in ("", None):
            errors.append(f"{rel}: receipt {rid} problem_details missing {key}")
    if rid not in referenced:
        errors.append(f"{rel}: receipt {rid} is not referenced by any refused attempt")

missing_rules = REQUIRED_RULES - seen_rules
if missing_rules:
    errors.append("Missing required egress refusal rules: " + ", ".join(sorted(missing_rules)))

if errors:
    print("Foundry egress refusal check failed:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"Foundry egress refusal check passed for {len(manifests)} manifest(s) and {len(receipts_by_id)} refusal receipt(s)")
