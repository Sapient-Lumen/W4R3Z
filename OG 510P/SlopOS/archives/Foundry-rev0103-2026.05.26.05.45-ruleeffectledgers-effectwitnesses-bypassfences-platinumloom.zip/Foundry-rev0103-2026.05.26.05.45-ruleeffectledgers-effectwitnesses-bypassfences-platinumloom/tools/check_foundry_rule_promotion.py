#!/usr/bin/env python3
"""Check Foundry specimen 94 rule-promotion fixtures."""
from pathlib import Path
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

FIXTURE_DIR = FIXTURES / "specimen-94-rule-promotion"
LEDGER_STATUSES = {"local_only", "candidate", "promoted", "rejected", "quarantined", "superseded"}
WITNESS_STATUSES = {"promoted", "partial", "rejected", "test_failed", "shadow_only", "deprecated"}
FENCE_REASONS = {
    "single_case_generalization",
    "scope_widening",
    "unresolved_fence_erased",
    "witness_without_tests",
    "stale_precedent",
    "false_positive_generalized",
    "authority_laundering",
    "public_release_laundering",
    "sibling_boundary_laundering",
}
RISKY_LEDGER_STATUSES = {"candidate", "rejected", "quarantined", "superseded", "local_only"}
AUTHORITY_WORDS = ["authority", "authorize", "authorization", "audit", "release", "repair", "lifecycle", "verdict", "truth", "policy"]

errors = []
fixture_files = sorted(FIXTURE_DIR.glob("*.json"))
if not fixture_files:
    print("Missing specimen 94 fixture")
    sys.exit(1)

ledger_count = witness_count = fence_count = 0
ledger_status_counts = {s: 0 for s in LEDGER_STATUSES}
witness_status_counts = {s: 0 for s in WITNESS_STATUSES}

for path in fixture_files:
    rel = path.relative_to(ROOT)
    data = load_json(path)
    if data.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if str(data.get("specimen_id")) != "94":
        errors.append(f"{rel}: wrong specimen_id")
    if not parse_time(data.get("fixture_now")):
        errors.append(f"{rel}: missing/unparsable fixture_now")

    source_ledgers = {l.get("ledger_id"): l for l in data.get("source_disposition_ledger_refs") or []}
    source_witnesses = {w.get("witness_id"): w for w in data.get("source_resolution_witness_refs") or []}
    source_fences = {f.get("fence_id"): f for f in data.get("source_premature_closure_fence_refs") or []}
    consumers = {c.get("consumer_id") for c in data.get("consumer_refs") or []}
    carriers = {c.get("carrier_id"): c for c in data.get("carrier_refs") or []}
    ledgers = data.get("precedent_ledgers") or []
    witnesses = data.get("rule_promotion_witnesses") or []
    fences = data.get("overgeneralization_fences") or []

    for name, index in [("source disposition ledgers", source_ledgers), ("source resolution witnesses", source_witnesses), ("source premature fences", source_fences), ("consumers", consumers), ("carriers", carriers)]:
        if not index:
            errors.append(f"{rel}: missing {name}")

    ledger_by_id = {}
    required_witnesses = {}
    required_fences = {}
    for ledger in ledgers:
        ledger_count += 1
        lid = ledger.get("ledger_id", "<missing>")
        if lid in ledger_by_id:
            errors.append(f"{rel}: duplicate precedent ledger_id {lid}")
        ledger_by_id[lid] = ledger
        if ledger.get("ledger_family") != "foundry_precedent_ledger_v0":
            errors.append(f"{rel}: ledger {lid} has wrong ledger_family")
        if not require_sha256(ledger.get("ledger_digest")):
            errors.append(f"{rel}: ledger {lid} missing sha256 ledger_digest")
        status = ledger.get("ledger_status")
        if status not in LEDGER_STATUSES:
            errors.append(f"{rel}: ledger {lid} has unknown ledger_status {status!r}")
        else:
            ledger_status_counts[status] += 1
        for key in ["source_disposition_ledger_ids", "source_resolution_witness_ids", "carrier_refs", "source_scope", "promotion_scope", "target_rule_surfaces", "required_rule_promotion_witnesses", "authority_boundaries"]:
            if not ledger.get(key):
                errors.append(f"{rel}: ledger {lid} missing {key}")
        for sid in ledger.get("source_disposition_ledger_ids") or []:
            if sid not in source_ledgers:
                errors.append(f"{rel}: ledger {lid} references unknown source disposition ledger {sid}")
        for wid in ledger.get("source_resolution_witness_ids") or []:
            if wid not in source_witnesses:
                errors.append(f"{rel}: ledger {lid} references unknown source witness {wid}")
            elif source_witnesses[wid].get("ledger_id") not in set(ledger.get("source_disposition_ledger_ids") or []):
                errors.append(f"{rel}: ledger {lid} witness {wid} is not for a source ledger in the precedent")
        for fid in ledger.get("source_premature_closure_fence_ids") or []:
            if fid not in source_fences:
                errors.append(f"{rel}: ledger {lid} references unknown source fence {fid}")
        for cref in ledger.get("carrier_refs") or []:
            cid = cref.get("carrier_id")
            if cid not in carriers:
                errors.append(f"{rel}: ledger {lid} references unknown carrier {cid}")
            elif cref.get("carrier_digest") != carriers[cid].get("carrier_digest"):
                errors.append(f"{rel}: ledger {lid} carrier {cid} digest mismatch")
        source_scope = ledger.get("source_scope") or {}
        promotion_scope = ledger.get("promotion_scope") or {}
        for key in ["consumers", "surfaces", "audiences", "purpose_classes"]:
            extra = set(promotion_scope.get(key) or []) - set(source_scope.get(key) or [])
            if extra and not ledger.get("required_overgeneralization_fences"):
                errors.append(f"{rel}: ledger {lid} widens {key} without overgeneralization fence: {', '.join(sorted(extra))}")
        for consumer_id in promotion_scope.get("consumers") or []:
            if consumer_id not in consumers:
                errors.append(f"{rel}: ledger {lid} scopes unknown consumer {consumer_id}")
        required_witnesses[lid] = set(ledger.get("required_rule_promotion_witnesses") or [])
        required_fences[lid] = set(ledger.get("required_overgeneralization_fences") or [])
        if status in RISKY_LEDGER_STATUSES and not ledger.get("required_overgeneralization_fences"):
            errors.append(f"{rel}: risky ledger {lid} must require overgeneralization fences")
        boundary_text = " ".join(ledger.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: ledger {lid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: ledger {lid} authority boundaries should name refused authority")

    fence_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate overgeneralization fence_id {fid}")
        fence_by_id[fid] = fence
        lid = fence.get("ledger_id")
        if fence.get("fence_family") != "foundry_overgeneralization_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if not require_sha256(fence.get("fence_digest")):
            errors.append(f"{rel}: fence {fid} missing sha256 fence_digest")
        if lid not in ledger_by_id:
            errors.append(f"{rel}: fence {fid} references missing ledger {lid}")
        reason = fence.get("fence_reason")
        if reason not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {reason!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        for sid in fence.get("affected_source_ledger_ids") or []:
            if sid not in source_ledgers:
                errors.append(f"{rel}: fence {fid} references unknown source ledger {sid}")
        for wid in fence.get("affected_witness_ids") or []:
            if wid not in source_witnesses and wid not in {w.get("witness_id") for w in witnesses}:
                errors.append(f"{rel}: fence {fid} references unknown witness {wid}")
        for fid2 in fence.get("affected_fence_ids") or []:
            if fid2 not in source_fences and fid2 not in fence_by_id:
                errors.append(f"{rel}: fence {fid} references unknown affected fence {fid2}")
        for key in ["affected_source_ledger_ids", "affected_witness_ids", "blocked_promotions", "required_clearance", "authority_boundaries"]:
            if not fence.get(key):
                errors.append(f"{rel}: fence {fid} missing {key}")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must name refused authority boundary")

    witness_by_id = {}
    witnesses_by_ledger = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if wid in witness_by_id:
            errors.append(f"{rel}: duplicate rule-promotion witness_id {wid}")
        witness_by_id[wid] = witness
        lid = witness.get("ledger_id")
        witnesses_by_ledger.setdefault(lid, set()).add(wid)
        if witness.get("witness_family") != "foundry_rule_promotion_witness_v0":
            errors.append(f"{rel}: witness {wid} has wrong witness_family")
        if lid not in ledger_by_id:
            errors.append(f"{rel}: witness {wid} references missing ledger {lid}")
            scope = {}
        else:
            scope = ledger_by_id[lid].get("promotion_scope") or {}
        if not require_sha256(witness.get("witness_digest")):
            errors.append(f"{rel}: witness {wid} missing sha256 witness_digest")
        status = witness.get("promotion_status")
        if status not in WITNESS_STATUSES:
            errors.append(f"{rel}: witness {wid} has unknown promotion_status {status!r}")
        else:
            witness_status_counts[status] += 1
        if not parse_time(witness.get("observed_at")):
            errors.append(f"{rel}: witness {wid} missing/unparsable observed_at")
        echo = witness.get("scope_echo") or {}
        if scope:
            for key in ["consumers", "surfaces", "audiences", "purpose_classes"]:
                extra = set(echo.get(key) or []) - set(scope.get(key) or [])
                if extra:
                    errors.append(f"{rel}: witness {wid} scope_echo {key} exceeds promotion scope: {', '.join(sorted(extra))}")
        for key in ["promoter_role", "scope_echo", "test_basis", "evidence_refs", "blocked_inferences", "authority_boundaries"]:
            if not witness.get(key):
                errors.append(f"{rel}: witness {wid} missing {key}")
        basis = witness.get("test_basis") or {}
        for key in ["positive_case_ids", "fixture_refs", "rulebook_refs", "checker_refs", "replay_status"]:
            if not basis.get(key):
                errors.append(f"{rel}: witness {wid} test_basis missing {key}")
        if status in {"promoted", "partial"} and not basis.get("negative_case_ids"):
            errors.append(f"{rel}: promoted/partial witness {wid} must preserve negative_case_ids")
        if status in {"rejected", "test_failed", "deprecated", "shadow_only"} and not witness.get("residual_fence_refs"):
            errors.append(f"{rel}: non-active witness {wid} must preserve residual_fence_refs")
        for fid in witness.get("residual_fence_refs") or []:
            if fid not in fence_by_id and fid not in source_fences:
                errors.append(f"{rel}: witness {wid} references unknown residual fence {fid}")
        boundary_text = " ".join(witness.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: witness {wid} must name refused authority boundary")

    for lid, required in required_witnesses.items():
        missing = required - set(witness_by_id)
        if missing:
            errors.append(f"{rel}: ledger {lid} missing required promotion witnesses: {', '.join(sorted(missing))}")
        if not witnesses_by_ledger.get(lid):
            errors.append(f"{rel}: ledger {lid} has no promotion witness")
    for lid, required in required_fences.items():
        missing = required - set(fence_by_id)
        if missing:
            errors.append(f"{rel}: ledger {lid} missing required overgeneralization fences: {', '.join(sorted(missing))}")

    if not all(ledger_status_counts[s] for s in ["local_only", "candidate", "promoted", "rejected", "quarantined", "superseded"]):
        errors.append(f"{rel}: fixture must include local_only, candidate, promoted, rejected, quarantined, and superseded ledgers")
    if not all(witness_status_counts[s] for s in ["promoted", "partial", "rejected", "test_failed", "shadow_only", "deprecated"]):
        errors.append(f"{rel}: fixture must include promoted, partial, rejected, test_failed, shadow_only, and deprecated witnesses")
    reasons = {f.get("fence_reason") for f in fences}
    for required_reason in ["single_case_generalization", "scope_widening", "unresolved_fence_erased", "witness_without_tests", "stale_precedent", "false_positive_generalized", "authority_laundering", "public_release_laundering"]:
        if required_reason not in reasons:
            errors.append(f"{rel}: fixture missing fence reason {required_reason}")

    negative_cases = data.get("negative_cases") or []
    if len(negative_cases) < 24:
        errors.append(f"{rel}: specimen 94 should include at least 24 negative cases")
    case_ids = [c.get("case_id") for c in negative_cases]
    if len(case_ids) != len(set(case_ids)):
        errors.append(f"{rel}: duplicate negative case ids")
    modes = " ".join((c.get("failure_mode", "") + " " + c.get("failure_code", "")) for c in negative_cases).lower()
    for phrase in ["single-case", "negative", "false", "deprecated", "checker", "public", "authorization", "audit", "sibling", "lifecycle"]:
        if phrase not in modes:
            errors.append(f"{rel}: negative cases should include {phrase} coverage")

fail(errors)
print(
    f"Foundry rule-promotion check passed for {len(fixture_files)} fixture file(s), "
    f"{ledger_count} precedent ledger(s), {witness_count} rule-promotion witness(es), and {fence_count} overgeneralization fence(s)"
)
