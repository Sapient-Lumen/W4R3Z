#!/usr/bin/env python3
"""Check Foundry specimen 93 disposition/resolution fixtures."""
from pathlib import Path
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

FIXTURE_DIR = FIXTURES / "specimen-93-disposition-resolution"
LEDGER_STATUSES = {"resolved", "partial", "blocked", "deferred", "transferred", "quarantined", "informational", "reopened"}
RESOLUTION_STATUSES = {"closed", "closed_informational", "partial", "transferred", "deferred", "rejected_duplicate", "false_positive", "quarantined", "reopened"}
FENCE_REASONS = {
    "missing_resolution_witness",
    "unresolved_source_fence",
    "missing_resolution_route",
    "transfer_without_receiving_scope",
    "public_release_laundering",
    "deferred_as_closed",
    "dedupe_erased_residue",
    "false_positive_without_contradictory_evidence",
    "stale_closure",
    "scope_widening",
    "authority_laundering",
    "sibling_verdict_laundering",
}
RISKY_LEDGER_STATUSES = {"blocked", "deferred", "transferred", "quarantined", "reopened", "partial"}
AUTHORITY_WORDS = ["authority", "authorize", "authorization", "audit", "release", "repair", "lifecycle", "verdict", "truth", "compliance"]

errors = []
fixture_files = sorted(FIXTURE_DIR.glob("*.json"))
if not fixture_files:
    print("Missing specimen 93 fixture")
    sys.exit(1)

ledger_count = witness_count = fence_count = 0
ledger_status_counts = {s: 0 for s in LEDGER_STATUSES}
witness_status_counts = {s: 0 for s in RESOLUTION_STATUSES}

for path in fixture_files:
    rel = path.relative_to(ROOT)
    data = load_json(path)
    if data.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if str(data.get("specimen_id")) != "93":
        errors.append(f"{rel}: wrong specimen_id")
    if not parse_time(data.get("fixture_now")):
        errors.append(f"{rel}: missing/unparsable fixture_now")

    packets = {p.get("packet_id"): p for p in data.get("source_escalation_packet_refs") or []}
    routing_witnesses = {w.get("witness_id"): w for w in data.get("source_routing_witness_refs") or []}
    unresolved_fences = {f.get("fence_id"): f for f in data.get("source_unresolved_signal_fence_refs") or []}
    consumers = {c.get("consumer_id") for c in data.get("consumer_refs") or []}
    carriers = {c.get("carrier_id"): c for c in data.get("carrier_refs") or []}
    ledgers = data.get("disposition_ledgers") or []
    witnesses = data.get("resolution_witnesses") or []
    fences = data.get("premature_closure_fences") or []

    for name, index in [("source packets", packets), ("routing witnesses", routing_witnesses), ("source unresolved fences", unresolved_fences), ("consumers", consumers), ("carriers", carriers)]:
        if not index:
            errors.append(f"{rel}: missing {name}")

    ledger_by_id = {}
    required_witnesses = {}
    required_fences = {}
    source_signals_under_disposition = set()
    for ledger in ledgers:
        ledger_count += 1
        lid = ledger.get("ledger_id", "<missing>")
        if lid in ledger_by_id:
            errors.append(f"{rel}: duplicate disposition ledger_id {lid}")
        ledger_by_id[lid] = ledger
        if ledger.get("ledger_family") != "foundry_disposition_ledger_v0":
            errors.append(f"{rel}: ledger {lid} has wrong ledger_family")
        if not require_sha256(ledger.get("ledger_digest")):
            errors.append(f"{rel}: ledger {lid} missing sha256 ledger_digest")
        status = ledger.get("ledger_status")
        if status not in LEDGER_STATUSES:
            errors.append(f"{rel}: ledger {lid} has unknown ledger_status {status!r}")
        else:
            ledger_status_counts[status] += 1
        for key in ["source_packet_ids", "source_routing_witness_ids", "carrier_refs", "disposition_scope", "review_basis", "required_resolution_witnesses", "authority_boundaries"]:
            if not ledger.get(key):
                errors.append(f"{rel}: ledger {lid} missing {key}")
        for pid in ledger.get("source_packet_ids") or []:
            if pid not in packets:
                errors.append(f"{rel}: ledger {lid} references unknown source packet {pid}")
            else:
                source_signals_under_disposition.update(packets[pid].get("source_drift_signal_ids") or [])
        for wid in ledger.get("source_routing_witness_ids") or []:
            if wid not in routing_witnesses:
                errors.append(f"{rel}: ledger {lid} references unknown routing witness {wid}")
            elif routing_witnesses[wid].get("packet_id") not in set(ledger.get("source_packet_ids") or []):
                errors.append(f"{rel}: ledger {lid} routing witness {wid} is not for a source packet in the ledger")
        for fid in ledger.get("source_unresolved_signal_fence_ids") or []:
            if fid not in unresolved_fences:
                errors.append(f"{rel}: ledger {lid} references unknown unresolved-signal fence {fid}")
        for cref in ledger.get("carrier_refs") or []:
            cid = cref.get("carrier_id")
            if cid not in carriers:
                errors.append(f"{rel}: ledger {lid} references unknown carrier {cid}")
            elif cref.get("carrier_digest") != carriers[cid].get("carrier_digest"):
                errors.append(f"{rel}: ledger {lid} carrier {cid} digest mismatch")
        scope = ledger.get("disposition_scope") or {}
        allowed = {"consumers": set(), "surfaces": set(), "audiences": set(), "purpose_classes": set()}
        for pid in ledger.get("source_packet_ids") or []:
            packet_scope = (packets.get(pid) or {}).get("escalation_scope") or {}
            for key in allowed:
                allowed[key].update(packet_scope.get(key) or [])
        for key in ["consumers", "surfaces", "audiences", "purpose_classes"]:
            extra = set(scope.get(key) or []) - allowed[key]
            # Transfers can name a receiving consumer, but must still be fenced/residual.
            if extra and ledger.get("ledger_status") != "transferred":
                errors.append(f"{rel}: ledger {lid} {key} exceeds source escalation scope: {', '.join(sorted(extra))}")
        for consumer_id in scope.get("consumers") or []:
            if consumer_id not in consumers:
                errors.append(f"{rel}: ledger {lid} scopes unknown consumer {consumer_id}")
        review = ledger.get("review_basis") or {}
        for key in ["reviewed_at", "reviewer_role", "decision", "evidence_refs", "required_resolution_witnesses", "blocked_inferences"]:
            if not review.get(key):
                errors.append(f"{rel}: ledger {lid} review_basis missing {key}")
        if not parse_time(review.get("reviewed_at")):
            errors.append(f"{rel}: ledger {lid} review_basis reviewed_at is not parseable")
        required_witnesses[lid] = set(ledger.get("required_resolution_witnesses") or [])
        required_fences[lid] = set(ledger.get("required_premature_closure_fences") or [])
        if status in RISKY_LEDGER_STATUSES and not ledger.get("required_premature_closure_fences"):
            errors.append(f"{rel}: risky ledger {lid} must require premature-closure fences")
        boundary_text = " ".join(ledger.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: ledger {lid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: ledger {lid} authority boundaries should name refused authority")

    fence_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate premature-closure fence_id {fid}")
        fence_by_id[fid] = fence
        lid = fence.get("ledger_id")
        if fence.get("fence_family") != "foundry_premature_closure_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if not require_sha256(fence.get("fence_digest")):
            errors.append(f"{rel}: fence {fid} missing sha256 fence_digest")
        if lid not in ledger_by_id:
            errors.append(f"{rel}: fence {fid} references missing ledger {lid}")
        reason = fence.get("fence_reason")
        if reason not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {reason!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        for pid in fence.get("affected_packet_ids") or []:
            if pid not in packets:
                errors.append(f"{rel}: fence {fid} references unknown source packet {pid}")
        for wid in fence.get("affected_witness_ids") or []:
            if wid not in routing_witnesses and wid not in {w.get("witness_id") for w in witnesses}:
                errors.append(f"{rel}: fence {fid} references unknown witness {wid}")
        for key in ["affected_packet_ids", "affected_witness_ids", "affected_signal_ids", "blocked_closure_uses", "required_clearance", "authority_boundaries"]:
            if not fence.get(key):
                errors.append(f"{rel}: fence {fid} missing {key}")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must name refused authority boundary")

    witness_by_id = {}
    witnesses_by_ledger = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if wid in witness_by_id:
            errors.append(f"{rel}: duplicate resolution witness_id {wid}")
        witness_by_id[wid] = witness
        lid = witness.get("ledger_id")
        witnesses_by_ledger.setdefault(lid, set()).add(wid)
        if witness.get("witness_family") != "foundry_resolution_witness_v0":
            errors.append(f"{rel}: witness {wid} has wrong witness_family")
        if lid not in ledger_by_id:
            errors.append(f"{rel}: witness {wid} references missing ledger {lid}")
            scope = {}
        else:
            scope = ledger_by_id[lid].get("disposition_scope") or {}
        if not require_sha256(witness.get("witness_digest")):
            errors.append(f"{rel}: witness {wid} missing sha256 witness_digest")
        status = witness.get("resolution_status")
        if status not in RESOLUTION_STATUSES:
            errors.append(f"{rel}: witness {wid} has unknown resolution_status {status!r}")
        else:
            witness_status_counts[status] += 1
        if not parse_time(witness.get("observed_at")):
            errors.append(f"{rel}: witness {wid} missing/unparsable observed_at")
        if witness.get("resolver_consumer_id") not in consumers:
            errors.append(f"{rel}: witness {wid} names unknown resolver consumer")
        echo = witness.get("scope_echo") or {}
        if scope:
            for key in ["consumers", "surfaces", "audiences", "purpose_classes"]:
                extra = set(echo.get(key) or []) - set(scope.get(key) or [])
                if extra:
                    errors.append(f"{rel}: witness {wid} scope_echo {key} exceeds disposition scope: {', '.join(sorted(extra))}")
        for key in ["resolver_role", "scope_echo", "evidence_refs", "closure_basis", "blocked_inferences", "authority_boundaries"]:
            if not witness.get(key):
                errors.append(f"{rel}: witness {wid} missing {key}")
        closure = witness.get("closure_basis") or {}
        if status in {"closed", "closed_informational", "partial"} and "closed_signal_ids" not in closure:
            errors.append(f"{rel}: witness {wid} closure status must name closed_signal_ids")
        if status in {"deferred", "quarantined", "reopened", "partial"} and not witness.get("residual_fence_refs"):
            errors.append(f"{rel}: non-final witness {wid} must preserve residual_fence_refs")
        if status == "false_positive" and "contradict" not in " ".join(witness.get("evidence_refs") or []).lower():
            errors.append(f"{rel}: false-positive witness {wid} must cite contradictory evidence")
        for fid in witness.get("residual_fence_refs") or []:
            if fid not in fence_by_id and fid not in unresolved_fences:
                errors.append(f"{rel}: witness {wid} references unknown residual fence {fid}")
        boundary_text = " ".join(witness.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: witness {wid} must name refused authority boundary")

    for lid, required in required_witnesses.items():
        missing = required - set(witness_by_id)
        if missing:
            errors.append(f"{rel}: ledger {lid} missing required resolution witnesses: {', '.join(sorted(missing))}")
        if not witnesses_by_ledger.get(lid):
            errors.append(f"{rel}: ledger {lid} has no resolution witness")
    for lid, required in required_fences.items():
        missing = required - set(fence_by_id)
        if missing:
            errors.append(f"{rel}: ledger {lid} missing required premature-closure fences: {', '.join(sorted(missing))}")

    # Required specimen variety.
    if not all(ledger_status_counts[s] for s in ["partial", "blocked", "deferred", "informational", "reopened"]):
        errors.append(f"{rel}: fixture must include partial, blocked, deferred, informational, and reopened ledgers")
    if not all(witness_status_counts[s] for s in ["partial", "quarantined", "deferred", "closed_informational", "reopened"]):
        errors.append(f"{rel}: fixture must include partial, quarantined, deferred, closed_informational, and reopened witnesses")
    reasons = {f.get("fence_reason") for f in fences}
    for required_reason in ["unresolved_source_fence", "missing_resolution_route", "transfer_without_receiving_scope", "public_release_laundering", "deferred_as_closed", "dedupe_erased_residue", "false_positive_without_contradictory_evidence"]:
        if required_reason not in reasons:
            errors.append(f"{rel}: fixture missing fence reason {required_reason}")

    negative_cases = data.get("negative_cases") or []
    if len(negative_cases) < 20:
        errors.append(f"{rel}: specimen 93 should include at least 20 negative cases")
    case_ids = [c.get("case_id") for c in negative_cases]
    if len(case_ids) != len(set(case_ids)):
        errors.append(f"{rel}: duplicate negative case ids")
    modes = " ".join(c.get("failure_mode", "") for c in negative_cases).lower()
    for phrase in ["acknowledgment", "deferred", "false_positive", "authorization", "audit", "public_release", "sibling"]:
        if phrase not in modes:
            errors.append(f"{rel}: negative cases should include {phrase} coverage")

fail(errors)
print(
    f"Foundry disposition/resolution check passed for {len(fixture_files)} fixture file(s), "
    f"{ledger_count} disposition ledger(s), {witness_count} resolution witness(es), and {fence_count} premature-closure fence(s)"
)
