#!/usr/bin/env python3
"""Check Foundry lifecycle transition coverage manifest.

This refactor guard makes the late executable specimens an explicit handoff
chain. It is not an ontology, correctness proof, governance workflow, or audit.
"""
from pathlib import Path
import json
import re
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "lifecycle-transition-coverage" / "coverage.json"
if not manifest_path.exists():
    print("Missing lifecycle transition coverage manifest")
    sys.exit(1)

coverage = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text())
if coverage.get("coverage_family") != "foundry_lifecycle_transition_coverage_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if coverage.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")
if not require_sha256(coverage.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")

runner = (ROOT / "tools/check_foundry_all.py").read_text(errors="ignore")
registered = set(re.findall(r'"(check_foundry_[^"]+\.py)"', runner))
entries = coverage.get("transitions") or []
if not entries:
    errors.append(f"{rel_manifest}: missing transitions")

seen_pairs = []
for entry in entries:
    fid = str(entry.get("from_specimen_id"))
    tid = str(entry.get("to_specimen_id"))
    seen_pairs.append((fid, tid))
    for key in ["from_fixture", "to_fixture", "from_checker", "to_checker"]:
        rel = entry.get(key)
        if not rel or not (ROOT / rel).exists():
            errors.append(f"{rel_manifest}: transition {fid}->{tid} missing {key} {rel!r}")
    for key in ["from_checker", "to_checker"]:
        checker = Path(entry.get(key) or "").name
        if checker and checker not in registered:
            errors.append(f"{rel_manifest}: transition {fid}->{tid} checker {checker} missing from aggregate runner")
    for key, expected in [("from_fixture", fid), ("to_fixture", tid)]:
        p = ROOT / (entry.get(key) or "")
        if p.exists():
            data = json.loads(p.read_text())
            if data.get("fixture_family") == "foundry_semantic_fixture_bundle_v0" and str(data.get("specimen_id")) != expected:
                errors.append(f"{entry.get(key)}: expected specimen_id {expected}")
    claim = (entry.get("transition_claim") or "").lower()
    if not any(word in claim for word in ["not", "does not", "fence", "refuse", "without"]):
        errors.append(f"{rel_manifest}: transition {fid}->{tid} claim should use bounded anti-laundering language")
    if not entry.get("carried_fields"):
        errors.append(f"{rel_manifest}: transition {fid}->{tid} missing carried_fields")
    fences = " ".join(entry.get("anti_laundering_fences") or []).lower()
    for word in ["authorization", "audit", "public", "sibling"]:
        if word not in fences:
            errors.append(f"{rel_manifest}: transition {fid}->{tid} anti_laundering_fences should mention {word}")

expected_pairs = [(str(i), str(i+1)) for i in range(78, 97)]
if seen_pairs != expected_pairs:
    errors.append(f"{rel_manifest}: expected transition chain {expected_pairs}, saw {seen_pairs}")

rules = " ".join(coverage.get("coverage_rules") or []).lower()
for word in ["specimen", "transition", "fixture", "checker", "runner", "fence"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(coverage.get("non_goals") or []).lower()
for word in ["ontology", "correctness", "audit", "certification", "governance", "verdict"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(f"Foundry lifecycle transition coverage check passed for {len(entries)} transition record(s)")
