#!/usr/bin/env python3
"""Check Foundry reference-integrity index coverage.

This audit/refactor guard catches dangling fixture ids and stale reference lists.
It is not a catalog, ontology, correctness proof, or audit product.
"""
from pathlib import Path
import json
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "reference-integrity-index" / "index.json"
if not manifest_path.exists():
    print("Missing reference integrity index")
    sys.exit(1)
index = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text())
if index.get("coverage_family") != "foundry_reference_integrity_index_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if index.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")
if not require_sha256(index.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")

seen_sets = set()
for refset in index.get("reference_sets") or []:
    sid = refset.get("set_id", "<missing>")
    if sid in seen_sets:
        errors.append(f"{rel_manifest}: duplicate reference set {sid}")
    seen_sets.add(sid)
    source_rel = refset.get("source_fixture") or ""
    source_path = ROOT / source_rel
    if not source_path.exists():
        errors.append(f"{rel_manifest}: set {sid} source fixture missing {source_rel!r}")
        continue
    source = json.loads(source_path.read_text())
    collection = refset.get("collection") or ""
    id_field = refset.get("id_field") or ""
    actual_ids = [item.get(id_field) for item in source.get(collection) or []]
    if len(actual_ids) != len(set(actual_ids)):
        errors.append(f"{source_rel}: duplicate ids in {collection}.{id_field}")
    listed_ids = refset.get("ids") or []
    if len(listed_ids) != len(set(listed_ids)):
        errors.append(f"{rel_manifest}: set {sid} lists duplicate ids")
    missing_from_source = sorted(set(listed_ids) - set(actual_ids))
    if missing_from_source:
        errors.append(f"{rel_manifest}: set {sid} lists ids absent from source: {', '.join(missing_from_source)}")
    mode = refset.get("mode")
    if mode == "exact":
        if sorted(actual_ids) != sorted(listed_ids):
            missing = sorted(set(actual_ids) - set(listed_ids))
            ghosts = sorted(set(listed_ids) - set(actual_ids))
            if missing:
                errors.append(f"{rel_manifest}: set {sid} omits source ids: {', '.join(missing)}")
            if ghosts:
                errors.append(f"{rel_manifest}: set {sid} lists source ghosts: {', '.join(ghosts)}")
    elif mode != "subset":
        errors.append(f"{rel_manifest}: set {sid} mode must be exact or subset")

    ref_rel = refset.get("referencing_fixture") or ""
    ref_path = ROOT / ref_rel
    if not ref_path.exists():
        errors.append(f"{rel_manifest}: set {sid} referencing fixture missing {ref_rel!r}")
        continue
    ref_data = json.loads(ref_path.read_text())
    ref_collection = refset.get("referencing_collection") or ""
    refs = ref_data.get(ref_collection) or []
    # Most referencing collections contain objects with the same id field; source trace refs use trace_id, etc.
    ref_ids = []
    for item in refs:
        if isinstance(item, dict):
            ref_ids.append(item.get(id_field) or item.get("ledger_id") or item.get("witness_id") or item.get("fence_id") or item.get("trace_id"))
    if refset.get("mode") == "subset" and not set(listed_ids).issubset(set(ref_ids)):
        missing = sorted(set(listed_ids) - set(ref_ids))
        errors.append(f"{rel_manifest}: set {sid} listed ids not used by referencing fixture: {', '.join(missing)}")

if len(index.get("reference_sets") or []) < 6:
    errors.append(f"{rel_manifest}: expected at least six reference sets")
rules = " ".join(index.get("coverage_rules") or []).lower()
for word in ["reference", "source", "fixture", "ids", "schema", "checker", "runner"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(index.get("non_goals") or []).lower()
for word in ["ontology", "correctness", "audit", "production", "governance", "authorization", "verdict"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(f"Foundry reference-integrity index check passed for {len(index.get('reference_sets') or [])} reference set(s)")
