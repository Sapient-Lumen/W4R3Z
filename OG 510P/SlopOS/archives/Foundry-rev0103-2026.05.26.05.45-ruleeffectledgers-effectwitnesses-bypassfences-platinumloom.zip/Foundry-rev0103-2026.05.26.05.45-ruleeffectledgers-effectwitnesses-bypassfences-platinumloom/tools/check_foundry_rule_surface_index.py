#!/usr/bin/env python3
"""Check Foundry rule-surface index coverage.

The index is the rev0101 audit/refactor twin for rule collision work: it makes
rulebook ids, checkers, and runner registration machine-visible without turning
Foundry into a policy registry or rule engine.
"""
from pathlib import Path
import json
import re
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "rule-surface-index" / "index.json"
if not manifest_path.exists():
    print("Missing rule surface index")
    sys.exit(1)

index = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text()) if (ROOT / "REVISION-RECEIPT.json").exists() else {}
if index.get("coverage_family") != "foundry_rule_surface_index_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if index.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")
if not require_sha256(index.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")

actual_rulebooks = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "docs/30-architecture").glob("*rulebook-v0.md"))
entries = index.get("rulebook_surfaces") or []
listed_rulebooks = sorted(e.get("rulebook") for e in entries)
if actual_rulebooks != listed_rulebooks:
    only_actual = [p for p in actual_rulebooks if p not in listed_rulebooks]
    only_listed = [p for p in listed_rulebooks if p not in actual_rulebooks]
    if only_actual:
        errors.append(f"{rel_manifest}: unlisted rulebook surfaces: {', '.join(only_actual)}")
    if only_listed:
        errors.append(f"{rel_manifest}: missing listed rulebook surfaces: {', '.join(only_listed)}")

runner = (ROOT / "tools/check_foundry_all.py").read_text(errors="ignore") if (ROOT / "tools/check_foundry_all.py").exists() else ""
registered = set(re.findall(r'"(check_foundry_[^"]+\.py)"', runner))
all_rule_ids = []
for entry in entries:
    rulebook = entry.get("rulebook") or ""
    p = ROOT / rulebook
    if not p.exists():
        continue
    actual_ids = re.findall(r'`(R-[A-Z0-9-]+)`', p.read_text(errors="ignore"))
    listed_ids = entry.get("rule_ids") or []
    if actual_ids != listed_ids:
        errors.append(f"{rulebook}: rule id drift; parsed {actual_ids}, indexed {listed_ids}")
    all_rule_ids.extend(listed_ids)
    status = entry.get("rulebook_status")
    if listed_ids and status != "active":
        errors.append(f"{rulebook}: rulebook with rule ids must be active in rule surface index")
    if not listed_ids and status != "legacy_prose_only":
        errors.append(f"{rulebook}: rulebook without ids must be marked legacy_prose_only")
    for checker in entry.get("checker_refs") or []:
        if not (ROOT / checker).exists():
            errors.append(f"{rulebook}: checker ref missing on disk: {checker}")
        if Path(checker).name not in registered:
            errors.append(f"{rulebook}: checker {Path(checker).name} missing from aggregate runner")
    assertions = " ".join(entry.get("index_assertions") or []).lower()
    for word in ["rulebook", "rule", "checker"]:
        if word not in assertions:
            errors.append(f"{rulebook}: index_assertions should mention {word}")

seen = set()
dupes = sorted({rid for rid in all_rule_ids if rid in seen or seen.add(rid)})
if dupes:
    errors.append(f"{rel_manifest}: duplicate rule ids across rulebooks: {', '.join(dupes)}")

rules = " ".join(index.get("coverage_rules") or []).lower()
for word in ["rulebook", "rule", "checker", "runner", "precedence"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(index.get("non_goals") or []).lower()
for word in ["ontology", "correctness", "audit", "production", "governance", "policy", "authorization", "verdict"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(f"Foundry rule-surface index check passed for {len(entries)} rulebook surface(s) and {len(all_rule_ids)} indexed rule id(s)")
