#!/usr/bin/env python3
"""Check Foundry negative-case coverage manifest.

This audit/refactor guard keeps executable fixtures from claiming hardening in
prose while omitting the named negative/tamper cases from machine-readable
fixtures. It is not a completeness proof and not a test-management product.
"""
from pathlib import Path
import json
import re
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "negative-case-coverage" / "coverage.json"
if not manifest_path.exists():
    print("Missing negative-case coverage manifest")
    sys.exit(1)

coverage = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text())
if coverage.get("coverage_family") != "foundry_negative_case_coverage_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if coverage.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")
if not require_sha256(coverage.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")

entries = coverage.get("specimen_negative_case_surfaces") or []
if not entries:
    errors.append(f"{rel_manifest}: missing specimen_negative_case_surfaces")

runner = (ROOT / "tools/check_foundry_all.py").read_text(errors="ignore")
registered = set(re.findall(r'"(check_foundry_[^"]+\.py)"', runner))
docs_map = (ROOT / "docs/README.md").read_text(errors="ignore")
seen_ids = []
listed_fixture_paths = []

for entry in entries:
    sid = str(entry.get("specimen_id"))
    seen_ids.append(sid)
    fixture_rel = entry.get("fixture") or ""
    rulebook_rel = entry.get("rulebook") or ""
    checker_rel = entry.get("checker") or ""
    listed_fixture_paths.append(fixture_rel)
    for key, rel in [("fixture", fixture_rel), ("rulebook", rulebook_rel), ("checker", checker_rel)]:
        if not rel or not (ROOT / rel).exists():
            errors.append(f"{rel_manifest}: specimen {sid} missing {key} {rel!r}")
    if checker_rel and Path(checker_rel).name not in registered:
        errors.append(f"{rel_manifest}: specimen {sid} checker {Path(checker_rel).name} missing from aggregate runner")
    if entry.get("docs_map_required") is True:
        for rel in [fixture_rel, rulebook_rel, checker_rel]:
            if rel and rel not in docs_map:
                errors.append(f"{rel_manifest}: specimen {sid} docs map missing {rel}")
    fixture_path = ROOT / fixture_rel
    if fixture_path.exists():
        data = json.loads(fixture_path.read_text())
        if str(data.get("specimen_id")) != sid:
            errors.append(f"{fixture_rel}: specimen_id mismatch; expected {sid}")
        negative_cases = data.get("negative_cases") or []
        case_ids = [case.get("case_id") for case in negative_cases]
        if len(case_ids) != len(set(case_ids)):
            errors.append(f"{fixture_rel}: duplicate negative case ids")
        min_cases = int(entry.get("expected_min_negative_cases") or 1)
        if len(case_ids) < min_cases:
            errors.append(f"{fixture_rel}: expected at least {min_cases} negative cases, saw {len(case_ids)}")
        listed_ids = entry.get("negative_case_ids") or []
        if sorted(case_ids) != sorted(listed_ids):
            missing = sorted(set(case_ids) - set(listed_ids))
            ghosts = sorted(set(listed_ids) - set(case_ids))
            if missing:
                errors.append(f"{fixture_rel}: negative-case coverage omits ids {', '.join(missing)}")
            if ghosts:
                errors.append(f"{fixture_rel}: negative-case coverage lists ghost ids {', '.join(ghosts)}")
        modes = " ".join(case.get("failure_mode", "") + " " + case.get("expected_failure", "") for case in negative_cases).lower()
        if entry.get("authority_coverage_required") is True and "authority" not in modes and "launder" not in modes and "verdict" not in modes:
            errors.append(f"{fixture_rel}: negative cases should include authority/laundering/verdict coverage")
    if rulebook_rel and (ROOT / rulebook_rel).exists():
        rulebook = (ROOT / rulebook_rel).read_text(errors="ignore").lower()
        if entry.get("required_negative_cases_section") is True and "required negative cases" not in rulebook:
            errors.append(f"{rulebook_rel}: missing Required negative cases section")
    assertions = " ".join(entry.get("coverage_assertions") or []).lower()
    for word in ["fixture", "negative", "rulebook", "checker"]:
        if word not in assertions:
            errors.append(f"{rel_manifest}: specimen {sid} coverage_assertions should mention {word}")
    modes = " ".join(entry.get("covered_failure_modes") or []).lower()
    if not modes:
        errors.append(f"{rel_manifest}: specimen {sid} missing covered_failure_modes")
    if entry.get("authority_coverage_required") is True and "launder" not in modes and "authority" not in modes and "verdict" not in modes:
        errors.append(f"{rel_manifest}: specimen {sid} covered_failure_modes should include laundering/authority/verdict risk")

if len(seen_ids) != len(set(seen_ids)):
    errors.append(f"{rel_manifest}: duplicate specimen ids")
expected_ids = [str(i) for i in range(78, 98)]
if sorted(seen_ids, key=int) != expected_ids:
    errors.append(f"{rel_manifest}: expected specimen ids {expected_ids}, saw {sorted(seen_ids, key=int)}")

rules = " ".join(coverage.get("coverage_rules") or []).lower()
for word in ["negative", "fixture", "rulebook", "checker", "runner"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(coverage.get("non_goals") or []).lower()
for word in ["completeness", "correctness", "audit", "certification", "ontology"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(f"Foundry negative-case coverage check passed for {len(entries)} specimen coverage record(s)")
