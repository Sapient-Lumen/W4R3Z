#!/usr/bin/env python3
"""Check Foundry escalation/routing fixtures.

Specimen 92 keeps risky drift signals from becoming silently handled merely
because they were grouped, routed, inhibited, acknowledged, or ticket-shaped.
"""
from pathlib import Path
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover - direct execution fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, parse_time, require_sha256, fail

REQUIRED_FAILURE_CODES = {
    "escalation_packet_required",
    "routing_witness_required",
    "unresolved_signal_fence_required",
    "source_signal_required",
    "source_cadence_required",
    "risky_signal_without_packet_refused",
    "missing_route_accepted_refused",
    "misrouted_acknowledgment_refused",
    "stale_acknowledgment_refused",
    "routing_scope_mismatch_refused",
    "dedupe_erased_residue_refused",
    "inhibited_without_fence_refused",
    "route_as_truth_refused",
    "acknowledgment_as_resolution_refused",
    "pager_as_authority_refused",
    "incident_management_capture_refused",
    "repair_lifecycle_laundering_refused",
    "routing_sibling_verdict_laundering_refused",
    "specimen_doc_coverage_drift_refused",
}

PACKET_STATUSES = {"routed", "acknowledged", "blocked", "quarantined", "informational", "superseded"}
ROUTE_STATUSES = {"delivered", "acknowledged", "deduplicated", "inhibited", "quarantined", "missing", "misrouted", "stale"}
RISKY_ROUTE_STATUSES = ROUTE_STATUSES - {"delivered", "acknowledged"}
RISKY_SIGNAL_STATES = {"warning", "firing", "stale", "missing", "flapping", "superseded", "quarantined"}
FENCE_REASONS = {
    "missing_route",
    "misrouted_receiver",
    "stale_acknowledgment",
    "scope_mismatch",
    "dedupe_erased_residue",
    "inhibited_without_clearance",
    "public_link_escalation_gap",
    "delegated_worker_flapping",
    "sibling_boundary_laundering",
}
AUTHORITY_WORDS = {
    "authorization", "legal", "compliance", "audit", "opinion", "proof", "verdict",
    "custody", "release", "deletion", "retention", "repair", "finality", "truth",
    "incident", "pager", "ticket", "ownership", "approval", "consent", "public",
    "harbor", "ward", "viewfs", "steward", "slopos", "schell", "helm",
}

fixture_paths = sorted(FIXTURES.glob("specimen-92-escalation-routing/fixture.json"))
if not fixture_paths:
    print("No specimen 92 escalation/routing fixture found")
    sys.exit(1)

errors = []
fixture_count = packet_count = witness_count = fence_count = 0
route_status_counts = {status: 0 for status in ROUTE_STATUSES}
packet_status_counts = {status: 0 for status in PACKET_STATUSES}

for fixture_path in fixture_paths:
    fixture_count += 1
    rel = fixture_path.relative_to(ROOT)
    fixture = load_json(fixture_path)
    if fixture.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if fixture.get("specimen_id") != "92":
        errors.append(f"{rel}: specimen_id must be 92")

    cadences = {item.get("cadence_id"): item for item in fixture.get("source_recheck_refs") or []}
    signals = {item.get("signal_id"): item for item in fixture.get("source_drift_signal_refs") or []}
    stale_fences = {item.get("fence_id"): item for item in fixture.get("source_stale_verification_fence_refs") or []}
    carriers = {item.get("carrier_id"): item for item in fixture.get("carrier_refs") or []}
    consumers = {item.get("consumer_id") for item in fixture.get("consumer_refs") or []}

    packets = fixture.get("escalation_packets") or []
    witnesses = fixture.get("routing_witnesses") or []
    fences = fixture.get("unresolved_signal_fences") or []
    if not packets:
        errors.append(f"{rel}: missing escalation_packets")
    if not witnesses:
        errors.append(f"{rel}: missing routing_witnesses")
    if not fences:
        errors.append(f"{rel}: missing unresolved_signal_fences")

    negative_codes = {case.get("failure_code") or case.get("must_fail_with") for case in fixture.get("negative_cases") or []}
    missing_codes = sorted(REQUIRED_FAILURE_CODES - negative_codes)
    if missing_codes:
        errors.append(f"{rel}: missing required negative cases: {', '.join(missing_codes)}")

    packet_by_id = {}
    required_witnesses = {}
    required_fences = {}
    packet_scopes = {}
    source_signals_routed = set()
    for packet in packets:
        packet_count += 1
        pid = packet.get("packet_id", "<missing>")
        if pid in packet_by_id:
            errors.append(f"{rel}: duplicate packet_id {pid}")
        packet_by_id[pid] = packet
        if packet.get("packet_family") != "foundry_escalation_packet_v0":
            errors.append(f"{rel}: packet {pid} has wrong packet_family")
        if not require_sha256(packet.get("packet_digest")):
            errors.append(f"{rel}: packet {pid} missing sha256 packet_digest")
        status = packet.get("packet_status")
        if status not in PACKET_STATUSES:
            errors.append(f"{rel}: packet {pid} has unknown packet_status {status!r}")
        else:
            packet_status_counts[status] += 1
        for key in ["source_cadence_ids", "source_drift_signal_ids", "carrier_refs", "escalation_scope", "route_basis", "required_receivers", "required_routing_witnesses", "authority_boundaries"]:
            if not packet.get(key):
                errors.append(f"{rel}: packet {pid} missing {key}")
        for cid in packet.get("source_cadence_ids") or []:
            if cid not in cadences:
                errors.append(f"{rel}: packet {pid} references unknown source cadence {cid}")
        for sid in packet.get("source_drift_signal_ids") or []:
            if sid not in signals:
                errors.append(f"{rel}: packet {pid} references unknown source drift signal {sid}")
            else:
                source_signals_routed.add(sid)
                signal_cadence = signals[sid].get("cadence_id")
                if signal_cadence not in set(packet.get("source_cadence_ids") or []):
                    errors.append(f"{rel}: packet {pid} signal {sid} cadence {signal_cadence} not in packet source_cadence_ids")
        for fid in packet.get("source_stale_verification_fence_ids") or []:
            if fid not in stale_fences:
                errors.append(f"{rel}: packet {pid} references unknown stale-verification fence {fid}")
        for cref in packet.get("carrier_refs") or []:
            cid = cref.get("carrier_id")
            if cid not in carriers:
                errors.append(f"{rel}: packet {pid} references unknown carrier {cid}")
            elif cref.get("carrier_digest") != carriers[cid].get("carrier_digest"):
                errors.append(f"{rel}: packet {pid} carrier {cid} digest mismatch")
        scope = packet.get("escalation_scope") or {}
        packet_scopes[pid] = scope
        for consumer_id in scope.get("consumers") or []:
            if consumer_id not in consumers:
                errors.append(f"{rel}: packet {pid} scopes unknown consumer {consumer_id}")
        # Scope must not exceed the source cadences/signals unless the extra consumer is a route-only receiver explicitly named.
        allowed = {"consumers": set(), "surfaces": set(), "audiences": set(), "purpose_classes": set()}
        for cid in packet.get("source_cadence_ids") or []:
            cadence_scope = (cadences.get(cid) or {}).get("scope") or {}
            for key in allowed:
                allowed[key].update(cadence_scope.get(key) or [])
        receiver_consumers = {r.get("consumer_id") for r in packet.get("required_receivers") or []}
        extra_consumers = set(scope.get("consumers") or []) - allowed["consumers"] - receiver_consumers
        if extra_consumers:
            errors.append(f"{rel}: packet {pid} consumer scope exceeds source cadence without receiver: {', '.join(sorted(extra_consumers))}")
        for key in ["surfaces", "audiences", "purpose_classes"]:
            extra = set(scope.get(key) or []) - allowed[key]
            if extra:
                errors.append(f"{rel}: packet {pid} {key} exceeds source cadence scope: {', '.join(sorted(extra))}")
        basis = packet.get("route_basis") or {}
        for key in ["severity_class", "channel_class", "grouping_key", "dedupe_key", "route_deadline_at", "required_residue", "blocked_inferences"]:
            if not basis.get(key):
                errors.append(f"{rel}: packet {pid} route_basis missing {key}")
        for receiver in packet.get("required_receivers") or []:
            if receiver.get("consumer_id") not in consumers:
                errors.append(f"{rel}: packet {pid} receiver names unknown consumer {receiver.get('consumer_id')}")
            if not receiver.get("receiver_role"):
                errors.append(f"{rel}: packet {pid} receiver missing receiver_role")
        if status in {"blocked", "quarantined"} and not packet.get("required_unresolved_signal_fences"):
            errors.append(f"{rel}: {status} packet {pid} must require unresolved-signal fences")
        required_witnesses[pid] = set(packet.get("required_routing_witnesses") or [])
        required_fences[pid] = set(packet.get("required_unresolved_signal_fences") or [])
        boundary_text = " ".join(packet.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: packet {pid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: packet {pid} authority boundaries should name refused authority")

    fence_by_id = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate unresolved-signal fence_id {fid}")
        fence_by_id[fid] = fence
        pid = fence.get("packet_id")
        if fence.get("fence_family") != "foundry_unresolved_signal_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        if not require_sha256(fence.get("fence_digest")):
            errors.append(f"{rel}: fence {fid} missing sha256 fence_digest")
        if pid not in packet_by_id:
            errors.append(f"{rel}: fence {fid} references missing packet {pid}")
        if fence.get("fence_reason") not in FENCE_REASONS:
            errors.append(f"{rel}: fence {fid} has unknown fence_reason {fence.get('fence_reason')!r}")
        if not parse_time(fence.get("created_at")):
            errors.append(f"{rel}: fence {fid} missing/unparsable created_at")
        for sid in fence.get("affected_signal_ids") or []:
            if sid not in signals:
                errors.append(f"{rel}: fence {fid} references unknown source signal {sid}")
        for key in ["affected_signal_ids", "affected_witness_ids", "blocked_uses", "required_clearance", "authority_boundaries"]:
            if not fence.get(key):
                errors.append(f"{rel}: fence {fid} missing {key}")
        boundary_text = " ".join(fence.get("authority_boundaries") or []).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: fence {fid} must name refused authority boundary")

    witness_by_id = {}
    witnesses_by_packet = {}
    for witness in witnesses:
        witness_count += 1
        wid = witness.get("witness_id", "<missing>")
        if wid in witness_by_id:
            errors.append(f"{rel}: duplicate routing witness_id {wid}")
        witness_by_id[wid] = witness
        pid = witness.get("packet_id")
        witnesses_by_packet.setdefault(pid, set()).add(wid)
        if witness.get("witness_family") != "foundry_routing_witness_v0":
            errors.append(f"{rel}: witness {wid} has wrong witness_family")
        if pid not in packet_by_id:
            errors.append(f"{rel}: witness {wid} references missing packet {pid}")
            scope = {}
        else:
            scope = packet_scopes.get(pid) or {}
        if not require_sha256(witness.get("witness_digest")):
            errors.append(f"{rel}: witness {wid} missing sha256 witness_digest")
        status = witness.get("route_status")
        if status not in ROUTE_STATUSES:
            errors.append(f"{rel}: witness {wid} has unknown route_status {status!r}")
        else:
            route_status_counts[status] += 1
        if not parse_time(witness.get("observed_at")):
            errors.append(f"{rel}: witness {wid} missing/unparsable observed_at")
        if witness.get("receiver_consumer_id") not in consumers:
            errors.append(f"{rel}: witness {wid} names unknown receiver consumer")
        if scope:
            echo = witness.get("scope_echo") or {}
            # Receiver can be required even if not original signal consumer, but echo must not invent surfaces/audiences/purposes outside packet scope.
            for key in ["surfaces", "audiences", "purpose_classes"]:
                extra = set(echo.get(key) or []) - set(scope.get(key) or [])
                if extra:
                    errors.append(f"{rel}: witness {wid} scope_echo {key} exceeds packet scope: {', '.join(sorted(extra))}")
            extra_consumers = set(echo.get("consumers") or []) - set(scope.get("consumers") or []) - {witness.get("receiver_consumer_id")}
            if extra_consumers:
                errors.append(f"{rel}: witness {wid} consumer echo exceeds packet scope")
        for key in ["receiver_role", "channel_class", "scope_echo", "evidence_refs", "delivered_residue", "blocked_inferences", "authority_boundaries"]:
            if not witness.get(key):
                errors.append(f"{rel}: witness {wid} missing {key}")
        residue = witness.get("delivered_residue") or {}
        if status in {"delivered", "acknowledged"}:
            if not residue.get("source_signal_ids") or not residue.get("carrier_ids"):
                errors.append(f"{rel}: witness {wid} delivered/acknowledged route must preserve source_signal_ids and carrier_ids")
        if status in RISKY_ROUTE_STATUSES and not witness.get("unresolved_signal_fence_refs"):
            errors.append(f"{rel}: risky routing witness {wid} must reference unresolved-signal fence")
        if status == "deduplicated" and not residue.get("dropped_residue"):
            errors.append(f"{rel}: deduplicated witness {wid} must name dropped_residue when residue was reduced")
        for fid in witness.get("unresolved_signal_fence_refs") or []:
            if fid not in fence_by_id:
                errors.append(f"{rel}: witness {wid} references unknown unresolved-signal fence {fid}")
        boundary_text = " ".join((witness.get("blocked_inferences") or []) + (witness.get("authority_boundaries") or [])).lower()
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: witness {wid} must include authority/refusal boundaries")

    for fid, fence in fence_by_id.items():
        for wid in fence.get("affected_witness_ids") or []:
            if wid not in witness_by_id:
                errors.append(f"{rel}: fence {fid} references unknown witness {wid}")

    for pid, needed in required_witnesses.items():
        missing = sorted(needed - witnesses_by_packet.get(pid, set()))
        if missing:
            errors.append(f"{rel}: packet {pid} missing required routing witnesses: {', '.join(missing)}")
    for pid, needed in required_fences.items():
        fence_ids_for_packet = {fid for fid, fence in fence_by_id.items() if fence.get("packet_id") == pid}
        missing = sorted(needed - fence_ids_for_packet)
        if missing:
            errors.append(f"{rel}: packet {pid} missing required unresolved-signal fences: {', '.join(missing)}")

    # Every risky source signal needs at least one packet unless it is explicitly clear/informational.
    for sid, signal in signals.items():
        if signal.get("signal_state") in RISKY_SIGNAL_STATES and sid not in source_signals_routed:
            errors.append(f"{rel}: risky source signal {sid} is not covered by an escalation packet")

    note = fixture.get("doc_coverage_refactor_note") or {}
    for path in ["fixtures/specimen-doc-coverage/coverage.json", "tools/check_foundry_specimen_doc_coverage.py"]:
        if path not in {note.get("coverage_manifest"), note.get("checker")}:
            errors.append(f"{rel}: doc_coverage_refactor_note must name {path}")
    if not any("not" in item for item in note.get("blocked_inferences") or []):
        errors.append(f"{rel}: doc_coverage_refactor_note must refuse overbroad coverage inference")

for status in ["routed", "blocked", "quarantined", "informational"]:
    if packet_status_counts[status] < 1:
        errors.append(f"specimen 92 must include at least one {status} escalation packet")
for status in ["delivered", "acknowledged", "deduplicated", "inhibited", "quarantined", "missing", "misrouted", "stale"]:
    if route_status_counts[status] < 1:
        errors.append(f"specimen 92 must include at least one {status} routing witness")

fail(errors)
print(
    f"Foundry escalation/routing check passed for {fixture_count} fixture file(s), "
    f"{packet_count} escalation packet(s), {witness_count} routing witness(es), "
    f"and {fence_count} unresolved-signal fence(s)"
)
