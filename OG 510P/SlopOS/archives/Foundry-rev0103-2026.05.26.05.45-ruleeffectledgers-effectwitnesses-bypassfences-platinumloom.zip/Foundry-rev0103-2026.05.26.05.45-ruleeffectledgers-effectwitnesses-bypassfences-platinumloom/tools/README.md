# Tools

This embryo now ships with twenty-six ordered checks plus a tiny shared helper module.

Run `make check` to verify all checks through `tools/check_foundry_all.py`.
Run individual `check_foundry_*.py` scripts when narrowing a failing seam.

The full check verifies:

1. repo/archive hygiene and index drift;
2. semantic sidecar survival rules for fixtures;
3. executable fixture coverage for specimens 70 through 95;
4. egress refusal receipt/manifest conformance for specimen 78;
5. semantic diff / regression lock / tamper corpus conformance for specimen 79;
6. semantic waiver / expiry witness / exception replay conformance for specimen 80;
7. consumer passport / portability witness / interpretation gate conformance for specimen 81;
8. delegation warrant / reliance receipt / transitive-use fence conformance for specimen 82;
9. revocation notice / recall receipt / stale-reliance fence conformance for specimen 83;
10. remediation packet / replacement witness / readmission gate conformance for specimen 84;
11. distribution manifest / adoption receipt / orphan-copy fence conformance for specimen 85;
12. surface inventory sweep / reachability witness / coverage-gap fence conformance for specimen 86;
13. exposure ledger / audience witness / purpose fence conformance for specimen 87;
14. obligation ledger / acknowledgment witness / obligation-drift fence conformance for specimen 88;
15. fulfillment receipt / completion witness / nonfulfillment fence conformance for specimen 89;
16. verification audit / evidence sample / false-closure fence conformance for specimen 90;
17. recheck cadence / drift signal / stale-verification fence conformance for specimen 91;
18. escalation packet / routing witness / unresolved-signal fence conformance for specimen 92;
19. disposition ledger / resolution witness / premature-closure fence conformance for specimen 93;
20. precedent ledger / rule-promotion witness / overgeneralization fence conformance for specimen 94;
21. rule-surface index coverage conformance for rulebook/rule/checker visibility;
22. rule-collision ledger / precedence witness / ambiguity fence conformance for specimen 95;
23. schema/fixture/checker coverage conformance for the executable harness;
24. specimen-doc/rulebook/fixture/schema/checker coverage conformance for promoted late specimens;
25. negative-case coverage conformance for late executable fixtures; and
26. lifecycle-transition coverage conformance for late executable handoffs.

`tools/foundry_checklib.py` is deliberately small. It centralizes root discovery, JSON loading, timestamp parsing, sha256-prefix checks, fatal-error reporting, and aggregate runner execution. It is not a validation framework and does not hide specimen-specific rules.

Keep automation tiny until the object model settles. These scripts are guardrails against semantic flattening, anonymous refusal, silent regression, exception drift, consumer interpretation drift, delegated-authority drift, stale-reliance drift, replacement-as-repair drift, readmission-as-distribution drift, distribution-as-inventory drift, inventory-as-exposure-approval drift, exposure-as-obligation-satisfaction drift, acknowledgment-as-fulfillment drift, completion-as-verification drift, verified-as-still-fresh drift, routed-as-handled drift, routed-as-resolved drift, resolved-as-rule drift, schema/fixture/checker coverage drift, specimen-doc coverage drift, negative-case coverage drift, and lifecycle-transition coverage drift, not a production validation runtime.
