#!/usr/bin/env python3
"""Run all Foundry checks through the shared harness runner.

rev0103 keeps the shared runner and extends the ordered list through rule
effect binding plus reference-integrity index coverage, so applied rules have
carrier-bound effect residue and cross-specimen ids remain checkable.
"""
from pathlib import Path
import sys

try:
    from foundry_checklib import run_check_scripts
except ModuleNotFoundError:  # pragma: no cover - direct execution fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import run_check_scripts

SCRIPTS = [
    "check_repo_hygiene.py",
    "check_foundry_semantic_sidecars.py",
    "check_foundry_specimen_fixtures.py",
    "check_foundry_egress_refusals.py",
    "check_foundry_semantic_regression.py",
    "check_foundry_semantic_exceptions.py",
    "check_foundry_consumer_portability.py",
    "check_foundry_delegation_boundaries.py",
    "check_foundry_revocation_recall.py",
    "check_foundry_remediation_readmission.py",
    "check_foundry_distribution_adoption.py",
    "check_foundry_surface_inventory.py",
    "check_foundry_exposure_accounting.py",
    "check_foundry_obligation_accounting.py",
    "check_foundry_fulfillment_accounting.py",
    "check_foundry_verification_audit.py",
    "check_foundry_recheck_drift.py",
    "check_foundry_escalation_routing.py",
    "check_foundry_disposition_resolution.py",
    "check_foundry_rule_promotion.py",
    "check_foundry_rule_surface_index.py",
    "check_foundry_rule_collision.py",
    "check_foundry_rule_evaluation.py",
    "check_foundry_rule_effect_binding.py",
    "check_foundry_checker_contract_index.py",
    "check_foundry_reference_integrity_index.py",
    "check_foundry_schema_fixture_coverage.py",
    "check_foundry_specimen_doc_coverage.py",
    "check_foundry_negative_case_coverage.py",
    "check_foundry_lifecycle_transition_coverage.py",
]

run_check_scripts(SCRIPTS)
