#!/usr/bin/env python3
"""Check Foundry distribution/adoption fixtures.

Specimen 85 is about proving that a readmitted semantic carrier was actually
accounted for across its relying consumers and surfaces without turning
Foundry into delivery infrastructure, cache-control, release approval, audit
opinion, policy authorization, or sibling-cube authority.
"""
from pathlib import Path
from datetime import datetime
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-DIST-001-DISTRIBUTION-MANIFEST",
    "R-DIST-002-CARRIER-LINKAGE",
    "R-DIST-003-TARGET-CONSUMER-SCOPE",
    "R-DIST-004-ADOPTION-RECEIPT",
    "R-DIST-005-OLD-CARRIER-RETIREMENT",
    "R-DIST-006-ORPHAN-COPY-FENCE",
    "R-DIST-007-PROPAGATION-WINDOW",
    "R-DIST-008-PARTIAL-ADOPTION-NO-OVERCLAIM",
    "R-DIST-009-NON-TRANSITIVE-ADOPTION",
    "R-DIST-010-AUTHORITY-LAUNDERING-FENCE",
    "R-DIST-011-CHANNEL-NEUTRALITY",
    "R-DIST-012-STRAGGLER-RECALL-HOOK",
}

REQUIRED_FAILURE_CODES = {
    "distribution_manifest_required",
    "adoption_receipt_required",
    "unknown_target_consumer_refused",
    "stale_carrier_unfenced_refused",
    "propagation_window_expired_refused",
    "cache_copy_without_purge_refused",
    "receipt_digest_mismatch_refused",
    "partial_adoption_overclaim_refused",
    "target_scope_widening_refused",
    "carrier_linkage_missing_refused",
    "adoption_as_approval_refused",
    "delivery_channel_as_truth_refused",
    "orphan_copy_as_current_refused",
    "receipt_without_readmission_gate_refused",
    "adoption_as_cache_policy_refused",
    "straggler_recall_hook_required",
}

MANIFEST_STATUSES = {"open", "completed", "partial", "blocked", "superseded", "retired"}
ADOPTION_RESULTS = {"adopted", "partial", "refused", "quarantined", "superseded"}
FENCE_RESULTS = {"blocked", "quarantined", "retired_as_history", "monitor_only"}
AUTHORITY_WORDS = {"truth", "verdict", "approval", "opinion", "permission", "custody", "remediation", "repair", "policy", "proof"}


def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("distribution_manifests"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No distribution_manifests fixture found for specimen 85.")

manifest_count = 0
adoption_count = 0
fence_count = 0
completed_manifests = 0
partial_manifests = 0
blocked_manifests = 0
adopted_receipts = 0
partial_receipts = 0
refused_or_quarantined_receipts = 0
blocked_fences = 0
retired_fences = 0
quarantined_fences = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    consumer_ids = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    gate_refs = {g.get("gate_id"): g for g in data.get("readmission_refs", []) if g.get("gate_id")}
    carriers = {c.get("carrier_id"): c for c in data.get("carrier_refs", []) if c.get("carrier_id")}

    manifests = data.get("distribution_manifests") or []
    receipts = data.get("adoption_receipts") or []
    fences = data.get("orphan_copy_fences") or []
    if not manifests:
        errors.append(f"{rel}: distribution_manifests must be non-empty")

    manifests_by_id = {}
    windows_by_manifest = {}
    for manifest in manifests:
        manifest_count += 1
        mid = manifest.get("manifest_id", "<missing>")
        if mid in manifests_by_id:
            errors.append(f"{rel}: duplicate manifest_id {mid}")
        manifests_by_id[mid] = manifest
        if manifest.get("manifest_family") != "foundry_distribution_manifest_v0":
            errors.append(f"{rel}: manifest {mid} has wrong manifest_family")
        if not str(manifest.get("manifest_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: manifest {mid} missing sha256 manifest_digest")
        status = manifest.get("manifest_status")
        if status not in MANIFEST_STATUSES:
            errors.append(f"{rel}: manifest {mid} has unknown manifest_status {status!r}")
        if status == "completed":
            completed_manifests += 1
        if status == "partial":
            partial_manifests += 1
        if status == "blocked":
            blocked_manifests += 1
        if not parse_time(manifest.get("issued_at")):
            errors.append(f"{rel}: manifest {mid} missing/unparsable issued_at")
        for key in ["source_packet_id", "source_readmission_gate_ids", "distributed_carriers", "superseded_carriers", "target_consumers", "target_surfaces", "delivery_channels", "required_receipts", "required_fences", "authority_boundaries"]:
            if not manifest.get(key):
                errors.append(f"{rel}: manifest {mid} missing {key}")
        target_consumers = set(manifest.get("target_consumers") or [])
        unknown_targets = target_consumers - consumer_ids
        if unknown_targets:
            errors.append(f"{rel}: manifest {mid} targets unknown consumers: {', '.join(sorted(unknown_targets))}")
        gate_ids = set(manifest.get("source_readmission_gate_ids") or [])
        unknown_gates = gate_ids - set(gate_refs)
        if unknown_gates:
            errors.append(f"{rel}: manifest {mid} references unknown readmission gates: {', '.join(sorted(unknown_gates))}")
        gate_consumers = {gate_refs[g].get("consumer_id") for g in gate_ids if g in gate_refs}
        if gate_consumers and not target_consumers <= gate_consumers:
            errors.append(f"{rel}: manifest {mid} targets consumers without matching readmission gates: {', '.join(sorted(target_consumers - gate_consumers))}")
        for carrier in manifest.get("distributed_carriers") or []:
            cid = carrier.get("carrier_id")
            if cid not in carriers:
                errors.append(f"{rel}: manifest {mid} distributes unknown carrier {cid}")
            elif carrier.get("carrier_digest") != carriers[cid].get("carrier_digest"):
                errors.append(f"{rel}: manifest {mid} carrier {cid} digest mismatch")
            if not str(carrier.get("carrier_digest", "")).startswith("sha256:"):
                errors.append(f"{rel}: manifest {mid} carrier {cid} missing sha256 digest")
        for carrier in manifest.get("superseded_carriers") or []:
            if not carrier.get("carrier_id") or not str(carrier.get("carrier_digest", "")).startswith("sha256:"):
                errors.append(f"{rel}: manifest {mid} has malformed superseded carrier")
            if not carrier.get("retirement_required"):
                errors.append(f"{rel}: manifest {mid} superseded carrier {carrier.get('carrier_id')} must name retirement_required")
        window = manifest.get("propagation_window") or {}
        opened = parse_time(window.get("opened_at"))
        closes = parse_time(window.get("closes_at"))
        if not opened or not closes or not opened < closes:
            errors.append(f"{rel}: manifest {mid} has invalid propagation_window")
        else:
            windows_by_manifest[mid] = (opened, closes)
        boundary_text = " ".join(manifest.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: manifest {mid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: manifest {mid} authority boundaries should name at least one refused authority")

    receipts_by_manifest_consumer = {}
    for receipt in receipts:
        adoption_count += 1
        rid = receipt.get("receipt_id", "<missing>")
        mid = receipt.get("manifest_id")
        if receipt.get("receipt_family") != "foundry_adoption_receipt_v0":
            errors.append(f"{rel}: adoption receipt {rid} has wrong receipt_family")
        if mid not in manifests_by_id:
            errors.append(f"{rel}: adoption receipt {rid} references missing manifest {mid}")
            manifest = {}
        else:
            manifest = manifests_by_id[mid]
        if not str(receipt.get("receipt_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: adoption receipt {rid} missing sha256 receipt_digest")
        result = receipt.get("adoption_result")
        if result not in ADOPTION_RESULTS:
            errors.append(f"{rel}: adoption receipt {rid} has unknown adoption_result {result!r}")
        if result == "adopted":
            adopted_receipts += 1
        if result == "partial":
            partial_receipts += 1
        if result in {"refused", "quarantined"}:
            refused_or_quarantined_receipts += 1
        cid = receipt.get("consumer_id")
        if cid not in consumer_ids:
            errors.append(f"{rel}: adoption receipt {rid} names unknown consumer {cid}")
        if manifest and cid not in set(manifest.get("target_consumers") or []):
            errors.append(f"{rel}: adoption receipt {rid} consumer {cid} is outside manifest target scope")
        surface = receipt.get("surface_id")
        if manifest and surface not in set(manifest.get("target_surfaces") or []):
            errors.append(f"{rel}: adoption receipt {rid} surface {surface} is outside manifest target surfaces")
        receipts_by_manifest_consumer.setdefault(mid, set()).add(cid)
        received = parse_time(receipt.get("received_at"))
        if not received:
            errors.append(f"{rel}: adoption receipt {rid} missing/unparsable received_at")
        elif mid in windows_by_manifest:
            opened, closes = windows_by_manifest[mid]
            if not (opened <= received <= closes):
                errors.append(f"{rel}: adoption receipt {rid} arrives outside propagation window")
        adopted_carrier = receipt.get("adopted_carrier_id")
        if manifest:
            manifest_carriers = {c.get("carrier_id"): c for c in manifest.get("distributed_carriers") or []}
            if adopted_carrier not in manifest_carriers and result != "superseded":
                errors.append(f"{rel}: adoption receipt {rid} adopts carrier not distributed by manifest")
            elif adopted_carrier in manifest_carriers and receipt.get("adopted_carrier_digest") != manifest_carriers[adopted_carrier].get("carrier_digest"):
                errors.append(f"{rel}: adoption receipt {rid} adopted carrier digest mismatch")
        for key in ["previous_carrier_id", "previous_carrier_retirement", "local_gate_refs", "residue_carried", "admitted_uses", "blocked_uses", "non_promises"]:
            if not receipt.get(key):
                errors.append(f"{rel}: adoption receipt {rid} missing {key}")
        for gate in receipt.get("local_gate_refs") or []:
            if gate not in gate_refs:
                errors.append(f"{rel}: adoption receipt {rid} references unknown local gate {gate}")
            elif gate_refs[gate].get("consumer_id") != cid:
                errors.append(f"{rel}: adoption receipt {rid} local gate {gate} belongs to another consumer")
            if manifest and gate not in set(manifest.get("source_readmission_gate_ids") or []):
                errors.append(f"{rel}: adoption receipt {rid} local gate {gate} is not listed in manifest")
        retirement = str(receipt.get("previous_carrier_retirement", "")).lower()
        if not any(word in retirement for word in ["retired", "quarantined", "blocked", "superseded", "history"]):
            errors.append(f"{rel}: adoption receipt {rid} must retire/quarantine/block previous carrier")
        if result in {"partial", "refused", "quarantined"} and not receipt.get("blocked_uses"):
            errors.append(f"{rel}: adoption receipt {rid} must name blocked_uses for {result}")
        np = " ".join(receipt.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: adoption receipt {rid} must include authority/refusal non_promises")
        if result == "partial" and not any(word in np for word in ["verdict", "approval", "truth", "custody"]):
            errors.append(f"{rel}: partial adoption receipt {rid} must refuse overclaim authority")

    fences_by_manifest_owner = {}
    for fence in fences:
        fence_count += 1
        fid = fence.get("fence_id", "<missing>")
        mid = fence.get("manifest_id")
        if fence.get("fence_family") != "foundry_orphan_copy_fence_v0":
            errors.append(f"{rel}: orphan-copy fence {fid} has wrong fence_family")
        if mid not in manifests_by_id:
            errors.append(f"{rel}: orphan-copy fence {fid} references missing manifest {mid}")
            manifest = {}
        else:
            manifest = manifests_by_id[mid]
        if not str(fence.get("stale_artifact_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: orphan-copy fence {fid} missing sha256 stale_artifact_digest")
        result = fence.get("fence_result")
        if result not in FENCE_RESULTS:
            errors.append(f"{rel}: orphan-copy fence {fid} has unknown fence_result {result!r}")
        if result == "blocked":
            blocked_fences += 1
        if result == "retired_as_history":
            retired_fences += 1
        if result == "quarantined":
            quarantined_fences += 1
        owner = fence.get("owning_consumer_id")
        if owner not in consumer_ids:
            errors.append(f"{rel}: orphan-copy fence {fid} names unknown owning_consumer_id {owner}")
        if manifest and owner not in set(manifest.get("target_consumers") or []):
            errors.append(f"{rel}: orphan-copy fence {fid} owner {owner} is outside manifest target scope")
        fences_by_manifest_owner.setdefault(mid, set()).add(owner)
        if not parse_time(fence.get("detected_at")):
            errors.append(f"{rel}: orphan-copy fence {fid} missing/unparsable detected_at")
        for key in ["stale_artifact_id", "stale_surface_id", "fence_reason", "replacement_carrier_id", "blocked_uses", "required_clearance", "non_promises"]:
            if not fence.get(key):
                errors.append(f"{rel}: orphan-copy fence {fid} missing {key}")
        if fence.get("replacement_carrier_id") and manifest:
            manifest_carrier_ids = {c.get("carrier_id") for c in manifest.get("distributed_carriers") or []}
            if fence.get("replacement_carrier_id") not in manifest_carrier_ids:
                errors.append(f"{rel}: orphan-copy fence {fid} replacement carrier is not in manifest")
        np = " ".join(fence.get("non_promises") or []).lower()
        if not any(word in np for word in ["deletion", "retention", "policy", "repair", "custody", "proof"]):
            errors.append(f"{rel}: orphan-copy fence {fid} must refuse deletion/retention/policy/repair/custody/proof overclaims")

    for mid, manifest in manifests_by_id.items():
        targets = set(manifest.get("target_consumers") or [])
        accounted = receipts_by_manifest_consumer.get(mid, set()) | fences_by_manifest_owner.get(mid, set())
        missing = targets - accounted
        if missing:
            errors.append(f"{rel}: manifest {mid} lacks receipt or orphan fence for targets: {', '.join(sorted(missing))}")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if completed_manifests < 1 or partial_manifests < 1 or blocked_manifests < 1:
    errors.append("Specimen 85 needs completed, partial, and blocked distribution manifest examples.")
if adopted_receipts < 1 or partial_receipts < 1 or refused_or_quarantined_receipts < 1:
    errors.append("Specimen 85 needs adopted, partial, and refused/quarantined adoption receipt examples.")
if blocked_fences < 1 or retired_fences < 1 or quarantined_fences < 1:
    errors.append("Specimen 85 needs blocked, retired_as_history, and quarantined orphan-copy fence examples.")

rulebook = ROOT / "docs/30-architecture/distribution-adoption-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing distribution/adoption rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = sorted(rule for rule in REQUIRED_RULES if rule not in text)
    if missing_rules:
        errors.append("Distribution/adoption rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry distribution/adoption check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry distribution/adoption check passed for {len(fixtures)} fixture file(s), {manifest_count} distribution manifest(s), {adoption_count} adoption receipt(s), and {fence_count} orphan-copy fence(s)")
