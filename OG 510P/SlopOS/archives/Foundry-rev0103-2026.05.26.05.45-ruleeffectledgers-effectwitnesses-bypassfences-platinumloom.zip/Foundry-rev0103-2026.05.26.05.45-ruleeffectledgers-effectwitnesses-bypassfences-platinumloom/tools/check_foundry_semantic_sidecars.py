#!/usr/bin/env python3
"""Tiny semantic-sidecar guard for Foundry fixtures.

This is intentionally smaller than JSON Schema validation. It checks the survival
properties that matter for specimen 77: egress surfaces must carry sidecars with
cuts, fences, and loss profiles; classification-heavy exports must refuse label
or bare-code semantics; and suppression/status/balance residue must not be
silently flattened.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

errors = []
sidecars = []

for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    candidates = []
    if isinstance(data, dict):
        if data.get("sidecar_family") == "foundry_semantic_sidecar_v0":
            candidates.append(data)
        if isinstance(data.get("sidecar"), dict):
            candidates.append(data["sidecar"])
    for sc in candidates:
        sidecars.append((path, sc))

if not sidecars:
    errors.append("No foundry_semantic_sidecar_v0 sidecars found in fixtures.")

for path, sc in sidecars:
    prefix = str(path.relative_to(ROOT))
    if sc.get("sidecar_family") != "foundry_semantic_sidecar_v0":
        errors.append(f"{prefix}: sidecar_family must be foundry_semantic_sidecar_v0")
    if not sc.get("sidecar_digest", "").startswith("sha256:"):
        errors.append(f"{prefix}: sidecar_digest must be sha256-prefixed")
    surface = sc.get("attached_surface") or {}
    if surface.get("kind") not in {"chart", "table", "json_export", "csv", "markdown", "support_card", "dashboard_tile", "query_result", "materialized_result"}:
        errors.append(f"{prefix}: attached_surface.kind is missing or unknown")
    if not str(surface.get("surface_digest", "")).startswith("sha256:"):
        errors.append(f"{prefix}: attached_surface.surface_digest must be sha256-prefixed")
    if not sc.get("source_cut"):
        errors.append(f"{prefix}: source_cut is required")
    fences = set(sc.get("fences") or [])
    if not fences:
        errors.append(f"{prefix}: at least one fence is required")
    loss = sc.get("loss_profile") or {}
    if "row_preserving" not in loss or loss.get("drill_through") not in {"allowed", "refused", "bounded", "sidecar_only"} or not isinstance(loss.get("irreversible_losses"), list):
        errors.append(f"{prefix}: loss_profile must carry row_preserving, drill_through, and irreversible_losses")

    egress_kind = surface.get("kind") in {"chart", "csv", "markdown", "dashboard_tile", "json_export", "table", "support_card"}
    if egress_kind and "export_sidecar_required" not in fences:
        errors.append(f"{prefix}: egress sidecar is missing export_sidecar_required fence")

    if sc.get("classification_pins"):
        for required in ["no_label_join", "no_bare_code_join"]:
            if required not in fences:
                errors.append(f"{prefix}: classification sidecar missing {required}")
    if sc.get("suppression_witnesses") and not ({"suppression_blocks_subtraction", "zero_not_released"} & fences):
        errors.append(f"{prefix}: suppression sidecar missing subtraction/zero refusal fence")
    if sc.get("observation_status_cards") and "as_observed_fence_required" not in fences:
        errors.append(f"{prefix}: observedness sidecar missing as_observed_fence_required")
    if sc.get("reconciliation_witnesses") and not ({"same_cut_only", "classification_cut_specific", "residual_visible"} & fences):
        errors.append(f"{prefix}: reconciliation sidecar missing cut/residual fence")
    if sc.get("materialization_cuts") and not ({"same_cut_only", "vary_basis_required", "stale_cut_refused"} & fences):
        errors.append(f"{prefix}: materialization sidecar missing reuse/cut fence")

if errors:
    print("Foundry semantic sidecar check failed:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"Foundry semantic sidecar check passed for {len(sidecars)} sidecars")
