#!/usr/bin/env python3
"""Check Foundry semantic regression fixtures.

Specimen 79 is about revision-to-revision honesty. It intentionally checks a
small set of semantic-diff, regression-lock, and tamper-corpus properties rather
than becoming a full migration framework or JSON Patch engine.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

ALLOWED_PATCH_OPS = {"add", "remove", "replace", "move", "copy", "test"}
REQUIRED_ROLES = {"sidecar", "egress_manifest", "refusal_receipt"}
REQUIRED_FAILURE_CODES = {
    "semantic_diff_manifest_required",
    "canonical_digest_required",
    "regression_lock_required",
    "tamper_case_required",
    "non_slopos_consumer_required",
    "breaking_change_requires_witness",
    "digest_reuse_after_mutation",
    "sidecar_pin_drop_unwitnessed",
    "receipt_rule_change_unwitnessed",
    "loss_profile_downgrade_unwitnessed",
    "cut_change_requires_migration_witness",
    "generic_problem_details_regression",
}
REQUIRED_RULES = {
    "R-REGRESS-001-DIFF-MANIFEST",
    "R-REGRESS-002-CANONICAL-DIGEST",
    "R-REGRESS-003-REGRESSION-LOCK",
    "R-REGRESS-004-TAMPER-CORPUS",
    "R-REGRESS-005-BREAKING-WITNESS",
    "R-REGRESS-006-NON-SLOPOS-CONSUMER",
    "R-REGRESS-007-DIGEST-MUTATION",
}

errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("semantic_diff_manifest"), dict):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No semantic_diff_manifest fixture found for specimen 79.")

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    manifest = data.get("semantic_diff_manifest") or {}
    if manifest.get("manifest_family") != "foundry_semantic_diff_manifest_v0":
        errors.append(f"{rel}: manifest_family must be foundry_semantic_diff_manifest_v0")
    for key in ["manifest_digest", "rule_suite_digest"]:
        if not str(manifest.get(key, "")).startswith("sha256:"):
            errors.append(f"{rel}: {key} must be sha256-prefixed")
    if manifest.get("previous_revision") != "rev0084" or manifest.get("candidate_revision") != "rev0085":
        errors.append(f"{rel}: manifest must compare rev0084 to rev0085")
    if "rfc8785" not in str(manifest.get("canonicalization_profile", "")).lower():
        errors.append(f"{rel}: canonicalization_profile must name rfc8785-like posture")

    for artifact_key in ["baseline_artifacts", "candidate_artifacts"]:
        artifacts = manifest.get(artifact_key)
        if not isinstance(artifacts, list) or not artifacts:
            errors.append(f"{rel}: {artifact_key} must be a non-empty list")
            continue
        roles = {a.get("role") for a in artifacts}
        missing_roles = REQUIRED_ROLES - roles
        if missing_roles:
            errors.append(f"{rel}: {artifact_key} missing roles: {', '.join(sorted(missing_roles))}")
        for artifact in artifacts:
            aid = artifact.get("artifact_id", "<missing>")
            if not str(artifact.get("digest", "")).startswith("sha256:"):
                errors.append(f"{rel}: artifact {aid} must have sha256 digest")
            if not str(artifact.get("canonical_bytes_digest", "")).startswith("sha256:"):
                errors.append(f"{rel}: artifact {aid} must have sha256 canonical_bytes_digest")

    witnesses = {w.get("witness_id") for w in data.get("migration_witnesses", []) if w.get("witness_id")}
    diff_entries = manifest.get("diff_entries") or []
    if not diff_entries:
        errors.append(f"{rel}: diff_entries must be non-empty")
    for entry in diff_entries:
        eid = entry.get("entry_id", "<missing>")
        for key in ["path", "change_class", "compatibility", "semantic_effect"]:
            if not entry.get(key):
                errors.append(f"{rel}: diff entry {eid} missing {key}")
        if entry.get("compatibility") in {"breaking", "requires_review", "breaking_refused"}:
            wid = entry.get("witness_id")
            if not wid or wid not in witnesses:
                errors.append(f"{rel}: diff entry {eid} requires a migration witness")

    consumers = data.get("consumers") or []
    if not any(c.get("non_slopos") is True or c.get("cube") not in {None, "", "SlopOS"} for c in consumers):
        errors.append(f"{rel}: at least one non-SlopOS consumer is required")

    locks = data.get("regression_locks") or []
    if not locks:
        errors.append(f"{rel}: regression_locks must be non-empty")
    lock_failure_codes = set()
    for lock in locks:
        lid = lock.get("lock_id", "<missing>")
        if lock.get("lock_family") != "foundry_regression_lock_v0":
            errors.append(f"{rel}: lock {lid} has wrong lock_family")
        if not isinstance(lock.get("protected_paths"), list) or not lock.get("protected_paths"):
            errors.append(f"{rel}: lock {lid} must name protected_paths")
        if not lock.get("invariant"):
            errors.append(f"{rel}: lock {lid} must name invariant")
        if not lock.get("failure_code"):
            errors.append(f"{rel}: lock {lid} must name failure_code")
        else:
            lock_failure_codes.add(lock["failure_code"])

    tamper_cases = data.get("tamper_cases") or []
    if not tamper_cases:
        errors.append(f"{rel}: tamper_cases must be non-empty")
    tamper_failure_codes = set()
    for case in tamper_cases:
        cid = case.get("case_id", "<missing>")
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: tamper case {cid} must set must_fail=true")
        code = case.get("expected_failure_code")
        if not code:
            errors.append(f"{rel}: tamper case {cid} missing expected_failure_code")
        else:
            tamper_failure_codes.add(code)
        ops = case.get("mutation_ops")
        if not isinstance(ops, list) or not ops:
            errors.append(f"{rel}: tamper case {cid} must name mutation_ops")
            continue
        for op in ops:
            if op.get("op") not in ALLOWED_PATCH_OPS:
                errors.append(f"{rel}: tamper case {cid} uses unsupported op {op.get('op')!r}")
            if not isinstance(op.get("path"), str) or not op.get("path", "").startswith("/"):
                errors.append(f"{rel}: tamper case {cid} op missing JSON-pointer-like path")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    missing_tamper_codes = REQUIRED_FAILURE_CODES.intersection(tamper_failure_codes | lock_failure_codes) - (tamper_failure_codes | lock_failure_codes)
    if missing_tamper_codes:
        errors.append(f"{rel}: unreachable regression failure codes: {', '.join(sorted(missing_tamper_codes))}")

# Rulebook text should contain every rule id so fixtures do not invent invisible rules.
rulebook = ROOT / "docs/30-architecture/semantic-regression-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing semantic regression rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = [rule for rule in sorted(REQUIRED_RULES) if rule not in text]
    if missing_rules:
        errors.append("Semantic regression rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry semantic regression check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry semantic regression check passed for {len(fixtures)} fixture file(s)")
