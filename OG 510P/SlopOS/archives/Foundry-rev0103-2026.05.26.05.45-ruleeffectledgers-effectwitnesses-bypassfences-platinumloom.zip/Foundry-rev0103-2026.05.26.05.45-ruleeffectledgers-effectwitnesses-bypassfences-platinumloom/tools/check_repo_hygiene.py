#!/usr/bin/env python3
from pathlib import Path
import json
import re
import sys
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
required = [
    'README.md',
    'START_HERE.md',
    'ARCHIVE_INDEX.md',
    'RELEASE-MANIFEST.json',
    'REVISION-RECEIPT.json',
    'SURFACE-STATUS.json',
    'QUESTION-REGISTRY.json',
    'ASSUMPTION-LEDGER.json',
    'FOREIGN-PRESSURE-LEDGER.json',
    'FOLLOWTHROUGH-QUEUE.json',
    'IRREVERSIBLE-DECISION-LEDGER.json',
    'docs/00-meta/charter.md',
    'docs/00-meta/roadmap.md',
    'docs/00-meta/load-bearing-source-register.md',
    'docs/00-meta/noun-promotion-rubric.md',
    'docs/00-meta/source-review-queue.md',
    'docs/30-architecture/architecture-overview.md',
    'docs/30-architecture/specimen-flow-index.md',
    'docs/90-inspirations/steal-these-ideas.md',
    'docs/README.md',
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    print('Missing required surfaces:')
    for m in missing:
        print(' -', m)
    sys.exit(1)
actual = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts and p.suffix != '.pyc')
index = (ROOT / 'ARCHIVE_INDEX.md').read_text(errors='ignore').splitlines()
listed = sorted(line.split('`')[1] for line in index if line.strip().startswith('- `') and '`' in line)

specimen_docs = sorted(str(p.relative_to(ROOT)) for p in (ROOT / 'docs/30-architecture').glob('specimen-flow-*.md') if p.name != 'specimen-flow-index.md')
specimen_index = (ROOT / 'docs/30-architecture/specimen-flow-index.md').read_text(errors='ignore')
specimen_listed = sorted(re.findall(r'`(docs/30-architecture/specimen-flow-[^`]+\.md)`', specimen_index))

specimen_numbers = []
for rel in specimen_docs:
    m = re.search(r'specimen-flow-(\d+)-', rel)
    if not m:
        print('Specimen file is missing a numeric prefix:', rel)
        sys.exit(1)
    specimen_numbers.append(int(m.group(1)))
expected_specimen_numbers = list(range(1, len(specimen_numbers) + 1))
if specimen_numbers != expected_specimen_numbers:
    print('Specimen numbering drift detected.')
    print(' - actual numbering:', specimen_numbers)
    print(' - expected numbering:', expected_specimen_numbers)
    sys.exit(1)

if specimen_docs != specimen_listed:
    print('Specimen index drift detected.')
    only_actual = [p for p in specimen_docs if p not in specimen_listed]
    only_listed = [p for p in specimen_listed if p not in specimen_docs]
    if only_actual:
        print('Unlisted specimen flows:')
        for p in only_actual:
            print(' -', p)
    if only_listed:
        print('Missing specimen flows on disk:')
        for p in only_listed:
            print(' -', p)
    sys.exit(1)

if actual != listed:
    print('Archive index drift detected.')
    only_actual = [p for p in actual if p not in listed]
    only_listed = [p for p in listed if p not in actual]
    if only_actual:
        print('Unlisted files:')
        for p in only_actual:
            print(' -', p)
    if only_listed:
        print('Missing on disk:')
        for p in only_listed:
            print(' -', p)
    sys.exit(1)

bib = (ROOT / 'docs/00-meta/bibliography.md').read_text(errors='ignore').splitlines()
bib_ref_list = [line.split('**')[1] for line in bib if line.startswith('- **') and '**' in line]
dupe_bib_refs = sorted(k for k, v in Counter(bib_ref_list).items() if v > 1)
if dupe_bib_refs:
    print('Duplicate bibliography refs detected.')
    for r in dupe_bib_refs:
        print(' -', r)
    sys.exit(1)
bib_refs = set(bib_ref_list)
register = (ROOT / 'docs/00-meta/load-bearing-source-register.md').read_text(errors='ignore')
register_ref_list = [r for r in re.findall(r'`([^`]+)`', register) if r.startswith('EXT-')]
register_refs = set(register_ref_list)
dupe_register_refs = sorted(k for k, v in Counter(register_ref_list).items() if v > 1)
if dupe_register_refs:
    print('Duplicate load-bearing source register refs detected.')
    for r in dupe_register_refs:
        print(' -', r)
    sys.exit(1)
missing_refs = sorted(r for r in register_refs if r not in bib_refs)
if missing_refs:
    print('Load-bearing source register points at bibliography ghosts:')
    for r in missing_refs:
        print(' -', r)
    sys.exit(1)

receipt = json.loads((ROOT / 'REVISION-RECEIPT.json').read_text())

outside_sources = receipt.get('outside_sources', [])
if outside_sources != sorted(outside_sources):
    print('Revision receipt outside_sources are not sorted.')
    sys.exit(1)
if len(outside_sources) != len(set(outside_sources)):
    print('Revision receipt outside_sources contain duplicates.')
    sys.exit(1)
queue = (ROOT / 'docs/00-meta/source-review-queue.md').read_text(errors='ignore')
queue_ref_list = re.findall(r'`(EXT-[^`]+)`', queue)
queue_refs = set(queue_ref_list)
dupe_queue_refs = sorted(k for k, v in Counter(queue_ref_list).items() if v > 1)
if dupe_queue_refs:
    print('Duplicate source review queue refs detected.')
    for r in dupe_queue_refs:
        print(' -', r)
    sys.exit(1)
review_needed = set()
for line in register.splitlines():
    line = line.strip()
    if not line.startswith('| `EXT-'):
        continue
    parts = [part.strip() for part in line.strip('|').split('|')]
    if len(parts) < 4:
        continue
    ref = parts[0].strip('` ')
    stability = parts[2].lower()
    if any(word in stability for word in ['moving', 'recent', 'living', 'development']):
        review_needed.add(ref)
missing_queue_refs = sorted(r for r in review_needed if r not in queue_refs)
if missing_queue_refs:
    print('Source review queue is missing moving/recent/living load-bearing refs:')
    for r in missing_queue_refs:
        print(' -', r)
    sys.exit(1)
missing_queue_bib_refs = sorted(r for r in queue_refs if r.startswith('EXT-') and r not in bib_refs)
if missing_queue_bib_refs:
    print('Source review queue points at bibliography ghosts:')
    for r in missing_queue_bib_refs:
        print(' -', r)
    sys.exit(1)
missing_receipt_refs = sorted(r for r in outside_sources if r.startswith('EXT-') and r not in bib_refs)
if missing_receipt_refs:
    print('Revision receipt points at bibliography ghosts:')
    for r in missing_receipt_refs:
        print(' -', r)
    sys.exit(1)
register_not_receipted = sorted(r for r in register_refs if r not in outside_sources)
if register_not_receipted:
    print('Load-bearing source register refs missing from revision receipt outside_sources:')
    for r in register_not_receipted:
        print(' -', r)
    sys.exit(1)
queue_not_receipted = sorted(r for r in queue_refs if r.startswith('EXT-') and r not in outside_sources)
if queue_not_receipted:
    print('Source review queue refs missing from revision receipt outside_sources:')
    for r in queue_not_receipted:
        print(' -', r)
    sys.exit(1)

manifest = json.loads((ROOT / 'RELEASE-MANIFEST.json').read_text())
archive_name = manifest.get('archive')
expected_archive_name = ROOT.name + '.zip'
if archive_name != expected_archive_name:
    print('Archive identity drift detected between folder name and release manifest.')
    print(' - folder expects:', expected_archive_name)
    print(' - release manifest:', archive_name)
    sys.exit(1)
actual_file_count = len(actual)
missing_core_docs = [p for p in manifest.get('core_docs', []) if p not in actual]
if missing_core_docs:
    print('Release manifest core_docs drift detected.')
    for p in missing_core_docs:
        print(' - missing core doc:', p)
    sys.exit(1)
if manifest.get('file_count') != actual_file_count:
    print('Release manifest file_count drift detected.')
    print(' - release manifest file_count:', manifest.get('file_count'))
    print(' - actual file_count:', actual_file_count)
    sys.exit(1)
if manifest.get('highlights') != receipt.get('summary'):
    print('Release manifest highlights drift detected.')
    print(' - release manifest highlights:', manifest.get('highlights'))
    print(' - revision receipt summary:', receipt.get('summary'))
    sys.exit(1)
if manifest.get('revision') != receipt.get('revision'):
    print('Archive identity drift detected between release manifest and revision receipt revision.')
    print(' - release manifest revision:', manifest.get('revision'))
    print(' - revision receipt revision:', receipt.get('revision'))
    sys.exit(1)
if manifest.get('codename') != receipt.get('codename'):
    print('Archive identity drift detected between release manifest and revision receipt codename.')
    print(' - release manifest codename:', manifest.get('codename'))
    print(' - revision receipt codename:', receipt.get('codename'))
    sys.exit(1)
for token in [receipt.get('revision'), receipt.get('codename')]:
    if token and token not in ROOT.name:
        print('Archive folder name is missing identity token:', token)
        sys.exit(1)

question_registry = json.loads((ROOT / 'QUESTION-REGISTRY.json').read_text())
question_ids = [item.get('id') for item in question_registry.get('questions', []) if item.get('id')]
dupe_question_ids = sorted(k for k, v in Counter(question_ids).items() if v > 1)
if dupe_question_ids:
    print('Question registry has duplicate IDs:')
    for qid in dupe_question_ids:
        print(' -', qid)
    sys.exit(1)
question_nums = []
for qid in question_ids:
    m = re.fullmatch(r'Q(\d+)', qid)
    if not m:
        print('Question registry has a malformed ID:', qid)
        sys.exit(1)
    question_nums.append(int(m.group(1)))
expected_question_nums = list(range(1, len(question_nums) + 1))
if question_nums != expected_question_nums:
    print('Question registry ID drift detected.')
    print(' - actual ids:', question_ids)
    sys.exit(1)
followthrough_queue = json.loads((ROOT / 'FOLLOWTHROUGH-QUEUE.json').read_text())
follow_ids = [item.get('id') for item in followthrough_queue.get('items', []) if item.get('id')]
follow_nums = []
for fid in follow_ids:
    m = re.fullmatch(r'F(\d+)', fid)
    if not m:
        print('Followthrough queue has a malformed ID:', fid)
        sys.exit(1)
    follow_nums.append(int(m.group(1)))
expected_follow_nums = list(range(1, len(follow_nums) + 1))
if follow_nums != expected_follow_nums:
    print('Followthrough queue ID drift detected.')
    print(' - actual ids:', follow_ids)
    sys.exit(1)
pressure_registry = json.loads((ROOT / 'FOREIGN-PRESSURE-LEDGER.json').read_text())
pressure_ids = [item.get('id') for item in pressure_registry.get('pressures', []) if item.get('id')]
dupe_pressure_ids = sorted(k for k, v in Counter(pressure_ids).items() if v > 1)
if dupe_pressure_ids:
    print('Foreign pressure ledger has duplicate IDs:')
    for pid in dupe_pressure_ids:
        print(' -', pid)
    sys.exit(1)

surface_status = json.loads((ROOT / 'SURFACE-STATUS.json').read_text())
context_pack = json.loads((ROOT / 'context-pack.json').read_text())
roadmap = (ROOT / 'docs/00-meta/roadmap.md').read_text(errors='ignore')
m = re.search(r'^Current revision focus \(`([^`]+)`\):\s*(.+)$', roadmap, re.MULTILINE)
if not m:
    print('Roadmap is missing a parsable current revision focus line.')
    sys.exit(1)
roadmap_revision, roadmap_focus = m.group(1), m.group(2).strip()
if roadmap_revision != surface_status.get('revision') or roadmap_revision != context_pack.get('revision'):
    print('Current-focus revision drift detected across roadmap/context/surface status.')
    print(' - roadmap revision:', roadmap_revision)
    print(' - surface status revision:', surface_status.get('revision'))
    print(' - context pack revision:', context_pack.get('revision'))
    sys.exit(1)
if roadmap_focus != surface_status.get('latest_focus') or roadmap_focus != context_pack.get('latest_revision_focus'):
    print('Current-focus text drift detected across roadmap/context/surface status.')
    print(' - roadmap focus:', roadmap_focus)
    print(' - surface status focus:', surface_status.get('latest_focus'))
    print(' - context pack focus:', context_pack.get('latest_revision_focus'))
    sys.exit(1)
if receipt.get('summary') != roadmap_focus:
    print('Revision-summary drift detected between revision receipt and roadmap/context/surface focus.')
    print(' - revision receipt summary:', receipt.get('summary'))
    print(' - shared focus:', roadmap_focus)
    sys.exit(1)

question_texts = {item.get('text') for item in question_registry.get('questions', []) if item.get('text')}
missing_top_open_questions = [q for q in context_pack.get('top_open_questions', []) if q not in question_texts]
if missing_top_open_questions:
    print('Context pack top_open_questions drift detected; these questions are not present in QUESTION-REGISTRY.json:')
    for q in missing_top_open_questions:
        print(' -', q)
    sys.exit(1)

immediate_pressure_heading = re.search(r'^## (rev\d+) immediate next pressure$', roadmap, re.MULTILINE)
if immediate_pressure_heading and immediate_pressure_heading.group(1) != receipt.get('revision'):
    print('Immediate-next-pressure heading drift detected.')
    print(' - roadmap heading revision:', immediate_pressure_heading.group(1))
    print(' - expected revision:', receipt.get('revision'))
    sys.exit(1)

changelog = (ROOT / 'CHANGELOG.md').read_text(errors='ignore')
if f'## {receipt.get("revision")} —' not in changelog:
    print('Current revision is missing from CHANGELOG.md.')
    print(' - expected heading:', f'## {receipt.get("revision")} —')
    sys.exit(1)
first_revision_heading = re.search(r'^## (rev\d+) —', changelog, re.MULTILINE)
if not first_revision_heading or first_revision_heading.group(1) != receipt.get('revision'):
    print('Current revision is not the first changelog heading.')
    print(' - expected first heading for:', receipt.get('revision'))
    print(' - first heading found:', first_revision_heading.group(1) if first_revision_heading else None)
    sys.exit(1)
changelog_headings = re.findall(r'^## (rev\d+) —', changelog, re.MULTILINE)
dupe_changelog_headings = sorted(k for k, v in Counter(changelog_headings).items() if v > 1)
if dupe_changelog_headings:
    print('Duplicate changelog headings detected.')
    for rev in dupe_changelog_headings:
        print(' -', rev)
    sys.exit(1)
expected_supersedes = changelog_headings[1] if len(changelog_headings) > 1 else None
if receipt.get('supersedes') != expected_supersedes:
    print('Revision receipt supersedes drift detected.')
    print(' - receipt supersedes:', receipt.get('supersedes'))
    print(' - expected previous revision:', expected_supersedes)
    sys.exit(1)

readme = (ROOT / 'README.md').read_text(errors='ignore')
start_here = (ROOT / 'START_HERE.md').read_text(errors='ignore')
docs_map = (ROOT / 'docs/README.md').read_text(errors='ignore')
for rel in receipt.get('hygiene_additions', []):
    if rel.startswith('docs/00-meta/research-synthesis-') or rel.startswith('docs/00-meta/slopos-companions-evaluation-') or rel.startswith('docs/30-architecture/specimen-flow-'):
        needle = f'({rel})'
        if needle not in readme:
            print('README latest-pass pointer drift detected; missing link to', rel)
            sys.exit(1)
        if needle not in start_here:
            print('START_HERE latest-pass pointer drift detected; missing link to', rel)
            sys.exit(1)
        backtick_rel = f'`{rel}`'
        if backtick_rel not in docs_map:
            print('docs/README latest-pass pointer drift detected; missing entry for', rel)
            sys.exit(1)
        if rel not in manifest.get('core_docs', []):
            print('Release manifest core_docs is missing latest addition:', rel)
            sys.exit(1)

docs_readme = (ROOT / 'docs/README.md').read_text(errors='ignore')
for rel in receipt.get('hygiene_additions', []):
    if rel.startswith('docs/00-meta/research-synthesis-') or rel.startswith('docs/00-meta/slopos-companions-evaluation-') or rel.startswith('docs/30-architecture/specimen-flow-'):
        if rel not in docs_readme:
            print('Docs map latest-pass pointer drift detected; missing reference to', rel)
            sys.exit(1)

ledger_revision_paths = [
    'ASSUMPTION-LEDGER.json',
    'FOREIGN-PRESSURE-LEDGER.json',
    'IRREVERSIBLE-DECISION-LEDGER.json',
    'QUESTION-REGISTRY.json',
    'FOLLOWTHROUGH-QUEUE.json',
]
for rel in ledger_revision_paths:
    obj = json.loads((ROOT / rel).read_text())
    if obj.get('revision') != receipt.get('revision'):
        print('Ledger revision drift detected.')
        print(' - file:', rel)
        print(' - file revision:', obj.get('revision'))
        print(' - expected revision:', receipt.get('revision'))
        sys.exit(1)

start_here = (ROOT / 'START_HERE.md').read_text(errors='ignore')
if f'## What changed in {receipt.get("revision")}' not in start_here:
    print('Start-here revision drift detected; missing current "What changed" heading.')
    sys.exit(1)
if f'## New in {receipt.get("revision")}' not in start_here:
    print('Start-here revision drift detected; missing current "New in" heading.')
    sys.exit(1)
for rel in receipt.get('hygiene_additions', []):
    if rel.startswith('docs/00-meta/research-synthesis-') or rel.startswith('docs/00-meta/slopos-companions-evaluation-') or rel.startswith('docs/30-architecture/specimen-flow-'):
        leaf = rel.split('/')[-1]
        if leaf not in start_here and leaf.replace('.md', '') not in start_here:
            print('Start-here latest-pass pointer drift detected; missing reference to', rel)
            sys.exit(1)

latest_pass = None
for rel in receipt.get('hygiene_additions', []):
    m = re.search(r'pass-([a-z]+)\.md$', rel)
    if m:
        latest_pass = m.group(1).upper()
        break
if latest_pass:
    lessons = (ROOT / 'docs/00-meta/lessons-we-must-learn.md').read_text(errors='ignore')
    inspirations = (ROOT / 'docs/90-inspirations/steal-these-ideas.md').read_text(errors='ignore')
    heading = f'## Pass {latest_pass} additions'
    if heading not in lessons:
        print('Lessons ledger is missing latest pass heading:', heading)
        sys.exit(1)
    if heading not in inspirations:
        print('Inspiration harvest is missing latest pass heading:', heading)
        sys.exit(1)


if receipt.get("revision") not in readme:
    print('README revision marker drift detected; missing current revision token.')
    sys.exit(1)
if receipt.get("summary") not in readme:
    print('README focus drift detected; missing current summary text.')
    sys.exit(1)
if receipt.get("revision") not in docs_map:
    print('docs/README revision marker drift detected; missing current revision token.')
    sys.exit(1)
if len(receipt.get('hygiene_additions', [])) != 3:
    print('Revision receipt hygiene_additions should name exactly three latest-pass surfaces.')
    sys.exit(1)
if len(set(receipt.get('hygiene_additions', []))) != len(receipt.get('hygiene_additions', [])):
    print('Revision receipt hygiene_additions contain duplicates.')
    sys.exit(1)
latest_research = [p for p in receipt.get('hygiene_additions', []) if p.startswith('docs/00-meta/research-synthesis-')]
latest_eval = [p for p in receipt.get('hygiene_additions', []) if p.startswith('docs/00-meta/slopos-companions-evaluation-')]
latest_specimen = [p for p in receipt.get('hygiene_additions', []) if p.startswith('docs/30-architecture/specimen-flow-')]
if len(latest_research) != 1 or len(latest_eval) != 1 or len(latest_specimen) != 1:
    print('Revision receipt hygiene_additions must contain exactly one research doc, one companion eval doc, and one specimen flow.')
    print(' - research docs:', latest_research)
    print(' - eval docs:', latest_eval)
    print(' - specimen docs:', latest_specimen)
    sys.exit(1)
pass_research = re.search(r'pass-([a-z]+)\.md$', latest_research[0])
pass_eval = re.search(r'pass-([a-z]+)\.md$', latest_eval[0])
if not pass_research or not pass_eval or pass_research.group(1) != pass_eval.group(1):
    print('Latest-pass research/eval token drift detected.')
    print(' - research:', latest_research[0])
    print(' - eval:', latest_eval[0])
    sys.exit(1)

if receipt.get("revision") not in changelog.splitlines()[0]:
    print('Changelog head drift detected; current revision is not first line.')
    sys.exit(1)

print('Repo hygiene check passed for', ROOT.name)
