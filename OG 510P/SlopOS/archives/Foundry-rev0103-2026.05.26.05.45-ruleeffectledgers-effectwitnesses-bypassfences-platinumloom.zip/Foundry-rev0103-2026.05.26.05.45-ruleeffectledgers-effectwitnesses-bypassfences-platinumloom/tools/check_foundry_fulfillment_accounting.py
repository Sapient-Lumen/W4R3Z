#!/usr/bin/env python3
"""Check Foundry fulfillment-accounting fixtures.

Specimen 89 proves that Foundry can distinguish obligation acknowledgment from
semantic-duty fulfillment without becoming a workflow engine, cleanup controller,
authorization system, legal-compliance system, audit product, custody model,
repair workflow, lifecycle authority, or sibling-cube verdict.
"""
from pathlib import Path
from datetime import datetime
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_FAILURE_CODES = {
    "fulfillment_receipt_required",
    "source_obligation_required",
    "completion_witness_required",
    "required_completion_missing_refused",
    "acknowledgment_as_fulfillment_refused",
    "deadline_expired_refused",
    "sidecar_not_carried_refused",
    "classification_pin_not_verified_refused",
    "observation_status_hidden_refused",
    "recall_route_untested_refused",
    "no_reexport_unenforced_refused",
    "recheck_missing_before_reuse_refused",
    "quarantine_not_applied_refused",
    "sibling_boundary_unfulfilled_refused",
    "completion_scope_mismatch_refused",
    "wrong_consumer_completion_refused",
    "partial_completion_as_complete_refused",
    "completion_digest_mismatch_refused",
    "public_link_fulfillment_unfenced_refused",
    "inherited_fulfillment_unbound_refused",
    "fulfillment_as_authorization_refused",
    "fulfillment_as_legal_compliance_refused",
    "fulfillment_as_audit_opinion_refused",
    "fulfillment_sibling_verdict_laundering_refused",
}

RECEIPT_STATUSES = {"complete", "partial", "blocked", "pending", "superseded", "retired"}
FULFILLMENT_TYPES = {"sidecar_preserved", "classification_pins_verified", "observation_status_displayed", "recall_route_probed", "no_reexport_enforced", "recheck_before_reuse", "quarantine_applied", "sibling_boundary_preserved"}
FULFILLMENT_STATUSES = {"fulfilled", "partial", "pending", "missed", "refused", "blocked", "retired"}
COMPLETION_STATES = {"completed", "partial", "pending", "missed", "refused", "quarantined", "superseded"}
FENCE_TYPES = {"completion_missing", "deadline_expired", "sidecar_not_carried", "classification_pin_not_verified", "observation_status_hidden", "recall_route_untested", "no_reexport_unenforced", "recheck_missing_before_reuse", "quarantine_not_applied", "sibling_boundary_unfulfilled", "completion_scope_mismatch", "wrong_consumer_completion", "partial_as_complete", "digest_mismatch", "public_link_unfulfilled", "inherited_fulfillment_unbound", "authority_laundering"}
FENCE_RESULTS = {"blocked", "quarantined", "recheck_required", "monitor_only", "retired_as_history"}
RISKY_COMPLETION_STATES = {"partial", "pending", "missed", "refused", "quarantined"}
AUTHORITY_WORDS = {"authorization", "legal", "consent", "audit", "public", "release", "deletion", "retention", "custody", "repair", "finality", "verdict", "proof", "policy"}


def parse_time(value):
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def check_fixture(path):
    data = json.loads(path.read_text())
    rel = path.relative_to(ROOT)
    errors = []
    if data.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: wrong fixture_family")
    if data.get("specimen_id") != "89":
        errors.append(f"{rel}: specimen_id must be 89")

    consumers = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    source_refs = data.get("source_obligation_refs") or []
    source_ledgers = {s.get("ledger_id") for s in source_refs if s.get("ledger_id")}
    source_acks = {aid for s in source_refs for aid in (s.get("acknowledgment_witness_ids") or [])}
    source_fences = {fid for s in source_refs for fid in (s.get("obligation_drift_fence_ids") or [])}
    source_obligations = {oid for s in source_refs for oid in (s.get("obligation_ids") or [])}
    carrier_refs = {c.get("carrier_id"): c for c in data.get("carrier_refs", []) if c.get("carrier_id")}

    receipts = data.get("fulfillment_receipts") or []
    completions = data.get("completion_witnesses") or []
    fences = data.get("nonfulfillment_fences") or []
    if not source_refs:
        errors.append(f"{rel}: source_obligation_refs required")
    if not receipts:
        errors.append(f"{rel}: fulfillment_receipts required")
    if not completions:
        errors.append(f"{rel}: completion_witnesses required")
    if not fences:
        errors.append(f"{rel}: nonfulfillment_fences required")

    receipt_by_id = {}
    windows = {}
    obligation_by_receipt = {}
    required_witnesses = {}
    required_fences = {}
    complete_count = partial_count = blocked_count = 0

    for receipt in receipts:
        rid = receipt.get("receipt_id", "<missing>")
        if rid in receipt_by_id:
            errors.append(f"{rel}: duplicate receipt_id {rid}")
        receipt_by_id[rid] = receipt
        if receipt.get("receipt_family") != "foundry_fulfillment_receipt_v0":
            errors.append(f"{rel}: receipt {rid} has wrong receipt_family")
        if not str(receipt.get("receipt_digest", "")).startswith("sha256:"):
            errors.append(f"{rel}: receipt {rid} missing sha256 receipt_digest")
        status = receipt.get("receipt_status")
        if status not in RECEIPT_STATUSES:
            errors.append(f"{rel}: receipt {rid} has unknown status {status!r}")
        if status == "complete": complete_count += 1
        if status == "partial": partial_count += 1
        if status == "blocked": blocked_count += 1
        issued = parse_time(receipt.get("issued_at"))
        closed = parse_time(receipt.get("closed_at"))
        if not issued or not closed or not issued <= closed:
            errors.append(f"{rel}: receipt {rid} has invalid issue/closed window")
        else:
            windows[rid] = (issued, closed)
        for key in ["source_obligation_ledger_ids", "source_acknowledgment_witness_ids", "carrier_ids", "fulfillment_scope", "obligations_to_fulfill", "required_completion_witnesses", "authority_boundaries"]:
            if not receipt.get(key):
                errors.append(f"{rel}: receipt {rid} missing {key}")
        if status in {"partial", "blocked"} and not receipt.get("required_nonfulfillment_fences"):
            errors.append(f"{rel}: partial/blocked receipt {rid} must require nonfulfillment fences")
        for lid in receipt.get("source_obligation_ledger_ids") or []:
            if lid not in source_ledgers:
                errors.append(f"{rel}: receipt {rid} references unknown source obligation ledger {lid}")
        for aid in receipt.get("source_acknowledgment_witness_ids") or []:
            if aid not in source_acks:
                errors.append(f"{rel}: receipt {rid} references unknown acknowledgment witness {aid}")
        for fid in receipt.get("source_obligation_drift_fence_ids") or []:
            if fid not in source_fences:
                errors.append(f"{rel}: receipt {rid} references unknown source obligation-drift fence {fid}")
        for cid in receipt.get("carrier_ids") or []:
            if cid not in carrier_refs:
                errors.append(f"{rel}: receipt {rid} references unknown carrier {cid}")
        scope = receipt.get("fulfillment_scope") or {}
        unknown_consumers = set(scope.get("consumers") or []) - consumers
        if unknown_consumers:
            errors.append(f"{rel}: receipt {rid} scopes unknown consumers: {', '.join(sorted(unknown_consumers))}")
        fulfillments = {}
        for item in receipt.get("obligations_to_fulfill") or []:
            fid = item.get("fulfillment_id")
            if not fid:
                errors.append(f"{rel}: receipt {rid} has fulfillment without id")
                continue
            if fid in fulfillments:
                errors.append(f"{rel}: receipt {rid} duplicates fulfillment {fid}")
            fulfillments[fid] = item
            if item.get("source_obligation_id") not in source_obligations:
                errors.append(f"{rel}: fulfillment {fid} references unknown source obligation")
            if item.get("fulfillment_type") not in FULFILLMENT_TYPES:
                errors.append(f"{rel}: fulfillment {fid} has unknown type {item.get('fulfillment_type')!r}")
            if item.get("fulfillment_status") not in FULFILLMENT_STATUSES:
                errors.append(f"{rel}: fulfillment {fid} has unknown status {item.get('fulfillment_status')!r}")
            due = parse_time(item.get("due_at"))
            if not due:
                errors.append(f"{rel}: fulfillment {fid} missing/unparsable due_at")
            elif rid in windows:
                issued, closed = windows[rid]
                if not issued <= due <= closed:
                    errors.append(f"{rel}: fulfillment {fid} due_at outside receipt window")
            for key in ["required_evidence", "applies_to", "blocked_inferences"]:
                if not item.get(key):
                    errors.append(f"{rel}: fulfillment {fid} missing {key}")
            applies = item.get("applies_to") or {}
            if not set(applies.get("surfaces") or []) <= set(scope.get("surfaces") or []):
                errors.append(f"{rel}: fulfillment {fid} applies to surface outside receipt scope")
            if not set(applies.get("audiences") or []) <= set(scope.get("audiences") or []):
                errors.append(f"{rel}: fulfillment {fid} applies to audience outside receipt scope")
            if not set(applies.get("purposes") or []) <= set(scope.get("purpose_classes") or []):
                errors.append(f"{rel}: fulfillment {fid} applies to purpose outside receipt scope")
        obligation_by_receipt[rid] = fulfillments
        required_witnesses[rid] = set(receipt.get("required_completion_witnesses") or [])
        required_fences[rid] = set(receipt.get("required_nonfulfillment_fences") or [])
        boundary_text = " ".join(receipt.get("authority_boundaries") or []).lower()
        if not any(token in boundary_text for token in ["does_not", "not_"]):
            errors.append(f"{rel}: receipt {rid} must state negative authority boundaries")
        if not any(word in boundary_text for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: receipt {rid} authority boundaries should name refused authority")

    completion_by_id = {}
    completions_by_receipt = {}
    completed_count = partial_witness_count = pending_count = missed_count = refused_count = quarantined_count = 0
    for witness in completions:
        wid = witness.get("witness_id", "<missing>")
        if wid in completion_by_id:
            errors.append(f"{rel}: duplicate completion witness_id {wid}")
        completion_by_id[wid] = witness
        rid = witness.get("receipt_id")
        fid = witness.get("fulfillment_id")
        if witness.get("witness_family") != "foundry_completion_witness_v0":
            errors.append(f"{rel}: completion witness {wid} has wrong witness_family")
        if rid not in receipt_by_id:
            errors.append(f"{rel}: completion witness {wid} references missing receipt {rid}")
            receipt = {}
            fulfillments = {}
        else:
            receipt = receipt_by_id[rid]
            fulfillments = obligation_by_receipt[rid]
            completions_by_receipt.setdefault(rid, set()).add(wid)
        if fid not in fulfillments:
            errors.append(f"{rel}: completion witness {wid} references fulfillment outside receipt: {fid}")
            fulfillment = {}
        else:
            fulfillment = fulfillments[fid]
        state = witness.get("completion_state")
        if state not in COMPLETION_STATES:
            errors.append(f"{rel}: completion witness {wid} has unknown completion_state {state!r}")
        if state == "completed": completed_count += 1
        if state == "partial": partial_witness_count += 1
        if state == "pending": pending_count += 1
        if state == "missed": missed_count += 1
        if state == "refused": refused_count += 1
        if state == "quarantined": quarantined_count += 1
        cid = witness.get("consumer_id")
        if cid not in consumers:
            errors.append(f"{rel}: completion witness {wid} names unknown consumer {cid}")
        scope = receipt.get("fulfillment_scope") or {}
        if receipt and cid not in set(scope.get("consumers") or []):
            errors.append(f"{rel}: completion witness {wid} consumer outside receipt scope")
        if receipt and witness.get("surface_id") not in set(scope.get("surfaces") or []):
            errors.append(f"{rel}: completion witness {wid} surface outside receipt scope")
        if receipt and witness.get("audience_id") not in set(scope.get("audiences") or []):
            errors.append(f"{rel}: completion witness {wid} audience outside receipt scope")
        observed = parse_time(witness.get("observed_at"))
        due = parse_time(fulfillment.get("due_at"))
        if not observed:
            errors.append(f"{rel}: completion witness {wid} missing/unparsable observed_at")
        else:
            if rid in windows:
                issued, closed = windows[rid]
                if not (issued <= observed <= closed):
                    errors.append(f"{rel}: completion witness {wid} observed outside receipt window")
            if due and observed > due and state == "completed" and not witness.get("nonfulfillment_fence_refs"):
                errors.append(f"{rel}: late completion witness {wid} must reference a nonfulfillment fence")
        if witness.get("source_acknowledgment_witness_id") not in source_acks:
            errors.append(f"{rel}: completion witness {wid} references unknown source acknowledgment witness")
        for key in ["evidence", "residue_verified", "blocked_uses", "non_promises"]:
            if not witness.get(key):
                errors.append(f"{rel}: completion witness {wid} missing {key}")
        carrier_id = witness.get("carrier_id")
        if carrier_id:
            if carrier_id not in carrier_refs:
                errors.append(f"{rel}: completion witness {wid} references unknown carrier {carrier_id}")
            elif witness.get("carrier_digest") != carrier_refs[carrier_id].get("carrier_digest"):
                errors.append(f"{rel}: completion witness {wid} carrier digest mismatch")
        if state in RISKY_COMPLETION_STATES and not witness.get("nonfulfillment_fence_refs"):
            errors.append(f"{rel}: risky completion witness {wid} must reference a nonfulfillment fence")
        np = " ".join(witness.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: completion witness {wid} must include authority/refusal non_promises")

    fence_by_id = {}
    for fence in fences:
        fid = fence.get("fence_id", "<missing>")
        if fid in fence_by_id:
            errors.append(f"{rel}: duplicate nonfulfillment fence_id {fid}")
        fence_by_id[fid] = fence
        rid = fence.get("receipt_id")
        ful_id = fence.get("fulfillment_id")
        if fence.get("fence_family") != "foundry_nonfulfillment_fence_v0":
            errors.append(f"{rel}: nonfulfillment fence {fid} has wrong fence_family")
        if rid not in receipt_by_id:
            errors.append(f"{rel}: nonfulfillment fence {fid} references missing receipt {rid}")
            receipt = {}
            fulfillments = {}
        else:
            receipt = receipt_by_id[rid]
            fulfillments = obligation_by_receipt[rid]
        if ful_id not in fulfillments:
            errors.append(f"{rel}: nonfulfillment fence {fid} references fulfillment outside receipt: {ful_id}")
        if fence.get("fence_type") not in FENCE_TYPES:
            errors.append(f"{rel}: nonfulfillment fence {fid} has unknown fence_type {fence.get('fence_type')!r}")
        if fence.get("fence_result") not in FENCE_RESULTS:
            errors.append(f"{rel}: nonfulfillment fence {fid} has unknown fence_result {fence.get('fence_result')!r}")
        scope = receipt.get("fulfillment_scope") or {}
        if receipt and fence.get("affected_consumer_id") not in set(scope.get("consumers") or []):
            errors.append(f"{rel}: nonfulfillment fence {fid} consumer outside receipt scope")
        if receipt and fence.get("affected_surface_id") not in set(scope.get("surfaces") or []):
            errors.append(f"{rel}: nonfulfillment fence {fid} surface outside receipt scope")
        if receipt and fence.get("affected_audience_id") not in set(scope.get("audiences") or []):
            errors.append(f"{rel}: nonfulfillment fence {fid} audience outside receipt scope")
        detected = parse_time(fence.get("detected_at"))
        if not detected:
            errors.append(f"{rel}: nonfulfillment fence {fid} missing/unparsable detected_at")
        elif rid in windows:
            issued, closed = windows[rid]
            if not issued <= detected <= closed:
                errors.append(f"{rel}: nonfulfillment fence {fid} detected outside receipt window")
        for key in ["missing_evidence", "required_clearance", "blocked_uses", "non_promises"]:
            if not fence.get(key):
                errors.append(f"{rel}: nonfulfillment fence {fid} missing {key}")
        if fence.get("fence_result") in {"blocked", "quarantined", "recheck_required"} and not fence.get("recheck_after"):
            errors.append(f"{rel}: active nonfulfillment fence {fid} must name recheck_after")
        np = " ".join(fence.get("non_promises") or []).lower()
        if not any(word in np for word in AUTHORITY_WORDS):
            errors.append(f"{rel}: nonfulfillment fence {fid} must include authority/refusal non_promises")

    for rid, expected in required_witnesses.items():
        actual = completions_by_receipt.get(rid, set())
        missing = expected - actual
        if missing:
            errors.append(f"{rel}: receipt {rid} is missing required completion witnesses: {', '.join(sorted(missing))}")
        receipt = receipt_by_id[rid]
        if receipt.get("receipt_status") == "complete":
            for wid in expected:
                witness = completion_by_id.get(wid)
                if witness and witness.get("completion_state") != "completed":
                    errors.append(f"{rel}: complete receipt {rid} has non-completed witness {wid}")
    for rid, expected in required_fences.items():
        actual = {fid for fid, fence in fence_by_id.items() if fence.get("receipt_id") == rid}
        missing = expected - actual
        if missing:
            errors.append(f"{rel}: receipt {rid} is missing required nonfulfillment fences: {', '.join(sorted(missing))}")
    for witness in completions:
        for fid in witness.get("nonfulfillment_fence_refs") or []:
            if fid not in fence_by_id:
                errors.append(f"{rel}: completion witness {witness.get('witness_id')} references unknown fence {fid}")

    seen_codes = {case.get("failure_code") for case in data.get("negative_cases", []) if case.get("failure_code")}
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")
    missing_codes = REQUIRED_FAILURE_CODES - seen_codes
    if missing_codes:
        errors.append(f"{rel}: missing required negative failure codes: {', '.join(sorted(missing_codes))}")

    if complete_count < 1 or partial_count < 1 or blocked_count < 1:
        errors.append(f"{rel}: need at least one complete, partial, and blocked fulfillment receipt")
    if completed_count < 1 or partial_witness_count < 1 or pending_count < 1 or missed_count < 1 or refused_count < 1:
        errors.append(f"{rel}: need completed, partial, pending, missed, and refused completion witnesses")
    if len(fences) < 5:
        errors.append(f"{rel}: need at least five nonfulfillment fences")

    return errors, {
        "receipts": len(receipts),
        "completions": len(completions),
        "fences": len(fences),
    }

fixture_dir = FIXTURES / "specimen-89-fulfillment-accounting"
files = sorted(fixture_dir.glob("*.json"))
errors = []
counts = {"files": 0, "receipts": 0, "completions": 0, "fences": 0}
if not files:
    errors.append("Missing specimen-89 fulfillment-accounting fixture JSON")
for path in files:
    errs, c = check_fixture(path)
    errors.extend(errs)
    counts["files"] += 1
    counts["receipts"] += c["receipts"]
    counts["completions"] += c["completions"]
    counts["fences"] += c["fences"]

if errors:
    print("Foundry fulfillment accounting check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry fulfillment accounting check passed for {counts['files']} fixture file(s), {counts['receipts']} fulfillment receipt(s), {counts['completions']} completion witness(es), and {counts['fences']} nonfulfillment fence(s)")
