#!/usr/bin/env python3
"""Check Foundry semantic waiver fixtures.

Specimen 80 is about bounded exception honesty. It deliberately checks a small
waiver/expiry/replay seam rather than becoming a policy engine, approval
workflow, risk register, or sibling-cube verdict system.
"""
from pathlib import Path
import json
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_FAILURE_CODES = {
    "semantic_waiver_warrant_required",
    "waiver_expiry_required",
    "waiver_owner_required",
    "waiver_scope_required",
    "waiver_replay_gate_required",
    "waiver_cannot_override_nonwaivable_residue",
    "expired_waiver_blocks_egress",
    "waiver_scope_widened_unreviewed",
    "waiver_not_default_success",
    "waiver_requires_linked_refusal_or_lock",
    "self_approved_waiver_refused",
    "renewal_requires_new_witness",
}

REQUIRED_RULES = {
    "R-WAIVER-001-WARRANT-REQUIRED",
    "R-WAIVER-002-EXPIRY",
    "R-WAIVER-003-SCOPE",
    "R-WAIVER-004-NON-WAIVABLE",
    "R-WAIVER-005-OWNER-REVIEW",
    "R-WAIVER-006-REPLAY-GATE",
    "R-WAIVER-007-NO-DEFAULT-SUCCESS",
    "R-WAIVER-008-LINKED-ALARM",
    "R-WAIVER-009-SCOPE-WIDENING",
}

REQUIRED_SCOPE_FIELDS = {"revision", "consumer_id", "surface_kind", "cut_ids", "rule_ids", "residue_families"}
REQUIRED_REPLAY_EVENTS = {"before_use", "before_renewal", "after_revision_change"}
FORBIDDEN_ALLOWED_LOSSES = {
    "classification_pins",
    "classification_pin_loss",
    "crosswalk_witnesses",
    "source_cut",
    "source_cut_loss",
    "suppression_witnesses",
    "suppression_status_loss",
    "control_total_cards",
    "balance_residue_loss",
    "query_contract_digest",
    "result_envelope_digest",
}


def parse_time(value: str):
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None

errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("waiver_warrants"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No waiver_warrants fixture found for specimen 80.")

active_count = 0
expired_or_rejected_count = 0
for path, data in fixtures:
    rel = path.relative_to(ROOT)
    fixture_now = parse_time(data.get("fixture_now", ""))
    if fixture_now is None:
        errors.append(f"{rel}: fixture_now must be ISO-like")
        fixture_now = datetime.now(timezone.utc)

    warrants = data.get("waiver_warrants") or []
    warrant_ids = {w.get("warrant_id") for w in warrants if w.get("warrant_id")}
    if not warrants:
        errors.append(f"{rel}: waiver_warrants must be non-empty")

    witnesses = data.get("expiry_witnesses") or []
    witness_by_warrant = {w.get("warrant_id"): w for w in witnesses if w.get("warrant_id")}
    gates = data.get("exception_replay_gates") or []
    gates_by_warrant = {g.get("warrant_id"): g for g in gates if g.get("warrant_id")}

    for warrant in warrants:
        wid = warrant.get("warrant_id", "<missing>")
        if warrant.get("warrant_family") != "foundry_semantic_waiver_warrant_v0":
            errors.append(f"{rel}: warrant {wid} has wrong warrant_family")
        if warrant.get("status") not in {"active", "expired", "rejected", "superseded"}:
            errors.append(f"{rel}: warrant {wid} has unknown status")
        issued = parse_time(warrant.get("issued_at", ""))
        expires = parse_time(warrant.get("expires_at", ""))
        if issued is None or expires is None:
            errors.append(f"{rel}: warrant {wid} must have parseable issued_at and expires_at")
        elif expires < issued:
            errors.append(f"{rel}: warrant {wid} expires before it is issued")
        owner = warrant.get("owner")
        reviewer = warrant.get("reviewer")
        if not owner or not reviewer:
            errors.append(f"{rel}: warrant {wid} must name owner and reviewer")
        elif owner == reviewer:
            errors.append(f"{rel}: warrant {wid} owner and reviewer must differ")
        if not (warrant.get("linked_refusal_receipts") or warrant.get("linked_regression_locks")):
            errors.append(f"{rel}: warrant {wid} must link to a refusal receipt or regression lock")

        scope = warrant.get("scope") or {}
        missing_scope = REQUIRED_SCOPE_FIELDS - set(scope)
        if missing_scope:
            errors.append(f"{rel}: warrant {wid} scope missing: {', '.join(sorted(missing_scope))}")
        for list_key in ["cut_ids", "rule_ids", "residue_families"]:
            if not isinstance(scope.get(list_key), list) or not scope.get(list_key):
                errors.append(f"{rel}: warrant {wid} scope.{list_key} must be a non-empty list")
        if scope.get("revision") != "rev0086" and warrant.get("status") == "active":
            errors.append(f"{rel}: active warrant {wid} must be scoped to rev0086")

        allowed = set(warrant.get("allowed_semantic_loss") or [])
        nonwaivable = set(warrant.get("non_waivable_residue") or [])
        if not allowed and warrant.get("status") == "active":
            errors.append(f"{rel}: active warrant {wid} should name allowed_semantic_loss")
        if not nonwaivable:
            errors.append(f"{rel}: warrant {wid} must name non_waivable_residue")
        if allowed & nonwaivable:
            errors.append(f"{rel}: warrant {wid} allows a non-waivable residue: {', '.join(sorted(allowed & nonwaivable))}")
        if allowed & FORBIDDEN_ALLOWED_LOSSES:
            errors.append(f"{rel}: warrant {wid} allowed_semantic_loss contains forbidden residue: {', '.join(sorted(allowed & FORBIDDEN_ALLOWED_LOSSES))}")

        renewal = warrant.get("renewal_policy") or {}
        if renewal.get("requires_new_review") is not True:
            errors.append(f"{rel}: warrant {wid} renewal_policy.requires_new_review must be true")
        if int(renewal.get("max_duration_days", 9999)) > 30:
            errors.append(f"{rel}: warrant {wid} max_duration_days must be bounded to <= 30")
        if not renewal.get("requires_replay_gate"):
            errors.append(f"{rel}: warrant {wid} renewal_policy must name requires_replay_gate")

        witness = witness_by_warrant.get(wid)
        if not witness:
            errors.append(f"{rel}: warrant {wid} missing expiry witness")
        else:
            state = witness.get("expiry_state")
            if warrant.get("status") == "active":
                active_count += 1
                if state != "valid":
                    errors.append(f"{rel}: active warrant {wid} must have valid expiry witness")
                if expires is not None and expires <= fixture_now:
                    errors.append(f"{rel}: active warrant {wid} is expired at fixture_now")
            elif warrant.get("status") in {"expired", "rejected"}:
                expired_or_rejected_count += 1
                if state not in {"expired", "rejected"}:
                    errors.append(f"{rel}: inactive warrant {wid} must have expired/rejected witness")
            if witness.get("renewal_requires_new_review") is not True:
                errors.append(f"{rel}: warrant {wid} expiry witness must require new review")

        gate = gates_by_warrant.get(wid)
        if not gate:
            errors.append(f"{rel}: warrant {wid} missing exception replay gate")
        else:
            if gate.get("gate_family") != "foundry_exception_replay_gate_v0":
                errors.append(f"{rel}: gate for warrant {wid} has wrong gate_family")
            events = set(gate.get("required_on") or [])
            if warrant.get("status") == "active" and not REQUIRED_REPLAY_EVENTS.issubset(events):
                errors.append(f"{rel}: active warrant {wid} replay gate must cover before_use, before_renewal, and after_revision_change")
            rules = set(gate.get("must_recheck_rules") or [])
            if not rules:
                errors.append(f"{rel}: replay gate for warrant {wid} must name must_recheck_rules")
            if not any(rule.startswith("R-WAIVER-") for rule in rules):
                errors.append(f"{rel}: replay gate for warrant {wid} must include at least one waiver rule")

    # no orphan witnesses or gates
    for w in witnesses:
        if w.get("warrant_id") not in warrant_ids:
            errors.append(f"{rel}: expiry witness {w.get('witness_id')} points at unknown warrant")
    for g in gates:
        if g.get("warrant_id") not in warrant_ids:
            errors.append(f"{rel}: replay gate {g.get('gate_id')} points at unknown warrant")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if active_count < 1:
    errors.append("Specimen 80 needs at least one active waiver warrant.")
if expired_or_rejected_count < 1:
    errors.append("Specimen 80 needs at least one expired or rejected waiver warrant.")

rulebook = ROOT / "docs/30-architecture/semantic-waiver-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing semantic waiver rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = [rule for rule in sorted(REQUIRED_RULES) if rule not in text]
    if missing_rules:
        errors.append("Semantic waiver rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry semantic exception check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry semantic exception check passed for {len(fixtures)} fixture file(s), {active_count} active waiver(s), and {expired_or_rejected_count} inactive waiver(s)")
