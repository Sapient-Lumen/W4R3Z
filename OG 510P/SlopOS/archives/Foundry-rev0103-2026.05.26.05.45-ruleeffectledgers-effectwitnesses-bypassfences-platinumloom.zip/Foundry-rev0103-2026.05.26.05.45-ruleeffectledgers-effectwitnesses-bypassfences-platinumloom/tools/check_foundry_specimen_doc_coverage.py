#!/usr/bin/env python3
"""Check Foundry specimen documentation coverage manifest.

This is a small refactor guard: late specimens must remain tied to their
rulebooks, fixtures, schemas, checkers, docs map, and aggregate runner entries.
It is not a documentation product and not a correctness proof.
"""
from pathlib import Path
import json
import re
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover - direct execution fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "specimen-doc-coverage" / "coverage.json"
if not manifest_path.exists():
    print("Missing specimen doc coverage manifest")
    sys.exit(1)

coverage = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text())
if coverage.get("coverage_family") != "foundry_specimen_doc_coverage_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if coverage.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")
if not require_sha256(coverage.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")

entries = coverage.get("specimen_surfaces") or []
if not entries:
    errors.append(f"{rel_manifest}: missing specimen_surfaces")

specimen_index = (ROOT / "docs/30-architecture/specimen-flow-index.md").read_text(errors="ignore")
docs_map = (ROOT / "docs/README.md").read_text(errors="ignore")
runner = (ROOT / "tools/check_foundry_all.py").read_text(errors="ignore")
registered = set(re.findall(r'"(check_foundry_[^"]+\.py)"', runner))

seen_ids = []
for entry in entries:
    sid = str(entry.get("specimen_id"))
    seen_ids.append(sid)
    for key in ["specimen_doc", "rulebook", "fixture", "checker"]:
        path = entry.get(key)
        if not path or not (ROOT / path).exists():
            errors.append(f"{rel_manifest}: specimen {sid} missing {key} {path!r}")
    for path in entry.get("schemas") or []:
        if not (ROOT / path).exists():
            errors.append(f"{rel_manifest}: specimen {sid} missing schema {path}")
    specimen_doc = entry.get("specimen_doc") or ""
    if specimen_doc and f"`{specimen_doc}`" not in specimen_index:
        errors.append(f"{rel_manifest}: specimen {sid} doc is missing from specimen-flow-index")
    if entry.get("docs_map_required") is True and specimen_doc and specimen_doc not in docs_map:
        errors.append(f"{rel_manifest}: specimen {sid} doc is missing from docs/README.md")
    checker = Path(entry.get("checker") or "").name
    if checker and checker not in registered:
        errors.append(f"{rel_manifest}: specimen {sid} checker {checker} missing from aggregate runner")
    # Fixture's specimen_id must match when it is a normal semantic fixture.
    fixture_path = ROOT / (entry.get("fixture") or "")
    if fixture_path.exists():
        data = json.loads(fixture_path.read_text())
        if data.get("fixture_family") == "foundry_semantic_fixture_bundle_v0" and str(data.get("specimen_id")) != sid:
            errors.append(f"{entry.get('fixture')}: specimen_id mismatch; expected {sid}")
    # Current/new rulebooks must name containment/non-goal language to resist scope capture.
    rulebook_path = ROOT / (entry.get("rulebook") or "")
    if entry.get("containment_required") is True and rulebook_path.exists():
        rb = rulebook_path.read_text(errors="ignore").lower()
        if "containment" not in rb and "non-goal" not in rb:
            errors.append(f"{entry.get('rulebook')}: rulebook should contain containment/non-goal language")
    for phrase in ["rulebook", "fixture", "schema", "checker"]:
        if phrase not in " ".join(entry.get("coverage_assertions") or []).lower():
            errors.append(f"{rel_manifest}: specimen {sid} coverage_assertions should mention {phrase}")

if len(seen_ids) != len(set(seen_ids)):
    errors.append(f"{rel_manifest}: duplicate specimen ids in specimen_surfaces")
# The late executable sequence starts at 78 because 77 introduced sidecars and 78+ add rulebook/checker families.
expected_ids = [str(i) for i in range(78, 98)]
if sorted(seen_ids, key=int) != expected_ids:
    errors.append(f"{rel_manifest}: expected specimen ids {expected_ids}, saw {sorted(seen_ids, key=int)}")

rules = " ".join(coverage.get("coverage_rules") or []).lower()
for word in ["specimen", "rulebook", "fixture", "schema", "checker", "runner", "docs"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(coverage.get("non_goals") or []).lower()
for word in ["governance", "ontology", "correctness", "audit", "certification"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(
    f"Foundry specimen doc coverage check passed for {len(entries)} specimen coverage record(s)"
)
