#!/usr/bin/env python3
"""Check Foundry schema/fixture/checker coverage manifest.

This is a small refactor guard: it verifies that machine-readable fixture and
schema surfaces are listed and that specimen checkers are registered in the
aggregate runner. It is not JSON Schema validation and not ontology proof.
"""
from pathlib import Path
import json
import re
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover - direct execution fallback
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "schema-fixture-coverage" / "coverage.json"
if not manifest_path.exists():
    print("Missing schema/fixture coverage manifest")
    sys.exit(1)

coverage = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
if coverage.get("coverage_family") != "foundry_schema_fixture_coverage_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if not require_sha256(coverage.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text())
if coverage.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")

actual_fixtures = sorted(str(p.relative_to(ROOT)) for p in FIXTURES.rglob("*.json"))
actual_schemas = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "schemas").glob("*.schema.json"))
actual_checkers = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "tools").glob("check_foundry_*.py") if p.name != "check_foundry_all.py")

listed_fixtures = sorted(item.get("path") for item in coverage.get("fixture_surfaces") or [])
listed_schemas = sorted(item.get("path") for item in coverage.get("schema_surfaces") or [])
listed_checkers = sorted(item.get("path") for item in coverage.get("checker_surfaces") or [])

for name, actual, listed in [
    ("fixture", actual_fixtures, listed_fixtures),
    ("schema", actual_schemas, listed_schemas),
    ("checker", actual_checkers, listed_checkers),
]:
    if actual != listed:
        only_actual = [p for p in actual if p not in listed]
        only_listed = [p for p in listed if p not in actual]
        if only_actual:
            errors.append(f"{rel_manifest}: unlisted {name} surfaces: {', '.join(only_actual)}")
        if only_listed:
            errors.append(f"{rel_manifest}: missing listed {name} surfaces: {', '.join(only_listed)}")

# Every listed path exists and named families match the schema/fixture payloads.
for item in coverage.get("schema_surfaces") or []:
    path = ROOT / item.get("path", "")
    if not path.exists():
        continue
    schema = json.loads(path.read_text())
    consts = sorted(
        value.get("const") for value in (schema.get("properties") or {}).values()
        if isinstance(value, dict) and isinstance(value.get("const"), str)
    )
    listed_families = sorted(item.get("families") or [])
    if consts != listed_families:
        errors.append(f"{item.get('path')}: schema family coverage mismatch; expected {consts}, listed {listed_families}")

for item in coverage.get("fixture_surfaces") or []:
    path = ROOT / item.get("path", "")
    if not path.exists():
        continue
    data = json.loads(path.read_text())
    primary = data.get("fixture_family") or data.get("coverage_family")
    if primary != item.get("primary_family"):
        errors.append(f"{item.get('path')}: fixture primary family mismatch")
    if item.get("specimen_id") and item.get("specimen_id") != "coverage" and str(data.get("specimen_id")) != str(item.get("specimen_id")):
        errors.append(f"{item.get('path')}: fixture specimen id mismatch")

# Aggregate runner must include every individual check_foundry checker.
runner = (ROOT / "tools" / "check_foundry_all.py").read_text(errors="ignore")
registered = set(re.findall(r'"(check_foundry_[^"]+\.py)"', runner))
missing_runner = sorted(Path(p).name for p in actual_checkers if Path(p).name not in registered)
if missing_runner:
    errors.append(f"tools/check_foundry_all.py missing checker registrations: {', '.join(missing_runner)}")

# Documentation pointers are intentionally sparse, but must exist.
for rel in coverage.get("documentation_surfaces") or []:
    if not (ROOT / rel).exists():
        errors.append(f"{rel_manifest}: missing documented coverage surface {rel}")

rules = " ".join(coverage.get("coverage_rules") or []).lower()
for word in ["schema", "fixture", "checker", "runner"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(coverage.get("non_goals") or []).lower()
for word in ["ontology", "correctness", "audit", "production"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(
    f"Foundry schema/fixture coverage check passed for {len(actual_schemas)} schema(s), "
    f"{len(actual_fixtures)} fixture JSON file(s), and {len(actual_checkers)} registered checker(s)"
)
