#!/usr/bin/env python3
"""Check Foundry checker-contract index coverage.

This refactor guard verifies that the aggregate runner, checker files, primary
fixtures/rulebooks, and success-output fragments are machine-visible. It is not
a proof that the checker logic is correct.
"""
from pathlib import Path
import json
import re
import sys

try:
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail
except ModuleNotFoundError:  # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from foundry_checklib import FIXTURES, ROOT, load_json, require_sha256, fail

manifest_path = FIXTURES / "checker-contract-index" / "index.json"
if not manifest_path.exists():
    print("Missing checker contract index")
    sys.exit(1)

index = load_json(manifest_path)
errors = []
rel_manifest = manifest_path.relative_to(ROOT)
receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text())
if index.get("coverage_family") != "foundry_checker_contract_index_v0":
    errors.append(f"{rel_manifest}: wrong coverage_family")
if index.get("revision") != receipt.get("revision"):
    errors.append(f"{rel_manifest}: revision does not match REVISION-RECEIPT")
if not require_sha256(index.get("coverage_digest")):
    errors.append(f"{rel_manifest}: missing sha256 coverage_digest")

runner_text = (ROOT / "tools/check_foundry_all.py").read_text(errors="ignore")
runner_scripts = re.findall(r'"(check_[^"]+\.py)"', runner_text)
contracts = index.get("checker_contracts") or []
listed_scripts = [Path(c.get("checker", "")).name for c in contracts]
if runner_scripts != listed_scripts:
    errors.append(f"{rel_manifest}: runner order mismatch; runner={runner_scripts}, indexed={listed_scripts}")

seen = set()
for ordinal, contract in enumerate(contracts, start=1):
    checker_rel = contract.get("checker") or ""
    checker_name = Path(checker_rel).name
    if checker_name in seen:
        errors.append(f"{rel_manifest}: duplicate checker contract for {checker_name}")
    seen.add(checker_name)
    if contract.get("runner_order") != ordinal:
        errors.append(f"{rel_manifest}: checker {checker_name} has runner_order {contract.get('runner_order')} but expected {ordinal}")
    checker_path = ROOT / checker_rel
    if not checker_rel or not checker_path.exists():
        errors.append(f"{rel_manifest}: checker missing on disk: {checker_rel!r}")
        continue
    source = checker_path.read_text(errors="ignore")
    fragment = contract.get("expected_output_fragment") or ""
    if not fragment or fragment not in source:
        errors.append(f"{rel_manifest}: checker {checker_name} missing expected output fragment {fragment!r}")
    if "check passed" not in source:
        errors.append(f"{rel_manifest}: checker {checker_name} should have a pass output")
    if contract.get("registered_in_runner") is not True:
        errors.append(f"{rel_manifest}: checker {checker_name} must set registered_in_runner=true")
    if checker_name not in runner_scripts:
        errors.append(f"{rel_manifest}: checker {checker_name} not registered in aggregate runner")
    primary_fixture = contract.get("primary_fixture")
    if primary_fixture and not (ROOT / primary_fixture).exists():
        errors.append(f"{rel_manifest}: checker {checker_name} primary_fixture missing: {primary_fixture}")
    primary_rulebook = contract.get("primary_rulebook")
    if primary_rulebook and not (ROOT / primary_rulebook).exists():
        errors.append(f"{rel_manifest}: checker {checker_name} primary_rulebook missing: {primary_rulebook}")
    specimen_doc = contract.get("specimen_doc")
    if specimen_doc and not (ROOT / specimen_doc).exists():
        errors.append(f"{rel_manifest}: checker {checker_name} specimen_doc missing: {specimen_doc}")
    assertions = " ".join(contract.get("contract_assertions") or []).lower()
    for word in ["runner", "checker", "fixture"]:
        if word not in assertions:
            errors.append(f"{rel_manifest}: checker {checker_name} contract_assertions should mention {word}")
    if contract.get("semantic_scope") == "specimen" and not (primary_fixture and primary_rulebook and specimen_doc):
        errors.append(f"{rel_manifest}: specimen checker {checker_name} must carry fixture, rulebook, and specimen_doc")
    if contract.get("success_output_is_not"):
        non_goal_text = " ".join(contract.get("success_output_is_not") or []).lower()
        for word in ["truth", "audit", "authorization", "approval", "verdict"]:
            if word not in non_goal_text:
                errors.append(f"{rel_manifest}: checker {checker_name} success_output_is_not should refuse {word}")
    else:
        errors.append(f"{rel_manifest}: checker {checker_name} missing success_output_is_not")

actual_individual = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "tools").glob("check_*.py") if p.name != "check_foundry_all.py")
listed_paths = sorted(c.get("checker") for c in contracts)
if actual_individual != listed_paths:
    missing = [p for p in actual_individual if p not in listed_paths]
    ghosts = [p for p in listed_paths if p not in actual_individual]
    if missing:
        errors.append(f"{rel_manifest}: unindexed checker surfaces: {', '.join(missing)}")
    if ghosts:
        errors.append(f"{rel_manifest}: listed checker ghosts: {', '.join(ghosts)}")

rules = " ".join(index.get("coverage_rules") or []).lower()
for word in ["runner", "checker", "fixture", "rulebook", "success"]:
    if word not in rules:
        errors.append(f"{rel_manifest}: coverage_rules should mention {word}")
non_goals = " ".join(index.get("non_goals") or []).lower()
for word in ["correctness", "audit", "certification", "production", "policy", "authorization", "verdict"]:
    if word not in non_goals:
        errors.append(f"{rel_manifest}: non_goals should refuse {word}")

fail(errors)
print(f"Foundry checker-contract index check passed for {len(contracts)} checker contract(s)")
