#!/usr/bin/env python3
"""Check the first Foundry datacube fixture harness.

The goal is not comprehensive schema validation. The goal is to ensure that
specimens 70-92 have executable pressure and that the known flattening failures
remain represented as failing cases.
"""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

required_dirs = {
    "specimen-70-query-result-validation": "70",
    "specimen-71-rollup-aggregation": "71",
    "specimen-72-materialization-reuse": "72",
    "specimen-73-disclosure-differencing": "73",
    "specimen-74-observedness-adjustment": "74",
    "specimen-75-reconciliation-balance": "75",
    "specimen-76-classification-drift": "76",
    "slopos-support-card-residue-survival": "70-77",
    "specimen-78-egress-conformance": "78",
    "specimen-79-semantic-regression": "79",
    "specimen-80-semantic-exceptions": "80",
    "specimen-81-consumer-portability": "81",
    "specimen-82-delegation-boundaries": "82",
    "specimen-83-revocation-recall": "83",
    "specimen-84-remediation-readmission": "84",
    "specimen-85-distribution-adoption": "85",
    "specimen-86-surface-inventory": "86",
    "specimen-87-exposure-accounting": "87",
    "specimen-88-obligation-accounting": "88",
    "specimen-89-fulfillment-accounting": "89",
    "specimen-90-verification-audit": "90",
    "specimen-91-recheck-drift": "91",
    "specimen-92-escalation-routing": "92",
}

required_failure_codes = {
    "query_contract_required",
    "validation_not_verdict",
    "aggregation_guard_required",
    "storage_layout_not_semantic_parentage",
    "materialization_cut_required",
    "vary_basis_required",
    "stale_cut_refused",
    "zero_not_released",
    "suppression_blocks_subtraction",
    "as_observed_fence_required",
    "status_preserving_export_required",
    "balance_not_truth",
    "classification_cut_specific",
    "export_sidecar_required",
    "no_bare_code_join",
    "deprecated_readable_not_current",
    "split_not_reconstructable",
    "unmapped_pocket",
    "egress_manifest_required",
    "refusal_receipt_required",
    "semantic_loss_must_be_named",
    "repair_escape_required",
    "problem_details_required",
    "receipt_attempt_cross_reference",
    "classification_pin_refusal_required",
    "cut_mismatch_refusal_required",
    "status_preservation_refusal_required",
    "semantic_diff_manifest_required",
    "canonical_digest_required",
    "regression_lock_required",
    "tamper_case_required",
    "non_slopos_consumer_required",
    "breaking_change_requires_witness",
    "digest_reuse_after_mutation",
    "sidecar_pin_drop_unwitnessed",
    "receipt_rule_change_unwitnessed",
    "loss_profile_downgrade_unwitnessed",
    "cut_change_requires_migration_witness",
    "generic_problem_details_regression",
    "semantic_waiver_warrant_required",
    "consumer_passport_required",
    "portability_witness_required",
    "interpretation_gate_required",
    "delegation_warrant_required",
    "delegation_reliance_receipt_required",
    "transitive_delegation_refused",
    "delegated_verdict_transfer_refused",
    "expired_warrant_refused",
    "revoked_warrant_refused",
    "revocation_notice_required",
    "revocation_reason_required",
    "affected_scope_required",
    "revocation_digest_required",
    "recall_receipt_required",
    "cache_quarantine_required",
    "stale_reliance_fence_required",
    "stale_reliance_refused",
    "revoked_sidecar_reuse_refused",
    "revoked_warrant_reuse_refused",
    "revoked_waiver_reuse_refused",
    "missing_consumer_ack",
    "silent_supersession_refused",
    "notice_audience_mismatch",
    "notice_propagation_window_expired",
    "replay_before_reuse_required",
    "authority_status_laundering_refused",
    "revocation_as_deletion_refused",
    "remediation_packet_required",
    "revocation_linkage_required",
    "replacement_witness_required",
    "readmission_gate_required",
    "quarantine_release_requires_gate",
    "replacement_digest_mismatch_refused",
    "old_history_rewrite_refused",
    "source_truth_laundering_refused",
    "missing_replayed_gate_refused",
    "consumer_scope_mismatch_refused",
    "active_revocation_unresolved_refused",
    "partial_repair_overclaim_refused",
    "candidate_without_witness_refused",
    "repair_action_without_evidence_refused",
    "readmission_as_harbor_remediation_refused",
    "readmission_as_helm_repair_completion_refused",
    "silent_readmission_refused",
    "new_notice_reopens_packet",
    "distribution_manifest_required",
    "adoption_receipt_required",
    "unknown_target_consumer_refused",
    "stale_carrier_unfenced_refused",
    "propagation_window_expired_refused",
    "cache_copy_without_purge_refused",
    "receipt_digest_mismatch_refused",
    "partial_adoption_overclaim_refused",
    "target_scope_widening_refused",
    "carrier_linkage_missing_refused",
    "adoption_as_approval_refused",
    "delivery_channel_as_truth_refused",
    "orphan_copy_as_current_refused",
    "receipt_without_readmission_gate_refused",
    "adoption_as_cache_policy_refused",
    "straggler_recall_hook_required",
    "surface_inventory_sweep_required",
    "seed_manifest_required",
    "reachability_witness_required",
    "expected_surface_unaccounted_refused",
    "unknown_surface_unfenced_refused",
    "alternate_identifier_unresolved_refused",
    "sweep_window_expired_refused",
    "partial_sweep_as_complete_refused",
    "owner_scope_mismatch_refused",
    "gap_fence_required",
    "witness_digest_mismatch_refused",
    "discovered_copy_as_adopted_refused",
    "inventory_as_catalog_refused",
    "inventory_as_truth_refused",
    "permission_denied_without_recheck_refused",
    "duplicate_surface_accounting_refused",
    "exposure_ledger_required",
    "source_inventory_required",
    "audience_witness_required",
    "intended_audience_unaccounted_refused",
    "unknown_audience_unfenced_refused",
    "public_link_unfenced_refused",
    "purpose_widening_refused",
    "access_mode_widening_refused",
    "inherited_permission_without_witness_refused",
    "ledger_window_expired_refused",
    "overexposed_surface_as_adopted_refused",
    "audience_as_authorization_refused",
    "exposure_as_consent_refused",
    "exposure_as_deletion_refused",
    "exposure_witness_digest_mismatch_refused",
    "purpose_fence_required",
    "obligation_ledger_required",
    "source_exposure_required",
    "obligation_pin_required",
    "acknowledgment_witness_required",
    "required_acknowledgment_missing_refused",
    "sidecar_requirement_dropped_refused",
    "classification_pin_requirement_dropped_refused",
    "recall_route_missing_refused",
    "no_reexport_downgraded_refused",
    "acknowledgment_scope_mismatch_refused",
    "wrong_consumer_acknowledgment_refused",
    "partial_ack_as_full_refused",
    "obligation_expired_without_recheck_refused",
    "public_link_obligation_unfenced_refused",
    "inherited_obligation_unbound_refused",
    "obligation_as_authorization_refused",
    "obligation_as_legal_compliance_refused",
    "obligation_as_consent_refused",
    "acknowledgment_digest_mismatch_refused",
    "waiver_without_replay_refused",
    "sibling_verdict_laundering_refused",
    "fulfillment_receipt_required",
    "source_obligation_required",
    "completion_witness_required",
    "required_completion_missing_refused",
    "acknowledgment_as_fulfillment_refused",
    "deadline_expired_refused",
    "sidecar_not_carried_refused",
    "classification_pin_not_verified_refused",
    "observation_status_hidden_refused",
    "recall_route_untested_refused",
    "no_reexport_unenforced_refused",
    "recheck_missing_before_reuse_refused",
    "quarantine_not_applied_refused",
    "sibling_boundary_unfulfilled_refused",
    "completion_scope_mismatch_refused",
    "wrong_consumer_completion_refused",
    "partial_completion_as_complete_refused",
    "completion_digest_mismatch_refused",
    "public_link_fulfillment_unfenced_refused",
    "inherited_fulfillment_unbound_refused",
    "fulfillment_as_authorization_refused",
    "fulfillment_as_legal_compliance_refused",
    "fulfillment_as_audit_opinion_refused",
    "fulfillment_sibling_verdict_laundering_refused",
    "verification_audit_required",
    "source_fulfillment_required",
    "evidence_sample_required",
    "required_sample_missing_refused",
    "completion_as_verification_refused",
    "self_verification_unfenced_refused",
    "verifier_conflict_refused",
    "audit_scope_mismatch_refused",
    "sample_scope_mismatch_refused",
    "stale_sample_accepted_refused",
    "contradiction_ignored_refused",
    "partial_audit_as_passed_refused",
    "sample_digest_mismatch_refused",
    "public_link_verification_unfenced_refused",
    "inherited_verification_unbound_refused",
    "verification_as_authorization_refused",
    "verification_as_legal_compliance_refused",
    "verification_as_audit_opinion_refused",
    "verification_as_cryptographic_proof_refused",
    "verification_sibling_verdict_laundering_refused",
    "harness_coverage_drift_refused",
    "recheck_cadence_required",
    "source_verification_required",
    "drift_signal_required",
    "required_signal_missing_refused",
    "stale_signal_accepted_refused",
    "flapping_signal_unfenced_refused",
    "missed_recheck_unfenced_refused",
    "cadence_scope_mismatch_refused",
    "signal_scope_mismatch_refused",
    "signal_digest_mismatch_refused",
    "paused_cadence_as_active_refused",
    "clear_signal_as_exhaustive_refused",
    "alert_as_truth_refused",
    "freshness_as_authorization_refused",
    "recheck_as_audit_opinion_refused",
    "monitoring_as_sibling_verdict_refused",
    "schema_fixture_coverage_drift_refused",
    "escalation_packet_required",
    "routing_witness_required",
    "unresolved_signal_fence_required",
    "source_signal_required",
    "source_cadence_required",
    "risky_signal_without_packet_refused",
    "missing_route_accepted_refused",
    "misrouted_acknowledgment_refused",
    "stale_acknowledgment_refused",
    "routing_scope_mismatch_refused",
    "dedupe_erased_residue_refused",
    "inhibited_without_fence_refused",
    "route_as_truth_refused",
    "acknowledgment_as_resolution_refused",
    "pager_as_authority_refused",
    "incident_management_capture_refused",
    "repair_lifecycle_laundering_refused",
    "routing_sibling_verdict_laundering_refused",
    "specimen_doc_coverage_drift_refused",
}

errors = []
seen_specimens = set()
seen_failure_codes = set()
fixture_files = []

for dirname, specimen_id in required_dirs.items():
    d = FIXTURES / dirname
    if not d.is_dir():
        errors.append(f"Missing fixture directory: fixtures/{dirname}")
        continue
    files = sorted(d.glob("*.json"))
    if not files:
        errors.append(f"Missing fixture JSON in fixtures/{dirname}")
        continue
    fixture_files.extend(files)

for path in fixture_files:
    data = json.loads(path.read_text())
    rel = path.relative_to(ROOT)
    if data.get("fixture_family") != "foundry_semantic_fixture_bundle_v0":
        errors.append(f"{rel}: fixture_family must be foundry_semantic_fixture_bundle_v0")
    sid = str(data.get("specimen_id", ""))
    if sid:
        seen_specimens.add(sid)
    if not data.get("title"):
        errors.append(f"{rel}: title is required")
    if not isinstance(data.get("negative_cases"), list) or not data.get("negative_cases"):
        errors.append(f"{rel}: at least one negative case is required")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")
        code = case.get("failure_code")
        if not code:
            errors.append(f"{rel}: negative case {case.get('case_id')} is missing failure_code")
        else:
            seen_failure_codes.add(code)

expected_specimens = set(required_dirs.values())
missing_specimens = expected_specimens - seen_specimens
if missing_specimens:
    errors.append("Missing specimen ids in fixtures: " + ", ".join(sorted(missing_specimens)))

missing_codes = required_failure_codes - seen_failure_codes
if missing_codes:
    errors.append("Missing required failure codes: " + ", ".join(sorted(missing_codes)))

# Specific guard: specimen 76 must include the SlopOS classification-drift scars.
s76_files = sorted((FIXTURES / "specimen-76-classification-drift").glob("*.json"))
if s76_files:
    s76 = json.loads(s76_files[0].read_text())
    pins = {p.get("pin_id") for p in s76.get("classification_pins", [])}
    if "pin_boundary_browser_federation_v0" not in pins or "pin_boundary_browser_mediation_v0" not in pins:
        errors.append("Specimen 76 fixture must include old and current boundary-family pins.")
    rels = {cw.get("relation") for cw in s76.get("crosswalk_witnesses", [])}
    cards = {cw.get("cardinality") for cw in s76.get("crosswalk_witnesses", [])}
    if "equivalent" not in rels or "source_broader_than_target" not in rels or "one_to_many" not in cards:
        errors.append("Specimen 76 fixture must include equivalent rename and one-to-many split crosswalks.")

if errors:
    print("Foundry specimen fixture check failed:")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print(f"Foundry specimen fixture check passed for {len(fixture_files)} fixture files")
