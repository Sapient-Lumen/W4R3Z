#!/usr/bin/env python3
"""Check Foundry delegation-boundary fixtures.

Specimen 82 is about delegated semantic acts. The checker is intentionally
small: it makes sure delegation warrants, reliance receipts, and transitive-use
fences prevent permission, verdict, approval, sibling authority, and transitive
reuse from leaking through Foundry residue.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "fixtures"

REQUIRED_RULES = {
    "R-DELEG-001-WARRANT-REQUIRED",
    "R-DELEG-002-SCOPED-ACTS",
    "R-DELEG-003-SCOPE-BOUNDARY",
    "R-DELEG-004-NON-TRANSITIVE-DEFAULT",
    "R-DELEG-005-RELIANCE-RECEIPT",
    "R-DELEG-006-AUTHORITY-NOT-VERDICT",
    "R-DELEG-007-EXPIRY-REVOCATION",
    "R-DELEG-008-ACTOR-CHAIN-TRACE",
    "R-DELEG-009-WITHHELD-RESIDUE",
    "R-DELEG-010-SIBLING-OWNERSHIP",
    "R-DELEG-011-CONSUMER-PASSPORT-COMPAT",
    "R-DELEG-012-REFUSAL-ON-WIDENING",
}

REQUIRED_FAILURE_CODES = {
    "delegation_warrant_required",
    "delegation_scope_required",
    "delegation_permitted_acts_required",
    "delegation_reliance_receipt_required",
    "transitive_delegation_refused",
    "delegated_verdict_transfer_refused",
    "sibling_authority_delegation_refused",
    "withheld_residue_used",
    "expired_warrant_refused",
    "revoked_warrant_refused",
    "self_issued_warrant_refused",
    "actor_chain_trace_required",
    "consumer_passport_mismatch",
    "purpose_widening_refused",
    "audience_widening_refused",
    "portability_witness_not_warrant",
}

AUTHORITY_WORDS = {"verdict", "authority", "approval", "truth", "risk", "proof", "identity"}

def parse_time(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None

errors = []
fixtures = []
for path in sorted(FIXTURES.rglob("*.json")):
    data = json.loads(path.read_text())
    if isinstance(data, dict) and isinstance(data.get("delegation_warrants"), list):
        fixtures.append((path, data))

if not fixtures:
    errors.append("No delegation_warrants fixture found for specimen 82.")

active_warrants = 0
inactive_warrants = 0
allowed_receipts = 0
refused_receipts = 0
fence_count = 0

for path, data in fixtures:
    rel = path.relative_to(ROOT)
    now = parse_time(data.get("fixture_now")) or datetime.now(timezone.utc)
    consumers = {c.get("consumer_id") for c in data.get("consumer_refs", []) if c.get("consumer_id")}
    warrants = data.get("delegation_warrants") or []
    warrant_by_id = {}
    if not warrants:
        errors.append(f"{rel}: delegation_warrants must be non-empty")
    for warrant in warrants:
        wid = warrant.get("warrant_id", "<missing>")
        if warrant.get("warrant_family") != "foundry_delegation_warrant_v0":
            errors.append(f"{rel}: warrant {wid} has wrong warrant_family")
        if not wid or wid in warrant_by_id:
            errors.append(f"{rel}: warrant ids must be present and unique; saw {wid}")
        warrant_by_id[wid] = warrant
        ids = [warrant.get("grantor_consumer_id"), warrant.get("delegate_consumer_id"), warrant.get("relying_consumer_id")]
        for cid in ids:
            if cid not in consumers:
                errors.append(f"{rel}: warrant {wid} references unknown consumer {cid!r}")
        if warrant.get("grantor_consumer_id") == warrant.get("delegate_consumer_id"):
            errors.append(f"{rel}: warrant {wid} must not be self-issued by the delegate")
        if warrant.get("delegate_consumer_id") == warrant.get("relying_consumer_id"):
            errors.append(f"{rel}: warrant {wid} must distinguish delegate from relying consumer")
        for key in ["artifact_ids", "permitted_semantic_acts", "forbidden_semantic_acts", "delegated_residue", "withheld_residue"]:
            if not isinstance(warrant.get(key), list) or not warrant.get(key):
                errors.append(f"{rel}: warrant {wid} must name non-empty {key}")
        scope = warrant.get("scope") or {}
        for key in ["purpose", "audience", "source_cut", "classification_cut", "revision"]:
            if not scope.get(key):
                errors.append(f"{rel}: warrant {wid} scope missing {key}")
        if warrant.get("non_transitive") is not True:
            errors.append(f"{rel}: warrant {wid} must be non_transitive=true")
        if warrant.get("requires_reliance_receipt") is not True or warrant.get("requires_transitive_fence") is not True:
            errors.append(f"{rel}: warrant {wid} must require reliance receipt and transitive fence")
        if warrant.get("verdict_transfer_allowed") is not False:
            errors.append(f"{rel}: warrant {wid} must set verdict_transfer_allowed=false")
        if warrant.get("sibling_authority_delegation_allowed") is not False:
            errors.append(f"{rel}: warrant {wid} must set sibling_authority_delegation_allowed=false")
        if not any(any(word in item for word in AUTHORITY_WORDS) for item in warrant.get("forbidden_semantic_acts", []) + warrant.get("withheld_residue", [])):
            errors.append(f"{rel}: warrant {wid} should forbid or withhold authority/verdict/approval/truth residue")
        status = warrant.get("revocation_status")
        expires = parse_time(warrant.get("expires_at"))
        if status == "active":
            active_warrants += 1
            if not expires or expires <= now:
                errors.append(f"{rel}: active warrant {wid} must expire after fixture_now")
        else:
            inactive_warrants += 1

    receipts = data.get("reliance_receipts") or []
    receipt_warrants = set()
    for receipt in receipts:
        rid = receipt.get("receipt_id", "<missing>")
        if receipt.get("receipt_family") != "foundry_reliance_receipt_v0":
            errors.append(f"{rel}: receipt {rid} has wrong receipt_family")
        wid = receipt.get("warrant_id")
        warrant = warrant_by_id.get(wid)
        if not warrant:
            errors.append(f"{rel}: receipt {rid} references unknown warrant {wid!r}")
            continue
        receipt_warrants.add(wid)
        if receipt.get("delegate_consumer_id") != warrant.get("delegate_consumer_id"):
            errors.append(f"{rel}: receipt {rid} delegate does not match warrant {wid}")
        if receipt.get("relying_consumer_id") != warrant.get("relying_consumer_id"):
            errors.append(f"{rel}: receipt {rid} relying consumer does not match warrant {wid}")
        rules = set(receipt.get("checked_rules") or [])
        if not any(rule.startswith("R-DELEG-") for rule in rules):
            errors.append(f"{rel}: receipt {rid} must check at least one R-DELEG rule")
        if "R-DELEG-008-ACTOR-CHAIN-TRACE" not in rules and receipt.get("result") == "allowed":
            errors.append(f"{rel}: allowed receipt {rid} must check actor-chain trace")
        chain = receipt.get("actor_chain") or []
        if len(chain) < 3:
            errors.append(f"{rel}: receipt {rid} must preserve at least grantor/delegate/relying actor chain")
        if not isinstance(receipt.get("refused_inferences"), list) or not receipt.get("refused_inferences"):
            errors.append(f"{rel}: receipt {rid} must name refused_inferences")
        if not any(any(word in item for word in AUTHORITY_WORDS) for item in receipt.get("refused_inferences", [])):
            errors.append(f"{rel}: receipt {rid} refused_inferences should include authority/verdict/approval/truth/risk/proof/identity")
        result = receipt.get("result")
        if result == "allowed":
            allowed_receipts += 1
            if warrant.get("revocation_status") != "active":
                errors.append(f"{rel}: receipt {rid} cannot allow reliance on inactive warrant {wid}")
            used = set(receipt.get("used_semantic_acts") or [])
            permitted = set(warrant.get("permitted_semantic_acts") or [])
            if not used or not used.issubset(permitted):
                errors.append(f"{rel}: receipt {rid} used acts must be a non-empty subset of warrant permitted acts")
            if not isinstance(receipt.get("preserved_residue"), list) or not receipt.get("preserved_residue"):
                errors.append(f"{rel}: allowed receipt {rid} must name preserved_residue")
        elif result == "refused":
            refused_receipts += 1
            problem = receipt.get("problem_details") or {}
            if not all(problem.get(k) for k in ["type", "title", "status", "detail"]):
                errors.append(f"{rel}: refused receipt {rid} must include problem_details with type/title/status/detail")
        else:
            errors.append(f"{rel}: receipt {rid} result must be allowed or refused")

    for wid, warrant in warrant_by_id.items():
        if warrant.get("revocation_status") == "active" and wid not in receipt_warrants:
            errors.append(f"{rel}: active warrant {wid} has no reliance receipt")

    fences = data.get("transitive_use_fences") or []
    fence_count += len(fences)
    fence_warrants = set()
    for fence in fences:
        fid = fence.get("fence_id", "<missing>")
        if fence.get("fence_family") != "foundry_transitive_use_fence_v0":
            errors.append(f"{rel}: fence {fid} has wrong fence_family")
        wid = fence.get("warrant_id")
        warrant = warrant_by_id.get(wid)
        if not warrant:
            errors.append(f"{rel}: fence {fid} references unknown warrant {wid!r}")
            continue
        fence_warrants.add(wid)
        if fence.get("allowed_redelegation") is not False:
            errors.append(f"{rel}: fence {fid} must set allowed_redelegation=false")
        blocked = set(fence.get("blocked_acts") or [])
        if not ({"redelegate", "widen_audience", "widen_purpose", "issue_verdict", "claim_sibling_authority"} & blocked):
            errors.append(f"{rel}: fence {fid} must block redelegation, widening, verdict, or sibling authority")
        if not fence.get("failure_code"):
            errors.append(f"{rel}: fence {fid} missing failure_code")
    for wid, warrant in warrant_by_id.items():
        if warrant.get("revocation_status") == "active" and wid not in fence_warrants:
            errors.append(f"{rel}: active warrant {wid} has no transitive-use fence")

    negative_codes = {c.get("failure_code") for c in data.get("negative_cases", []) if c.get("failure_code")}
    missing_codes = REQUIRED_FAILURE_CODES - negative_codes
    if missing_codes:
        errors.append(f"{rel}: negative_cases missing required codes: {', '.join(sorted(missing_codes))}")
    for case in data.get("negative_cases", []):
        if case.get("must_fail") is not True:
            errors.append(f"{rel}: negative case {case.get('case_id')} must set must_fail=true")

if active_warrants < 1:
    errors.append("Specimen 82 needs at least one active delegation warrant.")
if inactive_warrants < 1:
    errors.append("Specimen 82 needs at least one expired/revoked/superseded/rejected warrant.")
if allowed_receipts < 1 or refused_receipts < 1:
    errors.append("Specimen 82 needs at least one allowed and one refused reliance receipt.")
if fence_count < 1:
    errors.append("Specimen 82 needs at least one transitive-use fence.")

rulebook = ROOT / "docs/30-architecture/delegation-boundary-rulebook-v0.md"
if not rulebook.exists():
    errors.append("Missing delegation boundary rulebook.")
else:
    text = rulebook.read_text(errors="ignore")
    missing_rules = [rule for rule in sorted(REQUIRED_RULES) if rule not in text]
    if missing_rules:
        errors.append("Delegation boundary rulebook missing rules: " + ", ".join(missing_rules))

if errors:
    print("Foundry delegation boundary check failed:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(f"Foundry delegation boundary check passed for {len(fixtures)} fixture file(s), {active_warrants} active warrant(s), {inactive_warrants} inactive warrant(s), {allowed_receipts} allowed receipt(s), {refused_receipts} refused receipt(s), and {fence_count} transitive fence(s)")
