# ADR 0002: Runtime evidence is not a verdict

- Status: accepted

Foundry may emit runtime evidence and continuity facts, but Ward remains responsible for durable trust appraisal.
