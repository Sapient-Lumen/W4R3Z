# ADR 0001: Foundry owns off-native realization

- Status: accepted

Foundry is founded as the cube for artifact/world/ground/realization separation across foreign cells and compat membranes.
