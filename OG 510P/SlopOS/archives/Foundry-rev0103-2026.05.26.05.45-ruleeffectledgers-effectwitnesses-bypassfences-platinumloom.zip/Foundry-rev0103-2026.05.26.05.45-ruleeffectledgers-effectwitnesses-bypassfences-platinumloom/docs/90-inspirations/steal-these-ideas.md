# Steal these ideas

## From outside systems
- OCI: keep image/index/bundle/config distinct instead of flattening “what shipped” into “what ran”.
- Wasm component model: make packages, interfaces, and worlds explicit so foreign contracts stay honest.
- Fuchsia capability routing: route virtualization and foreign-power explicitly into products/sessions.
- Qubes qrexec: explicit cross-domain service routes beat ambient reachability.
- Confidential Containers: keep attestation/admission policy separate from resource-release policy; bind init-data integrity into the story.
- Firecracker and SnapStart: restore is valuable, but continuity, uniqueness, and network state still need humility.
- OCI referrers/artifacts: attach nearby evidence and contract artifacts to a digest subject without bloating the primary.
- Repository-scoped referrers: keep operational grouping close without confusing shared scope for final approval.

## From sibling cubes
- Harbor: foreign entry and return need truthful membrane receipts.
- Ward: evidence remains smaller than verdict or release.
- Helm: visibly foreign surfaces are a product virtue.
- Schell: helpers and sidecars deserve explicit adoption.
- ViewFS: artifact carriers, live instances, and durable references are different strengths.

## New steals for rev0008
1. **Subject spine** — a stable anchor for nearby sidecars without fake completeness.
2. **Sidecar pack** — grouped nearby evidence/contract artifacts that stay visibly partial.
3. **Measured policy capsule** — record which policy input was integrity-bound into realization.
4. **Adoption rail** — started, attested, reviewed, adopted remain separate even with neat sidecars.
5. **Repository-scope warning** — shared access scope is convenience, not verdict.
## New steals for rev0011
1. **Subject spine** — the primary artifact plus its attached nearby evidence neighborhood, still smaller than realization.
2. **Resource handle** — a typed exterior handle to something implemented across the boundary.
3. **Policy capsule** — compact account of which policy inputs governed admission or release.
4. **Secret-release latch** — explicit state showing that release of stronger foreign power is separately gated.
5. **Availability split** — required versus optional routed foreign power stays visible.

## New steals for rev0013
1. **Restore obligation card** — post-resume duties kept visible until discharged.
2. **Availability class** — required, optional, unavailable as a first-class foreign-power status.
3. **Referrer fallback card** — nearby sidecars discovered through a degraded path instead of native referrers.
4. **After-restore rail** — resumed is not the same as ready.
5. **Auxiliary-capability dimmer** — optional foreign power should degrade features without falsifying the whole realization.


- **borrowed handle card** — explicit note that a useful thing still lives elsewhere.
- **restore budget** — what a resumed realization may spend before its readiness claim narrows.
- **capability grade** — required/optional/degraded/absent rather than yes/no.

## New steals for rev0014
- **owned-handle swap** — record whether foreign utility is still borrowed or has been replaced/re-owned elsewhere.
- **availability floor** — the weakest still-true routed power posture.
- **restore duty ledger** — explicit after-restore obligations before strong readiness claims.
- **fallback lease** — honest degraded attachment discovery.
- **foreign utility without fake locality** — a standing anti-regrowth rule.

## New steals for rev0015
- **void route** — explicit absence for optional or product-specific power.
- **borrow rail** — a visible lane for useful handles that remain foreign-backed and borrowed.
- **secret latch** — release posture separated from attestation and base readiness.
- **degraded readiness class** — running, but still weaker than fully adopted or fully provisioned.
- **absence is a fact** — a standing anti-regrowth rule.

## New steals for rev0016
- **hydration frontier** — how much of the artifact is materially local right now.
- **prefetch witness** — compact residue about what was intentionally fetched early.
- **cold-read debt** — the remaining cost of later on-demand hydration.
- **lazy-locality grade** — a truthful class for “works now, still not fully local”.
- **launch smaller than locality** — a standing anti-regrowth rule.

## New steals for rev0018
- **extension witness** — compact compatibility residue for a foreign layer.
- **detachable layer** — attachable foreign merge that remains rollback-capable.
- **backing cargo** — content store distinct from the mountable structural layer.
- **structure/cargo split** — separate integrity and locality stories for layer versus data.
- **attach smaller than assimilate** — a standing anti-regrowth rule.

## New steals for rev0018
- **metadata seal** — explicit integrity story for names, structure, permissions, and directory shape.
- **payload root** — compact witness for foreign-backed file content.
- **bootstrap debt** — what still remains non-local even though startup can begin.
- **seal split** — keep structure assurance and payload assurance visibly different.
- **started smaller than sealed** — a standing anti-regrowth rule.

## Pass XIX additions
- **config layer** — foreign configuration surface distinct from runtime cargo.
- **compat witness** — compact compatibility proof for an overlay.
- **overlay gate** — typed refusal when merge compatibility is insufficient.

## Pass XX additions
- **staged generation** — prepared foreign basis that is real before activation.
- **activation cut** — explicit switch point where queued basis becomes live.
- **booted basis** — current live truth kept separate from queued candidates.
- **rollback selector** — explicit previous-basis choice instead of folklore.
- **candidate smaller than active** — a standing anti-regrowth rule.
- **noexec-by-default config overlay** — a safety hint worth stealing before broadening config-layer power.


## Pass XXI additions
- **trial basis** — activated-once basis still weaker than blessed current truth.
- **success latch** — explicit post-boot bless/commit seam.
- **fallback budget** — bounded remaining tries before deterministic return.
- **boot-complete target** — composable success milestone rather than hidden readiness folklore.
- **coherence target** — future grouped version unit for basis pieces that should move together.
- **prior-confirmed bundle receipt** — future protection against issuing a conflicting new bundle over uncertain prior adoption.
- **booted smaller than blessed** — a standing anti-regrowth rule.


## Pass XXII additions
- **coherence target** — grouped version unit for basis pieces that should move together.
- **confirmation fence** — explicit certainty boundary before prior offers count as settled current truth.
- **supersession hold** — refuse conflicting advance while confirmation is still missing.
- **prior-confirmed receipt** — evidence that opens the confirmation fence without becoming a global verdict.
- **mixed-time guard** — stop resources or metadata from different moments impersonating one coherent basis.
- **cohort hint** — rollout tag worth stealing only if it stays outside install authority.
- **offered smaller than confirmed** — a standing anti-regrowth rule.


## Pass XXIII additions
- **follow selector** — floating branch/channel/ref/track request.
- **basis pin** — exact resolved revision, digest, or version.
- **drift fence** — explicit refusal to let stale review or install intent follow moved selector.
- **selector snapshot** — historical record of one earlier selector resolution.
- **pinned-over-floating rule** — a standing anti-regrowth rule.


## Pass XXIV additions
- **offer hint** — server-side statement that an exact basis or transition is available.
- **local hold** — explicit local defer/pause/freeze posture that blocks uptake for now.
- **admission window** — bounded condition or time slice when a held offer may proceed.
- **hold reason chip** — future explanation surface for “why not now?”.
- **offered smaller than admissible** — a standing anti-regrowth rule.

## Pass XXV additions
- **prerequisite witness** — exact-current-state fact needed to justify one direct transition.
- **applicability fence** — required compatibility, dependency, or minimum-floor gate for a direct edge.
- **barrier hop** — explicit required intermediate before a later target becomes valid.
- **delta fingerprint card** — future exact-current-state label sharper than a version string.
- **direct-edge smaller than valid-path** — a standing anti-regrowth rule.

## Pass XXVI additions
- **rollback floor** — monotonic lower bound below which ordinary rollback no longer counts as admissible.
- **ratchet mark** — explicit event or receipt that advances the rollback floor.
- **rescue path** — explicit reviewed recovery path for older content when ordinary rollback is barred.
- **floor witness card** — future compact residue for the active rollback floor.
- **known-good smaller than rollback-safe** — a standing anti-regrowth rule.


## Pass XXVII additions
- **state epoch** — semantic/data-format epoch for persistent state, distinct from basis revision.
- **migration cut** — explicit crossing where persistent state changes epoch.
- **reset rail** — explicit reset/reseed path when rollback or forward progress cannot preserve continuity honestly.
- **read corridor** — future compact promise that a basis can safely read an older state epoch without rewriting it.
- **basis rollback smaller than state continuity** — a standing anti-regrowth rule.


## Pass XXVIII additions
- **retention root** — explicit reason or reference that keeps exact material alive beyond current use.
- **reclaim fence** — explicit blocker that ordinary GC/delete may not cross yet.
- **cleanup debt** — explicit outstanding work before release and reclamation become honest.
- **collectability class** — future compact retained-versus-collectible label.
- **not current smaller than reclaimable** — a standing anti-regrowth rule.


## Pass XXIX additions
- **admission cut** — explicit point after which new work should stop landing on one realization.
- **drain epoch** — bounded overlap while pre-existing work may still complete.
- **grace fence** — explicit blocker before final teardown or reclaim.
- **serving-terminating card** — future compact residue for `terminating` while still `serving`.
- **not admitted smaller than gone** — a standing anti-regrowth rule.

## Pass XXX additions
- **consistency class** — explicit captured-cut strength such as crash-consistent versus application-consistent.
- **write fence** — visible pause/freeze/flush boundary that strengthens a cut.
- **recovery debt** — replay or repair still owed after restore.
- **group cut without overclaim** — one point-in-time set across several volumes without pretending the application was quiesced.
- **captured smaller than resumed** — a standing anti-regrowth rule.

## Pass XXXI additions
- **intent generation** — explicit newer desired-state step.
- **observed generation** — the newest desired generation current status has actually caught up to.
- **stale-status fence** — refusal to read old green status as current truth about newer intent.
- **applied-lag card** — compact residue showing how far status trails desired state.
- **green smaller than current** — a standing anti-regrowth rule.

## Pass XXXII additions
- **commit frontier** — highest authoritative, durably accepted change point.
- **apply frontier** — highest point one realization or observer has actually applied locally.
- **delta horizon** — earliest still-usable point for incremental catch-up before snapshot or reseed is required.
- **gap card** — compact residue for how far local visibility trails authoritative history.
- **caught-up smaller than repairable** — a standing anti-regrowth rule.



## Pass XXXIII additions
- **exposure frontier** — highest point one subject may honestly expose now.
- **stability fence** — dependency, isolation, warmup, or safety boundary that blocks newer state from immediate exposure.
- **withheld tail** — newer committed/loaded/applied material intentionally kept outside current exposure.
- **active-set badge** — future compact residue for what cut is actually serving now.
- **applied smaller than exposed** — a standing anti-regrowth rule.


## Pass XXXIV additions
- **holder epoch** — monotonic ownership/version step for one singular mutable or serving role.
- **fence token** — exact checked witness that downstream systems use to reject stale holders.
- **stale-holder cut** — explicit point where older holders become non-authoritative even if still alive.
- **observer-only tail** — future compact residue for older holders that may still answer bounded stale observations after losing write authority.
- **current smaller than fenced** — a standing anti-regrowth rule.

## Pass XXXV additions
- **effect key** — stable retry-equivalent identity for one requested foreign effect.
- **fingerprint fence** — exact canonical request/effect check that blocks changed meaning under one old key.
- **prior-outcome anchor** — replayable earlier accepted outcome or receipt for an exact duplicate-safe retry.
- **pending-duplicate card** — future compact residue for “same key seen, original work still in flight”.
- **same key smaller than same effect** — a standing anti-regrowth rule.


## Pass XXXVI additions
- **pending duplicate** — same key, same fingerprint, original work still in flight.
- **dedupe horizon** — bounded replay/suppression memory interval for one effect key.
- **expiry gate** — visible edge where old duplicate memory stops governing retries.
- **timed idempotency** — a standing anti-regrowth rule: retry-safe identity still lives on a clock.
- **same key smaller than same timing class** — a standing anti-regrowth rule.


## Pass XXXVII additions
- **absence witness** — bounded authoritative negative result.
- **tombstone marker** — durable withdrawn/delete marker behind ordinary absence.
- **resurrection fence** — grace or quarantine before purge or identity reuse.
- **gone badge** — future compact residue for intentionally unavailable instead of merely absent.
- **absent smaller than reusable** — a standing anti-regrowth rule.

## Pass XXXVIII additions
- **issuance witness** — exact minted descriptor/proof/receipt without overclaiming current authority.
- **live-validity witness** — current active/non-revoked/non-expired statement for one exact context.
- **recheck horizon** — visible freshness limit on old positive-validity knowledge.
- **status-list complement** — separate pushed/pulled invalidation feed when direct introspection is too expensive or unavailable.
- **issued smaller than valid-now** — a standing anti-regrowth rule.

## Pass XXXIX additions
- **assurance class** — context-local statement of required or satisfied auth strength without pretending there is one global ladder.
- **recency fence** — visible bound on how old the last qualifying authentication event may be for one action.
- **intent latch** — explicit present-user intervention requirement before one sensitive effect crosses.
- **step-up card** — future compact residue for an otherwise valid session that still needs stronger or fresher auth.
- **valid smaller than high-and-fresh-enough** — a standing anti-regrowth rule.



## Pass XL additions
- **presenter binding** — visible reminder that current possession/holder proof is smaller than bare artifact validity.
- **audience fence** — exact receiver/resource boundary that keeps one artifact from becoming generic cross-resource truth.
- **request pin** — explicit method/route/nonce/token-hash style binding for one exact presentation.
- **valid smaller than bound** — a standing anti-regrowth rule.


## Pass XLI additions
- **derivation witness** — exact parent-to-child lineage without exporting the raw parent.
- **attenuation fence** — explicit upper-bound scope cut instead of polite-looking rebadging.
- **ancestor shadow** — keep parent or lineage invalidation visibly load-bearing for descendants.
- **discharge witness** — parked future proof that one caveat or outside condition was satisfied.
- **actor-path card** — parked future compact residue for multi-hop delegation history when one workflow genuinely needs it.

- **discharge witness** — carry one exact outside/context proof with the child instead of forcing fresh verifier lookup.
- **caveat hold** — keep “derived child exists” visibly smaller than “derived child is admissible now”.
- **actor-path card** — keep a compact multi-hop trail for audit without turning history into present authority.

## Pass XLIII additions
- **schema identity without universal ontology** — steal the idea of a revision/schema hook plus optional transforms from OpenTelemetry without promising one giant meaning plane.
- **explicit stability lanes** — steal development/stable/deprecated posture so attractive candidate nouns do not silently become law.
- **unknown-first defaults** — steal UNKNOWN/UNSPECIFIED-first posture from protobuf-style enum hygiene.
- **observed-generation style status hooks** — steal the habit of saying exactly which authoring revision a status/read model has caught up to.
- **main-spec evolution before registry sprawl** — steal the W3C instinct to add registries only when concrete extension pressure exists.
- **simplest-process-first** — steal GitLab’s bias toward the lightest process that still carries the architecture pressure.

## Pass XLIV additions
- **effective time** — when the fact was true in the modeled world.
- **record time** — when the archive learned or accepted it.
- **pending context** — explicit incomplete dimensional context instead of fake completeness.
- **stable noun identity** — let promoted fields survive rename/label drift without forcing a giant registry now.
- **thin semantic spine** — steal relation-spine discipline without freezing current product taxonomy as law.
- **derived acceleration view** — keep pre-aggregations and read models visibly downstream from cube truth.

## Pass XLV additions
- **grain card** — say exactly what one row/event/snapshot means before dimensions or facts multiply.
- **accumulation class** — keep snapshot, delta, cumulative, and derived/query-shaped values visibly distinct.
- **reduction fence** — mark additive, semi-additive, non-additive, approximate, or derived-only posture instead of hoping dashboards remember.
- **unit metadata over name cargo** — keep units explicit and adjacent rather than smuggled into field names.
- **additive-components first** — prefer sum/count-style components plus later formulas when a friendly result does not reduce cleanly.
- **query-result is not fact** — keep live search counts, support summaries, and other evaluated views smaller than atomic cube truth.

## Pass XLVI additions
- **population frame** — declare the eligible universe before totals or percentages start sounding authoritative.
- **overlap class** — mark whether sibling buckets are disjoint, overlapping, primary-picked, or unknown.
- **coverage witness** — carry full-frame, subset, sampled, lagging, or explicit-coverage posture with the result.
- **denominator inherits from frame** — treat “total” as a derived claim from a declared population, not a dashboard afterthought.
- **partition is earned, not assumed** — only let buckets add cleanly when disjointness is actually proven.

## Pass XLVII additions
- **identity anchor** — keep stable member/field identity distinct from current display names and paths.
- **label snapshot** — preserve the observed human-facing label at one cut without turning it into the join key.
- **axis budget** — review whether a label family is bounded enough to support grouping before promoting it into cube law.
- **rename is metadata, not rebirth** — treat many title/path moves as evolution of description rather than delete-and-recreate truth.
- **display-only labels stay useful** — let unstable or high-cardinality labels support search/review/drill-through without becoming first-class dimensions.
## Pass XLIX additions
- **exactness class** — exact-at-cut, bounded-estimate, advisory-rank, or query-shaped-only posture carried beside the value.
- **bound witness** — explicit algorithm/parameter/error/confidence or ranking-basis residue for any non-exact value.
- **correction horizon** — visible restatement/finalization window for values still exposed to late arrival or snapshot drift.
- **estimate smaller than exact** — a standing anti-folklore rule.
- **advisory smaller than authority** — a standing anti-regrowth rule for rank-like outputs.

## Pass L additions
- **input cut** — exact source snapshot/revision/partition/window/fact-epoch used for one derived value.
- **recipe witness** — compact query/transform/parameter/plan residue for how the value was produced.
- **replay class** — replayable-from-pins, conditionally-restatable, snapshot-advisory, or non-replayable-hint.
- **pin-over-branch rule** — a standing anti-regrowth rule: floating selection intent is smaller than the immutable source cut actually used.
- **execution-path metadata** — a standing anti-regrowth rule: derivation residue should come from the real execution/materialization path, not side hooks or memory.

## Pass LI additions
- **loss class** — explicit statement of what fidelity changed: row-preserving, attribute-lossy, bucketized, sketch-like, or summary-only.
- **exemplar anchor** — bounded breadcrumb to one or a few concrete contributing artifacts outside the summary itself.
- **raw-retention fence** — visible posture for whether narrower evidence is retained hot, retained cold, policy-blocked, or expired.
- **projection smaller than source truth** — a standing anti-regrowth rule for sticky acceleration artifacts.
- **breadcrumb smaller than lineage graph** — a standing anti-regrowth rule for drill-through honesty without ontology sprawl.

## Pass LII additions
- **view lens** — explicit witness for which view/export/policy cut shaped a visible value.
- **disclosure class** — public, sanitized, masked, threshold-gated, or sensitive-visible payload posture.
- **comparability fence** — same-lens-only, threshold-gated, monotone-only, or non-comparable cross-lens semantics.
- **visible smaller than universal** — a standing anti-regrowth rule.
- **same-number smaller than same-truth** — a standing anti-folklore rule for policy-shaped values.

## Pass LIII additions
- **selection recipe** — compact witness for predicate, view binding, and ordering residue behind one query-shaped result.
- **window cut** — explicit page/cursor/truncation slice for the currently visible rows.
- **total mode** — exact, lower-bound, estimated, page-local, or unknown total posture.
- **page smaller than population** — a standing anti-regrowth rule.
- **total smaller than whole truth unless mode is explicit** — a standing anti-folklore rule.

## Pass LIV additions
- **watermark frontier** — compact progress/completeness lower-bound for one time-bucketed family.
- **closure class** — preview, on-time, reopenable, or finalized posture beside the current value.
- **lateness aperture** — allowed lateness, grace, lookback, or manual-restatement window kept explicit.
- **frontier smaller than finality** — a standing anti-regrowth rule.
- **freshness smaller than completeness unless the aperture is explicit** — a standing anti-folklore rule.


## Pass LV additions
- **rank recipe** — compact witness for what actually produced an ordering.
- **score family** — explicit local meaning for BM25, distance, fusion, reranker, or unscored rows.
- **tie-break witness** — small residue for how equal-score windows stay reproducible.
- **score smaller than meaning** — a standing anti-regrowth rule.
- **ordered page smaller than population truth** — a standing anti-regrowth rule.

## Pass LVI additions
- **arbitration recipe** — compact witness for how competing candidates were reconciled or refused.
- **ambiguity class** — explicit posture for unique, tie-broken, underdetermined, rejected, or manual-resolution outcomes.
- **dissent retention** — visible posture for whether losing candidates remain inspectable, summarized, counted, or dropped.
- **winner smaller than settlement** — a standing anti-regrowth rule.
- **survivorship smaller than truth** — a standing anti-folklore rule.

## Pass LVII additions
- **sample class** — compact witness for census versus partial-cut posture.
- **inclusion basis** — compact residue for how rows entered the visible sample.
- **expansion fence** — compact guardrail for whether population-level scaling is lawful.
- **preview smaller than census** — a standing anti-regrowth rule.
- **factor/probability breadcrumb** — explicit residue when sampled output is meant to inform a wider estimate.

## Pass LVIII additions
- **unit witness** — compact residue for what unit or count-like non-unit a visible value actually carries.
- **canonical scale** — compact residue for the preferred interchange scale for storage, comparison, and aggregation.
- **conversion fence** — compact guardrail for whether conversion is linear, affine, display-only, contextual, or forbidden.
- **pretty scale smaller than truth** — a standing anti-folklore rule.
- **arbitrary unit smaller than comparability** — a standing anti-regrowth rule.

## Pass LIX additions
- **reset anchor** — compact residue for what re-bases a cumulative- or allowance-shaped family.
- **carry class** — compact residue for what survives that boundary.
- **continuity fence** — compact guardrail for whether cross-boundary stitching is lawful.
- **anchor smaller than lifetime total** — a standing anti-folklore rule.
- **carryover smaller than arithmetic intuition** — a standing anti-regrowth rule.
## Pass LX additions
- **allocation basis** — compact witness for how a shared total was split.
- **residue class** — compact witness for what stayed specially treated or unallocated.
- **apportionment fence** — compact guardrail for what recombination or comparison is lawful.
- **allocated smaller than native** — a standing anti-folklore rule.
- **leftover smaller than disappearance** — a standing anti-regrowth rule.
## Pass LXI additions
- **adjunct namespace** — bounded lane for provisional metadata that is useful before it deserves cube-wide law.
- **schema pin** — immutable pointer to the exact meaning of one adjunct payload.
- **promotion gate** — local experiment, cross-surface candidate, promoted, rejected, or superseded posture for candidate semantics.
- **layout smaller than logic** — a standing anti-regrowth rule for partitions, rollups, and acceleration hints.
- **design-time smaller than runtime truth** — a standing anti-folklore rule for proposed versus observed metadata.

## Pass LXII additions
- **translation witness** — compact residue for the exact reviewed mapping from one schema pin to another.
- **compatibility lane** — native, lossless-translated, lossy-translated, deprecated-source, or incomparable result posture.
- **upgrade fence** — compact refusal boundary against silent latest-version normalization.
- **source pin smaller than latest** — a standing anti-folklore rule.
- **translated smaller than identical** — a standing anti-regrowth rule.

## Pass LXIII additions
- **support witness** — compact residue for which required and optional meaning families one reader/export path actually understood.
- **unknown residue** — bounded preserved unread payload/enum/adjunct breadcrumb for later drill-through.
- **falsehood fence** — compact refusal boundary against coercing unread semantics into `false`, `none`, `0`, or “not applicable”.
- **required-smaller-than-optional support split** — a standing anti-folklore rule from JSON Schema-style vocabulary handling.
- **preserved smaller than understood** — a standing anti-regrowth rule for unknown carryover residue.

## Pass LXIV additions
- **profile card** — compact residue for which extra profile/convention bundle shaped one consumer/export reading.
- **precedence lane** — compact residue for whether profiles were absent, singular, ordered, or conflict-refused.
- **overlay fence** — compact refusal boundary against profiles silently mutating base subject/measure/schema truth.
- **profile smaller than base meaning** — a standing anti-folklore rule.
- **opt-in overlay smaller than ambient default** — a standing anti-regrowth rule.

## Pass LXV additions
- **interpretation cut** — compact residue for the exact semantic/model/profile/history cut that produced a historical answer.
- **restatement lane** — compact residue for original published reading, same-cut replay, translated restatement, or current-hindsight projection.
- **hindsight fence** — compact refusal boundary against silently replacing original history with current semantics.
- **immutable version smaller than timestamp folklore** — a standing reproducibility rule.
- **restate smaller than overwrite** — a standing anti-regrowth rule.

## Pass LXVI additions
- **ordering basis** — compact residue for which clock or field actually ordered the visible winner or history cut.
- **mutation lane** — compact residue for whether a row is a current snapshot, historical version, change event, invalidation/tombstone, or descriptor-not-state.
- **revision witness** — compact residue for whether the visible answer is subject to revision, complete for a cut, bounded by change-history windows, or source-claimed final.
- **snapshot smaller than mutable truth** — a standing anti-folklore rule.
- **disappearance smaller than delete semantics** — a standing anti-regrowth rule.

## Pass LXVII additions
- **contribution basis** — compact residue for what got counted once: subject, association row, target row, or sketch family.
- **fanout class** — compact residue for native rows, deduped one-to-many, bridge many-to-many, higher-grain projection, approximate decomposition, or refused chasm.
- **reaggregation fence** — compact refusal boundary against drilling or summing below the lawful level.
- **counted-once smaller than numeric-looking** — a standing anti-folklore rule.
- **bridge truth smaller than additive truth** — a standing anti-regrowth rule.

## Pass LXVIII additions
- **denominator basis** — compact residue for what the visible ratio divided by.
- **normalization lane** — compact residue for how numerator and denominator were aligned before division.
- **ratio fence** — compact refusal boundary against reusing a denominator-sensitive or display-only ratio as raw cube truth.
- **per-smaller-than-label** — a standing anti-folklore rule.
- **display ratio smaller than reusable fact** — a standing anti-regrowth rule.

## Pass LXIX additions
- Keep **clusters** separate from **representatives**.
- Require an explicit **survivorship witness** before a UI/export gets a winner row.
- Preserve drill-through to originals even when a representative row is convenient.
- Treat a **golden row** as a local convenience until repeated pressure proves it belongs in core ontology.

## Pass LXX additions
- Keep **provenance**, **quality annotation**, **validation result**, **policy verdict**, and **heuristic score** visibly distinct.
- Make **confidence basis** explicit and let missing confidence stay unspecified.
- Keep **warnings** and **advisory hints** smaller than failures or source truth.
- Put a **verdict fence** around local approval and heuristic outcomes so they cannot silently become ontology.

## Pass LXXI additions
- Keep **unknown**, **masked**, **not applicable**, **unsupported**, **delete-sentinel**, and **implicit-default-absent** visibly distinct.
- Make **applicability basis** explicit so profile exclusion and workflow omission stay smaller than falsehood.
- Put a **coercion fence** around blanks so serializers, patches, and dashboards cannot silently turn them into tidier facts.
- Treat a **rectangular null** as a transport convenience until repeated pressure proves it belongs in core ontology.



## Pass LXXII additions
- **eligibility basis** — compact residue for why a subject/event/window belonged to the measured world.
- **exclusion class** — compact residue for how non-claims, waivers, or rule-based narrowing removed other candidates.
- **whole-world fence** — compact guardrail for where a scoped summary must not impersonate archive-wide truth.
- **eligible smaller than total** — a standing anti-folklore rule.
- **summary smaller than subject-list truth** — a standing anti-regrowth rule.

## Pass LXXIII additions
- Keep **band class** explicit so badges, percentile bands, and buckets do not masquerade as the same species.
- Preserve the **threshold basis** that produced a band instead of assuming labels are timeless.
- Put a **scalarization fence** around ordinal, display-local, or threshold-drifted outputs before anyone averages or re-aggregates them.
- Treat a **colored badge** as a view convenience until repeated pressure proves it belongs in core ontology.



## Pass LXXIV additions
- **thin semantic spine** — keep member identity, counted-once posture, and replay cuts explicit without freezing a giant semantic-layer taxonomy.
- **serving lane** — compact residue for whether a value came from row-preserving base truth, a materialized summary, a rollup, or another acceleration path.
- **acceleration witness** — compact residue for the exact matching/materialization path that served a summary-backed answer.
- **raw fallback fence** — compact guardrail for whether row-preserving drill-through still exists, exists cold, or is intentionally absent.
- **mutable-head fence** — compact refusal boundary against treating branch/head/default-latest selection intent as the same thing as a pinned cut.
- **historical-tag witness** — compact replay breadcrumb for an intentionally retained immutable cut that should survive later head movement.
- **run/assertion smaller than fact** — a standing anti-regrowth rule for execution residue, lineage, and validation outcomes.

## Pass LXXV additions
- **browser mediation lane** — scoped evidence lane for browser/user-agent mediated sign-in or credential presentation flows.
- **identity hint fence** — refusal boundary against login hints, domain hints, account labels, chooser rows, or Login Status values becoming current-user truth.
- **origin-pair cut** — compact scope marker for relying-party/provider relationships before anyone invents a global identity graph.
- **prompt-basis witness** — residue for what activation/prompt/permission UX occurred, explicitly smaller than legal consent or approval basis.
- **disconnect choreography witness** — scoped breadcrumb for provider-local unlink/disconnect flows that do not revoke every related relation.
- **trust-chain witness** — replayable breadcrumb for exact entity statements, trust anchor, metadata policy, resolver output, and cut used for one trust-bootstrap decision.
- **trust-mark witness** — scoped badge residue that carries issuer/mark/federation/cut instead of pretending to be global trust.
- **credential-presentation opacity fence** — guardrail around encrypted, opaque, selective-disclosure, or ZKP-shaped responses.
- **issuer-suitability fence** — reminder that a valid signature is not a local policy decision that this issuer is fit for this purpose.
- **grain card before family promotion** — require one-row meaning before dimensions, measures, slices, or serving names get promoted.


## Pass LXXVI additions
- **query contract** — compact residue for request family, source family, predicate/schema/parameter digest, policy lens, cut, engine/profile, plan digest, and replay class.
- **result envelope** — compact wrapper for served-from posture, materialization digest, source cut, page/window, row-count posture, order posture, disclosure lens, freshness posture, and replay class.
- **validation witness** — compact residue for check-suite digest, target, cut, checker version, check class, outcome, scope, and severity.
- **ordering posture** — stable, unordered, tie-broken, page-local, output-only, or unknown result-order honesty.
- **row-count posture** — exact, bounded, estimated, omitted, policy-masked, relation-qualified, or page-local count honesty.
- **contract subset** — the part of a wider contract that actually governed one result.
- **axis/coordinate card** — logical dimension/coordinate/variable residue that stays smaller than storage chunking or catalog layout.
- **catalog card smaller than truth** — discovery metadata remains distinct from lineage, quality, validation, and trust.
- **validated smaller than true** — a standing anti-regrowth rule for green checks and suite-success folklore.

## Pass LXXVII additions
- **hierarchy scope** — compact residue for scheme/version, member cut, parent relation kind, valid combinations, availability basis, presentation order, and default-member posture.
- **rollup path** — compact witness for source grain, target level, hierarchy path, calendar/geography lens, membership posture, reparenting posture, and recipe digest.
- **aggregation guard** — compact permission/refusal card for additive, semi-additive, non-additive, bridge-shaped, ratio-derived, distinct-count, sampled, masked, banded, or refused rollups.
- **calendar lens** — explicit week-start, min-days, timezone, fiscal start, ISO/Gregorian/reporting-year posture for time buckets.
- **geography lens** — explicit administrative, statistical, legal-boundary, grid-cell, or presentation-region posture for spatial parent rows.
- **availability basis** — exact constraint/query/cut that made coordinates populated, valid, unavailable, suppressed, or unknown.
- **storage-layout fence** — standing guardrail that folder paths, partitions, chunks, and manifests do not create semantic hierarchy.
- **parent smaller than total** — a standing anti-folklore rule for hierarchy-shaped displays.

## Pass LXXVIII additions
- **materialization cut** — compact residue for recipe, source cut, build run, dependency cards, policy/disclosure lens, and materialized-object digest.
- **refresh witness** — compact residue for refresh mode, trigger, frontier/watermark, observed lag, invalidation cause, failure/skip/partial posture, and validation outcome.
- **reuse fence** — compact permission/refusal card for whether one served object may answer another request, page, audience, policy lens, or stale fallback.
- **vary basis** — explicit reuse dimensions such as principal, parameter, policy, locale/calendar, schema/profile, hierarchy, and disclosure lens.
- **cache-status witness** — hit/miss/forward/revalidate/collapsed/stored/ttl-style debugging residue for datacube serving.
- **stale smaller than current** — a standing anti-folklore rule for stale-if-error and stale-while-revalidate shaped outputs.

## Pass LXXIX additions
- **disclosure cut** — compact residue for release policy, audience/lens, protected-unit basis, source cut, query contract, release-set id, method family, contribution bounds, threshold/budget posture, and review run.
- **suppression witness** — compact per-result/cell state for released, primary-suppressed, complementary-suppressed, coarsened, rounded, perturbed, noisy, budget-refused, policy-refused, or not-run.
- **differencing fence** — compact permission/refusal card for comparison, subtraction, joins, drilldown, cache reuse, reissue, and neighboring releases.
- **release-set id** — table/batch family that was evaluated together for suppression, perturbation, or privacy-budget accounting.
- **protected-unit basis** — explicit entity being protected, kept separate from row grain and display denominator.
- **budget-spend witness** — epsilon/delta/noise/query-count-style residue that stays smaller than a privacy guarantee.
- **zero-not-released rule** — suppressed or budget-refused cells must not be chart-filled, exported, or joined as zero.
- **same-release-set-only comparison** — safe default for comparing suppressed, perturbed, or threshold-gated aggregates.
- **no-subtraction lane** — explicit refusal for totals/subtotals where differencing could reconstruct a hidden sibling cell.

## Pass LXXX additions
- **observation-status card** — compact value-adjacent residue for observedness, imputation, adjustment, provisionality, revision, forecast, processor-derived, and quality-flag posture.
- **adjustment witness** — tiny method/recipe/model/input/diagnostic card for values produced by imputation, smoothing, seasonal-like adjustment, benchmarking, processor summaries, or manual correction.
- **as-observed fence** — guardrail that says where a value cannot impersonate direct observation, raw denominator input, source-history backfill, or status-free export.
- **vintage cut** — publication/access/release cut for mutable series where an older visible value remains historically citeable after revision.
- **unadjusted companion pointer** — optional raw/original value breadcrumb when retention and policy allow it.
- **cell-methods-style residue** — steal CF's concise “axis: method” instinct without importing a full climate/netCDF data model.
- **quality flags as self-describing sidecars** — steal CF's flag-values/flag-meanings humility without pretending flags are verdicts.
- **status-preserving export sidecar** — let status travel through thin JSON/chart surfaces when the consumer cannot carry full cube metadata.

## Pass LXXXI additions
- **control-total card** — compact residue for total kind, scope, measure, unit, source cut, lens, and tolerance basis.
- **reconciliation witness** — rule/profile digest, component-set digest, operator/weights, checker/run, outcome, residual, residual class, severity, and evidence grade.
- **balance fence** — local permission/refusal card for charting, export, subtraction, drilldown, reuse, force-balancing, and exactness claims.
- **same-cut balance default** — do not reconcile across policy, schema, calendar, hierarchy, vintage, or materialization cuts unless a cross-cut rule explicitly authorizes it.
- **visible residual row** — publish an explicit residual when helpful instead of hiding it in a fake other bucket.
- **suppression-aware balance posture** — visible components may intentionally not sum when hidden siblings are protected.
- **mirror-check witness** — keep independent-source checks separate from within-table arithmetic.
- **not-run outcome** — a first-class check posture for design-phase, streaming, missing-evidence, or policy-blocked results.

## Pass LXXXII additions
- **classification pin** — compact residue for scheme/value-set/profile id, version or revision cut, namespace, member id, display label, label language, deprecation posture, and steward.
- **crosswalk witness** — source pin, target pin, mapping/correspondence-table digest, direction, use context, relation kind, cardinality, coverage, reviewer, confidence/evidence grade, and not-mapped reason.
- **code-drift fence** — local permission/refusal card for comparison, grouping, relabeling, backcasting, joining, exporting, and drilling across category revisions.
- **same-code-not-same-concept default** — refuse cross-scheme grouping unless a reviewed crosswalk witness says what relationship exists.
- **label-not-key rule** — pretty labels can display but cannot prove semantic identity.
- **old-lens display** — let historical rows remain legible under their native classification cut instead of forcing current labels.
- **reviewed-backcast lane** — allow reprojected history only when the mapping, assumptions, cardinality, and refusal boundaries are explicit.
- **unknown-code pocket** — preserve syntactically present but semantically unresolved codes without flattening them into null, zero, current `other`, or failure.

## Pass LXXXIII additions
- **residue sidecar** — compact digest-linked carrier for semantic meaning that a thin egress surface cannot carry in-band.
- **flattening refusal** — explicit refusal when a requested chart, CSV, JSON, table, support card, or markdown shape would shed required residue.
- **egress survival check** — tiny deterministic fixture proving that meaning survives export or the export fails.
- **decision-debt index** — sort open promotion questions by missing executable pressure rather than chronology.
- **projection honesty** — standing rule that useful surfaces may be thinner than source truth, but not allowed to impersonate it.

## Pass LXXXIV additions
- **refusal receipt** — compact artifact for a blocked egress attempt, including rule id, requested surface, semantic loss, problem details, and repair escapes.
- **egress manifest** — batch-local ledger of emitted and refused surfaces tied to sidecars or receipts.
- **conformance gate** — deterministic local rule suite for sidecar-or-receipt discipline.
- **semantic-loss list** — explicit inventory of meaning that would be dropped by a requested shape.
- **repair escape** — safe alternative request path, kept distinct from automatic repair or approval.
- **problem-details without transport capture** — steal typed machine-readable refusal while refusing to become an HTTP/API error taxonomy.


## Pass LXXXV additions
- **canonicalization as a witness, not a verdict** — steal RFC 8785's digestable-byte discipline while refusing to make a hash mean semantic compatibility.
- **path-scoped tamper syntax** — steal JSON Patch's compact operation shape for regression fixtures without turning patch application into migration authority.
- **fixture-local regression locks** — borrow SlopOS-style corpus/checker discipline so egress residue changes fail before they become folklore.
- **non-SlopOS consumer pressure** — require at least one outside consumer before widening a field family beyond SlopOS-shaped support surfaces.
- **migration witness smaller than backcast** — let a bounded witness explain one compatible change without promising automatic history rewrite.


## Pass LXXXVI additions
- **waiver warrant** — compact bounded-exception carrier for owner, reviewer, scope, linked alarm, allowed loss, and non-waivable residue.
- **expiry witness** — machine-readable valid/expired/rejected/renewal posture for exception windows.
- **exception replay gate** — list of refusal, regression, and waiver rules that rerun before use, renewal, or revision carry-forward.
- **scope-widening refusal** — default refusal when a temporary exception tries to cover a new consumer, cut, surface, revision, or rule family.
- **suppression triage without triage capture** — steal SARIF's explicit suppression/status instinct without becoming a static-analysis workflow.
- **decision replay without policy capture** — steal OPA's durable decision-id/logging instinct without owning policy authority.

## Pass LXXXVII additions
- **consumer passport** — compact carrier for target-consumer id, kind, purpose, audience, required residue, authority boundaries, and forbidden inferences.
- **portability witness** — compact source-consumer/target-consumer witness naming portable and non-portable residue plus required gates.
- **interpretation gate** — local rule gate that reruns egress, regression, waiver, and portability checks before a carried surface is used under a new consumer.
- **actor-relative quality without quality capture** — steal W3C DQV's actor-relative instinct without creating a Foundry scoring or certification system.
- **discovery humility without catalog capture** — steal DCAT's separation of discovery metadata from provenance, quality, and trust without becoming a catalog product.
- **provenance without verdict** — steal PROV's entity/activity/agent posture while keeping quality, reliability, trust, and sibling-cube authority outside Foundry.


## Pass LXXXVIII additions
- **delegation warrant** — compact carrier for grantor consumer, delegate, relying consumer, acts, scope, expiry, revocation status, delegated residue, and withheld residue.
- **reliance receipt** — compact record of a relying consumer checking a warrant, rerunning rules, preserving residue, and refusing inferences.
- **transitive-use fence** — local refusal card for redelegation, audience widening, purpose widening, verdict transfer, and sibling-authority claims.
- **actor-chain trace without token capture** — steal RFC 8693's actor-history instinct without adopting OAuth tokens or access-control doctrine.
- **presentation specificity without credential capture** — steal VC's holder/verifier/selective-disclosure separation without creating a credential system.
- **relying-party appraisal without attestation capture** — steal RATS's relying-party policy/freshness instinct without becoming an attestation protocol.

## Pass LXXXIX additions
- **revocation notice** — compact carrier-status overlay for id, digest, reason, scope, affected consumers, required actions, and propagation deadline.
- **recall receipt** — compact consumer-local acknowledgment that records quarantine, replay, replacement, refusal, and preserved history.
- **stale-reliance fence** — local refusal card for old digests, revoked warrants, withdrawn waivers, stale cache hits, and silent supersession.
- **status without deletion** — steal revocation/status-list instincts while keeping old evidence citeable and bounded.
- **stale metadata alarm** — steal update-framework rollback/freeze pressure so unchanged bytes do not outrank missed notices.
- **cache quarantine lane** — isolate stale surfaces without making Foundry a cache-control or retention system.

## Pass XC additions
- **remediation packet** — a small work envelope for one recalled semantic carrier, notice scope, quarantine set, candidate replacements, required witnesses, and replay gates.
- **replacement witness** — a bounded old/new carrier relation that records digests, correction classes, evidence refs, gate replay, residual risk, and non-promises.
- **readmission gate** — consumer-local decision that releases or refuses specific uses after recall without becoming approval, verdict, repair completion, or source truth.
- **subject/predicate binding without attestation capture** — steal in-toto's subject/predicate discipline while refusing to become a signed supply-chain attestation system.
- **provenance separation without build trust capture** — steal SLSA's produced-by/build-definition/materials instinct while keeping semantic replacement smaller than software supply-chain trust.
- **remediation status without advisory capture** — steal CSAF's subject/action/status pressure while refusing vulnerability-advisory or incident-governance capture.

## Pass XCI additions
- **distribution manifest** — compact envelope for post-readmission carrier digests, superseded carriers, target consumers/surfaces, delivery channels, propagation windows, and required receipts/fences.
- **adoption receipt** — consumer/surface-local record of adopted, partial, refused, quarantined, or superseded carrier use with old-copy retirement and blocked uses.
- **orphan-copy fence** — local refusal card for stale cached, exported, notebook, projected, or delegated copies that remain after distribution.
- **event envelope without eventing capture** — steal CloudEvents' common metadata instinct without choosing a message bus or transport binding.
- **freshness/revalidation without cache-control capture** — steal RFC 9111's stale/fresh separation while keeping Foundry out of cache policy.
- **subject-linked artifacts without registry capture** — steal OCI referrers' subject/digest graph posture without becoming a registry or package distribution system.
- **visibility without accuracy capture** — steal transparency-log accountability pressure without making inclusion or delivery equal semantic adoption.

## Pass XCII additions

- Steal NIST CM-8's inventory granularity/no-duplicate/accountability scar, but not its control-program scope.
- Steal OpenLineage symlink/alias humility, but not a lineage platform.
- Steal Kubernetes owner/dependent scoped cleanup caution, but never let owner references become semantic authority.

## Pass XCIII additions
- **exposure ledger** — compact carrier for source inventory, intended audiences, observed surfaces, purposes, access modes, method limits, and non-promises.
- **audience witness** — observed audience/surface/access-purpose evidence that stays smaller than authorization, consent, public release, or audit opinion.
- **purpose fence** — local refusal card for unknown readers, public links, inherited groups, purpose widening, access-mode widening, expired evidence, or missing authority.
- **party/action/constraint without policy capture** — steal ODRL's modeling instinct while refusing rights-language or policy-execution scope.
- **subject/object/action/environment without ABAC capture** — steal NIST ABAC's separation while refusing to decide authorization.
- **audience specificity without token capture** — steal JWT/OAuth resource-audience explicitness while staying out of authentication and access-token infrastructure.

## Pass XCIV additions
- **obligation ledger** — compact carrier for source exposure, carrier ids, scope, obligations, required acknowledgments, and authority boundaries.
- **acknowledgment witness** — consumer-local record of acknowledged, partial, refused, quarantined, or missing obligation carriage.
- **obligation-drift fence** — refusal card for dropped sidecars, downgraded no-reexport, missing recall routes, public links, inherited groups, wrong-consumer acknowledgments, and sibling-boundary laundering.
- **duties without rights-engine capture** — steal ODRL's duty/constraint instinct while refusing policy-execution scope.
- **obligation/advice separation without authorization capture** — steal XACML's separation between decisions and follow-up obligations while refusing to decide access.
- **purpose/recipient metadata without privacy-law capture** — steal DPV's machine-readable context while keeping Foundry out of consent and compliance systems.

## Pass XCV additions
- **fulfillment receipt** — compact closure carrier for acknowledged obligations, due windows, completion evidence, unresolved fences, and authority boundaries.
- **completion witness** — consumer-local record that a specific semantic duty was completed, partial, pending, missed, refused, or quarantined.
- **nonfulfillment fence** — refusal card for missing, late, wrong-scope, public-link, inherited, digest-mismatched, or authority-laundered fulfillment.
- **finalizer-style blocking without controller capture** — steal Kubernetes finalizers' wait-for-cleanup scar while refusing deletion or scheduling authority.
- **activity evidence without provenance verdict capture** — steal PROV's entity/activity/agent linkage while refusing quality, trust, audit, or truth verdicts.
- **duty discharge without policy capture** — steal XACML/ODRL's distinction between obligation and discharge while refusing authorization or rights-management scope.

## Pass XCVI additions
- **verification audit** — compact review packet for source fulfillment receipts, completion witnesses, sample basis, verifier posture, required samples, and boundaries.
- **evidence sample** — scoped probe result that can be verified, contradicted, stale, unavailable, inconclusive, quarantined, or superseded.
- **false-closure fence** — refusal card for completion claims contradicted by samples, self-verification, stale probes, public links, inherited scope, or authority laundering.
- **assessment scope without compliance capture** — steal OSCAL's assessed-what/how/who/finding posture without becoming a compliance report.
- **verification result without cryptographic-proof capture** — steal VC Data Integrity's explicit verified/errors/warnings instinct without adopting credentials or signatures.
- **expected evidence without supply-chain capture** — steal in-toto verification's layout/evidence/rule/expiry pressure without becoming a build provenance verifier.
- **shared check harness without framework capture** — refactor runner and helpers enough to prevent checker-registration drift without hiding specimen-specific seams.

## Pass XCVII additions
- **recheck cadence** — compact trigger/interval/grace-window carrier for when old verification must be distrusted again.
- **drift signal** — scoped probe result for clear, warning, firing, stale, missing, flapping, superseded, or quarantined semantic state.
- **stale-verification fence** — refusal card for missed cadences, risky signals, paused-as-active reuse, public-link drift, and alert-as-truth laundering.
- **pending/firing without alerting capture** — steal Prometheus' duration and anti-flapping instincts without becoming a monitoring or pager system.
- **periodic probes without control-plane capture** — steal Kubernetes probe discipline without deciding lifecycle, scheduling, traffic, or readiness truth.
- **coverage manifest** — small harness inventory that keeps schemas, fixtures, checkers, and runner registration from drifting invisibly.

## Pass XCVIII additions
- **escalation packet** — compact carrier for risky drift signals, source cadences, source fences, scope, route basis, receivers, required witnesses, and required unresolved fences.
- **routing witness** — compact route observation for delivered, acknowledged, deduplicated, inhibited, quarantined, missing, misrouted, or stale packet handling.
- **unresolved-signal fence** — refusal card for missing route, misroute, stale ack, inhibition, dedupe loss, scope mismatch, public route gaps, and sibling-boundary laundering.
- **routing without alerting capture** — steal Alertmanager grouping/routing/deduplication/inhibition scars without becoming a monitoring or pager system.
- **incident lifecycle humility** — steal NIST incident-response lifecycle caution without letting Foundry declare incidents, recovery, remediation, or closure.
- **event occurrence without truth capture** — steal event-at-a-time posture from telemetry systems while refusing continuing freshness or authority.
- **specimen-doc coverage** — small manifest tying specimen docs to rulebooks, fixtures, schemas, checkers, runner entries, and docs map.


## Pass XCIX additions
- **disposition ledger** — compact carrier for routed packets, route witnesses, unresolved-signal fences, disposition status, review basis, required resolution witnesses, residual fences, and authority boundaries.
- **resolution witness** — scoped evidence for closed, partial, deferred, transferred, quarantined, reopened, false-positive, or duplicate disposition without turning closure into authority.
- **premature-closure fence** — refusal card for missing evidence, unresolved source fences, stale closure, false-positive-without-evidence, scope widening, public-release laundering, repair/lifecycle laundering, and sibling-verdict laundering.
- **issue-status without compliance capture** — steal OSCAL POA&M's status/task discipline without becoming a compliance issue tracker.
- **subject/status/remediation without advisory capture** — reuse CSAF's scoped status instinct while refusing vulnerability/advisory/remediation authority.
- **active maintenance without governance capture** — steal RFC 9413's ambiguity-reduction posture while keeping Foundry fixtures local and falsifiable.
- **negative-case coverage manifest** — small audit/refactor surface tying fixtures, rulebooks, checkers, runners, and hard failure cases together.


## Pass C additions
- **precedent ledger** — compact carrier for source dispositions, resolution witnesses, premature-closure fences, scope, target rule surfaces, and authority boundaries.
- **rule-promotion witness** — local proof that a precedent is promoted, partial, rejected, shadow-only, test-failed, deprecated, or superseded with positive/negative cases.
- **overgeneralization fence** — refusal card for single-case generalization, scope widening, false-positive generalization, stale precedent, unresolved-fence erasure, and authority laundering.
- **policy tests without policy-engine capture** — steal OPA's test-next-to-policy instinct while refusing policy decisions and enforcement scope.
- **admission-boundary caution without control-plane capture** — steal Kubernetes admission-policy structure while refusing authorization or mutation authority.
- **lifecycle transition coverage** — small handoff manifest tying late executable specimens together without pretending the lifecycle is complete or canonical.

## Pass CI additions
- **rule-collision ledger** — compact carrier for overlapping promoted/candidate/shadow/deprecated rules, source precedents, overlap scope, and required fences.
- **precedence witness** — scoped evidence that one rule wins, partially wins, is refused, is shadow-only, expired, or superseded for a named surface and purpose.
- **ambiguity fence** — refusal card for unresolved overlap, contradictory outcome, stale/deprecated/shadow rule use, checker/rulebook drift, and authority laundering.
- **unambiguous query pressure without policy-engine capture** — steal OPA/Rego's clarity instinct while refusing policy decisions.
- **multi-binding failure behavior without admission-control capture** — steal Kubernetes' explicit match/failure behavior while refusing control-plane authority.
- **profile resources without compatibility-registry capture** — steal W3C Profiles' resource-linking instinct while refusing profile negotiation or governance.
- **rule-surface index** — small manifest tying rulebooks, rule ids, checkers, and runner registration together without becoming a rule engine.

## Pass CII additions
- **rule-evaluation trace** — compact carrier for source collisions, precedence, ambiguity fences, candidate/selected/skipped rules, context, output, and blocked inferences.
- **applicability witness** — scoped record that a rule was applicable, not applicable, partial, ambiguous, expired, or shadow-only for the exact subject.
- **misapplication fence** — refusal card for wrong context, precedence-as-application, skipped-rule erasure, default/deprecated/shadow activation, and authority laundering.
- **evaluation context without feature-flag capture** — steal OpenFeature's context/details split while refusing flag infrastructure.
- **schema-bound validation without authorization capture** — steal Cedar's context/action validation caution while refusing access-control decisions.
- **checker-contract index** — small harness map tying runner order, checker path, primary fixture/rulebook, and success output together without proving checker correctness.

## Pass CIII additions
- **rule-effect ledger** — compact carrier for source rule-evaluation traces, intended effects, bound effects, required witnesses, bypass fences, and authority boundaries.
- **effect witness** — scoped evidence that a rule result was applied, partial, refused, missing, bypassed, quarantined, or superseded.
- **bypass fence** — refusal card for selected-rule-as-effect, weak-result laundering, wrong surface, stale/default/deprecated/shadow effect, checker-success-as-effect, reference drift, and authority laundering.
- **effect modes without admission-control capture** — steal Kubernetes' Deny/Warn/Audit distinction while refusing control-plane enforcement scope.
- **decision/effect separation without authorization capture** — steal XACML's result/obligation/advice caution while refusing access-control decisions.
- **reference-integrity index** — small manifest tying source fixture collections and id fields to referencing fixtures without becoming a catalog or lineage graph.
