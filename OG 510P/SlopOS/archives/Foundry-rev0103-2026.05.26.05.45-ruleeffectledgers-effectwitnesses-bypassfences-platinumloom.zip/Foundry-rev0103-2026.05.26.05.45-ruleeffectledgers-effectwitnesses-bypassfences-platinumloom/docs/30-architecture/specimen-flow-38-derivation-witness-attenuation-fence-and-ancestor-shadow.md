# Specimen flow 38 — derivation witness, attenuation fence, and ancestor shadow

Goal: keep a narrower descendant artifact or grant distinct from the stronger parent it came from, and keep ancestor state visibly load-bearing.

## Scenario
A foreign-backed realization already holds a live-valid artifact, lease, grant, or token.
It wants to let one helper, downstream service, or sidecar do less than the current holder can do.
The tempting mistake is to hand along the raw parent or to treat a newly minted child as if it had become independent truth.

There are three narrower truths that many systems flatten when they only say “delegated”, “exchanged”, or “downscoped”.

First, there is a **derivation witness**.
One usable child may exist only because one exact parent lineage, one exact derivation event, and one exact descendant artifact can all still be named together.
That keeps “a child exists” distinct from “the parent was handed out raw”.

Second, there is an **attenuation fence**.
One child may only remain honest because it narrows target, action set, audience, time, use budget, or condition relative to the parent.
That keeps “derived” distinct from “same power in nicer packaging”.

Third, there is an **ancestor shadow**.
Parent expiry, revocation, consumption, or lineage-level invalidation can still narrow or void descendant truth.
That keeps “child artifact still parseable” distinct from “child still honestly usable now”.

This preserves three truths:
- which exact parent-child derivation happened,
- how the child was made smaller,
- and how ancestor state can still shadow descendant use.

## Proposed Foundry objects
1. **derivation witness**
   - exact parent-to-child lineage witness for one narrowed descendant artifact;
   - keeps child truth separate from raw-parent export folklore.

2. **attenuation fence**
   - explicit upper-bound narrowing across target, action, audience, time, use, or condition;
   - keeps downscope truth separate from ordinary rebinding or repackaging.

3. **ancestor shadow**
   - visible rule that parent or lineage state can still narrow descendant usability;
   - keeps descendant truth smaller than permanent standalone authority.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a product wants to hand a helper less power than the current holder has without exporting the raw parent;
- a downstream token or envelope is only acceptable because it is the intersection or upper bound of parent scope and child fences;
- old ancestor state such as revocation, expiry, or consumption should still matter to the descendant;
- and systems provide interesting caveat or third-party-proof ideas without forcing Foundry to standardize a generic delegation plane.

## Adjacent but parked
- **discharge witness** — future compact residue for third-party or contextual proof that satisfies one carried caveat without freezing a general caveat DSL.
- **actor-path card** — future compact residue for ordered multi-hop delegation history if later agentic/workflow specimens prove it belongs here.
- **caveat braid** — future compact residue for multiple independently narrowing conditions that should remain reviewable without becoming a policy language.

## Promotion rule
Do not promote `derivation witness`, `attenuation fence`, or `ancestor shadow` unless they improve:
- one SlopOS companion specimen where provider-local delegation/import machinery is explicitly smaller than portable account or session truth;
- one outside-system specimen where child permissions are an upper bound or intersection rather than an additive broadening;
- and one outside-system specimen where ancestor revocation, expiry, or lineage invalidation still shadows descendants.
