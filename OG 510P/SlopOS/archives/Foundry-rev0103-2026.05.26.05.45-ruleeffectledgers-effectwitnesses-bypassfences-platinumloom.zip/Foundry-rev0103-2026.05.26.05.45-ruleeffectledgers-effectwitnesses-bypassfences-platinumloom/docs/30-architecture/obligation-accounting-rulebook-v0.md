# Obligation accounting rulebook v0

This rulebook belongs to specimen 88. It defines tiny fixture-local checks for obligation ledgers, acknowledgment witnesses, and obligation-drift fences.

## Rules

- `R-OBL-001-OBLIGATION-LEDGER` — every post-exposure obligation-closure claim needs a ledger id, digest, status, time window, source exposure evidence, scope, obligations, required acknowledgments, and authority boundaries.
- `R-OBL-002-SOURCE-EXPOSURE-LINKAGE` — every obligation ledger must name source exposure ledgers, audience witnesses, purpose fences when relevant, and carrier ids.
- `R-OBL-003-OBLIGATION-PIN` — every obligation must be explicit and must name type, trigger, required residue, applies-to surfaces/audiences/purposes, and blocked inferences.
- `R-OBL-004-ACKNOWLEDGMENT-WITNESS` — every required consumer/surface/audience acknowledgment needs evidence, state, observed time, source exposure witness, obligations acknowledged, residue carried, and non-promises.
- `R-OBL-005-SCOPE-AND-DIGEST-CHECK` — acknowledgments may not exceed ledger scope and must preserve carrier digest linkage when a carrier is named.
- `R-OBL-006-PARTIAL-OR-MISSING-FENCE` — partial, refused, quarantined, missing, expired, public, inherited, or permission-denied acknowledgments require an obligation-drift fence.
- `R-OBL-007-NO-REEXPORT-AND-RECALL-HOOK` — no-reexport and recall-route obligations may not be downgraded into optional display hints.
- `R-OBL-008-RESIDUE-CARRIAGE` — sidecar, classification-pin, observation-status, disclosure-cut, and sibling-boundary obligations must travel or be refused.
- `R-OBL-009-CONSUMER-SCOPE-BOUNDARY` — an acknowledgment by one consumer, audience, or surface cannot clear another consumer's obligation boundary.
- `R-OBL-010-NON-TRANSITIVE-ACKNOWLEDGMENT` — acknowledgment is not authorization, legal compliance, consent, rights management, adoption, portability, delegation, public release, deletion, audit opinion, custody, or sibling verdict.
- `R-OBL-011-AUTHORITY-LAUNDERING-FENCE` — an obligation or acknowledgment must not be laundered into policy approval, legal basis, source truth, or sibling authority.
- `R-OBL-012-REPLAY-HOOK` — blocked, quarantined, missing, expired, or recheck-required obligation fences must name replay timing or clearance evidence.

## Required negative cases

A valid specimen 88 fixture must include failure cases for missing obligation ledgers, missing source exposure, missing obligation pins, missing acknowledgment witnesses, required acknowledgment missing, dropped sidecar requirements, dropped classification-pin requirements, missing recall routes, no-reexport downgrade, acknowledgment scope mismatch, wrong-consumer acknowledgment, partial acknowledgment treated as full, expired obligations without recheck, public-link obligation drift without fence, inherited obligation without rebinding, obligation-as-authorization, obligation-as-legal-compliance, obligation-as-consent, acknowledgment digest mismatch, waiver-without-replay, and sibling-verdict laundering.

## Containment

These rules do not define rights expression, ODRL policy execution, XACML/ABAC/IAM authorization, DPV/privacy-law compliance, consent management, public-release approval, deletion, retention, custody, or audit opinion. They only protect Foundry's semantic carriers from being interpreted as obligation-clean merely because exposure was observed.
