# Specimen flow 55 — reset anchor, carry class, and continuity fence

Goal: keep a future Foundry datacube honest when visible values look cumulative or allowance-shaped but actually live under different reset, reissue, or rollover boundaries.

## Scenario
A future SlopOS-neighbor support tile wants one “usage posture” panel for a running capsule and nearby payer state.
The panel mixes four upstream values:
- `net_bytes_sent_total` from a service exporter since the process last started;
- `budget_remaining` from an operation-scoped budget lease that expires and may be reissued;
- `quota_spend_observed` from a replicated additive quota summary that is observational only;
- and `usage_this_period` from an imported provider meter whose billing cycle can be re-anchored by threshold policy.

A tempting but wrong move is to flatten these into one generic value family with only `name` and `value`:
- `network_sent = 98304`
- `budget_remaining = 120000`
- `quota_spend = 88000`
- `provider_usage = 1450`

That would be misleading.
One value is since process start, one is tied to a lease issuance and expiry boundary, one is an observational additive summary under already-issued credit, and one belongs to a billing-cycle anchor that may reset on threshold.
The numbers all “look cumulative enough,” but they do not share one honest continuity story.

## Small seam to prove

### 1) reset anchor
Every reset-sensitive or allowance-shaped family carries a compact witness such as:
- `process_start`
- `lease_issue`
- `billing_cycle_anchor`
- `threshold_reanchor`
- `manual_reset`
- `lifetime_none`

This keeps a lower post-boundary number from pretending that work was undone.

### 2) carry class
Every such family carries a compact witness for what survives the boundary:
- `none`
- `residual_credit`
- `tier_memory`
- `observational_only`
- `other_explicit`

This keeps “new lease,” “new period,” and “same long-lived total” visibly different.

### 3) continuity fence
Every such family carries a compact guardrail for cross-boundary reasoning:
- `stitchable_with_reset_detection`
- `same_anchor_only`
- `policy_restatement_required`
- `forbidden`

This stops charts, exports, and support summaries from inventing one flattering lifetime total where none exists.

## What this specimen proves
Foundry can preserve reset/rollover honesty with three compact residues instead of inventing:
- a universal billing model,
- a global reset-normalization engine,
- or one giant lifecycle registry for every counter-like family.

The cube only needs to say:
1. **what re-anchors the visible value**,
2. **what carries across that boundary**,
3. and **what kind of continuity is actually lawful**.

## Example residue

```text
visible_value:
  subject: capsule.alpha
  measure: net_bytes_sent_total
  value: 98304
  reset_anchor: process_start
  carry_class: none
  continuity_fence: stitchable_with_reset_detection

visible_value:
  subject: capsule.alpha
  measure: budget_remaining
  value: 120000
  reset_anchor: lease_issue
  carry_class: none
  continuity_fence: same_anchor_only

visible_value:
  subject: capsule.alpha
  measure: quota_spend_observed
  value: 88000
  reset_anchor: local_credit_epoch
  carry_class: observational_only
  continuity_fence: policy_restatement_required

visible_value:
  subject: provider.beta
  measure: usage_this_period
  value: 1450
  reset_anchor: billing_cycle_anchor
  carry_class: tier_memory
  continuity_fence: same_anchor_only
```

## Why this belongs in Foundry
SlopOS already puts explicit pressure on meters, budgets, quota summaries, and expirying payer slices without yet promising one giant cycle or billing plane.
This specimen gives Foundry the smallest honest way to preserve that fact when future dashboards, exports, and derived summaries start mixing since-restart counters, expiring leases, observational quota summaries, and threshold-reset provider usage.

## What stays parked
- no universal cycle registry;
- no automatic reset detector for every family;
- no billing or forecasting product;
- no promise that all counter-like values can be losslessly stitched into one lifetime cumulative total.
