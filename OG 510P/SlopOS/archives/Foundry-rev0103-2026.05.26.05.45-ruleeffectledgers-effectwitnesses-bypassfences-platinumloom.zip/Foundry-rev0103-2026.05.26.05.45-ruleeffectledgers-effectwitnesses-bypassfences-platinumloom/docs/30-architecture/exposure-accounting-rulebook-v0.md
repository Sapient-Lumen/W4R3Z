# Exposure accounting rulebook v0

This rulebook belongs to specimen 87. It defines tiny fixture-local checks for exposure ledgers, audience witnesses, and purpose fences.

## Rules

- `R-EXP-001-EXPOSURE-LEDGER` — every post-inventory exposure closure claim needs a ledger id, digest, status, time window, scope, intended audiences, observed surfaces, method limits, and authority boundaries.
- `R-EXP-002-SOURCE-INVENTORY-LINKAGE` — every exposure ledger must name source surface-inventory sweeps, reachability witnesses, and carrier ids.
- `R-EXP-003-INTENDED-AUDIENCE-PIN` — intended audiences must be explicit and must name allowed purposes and access modes.
- `R-EXP-004-AUDIENCE-WITNESS` — every observed audience/surface pair needs evidence, observed time, exposure state, access modes, purposes seen, residue seen, and non-promises.
- `R-EXP-005-PURPOSE-AND-ACCESS-MODE-CHECK` — within-scope audience witnesses may not exceed intended purpose or access-mode pins.
- `R-EXP-006-UNKNOWN-OR-PUBLIC-FENCE` — unknown, public-link, external-share, or overexposed audiences require a purpose fence.
- `R-EXP-007-INHERITED-PERMISSION-HUMILITY` — inherited group/parent/project access is evidence to inspect, not an intended audience by default.
- `R-EXP-008-LEDGER-WINDOW-AND-RECENCY` — audience evidence outside the exposure-ledger window cannot close the ledger without recheck.
- `R-EXP-009-CONSUMER-SCOPE-BOUNDARY` — an audience witness for one consumer or surface cannot clear another consumer's purpose or exposure boundary.
- `R-EXP-010-NON-TRANSITIVE-EXPOSURE` — exposure to one audience is not adoption, authorization, consent, portability, delegation, or public release for another audience.
- `R-EXP-011-AUTHORITY-LAUNDERING-FENCE` — exposure evidence is not permission, policy approval, consent, privacy basis, source truth, audit opinion, deletion, custody, or sibling verdict.
- `R-EXP-012-RECHECK-HOOK` — blocked, quarantined, or recheck-required exposure fences must name recheck timing or clearance evidence.

## Required negative cases

A valid specimen 87 fixture must include failure cases for missing ledgers, missing source inventory, missing audience witnesses, unaccounted intended audiences, unknown audiences without fences, public links without fences, purpose widening, access-mode widening, inherited permissions treated as intended, expired ledger windows, overexposed surfaces treated as adopted/current, audience-as-authorization, exposure-as-consent, exposure-as-deletion, consumer-scope mismatch, witness digest mismatch, and missing purpose fences.

## Containment

These rules do not define access-control policy, OAuth audience handling, JWT validation, ABAC, privacy law, consent management, public-release approval, deletion, custody, or audit opinion. They only protect Foundry's semantic carriers from being interpreted as safe-for-every-audience merely because inventory found the surface.
