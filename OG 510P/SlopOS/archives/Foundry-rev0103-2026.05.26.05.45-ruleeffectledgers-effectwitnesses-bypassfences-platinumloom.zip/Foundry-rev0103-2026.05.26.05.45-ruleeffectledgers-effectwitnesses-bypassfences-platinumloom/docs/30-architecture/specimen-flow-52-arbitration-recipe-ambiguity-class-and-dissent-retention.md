# Specimen flow 52 — arbitration recipe, ambiguity class, and dissent retention

Goal: keep a future Foundry datacube honest when several candidate rows or claims could fill the same semantic slot but the system must either choose one, refuse to choose, or carry multiple candidates forward.

## Scenario
A future SlopOS-neighbor support shell wants a compact “current provenance posture” tile for one deployable subject.
The tile is fed by several candidate inputs:
- a local verifier summary over one exact evidence bundle,
- a newer remote advisory summary with overlapping but not identical coverage,
- a previously cached local synthesis that was built under an older policy cut,
- and a manual steward certification that may bless one candidate view for operator workflows.

The shell wants one visible row for convenience.
Foundry must not let that convenience flatten away how the winner was chosen, whether the choice was ambiguous, or whether losing candidates can still be inspected.

## Pressure
Without a narrow seam, the cube will drift into one of four dishonest postures:
1. **silent latest-wins** — the newest candidate overwrites others with no witness for why time was the selector;
2. **silent precedence folklore** — one source “usually wins” because operators remember it should;
3. **golden-row laundering** — one synthesized row looks native/exact even though it is just the outcome of survivorship logic;
4. **disappearing dissent** — losing candidates vanish, making later audit or replay impossible.

## Minimal residue to preserve

### 1) arbitration recipe
The compact witness for the choosing rule.
Examples:
- `source_precedence: local_verifier > steward_certification > remote_summary`
- `latest_event_time`
- `latest_commit_time`
- `attribute_survivorship`
- `manual_certification`
- `no_merge_fail_closed`
- `plural_carry`

### 2) ambiguity class
The compact witness for what happened after applying the recipe.
Closed starter posture:
- `unique`
- `tie_broken`
- `plural_carried`
- `underdetermined`
- `rejected_ambiguous`
- `manual_resolution`

### 3) dissent retention
The compact witness for what remains of the losing candidates.
Closed starter posture:
- `full_candidates_retained`
- `lineage_summary_retained`
- `count_only_retained`
- `dropped`

## Example sketch

```json
{
  "subject_anchor": "artifact:sha256:...",
  "value_family": "verification.posture.tile",
  "visible_value": {
    "status": "review_required",
    "basis_digest": "sha256:abc..."
  },
  "arbitration_recipe": {
    "kind": "manual_certification",
    "inputs": [
      "local_verifier_summary@sha256:111...",
      "remote_summary@sha256:222...",
      "cached_synthesis@sha256:333...",
      "steward_cert_receipt@sha256:444..."
    ]
  },
  "ambiguity_class": "manual_resolution",
  "dissent_retention": "full_candidates_retained"
}
```

## Why this belongs in Foundry
Foundry is the place where off-native realization truths get compressed without being laundered.
A reconciled row is exactly that kind of compression pressure.
The cube does not need to own a universal MDM engine, but it does need to keep winner-shaped outputs honest.

## Why this is smaller than a giant policy system
This specimen does **not** require:
- one global precedence hierarchy,
- a built-in latest-wins rule,
- automatic source certification,
- or a universal golden-record vocabulary.

It only requires that any winner-shaped row expose:
- **how** the winner was chosen,
- **whether** the choice was actually unique or ambiguous,
- and **what** happened to losing candidates.

## Promotion gate
Promote this seam only if at least one second specimen outside verification/posture tiles also needs it — for example an observation summary, duplicate observation synthesis, or imported-evidence reconciliation flow.
Until then, keep the nouns narrow and local.
