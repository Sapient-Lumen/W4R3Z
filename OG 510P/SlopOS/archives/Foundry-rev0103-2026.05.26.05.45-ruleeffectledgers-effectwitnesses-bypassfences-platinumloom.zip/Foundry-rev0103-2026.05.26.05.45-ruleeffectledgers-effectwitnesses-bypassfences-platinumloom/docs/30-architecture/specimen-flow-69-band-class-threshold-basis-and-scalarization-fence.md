# Specimen flow 69 — band class, threshold basis, and scalarization fence

Goal: keep a future Foundry datacube honest when a visible value is a bucket, band, badge, or percentile-shaped reduction rather than a raw reusable scalar.

## Scenario
A future SlopOS-neighbor support view wants to show one clean table:

- `update urgency = high`
- `exploit likelihood = top_10_percent`
- `latency posture = near`
- `verification badge = warn`

The tempting but wrong move is to flatten all of these into one cheerful scalar plane:
- `priority = 8`
- `risk = 0.9`
- `distance = 1`
- `health = 0.5`

That would be misleading.
Some rows are qualitative severity labels.
Some are percentile or bucket outputs whose meaning depends on cutpoints.
Some are local policy tiers.
Some are rough interpretations or verdict badges that should never become arithmetic truth.

## Small seam to prove

### 1) band class
Every bucketed/banded/thresholded value carries a compact statement of what kind of reduced value it is.
Examples:
- `qualitative_severity`
- `percentile_band`
- `threshold_bucket`
- `ordinal_stage`
- `rough_interpretation`
- `policy_priority_tier`
- `other_reviewed_band`

This keeps “banded but useful” visibly smaller than “same kind of scalar fact”.

### 2) threshold basis
Every banded/bucketed/thresholded value carries a compact statement of which rubric or cutpoints created it.
Examples:
- `cvss_v4_table22`
- `epss_local_triage_policy_v1`
- `histogram_bounds_digest_abcd1234`
- `profile_posture_matrix_v0`
- `reference_range_digest_efgh5678`
- `other_reviewed_threshold_basis`

This keeps bucket layout and rubric drift visible instead of letting labels pretend to be timeless.

### 3) scalarization fence
Every banded/bucketed/thresholded value carries a compact guardrail for downstream use.
Examples:
- `no_arithmetic`
- `ordinal_compare_only`
- `same_thresholds_only`
- `display_only`
- `no_cross_version_aggregation`
- `forbidden`

This stops badges, tiers, and bucket labels from silently becoming reusable cube numbers.

## Example residue

```text
visible_value:
  subject: vuln.priority
  value: High
  band_class: qualitative_severity
  threshold_basis: cvss_v4_table22
  scalarization_fence: no_arithmetic

visible_value:
  subject: exploit.likelihood
  value: top_10_percent
  band_class: percentile_band
  threshold_basis: epss_local_triage_policy_v1
  scalarization_fence: same_thresholds_only

visible_value:
  subject: memory.locality
  value: near
  band_class: threshold_bucket
  threshold_basis: histogram_bounds_digest_abcd1234
  scalarization_fence: no_cross_version_aggregation
```

## What this specimen proves
Foundry can preserve threshold honesty with three compact residues instead of inventing:
- a universal risk-score ontology,
- one permanent threshold registry,
- or a promise that every badge/tier/bucket is safely arithmetic.

The cube only needs to say:
1. **what kind of band this is,**
2. **which thresholds or rubric produced it,**
3. and **where later readers must stop before turning it into faux precision.**

## Why this belongs in Foundry
SlopOS already has design-phase pressure from imported CVSS / EPSS / vendor-severity signals, qualitative profile posture matrices, locality-hint bands, and family-local verdict badges.
This specimen gives Foundry the smallest honest way to preserve those surfaces when future dashboards, exports, or support cards start asking for one neat “risk”, “urgency”, or “health” column.

## What stays parked
- no archive-wide severity ladder;
- no permanent threshold registry;
- no automatic ordinal arithmetic over badges or tiers;
- no promise that differently bucketed values are safely comparable across revisions or families.
