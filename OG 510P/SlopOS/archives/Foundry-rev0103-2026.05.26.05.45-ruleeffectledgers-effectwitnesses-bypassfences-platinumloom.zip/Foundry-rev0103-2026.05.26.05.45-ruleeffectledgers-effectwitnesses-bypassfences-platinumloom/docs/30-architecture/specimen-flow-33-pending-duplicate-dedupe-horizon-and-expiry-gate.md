# Specimen flow 33 — pending duplicate, dedupe horizon, and expiry gate

Goal: keep “same effect key” smaller than both “the earlier work already finished” and “the provider will remember this forever”.

## Scenario
A foreign-backed realization needs to perform a non-commutative action through an external API: create, publish, attach, start, or mutate something.
The caller already uses an **effect key** plus the same reviewed request fingerprint from pass XXXV.
A timeout or transport break leaves the caller unsure what happened.
A retry arrives.

There are three timing classes that many systems flatten if they only say “idempotent request”.

First, the retry can be **too early**.
The same effect key and same fingerprint arrive while the original work is still in flight or otherwise unresolved.
That later attempt is a **pending duplicate**.
The right answer is not to fire the side effect again, and it is not to pretend the final result already exists.
The honest answer is a visible outstanding/pending duplicate posture.

Second, the retry can be **inside remembered replay time**.
The same effect key and same fingerprint arrive after the original work completed and while the provider still remembers the result.
That is the pass-XXXV lane where a **prior-outcome anchor** may be replayed instead of firing the effect again.

Third, the retry can be **too late**.
The same effect key and same fingerprint arrive after the provider intentionally forgot the old key.
The bounded replay/suppression memory interval is the **dedupe horizon**.
The boundary that ends it is the **expiry gate**.
After that gate, the old key no longer honestly buys replay or suppression.
That is different from mismatch, and it is different from provider-side completion.
It is simply the end of remembered duplicate-safe treatment.

This keeps three truths separate:
- same key while original work is still outstanding,
- same key while replay/suppression memory is still valid,
- and same key after the dedupe horizon has expired.

## Proposed Foundry objects
1. **pending duplicate**
   - same effect key and same fingerprint, but original work is still unresolved;
   - keeps retry-equivalent identity smaller than settled or replayable outcome truth.

2. **dedupe horizon**
   - bounded interval or policy during which duplicate-safe replay/suppression remains defined for one effect key;
   - keeps duplicate memory explicit and time-bounded rather than eternal.

3. **expiry gate**
   - visible boundary after which old duplicate memory no longer authoritatively governs retries under that key;
   - keeps expiry different from mismatch and different from live-state failure.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a same-key retry arrives before the first attempt settled;
- duplicate-safe replay is only valid for a bounded policy window;
- a historical receipt or remembered answer survives longer than the dedupe memory itself;
- and operators need a public explanation for why “same key” produced `still processing`, `replayed prior result`, or `fresh request after expiry`.

## Adjacent but parked
- **expiry-reason chip** — future compact residue for whether the horizon ended by age, policy, or cleanup.
- **duplicate-poll rail** — future narrow status lane for asking about one still-outstanding keyed effect without growing a general job plane.

## Promotion rule
Do not promote `pending duplicate`, `dedupe horizon`, or `expiry gate` unless they improve:
- one companion-cube specimen where same-key retries can visibly be `still processing` rather than silently replayed;
- one outside-system specimen where duplicate memory has a published TTL or pruning boundary;
- and one Foundry specimen where a historical receipt remains weaker than a still-live dedupe window.
