# Specimen flow index

Foundry now has enough recurring specimen pressure to justify one tiny discovery surface for specimen coverage.
This remains intentionally lighter than a schema family or registry.

## Inclusion rule
- Every current `specimen-flow-*.md` file under `docs/30-architecture/` must be listed here in the same revision.
- Add a new specimen here in the same revision that creates it.
- Do not create subfamilies until multiple specimens prove they earn one.

## Current specimen set

- `docs/30-architecture/specimen-flow-01-bundle-world-ground-instance.md`
- `docs/30-architecture/specimen-flow-02-snapshot-resume-and-freshness-reacquire.md`
- `docs/30-architecture/specimen-flow-03-capability-routed-foreign-service-with-generation-witness.md`
- `docs/30-architecture/specimen-flow-04-policy-split-attested-foreign-adoption.md`
- `docs/30-architecture/specimen-flow-05-subject-attached-sidecars-and-measured-adoption.md`
- `docs/30-architecture/specimen-flow-06-routed-virtualization-capability-and-resource-handles.md`
- `docs/30-architecture/specimen-flow-07-subject-closure-resource-warrant-and-foreign-lease.md`
- `docs/30-architecture/specimen-flow-08-subject-spine-resource-handle-and-secret-release-latch.md`
- `docs/30-architecture/specimen-flow-09-restore-obligation-availability-class-and-referrer-fallback.md`
- `docs/30-architecture/specimen-flow-10-borrowed-handle-restore-budget-and-capability-grade.md`
- `docs/30-architecture/specimen-flow-11-owned-handle-swap-availability-floor-and-restore-duty-ledger.md`
- `docs/30-architecture/specimen-flow-12-void-route-borrow-rail-and-secret-latch.md`
- `docs/30-architecture/specimen-flow-13-lazy-hydration-prefetch-witness-and-cold-read-debt.md`
- `docs/30-architecture/specimen-flow-14-extension-witness-detachable-layer-and-backing-cargo.md`
- `docs/30-architecture/specimen-flow-15-metadata-seal-payload-root-and-bootstrap-debt.md`
- `docs/30-architecture/specimen-flow-16-confext-check-config-layer-and-overlay-gate.md`
- `docs/30-architecture/specimen-flow-17-staged-generation-activation-cut-and-rollback-selector.md`
- `docs/30-architecture/specimen-flow-18-trial-basis-success-latch-and-fallback-budget.md`
- `docs/30-architecture/specimen-flow-19-coherence-target-confirmation-fence-and-supersession-hold.md`
- `docs/30-architecture/specimen-flow-20-follow-selector-basis-pin-and-drift-fence.md`
- `docs/30-architecture/specimen-flow-21-offer-hint-local-hold-and-admission-window.md`
- `docs/30-architecture/specimen-flow-22-prerequisite-witness-applicability-fence-and-barrier-hop.md`
- `docs/30-architecture/specimen-flow-23-rollback-floor-ratchet-mark-and-rescue-path.md`
- `docs/30-architecture/specimen-flow-24-state-epoch-migration-cut-and-reset-rail.md`
- `docs/30-architecture/specimen-flow-25-retention-root-reclaim-fence-and-cleanup-debt.md`
- `docs/30-architecture/specimen-flow-26-admission-cut-drain-epoch-and-grace-fence.md`
- `docs/30-architecture/specimen-flow-27-consistency-class-write-fence-and-recovery-debt.md`
- `docs/30-architecture/specimen-flow-28-intent-generation-observed-generation-and-stale-status-fence.md`
- `docs/30-architecture/specimen-flow-29-commit-frontier-apply-frontier-and-delta-horizon.md`
- `docs/30-architecture/specimen-flow-30-exposure-frontier-stability-fence-and-withheld-tail.md`
- `docs/30-architecture/specimen-flow-31-holder-epoch-fence-token-and-stale-holder-cut.md`
- `docs/30-architecture/specimen-flow-32-effect-key-fingerprint-fence-and-prior-outcome-anchor.md`
- `docs/30-architecture/specimen-flow-33-pending-duplicate-dedupe-horizon-and-expiry-gate.md`
- `docs/30-architecture/specimen-flow-34-absence-witness-tombstone-marker-and-resurrection-fence.md`
- `docs/30-architecture/specimen-flow-35-issuance-witness-live-validity-witness-and-recheck-horizon.md`
- `docs/30-architecture/specimen-flow-36-assurance-class-recency-fence-and-intent-latch.md`
- `docs/30-architecture/specimen-flow-37-presenter-binding-audience-fence-and-request-pin.md`
- `docs/30-architecture/specimen-flow-38-derivation-witness-attenuation-fence-and-ancestor-shadow.md`
- `docs/30-architecture/specimen-flow-39-discharge-witness-caveat-hold-and-actor-path-card.md`
- `docs/30-architecture/specimen-flow-40-promotion-candidate-stability-lane-and-revision-hook.md`
- `docs/30-architecture/specimen-flow-41-effective-time-record-time-and-pending-context.md`
- `docs/30-architecture/specimen-flow-42-grain-card-accumulation-class-and-reduction-fence.md`

- `docs/30-architecture/specimen-flow-43-population-frame-overlap-class-and-coverage-witness.md`
- `docs/30-architecture/specimen-flow-44-identity-anchor-label-snapshot-and-axis-budget.md`
- `docs/30-architecture/specimen-flow-45-exactness-class-bound-witness-and-correction-horizon.md`
- `docs/30-architecture/specimen-flow-46-input-cut-recipe-witness-and-replay-class.md`
- `docs/30-architecture/specimen-flow-47-loss-class-exemplar-anchor-and-raw-retention-fence.md`
- `docs/30-architecture/specimen-flow-48-view-lens-disclosure-class-and-comparability-fence.md`
- `docs/30-architecture/specimen-flow-49-selection-recipe-window-cut-and-total-mode.md`
- `docs/30-architecture/specimen-flow-50-watermark-frontier-closure-class-and-lateness-aperture.md`

- `docs/30-architecture/specimen-flow-51-rank-recipe-score-family-and-tie-break-witness.md`

- `docs/30-architecture/specimen-flow-52-arbitration-recipe-ambiguity-class-and-dissent-retention.md`

- `docs/30-architecture/specimen-flow-53-sample-class-inclusion-basis-and-expansion-fence.md`

- `docs/30-architecture/specimen-flow-54-unit-witness-canonical-scale-and-conversion-fence.md`

- `docs/30-architecture/specimen-flow-55-reset-anchor-carry-class-and-continuity-fence.md`

- `docs/30-architecture/specimen-flow-56-allocation-basis-residue-class-and-apportionment-fence.md`

- `docs/30-architecture/specimen-flow-57-adjunct-namespace-schema-pin-and-promotion-gate.md`

- `docs/30-architecture/specimen-flow-58-translation-witness-compatibility-lane-and-upgrade-fence.md`

- `docs/30-architecture/specimen-flow-59-support-witness-unknown-residue-and-falsehood-fence.md`

- `docs/30-architecture/specimen-flow-60-profile-card-precedence-lane-and-overlay-fence.md`

- `docs/30-architecture/specimen-flow-61-interpretation-cut-restatement-lane-and-hindsight-fence.md`

- `docs/30-architecture/specimen-flow-62-ordering-basis-mutation-lane-and-revision-witness.md`

- `docs/30-architecture/specimen-flow-63-contribution-basis-fanout-class-and-reaggregation-fence.md`

- `docs/30-architecture/specimen-flow-64-denominator-basis-normalization-lane-and-ratio-fence.md`

- `docs/30-architecture/specimen-flow-65-match-cluster-survivorship-witness-and-golden-row-fence.md`

- `docs/30-architecture/specimen-flow-66-assertion-class-confidence-basis-and-verdict-fence.md`

- `docs/30-architecture/specimen-flow-67-blank-class-applicability-basis-and-coercion-fence.md`

- `docs/30-architecture/specimen-flow-68-eligibility-basis-exclusion-class-and-whole-world-fence.md`
- `docs/30-architecture/specimen-flow-69-band-class-threshold-basis-and-scalarization-fence.md`
- `docs/30-architecture/specimen-flow-70-query-contract-result-envelope-and-validation-witness.md`
- `docs/30-architecture/specimen-flow-71-hierarchy-scope-rollup-path-and-aggregation-guard.md`
- `docs/30-architecture/specimen-flow-72-materialization-cut-refresh-witness-and-reuse-fence.md`
- `docs/30-architecture/specimen-flow-73-disclosure-cut-suppression-witness-and-differencing-fence.md`
- `docs/30-architecture/specimen-flow-74-observation-status-card-adjustment-witness-and-as-observed-fence.md`
- `docs/30-architecture/specimen-flow-75-control-total-card-reconciliation-witness-and-balance-fence.md`
- `docs/30-architecture/specimen-flow-76-classification-pin-crosswalk-witness-and-code-drift-fence.md`
- `docs/30-architecture/specimen-flow-77-residue-sidecar-flattening-refusal-and-egress-survival.md`
- `docs/30-architecture/specimen-flow-78-refusal-receipt-egress-manifest-and-conformance-gate.md`
- `docs/30-architecture/specimen-flow-79-semantic-diff-regression-lock-and-tamper-corpus-gate.md`
- `docs/30-architecture/specimen-flow-80-waiver-warrant-expiry-witness-and-exception-replay-gate.md`
- `docs/30-architecture/specimen-flow-81-consumer-passport-portability-witness-and-interpretation-gate.md`
- `docs/30-architecture/specimen-flow-82-delegation-warrant-reliance-receipt-and-transitive-use-fence.md`
- `docs/30-architecture/specimen-flow-83-revocation-notice-recall-receipt-and-stale-reliance-fence.md`
- `docs/30-architecture/specimen-flow-84-remediation-packet-replacement-witness-and-readmission-gate.md`
- `docs/30-architecture/specimen-flow-85-distribution-manifest-adoption-receipt-and-orphan-copy-fence.md`
- `docs/30-architecture/specimen-flow-86-surface-inventory-sweep-reachability-witness-and-coverage-gap-fence.md` — surface inventory sweep / reachability witness / coverage-gap fence
- `docs/30-architecture/specimen-flow-87-exposure-ledger-audience-witness-and-purpose-fence.md` — exposure ledger / audience witness / purpose fence
- `docs/30-architecture/specimen-flow-88-obligation-ledger-acknowledgment-witness-and-drift-fence.md` — obligation ledger / acknowledgment witness / obligation-drift fence
- `docs/30-architecture/specimen-flow-89-fulfillment-receipt-completion-witness-and-nonfulfillment-fence.md` — fulfillment receipt / completion witness / nonfulfillment fence
- `docs/30-architecture/specimen-flow-90-verification-audit-evidence-sample-and-false-closure-fence.md` — verification audit / evidence sample / false-closure fence

- `docs/30-architecture/specimen-flow-91-recheck-cadence-drift-signal-and-stale-verification-fence.md` — recheck cadence / drift signal / stale-verification fence
- `docs/30-architecture/specimen-flow-92-escalation-packet-routing-witness-and-unresolved-signal-fence.md`
- `docs/30-architecture/specimen-flow-93-disposition-ledger-resolution-witness-and-premature-closure-fence.md` — disposition ledger / resolution witness / premature-closure fence

- `docs/30-architecture/specimen-flow-94-precedent-ledger-rule-promotion-witness-and-overgeneralization-fence.md` — precedent ledger / rule-promotion witness / overgeneralization fence
- `docs/30-architecture/specimen-flow-95-rule-collision-ledger-precedence-witness-and-ambiguity-fence.md` — rule-collision ledger / precedence witness / ambiguity fence
- `docs/30-architecture/specimen-flow-96-rule-evaluation-trace-applicability-witness-and-misapplication-fence.md` — rule-evaluation trace / applicability witness / misapplication fence
- `docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md` — rule-effect ledger / effect witness / bypass fence
