# Specimen flow 67 — blank class, applicability basis, and coercion fence

Goal: keep a future Foundry datacube honest when it needs to carry blank-sensitive values without collapsing unknown, masked, not-applicable, delete-sentinel, and default-implicit-absent cases into one flattering null.

## Scenario
A future support workspace wants one rectangular “identity + posture + visibility” panel spanning design-phase SlopOS surfaces.
It can see:
- one `imported_userinfo_rows` table with optional profile/email/verification claims from provider-local UserInfo fetches;
- one `capability_graph_rows` table where node `label` may be policy-controlled and redacted;
- one `profile_posture_rows` table where some families simply do not apply in some profiles;
- and one `patch_update_rows` lane where JSON-merge-style `null` may mean “remove this member” rather than “we do not know”.

A tempting but wrong move is to flatten every blank-looking value into one reusable `null_reason = none` family and let later readers treat absence, masking, non-applicability, and deletion as interchangeable.
That would be misleading.
A masked label is not the same thing as unknown, a profile-excluded cell is not the same thing as false, a merge-patch deletion is not the same thing as missing observation, and an implicitly absent boolean must not quietly become `false`.

## Small seam to prove

### 1) blank class
Every blank-sensitive row carries a compact witness for what kind of blank it is.
Examples:
- `unknown`
- `asked_unknown`
- `temporarily_unavailable`
- `not_asked`
- `masked`
- `not_applicable`
- `unsupported`
- `delete_sentinel`
- `implicit_default_absent`

This keeps useful blanks distinct without inventing a giant missingness ontology.

### 2) applicability basis
Every such row carries a compact witness for why the value is absent or whether it ever properly applied here.
Examples:
- `provider_optional_field`
- `workflow_not_run`
- `profile_excluded`
- `export_redacted`
- `source_unsupported`
- `merge_patch_instruction`
- `subject_not_applicable`

This keeps non-applicability, omission, and redaction visibly smaller than generic unknown.

### 3) coercion fence
Every such row carries a compact guardrail for what later consumers must not assume.
Examples:
- `unspecified_not_zero`
- `not_false`
- `not_empty_string`
- `not_delete_equivalent`
- `not_groupable_as_none`
- `forbidden`

This stops dashboards, exports, and bridge layers from silently converting blanks into tidier but dishonest facts.

## Example residue

```text
blank_sensitive_row:
  subject: slopos.identity.imported_userinfo.email_verified
  visible_value: null
  blank_class: implicit_default_absent
  applicability_basis: provider_optional_field
  coercion_fence: not_false

blank_sensitive_row:
  subject: slopos.capability_graph.node.label
  visible_value: null
  blank_class: masked
  applicability_basis: export_redacted
  coercion_fence: not_empty_string

blank_sensitive_row:
  subject: slopos.profile_posture.D.current_user_export
  visible_value: null
  blank_class: not_applicable
  applicability_basis: profile_excluded
  coercion_fence: not_false

blank_sensitive_row:
  subject: slopos.identity.import_patch.picture
  visible_value: null
  blank_class: delete_sentinel
  applicability_basis: merge_patch_instruction
  coercion_fence: not_unknown
```

## What this specimen proves
Foundry can preserve blank honesty with three compact residues instead of inventing:
- a universal null ontology,
- a giant imputation/default engine,
- or a promise that every rectangular export preserved absence semantics faithfully.

The cube only needs to say:
1. **what kind of blank this is,**
2. **why the value is absent or inapplicable here,**
3. and **where later readers must not coerce it into something tidier.**

## Why this belongs in Foundry
SlopOS already has provider-local imported profile material, policy-controlled redaction, profile-shaped applicability differences, and design-phase boundaries where omission is not the same thing as falsehood.
This specimen gives Foundry the smallest honest way to preserve that fact when future exports and support panels start mixing imported claims, redacted labels, profile exclusions, and patch/update lanes.

## What stays parked
- no archive-wide null algebra;
- no universal fill-default product;
- no promise that every serializer preserves absence semantics;
- no claim that masked, unknown, delete-sentinel, and not-applicable cells are safely groupable by default.
