# Specimen flow 08 — subject spine, resource handle, and secret-release latch

This specimen exists to test whether Foundry can keep nearby attached evidence, foreign-backed handles, and release policy visibly separate from live realization.

## Scenario
An artifact is published with OCI-style subject-attached sidecars. A component/runtime contract uses WIT-style resources that remain implemented on the other side of the boundary. Launch occurs in confidential or otherwise foreign ground, but secret release remains separately gated.

## Flow
1. Foundry identifies a **subject spine**: the primary artifact plus its nearby attached sidecars/evidence.
2. Foundry reads the declared contract and records any **resource handles** that will remain foreign-backed at use time.
3. Foundry records required versus optional routed power and the relevant **policy capsule** for launch/admission.
4. Launch succeeds in foreign ground and may produce evidence.
5. Foundry **does not** yet assume that secrets or privileged resources are released.
6. A separate **secret-release latch** or resource-release gate is evaluated based on the governing policy.
7. Only after that gate opens do stronger foreign capabilities become usable.
8. Any durable local adoption remains a later explicit step and still must not collapse subject attachment, foreign handles, and live realization into one story.

## What this specimen is trying to preserve
- nearby attached evidence remains smaller than realization;
- foreign-backed handles stay visibly foreign;
- launch/admission policy and secret/resource release policy remain visibly different;
- durable adoption remains a later act.

## Candidate nouns under pressure
- **subject spine**
- **resource handle**
- **policy capsule**
- **secret-release latch**
- **availability split**

## Kill criteria
Reject these nouns if any of the following happens:
- the subject spine starts impersonating the whole live runtime story;
- resource handles start getting mistaken for native objects;
- policy capsules become a dumping ground for every runtime detail;
- Foundry starts swallowing Ward’s appraisal/verdict semantics or Harbor’s adoption semantics.

## If Foundry survives the specimen
If Foundry *can* survive it, then pass XI has found a promising smaller set:
- one attachment anchor,
- one honest family for foreign-backed handles,
- and one explicit split between launch success and released foreign power.
