# Specimen flow 73 — disclosure cut, suppression witness, and differencing fence

Goal: keep Foundry honest when an aggregate datacube output is visible only because a release policy, threshold rule, suppression plan, perturbation/noise method, clean-room constraint, or privacy-budget posture allowed it to leave the cube.

## Scenario

A future SlopOS support surface wants a table:

> weekly quarantined-open attempts by handler family, tenant posture, reviewer outcome, and origin class.

The table is useful.
It is also sparse.
One handler family has only a few attempts in one tenant posture.
A reviewer asks for a second table with the same total but one extra origin-class breakdown.
A product dashboard wants to cache the released table.
A support engineer wants to subtract one table from another to estimate the hidden class.
A collaborator asks for the same table through a clean-room-style aggregate rule.
A privacy-focused path wants to add noise with a privacy unit of user, device, tenant, or household-like group.

The tempting but wrong move is to publish the visible cells and leave blank or missing cells as ordinary nulls, zeros, or dashboard gaps.

Foundry allows aggregate release, but refuses to let release controls disappear.

## Walkthrough

1. The request enters through specimen 70's query contract and result envelope. The contract names the predicate, source cut, policy lens, parameter digest, output shape, and replay class.
2. The grouping crosses specimen 71's hierarchy scope and rollup path. The aggregation guard already says whether counts, distinct counts, ratios, or masked/banded values may be reduced.
3. The table is subject to an aggregate release policy. Foundry attaches a **disclosure cut** naming release policy digest, audience/lens, protected-unit basis, release-set id, source cut, query-contract digest, method family, contribution bounds, threshold/budget posture, and disclosure-review run.
4. A small cell fails direct release. Foundry records a **suppression witness** as `primary_suppressed` or `not_releasable`, without publishing the protected value and without turning it into zero.
5. A margin/subtotal would reveal the hidden cell by subtraction. Foundry records a secondary or complementary suppression witness for at least one additional cell or refuses the paired release.
6. The product dashboard wants to compare this week to last week. Foundry checks the **differencing fence**: the release policy, protected-unit basis, release set, method, hierarchy/calendar lenses, and composition window must allow that comparison.
7. A cached copy exists from specimen 72's materialization/reuse seam. The cache hit is not enough; the disclosure cut and differencing fence must still allow reuse for the current audience, cut, and release set.
8. A DP/noisy release is requested. Foundry does not implement differential privacy, but records the privacy-unit basis, privacy parameters or budget token, contribution bounds, noise family, budget-spend witness, and known limitations as release residue.
9. A later table uses a different protected unit: device instead of user. Foundry refuses equality, subtraction, and ratio reuse unless an explicit compatibility note says the protected-unit change is safe for that comparison.
10. A result renderer tries to fill missing chart points with zero. Foundry refuses: suppressed, coarsened, noisy, budget-refused, and policy-refused are disclosure-control states, not zeros.

## Nouns pressure-tested here

1. **disclosure cut**
   - exact residue for the release regime that made an aggregate visible;
   - includes policy digest, source cut, query contract, audience/lens, release-set id, protected-unit basis, method family, threshold or budget posture, contribution bounds, and review run;
   - smaller than a privacy product, authorization model, clean-room engine, or publication verdict.

2. **suppression witness**
   - exact residue for what happened to a cell/result under release control: released, primary-suppressed, complementary-suppressed, coarsened, rounded, perturbed, noisy, budget-refused, policy-refused, or not-run;
   - smaller than the hidden value and smaller than ordinary null/zero/unknown semantics.

3. **differencing fence**
   - exact guardrail for whether this output may be compared, subtracted, joined, drilled, cached, reissued, or combined with neighboring outputs;
   - smaller than a reconstruction-proof warranty and stronger than “the visible cell passed threshold.”

## What this specimen must keep separate

- row count versus protected-entity count;
- threshold-cleared versus source-complete;
- primary suppression versus complementary suppression;
- suppressed versus zero;
- noisy or perturbed versus exact;
- rounded for display versus rounded for disclosure control;
- privacy-unit basis versus cube grain;
- privacy budget refresh versus materialization refresh;
- clean-room output constraint versus local authorization;
- release-policy pass versus all-future-use approval;
- cache hit versus disclosure-lawful reuse.

## Promotion gate for these nouns

Do not widen these nouns beyond aggregate release surfaces unless a later specimen shows all of the following surviving without collapse:

- one direct small-cell suppression;
- one complementary/secondary suppression or paired-release refusal;
- one noisy or perturbed aggregate;
- one protected-unit basis change;
- one materialized/cached aggregate whose reuse is refused by release policy;
- one cross-table or cross-window differencing attempt;
- one chart/export path that would otherwise coerce suppressed cells into zero or ordinary null.

## Why this matters

Datacubes usually make aggregate release look safer than row export.
That is sometimes true, but it is not automatic.
Foundry should let SlopOS publish useful support summaries, diagnostics, and collaborator-safe aggregates while making every aggregate release say: which disclosure cut governed it, what suppression/noise/refusal happened, and where later readers must stop before reconstructing what was intentionally hidden.
