# Specimen flow 61 — interpretation cut, restatement lane, and hindsight fence

Goal: keep a future Foundry datacube honest when an old answer is later re-read under newer SlopOS-side semantics while the archive is still in active design.

## Scenario
A future SlopOS-facing support surface wants one compact history tile that shows:
- one count originally published when the active profile guidance came from an older profile matrix cut,
- one export derived from `capshell-exec-pack-schema-v1` rows that a newer reader can now also reinterpret through `...-v2`,
- one policy-shaped summary whose old answer depended on a now-resolved history note rather than the current trajectory surface,
- and one dashboard that wants “current semantics” without losing what earlier operators actually saw.

The tempting but wrong move is to overwrite the past:
- a new schema/profile cut silently rewrites old rows,
- a timestamp-only replay claims reproducibility even though the underlying semantic cut drifted,
- a translated modern reading impersonates the original published answer,
- or a current dashboard projection becomes the only surviving history.

That feels tidy.
It is also a lie.

## Small seam to prove

### 1) interpretation cut
Whenever a historical answer is produced or replayed, preserve the exact semantic/model/profile/history cut that shaped the answer.
Examples:
- `git:slopos/profile-posture-matrix@rev0681`
- `git:schemas/capshell-exec-pack-v1@0d1aa2c`
- `tag:foundry/history/support-export/2026-03-25-initial`
- `none` only when the answer is explicitly current-only and not claiming historical reproducibility

### 2) restatement lane
Whenever a visible answer relates to an older one, preserve the posture of that relationship.
Examples:
- `original_published`
- `same_cut_replay`
- `translated_restatement`
- `current_hindsight_projection`

### 3) hindsight fence
Whenever a newer semantic cut could overwrite or impersonate an older one, preserve the refusal boundary.
Examples:
- `do_not_overwrite_original_history`
- `timestamp_only_cut_is_weak`
- `new_profile_matrix_requires_explicit_restatement`
- `old_schema_requires_native_or_reviewed_translation`

## What this specimen proves
Foundry can keep historical readings inspectable without pretending that current semantics had always been in force.
The cube only needs to say:
1. **which interpretation cut produced the visible answer**,
2. **which restatement lane the answer occupies**,
3. and **where a hindsight fence blocked silent rewrite by newer meaning**.

## Example residue

```text
visible_value:
  subject: support.export
  measure: visible_case_count
  interpretation_cut: git:slopos/profile-posture-matrix@rev0681
  restatement_lane: original_published
  hindsight_fence: do_not_overwrite_original_history

visible_value:
  subject: capshell.exec
  measure: launch_request_count
  source_schema_pin: git:schemas/capshell-exec-pack-v1@0d1aa2c
  target_schema_pin: git:schemas/capshell-exec-pack-v2@73bc119
  interpretation_cut: git:schemas/capshell-exec-pack-v1@0d1aa2c
  restatement_lane: translated_restatement
  hindsight_fence: old_schema_requires_native_or_reviewed_translation

visible_value:
  subject: portal.net
  measure: strict_profile_grant_count
  interpretation_cut: tag:foundry/history/net-tile/2026-03-25-audit-branch
  restatement_lane: same_cut_replay
  hindsight_fence: timestamp_only_cut_is_weak

visible_value:
  subject: slopos.design
  measure: profile_requirement_count
  interpretation_cut: git:slopos/profile-claim-matrix@rev0681
  restatement_lane: current_hindsight_projection
  hindsight_fence: new_profile_matrix_requires_explicit_restatement
```

## Why this belongs in Foundry
SlopOS is design-phase enough that future historical answers will be re-read through moving schemas, moving profile guidance, and moving closure notes.
This specimen gives Foundry the smallest honest way to preserve both the old answer and the newer reinterpretation without forcing one giant universal history engine.

## What stays parked
- no universal historical-answer warehouse;
- no mandatory permanent storage of every restated view;
- no automatic rewrite of all old rows when a new semantic cut appears;
- no promise that every timestamp-only replay is semantically reproducible;
- no claim that current-hindsight projections may replace original published history.
