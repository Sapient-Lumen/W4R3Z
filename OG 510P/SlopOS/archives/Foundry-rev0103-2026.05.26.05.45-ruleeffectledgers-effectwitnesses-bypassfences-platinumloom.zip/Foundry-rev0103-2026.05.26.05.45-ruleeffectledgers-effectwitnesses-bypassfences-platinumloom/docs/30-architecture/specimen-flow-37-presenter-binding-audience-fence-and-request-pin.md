# Specimen flow 37 — presenter binding, audience fence, and request pin

Goal: keep current validity and even adequate assurance separate from correct presentation by the right presenter to the right receiver in the right exact request shape.

## Scenario
A foreign-backed realization already holds a live-validity witness and has crossed whatever assurance and recency fences the action requires.
It now calls an external resource, redeems a grant, or presents a foreign capability proof across a membrane.
The tempting mistake is to read the still-live artifact as if it were a generic bearer of truth.

There are three narrower truths that many systems flatten when they only say “token valid” or “request authenticated”.

First, there is a **presenter binding**.
One artifact may only be usable when presented by the holder of one key, certificate, transport binding, or comparable current presenter secret.
That keeps “artifact valid” distinct from “this presenter may use it now”.

Second, there is an **audience fence**.
One artifact may only be usable at one intended receiver, resource, route family, or redeeming surface.
That keeps “good artifact” distinct from “good at this receiver”.

Third, there is a **request pin**.
One presentation may still need to match exact request-shaped facts such as method, URI, nonce, token hash, or comparable presentation-local details.
That keeps “right presenter at the right receiver” distinct from “right for this exact presentation now”.

This preserves three truths:
- who may honestly present one artifact now,
- where that artifact may be redeemed,
- and how narrowly one exact presentation is bound.

## Proposed Foundry objects
1. **presenter binding**
   - exact current presenter/key/channel binding required for one foreign-backed presentation to count;
   - keeps live-validity truth separate from portable bearer folklore.

2. **audience fence**
   - explicit intended receiver/resource boundary for one usable artifact;
   - keeps cross-resource reuse visibly smaller than ordinary validity.

3. **request pin**
   - explicit method/route/nonce/token-hash style binding for one exact presentation;
   - keeps standing artifact truth separate from one narrowly bound presentation.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a token, lease descriptor, or proof is still live but only for one current presenter;
- the same artifact would be refused at the wrong receiver even though it remains otherwise well formed;
- one signed presentation is intentionally narrow enough that replaying it on a different method, route, or token should fail;
- and provider-local binding machinery exists without forcing Foundry to standardize a portable signer or replay plane.

## Adjacent but parked
- **signer braid** — future compact residue for keeping multiple proof-capable presenter keys distinct without inventing a signer registry.
- **replay ledger** — future compact residue for bounded request-proof replay memory.
- **auth target card** — future compact residue for richer receiver/resource/action targeting if later specimens prove it belongs here.

## Promotion rule
Do not promote `presenter binding`, `audience fence`, or `request pin` unless they improve:
- one SlopOS companion specimen where provider-local binding machinery is explicitly smaller than portable token/session truth;
- one outside-system specimen where receiver specificity is load-bearing rather than optional folklore;
- and one outside-system specimen where one exact request-shaped proof remains narrower than general live validity.
