# Specimen flow 16 — confext check, config layer, and overlay gate

Goal: keep foreign configuration overlays visibly separate from base/runtime cargo and from compatibility proof.

## Scenario
A foreign runtime image is already present and working.
An operator wants to attach a configuration-only overlay that changes policy and service defaults without changing the base runtime image.
Before the overlay is attached, the system checks the overlay’s compatibility metadata against the host/base image; if the metadata mismatches, the overlay is refused and the runtime keeps running without pretending partial merge.

## Proposed Foundry objects
1. **config layer**
   - foreign configuration surface distinct from base/runtime cargo;
   - stronger than an ad hoc file copy and weaker than a new runtime image.

2. **compat witness**
   - compact summary of why the overlay may merge with the current base/host;
   - stronger than folklore and weaker than full trust lineage.

3. **overlay gate**
   - typed refusal or admission result for the configuration layer;
   - stronger than a generic mount error and weaker than total runtime replacement.

4. **detach path**
   - explicit rollback/removal path that returns the runtime to its pre-overlay state.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- the useful foreign change is configuration-only,
- compatibility evidence is present but limited,
- mismatch should refuse cleanly,
- and attach/detach semantics are part of the truth.

## Promotion rule
Do not promote `config layer`, `compat witness`, `overlay gate`, or `detach path` unless they improve:
- one compatible config overlay specimen,
- one mismatch refusal specimen,
- and one detach/rollback specimen.
