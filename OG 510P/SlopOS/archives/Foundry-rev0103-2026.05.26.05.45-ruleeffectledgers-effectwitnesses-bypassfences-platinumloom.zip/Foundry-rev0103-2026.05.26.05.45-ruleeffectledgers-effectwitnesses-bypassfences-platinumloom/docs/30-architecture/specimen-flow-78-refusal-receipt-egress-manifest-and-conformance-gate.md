# Specimen flow 78 — refusal receipt, egress manifest, and conformance gate

Goal: make refusal itself durable when a requested egress surface would drop the residue required to read it honestly.

## Scenario

A SlopOS support workspace starts from the same weekly support result used in specimen 77. Operators ask for several output shapes:

- a chart for a dashboard;
- a CSV for offline review;
- a markdown incident summary;
- a JSON response for a portal widget;
- a cached support card reused from a prior cut; and
- a label-only category table for a quick comparison.

The chart can be emitted with a semantic sidecar. The others may be unsafe as requested.

In rev0083, Foundry could say “refuse flattening.” In this specimen, the refusal becomes a first-class artifact.

## Small seam to prove

### 1) refusal receipt

A refusal receipt is a compact machine-readable artifact produced when a requested surface would lose required meaning.

Example:

```yaml
refusal_receipt:
  receipt_family: foundry_refusal_receipt_v0
  receipt_id: refuse_csv_without_sidecar
  receipt_digest: sha256:...
  rule_id: R-EGRESS-001-SIDECAR-OR-INBAND
  requested_surface:
    kind: csv
    surface_id: weekly_support_csv
  refused_reason: classification_pins_and_disclosure_cuts_would_be_dropped
  semantic_loss:
    - classification_pins
    - disclosure_cuts
    - suppression_witnesses
  problem_details:
    type: https://foundry.local/problems/egress/sidecar-or-inband-required
    title: Egress surface would drop semantic residue
    status: 422
    detail: Requested CSV has no in-band residue and no semantic sidecar.
    instance: foundry://fixtures/specimen-78/csv_without_sidecar
  required_escape:
    - emit_semantic_sidecar
    - request_row_preserving_json
    - use_native_lens_export
  non_retryable_without:
    - classification_pins
    - suppression_witnesses
    - loss_profile
```

The RFC 9457 shape is useful, but Foundry does not require HTTP. The receipt is a semantic refusal record, not a transport-layer doctrine.

### 2) egress manifest

An egress manifest is the batch-local ledger for attempted surfaces.

```yaml
egress_manifest:
  manifest_family: foundry_egress_manifest_v0
  manifest_digest: sha256:...
  source_result: result_weekly_support_001
  rule_suite_digest: sha256:...
  attempts:
    - attempt_id: chart_with_sidecar
      requested_surface: {kind: chart, surface_id: weekly_category_chart}
      outcome: passed
      sidecar_digest: sha256:...
    - attempt_id: csv_without_sidecar
      requested_surface: {kind: csv, surface_id: weekly_support_csv}
      outcome: refused
      receipt_id: refuse_csv_without_sidecar
```

The manifest does not become the source result. It records how the result tried to leave.

### 3) conformance gate

A conformance gate is the deterministic local rule suite that binds attempts to either sidecars or refusal receipts.

Minimum rules:

| Rule | Meaning |
| --- | --- |
| `R-EGRESS-001-SIDECAR-OR-INBAND` | an emitted thin surface must carry residue in-band or point at a sidecar |
| `R-EGRESS-002-NAMED-SEMANTIC-LOSS` | a refusal must name the residue that would be lost |
| `R-EGRESS-003-REPAIR-ESCAPE` | a refusal must name safe request alternatives |
| `R-EGRESS-004-CLASSIFICATION-PINS` | classification-heavy surfaces cannot leave as labels or bare codes |
| `R-EGRESS-005-CUT-MISMATCH` | materialized or balanced outputs cannot be reused across incompatible cuts |
| `R-EGRESS-006-STATUS-PRESERVATION` | adjusted, imputed, provisional, revised, or suppressed status must survive export |

## What this specimen proves

- Refusal is not a missing output.
- Refusal is not a policy verdict.
- Refusal is not a hidden checker log.
- Refusal is a durable artifact tied to the attempted surface and the lost meaning.

## What this specimen must keep separate

- semantic refusal versus authorization denial;
- refusal receipt versus exception stack trace;
- egress manifest versus source result envelope;
- conformance gate versus privacy, trust, or Ward verdict;
- repair escape versus automatic repair;
- problem-details shape versus HTTP-only semantics;
- receipt digest versus evidence completeness.

## Promotion gate for these nouns

Do not widen refusal receipts beyond egress conformance until:

- at least one non-SlopOS consumer uses the same receipt fields;
- one fixture proves a generic error is insufficient;
- one fixture proves a receipt without repair escapes is insufficient;
- one fixture proves semantic-loss names are needed for audit; and
- one sibling cube consumes a refusal without treating it as its own verdict.

## Why this matters

A system that only emits safe artifacts can still be bypassed by retrying unsafe shapes elsewhere. Foundry needs the refused attempt itself to carry enough truth that later tools can see what was blocked and why.
