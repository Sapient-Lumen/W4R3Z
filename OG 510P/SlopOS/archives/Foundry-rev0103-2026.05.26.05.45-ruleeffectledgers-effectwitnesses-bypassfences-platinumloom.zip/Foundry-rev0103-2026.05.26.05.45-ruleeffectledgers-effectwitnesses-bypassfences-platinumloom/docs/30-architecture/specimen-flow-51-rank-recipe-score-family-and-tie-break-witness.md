# Specimen flow 51 — rank recipe, score family, and tie-break witness

Goal: keep a future Foundry datacube honest when useful rows are surfaced in an advisory order, a relevance order, or a fused retrieval order before anyone can responsibly call the visible `score` one universal quantity.

## Scenario
A future SlopOS-neighbor support shell wants to show “most relevant artifacts for this incident” and “best matching knowledge chunks for this question” across one deployment.
It can see:
- one `D-ATTRFS` snapshot-first query over an explicit view,
- one derived-artifact semantic retrieval lane that returns vector-distance-ranked candidates,
- one hybrid retrieval path that fuses keyword and semantic evidence,
- one optional semantic reranker layered over an earlier top-k result set,
- and one export button that wants to dump `title`, `score`, and `rank` as if that were timeless truth.

A tempting but wrong move is to publish these as one family with fields like `rank`, `score`, and `page`.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every ranked or advisory-ordered value family carries three small semantic companions.

### 1) rank recipe
A compact witness for what ordering procedure actually produced the visible order.
Examples:
- explicit unscored field sort over one declared column set,
- BM25-style full-text relevance,
- vector distance ordering,
- hybrid fusion over keyword + vector retrieval,
- semantic rerank over an already-preranked top-k set,
- or one local heuristic ordering that is useful but advisory only.

The rank recipe is **not** a universal search plane.
It is just enough residue to stop “sorted list” from sounding like timeless object truth.

### 2) score family
A compact witness for what the visible score means.
Examples:
- **bm25-score** — higher is better, query-local, unbounded;
- **distance** — lower is better, metric-local;
- **fusion-score** — recipe-local combined score;
- **reranker-score** — second-stage semantic score, separate from the first retrieval phase;
- **unscored** — rows are ordered by one field or cursor rule, not by a comparable relevance quantity.

This keeps score direction, range posture, and comparability honesty visible.
The score family is **not** a global calibration plane.
It is simply enough residue to stop `0.82` and `0.82` from sounding like the same truth when they came from different rank families.

### 3) tie-break witness
A compact witness for how equal-score or equal-rank rows were stabilized.
Examples:
- explicit secondary order on one durable field,
- cursor seed plus stable sort tuple,
- owner-issued ordering token,
- export-time deterministic row key,
- or explicit `none` when no stable tie-break was preserved.

The tie-break witness is **not** a generic transaction-order or sequencing service.
It is just enough residue to keep repeated pages and exports from quietly reordering under ties.

## Why this seam is small enough now
It does **not** require:
- a universal search engine contract;
- one relevance score algebra across all families;
- a mandatory ranking phase for snapshot-first families;
- or a full evaluation product with judgments, labels, and metrics.

It only says that once values become ranked or advisory-ordered, Foundry should preserve:
1. what ordered them,
2. what their score numbers mean,
3. and how ties were stabilized.

## SlopOS mapping
- **ATTRFS snapshot-first query result**
  - rank recipe: often `unscored-view-order` or one explicit shell-local sort, because Phase 1 `CH-ATTRQ` forbids ranking/full-text expansion
  - score family: usually `unscored`
  - tie-break witness: explicit stable sort tuple or explicit `none`

- **future derived-artifact semantic retrieval**
  - rank recipe: vector-distance or semantic-retrieval recipe over derived artifacts, not over the quarantined source object by hidden lineage substitution
  - score family: `distance` or one metric-local similarity family with explicit direction
  - tie-break witness: stable object key/cursor tuple for equal distances

- **future hybrid retrieval lane**
  - rank recipe: named fusion strategy over keyword + semantic retrieval, kept visibly smaller than object truth
  - score family: `fusion-score`, not “same as BM25” and not “same as distance”
  - tie-break witness: explicit secondary sort/cursor rule for equal fused positions

- **second-stage semantic rerank**
  - rank recipe: reranker layered over one already-preranked candidate set
  - score family: distinct reranker score rather than silent overwrite of first-stage score meaning
  - tie-break witness: retained candidate-order fallback or explicit stable rerank tuple

## Anti-regrowth rules
- **rank smaller than truth**
- **score family smaller than meaning**
- **page stability smaller than population truth**
- **fusion smaller than natural law**

## Non-goals parked on purpose
- no universal search/retrieval product plane;
- no cross-query score calibration promise;
- no mandatory ranking contract for all query families;
- no giant search relevance metrics regimen.

## Resulting recommendation
When Foundry later accepts ranked or advisory-ordered values, it should add only this narrow seam:
- **rank recipe** for what produced the current order,
- **score family** for what the visible score means,
- **tie-break witness** for how ties were stabilized.

That is enough to keep early datacube ranking semantics honest while SlopOS and the neighboring archives are still evolving.
