# Specimen flow 31 — holder epoch, fence token, and stale-holder cut

Goal: keep “a newer holder is current now” separate from “older holders have definitely lost the power to mutate, serve, or commit work”.

## Scenario
A foreign-backed realization has one role that is meant to be singular enough for correctness: writer, active owner, transaction coordinator, activation issuer, or mutable-service head.
A failover or restart elects or creates a newer holder.
That alone is not enough.
The older holder might still be running after a pause, partition, or delayed shutdown.
It might still have open sockets, cached authority, or a path that looks live enough to keep issuing writes or serving stale answers.

The monotonic assignment version for that reassignable role is the **holder epoch**.
It says which claimant is the current one for mutation or singular service authority.

But just naming the current holder is still smaller than downstream safety.
The mutable receiver, journal, or resource manager often needs one exact value to reject stale actors.
That checked witness is the **fence token**.
It can be an epoch, generation, producer epoch, or other monotonic ownership token.
Without such a check, old holders may continue doing real damage after a newer holder is already “current” on paper.

The point where a prior holder becomes non-authoritative even if it is still alive is the **stale-holder cut**.
After that cut, an old holder may still drain, observe, or even answer clearly stale reads in some designs, but it must not keep mutating or impersonating the current singular owner.

This keeps three facts separate:
- who is currently supposed to own the singular mutable lane,
- what exact witness downstream systems should check to reject older claimants,
- and when a prior holder crosses from “old but still present” into “stale and non-authoritative”.

## Proposed Foundry objects
1. **holder epoch**
   - monotonic ownership/version step for one singular mutable or serving role;
   - keeps “current owner” smaller than “all older holders are definitely gone”.

2. **fence token**
   - exact checked witness that mutable receivers use to reject stale holders;
   - keeps failover correctness smaller than graceful shutdown folklore.

3. **stale-holder cut**
   - explicit boundary after which an older holder may no longer mutate or claim current singular authority;
   - keeps “still alive” separate from “still allowed”.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a restarted or failover successor is current but the predecessor may still be paused or partitioned;
- downstream mutators need a monotonic token to reject zombie writers;
- writes are fenced while stale reads or drain may still linger briefly;
- and operators need a public explanation for why “new active” did not by itself make old actors harmless.

## Adjacent but parked
- **observer-only tail** — future residue for older holders that may still answer bounded stale reads after losing write authority.
- **fence-failure debt** — future explanation surface for “new owner elected, but old path not yet conclusively fenced”.

## Promotion rule
Do not promote `holder epoch`, `fence token`, or `stale-holder cut` unless they improve:
- one zombie-writer or producer-epoch specimen,
- one leader-election or HA specimen where currentness alone is explicitly not enough,
- and one activation or handle-handoff specimen where old presence must be smaller than present authority.
