# Specimen flow 30 — exposure frontier, stability fence, and withheld tail

Goal: keep “this subject has loaded/applied newer state” separate from “this is the newest point readers, traffic, or queries may honestly observe right now”.

## Scenario
A foreign-backed subject follows some authoritative stream or receives dynamic config updates.
It may already have newer material in hand.
Perhaps a replica has replayed farther into a log, a proxy has loaded new listeners or clusters, or a consumer has fetched records beyond the point it is allowed to expose.
That local ingest point may already outrun what the system should safely present outward.

The highest point the subject may honestly expose to readers, queries, or traffic now is the **exposure frontier**.

Why might exposure stop short of newer local or authoritative state?
Because one explicit boundary still blocks it.
Perhaps a listener or cluster is still warming.
Perhaps an open transaction means newer records must be withheld from `read_committed` consumers.
Perhaps bounded-staleness or closed-timestamp rules mean a replica may only serve reads through an older safe point.
That blocking condition is the **stability fence**.

Everything newer than the exposure frontier but still present in committed history, local buffers, local replay, or local config state is the **withheld tail**.
The withheld tail is not an error-shaped void.
It is exact newer state that remains intentionally outside current exposure.

This keeps three facts separate:
- what the authority has durably accepted,
- what one subject has locally applied/loaded,
- and what that subject may honestly expose now.

## Proposed Foundry objects
1. **exposure frontier**
   - highest point one subject may honestly expose to readers, queries, or traffic now;
   - keeps current outward truth smaller than local ingest or authoritative history.

2. **stability fence**
   - dependency, isolation, warmup, or safety boundary that blocks newer state from immediate exposure;
   - keeps “not yet active/visible” explicit instead of hiding it inside vague readiness or lag folklore.

3. **withheld tail**
   - the newer committed/loaded/applied range that remains intentionally outside the current exposure frontier;
   - keeps hidden-newer-state legible instead of pretending the frontier is the whole local story.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a proxy has loaded new config but still serves the old active set;
- a consumer or replica has newer data locally but may only expose a safer older cut;
- transactional, warming, or bounded-staleness rules intentionally withhold the newest tail;
- and users need to know whether a subject is merely behind, or is deliberately serving an older frontier.

## Adjacent but parked
- **active-set badge** — compact residue for what cut is actually serving now.
- **warmup debt** — future explanation surface for why one loaded update is still behind the stability fence.

## Promotion rule
Do not promote `exposure frontier`, `stability fence`, or `withheld tail` unless they improve:
- one dynamic-config warming specimen,
- one transactionally withheld or read-safe visibility specimen,
- and one status/readiness specimen where “loaded” or “applied” would otherwise overclaim what users or traffic can actually observe.
