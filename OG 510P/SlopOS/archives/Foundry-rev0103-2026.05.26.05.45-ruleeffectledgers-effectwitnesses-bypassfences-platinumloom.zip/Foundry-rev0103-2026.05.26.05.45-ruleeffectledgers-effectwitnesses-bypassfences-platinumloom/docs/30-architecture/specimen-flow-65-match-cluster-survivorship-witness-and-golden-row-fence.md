# Specimen flow 65 — match cluster, survivorship witness, and golden-row fence

Goal: keep a future Foundry datacube honest when several imported or observed rows may describe the same subject, but the archive is not ready to freeze one native “golden record” ontology.

## Scenario
A future support workspace wants one “subject summary” panel spanning design-phase SlopOS identity/profile/import surfaces.
It can see:
- one `userinfo_claim_rows` table with imported profile/email/name claims;
- one `subject_hint_rows` table with local hints or manually attached labels;
- one `verification_rows` table with family-local check results;
- and one `display_summary_rows` export used by a UI.

A tempting but wrong move is to collapse everything into one reusable `subject_current` row and let later readers treat that row as native truth.
That would be misleading.
Several rows may only be **duplicate candidates**, the chosen visible representative may depend on a local survivorship rule, and the result may only be lawful for display or review.

## Small seam to prove

### 1) match cluster
Every duplicate-sensitive summary carries a compact witness that several rows are candidate same-subject material.
Examples:
- `candidate_same_subject_cluster`
- `candidate_same_artifact_cluster`
- `candidate_same_profile_cluster`

This keeps clustering smaller than identity.

### 2) survivorship witness
Every representative row carries a compact witness for how it was chosen.
Examples:
- `source_priority_rule`
- `latest_by_declared_ordering_basis`
- `completeness_preference`
- `manual_review_choice`
- `policy_local_tie_break`

This keeps “winner” visibly smaller than ontology.

### 3) golden-row fence
Every such representative row carries a compact guardrail for what later reuse is lawful.
Examples:
- `display_only`
- `merge_target_only`
- `review_queue_only`
- `not_subject_truth`
- `forbidden`

This stops exports and dashboards from silently promoting a convenient survivor row into permanent archive law.

## Example residue

```text
cluster_summary:
  subject: slopos.import.identity.cluster
  cluster_class: candidate_same_subject_cluster
  member_count: 3
  representative_row: userinfo_row_17
  survivorship_witness: source_priority_rule
  golden_row_fence: display_only

cluster_summary:
  subject: slopos.import.profile.cluster
  cluster_class: candidate_same_profile_cluster
  member_count: 2
  representative_row: profile_row_04
  survivorship_witness: manual_review_choice
  golden_row_fence: review_queue_only
```

## What this specimen proves
Foundry can preserve deduplication honesty with three compact residues instead of inventing:
- a global master-data subsystem,
- a universal survivorship algebra,
- or a permanent “golden row” ontology.

The cube only needs to say:
1. **which rows are only a candidate cluster,**
2. **how a representative was chosen,**
3. and **where that representative must not impersonate native truth.**

## Why this belongs in Foundry
SlopOS already separates imported identity/profile material, native claims, local verdicts, and non-claims.
That makes representative rows useful but dangerous.
This specimen gives Foundry the smallest honest way to preserve that fact when future exports and support panels start clustering duplicate candidates.

## What stays parked
- no archive-wide golden-record doctrine;
- no mandatory deduplication engine;
- no universal survivorship grammar;
- no promise that representative rows are safe historical or semantic truth.
