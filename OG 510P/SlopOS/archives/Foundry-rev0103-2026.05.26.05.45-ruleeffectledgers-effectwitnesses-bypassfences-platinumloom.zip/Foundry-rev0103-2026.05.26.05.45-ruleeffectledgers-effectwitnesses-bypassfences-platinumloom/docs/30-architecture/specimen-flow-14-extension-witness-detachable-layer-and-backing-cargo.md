# Specimen flow 14 — extension witness, detachable layer, and backing cargo

Goal: keep compatibility check, merge posture, and content backing visibly separate.

## Scenario
A foreign extension wants to join a base system or realization.
Before attachment, the extension presents a compact compatibility witness showing it matches the intended base.
The structural layer can be mounted or merged and later removed again.
Its non-empty file content lives in a backing cargo store that may be shared or verified separately from the structural layer.

## Proposed Foundry objects
1. **extension witness**
   - compact residue that the foreign layer is compatible with the base it wants to join;
   - stronger than ambient optimism and weaker than durable adoption.

2. **detachable layer**
   - attached foreign merge that remains visibly removable or rollback-capable;
   - useful precisely because success does not mean assimilation.

3. **backing cargo**
   - the content store behind a mountable structural layer;
   - can have its own locality, sharing, and integrity story.

4. **structure/cargo split**
   - standing reminder that structural witness and backing content witness are different truths.

## Why this specimen matters
It pressure-tests whether Foundry can remain honest when:
- compatibility is checked before attach,
- removal and rollback remain legitimate futures,
- the structural layer and the backing cargo do not share one locality story,
- and successful attach still does not make the foreign layer native.

## Promotion rule
Do not promote `extension witness`, `detachable layer`, `backing cargo`, or `structure/cargo split` unless they improve:
- one compat-checked attach specimen,
- one detach/rollback specimen,
- and one structure/cargo split specimen.

