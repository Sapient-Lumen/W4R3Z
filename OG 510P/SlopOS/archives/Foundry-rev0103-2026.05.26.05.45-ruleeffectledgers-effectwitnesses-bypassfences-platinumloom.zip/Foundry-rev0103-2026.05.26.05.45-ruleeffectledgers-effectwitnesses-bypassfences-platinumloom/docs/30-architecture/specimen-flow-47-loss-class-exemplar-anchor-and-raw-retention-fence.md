# Specimen flow 47 — loss class, exemplar anchor, and raw-retention fence

Goal: keep a future Foundry datacube honest when neighboring archives emit faster summaries, rollups, or bundle-level views that are useful to query but no longer preserve full raw evidence shape.

## Scenario
A future Foundry read surface wants to summarize current diagnostic posture across one SlopOS deployment.
It can see:
- one ATTRFS smart-query count over an explicit view and cut;
- one inspect-derived health trend built from CH-INSPECT snapshots where richer structures were flattened into bounded counters/gauges;
- one incident summary row extracted from a CH-SNAPSHOT manifest;
- and one accelerated read-model row built from a pre-aggregated materialization over pinned source data.

A tempting but wrong move is to publish all of these as plain values with labels, timestamps, and a recipe witness.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every summarized or accelerated value carries three small semantic companions.

### 1) loss class
A compact witness for what kind of source fidelity changed.
Examples:
- **row-preserving** — raw row or exact object still individually queryable through the same value family;
- **attribute-lossy** — some dimensions/attributes were intentionally dropped during legal reaggregation;
- **bucketized** — raw events collapsed into counts, sums, or histogram-like buckets;
- **sketch-like** — raw membership compressed into a probabilistic or bounded-approximation structure;
- **summary-only** — value is a compact synopsis that does not pretend to preserve row-level or event-level freedom.

This keeps “fast to chart” visibly smaller than “fully faithful to raw evidence.”

### 2) exemplar anchor
A bounded breadcrumb to one or a few concrete contributing artifacts outside the summary itself.
Examples:
- a CH-AREF or digest for one diagnostic bundle entry;
- one exact inspect snapshot digest;
- one trace/incident/sample id;
- one representative raw artifact handle still reachable under the same policy/view.

The exemplar anchor is **not** full lineage.
It is a compact drill-through hint that proves the summary still touches concrete evidence somewhere.

### 3) raw-retention fence
A compact witness describing whether the narrower evidence still exists and how reachable it is.
Examples:
- **retained-hot** — raw source is still queryable directly on the ordinary path;
- **retained-cold** — raw source exists, but only behind archival/slow/costly access;
- **policy-blocked** — raw source exists but ordinary consumers may not drill through under current view/redaction policy;
- **expired** — raw source is gone and only the summarized residue remains.

This keeps “valid summary” visibly separate from “drill-through still possible.”

## Why this seam is small enough now
It does **not** require:
- a universal lineage graph;
- a mandatory exemplar store;
- one raw-retention policy family for the whole ecology;
- or a built-in rollup/projection planner.

It only says that once a value stops being plainly raw, Foundry should preserve:
1. what kind of loss happened,
2. whether a bounded breadcrumb remains,
3. and whether the narrower evidence still survives.

## SlopOS mapping
- **ATTRFS count over a view**
  - loss class: `summary-only`
  - exemplar anchor: optional one matching handle digest if policy/view allows
  - raw-retention fence: usually `retained-hot` or `policy-blocked`, depending on the view and downstream open rights

- **CH-INSPECT-derived health trend**
  - loss class: `bucketized` or `attribute-lossy`, depending on whether richer structures were flattened into counters/gauges or whether dimensions were intentionally dropped
  - exemplar anchor: optional exact snapshot digest for one contributing cut
  - raw-retention fence: `retained-hot`, `retained-cold`, or `expired` depending on snapshot retention policy

- **CH-SNAPSHOT incident summary row**
  - loss class: `summary-only`
  - exemplar anchor: one digest/CH-AREF entry from the underlying bundle
  - raw-retention fence: often `retained-cold` because the bundle persists but is no longer the ordinary read path

- **accelerated read-model row over pinned source data**
  - loss class: usually `attribute-lossy` or `bucketized`
  - exemplar anchor: optional pinned raw partition/object/sample digest
  - raw-retention fence: explicit and separate from refresh or replay posture

## Anti-regrowth rules
- **summary smaller than raw fidelity**
- **breadcrumb smaller than lineage graph**
- **retained summary smaller than retained raw evidence**
- **projection smaller than source truth**

## Non-goals parked on purpose
- no promise that every summary has an exemplar anchor;
- no promise that every raw source must be retained;
- no universal drill-through endpoint family;
- no assumption that one loss taxonomy should cover every future approximation engine.

## Resulting recommendation
When Foundry later accepts accelerated or summarized values, it should add only this narrow seam:
- **loss class** for what was discarded or compressed,
- **exemplar anchor** for a bounded breadcrumb back to concrete evidence when available,
- **raw-retention fence** for whether drill-through remains possible.

That is enough to keep early datacube acceleration honest while SlopOS and the neighboring archives are still evolving.
