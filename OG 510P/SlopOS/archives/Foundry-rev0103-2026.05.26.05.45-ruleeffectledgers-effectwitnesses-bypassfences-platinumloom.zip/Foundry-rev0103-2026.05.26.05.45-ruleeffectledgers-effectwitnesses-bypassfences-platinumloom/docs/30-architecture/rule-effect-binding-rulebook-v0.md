# Rule-effect binding rulebook v0

This rulebook belongs to specimen 97. It defines tiny fixture-local checks for rule-effect ledgers, effect witnesses, and bypass fences.

## Rules

- `R-EFFECT-001-RULE-EFFECT-LEDGER` — every rule result that is claimed to change a carrier, egress, projection, warning, quarantine, or no-op state needs a rule-effect ledger that links source rule-evaluation traces, source applicability witnesses, source misapplication fences, effect context, intended effects, bound effects, required effect witnesses, required bypass fences, blocked inferences, and authority boundaries.
- `R-EFFECT-002-SOURCE-LINKAGE` — effect ledgers must link to known specimen 96 rule-evaluation traces, applicability witnesses, and misapplication fences; unknown ids, digest mismatches, or source refs outside the local fixture fail closed.
- `R-EFFECT-003-CONTEXT-ECHO` — effect witnesses must echo consumer, surface, audience, purpose, carrier, and rule target so a rule result cannot be rebound to a different context.
- `R-EFFECT-004-APPLICATION-IS-NOT-EFFECT` — a rule-evaluation trace, selected rule, output decision, default outcome, warning, audit annotation, or checker success message is not a bound effect without an effect ledger and effect witness.
- `R-EFFECT-005-WEAK-RESULTS-STAY-WEAK` — warn-only, audit-only, informational, no-effect, deprecated, shadow-only, skipped, or default outcomes must not be laundered into refusal, approval, denial, release, mutation, or completion effects.
- `R-EFFECT-006-BYPASS-FENCE` — missing effect witness, wrong surface, scope widening, shadow/deprecated/default activation, ambiguity-fence erasure, checker-success-as-effect, public-release laundering, authorization/audit laundering, repair/lifecycle laundering, sibling-boundary laundering, and reference-integrity drift require bypass fences.
- `R-EFFECT-007-BOUND-EFFECTS-MATCH-STATUS` — bound, partial, and quarantined ledgers need bound effect descriptions; refused, no-effect, and informational ledgers must not smuggle bound effects.
- `R-EFFECT-008-REFERENCE-INTEGRITY-INDEX` — source ids and new fixture ids must appear in a machine-readable reference-integrity index so cross-specimen effect chains cannot rely on dangling references or renamed ids.
- `R-EFFECT-009-BYPASS-DETECTION-STAYS-VISIBLE` — a detected bypass is not silently folded into the successful effect path; it must remain a witness/fence pair until repaired or explicitly quarantined.
- `R-EFFECT-010-AUTHORITY-LAUNDERING-FENCE` — effect ledgers, effect witnesses, and bypass fences must not become source truth, authorization, audit opinion, public-release approval, legal compliance, policy approval, repair success, lifecycle finality, or sibling authority.

## Required negative cases

A valid specimen 97 fixture must include failure cases for evaluation-without-effect, effect-without-trace, effect-without-ledger, missing effect witness, missing bypass fence, wrong surface, scope widening, shadow rule as effect, deprecated rule as current effect, default outcome as effect, warning-as-enforcement, audit-only-as-block, public-release laundering, authorization laundering, audit laundering, repair/lifecycle laundering, sibling-authority laundering, informational-as-effect, ambiguity-as-effect, checker-success-as-effect, reference-integrity drift, runner-order-as-effect, evidence-reference mismatch, and no-op-as-success.

## Containment

These rules do not define an enforcement runtime, authorization layer, admission controller, mutation engine, feature-flag service, policy engine, audit product, public-release approval system, compliance system, deletion system, repair workflow, lifecycle authority, sibling verdict, or governance registry. They only ensure that a rule application result cannot be displayed as having changed a semantic carrier unless the effect residue and bypass risks are explicit.
