# Specimen flow 09 — restore obligation, availability class, and referrer fallback

Goal: keep resume, capability presence, and sidecar discovery honest without bloating the live realization story.

## Scenario
A foreign realization is resumed from a snapshot. It expects:
- one required foreign service route,
- one optional auxiliary capability,
- and subject-attached sidecars discoverable through OCI referrers when the registry supports them.

After restore:
- uniqueness must be regenerated,
- the optional capability is unavailable,
- and the registry falls back to tagged-index attachment discovery.

## Proposed Foundry objects
1. **restore obligation card**
   - records post-restore duties such as uniqueness repair, secret refresh, reconnect, or metadata refresh.

2. **availability class**
   - says which foreign power was required, optional, or unavailable.

3. **referrer fallback card**
   - says sidecar discovery degraded from native referrers to fallback-tag/index mode.

4. **adoption rail**
   - keeps restored, repaired, sidecar-discovered, and finally adopted as separate steps.

## Why this specimen matters
It pressure-tests whether Foundry can remain truthful when everything “mostly works” but not in the strongest form.

## Promotion rule
Do not promote `restore obligation card`, `availability class`, or `referrer fallback card` unless they improve one snapshot specimen, one routed-virtualization specimen, and one subject-sidecar specimen.
