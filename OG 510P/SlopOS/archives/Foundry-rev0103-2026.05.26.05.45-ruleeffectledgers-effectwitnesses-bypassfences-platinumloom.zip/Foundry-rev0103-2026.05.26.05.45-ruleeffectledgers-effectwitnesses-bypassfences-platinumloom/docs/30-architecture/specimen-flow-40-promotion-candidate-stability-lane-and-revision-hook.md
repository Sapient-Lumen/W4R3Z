# Specimen flow 40 — promotion candidate, stability lane, and revision hook

Goal: keep a future Foundry datacube export honest while the cube is still changing underneath it.

## Scenario
A future SlopOS-facing surface wants a compact Foundry datacube export.
The tempting mistake is to freeze a large field catalog immediately so dashboards, policies, and neighboring cubes can all code against it.
That feels efficient for one revision and becomes expensive for every later revision.

Instead, the export stays smaller and more honest.

First, one newly useful noun appears only as a **promotion candidate**.
It is visible because one specimen and one research pass need it, but the archive is not yet claiming that every later revision must keep it forever.

Second, the export marks the noun’s **stability lane**.
A consumer can see that this field or relation is candidate or development posture rather than silently assuming stable contract weight.

Third, the export carries a **revision hook**.
Any status card, read model, or export surface says exactly which Foundry revision and vocabulary it reflects.
A slower consumer can therefore decide whether it understands this export, whether it should ignore candidate fields, or whether it needs a later transform.

## Proposed Foundry objects
1. **promotion candidate**
   - a plausible noun, field, or relation under active pressure but not yet durable archive truth.

2. **stability lane**
   - explicit posture such as candidate, development, stable, deprecated, or parked.

3. **revision hook**
   - exact archive/revision identity on a status or export surface so readers know what vocabulary it reflects.

## Why this specimen matters
It pressure-tests whether Foundry can:
- publish something useful before the datacube is fully settled;
- keep candidate fields visible without overpromising permanence;
- let downstream consumers reason about lag, transforms, and unknown fields safely;
- avoid turning one convenient JSON shape into permanent ontology.

## Adjacent but parked
- **schema-url registry** — future, only if more than one consumer genuinely needs independent vocabulary tracks.
- **transform catalog** — future, only if more than one durable revision needs explicit cross-revision conversion.
- **lane-policy matrix** — future, only if candidate/deprecated handling becomes operationally load-bearing across several specimens.
