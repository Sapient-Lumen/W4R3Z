# Specimen flow 95 — rule-collision ledger, precedence witness, and ambiguity fence

Goal: make post-promotion rule overlap falsifiable without turning Foundry into a policy engine, rule scheduler, governance process, admission controller, authorization system, public-release approver, audit product, repair workflow, lifecycle authority, or sibling-verdict system.

## Scenario

Specimen 94 records precedent ledgers, rule-promotion witnesses, and overgeneralization fences. That prevents a local closure from becoming reusable archive law without scoped evidence. A new failure appears once more than one local rule is valid: two promoted or candidate rules can overlap on the same consumer, surface, audience, purpose, carrier, checker, or rulebook sentence, and each can appear correct in isolation.

A SlopOS support-card refusal rule, Ward preview caveat rule, ViewFS projection quarantine rule, public-link no-reexport rule, Harbor handoff rule, and external-audit notebook rule can all be locally well-promoted while disagreeing about whether a result should pass, warn, quarantine, refuse, or remain shadow-only. Foundry must record where the overlap exists, what precedence was chosen for a bounded scope, which evidence backs that precedence, and which ambiguous or contradictory uses stay fenced.

## Nouns under test

- **Rule-collision ledger** — a bounded carrier for promoted/candidate rule refs, source precedents, source promotion witnesses, overlapping scope, collision class, required precedence witnesses, required ambiguity fences, residual fences, and refused authority.
- **Precedence witness** — scoped evidence that a collision was resolved as applied, partial, shadow-only, refused, expired, or superseded for a named consumer/surface/audience/purpose/carrier/rule target, with winning/losing rule refs, basis refs, negative cases, and blocked inferences.
- **Ambiguity fence** — a refusal around overlapping, contradictory, equal-priority, stale, shadow/deprecated, checker/rulebook divergent, public-release-laundered, authorization-laundered, lifecycle-laundered, or sibling-verdict-laundered rule use.

## Fixture requirements

The specimen 95 fixture must include:

- source precedent ledgers, rule-promotion witnesses, and overgeneralization fences from specimen 94 pressure;
- promoted, candidate, partial, shadow, deprecated, and superseded rule refs across SlopOS, Ward, ViewFS, Harbor, public-link, worker, and external-audit surfaces;
- detected, precedence-assigned, unresolved, quarantined, superseded, and non-conflict collision ledgers;
- applied, partial, refused, shadow-only, expired, and superseded precedence witnesses;
- ambiguity fences for equal-priority overlap, contradictory outcomes, missing precedence witness, stale rule surface, deprecated/shadow activation, checker/rulebook divergence, scope widening, public-release laundering, authorization/audit laundering, repair/lifecycle laundering, and sibling-verdict laundering;
- explicit winner/loser posture that stays local to the collision scope and does not become global rule priority;
- rule-surface refs that can be cross-checked by the rule-surface index; and
- negative cases for missing collision ledger, missing precedence witness, missing ambiguity fence, unknown rule ref, unknown precedent ledger, unknown promotion witness, equal-priority unresolved, contradictory outcomes accepted, scope widening, shadow rule applied, deprecated rule applied, stale rule accepted, checker/rulebook divergence, missing negative cases, precedence-as-authorization, precedence-as-audit, precedence-as-public-release, precedence-as-repair, precedence-as-lifecycle-finality, precedence-as-sibling-verdict, and rule-surface-index drift.

## Rules

See [`rule-collision-rulebook-v0.md`](rule-collision-rulebook-v0.md).

## Non-goals

- no policy engine, rule engine, governance workflow, standards process, admission controller, authorization model, public-release approval, legal-compliance model, audit opinion, risk acceptance, deletion, retention, custody, repair, lifecycle, or sibling-verdict model;
- no global precedence ranking, severity ordering, priority taxonomy, conflict-resolution calculus, or compatibility registry;
- no guarantee that a chosen precedence is right outside its named consumer/surface/audience/purpose/carrier/rule target;
- no conversion of rulebook order, checker order, filename order, route order, or reviewer preference into semantic truth; and
- no replacement for egress, regression, waiver, portability, delegation, revocation, remediation, distribution, inventory, exposure, obligation, fulfillment, verification, recheck/drift, routing, disposition, or rule-promotion checks.

## Promotion status

Fixture-local. The nouns are useful only while they prevent separately promoted rules from colliding invisibly. Promotion requires generated collision tamper cases plus at least one second non-SlopOS consumer whose precedence choice differs from SlopOS support-card semantics without becoming policy/governance machinery.
