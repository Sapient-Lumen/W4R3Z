# Promotion gates and specimen tests

Foundry should not promote a new durable noun unless it survives at least one specimen flow.

## Promotion gates
1. A proposed object must say whether it describes a package, runtime contract, live realization, or continuity claim.
2. It must survive at least one OCI-style flow and one component-model flow without changing meaning.
3. It must declare which downgrade or foreignness signals remain visible.
4. It must identify which trust questions are exported to Ward rather than answered locally.

## First specimen tests
- OCI image versus runtime bundle versus live VM-backed container;
- Wasm world/interface contract versus ambient host assumption;
- snapshot restore with explicit uniqueness/network/ephemeral-data hazards;
- confidential runtime flow where evidence is exported but verdict stays outside Foundry.

- grouped multi-resource basis target with uncertain prior confirmation and explicit supersession hold.
- floating branch/channel/ref selector with exact basis pin and explicit drift fence.
- rollback-floor specimen with explicit post-success ratchet and separate rescue path.
- hot-restart or rolling-replacement specimen with explicit admission cut, drain epoch, and grace fence.

## rev0079 specimen test addition
- aggregate-release specimen with direct suppression, complementary suppression or paired-release refusal, privacy-unit basis, perturbation/noise posture, and differencing refusal.

## rev0083 specimen test addition
- egress-survival specimen with one table/chart/CSV/JSON/support-card path that carries residue by sidecar and one path that must refuse label-only, code-only, status-free, suppression-free, or balance-free flattening.
