# Specimen flow 25 — retention root, reclaim fence, and cleanup debt

Goal: keep “this basis or snapshot is no longer current” separate from “ordinary reclamation may now destroy it”.

## Scenario
A subject has already moved on to a newer blessed basis.
The previous basis is not current anymore, but operators still want it available as a rollback selector, an audit target, a migration checkpoint, or a recovery anchor.
That exact previous basis therefore carries a **retention root**.
The root may be a generation reference, an explicit pin, a lease, a named hold, or another bounded reason that says “keep this exact material alive”.

Later, ordinary pruning or garbage collection begins.
Even then, reclamation may still need to stop at a **reclaim fence** because something else is not done yet:
- a mounted or staged consumer still depends on the content,
- a state snapshot or export has not finished,
- a remote backing object or clone has not been cleaned up,
- or policy still requires an explicit operator-visible release step.

That unresolved work is **cleanup debt**.
It is smaller than currentness, smaller than approval, and smaller than basis truth itself.
But it is still load-bearing for collectability.
Only after the cleanup debt clears and the retention root is intentionally released may the old basis, snapshot, or adjunct evidence become ordinarily reclaimable.

This keeps history, rollback value, retention, cleanup, and collectability visibly distinct.

## Proposed Foundry objects
1. **retention root**
   - explicit reason or reference that keeps exact material alive beyond current use;
   - may back rollback, audit, migration, recovery, staged export, or another bounded future-need claim.

2. **reclaim fence**
   - explicit blocker that prevents ordinary prune/delete/GC from proceeding yet;
   - keeps “intended to remove” separate from “safe to reclaim now”.

3. **cleanup debt**
   - explicit outstanding work that must finish before a reclaim fence can fall;
   - may cover export completion, dependency teardown, remote cleanup, or operator-visible release steps.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- rollback-valuable generations are older but still intentionally rooted,
- pinned deployments or snapshots should survive default cleanup,
- future-needed staged content is not currently active,
- deletion requests still need explicit cleanup before storage may disappear,
- and audit or recovery material should stay alive without pretending it is current.

## Adjacent but parked
- **collectability class** — compact label for retained, reclaim-blocked, or collectible posture.
- **release witness card** — compact residue that cleanup debt cleared and a retention root was intentionally dropped.

## Promotion rule
Do not promote `retention root`, `reclaim fence`, or `cleanup debt` unless they improve:
- one generations-plus-gc specimen,
- one pinned deployment/snapshot/lease specimen,
- and one delete-needs-cleanup specimen where intended removal is still smaller than actual collectability.
