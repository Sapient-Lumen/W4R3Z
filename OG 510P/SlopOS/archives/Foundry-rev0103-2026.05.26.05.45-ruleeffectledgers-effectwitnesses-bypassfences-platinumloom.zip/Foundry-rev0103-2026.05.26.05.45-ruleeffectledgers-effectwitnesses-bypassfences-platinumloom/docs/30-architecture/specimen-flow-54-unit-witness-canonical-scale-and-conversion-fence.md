# Specimen flow 54 — unit witness, canonical scale, and conversion fence

Goal: keep a future Foundry datacube honest when visible values carry units, scales, or display transforms that should not collapse into one generic numeric field.

## Scenario
A future SlopOS-neighbor operations shell wants one “resource posture” panel for a capsule and its nearby support surfaces.
The panel combines five upstream values:
- `mem_bytes_remaining` from D-METER;
- `net_bytes_sent_total` from an exported transport summary;
- `request_duration_ms_p95` from an imported analysis job;
- `cpu_utilization_percent` from a support chart;
- and `cap_slots_remaining` from a kernel-object budget summary.

A tempting but wrong move is to flatten these into one generic value family with only `name` and `value`:
- `memory_remaining = 2147483648`
- `network_sent = 98304`
- `request_p95 = 187`
- `cpu_utilization = 87`
- `cap_slots_remaining = 42`

That would be misleading.
Some values are bytes, some are seconds-in-disguise, some are display percentages that should really be ratios, and some are count-like non-units.
Some can be linearly converted, some only reformatted for display, and some should not be normalized across families at all.

## Small seam to prove

### 1) unit witness
Every unit-bearing or count-like value carries a compact witness such as:
- `By`
- `s`
- `1`
- `{cap_slot}`
- `provider_native`
- `other_explicit_unit`

This keeps the visible value from pretending that its unit is obvious from context.

### 2) canonical scale
Every unit-bearing family carries a compact preferred interchange scale such as:
- `bytes`
- `seconds`
- `ratio`
- `count_like`
- `native_only`

This keeps pretty display units smaller than storage and comparison truth.

### 3) conversion fence
Every unit-bearing family carries a compact guardrail for downstream conversion:
- `linear`
- `affine`
- `display_only`
- `contextual`
- `forbidden`

This stops percentages, provider-native credits, and arbitrary local quantities from silently becoming comparable to base-unit measures.

## What this specimen proves
Foundry can preserve unit and scale honesty with three compact residues instead of inventing:
- a universal unit registry,
- a math engine for every conversion,
- or a formatting policy for every shell.

The cube only needs to say:
1. **what unit** the value carries,
2. **what canonical scale** the family prefers,
3. and **what kind of conversion** is lawful.

## Example residue

```text
visible_value:
  subject: capsule.alpha
  measure: mem_remaining
  value: 2147483648
  unit_witness: By
  canonical_scale: bytes
  conversion_fence: linear

visible_value:
  subject: capsule.alpha
  measure: cpu_utilization
  value: 0.87
  unit_witness: 1
  canonical_scale: ratio
  conversion_fence: display_only

visible_value:
  subject: capsule.alpha
  measure: cap_slots_remaining
  value: 42
  unit_witness: {cap_slot}
  canonical_scale: count_like
  conversion_fence: forbidden
```

## Why this belongs in Foundry
SlopOS already puts explicit pressure on bytes, time, utilization, and count-like resource families without yet promising one giant normalization layer.
This specimen gives Foundry the smallest honest way to preserve that fact when future dashboards, exports, and derived summaries start mixing base units, pretty display scales, and provider-native quantities.

## What stays parked
- no universal unit registry;
- no automatic display-unit chooser;
- no global conversion engine;
- no promise that every provider-native quantity can be compared or valued across families.
