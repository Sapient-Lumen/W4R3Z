# Specimen flow 10 — borrowed handle, restore budget, and capability grade

Goal: keep foreign-backed handles, post-restore obligations, and degraded foreign power honest without inflating them into one fuzzy readiness story.

## Scenario
A foreign realization resumes from a snapshot and reopens:
- a resource handle to a host-backed secret or device,
- one required routed capability,
- one optional helper capability,
- and one subject-attached sidecar discovered through a fallback index.

The runtime can keep serving only if:
- the borrowed handle is still valid,
- after-restore reinitialization stays within budget,
- and the required capability remains present.

## Proposed Foundry objects
1. **borrowed handle card**
   - records that the useful thing is still owned outside the realization;
   - distinguishes borrow/ownership posture from plain data.

2. **restore budget**
   - says how much restore work or delay is acceptable before readiness narrows.

3. **capability grade**
   - records required, optional, degraded, or absent foreign power.

4. **adoption rail**
   - keeps resumed, reinitialized, reborrowed, and fully adopted as separate steps.

## Why this specimen matters
It pressure-tests whether Foundry can stay truthful when resumed work is viable but only through still-foreign handles and still-graded capability presence.

## Promotion rule
Do not promote `borrowed handle card`, `restore budget`, or `capability grade` unless they improve one WIT/resource specimen, one snapshot/restore specimen, and one routed-capability specimen.
