# Specimen flow 90 — verification audit, evidence sample, and false-closure fence

Goal: make post-fulfillment verification explicit without turning Foundry into an audit opinion, certification program, compliance framework, cryptographic proof system, workflow engine, authorization system, legal-compliance system, custody model, repair workflow, or sibling-cube verdict.

## Scenario

Specimen 89 proved that Foundry can account for whether acknowledged semantic obligations were fulfilled, partially fulfilled, missed, refused, quarantined, or fenced. A new failure remains: a completion witness can be self-reported, stale, sampled too narrowly, contradicted by probe evidence, signed by the wrong verifier, or copied from another consumer's scope.

A SlopOS dashboard, external-audit CSV, Ward preview, ViewFS projection, delegated-worker cache, and public-link scan now have fulfillment receipts and completion witnesses. Foundry must now record which completion claims were actually checked: whether sidecar references still resolve, classification pins match the result surface, observation-status badges remain visible, recall routes work, no-reexport fences still block shadow exports, quarantine is actually applied, and sibling non-promises remain visible. Verification can pass, partially pass, be inconclusive, be blocked, or discover false closure. Each outcome must preserve scope, sample basis, independent verifier posture, contradictory evidence, and non-promises.

## Nouns under test

- **Verification audit** — a scoped review packet for already-issued fulfillment receipts and completion witnesses, naming population, sampling basis, verifier independence, required evidence samples, required false-closure fences, and authority boundaries.
- **Evidence sample** — consumer/surface/audience-local evidence that a completion witness was verified, contradicted, stale, unavailable, inconclusive, or quarantined under a named sampling/probe basis.
- **False-closure fence** — a block around completion claims that look closed but were contradicted, undersampled, stale, wrong-scope, digest-mismatched, verifier-conflicted, public/inherited, or authority-laundered.

## Fixture requirements

The specimen 90 fixture must include:

- passed, partial, and blocked verification audits;
- source fulfillment-receipt, completion-witness, nonfulfillment-fence, carrier, and consumer references from specimen 89 pressure;
- sampling/probe basis for sidecar-digest recomputation, classification-pin replay, rendered-observation-status probe, recall-route probe, no-reexport check, quarantine check, and sibling-boundary check;
- evidence samples for verified, contradicted, inconclusive, stale, unavailable, quarantined, and superseded states;
- false-closure fences for contradicted completion, missing sample, sampling-scope gap, stale probe, verifier conflict, digest mismatch, no-reexport leakage, public-link verification failure, inherited-scope ambiguity, and authority laundering;
- a checker-harness audit note so the growing fixture/checker suite is refactored rather than only extended; and
- negative cases for missing verification audits, missing source fulfillment, missing samples, required sample omission, completion-as-verification, self-verification, verifier conflict, audit scope mismatch, sample scope mismatch, stale sample accepted, contradiction ignored, partial audit as pass, digest mismatch, public/inherited verification without fences, verification-as-authorization, verification-as-legal-compliance, verification-as-audit-opinion, verification-as-cryptographic-proof, verification-as-sibling-verdict, and harness coverage drift.

## Rules

See [`verification-audit-rulebook-v0.md`](verification-audit-rulebook-v0.md).

## Non-goals

- no external audit opinion or certification;
- no OSCAL, FedRAMP, SOC, ISO, or compliance reporting format;
- no cryptographic proof, VC, DSSE, signature, timestamping, or attestation framework;
- no SLSA or in-toto supply-chain verification;
- no policy engine, authorization, IAM, consent, legal-compliance, or rights-management decision;
- no public-release approval;
- no deletion, retention, custody, repair completion, lifecycle finality, or sibling verdict;
- no guarantee that sampled evidence covers every reachable surface; and
- no global verification registry.

## Promotion status

Fixture-local. The nouns are useful only while they prevent completion witnesses from becoming verified truth merely because they look closed. Promotion requires generated verification tamper cases plus at least one second non-SlopOS consumer whose fulfillment evidence can be independently sampled, contradicted, or fenced without becoming an audit product.
