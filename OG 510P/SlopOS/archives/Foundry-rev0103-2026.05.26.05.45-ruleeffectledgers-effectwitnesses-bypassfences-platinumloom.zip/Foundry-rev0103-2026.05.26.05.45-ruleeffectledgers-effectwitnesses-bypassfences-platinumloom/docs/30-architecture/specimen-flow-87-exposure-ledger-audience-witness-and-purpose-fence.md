# Specimen flow 87 — exposure ledger, audience witness, and purpose fence

Goal: make post-inventory exposure explicit without turning Foundry into an authorization engine, entitlement system, privacy-policy engine, consent registry, access-control product, deletion workflow, Ward verdict, Harbor public-status workflow, ViewFS custody model, or SlopOS proof claim.

## Scenario

Specimen 86 made actual reachable surface inventory explicit: a sweep can find or fence dashboard tiles, notebook extracts, object paths, ViewFS projections, and delegated-worker copies. A new failure remains: a surface can be correctly found yet exposed to the wrong audience or reused for the wrong purpose. Inventory can prove a copy exists; it does not prove who may read it, why they may read it, or whether inherited/shared/public access widens the semantic claim.

A SlopOS support dashboard, external-audit extract, Ward preview tile, ViewFS projection, delegated-worker cache, and shadow/public export are inventoried. Foundry must now record observed audience exposure and purpose boundaries. It must allow within-scope readers, quarantine inherited or unknown groups, and block public links or purpose widening without pretending to grant permission, prove consent, delete anything, or issue a sibling-cube verdict.

## Nouns under test

- **Exposure ledger** — a scoped account of intended audiences, observed surfaces, source inventory sweeps, carrier ids, access modes, purposes, method limits, and authority boundaries.
- **Audience witness** — evidence that one audience, principal, group, public link, inherited role, or unknown reader can reach one semantic surface under observed access modes and purposes.
- **Purpose fence** — a block around audience widening, purpose widening, access-mode widening, unknown/public exposure, inherited permission, expired exposure evidence, or missing authority evidence until clearance exists.

## Fixture requirements

The specimen 87 fixture must include:

- complete, partial, and blocked exposure ledgers;
- source surface-inventory sweeps and reachability witnesses;
- intended audience pins with allowed purposes and access modes;
- audience witnesses for within-scope, overexposed, unknown, public-link, inherited, quarantined, and retired surfaces;
- purpose fences for purpose widening, inherited group exposure, unknown audience, permission-denied worker access, and public links;
- non-promises that refuse authorization, consent, privacy-policy, deletion, public-release, Ward verdict, ViewFS custody, SlopOS proof, and source-truth laundering;
- negative cases for missing ledger, missing source inventory, missing audience witness, unaccounted intended audience, unknown/public audiences without fences, purpose/access-mode widening, inherited permission without witness, expired ledger window, overexposure-as-adoption, audience-as-authorization, exposure-as-consent, exposure-as-deletion, consumer mismatch, digest mismatch, and missing purpose fence.

## Rules

See [`exposure-accounting-rulebook-v0.md`](exposure-accounting-rulebook-v0.md).

## Non-goals

- no authorization, entitlement, IAM, ABAC, OAuth, or JWT system;
- no privacy-policy or consent framework;
- no public-release approval;
- no deletion, purge, or retention claim;
- no audit opinion;
- no Ward verdict;
- no ViewFS custody claim;
- no Harbor external-status workflow;
- no SlopOS proof claim; and
- no universal audience registry.

## Promotion status

Fixture-local. The nouns are useful only while they prevent found surfaces from silently becoming safe-for-every-audience surfaces. Promotion requires generated exposure tamper cases plus at least one second non-SlopOS consumer with inherited/shared/public exposure pressure.
