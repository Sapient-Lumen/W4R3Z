# Specimen flow 71 — hierarchy scope, rollup path, and aggregation guard

Goal: keep a future Foundry datacube honest when a result groups, rolls up, drills down, traverses a hierarchy, or presents a parent row without turning hierarchy into accidental arithmetic.

## Scenario

A future SlopOS support card asks Foundry for a convenient summary:

- group credential-presentation observations by provider family;
- show weekly counts;
- roll them into a regional support view;
- hide unavailable or policy-suppressed choices in the dimension picker;
- and let the operator drill from parent rows to child rows.

The tempting but wrong move is to assume the hierarchy is obvious:

- `week` means the same week everywhere;
- a code-list parent can be summed from children;
- a displayed parent row is a complete population;
- a current geography hierarchy can restate old observations;
- a folder path or partition key proves semantic parentage;
- a default member means unknown, not applicable, and omitted all at once;
- and a validation-passed result is safe to aggregate again.

That would be misleading.
A hierarchy is a relation under a scheme, cut, calendar/geography lens, membership rule, availability constraint, and aggregation law.
It needs a small rollup-honesty seam.

## Small seam to prove

### 1) hierarchy scope

Every result that uses a hierarchy carries a compact scope card for the hierarchy it used.
Examples:

```text
hierarchy_scope:
  dimension_family: support_provider_family
  scheme_ref: slopos_support_provider_scheme_v0
  scheme_digest: sha256:...
  member_cut: foundry_cut_2026_05_13T21_01Z
  parent_relation_kind: dag
  valid_combination_basis: sdmx_like_availability_constraint_digest:sha256:...
  availability_basis: current_query_mode_available_at_cut
  default_member_posture: explicit_none_not_silent_default
  presentation_order_digest: sha256:...
```

This keeps controlled vocabulary, available coordinates, presentation order, and lawful parent relation distinct.

### 2) rollup path

Every grouped or parent result carries a witness for how source rows moved to target rows.
Examples:

```text
rollup_path:
  source_grain: credential_presentation_observation
  target_level: support_provider_family_by_iso_week
  path_digest: sha256:...
  calendar_lens:
    calendar: gregorian
    week_rule: iso_week
    timezone: UTC
    fiscal_start: none
  geography_lens: none
  membership_posture: as_of_cut
  reparenting_posture: refused_without_restatement_lane
  recipe_digest: sha256:...
  raw_fallback: base_rows_retained
```

This keeps weekly, geographic, organizational, and code-list rollups from hiding their basis.

### 3) aggregation guard

Every rollup says whether the measure may be aggregated along this path.
Examples:

```text
aggregation_guard:
  measure_family: credential_presentation_count
  additive_posture: additive_along_declared_path
  blockers:
    - policy_suppressed_children_may_make_parent_incomplete
  allowed_reductions:
    - sum_after_child_disclosure_check
  forbidden_reductions:
    - average_of_percentages
    - distinct_count_reaggregation_without_sketch_basis
    - band_scalarization
    - drill_below_source_grain
  comparison_posture: comparable_with_same_scope_and_rollup_path_only
```

This keeps a parent row from pretending every child value was additive, visible, complete, and safe to compare.

## What this specimen proves

Foundry can let SlopOS and companion cubes use useful hierarchies without inventing:

- one global dimension ontology;
- one permanent hierarchy registry;
- one universal calendar authority;
- one geography engine;
- one storage-layout truth model;
- or one rule that parent rows are always sums.

The cube only needs to say:

1. **which hierarchy was in scope,**
2. **which path produced the parent or bucket,**
3. **which aggregation was allowed or refused,**
4. and **where later readers must stop before treating grouped output as reusable base truth.**

## Why this belongs in Foundry

SlopOS already has attribute-query, view-object, trace-processing, boundary-index, label-atom, and security-time pressure that favors explicit scope over ambient inference.
Companion cubes add the same pressure from Harbor temporal membership, Ward appraisal boundaries, ViewFS manifests/folder illusions, Steward approval/reconciliation, and Schell/Helm helper surfaces.

Specimen 71 gives all of those consumers a small honest carrier for hierarchy and rollup residue while keeping Foundry's core datacube ontology small.

## What stays parked

- no universal hierarchy ontology;
- no global code-list or taxonomy registry;
- no portable calendar/timezone/fiscal authority;
- no mandatory geography or DGGS model;
- no storage partition, chunk grid, folder path, or manifest layout as semantic parentage;
- no additive rollup without a guard;
- no current-membership hindsight rewrite without restatement posture;
- no default member or valid dimension value as proof of populated, visible, or comparable truth.
