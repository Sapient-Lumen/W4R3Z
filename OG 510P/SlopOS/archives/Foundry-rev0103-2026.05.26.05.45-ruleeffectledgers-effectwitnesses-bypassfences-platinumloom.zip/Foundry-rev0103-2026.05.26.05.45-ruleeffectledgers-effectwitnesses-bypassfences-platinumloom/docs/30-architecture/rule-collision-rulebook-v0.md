# Rule collision rulebook v0

This rulebook belongs to specimen 95. It defines tiny fixture-local checks for rule-collision ledgers, precedence witnesses, and ambiguity fences.

## Rules

- `R-COLLIDE-001-COLLISION-LEDGER` — every overlap among active, candidate, shadow, deprecated, superseded, or partial rules needs a rule-collision ledger that links source precedent ledgers, rule-promotion witnesses, rule refs, overlap scope, collision class, required precedence witnesses, required ambiguity fences, residual fences, and authority boundaries.
- `R-COLLIDE-002-SOURCE-LINKAGE` — collision ledgers must link to known source precedent ledgers, rule-promotion witnesses, overgeneralization fences, and rule-surface refs; unknown ids or digest mismatches fail closed.
- `R-COLLIDE-003-OVERLAP-SCOPE` — a precedence scope must not exceed the detected overlap scope unless each widened consumer, surface, audience, purpose, carrier, and rule target is named, tested, and fenced.
- `R-COLLIDE-004-PRECEDENCE-WITNESS` — every applied, partial, refused, shadow-only, expired, or superseded precedence choice needs a witness carrying status, observed time, resolver role, winning and losing rule refs, scope echo, basis refs, negative cases, residual fences, blocked inferences, and authority boundaries.
- `R-COLLIDE-005-AMBIGUITY-FENCE` — equal-priority, contradictory-outcome, missing-witness, stale-rule, deprecated/shadow activation, checker/rulebook divergence, public-release, audit, authorization, repair, lifecycle, sibling, or scope-widened collisions require an ambiguity fence.
- `R-COLLIDE-006-ORDER-IS-NOT-PRECEDENCE` — rulebook order, checker order, filename order, fixture order, route order, or reviewer preference cannot decide precedence without a precedence witness.
- `R-COLLIDE-007-NEGATIVE-CASES-SURVIVE` — applied and partial precedence witnesses must preserve negative cases and fixture/rulebook/checker refs; refused, expired, superseded, and shadow-only witnesses must preserve why they did not become active precedence.
- `R-COLLIDE-008-DEPRECATED-IS-NOT-ACTIVE` — deprecated, superseded, and shadow-only rules may remain readable but cannot decide current precedence without a fresh witness and ambiguity-fence clearance.
- `R-COLLIDE-009-RULE-SURFACE-INDEX` — rulebook rule ids, rulebook paths, fixture refs, checker refs, and runner registration must be visible in a machine-readable rule-surface index so collisions cannot hide behind unindexed rule text.
- `R-COLLIDE-010-AUTHORITY-LAUNDERING-FENCE` — collision ledgers and precedence witnesses must not be laundered into source truth, authorization, audit opinion, public-release approval, legal compliance, policy approval, incident closure, repair success, lifecycle finality, or sibling authority.

## Required negative cases

A valid specimen 95 fixture must include failure cases for missing collision ledger, missing precedence witness, missing ambiguity fence, unknown rule ref, unknown source precedent ledger, unknown source promotion witness, unknown source overgeneralization fence, equal-priority unresolved, contradictory outcomes accepted, order-as-precedence, scope widening, shadow rule applied, deprecated rule applied, stale rule accepted, checker/rulebook divergence, witness without negative cases, precedence as authorization, precedence as audit, precedence as public release, precedence as repair, precedence as lifecycle finality, precedence as sibling verdict, rule-surface index drift, runner drift, fixture drift, and rulebook id duplication.

## Containment

These rules do not define policy management, rule engines, governance, standards process, admission control, authorization, public-release approval, legal compliance, risk acceptance, audit opinion, deletion, retention, custody, repair, lifecycle finality, or sibling verdicts. They only ensure that separately promoted Foundry rules cannot collide invisibly or choose precedence by ambient order.
