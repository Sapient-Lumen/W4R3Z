# Specimen flow 26 — admission cut, drain epoch, and grace fence

Goal: keep “this realization should stop taking new work” separate from “all prior work is gone” and separate again from “teardown or reclaim is now safe”.

## Scenario
A foreign-backed service is replaced by a newer realization.
The successor becomes the ordinary target for new traffic or new routed work.
But the predecessor still has pre-existing readers, sessions, requests, or connections.

The predecessor therefore crosses an **admission cut**.
After that cut, new externally triggered work should not be admitted to it as the normal path.
That does **not** mean the predecessor has vanished.

Instead it enters a **drain epoch**.
During that epoch, work that already existed before the admission cut may still finish honestly.
The predecessor may still be serving old connections, finishing old requests, or holding readers that began before replacement.

Only after those pre-existing uses have cleared may a final **grace fence** fall.
That fence keeps replacement currentness separate from safe teardown or reclamation.
It prevents the model from pretending that “new thing is live” automatically means “old thing is gone and safe to destroy”.

This keeps admission, overlap, and reclamation visibly distinct.

## Proposed Foundry objects
1. **admission cut**
   - explicit point after which a realization should not receive new externally triggered work;
   - keeps successor selection separate from predecessor disappearance.

2. **drain epoch**
   - bounded overlap period where pre-existing readers, sessions, requests, or connections may still complete;
   - keeps “terminating” or “superseded” separate from “not serving anything anymore”.

3. **grace fence**
   - explicit blocker before final teardown or reclamation while pre-existing use may still exist;
   - keeps “old path withdrawn” separate from “safe to free or reclaim now”.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a successor realization is already current for new work,
- the predecessor still serves pre-existing connections or readers,
- termination/readiness/serving truth do not collapse into one token,
- and teardown/reclamation must wait for a real grace boundary instead of wishful timing.

## Adjacent but parked
- **serving-terminating card** — compact residue that a realization is draining but still serving.
- **linger budget** — future bounded time or effort allowance for one drain epoch.

## Promotion rule
Do not promote `admission cut`, `drain epoch`, or `grace fence` unless they improve:
- one hot-restart or rolling-replacement specimen,
- one terminating-but-still-serving endpoint specimen,
- and one reader-grace specimen where invisibility is still smaller than reclaimability.
