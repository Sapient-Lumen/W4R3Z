
# Specimen flow 76 — classification pin, crosswalk witness, and code-drift fence

Goal: keep Foundry honest when SlopOS-facing datacube rows group, filter, compare, or export category-valued dimensions whose code systems, labels, mappings, and taxonomies are still evolving.

## Scenario

A future SlopOS support workspace wants one compact history table:

> weekly observations by boundary family, browser/credential mediation class, origin class, outcome class, redaction reason, profile, and support-card status.

The table mixes several category systems:

- a SlopOS boundary-family vocabulary that renamed `browser_federation` to `browser_mediation`;
- a credential-presentation category that split one old `credential_response` bucket into `plaintext_presentation`, `selective_disclosure_presentation`, and `opaque_or_zkp_presentation`;
- an outcome vocabulary where `accept` and `admit` were once used by different subsystems;
- `CH-OBSPOL` redaction reasons whose codes are profile-local;
- a replication-class code such as `RC3` that only means anything inside one CH-REPLCONTRACT cut;
- an imported OpenTelemetry-style semantic convention whose attribute was deprecated and renamed; and
- a human-readable export that only wants pretty labels.

The tempting but wrong move is to store only:

```text
week, boundary_family, mediation_class, outcome_class, redaction_reason, profile, status, count
```

and later group by matching strings.

Foundry permits category-valued dimensions, but refuses to let strings, display labels, or current-friendly names impersonate stable concept identity.

## Walkthrough

1. Each category-valued dimension carries a **classification pin**. The pin names the scheme/code-system/value-set/profile, version or revision cut, namespace, member id, label, label language, deprecation status, and owner/steward if known.
2. A historical row with `browser_federation` stays readable under its native pin even if a current UI displays `browser mediation`.
3. A reviewed rename can attach a **crosswalk witness** with `relation=equivalent`, `cardinality=one_to_one`, and the mapping table or rule digest that made the relabel safe.
4. A split from old `credential_response` into multiple new categories attaches a crosswalk witness with `relation=source_broader_than_target` or `cardinality=one_to_many`. The code-drift fence refuses automatic projection unless a reviewed backcast lane exists.
5. A many-to-one merge can support a new aggregate view, but the fence marks the result as `coarser_reclassification` and refuses child-level drillback as if the old categories had survived.
6. A redaction reason imported from `CH-OBSPOL` remains profile-local. The same text in another profile is not comparable without a crosswalk witness.
7. If an external semantic convention deprecates a member, Foundry keeps old rows queryable under the old pin and optionally displays a current label through a deprecated-code lane. It does not delete or recycle the old code.
8. If a support-card total reconciles under the old classification but not under a new mapping, specimen 75's balance fence records `classification_cut_mismatch` rather than forcing equality.
9. If a chart/export cannot carry classification pins, it must carry a sidecar, use an old-lens display, or refuse classification-free flattening. It may not emit pretty labels as if they were semantic keys.
10. Unmapped legacy codes remain in an unknown-code pocket. They are not null, zero, failure, current members, or silently folded into `other` unless a reviewed policy says so.

## Nouns pressure-tested here

1. **classification pin**
   - compact residue for a categorical member's identity;
   - includes scheme/code-system/value-set/profile id, version/revision cut, namespace, member id, display label, label language, deprecation/status posture, validity/effective period if known, and steward/owner;
   - smaller than a universal taxonomy registry, concept graph, or semantic-layer ontology.

2. **crosswalk witness**
   - compact residue for a reviewed mapping between classification pins;
   - includes source pin, target pin, mapping/correspondence-table digest, mapping direction, use context, relationship kind, cardinality, coverage, reviewer/run, confidence/evidence grade, and not-mapped reason;
   - smaller than an automatic reclassification engine or executable transform language.

3. **code-drift fence**
   - compact guardrail for what later consumers may do with category values;
   - includes allowed/refused postures such as native-lens-only, equivalent-relabel-ok, old-and-new-side-by-side, reviewed-backcast-only, coarser-merge-only, split-not-reconstructable, no-label-join, no-bare-code-join, deprecated-readable-not-current, unmapped-pocket, and export-sidecar-required;
   - smaller than banning evolving taxonomies and stronger than a warning icon.

## What this specimen must keep separate

- code versus display label;
- display language versus member identity;
- namespace versus scheme;
- scheme id versus scheme version;
- old native lens versus current UI label;
- one-to-one rename versus split;
- split versus merge;
- exact/equivalent mapping versus close/inexact mapping;
- broader/narrower relation versus aggregation law;
- unmapped code versus unknown value;
- deprecated code versus deleted concept;
- profile-local code versus archive-wide code;
- human-friendly `other` bucket versus reviewed residual classification;
- schema-field translation versus category-member crosswalk.

## Promotion gate for these nouns

Do not widen these nouns beyond category-sensitive dimensions and result families unless a later specimen shows all of the following surviving without collapse:

- one SlopOS boundary-family or support-status rename with a one-to-one crosswalk;
- one old category that splits into multiple current categories and cannot be reconstructed without side inputs;
- one many-to-one merge where drillback must be refused;
- one profile-local code whose label collides with another profile's label;
- one deprecated external semantic-convention member that must stay queryable under its native pin;
- one balance/reconciliation result that changes when classification cut changes;
- one export/render path that must carry a sidecar or refuse label-only flattening.

## Why this matters

Datacubes become dangerous when category values look like timeless nouns.
Foundry should let SlopOS evolve names, profile codes, outcome classes, browser/credential categories, redaction reasons, and support-card taxonomies while making every comparison say which classification cut it used, which crosswalk was reviewed, and where code or label sameness is not enough.
