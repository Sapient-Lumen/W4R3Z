# Specimen flow 01 — bundle, world, ground, instance

This is a **specimen**, not a frozen architecture. It exists to stress the emerging Foundry vocabulary against a concrete off-native flow.

## Purpose

Test whether Foundry can represent off-native execution without collapsing these layers:
- artifact or package basis;
- declared interface or world contract;
- runtime bundle/config;
- runtime ground class;
- live instance and continuity class.

## Candidate objects

1. **artifact basis**
   - OCI image/index reference, Wasm component package, snapshot/template, or other carrier.

2. **declared contract**
   - WIT world or interface set;
   - expected imports/exports;
   - not the same thing as runtime bundle or host configuration.

3. **realization bundle**
   - runtime config / bundle / launch envelope;
   - host-specific details allowed here without polluting artifact truth.

4. **ground class**
   - container runtime;
   - VM-backed runtime;
   - confidential ground;
   - compat membrane;
   - sidecar/helper lane.

5. **instance continuity note**
   - fresh;
   - restored;
   - reattached;
   - reacquired;
   - downgraded / compat-only.

6. **snapshot truth card**
   - what continuity is claimed;
   - what is explicitly not claimed (network persistence, uniqueness, prior attestation freshness, prior secret-release session validity).

## What this specimen refuses to decide yet

- whether one universal artifact basis object can honestly span OCI, Wasm, and snapshot carriers;
- whether ground class becomes a small enum, a family, or a richer capability statement;
- whether continuity note and snapshot truth card are separate objects or two views of the same object.

## Why this specimen matters

If Foundry cannot survive this flow without laundering package, world, ground, and instance into the same thing, the cube is not ready for broader registries.
