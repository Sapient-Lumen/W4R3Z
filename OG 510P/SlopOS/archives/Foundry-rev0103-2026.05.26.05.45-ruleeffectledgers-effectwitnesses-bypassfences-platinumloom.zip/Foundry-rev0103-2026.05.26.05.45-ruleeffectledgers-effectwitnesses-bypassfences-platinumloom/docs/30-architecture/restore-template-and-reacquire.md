# Restore, template, and reacquire

Foundry needs explicit continuity language because off-native systems are especially prone to false continuity.

Useful separations:
- **template** — a prepared basis for future instantiation;
- **restore** — resume from captured runtime state;
- **reacquire** — establish fresh footing or evidence after a restore, move, or resume;
- **reattach** — reconnect to an already live realization.

These are not interchangeable.

The cube should be comfortable saying:
- the runtime was restored but not yet trust-reacquired,
- the artifact basis is identical but the ground class changed,
- the same world contract is present but the live realization is degraded,
- or a snapshot exists but does not justify native continuity claims.
