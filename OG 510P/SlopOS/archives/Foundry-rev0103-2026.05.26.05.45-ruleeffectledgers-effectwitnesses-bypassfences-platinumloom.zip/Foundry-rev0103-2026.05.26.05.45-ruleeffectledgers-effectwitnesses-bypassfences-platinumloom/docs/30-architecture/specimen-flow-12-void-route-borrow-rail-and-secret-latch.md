# Specimen flow 12 — void route, borrow rail, and secret latch

Goal: keep absent optional power, borrowed foreign utility, and deferred secret release visibly separate.

## Scenario
A foreign realization resumes and becomes partially useful.
At that point:
- one optional routed capability is intentionally absent for this product configuration,
- one high-value resource is available only as a borrowed foreign handle,
- the workload has attested successfully,
- but a secret or protected resource is still withheld by resource policy until extra conditions are met.

## Proposed Foundry objects
1. **void route**
   - records that a capability path is absent by posture or product, not merely by accident;
   - keeps “not present” distinct from “present but failed later”.

2. **borrow rail**
   - records that a useful resource remains a borrowed foreign handle;
   - prevents smooth API use from laundering foreignness away.

3. **secret latch**
   - records that attestation or base readiness succeeded but release of sensitive material is still gated separately.

4. **degraded readiness class**
   - records that the realization is running under a weaker truth class while waiting on missing optional power, repair work, or release conditions.

## Why this specimen matters
It pressure-tests whether Foundry can remain honest when:
- some useful power is intentionally absent,
- foreign utility remains borrowed,
- and sensitive consequences are still latched even after attestation.

## Promotion rule
Do not promote `void route`, `borrow rail`, or `secret latch` unless they improve:
- one routed-capability specimen,
- one borrowed/owned resource specimen,
- and one attested-release specimen.
