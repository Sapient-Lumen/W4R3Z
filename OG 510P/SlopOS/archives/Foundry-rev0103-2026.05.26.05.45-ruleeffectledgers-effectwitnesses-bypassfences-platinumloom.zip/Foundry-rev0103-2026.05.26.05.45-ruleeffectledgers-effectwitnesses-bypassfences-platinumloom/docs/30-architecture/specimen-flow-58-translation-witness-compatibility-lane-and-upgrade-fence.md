# Specimen flow 58 — translation witness, compatibility lane, and upgrade fence

Goal: keep a future Foundry datacube honest when SlopOS-neighbor support surfaces need to compare rows emitted under different schema pins while both producer and consumer contracts are still moving.

## Scenario
A future SlopOS support surface wants one trend tile that shows:
- imported MCP-task status counts from an older provider snapshot,
- newer MCP-progress summaries from a revised import adapter,
- one support-finops adjunct whose methodology payload was revised after review,
- and a consumer-facing export that wants the newest visible vocabulary.

The tempting but wrong move is to rewrite all older rows into the latest field names silently.
That feels tidy.
It also destroys meaning.
Some changes are pure rename, some are safe field lifts, some are lossy rebuckets, and some are real semantic splits where no honest forward map exists.

## Small seam to prove

### 1) translation witness
Whenever one source schema pin is intentionally interpreted as another target schema pin, preserve the exact reviewed mapping used.
Examples:
- `git:schemas/transforms/mcp-task-v0-to-v1@91ab2ef`
- `sha256:43d1…`
- `docs/30-architecture/mcp-progress-translation-note-v1.md#rev0062`
- `none` when the row remained native

### 2) compatibility lane
Preserve the visible posture of that interpretation.
Examples:
- `native`
- `lossless_translated`
- `lossy_translated`
- `deprecated_source`
- `incomparable`

### 3) upgrade fence
Preserve the explicit refusal boundary for silent normalization.
Examples:
- no reviewed translation exists,
- the transform carrier is newer than the reader supports,
- the later schema split one earlier meaning into several incompatible ones,
- or the row may only be shown through an old-schema lens.

## What this specimen proves
Foundry can preserve evolving schema-pinned rows without pretending that “latest field names” are the same thing as “same meaning.”
The cube only needs to say:
1. **which source schema pin the row originally spoke**,
2. **which translation witness, if any, was applied**,
3. **which compatibility lane the visible result occupies**,
4. and **where an upgrade fence blocked silent reinterpretation**.

## Example residue

```text
visible_value:
  subject: portal.jobs
  measure: task_count
  source_schema_pin: git:schemas/mcp-task-import-v0@0fbc221
  target_schema_pin: git:schemas/mcp-task-import-v1@91ab2ef
  translation_witness: git:schemas/transforms/mcp-task-v0-to-v1@55d2c91
  compatibility_lane: lossless_translated
  upgrade_fence: cleared

visible_value:
  subject: capsule.alpha
  measure: provider_burden_cost
  source_schema_pin: sha256:4e73…
  target_schema_pin: sha256:7c92…
  translation_witness: docs/30-architecture/support-finops-translation-note-v1.md#rev0062
  compatibility_lane: lossy_translated
  upgrade_fence: cleared
  adjunct_payload:
    note: old methodology buckets were merged into a coarser public family

visible_value:
  subject: portal.jobs
  measure: progress_phase_count
  source_schema_pin: git:schemas/mcp-progress-v0@44aa110
  target_schema_pin: git:schemas/mcp-progress-v2@002bc91
  translation_witness: none
  compatibility_lane: incomparable
  upgrade_fence: semantic_split_requires_old_lens
```

## Why this belongs in Foundry
SlopOS is still design-phase enough that adjacent support/import/export families will evolve under active use.
This specimen gives Foundry the smallest honest way to compare, translate, or refuse comparison without either losing old meaning or silently rewriting history into current folklore.

## What stays parked
- no universal transform registry;
- no automatic migration/backfill engine;
- no promise that every old schema pin maps forward;
- no claim that deprecated source rows are automatically comparable to native current rows;
- no global latest-version doctrine.
