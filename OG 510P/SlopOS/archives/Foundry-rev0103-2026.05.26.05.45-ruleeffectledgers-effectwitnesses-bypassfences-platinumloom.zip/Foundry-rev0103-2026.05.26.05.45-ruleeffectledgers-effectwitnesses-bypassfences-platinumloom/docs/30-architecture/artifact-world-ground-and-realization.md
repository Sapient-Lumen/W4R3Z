# Artifact, world, ground, and realization

Foundry wants a low-regret separation that many ecosystems blur:

- **artifact basis** is not **runtime ground**;
- **declared interface or world** is not **observed live realization**;
- **observed realization** is not **native meaning** by default.

This matters across multiple foreign grounds:
- OCI images and bundles,
- VM-backed container runtimes,
- WebAssembly components and worlds,
- compatibility layers,
- confidential VMs and other protected grounds.

By making these layers explicit, Foundry can explain where a failure or capability actually belongs: package, contract, ground, runtime state, or continuity story.
