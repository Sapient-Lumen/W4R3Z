# Specimen flow 46 — input cut, recipe witness, and replay class

Goal: keep a future Foundry datacube honest when neighboring archives emit derived values that look stable in a table but actually depend on a specific source snapshot, query/transform recipe, and replay posture.

## Scenario
A future Foundry read surface wants to summarize the current SlopOS architecture corpus.
It can see:
- one count from an ATTRFS smart query over an explicit view;
- one SKB-derived placement summary computed from a named query over one fact epoch;
- one imported-resource digest derived from MCP resource bytes and local normalization;
- and one materialized read-model row produced by a deterministic transform over a pinned archive cut.

A tempting but wrong move is to publish all of these as plain values with only labels and timestamps.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every derived value carries three small semantic companions.

### 1) input cut
A compact witness for which source state the value actually used.
Examples:
- exact archive revision or manifest digest;
- exact view binding plus snapshot time/window;
- exact SKB fact epoch and optional event-sequence bound;
- exact imported-resource version, commit, tag, or captured-byte digest.

This keeps floating selector intent visibly smaller than the source state that actually shaped the result.

### 2) recipe witness
A compact residue explaining how the result was produced.
Examples:
- named query identifier plus bounded parameters;
- query digest or compiled-SQL/plan digest;
- transform code revision plus normalization mode;
- threshold/filter/window values that materially shaped the output.

This is derivation inspectability truth.
It keeps “we ran something like this once” from turning into cube folklore.

### 3) replay class
A small posture saying how honestly the result can be reproduced later.
Examples:
- **replayable-from-pins** — deterministic recompute is expected if the same pinned inputs and recipe witness are available;
- **conditionally-restatable** — replay is expected only if external provider material, late-arriving context, or retained side inputs are still available;
- **snapshot-advisory** — useful observation captured at one cut, but not promised as reproducibly recomputable;
- **non-replayable-hint** — ranking or provider-local hint whose future reproduction is not part of the contract.

This keeps “helpful now” visibly smaller than “replayable later.”

## What this prevents
- branch names, moving heads, or current-default selectors from masquerading as immutable source truth;
- query results with hidden thresholds or filters from looking like atomic facts;
- provider-local imported-resource summaries from being mistaken for durable replayable materializations;
- post-hoc metadata folklore from replacing execution-path derivation residue;
- and debugging sessions that cannot answer “what exactly produced this cell?”

## Why this is enough for now
Foundry does **not** yet need a mandatory lineage graph, a global orchestrator model, or one universal provenance schema.
The conservative win is just to keep input cut, recipe witness, and replay class visibly separate.

## Promotion gate
Do not promote `input cut`, `recipe witness`, or `replay class` beyond this specimen unless they improve at least:
- one SlopOS ATTRFS snapshot-query specimen;
- one SlopOS SKB named-query specimen with explicit fact epoch;
- one imported-resource or provider-local context specimen where replay is only conditional;
- and one truly replayable materialized-view specimen where pinned inputs plus recipe witness are enough to recompute the result.
