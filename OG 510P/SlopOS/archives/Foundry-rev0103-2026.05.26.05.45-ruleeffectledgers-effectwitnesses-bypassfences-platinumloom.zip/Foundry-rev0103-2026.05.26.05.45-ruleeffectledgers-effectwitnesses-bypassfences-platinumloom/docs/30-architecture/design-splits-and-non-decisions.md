# Design splits and non-decisions

## Splits Foundry is freezing early
- artifact basis versus runtime ground;
- declared world or interface versus observed realization;
- compat membrane versus native semantics;
- restore versus reacquire versus reattach;
- runtime evidence versus trust verdict;
- activated-once trial basis versus blessed current basis;
- fallback budget versus durable success mark.

## Non-decisions still open
- whether Foundry needs one stable datacube export surface before it attempts a larger schema family;
- whether revision hooks belong on every status/export surface or only on the ones that can lag or evolve visibly;
- whether Foundry needs one common artifact descriptor across OCI, snapshots, and component packages;
- how much host-specific runtime detail should be preserved as first-class archive truth;
- whether confidentiality grounds deserve a distinct subfamily from ordinary VM-backed grounds;
- how to represent degraded but acceptable compat paths without laundering them into native truth;
- where the boundary lies between Foundry continuity evidence and Harbor aftermath receipts.

- whether effective time and record time belong on only a few families or deserve wider reuse;
- whether pending context should stay one small posture or later split by family-specific context debt;
- whether derived acceleration views need a first-class noun at all or can remain descriptive notes on exports.

## Process non-decisions
- do not let one convenient JSON shape become the permanent ontology.
- do not create a registry until ordinary spec/doc evolution becomes materially insufficient.
- do not promote candidate nouns to stable vocabulary without a visible stability lane.
- do not create a boundary-family map until at least three recurring seams have earned it;
- do not create a giant registry or schema family until at least two specimen tests need it;
- do not let a convenience integration define the cube’s permanent object model.

## rev0018 pressure note
- compatibility witness versus successful attach;
- detachable layer versus native base assimilation;
- structural layer versus backing cargo.


## rev0021 pressure note
- booted-once basis versus blessed current basis;
- success latch versus vague “seems healthy”;
- bounded fallback budget versus hidden retry folklore.


## rev0023 pressure note
- coherence target versus loose per-resource version folklore;
- confirmation fence versus eager “latest wins” drift;
- supersession hold versus silent conflicting advance.


## rev0023 pressure note
- follow selector versus exact basis pin;
- selector drift versus sticky head-following review;
- channel or cohort hint versus install authority.


## rev0025 pressure note
- offer hint versus local admissibility;
- local hold versus hidden scheduler folklore;
- admission window versus premature currentness.

## rev0025 pressure note
- offered/admissible target versus directly applicable path;
- version label versus prerequisite witness;
- barrier hop versus false direct-edge promise.

## rev0026 pressure note
- remembered known-good versus rollback-safe;
- success latch versus ratchet mark;
- ordinary rollback versus explicit rescue path.

## rev0029 pressure note
- admission cut versus predecessor still serving old work;
- drain epoch versus instant disappearance folklore;
- grace fence versus eager teardown or reclaim after replacement.


## rev0033 pressure note
- locally applied versus outwardly exposed state;
- stability fence versus vague readiness folklore;
- withheld newer tail versus fake currentness.


## rev0040 pressure note
- presenter binding versus generic bearer validity;
- audience fence versus cross-resource replay folklore;
- request pin versus broad standing-proof overclaim.


## rev0041 pressure note
- derivation witness versus raw-parent export folklore;
- attenuation fence versus polite rebadging of the same power;
- ancestor shadow versus fake child independence.

## rev0043 pressure note
- promotion candidate versus durable archive noun;
- stability lane versus silent permanence folklore;
- revision hook versus status/export drift.


## rev0044 pressure note
- effective time versus record time;
- pending context versus fake completeness;
- derived acceleration view versus canonical cube truth.

## rev0045 pressure note
- grain card versus foreign-key-first folklore;
- accumulation class versus all-values-are-summable folklore;
- reduction fence versus hidden BI/dashboard semantics.

## rev0076 pressure note
- query contract versus universal query language;
- result envelope versus base cube truth;
- validation witness versus source truth or approval basis;
- materialization/serving path versus semantic identity.

## rev0077 pressure note
- hierarchy scope versus universal dimension ontology;
- rollup path versus parent-row folklore;
- aggregation guard versus sum-until-it-runs behavior;
- calendar/geography lens versus ambient bucket labels;
- storage layout versus semantic parentage.

## rev0079 pressure note
- disclosure cut versus global privacy product;
- suppression witness versus null/zero/unknown folklore;
- differencing fence versus visible-cell-passed-threshold overclaim;
- privacy-unit basis versus row grain;
- privacy-budget refresh versus materialization refresh.

## rev0083 pressure note
- residue sidecar versus source truth;
- flattening refusal versus tidy export convenience;
- schema-passing fixture versus durable ontology;
- digest-linked sidecar availability versus policy approval or trust verdict.

## rev0084 pressure note
- refusal receipt versus generic implementation error;
- egress manifest versus source result envelope;
- conformance gate versus policy approval, privacy release, or Ward verdict;
- repair escape versus automatic repair;
- problem-details shape versus HTTP-only semantics.

## rev0085 pressure note
- semantic diff manifest versus source result envelope or egress manifest;
- regression lock versus policy guarantee, quality verdict, or compatibility promise;
- canonical bytes and digest strings versus semantic truth;
- JSON Patch-like tamper operation versus reviewed migration witness;
- non-SlopOS consumer pressure versus Foundry-owned BI/audit product.


## rev0086 pressure note
- waiver warrant versus approval, policy override, or trust verdict;
- expiry witness versus calendar reminder or stale ticket;
- exception replay gate versus policy engine;
- allowed semantic loss versus non-waivable residue;
- scoped temporary exception versus default success folklore.

## rev0087 pressure note
- consumer passport versus permission grant, catalog record, or audit opinion;
- portability witness versus compatibility guarantee;
- interpretation gate versus policy engine;
- portable residue versus portable authority;
- stable digest versus stable consumer meaning;
- sibling-cube evidence versus sibling-cube verdict transfer.

## rev0088 pressure note

This pass deliberately does not choose an authorization system, OAuth profile, verifiable-credential profile, attestation protocol, trust framework, legal-agency model, policy workflow, or audit workflow. Delegation warrants, reliance receipts, and transitive-use fences remain specimen-local witnesses for bounded semantic acts.
