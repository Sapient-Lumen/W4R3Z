# Specimen flow 72 — materialization cut, refresh witness, and reuse fence

Goal: keep Foundry honest when a SlopOS-facing datacube answer is served from a cached, materialized, pre-aggregated, continuously refreshed, or stale-but-available object instead of being recomputed directly from row-preserving base truth at the pinned cut.

## Scenario

A SlopOS support surface wants a fast table:

> weekly quarantined-open attempts by handler family, tenant posture, and review outcome.

The raw event stream is large.
The UI wants the answer fast.
The operations lane wants a long-range view.
The incident lane wants drill-through.
The shell wants to reuse the answer across adjacent support cards.
A product owner asks whether the same materialized object can back several dashboards.

Foundry allows a served result, but refuses to let speed become truth.

## Walkthrough

1. The request enters through specimen 70's query contract and result envelope. It names the request family, predicate/schema/parameter digest, policy lens, source cut, page/window, order posture, disclosure lens, and validation witness.
2. The table groups by week and handler family, so specimen 71's hierarchy scope, calendar lens, rollup path, and aggregation guard remain attached.
3. The engine serves most historical weeks from a precomputed object. Foundry requires a **materialization cut** that names the query-contract digest, source snapshot/transaction cut, rollup/aggregation dependencies, recipe version, materialized object digest, build run, and audience/policy lens.
4. The precomputed object was last refreshed incrementally. Foundry requires a **refresh witness** that names refresh mode, trigger, dependency frontier, source watermark, build start/end, observed lag, invalidation status, skipped/partial/failure posture, and validation outcome.
5. The UI attempts to reuse the object for a second dashboard with a broader audience. Foundry checks the **reuse fence**: the policy lens, disclosure lens, query parameters, calendar lens, schema version, and validation state must match or explicitly allow reuse.
6. A source schema change lands. The materialized object may still exist, but the reuse fence can require revalidation or refusal. A cache hit is not enough.
7. A hierarchy membership change reclassifies one handler family. Foundry refuses reuse unless the materialization cut and rollup path name a compatible hierarchy cut or a reviewed restatement lane.
8. The upstream raw source becomes temporarily unavailable. A stale-if-error lane may show a support card only if the refresh witness and reuse fence say stale serving is allowed, visible, bounded, and smaller than current truth.
9. A validation suite passes after refresh. Foundry records the validation witness but does not let green checks overwrite the materialization cut, source cut, or raw fallback status.
10. A later drill-through request asks for row-preserving evidence. Foundry does not pretend the materialized object is enough; it follows the raw fallback/drill-through posture already present in the result envelope and serving lane.

## Nouns pressure-tested here

1. **materialization cut**  
   - exact residue for the served object's recipe, input cut, output digest, policy/disclosure lens, build run, and dependency cards;  
   - smaller than a materialized-view engine, table format, cache layer, semantic-layer aggregate, or storage path.

2. **refresh witness**  
   - exact residue for how and when the served object was refreshed, what source/frontier it covered, whether refresh was full/incremental/manual/automatic/continuous, and what lag/failure/invalidation evidence exists;  
   - smaller than source truth, validation truth, and freshness SLA.

3. **reuse fence**  
   - exact permission/refusal card for whether a materialized/cached result may answer another query, audience, lens, or page;  
   - smaller than a global cache policy and stronger than “same title, same query text, or cache hit.”

## What this specimen must keep separate

- source cut versus materialization cut;
- build success versus refresh freshness;
- refresh success versus validation success;
- validation success versus source truth;
- cache hit versus lawful reuse;
- target lag versus observed lag;
- request-local materialization versus hidden durable persistence;
- internal handler cache versus portable result identity;
- policy/audience-specific reuse versus audience-neutral reuse;
- stale-if-error support display versus current answer.

## Promotion gate for these nouns

Do not widen these nouns beyond emitted/served result surfaces unless a later specimen shows all of the following surviving without collapse:

- one precomputed historical answer;
- one live or incrementally refreshed answer;
- one stale refusal or revalidation event;
- one audience/policy-lens reuse refusal;
- one materialized rollup invalidated by hierarchy/calendar/schema change;
- one row-preserving drill-through or explicit raw-fallback absence.

## Why this matters

Datacubes usually do not die because precomputation is bad.
They die because useful precomputed answers become invisible infrastructure folklore.
Foundry should let SlopOS be fast, but every fast result must carry enough evidence to say: what was materialized, when it was refreshed, and why this reuse was allowed.
