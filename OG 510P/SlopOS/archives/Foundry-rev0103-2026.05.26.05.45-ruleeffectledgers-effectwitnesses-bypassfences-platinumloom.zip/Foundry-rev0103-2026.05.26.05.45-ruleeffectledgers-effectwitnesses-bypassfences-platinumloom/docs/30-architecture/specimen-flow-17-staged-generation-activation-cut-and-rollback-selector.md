# Specimen flow 17 — staged generation, activation cut, and rollback selector

Goal: keep prepared candidate, current live basis, and revert choice visibly separate.

## Scenario
A foreign runtime basis and its neighboring configuration layer are prepared offline or ahead of time.
Compatibility and integrity checks succeed, so the candidate becomes a **staged generation** for later activation.
Until the system crosses an **activation cut** — reboot, apply-live step, or other reviewed switch point — the current **booted basis** remains the old one.
If the candidate fails health checks or the operator decides to back out, a **rollback selector** chooses the prior basis without pretending the failed candidate was ever durable live truth.

## Proposed Foundry objects
1. **staged generation**
   - prepared foreign basis that is queued, downloaded, or otherwise candidate-ready;
   - stronger than a vague update notification and weaker than active realization.

2. **activation cut**
   - explicit event that promotes a staged generation into the live basis;
   - stronger than “files are present” and weaker than durable adoption.

3. **booted basis**
   - the currently active basis against which actual work is happening;
   - useful because the candidate may be well-formed and still not be current truth.

4. **rollback selector**
   - explicit mechanism for choosing a prior basis after failed tries, health refusal, or operator reversal;
   - keeps rollback routine and inspectable instead of folkloric.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a candidate generation is real and inspectable,
- current work still happens on an older live basis,
- config merge timing matters at activation,
- and rollback is a legitimate first-class future.

## Promotion rule
Do not promote `staged generation`, `activation cut`, `booted basis`, or `rollback selector` unless they improve:
- one candidate-only specimen,
- one explicit activation specimen,
- and one rollback / revert specimen.
