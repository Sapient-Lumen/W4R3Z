# Specimen flow 21 — offer hint, local hold, and admission window

Goal: keep “the issuer/server says this exact basis or transition is available” separate from “the local subject is willing or allowed to take it now”.

## Scenario
A foreign update service offers one exact basis pin or transition edge to a subject.
That statement is useful, but it is still only an **offer hint**: a server/issuer-side claim that this basis or edge is available now.
Locally, the subject is under a **local hold** because of a maintenance window policy, an operator freeze, a cluster lock, a user-in-use pause, or a similar defer condition.
Nothing about that hold says the offer is fake, and nothing about the offer says the local subject may proceed immediately.
Later, an **admission window** opens.
If the same exact offer is still admissible, the subject may proceed to stage, activate, or finalize it then.
This keeps “offered” smaller than “admissible”, and both smaller than “current”.

## Proposed Foundry objects
1. **offer hint**
   - issuer/server-side statement that one exact basis pin or transition edge is available;
   - useful for discovery and operations, but weaker than local currentness or local approval.

2. **local hold**
   - explicit local defer/pause/freeze state that prevents uptake or finalization for now;
   - may come from maintenance windows, cluster locks, operator freezes, user-in-use pauses, or other local policy.

3. **admission window**
   - bounded time or condition under which a held offer may proceed locally;
   - smaller than approval, currentness, or success.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- rollout systems spread offers over time,
- local agents stage but do not yet finalize,
- local operators/users can pause or defer,
- and stale/expired metadata must not quietly count as a still-admissible offer.

## Adjacent but parked
- **hold reason chip** — compact explanation of why the local hold exists.
- **offer freshness horizon** — compact note about when the offer or its metadata stops being admissible.

## Promotion rule
Do not promote `offer hint`, `local hold`, or `admission window` unless they improve:
- one phased-rollout hinted-edge specimen,
- one maintenance-window or cluster-lock specimen,
- and one local pause/resume specimen.
