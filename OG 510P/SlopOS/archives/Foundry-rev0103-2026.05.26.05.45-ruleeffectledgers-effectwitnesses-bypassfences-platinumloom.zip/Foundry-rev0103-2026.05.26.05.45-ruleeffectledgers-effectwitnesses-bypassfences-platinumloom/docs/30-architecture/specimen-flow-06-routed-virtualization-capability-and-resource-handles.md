# Specimen flow 06 — routed virtualization capability and resource handles

This specimen exists to test whether Foundry can keep routed power and exterior handles truthful even when the foreign ground feels smooth to use.

## Scenario
A product session does not ambiently “have virtualization.” Instead, virtualization power is explicitly routed into the session. A component then uses host-backed or foreign-backed resources through typed handles. Some routed capabilities are required; others are optional.

## Flow
1. The product/session receives an explicit **virtualization grant**.
2. Before launch, Foundry evaluates the **availability rail**:
   - required routed power present or absent,
   - optional routed power present or absent.
3. If required power is missing, the failure is surfaced before launch as a truthful absence, not as late runtime folklore.
4. If launch proceeds, the component interacts with the foreign ground through typed **resource handles** to things implemented on the host or other side of the boundary.
5. Runtime evidence, attestation results, and policy-release decisions remain separate from the mere existence of those handles.
6. Adoption decides whether the resulting foreign realization becomes durable local practice or remains an inspectable external turn.

## What this specimen is trying to preserve
- The power to create foreign ground is explicit.
- Required versus optional routed power is visible before launch.
- Host-backed functionality stays visibly exterior through handles.
- Smoothness does not erase foreignness.
- Attestation, release, and adoption remain distinct.

## Candidate nouns under pressure
- **virtualization grant**
- **availability rail**
- **resource handle**
- **failure-before-launch**
- **exterior-resource warning**

## Kill criteria
Reject these nouns if any of the following happens:
- the resource handle starts implying native local objecthood;
- availability rail becomes a giant deployment taxonomy instead of a small honesty tool;
- virtualization grant starts swallowing orchestration, policy, and adoption into one noun;
- Foundry can no longer explain the difference between “launchable”, “attested”, “released”, and “adopted”.

## If Foundry survives the specimen
If Foundry *can* survive it, then pass X has found a promising smaller set:
- explicit routed power to create foreign ground,
- explicit early truth about required versus optional capability presence,
- and typed exterior handles that keep foreign implementation visibly foreign.
