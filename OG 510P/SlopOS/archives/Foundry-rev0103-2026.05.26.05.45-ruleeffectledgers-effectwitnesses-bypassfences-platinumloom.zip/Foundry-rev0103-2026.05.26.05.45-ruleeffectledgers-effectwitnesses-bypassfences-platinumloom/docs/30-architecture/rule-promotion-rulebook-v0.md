# Rule promotion rulebook v0

This rulebook belongs to specimen 94. It defines tiny fixture-local checks for precedent ledgers, rule-promotion witnesses, and overgeneralization fences.

## Rules

- `R-PROMO-001-PRECEDENT-LEDGER` — every closure, false-positive, duplicate, transfer, deferral, quarantine, or disposition that is reused as a rule seed needs a precedent ledger linking source disposition ledgers, source resolution witnesses, source premature-closure fences, scope, target rule surfaces, required promotion witnesses, required fences, and authority boundaries.
- `R-PROMO-002-SOURCE-LINKAGE` — precedent ledgers must link to known source disposition ledgers, resolution witnesses, premature-closure fences, carriers, and consumers; unknown ids or digest mismatches fail closed.
- `R-PROMO-003-SCOPE-ECHO` — a promotion scope must not exceed the source disposition scope unless every widened axis is named, justified, tested, and fenced.
- `R-PROMO-004-RULE-PROMOTION-WITNESS` — every promoted, partial, shadow, rejected, deprecated, or test-failed rule target needs a witness carrying status, observed time, promoter role, source precedent, scope echo, positive cases, negative cases, fixture refs, rulebook refs, checker refs, replay status, blocked inferences, and authority boundaries.
- `R-PROMO-005-OVERGENERALIZATION-FENCE` — single-case, stale, untested, false-positive, duplicate, unresolved-fence, public, audit, authorization, lifecycle, repair, sibling, or scope-widened promotions require an overgeneralization fence.
- `R-PROMO-006-CLOSURE-IS-NOT-RULE` — resolution witness, ticket closure, duplicate label, false-positive label, remediation note, or reviewer text cannot count as a rule or checker without a rule-promotion witness.
- `R-PROMO-007-TEST-BASIS-SURVIVES` — promoted and partial rules must preserve both positive and negative cases, fixture refs, and checker refs; shadow-only and rejected rules must preserve why they did not become active.
- `R-PROMO-008-DEPRECATION-IS-NOT-ACTIVE` — deprecated or superseded precedent may remain readable but cannot be used as an active rule without a fresh witness and stale-precedent fence clearance.
- `R-PROMO-009-FENCE-CLEARANCE-IS-EXPLICIT` — a precedent ledger cannot clear source premature-closure fences or overgeneralization fences without named evidence and surviving residual-risk posture.
- `R-PROMO-010-AUTHORITY-LAUNDERING-FENCE` — precedent ledgers and promotion witnesses must not be laundered into source truth, authorization, audit opinion, public-release approval, legal compliance, policy approval, incident closure, repair success, lifecycle finality, or sibling authority.
- `R-PROMO-011-LIFECYCLE-COVERAGE-REFACTOR` — promoted executable specimens must be part of a machine-readable lifecycle transition map so the checker chain cannot silently skip a handoff.

## Required negative cases

A valid specimen 94 fixture must include failure cases for missing precedent ledger, missing rule-promotion witness, missing overgeneralization fence, unknown source disposition ledger, unknown resolution witness, unknown premature-closure fence, resolution-as-rule, closure-as-precedent, single-case generalization, witness without negative tests, unresolved fence erased, false-positive generalized, duplicate generalized, stale precedent accepted, promotion scope widening, shadow rule as active, deprecated rule as active, rule without checker, checker without fixture, rulebook sentence without source ledger, public-release laundering, authorization laundering, audit laundering, repair/lifecycle laundering, sibling-verdict laundering, and lifecycle-transition coverage drift.

## Containment

These rules do not define policy management, rule engines, governance, standards process, incident postmortems, authorization, public-release approval, legal compliance, risk acceptance, audit opinion, deletion, retention, custody, repair, lifecycle finality, or sibling verdicts. They only ensure that resolved local semantic cases cannot become ambient archive rules without scoped evidence, tests, and fences.
