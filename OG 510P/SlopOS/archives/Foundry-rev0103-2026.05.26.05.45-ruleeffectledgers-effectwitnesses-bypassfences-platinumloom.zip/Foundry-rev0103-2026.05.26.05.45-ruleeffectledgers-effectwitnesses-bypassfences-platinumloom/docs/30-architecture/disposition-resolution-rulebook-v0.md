# Disposition resolution rulebook v0

This rulebook belongs to specimen 93. It defines tiny fixture-local checks for disposition ledgers, resolution witnesses, and premature-closure fences.

## Rules

- `R-DISP-001-DISPOSITION-LEDGER` — every routed or risky escalation packet that claims post-route handling needs a disposition ledger linking source packets, routing witnesses, unresolved-signal fences, carrier/surface/consumer/audience/purpose scope, review basis, disposition status, required resolution witnesses, required premature-closure fences, residual fences, and authority boundaries.
- `R-DISP-002-SOURCE-LINKAGE` — disposition ledgers must link to known escalation packets, routing witnesses, unresolved-signal fences, carrier digests, and consumers; unknown packet ids, witness ids, fence ids, or digest mismatches fail closed.
- `R-DISP-003-SCOPE-ECHO` — disposition scope must not exceed the source escalation scope unless the extra receiver is explicitly transferred and fenced.
- `R-DISP-004-RESOLUTION-WITNESS` — every required closure or transfer needs a resolution witness that records status, observed time, resolver consumer/role, closure basis, scope echo, evidence refs, residual fences, blocked inferences, and authority boundaries.
- `R-DISP-005-PREMATURE-CLOSURE-FENCE` — missing, stale, deferred, transferred-without-receiver, false-positive-without-evidence, duplicate-without-canonical, scope-widened, unresolved-source-fence, public, repair, lifecycle, audit, authorization, or sibling-boundary closure claims require a premature-closure fence.
- `R-DISP-006-ACKNOWLEDGMENT-IS-NOT-DISPOSITION` — routing acknowledgment, queue receipt, route id, ticket id, pager page, or notification delivery cannot count as disposition, resolution, repair, authorization, audit opinion, public-release approval, lifecycle finality, or sibling verdict.
- `R-DISP-007-TRANSFER-IS-NOT-CLOSURE` — transfer can move review responsibility only with a receiving consumer, receiving scope, residual fences, and a resolution witness; it cannot clear source fences by itself.
- `R-DISP-008-FALSE-POSITIVE-NEEDS-EVIDENCE` — false-positive or duplicate dispositions need contradictory evidence or canonical-ledger evidence and must preserve dropped/residual residue.
- `R-DISP-009-FENCE-CLEARANCE-IS-EXPLICIT` — a disposition cannot clear an unresolved-signal fence or premature-closure fence without named clearance evidence and surviving residual-risk posture.
- `R-DISP-010-AUTHORITY-LAUNDERING-FENCE` — disposition ledgers and resolution witnesses must not be laundered into source truth, risk acceptance, policy approval, authorization, audit opinion, incident closure, public-release approval, repair success, lifecycle finality, or sibling authority.
- `R-DISP-011-NEGATIVE-CASE-COVERAGE-REFACTOR` — promoted executable specimens must have machine-readable negative-case coverage tying fixture cases to rulebook failure modes, checker registration, and docs-map visibility.

## Required negative cases

A valid specimen 93 fixture must include failure cases for missing disposition ledger, missing resolution witness, missing premature-closure fence, unknown source packet, unknown routing witness, unknown unresolved fence, acknowledgment-as-closure, unresolved signal marked closed, deferred-as-resolved, transferred-without-receiver, false-positive-without-evidence, duplicate-without-canonical, stale closure accepted, closure scope widening, fence cleared without clearance evidence, remediation-as-repair, closure-as-authorization, closure-as-audit, closure-as-public-release, lifecycle laundering, sibling-verdict laundering, and negative-case coverage drift.

## Containment

These rules do not define incident management, ticket state, case workflow, on-call ownership, risk acceptance, remediation planning, repair completion, authorization, legal compliance, audit opinion, public-release approval, deletion, retention, custody, lifecycle finality, or sibling verdicts. They only ensure that post-route semantic disposition is evidenced or fenced with enough residue to prevent false closure.
