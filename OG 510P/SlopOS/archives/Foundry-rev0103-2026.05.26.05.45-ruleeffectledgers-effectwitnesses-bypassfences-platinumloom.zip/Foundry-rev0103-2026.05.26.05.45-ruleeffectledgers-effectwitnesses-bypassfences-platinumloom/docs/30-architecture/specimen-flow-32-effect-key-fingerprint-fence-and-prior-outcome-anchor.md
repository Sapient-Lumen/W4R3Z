# Specimen flow 32 — effect key, fingerprint fence, and prior-outcome anchor

Goal: keep “this retry should count as the same requested foreign effect” separate from “the request still means the same thing” and separate again from “what earlier outcome may honestly be replayed”.

## Scenario
A foreign-backed realization needs to create, attach, start, publish, or mutate something through an external API.
The operation is not commutative enough to replay blindly.
A network timeout or transport break leaves uncertainty: maybe the provider already accepted the effect, maybe it is still processing, maybe nothing happened.
A retried call arrives.

Some systems let the retry carry one stable key so the provider can detect that this is meant to be the *same* requested effect.
That is useful, but it is only the first truth.
The provider still needs to know whether the request under that key is materially the same request.
The exact canonical request or reviewed effect shape that must match is the **fingerprint fence**.
If the retry edits parameters, scope, destination, or bindings under the old key, the right answer is not silent replace or merge.
The right answer is a visible mismatch before effect.

And even when the retry is truly equivalent, the result is still smaller than “perform the effect again”.
A duplicate-safe retry may point back to the earlier accepted answer or receipt instead of firing the side effect again.
That replayable earlier answer is the **prior-outcome anchor**.
It is useful historical truth.
It is not automatically current live state, current settlement, or forever validity.

This keeps three facts separate:
- which foreign mutation attempts count as the same retry-equivalent requested effect,
- what exact request/effect fingerprint must still match before reuse is honest,
- and what earlier outcome may be replayed for an exact duplicate-safe retry.

## Proposed Foundry objects
1. **effect key**
   - stable retry-equivalent identity for one requested foreign effect;
   - keeps request identity smaller than target identity or current live state.

2. **fingerprint fence**
   - exact canonical request/effect fingerprint that must still match before the same key may reuse prior work;
   - keeps “same key” smaller than “same effect”.

3. **prior-outcome anchor**
   - replayable earlier accepted outcome or receipt for an exact duplicate-safe retry;
   - keeps historical accepted answer smaller than fresh execution or current settlement.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- foreign mutation may already have happened even though transport went uncertain;
- the same retry key must not silently retarget a changed request;
- duplicate-safe retry may replay a prior answer while the live foreign state could still have moved since then;
- and operators need a public explanation for why “same key” did not mean “safe to mutate again” or “same as current state now”.

## Adjacent but parked
- **dedupe-window horizon** — future residue for how long prior-outcome replay remains available before the key expires.
- **pending-duplicate card** — future explanation surface for “same key seen, but original work is still in flight”.

## Promotion rule
Do not promote `effect key`, `fingerprint fence`, or `prior-outcome anchor` unless they improve:
- one request-id or client-token specimen where the same key with changed parameters is rejected before effect,
- one settlement or replay specimen where prior accepted outcome is reused instead of refiring the side effect,
- and one companion-cube specimen where historical request identity is explicitly kept smaller than current live state.
