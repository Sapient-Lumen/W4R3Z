# Consumer portability rulebook v0

This rulebook is intentionally small. It checks whether semantic residue can be reused by a named consumer without becoming authority transfer, verdict transfer, or purpose drift.

It is not a policy engine, trust exchange, discovery catalog, audit framework, or compatibility registry.

## Rules

- **R-PORT-001-CONSUMER-PASSPORT** — every target consumer of a carried surface must have a consumer passport naming id, kind, purpose, audience, accepted surface kinds, required residue families, and forbidden inferences.
- **R-PORT-002-PURPOSE-AUDIENCE** — purpose and audience are part of interpretation; changing either requires a new gate or a refusal.
- **R-PORT-003-REQUIRED-RESIDUE** — a consumer cannot use a surface unless the required residue families are present or explicitly refused with a receipt.
- **R-PORT-004-SIBLING-AUTHORITY-BOUNDARY** — Foundry residue cannot transfer SlopOS proof claims, Ward verdicts, Harbor membrane authority, Steward lifecycle authority, Schell retention authority, Helm repair consequence, or ViewFS object identity.
- **R-PORT-005-PORTABILITY-WITNESS** — cross-consumer reuse requires a portability witness naming source consumer, target consumer, artifacts, portable residue, non-portable residue, and required gates.
- **R-PORT-006-INTERPRETATION-GATE** — target consumers must run an interpretation gate before first use, after revision change, after waiver change, and after audience or purpose change.
- **R-PORT-007-CONSUMER-SPECIFIC-LOSS** — consumer-local semantics must be pinned or refused; stable surface names, digests, and sidecar ids do not prove portable meaning.
- **R-PORT-008-NO-VERDICT-TRANSFER** — trust, audit, policy, appraisal, repair, lifecycle, retention, and proof verdicts do not travel through Foundry carriers.
- **R-PORT-009-WAIVER-SCOPE-RECHECK** — waiver warrants must be rechecked when consumer id, audience, purpose, cut, surface, or revision changes.
- **R-PORT-010-NON-PORTABLE-REFUSAL** — if required residue or forbidden-inference posture cannot survive the handoff, the target consumer must receive a refusal instead of a downgraded success.

## Default posture

A carrier is portable only as far as the portability witness says. Everything else is consumer-local and must be treated as refused or uninterpreted.
