# Specimen flow 11 — owned-handle swap, availability floor, and restore duty ledger

Goal: keep foreign handle posture, routed-capability degradation, and post-restore repair work visibly separate.

## Scenario
A foreign realization resumes from a snapshot and starts with:
- one borrowed host-backed resource handle,
- one required routed capability,
- one optional helper capability,
- and one subject-attached sidecar discovered through fallback registry support.

During recovery:
- the borrowed handle must be refreshed or replaced,
- the optional helper stays absent,
- and readiness must wait for explicit after-restore repair work.

## Proposed Foundry objects
1. **owned-handle swap**
   - records whether a useful handle is borrowed, refreshed, replaced, or newly owned elsewhere;
   - keeps foreign-backed utility visibly foreign even when the API feels smooth.

2. **availability floor**
   - records the weakest still-true capability posture after routing loss or product degradation.

3. **restore duty ledger**
   - lists the repair work still required before the realization may claim stronger readiness.

4. **fallback lease**
   - records that nearby attached evidence or metadata was found through degraded discovery rather than native referrers support.

## Why this specimen matters
It pressure-tests whether Foundry can remain honest when resumed work is viable but only through:
- still-foreign handles,
- degraded capability presence,
- and explicit repair duties.

## Promotion rule
Do not promote `owned-handle swap`, `availability floor`, or `restore duty ledger` unless they improve:
- one WIT-resource specimen,
- one routed-capability specimen,
- and one restore/sidecar specimen.
