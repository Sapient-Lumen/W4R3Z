# Specimen flow 50 — watermark frontier, closure class, and lateness aperture

Goal: keep a future Foundry datacube honest when useful values are grouped into time buckets or completion-sensitive summaries before all late arrivals and restatements have played out.

## Scenario
A future Foundry read surface wants to show "jobs completed by hour" and "incident artifacts observed by day" across one SlopOS deployment.
It can see:
- one `portal.jobs` periodic workflow whose `trigger.earliest`/`trigger.latest` are best-effort windows rather than exact schedules;
- one pull-only IF-OBS support snapshot assembled at one operator request cut;
- one ATTRFS smart-query result series built from repeated snapshot-first queries over one explicit view;
- one ViewFS follow surface that has sync watermarks, rebuilt snapshots, and gap verdicts;
- and one dashboard tile that wants to color buckets green as if they were done forever.

A tempting but wrong move is to publish these as one family with fields like `bucket_start`, `bucket_end`, and `count`.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every time-bucketed or completeness-sensitive value carries three small semantic companions.

### 1) watermark frontier
A compact witness for how far source progress had advanced when the value was emitted.
Examples:
- event-time lower bound supplied by one stream source;
- sync watermark or rebuilt-snapshot frontier from a follow/feed system;
- snapshot pull timestamp plus "complete only through this explicit cut" posture;
- scheduler frontier saying no ordinary arrivals before this point remain unaccounted for.

The watermark frontier is **not** a universal stream engine.
It is just enough residue to stop one bucket timestamp from pretending to mean complete timeless truth.

### 2) closure class
A compact witness for how finished the value currently is.
Examples:
- **preview** — surfaced early for usefulness; ordinary frontier has not yet cleared the bucket end;
- **on-time** — ordinary frontier cleared the bucket end, but the declared late-correction aperture still exists;
- **reopenable** — value was surfaced and may still be restated by admitted late arrivals;
- **finalized** — declared late-correction aperture is exhausted or the system explicitly sealed the bucket.

The closure class is **not** a full trigger/pane algebra.
It is just enough residue to stop every visible bucket from sounding equally final.

### 3) lateness aperture
A compact witness for how much late arrival or restatement the family still admits.
Examples:
- allowed lateness duration,
- grace period,
- incremental lookback window,
- one-catch-up-run policy,
- manual-restatement-only posture,
- or explicit `none` when anything later is intentionally dropped.

This keeps finalization policy visibly separate from the current numeric value.

## Why this seam is small enough now
It does **not** require:
- a universal windowing engine;
- one trigger vocabulary across every backend;
- a global realtime product plane;
- or a promise that every family has event-time semantics.

It only says that once values become bucketed and completion-sensitive, Foundry should preserve:
1. how far progress had advanced,
2. how closed the current bucket is,
3. and how much late correction is still admitted.

## SlopOS mapping
- **portal.jobs periodic summary**
  - watermark frontier: scheduler or observation cut showing what ordinary windows have been considered so far
  - closure class: often `preview` or `on-time`, because Phase 1 best-effort windows and catch-up posture do not imply timeless finality
  - lateness aperture: at most one catch-up run or portal-local skip-to-next-window policy

- **IF-OBS snapshot-derived daily incident count**
  - watermark frontier: explicit pull timestamp or bundle assembly cut
  - closure class: typically `preview` or `reopenable`, because later snapshots may surface additional late evidence
  - lateness aperture: source-specific rebuild/lookback policy or explicit manual-restatement posture

- **ATTRFS snapshot-first trend tile**
  - watermark frontier: explicit query cut and view binding
  - closure class: `preview` unless the family separately proves whole-bucket completeness
  - lateness aperture: query-series rebuild/lookback rule rather than hidden dashboard folklore

- **ViewFS follow/feed-derived sync summary**
  - watermark frontier: follow watermark or rebuilt-snapshot frontier
  - closure class: `on-time` or `reopenable` while a gap verdict or resync possibility still exists
  - lateness aperture: repair/resync window or explicit gap policy

## Anti-regrowth rules
- **frontier smaller than finality**
- **freshness smaller than completeness**
- **on-time smaller than finalized**
- **lateness policy smaller than invisible engine folklore**

## Non-goals parked on purpose
- no universal pane algebra;
- no promise that every family exposes exact event-time watermarks;
- no giant stream/scheduler ontology;
- no mandatory realtime layer for the whole cube.

## Resulting recommendation
When Foundry later accepts bucketed or completion-sensitive values, it should add only this narrow seam:
- **watermark frontier** for progress/completeness lower-bound posture,
- **closure class** for how finished the current bucket is,
- **lateness aperture** for what late correction the family still admits.

That is enough to keep early datacube bucket semantics honest while SlopOS and the neighboring archives are still evolving.
