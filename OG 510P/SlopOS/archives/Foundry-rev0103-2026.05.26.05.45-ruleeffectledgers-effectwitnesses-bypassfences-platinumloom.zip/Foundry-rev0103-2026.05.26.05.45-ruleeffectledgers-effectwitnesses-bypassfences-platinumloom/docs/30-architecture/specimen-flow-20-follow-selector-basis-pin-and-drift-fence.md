# Specimen flow 20 — follow selector, basis pin, and drift fence

Goal: keep a floating branch/channel/ref choice separate from the exact basis that was actually reviewed, prepared, or activated.

## Scenario
An operator says “follow stable” or “use this ref/channel” for a foreign basis family.
That instruction is useful, but it is still only a **follow selector**: a moving locator such as an OSTree ref, a Nix channel-like input, or a release cohort/channel request.
Before anything strong happens, Foundry resolves that selector to one exact **basis pin** such as a commit digest, revision, or exact version.
Later, the selector moves.
A **drift fence** then refuses to pretend that the earlier review, preparation, or install intent automatically followed the new head.
This keeps a floating convenience surface smaller than the exact basis that was actually chosen.

## Proposed Foundry objects
1. **follow selector**
   - floating branch/channel/ref/track request that may resolve differently over time;
   - useful for operator intent and discovery, but weaker than any exact reviewed basis.

2. **basis pin**
   - exact resolved revision, digest, or version that a review, preparation, activation, or receipt can honestly bind;
   - stronger than a named track and weaker than any wider business or trust verdict.

3. **drift fence**
   - explicit refusal to let stale approval, stale preparation, or stale install intent silently follow later selector drift;
   - keeps “still on stable” separate from “still on the exact basis we reviewed”.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- products want one convenient track/channel noun,
- exact basis still matters for review and rollback,
- a selector can drift after review,
- and old approval would otherwise be tempted to follow the moving head.

## Promotion rule
Do not promote `follow selector`, `basis pin`, or `drift fence` unless they improve:
- one moving-ref or moving-branch specimen,
- one channel-with-exact-version-pin specimen,
- and one mutable-basis approval specimen.
