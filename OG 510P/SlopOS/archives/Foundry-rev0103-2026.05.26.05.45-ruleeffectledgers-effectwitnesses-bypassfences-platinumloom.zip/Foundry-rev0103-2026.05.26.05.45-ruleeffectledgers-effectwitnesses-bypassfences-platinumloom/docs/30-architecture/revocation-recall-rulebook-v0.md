# Revocation and recall rulebook v0

This rulebook is intentionally small. It checks whether a previously emitted Foundry semantic carrier was invalidated, recalled, quarantined, replayed, or refused without becoming a status registry, authorization revocation endpoint, credential-status system, PKI checker, update framework, cache-control product, legal-hold workflow, or sibling-cube correction authority.

## Rules

- **R-RECALL-001-REVOCATION-NOTICE** — every invalidated semantic carrier must have a revocation notice naming issuer, carrier family, carrier id, carrier digest, reason class, status, issued/effective time, affected consumers, affected surfaces, and required actions.
- **R-RECALL-002-AFFECTED-SCOPE** — notice scope includes consumer, audience, surface, carrier family, carrier digest, source/classification/materialization/disclosure cuts when applicable, and propagation deadline.
- **R-RECALL-003-REVOCATION-REASON** — revocation reason must be machine-readable and smaller than verdict; accepted reason families include bad pin, bad cut, withdrawn waiver, revoked warrant, stale cache, disclosure risk, superseded rule, and discovered omission.
- **R-RECALL-004-RECALL-RECEIPT** — every affected consumer must emit a recall receipt or be blocked by a stale-reliance fence before further use.
- **R-RECALL-005-CACHE-QUARANTINE** — cached surfaces, dashboard tiles, notebooks, derived CSVs, and materialized packets must be quarantined or revalidated when a notice covers their carrier.
- **R-RECALL-006-STALE-RELIANCE-FENCE** — after the notice effective time, old digests, stale receipts, revoked warrants, withdrawn waivers, and unacknowledged consumers must fail closed unless required rechecks pass.
- **R-RECALL-007-CONSUMER-PROPAGATION** — notice audience and consumer lists are part of meaning; a notice delivered to one consumer does not automatically satisfy another consumer's recall.
- **R-RECALL-008-NO-SILENT-SUPERSEDE** — a replacement carrier or superseding notice must be explicit and cannot silently bless old reliance.
- **R-RECALL-009-NO-AUTHORITY-LAUNDERING** — a notice or recall receipt does not delete source evidence, issue an audit opinion, approve risk, transfer sibling authority, or settle SlopOS truth.
- **R-RECALL-010-REPLAY-BEFORE-REUSE** — interpretation, portability, waiver, delegation, egress, and regression gates that the notice names must rerun before reuse.
- **R-RECALL-011-DELEGATION-WAIVER-RECHECK** — revoked delegation warrants and withdrawn/expired waivers remain blocked even when their original carrier bytes are unchanged.
- **R-RECALL-012-PROPAGATION-WINDOW** — consumers that miss the notice propagation deadline must be treated as stale until they emit recall receipts and replay required gates.

## Default posture

A Foundry revocation notice is a scoped carrier-status overlay. It says a carrier must not be relied on under the named scope. It does not erase historical evidence, repair the carrier, decide truth, or create sibling authority.
