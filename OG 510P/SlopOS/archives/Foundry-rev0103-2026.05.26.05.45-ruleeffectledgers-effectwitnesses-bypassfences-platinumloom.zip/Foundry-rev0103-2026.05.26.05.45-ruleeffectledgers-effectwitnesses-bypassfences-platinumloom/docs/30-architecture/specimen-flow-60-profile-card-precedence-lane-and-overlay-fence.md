# Specimen flow 60 — profile card, precedence lane, and overlay fence

Goal: keep a future Foundry datacube honest when a reader, dashboard, or export path applies one or more profile-shaped overlays without pretending those overlays rewrote the base meaning family.

## Scenario
A future SlopOS-facing support surface wants one compact tile that shows:
- one support export interpreted under a redaction/release profile,
- one network tile interpreted under a transport-profile overlay,
- one operational summary interpreted under a deployment/hardening profile,
- and one dashboard export that wants to combine a consumer-local display profile with an export-local presentation profile.

The tempting but wrong move is to let profile-shaped overlays silently rewrite the row itself:
- a profile changes what the base measure “really means”,
- one later profile quietly overrides an earlier one with no visible order,
- a display/export profile becomes universal semantic identity,
- or a policy profile smuggles in a new schema meaning without a new schema pin.

That feels flexible.
It is also a lie.

## Small seam to prove

### 1) profile card
Whenever a reader/export path applies an extra convention bundle or overlay, preserve which profile actually shaped interpretation.
Examples:
- a digest of one support-bundle redaction profile,
- a stable local name for one deployment profile,
- a URI for one release/export profile,
- or `none` when no profile overlay applied.

### 2) precedence lane
Whenever more than one profile could matter, preserve how order or refusal was decided.
Examples:
- `base_only`
- `single_profile`
- `ordered_left_to_right`
- `profile_conflict_refused`

### 3) overlay fence
Whenever a profile tries to do more than add constraints/conventions/extensions, preserve the explicit refusal boundary.
Examples:
- `profile_must_not_change_base_measure`
- `profile_must_not_change_schema_pin`
- `profile_conflict_requires_new_lens`
- `profile_requires_translation_not_overlay`

## What this specimen proves
Foundry can let profile-shaped overlays stay useful without pretending they are the base row.
The cube only needs to say:
1. **which profile card applied**,
2. **which precedence lane decided order or refusal**,
3. and **where an overlay fence blocked profile drift from mutating base truth**.

## Example residue

```text
visible_value:
  subject: support.export
  measure: visible_case_count
  source_schema_pin: git:schemas/obs-export-v2@ac22019
  profile_card:
    applied: ["sha256:redaction-profile-v2"]
  precedence_lane: single_profile
  overlay_fence: profile_must_not_change_base_measure

visible_value:
  subject: portal.net
  measure: successful_connect_count
  source_schema_pin: git:schemas/net-lease-v1@44d1820
  profile_card:
    applied: ["local:transport-profile/mtls-tight-v1", "local:ops-display/profile-summary-v1"]
  precedence_lane: ordered_left_to_right
  overlay_fence: profile_conflict_requires_new_lens

visible_value:
  subject: capsule.alpha
  measure: realized_instance_count
  source_schema_pin: git:schemas/runtime-summary-v1@21ab771
  profile_card:
    applied: ["uri:https://profiles.slopos.dev/deployment/hardened-a"]
  precedence_lane: single_profile
  overlay_fence: profile_must_not_change_schema_pin
```

## Why this belongs in Foundry
SlopOS is design-phase enough that profile-shaped defaults, release modes, hardening choices, and export conventions will keep appearing before a final shared cube law exists.
This specimen gives Foundry the smallest honest way to preserve that overlay pressure without either erasing it or letting it impersonate base semantic identity.

## What stays parked
- no universal profile registry;
- no mandatory dereferenceable profile document for every row;
- no automatic profile negotiation plane;
- no promise that profile stacking always yields a lawful merged meaning;
- no claim that profile overlays are automatically cross-consumer comparable.
