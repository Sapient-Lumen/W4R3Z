# Specimen flow 23 — rollback floor, ratchet mark, and rescue path

Goal: keep “this basis was once good” separate from “ordinary rollback to it is still admissible after anti-downgrade state has advanced”.

## Scenario
A subject activates a new basis as trial truth.
After the health predicate passes, an explicit success operation blesses it as current.
Only then does the subject emit a **ratchet mark** that advances a **rollback floor**.
That floor may be carried as a monotonic counter, patch/security level, metadata version floor, or similar remembered anti-downgrade state.

Older bases may still be historically known and may even remain last-known-good in a narrow operational sense.
But once the rollback floor has advanced, those older bases no longer count as ordinary rollback targets.
If operators later need older functional content for recovery, they must use a separate **rescue path**: for example, a specially versioned repair bundle, a reviewed recovery artifact, or an explicit out-of-band operator procedure.
This keeps “known-good” smaller than “rollback-safe”, and both smaller than “rescue-admissible under explicit exception”.

## Proposed Foundry objects
1. **rollback floor**
   - monotonic lower bound below which ordinary selection/install/boot no longer counts as admissible;
   - may be represented as a counter, patch/security level, manifest-version floor, or similar ratchet.

2. **ratchet mark**
   - explicit event or receipt that advances the rollback floor, often only after success/commit;
   - keeps anti-downgrade state separate from mere staging or first activation.

3. **rescue path**
   - explicit reviewed path for older functional content when ordinary rollback is barred;
   - should remain visibly different from the ordinary rollback selector.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- trial activation and committed anti-rollback advancement happen at different moments,
- keys or secrets ratchet forward with version or patch level,
- trusted metadata must persist higher versions and reject stale or expired state,
- and operational rollback folklore collides with security or compatibility floors.

## Adjacent but parked
- **floor witness card** — compact residue naming the active rollback floor.
- **downgrade exception chip** — compact explanation of why ordinary rollback is barred and what rescue path remains.

## Promotion rule
Do not promote `rollback floor`, `ratchet mark`, or `rescue path` unless they improve:
- one A/B-style trial→success→floor-advance specimen,
- one metadata-version or expiry-ratchet specimen,
- and one rescue/recovery specimen where older functional content returns only through an explicit path.
