# Lifecycle transition coverage audit v0

This audit/refactor surface belongs to rev0100. The late executable specimens now form a long lifecycle: egress, refusal, regression, waiver, portability, delegation, revocation, remediation, distribution, inventory, exposure, obligation, fulfillment, verification, recheck, routing, disposition, and rule promotion. The risk is no longer only a missing file; it is a missing **handoff**.

`fixtures/lifecycle-transition-coverage/coverage.json` records the ordered handoffs between executable specimens. `tools/check_foundry_lifecycle_transition_coverage.py` verifies that each transition names source and target specimens, fixtures, checkers, carried fields, anti-laundering fences, and a narrow transition claim.

The audit is deliberately small. It does not prove the lifecycle is complete, correct, canonical, or stable. It only prevents a new specimen from appearing as an isolated island with no explicit predecessor, successor pressure, or blocked inference.

## Refactor rules

- every late executable specimen from 78 onward must appear in an ordered transition chain;
- every transition must point at existing source/target fixtures and registered checkers;
- every transition must name at least one carried field and one anti-laundering fence;
- every transition claim must use bounded language such as “does not”, “not”, “fence”, or “refuse”; and
- lifecycle coverage must remain smaller than governance, audit, certification, ontology completeness, semantic correctness, incident workflow, or sibling verdicts.
