# Specimen flow 68 — eligibility basis, exclusion class, and whole-world fence

Goal: keep a future Foundry datacube honest when a visible count, rate, or report only speaks about the subjects/events that were eligible for one scoped question rather than the whole archive.

## Scenario
A future SlopOS-neighbor support panel wants to show one clean card:
“platform assurance coverage: 94%”.

But the visible number actually mixes several different scoped worlds:
- a **profile claim** report that only considers profiles where one claim is `REQ` or `REC`;
- a **verification summary** that only covers the case set present in one family-local evidence pack;
- a **threat-model status** that intentionally excludes side channels and other non-claims from default scorekeeping;
- and an **operational SLO** that only counts eligible requests or eligible windows inside one compliance period.

The tempting but wrong move is to flatten all of that into one archive-wide truth row:
- `coverage = 0.94`
- `status = good`
- `scope = platform`

That would be misleading.
The row did not speak about every profile, every attack class, every family, or every event.
It only spoke about one reviewed eligible slice.

## Small seam to prove

### 1) eligibility basis
Every scope-sensitive value carries a compact statement of why its contributing subjects/events were eligible.
Examples:
- `profile_claim_req_or_rec`
- `family_local_case_set`
- `in_scope_attack_classes`
- `request_based_eligible_events`
- `window_based_eligible_intervals`
- `other_reviewed_basis`

This keeps “what counted at all” visible before anyone argues about percentages or trends.

### 2) exclusion class
Every scope-sensitive value carries a compact statement of how other candidates were narrowed away.
Examples:
- `profile_no`
- `non_claim`
- `out_of_scope`
- `denominator_exclusion_like`
- `denominator_exception_like`
- `policy_waived`
- `insufficient_window`
- `other_reviewed_exclusion`

This keeps non-eligibility, waiver, and out-of-scope posture from silently becoming failure, success, or zero.

### 3) whole-world fence
Every scope-sensitive value carries a compact guardrail against flattering overreach.
Examples:
- `not_all_profiles`
- `not_all_subjects`
- `not_all_events`
- `summary_not_subject_list`
- `no_archive_wide_claim`
- `forbidden`

This keeps a useful scoped summary from pretending it is a platform-total fact.

## Example residue

```text
visible_metric:
  subject: assurance.coverage
  value: 0.94
  unit: ratio
  eligibility_basis: profile_claim_req_or_rec
  exclusion_class: non_claim
  whole_world_fence: not_all_profiles

visible_report:
  subject: verification.worker_pool
  report_kind: summary
  eligibility_basis: family_local_case_set
  exclusion_class: other_reviewed_exclusion
  whole_world_fence: summary_not_subject_list
```

## What this specimen proves
Foundry can preserve eligibility honesty with three compact residues instead of inventing:
- a universal denominator engine,
- a giant scope/exemption ontology,
- or a promise that every local scorecard is safely comparable across all neighboring archives.

The cube only needs to say:
1. **why this thing was eligible,**
2. **how exclusion narrowed the world,**
3. and **where later readers must stop before calling it whole-system truth.**

## Why this belongs in Foundry
SlopOS already has design-phase pressure from profile-scoped claim/posture matrices, explicit non-claims, family-local verdict summaries, and bounded observational exports.
This specimen gives Foundry the smallest honest way to preserve those boundaries when future dashboards, support cards, or exports start asking for one neat “coverage” or “health” number.

## What stays parked
- no archive-wide denominator grammar;
- no universal eligibility DSL;
- no claim that every scoped summary can become a platform-total KPI;
- no automatic extrapolation from summary reports to subject-level truth.
