# Specimen flow 34 — absence witness, tombstone marker, and resurrection fence

Goal: keep “currently absent” separate from “durably withdrawn” and separate again from “safe to purge or reuse”.

## Scenario
A foreign-backed realization owns or references a named thing: an object, slot, basis ref, attachment point, or published handle.
That thing used to resolve normally.
Later, a withdraw or delete act happens.
Ordinary reads now behave as if nothing is there.

There are three negative-state classes that many systems flatten if they only say “not found” or “deleted”.

First, a read can carry an **absence witness**.
There is no current representation or current object at this lookup surface.
That claim can still be bounded, cache-shaped, or query-specific.
It is real enough to route decisions now, but it is still smaller than “gone forever”.

Second, the system can carry a hidden **tombstone marker**.
Ordinary reads behave absent, but the negative state is not just empty air.
A durable delete/withdraw marker may remain present, and earlier versions or history may still exist behind it.
That keeps “current lookup goes negative” distinct from “nothing durable remains”.

Third, the marker may still sit behind a **resurrection fence**.
Dropping the marker or reusing the same identity immediately might let stale replicas, caches, or old readers repair/resurrect the withdrawn truth.
A grace or quarantine boundary therefore matters before purge or name/key reuse becomes honest.

This keeps three truths separate:
- current absence at the ordinary lookup surface,
- durable withdrawn/deleted state behind that absence,
- and safe purge or safe identity reuse after a grace boundary.

## Proposed Foundry objects
1. **absence witness**
   - explicit current no-object / no-current-representation claim;
   - keeps negative lookup truth visible without overclaiming permanence.

2. **tombstone marker**
   - durable delete/withdraw marker that can make ordinary reads behave absent while hidden history or older versions still exist;
   - keeps withdrawal stronger than empty absence and weaker than total destruction.

3. **resurrection fence**
   - grace or quarantine boundary before marker purge or identity reuse becomes honest;
   - keeps stale caches/replicas/observers from silently rebinding old truth into the world again.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- ordinary reads return not-found while durable hidden withdrawal state still exists;
- negative answers are cacheable or bounded rather than timeless;
- old versions or recovery paths remain real behind a delete marker;
- and purge or name reuse must wait because otherwise old truth may resurrect.

## Adjacent but parked
- **gone badge** — future compact residue for “intentionally unavailable” distinct from plain absence.
- **reuse quarantine chip** — future compact residue for “do not rebind this identity yet”.

## Promotion rule
Do not promote `absence witness`, `tombstone marker`, or `resurrection fence` unless they improve:
- one companion-cube specimen where withdrawn or removed state is visibly different from plain absence;
- one outside-system specimen where ordinary reads go negative while a delete marker or tombstone still exists;
- and one resurrection-hazard specimen where dropping the negative marker too early can bring stale truth back.
