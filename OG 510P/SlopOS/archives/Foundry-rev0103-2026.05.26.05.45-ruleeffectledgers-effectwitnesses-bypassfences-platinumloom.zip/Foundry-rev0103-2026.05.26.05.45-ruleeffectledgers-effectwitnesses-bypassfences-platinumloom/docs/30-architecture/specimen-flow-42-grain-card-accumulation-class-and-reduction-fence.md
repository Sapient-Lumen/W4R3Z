# Specimen flow 42 — grain card, accumulation class, and reduction fence

Goal: keep a future Foundry datacube honest when neighboring SlopOS surfaces produce values that look numerically similar but obey different aggregation laws.

## Scenario
A future support workflow wants to study one incident window.
It can see:
- a bounded stream of **trace events** from `CH-TRACE`;
- a monotonic **hardware event** sequence from `CH-HWEVENT`-style evolution;
- an **inspect snapshot** of current component counters and gauges;
- and a **smart-folder/query result** that says how many matching objects currently satisfy one predicate.

A tempting but wrong move is to flatten all of these into one generic `value` family and let later readers guess whether summing or averaging is legitimate.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every value-bearing row carries three small semantic companions.

### 1) grain card
A short declaration of what one row means.
Examples:
- one trace event;
- one hardware fact-evolution event;
- one inspect snapshot for component `X` at cut `T`;
- one evaluated query result for predicate `Q` over view `V` at cut `T`.

This comes **before** dimension argument.
Without it, later dimensions and “measure” nouns become guesswork.

### 2) accumulation class
A small posture saying how the value behaves through time.
Examples:
- **delta/event** — one occurrence or one bounded increment window;
- **cumulative** — running total that may be monotonic or explicitly non-monotonic;
- **snapshot/state** — point-in-time value such as queue depth, health class, or current match count;
- **derived/query-result** — result of evaluating a query or formula over other rows.

This is still smaller than a full metrics taxonomy.
It simply prevents counters, gauges, snapshots, and query results from masquerading as the same thing.

### 3) reduction fence
A small statement about legal reduction posture.
Examples:
- **additive** across ordinary dimensions;
- **semi-additive** with an explicit forbidden axis such as time;
- **non-additive** and therefore derived later from additive components;
- **approximate** with explicit tolerance/algorithm posture;
- **query-shaped only** and not promotable as atomic fact without another specimen.

Units and exactness may ride adjacent to this fence without forcing a giant registry.

## Why this matters
The same apparent number can otherwise lie.
A snapshot count of currently matching objects should not be summed across time the way a delta event count can.
A cumulative monotonic total should not be averaged the way a sampled gauge might be.
A query-result ratio or distinct count may be useful, but it often belongs as a derived surface rather than an atomic cube fact.

## What this specimen promotes
- **grain card**
- **accumulation class**
- **reduction fence**

## What this specimen still parks
- a universal measure taxonomy;
- one permanent unit registry;
- built-in aggregate-awareness planning;
- default approximation/sketch families;
- any promise that query-result outputs are base cube rows.

## Promotion test
Do not promote `grain card`, `accumulation class`, or `reduction fence` beyond this specimen unless they improve at least one other value-bearing family without forcing:
- a global semantic layer;
- a product-shaped metric taxonomy;
- or a warehouse-first vocabulary that outruns SlopOS’s still-moving design.
