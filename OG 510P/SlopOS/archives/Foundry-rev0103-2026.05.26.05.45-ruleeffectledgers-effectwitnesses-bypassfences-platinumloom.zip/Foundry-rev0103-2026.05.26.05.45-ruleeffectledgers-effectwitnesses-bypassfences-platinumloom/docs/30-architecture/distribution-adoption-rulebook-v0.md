# Distribution and adoption rulebook v0

This rulebook is intentionally small. It checks whether a readmitted Foundry semantic carrier was distributed and adopted without becoming a deployment system, cache-control protocol, registry, message bus, release approval process, audit product, or sibling-cube authority.

## Rules

- **R-DIST-001-DISTRIBUTION-MANIFEST** — every post-readmission distribution attempt must have a manifest naming manifest id, status, source packet, readmission gates, distributed carrier digests, superseded carriers, target consumers, target surfaces, delivery channels, propagation window, required receipts, required fences, and authority boundaries.
- **R-DIST-002-CARRIER-LINKAGE** — a manifest must link distributed carriers to accepted replacement/readmission evidence and superseded carriers to old recalled history; a new filename, refreshed cache, or message id is not enough.
- **R-DIST-003-TARGET-CONSUMER-SCOPE** — distribution scope must stay inside the named readmission/consumer audience; widening from audit to Ward, ViewFS, public export, dashboard cache, or delegated worker requires its own target and gate.
- **R-DIST-004-ADOPTION-RECEIPT** — every target consumer/surface must produce an adoption receipt, refusal/partial/quarantine receipt, or orphan-copy fence before the propagation window closes.
- **R-DIST-005-OLD-CARRIER-RETIREMENT** — adoption receipts must state how previous carriers are retired, quarantined, or preserved as recalled history; old copies cannot remain current by silence.
- **R-DIST-006-ORPHAN-COPY-FENCE** — any stale, unacknowledged, duplicated, delegated, cached, notebook, projected, or exported copy must have an orphan-copy fence blocking current use until clearance evidence exists.
- **R-DIST-007-PROPAGATION-WINDOW** — manifests must bound the time in which receipts are expected; missing receipts after the window are stale reliance, not implicit success.
- **R-DIST-008-PARTIAL-ADOPTION-NO-OVERCLAIM** — partial adoption may be recorded, but it cannot be advertised as complete release, public-safe distribution, audit signoff, Ward verdict, ViewFS custody, Harbor remediation, Helm repair completion, or SlopOS proof.
- **R-DIST-009-NON-TRANSITIVE-ADOPTION** — adoption by one consumer or surface does not authorize another consumer, purpose, surface, cache, export, delegate, or sibling cube to rely on the same carrier.
- **R-DIST-010-AUTHORITY-LAUNDERING-FENCE** — distribution manifests, adoption receipts, and orphan-copy fences must refuse delivery-as-truth, cache-refresh-as-repair, adoption-as-approval, receipt-as-audit-opinion, and projection-as-custody inferences.
- **R-DIST-011-CHANNEL-NEUTRALITY** — Foundry records channel evidence only to account for semantic residue movement; it does not standardize delivery transports, cache APIs, queues, registries, package managers, object stores, or notification protocols.
- **R-DIST-012-STRAGGLER-RECALL-HOOK** — a discovered orphan copy, expired propagation window, or mis-scoped adoption may trigger recall/revocation or remediation reopening, but it does not delete history or rewrite source rows.

## Accepted fixture-local statuses

Distribution manifest statuses:

- `open`
- `completed`
- `partial`
- `blocked`
- `superseded`
- `retired`

Adoption receipt results:

- `adopted`
- `partial`
- `refused`
- `quarantined`
- `superseded`

Orphan-copy fence results:

- `blocked`
- `quarantined`
- `retired_as_history`
- `monitor_only`

These are fixture-local examples, not a global release workflow state machine.

## Non-decisions

This rulebook does not choose a message bus, event envelope, deployment system, cache purge API, CDN invalidation model, registry graph, package manager, object-store policy, release approval process, audit evidence system, data catalog, retention policy, ticket queue, or SlopOS proof format.
