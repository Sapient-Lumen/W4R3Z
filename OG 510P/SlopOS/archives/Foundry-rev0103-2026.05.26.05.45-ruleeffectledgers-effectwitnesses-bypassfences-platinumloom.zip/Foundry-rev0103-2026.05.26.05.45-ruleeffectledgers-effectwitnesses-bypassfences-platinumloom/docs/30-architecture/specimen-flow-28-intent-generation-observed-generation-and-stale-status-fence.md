# Specimen flow 28 — intent generation, observed generation, and stale-status fence

Goal: keep “a newer desired change exists” separate from “status has caught up to that exact change” and separate again from “old success status may still be read as current”.

## Scenario
A foreign-backed realization is governed by a controller, agent, or status-producing supervisor.
An operator edits the desired basis, spec, or configuration.
That edit creates a newer **intent generation**.

For a while, however, the live status surface is still green from the previous generation.
Perhaps the controller has not reconciled the new spec yet.
Perhaps the agent has received a new config version but has not yet ACKed it as the last successfully applied version.
Perhaps the request was merely accepted for later processing.
In all of those cases, the newer desired state is real, but the status surface is lagging.

The system therefore needs an **observed generation**.
That field or equivalent residue tells consumers which desired generation the current status actually reflects.
Without it, an old `Ready=True`, `applied`, or “healthy” badge can silently masquerade as a verdict on the newer intent.

A **stale-status fence** blocks that mistake.
If status still reflects observed generation N while intent generation is N+1, then older green status remains valuable history but it does not count as current truth about the newer desired state.
Only when observed generation catches up may the status surface be read as a statement about the latest intent.

This keeps desire, catch-up, and currentness visibly distinct.

## Proposed Foundry objects
1. **intent generation**
   - explicit generation or version step representing one newer desired basis, spec, or requested state;
   - keeps “latest desired” separate from whatever the controller or agent has actually caught up to.

2. **observed generation**
   - latest intent generation that the controller, agent, or status producer has actually seen and reflected;
   - keeps status freshness inspectable instead of hidden behind one green badge.

3. **stale-status fence**
   - explicit refusal to treat status, readiness, or settlement claims as current when they still belong to an older observed generation;
   - keeps old success residue from impersonating truth about a newer intent.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- desired state changes faster than reconciliation or application catches up,
- acceptance or ACK is real but still smaller than downstream completion,
- green status can remain historically true while becoming stale for the newest intent,
- and consumers need one visible rule for “do not trust this status as current for the latest desired state yet”.

## Adjacent but parked
- **applied-lag card** — compact residue for how far status trails the newest intent generation.
- **stale-green lamp** — shell-facing warning that yesterday’s green badge is not about today’s desired state.

## Promotion rule
Do not promote `intent generation`, `observed generation`, or `stale-status fence` unless they improve:
- one controller reconciliation specimen,
- one config-distribution ACK/apply specimen,
- and one accepted-for-later-processing specimen where admission stays smaller than observed current truth.
