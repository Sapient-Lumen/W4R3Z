# Fulfillment accounting rulebook v0

This rulebook belongs to specimen 89. It defines tiny fixture-local checks for fulfillment receipts, completion witnesses, and nonfulfillment fences.

## Rules

- `R-FUL-001-FULFILLMENT-RECEIPT` — every post-acknowledgment fulfillment-closure claim needs a receipt id, digest, status, time window, source obligation evidence, scope, obligations-to-fulfill, required completion witnesses, required fences, and authority boundaries.
- `R-FUL-002-SOURCE-OBLIGATION-LINKAGE` — every fulfillment receipt must name source obligation ledgers, acknowledgment witnesses, obligation-drift fences when relevant, carrier ids, and consumers.
- `R-FUL-003-FULFILLMENT-PIN` — every obligation-to-fulfill must be explicit and must name source obligation id, fulfillment type, due time, required evidence, applies-to surfaces/audiences/purposes, and blocked inferences.
- `R-FUL-004-COMPLETION-WITNESS` — every required completion needs evidence, state, observed time, source acknowledgment witness, fulfilled obligation ids, residue verified, and non-promises.
- `R-FUL-005-SCOPE-TIME-AND-DIGEST-CHECK` — completion witnesses may not exceed receipt scope, may not arrive after due time without a fence, and must preserve carrier digest linkage when a carrier is named.
- `R-FUL-006-PARTIAL-PENDING-OR-MISSING-FENCE` — partial, pending, missed, refused, quarantined, overdue, public, inherited, permission-denied, or wrong-scope completion requires a nonfulfillment fence.
- `R-FUL-007-ACKNOWLEDGMENT-IS-NOT-FULFILLMENT` — acknowledgment witnesses cannot count as completion witnesses unless separate completion evidence exists.
- `R-FUL-008-RESIDUE-FULFILLMENT` — sidecar, classification-pin, observation-status, recall-route, no-reexport, recheck, quarantine, and sibling-boundary obligations must be fulfilled or refused.
- `R-FUL-009-CONSUMER-SCOPE-BOUNDARY` — completion by one consumer, audience, surface, or purpose cannot clear another consumer's fulfillment boundary.
- `R-FUL-010-NON-TRANSITIVE-COMPLETION` — fulfillment is not authorization, legal compliance, consent, rights management, adoption, portability, delegation, public release, deletion, retention, audit opinion, custody, repair completion, lifecycle finality, or sibling verdict.
- `R-FUL-011-AUTHORITY-LAUNDERING-FENCE` — a fulfillment receipt or completion witness must not be laundered into policy approval, legal basis, source truth, repair success, or sibling authority.
- `R-FUL-012-REPLAY-HOOK` — blocked, quarantined, missing, overdue, partial, or recheck-required nonfulfillment fences must name replay timing or clearance evidence.

## Required negative cases

A valid specimen 89 fixture must include failure cases for missing fulfillment receipts, missing source obligations, missing completion witnesses, required completion missing, acknowledgment-as-fulfillment, deadline expired, sidecar not carried, classification pin not verified, observation status hidden, recall route untested, no-reexport unenforced, recheck missing before reuse, quarantine not applied, sibling boundary not enforced, completion scope mismatch, wrong consumer completion, partial completion treated as full, completion digest mismatch, public-link fulfillment without fence, inherited fulfillment without rebinding, fulfillment-as-authorization, fulfillment-as-legal-compliance, fulfillment-as-audit-opinion, and sibling-verdict laundering.

## Containment

These rules do not define workflow completion, Kubernetes finalizers, ODRL policy execution, XACML/ABAC/IAM authorization, DPV/privacy-law compliance, consent management, public-release approval, deletion, retention, custody, repair completion, lifecycle finality, or audit opinion. They only protect Foundry's semantic carriers from being interpreted as fulfilled merely because obligations were acknowledged.
