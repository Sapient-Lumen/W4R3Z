# Specimen flow 43 — population frame, overlap class, and coverage witness

Goal: keep a future Foundry datacube honest when SlopOS surfaces produce counts or result sets that look comparable but actually speak about different universes, different overlaps, or different completeness posture.

## Scenario
A future support workflow wants to answer a seemingly simple question:
“how many affected components do we have?”

It can see:
- a **smart-folder/query result** for “objects tagged `urgent`” over one reachable view;
- a **health predicate result** for “components currently unhealthy” over another reviewed scope;
- an **inspect snapshot** count of queue depth or worker state inside one captured bundle;
- and an **SKB named-query** result listing devices with one topology/property trait at one fact epoch.

A tempting but wrong move is to flatten these into one generic `count` family and later compute totals, percentages, or trend comparisons as if they shared one denominator.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every value-bearing or result-bearing row carries three small semantic companions.

### 1) population frame
A short declaration of the eligible universe the row or result could speak about.
Examples:
- objects reachable via view `V` at snapshot cut `T`;
- components included in support bundle `B`;
- hardware facts valid at epoch `E` under named SKB query `Q`;
- rows produced by one bounded query digest over one explicit scope.

This comes **before** percentage or denominator argument.
Without it, later “affected out of total” stories become folklore.

### 2) overlap class
A small posture saying how sibling categories relate.
Examples:
- **disjoint partition** — buckets do not overlap and may support additive rollup;
- **overlapping membership** — one subject may appear in multiple buckets, so ordinary addition over-counts;
- **primary-picked** — one primary category was chosen from a larger multivalued set;
- **unknown/not-yet-proven** — the system has not earned a stronger claim.

This is still smaller than a global hierarchy or allocation engine.
It simply prevents tags, health states, query folders, and topology labels from pretending to be clean partitions by accident.

### 3) coverage witness
A small statement about completeness posture.
Examples:
- **full frame** — all eligible subjects in the declared frame were considered;
- **filtered subset** — only the matched subset is represented;
- **sampled** — only a sample or bounded window was observed;
- **lagging partial** — results are known to trail the full frame;
- **explicit possibility set** — a declared coverage/possibility table exists, so “what did not happen” claims are meaningful.

This keeps absence, completion, and percent-of-total claims from leaning on hidden assumptions.

## Why this matters
Two equal-looking counts can otherwise lie in different ways.
A smart-folder count may be frame-bound and overlapping.
An inspect snapshot count may be complete only for one bundle scope.
An SKB result may be complete for one fact epoch but irrelevant outside that epoch.
A percentage can only be trusted when numerator and denominator inherit the same population frame and compatible overlap/coverage posture.

## What this specimen promotes
- **population frame**
- **overlap class**
- **coverage witness**

## What this specimen still parks
- a universal denominator registry;
- a default overlap-allocation/weighting engine;
- one permanent category lattice;
- forced primary-category semantics;
- any promise that query-result buckets are additive by default.

## Promotion test
Do not promote `population frame`, `overlap class`, or `coverage witness` beyond this specimen unless they improve at least one other result-bearing family without forcing:
- a global semantic-layer denominator grammar;
- a warehouse-first partition taxonomy;
- or a heavier overlap-repair engine that outruns SlopOS’s still-moving design.
