# Specimen flow 75 — control-total card, reconciliation witness, and balance fence

Goal: keep Foundry honest when a datacube result contains totals, subtotals, margins, mirrors, invariants, or balance claims that are useful but not the same thing as source truth.

## Scenario

A future SlopOS support workspace wants one compact table:

> weekly handler attempts by boundary family, origin class, outcome class, and redaction profile, with subtotal rows and a published total.

The table mixes several value kinds:

- a direct `CH-OBS` total emitted by a native boundary;
- per-outcome component counts derived by a trace processor;
- a diagnostic snapshot bundle count where one missing bundle was imputed;
- a redacted bucket hidden by `CH-OBSPOL`;
- one cached/materialized support-card result from a prior cut;
- a Steward-style provisional reconciliation state that later confirms or withdraws; and
- an external incident-review total entered by a human reviewer.

The tempting but wrong move is to store only:

```text
week, boundary_family, origin_class, outcome_class, count, is_total
```

and either force the visible components to sum or call the table wrong.

Foundry permits useful totals and balance checks, but refuses to let them launder cut drift, suppression, redaction, stale materialization, imputation, rounding, or mirror-source mismatch.

## Walkthrough

1. The request enters through specimen 70's query contract and result envelope. The result shape says the table includes a total row and component rows.
2. Foundry attaches a **control-total card** to the published total. The card names whether the total is source-native, report-margin, independent mirror, reviewer total, or derived invariant; it carries measure, unit, cut, policy lens, hierarchy/calendar lens, status requirements, and tolerance basis.
3. Component rows carry their existing grain, hierarchy, disclosure, materialization, and observation-status evidence. A component is not eligible for the balance check merely because it has a matching label.
4. Foundry runs a reconciliation rule pinned by digest. The **reconciliation witness** records the component set, operators/weights, rule/profile digest, checker/run id, checker version, source cuts, outcome, residual amount, residual class, and evidence grade.
5. If the only residual is rounding within the declared tolerance, the witness says `outcome=balanced_with_rounding`. It does not overwrite values to make a false exact zero.
6. If a `CH-OBSPOL` redaction hides one sibling row, the witness may say `outcome=balanced_with_hidden_policy_component` and `residual_class=redaction_hidden`. The balance fence forbids subtraction/drilldown that would reveal the hidden value.
7. If a cached support table passes against an old total but not the current cut, the balance fence refuses current-serving reuse unless specimen 72's materialization/reuse evidence allows that stale posture.
8. If an imputed component participates, specimen 74's as-observed fence is checked. The balance may be valid for the imputed table while still refused for raw-observation queries.
9. If an external incident-review mirror disagrees with native components, Foundry records a mirror-check witness. The mismatch is not auto-resolved, and neither source silently wins.
10. A chart/export consumer that cannot carry the witness must either receive a visible residual/sidecar or a refusal. It may not emit a tidy total with the reconciliation residue stripped.

## Nouns pressure-tested here

1. **control-total card**
   - compact residue for the total, subtotal, margin, invariant, benchmark, mirror, or reviewer value being checked;
   - includes total kind, source family, subject scope, measure, unit, cut, policy/disclosure lens, hierarchy/calendar/geography lens, status requirements, tolerance basis, and owner/profile where known;
   - smaller than an accounting ledger, official-statistics framework, or global source-of-truth hierarchy.

2. **reconciliation witness**
   - compact residue for the check that was run;
   - includes rule/profile digest, component set digest, operators/weights, checker/run id, checker version, input cuts, outcome, residual amount, residual class, severity, not-run/blocked reason, and evidence grade;
   - smaller than a validation DSL, proof system, or correctness verdict.

3. **balance fence**
   - compact guardrail for whether the result may be charted, exported, compared, subtracted, drilled into, reused, force-balanced, or treated as exact;
   - includes allowed/refused postures such as exact-balance-only, same-cut-only, rounding-visible, residual-visible, suppression-blocks-subtraction, redaction-blocks-total, imputation-status-required, stale-cut-refused, mirror-mismatch-review, and not-comparable;
   - smaller than a ban on totals and stronger than a decorative warning icon.

## What this specimen must keep separate

- source-native total versus derived subtotal;
- report margin versus independent mirror;
- internal balance versus external consistency;
- arithmetic equality versus truth;
- exact zero residual versus rounded residual;
- hidden policy component versus missing component;
- suppressed/redacted/noisy residual versus arithmetic error;
- imputed component versus observed component;
- stale-cut balance versus current-cut balance;
- not-run check versus passing check;
- validation outcome versus Ward-style verdict;
- visible residual row versus fake `other` row;
- control-total scope versus hierarchy parentage.

## Promotion gate for these nouns

Do not widen these nouns beyond total-sensitive result families unless a later specimen shows all of the following surviving without collapse:

- one direct SlopOS `CH-OBS` total and one component-derived total over the same declared cut;
- one redaction or suppression case where visible components intentionally do not sum to the published total;
- one rounding/tolerance case that is balanced but not exact;
- one imputed/provisional/adjusted component whose observedness fence affects eligibility;
- one stale materialized result that passes an older check but is refused for current-cut reuse;
- one mirror check against an external or human-reviewed total that disagrees without automatic winner selection;
- one export/render path that must carry the witness or refuse tidy flattening.

## Why this matters

Datacubes become dangerous when totals look like truth and imbalance looks like failure.
Foundry should let SlopOS publish useful support-card totals, diagnostic margins, mirror checks, and reconciliation summaries while making every balance claim say what was checked, what residual remained, and where that result must not be reused as source truth.
