# VM, container, and component crosswalk

Foundry should not collapse all foreign grounds into one giant runtime bucket.

A useful crosswalk keeps at least three axes visible:

1. **carrier form** — OCI image, bundle, component package, template, snapshot;
2. **ground class** — process/container, VM/microVM, confidential VM, component host, compatibility shim;
3. **contract style** — ambient host assumptions, declarative runtime config, or explicit world/interface contract.

This makes it easier to compare systems without pretending they share the same truth model.

Example pressure:
- OCI gives strong packaging and lifecycle vocabulary but still leaves many host-specific details in the runtime config;
- Wasm components emphasize explicit interface and world contracts;
- Kata and related systems show that VM-backed containment can plug into container tooling while still changing the isolation story.
