# Specimen flow 59 — support witness, unknown residue, and falsehood fence

Goal: keep a future Foundry datacube honest when a reader, dashboard, or export path only understands part of a newer design-phase meaning family.

## Scenario
A future SlopOS support surface wants one compact tile that shows:
- MCP progress imports from a reader that understands the core status family but not one newer optional subtask adjunct,
- one budget/payer summary from a reader that understands the core payer root but not a newer sponsorship nuance,
- one observation/export summary from a reader that understands the visible value but not a newer disclosure adjunct,
- and one consumer-facing JSON export that wants a simple current answer.

The tempting but wrong move is to flatten every unread field into ordinary-looking defaults:
- subtask detail becomes “none”,
- payer nuance becomes “same payer”,
- unread disclosure becomes “no restriction”,
- unread enum becomes zero/false/unknown-but-safe.

That feels tidy.
It is also a lie.

## Small seam to prove

### 1) support witness
Whenever a reader/export path interprets a row, preserve what meaning families it actually understood.
Examples:
- required families understood,
- optional families understood,
- optional families ignored-but-preserved,
- required family missing so interpretation refused.

### 2) unknown residue
Whenever unread semantics survive, preserve a bounded uninterpreted breadcrumb rather than erasing them.
Examples:
- `sha256:…` digest of one unread adjunct payload,
- preserved unknown enum numeric value,
- a source-row pointer or exact source pin for later drill-through,
- or `none` when nothing unread survived.

### 3) falsehood fence
Whenever interpretation is partial, preserve the explicit refusal boundary against flattering defaults.
Examples:
- `do_not_coerce_optional_to_none`
- `required_vocabulary_missing`
- `unread_enum_not_false`
- `unsupported_disclosure_not_public`

## What this specimen proves
Foundry can let partial readers stay useful without pretending that partial understanding is full semantic truth.
The cube only needs to say:
1. **what the reader/export path claimed to understand**,
2. **what unread residue survived**,
3. and **where a falsehood fence blocked silent coercion**.

## Example residue

```text
visible_value:
  subject: portal.jobs
  measure: progress_phase_count
  source_schema_pin: git:schemas/mcp-progress-v1@44aa110
  support_witness:
    required_understood: ["mcp-progress-core-v1"]
    optional_understood: ["mcp-progress-message-v1"]
    optional_ignored_preserved: ["mcp-progress-subtask-v1"]
  unknown_residue:
    adjunct_digest: sha256:91cd…
  falsehood_fence: do_not_coerce_optional_to_none

visible_value:
  subject: capsule.alpha
  measure: payer_burden_count
  source_schema_pin: git:schemas/budget-export-v1@10bc811
  support_witness:
    required_understood: ["budget-payer-core-v1"]
    optional_understood: []
    optional_ignored_preserved: ["budget-sponsor-exception-v1"]
  unknown_residue:
    source_row_ref: sha256:7e01…
  falsehood_fence: unread_payer_nuance_not_same_sponsor

visible_value:
  subject: support.export
  measure: visible_case_count
  source_schema_pin: git:schemas/obs-export-v2@ac22019
  support_witness:
    required_understood: ["obs-export-core-v2"]
    optional_understood: []
    optional_ignored_preserved: []
    required_missing: ["obs-export-disclosure-v1"]
  unknown_residue: none
  falsehood_fence: required_vocabulary_missing
```

## Why this belongs in Foundry
SlopOS is still design-phase enough that adjacent support/import/export families will evolve under active use, and not every reader will update in lockstep.
This specimen gives Foundry the smallest honest way to preserve partial understanding without either erasing unread meaning or forcing one giant negotiated extension system.

## What stays parked
- no universal extension registry;
- no mandatory opaque carryover blob on every row;
- no promise that every unknown residue is later decodable;
- no automatic reader negotiation plane;
- no claim that convenience JSON/export surfaces may erase unread semantics safely.
