# Semantic regression rulebook v0

This rulebook is intentionally tiny. It gives specimen 79 stable names for the failures that matter when Foundry compares sidecars, egress manifests, and refusal receipts across revisions.

| Rule | Meaning |
| --- | --- |
| `R-REGRESS-001-DIFF-MANIFEST` | revision-to-revision egress residue changes must be named in a semantic diff manifest |
| `R-REGRESS-002-CANONICAL-DIGEST` | artifact digests must identify a canonicalization posture rather than relying on pretty-printed JSON |
| `R-REGRESS-003-REGRESSION-LOCK` | protected residue paths need fixture-local locks before they can be treated as stable for consumers |
| `R-REGRESS-004-TAMPER-CORPUS` | known dishonest mutations must be listed as failing tamper cases |
| `R-REGRESS-005-BREAKING-WITNESS` | breaking or meaning-changing diffs require a migration witness or refusal posture |
| `R-REGRESS-006-NON-SLOPOS-CONSUMER` | widening sidecar/receipt fields needs at least one non-SlopOS consumer in the fixture corpus |
| `R-REGRESS-007-DIGEST-MUTATION` | a digest must not be reused after a protected artifact mutation |

These rules do not create a global migration framework, schema registry, patch dialect, or cryptographic trust system. They only make Foundry's own regression claims testable.
