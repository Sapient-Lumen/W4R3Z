# Remediation and readmission rulebook v0

This rulebook is intentionally small. It checks whether a recalled Foundry semantic carrier can be replaced and re-admitted for a named consumer without becoming Helm repair custody, Harbor remediation status, Ward verdict, Schell retention policy, ViewFS object identity, Steward finality, SlopOS truth, a workflow engine, or a supply-chain attestation authority.

## Rules

- **R-READMIT-001-REMEDIATION-PACKET** — every attempt to reuse or replace a recalled semantic carrier must have a remediation packet naming packet id, status, notice links, affected carriers, affected consumers, quarantined artifacts, repair actions, replacement candidates, required witnesses, required gates, and authority boundaries.
- **R-READMIT-002-REVOCATION-LINKAGE** — a remediation packet must link to the exact revocation notice or stale-reliance fence that made the old carrier unsafe; generic "fixed later" language is not enough.
- **R-READMIT-003-QUARANTINE-PERSISTENCE** — quarantine persists until a readmission gate passes for the specific consumer and use; replacement names, fresh digests, cache refreshes, or human notes do not release quarantine by themselves.
- **R-READMIT-004-REPLACEMENT-WITNESS** — a replacement candidate must have a replacement witness naming old artifact family/id/digest, replacement family/id/digest, correction classes, evidence refs, replayed gates, residual risks, and non-promises.
- **R-READMIT-005-HISTORY-PRESERVATION** — replacement preserves old recalled carriers as history and must not rewrite source rows, old receipts, old notices, or old caches into success.
- **R-READMIT-006-GATE-REPLAY-BEFORE-READMISSION** — sidecar, egress, regression, waiver, portability, delegation, recall, and readmission gates required by the packet must replay before admitted use.
- **R-READMIT-007-CONSUMER-SCOPED-READMISSION** — readmission is local to consumer, audience, purpose, use, and replacement artifact; admission for audit does not admit Ward, dashboard cache, public export, or sibling authority.
- **R-READMIT-008-PARTIAL-REPAIR-NO-OVERCLAIM** — partial repair may be recorded, but it cannot be advertised as complete readmission, Harbor remediation verified, Helm repair settled, Ward verdict, or source truth.
- **R-READMIT-009-AUTHORITY-LAUNDERING-FENCE** — remediation packets, replacement witnesses, and readmission gates must refuse approval, audit opinion, risk acceptance, policy authorization, sibling verdict, and SlopOS proof inferences.
- **R-READMIT-010-REPLACEMENT-REJECTION** — rejected or mismatched replacement candidates must leave machine-readable refusal evidence and cannot be silently replaced by another candidate without a witness.
- **R-READMIT-011-NO-SILENT-READMISSION** — stale carriers cannot become usable because the old notice is hard to see, a cache refreshed, a notebook reran, or a digest changed; readmission must be explicit.
- **R-READMIT-012-REOPEN-ON-NEW-NOTICE** — a later notice covering an accepted replacement reopens or supersedes the remediation packet and returns affected uses to quarantine until gates replay again.

## Accepted fixture-local statuses

Remediation packet statuses:

- `open`
- `quarantined`
- `partial`
- `blocked`
- `readmitted`
- `retired`

Replacement witness statuses:

- `candidate`
- `accepted`
- `rejected`
- `partial`

Readmission gate results:

- `admitted`
- `refused`
- `quarantined`
- `conditional`

These are fixture-local examples, not a global workflow state machine.

## Non-decisions

This rulebook does not choose a ticket system, incident workflow, remediation workflow, Harbor status model, Helm repair model, supply-chain attestation predicate, release approval process, audit evidence package, policy engine, cache-control protocol, retention system, or SlopOS proof format.
