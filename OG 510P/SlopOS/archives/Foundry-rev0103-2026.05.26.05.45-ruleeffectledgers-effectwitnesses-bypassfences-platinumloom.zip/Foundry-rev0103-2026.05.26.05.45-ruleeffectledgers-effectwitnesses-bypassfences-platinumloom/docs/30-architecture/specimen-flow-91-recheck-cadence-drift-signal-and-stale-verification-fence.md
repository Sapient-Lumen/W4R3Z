# Specimen flow 91 — recheck cadence, drift signal, and stale-verification fence

Goal: make verification freshness explicit without turning Foundry into a monitoring system, alerting product, SLO framework, authorization system, audit program, incident workflow, control plane, or sibling-cube verdict.

## Scenario

Specimen 90 proved that Foundry can distinguish completion evidence from sampled verification evidence. A new failure remains: a verification audit is still a point-in-time claim. After the audit passes, the sidecar can be revised, the surface can be re-rendered, a public link can widen, a delegated worker can run from old bytes, a recall route can break, or a no-reexport guard can stop firing. If the fixture only preserves the old audit packet, a stale verification can be mistaken for continuing safety.

A SlopOS operator console, dashboard cache, external-audit notebook, Ward preview, ViewFS projection, delegated worker, and public-link scanner now carry verification-audit results. Foundry must record the cadence under which each verification remains live, the drift signals observed between audits, and the fences that block stale verification from being reused as freshness, authorization, audit opinion, public-release approval, sibling verdict, or source truth.

## Nouns under test

- **Recheck cadence** — a bounded schedule/trigger packet for rechecking a verification audit, naming source audit, carrier/surface/consumer scope, interval or trigger basis, grace window, required drift signals, escalation posture, and non-promises.
- **Drift signal** — a scoped observation that a semantic carrier, rendered surface, obligation, recall route, public exposure, no-reexport guard, or sibling boundary is clear, warning, firing, stale, missing, flapping, superseded, or quarantined under a named probe basis.
- **Stale-verification fence** — a refusal around verification claims whose cadence was missed, paused, superseded, underscoped, flapping, contradicted, digest-mismatched, public/inherited, scope-widened, or laundered into authority.

## Fixture requirements

The specimen 91 fixture must include:

- active, warning, paused, and blocked recheck cadences;
- source verification-audit, evidence-sample, false-closure-fence, carrier, consumer, surface, audience, and purpose references from specimen 90 pressure;
- cadence basis for interval, trigger, recall, public exposure, delegated worker execution, inherited-access rebinding, and no-reexport guard checks;
- drift signals for clear, warning, firing, stale, missing, flapping, superseded, and quarantined states;
- stale-verification fences for missed cadence, stale signal, flapping signal, missing signal, public-link exposure, inherited-access ambiguity, digest mismatch, cadence scope widening, paused-as-active overclaim, and alert-as-truth laundering;
- a schema/fixture coverage audit note so the growing schema/checker/fixture set is refactored rather than only extended; and
- negative cases for missing cadence, missing source verification, missing drift signal, required signal omission, stale signal accepted, flapping accepted, missed recheck unfenced, cadence scope mismatch, signal scope mismatch, digest mismatch, paused cadence treated as active, clear signal treated as exhaustive, alert-as-truth, freshness-as-authorization, recheck-as-audit-opinion, monitoring-as-sibling-verdict, and schema/fixture coverage drift.

## Rules

See [`recheck-drift-rulebook-v0.md`](recheck-drift-rulebook-v0.md).

## Non-goals

- no Prometheus, Kubernetes, OpenTelemetry, SLO, SIEM, incident, pager, or monitoring product;
- no continuous assurance, audit opinion, certification, compliance report, or control assessment;
- no authorization, IAM, consent, rights-management, public-release, deletion, retention, custody, repair, lifecycle finality, or sibling verdict;
- no guarantee that clear signals cover unsampled surfaces, audiences, purposes, obligations, or caches;
- no replacement for surface inventory, exposure accounting, obligation accounting, fulfillment, or verification audit; and
- no global runtime health registry.

## Promotion status

Fixture-local. The nouns are useful only while they prevent verified-at-time-T evidence from becoming continuing freshness. Promotion requires generated recheck/drift tamper cases plus at least one second non-SlopOS consumer whose verification freshness can decay independently without becoming monitoring infrastructure.
