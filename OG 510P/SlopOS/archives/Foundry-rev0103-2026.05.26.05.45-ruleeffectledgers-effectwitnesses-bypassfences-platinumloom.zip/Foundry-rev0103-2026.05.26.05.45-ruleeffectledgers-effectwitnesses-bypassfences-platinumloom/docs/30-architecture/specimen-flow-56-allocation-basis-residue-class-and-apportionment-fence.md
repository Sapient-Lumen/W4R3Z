# Specimen flow 56 — allocation basis, residue class, and apportionment fence

Goal: keep a future Foundry datacube honest when visible values come from splitting a shared total across subjects rather than from a direct native measurement on each subject.

## Scenario
A future SlopOS-neighbor support surface wants one “burden by subject” panel for a constructor-backed worker pool and its nearby payer state.
The panel mixes four upstream ingredients:
- one direct local charge already accepted against `budget.alpha`;
- one shared worker-pool overhead amount that benefits all tenants;
- one idle reserved-capacity amount that no tenant actually consumed;
- and one imported provider commitment-discount amount spread across active workloads.

A tempting but wrong move is to flatten these into one generic value family with only `subject`, `measure`, and `value`:
- `capsule.alpha total_cost = 12.30`
- `capsule.beta total_cost = 10.90`
- `capsule.gamma total_cost = 11.10`

That would be misleading.
Some rows were directly charged, some were uniformly split, some were proportional to a chosen metric, and some burden stayed idle or overhead rather than honestly belonging to one tenant.
The numbers all “look like cost,” but they do not share one honest provenance or one lawful re-aggregation story.

## Small seam to prove

### 1) allocation basis
Every apportioned row carries a compact witness such as:
- `direct_native_row`
- `uniform_split`
- `proportional_reserved_capacity`
- `proportional_observed_usage`
- `custom_metric_network_egress`
- `provider_native_allocation`

This keeps a split value from pretending it was directly measured on that subject.

### 2) residue class
Every such family carries a compact witness for what stayed specially treated:
- `fully_distributed_none`
- `idle_unallocated`
- `overhead_unallocated`
- `unused_commitment`
- `rounding_residue`
- `other_explicit`

This keeps leftovers visible instead of silently burying them in one recipient row.

### 3) apportionment fence
Every such family carries a compact guardrail for what reasoning is lawful:
- `conserves_total_same_basis`
- `same_basis_only`
- `view_only_split`
- `policy_restatement_required`
- `forbidden`

This stops support charts and exports from treating direct facts and apportioned convenience as the same kind of truth.

## What this specimen proves
Foundry can preserve allocation honesty with three compact residues instead of inventing:
- a universal chargeback engine,
- a giant weighting/algebra DSL,
- or one finance-grade valuation plane.

The cube only needs to say:
1. **what rule produced the visible split**,
2. **what residue stayed specially treated**,
3. and **what kind of recombination or comparison is actually lawful**.

## Example residue

```text
visible_value:
  subject: capsule.alpha
  measure: direct_compute_cost
  value: 7.40
  unit: usd
  allocation_basis: direct_native_row
  residue_class: fully_distributed_none
  apportionment_fence: conserves_total_same_basis

visible_value:
  subject: capsule.alpha
  measure: shared_pool_overhead_cost
  value: 1.60
  unit: usd
  allocation_basis: uniform_split
  residue_class: overhead_unallocated
  apportionment_fence: same_basis_only

visible_value:
  subject: capsule.alpha
  measure: commitment_discount_applied_cost
  value: 3.30
  unit: usd
  allocation_basis: provider_native_allocation
  residue_class: unused_commitment
  apportionment_fence: policy_restatement_required

visible_value:
  subject: pool.shared
  measure: idle_capacity_cost
  value: 2.10
  unit: usd
  allocation_basis: direct_native_row
  residue_class: idle_unallocated
  apportionment_fence: forbidden
```

## Why this belongs in Foundry
SlopOS already puts explicit pressure on payer identity, observational quota summaries, shared worker pools, and imported/provider-local accounting stories without yet promising one giant cost model.
This specimen gives Foundry the smallest honest way to preserve that fact when future dashboards, exports, and derived summaries start mixing direct charges, shared overhead, idle capacity, and provider-native allocations.

## What stays parked
- no universal chargeback model;
- no automatic redistribution of every idle or overhead remainder;
- no valuation or FX plane;
- no claim that allocated rows are interchangeable with direct measurements;
- no giant weighting DSL.
