# Specimen flow 85 — distribution manifest, adoption receipt, and orphan-copy fence

Goal: make post-readmission distribution explicit without turning Foundry into a deployment system, cache-control protocol, message bus, registry, ticket queue, approval workflow, audit product, or sibling-cube authority.

## Scenario

Specimen 84 made re-admission consumer-local: a replacement carrier can be admitted for a named consumer and use only after a remediation packet, replacement witness, and readmission gate pass. A new failure remains: the admitted carrier may never reach every relying surface, while old cached or derived copies continue to circulate.

A SlopOS support workspace readmits a repaired sidecar. External audit receives the new sidecar, Ward receives a partial preview, a dashboard cache refreshes one tile but leaves an old CSV extract behind, and a delegated worker still has a local copy of the recalled carrier. Everybody can point to a passing readmission gate, but the deployed world is mixed: some surfaces adopted, some refused, some are still stale, and some cannot prove they saw the new carrier.

Foundry's narrow question is smaller than delivery success: can the semantic release show which carriers were distributed, which consumers adopted which specific carrier for which use, which older copies were retired or fenced, and which surfaces remain unsafe?

The hard case is not sending the replacement. The hard case is proving that:

- distribution names the exact replacement and superseded carrier digests;
- the distribution audience does not widen beyond the readmission gate;
- every target consumer leaves an adoption receipt, refusal receipt, or orphan-copy fence;
- old copies cannot remain current merely because a cache refreshed or a notebook reran;
- partial adoption stays partial and does not become green release status;
- propagation windows are bounded and visible;
- delivery-channel evidence does not become semantic truth; and
- adoption by audit, Ward, dashboard cache, or ViewFS projection is not transitive approval for other consumers.

## Small seam to prove

### 1) distribution manifest

A distribution manifest names the readmitted carriers, superseded carriers, target consumers/surfaces, required receipts, propagation window, delivery channels, and authority boundaries.

```yaml
distribution_manifest:
  manifest_family: foundry_distribution_manifest_v0
  manifest_id: dm_sidecar_dashboard_002_001
  manifest_digest: sha256:dm001
  manifest_status: completed
  issued_at: 2026-05-23T05:25:00Z
  source_packet_id: rp_sidecar_classification_pin_loss_001
  source_readmission_gate_ids:
    - rg_external_audit_sidecar_002_001
    - rg_dashboard_cache_sidecar_002_003
  distributed_carriers:
    - carrier_id: sidecar_weekly_support_dashboard_002
      carrier_family: foundry_semantic_sidecar_v0
      carrier_digest: sha256:newsidecar002
  superseded_carriers:
    - carrier_id: sidecar_weekly_support_dashboard_001
      carrier_digest: sha256:oldsidecar001
  target_consumers:
    - external_audit_notebook
    - dashboard_cache
  target_surfaces:
    - csv_external_audit_extract_002
    - surface_weekly_support_dashboard_002
  delivery_channels:
    - support_bundle
    - cache_refresh
  propagation_window:
    opened_at: 2026-05-23T05:25:00Z
    closes_at: 2026-05-23T05:40:00Z
  required_receipts:
    - adoption_receipt_or_refusal_per_target
    - old_carrier_retirement_or_orphan_fence
  authority_boundaries:
    - does_not_assert_delivery_success_as_truth
    - does_not_issue_ward_verdict
    - does_not_set_cache_policy
```

The manifest is a distribution accounting envelope, not a message-bus event, registry entry, release approval, or cache-invalidation protocol.

### 2) adoption receipt

An adoption receipt is emitted by or for a consumer/surface. It says what carrier was adopted, refused, partially adopted, or quarantined; which old carrier was retired; which local checks or gates were replayed; and which uses remain blocked.

```yaml
adoption_receipt:
  receipt_family: foundry_adoption_receipt_v0
  receipt_id: ar_external_audit_sidecar_002_001
  manifest_id: dm_sidecar_dashboard_002_001
  consumer_id: external_audit_notebook
  surface_id: csv_external_audit_extract_002
  receipt_digest: sha256:ar001
  received_at: 2026-05-23T05:28:00Z
  adoption_result: adopted
  adopted_carrier_id: sidecar_weekly_support_dashboard_002
  adopted_carrier_digest: sha256:newsidecar002
  previous_carrier_id: sidecar_weekly_support_dashboard_001
  previous_carrier_retirement: retired_recalled_history_only
  local_gate_refs:
    - rg_external_audit_sidecar_002_001
  residue_carried:
    - classification_pin
    - code_drift_fence
    - disclosure_cut
  admitted_uses:
    - derive_external_audit_csv_v2
  blocked_uses:
    - rely_on_old_csv
    - issue_audit_opinion
    - transfer_to_ward_without_ward_gate
  non_promises:
    - not_audit_opinion
    - not_source_truth
    - not_global_release_success
```

The receipt proves local semantic adoption posture, not operational delivery success, audit signoff, or policy approval.

### 3) orphan-copy fence

An orphan-copy fence names an old or unacknowledged copy that still exists after distribution. It says which surface owns it, why it is unsafe, what uses are blocked, and what proof would be needed to retire the fence.

```yaml
orphan_copy_fence:
  fence_family: foundry_orphan_copy_fence_v0
  fence_id: ocf_dashboard_csv_old_001
  manifest_id: dm_sidecar_dashboard_002_001
  stale_artifact_id: csv_external_audit_extract_001
  stale_artifact_digest: sha256:oldcsv001
  owning_consumer_id: dashboard_cache
  stale_surface_id: cache_bucket_weekly_csv_old
  detected_at: 2026-05-23T05:42:00Z
  fence_reason: adoption_receipt_missing_after_window
  fence_result: blocked
  replacement_carrier_id: sidecar_weekly_support_dashboard_002
  blocked_uses:
    - serve_weekly_dashboard_csv
    - join_with_current_classification_label
  required_clearance:
    - adoption_receipt_for_replacement
    - purge_or_reclassify_old_copy
    - stale_copy_retired_as_history_only
```

The fence blocks stale reliance; it does not delete data, set retention policy, or prove cache invalidation.

## What this specimen proves

- A readmitted carrier is not distributed until a manifest names carrier digests, superseded carriers, target consumers, target surfaces, required receipts, and propagation bounds.
- A consumer has not adopted a carrier until it leaves an adoption receipt, refusal, partial receipt, quarantine, or orphan-copy fence.
- Old cached, exported, notebook, delegated-worker, or projected copies remain unsafe unless retired as recalled history or fenced.
- Adoption is consumer- and surface-local; it is not transitive release, permission, Ward verdict, audit opinion, ViewFS custody, Harbor remediation, Helm repair completion, or SlopOS proof.
- Delivery-channel evidence is not semantic truth; a message sent, cache refreshed, or file uploaded is weaker than a residue-carrying adoption receipt.
- Propagation windows make stragglers visible instead of letting stale copies survive as current.
- Partial adoption can be useful while still blocking authority-laundering and current-label joins.

## What this specimen must keep separate

- distribution manifest versus release approval;
- adoption receipt versus delivery acknowledgement;
- orphan-copy fence versus deletion or retention policy;
- propagation window versus SLA or cache-control protocol;
- delivery channel versus semantic truth;
- consumer-local adoption versus global release success;
- old-copy retirement versus history rewrite;
- ViewFS projection display versus object custody;
- Ward input adoption versus Ward verdict;
- Harbor remediation status versus Foundry distribution accounting;
- Helm repair completion versus Foundry stale-copy fencing;
- SlopOS support evidence versus Foundry adoption posture.

## Promotion gate for these nouns

Do not widen distribution manifests, adoption receipts, or orphan-copy fences beyond fixture-local use until:

- generated tamper cases mutate carrier ids/digests, target consumers, target surfaces, propagation windows, old-carrier retirement posture, adoption states, local gate refs, and orphan-copy clearance requirements;
- at least one real SlopOS support-card or audit-notebook replacement is distributed with a complete adoption ledger;
- one cache or notebook straggler remains fenced after the propagation window;
- one partial Ward or ViewFS projection adoption stays useful without becoming verdict or custody;
- a second non-SlopOS consumer repeats the same fields without asking Foundry to become a deployment, cache, registry, approval, audit, or policy system; and
- distribution/adoption remains smaller than Harbor remediation, Helm repair completion, Ward appraisal, Schell retention, ViewFS custody, Steward lifecycle finality, or SlopOS proof.

## Why this matters

Foundry can now re-admit a replacement semantic carrier. Without this specimen, a future editor can make the next lie: "the new carrier is live" because it was sent somewhere or a dashboard refreshed. Foundry needs one small machine-checkable layer that says which consumers actually adopted the replacement, which old copies are retired or fenced, and which surfaces are still unsafe.
