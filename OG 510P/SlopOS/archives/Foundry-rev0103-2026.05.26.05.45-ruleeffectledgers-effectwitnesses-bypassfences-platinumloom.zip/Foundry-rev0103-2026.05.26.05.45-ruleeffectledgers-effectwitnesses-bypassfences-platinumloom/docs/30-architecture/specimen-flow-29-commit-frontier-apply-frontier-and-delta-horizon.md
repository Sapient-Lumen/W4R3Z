# Specimen flow 29 — commit frontier, apply frontier, and delta horizon

Goal: keep “the authoritative history has durably advanced” separate from “this subject has actually applied/seen it” and separate again from “incremental catch-up is still possible from here without snapshot or reseed”.

## Scenario
A foreign-backed realization follows one authoritative history: perhaps a replicated configuration stream, a checkpoint lineage, a WAL/log sequence, or a basis-distribution stream.
The authority has durably accepted changes through one point.
That point is the **commit frontier**.

A local subject — replica, cache, watcher, standby, projected view, or helper process — may still lag.
It has only applied or made visible changes through an earlier point.
That point is the **apply frontier**.

So far, that is ordinary lag.
But ordinary lag is not the whole story.
Incremental catch-up is only honest while the required intervening history is still available.
Once old log entries, revisions, WAL, or deltas have been compacted, truncated, or retired, the subject may no longer be able to bridge the gap by replay alone.
That boundary is the **delta horizon**.

Before the delta horizon is crossed, the subject may still catch up incrementally from its current apply frontier.
After the delta horizon is crossed, the authority may still be healthy and the subject may still be repairable, but only through a different class of move: snapshot install, base-backup restore, reseed, or equivalent fresh-state acquisition.

This keeps authoritative advance, local visibility, and repairability from collapsing into one freshness badge.

## Proposed Foundry objects
1. **commit frontier**
   - highest authoritative, durably accepted change point for one stream, history, or basis lineage;
   - keeps authority/current-history truth separate from what any one consumer has made visible.

2. **apply frontier**
   - highest change point one realization, replica, cache, watcher, or observer has actually ingested or applied locally;
   - keeps local currentness inspectable instead of hidden behind one “replicated” bit.

3. **delta horizon**
   - earliest still-usable point for incremental catch-up before snapshot/reseed/reinitialization becomes necessary;
   - keeps ordinary lag distinct from history loss and repair-class change.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- authority has durably advanced farther than one observer has applied;
- watchers or caches need a progress beacon without pretending they are fully current;
- lag is still replay-bridgeable in one moment but no longer bridgeable after compaction or retention loss;
- and repair shifts from “replay the missing delta” to “install or reacquire a new state base”.

## Adjacent but parked
- **gap card** — compact residue for how far one apply frontier trails one commit frontier.
- **reseed trigger** — explicit explanation surface for why replay is no longer sufficient.

## Promotion rule
Do not promote `commit frontier`, `apply frontier`, or `delta horizon` unless they improve:
- one replicated/config-stream specimen,
- one watcher/cache/status specimen,
- and one lagging-subject repair specimen where replay ceases to be honest and snapshot/reseed becomes required.
