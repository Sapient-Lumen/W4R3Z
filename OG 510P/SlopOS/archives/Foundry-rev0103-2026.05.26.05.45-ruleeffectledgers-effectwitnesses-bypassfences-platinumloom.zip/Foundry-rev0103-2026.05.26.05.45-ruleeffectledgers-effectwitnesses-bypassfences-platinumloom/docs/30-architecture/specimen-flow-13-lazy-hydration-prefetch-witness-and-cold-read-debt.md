# Specimen flow 13 — lazy hydration, prefetch witness, and cold-read debt

Goal: keep launch success, locality posture, and later read debt visibly separate.

## Scenario
A foreign realization starts from an OCI-compatible artifact prepared for lazy pulling.
The runtime launches before the entire image is local.
An optimization prefetches some likely-needed files or chunks, but not all of them.
Later file or chunk access still incurs remote fetch or foreign-backed latency.

## Proposed Foundry objects
1. **hydration frontier**
   - describes how much of the artifact is materially local right now;
   - stays separate from artifact identity and from simple launch success.

2. **prefetch witness**
   - compact residue about what the runtime intentionally fetched early;
   - useful for operator truth without pretending the full artifact is now local.

3. **cold-read debt**
   - names the remaining cost of later on-demand hydration;
   - keeps later slowness or dependency honest instead of treating it as an implementation embarrassment.

4. **lazy-locality grade**
   - weakest still-true locality class after successful launch through lazy hydration.

## Why this specimen matters
It pressure-tests whether Foundry can remain honest when:
- a realization is operational before its artifact is fully local,
- optimization changes the first-use story,
- and later reads still reveal foreign dependence.

## Promotion rule
Do not promote `hydration frontier`, `prefetch witness`, `cold-read debt`, or `lazy-locality grade` unless they improve:
- one lazy-start specimen,
- one optimized-prefetch specimen,
- and one case where post-launch reads still reveal incomplete locality.
