# Specimen flow 70 — query contract, result envelope, and validation witness

Goal: keep a future Foundry datacube honest when a query, support-card table, dashboard tile, API result, or export leaves the cube without becoming the cube.

## Scenario

A future SlopOS-facing support view asks Foundry for one neat result:

- rows matching a predicate;
- displayed in a useful order;
- filtered through a policy lens;
- served quickly from a materialized summary or cache;
- accompanied by a green validation indicator.

The tempting but wrong move is to store the emitted table as if it were native cube truth:

- display order becomes semantic priority;
- page-local row count becomes population size;
- pre-aggregation becomes canonical fact identity;
- validation success becomes trust verdict;
- masked or policy-narrowed absence becomes factual absence;
- a query string becomes enough replay evidence.

That would be misleading.
A result is a derived surface over a cut, lens, contract, plan, materialization, and validation posture.
It needs to leave the cube in an envelope.

## Small seam to prove

### 1) query contract

Every emitted result carries a compact record of what was asked.
Examples:

```text
query_contract:
  request_family: slopos_attribute_query
  source_family: credential_presentation_observation
  predicate_digest: sha256:...
  schema_digest: sha256:...
  parameter_digest: sha256:...
  policy_lens: verifier_support_view_v1
  required_cut: foundry_cut_2026_05_13T20_51Z
  engine_profile: relational_subset_v0
  plan_digest: sha256:...
  replay_class: replayable_while_inputs_retained
```

This keeps a query/request shape smaller than a universal query language.

### 2) result envelope

Every emitted result carries a compact wrapper that says what was actually served.
Examples:

```text
result_envelope:
  result_id: result_01H...
  served_from: materialized_summary
  materialization_digest: sha256:...
  source_cut: foundry_cut_2026_05_13T20_51Z
  page_window: cursor_after_row_200_limit_50
  row_count_posture: bounded
  order_posture: tie_broken_stable
  disclosure_lens: support_agent_masked
  freshness_posture: cut_exact_not_live
  replay_class: replayable_with_summary_and_base_rows
```

This keeps output rows, pages, counts, masks, acceleration paths, and order posture from impersonating base cube truth.

### 3) validation witness

Every checked result carries a compact witness for what was checked and what the check meant.
Examples:

```text
validation_witness:
  check_suite_digest: sha256:...
  checked_cut: foundry_cut_2026_05_13T20_51Z
  checked_target: result_01H...
  checks:
    - class: schema_constraint
      scope: result_columns
      outcome: passed
      severity: error
    - class: freshness_sla
      scope: source_family
      outcome: warning
      severity: warn
    - class: policy_contract_subset
      scope: disclosure_lens
      outcome: not_run
      severity: exempt
  checker_version: foundry_validator_v0
```

This keeps validation residue smaller than source truth, local policy approval, or all-future-use guarantee.

## What this specimen proves

Foundry can let derived results leave the cube without inventing:

- one universal semantic layer;
- one mandatory query language;
- one data-contract runtime;
- one warehouse/lakehouse storage model;
- one catalog/provenance/quality super-plane;
- or one assumption that validated output equals true output.

The cube only needs to say:

1. **what was asked,**
2. **what was served,**
3. **what was checked,**
4. and **where later readers must stop before turning the result into base truth.**

## Why this belongs in Foundry

SlopOS already has design-phase pressure from attribute queries, view objects, tracing, trace processing, boundary indexes, browser-mediated identity/trust surfaces, and support-card outputs.
Companion cubes add the same pressure from Harbor contract subsets, Ward appraisal surfaces, ViewFS manifests, Steward approval boundaries, and Schell/Helm helper overlays.

Specimen 70 gives all of those consumers a small honest carrier for query/result/validation residue while keeping Foundry's core datacube ontology small.

## What stays parked

- no universal query language;
- no archive-wide semantic layer;
- no mandatory table-engine or lakehouse model;
- no always-on data-contract runtime;
- no global catalog/provenance/quality umbrella;
- no treating validation success as source truth;
- no treating display order, estimated count, page window, or accelerated serving path as semantic identity.
