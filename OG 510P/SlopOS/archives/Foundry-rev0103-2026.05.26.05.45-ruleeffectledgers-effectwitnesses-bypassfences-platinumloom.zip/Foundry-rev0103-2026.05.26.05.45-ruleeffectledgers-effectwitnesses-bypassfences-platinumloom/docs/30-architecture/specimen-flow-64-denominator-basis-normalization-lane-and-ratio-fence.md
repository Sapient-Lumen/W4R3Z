# Specimen flow 64 — denominator basis, normalization lane, and ratio fence

Goal: keep a future Foundry datacube honest when a visible percentage, rate, average, or coverage value depends on a denominator that is easy to forget and dangerous to recompute casually.

## Scenario
A future support workspace wants one “archive health” panel spanning design-phase SlopOS surfaces.
It can see:
- one `boundary_docs` table with one row per current boundary doc;
- one `profile_matrix_cells` table with one row per profile/surface matrix cell;
- one `signature_records` relation with one row per presented signature record;
- one `eligible_signers` table with one row per signer eligible for a quorum rule;
- and one `coverage_targets` table with one row per expected evidence opportunity.

A tempting but wrong move is to flatten several helpful ratios into one generic reusable measure family:
- `indexed_coverage = 0.91`
- `profile_coverage = 0.74`
- `accepted_signature_rate = 0.83`
- `evidence_coverage = 0.68`

That would be misleading.
Those values divide by different things, align numerator and denominator in different ways, and do not all support the same later regrouping.
Some are same-grain ratios, some compare activity to an opportunity set, some divide distinct accepted signers by eligible signers, and some may already be display-only percent-of-total values from a reporting tool.
The numbers all “look like percentages,” but they do not share one honest reuse story.

## Small seam to prove

### 1) denominator basis
Every ratio-like answer carries a compact witness for what it divided by.
Examples:
- `distinct_subject_population`
- `eligible_subject_subset`
- `signature_record_population`
- `eligible_signer_population`
- `coverage_opportunity_set`
- `exposure_time_total`
- `common_dimension_joined_metric`

This keeps “83% accepted” separate from “83% of records accepted” and from “83% of required targets covered.”

### 2) normalization lane
Every such answer carries a compact witness for how numerator and denominator were aligned before division.
Examples:
- `same_grain_direct`
- `common_dims_joined_subqueries`
- `weighted_recompute_from_parts`
- `coverage_minus_activity`
- `display_only_compare_total`

This keeps same-grain rates visibly smaller than coverage-table ratios or display-layer comparisons.

### 3) ratio fence
Every such answer carries a compact guardrail for what later recomputation is lawful.
Examples:
- `recompute_from_parts_only`
- `same_frame_only`
- `same_filter_only`
- `display_only_not_reusable`
- `forbidden`

This stops support charts and exports from filtering, drilling, or averaging percentages after the denominator has silently changed.

## What this specimen proves
Foundry can preserve denominator honesty with three compact residues instead of inventing:
- a universal KPI registry,
- a denominator algebra for every dashboard,
- or one archive-wide ratio language.

The cube only needs to say:
1. **what the denominator was,**
2. **how numerator and denominator were aligned,**
3. and **what later reuse is still lawful.**

## Example residue

```text
visible_value:
  subject: slopos.boundary.indexing
  measure: indexed_boundary_ratio
  value: 0.91
  denominator_basis: distinct_subject_population
  normalization_lane: same_grain_direct
  ratio_fence: same_filter_only

visible_value:
  subject: slopos.profile.coverage
  measure: profile_requirement_coverage_ratio
  value: 0.74
  denominator_basis: coverage_opportunity_set
  normalization_lane: coverage_minus_activity
  ratio_fence: same_frame_only

visible_value:
  subject: slopos.signature.acceptance
  measure: accepted_signer_ratio
  value: 0.83
  denominator_basis: eligible_signer_population
  normalization_lane: common_dims_joined_subqueries
  ratio_fence: recompute_from_parts_only

visible_value:
  subject: slopos.dashboard.compare_total
  measure: profile_share_of_total
  value: 0.27
  denominator_basis: current_panel_total
  normalization_lane: display_only_compare_total
  ratio_fence: display_only_not_reusable
```

## Why this belongs in Foundry
SlopOS already puts explicit pressure on family-coverage views, profile matrices, quorum-like acceptance posture, and evidence-completeness summaries without yet promising one fixed denominator doctrine.
This specimen gives Foundry the smallest honest way to preserve that fact when future dashboards, exports, and derived summaries start mixing coverage percentages, rates, averages, and display-layer compare-to-total views.

## What stays parked
- no universal denominator registry;
- no mandatory ratio family across the cube;
- no promise that visible percentages are raw facts rather than display overlays;
- no archive-wide weighted-average algebra;
- no claim that percentile/summary outputs can always be re-aggregated.
