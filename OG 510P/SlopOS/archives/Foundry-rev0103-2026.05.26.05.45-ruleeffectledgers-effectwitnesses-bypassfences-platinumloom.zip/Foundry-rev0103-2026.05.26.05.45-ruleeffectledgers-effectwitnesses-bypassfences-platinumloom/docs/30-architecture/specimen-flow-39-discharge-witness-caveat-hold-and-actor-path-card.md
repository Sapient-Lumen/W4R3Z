# Specimen flow 39 — discharge witness, caveat hold, and actor-path card

Goal: keep a derived child artifact honest when it still needs one exact outside/context proof before use, and keep longer multi-hop delegation history smaller than current authority.

## Scenario
A foreign-backed realization already holds a child artifact that was properly derived and attenuated from a stronger parent.
It wants to use that child against one verifier or pass it through one more helper lane.
The tempting mistake is to say “the child exists, therefore it is ready”, and then maybe attach a long actor chain that product surfaces start treating like current authority.

There are three narrower truths that many systems flatten when they only say “delegated”, “exchanged”, or “authorized”.

First, there is a **discharge witness**.
One child may remain honest only when one exact outside or contextual proof has been supplied for one carried caveat.
That keeps “the child parses” distinct from “the child is fully satisfiable now”.

Second, there is a **caveat hold**.
One child may need to stay visibly insufficient, withheld, or not-yet-usable until that exact caveat is satisfied.
That keeps “derived child exists” distinct from “derived child is admissible now”.

Third, there is an **actor-path card**.
One workflow may benefit from keeping a compact ordered trail of prior actors for audit or continuity, but prior actors should stay smaller than the current actor or top-level authority claims.
That keeps “audit/history is present” distinct from “history itself grants current rights”.

This preserves three truths:
- whether the child still needs one exact outside/context proof,
- whether that proof has been supplied for this child,
- and whether a compact multi-hop path is available for audit or continuity.

## Proposed Foundry objects
1. **discharge witness**
   - exact outside or contextual proof that satisfies one carried caveat for one derived artifact;
   - keeps satisfiable-now truth separate from raw child existence.

2. **caveat hold**
   - visible rule that one child artifact remains insufficient or withheld until one required caveat is satisfied;
   - keeps carried caveat pressure separate from generic validity folklore.

3. **actor-path card**
   - compact ordered multi-hop delegation trail kept for audit or continuity without promoting prior actors into current authority;
   - keeps history truth separate from top-level/current-actor authorization truth.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a derived child token, grant, or envelope still needs one extra proof from an outside domain or contextual service;
- the verifier wants that proof to travel with the child instead of making a synchronous lookup;
- product surfaces want to show a multi-hop trail for audit, continuity, or debugging;
- but access control still ought to remain anchored in the current child and the current actor, not in pretty history.

## Adjacent but parked
- **trusted-scope braid** — future compact residue if multiple outside signers/scopes genuinely belong in the cube.
- **disclosed-subset path** — future compact residue if partial actor-path disclosure proves load-bearing across more than one specimen.
- **discharge wallet** — future proof-broker surface if outside/context proofs ever need storage or refresh semantics.
