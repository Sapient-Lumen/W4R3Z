# Specimen flow 94 — precedent ledger, rule-promotion witness, and overgeneralization fence

Goal: make post-disposition rule reuse falsifiable without turning Foundry into policy management, governance, incident management, audit, risk acceptance, authorization, legal compliance, public-release approval, lifecycle finality, or sibling-verdict infrastructure.

## Scenario

Specimen 93 records disposition ledgers, resolution witnesses, and premature-closure fences. That prevents a routed signal from being called resolved without evidence, but a third failure remains: a local resolution can become a precedent, and then a precedent can be promoted into a checker, rulebook sentence, schema field, dashboard refusal rule, or sibling-cube expectation without preserving its scope.

A SlopOS support-card closure, Ward preview exception, ViewFS projection quarantine, public-link scanner failure, Harbor handoff, and external-audit notebook can each teach Foundry something. Foundry must record which closure may become precedent, which precedent may become a rule, which test basis backs that promotion, and where overgeneralization must be fenced because one case, one consumer, one surface, one audience, one purpose, or one sibling boundary was silently widened.

## Nouns under test

- **Precedent ledger** — a bounded carrier for source disposition ledgers, resolution witnesses, premature-closure fences, source scope, candidate generalization scope, intended rule targets, required promotion witnesses, required overgeneralization fences, residual fences, and refused authority.
- **Rule-promotion witness** — scoped evidence that a precedent became local-only, shadow-only, candidate, promoted, partially promoted, rejected, deprecated, or test-failed with positive cases, negative cases, replay status, fixture/rulebook/checker refs, and scope echo.
- **Overgeneralization fence** — a refusal around precedent reuse whose source evidence, test basis, consumer scope, audience, purpose, surface class, sibling boundary, stale status, or unresolved fence is too narrow or contradictory for the proposed rule.

## Fixture requirements

The specimen 94 fixture must include:

- source disposition ledgers, resolution witnesses, premature-closure fences, carriers, consumers, surfaces, audiences, and purpose classes from specimen 93 pressure;
- local-only, candidate, promoted, rejected, quarantined, and superseded precedent ledgers;
- promoted, partial, rejected, test-failed, shadow-only, and deprecated rule-promotion witnesses;
- overgeneralization fences for single-case generalization, scope widening, unresolved-fence erasure, witness-without-tests, stale precedent, false-positive generalization, sibling-boundary laundering, public-release laundering, authorization/audit laundering, and lifecycle/repair laundering;
- positive and negative case refs proving that a promoted rule is not just a renamed local closure;
- explicit promotion scope over consumers, surfaces, audiences, purpose classes, carriers, source ledgers, source witnesses, and target rule surfaces; and
- negative cases for missing precedent ledger, missing promotion witness, missing overgeneralization fence, unknown source ledger, unknown source witness, unknown source fence, resolution-as-rule, closure-as-precedent, single-case generalization, witness without negative tests, unresolved fence erased, false positive generalized, duplicate generalized, stale precedent accepted, target-scope widening, shadow rule as promoted, deprecated rule as active, rule without checker, checker without fixture, rulebook sentence without source ledger, public-release laundering, authorization/audit laundering, repair/lifecycle laundering, sibling-verdict laundering, and lifecycle-transition coverage drift.

## Rules

See [`rule-promotion-rulebook-v0.md`](rule-promotion-rulebook-v0.md).

## Non-goals

- no policy engine, rule engine, governance workflow, standards process, incident postmortem process, audit, authorization, legal-compliance, public-release, lifecycle, repair, or sibling-verdict model;
- no guarantee that a promoted rule is globally right, complete, stable, permanent, accepted, or applicable outside its scope;
- no automatic conversion of closure, disposition, false-positive, duplicate, remediation, or sibling outcome into a Foundry rule;
- no global severity, priority, precedent, rule, policy, or governance taxonomy; and
- no replacement for egress, regression, waiver, portability, delegation, revocation, remediation, distribution, inventory, exposure, obligation, fulfillment, verification, recheck/drift, routing, or disposition checks.

## Promotion status

Fixture-local. The nouns are useful only while they prevent resolved local cases from becoming ambient archive law. Promotion requires generated precedent-promotion tamper cases plus at least one second non-SlopOS consumer whose rule target diverges from SlopOS support-card semantics without becoming policy/governance machinery.
