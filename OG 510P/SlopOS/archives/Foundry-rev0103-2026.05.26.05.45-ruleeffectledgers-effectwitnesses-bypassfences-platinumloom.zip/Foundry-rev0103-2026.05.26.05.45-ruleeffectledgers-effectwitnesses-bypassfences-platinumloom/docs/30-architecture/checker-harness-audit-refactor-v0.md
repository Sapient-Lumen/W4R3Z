# Checker harness audit and refactor v0

This note records the rev0096 audit/refactor of Foundry's executable specimen harness.

## Audit finding

The rev0083–rev0095 harness grew correctly but linearly: each specimen added a focused checker, and `tools/check_foundry_all.py` manually invoked all of them through repeated runner code. That was acceptable while the harness had a few checks, but by specimen 89 the runner itself had become a quiet drift surface: a new fixture could be added, a standalone checker could pass in isolation, and the aggregate runner could still omit it unless the maintainer remembered to patch the list.

## Refactor

rev0096 adds `tools/foundry_checklib.py` with tiny shared helpers for root discovery, fixture discovery, JSON loading, timestamp parsing, sha256-prefix checks, fatal-error reporting, and ordered runner execution. It then rewrites `tools/check_foundry_all.py` so all checks are registered in a single ordered list and executed by the shared runner.

The existing focused checkers remain standalone. Foundry is not adopting a test framework, fixture engine, schema generator, or generalized validation DSL.

## New audit pressure

Specimen 90 also adds a `harness_audit` block inside its fixture. The new verification-audit checker verifies that the new specimen names the aggregate runner, the shared library, the new checker, the specimen index, and the archive index as checked surfaces. This is intentionally small: it proves that the refactor was not prose-only, without trying to certify overall test coverage.

## Non-goals

- no pytest/unittest migration;
- no generated checker framework;
- no global schema validator;
- no automatic fixture synthesis;
- no coverage badge or certification;
- no audit opinion about Foundry's correctness; and
- no promise that every semantic failure is modeled.

## Next useful refactor

The next harness cleanup should probably extract common checker vocabulary for `authority_boundaries`, `required negative cases`, `scope` fields, and source/carrier reference validation. That extraction should happen only when two or three future checkers repeat exactly the same constraints; premature generic validators would hide the seams Foundry is trying to expose.
