# Architecture overview

Foundry studies how native meaning survives when enacted on foreign ground.

The founding model has five layers:

1. **artifact basis** — image, package, component, template, snapshot, or similar carrier;
2. **declared interface or world** — what the artifact says it needs and offers;
3. **runtime ground** — container host, microVM, guest kernel, component host, TEE, or compatibility layer;
4. **live realization** — what is actually instantiated, attached, resumed, degraded, or mediated now;
5. **continuity evidence** — what can be restored, reacquired, cloned, or must instead be freshly re-realized.

Foundry’s job is to keep those layers from collapsing into “it runs somewhere else”.

## rev0003 posture additions
- keep snapshot, callback, and provider success signals visibly weaker than durable local consequence;
- prefer one or two specimen artifacts before inventing family-wide registries;
- track downgrade and freshness as first-class modifiers instead of folding them into a success bit.


## rev0021 posture additions
- activation is still smaller than blessed currentness when a newly booted basis remains under trial;
- post-boot success should cross an explicit latch instead of being inferred from one clean boot;
- bounded fallback belongs in public meaning, not hidden selector folklore.


## rev0023 posture additions
- grouped basis pieces may need a named coherence target before any larger universal deployment family exists;
- a newer conflicting target should wait behind a confirmation fence instead of silently superseding uncertain prior adoption;
- rollout or cohort hints may be useful later, but they remain smaller than basis truth and should stay parked for now.


## rev0023 posture additions
- a floating branch, channel, ref, or cohort request is smaller than the exact basis that is actually reviewed, prepared, or activated;
- selector drift should cross an explicit fence instead of letting prior review or install intent silently follow the new head;
- channels and rollout tags may stay operationally useful while remaining weaker than exact basis truth.


## rev0025 posture additions
- an offered update edge or exact basis is smaller than local admissibility and smaller again than current basis truth;
- local holds and admission windows should stay visible instead of masquerading as transient errors or hidden scheduler state;
- rollout cohorts, wariness, and lock-manager scheduling may remain operational hints outside basis truth.

## rev0025 posture additions
- offered and locally admissible remain smaller than directly applicable from the exact current state;
- prerequisite witnesses and applicability fences should stay visible instead of being flattened into version folklore;
- barrier hops may preserve valid paths without promoting a giant dependency or migration solver into the cube.

## rev0026 posture additions
- success or bless is still smaller than a ratcheted anti-downgrade floor; advancing that floor deserves its own explicit mark;
- remembered last-known-good history is smaller than ordinary rollback safety once a rollback floor moves forward;
- older functional content may still return, but only through a visibly separate rescue path instead of quiet rollback folklore.

## rev0028 posture additions
- a basis or snapshot can stop being current and still remain intentionally retained; currentness and collectability should not collapse.
- reclaim should cross an explicit fence when cleanup or downstream teardown still remains.
- pins, leases, holds, and finalizers may all be operational forms of one smaller retention truth without forcing a giant unified GC plane.


## rev0027 posture additions
- current or blessed basis truth is still smaller than guaranteed persistent-state compatibility;
- migration should cross an explicit cut instead of hiding inside one generic update-success bit;
- rollback and recovery may need a visible reset rail when state continuity cannot be preserved honestly.


## rev0029 posture additions
- a realization can stop being the ordinary admission target and still remain honestly live for pre-existing work;
- drain overlap should stay visible instead of collapsing into instant replacement folklore;
- final teardown or reclamation should wait behind an explicit grace fence when old readers or connections may still exist.


## rev0037 posture additions
- a current negative lookup can be real without implying total destruction or safe reuse;
- durable withdrawal markers should stay visible instead of hiding behind one cheerful not-found bit;
- purge and identity reuse may need an explicit resurrection fence when stale caches or replicas still matter.

## rev0039 posture additions
- current validity is still smaller than action-specific assurance, recentness, and explicit user intent;
- step-up should cross visible class and recency boundaries instead of hiding inside one generic auth-success bit;
- user presence or user verification may still be required now even while ordinary session continuity remains real.



## rev0040 posture additions
- a live-valid and even sufficiently assured artifact can still be wrong for the current presenter, receiver, or exact presentation;
- presenter proof, audience restriction, and request-shaped binding should stay visible instead of collapsing into one generic auth-success bit;
- signer registries, replay ledgers, and generic resource catalogs may be useful later, but they remain parked outside the cube for now.


## rev0041 posture additions
- a narrowed descendant artifact should stay visibly distinct from the stronger parent it came from;
- upper-bound attenuation is healthier than child artifacts that quietly broaden or obscure parent scope;
- parent or lineage invalidation can still shadow descendants, so child truth should not masquerade as independent timeless authority.


## rev0044 posture additions
- when a fact became true can remain smaller than when Foundry learned it, and both should stay smaller than one flattened present-looking row;
- incomplete descriptive context should stay visible instead of forcing premature dimensional completeness;
- derived summaries or pre-aggregations may be useful later, but they remain smaller than the cube’s core meaning model for now.

## rev0045 posture additions
- every value-bearing row should say what one row means before dimensions or measures start to sprawl;
- snapshot/state, delta/event, cumulative, and derived/query-shaped values should stay visibly different instead of collapsing into one generic number family;
- reduction legality matters: additive, semi-additive, non-additive, approximate, and query-shaped outputs should not hide behind one friendly value column.


## rev0049 posture additions
- exact-at-cut, bounded-estimate, advisory-rank, and query-shaped outputs should stay visibly different instead of collapsing into one generic value family;
- any non-exact or rank-shaped value should carry a bound witness or explicit “no numeric bound” posture;
- even exact values can remain restatable for a while, so correction horizons should stay visible when late arrival or finalization lag matters.


## rev0054 posture additions
- a bucket timestamp is smaller than bucket completeness; progress/frontier posture should stay visible when late arrival matters;
- preview, on-time, reopenable, and finalized outputs are different truths and should not silently share one final-looking row shape;
- lateness or lookback policy is part of meaning, not hidden engine tuning, so closure claims should stay explicit instead of folkloric.

## rev0076 posture additions
- a query result is a derived surface over a cut, lens, plan, materialization, and validation posture, not base cube truth;
- order, row count, page window, disclosure lens, freshness, and served-from path deserve explicit result-envelope residue;
- validation success should remain a witness about checks performed, not a trust verdict or source-truth replacement.

## rev0077 hierarchy/rollup honesty note

Foundry now has one narrow seam for hierarchy-shaped output:
- hierarchy scope says which scheme, member cut, parent relation, valid-combination basis, availability basis, and default-member posture was in play;
- rollup path says how source grain reached the displayed parent or bucket; and
- aggregation guard says which reductions were allowed or refused.

This does not create a global dimension model, calendar authority, geography engine, or storage-layout truth model.

## rev0079 aggregate-release honesty note

Foundry now has one narrow seam for aggregate-release-shaped output:
- disclosure cut says which policy, audience, protected-unit basis, source cut, release-set id, method family, threshold/budget posture, contribution bounds, and review run governed visibility;
- suppression witness says which cells/results were released, suppressed, coarsened, perturbed, noisy, refused, or not run; and
- differencing fence says where totals, subtotals, cached outputs, neighboring queries, or cross-audience releases must not be combined.

This does not create a privacy engine, SDC solver, clean-room product, publication authority, or global protected-entity registry.

## rev0083 projection-honesty note

Foundry now has one narrow seam for egress-shaped output:
- residue sidecar says which query/result, rollup, materialization, disclosure, observedness, balance, and classification residue moved beside a thin surface;
- flattening refusal says when a requested chart/table/CSV/JSON/markdown/support-card shape would drop meaning and must not be emitted as-is; and
- fixture checks make the refusal cases executable.

This does not create a universal semantic layer, warehouse model, terminology server, validation DSL, privacy engine, or Foundry-owned SlopOS authority.

## rev0084 refusal-honesty note

Foundry now has one narrow seam for blocked egress attempts:
- refusal receipt says which requested surface was blocked, which rule fired, which semantic residue would be lost, and which repair escapes are safe;
- egress manifest says which output attempts were evaluated together and binds passed attempts to sidecars or in-band residue and refused attempts to receipts; and
- conformance gate says the local deterministic rule suite that made the pass/refuse decision.

This does not create an API gateway, policy-denial system, privacy engine, BI product, global error ontology, or sibling-cube verdict.

## rev0085 regression-honesty note

Foundry now has one narrow seam for revision-to-revision egress-residue changes:
- semantic diff manifest says which sidecar, egress-manifest, refusal-receipt, rule-suite, and consumer facts changed between revisions;
- regression lock says which fixture-local invariant and residue paths must not silently change; and
- tamper corpus gate says which dishonest mutations must fail before a compatibility claim is trusted.

This does not create a global migration framework, schema registry, JSON Patch dialect, cryptographic trust system, BI/audit product, or sibling-cube verdict.


## rev0086 exception-honesty note

Foundry now has one narrow seam for bounded semantic exceptions:
- waiver warrant says who accepted which specific limitation, under which scope, linked to which refusal receipt or regression lock;
- expiry witness says whether the warrant is valid, expired, rejected, or requires renewed review; and
- exception replay gate says which refusal, regression, and waiver rules must rerun before use, renewal, or revision carry-forward.

This does not create a policy engine, approval workflow, risk register, exception registry, SLA waiver product, or sibling-cube verdict.

## rev0087 consumer-portability-honesty note

Foundry now has one narrow seam for cross-consumer reuse:
- consumer passport says who is consuming the carried surface, for which purpose and audience, and which residue and forbidden inferences govern interpretation;
- portability witness says which residue can travel from a source consumer to a target consumer, and which residue, verdicts, or sibling authorities cannot travel; and
- interpretation gate says which egress, regression, waiver, and portability rules must rerun before the target consumer uses the surface.

This does not create a permission system, discovery catalog, compatibility registry, trust exchange, audit-evidence framework, policy handoff, or sibling-cube verdict transfer.

## rev0088 delegation-boundary note

Delegated semantic acts are now treated as a separate seam from consumer portability. A consumer passport says who can interpret a surface; a portability witness says what residue can travel; a delegation warrant says who may perform a narrow semantic act for a relying consumer; a reliance receipt records that use; and a transitive-use fence says where the chain stops. Foundry still does not own permission, policy approval, audit opinion, or sibling-cube verdicts.

## rev0089 revocation/recall honesty note

Foundry now has one narrow seam for previously emitted semantic carriers that become unsafe:
- revocation notice says which carrier is invalidated, why, since when, for whom, and which actions must occur before reuse;
- recall receipt says which consumer processed the notice, quarantined cached surfaces, reran gates, adopted replacements, and refused authority-like inferences; and
- stale-reliance fence says where old digests, revoked warrants, withdrawn waivers, stale caches, or silent supersessions fail closed.

This does not create a status registry, authorization revocation endpoint, credential-status service, PKI checker, update framework, cache-control product, legal hold, source-truth correction system, or sibling-cube verdict transfer.

## rev0090 remediation/readmission honesty note

Foundry now has one narrow seam for recalled semantic carriers that have proposed replacements:
- remediation packet says which notice, old carrier, quarantined artifacts, affected consumers, repair actions, candidate replacements, required witnesses, and required gates govern the attempt;
- replacement witness says which old digest and new digest are linked, which semantic loss was corrected, which gates replayed, and which history/residual risks remain; and
- readmission gate says which named consumer/use can rely on the replacement again and which old uses or authority-like inferences remain blocked.

This does not create a repair workflow, Harbor remediation status, Helm repair completion, Ward verdict, Schell retention decision, ViewFS custody truth, Steward finality, SlopOS proof, supply-chain attestation, approval process, or cache-control product.

## rev0091 distribution/adoption honesty note

Foundry now has one narrow seam for carrying readmitted semantic carriers through relying surfaces:
- distribution manifest says which carriers, old carriers, target consumers/surfaces, channels, and propagation windows are in scope;
- adoption receipt says which consumer/surface adopted, refused, partially adopted, quarantined, or superseded the carrier; and
- orphan-copy fence says where stale notebook, cache, projection, export, or delegated copies remain blocked.

This does not create a message bus, registry, cache-control product, release approval, audit evidence system, or sibling-cube verdict.

## rev0092 surface-inventory honesty note

Foundry now has one narrow seam for finding reachable semantic copies after distribution:
- surface inventory sweep says which distribution manifests, carrier ids, expected surfaces, discovery sources, and method limits were in scope;
- reachability witness says which surface, artifact, alias, digest, and residue were actually observed; and
- coverage-gap fence says which missing, unknown, permission-denied, duplicate, stale, or ambiguous surface remains blocked.

This does not create a catalog, CMDB, object-store crawler, lineage graph, SBOM, cleanup controller, custody system, or cache-control product.

## rev0093 exposure-accounting honesty note

Foundry now has one narrow seam for checking audience and purpose after inventory:
- exposure ledger says which source inventory, carrier ids, intended audiences, allowed purposes, access modes, observed surfaces, and non-promises govern the check;
- audience witness says which audience can reach which surface under which observed access modes and purposes; and
- purpose fence says where unknown readers, public links, inherited groups, purpose widening, access-mode widening, expired evidence, or missing authority evidence fail closed.

This does not create authorization, IAM, ABAC, OAuth/JWT validation, ODRL policy execution, consent, privacy-policy, public-release, deletion, custody, audit, or sibling-cube verdict infrastructure.

## rev0094 obligation-accounting honesty note

Foundry now has one narrow seam for checking whether obligations travel after exposure:
- obligation ledger says which source exposure evidence, carrier ids, surfaces, audiences, purposes, obligations, required acknowledgments, and authority boundaries govern the check;
- acknowledgment witness says which consumer/surface/audience accepted, partially accepted, refused, quarantined, or missed required obligations; and
- obligation-drift fence says where sidecar detachment, dropped classification pins, hidden observation status, missing recall routes, no-reexport downgrade, inherited/public exposure, wrong-consumer acknowledgment, or sibling-boundary laundering fails closed.

This does not create rights-expression, authorization, legal-compliance, consent, public-release, deletion, custody, audit, or sibling-cube verdict infrastructure.
