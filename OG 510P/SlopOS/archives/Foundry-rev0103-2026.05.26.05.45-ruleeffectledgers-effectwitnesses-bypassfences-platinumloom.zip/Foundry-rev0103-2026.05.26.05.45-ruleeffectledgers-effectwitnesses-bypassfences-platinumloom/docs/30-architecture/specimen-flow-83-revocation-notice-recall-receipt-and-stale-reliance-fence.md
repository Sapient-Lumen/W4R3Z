# Specimen flow 83 — revocation notice, recall receipt, and stale-reliance fence

Goal: make semantic-carrier invalidation explicit without converting Foundry into a status registry, cache controller, authorization revocation endpoint, credential-status service, PKI checker, update framework, legal-hold workflow, or sibling-cube correction authority.

## Scenario

Specimen 82 made delegated semantic acts explicit. A new failure remains: a sidecar, waiver, delegation warrant, portability witness, refusal receipt, or cached egress surface can be valid at emission time and later become unsafe. The bytes may not change. The digest may still match. A dashboard, audit notebook, Ward input queue, or ViewFS projection can continue relying on stale residue unless Foundry carries an invalidation signal and requires consumer-local recall.

A SlopOS support workspace discovers that a sidecar-backed dashboard exported under a classification pin omitted a later code-drift fence. It issues a Foundry-local notice for the affected semantic carrier. External audit and Ward consumers must acknowledge, quarantine, replay their gates, and use a replacement before relying again. A cache that did not receive or process the notice must fail closed.

The hard case is not whether an artifact can be deleted. The hard case is whether a downstream consumer can tell:

- which semantic carrier was invalidated;
- which consumers, surfaces, receipts, warrants, waivers, and caches were affected;
- why the carrier is unsafe and from what time/cut the invalidation applies;
- whether a replacement exists;
- which cached or delegated uses were quarantined;
- which gates reran before reuse; and
- where stale reliance must fail even when the old digest still verifies.

## Small seam to prove

### 1) revocation notice

A revocation notice names the semantic carrier that can no longer be relied on under a scope, the reason, the issuer, the effective time, affected consumers, and required actions.

```yaml
revocation_notice:
  notice_family: foundry_revocation_notice_v0
  notice_id: rn_sidecar_classification_pin_loss_001
  notice_digest: sha256:notice001
  notice_status: active
  issuer_consumer_id: slopos_support_workspace
  revoked_artifact_family: foundry_semantic_sidecar_v0
  revoked_artifact_id: sidecar_weekly_support_dashboard_001
  revoked_artifact_digest: sha256:oldsidecar001
  reason_class: classification_pin_error
  reason_summary: old export omitted a required code-drift fence for deprecated browser_federation rows
  issued_at: 2026-05-22T21:20:00Z
  effective_at: 2026-05-22T20:45:00Z
  propagation_deadline: 2026-05-23T00:00:00Z
  affected_consumers:
    - external_audit_notebook
    - ward_appraisal_queue
    - dashboard_cache
  affected_surfaces:
    - surface_weekly_support_dashboard_001
  required_actions:
    - quarantine_cached_surface
    - replay_interpretation_gate
    - replace_sidecar_before_reuse
    - emit_recall_receipt
  superseding_artifacts:
    - sidecar_weekly_support_dashboard_002
  authority_boundaries:
    - does_not_delete_source_rows
    - does_not_issue_ward_verdict
    - does_not_assert_slopos_truth
```

The notice is a status overlay on Foundry residue, not a source-truth rewrite.

### 2) recall receipt

A recall receipt records that a consumer processed a notice, what it quarantined, what it replayed, what replacement it adopted, and what inferences it refused.

```yaml
recall_receipt:
  receipt_family: foundry_recall_receipt_v0
  receipt_id: rc_external_audit_sidecar_recall_001
  notice_id: rn_sidecar_classification_pin_loss_001
  consumer_id: external_audit_notebook
  received_at: 2026-05-22T21:21:00Z
  processed_at: 2026-05-22T21:25:00Z
  recall_result: quarantined_and_replayed
  actions_taken:
    - quarantined_cached_csv
    - replayed_interpretation_gate
    - replaced_sidecar
    - preserved_old_receipt_for_audit
  quarantined_artifacts:
    - csv_external_audit_extract_001
  replayed_gates:
    - R-PORT-006-INTERPRETATION-GATE
    - R-RECALL-006-STALE-RELIANCE-FENCE
  replacement_artifacts:
    - sidecar_weekly_support_dashboard_002
  refused_inferences:
    - audit_opinion
    - source_truth
    - ward_trust_verdict
```

The receipt is acknowledgment and replay evidence, not approval.

### 3) stale-reliance fence

A stale-reliance fence blocks old carriers, caches, or reliance receipts after a revocation notice unless the consumer has processed the notice and rerun required gates.

```yaml
stale_reliance_fence:
  fence_family: foundry_stale_reliance_fence_v0
  fence_id: srf_old_sidecar_no_reuse_001
  notice_id: rn_sidecar_classification_pin_loss_001
  consumer_id: dashboard_cache
  blocked_artifacts:
    - sidecar_weekly_support_dashboard_001
    - surface_weekly_support_dashboard_001
  blocked_uses:
    - serve_cached_dashboard_tile
    - reuse_old_sidecar_digest
    - derive_external_csv
  stale_after: 2026-05-22T20:45:00Z
  required_recheck:
    - recall_receipt_present
    - replacement_sidecar_present
    - interpretation_gate_replayed
  failure_code: stale_reliance_refused
```

The fence is the refusal edge: unchanged bytes are not enough after status changed.

## What this specimen proves

- Semantic carriers can be invalidated without deleting source evidence or rewriting history.
- Revocation notices must identify carrier family, carrier id, carrier digest, reason, scope, affected consumers, and required actions.
- Affected consumers must acknowledge with recall receipts or fail behind stale-reliance fences.
- Recall receipts preserve quarantine/replay/replacement evidence without becoming approval, trust, or sibling verdict.
- Cached surfaces, old sidecar digests, revoked delegation warrants, withdrawn waivers, stale refusal receipts, and silent supersessions can all be blocked.
- Revocation is consumer- and scope-sensitive; a notice to one audience cannot silently stand in for another.

## What this specimen must keep separate

- revocation notice versus source-truth correction;
- recall receipt versus approval or audit opinion;
- stale-reliance fence versus cache-control product;
- carrier invalidation versus deletion;
- replacement artifact versus automatic repair;
- notice issuer versus sibling authority;
- active notice versus rescinded or informational notice;
- cache quarantine versus retention/forgetting authority;
- downstream acknowledgment versus transitive trust.

## Promotion gate for these nouns

Do not widen revocation notices, recall receipts, or stale-reliance fences beyond fixture-local use until:

- generated tamper cases mutate notice reason, carrier digest, effective time, affected consumer, propagation deadline, replacement artifact, and required action;
- one real cached support-card or notebook packet is quarantined by a notice;
- one revoked delegation warrant and one withdrawn waiver block concrete reuse attempts;
- a second non-SlopOS consumer repeats the same fields without asking Foundry to become a global status service; and
- recall receipts remain smaller than approval, audit opinion, legal hold, Ward verdict, Harbor status, Steward finality, Schell retention, ViewFS identity, or SlopOS proof.

## Why this matters

Foundry now has carriers for egress, refusal, regression, waiver, consumer interpretation, and delegation. The next leak is time: a carrier can become unsafe after release, while caches and notebooks continue to rely on old bytes. Foundry needs a small witness that says the carrier is no longer usable under a scope, the consumer processed the notice, and stale reliance fails until a replacement or replay succeeds.
