# Specimen flow 82 — delegation warrant, reliance receipt, and transitive-use fence

Goal: make delegated interpretation explicit without converting Foundry residue into permission, policy approval, sibling verdict, or transitive authority.

## Scenario

Specimen 81 made cross-consumer reuse depend on consumer passports, portability witnesses, and interpretation gates. A new failure remains: one consumer can informally ask another actor to prepare, summarize, or carry a surface, and later readers may treat that delegated act as if authority itself traveled.

A SlopOS support workspace delegates a narrow export worker to prepare a sidecar-backed packet for an external audit notebook and a Ward appraisal queue. The worker can carry semantic residue and run local gates. It cannot issue an audit opinion, approve policy, make a Ward trust verdict, widen the audience, or redelegate the same authority to a research notebook.

The hard case is not whether a delegate can copy bytes. The hard case is whether a downstream consumer can tell:

- who granted the semantic act;
- who performed it;
- who is allowed to rely on it;
- what residue was delegated and what residue was withheld;
- which purpose, audience, cut, and artifact scope bound the act;
- whether the grant expired or was revoked; and
- whether any later transitive use must fail.

## Small seam to prove

### 1) delegation warrant

A delegation warrant names the grantor consumer, delegate, relying consumer, permitted semantic acts, forbidden acts, delegated residue, withheld residue, scope, expiry, revocation posture, and non-transitive default.

```yaml
delegation_warrant:
  warrant_family: foundry_delegation_warrant_v0
  warrant_id: dw_slopos_export_worker_to_external_audit_001
  grantor_consumer_id: slopos_support_workspace
  delegate_consumer_id: delegated_export_worker
  relying_consumer_id: external_audit_notebook
  artifact_ids:
    - surface_weekly_support_dashboard_001
    - receipt_csv_without_full_sidecar_001
  permitted_semantic_acts:
    - render_sidecar_backed_csv
    - carry_refusal_receipts
    - run_interpretation_gate
    - emit_reliance_receipt
  forbidden_semantic_acts:
    - issue_audit_opinion
    - approve_policy
    - transfer_ward_verdict
    - assert_source_truth
    - widen_audience
    - redelegate
  delegated_residue:
    - classification_pins
    - source_cut
    - query_contract_digest
    - result_envelope_digest
    - refusal_receipts
  withheld_residue:
    - slopos_operator_hint
    - ward_appraisal_posture
    - waiver_as_approval
    - source_truth
    - sibling_authority
  scope:
    purpose: review_sampling_only
    audience: reviewer_pair_only
    source_cut: cut_slopos_support_week_2026w21
    classification_cut: classcut_boundary_family_2026_05
  issued_at: 2026-05-22T20:05:00Z
  expires_at: 2026-06-05T00:00:00Z
  revocation_status: active
  non_transitive: true
  requires_reliance_receipt: true
  requires_transitive_fence: true
  verdict_transfer_allowed: false
  sibling_authority_delegation_allowed: false
```

A delegation warrant is not OAuth, an entitlement, a permission token, a legal agency grant, an audit appointment, or a sibling-cube approval. It is a Foundry-local witness that a narrow semantic act was bounded.

### 2) reliance receipt

A reliance receipt records that a target consumer relied on a delegated act, which warrant was checked, which rules reran, which residue was preserved, and which inferences were refused.

```yaml
reliance_receipt:
  receipt_family: foundry_reliance_receipt_v0
  receipt_id: rr_external_audit_packet_001
  warrant_id: dw_slopos_export_worker_to_external_audit_001
  delegate_consumer_id: delegated_export_worker
  relying_consumer_id: external_audit_notebook
  reliance_class: evidence_packet_only
  used_semantic_acts:
    - render_sidecar_backed_csv
    - carry_refusal_receipts
    - run_interpretation_gate
  checked_rules:
    - R-DELEG-001-WARRANT-REQUIRED
    - R-DELEG-003-SCOPE-BOUNDARY
    - R-DELEG-005-RELIANCE-RECEIPT
    - R-PORT-006-INTERPRETATION-GATE
  preserved_residue:
    - classification_pins
    - source_cut
    - refusal_receipts
    - expiry_witnesses
  refused_inferences:
    - audit_opinion
    - policy_approval
    - source_truth
    - ward_trust_verdict
  result: allowed
```

The receipt keeps reliance smaller than trust, approval, or verdict.

### 3) transitive-use fence

A transitive-use fence says that a delegated act may not be used as the basis for a further delegation, audience widening, purpose widening, or authority transfer unless a new warrant exists.

```yaml
transitive_use_fence:
  fence_family: foundry_transitive_use_fence_v0
  fence_id: tuf_external_audit_no_redelegate_001
  warrant_id: dw_slopos_export_worker_to_external_audit_001
  delegate_consumer_id: delegated_export_worker
  relying_consumer_id: external_audit_notebook
  allowed_redelegation: false
  blocked_acts:
    - redelegate
    - widen_audience
    - widen_purpose
    - issue_verdict
    - claim_sibling_authority
  failure_code: transitive_delegation_refused
```

The fence blocks the common mistake where a reviewed handoff becomes a reusable authority chain.

## What this specimen proves

- Delegation of a semantic act is not transfer of authority.
- A source consumer, delegate, and relying consumer must all be named.
- Scope includes purpose, audience, artifact set, source cut, and classification cut.
- Delegated residue and withheld residue must both be explicit.
- Reliance leaves a receipt; it is not a silent copy or generic success.
- Expired, revoked, unscoped, self-issued, or transitive delegations fail.
- Portability witnesses do not substitute for delegation warrants.
- Sibling-cube authority cannot be delegated through Foundry.

## What this specimen must keep separate

- delegation warrant versus permission grant;
- reliance receipt versus trust verdict;
- transitive-use fence versus authorization policy;
- delegated residue versus delegated authority;
- actor chain versus source truth;
- current actor versus prior actor history;
- consumer portability versus consumer delegation;
- Ward appraisal input versus Ward appraisal verdict;
- external review packet versus audit opinion.

## Promotion gate for these nouns

Do not widen delegation warrants, reliance receipts, or transitive-use fences beyond fixture-local use until:

- generated tamper cases mutate grantor, delegate, relying consumer, scope, expiry, revocation status, and forbidden acts;
- one real sibling-cube handoff consumes a reliance receipt without treating it as verdict;
- one expired or revoked warrant blocks a concrete egress reuse attempt;
- one attempted redelegation fails with a transitive-use fence; and
- a second non-SlopOS consumer repeats the same fields without asking Foundry to become an authorization system.

## Why this matters

Foundry now has carriers for egress, refusal, regression, exception, and consumer interpretation. The next leak is delegated use: a human, worker, queue, notebook, or sibling input process can perform a narrow semantic act, and later readers can mistake that act for transferred authority. Foundry needs a small witness that says exactly what was delegated, what was relied upon, and where the chain stops.
