# Specimen flow 89 — fulfillment receipt, completion witness, and nonfulfillment fence

Goal: make post-obligation fulfillment explicit without turning Foundry into a workflow engine, scheduler, Kubernetes controller, authorization system, legal-compliance system, rights-expression engine, audit product, deletion/retention system, custody model, repair workflow, or sibling-cube verdict.

## Scenario

Specimen 88 proved that Foundry can account for which semantic obligations travel with an exposed surface and whether each consumer acknowledged, partially acknowledged, refused, quarantined, or missed those obligations. A new failure remains: acknowledgment can be treated as fulfillment.

A SlopOS dashboard, external-audit CSV, Ward preview, ViewFS projection, delegated-worker cache, shadow export, and public-link scan have obligation ledgers and acknowledgment witnesses. Foundry must now record which acknowledged obligations were actually fulfilled: sidecars attached, classification pins verified, observation-status warnings displayed, recall routes tested, no-reexport boundaries enforced, rechecks performed before reuse, quarantine applied, and sibling non-promises preserved. Missing, late, partial, wrong-scope, digest-mismatched, inherited, public-link, or authority-laundered fulfillment must be fenced.

## Nouns under test

- **Fulfillment receipt** — a scoped closure record for acknowledged obligations, due windows, required completion evidence, required fences, and remaining unsafe uses.
- **Completion witness** — consumer/surface/audience-local evidence that a specific obligation was completed, partially completed, pending, missed, refused, quarantined, or superseded.
- **Nonfulfillment fence** — a block around missing, late, wrong-scope, partial, digest-mismatched, public, inherited, or authority-laundered fulfillment until replay and clearance evidence exists.

## Fixture requirements

The specimen 89 fixture must include:

- complete, partial, and blocked fulfillment receipts;
- source obligation-ledger, acknowledgment-witness, obligation-drift-fence, carrier, and consumer references from specimen 88 pressure;
- obligations-to-fulfill for sidecar preservation, classification-pin verification, observation-status display, recall-route probe, no-reexport enforcement, recheck-before-reuse, quarantine application, and sibling-boundary preservation;
- completion witnesses for completed, partial, pending, missed, refused, quarantined, and superseded states;
- nonfulfillment fences for missing recall-route probes, no-reexport leakage, recheck-after-execute, quarantine failure, digest mismatch, public-link fulfillment failure, inherited-scope ambiguity, and sibling-boundary laundering;
- non-promises that refuse workflow completion, cleanup-controller status, authorization, legal compliance, consent, rights management, public release, deletion, retention, audit opinion, custody, SlopOS proof, Harbor remediation, Helm repair completion, Steward finality, and sibling-cube verdicts; and
- negative cases for missing fulfillment receipts, missing source obligations, missing completion witnesses, acknowledging-as-fulfilling, deadline expiry, dropped sidecar/classification/status/recall/no-reexport/recheck/quarantine/sibling obligations, wrong consumer/surface/audience, partial-as-complete, digest mismatch, public/inherited fulfillment without fences, fulfillment-as-authorization, fulfillment-as-legal-compliance, fulfillment-as-audit-opinion, and sibling-verdict laundering.

## Rules

See [`fulfillment-accounting-rulebook-v0.md`](fulfillment-accounting-rulebook-v0.md).

## Non-goals

- no workflow engine, task scheduler, or cleanup controller;
- no Kubernetes finalizer implementation;
- no rights-expression, ODRL policy execution, XACML/ABAC/IAM authorization, or legal-compliance decision;
- no consent, public-release, deletion, retention, or privacy-law workflow;
- no audit opinion or certification;
- no Ward verdict;
- no ViewFS custody claim;
- no Harbor remediation or external-status authority;
- no Helm repair completion;
- no Steward lifecycle finality;
- no SlopOS proof claim; and
- no global fulfillment registry.

## Promotion status

Fixture-local. The nouns are useful only while they prevent acknowledged semantic obligations from silently becoming fulfilled obligations. Promotion requires generated fulfillment tamper cases plus at least one second non-SlopOS consumer with deadline, no-reexport, recall-route, quarantine, public-link, inherited-access, or sibling-boundary pressure.
