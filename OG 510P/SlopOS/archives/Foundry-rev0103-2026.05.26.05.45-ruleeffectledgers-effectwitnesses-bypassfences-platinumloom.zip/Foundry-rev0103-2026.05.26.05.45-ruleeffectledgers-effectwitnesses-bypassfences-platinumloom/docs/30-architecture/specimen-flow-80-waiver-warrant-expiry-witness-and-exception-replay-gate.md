# Specimen flow 80 — waiver warrant, expiry witness, and exception replay gate

Goal: make bounded semantic exceptions auditable without turning them into approval, truth, or permanent success.

## Scenario

A SlopOS-facing support dashboard and an external audit notebook both consume Foundry egress residue. One preview surface is useful even though drill-through must remain sidecar-only for a short review window. Another export is blocked because it would drop classification pins. A team asks to “just waive it for now.”

The hard case is not that a waiver exists. The hard case is that a waiver starts as a narrow exception and slowly becomes a default path:

- the original refusal receipt is no longer linked;
- the expiry is a calendar reminder rather than machine-readable residue;
- the reviewer and owner collapse into the same actor;
- the scope widens from one consumer/cut/surface to all dashboards;
- a non-waivable loss such as classification-pin loss is accepted by convenience; or
- the next revision reuses the waiver without replaying the refusal and regression rules.

## Small seam to prove

### 1) waiver warrant

A waiver warrant is a compact artifact that says who accepted which bounded semantic limitation, for which consumer/surface/cut/rule set, and until when.

```yaml
waiver_warrant:
  warrant_family: foundry_semantic_waiver_warrant_v0
  warrant_id: waiver_preview_sidecar_only_drillthrough_001
  status: active
  issued_at: 2026-05-22T17:20:00Z
  expires_at: 2026-06-05T17:20:00Z
  owner: foundry_export_operator
  reviewer: foundry_semantic_reviewer
  linked_refusal_receipts:
    - receipt_csv_without_full_sidecar_001
  scope:
    revision: rev0086
    consumer_id: external_audit_notebook_preview
    surface_kind: dashboard_tile
    cut_ids:
      - cut_weekly_support_2026w20
    rule_ids:
      - R-EGRESS-002-SIDECAR-OR-REFUSAL
  allowed_semantic_loss:
    - drill_through_sidecar_only
  non_waivable_residue:
    - classification_pins
    - source_cut
    - suppression_witnesses
```

A waiver warrant is not a policy decision or trust verdict. It is a bounded exception to a named refusal or regression alarm.

### 2) expiry witness

An expiry witness is machine-readable evidence that a waiver has a usable review window and cannot silently survive past it.

```yaml
expiry_witness:
  witness_id: exp_preview_sidecar_only_001
  warrant_id: waiver_preview_sidecar_only_drillthrough_001
  evaluated_at: 2026-05-22T17:30:00Z
  expiry_state: valid
  renewal_requires_new_review: true
```

Expiry is not a calendar note. It is part of the egress/revision semantics.

### 3) exception replay gate

An exception replay gate says which checks must rerun before a waived surface is used, renewed, or carried into a new revision.

```yaml
exception_replay_gate:
  gate_family: foundry_exception_replay_gate_v0
  gate_id: gate_preview_sidecar_only_001
  warrant_id: waiver_preview_sidecar_only_drillthrough_001
  required_on:
    - before_use
    - before_renewal
    - after_revision_change
  must_recheck_rules:
    - R-EGRESS-002-SIDECAR-OR-REFUSAL
    - R-REGRESS-003-REGRESSION-LOCK
    - R-WAIVER-004-NON-WAIVABLE
```

Replay prevents a waiver from bypassing the sidecar, refusal, and regression gates it depends on.

## What this specimen proves

- A waiver is not success.
- Expiry is semantic residue, not an external reminder.
- Scope is part of the exception; changing consumer, cut, surface, rule id, or revision is a new request.
- Owner and reviewer separation matters even for fixture-local exceptions.
- Non-waivable residue stays non-waivable.
- Renewal requires replay, not a copied old warrant.
- Waivers must remain linked to the refusal receipt or regression lock they bound.

## What this specimen must keep separate

- waiver warrant versus approval verdict;
- expiry witness versus schedule/reminder system;
- exception replay gate versus policy engine;
- reviewer versus owner;
- allowed semantic loss versus non-waivable residue;
- scoped preview versus default egress success;
- sibling-cube consequence versus Foundry's projection-honesty evidence.

## Promotion gate for these nouns

Do not widen semantic waivers beyond fixture-local exception checks until:

- a second real consumer needs the same waiver fields outside the toy fixture;
- at least one expired waiver blocks a real egress attempt;
- one renewal fixture proves replay occurred under a new revision;
- one sibling cube consumes a waiver id without treating it as a verdict; and
- generated tamper cases cover owner/reviewer collapse, expiry extension, scope widening, and non-waivable-residue loss.

## Why this matters

Every strong refusal system eventually faces “only this once.” Foundry needs that exception to be smaller than truth, smaller than approval, smaller than success, and too explicit to become folklore.
