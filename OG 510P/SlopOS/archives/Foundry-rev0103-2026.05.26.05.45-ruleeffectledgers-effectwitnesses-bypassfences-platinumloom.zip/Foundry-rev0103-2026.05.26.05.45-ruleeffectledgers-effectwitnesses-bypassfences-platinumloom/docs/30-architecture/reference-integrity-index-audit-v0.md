# Reference integrity index audit v0

## Why this exists

By rev0103, Foundry's executable specimens form a chain of local ids: traces, witnesses, fences, ledgers, packets, receipts, gates, surfaces, and rule refs. A passing checker can still become misleading if a fixture silently renames a source id and a downstream fixture keeps the old reference in prose.

## What the index checks

`fixtures/reference-integrity-index/index.json` records source fixture, collection, id field, listed ids, referencing fixture, and referencing collection. `tools/check_foundry_reference_integrity_index.py` verifies subset/exact expectations and rejects duplicate, dangling, ghost, or unused references.

## What it refuses

The index is not a catalog, CMDB, lineage graph, ontology, test-management system, audit product, or proof that the referenced evidence is correct. It only catches one structural class of cube drift: ids that no longer point at what the specimen claims they point at.
