# Specimen flow 03 — capability-routed foreign service with generation witness

This specimen exists to keep Foundry from pretending that cross-ground service use is “just networking”.

## Scenario
A live instance on foreign ground needs access to a service exposed from another ground or domain. The route is explicit and policy-shaped. Later the foreign instance is resumed from snapshot and must decide what parts of the service relation survive.

## Desired separations
- **artifact basis** — what was shipped
- **declared contract world** — which interfaces and rights the workload expects
- **service route object** — the explicit cross-ground service route and rights
- **live realization** — the current running instance
- **generation witness** — a signal that continuity changed
- **reacquire rail** — the path for refreshing ephemeral relations after restore

## Flow sketch
1. A workload is launched on foreign ground with a declared contract world.
2. A service route object is granted for a specific cross-ground service and rights set.
3. The workload uses the service through that explicit route.
4. The workload is snapshotted and later resumed.
5. A generation witness changes.
6. Foundry does not assume the old service relation is still good.
7. The workload follows a reacquire rail:
   - validate that the route is still authorized,
   - refresh any freshness-bound evidence,
   - reopen or renegotiate ephemeral channels if needed.

## Why this specimen matters
Without it, Foundry is at risk of regressing to the oldest compat lie of all:
“If it resumed and packets still move, then the old ground relationship must still be valid.”

## Promotion test
This specimen is promotable only if the same nouns can survive:
- qrexec-like command routing,
- capability-routed component services,
- and VM/container/component environments with different substrate details but the same explicit service-route honesty.
