# Specimen flow 44 — identity anchor, label snapshot, and axis budget

Goal: keep a future Foundry datacube honest when neighboring design-phase archives change names, move documents, regroup families, or expose useful but dangerous high-cardinality labels.

## Scenario
A future Foundry read surface wants to summarize the current SlopOS architecture corpus.
It can see:
- one boundary doc that currently lives as an intentional singleton;
- another doc that was renamed and moved under a boundary family index;
- a family count grouped by current `*-boundary-index.md` membership;
- and a set of display labels, relative paths, imported provider labels, or other human-facing strings that operators would like to search and group by.

A tempting but wrong move is to treat the current title, current path, or current family bucket as the durable identity of the row.
A second tempting mistake is to let every useful label become a datacube axis.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every rename-sensitive or groupable member carries three small semantic companions.

### 1) identity anchor
A stable anchor for the thing the row is about.
Examples:
- one exact boundary meaning pin independent of its current filename;
- one family/member identity independent of whether it is currently singleton or indexed;
- one imported field/member identity independent of current display name or order.

This is the join truth.
It should survive rename, regrouping, or path edits.

### 2) label snapshot
A time-scoped descriptive capture of the human-facing name(s) seen at one cut.
Examples:
- current title;
- current relative path;
- current family label;
- current short display string shown in one review surface.

This is **not** the join truth.
It is review and historical explanation material.
It belongs beside time posture, not inside the anchor itself.

### 3) axis budget
A small posture saying whether one label family is healthy to group on.
Examples:
- **reviewed-bounded** — safe enough for first-class grouping because values are few, curated, and semantically stable;
- **bounded-but-volatile** — groupable with caution because values are few but regrouping/rename pressure is still real;
- **display-only** — useful for reading, filtering, or drill-through, but too unstable to treat as durable cube axis;
- **unbounded/unsafe** — raw path, user-like identifier, free-form tag, or other high-cardinality label that should stay out of cube-wide grouping by default.

This keeps “helpful label” visibly smaller than “healthy dimension.”

## What this prevents
- a doc rename from looking like entity deletion plus entity creation;
- a singleton promoted into a family from looking like semantic replacement;
- current path changes from corrupting longitudinal counts;
- raw labels, URIs, or identifiers from silently exploding grouping cardinality;
- and later alias-fixup folklore from becoming the only repair mechanism.

## Why this is enough for now
Foundry does **not** yet need a universal alias graph, canonical-name registry, or full identity-resolution plane.
The conservative win is just to keep stable identity, observed label, and grouping safety visibly separate.

## Promotion gate
Do not promote `identity anchor`, `label snapshot`, or `axis budget` beyond this specimen unless they improve at least:
- one SlopOS singleton-to-family promotion or family regrouping specimen;
- one renamed/moved doc specimen where the semantic member should remain continuous;
- one Harbor or Ward specimen where current labels are explicitly smaller than durable truth;
- and one high-cardinality imported-label specimen where display utility should not become default aggregation authority.
