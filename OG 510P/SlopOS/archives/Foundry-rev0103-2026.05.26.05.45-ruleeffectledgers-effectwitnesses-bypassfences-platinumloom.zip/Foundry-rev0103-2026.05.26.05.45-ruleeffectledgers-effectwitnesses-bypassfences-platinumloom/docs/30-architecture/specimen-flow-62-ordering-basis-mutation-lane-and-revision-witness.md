# Specimen flow 62 — ordering basis, mutation lane, and revision witness

Goal: keep a future Foundry datacube honest when neighboring SlopOS surfaces look “latest-ish” even though they were ordered by different clocks, expressed through different mutation shapes, and remain revisable on different terms.

## Scenario
A future SlopOS-facing support surface wants one compact “current mutable truth” tile that mixes:
- one `portal.jobs` summary built from CH-JOBREQ request artifacts plus portal-local scheduler decisions;
- one `portal.background` grant summary built from request descriptors and later disable/revoke cleanup;
- one CH-HEALTHREC stream that is digest-bound evidence but explicitly non-authoritative;
- one CH-CAPTURE descriptor list whose rows describe issued sessions but do not themselves grant authority;
- and one imported provider table whose warehouse exposes current snapshots today, row-level change history tomorrow, and late corrections whenever upstream systems catch up.

The tempting but wrong move is to flatten all of this into rows like:
- `subject`, `status`, `updated_at`, `value`

That feels ergonomic.
It also hides three different truths:
- **which clock actually ordered the visible winner or history cut,**
- **what kind of mutable row the consumer is looking at,**
- and **how revisable the visible answer still is.**

## Small seam to prove

### 1) ordering basis
Whenever a mutable-source answer is exposed, preserve the field or clock that actually determined winner selection, ordering, or history position.
Examples:
- `event_time`
- `arrival_commit_time`
- `transaction_record_time`
- `updated_at`
- `issued_at`

The ordering basis is **not** a giant temporal ontology.
It is just enough residue to stop one timestamp column from pretending to mean the same thing everywhere.

### 2) mutation lane
Whenever a mutable-source answer is exposed, preserve what kind of row the consumer is actually seeing.
Examples:
- `current_snapshot`
- `historical_version`
- `change_event`
- `invalidate_prior`
- `delete_tombstone`
- `descriptor_not_state`

The mutation lane is **not** a universal changelog grammar.
It is just enough residue to stop snapshots, tombstones, invalidations, and non-authoritative descriptors from sounding interchangeable.

### 3) revision witness
Whenever a mutable-source answer is exposed, preserve how revisable that answer still is.
Examples:
- `subject_to_revision`
- `complete_for_cut`
- `bounded_change_window`
- `source_claims_final`

The revision witness is **not** a promise that every family offers permanent change history.
It is just enough residue to keep “current” from sounding more final than the source actually warrants.

## Example residue

```text
visible_value:
  subject: portal.jobs.request
  measure: pending_like_count
  ordering_basis: updated_at
  mutation_lane: descriptor_not_state
  revision_witness: subject_to_revision

visible_value:
  subject: portal.background.grant
  measure: grant_row_count
  ordering_basis: issued_at
  mutation_lane: historical_version
  revision_witness: complete_for_cut

visible_value:
  subject: slopos.health
  measure: failed_boot_count
  ordering_basis: record_time
  mutation_lane: historical_version
  revision_witness: source_claims_final

visible_value:
  subject: slopos.capture
  measure: active_capture_like_rows
  ordering_basis: issued_at
  mutation_lane: descriptor_not_state
  revision_witness: subject_to_revision

visible_value:
  subject: imported.provider.table
  measure: changed_row_count
  ordering_basis: arrival_commit_time
  mutation_lane: change_event
  revision_witness: bounded_change_window
```

## Why this belongs in Foundry
SlopOS is design-phase enough that many useful rows will be mutable, but not all mutable rows tell the same kind of truth.
Some are request artifacts.
Some are historical descriptors.
Some are explicit change events.
Some are current snapshots that remain subject to later correction.
This specimen gives Foundry the smallest honest way to preserve those distinctions without forcing the whole cube into a heavy CDC or bitemporal architecture.

## Anti-regrowth rules
- **event time smaller than arrival time, and vice versa**
- **snapshot smaller than mutable truth**
- **disappearance smaller than delete semantics**
- **descriptor smaller than live-state claim**
- **complete-for-cut smaller than final forever**

## What stays parked
- no universal CDC warehouse;
- no requirement that every family emit before/after rows;
- no universal delete semantics;
- no giant temporal algebra beyond the residue this specimen proves;
- no rule that one generic `updated_at` field can replace ordering basis.

## Resulting recommendation
When Foundry later absorbs mutable-source families, it should add only this narrow seam:
- **ordering basis** for which clock/field actually ordered or selected the visible row,
- **mutation lane** for what kind of mutable row is visible,
- **revision witness** for how revisable that answer still is.

That is enough to keep mutable-source datacube semantics honest while SlopOS and the neighboring archives are still evolving.
