# Specimen flow 63 — contribution basis, fanout class, and reaggregation fence

Goal: keep a future Foundry datacube honest when counts or totals are shaped by joins, bridge rows, or higher-grain summaries rather than by one native measurement row per visible answer.

## Scenario
A future support workflow wants one “artifact coverage” panel spanning design-phase SlopOS evidence and policy surfaces.
It can see:
- one `artifacts` table with one row per subject digest;
- one `signature_records` relation with one row per signature record over that subject;
- one `provenance_artifacts` relation with one row per provenance artifact attached to that subject;
- and one `family_targets` summary table whose rows live at the boundary-family or profile-category level rather than at per-doc level.

A tempting but wrong move is to flatten all of these into one generic count family:
- `signed_artifacts = 12`
- `provenance_artifacts = 19`
- `family_targets = 7`
- `coverage_total = 38`

That would be misleading.
Some rows count distinct subjects, some count association rows, and some count higher-grain target rows that should not be regrouped below their lawful level.
The numbers all “look like counts,” but they do not share one honest rollup story.

## Small seam to prove

### 1) contribution basis
Every count-like answer carries a compact witness for what got counted once.
Examples:
- `native_subject_row`
- `subject_digest_distinct`
- `signature_record_row`
- `subject_signature_association_row`
- `subject_evidence_association_row`
- `family_target_row`
- `approx_subject_sketch`

This keeps “artifact count” separate from “signature record count” and from “family target count.”

### 2) fanout class
Every such answer carries a compact witness for the relationship shape that touched it.
Examples:
- `none_native`
- `one_to_many_deduped`
- `bridge_many_to_many`
- `higher_grain_projection`
- `approx_decomposed`
- `chasm_refused`

This keeps bridge-shaped and higher-grain answers visibly smaller than native fact rows.

### 3) reaggregation fence
Every such answer carries a compact guardrail for what regrouping is lawful.
Examples:
- `native_rollup_ok`
- `same_basis_only`
- `do_not_group_below_family`
- `same_sketch_family_only`
- `forbidden`

This stops support charts and exports from summing category-level targets into child-level truth or from mixing association-row counts with subject-distinct counts.

## What this specimen proves
Foundry can preserve join/bridge honesty with three compact residues instead of inventing:
- a universal semantic join planner,
- a bridge-weighting DSL,
- or one permanent hierarchy model.

The cube only needs to say:
1. **what was counted once,**
2. **what fanout or projection shape affected the answer,**
3. and **what further regrouping is still lawful.**

## Example residue

```text
visible_value:
  subject: artifact.digest.distinct
  measure: signed_artifact_count
  value: 12
  contribution_basis: subject_digest_distinct
  fanout_class: one_to_many_deduped
  reaggregation_fence: same_basis_only

visible_value:
  subject: signer.association
  measure: signature_record_count
  value: 19
  contribution_basis: signature_record_row
  fanout_class: bridge_many_to_many
  reaggregation_fence: forbidden

visible_value:
  subject: provenance.association
  measure: artifacts_with_provenance_count
  value: 15
  contribution_basis: subject_digest_distinct
  fanout_class: bridge_many_to_many
  reaggregation_fence: same_basis_only

visible_value:
  subject: profile.family.target
  measure: required_boundary_target_count
  value: 7
  contribution_basis: family_target_row
  fanout_class: higher_grain_projection
  reaggregation_fence: do_not_group_below_family

visible_value:
  subject: artifact.sketch
  measure: approx_unique_artifact_count
  value: 12.4
  contribution_basis: approx_subject_sketch
  fanout_class: approx_decomposed
  reaggregation_fence: same_sketch_family_only
```

## Why this belongs in Foundry
SlopOS already puts pressure on multi-signature evidence, multi-artifact evidence sets, family-level maps, and profile-level matrices without yet promising one fixed reporting hierarchy.
This specimen gives Foundry the smallest honest way to preserve that fact when future dashboards, exports, and derived summaries start mixing distinct-subject counts, bridge-association counts, and higher-grain management targets.

## What stays parked
- no universal join planner;
- no mandatory bridge table family in the cube;
- no one-size-fits-all hierarchy registry;
- no claim that association-row counts are interchangeable with subject-distinct counts;
- no promise that higher-grain target rows can always be apportioned downward honestly.
