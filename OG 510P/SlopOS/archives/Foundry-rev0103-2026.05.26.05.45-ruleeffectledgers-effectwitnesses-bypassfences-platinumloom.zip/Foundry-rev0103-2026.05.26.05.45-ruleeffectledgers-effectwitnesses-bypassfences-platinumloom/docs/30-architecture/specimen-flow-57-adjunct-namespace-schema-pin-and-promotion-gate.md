# Specimen flow 57 — adjunct namespace, schema pin, and promotion gate

Goal: keep a future Foundry datacube honest when SlopOS and neighboring support surfaces need provisional metadata before the stable core ontology is deserved.

## Scenario
A future SlopOS-neighbor support surface wants one “burden by subject” panel for imported provider spend, worker-pool support burden, and current payer/quota posture.
During design, four genuinely useful metadata ideas appear:
- one provider-import completeness field for whether the source month is partial or final;
- one allocation methodology code for how blended/shared provider spend was assigned;
- one column-level drill-through hint for which upstream fields shaped the visible total;
- and one acceleration hint describing which pre-aggregated rollup currently powers the panel.

A tempting but wrong move is to add all four as permanent top-level cube fields immediately.
That would be misleading.
Some are design-phase support hints, some are runtime observations, some are local lineage clues, and some are physical acceleration residue.
They are useful, but they do not yet deserve to impersonate universal cube law.

## Small seam to prove

### 1) adjunct namespace
Every provisional metadata family carries a compact owner lane such as:
- `support.finops.v1`
- `import.provider.aws_cur.v0`
- `lineage.columns.v0`
- `accel.rollup_hint.v0`

This keeps local experiments from pretending to be archive-wide semantics.

### 2) schema pin
Every such adjunct carries an immutable meaning pointer such as:
- `git:schemas/support.finops.v1@9c31d2a`
- `sha256:1ab4…`
- `https://example.invalid/schema/provider-import/v0.2.1.json`
- `docs/30-architecture/provider-import-adjunct-v0.md#rev0061`

This keeps later label or vendor-shape drift from silently rewriting old rows.

### 3) promotion gate
Every such adjunct carries a compact posture for where it stands:
- `local_experiment`
- `cross_surface_candidate`
- `promoted`
- `rejected`
- `superseded`

This stops proposal, adoption, and retirement from collapsing into one flattering “supported” story.

## What this specimen proves
Foundry can carry brilliant design-phase ideas without freezing them as universal ontology.
The cube only needs to say:
1. **which adjunct namespace owns the idea**,
2. **which exact schema pin defines the meaning**,
3. and **which promotion gate posture it currently occupies**.

## Example residue

```text
visible_value:
  subject: capsule.alpha
  measure: provider_burden_cost
  value: 12.30
  unit: usd
  adjunct_namespace: import.provider.aws_cur.v0
  schema_pin: git:schemas/provider-import-v0@9c31d2a
  promotion_gate: cross_surface_candidate

visible_value:
  subject: capsule.alpha
  measure: provider_burden_cost
  adjunct_namespace: support.finops.v1
  schema_pin: sha256:4e73…
  promotion_gate: local_experiment
  adjunct_payload:
    allocation_methodology: blended_reserved_capacity_share
    source_completeness: partial_month

visible_value:
  subject: capsule.alpha
  measure: provider_burden_cost
  adjunct_namespace: lineage.columns.v0
  schema_pin: git:schemas/lineage-columns-v0@1bc8f77
  promotion_gate: local_experiment
  adjunct_payload:
    upstream_columns:
      - cur.line_item_unblended_cost
      - cur.savings_plan_effective_cost
      - mapping.workload_key

visible_value:
  subject: capsule.alpha
  measure: provider_burden_cost
  adjunct_namespace: accel.rollup_hint.v0
  schema_pin: docs/30-architecture/accel-rollup-hint-v0.md#rev0061
  promotion_gate: rejected
  adjunct_payload:
    rollup_name: monthly_subject_rollup_v3
    note: physical acceleration is not durable semantic identity
```

## Why this belongs in Foundry
SlopOS is still design-phase enough that promising metadata ideas will appear before stable core nouns do.
This specimen gives Foundry the smallest honest way to preserve those ideas, compare them, and retire them without either losing them or prematurely canonizing them.

## What stays parked
- no giant semantic-layer taxonomy;
- no universal lineage graph;
- no mandatory global adjunct registry;
- no promise that every export/support/import hint becomes core cube law;
- no claim that physical rollup or partition choices are semantic identity.
