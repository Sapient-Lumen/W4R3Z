# Specimen flow 53 — sample class, inclusion basis, and expansion fence

Goal: keep a future Foundry datacube honest when a visible value or list comes from a sample, preview, or convenience subset rather than the full eligible population.

## Scenario
A future SlopOS-neighbor support shell wants to show an “estimated affected subjects” card and a “recent examples” list for one incident family.
The shell combines three upstream cuts:
- a deterministic hash-based sample over a very large event stream so the support view stays cheap enough to refresh often;
- a warehouse-side block sample over historical artifact rows for quick directional estimates;
- and a first-200 preview list from a capability-scoped ATTRFS snapshot so an operator can inspect concrete examples.

The temptation is to flatten all three into one cheerful current summary:
- `affected_subjects = 12400`
- `recent_examples = [...]`
- `top_family = connector-timeout`

That would be misleading.
Those numbers and examples do not all come from the same population story, and only some of them may support lawful expansion back toward a wider denominator.

## Small seam to prove

### 1) sample class
Every sampled or preview-shaped value carries a compact class such as:
- `census`
- `deterministic_sample`
- `probability_sample`
- `block_sample`
- `bounded_preview`
- `manual_subset`
- `other_partial_cut`

This keeps “partial but useful” visibly smaller than “full population truth”.

### 2) inclusion basis
Every sampled or preview-shaped value carries a compact account of how rows entered:
- `hash_key`
- `probability_threshold`
- `block_pick`
- `first_n_cap`
- `manual_review`
- `provider_local_sampling`
- `other_explicit_basis`

This keeps the admission recipe visible without requiring a giant planner model.

### 3) expansion fence
Every sampled or preview-shaped value carries a compact guardrail for downstream use:
- `no_expansion`
- `factor_known`
- `probability_known_estimate`
- `biased_or_unknown`
- `preview_only`

This stops preview cards, block samples, and convenience subsets from silently turning into denominator truth.

## What this specimen proves
Foundry can preserve sample honesty with three compact residues instead of inventing:
- a universal statistics plane,
- a global weighting algebra,
- or a representativeness theorem for every partial cut.

The cube only needs to say:
1. **what class of sample** this output is,
2. **how rows got in**,
3. and **what expansion claims are forbidden or allowed**.

## Example residue

```text
visible_value:
  subject: incident-family.connector-timeout
  measure: affected_subjects
  value: 12400
  sample_class: block_sample
  inclusion_basis: block_pick
  expansion_fence: biased_or_unknown

visible_examples:
  subject: incident-family.connector-timeout
  list_kind: recent_examples
  sample_class: bounded_preview
  inclusion_basis: first_n_cap
  expansion_fence: preview_only
```

## Why this belongs in Foundry
SlopOS already treats preview metadata, nested imported sampling, and snapshot-scoped queries as smaller than durable ambient truth.
This specimen gives Foundry the smallest honest way to preserve that fact when future dashboards, exports, or support summaries start mixing census rows, preview slices, and sampled estimates.

## What stays parked
- no universal weighting DSL;
- no automatic expansion from previews;
- no guarantee that every deterministic sample is population-representative;
- no global comparability promise across provider-local sampling stacks.
