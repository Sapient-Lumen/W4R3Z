# Foreign cells and compat membranes

A foreign cell is useful precisely because it is not native.

Foundry therefore treats compatibility as a **membrane**, not as a promotion path to first-class meaning.

Good membrane questions include:
- what is genuinely promised by the foreign cell,
- what remains host-local or substrate-local trivia,
- what can be safely re-exported to sibling cubes,
- and what must be marked as degraded, translated, or non-native.

The cube should resist the temptation to adopt POSIX, container, hypervisor, or cloud folklore simply because those surfaces are familiar.
Compatibility can be a helpful servant while still being a bad sovereign.
