# Specimen flow 88 — obligation ledger, acknowledgment witness, and drift fence

Goal: make post-exposure semantic obligations explicit without turning Foundry into a legal-compliance system, rights-expression language, authorization engine, privacy-policy engine, consent registry, public-release workflow, deletion system, audit product, custody model, or sibling-cube verdict.

## Scenario

Specimen 87 proved that Foundry can account for who can reach a semantic surface and for which purpose. A new failure remains: the surface can be exposed to the right audience and still lose the obligations that made the surface meaningful. Sidecars can be detached, classification pins can be suppressed, observation-status warnings can be hidden, recall routes can be omitted, no-reexport boundaries can be downgraded, and sibling-cube non-promises can be quietly converted into local authority.

A SlopOS support dashboard, external-audit CSV, Ward preview tile, ViewFS projection, delegated-worker cache, shadow export, and public link all have exposure evidence. Foundry must now record what obligations travel with each carrier and whether each consumer acknowledged, refused, quarantined, partially accepted, or missed those obligations. It must block obligation drift without pretending to grant permission, prove legal compliance, manage consent, approve release, delete data, certify audit, or issue sibling-cube verdicts.

## Nouns under test

- **Obligation ledger** — a scoped list of semantic obligations that must travel with a carrier, surface, audience, purpose, and source exposure evidence.
- **Acknowledgment witness** — consumer-local evidence that a named surface/audience/consumer accepted, partially accepted, refused, quarantined, or failed to acknowledge required obligations.
- **Obligation-drift fence** — a block around dropped, downgraded, expired, widened, missing, self-approved, public-link, inherited, wrong-consumer, or authority-laundered obligations until replay and clearance evidence exists.

## Fixture requirements

The specimen 88 fixture must include:

- complete, partial, and blocked obligation ledgers;
- source exposure-ledger, audience-witness, and purpose-fence references from specimen 87 pressure;
- obligations for sidecar preservation, classification pins, observation-status display, recall route, no reexport, sibling-boundary preservation, quarantine, and recheck-before-execute;
- acknowledgment witnesses for acknowledged, partial, quarantined, refused, and missing states;
- obligation-drift fences for no-reexport downgrade, inherited obligation rebinding, public-link drift, missing worker acknowledgment, and Ward verdict laundering;
- non-promises that refuse authorization, legal compliance, consent, rights management, public release, deletion, audit opinion, custody, SlopOS proof, and sibling-cube verdicts; and
- negative cases for missing obligation ledgers, missing source exposure, missing obligation pins, missing acknowledgments, dropped sidecar/classification/recall obligations, no-reexport downgrade, wrong-consumer acknowledgments, partial-as-full, expired obligations without recheck, public/inherited obligations without fences, obligation-as-authorization, obligation-as-legal-compliance, obligation-as-consent, digest mismatch, waiver-without-replay, and sibling-verdict laundering.

## Rules

See [`obligation-accounting-rulebook-v0.md`](obligation-accounting-rulebook-v0.md).

## Non-goals

- no rights-expression or ODRL policy execution;
- no XACML/ABAC/IAM authorization decision;
- no privacy-law or DPV compliance framework;
- no consent, public-release, deletion, or retention workflow;
- no audit opinion or certification;
- no Ward verdict;
- no ViewFS custody claim;
- no Harbor remediation or external-status authority;
- no SlopOS proof claim; and
- no global obligation registry.

## Promotion status

Fixture-local. The nouns are useful only while they prevent exposed semantic carriers from silently shedding required residue. Promotion requires generated obligation tamper cases plus at least one second non-SlopOS duty-carrying consumer with no-reexport, recall, public-link, inherited-access, or sibling-boundary pressure.
