# Egress conformance rulebook v0

This rulebook is intentionally tiny. It exists so refusal receipts can cite stable rule ids before Foundry has any reason to grow a larger error or policy vocabulary.

| Rule id | Gate | Refusal when |
| --- | --- | --- |
| `R-EGRESS-001-SIDECAR-OR-INBAND` | sidecar or in-band residue | a thin egress surface would leave without residue or a digest-linked sidecar |
| `R-EGRESS-002-NAMED-SEMANTIC-LOSS` | named loss | a refusal cannot say which residue would be lost |
| `R-EGRESS-003-REPAIR-ESCAPE` | repair escape | a refusal does not name safe alternative request shapes |
| `R-EGRESS-004-CLASSIFICATION-PINS` | classification pin preservation | category labels or bare codes would leave without pins/crosswalk fences |
| `R-EGRESS-005-CUT-MISMATCH` | cut compatibility | cached, materialized, reconciled, or balanced output is reused across incompatible cuts |
| `R-EGRESS-006-STATUS-PRESERVATION` | status preservation | observedness, adjustment, suppression, provisionality, or revision status would be dropped |

## Non-goals

- not an authorization policy;
- not a privacy engine;
- not an API error taxonomy;
- not a BI semantic layer;
- not a universal validation DSL;
- not a sibling-cube verdict.

## Standing rule

A rule id is only useful if it appears in a receipt that names the attempted surface, semantic loss, and safe escape path.
