# Specimen flow 48 — view lens, disclosure class, and comparability fence

Goal: keep a future Foundry datacube honest when neighboring archives expose useful values through different views, export tiers, masking rules, or release thresholds.

## Scenario
A future Foundry read surface wants to summarize incident posture across one SlopOS deployment.
It can see:
- one ATTRFS smart-folder count through a user-visible shell view;
- one operator-only ATTRFS count through a broader diagnostic view;
- one sanitized CH-SNAPSHOT-derived support summary;
- one full internal incident summary;
- and one aggregate released only when a minimum-group rule is satisfied.

A tempting but wrong move is to publish these as the same metric with a loose `audience` tag.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every visibility-shaped value carries three small semantic companions.

### 1) view lens
A compact witness for the explicit visibility or export lens that shaped the value.
Examples:
- a view digest or handle binding for one ATTRFS query;
- an observation-export policy digest;
- a support-bundle redaction profile digest;
- a role/profile name pinned only as local descriptive residue when no better stable digest exists.

The view lens is **not** a universal authorization model.
It is just enough residue to stop “seen here” from impersonating “true everywhere.”

### 2) disclosure class
A compact witness for what kind of payload became visible after the lens was applied.
Examples:
- **public** — safe to expose broadly under current rules;
- **sanitized** — explicit redaction/minimization already applied;
- **masked** — field values were transformed or obscured rather than fully revealed;
- **threshold-gated** — value is releasable only because a minimum-group or similar release rule was satisfied;
- **sensitive-visible** — visible only on a narrower internal/operator path.

This keeps “value exists” visibly smaller than “all audiences see the same payload.”

### 3) comparability fence
A compact witness for whether cross-lens comparison or arithmetic is semantically safe.
Examples:
- **same-lens-only** — compare only with values produced under the same view lens and disclosure class;
- **threshold-gated** — comparison is only healthy where the same release threshold and entity rules are in force;
- **monotone-only** — one lens is known to be narrower or more redacted, so only ordering/subset-style claims are safe, not equality or ratios;
- **non-comparable** — no honest arithmetic relation is promised across lenses.

This keeps “two numbers exist” visibly smaller than “two numbers belong in the same denominator story.”

## Why this seam is small enough now
It does **not** require:
- a universal RBAC or entitlement plane;
- a global audience registry;
- a privacy-budget engine;
- or a cross-lens query rewriter.

It only says that once visibility or release policy shapes a value, Foundry should preserve:
1. which lens did the shaping,
2. what disclosure class survived,
3. and how far comparison may honestly go.

## SlopOS mapping
- **ATTRFS count over a shell view**
  - view lens: explicit view/query binding digest or handle
  - disclosure class: usually `public` or `sanitized`
  - comparability fence: `same-lens-only`

- **ATTRFS/operator diagnostic count over a broader view**
  - view lens: different diagnostic/operator view binding
  - disclosure class: often `sensitive-visible`
  - comparability fence: `monotone-only` or `non-comparable` relative to the user-view count unless containment is proven

- **CH-SNAPSHOT sanitized support summary**
  - view lens: CH-OBSPOL / redaction-profile digest
  - disclosure class: `sanitized`
  - comparability fence: `same-lens-only` or `monotone-only` relative to a fuller internal summary

- **minimum-group released aggregate**
  - view lens: release-policy digest or local rule witness
  - disclosure class: `threshold-gated`
  - comparability fence: `threshold-gated`

## Anti-regrowth rules
- **visible smaller than universal**
- **masked smaller than unmasked**
- **threshold-cleared smaller than source-complete**
- **same-number smaller than same-truth**

## Non-goals parked on purpose
- no promise that every family shares one audience taxonomy;
- no promise that cross-lens conversion is always possible;
- no requirement for one global policy graph;
- no built-in privacy product.

## Resulting recommendation
When Foundry later accepts policy-shaped or audience-shaped values, it should add only this narrow seam:
- **view lens** for which explicit visibility/export path shaped the value,
- **disclosure class** for what survived that path,
- **comparability fence** for whether cross-lens arithmetic is honest.

That is enough to keep early datacube visibility and release semantics honest while SlopOS and the neighboring archives are still evolving.
