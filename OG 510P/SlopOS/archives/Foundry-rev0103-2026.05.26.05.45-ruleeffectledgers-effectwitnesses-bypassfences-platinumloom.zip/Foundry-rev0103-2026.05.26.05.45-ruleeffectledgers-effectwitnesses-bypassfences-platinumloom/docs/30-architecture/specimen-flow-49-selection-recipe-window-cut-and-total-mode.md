# Specimen flow 49 — selection recipe, window cut, and total mode

Goal: keep a future Foundry datacube honest when useful values arrive from search-like, query-like, or paginated result surfaces instead of from stable whole-population facts.

## Scenario
A future Foundry read surface wants to summarize "matching incidents" and "matching artifacts" across one SlopOS deployment.
It can see:
- one ATTRFS smart-query result page over an explicit shell view;
- one second page or cursor continuation for the same query later;
- one provider-local MCP completion result with bounded `values`, optional `total`, and `hasMore`;
- one dashboard tile that shows "2,400 matches" without saying whether the number is exact or estimated;
- and one exported support summary that contains only the first `N` matching handles.

A tempting but wrong move is to publish these as one family with fields like `query`, `count`, and `results`.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every query-shaped value carries three small semantic companions.

### 1) selection recipe
A compact witness for how rows became eligible and how they were ordered.
Examples:
- CH-ATTRQ digest plus schema digest;
- explicit view binding or view-lens residue;
- sort/ranking mode when the returned order matters;
- query-template digest plus concrete bound arguments.

The selection recipe is **not** a universal search algebra.
It is just enough residue to stop “these were the results I saw” from impersonating “this is the stable population.”

### 2) window cut
A compact witness for which slice of the eligible set the current rows represent.
Examples:
- offset + limit;
- cursor/startCursor/endCursor + hasNext-like residue;
- first-page-only or truncated-at-N posture;
- search-after / PIT residue;
- continuation token or shell-owned page handle.

The window cut is **not** a browse/watch product.
It is just enough residue to stop one page from pretending to be the whole query.

### 3) total mode
A compact witness for what any total-like number actually means.
Examples:
- **exact** — full eligible set counted at the relevant cut;
- **lower-bound** — result says "at least this many";
- **estimated** — approximate total only;
- **page-local** — count describes the returned slice, not the whole eligible set;
- **unknown** — no healthy total claim is attached.

This keeps “a number near the page” visibly smaller than “whole-population truth.”

## Why this seam is small enough now
It does **not** require:
- a universal query language;
- a global ranking score model;
- one pagination abstraction for every backend;
- or a durable browse/watch/export product.

It only says that once results are query-shaped, Foundry should preserve:
1. what selected them,
2. how the current window was cut,
3. and what the attached total means.

## SlopOS mapping
- **ATTRFS smart query over one view**
  - selection recipe: CH-ATTRQ digest + view binding + schema digest when present
  - window cut: first page, explicit offset/limit, or shell-owned continuation residue
  - total mode: usually `unknown` or `page-local` unless the shell explicitly computed a whole-query count

- **later ATTRFS continuation / resumed page**
  - selection recipe: same query digest, same view binding, same ordering residue
  - window cut: new cursor/offset/token for the next slice
  - total mode: still whatever the system can honestly claim; continuation does not magically make the total exact

- **MCP completion bounded suggestions**
  - selection recipe: provider-local completion request shape (`ref`, argument name, partial value, context arguments)
  - window cut: bounded returned suggestion set plus `hasMore`-style residue
  - total mode: often `page-local`, `lower-bound`, or `unknown`, never silently durable inventory truth

- **dashboard tile with “matches”**
  - selection recipe: query digest or report-definition digest
  - window cut: often `first-page-only` or `not-applicable` if only a count was materialized
  - total mode: must say `exact`, `estimated`, `lower-bound`, or `unknown`

## Anti-regrowth rules
- **page smaller than population**
- **cursor smaller than stability guarantee**
- **estimated smaller than exact**
- **selection recipe smaller than universal query language**

## Non-goals parked on purpose
- no universal search or ranking product;
- no obligation to make every result cursor-resumable forever;
- no promise that every backend can expose the same total semantics;
- no requirement that all query-shaped values share one global pagination UI.

## Resulting recommendation
When Foundry later accepts query-shaped or search-shaped values, it should add only this narrow seam:
- **selection recipe** for how eligibility and ordering were formed,
- **window cut** for which slice of the eligible set is currently visible,
- **total mode** for what any nearby total-like number actually claims.

That is enough to keep early datacube query semantics honest while SlopOS and the neighboring archives are still evolving.
