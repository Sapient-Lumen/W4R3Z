# Specimen flow 36 — assurance class, recency fence, and intent latch

Goal: keep current validity separate from action-specific assurance strength, recentness, and present user intent.

## Scenario
A foreign-backed realization already has a session, token, or other live-validity witness that is good enough for routine reads.
A user now attempts a higher-risk action: reveal a secret, change a payment target, widen delegation, approve a policy jump, or export a durable bearer artifact.
The tempting mistake is to read the still-live session as if it also proved that this action is strong enough, recent enough, and intentionally confirmed enough.

There are three truths that many systems flatten when they only say “authenticated” or “logged in”.

First, there is an **assurance class**.
One verifier or resource may require a certain context-local authentication class, factor mix, or phishing-resistance posture for this exact action.
That keeps “current session exists” distinct from “the authentication event met this action's strength bar”.

Second, there is a **recency fence**.
Even if the earlier authentication event was strong enough in kind, it may be too old in time for this action.
That keeps “still authenticated” distinct from “fresh enough right now”.

Third, there is an **intent latch**.
One action may require present claimant intervention such as a button press, user-presence test, local user verification, or equivalent explicit reauthentication gesture before effect.
That keeps “session continuity” distinct from “the user intentionally authorized this sensitive effect now”.

This preserves three truths:
- class or strength sufficient for one decision context,
- freshness of the qualifying authentication event,
- and present user-intendedness before effect.

## Proposed Foundry objects
1. **assurance class**
   - context-local statement of the required or satisfied authentication-strength class for one decision;
   - keeps session validity separate from the action's strength bar and avoids inventing a fake universal ladder.

2. **recency fence**
   - explicit bound on how old the qualifying authentication event may be before reauthentication or step-up is required;
   - keeps ordinary session continuity separate from sensitive-action freshness.

3. **intent latch**
   - explicit demand for present claimant intervention before one sensitive effect crosses;
   - keeps user presence or verification separate from older login/session continuity.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a session remains valid for routine work but not for one sensitive effect;
- a resource's local ACR or assurance requirements are sharper than generic account/login truth;
- an older successful login is still too stale for present approval;
- and presence, user verification, or explicit step-up intent must be shown now without pretending the prior session never existed.

## Adjacent but parked
- **step-up card** — future compact residue for “valid session, but this action still needs stronger or fresher auth”.
- **method braid** — future compact residue for keeping method mix (`amr`) separate from class (`acr`) without importing a generic auth-method registry.

## Promotion rule
Do not promote `assurance class`, `recency fence`, or `intent latch` unless they improve:
- one SlopOS companion specimen where current valid session truth is explicitly smaller than action-specific assurance or recent-login truth;
- one outside-system specimen where stronger or fresher auth is requested without declaring the whole session dead;
- and one outside-system specimen where present user intent or user verification remains separate from mere session continuity.
