# Specimen flow 86 — surface inventory sweep, reachability witness, and coverage-gap fence

Goal: make post-distribution discovery explicit without turning Foundry into a catalog, CMDB, crawler, object-store inventory, lineage graph, SBOM, cache-control system, scheduler, cleanup system, or sibling-cube authority.

## Scenario

Specimen 85 made post-readmission circulation explicit: a carrier is distributed to named targets, targets emit adoption/refusal/quarantine receipts, and stale copies are fenced. A new failure remains: target lists are often incomplete. Old CSVs, dashboard object paths, notebook extracts, projected tiles, and delegated-worker local caches can remain reachable even if no distribution manifest named them.

A SlopOS support workspace seeds a sweep with the rev0091 distribution manifests. The sweep sees an external-audit extract, a dashboard tile, an old retired CSV path, a Ward preview tile, a ViewFS projection, and a delegated-worker local cache that refuses listing. It also finds a shadow CSV alias that carries a familiar digest but lacks adoption evidence.

Foundry must not conclude that the ecosystem is clean merely because the known targets were receipted. It must leave reachability witnesses for observed surfaces and coverage-gap fences for missing, ambiguous, inaccessible, duplicate, or unlinked copies.

## Nouns under test

- **Surface inventory sweep** — a scoped attempt to enumerate expected and discovered relying surfaces for one or more distribution manifests and carrier digests.
- **Reachability witness** — evidence that one surface, artifact, path, alias, or copy was observed, with digest/residue/path posture and local limits.
- **Coverage-gap fence** — a block around an expected-but-unobserved, unexpected, ambiguous, permission-denied, duplicate, expired, or owner-mismatched surface until clearance evidence exists.

## Fixture requirements

The specimen 86 fixture must include:

- complete, partial, and blocked surface inventory sweeps;
- seed distribution manifests and carrier references;
- expected surface ids, discovery sources, inventory scope, method limits, and sweep windows;
- reachability witnesses for reachable, quarantined, retired-as-history, and unknown/permission-limited surfaces;
- alternate identifier evidence that maps object paths or logical names to canonical surface ids;
- coverage-gap fences for stale/unknown/permission-denied/ambiguous/duplicate surfaces;
- negative cases for missing sweep, missing seed manifest, missing witness, unaccounted expected surface, unknown surface without fence, unresolved alias, expired sweep window, partial-as-complete, owner mismatch, digest mismatch, discovery-as-adoption, inventory-as-catalog, inventory-as-truth, permission-denied without recheck, and duplicate accounting.

## Rules

See [`surface-inventory-rulebook-v0.md`](surface-inventory-rulebook-v0.md).

## Non-goals

- no global catalog;
- no CMDB or asset-management program;
- no object-store crawler or listing protocol;
- no cache purge, deletion, or retention guarantee;
- no lineage platform or SBOM graph;
- no Kubernetes-style cleanup controller;
- no ViewFS custody claim;
- no Ward verdict;
- no Harbor remediation status; and
- no SlopOS proof claim.

## Promotion status

Fixture-local. The nouns are useful only while they prevent stale/unknown reachable semantic carriers from hiding behind distribution success. Promotion requires generated inventory tamper cases plus at least one second non-SlopOS consumer with alias-rich surfaces.
