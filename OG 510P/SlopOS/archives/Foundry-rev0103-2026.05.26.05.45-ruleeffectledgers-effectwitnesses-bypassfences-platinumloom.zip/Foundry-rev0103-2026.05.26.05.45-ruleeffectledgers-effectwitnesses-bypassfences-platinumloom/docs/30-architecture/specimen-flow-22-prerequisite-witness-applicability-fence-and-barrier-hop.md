# Specimen flow 22 — prerequisite witness, applicability fence, and barrier hop

Goal: keep “this exact target is offered and locally admissible” separate from “there is a valid direct path from this exact current state to that target”.

## Scenario
A service offers one exact target basis pin to a subject.
Locally, there is no hold and an admission window is open.
Even so, the direct transition may still be invalid.
The target may require a particular hardware or platform compatibility string, a minimum floor, an exact current checksum for a delta payload, or an intermediate migration/key-rotation release.

The subject therefore surfaces a **prerequisite witness**: a compact statement of the exact current fact that matters for direct-path validity.
That might be a current basis digest, a current payload checksum, a state epoch, a config generation digest, or a similar sharper-than-version residue.
An **applicability fence** checks the target’s requirements against that witness.
If the fence passes, the direct edge is real.
If the fence fails but a reviewed intermediate exists, the subject takes a **barrier hop** first and only later proceeds to the final target.
This keeps “offered” smaller than “admissible”, and both smaller than “directly applicable now”.

## Proposed Foundry objects
1. **prerequisite witness**
   - compact exact-current-state fact relevant to whether one direct transition is valid;
   - often sharper than a human-facing version string.

2. **applicability fence**
   - explicit dependency, compatibility, or minimum-floor check that must pass before a direct edge counts as real;
   - may compare provides/depends fields, compatibility strings, minimum versions, state epochs, or similar prerequisites.

3. **barrier hop**
   - explicit required intermediate transition when a later target is not directly valid from the current state;
   - keeps path truth visible instead of promising a false direct edge.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- delta updates depend on the exact current payload or basis,
- minimum platform or system-version floors exclude some subjects,
- key or schema migrations require one intermediate release,
- and rollback stops being the simple inverse of forward applicability.

## Adjacent but parked
- **delta fingerprint card** — compact exact-current-state label sharper than a version string.
- **incompatibility chip** — compact explanation of why a direct path is invalid right now.

## Promotion rule
Do not promote `prerequisite witness`, `applicability fence`, or `barrier hop` unless they improve:
- one delta/checksum-sensitive specimen,
- one compatibility or minimum-version specimen,
- and one barrier-release or required-intermediate specimen.
