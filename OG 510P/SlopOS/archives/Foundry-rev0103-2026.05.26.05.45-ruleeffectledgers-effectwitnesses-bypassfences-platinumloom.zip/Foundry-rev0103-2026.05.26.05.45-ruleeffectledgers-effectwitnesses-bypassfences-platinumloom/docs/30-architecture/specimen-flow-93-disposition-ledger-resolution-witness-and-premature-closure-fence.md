# Specimen flow 93 — disposition ledger, resolution witness, and premature-closure fence

Goal: make post-escalation disposition falsifiable without turning Foundry into incident management, ticket workflow, ownership assignment, risk acceptance, remediation authority, audit, authorization, lifecycle finality, public-release approval, legal compliance, or sibling verdict infrastructure.

## Scenario

Specimen 92 records escalation packets, routing witnesses, and unresolved-signal fences. That proves risky drift was routed or fenced, but a second failure remains: a receiver can mark the routed packet resolved without proving which semantic disposition was chosen, what residue survived, which source fences remain open, which consumer-local scope was reviewed, and which closure claims are still forbidden.

A SlopOS operator console, Ward preview queue, ViewFS projection service, public-link scanner, delegated worker, Harbor crossing queue, dashboard cache, and external-audit notebook now need a bounded post-route disposition surface. Foundry must record whether a routed semantic signal was accepted for remediation, deferred, transferred, rejected as duplicate or false positive, quarantined, or kept informational; what resolution witness backs that disposition; and which premature-closure fences block claims that the signal is handled, repaired, authorized, audited, or sibling-approved.

## Nouns under test

- **Disposition ledger** — a bounded carrier for routed packets, routing witnesses, unresolved-signal fences, carrier/surface/consumer/audience/purpose scope, review basis, disposition status, required resolution witnesses, required premature-closure fences, residual fences, and refused authority.
- **Resolution witness** — a scoped observation that a disposition was closed, partially closed, transferred, deferred, rejected, quarantined, or reopened, preserving closure evidence, residual fences, blocked inferences, and consumer-local scope.
- **Premature-closure fence** — a refusal around disposition claims whose route, source signal, source fence, closure evidence, scope, receiver, review basis, or residual-risk record is missing, stale, contradictory, widened, or laundered into repair, authorization, audit opinion, lifecycle finality, public release, or sibling verdict.

## Fixture requirements

The specimen 93 fixture must include:

- source escalation packets, routing witnesses, and unresolved-signal fences from specimen 92 pressure;
- resolved, deferred, transferred, quarantined, and informational disposition ledgers;
- closed, partial, transferred, deferred, false-positive, duplicate, reopened, and quarantined resolution witnesses;
- premature-closure fences for missing resolution witness, unresolved source fence, contradicted false positive, transfer without receiving scope, deferred-as-closed, stale closure, scope widening, public-release laundering, repair/lifecycle laundering, audit/authorization laundering, and sibling-verdict laundering;
- explicit disposition scope over consumers, surfaces, audiences, purpose classes, carriers, routed packets, source signals, unresolved fences, reviewer roles, and required evidence; and
- negative cases for missing disposition ledger, missing resolution witness, missing premature-closure fence, unknown packet, unknown routing witness, unknown unresolved fence, route acknowledgment as closure, unresolved signal marked closed, deferred-as-resolved, transferred-without-receiver, false positive without contradictory evidence, duplicate without canonical ledger, stale closure accepted, closure scope widening, fence cleared without clearance evidence, remediation-as-repair, closure-as-authorization, closure-as-audit, closure-as-public-release, lifecycle laundering, sibling-verdict laundering, and negative-case coverage drift.

## Rules

See [`disposition-resolution-rulebook-v0.md`](disposition-resolution-rulebook-v0.md).

## Non-goals

- no incident, ticket, case-management, workflow, pager, SIEM, or operations-product model;
- no ownership assignment, personnel duty, authorization, IAM, risk acceptance, legal compliance, public-release approval, deletion, retention, custody, repair, remediation, lifecycle finality, or sibling verdict;
- no guarantee that a local disposition is correct, sufficient, timely, complete, or accepted by another consumer;
- no global severity, priority, resolution, or issue-status taxonomy; and
- no replacement for routing, recheck/drift, verification, fulfillment, obligation, exposure, inventory, distribution, remediation/readmission, revocation/recall, delegation, portability, egress, or regression checks.

## Promotion status

Fixture-local. The nouns are useful only while they prevent routed drift from becoming silently resolved. Promotion requires generated disposition tamper cases plus at least one second non-SlopOS consumer whose post-route closure can diverge without becoming an incident/ticket or repair workflow.
