# Rule evaluation rulebook v0

This rulebook belongs to specimen 96. It defines tiny fixture-local checks for rule-evaluation traces, applicability witnesses, and misapplication fences.

## Rules

- `R-EVAL-001-EVALUATION-TRACE` — every attempt to apply a promoted, candidate, shadow, deprecated, or precedence-selected rule to a carrier/surface/context needs a rule-evaluation trace linking source collision ledgers, precedence witnesses, ambiguity fences, candidate rule refs, selected rule refs, skipped rule refs, evaluation context, output decision, blocked inferences, and authority boundaries.
- `R-EVAL-002-SOURCE-LINKAGE` — traces must link to known rule-collision ledgers, precedence witnesses, ambiguity fences, and rule-surface refs; unknown ids, missing digests, or rule refs outside the source collision fail closed.
- `R-EVAL-003-APPLICABILITY-WITNESS` — each selected or skipped rule needs an applicability witness that states applicable, not-applicable, partial, ambiguous, expired, or shadow-only for the same subject, consumer, surface, audience, purpose, carrier, and rule target.
- `R-EVAL-004-CONTEXT-ECHO` — applicability witnesses must echo the evaluation context and matched/missing inputs so later reuse cannot pretend a different carrier, cut, audience, or purpose was evaluated.
- `R-EVAL-005-PRECEDENCE-IS-NOT-APPLICATION` — a precedence witness may choose a winning rule for an overlap, but it does not prove the winning rule applied to this carrier or surface without an evaluation trace and applicability witness.
- `R-EVAL-006-SKIPPED-RULES-STAY-VISIBLE` — rules skipped because they are out of scope, deprecated, shadow-only, expired, missing inputs, or blocked by ambiguity fences must remain visible in the trace rather than disappearing from the decision.
- `R-EVAL-007-MISAPPLICATION-FENCE` — wrong-context application, scope widening, missing applicability witness, skipped-rule erasure, stale context, deprecated/shadow activation, default-decision laundering, contradiction with ambiguity fences, public-release laundering, audit/authorization laundering, repair/lifecycle laundering, and sibling-boundary laundering require a misapplication fence.
- `R-EVAL-008-DEFAULT-IS-NOT-DECISION` — a default outcome, fallback, checker order, rule order, absent rule, or abnormal evaluation must not become an applied decision unless the trace records why it was returned and what inferences remain blocked.
- `R-EVAL-009-CHECKER-CONTRACT-INDEX` — checker paths, primary fixtures, success-output fragments, runner order, and specimen/rulebook links must be visible in a machine-readable checker-contract index so rule evaluation does not hide behind an unregistered or misleading checker surface.
- `R-EVAL-010-AUTHORITY-LAUNDERING-FENCE` — evaluation traces and applicability witnesses must not be laundered into source truth, authorization, audit opinion, public-release approval, legal compliance, policy approval, incident closure, repair success, lifecycle finality, or sibling authority.

## Required negative cases

A valid specimen 96 fixture must include failure cases for missing evaluation trace, missing source collision ledger, missing precedence witness, missing ambiguity fence, unknown rule ref, selected rule without applicability witness, skipped rule erased, precedence-as-application, wrong carrier, wrong consumer, wrong audience, wrong purpose, stale context, missing context echo, default-as-decision, deprecated rule applied, shadow rule applied, ambiguity fence ignored, public-release laundering, authorization/audit laundering, repair/lifecycle laundering, sibling-verdict laundering, checker-contract index drift, runner-order-as-decision, and success-message-as-proof.

## Containment

These rules do not define a policy engine, rule engine, authorization runtime, feature-flag service, SHACL processor, Cedar evaluator, OPA server, admission controller, governance registry, audit product, public-release approval, legal compliance, risk acceptance, deletion, retention, custody, repair, lifecycle finality, or sibling verdict. They only ensure that a promoted or precedence-selected Foundry rule cannot be applied to a semantic carrier without scoped, replayable evaluation residue.
