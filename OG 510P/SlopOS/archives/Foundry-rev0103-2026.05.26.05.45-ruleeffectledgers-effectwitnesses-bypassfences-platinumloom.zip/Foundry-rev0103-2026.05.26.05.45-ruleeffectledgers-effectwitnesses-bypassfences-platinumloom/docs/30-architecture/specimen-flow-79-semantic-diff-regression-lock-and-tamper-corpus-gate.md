# Specimen flow 79 — semantic diff manifest, regression lock, and tamper corpus gate

Goal: make revision-to-revision semantic changes inspectable after sidecars, egress manifests, and refusal receipts already exist.

## Scenario

Foundry rev0084 emits a SlopOS-facing chart with a semantic sidecar and refuses several unsafe export attempts with receipt records. In rev0085, the fixture corpus is extended so an external audit notebook can consume the same sidecar/manifest/receipt residue. At the same time, future editors need a way to prove that the new revision did not silently change the meaning of the old residue.

The hard case is not malformed JSON. The hard case is well-formed JSON whose meaning shifted:

- the sidecar still has a digest-looking field, but classification pins disappeared;
- the manifest still has attempts, but a digest was reused after an attempt mutation;
- the receipt still has problem details, but the typed semantic refusal became a generic implementation error;
- the loss profile still exists, but drill-through changed from sidecar-only to allowed; or
- a classification/materialization cut changed without a bounded migration witness.

## Small seam to prove

### 1) semantic diff manifest

A semantic diff manifest is a compact revision-local artifact that names the compared revisions, canonicalization posture, baseline artifacts, candidate artifacts, and meaning-relevant diff entries.

Example:

```yaml
semantic_diff_manifest:
  manifest_family: foundry_semantic_diff_manifest_v0
  manifest_id: diff_rev0084_to_rev0085_egress_001
  manifest_digest: sha256:...
  previous_revision: rev0084
  candidate_revision: rev0085
  compared_subject: weekly_support_egress_bundle
  canonicalization_profile: rfc8785_jcs_like_stable_json_v0
  baseline_artifacts:
    - role: sidecar
      artifact_id: sidecar_weekly_category_chart_rev0084
      digest: sha256:...
  candidate_artifacts:
    - role: sidecar
      artifact_id: sidecar_weekly_category_chart_rev0085
      digest: sha256:...
  diff_entries:
    - entry_id: add_external_audit_consumer
      path: /consumers/1
      change_class: additive_consumer
      compatibility: compatible
      semantic_effect: same residue fields now used by one non-SlopOS consumer
      witness_id: wit_external_audit_notebook_consumer
```

The manifest is not a full migration engine. It is the smallest thing that prevents a future revision from saying “the tests still pass” while dropping the residue that made old results meaningful.

### 2) regression lock

A regression lock names a protected invariant and the path family it guards.

```yaml
regression_locks:
  - lock_id: lock_sidecar_classification_residue
    protected_paths:
      - /sidecar/classification_pins
      - /sidecar/crosswalk_witnesses
    invariant: classification-heavy egress cannot lose pins or crosswalks without refusal or migration witness
    failure_code: sidecar_pin_drop_unwitnessed
```

Locks are not permanent legal commitments. They are fixture-local alarms.

### 3) tamper corpus gate

A tamper corpus gate lists known dishonest mutations and the failure each mutation must trigger.

```yaml
tamper_cases:
  - case_id: drop_classification_pins_from_candidate_sidecar
    mutation_ops:
      - op: remove
        path: /candidate_artifacts/sidecar/semantic_payload/classification_pins
    expected_failure_code: sidecar_pin_drop_unwitnessed
    must_fail: true
```

Path-scoped mutation syntax borrows the JSON Patch instinct without making JSON Patch the Foundry migration language.

## What this specimen proves

- Compatibility is not a version bump.
- Digest stability is not semantic approval.
- Schema validity is not regression safety.
- An additive consumer is different from a meaning-changing field rewrite.
- Breaking-looking changes need a migration witness or a refusal posture.
- Non-SlopOS consumer pressure can be recorded without promoting a global data-product ontology.

## What this specimen must keep separate

- semantic diff manifest versus source result envelope;
- regression lock versus policy guarantee;
- tamper corpus versus adversarial security proof;
- canonical bytes versus semantic truth;
- JSON Patch-style mutations versus reviewed migrations;
- migration witness versus automatic backcast;
- external audit consumer versus Foundry-owned BI/audit product.

## Promotion gate for these nouns

Do not widen semantic diff manifests beyond fixture-local regression checks until:

- at least one real non-SlopOS consumer uses the same fields outside this toy fixture;
- tamper cases are generated from canonical bytes rather than only hand-authored;
- at least one sibling cube consumes a regression lock without treating it as its own verdict;
- one fixture proves a breaking change can be allowed only under a bounded migration witness; and
- one fixture proves a digest-preserving rename cannot count as compatibility.

## Why this matters

A datacube can become dishonest one revision at a time. Foundry needs a way to notice when the evidence carriers that protected egress semantics become the next thing to flatten.
