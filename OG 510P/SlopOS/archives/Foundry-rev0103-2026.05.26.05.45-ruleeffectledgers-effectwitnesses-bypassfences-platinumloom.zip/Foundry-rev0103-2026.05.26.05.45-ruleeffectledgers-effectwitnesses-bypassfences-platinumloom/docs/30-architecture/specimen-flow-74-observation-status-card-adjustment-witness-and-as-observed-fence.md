# Specimen flow 74 — observation-status card, adjustment witness, and as-observed fence

Goal: keep Foundry honest when a datacube value is useful and numeric, but not simply an as-observed value at the named cut.

## Scenario

A future SlopOS support workspace wants one compact table:

> weekly handler attempts, safe-open outcomes, diagnostic export sizes, trace-derived latency bands, and support-bundle health counts by tenant posture and origin class.

The table mixes several value kinds:

- a direct `CH-OBS` counter emitted by a native boundary;
- a trace-processor summary produced from sampled trace windows;
- a support-bundle count where one missing bundle entry was imputed from a manifest note;
- a provisional Steward-like currentness value that later reconciles to confirmed or withdrawn;
- a seasonality-like smoothed trend row used only for dashboard readability;
- a revised value after a boundary family renames an outcome class;
- and a raw prior vintage retained because an incident ticket cited the earlier table.

The tempting but wrong move is to store every row as:

```text
subject, measure, value, time, status
```

where `status` is a vague string, often dropped by export/chart/cache layers.

Foundry permits these useful values, but refuses to let adjusted, imputed, provisional, processor-derived, forecast, or revised values impersonate raw as-observed facts.

## Walkthrough

1. The request enters through specimen 70's query contract and result envelope. The contract names the source cut, policy lens, parameters, plan/replay posture, and result shape.
2. One cell is a direct counter emitted by `CH-OBS`. Foundry attaches an **observation-status card** with `status_family=as_observed`, vocabulary pin, source cut, and confidence that no adjustment witness is required.
3. A trace summary is produced by a processor over a sampled window. Foundry records `status_family=processor_derived`, points to the processor/config digest, and keeps sample/loss/replay posture from earlier specimens visible.
4. A support bundle lacks one expected entry. A count is imputed from a manifest note and a neighboring validated source. Foundry records `status_family=imputed`, an **adjustment witness** naming method family, input cut, missingness basis, side inputs, and diagnostics. It does not rewrite the missing bundle as if the entry existed.
5. A UI wants to plot raw and smoothed lines together. Foundry checks the **as-observed fence**. The smoothed line may display as a view, but it may not answer a raw-evidence query or backfill native event history.
6. A provisional currentness value confirms later. Foundry keeps the earlier provisional vintage and the later confirmed value as different readings; it does not silently rewrite the earlier incident panel.
7. A revised taxonomy regroups one outcome. Foundry records the revised status and the interpretation/revision witness; historical rows remain tied to the vintage cut that generated them.
8. A cache wants to serve the table without status metadata. Foundry refuses: status cards and as-observed fences are part of the result, not optional chart decoration.
9. A consumer asks for an export that only supports plain numbers. Foundry may emit a reduced view only if the as-observed fence allows it; otherwise it emits a refusal or a status-preserving sidecar.

## Nouns pressure-tested here

1. **observation-status card**
   - compact residue for what kind of value this cell is: as-observed, estimated, imputed, provisional, revised, adjusted, forecast, processor-derived, synthetic, substituted, quality-flagged, or unknown;
   - includes vocabulary/profile pin, status family, source cut, publication/vintage cut where relevant, and whether an unadjusted companion is known;
   - smaller than a universal quality ontology or status-code registry.

2. **adjustment witness**
   - compact residue for how a non-as-observed value was produced;
   - includes method family, recipe/model/spec digest, input cut, side-input cut, affected axis/window, diagnostics/check summary, reviewer/processor where known, and retention posture for the original value;
   - smaller than a statistical pipeline engine, ML lineage graph, or validation verdict.

3. **as-observed fence**
   - compact guardrail for whether the value may be used as direct observation, compared with raw values, backfilled into source history, joined into raw denominators, cached/exported without status, or shown in one line with unadjusted values;
   - smaller than a ban on adjusted data and stronger than a display-only label.

## What this specimen must keep separate

- as-observed versus observed-after-redaction;
- estimated versus imputed;
- imputed versus unknown;
- adjusted versus corrected;
- provisional versus final-for-cut;
- revised latest value versus historical vintage value;
- processor-derived summary versus native boundary observation;
- smoothed/dashboard value versus raw evidence value;
- quality flag versus policy verdict;
- adjustment diagnostic versus correctness proof;
- original retained value versus recoverable drill-through;
- status vocabulary pin versus global status ontology.

## Promotion gate for these nouns

Do not widen these nouns beyond observedness-sensitive value families unless a later specimen shows all of the following surviving without collapse:

- one directly observed SlopOS value and one processor-derived value in the same table;
- one imputed value where the missing source remains missing rather than backfilled;
- one adjusted or smoothed dashboard value shown beside, but not equal to, raw evidence;
- one provisional value that later confirms, revises, or withdraws;
- one revised/latest value where the earlier vintage remains citeable;
- one cache/export path that tries to drop status metadata and is refused;
- one consumer that can accept a status-preserving sidecar instead of plain-number flattening.

## Why this matters

Datacubes become dangerous when they make every number look equally observed.
Foundry should let SlopOS publish useful diagnostics, support summaries, trend views, and revised tables while making each non-raw value say what it is, how it was produced, and where it must not be treated as direct as-observed evidence.
