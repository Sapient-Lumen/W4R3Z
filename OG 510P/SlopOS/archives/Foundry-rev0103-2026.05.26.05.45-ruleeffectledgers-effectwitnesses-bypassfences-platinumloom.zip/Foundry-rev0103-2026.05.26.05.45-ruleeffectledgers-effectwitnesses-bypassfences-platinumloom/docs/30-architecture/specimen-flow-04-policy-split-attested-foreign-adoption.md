# Specimen flow 04 — policy-split attested foreign adoption

This specimen exists to test whether Foundry can describe confidential/foreign execution without flattening attestation, policy, and release into one runtime story.

## Story

A workload is packaged as an artifact basis with a declared interface world. It is launched onto a foreign ground that supports attestation. The workload carries init-data that is integrity-bound into attestation. Secret or resource release is allowed only after admission policy succeeds and a separate release policy says the workload may receive what it asks for.

## Candidate objects

- **artifact basis** — OCI image/component/package/bundle that is being realized.
- **declared world or contract** — what the workload claims it imports and exports.
- **foreign capability route** — how the product/session obtained the right to create or use this foreign ground.
- **init-integrity card** — how init-data or runtime policy inputs were integrity-bound.
- **attestation evidence** — measurements and claims exported for appraisal elsewhere.
- **policy split card** — admission policy versus resource-release policy.
- **adoption card** — started, attested, reviewed, adopted.
- **reacquire rail** — what must be reacquired on restore, clone, or generation change.

## Flow

1. A product/session uses an explicit **foreign capability route** to create or adopt a foreign cell.
2. The artifact basis and declared world are bound to a chosen runtime ground.
3. Init-data enters with an **init-integrity card** showing how it is protected from silent mutation.
4. The foreign ground emits **attestation evidence**.
5. A verifier/appraiser outside Foundry evaluates the evidence.
6. A separate **policy split card** keeps:
   - admission policy (“is this foreign ground acceptable?”)
   - resource-release policy (“may this acceptable ground receive this secret/resource?”)
   visibly different.
7. If the workload is only started or attested, it may still be **not yet adopted**.
8. On resume, clone, or generation change, the **reacquire rail** determines what must be refreshed before the workload can be treated as adopted again.

## Anti-collapses this specimen protects

- attested ≠ adopted
- attestation policy ≠ release policy
- init-data integrity ≠ init-data confidentiality
- started ≠ reviewed
- resumed ≈? ordinary continuity (not automatically)

## What to watch

If Foundry cannot describe this specimen without turning capability routing, policy split, init-data integrity, attestation evidence, and adoption into one runtime blob, the cube is still deciding too much too early.
