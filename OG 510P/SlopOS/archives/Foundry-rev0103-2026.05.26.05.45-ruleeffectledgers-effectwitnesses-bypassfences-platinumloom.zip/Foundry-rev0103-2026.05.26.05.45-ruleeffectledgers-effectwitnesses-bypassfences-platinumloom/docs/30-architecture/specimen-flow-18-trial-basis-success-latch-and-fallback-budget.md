# Specimen flow 18 — trial basis, success latch, and fallback budget

Goal: keep activated-once basis, blessed current truth, and bounded fallback visibly separate.

## Scenario
A foreign runtime basis is prepared and passes pre-activation integrity or compatibility checks.
It crosses an **activation cut** and actually boots, but the system still treats it as a **trial basis** rather than as blessed current truth.
A reviewed post-boot milestone — perhaps service health, user-session arrival, or an explicit operator bless step — drives a **success latch**.
Only after that latch is crossed does the new basis become the durable current basis and the old one stop being the known-good fallback.
Until then, a **fallback budget** tracks the bounded tries or remaining boot opportunities.
If health never arrives, the budget is exhausted, or a later explicit refusal occurs, selection returns to the previously known-good basis without pretending the trial basis was ever durably current.

## Proposed Foundry objects
1. **trial basis**
   - a basis that is active enough to run and be observed;
   - stronger than staged/downloaded candidate and weaker than blessed current.

2. **success latch**
   - explicit later event that blesses the trial basis as the durable current basis;
   - stronger than “boot happened” and weaker than any broader business or trust verdict.

3. **fallback budget**
   - bounded remaining tries before deterministic return to the known-good basis;
   - keeps post-activation risk honest and inspectable instead of magical.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- activation already happened,
- useful work may already be occurring on the new basis,
- the system still has not committed that basis as the durable current truth,
- and rollback/fallback remains a routine bounded path rather than an emergency myth.

## Promotion rule
Do not promote `trial basis`, `success latch`, or `fallback budget` unless they improve:
- one trial-boot specimen,
- one explicit success-mark / bless specimen,
- and one bounded fallback specimen.
