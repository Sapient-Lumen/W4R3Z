# Escalation routing rulebook v0

This rulebook belongs to specimen 92. It defines tiny fixture-local checks for escalation packets, routing witnesses, and unresolved-signal fences.

## Rules

- `R-ESC-001-ESCALATION-PACKET` — every risky drift signal that is not purely informational needs an escalation packet with source cadences, source signals, source fences, carrier/surface/consumer/audience/purpose scope, route basis, required receivers, required witnesses, required fences, and authority boundaries.
- `R-ESC-002-SOURCE-LINKAGE` — packets must link to known recheck cadences, drift signals, stale-verification fences, and carrier digests; unknown signal ids or missing cadence ids fail closed.
- `R-ESC-003-ROUTE-SCOPE` — route scope must preserve consumers, surfaces, audiences, purpose classes, receiver roles, channel class, grouping key, dedupe key, route deadline, and required residue.
- `R-ESC-004-ROUTING-WITNESS` — every required route needs a routing witness that records status, observed time, receiver consumer/role, channel class, scope echo, evidence refs, delivered residue, blocked inferences, and authority boundaries.
- `R-ESC-005-RISKY-ROUTE-FENCE` — missing, misrouted, stale, inhibited, quarantined, dedupe-flattened, scope-widened, public, delegated-worker, or sibling-boundary routes require an unresolved-signal fence.
- `R-ESC-006-DEDUPE-DOES-NOT-FLATTEN` — deduplication/grouping may reduce notification count but must not erase distinct carrier ids, signal ids, fences, audiences, or purposes.
- `R-ESC-007-INHIBITION-IS-NOT-HANDLING` — silenced or inhibited routing requires a fence; it cannot count as delivery, acknowledgment, resolution, adoption, or authorization.
- `R-ESC-008-ACKNOWLEDGMENT-IS-NOT-RESOLUTION` — acknowledgment, queue receipt, route id, ticket id, or notification delivery cannot clear stale verification, complete obligations, prove repair, close incident, authorize use, or create sibling verdict.
- `R-ESC-009-NON-TRANSITIVE-ROUTE` — a route to one consumer, receiver role, channel, audience, or purpose does not route to another without a new packet or explicit fence.
- `R-ESC-010-AUTHORITY-LAUNDERING-FENCE` — route packets and witnesses must not be laundered into source truth, policy approval, audit opinion, incident closure, public-release approval, repair success, lifecycle finality, or sibling authority.
- `R-ESC-011-DOC-COVERAGE-REFRACTOR` — promoted specimen docs must have machine-readable coverage tying specimen doc, rulebook, fixture, schemas, checker, aggregate runner, and docs map together.

## Required negative cases

A valid specimen 92 fixture must include failure cases for missing escalation packet, missing routing witness, missing unresolved-signal fence, unknown source signal, missing source cadence, risky signal without packet, missing route accepted, misrouted acknowledgment accepted, stale acknowledgment accepted, scope mismatch accepted, dedupe-erased residue, inhibition without fence, route-as-truth, acknowledgment-as-resolution, pager-as-authority, incident-management capture, repair/lifecycle laundering, sibling-verdict laundering, and specimen-doc coverage drift.

## Containment

These rules do not define alerting, incident management, ticketing, notification delivery, ownership assignment, on-call policy, authorization, consent, public-release approval, deletion, retention, custody, repair completion, remediation, lifecycle finality, audit opinion, or sibling verdicts. They only ensure that risky semantic drift is routed or fenced with enough residue to prevent false handling.
