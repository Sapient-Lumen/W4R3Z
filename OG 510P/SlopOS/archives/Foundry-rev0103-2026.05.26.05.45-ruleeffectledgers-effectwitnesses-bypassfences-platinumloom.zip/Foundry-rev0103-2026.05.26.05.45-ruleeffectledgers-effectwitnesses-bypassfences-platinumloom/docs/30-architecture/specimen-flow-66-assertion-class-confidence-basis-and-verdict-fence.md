# Specimen flow 66 — assertion class, confidence basis, and verdict fence

Goal: keep a future Foundry datacube honest when it needs to carry useful claims, validation results, local approvals, or heuristic scores without collapsing them into one flattering fact plane.

## Scenario
A future support workspace wants one “trust posture” panel spanning design-phase SlopOS surfaces.
It can see:
- one `native_observations` table with rows directly emitted by a native boundary;
- one `imported_claim_rows` table with imported profile, identity, or origin claims;
- one `validation_results` table with family-local pass/warn/fail style outputs;
- one `policy_decisions` table with local approval or rejection outcomes;
- and one `heuristic_scores` table with reputation or similarity scores.

A tempting but wrong move is to flatten all of these into a reusable `trust_value` family and let later readers treat every row as one comparable truth.
That would be misleading.
A native observation is not the same thing as an imported claim, a warning is not the same thing as a failure, a local policy decision is not the same thing as source truth, and an absent confidence is not zero.

## Small seam to prove

### 1) assertion class
Every claim- or verdict-shaped row carries a compact witness for what kind of assertion it is.
Examples:
- `native_observation`
- `imported_claim`
- `validation_result`
- `policy_verdict`
- `heuristic_score`
- `manual_annotation`

This keeps useful rows distinct without inventing a giant trust ontology.

### 2) confidence basis
Every such row carries a compact witness for what any confidence, severity, or score means.
Examples:
- `unspecified`
- `stix_confidence_0_100`
- `shacl_result_severity`
- `policy_local_pass_fail`
- `heuristic_similarity_score`
- `manual_review_only`

This keeps absent confidence visibly smaller than zero and keeps warnings, scores, and policy-local outcomes from pretending to live on one universal numeric ruler.

### 3) verdict fence
Every such row carries a compact guardrail for what later consumers must not assume.
Examples:
- `advisory_only`
- `policy_local_only`
- `unspecified_not_zero`
- `warning_not_failure`
- `not_source_equivalent`
- `forbidden`

This stops dashboards and exports from silently converting hints, warnings, approvals, or heuristic scores into native truth.

## Example residue

```text
claim_like_row:
  subject: slopos.identity.imported_profile_email
  assertion_class: imported_claim
  value: alice@example.com
  confidence_basis: unspecified
  verdict_fence: not_source_equivalent

claim_like_row:
  subject: slopos.worker_pool.validation_case
  assertion_class: validation_result
  value: warning
  confidence_basis: shacl_result_severity
  verdict_fence: warning_not_failure

claim_like_row:
  subject: slopos.client_trust.policy_decision
  assertion_class: policy_verdict
  value: accepted
  confidence_basis: policy_local_pass_fail
  verdict_fence: policy_local_only

claim_like_row:
  subject: slopos.origin.quarantine_score
  assertion_class: heuristic_score
  value: 0.83
  confidence_basis: heuristic_similarity_score
  verdict_fence: advisory_only
```

## What this specimen proves
Foundry can preserve claim/validation honesty with three compact residues instead of inventing:
- a universal trust score,
- a giant verification algebra,
- or a permanent verified/unverified ontology.

The cube only needs to say:
1. **what kind of assertion this row is,**
2. **what any confidence/severity/score actually means,**
3. and **where the outcome must not impersonate source truth.**

## Why this belongs in Foundry
SlopOS already has imported-claim surfaces, non-claims, family-local verdict summaries, and policy-local trust/approval boundaries.
That makes compact verdict rows useful but dangerous.
This specimen gives Foundry the smallest honest way to preserve that fact when future exports and support panels start mixing claims, validations, approvals, and scores.

## What stays parked
- no archive-wide trust score;
- no global verified/unverified boolean;
- no universal probability algebra;
- no promise that warnings, heuristic scores, and source truths are commensurable.
