# Delegation boundary rulebook v0

This rulebook is intentionally small. It checks whether a consumer-local semantic act was delegated without becoming permission, approval, sibling-cube authority, audit opinion, or transitive trust.

It is not an authorization server, entitlement system, legal-agency model, trust framework, audit workflow, policy engine, or sibling-cube verdict system.

## Rules

- **R-DELEG-001-WARRANT-REQUIRED** — every delegated semantic act must have a delegation warrant naming grantor consumer, delegate consumer, relying consumer, artifacts, permitted acts, forbidden acts, and expiry/revocation posture.
- **R-DELEG-002-SCOPED-ACTS** — delegated acts must be an explicit allow-list; copied bytes, matching surface names, portability witnesses, or dashboard access do not imply delegation.
- **R-DELEG-003-SCOPE-BOUNDARY** — purpose, audience, artifact ids, source cut, classification cut, revision, and consumer ids are part of the warrant scope.
- **R-DELEG-004-NON-TRANSITIVE-DEFAULT** — delegation is non-transitive unless a new warrant explicitly names the next grantor, delegate, relying consumer, scope, and acts.
- **R-DELEG-005-RELIANCE-RECEIPT** — a relying consumer must leave a receipt naming the warrant checked, acts used, rules rerun, residue preserved, and inferences refused.
- **R-DELEG-006-AUTHORITY-NOT-VERDICT** — delegation may allow Foundry evidence handling, but it cannot transfer trust verdicts, audit opinions, source truth, policy approval, repair consequence, lifecycle finality, retention authority, or object identity.
- **R-DELEG-007-EXPIRY-REVOCATION** — expired, revoked, superseded, rejected, or unknown-status warrants cannot authorize allowed reliance.
- **R-DELEG-008-ACTOR-CHAIN-TRACE** — receipts must preserve current actor, prior actor, and relying consumer enough to audit the handoff without treating prior actors as current authority.
- **R-DELEG-009-WITHHELD-RESIDUE** — withheld residue must stay withheld; using it as if delegated requires refusal.
- **R-DELEG-010-SIBLING-OWNERSHIP** — Ward, Harbor, Steward, Schell, ViewFS, Helm, and SlopOS authorities remain owned by those cubes; Foundry can carry evidence but not delegate their verdicts.
- **R-DELEG-011-CONSUMER-PASSPORT-COMPAT** — the relying consumer's passport and interpretation gate must still pass; a delegation warrant does not replace portability or interpretation checks.
- **R-DELEG-012-REFUSAL-ON-WIDENING** — purpose widening, audience widening, artifact widening, cut changes, delegate changes, relying-consumer changes, and redelegation require a new warrant or a refusal receipt.

## Default posture

A delegation warrant authorizes only the named semantic act in the named scope. Everything else is refused, uninterpreted, or local to the cube that owns the authority.
