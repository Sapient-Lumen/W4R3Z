# Checker contract index audit v0

## Why this audit exists

By rev0102, Foundry's executable surface is large enough that a checker can become folklore: a filename appears in the runner, a success message looks authoritative, or a checker quietly stops pointing at the fixture and rulebook it claims to protect. That is a semantic drift surface.

## What changed

- Added `fixtures/checker-contract-index/index.json` as a machine-readable map from aggregate-runner order to checker path, primary fixture, primary rulebook/specimen, and success-output fragment.
- Added `tools/check_foundry_checker_contract_index.py` to compare the index with the aggregate runner and checker source text.
- Wired the checker-contract index into schema/fixture coverage and the aggregate runner.

## What this refuses

The index does not prove checker correctness, fixture completeness, ontology correctness, audit validity, certification, production readiness, policy semantics, authorization, public release, repair success, lifecycle finality, or sibling verdict. It only makes the checker contract visible enough that a future rule-evaluation pass cannot hide behind runner order or success-message folklore.
