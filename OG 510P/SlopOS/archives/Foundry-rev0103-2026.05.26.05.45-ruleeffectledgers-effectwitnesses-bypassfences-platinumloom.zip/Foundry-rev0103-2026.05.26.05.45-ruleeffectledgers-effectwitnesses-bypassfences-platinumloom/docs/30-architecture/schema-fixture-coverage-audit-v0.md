# Schema/fixture coverage audit v0

Rev0097 audits a structural weakness in the fixture-backed part of the cube: the checker suite kept growing, but the relationship among schemas, fixtures, specimen docs, and checker registrations was still partially implicit.

## Refactor

This pass adds a small machine-readable coverage manifest at `fixtures/schema-fixture-coverage/coverage.json` and a checker at `tools/check_foundry_schema_fixture_coverage.py`. The checker is intentionally about repository shape, not JSON Schema validation.

It verifies that:

- every `schemas/*.schema.json` file is listed once in the coverage manifest;
- every fixture JSON file under `fixtures/` is listed once, including non-specimen support and coverage fixtures;
- every `tools/check_foundry*.py` checker except the aggregate runner is present in `tools/check_foundry_all.py`;
- every listed fixture, schema, checker, rulebook, and specimen doc exists;
- schema family names used by the coverage manifest match the corresponding schema files; and
- the coverage manifest records non-goals so schema coverage is not mistaken for ontology completeness, production validation, audit, or compatibility proof.

## Why this is an audit/refactor instead of a new ontology

Foundry has accumulated many narrow carriers: sidecars, receipts, locks, waivers, passports, warrants, notices, packets, ledgers, witnesses, fences, audits, samples, and now cadences/signals. The danger is not only semantic overreach; it is fixture/checker drift. A missing checker registration or unlisted schema lets a future revision appear healthy while leaving a semantic seam untested.

The refactor keeps each specimen checker local while making the harness inventory explicit. It does not validate every JSON Schema, generate fixtures, infer ontology, or certify the cube. It only prevents the executable surface from becoming invisible.

## Refusal line

Coverage is not correctness. A listed schema can be too weak, a fixture can be too small, and a checker can be wrong. The coverage audit only says the intended executable surfaces are present and wired into the harness.
