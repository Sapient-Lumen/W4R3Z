# Specimen flow 45 — exactness class, bound witness, and correction horizon

Goal: keep a future Foundry datacube honest when neighboring archives emit values that look comparable in a table but are actually exact, approximate, advisory, or still restatable.

## Scenario
A future Foundry read surface wants to summarize the current SlopOS architecture corpus.
It can see:
- one exact count of boundary docs by reviewed family membership at this archive cut;
- one smart-folder result count from a view-scoped ATTRFS query that is snapshot-first;
- one SKB-derived CPU-class ranking label that helps placement but is only advisory;
- one approximate distinct count produced from a sketch-backed query over imported identifiers;
- and one family summary that may still be corrected when late-arriving docs or regrouped members are folded in.

A tempting but wrong move is to put all of these in one cheerful `value` column and sort/filter/aggregate as though they shared the same semantics.
Instead, Foundry stays smaller and more honest.

## Healthy cut
Every estimate-sensitive or rank-shaped value carries three small semantic companions.

### 1) exactness class
A compact posture for what kind of value this is.
Examples:
- **exact-at-cut** — exact for the stated scope/revision/cut, while still potentially smaller than global timeless truth;
- **bounded-estimate** — algorithmic estimate with explicit error/confidence posture;
- **advisory-rank** — score/order/hint useful for steering or reading but not correctness-bearing;
- **query-shaped only** — helpful output whose semantics are too tied to one query/result shape to promote as atomic fact.

This keeps “number-like” visibly smaller than “same kind of fact.”

### 2) bound witness
A compact residue explaining why a non-exact or rank-shaped value is still interpretable.
Examples:
- sketch family plus algorithm parameters and confidence/error interval;
- query-engine operator choice such as approximate distinct versus exact distinct;
- ranking basis such as placement-hint derivation over CPU-capacity facts;
- statement that no numeric bound exists because the output is advisory only.

This is inspectability truth.
It keeps approximation and ranking from hiding in implementation folklore.

### 3) correction horizon
A small posture saying how long the value may still be restated.
Examples:
- **closed** — no ordinary late-arrival/backfill correction expected for this cut;
- **open-until-cut-finalized** — snapshot/export may still change until a stated archive or ingest finalization step closes;
- **late-fact window** — event/context corrections may still restate the value during a bounded horizon;
- **query-recomputed** — value is always rederived and should never be mistaken for permanently settled stored fact.

This keeps “currently shown” visibly smaller than “forever final.”

## What this prevents
- approximate distinct counts from becoming exact denominators by accident;
- advisory ranks from becoming category truth or policy authority;
- snapshot query counts from being read as global exhaustive inventory;
- late-arriving corrections from being mistaken for semantic contradiction;
- and dashboard-friendly numeric flattening from erasing what the value actually means.

## Why this is enough for now
Foundry does **not** yet need a global uncertainty calculus, forecast ontology, sketch registry, or universal metric catalog.
The conservative win is just to keep exactness class, bound witness, and correction horizon visibly separate.

## Promotion gate
Do not promote `exactness class`, `bound witness`, or `correction horizon` beyond this specimen unless they improve at least:
- one SlopOS snapshot query/count specimen;
- one SlopOS advisory-rank or hint-only specimen;
- one approximate-distinct or top-k specimen from a real read surface;
- and one late-arriving correction specimen where exact-at-cut is still smaller than final-after-restatement truth.
