# Negative-case coverage audit v0

This refactor guards a specific cube failure: as Foundry accumulates specimen fixtures, a fixture can look executable while its hard failures live only in prose. The negative-case coverage manifest makes every late executable specimen name the fixture path, rulebook, checker, expected minimum negative-case count, covered failure modes, and runner/docs-map surfaces.

## What it checks

- every covered specimen fixture has unique `negative_cases` with stable `case_id` values;
- every manifest record names the fixture, rulebook, checker, and docs map/runner expectations;
- every listed negative case id exists in the fixture, and every fixture negative case is listed by the manifest;
- covered failure modes include at least one explicit authority/laundering refusal; and
- the aggregate runner contains the named checker.

## What it refuses

- no completeness claim over the whole ontology;
- no proof the negative cases are sufficient or semantically correct;
- no audit, certification, compliance, test-management, coverage-product, or quality-score role;
- no generated tamper-corpus replacement; and
- no authority to promote a specimen beyond fixture-local v0.

## Why now

Specimen 92 added specimen-doc coverage. Specimen 93 adds the next useful refactor because route/disposition/closure failures are easy to under-test: a missing fence, stale closure, or sibling-verdict laundering case can disappear from fixtures while the prose still claims it exists. This audit keeps those cases discoverable by machine.
