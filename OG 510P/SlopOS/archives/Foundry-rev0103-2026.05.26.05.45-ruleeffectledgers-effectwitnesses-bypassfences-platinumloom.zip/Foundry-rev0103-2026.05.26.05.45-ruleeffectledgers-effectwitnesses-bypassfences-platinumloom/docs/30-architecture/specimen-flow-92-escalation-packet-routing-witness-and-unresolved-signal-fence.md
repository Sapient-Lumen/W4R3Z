# Specimen flow 92 — escalation packet, routing witness, and unresolved-signal fence

Goal: make risky semantic drift routable without turning Foundry into monitoring, alerting, ticketing, incident management, ownership assignment, remediation workflow, audit, authorization, public-release, repair, lifecycle, or sibling-verdict infrastructure.

## Scenario

Specimen 91 records recheck cadences, drift signals, and stale-verification fences. That proves old verification cannot remain fresh silently. A new failure remains: the signal can fire, but the right consumer-local owner never receives the residue. A dashboard can emit a generic alert, Alertmanager-like grouping can collapse two semantic risks into one label, an inhibition can hide the signal, a public-link scanner can acknowledge receipt without the recall-route residue, or a delegated-worker queue can mark a message handled while still running old bytes.

A SlopOS operator console, Ward preview queue, ViewFS projection service, delegated worker, public-link scanner, dashboard cache, and external-audit notebook now need a bounded routing surface. Foundry must record what risky signal was escalated, where it was routed, what residue traveled, which scope was covered, which route was missing/misrouted/stale/inhibited, and which unresolved-signal fences block reuse.

## Nouns under test

- **Escalation packet** — a bounded carrier for source cadences, risky drift signals, stale-verification fences, affected carrier/surface/consumer/audience/purpose scope, route basis, dedupe/grouping key, required receivers, required routing witnesses, required unresolved-signal fences, and refused authority.
- **Routing witness** — a scoped observation that an escalation packet was delivered, acknowledged, deduplicated, inhibited, quarantined, missing, misrouted, or stale on a named channel, preserving delivered residue and refused inferences.
- **Unresolved-signal fence** — a refusal around risky drift signals whose escalation is missing, misrouted, stale, inhibited, dedupe-flattened, scope-widened, ownerless, or laundered into incident closure, authorization, audit opinion, repair success, or sibling verdict.

## Fixture requirements

The specimen 92 fixture must include:

- source recheck cadences, drift signals, and stale-verification fences from specimen 91 pressure;
- routed, acknowledged, blocked, quarantined, and informational escalation packets;
- delivered, acknowledged, deduplicated, inhibited, quarantined, missing, misrouted, and stale routing witnesses;
- unresolved-signal fences for missing route, misroute, stale acknowledgment, scope mismatch, dedupe residue loss, inhibition without fence, public-link escalation gap, delegated-worker flapping, and sibling-boundary laundering;
- explicit route scope over consumers, surfaces, audiences, purpose classes, receivers, channels, grouping keys, and required residue; and
- negative cases for missing escalation packet, missing routing witness, missing unresolved fence, unknown source signal, missing source cadence, risky signal without packet, missing route accepted, misrouted acknowledgment accepted, stale acknowledgment accepted, scope mismatch accepted, dedupe erased residue, inhibition without fence, route-as-truth, acknowledgment-as-resolution, pager-as-authority, incident-management capture, repair/lifecycle laundering, and sibling-verdict laundering.

## Rules

See [`escalation-routing-rulebook-v0.md`](escalation-routing-rulebook-v0.md).

## Non-goals

- no Prometheus Alertmanager, pager, ticket, incident, SIEM, notification, or operations workflow;
- no ownership assignment, personnel duty, authorization, IAM, public-release, consent, legal-compliance, deletion, retention, custody, repair, remediation, lifecycle finality, or sibling verdict;
- no guarantee that a routed packet was read, understood, resolved, acted on, or sufficient;
- no global alert taxonomy or severity policy; and
- no replacement for recheck/drift, verification audit, fulfillment, obligation, exposure, inventory, distribution, remediation, revocation, delegation, or portability checks.

## Promotion status

Fixture-local. The nouns are useful only while they prevent risky drift signals from becoming silently handled. Promotion requires generated routing tamper cases plus at least one second non-SlopOS consumer whose routing can misdeliver or flatten residue without becoming an incident/ticket system.
