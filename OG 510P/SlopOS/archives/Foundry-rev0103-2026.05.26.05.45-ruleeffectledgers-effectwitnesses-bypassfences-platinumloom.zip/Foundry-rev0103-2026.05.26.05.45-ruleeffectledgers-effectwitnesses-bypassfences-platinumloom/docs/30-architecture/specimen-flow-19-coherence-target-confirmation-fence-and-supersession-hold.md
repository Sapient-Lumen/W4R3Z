# Specimen flow 19 — coherence target, confirmation fence, and supersession hold

Goal: keep grouped basis family, confirmation certainty, and blocked conflicting advance visibly separate.

## Scenario
A foreign basis update consists of several pieces that only make honest sense together: for example a root deployment, matching kernel, matching verity data, and an adjacent policy/config binding.
Foundry treats that grouped family as one **coherence target** rather than as a pile of coincidentally similar version strings.
A newer target family is later prepared, but the system still lacks reliable confirmation that the previously offered family became the currently known-good family on the recipient side.
A **confirmation fence** therefore refuses to treat the prior offer as settled truth.
Until that fence is crossed by explicit confirmation, a **supersession hold** prevents a conflicting newer family from being treated as the safe next current family.
This keeps “newer exists” smaller than “safe to advance” and prevents mixed-time resource sets or uncertain prior adoption from being flattened into one cozy update noun.

## Proposed Foundry objects
1. **coherence target**
   - grouped multi-resource basis family that should move together as one reviewed version moment;
   - stronger than a loose collection of same-looking version labels and weaker than any fleet-wide rollout policy.

2. **confirmation fence**
   - explicit boundary requiring reviewed evidence before a prior target family is treated as settled current/known-good truth;
   - stronger than “we issued it” and weaker than any wider business or trust verdict.

3. **supersession hold**
   - explicit refusal to advance a conflicting newer target family while the confirmation fence is still closed;
   - keeps issuer-side certainty and recipient-side adoption from being confused.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- several basis pieces must remain version-coherent,
- repository or issuer logic has offered a newer family,
- prior adoption is still uncertain,
- and mixed-time or partially confirmed updates would otherwise be easy to overclaim.

## Promotion rule
Do not promote `coherence target`, `confirmation fence`, or `supersession hold` unless they improve:
- one grouped-target specimen,
- one uncertain-prior-adoption specimen,
- and one explicit supersession-refusal specimen.
