# Specimen flow 07 — subject closure, resource warrant, and foreign lease

This specimen exists to test whether Foundry can keep attached evidence neighborhoods, routed launch inputs, and live foreign realization visibly separate.

## Scenario
A digest-addressed artifact has nearby sidecars: signature, attestation, contract description, and policy capsule. A product session also receives explicit routed power and structured configuration before it launches foreign ground. Some foreign-backed resources are available only under a temporary right.

## Flow
1. Foundry resolves the primary subject artifact plus its nearby attached evidence and contract artifacts into a **sidecar closure**.
2. Before launch, Foundry records a **resource warrant** describing:
   - which routed powers were present,
   - which structured configuration values were injected,
   - which host-backed or foreign-backed handles were required versus optional.
3. Launch proceeds only if required routed inputs are present.
4. The running system receives a **foreign lease** for using certain foreign-backed services or resources.
5. Later, if resume or reattachment occurs, some resources may require explicit reacquire, yielding a **reacquire warrant**.
6. Local adoption still decides whether this foreign realization becomes durable local practice.

## What this specimen is trying to preserve
- Attached sidecars remain smaller than realization truth.
- Routed power and config remain inspectable launch inputs.
- Temporary rights to foreign resources stay visibly temporary.
- Reacquire after resume remains distinct from uninterrupted continuity.
- Durable adoption remains a later act.

## Candidate nouns under pressure
- **sidecar closure**
- **resource warrant**
- **foreign lease**
- **launch closure**
- **reacquire warrant**

## Kill criteria
Reject these nouns if any of the following happens:
- the sidecar closure is read as equivalent to what finally ran;
- the resource warrant starts swallowing all orchestration, policy, and runtime taxonomy;
- the foreign lease stops feeling temporary or exterior;
- reacquire warrant cannot distinguish “reacquired” from “never lost continuity”.

## If Foundry survives the specimen
If Foundry *can* survive it, then pass X has found a promising smaller set:
- a subject-neighborhood view smaller than realization,
- explicit routed launch truth smaller than runtime folklore,
- and a temporary foreign-use notion that keeps off-native power honest.
