# Recheck drift rulebook v0

This rulebook belongs to specimen 91. It defines tiny fixture-local checks for recheck cadences, drift signals, and stale-verification fences.

## Rules

- `R-RCK-001-RECHECK-CADENCE` — every continuing verification claim needs a cadence id, digest, status, source verification audit, scope, cadence basis, freshness window, required drift signals, escalation posture, and authority boundaries.
- `R-RCK-002-SOURCE-VERIFICATION-LINKAGE` — every cadence must name source verification audits, evidence samples, false-closure fences when relevant, carrier ids, consumers, surfaces, audiences, and purposes.
- `R-RCK-003-CADENCE-BASIS` — cadence basis must state interval or trigger, grace window, first/last/next check times, blocked inferences, and paused/blocked status so a stale packet cannot masquerade as live verification.
- `R-RCK-004-DRIFT-SIGNAL` — every required signal needs evidence, state, observed time, probe basis, source cadence, carrier/surface scope, residue checked, and non-promises.
- `R-RCK-005-SCOPE-TIME-AND-DIGEST-CHECK` — drift signals may not exceed cadence scope, may not be accepted after the cadence freshness window without a fence, and must preserve carrier digest linkage when a carrier is named.
- `R-RCK-006-RISKY-SIGNAL-FENCE` — warning, firing, stale, missing, flapping, superseded, quarantined, public, inherited, scope-widened, digest-mismatched, or permission-denied signals require a stale-verification fence.
- `R-RCK-007-RECHECK-IS-NOT-VERIFICATION` — a recheck cadence or clear signal cannot replace the source verification audit or evidence sample.
- `R-RCK-008-NON-EXHAUSTIVE-CLEAR` — a clear drift signal clears only the named signal/scope/window, not unsampled consumers, surfaces, audiences, purposes, obligations, or future intervals.
- `R-RCK-009-NON-TRANSITIVE-FRESHNESS` — cadence freshness is not authorization, legal compliance, consent, public release, audit opinion, cryptographic proof, monitoring SLA, incident closure, custody, repair completion, lifecycle finality, source truth, or sibling verdict.
- `R-RCK-010-AUTHORITY-LAUNDERING-FENCE` — a cadence, signal, or fence must not be laundered into source truth, policy approval, audit opinion, SLO compliance, incident resolution, repair success, or sibling authority.
- `R-RCK-011-COVERAGE-REFRACTOR` — schema/fixture/checker coverage must be machine-readable enough to catch an unlisted schema, fixture, or checker when new specimen machinery is added.

## Required negative cases

A valid specimen 91 fixture must include failure cases for missing recheck cadence, missing source verification, missing drift signal, required signal omitted, stale signal accepted, flapping signal unfenced, missed recheck unfenced, cadence scope mismatch, signal scope mismatch, signal digest mismatch, paused cadence treated as active, clear signal treated as exhaustive, alert-as-truth, freshness-as-authorization, recheck-as-audit-opinion, monitoring-as-sibling-verdict, and schema/fixture coverage drift.

## Containment

These rules do not define monitoring, alert routing, SLOs, incident management, audit, certification, control assessment, authorization, consent, public-release approval, deletion, retention, custody, repair completion, lifecycle finality, or sibling verdicts. They only protect Foundry's verification evidence from being treated as continuously fresh merely because an old verification passed.
