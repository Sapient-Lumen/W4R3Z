# Specimen flow 41 — effective time, record time, and pending context

Goal: keep a future Foundry datacube honest when a fact was true at one time, was learned later, and still lacks some context when first ingested.

## Scenario
A foreign-ground event matters to Foundry.
Maybe an off-native realization actually crossed a boundary yesterday, but Foundry only receives the evidence today.
Worse, the event arrives before all descriptive context has been joined in: one provider detail, world label, or companion-side explanation is still missing.

The tempting mistake is to force one cheerful final row immediately.
That produces quiet lies:
- the row pretends the record time and true/effective time are the same;
- missing dimensional context gets silently filled with folklore;
- and a later correction looks like an overwrite instead of a fact learned later.

Instead, the cube stays smaller and more honest.

First, the row may carry an **effective time**.
That is when the modeled thing was true on the foreign ground or in the artifact world.

Second, the row may separately carry a **record time**.
That is when Foundry learned, accepted, or restated the fact.

Third, the row may explicitly remain in **pending context**.
The fact exists, but one part of its descriptive join/context story is not yet settled.
A later revision can fill that context without pretending the original record was already complete.

## Proposed Foundry objects
1. **effective time**
   - when a fact was true in the modeled world.

2. **record time**
   - when Foundry learned, accepted, or restated that fact.

3. **pending context**
   - visible incomplete dimensional/context state instead of forced completeness.

## Why this specimen matters
It pressure-tests whether Foundry can:
- absorb retroactive correction without flattening it into one overwritten present;
- admit a fact before every descriptive dimension or companion noun is available;
- support later honest restatement without claiming that the first row was already complete;
- and keep future summaries or exports smaller than the cube’s full meaning model.

## Adjacent but parked
- **restatement ticket** — future, only if more than one specimen needs explicit backfill/rewrite workflow.
- **promoted noun id** — future, only if renames or alias pressure prove labels are not enough.
- **acceleration view** — future, only if one derived summary or pre-aggregation truly needs first-class treatment.
- **universal bitemporal plane** — future, only if several families genuinely require it.
