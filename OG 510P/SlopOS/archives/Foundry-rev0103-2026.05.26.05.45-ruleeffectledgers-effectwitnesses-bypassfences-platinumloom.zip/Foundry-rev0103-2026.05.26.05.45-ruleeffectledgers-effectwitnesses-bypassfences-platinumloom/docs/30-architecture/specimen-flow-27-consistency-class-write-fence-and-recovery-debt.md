# Specimen flow 27 — consistency class, write fence, and recovery debt

Goal: keep “a cut was captured” separate from “the cut was strengthened by an explicit freeze/flush boundary” and separate again from “restore is now semantically comfortable”.

## Scenario
A service group must be checkpointed or snapshotted before maintenance.
The operator captures a point-in-time image that is real enough to restore later.
But the semantic strength of that image depends on how the cut was taken.

If the capture happens without any stronger pause or flush coordination, the result may be only a **crash-consistent** cut.
That is still a real cut.
It may be entirely acceptable for some workloads.
But it is weaker than an application-aware capture.

If the service crosses an explicit **write fence** first — such as a cooperative pause, filesystem freeze, or application flush boundary — then the cut has a stronger **consistency class**.
That stronger class should stay explicit.
It should not be inferred later from the mere existence of a snapshot artifact.

Even then, restore may still carry **recovery debt**.
The restored system may need WAL replay, journal recovery, cache rebuild, rebind work, or other repair steps before it counts as comfortably resumed.
That debt keeps “valid captured cut” separate from “no meaningful repair still owed”.

This keeps capture reality, capture strength, and post-restore repair visibly distinct.

## Proposed Foundry objects
1. **consistency class**
   - explicit statement of what kind of cut was actually captured;
   - examples may later include crash-consistent, filesystem-consistent, or application-consistent without forcing a global registry yet.

2. **write fence**
   - explicit pause, flush, freeze, or quiesce boundary crossed before or during capture;
   - keeps stronger capture discipline separate from the snapshot artifact itself.

3. **recovery debt**
   - explicit replay, repair, or restart work still owed after restore before strong resumed truth can be claimed;
   - keeps “restorable” separate from “comfortably resumed and semantically quiet”.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a snapshot/checkpoint exists,
- the cut is weaker or stronger depending on pre-capture discipline,
- multi-volume point-in-time grouping still does not imply application quiescence,
- and restore may still owe replay or repair work after the image is accepted.

## Adjacent but parked
- **cut witness** — compact residue for how one capture cut was taken.
- **replay ledger** — future visible account of debt discharged after restore.

## Promotion rule
Do not promote `consistency class`, `write fence`, or `recovery debt` unless they improve:
- one filesystem or VM snapshot specimen,
- one cooperative checkpoint specimen,
- and one restore path where replay or repair is still honest public truth instead of hidden postscript.
