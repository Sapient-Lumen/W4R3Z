# Specimen flow 05 — subject-attached sidecars and measured adoption

This specimen is intentionally narrow. It exists to pressure-test one modern off-native realization lane without deciding that Foundry should become a generic registry or packaging cube.

## The situation

A realizable artifact is distributed with nearby material:
- contract descriptions,
- provenance,
- attestation or transparency receipts,
- policy input descriptions,
- and perhaps platform-specific runtime hints.

Modern registry ecosystems increasingly let those materials attach to a primary digest as **subject-related** sidecars.

Foundry should learn from that pattern without pretending that neat attachment solves realization truth.

## Candidate Foundry objects

### 1) Subject spine (candidate)
A primary digest or equivalent stable anchor for the realization.
It says “these nearby artifacts relate to this artifact”.
It does **not** say the nearby set is complete or approved.

### 2) Sidecar pack (candidate)
A grouped set of attached artifacts:
- world/contract material,
- provenance,
- verification receipts,
- runtime hints,
- measured policy descriptions.

It is still smaller than realization verdict.

### 3) Measured policy capsule (candidate)
A compact record of which policy or init-data input was integrity-bound into the foreign-ground story.

### 4) Runtime evidence (candidate)
Evidence that the foreign ground started under some attested or measured conditions.
Still weaker than adoption.

### 5) Adoption rail (candidate)
The explicit path from:
- artifact known,
- sidecars observed,
- policy input measured,
- runtime attested,
- local adoption granted.

## Walkthrough

1. A primary artifact digest is chosen as the subject spine.
2. Nearby sidecars are discovered and grouped as a sidecar pack.
3. Contract/world material is read separately from provenance or receipt material.
4. Foreign ground is created or selected through explicit capability/service routes.
5. Policy/init-data input is measured and recorded in a measured policy capsule.
6. Runtime evidence is gathered.
7. Local policy decides whether the foreign ground is merely started, merely attested, reviewed, or actually adopted.
8. Foundry records what happened without overclaiming:
   - which subject spine anchored the relation,
   - what sidecars were observed,
   - what policy input was measured,
   - what runtime evidence exists,
   - what adoption class was reached.

## The anti-collapse rules

- Sidecar attachment is not completeness.
- Repository-scope access is not approval.
- Runtime evidence is not adoption.
- Measured policy input is not the whole policy story.
- Subject relation is not live instance identity.

## Why this specimen matters
If Foundry cannot survive this specimen without turning into a registry catalog or a universal runtime descriptor, then the candidate nouns are too big.

If Foundry *can* survive it, then pass VIII has found a promising smaller set:
- subject spine,
- sidecar pack,
- measured policy capsule,
- runtime evidence,
- adoption rail.

That is still only a candidate set, but it is far healthier than one flattened “artifact metadata” story.
