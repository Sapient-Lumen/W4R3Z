# Specimen flow 96 — rule-evaluation trace, applicability witness, and misapplication fence

## Pressure

Specimen 95 makes promoted-rule collisions and precedence choices visible. The next failure is subtler: a precedence witness can be reused as if the winning rule automatically applies to a new carrier, consumer, surface, audience, purpose, or checker context. That launders a rule-choice artifact into a rule-application artifact.

## New nouns

- **Rule-evaluation trace** — a compact record that a named carrier/context was evaluated against a bounded set of candidate, selected, and skipped rules with source collision, precedence, ambiguity, context, output, and blocked-inference residue.
- **Applicability witness** — a scoped proof that a rule was applicable, not applicable, partial, ambiguous, expired, or shadow-only for the specific subject/context in the trace.
- **Misapplication fence** — a refusal card for rule application when context, carrier, consumer, audience, purpose, precedence, rule status, ambiguity fences, skipped rules, or checker contracts do not support reuse.

## Fixture commitment

`fixtures/specimen-96-rule-evaluation/fixture.json` carries six evaluation traces, seven applicability witnesses, and ten misapplication fences. The checker refuses missing source collision ledgers, missing precedence witnesses, missing ambiguity fences, selected rules without applicability witnesses, erased skipped rules, stale/default context, deprecated or shadow activation, and authority/public-release/audit/repair/lifecycle/sibling laundering.

## Refactor twin

This pass also adds `fixtures/checker-contract-index/index.json` and `tools/check_foundry_checker_contract_index.py`. The index is deliberately humble: it ties checkers to runner order, primary fixture/rulebook surfaces, and expected success-output fragments. It prevents the growing harness from hiding a rule evaluation behind an unregistered checker, misleading success message, or runner-order folklore.

## Non-goals

This specimen does not make Foundry a policy engine, feature-flag service, authorization runtime, SHACL processor, OPA server, Cedar evaluator, admission controller, governance registry, compatibility registry, audit product, public-release approval system, repair workflow, lifecycle authority, or sibling-verdict engine.
