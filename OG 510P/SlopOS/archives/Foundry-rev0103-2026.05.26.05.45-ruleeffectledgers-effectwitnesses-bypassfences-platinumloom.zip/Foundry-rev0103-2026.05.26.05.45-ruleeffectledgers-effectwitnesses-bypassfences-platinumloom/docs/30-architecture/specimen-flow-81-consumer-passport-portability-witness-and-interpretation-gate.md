# Specimen flow 81 — consumer passport, portability witness, and interpretation gate

Goal: make cross-consumer reuse of semantic residue explicit without transferring verdicts, sibling authority, or purpose-specific meaning.

## Scenario

A SlopOS support-card dashboard emits Foundry sidecars, refusal receipts, regression locks, and bounded waivers. The same surface is useful to four downstream consumers:

- a SlopOS support workspace;
- an external audit notebook;
- a Ward appraisal queue; and
- a ViewFS projection browser.

The hard case is not copying the artifact. The hard case is copying the interpretation:

- the external notebook treats an operator support hint as audit evidence;
- Ward treats Foundry residue as a trust verdict;
- ViewFS displays a waiver as approval;
- a waiver scoped to one audience is reused for another audience;
- a stable digest is read as stable consumer meaning; or
- SlopOS boundary-family semantics leak into a sibling cube as if Foundry owned them.

## Small seam to prove

### 1) consumer passport

A consumer passport names who is consuming the surface, why, for what audience, what residue it requires, and which inferences are forbidden.

```yaml
consumer_passport:
  passport_family: foundry_consumer_passport_v0
  passport_id: pass_external_audit_notebook_001
  consumer_id: external_audit_notebook
  consumer_kind: external_review_surface
  purpose: review_sampling_only
  audience: reviewer_pair_only
  accepted_surface_kinds:
    - markdown
    - csv
  required_residue_families:
    - semantic_sidecar
    - query_contract_digest
    - result_envelope_digest
    - classification_pin
    - source_cut
    - refusal_receipt
    - waiver_warrant
  forbidden_inferences:
    - waiver_means_approval
    - sidecar_digest_means_truth
    - slopos_operator_hint_means_audit_evidence
```

A consumer passport is not a permission grant, trust verdict, catalog record, or audit opinion.

### 2) portability witness

A portability witness says which residue can travel from a source consumer to a target consumer, and which residue cannot.

```yaml
portability_witness:
  witness_family: foundry_portability_witness_v0
  witness_id: port_slopos_to_external_audit_001
  source_consumer_id: slopos_support_workspace
  target_consumer_id: external_audit_notebook
  artifact_ids:
    - surface_weekly_support_dashboard_001
    - waiver_preview_sidecar_only_drillthrough_001
  portability_class: bounded
  portable_residue:
    - query_contract_digest
    - result_envelope_digest
    - classification_pins
    - source_cut
    - refusal_receipts
  non_portable_residue:
    - slopos_operator_hint
    - ward_appraisal_posture
    - waiver_as_approval
  required_gates:
    - gate_external_audit_interpretation_001
  verdict_transfer_allowed: false
  sibling_authority_transfer_allowed: false
```

Portability is scoped. It is not compatibility folklore.

### 3) interpretation gate

An interpretation gate says what must rerun before a target consumer uses a carried surface.

```yaml
interpretation_gate:
  gate_family: foundry_interpretation_gate_v0
  gate_id: gate_external_audit_interpretation_001
  target_consumer_id: external_audit_notebook
  required_on:
    - before_first_use
    - after_revision_change
    - after_waiver_change
    - after_audience_change
  must_recheck_rules:
    - R-PORT-001-CONSUMER-PASSPORT
    - R-PORT-005-PORTABILITY-WITNESS
    - R-EGRESS-002-NAMED-SEMANTIC-LOSS
    - R-WAIVER-003-SCOPE
  must_preserve_residue:
    - classification_pins
    - source_cut
    - suppression_witnesses
    - query_contract_digest
    - result_envelope_digest
  refused_interpretations:
    - audit_opinion
    - policy_approval
    - ward_trust_verdict
```

The gate prevents a carrier that passed for one consumer from silently passing for another.

## What this specimen proves

- A stable carrier is not a stable interpretation.
- Consumer purpose and audience are semantic residue.
- Cross-consumer reuse requires a portability witness.
- Sibling authority does not travel through Foundry residue.
- Waiver scope must be rechecked when consumer or audience changes.
- Forbidden inferences are as important as portable fields.
- Interpretation gates are local checks, not a universal compatibility registry.

## What this specimen must keep separate

- consumer passport versus permission grant;
- portability witness versus compatibility guarantee;
- interpretation gate versus policy engine;
- portable residue versus portable authority;
- stable digest versus stable meaning;
- external review purpose versus audit opinion;
- Ward appraisal verdict versus Foundry evidence;
- SlopOS boundary semantics versus Foundry projection honesty.

## Promotion gate for these nouns

Do not widen consumer passports beyond fixture-local cross-consumer checks until:

- a second non-SlopOS consumer uses the same passport fields;
- a real sibling cube consumes a portability witness without treating it as a verdict;
- an audience-widening fixture fails without an interpretation gate;
- one expired or scope-mismatched waiver is blocked by consumer-portability checks; and
- generated tamper cases cover missing passport, missing witness, stable-digest reuse, forbidden-inference loss, and authority transfer.

## Why this matters

Foundry has made egress, regression, and exception residue visible. The next danger is reuse: an honest surface for one consumer can become dishonest in another consumer's hands. Foundry needs the handoff to be explicit, bounded, and smaller than verdict, policy, permission, catalog, or audit truth.
