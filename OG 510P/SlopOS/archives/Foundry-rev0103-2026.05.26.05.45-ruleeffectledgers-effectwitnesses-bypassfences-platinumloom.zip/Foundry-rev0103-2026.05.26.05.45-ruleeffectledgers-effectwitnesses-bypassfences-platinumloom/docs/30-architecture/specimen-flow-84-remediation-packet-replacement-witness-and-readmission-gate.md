# Specimen flow 84 — remediation packet, replacement witness, and readmission gate

Goal: make post-recall re-admission explicit without turning Foundry into Helm repair custody, Harbor remediation status, Steward finality, Schell retention policy, ViewFS object identity, Ward verdict, SlopOS source truth, a ticketing system, or a supply-chain attestation authority.

## Scenario

Specimen 83 made invalidation and recall visible. A new failure remains: once a semantic carrier is revoked, teams often treat any later replacement artifact as safe merely because it has a newer id, a fresh digest, or a reassuring name. The old stale surface is quarantined, but the replacement can still be under-evidenced, partial, consumer-mismatched, or missing the replay gates that made the original refusal meaningful.

A SlopOS support workspace recalls a dashboard sidecar because it omitted a required code-drift fence. A repaired sidecar is emitted. External audit and Ward want to use the replacement. A dashboard cache wants to resume serving tiles. Helm sees an intervention trace; Harbor sees a remediation claim. Foundry's narrow question is smaller: does the replacement semantic carrier carry enough evidence to be re-admitted for the named consumer and use, while preserving the old carrier as history and refusing overclaims?

The hard case is not producing a new artifact. The hard case is telling whether:

- the replacement is linked to the exact revocation notice and quarantined carrier;
- the repair action names the semantic loss it corrected;
- the replacement witness preserves old history instead of rewriting it;
- every required sidecar, egress, regression, waiver, portability, delegation, and recall gate replayed;
- consumer scope did not widen from audit to Ward, cache, public dashboard, or sibling verdict;
- partial repair remains partial instead of becoming green status; and
- a later notice can reopen the packet and re-quarantine the candidate.

## Small seam to prove

### 1) remediation packet

A remediation packet groups the recalled carrier, notice scope, quarantined artifacts, proposed replacement candidates, required witnesses, required gates, and non-authority boundaries.

```yaml
remediation_packet:
  packet_family: foundry_remediation_packet_v0
  packet_id: rp_sidecar_classification_pin_loss_001
  packet_digest: sha256:rp001
  packet_status: readmitted
  triggered_by_notices:
    - rn_sidecar_classification_pin_loss_001
  affected_carriers:
    - sidecar_weekly_support_dashboard_001
  affected_consumers:
    - external_audit_notebook
    - ward_appraisal_queue
    - dashboard_cache
  quarantined_artifacts:
    - csv_external_audit_extract_001
    - surface_weekly_support_dashboard_001
  repair_actions:
    - add_missing_code_drift_fence
    - restore_classification_pin_reference
  replacement_candidates:
    - sidecar_weekly_support_dashboard_002
  required_witnesses:
    - replacement_witness_present
    - old_history_preserved
    - source_rows_not_rewritten
  required_gates:
    - R-SIDECAR-004-CLASSIFICATION-PINS
    - R-RECALL-010-REPLAY-BEFORE-REUSE
    - R-READMIT-006-GATE-REPLAY-BEFORE-READMISSION
  authority_boundaries:
    - does_not_assert_source_truth
    - does_not_issue_ward_verdict
    - does_not_claim_harbor_remediation
```

The packet is a re-admission work envelope, not a repair ticket, approval, status page, or truth rewrite.

### 2) replacement witness

A replacement witness names the old carrier and candidate replacement, their digests, the correction classes, evidence refs, replayed gates, residual risks, and non-promises.

```yaml
replacement_witness:
  witness_family: foundry_replacement_witness_v0
  witness_id: rw_sidecar_dashboard_002_001
  packet_id: rp_sidecar_classification_pin_loss_001
  supersedes_notice_ids:
    - rn_sidecar_classification_pin_loss_001
  old_artifact_family: foundry_semantic_sidecar_v0
  old_artifact_id: sidecar_weekly_support_dashboard_001
  old_artifact_digest: sha256:oldsidecar001
  replacement_artifact_family: foundry_semantic_sidecar_v0
  replacement_artifact_id: sidecar_weekly_support_dashboard_002
  replacement_artifact_digest: sha256:newsidecar002
  replacement_status: accepted
  correction_classes:
    - classification_pin_restored
    - code_drift_fence_added
  evidence_refs:
    - fixture/specimen-76-classification-drift
    - semantic_diff_manifest_rev0090_001
  gates_replayed:
    - R-SIDECAR-004-CLASSIFICATION-PINS
    - R-REGRESS-005-LOSS-PROFILE
    - R-RECALL-010-REPLAY-BEFORE-REUSE
  old_history_preserved: true
  source_rows_rewritten: false
  residual_risks:
    - old_csv_remains_historical_only
  non_promises:
    - not_source_truth
    - not_audit_opinion
    - not_harbor_remediation_verified
```

The witness proves replacement relation and replay evidence, not external remediation or completion.

### 3) readmission gate

A readmission gate is consumer-local. It says whether a replacement can be used by a named consumer for named uses, which inputs were checked, which rules reran, which old uses remain blocked, and which inferences stay refused.

```yaml
readmission_gate:
  gate_family: foundry_readmission_gate_v0
  gate_id: rg_external_audit_sidecar_002_001
  packet_id: rp_sidecar_classification_pin_loss_001
  consumer_id: external_audit_notebook
  gate_result: admitted
  candidate_artifacts:
    - sidecar_weekly_support_dashboard_002
  required_inputs:
    - recall_receipt_present
    - replacement_witness_accepted
    - regression_lock_passed
    - interpretation_gate_replayed
  replayed_rules:
    - R-PORT-006-INTERPRETATION-GATE
    - R-RECALL-006-STALE-RELIANCE-FENCE
    - R-READMIT-006-GATE-REPLAY-BEFORE-READMISSION
  notice_status_checked: true
  quarantine_release: true
  admitted_uses:
    - derive_external_audit_csv_v2
  blocked_uses:
    - rely_on_old_csv
    - issue_audit_opinion
    - transfer_to_ward_without_ward_gate
```

The gate releases a narrow use, not the whole carrier for every consumer.

## What this specimen proves

- Replacement is not automatic repair; it needs a packet, witness, and consumer-local gate.
- A repaired carrier must link to the exact notice, old carrier digest, replacement digest, correction class, and replayed rules.
- Quarantine persists until readmission gates pass; a new filename, digest, or dashboard id is not enough.
- Old history remains citeable as recalled/quarantined evidence and is not rewritten into success.
- Partial repair can remain useful without being promoted to completion, Harbor remediation, Helm repair settlement, Ward verdict, or SlopOS truth.
- Consumer scope matters: audit readmission does not admit Ward, dashboard cache, ViewFS projection, or public release.
- New notices can reopen a packet and make a previously accepted replacement unsafe again.

## What this specimen must keep separate

- remediation packet versus repair ticket;
- replacement witness versus automatic repair;
- readmission gate versus approval, audit opinion, Ward verdict, Harbor remediation, or SlopOS proof;
- replacement artifact versus source-history rewrite;
- quarantine release versus Schell retention or deletion;
- Helm repair attempt versus Foundry semantic re-admission;
- Harbor remediation status versus Foundry carrier readmission;
- partial repair versus complete settlement;
- candidate replacement versus accepted replacement;
- consumer-local admission versus transitive permission.

## Promotion gate for these nouns

Do not widen remediation packets, replacement witnesses, or readmission gates beyond fixture-local use until:

- generated tamper cases mutate notice links, old/replacement digests, evidence refs, replayed gates, consumer ids, admitted uses, and quarantine-release posture;
- one real recalled support-card or audit-notebook packet is re-admitted by a replacement witness;
- one partial replacement remains blocked from at least one consumer while admitted for another;
- one later notice reopens an already readmitted packet;
- a second non-SlopOS consumer repeats the same fields without asking Foundry to become a repair workflow, status page, attestation framework, or audit product; and
- readmission gates remain smaller than Helm repair completion, Harbor remediation verification, Ward appraisal, Schell retention, ViewFS custody, Steward finality, or SlopOS proof.

## Why this matters

Foundry can now say a semantic carrier was recalled. Without this specimen, a future editor can make the next lie: "we fixed it" because a replacement name exists. Foundry needs one small machine-checkable layer that says what was repaired, what was witnessed, which gates replayed, which consumer may use it again, and which overclaims are still refused.
