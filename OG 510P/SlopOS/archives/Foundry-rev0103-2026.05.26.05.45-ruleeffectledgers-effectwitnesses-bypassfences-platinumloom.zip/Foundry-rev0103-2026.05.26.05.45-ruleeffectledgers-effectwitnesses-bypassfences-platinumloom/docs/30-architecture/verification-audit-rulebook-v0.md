# Verification audit rulebook v0

This rulebook belongs to specimen 90. It defines tiny fixture-local checks for verification audits, evidence samples, and false-closure fences.

## Rules

- `R-VER-001-VERIFICATION-AUDIT` — every verification claim over fulfillment/completion evidence needs an audit id, digest, status, time window, source fulfillment evidence, scope, sampling basis, required evidence samples, required false-closure fences, verifier posture, and authority boundaries.
- `R-VER-002-SOURCE-FULFILLMENT-LINKAGE` — every verification audit must name source fulfillment receipts, completion witnesses, nonfulfillment fences when relevant, carrier ids, and consumers.
- `R-VER-003-SAMPLING-BASIS` — every audit must state population refs, selection method, sample basis, excluded items, and blocked inferences so a sample cannot masquerade as exhaustive coverage.
- `R-VER-004-EVIDENCE-SAMPLE` — every required sample needs evidence, state, observed time, source completion witness, probe basis, residue checked, contradictions, and non-promises.
- `R-VER-005-SCOPE-TIME-AND-DIGEST-CHECK` — evidence samples may not exceed audit scope, may not be accepted outside the audit window without a fence, and must preserve carrier digest linkage when a carrier is named.
- `R-VER-006-CONTRADICTION-FENCE` — contradicted, inconclusive, stale, unavailable, quarantined, superseded, public, inherited, permission-denied, wrong-scope, or verifier-conflicted samples require a false-closure fence.
- `R-VER-007-COMPLETION-IS-NOT-VERIFICATION` — completion witnesses cannot count as evidence samples unless separate verification/probe evidence exists.
- `R-VER-008-VERIFIER-INDEPENDENCE` — a verifier cannot be the same actor that authored the completion witness unless the fixture explicitly records a verifier-conflict fence.
- `R-VER-009-SAMPLING-NON-EXHAUSTIVENESS` — sampled verification cannot clear unsampled consumers, surfaces, audiences, purposes, or obligations.
- `R-VER-010-NON-TRANSITIVE-VERIFICATION` — verification is not authorization, legal compliance, consent, rights management, adoption, portability, delegation, public release, deletion, retention, cryptographic proof, audit opinion, custody, repair completion, lifecycle finality, or sibling verdict.
- `R-VER-011-AUTHORITY-LAUNDERING-FENCE` — a verification audit or evidence sample must not be laundered into source truth, policy approval, audit opinion, legal basis, repair success, or sibling authority.
- `R-VER-012-HARNESS-COVERAGE` — fixture/checker growth must leave a runnable checker, runner entry, docs pointer, schema pointer, and archive-index entry rather than hand-written prose only.

## Required negative cases

A valid specimen 90 fixture must include failure cases for missing verification audits, missing source fulfillment, missing evidence samples, required sample omitted, completion-as-verification, self-verification without fence, verifier conflict, audit scope mismatch, sample scope mismatch, stale sample accepted, contradiction ignored, partial audit treated as passed, sample digest mismatch, public-link verification without fence, inherited verification without rebinding, verification-as-authorization, verification-as-legal-compliance, verification-as-audit-opinion, verification-as-cryptographic-proof, verification-as-sibling-verdict, and checker harness coverage drift.

## Containment

These rules do not define OSCAL assessment results, continuous monitoring, cryptographic proofs, verifiable credentials, DSSE envelopes, SLSA provenance, in-toto layouts, compliance evidence, legal duties, public release, deletion, retention, custody, repair completion, lifecycle finality, or audit opinions. They only protect Foundry's semantic carriers from being interpreted as verified merely because completion evidence exists.
