# Rule-surface index audit v0

rev0101 adds a small audit/refactor surface for the rulebook layer. The cube now has many rulebooks and many executable checkers. Before this pass, a new rulebook could add rule ids that were present in prose and enforced by a checker, but not machine-visible as a rule surface. That made post-promotion collision analysis depend on humans remembering which rule ids existed.

## What changed

- `fixtures/rule-surface-index/index.json` lists every current architecture rulebook, its specimen binding where applicable, its parsed rule ids, and its checker refs.
- `tools/check_foundry_rule_surface_index.py` parses the rulebooks directly and fails if rule ids, rulebook paths, checker refs, or runner registration drift.
- The index is intentionally smaller than a policy registry: it does not evaluate rules, choose precedence, assign severity, or prove correctness. It only makes the executable/prose rule surface visible enough for specimen 95 collision checks.

## Guardrails

- Rule ids must be unique across rulebooks.
- The index must match the rule ids actually written in the rulebooks.
- Any listed checker must exist and be registered in `tools/check_foundry_all.py`.
- Coverage fixtures must list the rule-surface index so it cannot become an untracked side table.

## Non-goals

No governance registry, no rule engine, no policy product, no compatibility database, no authorization model, no audit evidence, no source-truth verdict, no public-release approval, no repair/lifecycle decision, and no sibling-cube authority.
