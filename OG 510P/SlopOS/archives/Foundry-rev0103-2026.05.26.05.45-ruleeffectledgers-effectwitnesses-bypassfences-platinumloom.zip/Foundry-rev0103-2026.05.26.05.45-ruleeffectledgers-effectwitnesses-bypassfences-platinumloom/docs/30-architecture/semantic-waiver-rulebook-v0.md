# Semantic waiver rulebook v0

This rulebook gives specimen 80 stable names for failures that matter when Foundry carries temporary semantic exceptions.

| Rule | Meaning |
| --- | --- |
| `R-WAIVER-001-WARRANT-REQUIRED` | a waived egress/regression issue must have a waiver warrant |
| `R-WAIVER-002-EXPIRY` | every waiver must have machine-readable issue, expiry, and renewal posture |
| `R-WAIVER-003-SCOPE` | waiver scope must name revision, consumer, surface, cut, and rule ids |
| `R-WAIVER-004-NON-WAIVABLE` | non-waivable residue such as classification pins, source cuts, suppression status, and balance residue cannot be accepted as ordinary semantic loss |
| `R-WAIVER-005-OWNER-REVIEW` | owner and reviewer must be present and distinct |
| `R-WAIVER-006-REPLAY-GATE` | a waiver must name the checks that rerun before use, renewal, or revision carry-forward |
| `R-WAIVER-007-NO-DEFAULT-SUCCESS` | a waiver must never convert a refusal or regression alarm into default success |
| `R-WAIVER-008-LINKED-ALARM` | a waiver must link to at least one refusal receipt or regression lock |
| `R-WAIVER-009-SCOPE-WIDENING` | widening consumer, surface, cut, revision, audience, or rule scope requires a new warrant or review witness |

These rules do not create a policy engine, approval workflow, risk register, exception registry, or sibling-cube verdict system. They only make Foundry's own bounded exceptions testable.
