# Surface inventory rulebook v0

This rulebook belongs to specimen 86. It defines tiny fixture-local checks for surface inventory sweeps, reachability witnesses, and coverage-gap fences.

## Rules

- `R-INV-001-SURFACE-INVENTORY-SWEEP` — every post-distribution closure claim needs a sweep id, digest, status, time window, scope, discovery sources, and method limits.
- `R-INV-002-SCOPE-AND-SEED` — every sweep must name seed distribution manifests, seed carrier ids, expected surfaces, target consumers, and excluded/non-inspectable zones.
- `R-INV-003-REACHABILITY-WITNESS` — every observed surface or copy must leave a witness with digest, path/alias evidence, residue seen, and local limits.
- `R-INV-004-ALTERNATE-ID-RESOLUTION` — aliases, logical names, object paths, and notebook paths must collapse only through explicit alternate-identifier evidence.
- `R-INV-005-EXPECTED-SURFACE-COVERAGE` — every expected surface is accounted for by a reachability witness or a coverage-gap fence.
- `R-INV-006-COVERAGE-GAP-FENCE` — unknown, unlinked, ambiguous, permission-denied, duplicate, stale, or expired inventory gaps must be fenced.
- `R-INV-007-SWEEP-WINDOW-AND-RECENCY` — reachability evidence outside the sweep window cannot close the sweep without a recheck hook.
- `R-INV-008-PARTIAL-SWEEP-NO-CLOSURE` — partial or blocked sweeps must not be advertised as complete distribution closure.
- `R-INV-009-UNKNOWN-SURFACE-NO-ADOPTION` — discovered copies, digest matches, and catalog cards are not adoption receipts.
- `R-INV-010-OWNER-BOUNDARY` — a surface observed under one owner/consumer cannot clear another owner/consumer's expected surface.
- `R-INV-011-AUTHORITY-LAUNDERING-FENCE` — inventory success is not truth, approval, cache policy, custody, deletion, repair, remediation, or audit opinion.
- `R-INV-012-RECHECK-HOOK` — inaccessible or permission-denied zones must name recheck timing or clearance evidence.

## Required negative cases

A valid specimen 86 fixture must include failure cases for missing sweeps, missing seed manifests, missing reachability witnesses, unaccounted expected surfaces, unknown surfaces without fences, unresolved aliases, expired sweep windows, partial sweeps treated as complete, owner mismatch, missing gap fences, witness digest mismatch, discovered-copy-as-adoption, inventory-as-catalog, inventory-as-truth, permission-denied without recheck, and duplicate surface accounting.

## Containment

These rules do not define a catalog product, CMDB, object inventory protocol, package graph, cache purge system, lineage authority, cleanup controller, or sibling-cube status model. They only protect Foundry's semantic carriers from stale, hidden, alias-ambiguous, or unreachable copies after distribution/adoption appears to have succeeded.
