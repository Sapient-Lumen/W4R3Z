# Specimen flow 15 — metadata seal, payload root, and bootstrap debt

Goal: keep structural integrity, payload integrity, and full-locality claims visibly separate.

## Scenario
A foreign realization starts from a small structural image or bootstrap that is already local.
That structure is authenticated as a coherent directory/metadata tree.
File content remains in a backing store or blob set and is verified later through a content-root or fs-verity style check as reads occur.
The program starts quickly, but full locality has not yet arrived; later cold reads and reacquisition still belong to the public story.

## Proposed Foundry objects
1. **metadata seal**
   - explicit integrity story for structure, naming, directory relationships, and metadata posture;
   - stronger than “it mounted” and weaker than full adoption.

2. **payload root**
   - compact witness for foreign-backed file bytes or chunk sets;
   - keeps content verification visible without pretending structure was solved by the same mechanism.

3. **bootstrap debt**
   - the remaining non-locality or deferred fetch cost after startup succeeds;
   - useful because fast start is smaller than full realization.

4. **seal split**
   - standing reminder that structural authenticity and payload authenticity are different truths.

## Why this specimen matters
It pressure-tests whether Foundry can remain honest when:
- a structural image is already local,
- payload bytes remain elsewhere,
- runtime reads verify content lazily,
- and startup succeeds before full locality arrives.

## Promotion rule
Do not promote `metadata seal`, `payload root`, `bootstrap debt`, or `seal split` unless they improve:
- one structure-authentic but payload-remote specimen,
- one payload-verified cold-read specimen,
- and one startup-before-full-locality specimen.
