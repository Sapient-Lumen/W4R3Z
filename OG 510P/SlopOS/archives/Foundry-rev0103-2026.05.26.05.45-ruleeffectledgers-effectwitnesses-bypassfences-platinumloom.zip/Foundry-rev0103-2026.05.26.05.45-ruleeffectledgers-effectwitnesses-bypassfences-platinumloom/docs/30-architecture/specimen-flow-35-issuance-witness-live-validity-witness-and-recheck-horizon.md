# Specimen flow 35 — issuance witness, live-validity witness, and recheck horizon

Goal: keep exact issued evidence separate from current validity, and keep current validity separate again from how long the last good answer remains fresh enough.

## Scenario
A foreign-backed realization receives or stores one exact artifact: a capability-lease descriptor, access token, certificate, signed receipt, or comparable provider-issued witness.
That artifact is still byte-for-byte real.
The tempting mistake is to read it as a portable oracle of present authority.

There are three validity classes that many systems flatten if they only say “token”, “certificate”, or “grant”.

First, there is an **issuance witness**.
It records what was actually minted or granted.
It can stay exact historical evidence even after the live grant changes or dies.
That keeps “what was issued” distinct from “what is still allowed now”.

Second, there is a **live-validity witness**.
A protected resource, provider, or current status surface may have to say whether the thing remains active, non-revoked, non-expired, and valid for this exact context now.
That keeps present acceptability separate from artifact possession.

Third, there is a **recheck horizon**.
One positive validity answer is still a time-bounded statement.
Even if the answer was good when checked, a later decision may need re-introspection, fresher revocation/status material, or a newly issued short-lived artifact.
That keeps “was good recently” distinct from “is still good enough now”.

This preserves three truths:
- exact issuance evidence,
- current validity in one decision context,
- and the freshness limit on old positive-validity knowledge.

## Proposed Foundry objects
1. **issuance witness**
   - exact minted descriptor/proof/receipt for one once-approved foreign artifact shape;
   - keeps issuance history visible without overclaiming present liveness.

2. **live-validity witness**
   - current authoritative statement that the thing remains active/usable for one context now;
   - keeps current acceptability separate from possession and separate from historical receipt trails.

3. **recheck horizon**
   - explicit limit after which old positive-validity knowledge is too stale and recheck or reissuance becomes the honest path;
   - keeps cached good news smaller than durable authority.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- a descriptor or token remains exact about issuance while current permission has changed;
- revocation or expiry happens elsewhere and the old artifact still circulates;
- status answers are cacheable or explicitly time-bounded;
- and systems choose between direct introspection, pushed status lists, or short-lived artifacts to keep current-validity truth manageable.

## Adjacent but parked
- **revocation digest** — future compact residue for locally remembered invalidation material.
- **short-life badge** — future compact residue for “fresh replacement is the intended validity model”.

## Promotion rule
Do not promote `issuance witness`, `live-validity witness`, or `recheck horizon` unless they improve:
- one companion-cube specimen where exact issued material is explicitly smaller than current provider-owned state;
- one outside-system specimen where current validity must be queried or rechecked separately from the original artifact;
- and one short-lived-or-status-list specimen where the freshness window itself is part of the honest story.
