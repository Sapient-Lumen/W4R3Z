# Specimen flow 24 — state epoch, migration cut, and reset rail

Goal: keep “this basis is installed/booted/current” separate from “persistent state is still in a compatible semantic world for it”.

## Scenario
A subject installs and blesses a new basis.
Its persistent state lives in `/var`, a data partition, an object store, or another durable region that is intentionally not replaced along with the basis.
That durable region currently belongs to **state epoch** `E4`: not merely a version string, but the semantic/data-format world the new basis must read.

The new basis may be able to read `E4` directly, or it may need to cross a **migration cut** that rewrites or reclassifies state into `E5`.
That cut might happen during install, first boot, post-boot convergence, or a later explicit maintenance action.
It is a different event from download, activation, bless, and rollback-floor ratchet.

Now suppose operators need to roll the basis back.
The older basis may still be an ordinary rollback target at the basis level, but it may no longer understand state epoch `E5` cleanly.
At that point the honest path may be a visibly separate **reset rail**: wipe/reseed/reinitialize durable state, restore from a separate backup, or boot a recovery flow that rebuilds state instead of pretending seamless continuity.

This keeps basis currentness, state compatibility, migration, and reset visibly distinct.

## Proposed Foundry objects
1. **state epoch**
   - semantic/data-format epoch that persistent state currently belongs to;
   - distinct from basis revision, served API version, or rollback floor.

2. **migration cut**
   - explicit event or receipt where persistent state crosses into a new epoch;
   - may happen during install, post-install, first boot, or later maintenance, but should not hide inside “update succeeded”.

3. **reset rail**
   - explicit non-continuous path for wipe/reseed/reinitialize behavior when compatibility or rollback cannot preserve continuity honestly;
   - should remain visibly different from ordinary rollback and from rescue paths that preserve state.

## Why this specimen matters
It pressure-tests whether Foundry can stay honest when:
- basis updates do not automatically rewrite shared mutable state,
- new bases can sometimes read old state without rewriting it,
- migration can be explicit, delayed, or operator-triggered,
- and rollback may require reset rather than smooth continuity.

## Adjacent but parked
- **read corridor** — compact promise that a basis can safely read an older state epoch without rewriting it.
- **migration witness card** — compact residue about whether migration happened, was deferred, or was avoided.

## Promotion rule
Do not promote `state epoch`, `migration cut`, or `reset rail` unless they improve:
- one shared-state / no-copy-on-upgrade specimen,
- one explicit storage- or config-migration specimen,
- and one rollback-or-recovery specimen that requires reset or reseed instead of pretending continuity.
