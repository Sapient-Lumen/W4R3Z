# Research synthesis — pass LX

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from dimensional modeling, cloud cost allocation practice, and shared-infrastructure telemetry: **a value that comes from splitting a shared total should not pretend to be a native fact unless the cube can say what split rule produced it, what residue stayed special, and what comparisons or re-aggregation remain lawful.**

The smallest durable seam from this pass is:
- **allocation basis** — the compact witness for the rule that split a shared total: uniform split, proportional to reserved capacity, proportional to observed usage, explicit custom metric, provider-native allocation, or explicit none/native row;
- **residue class** — the compact witness for what portion of the source amount stayed special: idle, overhead, unallocated, unused commitment, rounding residue, or another explicitly bounded remainder posture;
- **apportionment fence** — the compact witness for how apportioned rows may be reasoned about: conserves source total under the same basis, explanatory/view-only split, same-basis-only comparison, or forbidden to flatten back into native-fact truth.

These are still smaller than a chargeback engine, a universal allocation DSL, or a full finance semantics plane.
They simply keep future Foundry rows from laundering apportionment choices into fake native truth.

## Lessons we must learn from the past

### 1) Many-to-many groupings over-count unless weighting or allocation is explicit
Kimball’s bridge-table guidance is direct: a single fact row can be associated with multiple dimension rows, and grouping through that bridge can over-count unless an allocation or weighting factor is assigned.
The lesson is broader than dimensional modeling.
Whenever a future cube row is a split of some shared whole, the split rule belongs in meaning, not just in ETL folklore.

### 2) Shared-cost truth usually needs a workload-aware split, not a black box bill
FinOps guidance for managing shared cloud costs argues that organizations must move beyond black-box billing toward an execution-aware model that links shared substrate spend to consuming workloads.
The lesson for Foundry is that a friendly shared-cost row is smaller than the underlying substrate truth unless the basis of the split is carried beside it.

### 3) Idle, overhead, and shared portions are not interchangeable leftovers
OpenCost’s specification distinguishes cluster asset costs, overhead costs, shared costs, and idle costs, and it explicitly allows different methods for distributing shared costs such as uniform allocation, proportional allocation, or a custom metric.
The lesson is that the unsplit or specially treated remainder deserves its own **residue class** rather than being silently folded into one recipient’s row.

### 4) Allocation methodology should be visible, not inferred from outputs
FOCUS’s recent specification work adds allocation-specific columns so data generators can expose how shared costs were split, not just what numbers came out.
That is a strong reminder that once Foundry emits apportioned values, it should preserve the compact rule witness instead of forcing future readers to reverse-engineer methodology from totals.

## What to steal now
- an **allocation basis** beside any future apportioned spend, usage, capacity, or burden row;
- a **residue class** so idle, overhead, unallocated, unused, and rounding leftovers do not disappear into one flattering per-subject total;
- an **apportionment fence** so same-basis conservation stays visibly different from cross-basis comparison or view-only splits;
- and a habit of treating “directly measured on subject” as different from “allocated to subject” even when both share the same unit.

## What to keep parked
Do not yet promote:
- a universal cost-allocation or chargeback engine;
- one cube-wide weighting/algebra DSL;
- automatic re-allocation of every shared residue;
- a full valuation, FX, or accounting plane;
- or a claim that every apportioned row can be losslessly recombined across arbitrary bases.

## Resulting recommendation
The next healthy move is not “build a full shared-cost model inside the cube.”
It is to let Foundry say, for any future apportioned family:
1. which **allocation basis** produced the visible row,
2. which **residue class** remained outside or specially treated,
3. and what **apportionment fence** limits re-aggregation or comparison.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from Kimball, FinOps, OpenCost, and FOCUS.
