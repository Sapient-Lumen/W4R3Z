# SlopOS and companions evaluation — pass XVIII

This pass keeps Foundry aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** keeps the foreign-cell contract explicit and the microVM adjunct family honest about restore class, template availability, and generation witness. That argues for keeping compatibility witness and detachable layer truth explicit rather than flattening them into “works on this machine”.
- **SlopOS** also keeps warm-state and foreign-ground meanings local, which matches the idea that a successful attach still should not become native base truth.
- **ViewFS** keeps handles, refs, fragments, and materialization distinct, which supports a structure/cargo split instead of one giant package blob.
- **Helm** still wants operator truth that can say what is native, attached, or merely projected.
- **Schell** still wants live checkout and adoption gates, which makes detachability and rollback more than academic.
- **Ward** still wants runtime evidence smaller than final trust, which fits keeping compatibility witness smaller than adoption.

## Pressure on Foundry
Foundry should not decide yet whether compatibility witness belongs inside artifacts, handles, or realization objects.
The stronger move is to keep one more specimen where:
1. a foreign layer is compat-checked before attach,
2. the attach is detachable and rollback-capable,
3. structure and backing cargo have different integrity or locality stories,
4. and adoption does not overclaim base assimilation.

## Promotion restraint
Do not promote `extension witness`, `detachable layer`, or `backing cargo` unless they improve:
- one compat-checked attach specimen,
- one detach/rollback specimen,
- and one structure/cargo split specimen.

