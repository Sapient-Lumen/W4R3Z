# Research synthesis — 2026-03-23 pass VIII

This pass focused on another way foreign-ground designs overclaim: they often gather beautifully attached evidence and then quietly act as if attachment solved realization truth.

## New lessons from outside systems

### 1) Subject-attached sidecars are a strong anti-bloat pattern
The OCI artifacts/referrers ecosystem is a powerful design hint. A referrers API can return artifacts that have a `subject` of a given manifest digest, letting related artifacts stay attached to a primary digest without stuffing every concern into one manifest. Foundry should steal the **subject spine** idea while refusing to treat attached sidecars as proof of completeness or approval.

### 2) Repository scope is useful, but still not verdict
OCI/ORAS guidance also makes a subtle point: referrers are scoped to a repository, so access rights for the repository can authorize access to the referenced artifacts. That is operationally elegant, but Foundry should keep **repository scope** smaller than **local realization verdict**.

### 3) Explicit contract worlds still matter even when sidecars get fancy
The Wasm component model keeps reminding Foundry that interfaces, worlds, and the canonical ABI are how foreign contracts stay honest across languages and implementations. Sidecars should not become an excuse to go vague about the core contract.

### 4) Measured policy input belongs in the foreign-ground story
Confidential Containers remains especially useful here: init-data integrity is part of the attestation story, and downstream resource policy may check measured init-data claims before releasing secrets. Foundry should keep policy input visible even when the foreign ground looks smooth.

### 5) Cross-domain service routes still beat ambient reachability
Qubes qrexec and Fuchsia capability routing keep supplying the same anti-lesson: explicit service/capability routes are healthier than pretending the foreign ground simply “has access” because the product wants it.

## New lessons from SlopOS and companions

### SlopOS
- `provenance-container-selection-boundary-v0.md` already warns against letting one bundle of attached statements silently settle reconciliation.
- `artifact-resolution-posture-v0.md` continues to reinforce that locators and nearby metadata are hints until explicit retrieval and verification occur.
- `init-snapshot-posture-v0.md` and `microvm-generation-witness-posture-v0.md` remain strong guards against confusing boot-time description, warm-state continuity, and restored instance truth.
- The transparency/provenance import boundaries continue to support pass VIII’s core restraint: attached evidence helps, but local realization meaning still needs explicit appraisal.

### Siblings
- Harbor keeps reminding Foundry that the membrane story and the realization story should remain separately truthful.
- Ward keeps evidence, appraisal, and consequence distinct, which matters even more once sidecars make evidence easy to collect.
- ViewFS again supplies the best analogy: attachment, identity, and durable local objecthood are different strengths.
- Helm and Schell continue to help by turning adoption and capability-routing residue into inspectable product surfaces.

## Brilliant ideas worth stealing carefully

1. **Subject spine** — the primary digest as a stable anchor for nearby sidecars without pretending one giant manifest knows everything.
2. **Sidecar pack** — a grouped set of nearby evidence/contract/policy artifacts that remains visibly incomplete by default.
3. **Measured policy capsule** — a compact record of which policy input was integrity-bound into the realization story.
4. **Adoption rail** — explicit started / attested / reviewed / adopted stages even when sidecars look neat and complete.
5. **Repository-scope warning** — a reminder that shared repository authorization is operational convenience, not final local acceptance.

## Current recommendation
Foundry still should not freeze a universal runtime descriptor.

The safer move is:
- keep artifact spine, contract world, subject-attached sidecars, measured policy input, runtime evidence, and adoption visibly separate;
- use specimen flow 05 to test whether subject-spine and sidecar-pack language belongs inside Foundry’s durable vocabulary;
- and only promote the nouns that survive both OCI-style and confidential-runtime-style specimens.
