# SlopOS / companions evaluation — pass XXIII

Foundry still looks justified as its own companion cube, and this pass sharpens a neighboring seam that SlopOS already pressures from another direction: **floating selection intent versus exact mutable basis**.

## What the current cube ecology keeps proving
- **SlopOS** already resists sticky head-following approval. `approval-basis-posture-v0.md` is explicit that approval binds one exact action, not whatever the current head/revision/queue entry becomes later. That means Foundry should not invent a cozy “follow stable” truth that silently inherits new basis after drift.
- **SlopOS** is still in the design phase, which makes this split especially cheap and valuable to keep now. If early update or realization surfaces start speaking as though refs, channels, or cohorts were themselves exact basis truth, later docs will quietly train the archive toward hidden drift and accidental latest-wins semantics.
- **ViewFS** benefits because it already keeps references, live handles, and receipts distinct; moving selectors versus exact basis pins are the same kind of honesty move.
- **Helm** benefits because request, admitted, live, and historical truth are already kept separate; a floating selector should stay with request/history until a pin is bound.
- **Steward** benefits because chooser surfaces already pressure visible selection toward exact selectors and anchors rather than ambient text folklore.
- **Ward** benefits because success or cohort metadata can remain useful evidence without being mistaken for durable exact currentness.

## Pressure on Foundry
Foundry should not decide yet whether `follow selector`, `basis pin`, and `drift fence` belong under artifact identity, live realization, or continuity residue.
The stronger move is to keep one specimen where:
1. an operator chooses a moving branch/channel/ref,
2. the system resolves that to one exact basis pin,
3. the selector later drifts,
4. and prior review or preparation is explicitly fenced instead of silently following.

## Collected but parked ideas
This pass also surfaces one good adjacent idea that should stay parked:
- **selector snapshot** for historical “what did this selector resolve to then?” residue.

That idea is real, but it does not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `follow selector`, `basis pin`, or `drift fence` unless they improve:
- one moving-ref or moving-branch specimen,
- one channel-with-exact-version-pin specimen,
- and one mutable-basis approval specimen.
