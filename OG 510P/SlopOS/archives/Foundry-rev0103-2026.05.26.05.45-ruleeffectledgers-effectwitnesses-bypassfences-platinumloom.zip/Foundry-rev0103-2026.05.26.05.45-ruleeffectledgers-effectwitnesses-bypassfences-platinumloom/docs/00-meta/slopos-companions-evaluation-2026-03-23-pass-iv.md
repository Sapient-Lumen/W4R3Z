# SlopOS and companion-cube evaluation — 2026-03-23 pass IV

## Lessons to steal from SlopOS
- `foreign-cell-contract.md` is effectively a miniature constitution for Foundry: no ambient channels, portalized interop, closed ABI surface, policy-killable lanes, and non-authoritative configuration.
- `microvm-snapshot-posture-v0.md` and related template/resume-class documents are the strongest anti-overclaiming material in the current ecology. Foundry should keep learning from them instead of reinventing snapshot folklore.
- `microvm-attestation-reacquire-posture-v0.md` is a key bridge to Ward: continuity changes can invalidate freshness-bound evidence and secret-release sessions without forcing a total narrative collapse.

## Lessons to steal from siblings
- **Harbor**: a crossing into foreign ground still needs an honest admission/aftermath story.
- **ViewFS**: package, carrier, and realized object truth must remain separate.
- **Helm** and **Schell**: remembered or projected state should not outrun what the system can still prove live.
- **Ward**: runtime claims and appraisal consequences should never collapse into the same layer.

## Process result
Foundry should keep promoting **one visibly different specimen at a time** and let general vocabulary emerge only after repeated survival across very different grounds.
