# SlopOS + companions evaluation — pass LXI

This pass checks whether **adjunct namespace, schema pin, and promotion gate** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant semantic layer, a universal lineage plane, or a hard global metadata registry.

## Why SlopOS pressures this seam now

### 1) SlopOS is already producing candidate support semantics before its core datacube is settled
The current SlopOS materials already separate payer authority, observational quota summaries, worker-pool sponsor posture, and imported/provider-facing accounting surfaces.
That means design pressure will arrive first as support/export/import metadata long before one stable core cube ontology is deserved.
Those candidate fields need a place to live without impersonating permanent truth.

### 2) Provider imports and support tiles will want provisional methodology and completeness residue
A future SlopOS support tile may reasonably want fields like import completeness, allocation methodology code, unblended-versus-amortized source posture, or advisory acceleration hints.
Those can be brilliant ideas.
They are also exactly the sort of ideas that should begin life as namespaced adjuncts with pinned meaning rather than instantly becoming top-level cube law.

### 3) Runtime observations and design-time declarations will diverge in healthy ways
SlopOS is still in design motion, so some metadata will describe intended support shapes or export proposals while other metadata will describe what a run, import, or derived view actually produced.
Foundry needs to preserve that distinction instead of forcing one flattened “metadata” family.
A **promotion gate** lets design-time proposal, observed usefulness, and durable adoption remain visibly different.

### 4) Companion cubes already warn against flattening projection-sized truth into core ontology
Ward’s current hybrid-seam work is a good neighboring reminder that raw, downsampled, and stitched views should not silently impersonate one native truth family.
That same caution applies here: exported convenience fields, lineage hints, or acceleration choices are useful, but they are still smaller than core cube semantics unless repeated pressure proves otherwise.

### 5) Column lineage and branch experiments are likely to be useful before they are universal
It is plausible that one SlopOS-adjacent support flow will benefit from column-level drill-through or one imported dataset branch/tag experiment.
It is not yet plausible that Foundry should freeze a mandatory global column-lineage ontology or a universal branch semantics plane.
That is exactly why this seam is the right size.

## What to steal into Foundry

### adjunct namespace
A compact namespaced lane for provisional metadata.
Examples:
- `support.finops.v1`
- `import.provider.aws_cur.v0`
- `lineage.columns.v0`
- `accel.rollup_hint.v0`

This is smaller than a permanent ontology.
It only stops local experiments from pretending to be universal facts.

### schema pin
An immutable pointer to the exact adjunct meaning.
Examples:
- pinned JSON schema URL
- git-tagged schema path
- content-addressed schema hash
- exact doc revision path

This is smaller than a central schema bureaucracy.
It simply keeps meaning from drifting under a stable-looking field name.

### promotion gate
A compact posture for where one adjunct currently stands.
Examples:
- `local_experiment`
- `cross_surface_candidate`
- `promoted`
- `rejected`
- `superseded`

This is smaller than a heavyweight governance workflow.
It just keeps proposal, adoption, and retirement visibly different.

## Why this seam is small enough now
It does **not** require:
- one final semantic-layer taxonomy for all of SlopOS;
- one mandatory column-lineage or dataset-lineage graph;
- one universal adjunct registry with heavy approvals;
- or a claim that every provisional import/export field deserves permanent first-class status.

It only says that once Foundry carries experimental metadata, it should preserve:
1. **which namespace owns the idea**,
2. **which exact schema defines the meaning**,
3. and **what promotion posture the idea currently has**.

## Recommended Foundry posture
Promote **adjunct namespace**, **schema pin**, and **promotion gate** as a narrow honesty seam for design-phase imported fields, export-only support metadata, lineage hints, acceleration hints, and other provisional semantics.
Keep the larger semantic-layer, lineage-graph, and governance-registry questions parked.

This matches current SlopOS discipline well: SlopOS is still early enough that the healthiest move is to capture promising ideas without pretending they are settled.
