# SlopOS plus companions evaluation — pass XLVI

This pass adds one more datacube warning:
Foundry should model **which population a result speaks about** before it treats neighboring counts as if they share one denominator or one partition.

## SlopOS
SlopOS already contains several surfaces that naturally produce counts or sets, but they do **not** all speak about the same population or the same completeness posture.

`RFC-0100` keeps attribute queries and smart folders **view-scoped**, **snapshot-first**, and **handle-returning**.
That means a match count belongs to one explicit reachable view and one query digest, not to a global platform inventory.

`RFC-0075` keeps inspect trees and support bundles **snapshot-shaped** and **bounded**.
An inspect-derived count therefore belongs to one snapshot scope and one capture cut, not to an ambient always-current universe.

`D-SKB posture v0` keeps hardware knowledge on an explicit fact base with **named, bounded queries** rather than a free ambient inventory tree.
So any count or list returned by SKB reasoning belongs to one fact epoch and one bounded query shape, not to “all hardware everywhere forever.”

These are excellent pressures for Foundry.
The datacube should not flatten them into one generic total or allow shell/UI buckets to masquerade as disjoint partitions when they may overlap or be incomplete.
At minimum it should be able to say:
- this result speaks about components reachable through view `V`;
- this result speaks about one inspect snapshot/bundle scope;
- this result speaks about one explicit fact epoch and named SKB query;
- and the compared categories are either disjoint, overlapping, or not yet proven.

## Ward
Ward continues to supply the right process reminder: source review, explicit noun promotion, and honest read-surface discipline matter more than attractive early schema closure.
That is especially valuable here because denominator and overlap mistakes often look plausible until much later.

## Steward and Harbor
Steward’s freshness/posture discipline and Harbor’s convenience-view restraint map directly onto coverage witness pressure.
A lagging, cached, or audience-shaped result is still useful, but it should stay visibly smaller than a full-population claim.

## Resulting judgment
Promote only the following small seam in this revision:
1. **population frame** — what eligible universe a value or result actually speaks about;
2. **overlap class** — whether compared buckets are disjoint, overlapping, primary-picked, or still unknown;
3. **coverage witness** — whether the observed set is full-frame, subset, sampled, lagging, or backed by an explicit possibility set.

Keep parked for now:
- a universal denominator registry;
- automatic overlap allocation/weighting policy;
- forced primary-category rules;
- global percentage semantics;
- and any promise that smart-folder or snapshot counts are ambient inventory truth.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the datacube a safer path to future percentages, distinct counts, and category rollups without premature schema freeze.
