# Research synthesis — 2026-03-23 pass X

This pass focused on a Foundry failure mode that gets worse as tooling gets nicer: nearby evidence, routed power, and live foreign realization start feeling like one package-shaped thing.

## New lessons from outside systems

### 1) OCI subject/referrers keep nearby evidence attached but still separate
OCI 1.1’s `subject` and referrers are valuable because they let signatures, attestations, and other nearby artifacts gather around a subject digest without pretending that the attachment neighborhood is the same as what finally ran. Foundry should preserve the option for a **sidecar closure** that stays smaller than realization.

### 2) WIT resources keep exterior implementation honest
The component model’s resource concept is still one of the cleanest models for “pleasant to use, still exterior.” Foundry should keep host-backed or foreign-backed things visibly exterior through typed claims and handles.

### 3) Capability routing plus configuration routing should be explicit inputs
Fuchsia’s capability and configuration surfaces remain a strong lesson: external power and structured configuration should be routed, inspectable inputs, not hidden host folklore. Foundry should consider a **resource warrant** that says what routed power and structured config were actually present.

### 4) Confidential release still depends on policy split
Confidential Containers continues to distinguish attestation-service policy from resource-release policy. Foundry should keep nearby evidence, routed power, attestation outcome, and secret/resource release visibly different.

## New lessons from SlopOS and companions

### SlopOS
- The component-manifest, capability-routing, and foreign-ground posture files still argue for explicit routing and lintable declarations over ambient host assumption.
- The snapshot/generation-witness and restore-repair cuts continue to reinforce humility: smooth realization is not yet durable continuity.
- SlopOS’s boundary discipline still suggests that package neighborhood, declared contract, routed power, and adoption should not collapse.

### Siblings
- Harbor keeps membrane truth smaller than realization truth.
- Ward keeps evidence and release distinct, which matters even more once sidecars and attached attestations feel complete.
- Helm and Schell both support inspectable adoption and explicit helper/foreign residue.

## Brilliant ideas worth stealing carefully

1. **Sidecar closure** — the nearby set of evidence/contract artifacts attached to a subject, still smaller than live realization.
2. **Resource warrant** — a typed claim about which routed powers, handles, and structured config were present at launch.
3. **Foreign lease** — a temporary right to use foreign ground or foreign-backed resources without claiming native permanence.
4. **Launch closure** — a small truthful object about artifact, contract, routed power, and nearby evidence at launch time.
5. **Reacquire warrant** — explicit proof that some exterior resource had to be reacquired after resume or reattachment.

## What pass X should not decide yet

Foundry still should not decide:
- whether sidecar closure is a first-class object or just a subject-neighborhood view;
- whether resource warrants belong with launch receipts or as separate routed-power objects;
- whether foreign lease is a general runtime noun or only a narrow honesty tool for explicit adoption.
