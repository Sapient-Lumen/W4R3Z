# Research synthesis — pass LXVIII

This pass stays conservative.
Foundry still should **not** freeze one archive-wide denominator catalog, one universal per-X doctrine, or one flattering rule that any visible percentage can be re-sliced and re-aggregated safely.
But it can steal one more durable lesson from current semantic-layer ratio docs, monitoring math, BI display-calculation behavior, and classic coverage-table discipline: **a design-phase datacube needs to say what the denominator was, how numerator and denominator were aligned, and when the visible ratio is only a display overlay rather than reusable cube truth.**

The smallest durable seam from this pass is:
- **denominator basis** — the compact statement of what the visible ratio divides by: distinct subject population, eligible subset, activity count, coverage/opportunity set, exposure time, common-dimension joined metric, or another reviewed basis;
- **normalization lane** — the compact statement of how numerator and denominator were aligned before division: same-grain direct aggregate, common-dimension joined subqueries, weighted recompute from retained parts, coverage-minus-activity comparison, or display-only compare-to-total;
- **ratio fence** — the compact statement of what later re-slicing or recomputation is still lawful: recompute-from-parts only, same frame only, same eligibility filter only, display-only not reusable, or forbidden.

These are still smaller than a universal KPI layer, one mandatory denominator registry, or a built-in formula language for every dashboard percentage.
They simply stop helpful ratios from hardening into dishonest facts.

## Lessons we must learn from the past

### 1) A ratio needs an explicit numerator and denominator, not one friendly metric name
Current dbt ratio-metric docs are refreshingly explicit: a ratio metric names a numerator and a denominator, and when those live in different semantic models dbt computes them in subqueries and joins on common dimensions before dividing.
That is exactly the lesson Foundry should steal.
A visible rate or percentage should preserve **which denominator basis** it used instead of pretending the “per” is obvious from the label.

### 2) Some ratios are already-aggregated views, not reusable raw facts
Current Looker Studio docs say some ratio metrics are already aggregated before the product sees them, and the product can fail with “Unable to aggregate ratio metrics” when a later filter/calculated-field step would require recalculating them.
That is useful pressure for Foundry.
A visible ratio may be a valid answer for one lens while still being the wrong substrate for later regrouping.
That is precisely where a **ratio fence** belongs.

### 3) Honest averages and service-level ratios are usually recomputed from retained parts
Current Prometheus histogram guidance keeps averages honest by deriving them from `_sum` and `_count`, and its Apdex example explicitly corrects for cumulative bucket overlap.
That is a very strong model for Foundry’s **normalization lane**.
Some visible ratios should be recomputed from retained pieces rather than treated as atomic facts.

### 4) Precomputed quantiles are a warning against denominator folklore
The current OpenMetrics spec says precomputed quantiles should not be used because quantiles are not aggregatable and users often cannot deduce the timeframe they cover.
That is exactly the warning Foundry needs.
A friendly percentile, score, or rate can hide enough missing denominator/window truth that the safest answer is to preserve the computation posture and refuse later re-aggregation.

### 5) “What didn’t happen” needs a possibility set, not just observed activity
Kimball’s factless coverage-table guidance remains load-bearing here: absence/completeness queries need both a coverage table of possibilities and an activity table of what happened.
That is denominator hygiene in classic form.
A future percentage such as “coverage completed” or “controls with attached evidence” needs an explicit opportunity set rather than one flattering activity-only denominator.

### 6) If sum or avg over labels is not meaningful, split the family
Current Prometheus naming guidance says a metric should represent the same logical thing across label dimensions, and as a rule of thumb either the sum or avg over all dimensions should be meaningful; otherwise the data should be split into multiple metrics.
That fits Foundry directly.
If two visible percentages depend on different denominator bases, they should not impersonate one reusable measure family.

## What to steal now
- a **denominator basis** field or adjunct that says what the ratio divided by;
- a **normalization lane** that says whether numerator and denominator came from the same native grain, common-dimension subqueries, coverage-vs-activity comparison, or another reviewed alignment;
- a **ratio fence** that blocks later filters, drilldowns, or regrouping from treating a display/comparison ratio as raw truth;
- a habit of preserving **ratio parts** (sum/count, numerator/denominator, satisfied/eligible, covered/possible) when later recompute may be needed;
- and a habit of treating **percent-of-total / compare-to-max / already-aggregated source ratios** as display overlays unless a stronger reviewed seam says otherwise.

## What to keep parked
Do not yet promote:
- one archive-wide denominator registry;
- one universal weighted-average or ratio algebra;
- one permanent KPI namespace for every “per user”, “percent complete”, or “coverage” family;
- or a promise that any visible percentile, rate, or percent can always be safely re-aggregated.

## Resulting recommendation
The next healthy move is not “teach Foundry every ratio trick from dbt, Looker Studio, Prometheus, and Kimball.”
It is to let Foundry say, for denominator-sensitive families:
1. **what the denominator was,**
2. **how numerator and denominator were aligned,**
3. and **whether the visible ratio is reusable or only display-valid for this lens.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart restraint from current metrics, BI, and monitoring practice.
