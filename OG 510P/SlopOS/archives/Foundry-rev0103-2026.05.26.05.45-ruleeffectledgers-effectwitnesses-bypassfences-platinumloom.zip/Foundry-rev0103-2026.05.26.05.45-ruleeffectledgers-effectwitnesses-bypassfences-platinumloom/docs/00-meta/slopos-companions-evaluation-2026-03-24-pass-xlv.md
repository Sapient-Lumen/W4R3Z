# SlopOS plus companions evaluation — pass XLV

This pass adds one more cautionary datacube lesson:
Foundry should model **what kind of value it is looking at** before it models a broad measure catalog.

## SlopOS
SlopOS already contains several neighboring surfaces that look numerically adjacent but should not collapse into one grain.

`RFC-0015` keeps **CH-TRACE** intentionally event-shaped and small.
`RFC-0018` gives hardware-fact evolution an explicit event log with monotonic sequence.
`RFC-0075` treats inspect trees and diagnostic bundles as **snapshots** rather than counters.
`RFC-0100` keeps attribute-query and smart-folder results as query/view-shaped outputs, not as an ambient background inventory oracle.

That is excellent pressure for Foundry.
The datacube should not pretend these are all just “facts” of one kind.
At minimum it should be able to say:
- this row is one event-like observation;
- this row is one snapshot/state observation;
- this row is one query-result surface derived from underlying observations.

## Ward
Ward continues to supply the right process reminder: source review and noun promotion discipline matter more than attractive schema growth.
That is especially valuable here because accumulation and reduction mistakes often hide inside friendly dashboards until much later.

## Steward and Harbor
Steward’s freshness and lane posture remain useful reminders that derived read surfaces should stay visibly smaller than source truth.
Harbor reinforces the same meta-lesson: convenience views should not silently become the meaning model.
That maps directly onto pre-aggregations, incident summaries, and query-result counts.

## Resulting judgment
Promote only the following small seam in this revision:
1. **grain card** — what one value-bearing row means;
2. **accumulation class** — snapshot, delta, cumulative, or another clearly bounded posture;
3. **reduction fence** — what reductions are legal, approximate, or derived-only.

Keep parked for now:
- a universal metric or measure catalog;
- a global unit registry;
- approximate-sketch defaults baked into the cube;
- query-result counts promoted automatically into atomic truth;
- and any promise that every value-bearing family can share one reduction story.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the cube a safer path to future aggregation without premature schema freeze.
