# Research synthesis — pass XXXIII

This pass keeps the next seam deliberately narrow: **exposure frontier / stability fence / withheld tail**.
The outside systems do not agree on one control plane, but they keep rediscovering the same meaning split: some newer state may already be committed, replicated, loaded, or locally applied while still not being the state that readers, traffic, or queries may honestly observe right now.
Foundry should preserve that seam without importing a universal serving protocol, rollout graph, or read-isolation algebra.

## Primary lessons from the outside

### 1) Loaded or committed is still smaller than exposed
Envoy is very explicit here.
Clusters and listeners go through warming before they can serve requests, and a newly added listener is warmed before taking traffic.
For updated clusters, the old cluster continues to serve traffic until the new cluster has warmed and can be atomically swapped in.
That is the exact humility worth stealing: a new state can be real inside the system before it is yet the state that honest traffic should observe.

Kafka teaches the same lesson through transactional visibility.
In `read_committed` mode, consumers only read up to the last stable offset (LSO), messages after an open transaction are withheld, and consumers may therefore not read all the way to the high watermark.
That means even a replicated tail can remain intentionally outside the current exposure frontier.

### 2) Safe read visibility often has its own frontier
CockroachDB sharpens the idea with follower reads.
A follower may serve reads only when the requested timestamp is at or below the closed timestamp, and only once it has applied the Raft commands up to the relevant log position.
So the system keeps separate truths for authoritative history, local application, and the highest point that is actually safe to expose for reads from that replica.

PostgreSQL expresses a nearby lesson with synchronous replication modes.
With `synchronous_commit=remote_apply`, the primary waits until the standby has replayed the transaction, making it visible to user queries.
That is a strong reminder that durable transfer and reader-visible exposure are different promises.

### 3) The withheld tail is a first-class fact, not a bug-shaped absence
The most useful steal is not another readiness graph.
It is the discipline of making the hidden tail legible.
Kafka’s open transactional tail, Envoy’s warming listeners/clusters, and CockroachDB’s writes newer than the closed timestamp all show the same pattern: there can be newer state present in some form while the system still honestly serves an earlier cut.
Foundry should not force that truth to hide inside one vague “lag” or “ready” bit.

## SlopOS/companion pressure
The uploaded SlopOS archive and the Steward/ViewFS companions already lean the right way.
Steward keeps startup, control-ready, readiness, and readiness-generation separate, which means it already resists the temptation to treat “loaded” or “started” as equivalent to “servable now”.
ViewFS likewise distinguishes rebuilt snapshots, watermarks, and live-follow state, which keeps current rendered truth separate from sync machinery.
Those cubes already carry the operational pressure; Foundry only needs to preserve the small cross-cutting meaning seam.

That makes the Foundry move very small:
- **apply frontier** should remain about what one realization has actually ingested/applied locally;
- **exposure frontier** should say what consumers, traffic, or queries may honestly observe now;
- **stability fence** should explain why newer state is still withheld;
- **withheld tail** should keep the newer-but-not-yet-exposed range explicit.

## Candidate nouns worth collecting
- **exposure frontier** — highest point one subject may honestly expose to readers, queries, or traffic now.
- **stability fence** — dependency, isolation, warmup, or safety boundary that blocks newer state from immediate exposure.
- **withheld tail** — the newer committed/loaded/applied range that remains intentionally outside the current exposure frontier.

## Things to keep parked
- a universal serve-readiness state machine;
- one cross-domain read-isolation algebra;
- a giant dependency or warming planner;
- any collapse of applied truth, reader-visible truth, and transactional/traffic-safe truth into one currentness badge.

## Provisional judgment
Promote only the seam, not the machinery.
Foundry should be able to say that one realization has applied through one point, that it only exposes through a lower **exposure frontier**, and that a **stability fence** plus **withheld tail** explains the difference.
That is especially valuable while SlopOS is still plastic enough to avoid teaching later docs that “loaded”, “committed”, “active”, and “visible to users/traffic” are interchangeable truths.
