# Research synthesis — 2026-03-23 pass VII

This pass focused on another way foreign-ground designs overclaim: they often present “the runtime is attested” as if that were enough to explain capability release, policy, and adoption.

## New lessons from outside systems

### 1) Capability to create foreign ground should be routed explicitly
Fuchsia’s virtualization capability-routing work is a strong modern reminder that the ability to create virtual machines or foreign runtime surfaces should be routed into a product/session explicitly. Foundry should steal that design instinct instead of assuming ambient hypervisor or sandbox access.

### 2) Policy split is healthier than one giant attestation story
Confidential Containers’ Trustee policies are a valuable lesson because they keep attestation-service policy separate from KBS resource policy. Foundry should steal that split: **admission policy** and **resource-release policy** are related, but not identical.

### 3) Integrity of init-data belongs in the foreign-ground story
Confidential Containers’ init-data guidance is valuable because it binds integrity of deployment configuration into attestation, while remaining honest that confidentiality is a separate matter. Foundry should keep policy inputs and init-data visible instead of pretending the ground makes them safe by magic.

### 4) Restore humility still matters after a successful attestation
Firecracker snapshotting and network-for-clones guidance, plus SnapStart’s restore guidance, still teach the same thing: a fast restored instance may need uniqueness regeneration, network reacquire, or policy re-check before it should be treated as ordinary continuity. Foundry should keep restore and adopt/reacquire distinct.

### 5) Explicit interface worlds still beat host folklore
The Wasm component model’s worlds, interfaces, and package separation continue to be a strong model for telling the truth about what a foreign component expects and provides. Foundry should keep those contract nouns crisp.

## New lessons from SlopOS and companions

### SlopOS
- `confidential-computing-boundary-index.md` and the SNP claim boundaries show that foreign-ground evidence is already treated as structured material, not magical runtime aura.
- `microvm-attestation-reacquire-posture-v0.md` continues to support reacquire over magical continuity.
- `host-guest-channel-posture-v0.md` and component/manifest surfaces reinforce the preference for explicit route and contract nouns.
- `microvm-generation-witness-posture-v0.md` remains one of the clearest humility patterns in the whole ecology.

### Siblings
- Harbor reinforces that entry and return across the membrane should remain truthful about what happened.
- Ward reinforces that attestation evidence is still smaller than final local verdict or release.
- ViewFS reinforces that package, live instance, and durable reference are different object strengths.
- Schell reinforces explicit adoption for helpers and sidecars.
- Helm reinforces that visibly foreign surfaces are a product virtue, not a defect.

## Brilliant ideas worth stealing carefully

1. **Foreign capability route** — explicit routing of “can create or use this foreign ground” instead of ambient availability.
2. **Policy split card** — separate attestation/admission policy from resource-release policy.
3. **Init-integrity card** — record how deployment/runtime inputs were integrity-bound without implying confidentiality.
4. **Adoption card** — distinguish started, attested, reviewed, and adopted foreign grounds.
5. **Reacquire rail** — make post-restore network, secret, or attestation reacquire visible rather than magical.

## Current recommendation
Foundry still should not freeze a universal runtime descriptor.

The safer move is:
- keep artifact, contract world, ground, policy, attestation, and release visibly separate;
- use specimen flow 04 to test whether policy split and adoption deserve first-class objects;
- and only promote the nouns that survive both component-style and confidential-runtime-style specimens.
