# Research synthesis — 2026-05-25 pass XCIV

Focus: **obligation ledgers, acknowledgment witnesses, and drift fences**.

The previous pass made audience and purpose exposure explicit after surface inventory. This pass closes the next gap: a surface can be exposed to the right audience for the right purpose and still drop the semantic obligations that made the exposure safe to interpret.

## New outside pressure

- `EXT-W3C-ODRL-2-2` gives Foundry a useful scar: duties and constraints can be linked to content use. Foundry should steal the idea that required actions travel with a surface, while refusing to become a rights-expression language or policy executor.
- `EXT-OASIS-XACML-3-0` separates a decision from obligations/advice that a policy-enforcement point may need to fulfill. Foundry should steal the separation between "may proceed" and "must carry residue," without deciding authorization.
- `EXT-W3C-DPV-2026` shows that processing, purpose, recipient, rights, and measures metadata can be machine-readable. Foundry should borrow machine-readable duty context while refusing to become a privacy-law, consent, or rights-management engine.
- `EXT-W3C-ODRL-2-2` and the existing exposure fixtures together pressure Foundry to keep obligations attached to assets/audiences/actions, not hidden in prose or assumed from access.

## What rev0093 still allowed

Rev0093 can say that an external-audit CSV, dashboard tile, Ward preview, ViewFS projection, delegated-worker cache, or public link is exposed to a named audience and purpose. It still allows quiet obligation failures:

- a CSV leaves with the right audience witness but drops the requirement to keep the semantic sidecar attached;
- a dashboard tile is visible to the right service account but suppresses observation-status warnings and classification pins;
- an external auditor acknowledges receipt but not the recall route or no-reexport boundary;
- a Ward preview keeps the surface but turns a "not Ward verdict" boundary into a local appraisal shortcut;
- a ViewFS inherited group inherits access but not the obligation to quarantine until explicit rebinding;
- a delegated worker is permission-denied, so required recheck-before-execute obligations cannot be observed; or
- a public link is blocked for exposure, but downstream consumers still treat the link as if obligations were satisfied.

Those are obligation-carriage failures, not merely exposure failures.

## Speculative read

Foundry needs a tiny **obligation accounting seam** after exposure:

```text
obligation ledger          = scoped list of semantic obligations that must travel with a carrier, audience, surface, and purpose
acknowledgment witness     = consumer-local evidence that those obligations were accepted, refused, partially accepted, quarantined, or missing
obligation-drift fence     = refusal when an obligation is dropped, downgraded, expired, widened, self-acknowledged, or laundered into authority
```

The seam should stay smaller than law, consent, policy enforcement, authorization, ODRL, XACML, DPV, audit, release management, deletion, custody, or sibling-cube verdicts. Foundry's job is not to decide what the world legally requires. Its job is to prevent a dangerous sentence: "the surface was exposed correctly, therefore all semantic obligations traveled correctly."

## New specimen pressure

Add specimen 88 around obligation ledgers, acknowledgment witnesses, and obligation-drift fences. The fixture must prove at least:

- every obligation ledger names source exposure ledgers, audience witnesses, carrier ids, scope, obligations, required acknowledgments, and authority boundaries;
- every active obligation names trigger, required residue, applies-to surfaces/audiences/purposes, and blocked inferences;
- every required consumer/surface/audience has an acknowledgment witness or a drift fence;
- acknowledged obligations cannot exceed the ledger scope and must preserve carrier digest and source exposure linkage;
- partial, refused, missing, public, inherited, or permission-denied acknowledgments require obligation-drift fences;
- no-reexport, recall-route, sidecar-preservation, classification-pin, observation-status, and sibling-boundary obligations cannot be downgraded by display/export convenience;
- a complete ledger cannot leave active obligations unacknowledged; and
- negative cases cover missing ledger, missing source exposure, missing obligation pin, missing acknowledgment, dropped sidecar/classification/recall obligations, no-reexport downgrade, wrong-consumer acknowledgment, partial-as-full, expired obligations without recheck, inherited/public exposure without fences, obligation-as-authorization, obligation-as-legal-compliance, obligation-as-consent, digest mismatch, waiver-without-replay, and sibling-verdict laundering.

## Recommendation

Keep obligation accounting fixture-local and reversible. Do not promote a global rights or policy model. The narrow Foundry job is to make obligation carriage visible enough that exposed semantic surfaces cannot silently shed the sidecars, pins, warnings, recall hooks, no-reexport boundaries, and sibling non-promises that made them interpretable.
