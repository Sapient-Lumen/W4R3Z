# SlopOS + companions evaluation — pass LX

This pass checks whether **allocation basis, residue class, and apportionment fence** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal chargeback product, a full valuation plane, or a giant weighting DSL.

## Why SlopOS pressures this seam now

### 1) SlopOS already separates explicit payer authority from resource execution subjects
`docs/30-architecture/budget-payer-semantics-v0.md` keeps payer identity explicit and non-ambient.
That means future support or accounting views may legitimately want to say “this burden belongs to subject X” even when the runtime subject, resource envelope, or worker is not itself the payer.
Once that happens, the split rule needs to stay visible instead of dissolving into “obvious ownership.”

### 2) SlopOS already has observational quota summaries that are smaller than authority
`docs/30-architecture/quota-replication-boundary-v0.md` is explicit that replicated `quota` objects are additive spend summaries under already-issued local credit, not remote admission authority.
That is already one form of derived/apportioned accounting truth.
A future cube that spreads such observational burden across projects, capsules, or products needs an explicit **allocation basis** and **apportionment fence**.

### 3) Shared workers and pooled resources create natural split pressure
The worker-pool constructor family already fixes one explicit pool-wide `sponsor` root and rejects silent per-worker sponsor splits.
That is healthy for authority.
But any dashboard or export that later wants “cost per worker,” “shared pool burden per tenant,” or “fair-share idle overhead” will be creating apportioned values, not discovering native ones.
That pressures Foundry toward an explicit **residue class** and **allocation basis**.

### 4) Imported provider spend and discounts will not arrive as one native per-subject truth
Even before a full datacube exists, future SlopOS-adjacent views are likely to mix:
- direct local charges against an explicit budget lease,
- shared substrate overhead,
- idle reserved capacity,
- and imported provider-side blended or commitment-discounted spend.
Those can all share a unit while differing sharply in whether they are direct, allocated, residual, or restated under a policy.
That is exactly the pressure this seam contains.

## What to steal into Foundry

### allocation basis
A compact witness for the rule that produced an apportioned row.
Examples:
- `direct_native_row`
- `uniform_split`
- `proportional_reserved_capacity`
- `proportional_observed_usage`
- `custom_metric_network_egress`
- `provider_native_allocation`

This is smaller than a giant weighting language.
It just stops split values from impersonating direct measurements.

### residue class
A compact witness for what stayed specially treated rather than silently disappearing.
Examples:
- `idle_unallocated`
- `overhead_unallocated`
- `unused_commitment`
- `rounding_residue`
- `fully_distributed_none`
- `other_explicit`

This is smaller than a finance or ops accounting product.
It simply keeps leftovers visible.

### apportionment fence
A compact witness for what reasoning remains lawful.
Examples:
- `conserves_total_same_basis`
- `same_basis_only`
- `view_only_split`
- `policy_restatement_required`
- `forbidden`

This is smaller than a universal reconciliation engine.
It only keeps direct facts and apportioned convenience visibly different.

## Why this seam is small enough now
It does **not** require:
- one universal cost model for all budgets, quotas, and provider charges;
- automatic reallocation of every idle or overhead remainder;
- one weighting DSL for every shared family;
- or a promise that apportioned rows are interchangeable with direct measurements.

It only says that once Foundry emits a split/shared/allocated value, it should preserve:
1. **what rule produced the split**,
2. **what residue stayed special**,
3. and **what kind of re-aggregation or comparison is actually lawful**.

## Recommended Foundry posture
Promote **allocation basis**, **residue class**, and **apportionment fence** as a narrow honesty seam for shared spend, shared usage, idle/overhead burden, provider discounts, and other apportioned values.
Keep the larger chargeback, valuation, and full cost-model questions parked.

This matches current SlopOS discipline well: SlopOS already keeps payer authority explicit, already treats quota replication as observational, and is still early enough that Foundry should record only the smallest residue needed to keep allocated rows from turning into native-fact folklore.
