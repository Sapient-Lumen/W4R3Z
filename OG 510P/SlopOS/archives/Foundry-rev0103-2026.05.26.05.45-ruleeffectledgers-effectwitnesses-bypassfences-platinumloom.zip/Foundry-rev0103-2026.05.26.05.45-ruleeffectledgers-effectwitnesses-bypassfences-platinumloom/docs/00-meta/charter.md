# Charter

        **Mission:** Foundry is the companion cube for off-native realization: containers, microVMs, TEEs, component hosts, compatibility layers, and other foreign cells where native meaning is enacted on alien ground.

        ## North-star sentence
        Foundry must preserve native semantic discipline even when execution, storage, or interaction occur on alien substrate with different failure stories.

        ## Non-goals
        - choosing a single deployment substrate up front
- letting host, container, or cloud folklore quietly become native meaning
- owning trust verdict logic that belongs in Ward
- becoming a generic DevOps or platform-ops archive


        ## Sibling pressure map
        - **Harbor**: crossings into foreign runtimes still need exchange and aftermath truth
- **Ward**: runtime evidence and platform measurements may be exported for appraisal, not judged here
- **Helm**: shell surfaces need honest stories about what is native, delegated, or merely projected from foreign ground
- **Schell**: helper lanes and terminal work often straddle native and foreign execution grounds
- **ViewFS**: artifact packages, bundles, and snapshots need object and lineage honesty
