# Research synthesis — pass XLV

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from warehouse history and metrics systems: not every number has the same grain, temporality, or legal reduction.

The smallest durable seam from this pass is:
- **grain card** — a plain statement of what one row, event, or snapshot actually represents;
- **accumulation class** — whether the value behaves like a snapshot, delta, cumulative total, or similarly bounded accumulation posture;
- **reduction fence** — explicit limits on which reductions are legal, approximate, or forbidden.

These are still smaller than a full semantic layer, warehouse grammar, or built-in rollup planner.
Units, monotonicity, and exactness can stay as attached metadata until more pressure proves they deserve larger noun status.

## Lessons we must learn from the past

### 1) Grain comes before dimensions and facts
Kimball’s oldest durable lesson still holds: say what one row means **before** arguing about dimensions or measures.
If the cube cannot plainly say whether a row is “one trace event,” “one inspect snapshot,” or “one evaluated smart-folder result,” then later aggregation and join behavior will become folklore.
Foundry should therefore keep a lightweight **grain card** wherever a value-bearing family first appears.

### 2) Snapshot, delta, and cumulative truths should not collapse
Metrics systems keep relearning that values which all look numeric obey different laws.
OpenTelemetry’s data model and instrument kinds distinguish monotonic versus non-monotonic sums, counters versus gauges, and delta versus cumulative temporality.
That is exactly the right lesson for an embryonic datacube.
Foundry should preserve an **accumulation class** rather than assuming every future value can be summed the same way.

### 3) Units belong in metadata, not smuggled into names
OpenTelemetry also treats unit as explicit instrument metadata and recommends standard unit discipline rather than folding meaning into the name.
Foundry should steal that instinct.
Future exported fields should not rely on “count_ms_pctish” naming folklore when a small metadata field can say the unit more honestly.

### 4) Non-additive results should stay derived when possible
Kimball warns that ratios and other non-additive facts usually behave better when their additive components are stored and the final result is computed later.
Cube’s current docs make the same point from a modern acceleration angle: averages, distinct counts, and percentiles are special because they do not reduce cleanly across arbitrary cuts, while additive components often do.
Foundry should therefore keep **reduction fences** explicit and prefer additive components plus later derivation over prematurely canonizing every friendly result as a first-class fact.

### 5) Query results are not automatically cube facts
A count returned by a smart-folder query, a bounded knowledge-base answer, or a support bundle summary can be useful without being the cube’s native atomic truth.
Foundry should stay alert to this trap.
Some future read surfaces will be query results over more primary rows, not rows that deserve promotion into the base cube.

## What to steal now
- a minimal **grain card** on value-bearing specimens so “one row means what?” is answered before dimension debate begins;
- explicit **accumulation class** for snapshot, delta, cumulative, or similarly load-bearing value posture;
- explicit **reduction fence** for additive, semi-additive, non-additive, approximate, or derived-only posture;
- **unit metadata** kept adjacent to value semantics instead of hidden inside names;
- **derived-result discipline** so ratios, distinct counts, and similar friendly outputs do not silently become atomic truth.

## What to keep parked
Do not yet promote:
- a universal measure/metric taxonomy;
- a built-in rollup or aggregate-awareness planner;
- a giant unit registry;
- global approximation policy;
- or a promise that every query result deserves first-class cube status.

## Resulting recommendation
The next healthy move is not “design all measures.”
It is to let Foundry say, for any future value-bearing row:
1. what one row means,
2. what sort of accumulation posture the value has,
3. and which reductions are legal, approximate, or forbidden.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable lessons from both classic dimensional modeling and current metrics systems.
