# SlopOS and companions evaluation — pass XVIII

This pass keeps Foundry aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** keeps foreign-cell, microVM, restore, and generation-witness surfaces distinct. That argues for preserving metadata seal, payload root, and bootstrap debt as separate truths rather than one runtime-ready bit.
- **SlopOS** also treats compatibility as sealed and foreign ground as explicit, which matches the idea that a mounted or bootstrapped structure can still depend on remote or foreign payload bytes.
- **ViewFS** repeatedly teaches object-vs-range-vs-whole-proof separation, which reinforces a structure/payload split rather than one giant image blob.
- **Helm** still wants truthful operator surfaces about what is local, projected, attached, or still loading.
- **Schell** still wants live-checkout humility, which matches the idea that started work may still carry cold-read or reacquire debt.
- **Ward** keeps evidence smaller than final trust, which helps Foundry keep payload roots and metadata seals smaller than adoption.

## Pressure on Foundry
Foundry should not decide yet whether metadata seal and payload root belong inside artifacts, runtime evidence, or locality classes.
The stronger move is to keep one more specimen where:
1. structural metadata is sealed,
2. payload bytes are verified through a different root or Merkle story,
3. startup succeeds before all payload is local,
4. and the remaining debt stays public.

## Promotion restraint
Do not promote `metadata seal`, `payload root`, or `bootstrap debt` unless they improve:
- one structure-authentic but payload-remote specimen,
- one payload-verified cold-read specimen,
- and one startup-before-full-locality specimen.
