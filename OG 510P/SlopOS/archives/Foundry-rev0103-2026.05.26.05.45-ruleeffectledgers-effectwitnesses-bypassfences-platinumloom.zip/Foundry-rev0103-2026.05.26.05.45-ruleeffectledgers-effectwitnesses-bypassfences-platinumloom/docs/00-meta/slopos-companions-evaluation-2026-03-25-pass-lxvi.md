# SlopOS + companions evaluation — pass LXVI

This pass checks whether **ordering basis, mutation lane, and revision witness** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal CDC warehouse, a global “latest mutable truth” plane, or a promise that every SlopOS-side family needs permanent before/after history.

## Why SlopOS pressures this seam now

### 1) SlopOS already distinguishes request identity from current live state
`docs/30-architecture/job-request-state-posture-v0.md`, `background-request-state-posture-v0.md`, and `network-request-state-posture-v0.md` all say the same thing in adjacent families: a stable request key is useful, but it is **not** current scheduler/grant/lease truth.
`docs/30-architecture/lease-descriptor-state-boundary-v0.md` generalizes the same lesson for issued descriptors.
That is almost a direct demand for Foundry’s **mutation lane**.
Some future rows are request artifacts or historical descriptors, not live-state rows, and the cube should say so.

### 2) SlopOS already keeps some digest-bound records explicitly non-authoritative
`docs/30-architecture/health-record-schema-v0.md` describes CH-HEALTHREC as a **non-authoritative but digest-bound** account of a health evaluation.
`docs/30-architecture/capture-session-schema-v0.md` says the capture descriptor is **not authority** and only describes bounds/attribution for portal-mediated capability delivery.
That is strong evidence that Foundry must not let every structured row sound like live truth.
Again, mutation lane earns its keep.

### 3) SlopOS already has moving history and design-phase correction surfaces
`docs/00-meta/resolved-history.md` is full of revised closure notes.
It is intentionally useful and intentionally not the same thing as current mainline architecture truth.
That puts pressure on **revision witness**: some visible answers are complete only for a given cut, some are historical-only, and some remain subject to later correction while design is still active.

### 4) SlopOS already has many clocks and ordering candidates, and they are not interchangeable
Capture descriptors carry issue/expiry times.
Portal request-state docs distinguish review/acceptance history from current runtime state.
Imported auth/userinfo families repeatedly fence off provider-local freshness and live-state semantics.
MicroVM and health-related surfaces also keep boot/session/accounting cuts distinct.
That is exactly why Foundry needs **ordering basis** rather than one flattering generic timestamp field.

### 5) Companions reinforce the same restraint
Ward keeps snapshot cuts and retractions visible.
ViewFS repeatedly separates receipts/history from live authority.
Steward’s history-policy and session-proof posture likewise resists flattening historical evidence into current-truth claims.
Together they say: preserve useful mutable history, but do not pretend every historical or corrective row is a current authoritative state row.

## What to steal into Foundry

### ordering basis
A compact statement of which field or clock decided the visible winner/history position.
Examples:
- `event_time`
- `arrival_commit_time`
- `updated_at`
- `issued_at`
- `record_time`

### mutation lane
A compact statement of what sort of row the consumer is seeing.
Examples:
- `current_snapshot`
- `historical_version`
- `change_event`
- `invalidate_prior`
- `delete_tombstone`
- `descriptor_not_state`

### revision witness
A compact statement of how revisable the answer still is.
Examples:
- `subject_to_revision`
- `complete_for_cut`
- `bounded_change_window`
- `source_claims_final`

## Why this should stay narrow
Foundry does **not** need to force every SlopOS family into a full changelog model.
Many current neighboring surfaces only need enough honesty to prevent three common lies:
- “this timestamp means the same thing everywhere,”
- “this snapshot row tells the whole mutable story,”
- and “this absent or changed row had one obvious delete/update meaning.”

Ordering basis, mutation lane, and revision witness are enough to keep those lies from hardening into ontology.

## Recommendation
Promote this seam only as a **small reversible honesty layer** for mutable-source families.
Keep any wider CDC warehouse, permanent bitemporal store, or universal before/after algebra parked until at least two real consumers outside the current SlopOS pressure set prove they are necessary.
