# SlopOS and companions evaluation — 2026-05-23 pass XC

Focus: whether Foundry can re-admit a replacement semantic carrier after recall without claiming repair completion, source truth, or sibling authority.

## SlopOS pressure

SlopOS support surfaces may trigger a Foundry revocation notice when a sidecar, support-card export, cached dashboard, or delegated packet loses a required pin, cut, witness, fence, or status. Rev0089 can quarantine the old carrier. Rev0090 adds the missing next step: a replacement must be witnessed and consumer-gated before reuse.

A SlopOS operator can provide the evidence that a replacement sidecar includes the missing code-drift fence. Foundry can record that the replacement carrier passed its readmission gate for external audit. Foundry still does not assert SlopOS proof, operator truth, repair completion, or policy approval.

## Companion boundaries

| Companion | Remediation/readmission interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may provide replacement sidecars and replay evidence for recalled support surfaces | SlopOS still owns source evidence, proof claims, and operator semantics |
| Harbor | may record external remediation claims or stale-impact status | Harbor still owns external status, public-safe impact, and remediation verification |
| Ward | may consume readmitted packets as appraisal inputs | Ward still owns appraisal and trust verdicts |
| Steward | may observe replay/retry state around replacement generation | Steward still owns effect lifecycle, pushback, and finality |
| Schell | may constrain quarantine release, retention, or minimization | Schell still owns forgetting and retention authority |
| ViewFS | may display replaced/recalled projections | ViewFS still owns object identity, paths, consent, and projection custody |
| Helm | may carry repair-attempt/intervention traces | Helm still owns repair custody, remainder bridges, and handback consequence |
| External audit notebook | may receive a consumer-local readmission gate | readmission is not audit opinion or certification |
| Dashboard cache | may resume serving only after a cache-specific gate | cache refresh is not semantic repair |

## What changed in this pass

- Added specimen 84 for remediation packets, replacement witnesses, and readmission gates.
- Added a remediation/readmission rulebook so replacement reuse has named failure modes.
- Added v0 schemas for remediation packets, replacement witnesses, and readmission gates.
- Added a specimen 84 fixture with a readmitted sidecar replacement, a partial Ward readmission, a blocked revoked-warrant remediation, a reopened replacement, and negative cases.
- Added `check_foundry_remediation_readmission.py` and wired it into `make check`.
- Reused in-toto subject/predicate binding, SLSA provenance separation, CSAF remediation/status structure, and companion-cube repair/status boundaries while keeping Foundry smaller than attestation, supply-chain security, vulnerability advisory, incident remediation, approval, or repair workflows.

## Recommendation

Future Foundry revisions should treat "replacement exists" as weaker than "readmitted for this consumer/use." A repaired sidecar needs a replacement witness and readmission gate before the old quarantine can lift, and the gate must keep old history, residual risks, partial repair, and sibling authority boundaries visible.
