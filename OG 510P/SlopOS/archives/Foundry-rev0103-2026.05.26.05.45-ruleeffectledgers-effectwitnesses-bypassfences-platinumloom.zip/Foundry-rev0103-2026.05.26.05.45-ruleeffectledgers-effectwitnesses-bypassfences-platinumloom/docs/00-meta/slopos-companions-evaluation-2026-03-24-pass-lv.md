# SlopOS + companions evaluation — pass LV

This pass checks whether **rank recipe, score family, and tie-break witness** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal search service, a full relevance-evaluation plane, or one cube-wide score algebra.

## Why SlopOS pressures this seam now

### 1) SlopOS ATTRFS is already query-shaped and snapshot-first, which makes ordering residue meaningful even before ranking exists
`attrfs-posture-v0.md` says `D-ATTRFS` is **view-scoped**, **snapshot-first**, and **handle-returning**.
`attribute-query-schema-v0.md` further keeps `CH-ATTRQ` closed and explicitly refuses regex/full-text/ranking expansion in Phase 1.
That means a future Foundry read model built over ATTRFS will already face an honesty problem: some orders will be unscored field sorts or shell-local presentation orders, not relevance scores.
A compact **rank recipe** and **score family** therefore help immediately, even when the score family is simply `unscored`.

### 2) SlopOS smart-folder persistence is shell-owned, so window/page stability should not be assumed ambiently
Because saved queries remain shell-owned manifests rather than an app-visible search daemon, any future “next page”, export slice, or repeated advisory list should preserve how ties were stabilized rather than pretending one first-seen order is durable truth.
That pressures Foundry toward an explicit **tie-break witness**.

### 3) SlopOS already has an ordering-witness discipline elsewhere
`ordering-token-posture-v0.md` keeps ordering evidence as a small witness seam rather than a universal sequencer.
That is exactly the adjacent lesson Foundry should steal here: ranked-result stability wants a compact tie-break witness, not a giant ordering product.

### 4) The companion cubes increasingly pressure ranked convenience without justifying a universal search plane
ViewFS follow/feed and Harbor preview surfaces already create user pressure for “best”, “latest”, “most relevant”, or “first useful” result lists.
Those pressures are real, but they are still smaller than one stable cross-cube relevance algebra.
A narrow seam keeps that distinction visible.

## What to steal into Foundry

### rank recipe
A compact witness for the ordering procedure that produced the visible rows.
Examples:
- explicit field sort,
- BM25/text relevance,
- vector-distance ordering,
- hybrid fusion,
- reranker-over-preranked-candidates,
- or explicit advisory/manual order.

This is smaller than a search platform.
It just keeps the order from sounding natural and universal.

### score family
A compact witness for what the visible score means.
Examples:
- higher-is-better BM25 family,
- lower-is-better distance family,
- recipe-local fusion family,
- reranker score kept distinct from first-stage score,
- or `unscored` where rank is advisory only.

This is smaller than a calibration plane.
It simply stops one scalar field from laundering unlike ranking semantics into fake sameness.

### tie-break witness
A compact witness for how ties or equal scores were stabilized.
Examples:
- explicit secondary sort tuple,
- cursor seed + stable key,
- deterministic export row key,
- or explicit `none` when no stable tie-break was preserved.

This is smaller than a global sequence service.
It just makes repeated pages/exports honest.

## Why this seam is small enough now
It does **not** require:
- a universal search/relevance product;
- a score calibration algebra;
- a mandatory ranking phase for every family;
- or a giant evaluation infrastructure.

It only says that once values become ranked or advisory-ordered, Foundry should preserve:
1. what ordered them,
2. what their score numbers mean,
3. and how ties were stabilized.

## Recommended Foundry posture
Promote **rank recipe**, **score family**, and **tie-break witness** as a narrow honesty seam for ranked and advisory-ordered values.
Keep the larger retrieval/search/relevance-product questions parked.

This matches current SlopOS discipline well: ATTRFS is already snapshot-first and closed rather than ambient full-text ranking, smart-folder persistence is shell-owned rather than a universal query product, and SlopOS already knows how to keep ordering evidence smaller than a global sequencer.
