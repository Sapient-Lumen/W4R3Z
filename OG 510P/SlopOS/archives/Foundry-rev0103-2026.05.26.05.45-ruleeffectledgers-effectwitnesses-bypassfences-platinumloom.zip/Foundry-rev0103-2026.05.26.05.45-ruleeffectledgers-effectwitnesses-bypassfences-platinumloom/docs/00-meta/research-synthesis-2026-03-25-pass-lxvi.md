# Research synthesis — pass LXVI

This pass stays conservative.
Foundry still should **not** promise one universal mutable-truth engine while SlopOS-side meanings and neighboring archive surfaces are still moving.
But it can steal one more durable lesson from change-feed systems, temporal tables, stream processors, and snapshot tools: **a mutable-source datacube needs an explicit ordering basis, an explicit mutation lane, and an explicit revision witness before “latest value” can be trusted.**

The smallest durable seam from this pass is:
- **ordering basis** — the compact statement of which clock or field actually ordered the visible winner or history cut: event time, arrival/commit time, transaction/record time, `updated_at`, issue time, or another explicit field;
- **mutation lane** — the compact statement of what sort of row the consumer is looking at: current snapshot, historical version, change event, invalidation, tombstone/delete, descriptor-not-state, or another reviewed mutation shape;
- **revision witness** — the compact statement of how revisable the visible answer still is: subject to revision, complete for this cut, bounded by a replay/change-history window, or final only by a source-local claim.

These are still smaller than a universal CDC warehouse, a mandatory bitemporal algebra for every family, or one archive-wide doctrine that every mutable source must emit both before/after images forever.
They simply stop a convenience snapshot from impersonating timeless truth.

## Lessons we must learn from the past

### 1) “What time won?” is a real semantic question, not an implementation footnote
Apache Hudi says the commit instant in the timeline is the **arrival time** of data while the data organization reflects the **event time** the record belongs to, and its record-merger guidance separately supports event-time ordering for late-arriving data.
SQL Server’s temporal-table guidance is equally cautionary from another angle: system-versioned history is fine for SCD-like work only if **database transaction time** is acceptable for the business logic, and it explicitly warns that significant load delay can make transaction time unacceptable.
Foundry should steal the discipline, not the products: every mutable-source family needs an explicit ordering basis before a “latest” answer sounds comparable.

### 2) Snapshot rows and change rows are different species
Delta Lake’s Change Data Feed records row-level inserts, updates, and deletes between table versions.
BigQuery’s `CHANGES` function likewise exposes `INSERT`, `UPDATE`, and `DELETE` with commit timestamps.
Those are not the same thing as the current table snapshot.
Foundry should keep mutation lane explicit so a dashboard cannot quietly swap “current snapshot row”, “historical version”, and “change event” as if they were one generic fact family.

### 3) Delete handling is policy, not folklore
Current dbt snapshot guidance on `hard_deletes` makes this unusually plain: deleted source rows can be ignored, invalidated, or represented as a new delete-marked record.
That means disappearance does not have one natural meaning.
Foundry should keep delete/tombstone/invalidation posture visible in mutation lane instead of letting absent rows masquerade as “never existed”, “definitely inactive”, or “same as ordinary overwrite”.

### 4) Change history is often bounded, schema-shaped, and therefore weaker than permanent semantic memory
BigQuery’s `CHANGES` history is limited to the table’s time-travel window and current schema, and cloned or snapshotted tables do not inherit the source table’s change history.
That is a valuable warning for Foundry.
A change feed can be useful without being the permanent semantic archive.
Revision witness should therefore let the cube say when the visible answer is only complete **within a bounded change-history window**.

### 5) Final-looking output still needs explicit revision posture
FOCUS 1.3 now requires providers to timestamp datasets and flag completeness status so users know whether data are final or still subject to revision.
Beam likewise treats late-data handling as a deliberate configuration choice once watermarks pass window ends.
Foundry should steal the design lesson: a useful answer may be complete for one cut and still not be final forever.
Revision witness is the smallest honest place to say that.

## What to steal now
- an **ordering basis** field or adjunct that says which time/ordering field actually decided visibility or winner selection;
- a **mutation lane** that distinguishes snapshot rows, historical versions, change rows, tombstones/invalidation, and descriptor-not-state rows;
- a **revision witness** that says whether the visible answer is subject to revision, bounded by a replay/change-history window, complete for a cut, or final only by source-local claim;
- a standing rule that **disappearance is smaller than delete semantics**;
- and a standing rule that **current snapshot is smaller than full mutable truth**.

## What to keep parked
Do not yet promote:
- one mandatory bitemporal algebra across the whole cube;
- one universal before/after-image requirement;
- one automatic rule that every mutable family must preserve permanent changelog history;
- or one doctrine that event time, arrival time, transaction time, and `updated_at` can be safely flattened into a generic timestamp.

## Resulting recommendation
The next healthy move is not “teach Foundry to do everything a streaming engine, temporal database, and CDC system can do.”
It is to let Foundry say, for mutable-source families:
1. **which ordering basis actually determined the visible answer,**
2. **which mutation lane the visible row occupies,**
3. and **which revision witness explains how revisable the answer still is.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart discipline from Hudi, Delta Lake, BigQuery, dbt, SQL temporal tables, FOCUS, and Beam.
