# Research synthesis — 2026-05-21 pass LXXXIV

Focus: **refusal receipts, egress manifests, and conformance gates**.

The prior pass made semantic residue survive egress by adding sidecars and fixture checks. This pass tightens the negative path: when Foundry refuses to emit a table, chart, CSV, JSON, markdown summary, dashboard tile, or support card, the refusal itself must be a replayable artifact instead of a console log, prose warning, or missing output.

## New external pressure added

- `EXT-RFC9457-PROBLEM-DETAILS-2023` supplies a useful shape for machine-readable refusals: type, title, status, detail, and instance. Foundry should borrow the typed-error discipline without making every semantic refusal an HTTP API error.

## Existing pressure reused

- `EXT-JSON-SCHEMA-CORE-2026` keeps schemas in their lane: validation aids, not Foundry ontology or approval authority.
- `EXT-W3C-PROV-DM-2013` keeps provenance smaller than trust, quality, or policy verdicts. A refusal receipt can be evidence of a blocked export without becoming a governance decision.
- `EXT-OPENLINEAGE-OBJECT-MODEL-2026` and `EXT-OPENLINEAGE-FACETS-2026` reinforce a facet-like posture: attach the needed residue to jobs/runs/results without forcing one lineage graph to own all meaning.
- SlopOS checker and evidence patterns reinforce deterministic, local gates over broad prose claims.

## What rev0083 still allowed

Rev0083 could prove that sidecars existed and that specimens 70 through 77 had negative cases. It did not yet prove that a refusal is:

- named by a stable rule;
- tied to the exact requested surface;
- cross-referenced from the egress attempt;
- explicit about semantic loss;
- explicit about repair escapes;
- digest-addressed for later audit; and
- smaller than policy approval, privacy release, trust verdict, or source truth.

That gap matters because silent non-output is just another flattening failure. A refused CSV can be retried manually, screenshotted, or reimplemented elsewhere unless the refusal states what meaning would be lost and how to request a safe shape.

## Speculative read

Foundry is approaching an **egress contract** layer, but it should not become an API gateway, privacy engine, BI product, or data-contract runtime. The narrower object is an egress manifest: a batch-local ledger of attempted surfaces, accepted surfaces, refused surfaces, sidecar links, rule-suite digests, and refusal receipts.

A useful division now emerges:

```text
sidecar       = what meaning travels with an emitted surface
receipt       = why a requested surface could not honestly be emitted
manifest      = which attempts were evaluated together
gate          = the deterministic check that binds attempts to sidecars/receipts
verdict       = outside Foundry
```

This is smaller than provenance and smaller than policy. It is the export boundary telling the truth about itself.

## Design claim

Every egress attempt should end as exactly one of these:

1. emitted with in-band residue;
2. emitted with a digest-linked semantic sidecar;
3. refused with a digest-linked refusal receipt; or
4. explicitly marked out-of-scope before semantic evaluation.

An attempt that fails silently, logs only a string, or returns a generic error without semantic-loss and repair information is not Foundry-clean.

## New specimen pressure

Add specimen 78 around refusal receipt, egress manifest, and conformance gate. The fixture must prove at least:

- a chart with sidecar can pass;
- a CSV without sidecar is refused;
- a markdown summary that drops observedness/status is refused;
- a cached support card crossing materialization or classification cut is refused;
- a label-only classification export is refused;
- every refusal has a rule id, problem-details object, semantic-loss list, repair escape, and non-retryable-without list; and
- every refused attempt in the manifest points at an actual receipt.

## Recommendation

Keep refusal receipts scoped to egress conformance for now. Do not let them grow into a global error ontology or policy-denial system. A future pass can widen them only after at least one non-SlopOS consumer needs the same manifest/receipt pairing.
