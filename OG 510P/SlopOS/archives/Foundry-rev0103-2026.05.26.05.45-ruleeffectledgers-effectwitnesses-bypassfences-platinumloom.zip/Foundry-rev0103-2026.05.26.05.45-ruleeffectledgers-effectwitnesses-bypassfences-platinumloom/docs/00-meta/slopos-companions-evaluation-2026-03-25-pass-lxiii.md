# SlopOS + companions evaluation — pass LXIII

This pass checks whether **support witness, unknown residue, and falsehood fence** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal extension registry, one mandatory opaque payload on every row, or a promise that every older reader can safely flatten every newer family.

## Why SlopOS pressures this seam now

### 1) SlopOS is intentionally rich in schema-pinned and boundary-pinned families
The current SlopOS archive has many exact `v0` / `v1` meanings across request context, trace processing, meter descriptors, observation export, and MCP import boundaries.
That is healthy.
It also means Foundry should assume that different readers will understand different subsets of those families for a while.
A support/export tile that knows `CH-REQCTX v1` and `CH-TRACEPROC v1` may still not understand one newer MCP or observation adjunct without becoming dishonest.

### 2) MCP import boundaries are explicitly narrower than native SlopOS truth
`mcp-progress-import-boundary-v0.md`, `mcp-task-import-boundary-v0.md`, and `mcp-userinfo-import-boundary-v0.md` all keep provider-local protocol semantics smaller than native job, completion, identity, or authorization truth.
That makes them exactly the sort of design-phase families where a future consumer may understand the core import card but not a later optional detail family.
Foundry therefore needs a way to say “this reader did not understand that extra provider-local adjunct” without turning unread into “none” or “unsupported by reality”.

### 3) Budget/payer surfaces are too authority-sensitive for flattering defaults
`budget-payer-semantics-v0.md` is very clear that payer identity is explicit and non-ambient.
That means a later export that fails to understand one newer sponsorship nuance, exception family, or budget lineage adjunct must not quietly coerce the row into “no payer”, “same payer”, or “safe default budget posture”.
A falsehood fence is healthier than convenience.

### 4) Observation/export and quarantine surfaces already distinguish evidence from universal truth
`observation-export-posture-v0.md` keeps exports bounded, policy-killable, and non-authoritative.
`open-untrusted-export-lineage-boundary-v0.md` keeps saved output a fresh artifact with explicit parent linkage instead of hidden continuity.
Those neighboring rules pressure Foundry toward the same posture: if a reader/export path does not understand one new lineage, disclosure, or redaction adjunct, it should preserve unread residue rather than laundering it into ordinary universal truth.

### 5) Companions are already converging on “useful but smaller than truth” residues
Harbor keeps schema-source/audience/repair details smaller than durable trust.
ViewFS keeps payer, spend, and receipt lanes separate.
Schell keeps source witness, import card, and scope-mutation posture separate.
All of those neighbors make the same datacube demand: partial understanding must stay visibly partial.
That makes this seam the right size for Foundry now.

## What to steal into Foundry

### support witness
A compact record of what the current reader/export path understood.
Examples:
- required schema families understood,
- optional adjunct namespaces understood,
- optional adjunct namespaces ignored but preserved,
- or hard refusal because a required vocabulary was missing.

### unknown residue
A preserved uninterpreted remainder for what survived unread.
Examples:
- an opaque adjunct digest,
- one preserved unknown enum value,
- a field/value fragment held only for later drill-through,
- or a source-row pointer proving the unread detail still exists somewhere exact.

### falsehood fence
A compact refusal boundary against flattering defaults.
Examples:
- unread optional family must not become `false`,
- unread payer nuance must not become “same sponsor”,
- unread progress detail must not become “0 remaining”,
- unread lineage/disclosure hint must not become “no lineage/no restriction”.

## Why this seam is small enough now
It does **not** require:
- one mandatory opaque payload on every result,
- one universal negotiation protocol,
- one global extension governance board,
- or a promise that every unknown is later decodable.

It only says that once a Foundry reader/export path handles evolving design-phase families, it should preserve:
1. **what it claimed to understand**,
2. **what unread residue survived**,
3. and **where it refused to coerce partial understanding into ordinary truth**.

## Recommended Foundry posture
Promote **support witness**, **unknown residue**, and **falsehood fence** as a narrow honesty seam for evolving imported/exported/adjunct families.
Keep wider extension registries, negotiation engines, and mandatory carryover blobs parked.

This matches current SlopOS discipline well: SlopOS is still early enough that the healthy move is not “make every consumer fully understand everything,” but “make partial understanding, preserved residue, and explicit refusal visible.”
