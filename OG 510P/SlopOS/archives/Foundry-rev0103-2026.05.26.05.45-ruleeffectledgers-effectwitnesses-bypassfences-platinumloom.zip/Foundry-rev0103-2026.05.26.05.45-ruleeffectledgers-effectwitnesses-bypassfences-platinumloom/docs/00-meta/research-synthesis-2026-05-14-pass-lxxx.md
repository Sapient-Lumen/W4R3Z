# Research synthesis — pass LXXX

This pass goes deeper on a datacube failure mode that sits just downstream of grain, exactness, recipe, replay, materialization, hierarchy, and disclosure: a cell can look like one ordinary observation while actually being estimated, imputed, provisional, adjusted, seasonally adjusted, benchmarked, forecast, revised, quality-flagged, or substituted for a missing/unusable value.

That is not merely a data-quality note. In a SlopOS-facing Foundry cube, support cards will want compact tables over diagnostic snapshots, trace processors, observation exports, quarantined derived artifacts, provisional Steward state, and provider-local imported logs. Some values will be directly emitted counters. Some will be processor summaries. Some will be guessed from incomplete windows. Some will be corrected after a bootstrap reconciliation. Some will be revised when a later bundle, vocabulary, or policy lens arrives. If Foundry flattens those into one `value` column plus a timestamp, it will make the datacube tidy at the cost of truth.

The low-regret move is small: when a value is not simply an as-observed value at a named cut, carry an **observation-status card**, an **adjustment witness**, and an **as-observed fence**.

Specimen 74 is therefore added. It is an observedness and adjustment seam, not a statistical processing engine.

## Lessons we must learn from the past

### 1) Observation status is part of cube meaning, not a comment
RDF Data Cube explicitly leaves room for attribute components that qualify observed values, including observation status such as estimated or provisional. SDMX maintains observation-status code lists and has had to clarify the distinction between estimated values and imputed values. Foundry should steal the idea that status belongs beside the cell, but should not copy any one code list as permanent law.

### 2) Imputation is a substitution, not raw measurement
NIST/OECD define imputation as entering or replacing a value where a response/data item is missing, unknown, unmeasured, or unusable. A value can therefore be numeric, bounded, and even useful while still not being an observed value. Foundry must not let imputed support rows become native evidence rows merely because a dashboard can plot them.

### 3) Adjustment can be methodologically serious and still not be raw truth
The Census Bureau's X-13ARIMA-SEATS software exists precisely because seasonal adjustment, regARIMA modeling, diagnostics, and many-series processing are real statistical work. The lesson is not that SlopOS needs seasonal adjustment. The lesson is that adjusted values often have a model/method family, input specification, diagnostics, and revision posture that change how they may be compared.

### 4) Vintages matter
ALFRED's whole public value proposition is retrieving the economic data vintage available on a specific date. That tells Foundry to keep revised/benchmark-adjusted/publication-cut values from silently replacing what a user, incident, model, or support card actually saw at an earlier cut.

### 5) Cell methods are a brilliant small idea
The CF conventions' `cell_methods` idea is exactly the kind of tiny residue Foundry should steal: say how a cell value was determined or derived over a named axis, such as `time: mean`, without forcing the file to become a statistical-method ontology. Foundry's adjustment witness should be similarly compact: method family, axis/window, recipe/model digest, and diagnostics pointer where known.

### 6) Quality flags must be self-describing enough to travel
CF flag variables use `flag_values` and `flag_meanings` so quality flags remain interpretable near the data. Foundry should avoid naked booleans like `is_adjusted` or `is_bad`; compact status families need enough meaning to survive export, cache, and support-card rendering.

### 7) Revision policy and adjusted/preliminary identity are serviceability facts
The IMF DQAF calls out source-data assessment, statistical techniques, validation of intermediate/output data, revision studies, and the clear identification of preliminary or revised data. Foundry should treat revised/provisional/adjusted identity as a serviceability and reproducibility fact, not as later prose.

### 8) SlopOS already has the boundary style
SlopOS observation export is bounded, redacted, pull-only, and policy-killable; CH-SNAPSHOT support bundles carry redaction profiles and manifest entries; quarantined derived attributes live on separate derived artifacts; MCP logging imports are provider-local diagnostics; Steward's provisional state explicitly confirms/refines/rolls back. Foundry should mirror that pattern: let adjusted/imputed/provisional values exist, but keep their status and use fence visible.

### 9) This is different from exactness, replay, and blankness
A value can be exact but imputed. A value can be replayable but seasonally adjusted. A value can be provisional but non-blank. A value can have a recipe witness and still need an as-observed fence. This seam does not replace specimens 45, 46, 61, 62, 67, 72, or 73; it prevents a specific laundering move those specimens do not fully block.

### 10) SlopOS being design-phase makes the conservative seam more valuable
Because SlopOS is still changing, Foundry should not commit to a final status-code taxonomy. But it should prevent the worst irreversible mistake now: letting early support tiles, diagnostic summaries, or model-assisted values look indistinguishable from direct native observations.

## Nifty ideas to steal without over-freezing

- **observation-status card** — compact residue for observed, estimated, imputed, provisional, revised, adjusted, forecast, substituted, synthetic, quality-flagged, or processor-derived posture.
- **adjustment witness** — compact residue for method family, recipe/model/spec digest, input cut, axis/window, side-input cut, diagnostics, reviewer or processor, and whether an unadjusted companion exists.
- **as-observed fence** — compact guardrail that says whether the value may be used as direct observed evidence, compared to raw values, backfilled into source history, or exported without status.
- **status-vocabulary pin** — a small code-list/profile/version pointer so `estimated`, `imputed`, and `provisional` do not drift across consumers.
- **unadjusted companion pointer** — optional link/digest to the raw/original value when retained and policy-allowed.
- **adjustment family** — imputation, seasonal adjustment, smoothing, interpolation, benchmark revision, manual correction, forecast, synthetic substitution, or diagnostic processor output.
- **diagnostic residue** — bounded metrics/check results from the adjustment process, explicitly smaller than a proof of correctness.
- **vintage cut** — publication/release/access cut that explains which version of a mutable series a reader saw.
- **raw-comparison refusal** — default guardrail against plotting adjusted and unadjusted values as one line without a compatibility note.
- **status survives cache/export rule** — materialized tables, JSON exports, support cards, and chart data must carry status or refuse to serve the value as ordinary raw data.

## What stays parked

- no universal official-statistics ontology;
- no mandatory SDMX status-code clone;
- no seasonal-adjustment, imputation, or forecasting engine;
- no general ML-model lineage plane;
- no universal data-quality score;
- no claim that imputed or adjusted values are inferior, only that they are not raw/as-observed by default;
- no rule that every adjusted value must retain the original raw value forever;
- no automatic replacement of historical values with the latest revised/benchmark version;
- no treating `estimated`, `imputed`, `provisional`, `forecast`, `revised`, `adjusted`, and `quality-flagged` as interchangeable;
- no treating an adjustment recipe as a validation verdict or release-policy pass.
