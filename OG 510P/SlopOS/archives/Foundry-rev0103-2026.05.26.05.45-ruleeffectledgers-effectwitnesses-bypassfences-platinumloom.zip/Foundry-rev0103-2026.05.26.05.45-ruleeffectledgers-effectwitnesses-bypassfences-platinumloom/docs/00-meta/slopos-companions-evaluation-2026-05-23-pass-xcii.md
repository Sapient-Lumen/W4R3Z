# SlopOS and companions evaluation — 2026-05-23 pass XCII

Focus: whether Foundry can account for actual reachable relying surfaces after distribution without claiming catalog completeness, custody, cache control, repair, deletion, or sibling authority.

## SlopOS pressure

SlopOS support surfaces can name a support bundle, a dashboard projection, and an audit extract as distribution targets. Rev0091 can account for those named targets. Rev0092 asks a sharper question: did the sweep find every reachable surface that can still carry or influence the semantic carrier, including aliases, object-store paths, notebook extracts, projected tiles, and delegated-worker copies?

A SlopOS operator can provide seed distribution manifests and carrier digests. Foundry can record that a dashboard tile was reachable through both a logical surface id and a cache path, that an external-audit CSV carried the new sidecar residue, that a ViewFS projection remained quarantined, that a delegated worker copy was permission-denied and fenced for recheck, and that a shadow CSV was discovered but not adopted. Foundry still does not assert SlopOS proof, cache invalidation, object custody, deletion, release approval, or source truth.

## Companion boundaries

| Companion | Surface-inventory interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may seed sweeps with distribution manifests, support-card carriers, and expected surfaces | SlopOS still owns source evidence, proof claims, and operator semantics |
| Harbor | may receive gap fences as evidence that public/external status should stay cautious | Harbor still owns external status and remediation verification |
| Ward | may use reachability witnesses as appraisal inputs | Ward still owns appraisal and trust verdicts |
| Steward | may observe retry/recheck attempts for inaccessible listings | Steward still owns effect lifecycle, retry budgets, and finality |
| Schell | may constrain what a sweep can inspect or retain | Schell still owns forgetting, minimization, and deletion authority |
| ViewFS | may expose trusted paths, aliases, and projection reachability | ViewFS still owns object identity, trusted paths, consent, and custody |
| Helm | may carry repair/intervention traces for blocked inventory gaps | Helm still owns repair custody and handback consequence |
| External audit notebook | may expose an adopted extract under multiple aliases | discovery is not audit opinion or certification |
| Dashboard cache | may expose a tile, stale CSV, and cache object path | reachability is not cache-control or purge proof |
| Delegated worker lane | may be unreachable or permission-denied | failed reachability is not absence or permission |

## What changed in this pass

- Added specimen 86 for surface inventory sweeps, reachability witnesses, and coverage-gap fences.
- Added a surface inventory rulebook so inventory gaps have named failure modes.
- Added v0 schemas for surface inventory sweeps, reachability witnesses, and coverage-gap fences.
- Added a specimen 86 fixture with complete, partial, and blocked sweeps; reachable, quarantined, retired, and unknown witnesses; and blocked/quarantined/recheck coverage-gap fences.
- Added `check_foundry_surface_inventory.py` and wired it into `make check`.
- Reused NIST CM-8 inventory accountability, DCAT discovery humility, OpenLineage alias/symlink pressure, SPDX relationship edges, and Kubernetes owner/dependent cleanup caution while keeping Foundry smaller than CMDBs, catalogs, lineage platforms, package graphs, orchestrators, or cleanup systems.

## Recommendation

Future Foundry revisions should treat distribution target lists as seeds, not the universe. A replacement carrier is not operationally safe merely because all named targets receipted it; the reachable surface inventory must either witness the relevant surfaces or leave coverage-gap fences that block stale, unknown, duplicate, inaccessible, and alias-ambiguous copies.
