# Research synthesis — pass XLVI

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from warehouse practice, metrics systems, and semantic-layer tooling: a value is unsafe unless the cube can say **which population it speaks about**, whether category memberships **overlap**, and whether the observed set is **complete enough** for the claim being made.

The smallest durable seam from this pass is:
- **population frame** — the declared universe of rows, objects, or subjects eligible to contribute to one value or result;
- **overlap class** — whether the categories or memberships in play are disjoint, overlapping, primary-only, or still unknown;
- **coverage witness** — whether the result covers the whole eligible frame, a filtered subset, a sample, a lagging partial view, or an explicit possibility/coverage set.

These are still smaller than a full semantic layer, denominator registry, allocation engine, or category lattice.
They simply keep future counts, percentages, and query-result summaries from pretending to describe a larger or cleaner universe than they really do.

## Lessons we must learn from the past

### 1) Summaries lie when the underlying grouping is not really a partition
Classic OLAP and warehouse work keeps rediscovering the same problem: if categories overlap, subtotals and grand totals stop meaning what users assume they mean.
Kimball’s bridge-table guidance is blunt that multivalued dimensions can over-count unless the design changes grain or carries an allocation/weighting factor.
Foundry should therefore make overlap posture explicit instead of treating every grouping as a safe partition.

### 2) “What didn’t happen” requires an explicit possibility set
Kimball’s factless coverage-table lesson is especially important for a young datacube.
You cannot honestly claim absence, completion rate, or missed events from activity rows alone.
You need a visible statement of the eligible population or coverage set.
That is exactly what a small **coverage witness** should preserve.

### 3) Whole-population identity and subset identity are different truths
Current semantic-layer tooling also makes a helpful distinction here.
dbt’s entity docs distinguish a **primary** entity that includes every record in the data platform from a **unique** entity that may cover only a subset.
Foundry should steal the lesson, not the product vocabulary: some identifiers describe the full frame, while others only name a subset or one reachable view.

### 4) Labels only help if reductions remain meaningful
Prometheus’s naming guidance gives a useful anti-folklore rule: either `sum()` or `avg()` across all dimensions of a metric should still be meaningful; otherwise the data should be split into multiple metrics.
That is an excellent discipline for Foundry.
If one query bucket means “components with tag X” and another means “components currently unhealthy,” the cube should not treat them as sibling partitions unless their overlap class says that is honest.

### 5) Coverage is a semantic fact, not just a query-plan accident
A result can be full-frame, sampled, filtered, revocation-bounded, view-scoped, or lagging, and those are different truths.
The datacube should not make readers reverse-engineer completeness from transport folklore, cache settings, or shell conventions.
A small coverage witness is cheaper and more honest.

## What to steal now
- a minimal **population frame** on any value-bearing or result-bearing family so the eligible universe is visible;
- explicit **overlap class** for whether sibling categories are disjoint, overlapping, primary-picked, or unknown;
- a **coverage witness** for full-frame, subset, sample, lagging partial, or explicit possibility-set posture;
- denominator discipline that inherits from the declared frame instead of inventing ad-hoc “total” folklore later;
- restraint about percentages and distinct-ish results unless their frame and overlap posture are clear.

## What to keep parked
Do not yet promote:
- a universal denominator registry;
- a built-in allocation/weighting engine for overlap repair;
- a global partition taxonomy for every category family;
- one mandatory “primary category” rule;
- or a promise that every count can be rolled into a percent-of-total story.

## Resulting recommendation
The next healthy move is not “design all dimensions and totals.”
It is to let Foundry say, for any future count, ratio, or query result:
1. which population could contribute,
2. whether the compared buckets overlap,
3. and how complete the observed set is.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from classic dimensional modeling, current semantic-layer tooling, and metrics practice.
