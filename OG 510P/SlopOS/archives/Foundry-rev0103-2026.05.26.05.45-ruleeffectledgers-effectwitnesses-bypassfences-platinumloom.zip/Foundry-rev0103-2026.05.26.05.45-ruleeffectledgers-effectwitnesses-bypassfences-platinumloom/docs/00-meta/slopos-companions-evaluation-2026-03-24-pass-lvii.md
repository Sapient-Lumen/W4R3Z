# SlopOS + companions evaluation — pass LVII

This pass checks whether **sample class, inclusion basis, and expansion fence** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal statistics plane, a built-in representativeness algebra, or an automatic upweighting engine for preview-shaped values.

## Why SlopOS pressures this seam now

### 1) SlopOS already names one important sampling family and keeps it explicitly smaller than planner truth
`mcp-sampling-import-boundary-v0.md` says imported MCP sampling is provider-local, request-local nested model-generation mechanics only.
That means sampled nested generations are already a distinct class of output rather than census truth about all possible work.
Foundry needs a compact **sample class** for exactly that kind of future read model.

### 2) SlopOS repeatedly treats previews as smaller than full object or population truth
`openuri-preview-metadata-boundary-v0.md` says preview and unfurl semantics are not portable OpenURI truth, and `tool-ui-file-boundary-v0.md` keeps temporary preview/download URLs as staging convenience rather than durable object authority.
That pressures Foundry toward an explicit **sample class** for bounded previews and temporary convenience cuts.

### 3) SlopOS keeps request identity separate from live sample state
`timeproof-request-state-posture-v0.md` says a stable CH-TIMEREQ request key is not the same thing as current portal-owned live timeproof sample state.
That is a strong hint that a future cube should preserve the **inclusion basis** for sampled observations instead of collapsing request identity, admission, and current sample truth into one cheerful row.

### 4) SlopOS query posture is already snapshot-first and view-scoped
`attribute-query-schema-v0.md` says query evaluation is snapshot-first and capability-scoped in v0, while saved-query persistence remains shell-owned rather than app-visible inventory or background watch state.
That means future preview or sampled summaries should not silently become denominator truth for the whole subject universe.
They need an **expansion fence**.

## What to steal into Foundry

### sample class
A compact witness for whether a visible value came from:
- a full census,
- a deterministic hash/key sample,
- a probabilistic keep rule,
- a bounded preview,
- or another explicitly partial cut.

This is smaller than a statistics product.
It just stops preview and sample outputs from sounding like whole-population truth.

### inclusion basis
A compact witness for how rows entered the visible sample.
Examples:
- block sampling,
- hash-key selection,
- probability threshold,
- first-`N` preview cap,
- explicit manual review subset,
- or provider-local nested-sampling admission.

This is smaller than a full query planner.
It just keeps the “why these rows?” answer attached to sampled output.

### expansion fence
A compact witness for whether the visible sample supports:
- no expansion,
- exact factor-based scaling,
- probability-aware estimation,
- biased/unknown representativeness,
- or preview-only/non-denominator posture.

This is smaller than a weighting DSL.
It simply prevents downstream surfaces from treating every partial cut as scale-up-ready truth.

## Why this seam is small enough now
It does **not** require:
- a universal representativeness calculus;
- one cube-wide weighting engine;
- a promise that preview cards are statistically meaningful;
- or automatic comparability across every provider’s sampling stack.

It only says that once Foundry emits a sampled or preview-shaped value, it should preserve:
1. **what class of sample** it is,
2. **how rows got in**,
3. and **whether expansion is legal**.

## Recommended Foundry posture
Promote **sample class**, **inclusion basis**, and **expansion fence** as a narrow honesty seam for sampled, preview-shaped, and convenience-cut values.
Keep the larger representativeness, weighting, and statistical-correction questions parked.

This matches current SlopOS discipline well: SlopOS already distinguishes imported sampling from planner truth, already treats previews as smaller than durable object truth, and already keeps request identity separate from current sample state.
