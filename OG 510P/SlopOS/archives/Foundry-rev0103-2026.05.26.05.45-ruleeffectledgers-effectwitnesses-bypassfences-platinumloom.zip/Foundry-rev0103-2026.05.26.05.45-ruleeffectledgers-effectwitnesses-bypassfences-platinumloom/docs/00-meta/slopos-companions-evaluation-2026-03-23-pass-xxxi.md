# SlopOS plus companions evaluation — pass XXXI

This pass tested whether Foundry needs a small meaning seam for *new desired state that outruns its status surfaces*.
The answer is yes, but only narrowly.

## What SlopOS already contributes
The uploaded SlopOS archive already carries the deeper control-plane discipline.
`acp-acceptance-completion-posture-v0.md` insists that accepted request receipts do not prove downstream completion or current live state.
`approval-basis-posture-v0.md` insists that mutable basis must be bound exactly instead of letting review silently follow later drift.
`attention-durable-status-boundary-v0.md` and neighboring status/receipt surfaces keep durable exported status smaller than local provider reality.
That is already the right direction.

## What Foundry should own instead
Foundry should own the semantic split that keeps three facts separate:
1. a newer desired basis/spec/request now exists as one **intent generation**;
2. current status has only caught up through some **observed generation**;
3. a **stale-status fence** blocks old green/ready/applied claims from being treated as current truth about the newer intent.

That seam is smaller than a reconciliation controller and smaller than a task/completion subsystem.
It is just enough vocabulary to stop later docs from flattening “latest desired”, “latest seen”, and “latest settled” into one flattering status object.

## Companion-cube fit
- **Helm** already keeps request/admission/history smaller than current live truth; that supports a smaller Foundry claim that older success surfaces can remain historically valuable while still stale against a newer intent generation.
- **ViewFS** already keeps apply sessions, exact basis requirements, and durable results separate; that supports a Foundry claim that observed/apply status can lag newer desired state without becoming dishonest.
- **Ward** keeps evidence smaller than verdict; likewise, a stale green status light is still evidence, but not a verdict on the newest intent.
- **Steward** remains the more natural home for broad operational rollout or maintenance-window policy, so Foundry should stop at the semantic seam.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small but load-bearing distinction between:
- **intent generation** — what newer desired state exists now,
- **observed generation** — what current status has actually caught up to,
- **stale-status fence** — what stops old success surfaces from impersonating truth about newer intent.

If Foundry misses that seam now, later revisions will be tempted to let “accepted”, “applied”, “ready”, “green”, and “current” collapse into one cozy noun that quietly ignores status lag and controller/agent catch-up.
