# SlopOS and companions evaluation — 2026-05-25 pass XCIV

Focus: whether Foundry can account for semantic obligations after audience/purpose exposure without claiming authorization, legal compliance, consent, public release, deletion, custody, audit opinion, or sibling authority.

## SlopOS pressure

SlopOS support surfaces now have egress sidecars, refusal receipts, regression locks, waivers, consumer passports, delegation boundaries, recall/readmission paths, distribution/adoption receipts, surface inventory, and exposure ledgers. Rev0094 asks what happens after the right audience sees the right surface: did the surface also carry the obligations that make it safe to interpret?

A SlopOS support dashboard can be exposed to operators and service accounts, but it must still carry sidecar, classification-pin, observation-status, disclosure-cut, recall-route, and no-reexport obligations. An external-audit CSV can be exposed to a read-only auditor, but must not become audit opinion and must preserve recall and no-reexport boundaries. A Ward preview can acknowledge only a partial obligation set until interpretation gates preserve the "not Ward verdict" boundary. A ViewFS projection with inherited access can remain quarantined until obligation rebinding is explicit. A delegated worker and a public link can be blocked because required obligations cannot be acknowledged.

## Companion boundaries

| Companion | Obligation-accounting interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may seed obligations such as sidecar required, classification pins, disclosure cuts, recall routes, and no-reexport hooks | SlopOS still owns operator policy and proof claims |
| Harbor | may receive public-link and external-status obligation-drift fences | Harbor still owns external status, correction, and remediation verification |
| Ward | may receive acknowledgment witnesses as appraisal inputs | Ward still owns appraisal and trust verdicts |
| Steward | may schedule rechecks for expired or permission-denied obligations | Steward still owns lifecycle, retry budgets, and finality |
| Schell | may constrain which obligation evidence is retainable | Schell still owns minimization, forgetting, and privacy authority |
| ViewFS | may expose projection/ACL obligations and inherited-access rebinding needs | ViewFS still owns object identity, consent fences, and custody |
| Helm | may consume blocked obligation-drift fences as repair/intervention inputs | Helm still owns repair custody and handback consequence |
| External audit notebook | may acknowledge sidecar, recall, and no-reexport obligations | acknowledgment is not audit opinion or certification |
| Dashboard cache | may acknowledge display/status/pin obligations | acknowledgment is not cache policy or access-control authority |
| Public-link scanner | may discover that no valid acknowledgment exists | public reachability is not obligation satisfaction, consent, or public release |

## What changed in this pass

- Added specimen 88 for obligation ledgers, acknowledgment witnesses, and obligation-drift fences.
- Added an obligation accounting rulebook so semantic duty-carriage gaps have named failure modes.
- Added v0 schemas for obligation ledgers, acknowledgment witnesses, and obligation-drift fences.
- Added a specimen 88 fixture with complete, partial, and blocked obligation ledgers; acknowledged, partial, quarantined, refused, and missing acknowledgment examples; and drift fences for Ward boundary laundering, ViewFS inherited obligation rebinding, worker missing acknowledgment, public-link obligation drift, and shadow reexport.
- Added `check_foundry_obligation_accounting.py` and wired it into `make check`.
- Reused ODRL duty/constraint pressure, XACML obligation/advice separation, and DPV machine-readable purpose/recipient/rights metadata while keeping Foundry smaller than policy engines, authorization systems, privacy-law frameworks, consent management, rights management, public-release workflows, deletion, custody, and sibling verdict systems.

## Recommendation

Future Foundry revisions should treat exposure accounting as a necessary input to obligation accounting, not as closure. A surface is not safe to reuse merely because the intended audience can see it; the required semantic obligations must be acknowledged inside scope or fenced when they drift, expire, widen, or fail to travel.
