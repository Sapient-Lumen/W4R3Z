# Research synthesis — pass LVII

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from warehouse sampling, approximate query processing, and telemetry sampling systems: **a visible value should not pretend to be census truth unless the cube can say whether it came from a full population, a deterministic subsample, a probabilistic keep rule, or a bounded preview — and whether any expansion back toward the population is actually justified.**

The smallest durable seam from this pass is:
- **sample class** — the compact witness for whether the visible value comes from a census, deterministic sample, probabilistic sample, bounded preview, convenience subsample, or other explicitly non-census cut;
- **inclusion basis** — the compact witness for how rows entered the visible sample: block sampling, hash-key selection, probability threshold, first-`N` preview cap, manual review subset, or another explicit selection basis;
- **expansion fence** — the compact witness for whether the visible sample may be expanded toward a population claim: exact factor known, probability-known estimate, biased/unknown, preview-only, or no legal expansion at all.

These are still smaller than a universal statistics plane, a representativeness theorem, or a built-in sample-weighting algebra.
They simply keep future Foundry rows from laundering previews and samples into population truth.

## Lessons we must learn from the past

### 1) A sample is not a census, and the sampling method changes what the sample means
BigQuery says `TABLESAMPLE` selects a percentage of **data blocks** rather than individual rows, notes that results can change between runs, and warns that partitioning and clustering can make sample sets more biased.
That is the lesson: one sampled row family does not automatically stand in for the full eligible population.

### 2) Deterministic subsamples are a different species from vague previews
ClickHouse treats `SAMPLE` as approximate query processing, makes the mechanism deterministic, keeps the same subset alignment across tables that share the sampling key, and exposes `_sample_factor` when approximate aggregate expansion is needed.
Foundry should steal that discipline: the cube should know whether a sample was deterministic and whether the expansion factor is actually knowable.

### 3) Sampling decisions become part of meaning once they are propagated across a pipeline
OpenTelemetry’s sampling docs separate sampled from not-sampled traces, and the probability-sampling spec says inconsistent keep/drop decisions across participants make traces unusable because the resulting span set is incoherent.
That means sampled output should carry enough residue to say how and why it was admitted.

### 4) Expansion should stay fenced unless the inclusion basis earns it
Some samples support approximate expansion, some support only bounded preview, and some are too biased or convenience-shaped to scale honestly.
Foundry should make that legal boundary explicit instead of letting downstream surfaces guess.

## What to steal now
- a **sample class** beside any future value family that is not guaranteed to be full-population truth;
- an **inclusion basis** so deterministic, probabilistic, block, and preview cuts do not collapse into one generic “sampled” bit;
- an **expansion fence** so consumers know whether population-level scaling is legal, estimated, biased, or forbidden;
- a habit of treating preview/triage value as smaller than denominator truth;
- and a habit of keeping probability or factor residue explicit whenever a sample is meant to inform a wider estimate.

## What to keep parked
Do not yet promote:
- a universal weighting or sample-correction DSL;
- one cube-wide representativeness theorem;
- automatic expansion from preview cards or first-page slices into totals;
- a global stats/uncertainty product plane;
- or a claim that every telemetry sample can be compared directly across tools and providers.

## Resulting recommendation
The next healthy move is not “build a statistics product inside the cube.”
It is to let Foundry say, for any future sampled or preview-shaped value family:
1. which **sample class** the visible output belongs to,
2. what **inclusion basis** admitted rows into that sample,
3. and what **expansion fence** limits any claim about the wider population.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from BigQuery `TABLESAMPLE`, ClickHouse `SAMPLE`, and OpenTelemetry sampling discipline.
