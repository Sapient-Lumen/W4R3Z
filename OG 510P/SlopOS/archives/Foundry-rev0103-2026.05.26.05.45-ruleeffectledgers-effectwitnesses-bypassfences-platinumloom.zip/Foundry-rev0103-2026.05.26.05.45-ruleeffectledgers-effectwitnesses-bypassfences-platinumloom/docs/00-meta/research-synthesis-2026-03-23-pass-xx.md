# Research synthesis — pass XX

This pass keeps Foundry narrow and learns one more thing from staged deployment systems: **a prepared foreign generation is smaller than the live basis, and the activation cut deserves its own truth rather than hiding inside “upgrade succeeded”.**

## Outside lessons
1. **Nix profiles make the active generation explicit and switches atomic.**  
   Profiles are versioned for atomic upgrades and rollbacks, with generations kept as explicit history and the active profile updated by an atomic symlink switch. Foundry should steal the discipline that candidate and active basis are different facts.

2. **OSTree shows that `/etc` merge timing is semantically load-bearing.**  
   A pending deployment can lose later `/etc` edits if it was created too early, which is why staged deployments delay the 3-way `/etc` merge until reboot/shutdown. Foundry should preserve that activation timing is part of realization truth, not just a transport detail.

3. **bootc treats staged deployment as a first-class but smaller object.**  
   A `--download-only` update creates a staged deployment that is visible and inspectable, but it is not applied until a later explicit step; it may be discarded on reboot if never applied, or replaced by a newer staged deployment. Foundry should therefore keep candidate generations visibly weaker than the currently booted basis.

4. **systemd sysext/confext keeps overlay activation explicit and reversible.**  
   Extensions are managed through explicit merge, unmerge, and refresh actions, and configuration extensions for `/etc` default to `MS_NOEXEC`. Foundry should steal both ideas: attach is a real lifecycle seam, and configuration overlays may deserve a smaller execution posture than code overlays.

## Resulting Foundry move
Do not decide yet whether the durable nouns are `staged generation`, `activation cut`, `booted basis`, and `rollback selector`, or whether some later compress behind a smaller activation family.
For now, keep them alive as specimen nouns and demand that they improve:
- one candidate-only specimen,
- one explicit activation specimen,
- and one rollback / revert specimen.

## Fresh ideas worth stealing
- **staged generation** — prepared foreign basis that is real but not yet active.
- **activation cut** — explicit moment when the candidate becomes the live basis.
- **booted basis** — the currently active basis, kept distinct from queued or downloaded candidates.
- **rollback selector** — explicit choice of prior basis rather than panic folklore.
- **noexec-by-default config overlay** — reminder that config layers may deserve a weaker execution posture than runtime cargo.
