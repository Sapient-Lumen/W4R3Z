# Research synthesis — pass XXI

This pass keeps Foundry narrow and learns one more thing from staged and transactional update systems: **a basis that has crossed the activation cut can still be smaller than the blessed current basis until health says it is real enough to keep.**

## Outside lessons
1. **systemd makes “boot complete” an explicit extension point instead of a hidden feeling.**  
   `boot-complete.target` is the generic synchronization point for units that must succeed before a boot is considered successful, and `systemd-bless-boot.service` only marks the boot entry good after that target is reached. Foundry should steal the idea that post-activation success is a named seam, not an implication of “it booted once”.

2. **RAUC treats boot confirmation and fallback as part of the update story, not cleanup trivia.**  
   Its documentation says update handling does not end when installation succeeds, because later crashes or invalid behavior may still appear; `status mark-good` / `mark-bad` and bootloader fallback stay first-class. Foundry should preserve that installed bytes, trial boot, and durable currentness are different facts.

3. **ChromeOS keeps tries, success, and rollback explicitly separate.**  
   A new kernel gets priority with a bounded tries counter and `successful=0`; firmware decrements tries on each boot, and only a later “set good kernel” step ends rollback risk. Foundry should keep bounded trial posture visible instead of calling the newly booted basis simply current.

4. **Android A/B keeps slot success, retry count, and rollback protection timing explicit.**  
   Switching slots clears “successful” and resets retry count; boot attempts decrement retries; a slot that is not marked successful can become unbootable and trigger fallback. Verified Boot guidance also requires marking the slot `SUCCESSFUL` before updating rollback-protection metadata. Foundry should keep post-activation commitment separate from first boot and separate again from anti-rollback posture.

5. **Mender makes “verify reboot” and “commit” distinct operations.**  
   `ArtifactVerifyReboot` checks that the right partition actually booted, while `ArtifactCommit` disables automatic rollback and makes the update permanent. Foundry should steal that commit is a later latch, not a synonym for activation.

6. **systemd-sysupdate offers a great future clue about coherence without forcing an early model.**  
   Multiple transfer files can be bound by a common version identifier into one target so that a kernel, root filesystem, and verity partition update together. That suggests a future Foundry seam around multi-resource basis coherence, but not a promotion yet.

7. **TUF and Uptane warn against mixed-time bundles and advancing before confirmation.**  
   TUF is explicitly designed to resist mix-and-match, freeze, and rollback attacks, while Uptane recommends that a director not issue a new conflicting bundle until it has confirmation from the last vehicle version manifest. Foundry should collect the idea of a coherence target and a prior-confirmed bundle receipt, but keep both parked until a second specimen proves they belong here.

## Resulting Foundry move
Do not decide yet whether the durable nouns are `trial basis`, `success latch`, and `fallback budget`, or whether some later compress behind a smaller activation/commit family.
For now, keep them alive as specimen nouns and demand that they improve:
- one trial-boot specimen,
- one explicit success-mark / bless specimen,
- and one bounded fallback specimen.

Also collect — but do not promote — two wider ideas for a later pass:
- **coherence target** — a grouped multi-resource basis change that should move together.
- **prior-confirmed bundle receipt** — evidence that the last intended basis family really became the currently known good family before a new conflicting one is issued.

## Fresh ideas worth stealing
- **trial basis** — a basis that is active enough to run but still weaker than blessed current truth.
- **success latch** — explicit later mark that turns trial activation into durable currentness.
- **fallback budget** — bounded remaining tries before deterministic return to known-good basis.
- **boot-complete target** — composable success milestone instead of hidden “ready enough” folklore.
- **coherence target** — future grouped version unit for multiple related resources.
- **prior-confirmed bundle receipt** — future defense against “new bundle over uncertain prior state”.
- **booted smaller than blessed** — a standing anti-regrowth rule.
