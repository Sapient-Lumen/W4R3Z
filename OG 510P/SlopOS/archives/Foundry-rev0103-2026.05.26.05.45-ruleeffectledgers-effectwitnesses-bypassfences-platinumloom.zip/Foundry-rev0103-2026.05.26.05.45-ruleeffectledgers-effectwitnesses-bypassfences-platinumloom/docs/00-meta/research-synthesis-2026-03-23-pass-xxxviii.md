# Research synthesis — pass XXXVIII

This pass stays deliberately narrow.
Pass XXXVII kept **current absence**, **durable withdrawn state**, and **safe resurrection/reuse** apart.
The next cheap-to-preserve seam is what happens when a foreign token, lease descriptor, certificate, or grant receipt is *still exactly the thing that was once issued* but is no longer enough to prove *current validity now*.
Several mature systems distinguish three truths that are easy to flatten if the cube only says “token”, “certificate”, “lease”, or “proof”:

1. one artifact can remain exact **issuance evidence** long after issuance;
2. current acceptability may require a separate **live-validity check** because the artifact can be expired, revoked, policy-inapplicable, or otherwise no longer active;
3. any positive current-validity answer itself lives on a clock, so a **recheck horizon** matters before cached good news can be trusted again.

That split is worth preserving now because it is smaller than a whole auth subsystem, smaller than a universal lease/status plane, and smaller than a revocation product family.
It is just enough honesty to stop “I possess a once-valid thing” from quietly impersonating “it is still valid for this use right now”.

## Lessons from current outside systems

1. **OAuth token introspection exists because a token string or structure is smaller than current active state.**  
   RFC 7662 defines introspection as asking an authorization server for the token’s current state and metadata, and says “active” commonly means issued by that server, not expired, not revoked, and valid for use at the protected resource making the call.
   That is the cleanest anti-lesson: possession of a token and current validity are different truths.

2. **Revocation changes current truth even when the old token bytes still exist.**  
   RFC 7009 says a revocation request invalidates the actual token and, when applicable, other tokens based on the same authorization grant.
   So exact issuance evidence does not remain a portable current-state oracle after revocation.

3. **Certificate ecosystems make the same split and also put the status answer on a clock.**  
   RFC 9608 quotes RFC 5280 path validation: at the current time, the certificate is not revoked, and that fact may need CRLs, status information, or out-of-band mechanisms.
   RFC 6960 then says OCSP responses carry `thisUpdate` and `nextUpdate`, meaning the responder says when the status was last known correct and when newer information will be available.
   That is a strong clue that “currently good” is not timeless; it has a recheck horizon.

4. **Some ecosystems reduce revocation dependence by shrinking credential lifetime or by distributing status separately.**  
   SPIFFE’s workload APIs return short-lived X.509-SVIDs and JWT-SVIDs, which is one honest way to keep current-validity windows small.
   RFC 9770 complements introspection with a Token Revocation List for constrained devices, showing another design move: current invalidation can travel as a separate status surface instead of hiding inside the original artifact.

## What this means for Foundry

Foundry should preserve a tiny validity seam so later docs cannot let “exactly what was issued”, “currently valid now”, and “recently checked enough” collapse.
The useful promoted nouns are:
- **issuance witness** — exact minted descriptor/proof/receipt for one once-approved grant, token, certificate, or foreign handle shape;
- **live-validity witness** — current authoritative statement that the thing remains active/usable for one context now;
- **recheck horizon** — boundary after which old positive-validity knowledge is too stale and a recheck or fresh short-lived artifact becomes the honest path.

The main past lesson is not “build a revocation platform”.
It is the narrower rule that **issuance truth, current validity, and freshness of that validity answer live on different clocks**.
Systems that flatten those clocks end up lying about whether a still-present artifact can be trusted now, whether revocation already happened elsewhere, and whether old “good” status is still fresh enough for current use.

## Candidate nouns worth collecting
- **issuance witness** — bounded evidence of what was actually minted or granted.
- **live-validity witness** — current active/non-revoked/non-expired statement for one exact context.
- **recheck horizon** — explicit freshness window on status knowledge.

## Things to keep parked
- a universal auth or lease status plane;
- a promise that every issuance witness has a portable current-status endpoint;
- any collapse of revocation and expiry into one invisible failure bucket;
- any claim that one old positive validity answer remains trustworthy forever.

## Provisional judgment
Promote only the seam.
Foundry should be able to say that one artifact remains an **issuance witness**, that a separate **live-validity witness** may still be needed before present use is honest, and that a **recheck horizon** can age out old good news without implying the artifact itself changed.
That is especially valuable while SlopOS is still plastic enough to avoid teaching later docs that “descriptor in hand”, “status when last checked”, and “valid right now” always mean the same thing.
