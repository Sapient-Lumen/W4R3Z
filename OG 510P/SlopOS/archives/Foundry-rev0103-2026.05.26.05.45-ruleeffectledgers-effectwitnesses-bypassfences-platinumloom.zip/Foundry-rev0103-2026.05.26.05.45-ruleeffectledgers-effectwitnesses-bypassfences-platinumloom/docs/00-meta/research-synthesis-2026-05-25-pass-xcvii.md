# Research synthesis — pass XCVII

Rev0097 moves the pressure one step after verification. Specimen 90 made completion evidence sampleable; this pass asks what happens the next hour, day, or reuse attempt. The new failure is stale confidence: a verification audit can pass, then its carrier, rendered surface, recall route, public exposure, no-reexport guard, or delegated-worker precheck can drift.

## Outside pressure

Prometheus alerting rules are useful not because Foundry needs alerts, but because they separate condition evaluation from firing state and preserve a `keep_firing_for`-style persistence window to avoid false resolution and flapping folklore. Foundry steals the scar, not the alert system: a drift signal can be clear, warning, firing, stale, missing, flapping, superseded, or quarantined, but no signal becomes source truth, authorization, or incident closure.

Kubernetes probes are useful because they are periodic diagnostics with consequences that stay scoped: liveness, readiness, and startup checks diagnose a running container and trigger local traffic/restart behavior, not global semantic truth. Foundry steals the periodic diagnostic shape for recheck cadences while refusing control-plane, scheduling, or lifecycle authority.

Existing Foundry pressure also matters. Dagster freshness policies kept freshness expectations smaller than asset truth; RFC stale controls kept freshness/staleness explicit; verification audit fixtures kept sampled evidence smaller than audit opinion. Rev0097 combines those scars: continuing verification requires cadence, drift signal, and stale-verification fences.

## New seam

A **recheck cadence** says when a source verification audit must be probed again, what trigger or interval applies, which carrier/surface/consumer/audience/purpose scope is covered, which drift signals are required, and what it refuses to mean.

A **drift signal** says what was observed between verification audits under a named probe basis: sidecar digest still matches, classification pins still replay, recall route resolves, public link has no-reexport guard, inherited access was rebound, delegated worker rechecked before execution, and so on.

A **stale-verification fence** blocks old verification from being reused when a cadence was missed, signal is risky, public exposure widened, inherited scope is stale, no-reexport is missing, a worker signal is flapping, or a paused/retired surface is treated as active.

## Audit/refactor

The structural refactor is `schema-fixture-coverage-audit-v0`: a machine-readable manifest now lists schema, fixture, checker, and documentation surfaces. The point is not to validate all JSON Schema. The point is to make an unlisted schema, missing fixture, or unregistered checker visible as cube drift.

## Speculation

Foundry is developing a narrow temporal discipline: semantic residue does not merely survive export; it has a freshness posture. The likely future noun is not a global monitor. It is a **semantic liveness envelope** that summarizes the latest valid cadence/signal/fence posture for a carrier, but only after more generated tamper cases prove the shape is stable.

## Refusal line

Do not let recheck cadence become monitoring SLA, readiness, permission, source truth, legal compliance, audit opinion, incident closure, repair completion, lifecycle finality, or sibling verdict. The cadence is just the next required chance to distrust old verification.
