# Research synthesis — pass XXVI

This pass keeps Foundry narrow and learns one more thing from update ecosystems: **a blessed current basis can still be under a separate monotonic downgrade bar, and that bar often advances only after an explicit success/commit moment.**

## Outside lessons
1. **Android A/B keeps rollback protection behind success.**  
   Android’s boot flow says an A/B slot must be marked `SUCCESSFUL` before rollback-protection metadata is updated. The A/B FAQ makes the implication explicit: until the new image successfully boots, rollback protection does not treat it as current; after that, you cannot simply go back.

2. **Android version binding turns patch/version state into a ratchet.**  
   Keymaster/KeyMint binds keys to OS and patch level, upgrades keys before use on newer systems, and invalidates the previous version so that devices and keys ratchet forward together instead of letting “old but once good” stay equally admissible.

3. **TUF treats trusted metadata as a persisted monotonic floor, not a fresh convenience lookup.**  
   Clients must reject lower metadata versions as rollback attacks, reject expired metadata as freeze attacks, and persist newly trusted metadata. That is a strong lesson: anti-rollback lives in durable remembered state, not just in whatever the server offers now.

4. **RAUC shows why monotonic floors and ordinary rollback are different truths.**  
   `min-bundle-version` rejects older bundles once the updated system runs. RAUC also documents the awkward but important consequence: if you need older content later, you may need a newer bundle version that carries that older content. That means “rescue path” is sometimes a different thing from “ordinary rollback”.

## Resulting Foundry move
Do not decide yet whether `rollback floor`, `ratchet mark`, and `rescue path` belong under basis lineage, currentness, security posture, or a still-smaller anti-downgrade sideband.
For now, keep them alive as specimen nouns and demand that they improve:
- one A/B-style trial→success→floor-advance specimen,
- one metadata-version or expiry-ratchet specimen,
- and one rescue/recovery specimen where older functional content returns only through an explicit path.

Also keep two adjacent ideas parked rather than promoted:
- **floor witness card** — compact residue naming which monotonic floor is currently in force;
- **downgrade exception chip** — concise explanation of why ordinary rollback is barred and what explicit rescue path remains.

## Fresh ideas worth stealing
- **rollback floor** — monotonic lower bound below which ordinary selection/install/boot no longer counts as admissible.
- **ratchet mark** — explicit event or receipt that advances the rollback floor, often after success/commit.
- **rescue path** — separate explicit recovery path for older content when ordinary rollback is barred.
- **floor witness card** — future compact residue for the active monotonic floor.
- **known-good smaller than rollback-safe** — a standing anti-regrowth rule.
