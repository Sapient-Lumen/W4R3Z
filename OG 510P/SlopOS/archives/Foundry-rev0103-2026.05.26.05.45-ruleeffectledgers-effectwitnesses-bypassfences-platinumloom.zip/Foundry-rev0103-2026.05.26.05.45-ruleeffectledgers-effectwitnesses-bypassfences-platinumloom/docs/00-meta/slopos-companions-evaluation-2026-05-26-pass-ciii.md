# SlopOS companions evaluation — 2026-05-26 pass CIII

## SlopOS

SlopOS support-card and CH-* surfaces can consume rule-effect ledgers when they need to know whether a Foundry rule result actually bound an egress refusal, quarantine, warning, or no-op state. They must not treat effect residue as SlopOS proof, operator trust, or policy approval.

## Ward

Ward can consume effect witnesses as caveated evidence that a Foundry-side warning or refusal did or did not bind for a preview surface. Foundry must not decide Ward appraisal, trust verdicts, or delegation authority.

## ViewFS

ViewFS can consume bypass fences when projections or aliases attempt to reuse a rule result without effect binding. Foundry must not decide filesystem identity, consent, custody, trusted paths, or deletion.

## Harbor

Harbor can consume informational/no-effect ledgers when a correction queue needs to know that Foundry did not bind a correction effect. Foundry must not decide outside-fact truth, membrane truth, or remediation authority.

## Steward and Helm

Steward and Helm can consume partial/bypassed effect witnesses when retry or repair paths are tempted to treat checker success as effect finality. Foundry must not decide retry finality, repair success, or intervention custody.

## Schell

Schell can consume bypass fences for no-reexport, recall, retention-adjacent, and public-link paths. Foundry must not decide forgetting, deletion, minimization, or retention authority.
