# SlopOS and companions evaluation — 2026-05-22 pass LXXXVIII

Focus: whether Foundry can carry delegated semantic acts without turning them into sibling authority, approval, or transitive trust.

## SlopOS pressure

SlopOS support surfaces may need export workers, notebooks, repair queues, or sibling input queues to prepare sidecar-backed packets. The worker can carry Foundry residue and run Foundry gates, but it does not inherit SlopOS proof authority or operator semantics. A SlopOS grant to prepare an external review packet must stay narrower than a proof claim, approval, or evergreen access right.

## Companion boundaries

| Companion | Delegation-boundary interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| Ward | may rely on a worker-prepared evidence packet only as appraisal input | Ward still issues appraisal, consequence, and trust verdicts locally |
| Harbor | may attach outside-fact aftermath to a reliance receipt | Harbor still owns membrane authority and external status |
| Steward | may consume delegated residue for retry/replay context | Steward still owns effect finality and operational lifecycle |
| Schell | may constrain delegated drill-through and retention posture | Schell still owns forgetting and minimization authority |
| ViewFS | may display delegated projection evidence | ViewFS still owns object identity, trusted paths, and consent fences |
| Helm | may carry repair traces as delegated evidence | Helm still owns repair custody and intervention consequence |
| SlopOS | may grant a narrow worker act for support-card egress | SlopOS still owns boundary-family proof claims and operator semantics |
| External audit notebook | may rely on a packet only for the declared review purpose | does not become an audit-opinion or certification surface |
| Delegated export worker | may carry residue and emit receipts | does not own interpretation, verdict, permission, or redelegation authority |

## What changed in this pass

- Added specimen 82 for delegation warrants, reliance receipts, and transitive-use fences.
- Added a delegation-boundary rulebook so delegated semantic acts have named failure modes.
- Added v0 schemas for delegation warrants, reliance receipts, and transitive-use fences.
- Added a specimen 82 fixture with active, expired, and revoked warrants; allowed and refused reliance receipts; and transitive-use fences.
- Added `check_foundry_delegation_boundaries.py` and wired it into `make check`.
- Reused RFC 8693 token-exchange actor-chain pressure, W3C Verifiable Credentials presentation/issuer/holder/verifier pressure, RFC 9334 RATS relying-party/appraisal pressure, and companion-cube ownership pressure while keeping Foundry smaller than authorization, credential, attestation, trust, legal-agency, or audit systems.

## Recommendation

Future Foundry revisions should not treat a delegated act as durable authority. A handoff becomes meaningful only when the delegation warrant, reliance receipt, transitive-use fence, consumer passport, portability witness, and interpretation gate agree about act, scope, purpose, audience, residue, and forbidden inferences.
