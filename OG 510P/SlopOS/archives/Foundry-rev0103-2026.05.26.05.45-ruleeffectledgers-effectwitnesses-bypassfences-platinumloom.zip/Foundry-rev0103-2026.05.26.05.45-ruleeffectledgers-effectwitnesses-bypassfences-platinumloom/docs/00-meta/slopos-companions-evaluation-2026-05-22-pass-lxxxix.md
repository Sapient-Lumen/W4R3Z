# SlopOS and companions evaluation — 2026-05-22 pass LXXXIX

Focus: whether Foundry can invalidate previously emitted semantic carriers without deleting history or becoming a status authority.

## SlopOS pressure

SlopOS support surfaces may emit sidecar-backed packets, refusal receipts, waiver-scoped reports, consumer-passported dashboards, and delegated review artifacts. Later, SlopOS or a companion may discover a bad classification pin, stale materialization cut, withdrawn waiver, revoked delegation, or disclosure-risk issue. Foundry needs a way to carry the invalidation to consumers and caches without asserting SlopOS source truth, Ward trust, Harbor external status, or Schell retention policy.

A SlopOS correction can trigger a Foundry revocation notice for a Foundry carrier. It does not let Foundry rewrite SlopOS evidence or decide the downstream verdict.

## Companion boundaries

| Companion | Revocation/recall interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may trigger notices when support-card residue becomes unsafe | SlopOS still owns proof claims, operator semantics, and source evidence |
| Harbor | may provide outside-fact aftermath or stale-surface status that explains a notice | Harbor still owns membrane authority and external status |
| Ward | may receive recall receipts as appraisal inputs | Ward still owns appraisal, trust verdicts, and consequence decisions |
| Steward | may use recall as replay/retry pressure | Steward still owns effect lifecycle, retry policy, and finality |
| Schell | may require quarantine, minimization, or retention action | Schell still owns forgetting and retention authority |
| ViewFS | may hide or badge stale projections | ViewFS still owns object identity, trusted paths, consent, and projection custody |
| Helm | may link recall to repair attempts | Helm still owns intervention traces and repair consequence |
| External audit notebook | must acknowledge notices before relying on a packet | a recall receipt is not audit approval or certification |
| Delegated export worker | may propagate notices and collect recall receipts | does not become revocation authority or redelegation authority |

## What changed in this pass

- Added specimen 83 for revocation notices, recall receipts, and stale-reliance fences.
- Added a revocation/recall rulebook so stale use has named failure modes.
- Added v0 schemas for revocation notices, recall receipts, and stale-reliance fences.
- Added a specimen 83 fixture with active, superseded, and informational notices; consumer recall receipts; stale cache fences; revoked-warrant and withdrawn-waiver cases; and negative cases.
- Added `check_foundry_revocation_recall.py` and wired it into `make check`.
- Reused RFC 7009 revocation, RFC 6960 status checking, W3C Bitstring Status List, TUF stale/rollback/freeze pressure, HTTP caching freshness pressure, and companion-cube ownership pressure while keeping Foundry smaller than authorization, PKI, credential-status, update-security, cache-control, legal-hold, or sibling-verdict systems.

## Recommendation

Future Foundry revisions should treat revocation as a status overlay on semantic carriers, not as deletion, repair, approval, or truth rewrite. A carrier becomes usable again only after the target consumer has a recall receipt, replacement carrier, and rerun gates that match the notice scope.
