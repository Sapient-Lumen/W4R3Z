# Research synthesis — 2026-05-22 pass LXXXVI

Focus: **semantic waivers, expiry witnesses, and exception replay gates**.

The previous pass made revision-to-revision semantic regression inspectable. This pass covers the next operational scar: sometimes a team needs to proceed with a known semantic limitation for a preview, migration window, external audit extract, or repair lane. If Foundry has no bounded exception artifact, the refusal receipt becomes informal chat, a dashboard warning becomes folklore, or a temporary waiver quietly becomes the new success path.

## New external pressure added

- `EXT-SARIF-V210-SUPPRESSIONS` shows a useful split between an analysis result and the process state around suppressing or accepting that result. Foundry should steal the idea that suppressed/accepted-under-review findings need explicit state and justification, while refusing to become a static-analysis triage format.
- `EXT-OPA-DECISION-LOGS-2026` shows that policy-style decisions benefit from durable decision ids, input/result/bundle metadata, timestamps, trace ids, and masking records for audit and replay. Foundry should borrow decision replay discipline, not OPA policy authority.
- `EXT-CYCLONEDX-VEX-2026` shows context-specific status, justification, response, first-issued, and last-updated posture for vulnerability exploitability. Foundry should borrow context-specific exception posture without treating semantic loss like vulnerability exploitability or security acceptance.

## Existing pressure reused

- `EXT-RFC9457-PROBLEM-DETAILS-2023` keeps refusal receipts machine-readable without making them HTTP-only.
- `EXT-RFC8785-JCS` keeps replay and digest checks stable across incidental JSON formatting.
- `EXT-RFC6902-JSON-PATCH` keeps path-scoped mutation examples useful for exception replay tampering.
- SlopOS and Foundry rev0085 regression fixtures keep waiver checks deterministic instead of relying on social memory.

## What rev0085 still allowed

Rev0085 could prove that a residue carrier changed, stayed stable, or failed tamper cases. It did not yet prove what happens when a human intentionally accepts a bounded semantic risk. Without a waiver seam, a future editor can:

- ship a preview with a refusal receipt mentioned only in prose;
- let an expired exception continue because the dashboard still renders;
- widen a waiver from one consumer or cut to all consumers and all cuts;
- self-approve an exception whose reviewer should be distinct;
- waive a non-waivable residue such as classification pins, source cuts, suppression posture, or balance residue;
- renew a waiver without replaying the refusal/regression rules; or
- convert a waiver into default success by dropping the link to the original refusal receipt or regression lock.

Those are exception-lifecycle failures, not ordinary egress failures.

## Speculative read

Foundry now needs an **exception boundary contract** beside its egress and regression contracts:

```text
refusal receipt         = why this egress shape failed
semantic diff manifest  = what changed across revisions
regression lock         = what cannot silently change
waiver warrant          = who knowingly accepts one bounded semantic limitation
expiry witness          = when that acceptance stops being valid
exception replay gate   = which checks must rerun before use, renewal, or revision change
verdict                 = still outside Foundry
```

The important move is negative: a waiver is not approval, truth, trust, policy override, or product entitlement. It is a bounded exception to an already-recorded refusal or regression alarm.

## New specimen pressure

Add specimen 80 around waiver warrant, expiry witness, and exception replay gate. The fixture must prove at least:

- every waiver names owner, reviewer, issue time, expiry, scope, linked refusal/lock, non-waivable residue, and allowed semantic loss;
- the owner and reviewer cannot be the same actor;
- expiry and renewal are machine-readable, not prose reminders;
- replay gates name which refusal/regression rules rerun before use, renewal, and revision change;
- waiver scope cannot silently widen across consumer, surface, revision, cut, audience, or rule ids;
- non-waivable residue cannot be waived by convenience; and
- negative cases fail for expired, ownerless, unlinked, self-approved, widened, or default-success waivers.

## Recommendation

Keep semantic waivers fixture-local and reversible. Do not promote a policy engine, approval workflow, risk-acceptance product, exception registry, or sibling-cube verdict system. The narrow Foundry job is to prevent “known limitation” from becoming a silent semantic rewrite.
