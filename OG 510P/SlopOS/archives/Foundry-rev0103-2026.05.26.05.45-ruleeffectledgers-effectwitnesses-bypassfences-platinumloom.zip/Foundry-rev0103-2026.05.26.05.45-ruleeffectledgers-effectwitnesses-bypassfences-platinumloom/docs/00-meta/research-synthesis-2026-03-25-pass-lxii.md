# Research synthesis — pass LXII

This pass stays deliberately conservative.
Foundry still should **not** pretend that one current schema pin, one latest vendor spec, or one freshly renamed field family has already become universal datacube law.
But it can steal one more durable lesson from current telemetry-schema, semantic-versioning, and data-model-governance ecosystems: **old schema pins should be preserved, reviewed translations should be explicit, and silent “latest-version” normalization should be fenced off by default.**

The smallest durable seam from this pass is:
- **translation witness** — the exact reviewed mapping, transform, or migration note that explains how one source schema pin was interpreted as another target schema pin;
- **compatibility lane** — a compact posture such as `native`, `lossless_translated`, `lossy_translated`, `deprecated_source`, or `incomparable`;
- **upgrade fence** — the explicit rule that old rows do not silently inherit current meaning unless a reviewed translation witness says they may.

These are still smaller than a global schema registry, a universal transform engine, or a giant compatibility bureaucracy.
They simply keep design-phase evolution honest.

## Lessons we must learn from the past

### 1) Version labels alone are not enough; consumers need reviewed translation stories
OpenTelemetry schemas are unusually useful here.
They make schemas versioned, identify them by schema URL, and explicitly define transformations between versions when those conversions are possible.
When they are not possible, the result is a breaking change rather than a flattering silent upgrade.
That is exactly the humility Foundry needs.

### 2) A schema family and the file format that describes it are different contracts
OpenTelemetry’s schema file format is itself versioned and tells consumers when they may or may not interpret the file.
That is a healthy warning for Foundry too: a transform carrier, a schema family, and a visible field rename should not collapse into one generic “version” word.

### 3) Deprecation is healthier than name reuse or magical disappearance
OpenTelemetry semantic-convention naming guidance says names should not be reused and should not simply vanish; they should be deprecated when renamed or no longer recommended.
That is a sharp lesson for datacube construction.
A renamed field family is not “the same thing, trust me” unless the archive can show how the older meaning maps forward.

### 4) “Latest version” pointers do not remove producer/consumer coordination work
Recent dbt guidance on model versions is useful for Foundry because it separates project/YAML parser versions from model versions, and it treats producer/consumer coordination as real work when a new version lands.
That means Foundry should not let one `latest` pointer or one consumer-preferred schema pin erase the fact that older rows still speak older meaning.

### 5) Migration aids are valuable, but they still need reviewable diffs
Recent dbt semantic-layer migration guidance is another good warning.
Even when tooling can rewrite older specs into a newer shape, the output is framed as a reviewable diff rather than magic sameness.
Foundry should steal that instinct: a translation witness is healthier than folklore that “the tool updated it.”

## What to steal now
- a **translation witness** whenever one source schema pin is intentionally interpreted as another target schema pin;
- a **compatibility lane** so native rows, lossless translations, lossy translations, deprecated sources, and incomparable rows do not silently share one flattering status;
- an **upgrade fence** so “current consumer expects vN” does not automatically rewrite older history into vN meaning;
- a standing split between **schema-family versioning** and **transform-carrier/file-format versioning**;
- and a habit of preferring **deprecation plus explicit mapping** over silent rename/reuse folklore.

## What to keep parked
Do not yet promote:
- a cube-wide transform registry with heavy governance;
- a universal automatic migration engine;
- one compatibility promise for every family;
- or a claim that every renamed or re-nested field family deserves forward comparability by default.

## Resulting recommendation
The next healthy move is not “make every old row speak the newest vocabulary.”
It is to let Foundry say, for any evolving imported/exported/adjunct family:
1. which **source schema pin** the row originally spoke,
2. whether a reviewed **translation witness** was applied,
3. which **target schema pin** the consumer asked for,
4. and which **compatibility lane** the result honestly occupies.

That keeps the cube aligned with SlopOS’s design-phase reality while still stealing smart discipline from OpenTelemetry and dbt.
