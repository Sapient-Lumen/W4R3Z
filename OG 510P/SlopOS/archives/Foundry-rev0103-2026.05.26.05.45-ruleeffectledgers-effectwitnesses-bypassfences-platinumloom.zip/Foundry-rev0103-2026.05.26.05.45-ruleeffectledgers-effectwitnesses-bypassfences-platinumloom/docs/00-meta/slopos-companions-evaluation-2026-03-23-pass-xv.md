# SlopOS and companions evaluation — pass XV

This pass keeps Foundry aligned with the uploaded cube ecology.

## What the current cubes keep teaching
- **SlopOS** repeatedly favors explicit capability routing, leases, checkpoint/restore humility, and policy/evidence separation; those are strong pressures toward void-route honesty and secret-release separation.
- **Harbor** needs aftermath objects that can say “foreign work started, but strong consequence is still pending”.
- **Ward** wants runtime evidence exported without turning it into immediate approval.
- **ViewFS** keeps imported or mounted utility distinct from durable local identity.
- **Schell** often lives with helper lanes and foreign grounds that are useful long before they are native.

## Pressure on Foundry
Foundry should resist any vocabulary that turns missing optional routes, borrowed foreign handles, or deferred secret release into invisible implementation details.
The stronger move is one more specimen where:
1. one capability is absent by declared posture,
2. one useful resource remains borrowed,
3. the workload is attested but secret release is still gated,
4. and restore/readiness remains explicitly degraded.

## Promotion restraint
Do not promote `void route`, `borrow rail`, or `secret latch` unless they jointly improve routed-capability, resource-handle, and attested-release specimens.
