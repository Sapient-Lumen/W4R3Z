# SlopOS + companions evaluation — pass LXIV

This pass checks whether **profile card, precedence lane, and overlay fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify one global profile registry, automatic profile negotiation, or a claim that every profile-shaped noun in SlopOS belongs in the cube as base truth.

## Why SlopOS pressures this seam now

### 1) SlopOS already uses profile language heavily, but not all profiles are the same species of truth
The current SlopOS archive has deployment profiles, release profiles, hardening profiles, failpoint profiles, transport profiles, workflow defaults, and profile matrices.
That is a healthy warning by itself: “profile” is a useful local shape, but it is not one universal semantic category.
Foundry therefore needs a way to carry which profile shaped one consumer/export path without pretending that every profile is base cube ontology.

### 2) SlopOS already keeps some profile semantics explicitly smaller than authority
`profile-default-artifact-boundary-v0.md`, `profile-feature-flag-defaults.md`, `profile-lane-defaults.md`, `profile-repl-defaults.md`, and `profile-workflow-defaults.md` all read like the same discipline: defaults and profile overlays are useful, but they are smaller than the authoritative base/runtime/boundary truth.
That is very close to the Foundry move here.
A profile card can carry the overlay; it should not become the base row’s semantic identity.

### 3) Transport/profile boundaries show why overlay must stay separate from native truth
`network-lease-transport-profile-boundary-v0.md` is especially revealing.
It keeps negotiated transport-profile details from silently regrowing into portable transcript-stable truth.
That is exactly the kind of pressure that justifies an overlay fence in Foundry: a profile-shaped overlay may describe one interpretation or presentation path without changing what the underlying row fundamentally is.

### 4) Policy and hardening profiles are useful, but not universal cube comparability
`hardening-profile-schema-v0.md`, `microvm-profile-posture-v0.md`, `capshell-startup-profile-posture-v0.md`, and `capshell-mac-profile-posture-v0.md` show another pattern.
Profiles here are meaningful and worth preserving, but they are still policy/posture overlays over narrower seams.
A future Foundry row can preserve which profile card applied without claiming that two rows with different hardening or startup profiles are automatically semantically identical or mutually comparable.

### 5) Companions reinforce profile humility rather than profile inflation
Schell’s `semantic-transport-profiles-projection-loss-and-portable-humility.md` is especially aligned with this pass.
It treats transport profiles as projection/loss posture rather than magical universal sameness.
Ward’s spend-profile specimen also reminds Foundry that profile-shaped language can matter operationally while still remaining local to one consumer or authority boundary.
That makes this seam a good fit for Foundry now.

## What to steal into Foundry

### profile card
A compact record of which extra profile, convention bundle, or overlay shaped the current consumer/export interpretation.
Examples:
- a support-bundle redaction profile digest,
- a release-profile identifier,
- a transport-profile name pinned as local descriptive residue,
- or a deployment-profile handle used only for one export path.

### precedence lane
A compact record of how multiple profiles were ordered or refused.
Examples:
- `base_only`,
- `single_profile`,
- `ordered_left_to_right`,
- `profile_conflict_refused`.

### overlay fence
A compact refusal boundary that keeps profiles from silently mutating base truth.
Examples:
- `profile_must_not_change_base_measure`,
- `profile_must_not_change_schema_pin`,
- `profile_conflict_requires_new_lens`,
- `profile_requires_translation_not_overlay`.

## Why this seam is small enough now
It does **not** require:
- one universal taxonomy for every SlopOS profile noun,
- one mandatory dereferenceable profile document for every row,
- one automatic merge engine for overlapping profiles,
- or a promise that profiles are globally comparable across all consumers.

It only says that once a Foundry reader/export path uses profile-shaped overlays, it should preserve:
1. **which profile card applied**,
2. **how precedence was decided**,
3. and **where overlay fence stopped profile drift from becoming fake base truth**.

## Recommended Foundry posture
Promote **profile card**, **precedence lane**, and **overlay fence** as a narrow honesty seam for evolving consumer/export conventions.
Keep profile language local and optional by default.
Only treat a profile as cube-wide law after repeated cross-consumer pressure proves it deserves promotion beyond one design-phase surface.
