# Research synthesis — 2026-05-26 pass CIII

This pass investigates the seam after rule evaluation: a trace can say which rule was selected, skipped, refused, or quarantined, but it cannot prove that any semantic effect was actually bound to a carrier or surface.

## Outside pressure

- Kubernetes ValidatingAdmissionPolicy separates failure actions such as Deny, Warn, and Audit. Foundry steals the explicit effect-mode caution while refusing admission-control scope.
- XACML separates Permit, Deny, Indeterminate, and NotApplicable decisions and keeps obligations/advice distinct from the decision. Foundry steals the result/effect distinction while refusing authorization decisions.
- OpenFeature evaluation details preserve value, variant, reason, error, and metadata rather than treating every evaluation as the same kind of effect. Foundry steals the weak-result visibility while refusing feature-flag infrastructure.
- W3C Trace Context shows that ids need explicit propagation across boundaries. Foundry steals the cross-boundary reference-integrity instinct while refusing distributed tracing scope.

## Foundry move

Promote specimen 97 locally: rule-effect ledger, effect witness, and bypass fence. Add a reference-integrity index so cross-specimen ids used by effect binding cannot drift invisibly.

## Non-goals

Do not build an enforcement runtime, authorization layer, admission controller, policy engine, feature-flag system, mutation engine, trace system, audit product, public-release approval system, compliance engine, repair workflow, lifecycle authority, sibling verdict, or governance registry.
