# Research synthesis — pass XLI

This pass keeps Foundry narrow and learns one more delegation-adjacent lesson from current primary sources: **a narrowed descendant artifact is still smaller than its parent, and ancestor state can remain load-bearing**.

The pressure is easy to miss because many surfaces only say “exchanged token”, “assumed role”, “session policy”, or “delegated access”.
But several mature systems keep three more exact truths apart.

1. **Derivation is a distinct event, not raw-parent export.**
   RFC 8693 defines OAuth 2.0 token exchange as an HTTP/JSON STS protocol for obtaining new security tokens, including delegation and impersonation use cases.
   It explicitly notes that the new token may be more narrowly scoped for the downstream service, while also saying that the detailed syntax, semantics, and trust model of the tokens themselves are out of scope.
   That is a useful warning: the child token is real, but it should not quietly harden into one universal delegation ontology.

2. **Healthy descendants are upper-bounded, not broadened.**
   Google Cloud Credential Access Boundaries let a short-lived credential be exchanged for a new one constrained by resource, upper-bound permissions, and optional conditions.
   AWS STS session policies do the same from another angle: the resulting session permissions are the intersection of the role or user policy and the session policies, and the session policies cannot grant more than the parent already had.
   So “derived credential” remains smaller than “new peer credential”.

3. **Attenuation ideas get richer, but parent shadow still matters.**
   Macaroons taught the classic lesson: bearer credentials can carry caveats that attenuate when, where, by who, and for what purpose they authorize requests.
   Biscuit keeps the same core discipline in a more explicit public-key form: blocks added during attenuation can only restrict rights, and revocation guidance says revoking a token should also revoke all tokens derived from it.
   So descendants are not standalone islands; lineage can still matter.

That yields one conservative datacube seam:
- **derivation witness** — exact parent-to-child lineage witness for one narrowed descendant artifact;
- **attenuation fence** — explicit upper-bound narrowing across target, action, audience, time, use, or condition;
- **ancestor shadow** — visible rule that parent or lineage state can still narrow descendant truth.

The important anti-regrowth rule is simple: **child smaller than parent**.
Foundry should be able to say that one descendant artifact is useful and maybe even currently valid, while also saying that it exists under one exact derivation story, one narrower fence, and one ancestor whose later invalidation may still matter.

## What to steal without overcommitting
- **upper-bound derivation** — child power should be obviously narrower or intersected, never quietly broadened.
- **derivation witness** — a compact way to keep parent and child distinct without exporting the raw parent.
- **ancestor shadow** — a compact way to keep lineage-level invalidation or expiry visible.
- **discharge witness** — a parked future idea from macaroon third-party caveats and Biscuit third-party blocks when one child needs outside/context proof before use.
- **actor-path card** — a parked future idea from current actor-chain work when one deployment genuinely needs auditably preserved multi-hop delegation history.

## What to keep parked
Do not yet promote:
- a portable token-exchange or STS plane,
- a general caveat DSL,
- a token wallet or delegation registry,
- or a cross-domain actor-chain substrate.

Those may become real later, but this pass only proves the smaller meaning seam.
