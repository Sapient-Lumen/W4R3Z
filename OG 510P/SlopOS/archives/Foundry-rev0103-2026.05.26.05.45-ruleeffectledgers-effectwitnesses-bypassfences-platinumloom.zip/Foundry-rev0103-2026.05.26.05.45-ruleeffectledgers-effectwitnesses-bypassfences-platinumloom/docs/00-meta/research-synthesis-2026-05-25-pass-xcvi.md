# Research synthesis — 2026-05-25 pass XCVI

Focus: **verification audits, evidence samples, and false-closure fences**.

The previous pass made semantic-duty fulfillment explicit. This pass closes the next gap: completion evidence can be self-reported, stale, contradicted, undersampled, outside scope, or produced by the same actor whose claim is being checked. Foundry needs a small verification seam that records what was sampled, what was contradicted, and what remains unsafe without becoming an audit product or cryptographic proof system.

## New outside pressure

- `EXT-NIST-OSCAL-ASSESSMENT-RESULTS-2026` gives Foundry a scope/evidence scar: assessment results name what was assessed, how it was assessed, who performed it, observations, findings, risks, and expiry. Foundry should steal scope, activity, evidence, and expiry discipline while refusing OSCAL/FedRAMP/compliance-report capture.
- `EXT-W3C-VC-DATA-INTEGRITY-2025` gives Foundry a verification scar: verification is an explicit algorithm that can return verified=false with warnings and errors, and it may bind proof purpose, domain, and challenge. Foundry should steal "verified is a result, not a feeling" while refusing cryptographic proof, VC, DSSE, signature, and credential-system capture.
- `EXT-IN-TOTO-VERIFY-2026` gives Foundry a threshold/evidence scar: verification checks signed layouts, expiry, expected link metadata, authorized functionaries, and artifact rules. Foundry should steal the idea that expected evidence must exist and match rules, while refusing to become a supply-chain verifier or build-trust system.
- Existing `EXT-IN-TOTO-ATTESTATION-2026` and `EXT-SLSA-PROVENANCE-1-0` continue to pressure Foundry to keep subject/evidence/provenance specific, but rev0096 deliberately keeps verification fixture-local rather than adopting attestations as truth.

## What rev0095 still allowed

Rev0095 can say that a consumer fulfilled a semantic duty because it emitted a completion witness. It still leaves dangerous verification gaps:

- a dashboard claims the observation-status badge displayed, but the current render probe cannot find it;
- an audit CSV claims sidecar preservation, but the sampled CSV points at a digest that no longer matches;
- a public-link scanner claims no-reexport was refused, but a sidecarless public CSV exists;
- a delegated worker claims recheck-before-execute, but logs show execution happened first;
- a ViewFS projection claims quarantine, but inherited access evidence is stale;
- a Ward preview claims the "not Ward verdict" boundary, but the badge language is ambiguous; or
- the same actor who authored the completion witness also "verifies" it.

Those are not only nonfulfillment cases. Some are **false closure** cases: a claim looks closed until sampled evidence contradicts it.

## Speculative read

Foundry needs a tiny **verification audit seam** after fulfillment accounting:

```text
verification audit      = scoped review packet over fulfillment receipts and completion witnesses, with population, sampling basis, verifier posture, required samples, and boundaries
evidence sample         = consumer/surface-local probe result for a completion claim: verified, contradicted, stale, unavailable, inconclusive, quarantined, or superseded
false-closure fence     = refusal card for completion claims that look closed but are contradicted, undersampled, stale, wrong-scope, self-verified, public, inherited, or authority-laundered
```

The seam should stay smaller than audit, certification, compliance reporting, cryptographic proofs, verifiable credentials, in-toto/SLSA verification, authorization, legal compliance, repair, custody, or sibling-cube verdicts. Foundry's job is not to declare a system compliant. Its job is to prevent a dangerous sentence: "there is a completion witness, therefore the completion is verified."

## Harness audit/refactor finding

While adding the new seam, rev0096 also audited the executable harness. The finding is small but load-bearing: the aggregate runner had become its own drift surface. New checkers were easy to add but easy to forget in `check_foundry_all.py`.

The refactor adds `tools/foundry_checklib.py` and rewrites the aggregate runner to use a shared ordered script runner. Existing focused checkers stay standalone; only root discovery, JSON loading, timestamp parsing, sha256 checks, fatal reporting, and aggregate execution move into the shared helper.

This is not a test framework migration. It is a guard against checker-registration drift.

## New specimen pressure

Add specimen 90 around verification audits, evidence samples, and false-closure fences. The fixture must prove at least:

- every verification audit names source fulfillment receipts, completion witnesses, carrier ids, scope, sampling basis, verifier posture, required samples, required fences, and authority boundaries;
- every audit states non-exhaustive sampling so a sample cannot masquerade as full inventory;
- every evidence sample is consumer/surface/audience-local, probe-based, digest-linked when a carrier is named, and scoped to a source completion witness;
- contradicted, stale, unavailable, inconclusive, quarantined, public, inherited, wrong-scope, or self-verifying samples need false-closure fences;
- verification by one consumer, surface, audience, purpose, carrier, verifier, or sample basis cannot clear another boundary;
- false-closure fences must name affected completion witnesses, blocked uses, required replay/clearance, and non-promises; and
- the fixture must include a harness audit block so the runner refactor is executable evidence rather than prose.

## Recommendation

Keep verification audits fixture-local. Do not promote a generalized audit or proof object. The narrow Foundry move is to make verification falsifiable: a completion witness may exist, but reuse stays unsafe if sampled evidence contradicts it, the verifier is conflicted, scope widened, or the audit omits required samples.
