# SlopOS plus companions evaluation — pass XXXIV

This pass tested whether Foundry needs a small meaning seam for *new current holder versus stale holder that must now be rejected*.
The answer is yes, but again only narrowly.

## What SlopOS and companions already contribute
The uploaded SlopOS archive already has the right instincts for this area.
Its ordering-token, activation-handoff, drain/quiesce, revocation-epoch, and approval/currentness materials repeatedly refuse to let one cheerful current-state claim swallow a stronger correctness promise.
That is the right house style.

The clearest immediate support comes from companions:
- **Steward** already names exact fence-token semantics for reassignable live claims, while explicitly refusing to freeze a giant distributed-lock or leader-election plane.
- **ViewFS** already distinguishes current handles, live handle copies, shared-open-state truth, and fresh reopen truth, which means it naturally resists equating “the new holder/card is current” with “older holders are impossible or harmless”.
- **Ward** still keeps evidence and verdict separate, which helps keep “I observed a current owner change” smaller than “all stale actors are now fenced for correctness”.

So the ecosystem already has better homes for broad coordination, scheduling, or lease-manager mechanics.
Foundry does not need to grow a second one.

## What Foundry should own instead
Foundry should own only the semantic split that keeps these facts separate:
1. **holder epoch** — which claimant currently owns one singular mutable or serving role;
2. **fence token** — what exact checked witness a downstream mutator or authority surface must validate to reject stale holders;
3. **stale-holder cut** — when older holders stop counting as authoritative even if still alive, draining, or able to answer bounded stale observations.

That seam is smaller than a lock service, smaller than a failover orchestrator, and smaller than a universal lease fabric.
It is just enough vocabulary to stop later docs from flattening “new active/current” into “old actor can no longer do harm”.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small truth that one role can be:
- already reassigned to a newer holder,
- still contended by an older paused or partitioned actor,
- and only made correctness-safe once a checked **fence token** and explicit **stale-holder cut** are part of the story.

If Foundry misses that seam now, later revisions will be tempted to let “active”, “leader”, “owner”, “current”, and “safe singular mutator” collapse into one flattering status token.
That would make the archive worse at explaining zombie writers, stale-active failover cases, activation handoff hazards, and old-handle afterimages — all of which are already real pressures in the companion ecology.
