# SlopOS / companions evaluation — pass XXII

Foundry still looks justified as its own companion cube, but this pass sharpens where grouped-basis and confirmation pressure should live.

## What the current cube ecology keeps proving
- **SlopOS** already keeps `CH-UPD` narrow: one digest-bound install intent for one target deployment root plus one config/policy binding, with no native channel/ring/percentage-rollout or latest-wins semantics. It also already binds explicit artifact sets in `CH-BOOT` and keeps boot selection / commit semantics on `CH-BOOTSEL`, `CH-HEALTH`, and `CH-HEALTHREC`. That means Foundry should not reinvent repository metadata, rollout policy, or selector mechanics; it should model the meaning seam around grouped coherence and confirmation certainty.
- **SlopOS** is still in the design phase, so this restraint matters now. If early surfaces start calling every newly offered grouped update “the next current basis,” later docs will quietly train the archive toward overclaim and accidental latest-wins folklore.
- **ViewFS** benefits because lineage and durable references already want a clear difference between the latest offered bundle family and the latest confirmed coherent one.
- **Helm** benefits because settlement witnesses and commit cards already distinguish historical landing from current-live truth; grouped basis transitions should inherit that same honesty.
- **Harbor** benefits because a crossing into a target family that is coherent-but-unconfirmed may deserve different risk posture than a crossing into the latest confirmed family.
- **Ward** benefits because confirmation receipts and vehicle/version reports remain smaller than trust verdicts or release consequences.
- **Schell** benefits because command and repair lanes often need to act on the latest confirmed basis even while a newer grouped family is already staged or offered.

## Pressure on Foundry
Foundry should not decide yet whether `coherence target`, `confirmation fence`, and `supersession hold` belong under artifact identity, live realization, or aftermath residue.
The stronger move is to keep one more specimen where:
1. several basis pieces only make sense as one coherence target,
2. a newer conflicting family exists,
3. prior adoption is still uncertain,
4. and advancement is explicitly held rather than silently flattened into “latest”.

## Collected but parked ideas
This pass also surfaces one excellent side idea that should stay parked:
- **cohort hint** for rollout/track metadata that may help external orchestration, but should remain weaker than install authority and basis truth.

That idea is real, but it does not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `coherence target`, `confirmation fence`, or `supersession hold` unless they improve:
- one grouped-target specimen,
- one uncertain-prior-adoption specimen,
- and one explicit supersession-refusal specimen.
