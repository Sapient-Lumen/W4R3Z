# SlopOS companions evaluation — pass XCVIII

Rev0098 adds escalation/routing residue and audits specimen documentation coverage. The companion boundary remains strict: Foundry carries semantic risk to the right surface and fences unresolved risk; neighbors decide their own consequences.

## SlopOS

SlopOS support cards now get a way to carry risky drift signals into an operator console without losing sidecar, cadence, fence, audience, and purpose context. Foundry still must not turn an acknowledged route into SlopOS proof, support closure, or operator intervention success.

## Ward

Ward preview queues benefit from routing witnesses when classification, boundary, or verdict-disclaimer drift appears. Foundry can show that Ward received a packet or that a packet was misrouted. Ward still owns appraisal and verdict.

## ViewFS

ViewFS inherited-access and projection drift need routing witnesses because the right projection or custody surface may differ from the dashboard surface that observed the signal. Foundry can fence a stale or misrouted packet; ViewFS still owns object identity, trusted paths, access posture, and custody.

## Steward

Delegated workers need pre-execute routing when drift signals flap or a recheck is missing. Foundry can block reuse until a routing witness and unresolved-signal fence posture is clear. Steward still owns retry, replay, pushback, lifecycle, and effect finality.

## Harbor

Public-link, external-notebook, and outside-fact surfaces need route packets when recall routes disappear or no-reexport guards fail. Foundry can carry the semantic packet and show unresolved routing; Harbor still owns crossings, external aftermath, implementation receipts, and correction workflow.

## Schell

Schell remains the minimization and forgetting authority. Foundry can route semantic risk about retained, public, or exposed surfaces, but it must not decide deletion, retention, legal hold, privacy policy, or minimization consequence.

## Helm

Helm repair/intervention traces can later supply evidence that a risky signal was handled. Foundry can require the routing packet and unresolved fence before consuming that evidence, but Helm still owns repair workflow, intervention traces, and operational consequence.

## Refactor result

The specimen-doc coverage audit catches a growing-cube failure: adding prose specimens without matching rulebooks, schemas, fixtures, checkers, runner entries, and docs-map coverage. This keeps the datacube falsifiable without turning Foundry into a documentation governance product.
