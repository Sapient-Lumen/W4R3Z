# SlopOS / companions evaluation — 2026-03-23 pass VIII

This pass evaluated how Foundry should react to subject-attached sidecars and measured policy ideas without turning the cube into a generic registry or artifact catalog.

## SlopOS lessons that matter right now

### 1) Selection and reconciliation stay local
`provenance-container-selection-boundary-v0.md` is the clearest SlopOS warning for pass VIII. Multiple attached statements can be useful, but choosing among them stays a local verifier or product decision.

### 2) Attachment is still smaller than retrieval and verification
`artifact-resolution-posture-v0.md` strongly supports Foundry’s pass VIII restraint. Locators, nearby metadata, and attached artifacts are helpful hints until explicit retrieval and verification happen.

### 3) Boot description, runtime state, and restored continuity remain separate
`init-snapshot-posture-v0.md` and `microvm-generation-witness-posture-v0.md` remain excellent brakes on overclaiming. A beautiful sidecar pack should not tempt Foundry to blur initial description, live instance, and restored continuity.

### 4) Measured policy input belongs in the story but not at the top of the story
SlopOS already shows a healthy habit of keeping measured or imported material structured and bounded. Foundry should copy that habit and avoid acting as though measured policy input alone settles adoption.

## Companion-cube effects

### Harbor
Harbor continues to own entry/return truth. Subject-attached sidecars are useful, but they do not erase the need for membrane honesty about how a foreign ground was reached.

### Ward
Ward is Foundry’s main brake here. Sidecars full of witnesses, endorsements, or receipts are still smaller than final local release, spend, or admission.

### ViewFS
ViewFS remains the strongest analogy again: an attached sidecar pack is not the same as a durable local object, and neither is the same as a live instance.

### Helm
Helm should make adoption classes and foreign-ground sidecar residue inspectable rather than mystical.

### Schell
Schell remains where sidecars and measured-policy rails will become operationally sharp very quickly, especially for helpers, live checkouts, and explicit foreign lanes.

## Recommendation for Foundry rev0008
Keep these candidate nouns alive, but only as candidates:
- subject spine;
- sidecar pack;
- measured policy capsule;
- adoption rail;
- repository-scope warning.

Do **not** decide yet:
- whether the subject spine belongs to Foundry proper or should remain a thinner imported relation from packaging ecosystems;
- whether a sidecar pack should be one object or a view over attached artifacts;
- whether repository-scope attachment is worth surfacing to users or should stay mostly diagnostic.

The pass VIII specimen should exist to kill weak or misleading versions of those ideas early.
