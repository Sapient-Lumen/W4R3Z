# Research synthesis — pass XXXVII

This pass stays deliberately narrow.
Pass XXXVI kept **same key while pending**, **same key while replayable**, and **same key after expiry** apart.
The next cheap-to-preserve seam is what happens when a foreign thing becomes *currently absent*.
Several mature systems distinguish three truths that are easy to flatten if the cube only says “not found” or “deleted”:

1. a lookup may carry an **authoritative negative answer** that is real now but still bounded and cache-shaped;
2. the system may carry a **durable tombstone or delete marker** even while ordinary reads behave as if nothing is there;
3. dropping that marker or reusing that identity may still need a **grace/quarantine boundary** to avoid stale resurrection.

That split is worth preserving now because it is smaller than a universal deletion plane, smaller than a history browser, and smaller than a whole garbage-collection family.
It is just enough honesty to stop absence, withdrawal, and safe reuse from quietly impersonating one another.

## Lessons from current outside systems

1. **DNS negative caching treats nonexistence as real knowledge with a TTL.**  
   RFC 2308 defines negative caching as storing knowledge that something does not exist, covers NXDOMAIN and NODATA, and keys cached negative answers to exact query tuples while making them time out through the SOA-driven TTL.
   That is a powerful anti-lesson: current absence can be authoritative and still bounded.

2. **HTTP keeps “not found” smaller than “intentionally gone”.**  
   RFC 9110 says 404 does not indicate whether the lack of a current representation is temporary or permanent, while 410 is preferred when the server knows the condition is likely to be permanent.
   That means absence class matters, even before any storage/history story enters.

3. **S3 versioning keeps a durable delete marker behind an ordinary 404.**  
   Amazon S3 says a simple DELETE in a versioning-enabled bucket does not remove prior versions; it creates a delete marker that becomes the current version.
   Ordinary GET without a version ID then returns 404 with `x-amz-delete-marker: true`, while the marker and older versions still exist and are listable through version-aware operations.

4. **Cassandra tombstones exist largely to prevent deleted data from resurrecting as zombies.**  
   Cassandra keeps tombstones through `gc_grace_seconds`, explains that dropping them too early can let deleted data repair back from a down node, and explicitly warns that deleted data can reappear if a node stays away longer than the grace period.
   That is the cleanest argument for an explicit resurrection boundary instead of “delete means reusable now”.

## What this means for Foundry

Foundry should preserve a tiny negative-state seam so later docs cannot let “absent”, “withdrawn”, and “safe to reuse” collapse.
The useful promoted nouns are:
- **absence witness** — explicit current no-object / no-current-representation claim, often cacheable and bounded;
- **tombstone marker** — durable deletion or withdrawal marker that can make ordinary reads look absent while hidden history or versions still exist;
- **resurrection fence** — grace or quarantine boundary before marker purge or identity reuse becomes honest.

The main past lesson is not “build a delete subsystem”.
It is the narrower rule that **negative knowledge, durable withdrawal, and safe reuse live on different clocks**.
Systems that flatten those clocks end up lying about whether something never existed, was intentionally withdrawn, still has hidden history, or can be safely reborn under the same name/identity.

## Candidate nouns worth collecting
- **absence witness** — bounded authoritative negative result.
- **tombstone marker** — durable delete/withdraw marker behind ordinary absence.
- **resurrection fence** — grace/quarantine before purge or identity reuse.

## Things to keep parked
- a universal delete/trash/history plane;
- a promise that every negative answer has durable provenance;
- any collapse of tombstone purge into ordinary absence;
- any claim that one old name or key becomes safely reusable the instant current reads go negative.

## Provisional judgment
Promote only the seam.
Foundry should be able to say that one lookup carries an **absence witness**, that a hidden **tombstone marker** may still govern current absence, and that a **resurrection fence** can delay purge or reuse without implying current presence.
That is especially valuable while SlopOS is still plastic enough to avoid teaching later docs that “404”, “deleted”, and “safe to reuse” always mean the same thing.
