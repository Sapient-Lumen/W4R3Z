# SlopOS and companions evaluation — 2026-05-21 pass LXXXIV

Focus: whether Foundry can make refusal itself inspectable when SlopOS-facing egress would shed semantic residue.

## SlopOS pressure

SlopOS already treats boundary checks, singleton contracts, resume/recheckpoint evidence, append/truncation surfaces, and portal/network artifacts as things that should leave receipts rather than vague success bits. Foundry should now mirror that style at the datacube edge: an export refusal should be reviewable, digest-linked, and tied to the attempted surface.

The pressure is not that Foundry should decide SlopOS policy. The pressure is that Foundry should say, deterministically, when a SlopOS-facing chart, CSV, result card, support table, or dashboard tile would lose the query/result, materialization, disclosure, observedness, reconciliation, or classification residue required to read it honestly.

## Companion boundaries

| Companion | Refusal receipt interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| Ward | may consume a refusal receipt as evidence that an export was blocked | Ward still owns appraisal/verdict |
| Harbor | may connect refusal receipts to external correction or outside-fact aftermath | Harbor still owns membrane/status authority |
| Steward | may treat refusal receipts as lifecycle evidence around retry/replay surfaces | Steward still owns effect finality and lifecycle state |
| Schell | may require refusal when retention/minimization prevents drill-through or sidecar exposure | Schell still owns forgetting/minimization authority |
| ViewFS | may expose emitted and refused surfaces as artifact/projection events | ViewFS still owns file/object identity and trusted paths |
| Helm | may use refusal receipts in repair traces when an operator artifact is withheld | Helm still owns repair custody and intervention consequence |

## What changed in this pass

- Added specimen 78 for refusal receipt, egress manifest, and conformance gate.
- Added a compact egress conformance rulebook so rule ids are readable before they appear in receipts.
- Added v0 schemas for egress manifests and refusal receipts.
- Added a specimen 78 fixture with passing and refused export attempts.
- Added `check_foundry_egress_refusals.py` and wired it into `make check`.
- Added RFC 9457 as a load-bearing source for machine-readable problem details while keeping Foundry refusals non-HTTP-specific.

## Recommendation

Future SlopOS-facing result surfaces should not be allowed to fail as anonymous implementation errors. Either emit with residue, emit with a sidecar, or refuse with a receipt that names the semantic loss and the safe escape paths.
