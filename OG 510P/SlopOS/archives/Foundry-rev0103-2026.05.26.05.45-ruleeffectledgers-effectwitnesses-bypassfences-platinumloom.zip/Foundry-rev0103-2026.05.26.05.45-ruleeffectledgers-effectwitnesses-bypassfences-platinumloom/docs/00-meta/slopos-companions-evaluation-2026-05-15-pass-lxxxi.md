# SlopOS + companions evaluation — pass LXXXI

This pass evaluates Foundry's next SlopOS-facing datacube seam: control totals, reconciliation, and balance honesty.

## Verdict

Promote one narrow seam: **control-total card**, **reconciliation witness**, and **balance fence**.

This is a conservative promotion because it does not choose a validation language, accounting model, official-statistics framework, or always-balance runtime. It only requires a result family to say what total or invariant it was checked against, how the reconciliation ran, and where downstream consumers must not overread the outcome.

## SlopOS pressure

SlopOS already contains several sources of balance/reconciliation pressure:

- `CH-OBS` can emit bounded metrics, logs, traces, capability snapshots, and support counters; direct counters and derived support totals will not always share the same cut or meaning.
- `CH-OBSPOL` redaction profiles and bounds mean visible rows may not sum to a visible total, and that mismatch can be policy-correct rather than erroneous.
- `CH-SNAPSHOT` support bundles can collect manifest entries, diagnostic summaries, session/boot bindings, and redacted evidence; support-card totals may blend native, derived, missing, and imputed rows unless Foundry fences them.
- Quarantined-result previews and derived artifacts already refuse to let result lanes become source truth. A reconciled support table should likewise stay a result with a witness, not source history.
- Tool-result visibility boundaries and observation-export posture make audience, policy, and result shape explicit; control totals need the same policy/cut humility.
- FedCM/Digital Credentials work showed a general SlopOS lesson: mediated output is useful, but the mediation surface is not durable truth. Reconciled totals are useful, but the reconciliation surface is not the cube.
- SlopOS is still design-phase; early counters, taxonomies, processor outputs, and support panels will likely change, so forced balance would be especially dangerous.

## Companion pressure

- **Steward** is the strongest positive analogy. Its bootstrap-reconciliation posture separates activation cause from present-tense condition truth and records reconciliation scope. Foundry should borrow that discipline for table totals: reported total, component set, and current reconciliation outcome are separate.
- **Harbor** already distinguishes evidence grades, contract tiers, and lineage guards. A reconciliation witness should be an assertion about a check run, not a replacement for row meaning, lineage, or source authority.
- **ViewFS** warns that derived/list/rendered surfaces must not back-write source identity. A balanced summary row must not become a source attribute merely because it looks tidy.
- **Ward** is where claims and verdicts belong. Foundry's balance fence is a local permission/refusal card, not a Ward-quality judgement that a table is correct.
- **Helm** and **Schell** will likely render cards, queues, and operator-facing summaries. They need a simple display rule: show the balance posture and residual class; do not silently force a total or hide an imbalance.

## Why existing specimens are not enough

- Specimen 56 covers allocation residue and apportionment fences, but not independent control totals or mirror checks.
- Specimen 64 covers denominator basis and ratio fences, but not table-level subtotal/margin reconciliation.
- Specimen 70 carries a validation witness, but specimen 75 specializes the common and dangerous case where arithmetic/mirror/control checks are interpreted as truth.
- Specimen 71 covers lawful rollups and hierarchy paths, but not whether the produced rollup balanced against a control total.
- Specimen 73 covers disclosure and differencing; specimen 75 prevents suppression/noise/redaction residuals from becoming hidden arithmetic fraud or leaked hidden cells.
- Specimen 74 covers observedness and adjustment; specimen 75 prevents adjusted/imputed/provisional rows from silently participating in raw totals without a balance fence.

## Recommendation

Add specimen 75 and update ledgers/source hygiene accordingly. Keep the nouns local to result families, support-card tables, exports, rollups, and aggregate outputs where a total/margin/mirror/invariant check changes interpretation. Do not widen the seam into a global validation framework or balancing engine.

## Follow-up pressure to keep open

- Test one SlopOS `CH-OBS` direct total against a component-derived support-card total from the same cut.
- Test one redaction/suppression case where visible components intentionally do not sum to the released total.
- Test one trace-processor-derived count whose processor and source cuts differ from the native counter.
- Test one Steward-style bootstrap reconciliation row that later becomes reconciled, lost, or unknown.
- Test one cache/materialized result whose stale cut would otherwise pass an old balance check.
- Test one JSON/chart export that cannot preserve the full witness and must either carry a sidecar or refuse balance-free flattening.
