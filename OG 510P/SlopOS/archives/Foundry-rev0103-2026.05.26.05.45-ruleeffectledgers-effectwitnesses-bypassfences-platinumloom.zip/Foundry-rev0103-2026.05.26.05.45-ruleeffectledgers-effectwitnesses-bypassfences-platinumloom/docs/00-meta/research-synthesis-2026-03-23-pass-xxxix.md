# Research synthesis — pass XXXIX

This pass stays deliberately narrow.
Pass XXXVIII kept **exact issuance evidence**, **current validity**, and **freshness of the last good validity check** apart.
The next cheap-to-preserve seam lives *inside* the current-validity world: a session, token, or account-binding may still be currently valid for ordinary use while failing one sensitive action because the last authentication event was not **strong enough**, not **recent enough**, or not **user-intended enough** for that exact action.
Several mature systems keep those facts separate even when product wrappers flatten them into one cozy story of “logged in”.

## Lessons from current outside systems

1. **OAuth step-up says a valid token can still be insufficient for one resource action.**  
   RFC 9470 defines `insufficient_user_authentication` for the case where the authentication event associated with the presented access token does not meet the protected resource's requirements.
   It also introduces `acr_values` and `max_age` so the resource can communicate required authentication strength or recentness.
   Just as importantly, the same RFC warns that “authentication level” and “step up” are only metaphors here and do **not** imply one universal interoperable hierarchy of methods.

2. **OpenID Connect keeps the evidence pieces separate.**  
   OIDC defines `auth_time` as when the End-User authentication occurred, `acr` as the Authentication Context Class Reference that the authentication satisfied, and `amr` as the authentication methods used.
   That is a useful split because elapsed time, satisfied class, and method list are different strengths of fact.

3. **WebAuthn keeps simple presence, stronger local verification, and account identity from collapsing.**  
   WebAuthn says a user-presence test is a simple authorization gesture that yields a Boolean result and is not user verification.
   It separately defines user verification as the local process by which the authenticator authorizes the operation, often with PIN, password, or biometrics, and explicitly notes that user verification does not give the relying party a concrete identification of the natural person.
   So “someone touched the authenticator”, “the authenticator locally verified a user”, and “the relying party now knows the exact human” are different truths.

4. **NIST keeps assurance level, reauthentication timing, and authentication intent distinct.**  
   SP 800-63B says AALs categorize the strength of an authentication transaction.
   It separately gives reauthentication timeouts and defines authentication intent as explicit claimant intervention for each authentication or reauthentication request.
   That is a strong anti-lesson for Foundry: strength, age, and user-intendedness are separate axes even when one UX bundles them.

## What this means for Foundry

Foundry should preserve one tiny seam so later docs cannot quietly treat “currently valid session” as if it also proved “strong enough”, “recent enough”, and “fresh user-intendedness” for a sensitive effect.
The useful promoted nouns are:
- **assurance class** — context-local statement of the authentication strength or class that one action requires or one authentication event satisfied, without pretending there is one global assurance ladder;
- **recency fence** — explicit bound on how old the qualifying authentication event may be before step-up or reauthentication becomes the honest path;
- **intent latch** — explicit demand for claimant intervention, user presence, or user verification before one sensitive effect is allowed to proceed.

The key past lesson is not “build an assurance platform”.
It is the narrower rule that **valid now**, **strong enough for this action**, **recent enough for this moment**, and **user-intended enough for this effect** are separate truths.
Systems that flatten them end up laundering old logins into present approval, turning context-local ACR labels into fake universal tiers, and letting a live session quietly impersonate fresh user intent.

## Candidate nouns worth collecting
- **assurance class** — required or satisfied authentication-strength class for one decision context.
- **recency fence** — bound on allowable age of the last qualifying authentication event.
- **intent latch** — explicit intervention requirement before a sensitive effect crosses.

## Things to keep parked
- a universal assurance taxonomy;
- a portable recent-login oracle;
- any claim that `acr`, `amr`, or `auth_time` automatically become durable platform truth outside the local verifier context;
- any collapse of user presence, user verification, and account identity into one flattering proof object.

## Provisional judgment
Promote only the seam.
Foundry should be able to say that one action needs or satisfied an **assurance class**, that a **recency fence** may reject an otherwise live session, and that an **intent latch** may still demand explicit present user intervention before effect.
That is especially valuable while SlopOS is still plastic enough to avoid teaching later docs that “logged in” always means “high enough, fresh enough, and intentionally confirmed enough”.
