# SlopOS / companions evaluation — pass XXI

Foundry still looks justified as its own companion cube, but this pass sharpens *where not to trespass*.

## What the current cube ecology keeps proving
- **SlopOS** already has the control-plane pieces for this seam: `CH-BOOTSEL` for bounded trial selection, `CH-HEALTH` for the reviewed commit milestone, and `CH-HEALTHREC` for non-authoritative evidence of the evaluation. That means Foundry should not reinvent health-policy language or boot-selector machinery; it should model the semantic cut between activated-once and blessed-current.
- **SlopOS** is still in the design phase, which increases the value of this cut. If early product/ops language says “current” too soon, the archive will quietly train later surfaces to overclaim before the update is actually committed.
- **Helm** benefits because shell/compositor surfaces need to say whether a foreign basis is merely staged, currently on trial, blessed current, or reverted.
- **Schell** benefits because command lanes often act against the real current basis while another candidate is already staged or even booted-once under trial posture.
- **Ward** benefits because a successful boot or health record is still smaller than a trust verdict, spend decision, or release consequence.
- **ViewFS** benefits because version lineage, applied binds, and durable receipts already want confirmation-shaped language rather than one cozy “new version active” story.
- **Harbor** benefits because crossing into a foreign basis that is only on trial may deserve different risk posture and aftermath language than crossing into a blessed current basis.

## Pressure on Foundry
Foundry should not decide yet whether `trial basis`, `success latch`, and `fallback budget` belong under artifact identity, live realization, or aftermath residue.
The stronger move is to keep one more specimen where:
1. a candidate basis becomes active enough to run,
2. it is still weaker than blessed current truth,
3. success requires a later explicit latch,
4. and fallback remains bounded and inspectable rather than folkloric.

## Collected but parked ideas
This pass also surfaces two excellent future pressures that should **not** be promoted yet:
- **coherence target** for multi-resource basis families that should move together;
- **prior-confirmed bundle receipt** so a later conflicting bundle is not issued over uncertain prior adoption.

Those ideas are real, but they need a second specimen before Foundry should turn them into durable vocabulary.

## Promotion restraint
Do not promote `trial basis`, `success latch`, or `fallback budget` unless they improve:
- one trial-boot specimen,
- one explicit success-mark / bless specimen,
- and one bounded fallback specimen.
