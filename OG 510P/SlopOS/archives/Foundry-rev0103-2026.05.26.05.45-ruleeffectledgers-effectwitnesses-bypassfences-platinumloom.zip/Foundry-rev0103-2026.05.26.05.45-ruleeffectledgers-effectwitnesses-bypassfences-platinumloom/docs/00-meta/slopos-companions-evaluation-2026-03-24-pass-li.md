# SlopOS plus companions evaluation — pass LI

This pass adds one more datacube warning:
Foundry should model **how much fidelity a summarized value lost, whether one bounded concrete breadcrumb remains reachable, and whether the narrower evidence still exists** before it lets fast read surfaces masquerade as timeless cube facts.

## SlopOS
SlopOS already creates strong pressure in this direction.

`attrfs-posture-v0.md` says smart queries are **view-scoped**, **snapshot-first**, and return handles rather than global inventory or path truth.
It also says shell summary counts remain shell-owned presentation, not a new authority surface.
That means a future ATTRFS-derived count belongs to a visible **loss class**: it is a query-shaped summary over one view and cut, not ambient host inventory.

`inspect-snapshot-schema-v0.md` says CH-INSPECT is a **bounded canonical snapshot** with a closed set of value kinds, and it intentionally excludes arrays and histograms in v0, advising exporters to encode them as derived counters/gauges instead.
That is already a lossy-shape decision.
If Foundry ever cubes over those exports, it should say so explicitly rather than pretending the inspect snapshot preserved every raw measurement shape.

`diagnostic-snapshot-bundle-schema-v0.md` is a helpful hint about **exemplar anchors**.
The bundle manifest references entry payloads by digest or CH-AREF, letting a summarized support/incident package keep bounded links to concrete artifacts without forcing every consumer to ingest the full payload set.
That is exactly the sort of drill-through breadcrumb Foundry should steal.

Across SlopOS more broadly, many surfaces are careful about bounded export, explicit redaction, and provider-local meaning.
That makes a small fidelity seam healthier than a large universal lineage or observability plane.

So for a future Foundry datacube over SlopOS surfaces:
- an ATTRFS result count should declare that it is **query-shaped** and view/cut-bound rather than row-preserving inventory truth;
- an inspect-derived trend should declare when it is **shape-lossy** because histograms/arrays were collapsed into gauges or counters;
- a support summary should optionally carry a **digest/aref exemplar anchor** to one incident bundle entry or one exact snapshot;
- and every fast summary should say whether the narrower source evidence is still retained, cold-only, policy-blocked, or gone.

## Ward, Harbor, and ViewFS
Ward already keeps appraisal smaller than evidence, which reinforces loss-class humility.
Harbor keeps presentation/preview surfaces smaller than durable source truth, which is a good neighbor for exemplar-anchor restraint.
ViewFS already has strong object/digest discipline, making it a natural place to borrow “breadcrumb to exact artifact” rather than “full lineage graph now.”

## Resulting judgment
Promote only the following small seam in this revision:
1. **loss class** — what kind of fidelity change occurred;
2. **exemplar anchor** — whether a bounded concrete breadcrumb exists outside the summary;
3. **raw-retention fence** — whether the narrower evidence still exists and how reachable it is.

Keep parked for now:
- a universal drill-through API;
- mandatory raw retention for every family;
- a global exemplar registry;
- or a multi-stage aggregate planner.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the datacube a safer path to future ATTRFS summaries, inspect-derived health trends, support-bundle views, and accelerated read models without premature semantic freeze.
