# Research synthesis — pass L

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from lineage systems, workflow metadata, versioned lake catalogs, and asset tools: a cube stays healthier when a derived value can say **which input cut it used, which recipe/parameters produced it, and whether the result is realistically replayable later**.

The smallest durable seam from this pass is:
- **input cut** — the exact source snapshot, revision, partition/time window, or fact epoch the value depended on;
- **recipe witness** — the compact digestable residue for the transformation/query/parameters that produced the value;
- **replay class** — whether the value is reproducibly recomputable, conditionally restatable, or fundamentally advisory/non-replayable.

These are still smaller than a full lineage graph, asset catalog, orchestration ontology, or universal reproducibility subsystem.
They simply keep future Foundry rows from laundering “some query ran somewhere” into durable datacube truth.

## Lessons we must learn from the past

### 1) Lineage without run context is too thin
OpenLineage’s core model centers dataset, job, and run, and its facets exist precisely because one run often needs more context than a plain parent/child edge provides.
That is a good warning for Foundry: a derived value should not rely on a giant lineage graph before it can at least carry a small input-cut and recipe witness.

### 2) Parameters belong with the run, not in someone’s memory
OpenLineage now has an execution-parameters facet specifically for input parameters/configuration supplied to a job.
That is the right discipline for a future cube too: thresholds, filters, partition windows, and feature toggles should not hide in prose or dashboard folklore.

### 3) Reproducible queries want immutable input references
lakeFS makes metadata searchable by branch, commit, or tag, and explicitly says commit IDs or tags ensure reproducible queries because they point at immutable metadata state.
Delta Lake makes the same larger point through time-travel/versioning.
Foundry should steal the smallest version of that lesson: branch-like intent is smaller than an actual input cut.

### 4) A recipe witness can be tiny and still valuable
The dbt artifact model is instructive here.
Each invocation writes artifacts, and `manifest.json` records a full project/resource representation with executed-node details such as compiled SQL when present.
Foundry does not need all of dbt, but it should steal the idea that replayable derived truth wants an inspectable recipe residue.

### 5) Execution metadata must come from the real execution path
Airflow’s asset-event metadata docs contain a very practical warning: metadata added in `pre_execute` or `post_execute` hooks may not match reality on retry because those hooks are not rerun.
That is exactly the kind of past mistake Foundry should learn from.
A recipe witness that is not tied to the actual execution path can silently become fiction.

### 6) Replay posture is smaller than a universal provenance plane
Dagster’s materialization metadata, provenance access, and optional column lineage are useful reminders that a system can expose helpful replay/provenance residue without forcing every consumer to understand one giant lineage universe.
Foundry should keep that restraint.

## What to steal now
- an **input cut** beside any derived value whose meaning depends on specific source state;
- a **recipe witness** that keeps query/transform/parameter shape inspectable;
- a **replay class** so “recompute later” is distinguished from “only conditionally restatable” and from “advisory snapshot only”;
- a habit of pinning branch-like or floating selection intent separately from the actual immutable input cut;
- and a habit of attaching derivation metadata from the execution/materialization path rather than from side hooks or post-hoc folklore.

## What to keep parked
Do not yet promote:
- a universal lineage graph requirement;
- a global asset-orchestrator ontology;
- one canonical transformation-language registry;
- automatic reproducibility guarantees for every query-shaped output;
- or a giant provenance UI/export family.

## Resulting recommendation
The next healthy move is not “design the full lineage plane.”
It is to let Foundry say, for any future derived value:
1. which exact input cut it used,
2. which compact recipe witness explains how it was produced,
3. and what replay class honestly describes whether it can be recomputed later.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from lineage specs, versioned data catalogs, workflow metadata, and asset materialization systems.
