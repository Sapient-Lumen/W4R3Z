# SlopOS plus companions evaluation — pass XXXVIII

This pass tested whether Foundry should preserve one narrow seam beside pass XXXVII's absence vocabulary: *exact issued artifact* versus *current validity now* versus *how long a good-status answer stays fresh enough*.
The answer is yes, but again only narrowly.

## What SlopOS and companions already contribute
The uploaded SlopOS archive already carries the core anti-flattery rule almost verbatim.
Its **lease-descriptor state boundary** says a lease/grant descriptor is exact issuance-bounded evidence of one reviewed grant shape, not a portable oracle for current provider-owned live state.
Its **capability-lease posture** separately says CH-CAPLEASE is evidence, not authority.
Its **attestation freshness boundary** keeps old good evidence from quietly impersonating current enough evidence.
Those are different domains, but together they already teach the discipline Foundry needs: exact issued artifacts are real, yet current acceptability often lives elsewhere and ages.

The companions sharpen the same seam from adjacent directions:
- **Steward** already keeps presence adverts, renewal windows, and stability windows smaller than present readiness or serving truth.
- **Ward** keeps exported evidence smaller than verdict, and recency smaller than final release judgment.
- **Harbor** keeps detour/continuation artifacts bounded instead of letting one return object impersonate durable trust.

So the ecosystem already has better homes for a full auth/revocation/lease-management product.
Foundry does not need to grow a second one.

## What Foundry should own instead
Foundry should own only the semantic split that keeps these facts distinct:
1. **issuance witness** — exact minted descriptor/proof/receipt for one once-approved foreign grant or artifact shape;
2. **live-validity witness** — current statement that the thing remains active/usable in one decision context now;
3. **recheck horizon** — explicit limit after which old positive validity knowledge becomes too stale to overclaim.

That seam is smaller than revocation services, smaller than lease inventories, and smaller than auth proof brokerage.
It is just enough vocabulary to stop later docs from laundering one historical descriptor, once-good certificate, or cached active bit into present authority.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small truth that a foreign token, descriptor, certificate, or grant receipt can be:
- still exact about what was once issued,
- no longer currently valid because it expired, was revoked, or became context-inapplicable,
- or only conditionally usable because the last positive status answer has aged past its recheck horizon.

If Foundry misses that seam now, later revisions will be tempted to let signedness, exact bytes, or yesterday’s successful status check quietly imply the strongest story available.
That would make the archive worse at explaining short-lived credentials, cached token introspection, lease descriptors that outlive live permission, old OCSP/CRL knowledge, and current-validity checks that are correct only for one bounded window.
