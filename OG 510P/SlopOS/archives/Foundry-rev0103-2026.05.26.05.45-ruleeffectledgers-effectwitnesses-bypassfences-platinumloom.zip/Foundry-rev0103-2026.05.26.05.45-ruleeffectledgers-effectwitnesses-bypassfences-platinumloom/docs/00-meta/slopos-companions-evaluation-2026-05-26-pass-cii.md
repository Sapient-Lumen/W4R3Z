# SlopOS companions evaluation — 2026-05-26 pass CII

## SlopOS

SlopOS support-card and CH-* surfaces can consume rule-evaluation traces as evidence that a Foundry rule was applied or skipped for a specific carrier/context. They must not treat a trace as SlopOS proof, operator trust, policy approval, or source truth.

## Ward

Ward can consume applicability witnesses as caveated input when a support surface is being previewed for appraisal. Foundry must not decide Ward verdicts or appraisal authority.

## ViewFS

ViewFS can consume misapplication fences when projection surfaces try to reuse rule choices across aliases, renderers, or extracted artifacts. Foundry must not decide custody, filesystem identity, consent, or trusted-path authority.

## Harbor

Harbor can consume rule-evaluation residue when correction/aftercare surfaces need to know why a Foundry rule was not applicable. Foundry must not own outside-fact correction, membrane truth, or remediation authority.

## Steward and Helm

Steward and Helm can consume stale/default/checker-contract fences when worker/retry/repair paths are tempted to treat a passing checker as lifecycle success. Foundry must not decide effect finality, repair success, or intervention custody.

## Schell

Schell can consume traces to see whether no-reexport, sidecar, recall, or retention-adjacent obligations were carried through an application context. Foundry must not decide forgetting, minimization, deletion, or retention authority.
