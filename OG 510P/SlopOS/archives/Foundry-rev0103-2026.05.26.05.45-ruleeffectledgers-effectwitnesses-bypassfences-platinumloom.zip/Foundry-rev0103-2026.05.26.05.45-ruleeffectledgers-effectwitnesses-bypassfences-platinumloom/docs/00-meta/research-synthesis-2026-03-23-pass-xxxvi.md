# Research synthesis — pass XXXVI

This pass stays deliberately close to pass XXXV.
The last pass preserved the seam between **effect key**, **fingerprint fence**, and **prior-outcome anchor**.
The next cheap-to-preserve seam is what happens when a later retry is *too early* or *too late*.
Several mature systems distinguish three truths that are easy to flatten if the cube only says “idempotent request”:

1. the same key and same fingerprint may arrive **while the original work is still outstanding**;
2. the same key and same fingerprint may arrive **after the original work completed**, so a prior result can be replayed;
3. the same key may arrive **after the retention window has expired**, so replay/suppression truth is no longer honest.

That split is worth preserving now because it is smaller than an async job system and smaller than a global exactly-once ledger.
It is just enough honesty to keep retry semantics from quietly impersonating present live state or eternal memory.

## Lessons from current outside systems

1. **The current HTTP idempotency draft distinguishes completed duplicates from concurrent duplicates.**
   The October 2025 Internet-Draft says a duplicate request after the original completed should return the earlier result, while a retry before the original completed should return a conflict-style error for an outstanding request.
   It also says resources must publish expiration policy when applicable.

2. **Stripe separates replayable duplicates, concurrent duplicates, and pruned keys.**
   Stripe saves the first result once endpoint execution begins, compares parameters on reuse, exposes an `idempotency_key_in_use` condition when the same key is concurrently in another request, and says keys can be pruned after they are at least 24 hours old, after which reuse becomes a new request.
   Stripe also says no idempotent result is saved when validation fails or when the request conflicts with another request already executing.

3. **AWS ECS makes the retention horizon explicit.**
   ECS `RunTask` says the same client token and same parameters return the original result after a successful request, changed parameters fail with `ConflictException`, and the client token has a bounded TTL: the lower of 24 hours or the resource lifetime plus one hour.
   That is an especially good anti-lesson for cubes: key memory is policy, not permanence.

## What this means for Foundry

Foundry should keep the pass XXXV seam, but it now needs one smaller adjacent seam so later docs cannot say “same key” and leave the timing class unstated.
The useful promoted nouns are:
- **pending duplicate** — the same effect key and same fingerprint arrived while the original work is still unresolved;
- **dedupe horizon** — the bounded interval or retention policy during which duplicate-safe replay/suppression remains defined;
- **expiry gate** — the boundary after which the old key no longer honestly buys replay or suppression and a new effect attempt may happen.

The main past lesson is not “build a queue”.
It is the narrower rule that **retry-equivalent identity still lives on a clock**.
A key can be too early for replay because the first attempt is still in flight, and it can be too late for replay because the dedupe memory was intentionally forgotten.
Systems that flatten that timing seam end up lying about whether a second attempt is safe, pending, replayed, or fresh.

## Candidate nouns worth collecting
- **pending duplicate** — same key, same fingerprint, original work still outstanding.
- **dedupe horizon** — bounded replay/suppression memory interval for one effect key.
- **expiry gate** — visible edge where prior dedupe memory stops being authoritative.

## Things to keep parked
- a universal async task or polling plane;
- a forever operation ledger;
- any collapse of key expiry into key mismatch;
- any claim that an old receipt recreates the dedupe horizon after retention has elapsed.

## Provisional judgment
Promote only the seam.
Foundry should be able to say that one later retry is a **pending duplicate**, that duplicate-safe replay or suppression only lives within one **dedupe horizon**, and that an **expiry gate** can end that promise without implying request mismatch or provider error.
That is especially valuable while SlopOS is still plastic enough to avoid teaching future docs that “same key” always means “same answer now”.
