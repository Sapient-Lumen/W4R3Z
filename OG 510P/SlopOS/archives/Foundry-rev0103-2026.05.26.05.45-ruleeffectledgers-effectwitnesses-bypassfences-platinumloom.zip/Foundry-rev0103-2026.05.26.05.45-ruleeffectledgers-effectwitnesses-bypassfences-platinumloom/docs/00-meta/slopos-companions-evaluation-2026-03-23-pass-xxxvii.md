# SlopOS plus companions evaluation — pass XXXVII

This pass tested whether Foundry should preserve one narrow seam beside pass XXXVI's retry-window vocabulary: *current absence* versus *durable withdrawn state* versus *safe resurrection/reuse*.
The answer is yes, but again only narrowly.

## What SlopOS and companions already contribute
The uploaded SlopOS archive already keeps the right anti-flattery law in several places.
Its attention boundary keeps `post` and `withdraw` on a small ephemeral request seam and refuses to let that mutate into durable history or interruption authority.
Its crypto-service key-lifecycle boundary likewise refuses to let ordinary key use imply durable delete/archive/revoke truth.
Those are different domains, but they point in the same direction: withdrawal or deletion semantics are stronger than ordinary “not present right now”, and stronger semantics should not be smuggled through smaller surfaces.

The companions sharpen the same seam from adjacent directions:
- **Steward** already keeps discoverable presence separate from readiness and distinguishes `advertised`, `withheld`, `withdrawn`, and `expired` instead of forcing every negative discovery fact into one bucket.
- **ViewFS** already keeps remove/unbind, trash entry, recoverability history, retention roots, and purge on different seams, which is exactly the anti-collapse Foundry needs nearby.
- **Steward** and **ViewFS** together show that negative or withdrawn state is useful only when the archive resists treating “not visible now” as the whole truth.

So the ecosystem already has better homes for full trash/history/discovery products.
Foundry does not need to grow a second one.

## What Foundry should own instead
Foundry should own only the semantic split that keeps these facts distinct:
1. **absence witness** — explicit current no-object / no-current-representation claim, often cacheable and bounded;
2. **tombstone marker** — durable deletion or withdrawal marker that can make ordinary reads look absent while hidden history still exists;
3. **resurrection fence** — grace or quarantine boundary before dropping the marker or reusing that identity becomes honest.

That seam is smaller than trash, smaller than GC, and smaller than durable discovery/history APIs.
It is just enough vocabulary to stop later docs from laundering one current negative answer into “gone forever” or “safe to reuse immediately”.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small truth that a foreign-backed object, slot, selector, or published handle can be:
- currently absent for ordinary reads,
- intentionally withdrawn via a still-real hidden marker,
- or not yet safe to purge/reuse because stale replicas, caches, or observers could resurrect the old truth.

If Foundry misses that seam now, later revisions will be tempted to let negative responses, withdraw acts, or delete receipts quietly imply the strongest story available.
That would make the archive worse at explaining versioned delete markers, withdrawn-yet-recoverable state, stale-cache absence, zombie resurrection, and reuse hazards — all of which are already real pressures in the companion ecology.
