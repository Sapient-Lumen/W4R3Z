# Research synthesis — 2026-03-23 pass II

This pass combined two inputs:
1. a readthrough of the current cube ecology to infer house style, neighbor boundaries, and repeated pressure points;
2. a fresh outside pass across official specifications and project documentation relevant to Foundry.

## What the current cube ecology teaches
- small, sharp separations age better than giant synthetic frameworks;
- typed receipts, grants, witnesses, and ladders are healthier than ambient folklore;
- sibling cubes become more valuable when they export modest truths instead of pretending to own the whole story;
- archive discipline matters: charter, trajectory, roadmap, question ledger, and assumption ledger give the cube continuity before it has a giant implementation story.

## What the outside sources reinforced


- packaging, runtime config, and explicit interface contracts are distinct layers;
- foreign grounds can look uniform from the outside while still carrying very different trust and continuity stories;
- restore and reattach are easy places to overclaim unless continuity evidence stays explicit.

## Resulting founding bet
Foundry should begin with a **small object model and visible non-decisions**, not with a giant implementation scaffold.
