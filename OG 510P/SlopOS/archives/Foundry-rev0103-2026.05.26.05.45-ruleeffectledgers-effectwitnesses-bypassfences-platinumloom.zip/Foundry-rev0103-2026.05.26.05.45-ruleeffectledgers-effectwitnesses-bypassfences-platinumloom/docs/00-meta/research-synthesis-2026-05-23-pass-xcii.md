# Research synthesis — 2026-05-23 pass XCII

Focus: **surface inventory sweeps, reachability witnesses, and coverage-gap fences**.

The previous pass made post-readmission circulation explicit: a repaired carrier needs distribution manifests, adoption receipts, and orphan-copy fences. This pass closes the next gap: distribution only accounts for the targets someone already named. It does not prove Foundry found every reachable cache, notebook extract, projection, delegated-worker copy, alias, or old export that can still influence interpretation.

## New outside pressure

- `EXT-NIST-CM8-INVENTORY-2026` gives the right scar for inventory accountability: an inventory should accurately reflect the current system, include components within the boundary, avoid duplicate accounting, and use the granularity needed for tracking. Foundry should steal the boundary/granularity/no-duplicates instinct without becoming a security-control program or asset CMDB.
- `EXT-W3C-DCAT3-2024` already warned Foundry not to confuse catalog/distribution metadata with truth, quality, or verdict. For this pass, it reinforces that discovery records are useful descriptions, not complete evidence that every reachable semantic copy was swept.
- `EXT-OPENLINEAGE-SYMLINKS-2026` shows why alternate identifiers matter: one dataset can appear by physical path in one context and logical name in another. Foundry should steal alias-collapse humility without becoming a lineage platform or identifier registry.
- `EXT-SPDX-RELATIONSHIPS-2026` shows that relationship edges between described elements are explicit records, not ambient truth. Foundry should borrow relationship-accounting pressure without becoming an SBOM or package graph.
- `EXT-K8S-OWNER-DEPENDENTS-2026` shows owner/dependent references and cleanup hooks can express dependency, but not semantic authority. Foundry should steal scoped owner/dependent caution without becoming an orchestrator or garbage collector.

## What rev0091 still allowed

Rev0091 could prove that a readmitted carrier was sent to named targets and that each target adopted, refused, quarantined, or fenced an old copy. It still allowed quiet inventory failures:

- the distribution manifest omits an old notebook extract nobody remembered;
- a dashboard tile has both a logical name and an object-store path, and only one alias is swept;
- a ViewFS projection is reachable through a trusted path but not listed as a target surface;
- a delegated worker copy is inaccessible, and the failed listing is mistaken for non-existence;
- a cache bucket refuses inspection but no recheck hook or gap fence is left behind;
- a discovered shadow CSV is displayed as adopted because it contains the new digest;
- duplicate accounting lets the same surface pass twice while another surface remains unswept; or
- a catalog entry is treated as proof that all reachable copies were inventoried.

Those are inventory/reachability failures, not distribution/adoption failures.

## Speculative read

Foundry needs a small **surface discovery seam** after distribution:

```text
surface inventory sweep = scoped attempt to enumerate expected and discovered relying surfaces
reachability witness    = one observed surface/copy/alias with digest, path, residue, and limits
coverage-gap fence      = one missing, ambiguous, inaccessible, duplicate, or unlinked surface blocked until clearance
catalog card            = useful clue, not inventory truth
failed listing          = useful evidence, not absence
alias match             = useful evidence, not adoption
```

This should stay intentionally less ambitious than a catalog, CMDB, object inventory, crawl framework, lineage graph, SBOM, package manifest, scheduler, or cleanup system. Foundry only needs to prevent a dangerous sentence: "we distributed the fix, therefore there are no stale or unknown reachable copies."

## New specimen pressure

Add specimen 86 around surface inventory sweeps, reachability witnesses, and coverage-gap fences. The fixture must prove at least:

- every sweep names seed distribution manifests, carrier ids/digests, expected surfaces, discovery sources, scope limits, and method limits;
- every reachable expected surface has a reachability witness with observed digest, path/alias evidence, residue seen, and adoption/fence links;
- every unreachable, ambiguous, unlinked, permission-denied, duplicate, or unexpected surface has a coverage-gap fence;
- complete sweeps cannot have unaccounted expected surfaces;
- partial and blocked sweeps cannot be advertised as closure;
- alternate identifiers collapse only under an explicit witness, not because labels match;
- discovered copies are not adoption receipts; and
- negative cases cover missing sweep, missing seed manifest, missing witness, unaccounted expected surface, unknown/unfenced surface, unresolved alias, expired sweep window, owner mismatch, digest mismatch, inventory-as-catalog, inventory-as-truth, and duplicate accounting.

## Recommendation

Keep surface inventory fixture-local and reversible. Do not promote a global catalog, asset inventory, crawler, reachability protocol, object-store listing format, lineage graph, owner/dependent cleanup model, SBOM, or custody system. The narrow Foundry job is to make discoveredness, reachability, alias resolution, and inventory gaps visible enough that stale semantic carriers cannot hide behind a successful distribution receipt.
