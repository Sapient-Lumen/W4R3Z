# Research synthesis — pass XXXIV

This pass keeps the next seam deliberately narrow: **holder epoch / fence token / stale-holder cut**.
The strongest shared outside lesson is not “build a distributed lock service” or “standardize failover now”.
It is smaller and more durable: systems that reassign a singular mutable role keep rediscovering that *new current owner* and *old holder can no longer do harm* are different truths.
Foundry should preserve that seam without importing one global lease service, one universal leadership plane, or one portable lock manager.

## Primary lessons from the outside

### 1) Currentness without fencing is openly admitted to be weaker than correctness
Kubernetes’ client-go leader-election package says the quiet part out loud: it **does not guarantee fencing**.
That is a precious anti-lesson.
A lease record or current leader hint may be good enough for some availability tasks while still being too weak for correctness-critical singular mutation.
Foundry should preserve that warning instead of laundering every “current leader” surface into a safe singular-authority claim.

### 2) Monotonic epochs are a compact and steal-worthy zombie defense
Kafka’s transactional protocol and producer APIs provide a cleaner positive lesson.
The protocol now bumps the producer epoch on every transaction in the strengthened 4.x path, and the protocol/error surfaces explicitly define `INVALID_PRODUCER_EPOCH` for operations attempted with an old epoch.
The producer APIs likewise treat `ProducerFencedException` as a fatal sign that another producer with the same `transactional.id` is active.
That is the right level of steal: not “adopt Kafka transactions”, but “keep one exact monotonic witness that stale holders cannot outtalk”.

### 3) Write fencing and total disappearance are different promises
Hadoop HDFS HA with QJM sharpens the boundary from yet another direction.
The JournalNodes allow only one writer at a time, which prevents split-brain metadata corruption, but the docs still say the previous Active NameNode may continue serving stale reads until it shuts down when it next tries to write.
That is exactly why Foundry needs a **stale-holder cut** rather than one triumphant “old owner gone” bit.
A predecessor can be non-authoritative for mutation before it is fully gone from the world.

## SlopOS/companion pressure
The uploaded cube ecology already leans toward this seam.
SlopOS keeps ordering tokens, activation handoff, revocation epochs, drain/quiesce, and currentness surfaces separate enough that “new current” does not automatically imply “all older holders are now harmless”.
Steward is even more explicit in its README trajectory language: it collects exact fence-token semantics for reassignable live claims while warning against freezing a giant distributed-lock or global-sequencer plane.
ViewFS also contributes the right house style by keeping current handles, live handle copies, shared open state, and independent reopens distinct.

That makes the Foundry move very small:
- **holder epoch** should say who currently owns one singular mutable lane;
- **fence token** should say what exact witness downstream systems must check to reject stale claimants;
- **stale-holder cut** should say when older presence is smaller than current authority.

## Candidate nouns worth collecting
- **holder epoch** — monotonic ownership/version step for one singular mutable or serving role.
- **fence token** — exact checked witness that mutable receivers use to reject stale holders.
- **stale-holder cut** — explicit point where an older holder loses mutation/current-owner authority even if still alive.

## Things to keep parked
- one universal lease or lock service;
- a portable leader-election API;
- any claim that fencing always requires process death rather than downstream refusal;
- any collapse of “new current owner”, “old holder drained”, and “old holder impossible to act” into one flattering failover bit.

## Provisional judgment
Promote only the seam, not the control plane.
Foundry should be able to say that a newer holder owns the current mutable lane by **holder epoch**, that downstream mutation requires a **fence token**, and that a **stale-holder cut** explains why an older still-running actor no longer counts as authoritative.
That is especially valuable while SlopOS is still plastic enough to avoid teaching later docs that election, activation, or restart automatically imply correctness-safe singular ownership.
