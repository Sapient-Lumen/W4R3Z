# Research synthesis — pass XVI

This pass keeps Foundry narrow and learns one more thing from outside runtime systems: **a foreign realization can start executing before all of its bytes are local, and that means readiness, locality, and performance debt should stay explicit**.

## Outside lessons
1. **stargz-snapshotter treats lazy pulling as normal.**  
   A container can run without waiting for the whole image pull to complete, while needed files or chunks are fetched on demand. Foundry should steal the honesty: “running now” can still mean “not fully local yet”.

2. **eStargz stays compatible while adding runtime-oriented behavior.**  
   The format remains compatible with OCI/Docker images and adds runtime optimization and content verification. Foundry should preserve the distinction between compatibility of packaging and readiness of realization.

3. **Prefetch changes the debt story without erasing it.**  
   The docs note that on-demand fetch can hurt run-time access, while optimization can prefetch likely-needed files and shorten the first-use penalty. Foundry should keep prefetch witness and cold-read debt separate instead of pretending lazy hydration is either free or impossible.

4. **The current cube ecology wants this split.**  
   SlopOS keeps capability leases and import/materialization boundaries small; ViewFS already warns against collapsing download, hydration, caching, and offline truth; Foundry can therefore add hydration honesty without laundering it into local completion.

## Resulting Foundry move
Do not decide yet whether the durable noun is `hydration frontier`, `prefetch witness`, or `cold-read debt`.
For now, keep all three alive as specimen nouns and demand that they improve:
- one fast-start lazy-hydration specimen,
- one optimized prefetch specimen,
- and one specimen where execution succeeds but later access still reveals locality debt.

## Fresh ideas worth stealing
- **hydration frontier** — how much of the foreign artifact is materially local right now.
- **prefetch witness** — compact residue about what was intentionally fetched early.
- **cold-read debt** — the remaining latency/dependence cost of on-demand hydration.
- **lazy-locality grade** — an honesty class for “works now, still not fully local”.
