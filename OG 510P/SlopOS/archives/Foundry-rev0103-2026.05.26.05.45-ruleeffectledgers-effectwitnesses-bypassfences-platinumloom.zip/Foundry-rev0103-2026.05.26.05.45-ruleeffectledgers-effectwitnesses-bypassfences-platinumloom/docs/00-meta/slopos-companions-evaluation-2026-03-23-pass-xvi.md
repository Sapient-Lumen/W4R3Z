# SlopOS and companions evaluation — pass XVI

This pass keeps Foundry aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** keeps capability leases, import/materialization seams, and foreign/runtime meaning cuts small; that argues against treating “started” as “fully local”.
- **ViewFS** explicitly warns against collapsing prefetch, cache warmth, hydration, pinning, mirroring, and offline bundles into one download-state blob. Foundry should treat that as a direct pressure signal.
- **Helm** still wants clear operator truth, so a product surface should be able to say “running through lazy hydration” without embarrassment.
- **Schell** still wants live checkout and adoption gates, which makes cold-read debt and hydration frontier operationally relevant.
- **Steward** still benefits from typed aftermath and followthrough; a foreign realization that launches before full hydration should leave typed residue.

## Pressure on Foundry
Foundry should not decide yet whether hydration posture belongs inside artifact, handle, or realization objects.
The stronger move is to keep one more specimen where:
1. execution starts before full locality,
2. optimization changes likely-read performance,
3. locality debt remains visible after launch,
4. and adoption does not overclaim full materialization.

## Promotion restraint
Do not promote `hydration frontier`, `prefetch witness`, or `cold-read debt` unless they improve:
- one lazy-start specimen,
- one optimized-prefetch specimen,
- and one case where later reads still reveal foreign dependence after apparent success.
