# Research synthesis — 2026-05-21 pass LXXXIII

Focus: **residue sidecars, flattening refusals, and semantic fixture checks**.

This pass does not add a new external-source family. It operationalizes the pressure already carried in the source register from RDF Data Cube, OpenLineage, Apache Iceberg, dbt semantic models, Looker symmetric aggregates, Open Data Contract Standard, FHIR ConceptMap, OpenTelemetry semantic-convention naming, and prior SlopOS/companion archive readings.

## Why the previous seven specimens are not enough

Specimens 70 through 76 name the right seams:

- query/result/validation residue;
- hierarchy/rollup/aggregation residue;
- materialization/refresh/reuse residue;
- disclosure/suppression/differencing residue;
- observation-status/adjustment/as-observed residue;
- control-total/reconciliation/balance residue;
- classification/crosswalk/code-drift residue.

But prose seams alone are not enough. A later table, chart, CSV, JSON export, dashboard tile, support card, or SlopOS-facing operator artifact can still drop the residue and look tidy. The missing test is whether the meaning survives egress.

## Prior-source pressure being reused

- `EXT-W3C-RDF-DATA-CUBE-2014` keeps observation structure separate from arbitrary metadata and supports the idea that dimensions/measures/attributes should travel with observations rather than becoming one opaque table.
- `EXT-OPENLINEAGE-OBJECT-MODEL-2026` and `EXT-OPENLINEAGE-DATASET-TYPE-2026` keep runs, jobs, datasets, and materialized dataset type posture separate, which reinforces Foundry's cut/run/refresh split.
- `EXT-ICEBERG-BRANCHING-2026` reinforces that named cuts, branches, tags, and retention posture are semantic facts when a result depends on them.
- `EXT-LOOKER-SYMMETRIC-AGGREGATES-2026` reinforces that joins and rollups need fanout/grain discipline before a BI-looking result can be reused.
- `EXT-DBT-SEMANTIC-MODELS-2026` reinforces that entities and key posture are part of semantic serving, but should not force Foundry into a full semantic-layer product.
- `EXT-ODCS-3-1-2026` reinforces the separation between a human/data-contract surface and machine validation artifacts.
- `EXT-FHIR-CONCEPTMAP-2026` reinforces contextual, directional mappings that may be incomplete and should not become automatic transforms.
- `EXT-OTEL-SEMCONV-NAMING-2026` reinforces deprecation/renaming without reusing old names as if they were current durable meaning.

## Speculative read

Foundry is becoming not just an off-native realization archive, but a **projection-honesty archive**. The dangerous future is not only that execution moves to foreign ground. It is that a native-ish fact is projected into a convenient table, chart, export, support-card total, cache hit, current-label display, or profile-local category and then gets treated as source truth.

That suggests a second stack beside the founding five-layer model:

```text
L0 — source/native evidence
L1 — row meaning
L2 — derivation/query meaning
L3 — release/render meaning
L4 — consequence/appraisal outside Foundry
```

This pass adds a narrow L3 carrier: a residue sidecar plus flattening refusal rules. It intentionally avoids a universal datacube schema, warehouse engine, semantic-layer runtime, terminology server, privacy engine, validation DSL, or official-statistics framework.

## Design claim

A result that leaves Foundry must do exactly one of three things:

1. carry the relevant residue in-band;
2. carry a digest-linked semantic sidecar; or
3. refuse the export/render/flattening path.

Anything else is label laundering.

## Required executable pressure

The first fixture harness should catch at least these failures:

- label-only export of category values;
- bare-code joins across schemes, profiles, or cuts;
- cache hit reused across a different policy/classification/materialization cut;
- balance result reused across a different classification cut;
- suppressed or noisy cell treated as zero, null, or exact;
- adjusted/imputed/provisional value exported as raw observation;
- hierarchy parent row reused as total without rollup/aggregation evidence;
- deprecated external semantic-convention member rewritten into current label truth;
- unmapped legacy code coerced into null, default, current `other`, or failure.

## Recommendation

Add specimen 77 around residue sidecars, flattening refusals, and egress survival. Add a tiny schema pair, specimen fixtures for 70 through 76, a cross-specimen SlopOS support-card fixture, and deterministic checkers. Keep every new file explicitly v0 and fixture-shaped so the sidecar carrier cannot quietly become Foundry's permanent ontology.
