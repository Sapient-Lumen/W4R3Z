# Research synthesis — pass LXXIII

This pass stays conservative.
Foundry still should **not** freeze one archive-wide severity ladder, one universal bucket layout, or one flattering doctrine that every band/percentile/tier label can be treated like a reusable scalar.
But it can steal one more durable lesson from observability formats, vulnerability scoring, and clinical interpretation vocabularies: **a design-phase datacube needs to distinguish what kind of banded or bucketed value this is, what threshold recipe produced it, and where later readers must not scalarize it into faux precision.**

The smallest durable seam from this pass is:
- **band class** — the compact statement of what kind of reduced value is visible: qualitative-severity, threshold-bucket, ordinal-stage, rough-interpretation, percentile-band, policy-priority-tier, or another reviewed class;
- **threshold basis** — the compact statement of which cutpoints, rubric, or bucket layout produced the visible band: CVSS-table-22, local-triage-policy-v1, histogram-bounds-digest, profile-posture-rubric-v0, reference-range-vN, or another reviewed basis;
- **scalarization fence** — the compact statement of what later readers must not do: no-arithmetic, ordinal-compare-only, same-thresholds-only, display-only, no-cross-version-aggregation, or forbidden.

These are still smaller than a universal risk-score ontology, one permanent threshold registry, or a promise that every “high/medium/low”, percentile, or bucket label is comparable across products, time, or local policy.

## Lessons we must learn from the past

### 1) Bucket layout is semantics, not decoration
OpenMetrics says every classic histogram bucket has a threshold, bucket counts are cumulative, and thresholds should stay constant over time and between targets intended for aggregation.
That is exactly the lesson Foundry should steal.
Once a value is bucketed, the threshold layout becomes part of meaning.
A future cube should therefore preserve **threshold basis** instead of pretending every bucket label is interchangeable.

### 2) Different distribution summaries fail in different ways
Prometheus’s histogram-versus-summary guidance says summaries can produce accurate client-side quantiles but cannot be aggregated across instances, while histograms can aggregate and move error into the observed-value dimension via bucket layout.
That means two “p95 latency” values may both look numeric while depending on very different upstream semantics.
Foundry should therefore preserve both **band class** and **threshold basis** instead of flattening percentiles, buckets, and exact-at-cut values into one reusable number plane.

### 3) Qualitative severity is smaller than the full score story
CVSS v4.0 defines a qualitative severity scale mapping quantitative scores into None/Low/Medium/High/Critical bands and explicitly says use of those qualitative ratings is optional.
The separate Consumer Implementation Guide recommends layering Threat and Environmental metrics so prioritization reflects the consumer’s environment.
That is a direct warning against treating a visible severity band as timeless or universal truth.
A future cube should keep the band visible while preserving the **threshold basis** and any local policy overlay that made the band operationally important.

### 4) Rough interpretation is smaller than measurement
HL7 ObservationInterpretation says codes like normal/abnormal, low/high, or better/worse are a rough qualitative interpretation of an observation.
That is an excellent pattern for Foundry.
A rough band or interpretation can be useful without replacing the underlying value, unit, reference range, or local clinical/policy context.
That belongs in **band class** plus **scalarization fence**.

### 5) Aggregation safety depends on stable thresholds
OpenMetrics also warns that changing bucket thresholds can prevent histograms from participating in the same operation over time or across targets.
This is the stealable idea.
Even when a bucket label looks stable to a human, threshold drift can make arithmetic dishonest.
Foundry should therefore keep **same-thresholds-only** and similar scalarization fences available before it promises cross-cut comparability.

### 6) Prioritization bands are policy-shaped even when fed by standards
The CVSS Consumer Implementation Guide pushes consumers to combine Threat and Environmental metrics so prioritization becomes environment-specific rather than stuck at generalized worst-case assumptions.
That means “high priority” may be a policy-local band layered over imported scores.
A future cube should not let policy-shaped urgency tiers impersonate native substrate truth.

## What to steal now
- a **band class** field or adjunct that says whether the visible thing is a threshold bucket, percentile band, rough interpretation, qualitative severity, or another reduced-value class;
- a **threshold basis** field or adjunct that points at the exact cutpoint recipe, bucket layout, or rubric that created the visible band;
- a **scalarization fence** that blocks arithmetic, re-aggregation, or cross-version comparison when the band is only ordinal, display-local, or threshold-drifted;
- and a habit of preserving the **raw scalar or retained parts** whenever later recomputation may matter.

## What stays parked
- no archive-wide severity ladder;
- no permanent threshold registry;
- no assumption that every percentile, bucket, or qualitative band can be compared across families;
- no automatic conversion from colored badges or priority tiers into numeric cube truth.
