# Roadmap

Current revision focus (`rev0103`): rule-effect ledgers, effect witnesses, and bypass fences

## Phase 0 — found the language
- freeze the first durable separations;
- keep the assumption, pressure, question, followthrough, decision-debt, fixture, egress, regression, waiver, consumer-portability, delegation-boundary, revocation/recall, remediation/readmission, distribution/adoption, surface-inventory, exposure-accounting, obligation-accounting, fulfillment-accounting, and verification-audit, recheck/drift, and escalation/routing and disposition/resolution, rule-promotion, rule-collision, rule-evaluation, and rule-effect-binding ledgers alive;
- sharpen neighbor boundaries with Helm, Schell, ViewFS, Steward, Ward, Harbor, SlopOS, and at least one non-SlopOS egress/recall/verification consumer.

## Phase 1 — specimen cuts
- design 2–4 specimen flows or artifacts that prove the cube’s vocabulary earns its keep;
- create the smallest honest status/export/refusal/regression/waiver/consumer-portability/delegation-boundary/revocation-recall/remediation-readmission/distribution-adoption/surface-inventory/exposure-accounting/obligation-accounting/fulfillment-accounting/verification-audit/recheck-drift/escalation-routing/disposition-resolution/rule-promotion/rule-collision/rule-evaluation/rule-effect-binding surfaces before any large schema family;
- identify which sibling and non-SlopOS surfaces would consume them;
- require tiny executable fixtures when a prose seam claims it prevents a concrete flattening, anonymous-refusal, silent-regression, exception-drift, cross-consumer interpretation failure, delegated-authority failure, stale-reliance failure, replacement-as-repair failure, distribution/adoption failure, inventory/exposure failure, obligation/fulfillment failure, or false-closure verification failure, stale-verification failure, or routed-as-handled failure, or routed-as-resolved failure, local-closure-as-law failure, promoted-rule-collision failure, or precedence-as-application failure, or application-as-effect failure.

## Phase 2 — narrow registries
- only after specimen cuts, fixtures, consumer pressure, and tamper cases survive review, grow registries, schemas, code-list pins, transform rules, manifest shapes, receipt families, regression-lock families, waiver-warrant families, consumer-portability families, delegation-boundary families, revocation/recall families, remediation/readmission families, distribution/adoption families, surface-inventory families, exposure-accounting families, obligation-accounting families, fulfillment-accounting families, verification-audit families, recheck-drift families, or escalation-routing families, or disposition-resolution/rule-promotion families.

## Phase 3 — operational proof
- require at least one end-to-end example where Foundry absorbs real outside pressure without flattening a sibling cube, freezing accidental export shape, dropping egress residue, hiding refusal reason, reusing an unsafe digest, letting an expired waiver or widened exception pass, transferring sibling authority, missing a revocation notice, serving a stale carrier, readmitting an under-evidenced replacement, leaving an old copy unfenced after distribution, missing an alias-rich reachable copy during inventory, treating found surfaces as safe for every audience/purpose, treating exposed surfaces as obligation-clean, treating acknowledged obligations as fulfilled, treating completion witnesses as verified closure, treating verified audits as still-fresh, treating routed drift as handled, treating post-route disposition as resolved authority, treating local closure as reusable archive law, treating promoted-rule overlap as global precedence, or making label/code/version/schema/consumer/status/replacement/discovery/completion/sample/closure/precedent sameness into semantic truth.

## rev0103 immediate next pressure
- generate rule-effect tamper cases for evaluation-without-effect, effect-without-trace, missing effect witness, missing bypass fence, wrong carrier/surface, scope widening, shadow/deprecated/default activation, warning/audit-only laundering, checker-success-as-effect, runner-order folklore, reference-integrity drift, and no-op-as-success.
- prove one SlopOS support-card effect, one public-export refusal, one Ward preview warning/no-effect, one ViewFS projection quarantine, one delegated worker partial guard, and one Harbor informational path can share rule-evaluation residue without collapsing effect into authorization, audit, public release, repair, lifecycle finality, or sibling verdict.
- keep rule-effect residue smaller than enforcement runtimes, policy engines, feature flags, admission control, authorization, audit, public release, legal compliance, repair, lifecycle finality, and sibling-verdict systems.
- expand reference-integrity indexing only enough to catch dangling source ids, ghost fixture ids, renamed refs, and unused subset references; do not turn it into a catalog, lineage graph, certification system, or semantic-correctness proof.
