# SlopOS plus companions evaluation — pass L

This pass adds one more datacube warning:
Foundry should model **which source cut a derived value used, which recipe produced it, and whether the answer is replayable later** before it lets derived read surfaces masquerade as timeless cube facts.

## SlopOS
SlopOS already creates strong pressure in this direction.

`attrfs-posture-v0.md` says smart queries are **view-scoped**, **snapshot-first**, and return handles rather than global-inventory truth.
That means a query result count or result set is only interpretable relative to one explicit view and one cut.
So a future cube value derived from ATTRFS should carry an **input cut**, not just a cheerful count.

`skb-posture-v0.md` says the SKB is an explicit fact base with **pure named queries** and policy-driving results that stay attributable to one explicit **fact epoch**.
That already sounds like Foundry’s future **recipe witness** and **input cut** pressure.
SKB answers are not ambient host truth; they are exact relative to one declared fact base and one named query posture.

`mcp-resource-import-boundary-v0.md` says imported MCP resources stay provider-local context material rather than quietly becoming durable file/document/current-state truth.
That is a direct reminder that some derived read surfaces are only **conditionally replayable** unless the host also records the imported bytes, URI, template binding, or later materialization step.

Across SlopOS more broadly, many seams already refuse to equate provider-local hints with durable transcript truth.
That means Foundry can add replay honesty without inventing a giant new semantic layer.

So for a future Foundry datacube over SlopOS surfaces:
- a view-scoped search summary should say which view/cut it came from;
- an SKB-derived placement summary should say which fact epoch and named query/parameters produced it;
- imported-provider summaries should say whether they are replayable from durable local residue or only advisory snapshots;
- and branch-like selection intent should remain smaller than the actual immutable source cut that the value used.

## Ward, ViewFS, Harbor, and Steward
Ward already keeps appraisal outputs smaller than the evidence world they summarize, which reinforces recipe-witness humility.
ViewFS keeps object lineage and summary stories scoped rather than pretending to be universal reality, which helps keep replay class honest.
Harbor and Steward both keep presentation and freshness surfaces visibly smaller than durable source truth, which makes them good neighbors for input-cut discipline.

## Resulting judgment
Promote only the following small seam in this revision:
1. **input cut** — which exact source snapshot/revision/epoch/window the value used;
2. **recipe witness** — the compact derivation residue for the query/transform/parameters;
3. **replay class** — whether the value is reproducibly recomputable, conditionally restatable, or advisory-only.

Keep parked for now:
- any global lineage graph;
- a mandatory orchestrator model;
- a universal transformation-language registry;
- or a giant provenance/observability export plane.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the datacube a safer path to future search summaries, SKB-derived placement outputs, imported-resource digests, and replayable materialized views without premature semantic freeze.
