# Decision debt index

Purpose: sort Foundry's open promotion questions by **executable blocker**, not just by chronology.

This index does not close questions. It states what proof is missing before a prose seam becomes a wider archive object.

| Question | Seam | Current scope | Promotion blocker | Next executable pressure |
| --- | --- | --- | --- | --- |
| Q078 | query contract / result envelope / validation witness | emitted results, support-card tables, attribute queries, export surfaces | no second non-SlopOS consumer and too few egress fixtures | specimen 77 JSON result fixture plus label-free result refusal |
| Q079 | hierarchy scope / rollup path / aggregation guard | parent rows, calendars, geographies, code-list summaries, support-card rollups | no parent-row fixture proving aggregation refusal | specimen 77 parent-row table fixture |
| Q080 | materialization cut / refresh witness / reuse fence | cached, materialized, dynamic-table, support-card, stale-serving outputs | no stale/reuse tamper fixture | specimen 77 cached support-card fixture |
| Q081 | disclosure cut / suppression witness / differencing fence | aggregate release, suppressed/noisy/clean-room/DP-shaped outputs | no paired-release/export tamper fixture | specimen 77 CSV/chart fixture with suppression refusal |
| Q082 | observation-status card / adjustment witness / as-observed fence | adjusted, imputed, provisional, revised, processor-derived, quality-flagged values | no raw-export tamper fixture | specimen 77 adjusted-value export fixture |
| Q083 | control-total card / reconciliation witness / balance fence | total-sensitive result families, support-card tables, exports, rollups | no classification-cut mismatch fixture | specimen 77 support-card total fixture |
| Q084 | classification pin / crosswalk witness / code-drift fence | category-sensitive dimensions, support-card groups, imports, exports | no label-only/bare-code/unmapped-code fixture | specimen 76 and 77 classification-drift fixtures |
| Q085 | residue sidecar / flattening refusal / egress survival | tables, charts, CSV, JSON, markdown, dashboard tiles, support cards | only one SlopOS-shaped consumer so far | keep v0 sidecar fixture-only until a second consumer repeats the same fields |
| Q086 | refusal receipt / egress manifest / conformance gate | refused egress attempts, thin exports, support cards, dashboard tiles | only one toy non-SlopOS consumer and no generated tamper corpus yet | keep v0 receipt/manifest fields local until generated semantic-regression cases pass |

| Q087 | semantic diff manifest / regression lock / tamper corpus gate | revision-to-revision sidecar, egress-manifest, and refusal-receipt regression tests | hand-authored fixture only; no generated corpus and no real non-SlopOS export yet | generate tamper cases from canonical bytes and run one real non-SlopOS consumer |
| Q088 | waiver warrant / expiry witness / exception replay gate | bounded exceptions to refused egress or semantic-regression alarms | fixture-only waiver corpus; no generated expiry/scope tamper cases and no real expired-waiver egress block yet | generate waiver tamper cases and prove one expired waiver blocks a concrete egress attempt |

| Q089 | consumer passport / portability witness / interpretation gate | cross-consumer reuse of sidecars, receipts, regression locks, waivers, support cards, dashboards, notebooks, and sibling-cube inputs | only hand-authored fixture; no generated portability tamper corpus and no real consumer/audience-change egress block yet | generate portability tamper cases and prove a concrete consumer reuse refusal |
| Q090 | delegation warrant / reliance receipt / transitive-use fence | delegated semantic acts performed by workers, notebooks, queues, sibling inputs, and external review packets | fixture-only warrant/receipt/fence corpus; no generated delegation tamper cases and no real transitive reuse block yet | generate delegation tamper cases and prove a concrete redelegation refusal |

| Q091 | revocation notice / recall receipt / stale-reliance fence | invalidated semantic carriers, stale caches, revoked warrants, withdrawn waivers, superseded receipts, and recalled consumer packets | fixture-only notice/receipt/fence corpus; no generated recall tamper cases and no real cache quarantine yet | generate revocation tamper cases and prove a concrete stale cache or notebook reuse refusal |
| Q092 | remediation packet / replacement witness / readmission gate | recalled semantic carriers, replacement sidecars, quarantined caches, partial repairs, and consumer-local reuse attempts | fixture-only packet/witness/gate corpus; no generated replacement tamper cases and no real recalled packet readmitted yet | generate readmission tamper cases and prove a concrete recalled support-card or audit-notebook replacement |

| Q093 | distribution manifest / adoption receipt / orphan-copy fence | post-readmission circulation of sidecars, support-card tables, dashboard tiles, notebook extracts, delegated-worker copies, and stale copies | fixture-only distribution corpus; no generated distribution tamper cases and no real alias-rich inventory sweep yet | generate distribution tamper cases and prove a concrete stale-copy/orphan-fence refusal |

| Q094 | surface inventory sweep / reachability witness / coverage-gap fence | post-distribution discovery across aliases, paths, notebook extracts, cache objects, projections, delegated-worker copies, and shadow exports | fixture-only inventory corpus; no generated alias/reachability tamper cases and no real second non-SlopOS alias-rich consumer yet | generate surface-inventory tamper cases and prove a concrete unknown/permission-denied/duplicate surface refusal |

| Q095 | exposure ledger / audience witness / purpose fence | post-inventory audience and purpose exposure across dashboard readers, external audit extracts, Ward previews, ViewFS inherited groups, delegated workers, shadow exports, and public links | fixture-only exposure corpus; no generated public/inherited/unknown-reader tamper cases and no real second non-SlopOS shared/public consumer yet | generate exposure-accounting tamper cases and prove a concrete unknown/public/inherited exposure refusal |

| Q096 | obligation ledger / acknowledgment witness / obligation-drift fence | post-exposure obligation carriage across sidecar-required exports, dashboards, audit notebooks, Ward previews, ViewFS projections, delegated workers, shadow exports, and public links | fixture-only obligation corpus; no generated dropped-obligation tamper cases and no real second non-SlopOS duty-carrying consumer yet | generate obligation-accounting tamper cases and prove a concrete dropped-sidecar/no-reexport/public-link obligation refusal |

| Q097 | fulfillment receipt / completion witness / nonfulfillment fence | post-obligation duty discharge across dashboards, audit notebooks, Ward previews, ViewFS projections, delegated workers, shadow exports, and public links | fixture-only fulfillment corpus; no generated deadline/digest/public/inherited/sibling-boundary tamper cases and no real second non-SlopOS duty-performing consumer yet | generate fulfillment-accounting tamper cases and prove a concrete acknowledged-but-unfulfilled sidecar/status/recall/no-reexport/recheck refusal |

| Q098 | verification audit / evidence sample / false-closure fence | post-fulfillment evidence checking across render probes, sidecar digests, classification pins, recall routes, no-reexport checks, quarantine checks, and sibling-boundary samples | fixture-only verification corpus; no generated contradiction/self-verification/stale-sample tamper cases and no real second non-SlopOS sampleable consumer yet | generate verification-audit tamper cases and prove a concrete false-closure refusal for a completion witness that looks closed but is contradicted |

## Standing rule

A future revision should not promote a new global schema family merely because several open questions share field names. It should first add a fixture that fails without the proposed field or records why the pressure remains prose-only.

## Q099 — recheck cadence / drift signal / stale-verification fence

- Current scope: fixture-local post-verification freshness.
- Promotion blocker: generated drift tamper corpus and a second non-SlopOS recheckable consumer.
- Executable pressure: specimen 91 plus `tools/check_foundry_recheck_drift.py` and schema/fixture coverage audit.
- Decision state: local-only until stale-verification and flapping-signal failures repeat outside SlopOS support-card surfaces.

## Q100 — escalation packet / routing witness / unresolved-signal fence

- Current scope: fixture-local post-drift routing.
- Promotion blocker: generated routing tamper corpus and a second non-SlopOS routable consumer.
- Executable pressure: specimen 92 plus `tools/check_foundry_escalation_routing.py` and specimen-doc coverage audit.
- Decision state: local-only until missing/misrouted/stale/inhibited/dedupe-loss routing failures repeat outside SlopOS support-card surfaces.


## Q101 — disposition ledger / resolution witness / premature-closure fence

- Current scope: fixture-local post-routing disposition and closure claims.
- Promotion blocker: generated disposition tamper corpus and a second non-SlopOS disposition-making consumer.
- Executable pressure: specimen 93 plus `tools/check_foundry_disposition_resolution.py` and negative-case coverage audit.
- Decision state: local-only until acknowledgment-as-closure, deferred-as-resolved, false-positive-without-evidence, transfer-without-receiver, stale-closure, and authority-laundering failures repeat outside SlopOS support-card surfaces.


## Q102 — precedent ledger / rule-promotion witness / overgeneralization fence

- Current scope: fixture-local post-disposition rule reuse.
- Promotion blocker: generated precedent/rule-promotion tamper corpus and a second non-SlopOS rule-reuse consumer.
- Executable pressure: specimen 94 plus `tools/check_foundry_rule_promotion.py` and lifecycle-transition coverage audit.
- Decision state: local-only until closure-as-precedent, single-case generalization, missing negative tests, unresolved-fence erasure, false-positive generalization, stale-precedent, scope-widening, shadow/deprecated-rule activation, checker/fixture drift, and authority-laundering failures repeat outside SlopOS support-card surfaces.
