# Research synthesis — pass LIII

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from search APIs, paginated query surfaces, and cursor-based result windows: a query-shaped value stays healthier when it says **how the eligible set was selected, how the returned window was cut, and what kind of total it is claiming**.

The smallest durable seam from this pass is:
- **selection recipe** — the compact witness for the predicate, ranking/sort, and view-local query shape that determined eligibility;
- **window cut** — the exact pagination or cursor slice that says which portion of the eligible set the current rows came from;
- **total mode** — whether any attached `total` means exact, lower-bound, estimated, page-local only, or unknown.

These are still smaller than a universal search product, a ranking engine contract, or a giant semantic layer.
They simply keep future Foundry rows from laundering “what this page returned” into “the whole truth of the population.”

## Lessons we must learn from the past

### 1) LIMIT/OFFSET without stable order is not one trustworthy slice
PostgreSQL’s docs are blunt: `LIMIT` / `OFFSET` return an unpredictable subset unless `ORDER BY` constrains rows into a unique order, and different `LIMIT` / `OFFSET` values can yield inconsistent subsets because the planner may choose different plans.
Foundry should learn the same lesson before it lets page-shaped outputs masquerade as stable cube facts.

### 2) A cursor is smaller than the whole result family, but healthier than blind offset drift
GraphQL’s pagination guidance recommends cursor-based pagination and a `pageInfo` surface (`hasNextPage`, cursors) specifically because it provides a stable model for large result sets.
Foundry should steal the humility: a result page should be able to say where the current window starts and ends without pretending the page itself is the full eligible set.

### 3) “Total” is not one thing
Elastic’s search API says `track_total_hits=true` yields an exact count, `false` can omit totals, and otherwise `total.relation` determines how the returned value should be interpreted.
That is a direct warning for Foundry: a plain `total` field is too flattering unless the cube also says what kind of total it is.

### 4) Pagination APIs often separate whole-result totals from current-page rows
BigQuery’s `jobs.getQueryResults` returns only the first page unless continued and carries `totalRows` plus continuation state.
That is the right kind of honesty for Foundry: page-local rows and whole-result claims should not collapse into one unnamed count.

### 5) Approximate or estimated totals are useful, but still smaller than exact truth
Meilisearch’s pagination docs distinguish `estimatedTotalHits` from `totalHits`, and Algolia documents `exhaustive.nbHits` because total hits may be approximate for large queries.
Foundry should steal that explicitness rather than pretending every UI-facing total is equally exact.

## What to steal now
- a **selection recipe** beside any query-shaped or search-shaped value so consumers know what made rows eligible and in what order they were surfaced;
- a **window cut** so page/cursor/offset slices stop pretending they are the entire eligible set;
- a **total mode** so exact, lower-bound, estimated, page-local, and unknown totals stop sharing one flattering field shape;
- a habit of keeping query convenience smaller than population truth;
- and a habit of refusing audience-neutral arithmetic when the page/window semantics are not preserved.

## What to keep parked
Do not yet promote:
- a universal ranking model;
- a global search or browse API vocabulary;
- a mandatory per-row relevance-score family;
- a cross-engine pagination abstraction that pretends offset, cursor, PIT, and snapshot paging all mean the same thing;
- or a universal query planner/provenance product.

## Resulting recommendation
The next healthy move is not “design the search layer.”
It is to let Foundry say, for any future query-shaped value:
1. which **selection recipe** produced eligibility and ordering,
2. what **window cut** produced the currently visible rows,
3. and what **total mode** governs any count that sounds whole.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from PostgreSQL, GraphQL cursor pagination, Elasticsearch total-hit semantics, BigQuery query-result paging, and modern search systems that admit estimated totals.
