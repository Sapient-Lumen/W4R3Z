# Research synthesis — pass LXXVII

This pass goes deeper on a danger that usually arrives after a cube has its first useful query/result seam: the next reader asks for a parent row, a weekly rollup, a regional total, a dashboard drilldown, or a dimension picker, and the archive quietly treats a hierarchy as if it were automatically an aggregation law.

That is not safe.
SlopOS is still in design phase, and Foundry should not answer that uncertainty by freezing a universal dimension model, code-list ontology, fiscal calendar registry, geospatial engine, or semantic layer.

The low-regret move is to promote a very small seam: when a result rolls up, drills down, groups by a parent, traverses a code list, rounds into a calendar period, or claims a geographic/organizational parent, it should carry a **hierarchy scope**, a **rollup path**, and an **aggregation guard**.

Specimen 71 is therefore added.
It is a rollup-honesty seam, not a hierarchy ontology.

## Lessons we must learn from the past

### 1) Structure helps, but structure is not the rollup law
The RDF Data Cube vocabulary's Data Structure Definition is useful because it declares dimensions, attributes, measures, ordering, and required/optional attributes; that helps verification and consumption.
It also points toward reuse of concepts and code lists.

The Foundry lesson: DSD-like structure is necessary but insufficient.
A dimension can be present and coded without proving that child values sum to a parent, that a parent is exclusive, or that a slice is complete.

### 2) Controlled vocabularies are reusable bridges, not automatic arithmetic
SKOS is valuable because it gives low-cost machinery for concept schemes, labels, notations, informal hierarchies, associative networks, collections, and mappings.
SDMX content-oriented guidelines similarly push shared cross-domain concepts and code lists for interoperability.

The Foundry lesson: borrow code-list discipline, but never let `broader`, `narrower`, or a shared code become a summation rule by accident.

### 3) Valid combinations are different from totals
XBRL Dimensions is a useful old scar: it distinguishes dimensions, domain members, explicit/typed dimensions, valid combinations, hypercubes, and presentation ordering.
Especially important, the dimensions specification says explicit summations over dimension members were not satisfied there.

The Foundry lesson: a valid member combination, a presentation order, and a lawful aggregation are three different things.

### 4) Availability constraints prevent phantom coordinates
SDMX availability APIs and data constraints are excellent warnings.
They can expose which dimension values are available, which values remain valid under a current query, which codelists/concepts are referenced, and sometimes series/observation counts.

The Foundry lesson: an axis value being legal in a scheme does not mean it is populated for this cut, valid under this filter, or safe to present as an empty-but-real slice.

### 5) Calendar rollups are traps with nice names
Unicode LDML's week rules depend on first day of week and minimal days in the first week; changing those values can move a date into a different week-year.
BigQuery and PostgreSQL both expose ISO week/year behavior where ISO year can differ from Gregorian year near boundaries.

The Foundry lesson: `week`, `month`, `quarter`, `year`, `fiscal year`, and `reporting year` require a calendar lens, not a pleasant label.

### 6) Geography parents have cuts and kinds
The U.S. Census hierarchy diagrams explicitly describe relationships among legal, administrative, and statistical boundaries and also where relationships do not exist.
TIGER/Line releases pin boundaries and names to a date.
OGC DGGS shows a different spatial pattern: hierarchical grid zones with identifiers and deterministic sub-zone order.

The Foundry lesson: administrative parentage, statistical geography, legal boundary cuts, and DGGS cell containment are related but not interchangeable.
A grid parent is not a county, and a county cut is not timeless.

### 7) Storage partitioning is not dimension hierarchy
Apache Arrow's Hive partitioning parses directory keys such as `key=value`, can ignore field order, and can ignore missing or unrecognized field names.
That is useful storage/indexing machinery.

The Foundry lesson: file paths, partitions, chunk grids, table manifests, and directory layouts must not become semantic parentage or calendar/geography truth.

### 8) Slowly changing dimensions are not a nuisance; they are the point
dbt's dimension guidance around SCD Type II validity intervals is a reminder that descriptive context can change at coarser granularity than facts.

The Foundry lesson: a rollup needs to say which hierarchy version, member validity cut, and reparenting posture applied; otherwise historical totals become hindsight rewrites.

### 9) SlopOS hierarchy pressure is mostly negative space today
SlopOS already has attribute queries, view objects, boundary indexes, label-atom boundaries, trace-processing outputs, and security-time posture that reject ambient path grammars, wildcard hierarchies, portable calendar authority, and unbounded query surfaces.

Foundry should mirror that restraint: a rollup seam is useful because it lets SlopOS support cards and query exports carry hierarchy evidence without inventing a global SlopOS taxonomy, path language, or geography/calendar authority plane.

## Nifty ideas to steal without over-freezing

- **hierarchy scope** — a compact card for dimension family, scheme/version, member set, parent relation kind, default/unknown member posture, valid-combination basis, availability basis, and cut.
- **rollup path** — a compact witness for source grain, target level, exact path or closure used, calendar/geography lens, membership cut, recipe digest, and reparenting posture.
- **aggregation guard** — a compact refusal/permission surface for additive, semi-additive, non-additive, bridge-shaped, ratio-derived, distinct-count, weighted, allocated, approximate, or refused rollups.
- **calendar lens** — week start, min-days, timezone, fiscal start, ISO/Gregorian/reporting-year posture, and locale/calendar family kept explicit when time buckets appear.
- **geography lens** — administrative, statistical, legal-boundary, grid-cell, route/service-area, or presentation-region posture kept explicit.
- **availability basis** — the concrete constraint/query/cut that said which coordinates are populated, valid future choices, unavailable, suppressed, or unknown.
- **parent relation kind** — strict tree, DAG, overlapping set, ragged hierarchy, cross-cutting classification, containment grid, presentation order, or refused.
- **reparenting posture** — as-observed, as-of-cut, restated-current, bridged, split, merged, or refused.
- **default-member witness** — explicit residue when an omitted dimension value, default member, or not-applicable member was used.
- **storage-layout fence** — guardrail that Hive-style partitions, chunk grids, file paths, and manifests are not semantic parentage.

## What stays parked

- no universal hierarchy ontology;
- no single calendar/fiscal/calendar-locale registry;
- no single geography engine or grid system;
- no assumption that SKOS/SDMX/XBRL/DSD hierarchy means additive rollup;
- no treating code-list parentage, presentation order, default members, or availability constraints as totals;
- no automatic summation across hierarchy levels, bridge rows, distinct counts, ratios, sampled values, masks, bands, or policy-narrowed outputs;
- no treating physical partitions, chunks, manifests, folders, or file naming as cube dimensions;
- no treating current hierarchy membership as a valid restatement of historical facts without an explicit restatement lane.
