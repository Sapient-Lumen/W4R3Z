# Research synthesis — pass XXII

This pass keeps Foundry narrow and learns one more thing from grouped-update and repository-security systems: **a basis family can be the newest offered thing and still be smaller than the latest confirmed coherent thing.**

## Outside lessons
1. **systemd-sysupdate makes grouped basis pieces explicit.**  
   A kernel, root filesystem, and verity partition can be bound together by one common version identifier and treated as a single target. Foundry should steal the idea that some basis pieces want a coherence target before any larger deployment family exists.

2. **TUF separates “latest coherent metadata set” from loose file-by-file freshness folklore.**  
   The snapshot role records the latest version of all targets metadata and explicitly prevents mix-and-match attacks, while the timestamp role exists to prevent replay of out-of-date signed metadata. Foundry should collect a mixed-time guard instinct instead of assuming “new enough” means “coherent enough”.

3. **Uptane is explicit about not advancing over uncertain prior adoption.**  
   Its best-practices guide says the Director repository SHOULD NOT issue a new bundle that may conflict with images listed on the last confirmed vehicle version manifest, and SHOULD wait for confirmation before issuing a conflicting third bundle. Foundry should steal a confirmation fence and a supersession hold instead of telling one flattering story about “latest update”.

4. **Uptane also reminds us that retention and confirmation are part of truth maintenance.**  
   The same guide says previous known-good metadata should be retained, that images are wisely retained until Secondaries confirm installation, and that ECU version reports need not be rewritten every boot — only after successful verification and installation of a new image. Foundry should keep confirmation-shaped evidence smaller than activation and smaller than repository publication.

5. **RAUC shows a useful optional late-fallback kill switch.**  
   After `mark-good`, `prevent-late-fallback` can make the old slot ineligible for fallback. Foundry should note this as a good reminder that “prior known good” has its own lifecycle and may need an explicit retirement seam rather than magical permanent fallback.

6. **Omaha offers a useful cautionary steal for rollout metadata.**  
   Clients record `cohort`, `cohortname`, and `cohorthint` values from the server and report them later. That is a nice idea for rollout conversation, but Foundry should keep any such cohort hint outside basis truth unless a later specimen proves it belongs in the cube.

## Resulting Foundry move
Do not decide yet whether `coherence target`, `confirmation fence`, and `supersession hold` belong under artifact identity, live realization, or aftermath residue.
For now, keep them alive as specimen nouns and demand that they improve:
- one grouped-target specimen,
- one uncertain-prior-adoption specimen,
- and one explicit supersession-refusal specimen.

Also collect — but do not promote — one smaller adjacent idea for a later pass:
- **cohort hint** — rollout metadata that should stay visibly weaker than install authority or currentness.

## Fresh ideas worth stealing
- **coherence target** — grouped basis family that should move together.
- **confirmation fence** — explicit certainty boundary before a prior offer counts as settled current truth.
- **supersession hold** — block conflicting advance while confirmation is still missing.
- **prior-confirmed receipt** — evidence that opens the fence without pretending to be the whole verdict.
- **mixed-time guard** — protection against assembling one fake coherent moment from different metadata/resource moments.
- **cohort hint** — rollout/track signal kept outside install authority.
- **offered smaller than confirmed** — a standing anti-regrowth rule.
