
# Research synthesis — pass LXXXII

This pass goes deeper on a datacube failure mode that appears after grain, exactness, derivation, query envelopes, rollups, materialization, disclosure, observedness, and reconciliation have all been treated carefully: **category values drift**.

A datacube cell often carries a categorical dimension that looks harmless: boundary family, interface surface, origin class, outcome class, credential-presentation class, replication class, observation status, redaction reason, policy tier, support-card bucket, taxonomy member, or imported telemetry attribute. Those values feel stable because they are short strings or codes. But the string is not the meaning. The meaning lives in a code system, classification, value set, semantic-convention registry, local profile, label language, revision, and sometimes a mapping/correspondence table.

SlopOS is still design-phase. Its family names, profile matrices, trust/browser/credential terms, observation-export categories, redaction reasons, and support-card outcome classes will continue to change. Foundry should not freeze a taxonomy now. It should, however, prevent the worst early mistake: letting `code = same` or `label = same` become proof that old and new rows are comparable.

The low-regret move is small: whenever a result depends on a categorical member whose meaning could drift, carry a **classification pin**, a **crosswalk witness**, and a **code-drift fence**.

Specimen 76 is therefore added. It is a classification/version/mapping seam, not a universal taxonomy registry, SKOS/SDMX/FHIR adoption, semantic-layer ontology, or automatic backcasting engine.

## Lessons we must learn from the past

### 1) Code lists help only when their identity and version travel with the code
SDMX Content-Oriented Guidelines emphasize cross-domain concepts and code lists because common terms and code lists improve exchange and maintenance. The scar for Foundry is that the code list choice has a large impact on sharing. A bare code or display label is not enough; a cube result needs to name the classification/code-system/value-set/profile cut that made the code meaningful.

### 2) Lightweight concept systems are useful precisely because they do not overclaim
SKOS gives a low-cost way to model concept schemes, labels, notations, hierarchies, collections, and mappings. It is useful because it is not a heavy ontology. The scar for Foundry is that a concept scheme, label, or broader/narrower relation should not silently become a closed-world taxonomy, aggregation rule, or compatibility proof.

### 3) Mappings are directional, contextual, and often incomplete
FHIR ConceptMap is a strong precedent: mappings are one-way, cannot automatically be reversed, depend on business/use context, can have multiple targets, can be unmapped, and carry explicit relationship classes such as equivalent, broader, narrower, related, or not-related. Foundry should steal the posture, not the healthcare model: crosswalks are witnesses, not magic upgrades.

### 4) Correspondence tables compare classifications; they do not erase revision history
Eurostat's NACE correspondence-table docs are explicit: correspondence tables between versions describe detailed revision changes, and tables between different classifications show relationships between positions. Foundry should preserve the correspondence table or digest that enabled a comparison, but not claim the old and new classification are now identical.

### 5) Official classifications evolve because the world evolves
NAICS is revised on a five-year cadence to account for new, shrinking, or obsolete industries; revisions can combine or separate codes. Foundry's lesson is broader than industries: SlopOS category systems will undergo the same kind of split, merge, rename, and deprecation pressure. A code's text today is not a timeless concept identity.

### 6) Name reuse and removal are dangerous even in observability conventions
OpenTelemetry semantic-convention naming says names should not be reused across same-kind entities and renamed/no-longer-recommended items should be deprecated rather than removed. Foundry should steal that habit for SlopOS/Foundry local categories: deprecate and crosswalk; do not silently recycle a code or label.

### 7) A label is display, not identity
Labels can change for clarity, audience, locale, accessibility, or product polish. A display label should never be a join key, rollup parent, or comparability proof. A classification pin should separate stable code/member identity, preferred label, label language, label cut, and deprecation posture.

### 8) Same code can mean different things across schemes
`accept`, `deny`, `blocked`, `unknown`, `masked`, `credential`, `browser`, `profile`, or `RC3` may be local to one scheme. The code is meaningful only inside its namespace/scheme/version. A code-drift fence should refuse joins across schemes unless a crosswalk witness says what relationship was reviewed.

### 9) Crosswalk cardinality is the trap
Renames may be one-to-one and lossless. Splits, merges, many-to-many mappings, catch-all buckets, and local exclusions are not. A chart can be valid under old-classification lens, new-classification lens, side-by-side lens, or reviewed-backcast lens, but those are distinct outputs.

### 10) Design-phase SlopOS needs category humility now
Early support panels will almost certainly group by boundary family, profile class, capability class, outcome class, error class, credential/browser mediation class, redaction reason, and observation status before the names settle. If those rows escape as ordinary category strings, later cleanup will be indistinguishable from history rewrite.

## Nifty ideas to steal without over-freezing

- **classification pin** — compact residue for scheme/code-system/value-set/profile id, version/revision cut, namespace, member id, display label, label language, deprecation status, and owner/steward.
- **crosswalk witness** — compact residue for source pin, target pin, mapping/correspondence-table digest, mapping direction, context/use case, relation kind, cardinality, coverage, reviewer/run, and not-mapped reason.
- **code-drift fence** — compact guardrail for whether a row may be compared, grouped, backcast, relabeled, joined, exported, rolled up, or shown only under an old lens.
- **same-code-not-same-concept rule** — default refusal to join on a bare code when scheme/version/pin differs.
- **label-not-key rule** — display text is never the semantic key.
- **deprecated-code lane** — keep old members readable and queryable without letting them become current defaults.
- **split/merge cardinality class** — one-to-one rename, one-to-many split, many-to-one merge, many-to-many correspondence, unmapped, or local-only.
- **old-lens display** — allow historical rows to stay legible under their native classification instead of forcing newest labels.
- **reviewed-backcast lane** — allow a derived series to project old rows into a new classification only with an explicit crosswalk witness and fence.
- **unknown-code pocket** — imported or legacy codes that are syntactically present but semantically unresolved are not null, zero, failure, or current-member truth.

## What stays parked

- no universal taxonomy registry;
- no permanent Foundry code-list ontology;
- no mandatory SKOS, SDMX, FHIR, OTel, or ISO classification substrate;
- no automatic backcasting/reclassification engine;
- no claim that every local SlopOS category needs a globally unique URI now;
- no treating `latest label` as semantic truth;
- no label-based joins;
- no assumption that correspondence tables are reversible;
- no treating broader/narrower or parent code as aggregation law;
- no forcing early SlopOS design names to become durable archive law;
- no deleting old category members just because a cleaner current vocabulary exists.
