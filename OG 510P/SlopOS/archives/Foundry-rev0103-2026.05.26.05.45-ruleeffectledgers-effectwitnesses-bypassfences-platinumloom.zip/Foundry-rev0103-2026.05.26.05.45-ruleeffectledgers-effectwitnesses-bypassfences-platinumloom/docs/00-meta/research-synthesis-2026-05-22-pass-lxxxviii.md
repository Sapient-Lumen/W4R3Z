# Research synthesis — 2026-05-22 pass LXXXVIII

Focus: **delegation warrants, reliance receipts, and transitive-use fences**.

The previous pass made cross-consumer interpretation explicit. This pass covers the next scar: a consumer can delegate a narrow semantic act to a worker, notebook, queue, or sibling input process, and downstream readers can mistake that delegated act for permission, approval, verdict, source truth, or reusable authority.

## New outside pressure

- `EXT-RFC8693-TOKEN-EXCHANGE` distinguishes delegation/actor history from top-level validity. Its `act` claim can show that delegation occurred and who the current actor is; nested actors form history, but prior actors are informational for access-control decisions. Foundry should steal the actor-chain humility without becoming a token-exchange system.
- `EXT-W3C-VC-DM-2-2025` separates issuers, holders, verifiers, claims, presentations, and selective disclosure. Foundry should steal the idea that a presentation is for a specific verifier and purpose without becoming a credential wallet or proof suite.
- `EXT-RFC9334-RATS-ARCH` separates Attesters, Verifiers, Relying Parties, Evidence, Attestation Results, appraisal policies, and freshness. Foundry should steal the relying-party posture: a carried result is still checked by the relying party's own policy and freshness needs.
- Existing rev0087 consumer passports and portability witnesses still apply; delegation must not bypass them.

## What rev0087 still allowed

Rev0087 could prove a target consumer had a passport and gate. It did not yet prove that an intermediate actor was allowed to prepare, transform, or carry residue for that consumer. A future editor could still:

- let a delegated export worker produce a review packet without saying who granted that act;
- treat a portability witness as if it were a delegation warrant;
- let a Ward queue read a worker-prepared packet as a Ward verdict;
- let an external notebook redelegate a review packet to a research notebook;
- let a revoked or expired delegation continue because the sidecar digest is unchanged;
- use withheld residue such as operator hints, waiver-as-approval, or sibling authority as if delegated; or
- lose the actor chain while preserving the output artifact.

Those are delegation-boundary failures, not ordinary portability failures.

## Speculative read

Foundry needs a small **delegated reliance seam** beside portability:

```text
delegation warrant    = who granted which semantic act to which delegate for which relying consumer and scope
reliance receipt      = which warrant was checked, what was relied upon, and what inferences were refused
transitive-use fence  = where the delegation chain stops unless a new warrant exists
verdict / permission  = still outside Foundry
```

The negative move matters most: a warrant is not a permission token. It is a local witness that semantic evidence handling stayed bounded.

## New specimen pressure

Add specimen 82 around delegation warrants, reliance receipts, and transitive-use fences. The fixture must prove at least:

- every delegated act names grantor consumer, delegate consumer, relying consumer, artifacts, scope, expiry, and revocation status;
- permitted semantic acts and forbidden semantic acts are both explicit;
- delegated residue and withheld residue are both explicit;
- relying consumers emit reliance receipts before using delegated output;
- receipts preserve actor-chain trace, checked rules, preserved residue, and refused inferences;
- transitive delegation, audience widening, purpose widening, sibling-authority transfer, and verdict transfer fail; and
- expired, revoked, self-issued, unscoped, or passport-mismatched warrants cannot produce allowed reliance.

## Recommendation

Keep delegation warrants fixture-local and reversible. Do not promote a permission system, OAuth profile, VC profile, attestation protocol, trust framework, policy handoff, legal-agency model, or audit workflow. The narrow Foundry job is to prove when a consumer-authorized semantic act was bounded, recorded, and stopped before it became portable authority.
