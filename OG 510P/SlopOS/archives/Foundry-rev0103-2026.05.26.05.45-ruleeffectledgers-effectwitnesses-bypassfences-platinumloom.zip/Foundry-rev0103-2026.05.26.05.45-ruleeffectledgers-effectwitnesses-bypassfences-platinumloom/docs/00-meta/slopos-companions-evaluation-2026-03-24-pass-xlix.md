# SlopOS plus companions evaluation — pass XLIX

This pass adds one more datacube warning:
Foundry should model **how exact a value is, what bound or ranking witness explains it, and whether correction is still expected** before it lets every count, score, or query result become cube truth.

## SlopOS
SlopOS already contains strong pressure in this direction.

`attrfs-posture-v0.md` says view-scoped smart queries are **snapshot-first** and explicitly rejects regex/full-text ranking as Phase 1 meaning.
That means a query count or result set is a cut-relative observation, not an eternal exhaustive inventory fact.

`cpu-capacity-authority-boundary-v0.md` says asymmetric CPU-capacity facts and any SKB-derived rank labels are **placement hints only**.
So a rank or score may be useful without becoming correctness-bearing authority.

`attention-durable-interrupt-boundary-v0.md` says urgent notification importance is **advisory hint only**.
Again, valuable output, but visibly smaller than a lease, durable grant, or native state transition.

The mechanism docs also keep inspect surfaces and snapshot bundles as snapshots/captures rather than universal current-state truth.
Together these pressures say the same thing: SlopOS already knows that not every number-like or list-like output should be treated as exact ambient inventory truth.

So for a future Foundry datacube over SlopOS surfaces:
- snapshot query counts should not silently become exhaustive totals;
- advisory rank labels should not silently become category truth;
- approximation/sketch outputs should not silently become denominators;
- and late archive corrections should not be mistaken for corruption when the correction horizon was never closed.

## Ward, Harbor, and ViewFS
Ward already keeps appraisal and read surfaces smaller than the world they summarize, which is good nearby pressure for estimate humility.
Harbor keeps convenience labels and presentation surfaces smaller than durable issuer/account/session truth.
ViewFS keeps summary and object-lineage stories visibly scoped rather than magically totalizing.
Together they reinforce the same lesson: useful outputs may still be cut-relative, approximate, or advisory.

## Resulting judgment
Promote only the following small seam in this revision:
1. **exactness class** — what kind of value this is;
2. **bound witness** — why a non-exact or rank-shaped value is still interpretable;
3. **correction horizon** — how provisional/restatable the value still is.

Keep parked for now:
- any global uncertainty plane;
- automatic sketch/result promotion rules;
- forecast/simulation semantics;
- or a universal ranking ontology.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the datacube a safer path to future snapshot counts, advisory scores, sketch-backed distincts, and corrected summaries without premature semantic freeze.
