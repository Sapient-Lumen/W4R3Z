# SlopOS and companions evaluation — 2026-05-25 pass XCV

Focus: whether Foundry can prove that acknowledged semantic obligations were actually fulfilled without claiming workflow completion, authorization, legal compliance, audit opinion, deletion, retention, custody, repair, or sibling authority.

## SlopOS pressure

SlopOS support surfaces now carry egress sidecars, refusal receipts, regression locks, waivers, consumer passports, delegation boundaries, recall/readmission paths, distribution/adoption receipts, surface inventory, exposure ledgers, and obligation acknowledgments. Rev0095 asks the next question: after a consumer says it accepted the obligations, did the consumer actually perform the semantic work before reuse?

A SlopOS support dashboard can acknowledge sidecar, classification-pin, observation-status, recall-route, and no-reexport obligations. Foundry must still check whether the render carried the sidecar ref, the status badge displayed, the recall contact was reachable, the no-reexport boundary blocked forks, and any recheck-before-reuse happened before execution. An external-audit CSV can acknowledge a no-reexport duty without proving the notebook did not fork. A Ward preview can acknowledge the "not Ward verdict" boundary without preventing a later appraisal shortcut. A ViewFS projection can acknowledge quarantine while still exposing the projection. A delegated worker can acknowledge recheck-before-execute but execute first and recheck later.

## Companion boundaries

| Companion | Fulfillment-accounting interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may seed obligations whose discharge must be witnessed before support reuse | SlopOS still owns proof claims, operator policy, and runtime consequence |
| Harbor | may receive nonfulfillment fences for recall route, outside-status, or public-link failures | Harbor still owns external correction, membrane status, and remediation verification |
| Ward | may receive completed or fenced boundary-preservation evidence | Ward still owns appraisal and trust verdicts |
| Steward | may schedule rechecks and lifecycle retries from nonfulfillment fences | Steward still owns retry budgets, finality, and lifecycle authority |
| Schell | may constrain how much fulfillment evidence can be retained | Schell still owns minimization, forgetting, and privacy authority |
| ViewFS | may expose projection/quarantine fulfillment evidence | ViewFS still owns object identity, consent fences, and custody |
| Helm | may consume missed-fulfillment fences as repair inputs | Helm still owns repair custody and handback consequence |
| External audit notebook | may show completed sidecar/recall/no-reexport fulfillment | completion evidence is not audit opinion or certification |
| Dashboard cache | may prove display obligations were fulfilled in a render | fulfillment is not cache policy, IAM, or release approval |
| Delegated worker | may prove recheck-before-execute timing | timing evidence is not Steward finality or execution permission |
| Public-link scanner | may show obligations cannot be fulfilled for anonymous readers | public reachability is not fulfillment, consent, or public release |

## What changed in this pass

- Added specimen 89 for fulfillment receipts, completion witnesses, and nonfulfillment fences.
- Added a fulfillment accounting rulebook so acknowledgment-vs-completion gaps have named failure modes.
- Added v0 schemas for fulfillment receipts, completion witnesses, and nonfulfillment fences.
- Added a specimen 89 fixture with complete, partial, and blocked fulfillment receipts; completed, partial, pending, missed, refused, and quarantined completion witnesses; and nonfulfillment fences for missing recall-route probes, no-reexport leakage, recheck-after-execute, quarantine failure, digest mismatch, public-link failure, and sibling-boundary laundering.
- Added `check_foundry_fulfillment_accounting.py` and wired it into `make check`.
- Reused Kubernetes finalizer, PROV activity/entity/agent, XACML obligation/advice, and ODRL duty pressure while keeping Foundry smaller than cleanup controllers, workflow engines, authorization systems, rights engines, legal compliance, audit, deletion, retention, custody, repair, or sibling-verdict infrastructure.

## Recommendation

Future Foundry revisions should treat acknowledgment as necessary input to fulfillment accounting, not as closure. A surface is not safe to reuse merely because the consumer accepted semantic obligations; each required action must leave completion evidence or a nonfulfillment fence that blocks reuse until replay and clearance evidence exists.
