# Research synthesis — pass XIX

This pass keeps Foundry narrow and learns one more thing from extension-image systems: **configuration overlays deserve a compatibility check of their own, and they should stay visibly different from base image or runtime cargo**.

## Outside lessons
1. **systemd distinguishes system extensions from configuration extensions.**  
   sysext images extend `/usr`, while confext images extend `/etc`. Foundry should steal the discipline that code/runtime layers and configuration layers are neighboring but non-identical facts.

2. **Compatibility metadata gates the merge.**  
   systemd expects extension images to carry an `extension-release` file whose metadata matches the base image or host. This is explicitly about ABI/API compatibility and preventing incompatible overlay merges.

3. **Naming and placement matter.**  
   sysext and confext use different release-file locations and image names that must match. Foundry should preserve that a foreign layer is not just bytes; it arrives with placement and compatibility posture.

4. **The uploaded cube ecology wants this separation.**  
   SlopOS, ViewFS, and Steward repeatedly separate object identity, activation, and aftermath. Foundry can therefore add config-layer truth without pretending a config overlay is the same thing as a base runtime image.

## Resulting Foundry move
Do not decide yet whether the durable nouns are `config layer`, `compat witness`, `overlay gate`, and `detach path`, or whether one later compresses behind a smaller extension family.
For now, keep them alive as specimen nouns and demand that they improve:
- one compatible config overlay specimen,
- one mismatch refusal specimen,
- and one detach/rollback specimen.

## Fresh ideas worth stealing
- **config layer** — foreign configuration surface kept distinct from runtime/base cargo.
- **compat witness** — small object summarizing why an overlay may merge.
- **overlay gate** — typed refusal when compatibility is insufficient.
- **detach path** — explicit rollback/removal surface for a foreign layer.
