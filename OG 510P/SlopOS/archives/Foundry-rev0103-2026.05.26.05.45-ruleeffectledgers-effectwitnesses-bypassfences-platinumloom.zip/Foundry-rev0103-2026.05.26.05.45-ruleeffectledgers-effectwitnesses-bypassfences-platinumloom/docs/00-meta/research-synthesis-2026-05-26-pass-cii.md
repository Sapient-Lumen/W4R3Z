# Research synthesis — 2026-05-26 pass CII

This pass investigates the seam after promoted-rule collision: a precedence witness can identify a winning rule, but it cannot prove that the rule was applicable to a particular carrier, consumer, audience, purpose, or checker context.

## Outside pressure

- Open Policy Agent decision logs keep policy query events tied to queried policy, input, bundle metadata, and offline debugging posture. Foundry steals the query/input/result residue instinct while refusing policy-engine scope.
- SHACL validation results keep focus-node, path, value, source shape, severity, and message residue. Foundry steals the result-local evidence posture while refusing to become an RDF validator or source-truth judge.
- OpenFeature separates evaluation context from evaluation details, including reason/error/default-like outcomes. Foundry steals the context/result split while refusing feature-flag infrastructure.
- Cedar validation requires application schema knowledge for entity/action/context checks. Foundry steals schema-bound applicability caution while refusing authorization decisions.

## Foundry move

Promote specimen 96 locally: rule-evaluation trace, applicability witness, and misapplication fence. Keep the shape fixture-local until a second non-SlopOS consumer needs the same application residue.

## Non-goals

Do not build a rule engine, policy language, authorization evaluator, feature-flag system, SHACL processor, OPA server, Cedar runtime, admission controller, governance registry, audit product, public-release approval system, repair workflow, lifecycle authority, or sibling verdict system.
