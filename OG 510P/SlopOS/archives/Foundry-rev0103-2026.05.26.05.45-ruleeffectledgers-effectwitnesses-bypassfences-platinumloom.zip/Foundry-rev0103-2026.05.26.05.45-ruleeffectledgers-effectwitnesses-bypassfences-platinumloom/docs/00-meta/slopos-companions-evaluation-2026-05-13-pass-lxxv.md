# SlopOS + companions evaluation — pass LXXV

This pass evaluates SlopOS's current browser-identity and credential pressure against Foundry's datacube posture.

## Verdict

Not yet.
The new pressure is useful, but the right Foundry move is still to **collect brilliant ideas without promoting them too early**.

SlopOS rev0695 and rev0694 both reinforce the same rule:
- FedCM and browser Login Status belong in a provider-local browser-mediation boundary.
- Digital Credentials belong in a provider-local browser-wallet/presentation boundary.
- OpenID Federation trust chains and Trust Marks are discovery/bootstrap/conformance evidence, not durable native truth.

That means Foundry should add parked candidate seams, not specimen 70.

## What SlopOS keeps teaching now

### 1) Browser import boundaries should be narrow
SlopOS rev0695 correctly refuses to treat FedCM as a portable account chooser, current-user oracle, connected-account inventory, disconnect control plane, browser-session substrate, approval-basis receipt, or durable account/session truth.
For Foundry, that means browser-mediated identity rows must enter as scoped evidence or hints, not as native person/account/session facts.

### 2) Credential presentation is not wallet truth
SlopOS rev0694 correctly refuses to turn Digital Credentials API mediation into wallet inventory, current-user truth, approval basis, connected-device truth, or durable session truth.
For Foundry, a credential presentation may be an observation with request, response, issuer, verifier, disclosed claim, proof, and verification posture — but only if the grain is explicit and opaque parts stay opaque.

### 3) Trust bootstrap must not become trust folklore
SlopOS's OpenID Federation boundary treats entity statements, trust chains, metadata policies, Trust Marks, authority hints, resolver outputs, and endpoints as provider-local discovery/cache/conformance/trust-bootstrap evidence.
For Foundry, the stealable shape is a scoped **trust-chain witness** and **trust-mark witness**, not a universal trust registry.

### 4) Design-phase SlopOS makes premature ontology extra dangerous
Because SlopOS is still designing its boundaries, Foundry should not bake one identity, credential, or trust ontology based on the current browser API wave.
The healthy move is a parked lane plus review triggers.

## What the companions add

### Harbor
Harbor keeps insisting on temporal witnesses, contract subsets, and lineage guards.
For this pass, that means any identity/credential/trust row needs a cut, actor/path posture, and derivation witness before it can inform a durable report.

### Ward
Ward keeps raw evidence and appraised summaries distinct.
That is exactly the right posture for FedCM account lists, Login Status hints, credential presentations, and trust marks: keep imported browser/provider evidence smaller than local appraisal.

### ViewFS
ViewFS keeps frozen manifests, handles, previews, and durable receipts apart.
Foundry should mirror that split by keeping config discovery, account hints, trust-chain material, and verification receipts distinct instead of bundling them into one identity object.

### Steward
Steward keeps request state, live state, approval basis, and mutable-basis review separate.
That directly supports the pass LXXV warning: a browser prompt, request object, login status, or presentation ceremony is not automatically durable approval or live truth.

### Schell and Helm
Schell and Helm keep humane helper/overlay surfaces smaller than durable substrate semantics.
Foundry should borrow their UI humility: an account chooser, wallet chooser, or badge display is a surface over narrower evidence, not a fact family by itself.

## Parked candidate seams

### browser mediation lane / identity hint fence / prompt-basis witness
Candidate use:
- FedCM request and provider config lanes;
- Login Status hints;
- account chooser affordances;
- `loginHint` / `domainHint` / provider-local account labels;
- prompt/user-activation evidence.

Refusals:
- no current-user oracle;
- no browser-session truth;
- no portable account registry;
- no universal consent/approval basis.

### trust-chain witness / trust-mark witness / issuer-suitability fence
Candidate use:
- OpenID Federation entity statements, trust chains, trust anchors, metadata policies, and Trust Marks;
- Digital Credentials issuer verification and verifier policy;
- scoped conformance badges and federation-local marks.

Refusals:
- no global trust score;
- no issuer suitability without local policy;
- no trust mark outside its scope, federation, mark definition, and time/cut.

### credential-presentation opacity fence / verification-result witness
Candidate use:
- encrypted/opaque wallet responses;
- selective disclosure and ZKP-shaped presentation paths;
- verifier-side signature/issuer checks;
- cross-device mediated presentations.

Refusals:
- no wallet inventory;
- no all-claims visibility;
- no unlinkability guarantee just because the browser cannot inspect the response;
- no credential truth without verifying issuer, signature, audience, nonce, freshness, and purpose.

## Recommended Foundry posture right now

1. **Do not add specimen 70 yet.**
   This is a consolidation pass while SlopOS is still in design phase.

2. **Add the candidate seams to ledgers and research, not to architecture law.**
   Keep them discoverable, reviewable, and explicitly parked.

3. **Require one real SlopOS flow before promotion.**
   Good pressure tests would be:
   - one FedCM import/export/support tile that wants account/login hints but must not become account truth;
   - one Digital Credentials presentation that has opaque response posture and issuer-suitability policy;
   - one OpenID Federation trust-chain/Trust-Mark path that must be replayed without becoming global trust.

4. **Keep cube hygiene strict.**
   Every moving or development-stage source must stay in the review queue, and every new candidate seam must be linked through assumptions, questions, followthrough, lessons, and inspirations before any irreversible decision.

## Low-regret next step

Pressure-test these parked identity/credential/trust seams against one concrete SlopOS browser-mediated flow and one companion-cube evidence/appraisal surface.
Only after those two consumers converge should Foundry consider a new specimen.
