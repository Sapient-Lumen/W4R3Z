# Research synthesis — pass XXIV

This pass keeps Foundry narrow and learns one more thing from update ecosystems: **what a server or issuer offers is still smaller than what a local subject is willing or allowed to take right now.**

## Outside lessons
1. **Cincinnati and Zincati treat server output as update hints, not destiny.**  
   Cincinnati describes itself as a protocol to provide update hints, and Zincati says a client that discovers a valid update edge may or may not decide to apply it locally based on configuration and heuristic. Foundry should steal that humility directly.

2. **Phased rollout timing is not the same as local admissibility.**  
   Zincati says there is no strict guarantee on when an individual node detects a new release because rollout is spread over a controlled timeframe, and it lets clients send a `rollout_wariness` hint. Offer timing is therefore a policy surface, not a current-basis fact.

3. **Maintenance windows are real meaning, not implementation noise.**  
   Zincati’s periodic strategy stages updates and then holds them until the next maintenance/reboot window. That means “available” and “allowed to finalize now” are different truths.

4. **Mender keeps local pause/resume semantics explicit.**  
   The device-side API lets a local application pause, resume, or cancel specific update states, with explicit priorities and expiry/refresh behavior. Foundry should learn that local hold state is not an error condition and not the same as “no update exists”.

5. **Omaha keeps update availability and cohort metadata smaller than installation truth.**  
   Omaha’s update check answers whether an update is available right now, including `ok` and `noupdate`, while cohort/cohorthint/cohortname remain channel-like metadata that can be reported even on no-update responses. Foundry should continue to park cohort semantics outside basis truth.

6. **Freshness and anti-freeze checks still matter before any offer deserves trust.**  
   TUF requires rollback and freeze checks on trusted metadata before proceeding, so even a well-shaped offer remains too small if its freshness or continuity story has decayed. This suggests a future seam, but not yet a promoted family.

## Resulting Foundry move
Do not decide yet whether `offer hint`, `local hold`, and `admission window` belong under live realization, continuity evidence, or a still-smaller operational sideband.
For now, keep them alive as specimen nouns and demand that they improve:
- one phased-rollout hinted-edge specimen,
- one maintenance-window or cluster-lock specimen,
- and one local pause/resume specimen.

Also keep two adjacent ideas parked rather than promoted:
- **hold reason chip** — a compact explanation of why a local hold exists right now;
- **offer freshness horizon** — a compact note about when an offer or its metadata stops being admissible.

## Fresh ideas worth stealing
- **offer hint** — issuer/server statement that an exact basis or transition is available now.
- **local hold** — explicit local defer/pause/freeze state that blocks uptake or finalization for now.
- **admission window** — bounded condition or time slice when a held offer may proceed.
- **hold reason chip** — future explanation surface for why a hold exists.
- **offered smaller than admissible rule** — a standing anti-regrowth rule.
