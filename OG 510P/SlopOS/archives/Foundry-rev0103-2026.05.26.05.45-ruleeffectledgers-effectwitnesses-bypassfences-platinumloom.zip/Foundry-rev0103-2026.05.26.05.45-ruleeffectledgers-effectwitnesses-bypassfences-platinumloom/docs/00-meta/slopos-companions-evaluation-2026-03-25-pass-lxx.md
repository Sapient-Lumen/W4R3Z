# SlopOS + companions evaluation — pass LXX

This pass checks whether **assertion class, confidence basis, and verdict fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant trust-score plane, one archive-wide verified/unverified boolean, or a permanent confidence algebra.

## Why SlopOS pressures this seam now

### 1) SlopOS already distinguishes claims from non-claims
The assurance docs, claim registry, and non-claims posture already make a core separation: some rows are positive claims, some are explicit exclusions, and some are still design-phase imports or local observations.
That is direct **assertion class** pressure.
A future cube should not flatten those into one generic “fact” family.

### 2) Imported identity/profile material is useful before it is authoritative
`docs/30-architecture/mcp-userinfo-import-boundary-v0.md` keeps imported userinfo/profile/email material smaller than durable subject truth.
That means imported rows may still deserve display, review, or scoring while remaining different from native observations.
That is exactly why Foundry needs an explicit **assertion class**.

### 3) Verification summaries are real, but they stay family-local
`docs/40-verification/worker-pool-verdict-summary-v0.md` deliberately pins one exact local meaning for one verdict summary and refuses to generalize it into a universal result service.
That is direct **verdict fence** pressure.
A compact verdict can be helpful without becoming archive ontology.

### 4) Policy-local approvals and trust decisions should stay smaller than source truth
Several auth-mediation and trust-policy boundary docs keep local evaluation, exact-match validation, or client-trust posture visibly separate from durable identity/account truth.
That means a future cube may carry “accepted locally,” “exact match passed,” or “trust policy allowed” rows that must remain policy-local verdicts rather than native truths.

### 5) Quarantine, origin, and evidence hooks invite heuristic scores and warnings
The quarantine/origin/evidence families will eventually pressure the cube toward rows like reputation score, suspicion hint, or safe-open recommendation.
Those can be useful without being equivalent to a source claim or a hard validation failure.
That is strong **confidence basis** and **verdict fence** pressure.

### 6) Companions reinforce the same caution
Ward, Harbor, Helm, and Steward all contain approval-, evidence-, or health-shaped surfaces where local status can be useful while still remaining smaller than the subject itself.
Together they say the same thing: neighboring archives want compact verdicts and scores, but they do not justify a universal trust plane.

## SlopOS-side recommendation
If a future SlopOS-adjacent cube needs compact claim or validation summaries, Foundry should let the row say:
- **what kind of assertion it is,**
- **what its confidence/severity/score basis means,**
- and **where that outcome must not be mistaken for source truth.**

That is enough to keep design-phase imports, validations, and policy-local outcomes honest without freezing a giant trust subsystem into the cube.
