# Research synthesis — pass XXXI

This pass keeps the next seam deliberately narrow: **intent generation / observed generation / stale-status fence**.
The outside systems keep repeating the same lesson in different clothes: a new desired change can already be real while status, readiness, or “applied” surfaces still belong to an older desired state.
Foundry should preserve that seam without importing a universal reconciliation engine, rollout controller, or async task framework.

## Primary lessons from the outside

### 1) Desired change and status catch-up are different facts
Kubernetes now documents this unusually clearly for Pods.
A mutable spec change increments `metadata.generation`, while `status.observedGeneration` reflects the generation that the kubelet is actually reporting status for.
The same document goes further and warns that different status fields may reflect either the current sync loop or the previous one, depending on whether the status is a direct reflection of the spec or an indirect result of running work.
That is the pattern to steal: a new desired state and the status that has caught up to it are different truths.

The `cli-utils` kstatus guidance turns that into a practical operator rule.
If `generation` and `observedGeneration` do not match, there are changes the controller has not yet seen and therefore has not yet acted upon.
So Foundry should keep a **stale-status fence** available whenever old green status could otherwise be misread as a verdict on a newer intent.

### 2) “Last successfully applied” is a smaller claim than global success
Envoy’s xDS protocol says the client reports the last version successfully applied together with the nonce from the management server.
That gives the client and server a shared notion of the currently applied configuration.
But the same document also says an ACK only means the resources were considered valid when evaluated in isolation.
That is a beautiful discipline to steal.
A surface can truthfully say which desired/config generation it has applied without pretending that every downstream effect is now semantically settled.

### 3) Admission/acceptance is still smaller than completion
RFC 9110 keeps the old lesson sharp.
HTTP `202 Accepted` means a request has been accepted for processing, but processing is not completed, might never be acted upon, and HTTP itself provides no facility for a later asynchronous status code.
The response ought to point to a status monitor instead.
That matches the same seam from another side: acceptance is real, but it is not yet the same thing as observed, applied, or completed current truth.

## SlopOS/companion pressure
The uploaded SlopOS archive already carries exactly the instincts Foundry needs here.
`acp-acceptance-completion-posture-v0.md` says accepted requests and CH-ACPOUT receipts do not prove downstream completion or current provider-owned live state.
`approval-basis-posture-v0.md` says review must bind exact mutable basis rather than silently follow a moving head.
Those two moves together create the pressure for a smaller public seam: one fact for the new desired basis/request, one fact for what status has actually caught up to, and one guard against stale green status.

Helm and ViewFS reinforce the same shape from adjacent lanes.
Helm keeps request/admission/history separate from current live state.
ViewFS keeps apply sessions and receipts separate from a durable reconstructed target.
So Foundry should collect the shared lesson without swallowing those cubes’ whole control planes.

## Candidate nouns worth collecting
- **intent generation** — explicit generation or version step representing one newer desired basis, spec, or requested state.
- **observed generation** — the latest intent generation that a controller, agent, or status producer has actually seen and reflected.
- **stale-status fence** — explicit refusal to treat status, readiness, or settlement claims as current when they still belong to an older observed generation.

## Things to keep parked
- a universal reconciliation state machine;
- a generic async task/completion bus;
- any claim that green/ready/applied automatically refers to the newest desired state unless the generation match is explicit;
- any attempt to flatten acceptance, application, and completion into one triumphant status token.

## Provisional judgment
Promote only the seam, not the machinery.
Foundry should be able to say that a new **intent generation** exists, that status currently reflects only **observed generation** N rather than N+1, and that a **stale-status fence** blocks old success surfaces from masquerading as current truth.
That is especially valuable while SlopOS is still plastic enough to keep request admission, basis drift, reconciliation, and downstream completion on honest separate seams.
