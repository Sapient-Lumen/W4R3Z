# Research synthesis — pass LXXV

This pass stays conservative on purpose.
SlopOS itself is still in design phase, and the newest pressure around browser-mediated identity, digital credentials, trust chains, and classic cube modeling does **not** justify a large Foundry ontology move.

The important move is smaller: Foundry should collect the lessons, add stronger parked seams, and refuse to confuse a browser-mediated interaction, a trust bootstrap, a credential presentation, or a served cube view with durable archive truth.

This pass deliberately does **not** add specimen 70.
The pressure is real, but the safest move today is still to preserve optionality, keep repo hygiene current, and wait for one concrete SlopOS consumer plus one sibling-cube consumer before promoting another noun family.

## Lessons we must learn from the past

### 1) Declare the grain before admiring the dimensions
Classic dimensional modeling treats grain as the binding contract: one fact row must say exactly what it represents before dimensions or facts are chosen.
Foundry should keep stealing that posture.
A SlopOS datacube that starts with pretty axes before it knows whether one row is a browser request, a credential presentation, a provider account hint, a family coverage summary, or a pinned replay cut will drift immediately.

### 2) Observations need dimensions, measures, attributes, and slices — but not every useful grouping deserves promotion
The W3C RDF Data Cube vocabulary separates dimensions, measures, attributes, data-structure definitions, and slices.
The lesson is not that Foundry should become RDF Data Cube.
The lesson is that an observation family needs enough declared structure to be checkable, and slices are useful presentation/discovery groupings precisely because they are smaller than the underlying observation world.

### 3) The old cube lessons were already about guidance, well-formedness, hierarchy, rollup, preprocessing, and discovery
The W3C data-cube lessons note recurring pain around slice management, hierarchy representation, rollup/slice/dice guidance, transparent preprocessing, well-formedness checks, conversions, efficient processing, and discovery.
Foundry should treat that as a warning against inventing one magical datacube noun.
The cube will need process surfaces and witnesses, not just a taxonomy.

### 4) Browser mediation is not durable identity truth
FedCM is a browser-mediated federated sign-in API, and SlopOS rev0695 correctly imported it as provider-local browser sign-in mediation only.
A user gesture, browser account chooser, provider `loginHint`, `domainHint`, connected-account list, or disconnect dance may be useful evidence for one flow, but none of it is a portable current-user oracle, durable account registry, or archive-wide identity plane.

### 5) Login status is a hint, not a server-state oracle
The Login Status API pressure is especially tempting because it gives a browser-visible logged-in/logged-out/unknown style map.
Foundry should keep that as an **identity hint** lane at most.
It must not become native session truth, current provider truth, or a global fact table about people.

### 6) Prompt, activation, policy consent, and approval basis are separate
FedCM and Digital Credentials both involve browser/user-agent mediation and user activation or permission UX.
That does not make every prompt a durable approval basis, legal consent receipt, or future-use license.
SlopOS already makes this split in its import boundaries; Foundry should preserve the same separation for datacube rows.

### 7) Trust chains and trust marks are scoped bootstrap evidence, not global trust
OpenID Federation gives useful language for trust anchors, trust chains, entity statements, metadata policies, and Trust Marks.
The lesson to steal is the **witness shape**, not a global trust ontology.
A Trust Mark or resolved chain can say why a relying party chose to interact with a provider under a particular federation policy; it does not certify every future use, every claim, or every archive consumer.

### 8) Opaque credential responses protect privacy while limiting what the mediator can know
The Digital Credentials API intentionally lets user agents mediate credential presentation while responses may be encrypted or opaque to the user agent.
That is a good privacy design and a datacube warning: the observer may know a request happened and later verify a response, but not automatically know wallet inventory, all presented attributes, issuer suitability, or unlinkability.

### 9) Lineage facets and table snapshots are useful because they stay smaller than truth
OpenLineage-style jobs/runs/datasets/facets and Iceberg-style metadata/snapshots/manifests are still worth stealing, but only as witnesses.
A derivation run, a schema facet, a snapshot reference, or a manifest list should help replay and audit a result; it should not quietly become the result's semantic meaning.

## Nifty ideas to steal without freezing the cube

- **browser mediation lane** — a parked lane for FedCM/Digital-Credentials-style flows where the browser/user agent mediates a request or chooser but does not become the archive's identity authority.
- **identity hint fence** — a parked guardrail for login hints, domain hints, account labels, login-status values, and chooser affordances that are useful but weaker than current account/session truth.
- **origin-pair cut** — a compact reminder that many browser identity APIs are scoped to a relying-party/provider relationship, not a global multi-hop identity graph.
- **prompt-basis witness** — a small record of what prompt/activation/permission UX occurred, explicitly smaller than legal consent, policy approval, or future authorization.
- **disconnect choreography witness** — a parked witness for provider-local unlink/disconnect flows that does not pretend to revoke every related account/session/credential relation.
- **trust-chain witness** — a parked replay breadcrumb for the exact entity statements, trust anchor, resolver behavior, metadata policy, and resulting relationship used for one decision.
- **trust-mark witness** — a parked badge-shaped witness that stays scoped to issuer, mark, federation, and time/cut rather than becoming global trust.
- **credential-presentation opacity fence** — a guardrail for encrypted/opaque wallet responses, selective disclosure, and zero-knowledge-shaped presentations where the mediator cannot be treated as an omniscient observer.
- **issuer-suitability check** — a parked followthrough habit: signatures prove authenticity, but the consuming system still has to decide whether this issuer is suitable for this purpose.
- **well-formedness witness** — steal from RDF Data Cube and validation practice: every promoted family should have a lightweight, checkable structure before it gets ceremony.
- **grain card before family promotion** — steal from Kimball: every candidate fact/table/specimen must state one-row meaning before choosing dimensions, measures, slices, or display names.

## What stays parked

- no universal identity plane;
- no portable account chooser or browser-session table;
- no wallet inventory or credential inventory ontology;
- no global trust-score or Trust-Mark-as-truth doctrine;
- no promise that a prompt is an approval basis;
- no rule that encrypted credential responses make the browser an all-knowing witness;
- no conversion of discovery/config metadata into durable issuer/account truth;
- no specimen 70 until one concrete SlopOS browser-mediated or trust-mediated flow and one sibling-cube consumer converge on the same new seam.
