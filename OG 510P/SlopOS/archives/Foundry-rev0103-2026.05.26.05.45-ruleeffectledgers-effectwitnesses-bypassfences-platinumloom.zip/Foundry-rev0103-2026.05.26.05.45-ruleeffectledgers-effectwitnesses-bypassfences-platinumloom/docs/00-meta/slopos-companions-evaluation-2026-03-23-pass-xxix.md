# SlopOS plus companions evaluation — pass XXIX

This pass tested whether Foundry needs a small meaning seam for *replacement without immediate disappearance*.
The answer is yes, but only narrowly.

## What SlopOS already contributes
The uploaded SlopOS archive already contains draft surfaces around cooperative quiesce, worker-pool quiesce state, and RCU-style deferred reclamation.
That is good news for Foundry.
It means the mechanism vocabulary does **not** need to be reinvented here.

## What Foundry should own instead
Foundry should own the semantic cut that sibling cubes can reference when a foreign realization is no longer the ordinary admission target but still cannot honestly be treated as gone.
That cut is smaller than lifecycle management and smaller than garbage collection:
1. **admission cut** — new work should stop landing here;
2. **drain epoch** — old work/readers/connections may still be completing;
3. **grace fence** — teardown or reclaim must still wait.

## Companion-cube fit
- **Steward** already cares about readiness, stop deferral, and cooperative quiesce; Foundry should not duplicate that control plane.
- **Harbor** keeps handoff and route truth separate from realization truth; that supports the idea that successor routing can advance before predecessor drain completes.
- **Ward** reminds Foundry that evidence and verdict are smaller than consequence; similarly, drain observations are smaller than reclaim permission.
- **ViewFS** keeps exact material and lineage honest, which helps when an older realization remains referenced by draining use instead of by archival retention alone.

## Why this seam is worth preserving now
SlopOS is still in design, so this is the right time to keep three facts separate without freezing a grand subsystem:
- no longer admitted,
- still draining,
- finally safe to tear down or reclaim.

If Foundry misses that seam now, later revisions will be tempted to overcompress replacement, quiesce, and reclamation into one flattering “rolled over cleanly” story.
