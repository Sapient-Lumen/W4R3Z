# SlopOS + companions evaluation — pass LIII

This pass checks whether **selection recipe, window cut, and total mode** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant search subsystem, a universal ranking algebra, or a cube-wide browse product.

## Why SlopOS pressures this seam now

### 1) SlopOS ATTRFS already keeps queries smaller than global inventory
`attrfs-posture-v0.md` makes D-ATTRFS queries **view-scoped, snapshot-first, and handle-returning**.
It explicitly refuses ambient global inventory, raw paths, and app-visible count-only probes, and it keeps saved queries as shell-owned manifests.
That means any future Foundry count derived from an ATTRFS query is already query-shaped and view-shaped rather than a universal population fact.
A compact **selection recipe** is therefore honest residue, not ornamental metadata.

### 2) SlopOS already warns that bounded suggestion sets are not current-state truth
The MCP completion import boundary says bounded `completion.values`, optional `total`, and `hasMore` stay provider-local suggestion mechanics only, not durable selector receipts or inventory truth.
That is exactly the humility Foundry should steal for query/result families: page-local rows and whole-result claims should not collapse into one vague count or one flattering `results` field.

### 3) Schell strengthens the cursor/window lesson
Schell’s current focus on cursor expiry and reset-scope humility is a good companion warning.
A review cursor or first-unseen anchor can expire, be reset, or become weaker residue after truncation or compaction.
That pressures Foundry toward an explicit **window cut** instead of silent assumptions that one saved page or cursor still names the same slice forever.

## What to steal into Foundry

### selection recipe
A compact witness for the query shape that made rows eligible.
In nearby SlopOS-adjacent reality this can stay small:
- CH-ATTRQ digest or query digest,
- schema digest when the query is schema-bound,
- explicit view binding / lens residue when eligibility was visibility-scoped,
- and sort/ranking residue only when ordering mattered to the returned slice.

This is smaller than a full search DSL registry.
It simply prevents “results page” from impersonating “population truth.”

### window cut
A compact witness for how the current rows were sliced from the eligible set.
Examples:
- offset + limit for snapshot paging,
- cursor/start/end pageInfo residue,
- PIT/search-after style cut,
- shell-local smart-folder page token or equivalent continuation residue,
- explicit “first page only” or “truncated at N” posture.

This is smaller than a browse/watch product.
It just keeps one page of handles from pretending to be the whole query.

### total mode
A compact witness for what any count means.
Examples:
- **exact** — full eligible count at the relevant cut;
- **lower-bound** — count is at least this large;
- **estimated** — useful approximation only;
- **page-local** — count only describes the current returned slice;
- **unknown** — no honest total claim attached.

This is smaller than a universal statistics plane.
It simply stops one integer field from carrying five incompatible meanings.

## Why this seam is small enough now
It does **not** require:
- a universal query planner;
- a ranking-score ontology;
- a full search UI model;
- a cube-wide browse/watch substrate;
- or a single pagination abstraction for every future engine.

It only says that once a value comes from a query-shaped or page-shaped result, Foundry should preserve:
1. how rows were selected,
2. how the current window was cut,
3. and what any attached total is actually claiming.

## Recommended Foundry posture
Promote **selection recipe**, **window cut**, and **total mode** as a narrow honesty seam for query-shaped values.
Keep the larger search/ranking/product questions parked.

This matches current SlopOS discipline well: ATTRFS already keeps query authority bounded, current completion surfaces already refuse to turn bounded lists into durable truth, and Schell already teaches that cursor continuity can weaken or expire instead of silently surviving forever.
