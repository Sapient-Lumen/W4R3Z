# Research synthesis — 2026-05-24 pass XCIII

Focus: **exposure ledgers, audience witnesses, and purpose fences**.

The previous pass made reachable surface inventory explicit. This pass closes the next gap: inventory can prove that a semantic carrier exists at a surface, but it cannot prove that the right audience can see it, that the audience can use it for the requested purpose, or that inherited/shared/public access is safe.

## New outside pressure

- `EXT-W3C-ODRL-2-2` gives the right semantic scar for usage constraints: permissions, prohibitions, duties, parties, assets, actions, and constraints belong near content use. Foundry should steal the party/action/constraint instinct without becoming a digital-rights language or policy engine.
- `EXT-NIST-ABAC-800-162` defines ABAC as evaluating subject, object, operation, and environment attributes against rules. Foundry should steal the subject/object/action/environment separation but not decide authorization.
- `EXT-RFC7519-JWT` warns that an audience claim is about intended recipients. Foundry should borrow audience specificity while refusing token validation or authentication capture.
- `EXT-RFC8707-OAUTH-RESOURCE` lets OAuth clients signal protected resources to authorization servers. Foundry should borrow resource/audience explicitness without becoming OAuth, IAM, or access-token infrastructure.

## What rev0092 still allowed

Rev0092 can say that a dashboard tile, notebook CSV, ViewFS projection, worker cache, or shadow export was reached or fenced. It still allows quiet exposure failures:

- a found dashboard tile is readable by an operator group and a service account, but the operator purpose differs from dashboard rendering;
- a Ward preview tile can be read by the right group, but carries a SlopOS support-debug purpose that Ward must not use as appraisal truth;
- a ViewFS projection inherits access from a parent project and is accidentally treated as intended audience scope;
- a delegated worker cache refuses listing, so runtime access is unknown and must not be called authorized;
- a shadow CSV has an unknown external reader and a matching digest, but no audience pin or adoption receipt;
- a public preview link makes a sidecar visible to anonymous readers, and the link is mistaken for consent or public-release approval; or
- exposure evidence for one surface is reused to clear another consumer's surface.

Those are exposure/purpose failures, not inventory failures.

## Speculative read

Foundry needs a small **audience exposure seam** after inventory:

```text
exposure ledger  = scoped ledger of intended audiences, observed surfaces, access modes, purposes, source inventory, and non-promises
audience witness = one observed audience/surface/access-purpose fact with residue and limits
purpose fence    = one audience/purpose/access-mode/public/inherited/unknown exposure blocked until clearance
```

The seam should stay smaller than authorization, IAM, ABAC, OAuth, JWT validation, ODRL policy execution, consent management, privacy engineering, public-release workflow, deletion, custody, audit, or sibling-cube verdicts. Foundry only needs to prevent a dangerous sentence: "we found the copy, therefore it is safe for this audience and purpose."

## New specimen pressure

Add specimen 87 around exposure ledgers, audience witnesses, and purpose fences. The fixture must prove at least:

- every exposure ledger names source inventory sweeps, reachability witnesses, carrier ids, intended audiences, purposes, access modes, method limits, and authority boundaries;
- every observed audience/surface pair has an audience witness;
- within-scope witnesses do not exceed intended purpose or access-mode pins;
- overexposed, unknown, public-link, and inherited-access witnesses carry purpose fences;
- complete ledgers cannot have unaccounted observed surfaces or intended audiences;
- partial/blocked ledgers cannot be advertised as exposure closure;
- public link is not consent, release approval, deletion, authorization, or source truth; and
- negative cases cover missing ledger, missing source inventory, missing witness, unknown/public audience without fence, purpose/access widening, inherited permission, expired ledger, overexposure-as-adoption, audience-as-authorization, exposure-as-consent, exposure-as-deletion, consumer mismatch, and digest mismatch.

## Recommendation

Keep exposure accounting fixture-local and reversible. Do not promote a global audience registry or access-policy model. The narrow Foundry job is to make audience, purpose, access-mode, public-link, inherited-permission, and unknown-reader residue visible enough that a found semantic surface cannot silently become safe for every reader.
