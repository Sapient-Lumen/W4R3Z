# SlopOS and companions evaluation — 2026-05-22 pass LXXXVII

Focus: whether Foundry can carry semantic residue across consumers without transferring sibling authority, verdicts, or purpose-specific meaning.

## SlopOS pressure

SlopOS support surfaces can carry Foundry residue, but a SlopOS-facing support card is not automatically meaningful to an external audit notebook, a Ward appraisal queue, or a ViewFS artifact browser. The same sidecar digest may be portable while the interpretation is not. A SlopOS operator hint, proof posture, or boundary-family convention must stay pinned to its consumer purpose unless a portability witness and interpretation gate say otherwise.

The pressure is not that Foundry should manage SlopOS consumer policy. The pressure is smaller: if a SlopOS-facing surface is reused elsewhere, the target consumer must name what it is allowed to infer and what it must refuse.

## Companion boundaries

| Companion | Consumer-portability interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| Ward | may consume a consumer passport and portability witness before appraising a surface | Ward still owns appraisal, consequence, and trust verdicts |
| Harbor | may provide outside-fact aftermath that a target consumer needs before reuse | Harbor still owns membrane authority and external status |
| Steward | may need portability gates before lifecycle/retry evidence is reused across consumers | Steward still owns effect finality and operational lifecycle |
| Schell | may restrict portability when retention/minimization changes drill-through posture | Schell still owns forgetting and minimization authority |
| ViewFS | may expose consumer passports beside projected artifacts and trusted paths | ViewFS still owns object identity, trusted paths, and consent fences |
| Helm | may route repair traces to a target consumer only with an interpretation gate | Helm still owns repair custody and intervention consequence |
| SlopOS | may emit support-card residue as a source consumer | SlopOS still owns boundary-family proof claims and operator semantics |
| External audit notebook | may reuse residue only for the declared review purpose and audience | does not promote Foundry into an audit product or evidence-opinion framework |

## What changed in this pass

- Added specimen 81 for consumer passports, portability witnesses, and interpretation gates.
- Added a consumer-portability rulebook so cross-consumer reuse has named failure modes.
- Added v0 schemas for consumer passports, portability witnesses, and interpretation gates.
- Added a specimen 81 fixture with SlopOS, Ward, ViewFS, and external-audit consumers plus cross-consumer witnesses and negative cases.
- Added `check_foundry_consumer_portability.py` and wired it into `make check`.
- Reused W3C PROV, DQV, DCAT, OpenLineage, SlopOS, and companion-cube pressure while keeping Foundry smaller than provenance verdicts, data-quality scoring, catalogs, lineage platforms, or audit products.

## Recommendation

Future Foundry revisions should never treat a stable carrier as a stable interpretation. A carrier becomes meaningful to a new consumer only after the consumer passport, portability witness, and interpretation gate agree about purpose, audience, residue, and forbidden inferences.
