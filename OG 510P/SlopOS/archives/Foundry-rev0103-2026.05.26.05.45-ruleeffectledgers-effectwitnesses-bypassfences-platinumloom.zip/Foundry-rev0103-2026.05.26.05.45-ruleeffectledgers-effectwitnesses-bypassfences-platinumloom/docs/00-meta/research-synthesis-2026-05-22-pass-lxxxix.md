# Research synthesis — 2026-05-22 pass LXXXIX

Focus: **revocation notices, recall receipts, and stale-reliance fences**.

The previous pass made delegated semantic acts explicit. This pass covers the next scar: a sidecar, waiver, delegation warrant, portability witness, refusal receipt, or cached export can be valid when emitted and later become unsafe. If Foundry can create egress residue, it also needs a tiny way to say that a carrier has been revoked, consumers were notified, cached copies were quarantined, and stale reliance failed.

## New outside pressure

- `EXT-RFC7009-OAUTH-REVOCATION` gives a narrow revocation instinct: a previously issued credential can be invalidated without pretending the original issuance never happened. Foundry should steal the lifecycle distinction without becoming OAuth or an authorization server.
- `EXT-RFC6960-OCSP` separates certificate-status checking from the certificate bytes themselves. Foundry should steal the current-status check instinct without becoming PKI, CRL, or OCSP infrastructure.
- `EXT-W3C-VC-BITSTRING-STATUS-2025` shows status as a separately published machine-readable state such as revocation or suspension. Foundry should steal the status-list humility without creating credential-status or identity-verification machinery.
- `EXT-TUF-SPEC-2026` treats stale metadata, rollback, and freeze attacks as first-class update-system hazards. Foundry should steal the stale-metadata alarm: an unchanged digest or cached file can still be unsafe if the consumer missed a newer status notice.
- Existing `EXT-RFC9111-CACHING` and `EXT-RFC9211-CACHE-STATUS` pressure still applies: freshness, revalidation, and cache-handling details are not truth.

## What rev0088 still allowed

Rev0088 could prove that a delegated export worker was scoped and non-transitive. It did not yet prove that a previously valid artifact stopped being usable after a later correction. A future editor could still:

- revoke a delegation warrant in prose while a notebook continues to rely on the old warrant;
- replace a sidecar after a classification-pin error while cached dashboards keep serving the old sidecar digest;
- let a waiver expire or be withdrawn but keep the waiver's old “allowed loss” posture in a materialized packet;
- supersede a refusal receipt or egress manifest without telling every affected consumer;
- treat revocation as deletion of source evidence instead of a status overlay on the carrier;
- let a recall receipt become approval, proof, or sibling-cube verdict; or
- miss the propagation window and still allow stale reliance because the bytes match a historical fixture.

Those are revocation/recall failures, not ordinary delegation or portability failures.

## Speculative read

Foundry needs a small **recall seam** beside delegation:

```text
revocation notice     = which semantic carrier is invalidated, why, since when, for whom, and what must be rechecked
recall receipt        = which consumer received the notice, quarantined/replayed/replaced what, and what it refused
stale-reliance fence  = where old reliance, cache hits, or unchanged digests must fail after the notice
source truth          = still outside Foundry
```

The negative move matters most: revocation does not erase history. It says a carrier may no longer be relied on under a named scope until a replacement or recheck passes.

## New specimen pressure

Add specimen 83 around revocation notices, recall receipts, and stale-reliance fences. The fixture must prove at least:

- every revocation notice names the carrier family, carrier id, carrier digest, reason class, issuer, issued/effective time, affected consumers, affected surfaces, required actions, and propagation deadline;
- revocation notices distinguish active, superseded, rescinded, and informational states;
- every affected consumer either emits a recall receipt or is blocked by a stale-reliance fence;
- recall receipts record quarantine, replay, replacement, refusal, and cache-handling actions without becoming approval;
- stale-reliance fences block old sidecars, revoked warrants, withdrawn waivers, stale caches, audience-mismatched notices, and silent supersession; and
- a recall failure is machine-readable enough to replay in the fixture harness.

## Recommendation

Keep revocation notices fixture-local and reversible. Do not promote a global status registry, authorization revocation endpoint, credential-status service, certificate-validation system, update framework, cache-control product, legal hold, or sibling-cube correction authority. The narrow Foundry job is to prove that consumers stopped relying on a semantic carrier after a notice made that carrier unsafe.
