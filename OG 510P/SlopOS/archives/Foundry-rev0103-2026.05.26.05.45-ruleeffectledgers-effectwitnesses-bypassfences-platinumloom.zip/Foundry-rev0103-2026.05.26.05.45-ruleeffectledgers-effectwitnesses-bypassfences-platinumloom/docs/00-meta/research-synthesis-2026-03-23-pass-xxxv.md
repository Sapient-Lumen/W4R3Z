# Research synthesis — pass XXXV

This pass keeps the next seam deliberately narrow: **effect key / fingerprint fence / prior-outcome anchor**.
The strongest shared outside lesson is not “build exactly-once transport” or “standardize a universal operation ledger now”.
It is smaller and more durable: systems that offer retry-safe mutation keep rediscovering that *retry-equivalent intent*, *the exact request fingerprint that may reuse that intent*, and *the earlier outcome you may honestly replay* are different truths.
Foundry should preserve that seam without importing one global dedupe service, one universal queue, or one portable transaction coordinator.

## Primary lessons from the outside

### 1) Retry identity belongs to the request, not to the resource or current live state
Google AIP-155 gives the cleanest compact rule.
A request ID exists to provide idempotency guarantees, it belongs on the request message rather than on the resource itself, and services may honor it for a reasonable bounded timeframe.
That is exactly the shape Foundry should steal.
A stable retry key is useful because transport can go uncertain.
It should not quietly become target identity, current live state, or a forever-honored operation handle.

### 2) Reuse is only safe when the effect fingerprint still matches
AWS EC2, AWS ECS, and Stripe all keep the same discipline.
A repeated call with the same key and the same parameters may return the earlier result without performing the effect again.
But the same key with materially different parameters must fail loudly (`IdempotentParameterMismatch`, `ConflictException`, or equivalent mismatch error) rather than silently retargeting the old request.
That gives Foundry its second noun.
The checked canonical request or reviewed effect shape is the **fingerprint fence**.
It keeps “same key” smaller than “same effect”.

### 3) Prior outcome replay and forever truth are different promises
The outside systems are also refreshingly honest about time and incompleteness.
AIP-155 allows a reasonable honoring window rather than requiring permanence.
ECS gives `RunTask` client tokens a bounded TTL.
Stripe prunes old keys and treats reuse after pruning as a new request; it also says requests that fail validation or conflict before execution begins do not save an idempotent result.
That combination is the right humility lesson.
A duplicate-safe path may replay one earlier accepted answer, but it does not promise a forever ledger and it does not promise that “still processing”, “same earlier outcome”, and “current live state” all collapse into one fact.

## SlopOS/companion pressure
The uploaded cube ecology already leans toward this seam.
SlopOS repeatedly keeps requester-chosen request identity smaller than portal-owned live state across network, background, entropy, and timeproof request lanes.
Its narrow request-idempotency boundary is even more explicit: same scoped request key means exact replay of one canonical request, not mutable upsert or broadened meaning under one key.
Steward already gathers the same pressure in shell form with effect keys, explicit mismatches, still-processing posture, and bounded dedupe windows.
Helm’s settlement witnesses reinforce the same anti-flattery law from the outcome side: acceptance and later settlement remain weaker than one triumphant `done` badge.

That makes the Foundry move very small:
- **effect key** should say which foreign mutation attempts count as retry-equivalent intent;
- **fingerprint fence** should say what exact reviewed request/effect shape must match before that key may reuse prior work;
- **prior-outcome anchor** should say which earlier accepted outcome or receipt may honestly be replayed instead of performing the effect again.

## Candidate nouns worth collecting
- **effect key** — stable retry-equivalent identity for one requested foreign effect, weaker than target identity or live state.
- **fingerprint fence** — exact canonical request/effect fingerprint that must still match before the same key may reuse prior work.
- **prior-outcome anchor** — replayable earlier outcome/receipt reference for an exact duplicate-safe retry.

## Things to keep parked
- one universal exactly-once or transaction plane;
- a forever global dedupe ledger;
- any collapse of effect keys into target/resource ids or current live grant truth;
- any claim that a replayed prior outcome automatically proves present settlement or present liveness.

## Provisional judgment
Promote only the seam, not the control plane.
Foundry should be able to say that a foreign mutation attempt carries one **effect key**, that reuse of that key still depends on a checked **fingerprint fence**, and that an exact duplicate-safe retry may point back to one **prior-outcome anchor** instead of firing the side effect again.
That is especially valuable while SlopOS is still plastic enough to avoid teaching later docs that request identity, effect identity, settlement, and current live state are all the same thing.
