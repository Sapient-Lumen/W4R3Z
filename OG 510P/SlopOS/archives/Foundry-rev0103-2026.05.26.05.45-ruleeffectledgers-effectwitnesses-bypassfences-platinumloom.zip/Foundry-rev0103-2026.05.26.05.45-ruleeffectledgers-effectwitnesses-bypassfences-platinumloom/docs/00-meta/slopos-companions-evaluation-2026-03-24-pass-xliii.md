# SlopOS plus companions evaluation — pass XLIII

The best datacube move to steal from the companion archives is **discipline before ontology**.
Foundry does not need a giant datacube schema yet.
It needs sharper process surfaces so the schema can emerge without hidden drift.

## SlopOS
SlopOS already demonstrates excellent archive hygiene around boundary naming and family coverage.
`boundary-family-map.md`, `boundary-index-contract-v0.md`, and `boundary-singleton-contract-v0.md` keep the archive honest about whether a boundary belongs to a family, is intentionally standalone, or still lacks placement.
That is exactly the kind of discipline Foundry should copy before it copies heavier semantic machinery.

SlopOS also keeps capability/export/continuation/account-binding surfaces smaller than ambient “session” or “provider” folklore.
That argues for slow noun promotion in Foundry’s datacube.

## Ward
Ward contributes the most directly useful repo/process moves for this revision:
- a noun-promotion rubric;
- a load-bearing source register;
- a source review queue;
- a specimen-flow index;
- and a stricter hygiene checker that catches revision drift and bibliography ghosts.

Those are ideal steals because they increase discipline without freezing ontology.

## Steward
Steward’s external source review discipline is a good reminder that living specs and product docs quietly drift.
Foundry should keep the same “re-check before promotion” posture for moving datacube-construction ideas.

## Harbor and the others
Harbor, ViewFS, Schell, and Helm keep proving the same meta-lesson: the right noun is usually the smaller one, and convenience surfaces should not silently become the meaning model.
That strengthens the case for explicit candidate/stable parking posture.

## Resulting judgment
Promote only the following small process seam in this revision:
1. **promotion candidate** — a noun under pressure, not yet durable archive truth;
2. **stability lane** — explicit posture for how hard future revisions may lean on that noun;
3. **revision hook** — exact revision/vocabulary identity on any status/export surface that could lag or evolve.

Keep parked for now:
- a universal Foundry datacube schema;
- a generic registry for every noun/field;
- any promise that JSON export is the permanent compatibility surface;
- any broad migration/transform engine.

That keeps Foundry aligned with SlopOS’s design-phase discipline and gives the repo better process hygiene at the same time.
