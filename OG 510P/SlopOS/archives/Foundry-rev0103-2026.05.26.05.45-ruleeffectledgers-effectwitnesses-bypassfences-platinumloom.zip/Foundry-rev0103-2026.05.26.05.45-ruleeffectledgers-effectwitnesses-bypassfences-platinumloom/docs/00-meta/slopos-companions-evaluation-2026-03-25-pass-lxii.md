# SlopOS + companions evaluation — pass LXII

This pass checks whether **translation witness, compatibility lane, and upgrade fence** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal transform registry or a promise that every schema-pinned family is forward-comparable forever.

## Why SlopOS pressures this seam now

### 1) SlopOS already speaks in many pinned `v0` surfaces, which means revision churn is part of the design reality
The current SlopOS archive is rich in schema- and posture-shaped documents such as `budget-lease-schema-v0.md`, `meter-descriptor-schema-v0.md`, `job-request-state-posture-v0.md`, `mcp-progress-import-boundary-v0.md`, `mcp-task-import-boundary-v0.md`, and `mcp-sampling-import-boundary-v0.md`.
That is healthy.
It also means Foundry should assume that future support/import/export rows will be asked to compare data emitted under several adjacent pins rather than one eternal frozen schema.

### 2) Imported MCP-family support metadata is likely to rename or rebucket before it stabilizes
The MCP task/progress/sampling boundary docs are intentionally narrow and explicitly refuse to let provider-local protocol mechanics masquerade as SlopOS-native job, background, or planner truth.
That same narrowness means their support metadata may legitimately evolve.
Foundry therefore needs a way to say “this tile translated one older provider-local status family into the consumer’s current view” without pretending the older rows always meant the newer thing.

### 3) Budget and payer families are too authority-sensitive for silent upgrades
`budget-payer-semantics-v0.md` is very clear that payer identity must remain explicit, non-ambient, and separate from execution subject or request context.
That kind of surface is too load-bearing for silent normalization.
If a later schema renames a field, splits one enum, or narrows one authority claim, Foundry needs an upgrade fence by default and an explicit translation witness only where review proves it is honest.

### 4) Harbor already shows why schema-rotation repair deserves explicit residue
Harbor’s current schema-rotation specimen is a good neighboring reminder that repair after trusted-schema drift is not the same thing as timeless validity.
That pressures Foundry toward a similar posture: when a later support/export row only became comparable after refetch/rebuild/translation, the archive should preserve that fact rather than flattening it into “same current schema.”

### 5) ViewFS and Schell both benefit from cross-revision honesty without a giant registry
ViewFS is already pressure-testing payer roots, budget leases, charge verdicts, and receipts as separate truths.
Schell is pressure-testing explicit payer/budget posture and reviewed resource receipts.
Both neighbors are likely to want support and accounting tiles across evolving shapes, but neither pressure source currently justifies one cube-wide compatibility bureaucracy.
That makes this seam the right size.

## What to steal into Foundry

### translation witness
A compact reviewed record of how one source schema pin became one consumer-facing target schema pin.
Examples:
- a content-addressed migration rule,
- a git-pinned transform note,
- a doc revision that explains the exact rename/split/merge,
- or an explicit `none` when the row stayed native.

### compatibility lane
A compact posture for the result of that interpretation.
Examples:
- `native`
- `lossless_translated`
- `lossy_translated`
- `deprecated_source`
- `incomparable`

This is smaller than a global compatibility matrix.
It only stops several very different upgrade stories from sharing one flattering “current” badge.

### upgrade fence
A compact refusal boundary for silent reinterpretation.
Examples:
- no reviewed transform exists,
- the transform carrier itself is newer than the reader supports,
- the rename was actually a semantic split,
- or the consumer can show the old row only through an explicit old-schema lens.

This is smaller than a registry.
It simply says old history should not be rewritten by habit.

## Why this seam is small enough now
It does **not** require:
- one cube-wide transform registry,
- one automatic backfill/migration engine,
- one promise that every `v0` family has a lawful `v1` forward map,
- or one global deprecation calendar.

It only says that once Foundry compares or re-renders evolving schema-pinned families, it should preserve:
1. **what the source schema pin originally was**,
2. **what translation witness, if any, was applied**,
3. **which compatibility lane the visible result now occupies**,
4. and **where the upgrade fence refused silent normalization**.

## Recommended Foundry posture
Promote **translation witness**, **compatibility lane**, and **upgrade fence** as a narrow honesty seam for evolving imported/exported/adjunct families.
Keep the heavier transform-catalog, migration-engine, and universal-compatibility questions parked.

This matches current SlopOS discipline well: SlopOS is still early enough that the healthy move is not “make all versions look the same,” but “make version drift, reviewed translation, and refusal to compare visible.”
