# Research synthesis — pass LXXVIII

This pass goes deeper on a problem that appears once query contracts, result envelopes, validation witnesses, hierarchy scopes, and rollup guards exist: somebody will want the answer to be fast, reusable, refreshed in the background, served from a summary, served during an upstream outage, or replayed from a cached/materialized object.

That pressure is legitimate.
It is also one of the fastest ways for a careful datacube to rot into folklore.

SlopOS is still in design phase, and Foundry should not answer materialization pressure by choosing a warehouse, semantic layer, scheduler, lakehouse table format, cache hierarchy, freshness SLA language, or invalidation algorithm too early.
The low-regret move is much smaller: when an answer is served from anything other than immediate row-preserving recomputation at the pinned source cut, the answer should carry a **materialization cut**, a **refresh witness**, and a **reuse fence**.

Specimen 72 is therefore added.
It is a served-output honesty seam, not a storage engine.

## Lessons we must learn from the past

### 1) Materialized views are not one thing
BigQuery distinguishes incremental from non-incremental materialized views, smart tuning eligibility, limitations on supported queries, maximum staleness, and cases where cached materialized data is bypassed or invalidated.
The Foundry lesson: “materialized” is not enough. A served answer needs to say which cut, recipe, refresh posture, and base-change coverage made it usable.

### 2) Automatic rewrites are useful precisely because they are dangerous
BigQuery smart tuning can reroute a base-table query through a materialized view without changing query results when conditions are satisfied.
The Foundry lesson: automatic acceleration is a serving decision, not a semantic promotion. The result should retain an acceleration/materialization witness rather than pretending it was directly read from base truth.

### 3) Target lag is a budget, not proof of freshness
Snowflake dynamic tables let authors state a target lag and schedule refreshes to keep actual lag below that target where possible, but refresh duration, dependency chains, warehouse size, and skipped refreshes can increase actual lag.
The Foundry lesson: a target freshness promise and an observed freshness witness are separate.

### 4) Incremental rebuilds depend on filters, unique keys, and strategy
The dbt incremental model docs make the author state how rows are filtered on incremental runs and, if needed, the unique key.
The Foundry lesson: incremental refresh is a recipe with hidden assumptions until the filter, key, merge/append/delete posture, and full-refresh escape hatch are named.

### 5) Live incremental engines are excellent pressure, not ontology
Materialize advertises incrementally maintained results as new data arrives.
The Foundry lesson: continuous maintenance is a serving posture. Foundry can borrow the idea of a live refresh witness without freezing a live-data engine or streaming algebra as the cube's core ontology.

### 6) HTTP cache history has the right scar tissue
HTTP caching separates freshness, validation, storage permission, authorization-sensitive reuse, `no-cache`, `no-store`, `must-revalidate`, `private`, `public`, stale reuse, conditional requests, and cache-status debugging.
The Foundry lesson: cacheability is not a property of a result alone. It depends on the request, audience, policy lens, validator, freshness budget, and revalidation rule.

### 7) Debuggability beats mystery hits
RFC 9211's `Cache-Status` exists because ad-hoc cache-hit headers were inconsistent and hard to debug.
The Foundry lesson: a reused cube answer should say whether it hit, missed, revalidated, forwarded, collapsed, refreshed, or refused reuse. A bare “served fast” badge is too weak.

### 8) Freshness checks and quality assertions are witnesses, not row truth
Dagster freshness policies and asset checks, DataHub assertions, and OpenLineage data-quality assertion facets are useful because they attach observable checks to assets/datasets without rewriting the asset into truth.
The Foundry lesson: a refresh witness can include freshness and validation status, but it must stay smaller than the facts it served.

### 9) SlopOS already has the right instinct on materialization
The SlopOS archive treats safe-open materialization as request-local stable input, refuses generic OpenURI download/docref minting, keeps handler-local caches non-authoritative, keeps Capshell richer result structure in explicit sidecars, and keeps quarantined result previews metadata-safe.
The Foundry lesson: served datacube outputs should follow the same boundary style. Materialization can be useful without becoming hidden persistence, authority, preview, or source truth.

### 10) Ward's tier/resolution lesson should be borrowed, not copied
Ward already pressure-tests resolution binding, tier witness, and hybrid seams for recurring trust answers.
Foundry should not duplicate Ward's trust-result vocabulary. Foundry's narrower job is to attach materialization/reuse evidence to any emitted cube result, including SlopOS support cards, attribute-query exports, dashboard tables, and sibling-cube projections.

## Nifty ideas to steal without over-freezing

- **materialization cut** — compact residue for query-contract digest, result-envelope digest, rollup/aggregation guard dependencies, source snapshot or transaction cut, build run, recipe version, policy lens, principal/audience lens, and materialized-object digest.
- **refresh witness** — compact residue for refresh mode, refresh trigger, dependency cut, source watermark/frontier, build start/end, incremental/full posture, invalidation cause, skipped/failed/partial status, observed lag, and validation result.
- **reuse fence** — compact rule card for which query contracts, parameter values, policy lenses, audiences, schema versions, calendar/geography lenses, rollup paths, validation states, and staleness windows may reuse a served object.
- **validator token** — ETag-like or digest-like token for “this served object still corresponds to that source cut/recipe/lens,” without pretending validators are semantic identity.
- **vary basis** — explicit dimensions of reuse: principal, permission lens, request parameters, locale/calendar lens, disclosure policy, schema/profile, and transform version.
- **must-revalidate after stale** — a refusal posture for result families where stale reuse would be misleading or unsafe.
- **stale-if-error lane** — a narrow display/support posture that may serve stale results during upstream failure only when the result says so loudly.
- **cache-status witness** — hit/miss/forward/revalidate/collapsed/stored/ttl-style debugging residue for served cube results.
- **invalidation cause** — base change, schema change, policy change, hierarchy change, calendar/geography lens change, validation failure, retention loss, or manual retirement.
- **manual refresh receipt** — a witness that a human/operator forced rebuild or bypass, explicitly smaller than proof that the result is better.

## What stays parked

- no Foundry-wide cache hierarchy;
- no chosen materialized-view engine, warehouse, streaming database, semantic-layer cache, or lakehouse table protocol;
- no universal target-lag or freshness SLA vocabulary;
- no automatic stale-if-error default;
- no assumption that a cache hit is a valid answer;
- no assumption that a materialized object is cheaper, safer, more authoritative, or more private than recomputation;
- no treating refresh success as validation success;
- no treating validation success as source truth;
- no treating materialization layout, partitioning, or storage digest as cube grain;
- no audience-neutral reuse unless the reuse fence says the policy/disclosure lens allows it;
- no hidden persistence, docref minting, or preview authority from the fact that a handler/query engine materialized something internally.
