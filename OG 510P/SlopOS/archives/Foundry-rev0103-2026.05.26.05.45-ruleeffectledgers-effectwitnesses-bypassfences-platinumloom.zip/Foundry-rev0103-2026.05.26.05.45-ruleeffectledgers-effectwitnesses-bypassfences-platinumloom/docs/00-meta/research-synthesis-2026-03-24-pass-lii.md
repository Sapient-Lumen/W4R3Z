# Research synthesis — pass LII

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from row-filtered analytics, masked columns, and privacy-gated aggregate release: a cube stays healthier when a value can say **which explicit view or export lens shaped it, what disclosure class the visible payload belongs to, and whether cross-lens comparison is even semantically legal**.

The smallest durable seam from this pass is:
- **view lens** — the explicit view/export/policy lens that shaped which rows, fields, and release rules were in force;
- **disclosure class** — whether the visible value is public, sanitized, masked, threshold-gated, sensitive, or otherwise disclosure-shaped;
- **comparability fence** — whether the value can only be compared inside the same lens, only under the same release threshold, only by monotone relation, or not safely compared at all.

These are still smaller than a universal authorization plane, a privacy-budget engine, or a global audience catalog.
They simply keep future Foundry rows from laundering “a number someone can see” into “the same truth for everybody.”

## Lessons we must learn from the past

### 1) Visible rows are principal-shaped, not universal
PostgreSQL row security says policies restrict, on a per-user basis, which rows can be returned, and default-deny if row security is enabled without a policy.
That means the same SQL shape can still speak about different visible universes.
Foundry should learn the same lesson before it lets one count impersonate global truth.

### 2) Masking changes visible semantics even when access continues
BigQuery masking docs are explicit that users may see unmasked data, masked data, or access denied depending on groups and roles.
That is exactly the kind of semantic fork a design-phase datacube must keep visible.
A value that survived a mask is useful, but it is not the same disclosure posture as the unmasked value.

### 3) Security filters are allowed to reject faster plans
PostgreSQL’s `security_barrier` guidance is unusually honest: the safest possible filtered view may perform worse because the fastest plan must be rejected if it could compromise security.
Foundry should steal that humility.
A secure lens is allowed to have different performance, freshness, or optimizer shape than a broader lens.

### 4) Aggregate release can have explicit disclosure thresholds
Snowflake aggregation policies are a strong modern reminder that release rules can be attached to aggregate outputs themselves.
Providers can require aggregation and minimum group sizes before results are allowed.
That is a brilliant steal for Foundry, but only as a small fence rather than a built-in privacy product.

### 5) Even metadata about the query can become policy-shaped
BigQuery’s JOBS documentation notes that some statistics are hidden for queries over row-level-secured tables.
That is important for Foundry because “the dashboard around the value” may also inherit the security lens.
Usage, cost, or freshness metadata may not be uniformly visible across audiences.

## What to steal now
- a **view lens** beside any value whose eligible population or visible fields were shaped by an explicit view, role, export policy, or release rule;
- a **disclosure class** so masked, sanitized, threshold-gated, and sensitive-visible values stop pretending to be one generic payload type;
- a **comparability fence** so consumers know whether two values may be numerically compared, only ordered monotonically, or treated as incomparable across lenses;
- a habit of keeping security-shaped visibility smaller than cube-wide truth;
- and a habit of treating minimum-group or masking rules as explicit disclosure posture rather than dashboard folklore.

## What to keep parked
Do not yet promote:
- a universal RBAC or entitlement plane;
- a global audience or tenant catalog;
- a built-in differential-privacy budget system;
- a general cross-lens query rewriter;
- or a giant policy language for all future cube families.

## Resulting recommendation
The next healthy move is not “design the privacy layer.”
It is to let Foundry say, for any future visibility-shaped value:
1. which **view lens** produced it,
2. what **disclosure class** the visible value belongs to,
3. and what **comparability fence** governs cross-lens arithmetic or interpretation.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from PostgreSQL row security and security-barrier views, BigQuery row filtering and masking, and Snowflake aggregation-policy discipline.
