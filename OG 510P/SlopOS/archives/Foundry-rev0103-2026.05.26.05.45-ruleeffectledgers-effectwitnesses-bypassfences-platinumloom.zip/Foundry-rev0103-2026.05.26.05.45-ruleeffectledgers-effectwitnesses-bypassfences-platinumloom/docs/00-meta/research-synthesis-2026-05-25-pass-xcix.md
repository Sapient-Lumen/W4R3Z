# Research synthesis — 2026-05-25 pass XCIX

## Focus

Post-drift routing exposed a new false-comfort seam: a routed signal can be marked resolved without proving what was decided, what evidence was reviewed, what scope was covered, which source fences remain open, or which authority claims remain forbidden.

This pass promotes a fixture-local disposition layer:

- **disposition ledger** — consumer-local record of source packets, route witnesses, unresolved-signal fences, disposition status, review basis, required resolution witnesses, residual fences, and authority boundaries;
- **resolution witness** — scoped evidence that a disposition was closed, partial, deferred, transferred, quarantined, reopened, false-positive, or duplicate; and
- **premature-closure fence** — refusal for missing, stale, widened, contradicted, transferred-without-receiver, unresolved-source-fence, or authority-laundered closure.

## Outside pressure

`EXT-NIST-OSCAL-POAM-2026` is useful pressure because POA&M material tracks identified issues/risks and planned status rather than erasing the underlying assessment residue. Foundry should steal that status-and-task humility, but must not become compliance issue tracking.

`EXT-CSAF-2-0` remains useful because status/remediation claims are scoped to subjects and interested parties. Foundry should preserve subject/scope/status shape without becoming a security advisory, vulnerability, or remediation ecosystem.

`EXT-RFC9413-PROTOCOL-MAINTENANCE` is useful because robust systems need active maintenance to reduce ambiguity over time. Foundry should apply that maintenance scar to semantic fixtures and closure claims, not turn it into protocol governance.

## What changed in the cube

Specimen 93 asserts that a routed signal is not resolved until a disposition ledger names the source packets and witnesses, a resolution witness records closure/deferral/transfer/reopen evidence, and premature-closure fences preserve remaining risk.

The audit/refactor addition is `fixtures/negative-case-coverage/coverage.json`. It makes late executable specimens name their negative cases so fixture hardening cannot disappear while prose still claims coverage.

## Non-promotions

- no incident-management model;
- no ticket/issue workflow;
- no risk acceptance;
- no remediation or repair authority;
- no authorization, consent, public-release approval, legal compliance, or audit opinion;
- no sibling verdict; and
- no claim that a negative-case manifest proves semantic correctness.

## Next pressure

Generate disposition tamper cases from the new fixture: acknowledgment-as-closure, deferred-as-resolved, transfer-without-receiver, false-positive-without-evidence, stale closure, scope widening, fence clearance without evidence, public-release laundering, repair/lifecycle laundering, and sibling-verdict laundering.
