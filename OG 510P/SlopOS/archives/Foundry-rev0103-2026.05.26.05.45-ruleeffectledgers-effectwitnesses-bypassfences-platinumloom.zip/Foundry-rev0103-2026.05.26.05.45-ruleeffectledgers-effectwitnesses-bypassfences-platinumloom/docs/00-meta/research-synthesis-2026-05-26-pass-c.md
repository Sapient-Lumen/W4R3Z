# Research synthesis — 2026-05-26 pass C

Focus: post-disposition precedent promotion. Foundry now has residue for routing and closure, but a closed local case can still turn into an archive-wide rule if the source scope, unresolved fences, test basis, and non-authority boundary are not carried forward.

## Findings

Open Policy Agent's policy-testing guidance is the strongest operational scar for this pass: policies are requirements encoded as rules, but the docs put tests next to policy authoring so rules can evolve without silently changing expected behavior. Foundry should steal the test-basis requirement, not Rego, policy decision, or enforcement authority.

W3C SHACL keeps validation reports and results separate from the data graph being checked. Foundry should steal the habit of returning scoped validation evidence, not convert every validation or promoted rule into source truth.

Kubernetes ValidatingAdmissionPolicy shows that rule-like checks can sit at an admission boundary with explicit policy/binding/parameter structure and failure behavior. Foundry should steal the boundary-shape caution while refusing admission-control, authorization, mutation, or control-plane capture.

OpenTelemetry semantic conventions and stability posture continue to matter: names and conventions become useful only when their stability and evolution lanes are visible. Foundry should preserve local-only, shadow-only, promoted, deprecated, and superseded lanes for precedent-derived rules instead of treating one resolved closure as permanent law.

## Nouns promoted fixture-locally

- **precedent ledger** — wraps source dispositions, resolution witnesses, premature-closure fences, scope, candidate rule targets, required promotion witnesses, residual fences, and authority boundaries.
- **rule-promotion witness** — records whether a precedent became local-only, shadow-only, promoted, partial, rejected, test-failed, deprecated, or superseded with positive/negative cases, fixture/rulebook/checker refs, and replay status.
- **overgeneralization fence** — refuses single-case generalization, scope widening, unresolved-fence erasure, stale precedent, false-positive generalization, public-release/authorization/audit laundering, repair/lifecycle laundering, and sibling-verdict laundering.

## Audit/refactor

Added lifecycle-transition coverage. The executable specimen chain is now long enough that missing handoffs are a structural risk. The new coverage manifest checks ordered transitions from specimen 78 through specimen 94 and names carried fields plus anti-laundering fences for each handoff.

## Non-promotions

- no policy engine;
- no rule/governance process;
- no global precedent taxonomy;
- no incident-postmortem workflow;
- no authorization, audit, legal-compliance, public-release, repair, lifecycle, or sibling-verdict authority; and
- no claim that lifecycle coverage proves semantic completeness or correctness.
