# SlopOS plus companions evaluation — pass XLVII

This pass adds one more datacube warning:
Foundry should model **what stays the same when names and groupings change** before it lets current labels become durable cube identity or default grouping axes.

## SlopOS
SlopOS already contains strong pressure in this direction.

The boundary-family map and boundary-singleton contract keep current docs visibly classified as either family-indexed or intentional singletons, and they require same-revision maintenance when a singleton should be promoted.
That is excellent archive hygiene, but it also means the current family placement is an editorial/runtime cut, not eternal member identity.
A meaning pin can survive while its discovery surface changes.

SlopOS also repeatedly distinguishes exact provider-native or local labels from portable meaning.
The confidential-computing identity and signing-metadata boundaries, for example, preserve imported labels and identifiers as exact evidence without letting them become one portable platform-wide identity schema.
That is exactly the restraint Foundry needs.

The capability-graph schema’s optional redacted `label` field adds another useful pressure point: labels can be operationally valuable while still remaining policy-controlled, partial, and smaller than durable object identity.

So for a future Foundry datacube over SlopOS surfaces:
- current boundary titles should not be the durable join key;
- current relative paths should not be the durable join key;
- family membership should not be assumed timeless when singleton promotion is an explicit design tool;
- and free-form labels should not become default dimensions until they have a reviewed boundedness story.

## Ward, Harbor, and ViewFS
Ward already carries the right nearby pressure: stable field identity should stay distinct from labels, order, and aliases.
Harbor keeps label honesty smaller than durable account/session/issuer truth.
ViewFS keeps durable object identity and lineage pressure separate from convenience names.
Together they reinforce the same lesson: current names are useful review material, but they are not enough to carry long-lived cube joins.

## Resulting judgment
Promote only the following small seam in this revision:
1. **identity anchor** — the stable thing the row/member is actually about;
2. **label snapshot** — the human-facing name/path/title observed at this cut;
3. **axis budget** — whether this label family is reviewed-bounded enough to support grouping, or should remain display-only.

Keep parked for now:
- a universal alias registry;
- path-based identity;
- automatic fuzzy rename matching;
- global tag dictionaries;
- and any promise that every imported label family is healthy as a cube dimension.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the datacube a safer path to future renamed docs, promoted singleton families, and archive-wide summaries without premature schema freeze.
