# SlopOS / companions evaluation — pass XXV

Foundry still looks justified as its own companion cube, and this pass sharpens another seam that SlopOS is culturally prepared to respect: **offer/admission truth is still smaller than direct transition validity from the subject’s exact current state.**

## What the current cube ecology keeps proving
- **SlopOS** already prefers explicit, compiled, auditable surfaces over mutable folklore. Its current ADR set repeatedly rewards pinned artifacts, compiled configuration, and versioned policy rather than ambient “latest should work” stories.
- **SlopOS** is still in the design phase, which makes this seam especially cheap to keep now. If early update/config/generation surfaces start speaking as though any exact offered basis can be taken directly from any current basis, later docs will quietly learn false symmetry and bury the real migration floor.
- **SlopOS** already has one internal warning that matters here: config generations are good, but data/schema migrations remain an operational hazard. That means direct-path validity cannot be assumed just because a later basis is desirable or even locally admissible.
- **Steward** is aligned because requested affordance and proven support are already kept apart. The same restraint should apply to update applicability.
- **Harbor** benefits because a proposed foreign destination and a valid path from the current residue are different strengths of fact.

## Pressure on Foundry
Foundry should not invent a universal dependency solver, migration engine, or giant compatibility registry.
The stronger move is to keep one specimen where:
1. an exact target basis is offered,
2. the local subject is willing to take something now,
3. a **prerequisite witness** shows whether the current state actually qualifies for the direct edge,
4. an **applicability fence** decides whether that direct edge is real,
5. and a **barrier hop** is used when the path is only valid through an intermediate basis.

## Collected but parked ideas
This pass also surfaces two good adjacent ideas that should stay parked:
- **delta fingerprint card** for exact-current-state labels sharper than human-facing version strings;
- **incompatibility chip** for compact “why this direct path is invalid” residue.

Those ideas are real, but they do not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `prerequisite witness`, `applicability fence`, or `barrier hop` unless they improve:
- one delta/checksum-sensitive specimen,
- one compatibility or minimum-version specimen,
- and one barrier-release or required-intermediate specimen.
