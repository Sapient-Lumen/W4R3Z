# SlopOS / companions evaluation — pass XXIV

Foundry still looks justified as its own companion cube, and this pass sharpens another seam that SlopOS is culturally prepared to respect: **issuer/server offer truth versus local admissibility truth**.

## What the current cube ecology keeps proving
- **SlopOS** already prefers explicit local meaning over imported “latest/current” folklore. Its attestation and approval boundaries repeatedly refuse to let imported evidence or mutable targets become portable current-truth or approval planes. That is the right house style for offer semantics too.
- **SlopOS** is still in the design phase, which makes this split especially cheap and valuable to keep now. If early update or realization docs start speaking as though offered edges were the same thing as locally admissible actions, later surfaces will quietly learn “server said so” semantics and hide real pause/hold/freshness reasons.
- **Steward** is culturally aligned: requested affordance and live proven support are already kept visibly separate. The same restraint should apply to update/realization timing.
- **Ward** benefits because freshness, attestation, and collateral status can remain imported evidence without becoming hidden “ready to take this offer” authority.
- **Harbor** benefits because an offered foreign basis and an actually crossed/returned foreign realization are different strengths of fact.

## Pressure on Foundry
Foundry should not invent a rollout service, a fleet scheduler, or a generic update-control plane.
The stronger move is to keep one specimen where:
1. an issuer/server offers one exact basis or transition,
2. a local hold prevents uptake or finalization for now,
3. an admission window later permits the same offer to proceed,
4. and current truth stays unchanged until that later step actually happens.

## Collected but parked ideas
This pass also surfaces two good adjacent ideas that should stay parked:
- **hold reason chip** for operator-visible “why not now?” residue;
- **offer freshness horizon** for stale or expired offer metadata.

Those ideas are real, but they do not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `offer hint`, `local hold`, or `admission window` unless they improve:
- one phased-rollout hinted-edge specimen,
- one maintenance-window or cluster-lock specimen,
- and one local pause/resume specimen.
