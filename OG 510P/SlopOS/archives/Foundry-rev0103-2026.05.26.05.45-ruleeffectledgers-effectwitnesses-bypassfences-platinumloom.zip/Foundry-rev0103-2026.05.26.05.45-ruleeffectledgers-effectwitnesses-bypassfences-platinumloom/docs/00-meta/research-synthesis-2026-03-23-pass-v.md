# Research synthesis — 2026-03-23 pass V

This pass focused on old mistakes that make foreign ground feel deceptively native.

## What the past keeps teaching Foundry
- OCI keeps a useful and durable split between image material and runtime material. The image index and manifest describe packaged artifacts; the runtime spec describes configuration, execution environment, and lifecycle. Foundry should keep those layers separate.
- The Wasm component model keeps package, interface, world, and canonical ABI explicit. That is exactly the kind of contract visibility Foundry needs before substrate choices or language glue start to blur semantics.
- Firecracker snapshot support makes an old truth concrete: a restorable machine is not one monolithic thing. Memory, emulated hardware state, and surrounding host integration all matter.
- SnapStart’s uniqueness guidance is a sharp anti-lesson: if many instances resume from one initialized snapshot, unique IDs, secrets, and entropy must be regenerated after initialization.
- Kata Containers continues to model a valuable honesty: something can feel container-like while actually being VM-backed and therefore carrying a different ground and failure story.
- Confidential Containers and Trustee keep attestation policy separate from secret-release policy. Foundry should steal that split and leave verdict-making to Ward.
- Qubes qrexec and Fuchsia capability routing both reinforce a broader historical lesson: cross-domain power should be routed explicitly rather than implied by co-location or packaging.

## What the cubes reinforced
- SlopOS’s foreign-cell contract already reads like Foundry’s constitution: no ambient channels, portalized interop, closed ABI surface, and policy-killable lanes.
- SlopOS’s microVM template / snapshot / resume-class / generation-witness surfaces suggest that “warm start” is actually a family of continuity claims with different honesty requirements.
- ViewFS keeps reminding Foundry that a package, a carrier, a realized object, and a resumed instance are different classes.
- Ward keeps Foundry honest by refusing to let runtime evidence become verdicts just because it is cryptographically shaped.

## Brilliant ideas worth stealing carefully
1. **Ground capability statement** — a compact statement of what the current execution ground promises: isolation class, restart guarantees, secret ingress posture, network posture, and downgrade notes.
2. **Resume humility card** — a typed statement of what continuity is preserved and what must be reacquired after restore.
3. **Generation witness export** — a small signal for “this is not the exact old live continuation,” useful both to Foundry and to Ward’s freshness logic.
4. **Foreign channel lease** — cross-domain communication objects inspired by qrexec/capability routing rather than by ambient host reachability.
5. **Contract seam ladder** — package -> interface/world -> ground -> live instance should remain a ladder of different truths, not a single object with too many fields.
6. **Policy-killable compatibility lanes** — a direct steal from SlopOS foreign-cell style: compat should be disable-able and fail closed.

## Current recommendation
Foundry should promote a second specimen centered on snapshot resume and freshness reacquire. That will test whether the current vocabulary can survive a visibly different continuity story than the bundle/world/ground specimen.
