# SlopOS companions evaluation — 2026-05-26 pass C

Question: when a SlopOS-derived semantic closure becomes a reusable Foundry rule, which sibling boundary can it accidentally cross?

## SlopOS

SlopOS may emit support-card closures, operator-console dispositions, and route outcomes. Foundry can use those as source dispositions for precedent ledgers, but the rule-promotion witness must keep the SlopOS surface, carrier digest, audience, purpose, and negative cases visible. A SlopOS closure is not a global Foundry rule.

## Ward

Ward owns appraisal and stewardship judgment. Foundry may record that a Ward preview case inspired a local refusal rule, but overgeneralization fences must block Ward preview evidence from becoming a Ward verdict, delegation approval, or stewardship decision.

## Harbor

Harbor owns crossing and correction membrane posture. Foundry may learn from a Harbor-routed disposition, but a promoted Foundry rule must not become Harbor implementation receipt, external-truth correction, or crossing approval.

## Steward

Steward owns lifecycle/effect finality. A Foundry rule that blocks reused semantic residue cannot prove an effect was finally applied, retried, replayed, or made exactly-once. Repair/lifecycle laundering remains fenced.

## Schell

Schell owns minimization, retention, and forgetting. Foundry may carry a no-reexport or sidecar obligation into rule promotion, but it does not decide deletion, retention compliance, or forgetting success.

## ViewFS

ViewFS owns trusted path, projection, and consent-sensitive surface handling. Foundry can cite ViewFS projection cases as local precedent only when the promotion scope stays projection-local or carries a widening fence.

## Helm

Helm owns repair attempts and intervention traces. Foundry can say a repair-shaped closure inspired a rule candidate, but it cannot say the repair succeeded or that operational remediation is complete.

## Result

rev0100 keeps rule promotion fixture-local. The new nouns are useful because they stop one closed SlopOS or sibling case from becoming ambient archive law. They should remain smaller than sibling authority until a second non-SlopOS consumer repeats the same failure without policy/governance capture.
