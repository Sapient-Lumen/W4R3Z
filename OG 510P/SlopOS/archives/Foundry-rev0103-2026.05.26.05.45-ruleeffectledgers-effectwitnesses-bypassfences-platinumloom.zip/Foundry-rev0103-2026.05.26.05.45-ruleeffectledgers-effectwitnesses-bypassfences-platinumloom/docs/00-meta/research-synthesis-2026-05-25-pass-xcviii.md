# Research synthesis — pass XCVIII

Rev0098 moves one step after recheck/drift. Specimen 91 can say a verification has gone stale, a public link has lost its no-reexport guard, a delegated worker is flapping, or an inherited ViewFS audience needs a fresh bind. The next failure is **unrouted semantic risk**: a drift signal can fire, yet no consumer-local owner sees the residue, the signal gets deduplicated into a generic alert, an inhibition rule hides the only actionable packet, or an acknowledgment is mistaken for resolution.

## Outside pressure

Prometheus Alertmanager is useful not because Foundry needs a pager, but because it separates alert production from grouping, deduplication, routing, silencing, and inhibition. Foundry steals the routing scars: grouping must not collapse semantic residue, inhibition must leave a fence, and delivery must not become adoption, resolution, authorization, or incident closure.

NIST SP 800-61 Rev. 3 is useful because it frames incident response as preparation, detection, response, and recovery considerations inside risk management rather than as a single magic status badge. Foundry steals the lifecycle caution while refusing incident-management capture: escalation packets only move semantic evidence to the right relying surface; they do not declare an incident, root cause, remediation, recovery, or control effectiveness.

OpenTelemetry event semantics are useful because an event is a named occurrence at an instant with attributes, not an enduring truth. Foundry steals this for routing witnesses: a route happened at a time, on a channel, for a packet/scope, with delivered residue and refused inferences. The witness is not continuing freshness.

## New seam

An **escalation packet** wraps one or more risky drift signals, source cadences, source fences, consumer/surface/audience/purpose scope, route basis, dedupe/grouping key, required receivers, required routing witnesses, and required unresolved-signal fences.

A **routing witness** records whether the packet was delivered, acknowledged, deduplicated, inhibited, quarantined, missing, misrouted, or stale under a named channel and scope. It must echo the residue that traveled and the inferences that did not.

An **unresolved-signal fence** blocks stale, risky, or misrouted signals from being treated as handled merely because a route id, queue message, dedupe key, silence, acknowledgment, or ticket-like surface exists.

## Audit/refactor

Rev0097 audited schema/fixture/checker coverage. Rev0098 adds `specimen-doc-coverage-audit-v0`: a small machine-readable coverage manifest plus checker that ties late specimens to their specimen doc, rulebook, fixture, schemas, checker, docs map, and aggregate runner entry. This closes a different drift path: prose can no longer silently add a specimen without the executable and documentation surfaces that make the noun falsifiable.

## Speculation

Foundry is approaching a semantic operations loop: detect drift, route it, fence unresolved risk, then later prove owner response. The likely future noun is not an incident, not a ticket, and not a workflow. It is a **semantic handling envelope**: a bounded packet that records which evidence was put in front of which consumer-local surface and what still cannot be inferred.

## Refusal line

Do not let escalation packets become incidents, tickets, alerts, approvals, assignments, ownership truth, audit opinions, authorization, legal compliance, public-release decisions, repair completion, lifecycle finality, or sibling verdicts. A route says evidence was carried; it does not say the world was fixed.
