# Research synthesis — pass XIV

This pass keeps Foundry narrow and learns one more thing from outside runtime systems: **foreign usefulness is often a mix of handle posture, availability posture, and restore duty**.

## Outside lessons
1. **WIT resources are explicitly exterior and can be owned or borrowed.**  
   That is a strong hint that a useful thing inside a foreign realization may still belong elsewhere. Foundry should preserve that distinction instead of flattening foreign-backed resources into local values.

2. **Fuchsia availability keeps capability expectations explicit.**  
   Capability chains can fail or degrade for routing reasons, so availability belongs in the meaning model rather than being hidden in deployment folklore.

3. **SnapStart runtime hooks make repair work first-class.**  
   Before-snapshot and after-restore hooks exist because resumed execution often needs explicit refresh, reconnect, or metadata update work. Foundry should keep those restore duties visible.

4. **OCI 1.1 still needs fallback attachment discovery in some registries.**  
   Subject/referrers are powerful, but nearby attachment truth may still degrade to a fallback index/tag scheme. Foundry should preserve that degradation as a first-class truth.

## Resulting Foundry move
Do not decide yet whether the durable noun is `owned-handle swap`, `availability floor`, or `restore duty ledger`.  
For now, keep all three alive as specimen nouns and demand that they improve:
- one borrowed/owned resource specimen,
- one restore/reinit specimen,
- and one sidecar-discovery specimen.

## Fresh ideas worth stealing
- **owned-handle swap** — a visible turn where a previously borrowed foreign handle becomes stably owned elsewhere or vice versa.
- **availability floor** — the weakest still-true capability posture after routing or product degradation.
- **restore duty ledger** — an inspectable list of reinit and repair obligations after resume.
- **fallback lease** — a temporary attachment-discovery relation that admits it was found through degraded registry support.
