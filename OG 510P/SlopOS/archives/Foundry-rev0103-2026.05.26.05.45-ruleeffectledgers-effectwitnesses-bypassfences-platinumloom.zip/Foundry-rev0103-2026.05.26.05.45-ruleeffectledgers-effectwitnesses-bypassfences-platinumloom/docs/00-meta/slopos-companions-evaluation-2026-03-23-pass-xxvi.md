# SlopOS / companions evaluation — pass XXVI

Foundry still looks justified as its own companion cube, and this pass sharpens another seam that SlopOS is already culturally prepared to respect: **last-known-good history is still smaller than what remains rollback-safe after an anti-downgrade floor ratchets forward.**

## What the current cube ecology keeps proving
- **SlopOS** already carries this seam explicitly. Its current boot-manifest and boot-selector docs already admit an optional `rollback_floor`, and its selector state only commits a pending deployment as last-known-good after an explicit success mark.
- **SlopOS** is still in the design phase, which makes this a cheap seam to preserve now. If early update/config/generation surfaces quietly imply that any remembered good basis is always rollbackable, later docs will have to unteach that false symmetry.
- **SlopOS** also already rewards exact, compiled, reviewable surfaces over ambient folklore. That is exactly the right culture for keeping rollback bars explicit instead of letting them hide behind one fuzzy “version” story.
- **ViewFS** and **Harbor** both benefit from the same restraint: remembered lineage or recoverable residue does not automatically imply currently admissible re-entry.
- **Ward** remains the right place for exported evidence or verdict logic; Foundry only needs the meaning cut that distinguishes ordinary rollback from explicitly separate rescue.

## Pressure on Foundry
Foundry should not invent a universal security-patch registry, key-lifecycle subsystem, or generalized anti-rollback policy engine.
The stronger move is to keep one specimen where:
1. a basis becomes trial-active,
2. an explicit success mark blesses it,
3. a **ratchet mark** advances a **rollback floor**,
4. older remembered bases may remain historically known but stop counting as ordinary rollback targets,
5. and any later return to older functional content must arrive through an explicit **rescue path** instead of quiet fallback folklore.

## Collected but parked ideas
This pass also surfaces two good adjacent ideas that should stay parked:
- **floor witness card** for compact monotonic-floor residue;
- **downgrade exception chip** for concise “why ordinary rollback is barred” residue.

Those ideas are real, but they do not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `rollback floor`, `ratchet mark`, or `rescue path` unless they improve:
- one A/B-style trial→success→floor-advance specimen,
- one metadata-version or expiry-ratchet specimen,
- and one rescue/recovery specimen where older functional content returns only through an explicit path.
