# Noun promotion rubric

Purpose: keep Foundry from promoting attractive datacube vocabulary into durable archive truth before the cube has earned it.

Foundry is still embryonic.
The right question is not “can we name this?” but “has this noun survived enough outside, sibling, and specimen pressure that future revisions should rely on it?”

## Promote a noun only when all of these hold
1. **Outside pressure exists**
   - at least one load-bearing external source clearly pressures the noun, or the noun cleanly summarizes a stable cross-source pattern.

2. **Sibling or neighbor pressure exists**
   - at least one companion cube or nearby SlopOS boundary becomes clearer because the distinction exists.

3. **Specimen pressure exists**
   - at least one concrete specimen flow gets smaller, sharper, or more honest because the noun exists.

4. **The noun is smaller than consequence**
   - it does not quietly swallow policy, lifecycle, serialization shape, or a whole neighboring cube.

5. **The noun still has an exit ramp**
   - if later evidence shows the noun was too broad, too implementation-shaped, or better owned elsewhere, the archive can demote or relocate it without historical amnesia.

## Temporary lanes before promotion
- **promotion candidate** — plausible noun, field, or relation under active pressure, not yet durable archive truth.
- **stability lane** — explicit posture such as candidate, development, stable, deprecated, or parked so readers know how hard to lean on a term.
- **revision hook** — exact archive/revision identifier that tells a reader what vocabulary and stability posture a status or export actually reflects.

These are intentionally process nouns first.
They are smaller than a universal schema plane.

## Anti-patterns
- promoting one export shape as if it were the meaning model;
- promoting one dashboard/status rendering as if it were canonical archive truth;
- promoting a registry before concrete extension pressure exists;
- promoting a boolean when the state is likely to grow more values later;
- promoting one pleasant research summary into permanent ontology without a second specimen.
