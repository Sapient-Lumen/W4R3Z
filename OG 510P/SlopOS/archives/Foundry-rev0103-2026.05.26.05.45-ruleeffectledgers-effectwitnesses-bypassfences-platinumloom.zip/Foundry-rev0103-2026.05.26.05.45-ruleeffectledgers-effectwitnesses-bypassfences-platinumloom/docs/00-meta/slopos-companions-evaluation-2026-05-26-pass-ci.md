# SlopOS companions evaluation — 2026-05-26 pass CI

Specimen 95 tests the point where Foundry's local rules become numerous enough to disagree.

## SlopOS

SlopOS support-card rules can require refusal when sidecars, pins, evidence ids, or recheck windows are missing. Foundry must not let a locally promoted SlopOS support-card rule override Ward, ViewFS, Harbor, or external-audit interpretation unless the overlap scope and precedence witness say so.

## Ward

Ward may consume Foundry residue as appraisal input. A Ward preview caveat rule can be locally valid while colliding with a SlopOS export refusal rule. Foundry must carry the collision without turning precedence into Ward verdict or appraisal authority.

## ViewFS

ViewFS projection and trusted-path rules can collide with Foundry export/sidecar rules when projections hide or synthesize surfaces. Foundry should preserve projection scope and ambiguity fences without claiming ViewFS custody or filesystem truth.

## Harbor

Harbor correction and outside-fact aftermath rules can collide with Foundry stale-precedent or public-link rules. Foundry should treat Harbor as a receiver of residue, not the source of Foundry precedence unless a witness binds the exact handoff scope.

## Steward, Schell, Helm

Steward lifecycle states, Schell retention/minimization pressure, and Helm repair traces can inform collision inputs, but Foundry precedence is not lifecycle finality, retention authority, deletion proof, repair success, or custody.

## External audit notebook

The external-audit notebook remains useful as a non-SlopOS consumer because it can have different precedence preferences: audit-preview warnings may be allowed where public-link exports must refuse. Foundry should preserve that divergence rather than collapse it into one global rule order.
