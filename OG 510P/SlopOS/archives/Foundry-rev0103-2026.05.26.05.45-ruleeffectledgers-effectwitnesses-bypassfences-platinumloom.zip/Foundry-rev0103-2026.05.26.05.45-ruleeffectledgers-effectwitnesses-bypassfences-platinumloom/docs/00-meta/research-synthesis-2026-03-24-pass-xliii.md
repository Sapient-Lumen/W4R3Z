# Research synthesis — pass XLIII

This pass stays deliberately conservative.
Foundry should **not** freeze a universal datacube schema while SlopOS and Foundry are both still in design motion.
But it should steal a few excellent process moves from mature systems so future noun promotion is safer.

The smallest durable seam from this pass is:
- **promotion candidate** — a plausible noun, field, or relation under pressure but not yet permanent archive truth;
- **stability lane** — explicit posture such as candidate, development, stable, deprecated, or parked;
- **revision hook** — an exact revision/schema/export identity that says what vocabulary a surface actually reflects.

These are intentionally process/control-surface nouns.
They are smaller than a full semantic layer or giant registry.

## Lessons we must learn from the past

### 1) Evolution happens whether the archive plans for it or not
OpenTelemetry schemas are useful because they make versioned schema identity and transformations explicit instead of pretending names never change.
That is the lesson to steal, not the dream of a universal ontology.
Foundry should be able to say which revision or vocabulary an export reflects, and later describe a transform if one ever becomes necessary.

### 2) Development truth and stable truth must not be confused
OpenTelemetry semantic conventions explicitly mark some conventions as development, and its stability guidance separates development, stable, deprecated, and removed surfaces.
Kubernetes teaches the same lesson with alpha/beta/GA and feature-gate posture.
Foundry should stop short of promising that every attractive noun is stable the moment it appears in one revision.

### 3) Human-friendly export is not the same as safe evolution surface
Protobuf best practices and ProtoJSON guidance both warn against flattening storage shape, API/wire shape, and friendly JSON shape into one forever contract.
That is especially important for a datacube: the first exported JSON should not accidentally become the permanent ontology.

### 4) Registries are expensive; earn them
W3C design principles argue for explicit extension points and clear unknown-extension behavior, but they also say to prefer ordinary main-spec evolution when possible instead of inventing registries too early.
GitLab’s architecture guidance says to use the simplest process that works.
Foundry should therefore create registries late, not early.

### 5) Status must say what revision it reflects
Kubernetes’ observedGeneration lesson is bigger than Kubernetes.
Any read model, summary surface, or exported status card that can lag authoring intent should say what revision/generation it has actually caught up to.
That is exactly what a revision hook is for.

### 6) Unknown is healthier than false certainty
Protobuf’s guidance to reserve a zero enum value for UNKNOWN or UNSPECIFIED is the right instinct for an embryonic datacube.
If a lane, reason family, or posture class may grow later, the cube should leave itself an honest unknown/unspecified posture instead of forcing a boolean or fake final taxonomy.

## What to steal now
- a lightweight **revision hook** similar in spirit to schema URLs or observed-generation markers;
- explicit **stability lanes** so candidate nouns do not silently masquerade as settled truth;
- an **unknown/unspecified** default posture wherever future values are plausible;
- explicit **deprecation/parking** posture so retiring or delaying a noun is visible rather than erased;
- **separate storage, export, and human-summary surfaces** so one convenience format does not own the whole cube.

## What to keep parked
Do not yet promote:
- a universal semantic layer;
- a giant field registry;
- machine-negotiated extension catalogs;
- automatic transform engines;
- or an irreversible candidate/stable taxonomy beyond the minimal lane labels the repo needs right now.

## Resulting recommendation
The next healthy move is not “design the datacube.”
It is to make noun promotion and export/status revisioning more explicit while leaving the permanent ontology mostly unfrozen.
That keeps Foundry aligned with SlopOS’s own design-phase reality.
