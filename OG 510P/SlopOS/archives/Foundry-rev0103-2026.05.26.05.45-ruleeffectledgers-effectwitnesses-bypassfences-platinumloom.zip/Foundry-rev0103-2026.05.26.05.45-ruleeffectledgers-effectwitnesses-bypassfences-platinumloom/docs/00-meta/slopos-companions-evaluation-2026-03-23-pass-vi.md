# SlopOS and companion-cube evaluation — 2026-03-23 pass VI

## What SlopOS keeps teaching Foundry
- `foreign-cell-contract.md` remains the strongest reason this cube exists: compat and foreign realization are first-class meaning problems.
- `microvm-template-resume-class-posture-v0.md` demonstrates a discipline worth stealing whole: normalize heterogeneity before the cut, then resume only within a reviewed class.
- `microvm-attestation-reacquire-posture-v0.md` strongly reinforces that clone/restore invalidates freshness-bound sessions and that reacquire is healthier than magical continuity.
- `host-guest-channel-posture-v0.md` and the component-manifest surfaces point toward explicit channel and contract nouns rather than ambient reachability.
- `artifact-resolution-posture-v0.md` keeps the shipped basis separate from the live realization path.

## What the siblings sharpened this pass
- **Harbor** reinforces that entry into foreign ground should export honest membrane receipts instead of quietly upgrading the route into native success.
- **Ward** reinforces that runtime measurements or attestations are evidence, not the final local consequence.
- **Schell** reinforces explicit adoption gates and visible helper status.
- **ViewFS** reinforces that bundles, realized instances, and durable references are different object strengths.
- **Helm** reinforces that visibly foreign surfaces are a product virtue, not a failure.

## Pass-VI result
Foundry should not promote a giant universal runtime or substrate object.

The sharper move is:
- add a specimen around explicit foreign service routing with typed rights;
- keep artifact basis, declared contract world, runtime ground, and live realization separate;
- keep generation-change and post-restore reacquire visible;
- and keep foreign adoption as an explicit, inspectable posture rather than an accidental side effect of repeated success.
