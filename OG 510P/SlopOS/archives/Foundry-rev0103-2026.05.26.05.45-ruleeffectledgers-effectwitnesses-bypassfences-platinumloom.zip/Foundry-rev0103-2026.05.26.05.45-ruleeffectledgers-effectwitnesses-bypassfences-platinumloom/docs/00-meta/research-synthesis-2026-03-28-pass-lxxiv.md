# Research synthesis — pass LXXIV

This pass stays conservative on purpose.
Foundry still should **not** freeze one vendor-shaped semantic-layer taxonomy, one automatic aggregate-awareness doctrine, or one flattering rule that a mutable branch/head is “close enough” to the exact source cut used for a durable answer.

But the outside systems and companion cubes now agree on one sharper lesson: **a design-phase datacube needs a thin semantic spine, explicit serving-lane humility, and pinned-cut discipline before it deserves any larger semantic-layer or acceleration story.**

This pass deliberately does **not** add specimen 70.
The pressure is real, but the safest move today is to collect the ideas, keep them parked, and require one more concrete SlopOS-side consumer before promoting another noun family.

## Lessons we must learn from the past

### 1) Thin semantic spines age better than giant front-door taxonomies
The current dbt Semantic Layer keeps semantic models, entities, dimensions, and measures explicit enough to drive query generation, but even dbt’s own recent modernization work is a reminder that the authoring taxonomy can still move.
Foundry should steal the **thin semantic spine** lesson, not the product-shaped noun set.

### 2) Join safety is semantic truth, not optimizer trivia
Current dbt join logic and Looker symmetric-aggregate guidance both treat fanout as a meaning hazard rather than a cosmetic SQL detail.
That is the right lesson for Foundry.
A visible answer is only honest once counted-once posture, fanout pressure, and regroupability are explicit.

### 3) Pre-aggregations are serving lanes, not canonical truth
Cube says pre-aggregations are materialized query results selected through aggregate-awareness logic.
Druid says rollup can reduce row counts dramatically, but you lose the ability to query individual events.
That is exactly the design warning Foundry should keep stealing: fast lanes, rollups, and summary tables are often healthy, but they are **downstream serving artifacts**, not self-justifying ontology.

### 4) Matching logic belongs to the serve path, not the fact meaning
Cube’s matching rules check whether leaf measures are additive, whether every member is present, and whether one-to-many multiplication would make the pre-aggregation dishonest.
That means “this summary served the query” is already a smaller claim than “this is the archive’s primary fact family.”
Foundry should preserve that separation instead of letting serving success silently promote an acceleration artifact into datacube law.

### 5) Mutable heads and immutable cuts are different truths
Iceberg’s spec says branches are mutable named references while tags label individual snapshots.
That is the lesson Foundry must keep: a floating selector, default head, or current branch is useful intent, but a durable answer still needs a **pinned cut**.
Historical tags and immutable snapshot references are stronger than moving heads when replay or audit really matters.

### 6) Temporality is semantic, not formatting
OpenTelemetry distinguishes cumulative and delta temporality explicitly.
Prometheus distinguishes counters, gauges, histograms, and summaries, and warns that some operations stop making sense when values can go down or reset.
Foundry already has useful accumulation/reset discipline, but this pass reinforces that a numeric-looking lane still needs explicit temporality posture before consumers pretend it is just “a number.”

### 7) Assertions and lineage help verify or replay a result without becoming the result
OpenLineage keeps job, dataset, and run metadata explicit, and recent run facets make execution parameters first-class derivation residue.
DataHub keeps assertions as contract-verification artifacts rather than silently rewriting the dataset into generic healthy/unhealthy truth.
Foundry should keep stealing that split: derivation and validation are valuable, but they stay smaller than subject truth.

## What to steal now
- a **thin semantic spine** so stable member identity, counted-once posture, and replay cuts can stay explicit without freezing a giant semantic-layer ontology;
- a parked **serving lane** idea for when a value is being served from a pre-aggregation, rollup, cache, or summary artifact rather than from row-preserving base truth;
- a parked **acceleration witness** idea for the exact summary/materialization/matching path that served a result;
- a parked **raw fallback fence** idea for whether row-preserving drill-through still exists, exists cold, or is intentionally absent;
- a parked **mutable-head fence** idea so branch/head/default-latest selection intent stays visibly weaker than the exact pinned cut used for one durable answer;
- a parked **historical-tag witness** idea for intentionally retained replay cuts that are meant to survive later head movement;
- a standing habit of keeping **assertions**, **lineage/run facets**, and **validation outcomes** visibly smaller than the fact/result family they comment on.

## What stays parked
- no universal semantic-layer taxonomy;
- no promise that aggregate-aware tables, pre-aggregations, or rollups become canonical cube families by default;
- no rule that “current branch” or “latest head” is sufficient replay truth;
- no giant lineage/assertion/quality mega-plane;
- no specimen 70 until one concrete SlopOS-side consumer and one sibling-cube consumer both need the same new seam.
