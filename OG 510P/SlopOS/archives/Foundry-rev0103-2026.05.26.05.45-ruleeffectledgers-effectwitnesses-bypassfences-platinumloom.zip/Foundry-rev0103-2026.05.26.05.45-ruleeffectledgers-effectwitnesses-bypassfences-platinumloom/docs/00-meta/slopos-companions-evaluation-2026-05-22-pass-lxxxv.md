# SlopOS and companions evaluation — 2026-05-22 pass LXXXV

Focus: whether Foundry can catch semantic regressions across revisions after sidecars and refusal receipts already pass local egress checks.

## SlopOS pressure

SlopOS has accumulated a strong instinct for corpus-shaped proof: boundary indexes, singleton contracts, append/truncation chains, checkpoint/resume evidence, and mutation corpora make failures inspectable instead of relying on prose. Foundry should mirror that style for datacube egress residue. A sidecar or refusal receipt must not silently change meaning just because its file still validates.

The pressure is not that Foundry should import SlopOS verification machinery wholesale. The pressure is smaller: Foundry should carry a compact semantic-diff fixture that says what changed between Foundry revisions, which invariants are locked, and which tampered variants must fail.

## Companion boundaries

| Companion | Semantic regression interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| Ward | may consume a regression lock as evidence that an appraisal surface did not silently shed residue | Ward still owns appraisal/verdict |
| Harbor | may connect a semantic regression to outside-fact correction or import aftermath | Harbor still owns membrane/status authority |
| Steward | may treat regression locks as lifecycle evidence around retry/replay result surfaces | Steward still owns effect finality and lifecycle state |
| Schell | may require a regression refusal when minimization/drill-through posture changes | Schell still owns forgetting/minimization authority |
| ViewFS | may expose semantic-diff artifacts as projection events or sidecar companions | ViewFS still owns file/object identity and trusted paths |
| Helm | may use tamper failures in repair traces when an operator artifact becomes unsafe | Helm still owns repair custody and intervention consequence |
| SlopOS | may consume regression artifacts beside CH-* support-card exports | SlopOS still owns SlopOS boundary families and proof claims |
| External audit notebook | may consume the same semantic-diff/lock fields without being a SlopOS surface | does not promote Foundry into a BI, audit, or policy product |

## What changed in this pass

- Added specimen 79 for semantic diff manifests, regression locks, and tamper corpus gates.
- Added a semantic regression rulebook so compatibility claims are readable before they appear in fixtures.
- Added v0 schemas for semantic diff manifests and regression locks.
- Added a specimen 79 fixture with baseline/candidate artifacts, one non-SlopOS consumer, regression locks, migration witnesses, and tamper cases.
- Added `check_foundry_semantic_regression.py` and wired it into `make check`.
- Added RFC 8785 and RFC 6902 as load-bearing pressure while keeping Foundry smaller than a canonicalization, patching, or migration framework.

## Recommendation

Future Foundry changes that alter sidecars, egress manifests, refusal receipts, or their rule suites should leave a semantic diff manifest. A successful schema check is not enough; either the change is additive and witnessed, breaking and refused, or migration-scoped by a witness that says exactly which consumer/cut can survive it.
