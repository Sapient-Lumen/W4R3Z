# SlopOS + companions evaluation — pass LVI

This pass checks whether **arbitration recipe, ambiguity class, and dissent retention** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal golden-record plane, a native cross-artifact preference algebra, or a built-in latest-wins policy.

## Why SlopOS pressures this seam now

### 1) SlopOS repeatedly refuses native union/preference/completeness rules across evidence sets
The provenance-container-selection, provenance-evidence-set, and SBOM/VEX evidence-set boundaries all say that multiple exact artifacts do **not** become one native closure and that cross-artifact union, fallback, preference, and completeness remain verifier-local.
That is already arbitration pressure, just expressed as a refusal to pretend the answer is built in.

### 2) SlopOS verification posture keeps verdicts consumer-local instead of portable authority
`verification-verdict-boundary-v0.md` keeps verification consumer-local and says imported summaries stay evidence rather than becoming a native verified-good, waiver, or latest-verified plane.
That strongly argues for an explicit **ambiguity class** instead of a cheerful winner bit.

### 3) SlopOS repeatedly rejects latest-wins semantics where identity or evidence revisions exist
Release identity, VEX document supersession, SBOM document supersession, update posture, and namecert metadata/revocation boundaries all refuse metadata-driven latest-wins or hidden replacement semantics.
That pressures Foundry toward an explicit **arbitration recipe** whenever one row/view chooses among competing candidates.

### 4) SlopOS still needs some compact way to describe reconciled outputs when they do occur
Even without a native preference plane, future Foundry read models will likely reconcile imported provenance, status summaries, duplicate observations, or query-shaped support views.
Those outputs should say whether they were event-time-picked, source-preferred, manually certified, or left unresolved.

## What to steal into Foundry

### arbitration recipe
A compact witness for how competing candidates were handled.
Examples:
- authoritative-source precedence,
- latest-by-event-time,
- latest-by-commit-time,
- attribute-level survivorship,
- manual certification,
- or fail-closed/no-merge.

This is smaller than a global policy engine.
It just keeps the visible row from sounding self-evident.

### ambiguity class
A compact witness for whether reconciliation was:
- unique,
- tie-broken,
- plural-but-carried,
- underdetermined,
- rejected-as-ambiguous,
- or manually-resolved.

This is smaller than a full conflict-management product.
It just stops one row from laundering unresolved pressure into fake certainty.

### dissent retention
A compact witness for whether losing candidates remain:
- fully inspectable,
- retained as compressed lineage,
- retained only as counts/hashes,
- or dropped.

This is smaller than a full lineage graph.
It simply tells consumers whether the disagreement is still recoverable.

## Why this seam is small enough now
It does **not** require:
- a universal survivorship engine;
- one precedence hierarchy for every source family;
- a mandatory golden-record abstraction;
- or automatic policy selection from imported metadata.

It only says that once Foundry emits a reconciled or winner-shaped value, it should preserve:
1. **how** the winner was chosen,
2. **whether** the choice was actually unique or ambiguous,
3. and **what happened** to the losing candidates.

## Recommended Foundry posture
Promote **arbitration recipe**, **ambiguity class**, and **dissent retention** as a narrow honesty seam for reconciled or winner-shaped values.
Keep the larger MDM, golden-record, and global-precedence questions parked.

This matches current SlopOS discipline well: SlopOS already refuses native union/preference/latest-wins semantics across several evidence families, already keeps verdicts consumer-local, and already treats imported summaries as evidence rather than portable authority.
