# Bibliography

- **EXT-OCI-IMAGE-SPEC** — OCI Image Specification — https://specs.opencontainers.org/image-spec/
- **EXT-OCI-IMAGE-INDEX** — OCI Image Index Specification — https://specs.opencontainers.org/image-spec/image-index/
- **EXT-OCI-RUNTIME-SPEC** — OCI Runtime Specification — https://github.com/opencontainers/runtime-spec
- **EXT-WASM-WORLDS** — WIT Worlds — https://component-model.bytecodealliance.org/design/worlds.html
- **EXT-WASM-INTERFACES** — WIT Interfaces — https://component-model.bytecodealliance.org/design/interfaces.html
- **EXT-WASM-PACKAGES** — WIT Packages — https://component-model.bytecodealliance.org/design/packages.html
- **EXT-WASM-CANONICAL-ABI** — Canonical ABI — https://component-model.bytecodealliance.org/advanced/canonical-abi.html
- **EXT-WASM-WIT** — WIT overview — https://component-model.bytecodealliance.org/design/wit.html
- **EXT-KATA** — Kata Containers — https://katacontainers.io/
- **EXT-COCO-ATTEST** — Confidential Containers attestation with Trustee — https://confidentialcontainers.org/docs/attestation/
- **EXT-COCO-POLICIES** — Confidential Containers Trustee policies — https://confidentialcontainers.org/docs/attestation/policies/
- **EXT-FIRECRACKER-SNAPSHOT** — Firecracker snapshot support — https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/snapshot-support.md
- **EXT-FIRECRACKER-VMGENID** — Firecracker random for clones / VMGenID — https://github.com/firecracker-microvm/firecracker/blob/main/docs/snapshotting/random-for-clones.md
- **EXT-AWS-SNAPSTART-UNIQUENESS** — AWS Lambda SnapStart uniqueness guidance — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-uniqueness.html
- **EXT-OCI-RUNTIME-CONFIG** — OCI Runtime Spec config — https://specs.opencontainers.org/runtime-spec/config/
- **EXT-QUbes-QREXEC** — Qubes qrexec secure communication — https://doc.qubes-os.org/en/latest/developer/services/qrexec.html
- **EXT-FUCHSIA-CAPABILITIES** — Fuchsia component capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities
- **EXT-FUCHSIA-VIRT-ROUTING** — Fuchsia virtualization capability routing RFC — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0210_virtualization_capability_routing
- **EXT-WASI-INTERFACES** — WASI interfaces and component model — https://wasi.dev/interfaces
- **EXT-OCI-IMAGE-INDEX-2025** — OCI Image Index Spec — https://specs.opencontainers.org/image-spec/image-index/
- **EXT-OCI-RUNTIME-BUNDLE-2025** — OCI Runtime Bundle Spec — https://specs.opencontainers.org/runtime-spec/bundle/?v=v1.3.0
- **EXT-WASM-COMPONENT-MODEL** — The WebAssembly Component Model — https://component-model.bytecodealliance.org/
- **EXT-QUBES-QREXEC** — Qubes OS qrexec — https://doc.qubes-os.org/en/latest/developer/services/qrexec.html
- **EXT-LAMBDA-SNAPSTART-RESTORE** — AWS Lambda execution environment lifecycle / SnapStart restore — https://docs.aws.amazon.com/lambda/latest/dg/lambda-runtime-environment.html
- **EXT-COCO-INITDATA** — Confidential Containers Init-Data — https://confidentialcontainers.org/docs/features/initdata/
- **EXT-COCO-INITDATA-2026** — Confidential Containers init-data — https://confidentialcontainers.org/docs/features/initdata/
- **EXT-COCO-POLICIES-2026** — Confidential Containers Trustee policies — https://confidentialcontainers.org/docs/attestation/policies/
- **EXT-FIRECRACKER-NET-CLONES** — Firecracker network connectivity for clones — https://cocalc.com/github/aos/firecracker/blob/main/docs/snapshotting/network-for-clones.md

- **EXT-OCI-REFERRERS** — ORAS artifacts spec, referrers API — https://github.com/oras-project/artifacts-spec/blob/main/manifest-referrers-api.md

- **EXT-WIT-RESOURCES** — Using WIT resources — https://component-model.bytecodealliance.org/using-wit-resources.html
- **EXT-FUCHSIA-CAPABILITY-AVAILABILITY** — Fuchsia capability availability — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/availability
- **EXT-FUCHSIA-VIRT-ROUTING-2025** — Fuchsia RFC 0210, virtualization capability routing — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0210_virtualization_capability_routing
- **EXT-FUCHSIA-CONFIG-CAPABILITIES** — Fuchsia configuration capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/configuration

- **EXT-OCI-11-BLOG-2024** — OCI Image and Distribution Specs v1.1 Releases — https://opencontainers.org/posts/blog/2024-03-13-image-and-distribution-1-1/

- **EXT-AWS-SNAPSTART-HOOKS** — AWS Lambda SnapStart runtime hooks — https://docs.aws.amazon.com/lambda/latest/dg/snapstart-runtime-hooks.html

- **EXT-OCI-DISTRIBUTION-SPEC-REFERRERS** — OCI Distribution Spec referrers behavior — https://github.com/opencontainers/distribution-spec/blob/main/spec.md
- **EXT-WIT-REFERENCE** — WIT reference — https://component-model.bytecodealliance.org/design/wit.html
- **EXT-FUCHSIA-BUILD-COMPONENTS** — Fuchsia component build and source availability — https://fuchsia.dev/fuchsia-src/development/components/build
- **EXT-COCO-DESIGN-OVERVIEW** — Confidential Containers design overview — https://confidentialcontainers.org/docs/architecture/design-overview/

- **EXT-STARGZ-SNAPSHOTTER** — containerd stargz-snapshotter overview — https://github.com/containerd/stargz-snapshotter
- **EXT-NERDCTL-STARGZ** — containerd/nerdctl lazy-pulling with Stargz Snapshotter — https://github.com/containerd/nerdctl/blob/main/docs/stargz.md
- **EXT-COMPOSEFS** — composefs project overview — https://github.com/composefs/composefs
- **EXT-FS-VERITY** — Linux kernel fs-verity documentation — https://docs.kernel.org/filesystems/fsverity.html
- **EXT-NYDUS-DESIGN** — Nydus design overview — https://github.com/dragonflyoss/nydus/blob/master/docs/nydus-design.md

- **EXT-NIX-PROFILES** — Nix profiles and generations — https://nix.dev/manual/nix/2.25/package-management/profiles
- **EXT-NIX-PROFILE-ROLLBACK** — Nix profile rollback — https://nix.dev/manual/nix/2.25/command-ref/new-cli/nix3-profile-rollback
- **EXT-OSTREE-DEPLOYMENTS** — OSTree deployments and staged deployments — https://ostreedev.github.io/ostree/deployment/
- **EXT-BOOTC-UPGRADES** — bootc upgrade and rollback — https://bootc-dev.github.io/bootc/upgrades.html

- **EXT-SYSTEMD-AUTO-BOOT-ASSESS** — systemd Automatic Boot Assessment — https://systemd.io/AUTOMATIC_BOOT_ASSESSMENT/
- **EXT-SYSTEMD-BLESS-BOOT** — systemd-bless-boot.service — https://www.freedesktop.org/software/systemd/man/systemd-bless-boot.service.html
- **EXT-RAUC-BASICS** — RAUC basics / boot confirmation and fallback — https://rauc.readthedocs.io/en/latest/basic.html
- **EXT-CHROMEOS-BOOT-DESIGN** — Chrome OS user-land boot design — https://www.chromium.org/chromium-os/chromiumos-design-docs/boot-design/
- **EXT-ANDROID-BOOTLOADER-UPDATING** — Android OTA bootloader / slots updating — https://source.android.com/docs/core/architecture/bootloader/updating
- **EXT-ANDROID-VERIFIEDBOOT-FLOW** — Android Verified Boot flow — https://source.android.com/docs/security/features/verifiedboot/boot-flow
- **EXT-ANDROID-UPDATE-ENGINE** — Android/ChromeOS update_engine overview — https://android.googlesource.com/platform/system/update_engine/
- **EXT-MENDER-INTERFACE-PROTOCOL** — Mender interface protocol — https://docs.mender.io/orchestrate-updates/interface-protocol
- **EXT-SYSTEMD-SYSUPDATE-TRANSFER** — sysupdate.d target/transfer rules — https://man7.org/linux/man-pages/man5/sysupdate.d.5.html
- **EXT-UPTANE-BEST-PRACTICES** — Uptane deployment best practices — https://uptane.org/docs/latest/deployment/best-practices
- **EXT-TUF-SPEC-2026** — TUF specification (latest) — https://theupdateframework.github.io/specification/latest/
- **EXT-TUF-SECURITY** — TUF security goals — https://theupdateframework.io/docs/security/

- **EXT-SYSTEMD-SYSEXT** — systemd-sysext / confext manual — https://man7.org/linux/man-pages/man8/systemd-sysext.8.html
- **EXT-SYSTEMD-CONFEXT** — systemd confext behavior — https://man7.org/linux/man-pages/man8/systemd-sysext.8.html
- **EXT-FUCHSIA-CAPABILITIES-AVAILABILITY** — Fuchsia capability availability — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/availability

- **EXT-RAUC-REFERENCE** — RAUC reference / prevent-late-fallback — https://rauc.readthedocs.io/en/latest/reference.html
- **EXT-OMAHA-FUNCTIONAL-SPEC** — Chromium updater functional specification — https://chromium.googlesource.com/chromium/src/+/HEAD/docs/updater/functional_spec.md
- **EXT-NIX-CHANNELS** — Nix channels — https://nix.dev/manual/nix/2.19/command-ref/nix-channel
- **EXT-NIX-PROFILES-FILES** — Nix profiles filesystem layout — https://nix.dev/manual/nix/2.25/command-ref/files/profiles
- **EXT-NIX-SWITCH-GENERATION** — Nix switch generation — https://nix.dev/manual/nix/2.27/command-ref/nix-env/switch-generation
- **EXT-OSTREE-TERMINOLOGY** — OSTree terminology — https://ostreedev.github.io/ostree/man/ostree.html
- **EXT-RHEL-EDGE-OSTREE-TERMS** — RHEL Edge OSTree terminology — https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/9/html/composing_installing_and_managing_rhel_for_edge_images/edge-terminology-and-commands_composing-installing-managing-rhel-for-edge-images
- **EXT-CHROME-UPDATES-MANAGE** — Chrome Enterprise update management — https://support.google.com/chrome/a/answer/9838774?hl=en
- **EXT-OMAHA-PROTOCOL-31** — Chromium updater protocol 3.1 — https://chromium.googlesource.com/chromium/src.git/+/master/docs/updater/protocol_3_1.md
- **EXT-ZINCATI-AUTO-UPDATES** — Zincati auto-updates and phased rollout — https://coreos.github.io/zincati/usage/auto-updates/
- **EXT-ZINCATI-UPDATE-STRATEGY** — Zincati update strategies and maintenance windows — https://coreos.github.io/zincati/usage/updates-strategy/
- **EXT-ZINCATI-CINCINNATI** — Cincinnati protocol for Fedora CoreOS — https://coreos.github.io/zincati/development/cincinnati/protocol/
- **EXT-ZINCATI-AGENT-IDENTITY** — Zincati agent identity and rollout wariness — https://coreos.github.io/zincati/usage/agent-identity/
- **EXT-MENDER-DEVICE-SIDE-API** — Mender device-side API / synchronized updates — https://docs.mender.io/client-installation/use-the-device-side-api
- **EXT-MENDER-UPDATE-MGMT-API** — Mender update management API / update control map — https://docs.mender.io/device-side-api/io.mender.update1

- **EXT-ZINCATI-OVERVIEW** — Zincati overview — https://coreos.github.io/zincati/
- **EXT-MENDER-ARTIFACT** — Mender Artifact overview — https://docs.mender.io/overview/artifact
- **EXT-SPARKLE-PUBLISHING** — Sparkle publishing an update — https://sparkle-project.org/documentation/publishing/
- **EXT-ANDROID-VERIFIEDBOOT** — Verified Boot overview and rollback protection — https://source.android.com/docs/security/features/verifiedboot
- **EXT-ANDROID-AB-FAQ** — Android A/B FAQ / rollback protection timing — https://source.android.com/docs/core/ota/ab/ab_faqs
- **EXT-ANDROID-VERSION-BINDING** — Android KeyMint / version binding and key ratchet — https://source.android.com/docs/security/features/keystore/version-binding

- **EXT-OSTREE-VAR-HANDLING** — OSTree and /var handling — https://ostreedev.github.io/ostree/var/
- **EXT-RAUC-DATA-MIGRATION** — RAUC data storage and migration — https://rauc.readthedocs.io/en/latest/advanced.html
- **EXT-MENDER-STATE-SCRIPTS** — Mender state scripts — https://docs.mender.io/artifact-creation/state-scripts
- **EXT-MENDER-PERSISTENT-DATA** — Mender OS updates overview / persistent data partition — https://docs.mender.io/operating-system-updates-debian-family/overview
- **EXT-CHROMEOS-UPDATE-ENGINE-README** — ChromeOS update_engine README — https://chromium.googlesource.com/aosp/platform/system/update_engine/+/HEAD/README.md
- **EXT-K8S-DEPRECATION-POLICY** — Kubernetes deprecation policy — https://kubernetes.io/docs/reference/using-api/deprecation-policy/
- **EXT-K8S-STORAGE-VERSIONS** — Kubernetes storage versions — https://kubernetes.io/docs/concepts/overview/working-with-objects/storage-version/
- **EXT-K8S-STORAGE-VERSION-MIGRATION** — Kubernetes storage version migration — https://kubernetes.io/docs/tasks/manage-kubernetes-objects/storage-version-migration/
- **EXT-NIX-GCROOTS** — Nix garbage collector roots — https://nix.dev/manual/nix/2.25/package-management/garbage-collector-roots
- **EXT-NIX-GC** — Nix garbage collection and old generations — https://nix.dev/manual/nix/2.26/package-management/garbage-collection
- **EXT-OSTREE-ADMIN-PIN** — OSTree admin pin — https://man.archlinux.org/man/extra/ostree/ostree-admin-pin.1.en
- **EXT-CONTAINERD-LEASES** — containerd garbage collection and leases — https://github.com/containerd/containerd/blob/main/docs/garbage-collection.md
- **EXT-ZFS-HOLD** — OpenZFS snapshot holds — https://openzfs.github.io/openzfs-docs/man/master/8/zfs-hold.8.html
- **EXT-K8S-FINALIZERS** — Kubernetes finalizers — https://kubernetes.io/docs/concepts/overview/working-with-objects/finalizers/
- **EXT-LINUX-RCU-CONCEPTS** — Linux kernel RCU concepts — https://docs.kernel.org/RCU/rcu.html
- **EXT-ENVOY-DRAINING** — Envoy draining operations — https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/operations/draining
- **EXT-ENVOY-HOT-RESTART** — Envoy hot restart — https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/operations/hot_restart
- **EXT-K8S-ENDPOINTSLICES** — Kubernetes EndpointSlices conditions — https://kubernetes.io/docs/concepts/services-networking/endpoint-slices/
- **EXT-K8S-POD-LIFECYCLE** — Kubernetes Pod lifecycle and termination — https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/

- **EXT-VSS** — Volume Shadow Copy Service (VSS) — https://learn.microsoft.com/en-us/windows-server/storage/file-server/volume-shadow-copy-service
- **EXT-VSS-NO-WRITER** — VSS backups without writer participation — https://learn.microsoft.com/en-us/windows/win32/vss/backups-without-writer-participation
- **EXT-FSFREEZE** — fsfreeze manual page — https://man7.org/linux/man-pages/man8/fsfreeze.8.html
- **EXT-POSTGRES-FILESYSTEM-BACKUP** — PostgreSQL file system level backup — https://www.postgresql.org/docs/current/backup-file.html
- **EXT-K8S-VOLUME-SNAPSHOT-GA** — Kubernetes volume snapshots GA note on app consistency — https://kubernetes.io/blog/2020/12/10/kubernetes-1.20-volume-snapshot-moves-to-ga/
- **EXT-K8S-VOLUME-GROUP-SNAPSHOT** — Kubernetes volume group snapshots — https://kubernetes.io/blog/2024/12/18/kubernetes-1-32-volume-group-snapshot-beta/
- **EXT-CRIU-WHAT-CANNOT-BE-CHECKPOINTED** — CRIU limits on checkpointability — https://criu.org/What_cannot_be_checkpointed

- **EXT-K8S-POD-GENERATION** — Kubernetes Pod generation and observedGeneration — https://kubernetes.io/docs/concepts/workloads/pods/
- **EXT-K8S-KSTATUS** — Kubernetes cli-utils kstatus observedGeneration guidance — https://github.com/kubernetes-sigs/cli-utils/blob/master/pkg/kstatus/README.md
- **EXT-ENVOY-XDS-PROTOCOL** — Envoy xDS REST and gRPC protocol — https://www.envoyproxy.io/docs/envoy/latest/api-docs/xds_protocol
- **EXT-RFC9110-202** — HTTP 202 Accepted semantics — https://www.rfc-editor.org/rfc/rfc9110.html
- **EXT-ETCD-STATUS-INDICES** — etcd status response committed and applied indexes — https://etcd.io/docs/v3.3/dev-guide/api_reference_v3/

- **EXT-ETCD-WATCH-PROGRESS** — etcd watch progress and compacted revisions — https://etcd.io/docs/v3.3/dev-guide/interacting_v3/
- **EXT-ETCD-MAINTENANCE** — etcd maintenance, snapshot-count, and slow-follower snapshot replacement — https://etcd.io/docs/v3.5/op-guide/maintenance/
- **EXT-ETCD-API-GUARANTEES** — etcd API guarantees, resumable watches, and operation completion — https://etcd.io/docs/v3.4/learning/api_guarantees/
- **EXT-POSTGRES-WARM-STANDBY** — PostgreSQL warm standby and replication lag / reinitialization — https://www.postgresql.org/docs/current/warm-standby.html
- **EXT-POSTGRES-FUNCTIONS-ADMIN** — PostgreSQL WAL position functions — https://www.postgresql.org/docs/current/functions-admin.html
- **EXT-POSTGRES-RUNTIME-REPLICATION** — PostgreSQL replication retention and slot lag limits — https://www.postgresql.org/docs/current/runtime-config-replication.html


- **EXT-KAFKA-CONSUMER-CONFIG** — Apache Kafka consumer isolation.level / LSO docs — https://kafka.apache.org/41/configuration/consumer-configs/
- **EXT-ENVOY-LDS** — Envoy listener discovery service and warming-to-active semantics — https://www.envoyproxy.io/docs/envoy/latest/configuration/listeners/lds
- **EXT-ENVOY-CLUSTER-MANAGER** — Envoy cluster warming and active swap semantics — https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/upstream/cluster_manager
- **EXT-COCKROACH-TRANSACTION-LAYER** — CockroachDB transaction layer / closed timestamps — https://www.cockroachlabs.com/docs/stable/architecture/transaction-layer
- **EXT-COCKROACH-FOLLOWER-READS** — CockroachDB follower reads and closed timestamp semantics — https://www.cockroachlabs.com/docs/stable/follower-reads

- **EXT-K8S-LEADERELECTION** — Kubernetes client-go leader election package — https://github.com/kubernetes/client-go/blob/master/tools/leaderelection/leaderelection.go
- **EXT-KAFKA-TRANSACTION-PROTOCOL-2026** — Apache Kafka transaction protocol — https://kafka.apache.org/42/operations/transaction-protocol/
- **EXT-KAFKA-PRODUCER-FENCING** — Apache Kafka producer transactions / ProducerFencedException — https://kafka.apache.org/23/javadoc/org/apache/kafka/clients/producer/KafkaProducer.html
- **EXT-HDFS-QJM-FENCING** — Apache Hadoop HDFS HA with Quorum Journal Manager — https://hadoop.apache.org/docs/r3.4.0/hadoop-project-dist/hadoop-hdfs/HDFSHighAvailabilityWithQJM.html

- **EXT-GOOGLE-AIP-155** — Google AIP-155 request identification — https://google.aip.dev/155
- **EXT-AWS-EC2-IDEMPOTENCY** — Amazon EC2 API idempotency with client tokens — https://docs.aws.amazon.com/ec2/latest/devguide/ec2-api-idempotency.html
- **EXT-AWS-ECS-IDEMPOTENCY** — Amazon ECS idempotency and RunTask client tokens — https://docs.aws.amazon.com/AmazonECS/latest/APIReference/ECS_Idempotency.html
- **EXT-STRIPE-IDEMPOTENT-REQUESTS** — Stripe idempotent requests — https://docs.stripe.com/api/idempotent_requests
- **EXT-IETF-IDEMPOTENCY-KEY** — IETF HTTP Idempotency-Key draft — https://datatracker.ietf.org/doc/draft-ietf-httpapi-idempotency-key-header/

- **EXT-RFC2308-NEGATIVE-CACHING** — RFC 2308 negative caching of DNS queries — https://datatracker.ietf.org/doc/html/rfc2308
- **EXT-RFC9110-404-410** — RFC 9110 HTTP 404 and 410 semantics — https://datatracker.ietf.org/doc/html/rfc9110
- **EXT-S3-DELETE-MARKERS** — Amazon S3 working with delete markers — https://docs.aws.amazon.com/AmazonS3/latest/userguide/DeleteMarker.html
- **EXT-CASSANDRA-TOMBSTONES** — Apache Cassandra tombstones and zombie resurrection — https://cassandra.apache.org/doc/latest/cassandra/managing/operating/compaction/tombstones.html

- **EXT-RFC7662-OAUTH-INTROSPECTION** — RFC 7662 OAuth 2.0 Token Introspection — https://datatracker.ietf.org/doc/html/rfc7662
- **EXT-RFC7009-TOKEN-REVOCATION** — RFC 7009 OAuth 2.0 Token Revocation — https://datatracker.ietf.org/doc/html/rfc7009
- **EXT-RFC6960-OCSP** — RFC 6960 Online Certificate Status Protocol — https://datatracker.ietf.org/doc/html/rfc6960
- **EXT-RFC9608-NOREVAVAIL** — RFC 9608 No Revocation Available for X.509 Public Key Certificates — https://datatracker.ietf.org/doc/html/rfc9608
- **EXT-RFC9770-TRL** — RFC 9770 Notification of Revoked Access Tokens / Token Revocation List — https://datatracker.ietf.org/doc/rfc9770/
- **EXT-SPIFFE-WORKLOAD-API** — SPIFFE Workload API — https://spiffe.io/docs/latest/spiffe-specs/spiffe_workload_api/
- **EXT-SPIFFE-SVIDS** — SPIFFE Working with SVIDs — https://spiffe.io/docs/latest/deploying/svids/

- **EXT-RFC9470-STEP-UP-AUTH** — RFC 9470 OAuth 2.0 Step Up Authentication Challenge Protocol — https://datatracker.ietf.org/doc/html/rfc9470
- **EXT-OPENID-CONNECT-CORE** — OpenID Connect Core 1.0 — https://openid.net/specs/openid-connect-core-1_0.html
- **EXT-WEBAUTHN-L3** — Web Authentication Level 3 — https://www.w3.org/TR/webauthn-3/
- **EXT-NIST-800-63B-4** — NIST SP 800-63B Digital Identity Guidelines: Authentication and Authenticator Management — https://pages.nist.gov/800-63-4/sp800-63b.html


- **EXT-RFC8705-MTLS-BOUND-TOKENS** — RFC 8705 OAuth 2.0 Mutual-TLS Client Authentication and Certificate-Bound Access Tokens — https://datatracker.ietf.org/doc/html/rfc8705
- **EXT-RFC8707-RESOURCE-INDICATORS** — RFC 8707 Resource Indicators for OAuth 2.0 — https://datatracker.ietf.org/doc/html/rfc8707
- **EXT-RFC9449-DPOP** — RFC 9449 OAuth 2.0 Demonstrating Proof of Possession (DPoP) — https://datatracker.ietf.org/doc/html/rfc9449
- **EXT-RFC9700-OAUTH-BCP** — RFC 9700 Best Current Practice for OAuth 2.0 Security — https://datatracker.ietf.org/doc/rfc9700/

- **EXT-RFC8693-TOKEN-EXCHANGE** — RFC 8693 OAuth 2.0 Token Exchange — https://datatracker.ietf.org/doc/html/rfc8693
- **EXT-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY** — Google Cloud Credential Access Boundaries overview — https://docs.cloud.google.com/iam/docs/downscoping-short-lived-credentials
- **EXT-AWS-STS-ASSUMEROLE** — AWS STS AssumeRole and session policies — https://docs.aws.amazon.com/STS/latest/APIReference/API_AssumeRole.html
- **EXT-GOOGLE-MACAROONS** — Macaroons paper — https://research.google/pubs/macaroons-cookies-with-contextual-caveats-for-decentralized-authorization-in-the-cloud/
- **EXT-BISCUIT-CRYPTOGRAPHY** — Biscuit attenuation cryptography reference — https://doc.biscuitsec.org/reference/cryptography.html
- **EXT-BISCUIT-REVOCATION** — Biscuit revocation and derived-token identifiers — https://www.biscuitsec.org/docs/guides/revocation/
- **EXT-BISCUIT-THIRD-PARTY-BLOCKS** — Biscuit third-party blocks — https://www.biscuitsec.org/blog/third-party-blocks-why-how-when-who/
- **EXT-SPICE-ACTOR-CHAIN-DRAFT-2026** — Cryptographically Verifiable Actor Chains for OAuth 2.0 Token Exchange — https://datatracker.ietf.org/doc/draft-mw-spice-actor-chain/03/

- **EXT-GITLAB-ARCHITECTURE-DECISIONS-2026** — GitLab architecture guidance — https://docs.gitlab.com/development/fe_guide/architecture/
- **EXT-W3C-DESIGN-PRINCIPLES-2026** — W3C Web Platform Design Principles — https://www.w3.org/TR/design-principles/
- **EXT-JSON-SCHEMA-CORE-2026** — JSON Schema core / dialect and vocabulary semantics — https://json-schema.org/draft/2020-12/json-schema-core
- **EXT-OTEL-SCHEMAS-2026** — OpenTelemetry Schemas — https://opentelemetry.io/docs/specs/otel/schemas/
- **EXT-OTEL-SEMCONV-2026** — OpenTelemetry Semantic Conventions — https://opentelemetry.io/docs/specs/otel/semantic-conventions/
- **EXT-OTEL-VERSIONING-STABILITY-2026** — OpenTelemetry Versioning and Stability — https://opentelemetry.io/docs/specs/otel/versioning-and-stability/
- **EXT-OTEL-SCHEMA-FILE-FORMAT-2026** — OpenTelemetry Schema File Format 1.0.0 — https://opentelemetry.io/docs/specs/otel/schemas/file_format_v1.0.0/
- **EXT-OTEL-SEMCONV-NAMING-2026** — OpenTelemetry semantic-convention naming — https://opentelemetry.io/docs/specs/semconv/general/naming/
- **EXT-PROTOBUF-BEST-PRACTICES-2026** — Protocol Buffers best practices — https://protobuf.dev/best-practices/dos-donts/
- **EXT-PROTOBUF-PROTO3-2026** — Protocol Buffers proto3 guide — https://protobuf.dev/programming-guides/proto3/
- **EXT-PROTOBUF-PROTOJSON-2026** — Protocol Buffers ProtoJSON guide — https://protobuf.dev/programming-guides/json/
- **EXT-K8S-FEATURE-GATES-2026** — Kubernetes feature gates — https://kubernetes.io/docs/reference/command-line-tools-reference/feature-gates/
- **EXT-STRIPE-ERROR-CODES** — Stripe error codes — https://docs.stripe.com/error-codes
- **EXT-ICEBERG-EVOLUTION-2026** — Apache Iceberg schema evolution — https://iceberg.apache.org/docs/1.7.1/evolution/
- **EXT-ICEBERG-SPEC-2026** — Apache Iceberg specification — https://iceberg.apache.org/spec/
- **EXT-DBT-SEMANTIC-MODELS-2026** — dbt semantic models — https://docs.getdbt.com/docs/build/semantic-models
- **EXT-DBT-DIMENSIONS-2026** — dbt dimensions and SCD Type II guidance — https://docs.getdbt.com/docs/build/dimensions
- **EXT-DBT-MEASURES-2026** — dbt measures deprecation note — https://docs.getdbt.com/docs/build/measures
- **EXT-CUBE-PREAGG-2026** — Cube pre-aggregations / aggregate awareness — https://cube.dev/docs/product/caching/using-pre-aggregations
- **EXT-XTDB-TIME-2026** — XTDB time and bitemporality — https://docs.xtdb.com/about/time-in-xtdb.html
- **EXT-KIMBALL-LATE-ARRIVING-DIMENSION** — Kimball late arriving dimension — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/late-arriving-dimension/
- **EXT-KIMBALL-LATE-ARRIVING-FACT** — Kimball late arriving fact — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/late-arriving-fact/

- **EXT-OTEL-METRICS-DATA-MODEL-2026** — OpenTelemetry metrics data model — https://opentelemetry.io/docs/specs/otel/metrics/data-model/
- **EXT-OTEL-METRICS-API-2026** — OpenTelemetry metrics API — https://opentelemetry.io/docs/specs/otel/metrics/api/
- **EXT-OTEL-METRIC-SEMCONV-UNITS-2026** — OpenTelemetry metric semantic conventions and units — https://opentelemetry.io/docs/specs/semconv/general/metrics/
- **EXT-KIMBALL-GRAIN** — Kimball grain technique — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/
- **EXT-KIMBALL-FACT-TABLES** — Kimball fact tables and true-to-grain additive facts — https://www.kimballgroup.com/2008/11/fact-tables/
- **EXT-CUBE-NON-ADDITIVITY-2026** — Cube non-additive measures and additive-component decomposition — https://cube.dev/docs/product/caching/recipes/non-additivity

- **EXT-KIMBALL-BRIDGE-DETOURS** — Kimball Design Tip #166, bridge-table detours and over-counting/weighting pressure — https://www.kimballgroup.com/2014/05/design-tip-166-potential-bridge-table-detours/
- **EXT-KIMBALL-FACTLESS-COVERAGE** — Kimball factless fact tables and coverage tables for “what didn’t happen” — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/factless-fact-table/
- **EXT-DBT-ENTITIES-2026** — dbt entities and primary/unique/foreign posture — https://docs.getdbt.com/docs/build/entities
- **EXT-DBT-RATIO-2026** — dbt ratio metrics and explicit numerator/denominator posture — https://docs.getdbt.com/docs/build/ratio
- **EXT-PROMETHEUS-NAMING-2026** — Prometheus metric and label naming guidance — https://prometheus.io/docs/practices/naming/
- **EXT-PROMETHEUS-HISTOGRAMS-2026** — Prometheus histograms, summaries, averages, and bucket-based ratio guidance — https://prometheus.io/docs/practices/histograms/
- **EXT-LOOKERSTUDIO-RATIO-2026** — Looker Studio already-aggregated ratio metrics and reaggregation failure guidance — https://docs.cloud.google.com/looker/docs/studio/what-does-the-unable-to-aggregate-ratio-metrics-error-mean
- **EXT-KIMBALL-SURROGATE-KEYS** — Kimball surrogate keys — https://www.kimballgroup.com/1998/05/surrogate-keys/
- **EXT-KIMBALL-TYPE2** — Kimball Type 2 slowly changing dimensions — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/type-2/
- **EXT-PROMETHEUS-INSTRUMENTATION-2026** — Prometheus instrumentation and label-cardinality guidance — https://prometheus.io/docs/practices/instrumentation/
- **EXT-DATASKETCHES-HLL-2026** — Apache DataSketches HLL sketch bounds and confidence posture — https://datasketches.apache.org/docs/HLL/HllSketches.html
- **EXT-DATASKETCHES-THETA-2026** — Apache DataSketches Theta sketch framework — https://datasketches.apache.org/docs/Theta/ThetaSketches.html
- **EXT-CLICKHOUSE-UNIQ-2026** — ClickHouse uniq aggregate function (approximate distinct count) — https://clickhouse.com/docs/sql-reference/aggregate-functions/reference/uniq
- **EXT-CLICKHOUSE-APPROXTOPK-2026** — ClickHouse approx_top_k aggregate function (approximate frequent-values ranking) — https://clickhouse.com/docs/sql-reference/aggregate-functions/reference/approxtopk
- **EXT-OPENLINEAGE-ABOUT-2026** — OpenLineage overview — https://openlineage.io/docs/
- **EXT-OPENLINEAGE-FACETS-2026** — OpenLineage facets and extensibility — https://openlineage.io/docs/spec/facets/
- **EXT-OPENLINEAGE-PARENT-RUN-2026** — OpenLineage Parent Run Facet — https://openlineage.io/docs/spec/facets/run-facets/parent_run/
- **EXT-OPENLINEAGE-EXECUTION-PARAMETERS-2026** — OpenLineage Execution Parameters Facet — https://openlineage.io/docs/1.43.0/spec/facets/run-facets/execution_parameters/
- **EXT-DBT-ARTIFACTS-2026** — dbt artifacts overview — https://docs.getdbt.com/reference/artifacts/dbt-artifacts
- **EXT-DBT-MANIFEST-JSON-2026** — dbt manifest.json artifact — https://docs.getdbt.com/reference/artifacts/manifest-json
- **EXT-LAKEFS-METADATA-SEARCH-2026** — lakeFS metadata search by branch/commit/tag — https://docs.lakefs.io/v1.71/datamanagment/metadata-search/
- **EXT-DELTA-TIME-TRAVEL-2026** — Delta Lake time travel and older-version query semantics — https://docs.delta.io/delta-batch/
- **EXT-AIRFLOW-ASSETS-2026** — Apache Airflow asset definitions and asset-event metadata — https://airflow.apache.org/docs/apache-airflow/stable/authoring-and-scheduling/assets.html
- **EXT-AIRFLOW-EVENT-SCHEDULING-2026** — Apache Airflow event-driven scheduling — https://airflow.apache.org/docs/apache-airflow/stable/authoring-and-scheduling/event-scheduling.html
- **EXT-DAGSTER-ASSET-PROVENANCE-2026** — Dagster asset execution context and provenance APIs — https://docs.dagster.io/api/dagster/execution
- **EXT-DAGSTER-COLUMN-LINEAGE-2026** — Dagster column-level lineage — https://docs.dagster.io/guides/build/assets/metadata-and-tags/column-level-lineage
- **EXT-DRUID-PROJECTIONS-2026** — Apache Druid projections in ingestion specs — https://druid.apache.org/docs/latest/ingestion/ingestion-spec/
- **EXT-DRUID-ROLLUP-2026** — Apache Druid data rollup trade-offs — https://druid.apache.org/docs/latest/ingestion/rollup/
- **EXT-OPENMETRICS-HISTOGRAM-EXEMPLARS-2026** — OpenMetrics histogram exemplars and valid granularity loss — https://prometheus.io/docs/specs/om/open_metrics_spec/
- **EXT-OPENMETRICS-SUMMARIES-2026** — OpenMetrics summary/quantile aggregation caveats and timeframe warning — https://prometheus.io/docs/specs/om/open_metrics_spec/
- **EXT-PROMETHEUS-EXEMPLAR-STORAGE-2026** — Prometheus exemplar storage and external-reference posture — https://prometheus.io/docs/prometheus/latest/feature_flags/
- **EXT-POSTGRES-ROW-SECURITY-2026** — PostgreSQL row security policies — https://www.postgresql.org/docs/current/ddl-rowsecurity.html
- **EXT-POSTGRES-SECURITY-BARRIER-2026** — PostgreSQL security-barrier views and privilege rules — https://www.postgresql.org/docs/current/rules-privileges.html
- **EXT-BIGQUERY-ROW-SECURITY-INTRO-2026** — BigQuery row-level security overview — https://docs.cloud.google.com/bigquery/docs/row-level-security-intro
- **EXT-BIGQUERY-COLUMN-MASKING-2026** — BigQuery column data masking — https://docs.cloud.google.com/bigquery/docs/column-data-masking
- **EXT-BIGQUERY-JOBS-RLS-2026** — BigQuery JOBS view limitations for row-level-secured queries — https://docs.cloud.google.com/bigquery/docs/information-schema-jobs
- **EXT-SNOWFLAKE-AGGREGATION-POLICIES-2026** — Snowflake aggregation policies and minimum group size — https://docs.snowflake.com/en/user-guide/aggregation-policies
- **EXT-POSTGRES-LIMIT-2026** — PostgreSQL LIMIT / OFFSET semantics — https://www.postgresql.org/docs/current/queries-limit.html
- **EXT-GRAPHQL-PAGINATION-2026** — GraphQL cursor pagination guidance — https://graphql.org/learn/pagination/
- **EXT-ELASTIC-SEARCH-API-2026** — Elasticsearch search API and total-hit semantics — https://www.elastic.co/docs/solutions/search/the-search-api
- **EXT-BIGQUERY-GETQUERYRESULTS-2026** — BigQuery jobs.getQueryResults paging and totalRows — https://docs.cloud.google.com/bigquery/docs/reference/rest/v2/jobs/getQueryResults
- **EXT-MEILISEARCH-PAGINATION-2026** — Meilisearch page/hitsPerPage vs estimatedTotalHits/totalHits — https://meilisearch.com/docs/reference/api/search/search-with-post
- **EXT-BEAM-BASICS-2026** — Apache Beam basics (watermarks, early results, and late data) — https://beam.apache.org/documentation/basics/
- **EXT-FLINK-TIME-2026** — Apache Flink timely stream processing (event time, watermarks, and late elements) — https://nightlies.apache.org/flink/flink-docs-stable/docs/concepts/time/
- **EXT-SPARK-WATERMARK-2026** — Spark Structured Streaming late data and watermarking — https://spark.apache.org/docs/latest/streaming/apis-on-dataframes-and-datasets.html
- **EXT-KAFKA-STREAMS-GRACE-2026** — Apache Kafka Streams grace-period and window-finality semantics — https://kafka.apache.org/33/streams/core-concepts/
- **EXT-DBT-STATE-AWARE-2026** — dbt state-aware orchestration guidance for late-arriving data and freshness alignment — https://docs.getdbt.com/docs/deploy/state-aware-setup
- **EXT-AZURE-BM25-SCORING-2026** — Azure AI Search BM25 scoring, tie instability, and unscored sentinel — https://learn.microsoft.com/en-us/azure/search/index-similarity-and-scoring
- **EXT-AZURE-HYBRID-RANKING-2026** — Azure AI Search hybrid search scoring and separate reranker score — https://learn.microsoft.com/en-us/azure/search/hybrid-search-ranking
- **EXT-ELASTIC-QUERYDSL-2026** — Elasticsearch Query DSL relevance scores and query/filter context — https://www.elastic.co/docs/explore-analyze/query-filter/languages/querydsl
- **EXT-WEAVIATE-HYBRID-2026** — Weaviate hybrid search and fusion strategies — https://docs.weaviate.io/weaviate/concepts/search/hybrid-search
- **EXT-WEAVIATE-VECTOR-SEARCH-2026** — Weaviate vector search distance/similarity semantics and threshold posture — https://docs.weaviate.io/weaviate/concepts/search/vector-search
- **EXT-DATABRICKS-MERGE-INTO-2026** — Databricks Delta `MERGE INTO` ambiguity and multiple-source-row failure semantics — https://docs.databricks.com/aws/en/sql/language-manual/delta-merge-into
- **EXT-DATABRICKS-DELTA-MERGE-2026** — Databricks Delta merge/upsert deduplication guidance and duplicate-within-source warning — https://docs.databricks.com/aws/en/delta/merge
- **EXT-HUDI-RECORD-MERGER-2026** — Apache Hudi record merger modes: commit-time ordering, event-time ordering, and custom reconciliation — https://hudi.apache.org/docs/record_merger/
- **EXT-PURVIEW-PROFISEE-MDM-2025** — Microsoft Purview + Profisee MDM matching, survivorship, lineage, and golden-record guidance — https://learn.microsoft.com/en-us/purview/data-governance-master-data-management-profisee
- **EXT-DBT-INCREMENTAL-MODELS-2026** — dbt incremental models, `unique_key`, duplicate-key caveats, and rebuild posture — https://docs.getdbt.com/docs/build/incremental-models
- **EXT-DBT-INCREMENTAL-STRATEGY-2026** — dbt incremental strategies (`append`, `delete+insert`, `merge`) and overwrite/history differences — https://docs.getdbt.com/docs/build/incremental-strategy
- **EXT-BIGQUERY-TABLESAMPLE-2026** — BigQuery `TABLESAMPLE` block sampling and sampling bias notes — https://docs.cloud.google.com/bigquery/docs/table-sampling
- **EXT-CLICKHOUSE-SAMPLE-2026** — ClickHouse `SAMPLE` clause and `_sample_factor` semantics — https://clickhouse.com/docs/sql-reference/statements/select/sample
- **EXT-OTEL-SAMPLING-CONCEPTS-2026** — OpenTelemetry sampling concepts — https://opentelemetry.io/docs/concepts/sampling/
- **EXT-OTEL-PROBABILITY-SAMPLING-2026** — OpenTelemetry TraceState probability sampling — https://opentelemetry.io/docs/specs/otel/trace/tracestate-probability-sampling/

- **EXT-UCUM-2024** — UCUM specification 2.2 — https://ucum.org/ucum
- **EXT-OPENMETRICS-UNITS-2026** — OpenMetrics base-unit and ratio guidance — https://prometheus.io/docs/specs/om/open_metrics_spec/
- **EXT-PROMETHEUS-WRITING-EXPORTERS-2026** — Prometheus exporter guidance for base units and ratios — https://prometheus.io/docs/instrumenting/writing_exporters/

- **EXT-PROMETHEUS-METRIC-TYPES-2026** — Prometheus metric types and counter reset semantics — https://prometheus.io/docs/concepts/metric_types/
- **EXT-PROMETHEUS-QUERY-FUNCTIONS-2026** — Prometheus query functions (`resets`, `increase`) — https://prometheus.io/docs/prometheus/latest/querying/functions/
- **EXT-OTEL-METRICS-SUPPLEMENTARY-2026** — OpenTelemetry metrics supplementary guidelines and reset detection — https://opentelemetry.io/docs/specs/otel/metrics/supplementary-guidelines/
- **EXT-STRIPE-BILLING-CYCLE-2026** — Stripe billing cycle anchor and period reset behavior — https://docs.stripe.com/billing/subscriptions/billing-cycle
- **EXT-STRIPE-USAGE-THRESHOLDS-2026** — Stripe usage thresholds, anchor resets, and tier reset behavior — https://docs.stripe.com/billing/subscriptions/usage-based/thresholds


- **EXT-FINOPS-SHARED-COSTS-2026** — FinOps Foundation managing shared cloud costs — https://www.finops.org/wg/identifying-shared-costs/
- **EXT-OPENCOST-SPEC-2026** — OpenCost specification — https://opencost.io/docs/specification/
- **EXT-FOCUS-SPEC-2026** — FOCUS specification overview and release notes — https://focus.finops.org/focus-specification/
- **EXT-DBT-SEMANTIC-SPEC-MODERNIZATION-2026** — dbt Developer Blog: Modernizing the Semantic Layer Spec — https://docs.getdbt.com/blog/modernizing-the-semantic-layer-spec
- **EXT-DBT-MODEL-VERSIONS-2026** — dbt model versions — https://docs.getdbt.com/docs/mesh/govern/model-versions
- **EXT-DBT-COORDINATE-VERSIONS-2026** — dbt coordinating model versions — https://docs.getdbt.com/best-practices/how-we-mesh/mesh-6-coordinate-versions
- **EXT-DBT-LATEST-METRICS-SPEC-2026** — dbt migrate to the latest YAML spec — https://docs.getdbt.com/docs/build/latest-metrics-spec
- **EXT-OPENLINEAGE-OBJECT-MODEL-2026** — OpenLineage object model — https://openlineage.io/docs/spec/object-model/
- **EXT-ICEBERG-BRANCHING-2026** — Apache Iceberg branching and tagging — https://iceberg.apache.org/docs/latest/branching/
- **EXT-RFC6906-PROFILE-2026** — RFC 6906 profile link relation — https://www.rfc-editor.org/rfc/rfc6906.html
- **EXT-ALPS-PROFILE-2026** — ALPS profile linking and precedence draft — https://datatracker.ietf.org/doc/draft-amundsen-richardson-foster-alps/05/
- **EXT-OPENAPI-DIALECT-2026** — OpenAPI 3.2.0 schema dialect and extension semantics — https://spec.openapis.org/oas/v3.2.0.html
- **EXT-OTEL-SEMCONV-GROUPS-2026** — OpenTelemetry semantic convention groups / opt-in unstable guidance — https://opentelemetry.io/docs/specs/semconv/general/semantic-convention-groups/

- **EXT-HUDI-TABLE-TYPES-2026** — Apache Hudi table/query types and arrival-time versus event-time distinction — https://hudi.apache.org/docs/table_types/
- **EXT-DELTA-CHANGE-DATA-FEED-2026** — Delta Lake Change Data Feed — https://docs.delta.io/delta-change-data-feed/
- **EXT-BIGQUERY-CHANGES-2026** — BigQuery `CHANGES`/`APPENDS` functions and bounded change-history semantics — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/time-series-functions
- **EXT-DBT-SNAPSHOTS-2026** — dbt snapshots and timestamp strategy — https://docs.getdbt.com/docs/build/snapshots
- **EXT-DBT-HARD-DELETES-2026** — dbt `hard_deletes` snapshot config — https://docs.getdbt.com/reference/resource-configs/hard-deletes
- **EXT-SQLSERVER-TEMPORAL-USAGE-2026** — SQL Server temporal-table usage scenarios and delayed-load caveat — https://learn.microsoft.com/en-us/sql/relational-databases/tables/temporal-table-usage-scenarios?view=sql-server-ver17

- **EXT-LOOKER-SYMMETRIC-AGGREGATES-2026** — Looker symmetric aggregates and fanout-safe counting — https://docs.cloud.google.com/looker/docs/best-practices/understanding-symmetric-aggregates
- **EXT-DBT-JOIN-LOGIC-2026** — dbt MetricFlow join logic, fan-out avoidance, and chasm-join avoidance — https://docs.getdbt.com/docs/build/join-logic
- **EXT-POWERBI-MANY-TO-MANY-2025** — Power BI many-to-many and higher-grain fact guidance — https://learn.microsoft.com/en-us/power-bi/guidance/relationships-many-to-many
- **EXT-CUBE-TYPES-FORMATS-2026** — Cube measure types, row-duplication-safe counts/sums, and additive approximate distinct counts — https://cube.dev/docs/product/data-modeling/reference/types-and-formats
- **EXT-W3C-PROV-DM-2013** — W3C PROV-DM provenance data model — https://www.w3.org/TR/2013/REC-prov-dm-20130430/
- **EXT-W3C-DQV-2016** — W3C Data Quality Vocabulary — https://www.w3.org/TR/vocab-dqv/
- **EXT-W3C-SHACL12-2026** — W3C SHACL 1.2 Core and validation-result severity semantics — https://www.w3.org/TR/shacl12-core/
- **EXT-STIX-21-2026** — STIX 2.1 confidence semantics — https://docs.oasis-open.org/cti/stix/v2.1/stix-v2.1.html
- **EXT-OPENLINEAGE-DQ-ASSERTIONS-2026** — OpenLineage data quality assertions facet — https://openlineage.io/docs/spec/facets/dataset-facets/data_quality_assertions_dataset/

- **EXT-HL7-NULLFLAVOR-2026** — HL7 v3 NullFlavor reason-coded blank semantics — https://terminology.hl7.org/6.5.0/CodeSystem-v3-NullFlavor.html
- **EXT-FHIR-DATA-ABSENT-REASON-2026** — FHIR Data Absent Reason code system — https://terminology.hl7.org/5.1.0/CodeSystem-data-absent-reason.json.html
- **EXT-RFC7396-JSON-MERGE-PATCH** — RFC 7396 JSON Merge Patch and null-as-removal semantics — https://www.rfc-editor.org/rfc/rfc7396.html
- **EXT-PROTOBUF-FIELD-PRESENCE-2026** — Protocol Buffers field presence guidance — https://protobuf.dev/programming-guides/field_presence/
- **EXT-PROTOBUF-PROTO3-DEFAULTS-2026** — Protocol Buffers proto3 default-value and implicit-presence guidance — https://protobuf.dev/programming-guides/proto3/


- **EXT-HL7-MEASURE-POPULATION-2026** — HL7 measure population types for eligibility, exclusion, and exception posture — https://terminology.hl7.org/2.1.0/CodeSystem-measure-population.html
- **EXT-HL7-MEASURE-SCORING-2026** — HL7 measure scoring types showing initial-population and inclusion/exclusion differences — https://terminology.hl7.org/6.1.0/ValueSet-measure-scoring.html
- **EXT-FHIR-MEASURE-REPORT-TYPE-2026** — FHIR measure report types distinguishing subject-list and summary outputs — https://fhir.hl7.org/fhir/codesystem-measure-report-type.html
- **EXT-GCLOUD-SLO-MONITORING-2026** — Google Cloud SLO guidance on eligible events, compliance periods, and error budgets — https://docs.cloud.google.com/stackdriver/docs/solutions/slo-monitoring

- **EXT-CVSS-V4-SPEC-2026** — FIRST CVSS v4.0 qualitative severity scale and optional qualitative ratings — https://www.first.org/cvss/v4-0/cvss-v40-specification.pdf
- **EXT-CVSS-V4-CONSUMER-GUIDE-2026** — FIRST CVSS v4.0 Consumer Implementation Guide on environment-specific prioritization — https://www.first.org/cvss/v4.0/implementation-guide
- **EXT-HL7-OBS-INTERPRETATION-2026** — HL7 ObservationInterpretation rough qualitative interpretation codes — https://terminology.hl7.org/3.1.0/ValueSet-v3-ObservationInterpretation.html

- **EXT-CUBE-MATCHING-PREAGG-2026** — Cube pre-aggregation matching algorithm — https://cube.dev/docs/product/caching/matching-pre-aggregations
- **EXT-LOOKER-AGGREGATE-AWARENESS-2026** — Looker aggregate awareness — https://docs.cloud.google.com/looker/docs/aggregate_awareness
- **EXT-DATAHUB-ASSERTIONS-2026** — DataHub assertions — https://docs.datahub.com/docs/managed-datahub/observe/assertions
- **EXT-W3C-FEDCM-2026** — W3C Federated Credential Management API — https://www.w3.org/TR/fedcm/
- **EXT-CHROME-FEDCM-2026** — Chrome FedCM overview — https://developer.chrome.com/docs/identity/fedcm/overview
- **EXT-GOOGLE-FEDCM-MIGRATION-2026** — Google Identity Services FedCM migration guide — https://developers.google.com/identity/gsi/web/guides/fedcm-migration
- **EXT-W3C-LOGIN-STATUS-2026** — W3C Login Status API — https://w3c-fedid.github.io/login-status/
- **EXT-W3C-DIGITAL-CREDENTIALS-2026** — W3C Digital Credentials API — https://www.w3.org/TR/digital-credentials/
- **EXT-CHROME-DIGITAL-CREDENTIALS-2026** — Chrome Digital Credentials API shipped — https://developer.chrome.com/blog/digital-credentials-api-shipped
- **EXT-OPENID-FEDERATION-1-0-2026** — OpenID Federation 1.0 final specification — https://openid.net/specs/openid-federation-1_0.html
- **EXT-W3C-RDF-DATA-CUBE-2014** — W3C RDF Data Cube Vocabulary — https://www.w3.org/TR/vocab-data-cube/
- **EXT-W3C-DATA-CUBE-USE-CASES-2013** — W3C Use Cases and Lessons for the Data Cube Vocabulary — https://www.w3.org/TR/vocab-data-cube-use-cases/
- **EXT-KIMBALL-GRAIN-2003** — Kimball Group dimensional modeling grain guidance — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/

- **EXT-ODCS-3-1-2026** — Open Data Contract Standard v3.1.0 — https://bitol-io.github.io/open-data-contract-standard/v3.1.0/

- **EXT-OPENMETADATA-DATA-CONTRACTS-2026** — OpenMetadata data contracts — https://docs.open-metadata.org/v1.12.x/how-to-guides/data-contracts

- **EXT-FRICTIONLESS-TABLE-SCHEMA-2026** — Frictionless Table Schema — https://specs.frictionlessdata.io/table-schema/

- **EXT-SUBSTRAIT-2026** — Substrait cross-language relational algebra serialization — https://substrait.io/

- **EXT-DUCKDB-ORDER-PRESERVATION-2026** — DuckDB order preservation semantics — https://duckdb.org/docs/current/sql/dialect/order_preservation

- **EXT-XARRAY-DATA-STRUCTURES-2026** — xarray data structures, dimensions, coordinates, and attributes — https://docs.xarray.dev/en/latest/user-guide/data-structures.html

- **EXT-ZARR-V3-CORE-2026** — Zarr v3 core specification — https://zarr-specs.readthedocs.io/en/latest/v3/core/index.html

- **EXT-STAC-DATACUBE-2026** — STAC datacube extension — https://github.com/stac-extensions/datacube

- **EXT-STAC-EXTENSIONS-2026** — STAC extensions overview and maturity statuses — https://stac-extensions.github.io/

- **EXT-DELTA-PROTOCOL-2026** — Delta Lake transaction protocol — https://github.com/delta-io/delta/blob/master/PROTOCOL.md

- **EXT-GREATEXPECTATIONS-VALIDATION-RESULT-2026** — Great Expectations ExpectationSuiteValidationResult API — https://docs.greatexpectations.io/docs/reference/api/core/expectationsuitevalidationresult_class/

- **EXT-W3C-DCAT3-2024** — W3C Data Catalog Vocabulary version 3 — https://www.w3.org/TR/vocab-dcat-3/
- **EXT-ARROW-PARTITIONING-2026** — Apache Arrow dataset partitioning / Hive partitioning docs — https://arrow.apache.org/docs/python/generated/pyarrow.dataset.partitioning.html
- **EXT-BIGQUERY-DATE-FUNCTIONS-2026** — BigQuery date functions, ISO week/year and week-start behavior — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/date_functions
- **EXT-CENSUS-HIERARCHY-2021** — U.S. Census hierarchy diagrams for legal, administrative, and statistical boundaries — https://www.census.gov/programs-surveys/geography/guidance/hierarchy.html
- **EXT-CENSUS-TIGER-2025** — U.S. Census TIGER/Line release page and boundary-date posture — https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.html
- **EXT-OGC-DGGS-2026** — OGC API Discrete Global Grid Systems overview and hierarchical grid reference posture — https://ogcapi.ogc.org/dggs/
- **EXT-POSTGRES-DATETIME-FUNCTIONS-2026** — PostgreSQL datetime functions, ISO week/year cautions — https://www.postgresql.org/docs/current/functions-datetime.html
- **EXT-SDMX-AVAILABILITY-2026** — SDMX REST availability queries and AvailabilityConstraint behavior — https://github.com/sdmx-twg/sdmx-rest/blob/master/doc/availability.md
- **EXT-SDMX-COG-2026** — SDMX Content-Oriented Guidelines: concepts and code lists — https://sdmx.org/guidelines/
- **EXT-UNICODE-LDML-DATES-2026** — Unicode LDML dates and week data rules — https://unicode.org/reports/tr35/tr35-dates.html
- **EXT-W3C-SKOS-2009** — W3C SKOS Reference for concept schemes and informal hierarchies — https://www.w3.org/TR/skos-reference/
- **EXT-XBRL-DIMENSIONS-2011** — XBRL Dimensions 1.0 specification — https://www.xbrl.org/Specification/dimensions/per-2011-11-20/dimensions-per-2011-11-20_clean.html
- **EXT-XBRL-OIM-2023** — XBRL Open Information Model 1.0 — https://specifications.xbrl.org/work-product-index-open-information-model-open-information-model.html
- **EXT-BIGQUERY-MATERIALIZED-VIEWS-2026** — BigQuery materialized views overview, incremental/non-incremental posture, smart tuning, max staleness, and limitations — https://docs.cloud.google.com/bigquery/docs/materialized-views-intro
- **EXT-BIGQUERY-MATERIALIZED-VIEWS-USE-2026** — BigQuery materialized view use, incremental update rejection, partition alignment, and smart tuning conditions — https://docs.cloud.google.com/bigquery/docs/materialized-views-use
- **EXT-SNOWFLAKE-DYNAMIC-TABLES-2026** — Snowflake dynamic tables overview, target lag, refresh, and declarative pipeline posture — https://docs.snowflake.com/en/user-guide/dynamic-tables-about
- **EXT-SNOWFLAKE-TARGET-LAG-2026** — Snowflake dynamic table target lag, actual lag, dependency-chain, skipped-refresh, and downstream lag behavior — https://docs.snowflake.com/en/user-guide/dynamic-tables-target-lag
- **EXT-MATERIALIZE-LIVE-DATA-2026** — Materialize live data layer and incremental update posture — https://materialize.com/docs/get-started/
- **EXT-RFC9111-CACHING** — RFC 9111 HTTP Caching, freshness, authorization-sensitive storage, no-cache/no-store, must-revalidate, private/public, and revalidation semantics — https://www.rfc-editor.org/rfc/rfc9111.html
- **EXT-RFC9211-CACHE-STATUS** — RFC 9211 Cache-Status response header for cache handling debug semantics — https://www.rfc-editor.org/rfc/rfc9211.html
- **EXT-RFC5861-STALE-CONTROLS** — RFC 5861 stale-while-revalidate and stale-if-error cache-control extensions — https://datatracker.ietf.org/doc/html/rfc5861
- **EXT-DAGSTER-FRESHNESS-POLICIES-2026** — Dagster asset freshness policies and asset-health freshness expectations — https://docs.dagster.io/guides/observe/asset-freshness-policies
- **EXT-OPENLINEAGE-DATASET-TYPE-2026** — OpenLineage dataset type facet, including materialized subtype posture — https://openlineage.io/docs/spec/facets/dataset-facets/type/
- **EXT-AWS-CLEANROOMS-AGGREGATION-2026** — AWS Clean Rooms aggregation analysis rule and output constraints — https://docs.aws.amazon.com/clean-rooms/latest/userguide/analysis-rules-aggregation.html
- **EXT-AWS-CLEANROOMS-ANALYSIS-RULES-2026** — AWS Clean Rooms analysis rules, restrictive controls, and output-constraint behavior — https://docs.aws.amazon.com/clean-rooms/latest/userguide/analysis-rules.html
- **EXT-AWS-CLEANROOMS-DP-POLICY-2026** — AWS Clean Rooms differential privacy policy, privacy budget, and noise controls — https://docs.aws.amazon.com/clean-rooms/latest/userguide/dp-settings.html
- **EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026** — BigQuery differential privacy query behavior, privacy-unit column, contribution bounds, noise, and limitations — https://docs.cloud.google.com/bigquery/docs/differential-privacy
- **EXT-EUROSTAT-SDC-CROS-2024** — Eurostat CROS Statistical Disclosure Control overview — https://cros.ec.europa.eu/book-page/statistical-disclosure-control
- **EXT-NIST-DP-800-226-2025** — NIST SP 800-226 Guidelines for Evaluating Differential Privacy Guarantees — https://csrc.nist.gov/pubs/sp/800/226/final
- **EXT-ONS-CENSUS-SDC-2023** — ONS Census 2021 statistical disclosure control methodology — https://www.ons.gov.uk/peoplepopulationandcommunity/populationandmigration/populationestimates/methodologies/protectingpersonaldataincensus2021results
- **EXT-OPENDP-WORKFLOW-2026** — OpenDP typical workflow: privacy unit, privacy loss parameters, and mediated access — https://docs.opendp.org/en/stable/getting-started/typical-workflow.html
- **EXT-SNOWFLAKE-ENTITY-PRIVACY-2026** — Snowflake entity-level privacy with aggregation policies — https://docs.snowflake.com/en/user-guide/aggregation-policies-entity-privacy
- **EXT-STATCAN-DQ-SDC-2014** — Statistics Canada data quality guidance on disclosure-control techniques for tables and microdata — https://www150.statcan.gc.ca/n1/pub/12-539-x/steps-etapes/4058325-eng.htm
- **EXT-SDMX-OBS-STATUS-2026** — SDMX CL_OBS_STATUS observation-status code-list lineage and estimated-vs-imputed distinction — https://sdmx.org/news/new-version-of-code-list-for-observation-status-version-2-2/
- **EXT-CF-CELL-METHODS-2026** — CF Conventions cell_methods attribute for how cell values are determined over axes — https://cfconventions.org/Data/cf-conventions/cf-conventions-1.7/build/ch07s03.html
- **EXT-CF-FLAGS-2026** — CF Conventions flag_values and flag_meanings for self-describing quality flags — https://cfconventions.org/Data/cf-conventions/cf-conventions-1.1/build/ch03s05.html
- **EXT-NIST-OECD-IMPUTATION-2026** — NIST/OECD glossary definition of imputation as entering/replacing missing or unusable values — https://csrc.nist.gov/glossary/term/imputation
- **EXT-CENSUS-X13ARIMA-2025** — U.S. Census X-13ARIMA-SEATS seasonal adjustment software and diagnostics page — https://www.census.gov/data/software/x13as.html
- **EXT-ALFRED-VINTAGES-2026** — St. Louis Fed ALFRED vintage economic data retrieval — https://alfred.stlouisfed.org/
- **EXT-IMF-DQAF-2003** — IMF Data Quality Assessment Framework generic framework on source assessment, techniques, validation, revisions, and preliminary/revised identification — https://dsbb.imf.org/content/pdfs/dqrs_Genframework.pdf
- **EXT-EUROSTAT-DATA-VALIDATION-2026** — Eurostat data validation definition, common standards, tools/services, and validation-responsibility posture — https://ec.europa.eu/eurostat/data/data-validation
- **EXT-EUROSTAT-VALIDATION-LEVELS-2026** — Eurostat CROS validation levels, structural/content validations, within-dataset totals, mirror checks, and external consistency levels — https://cros.ec.europa.eu/book-page/validation-levels
- **EXT-SDMX-VTL-2026** — SDMX Validation and Transformation Language overview and technology-neutral validation/transformation rule posture — https://sdmx.org/validation-and-transformation-language-vtl/
- **EXT-UNECE-GSBPM-5-2-2026** — UNECE Generic Statistical Business Process Model v5.2, metadata, process data, quality, and documentation loops — https://unece.github.io/GSBPM-5.2/
- **EXT-XBRL-CALCULATIONS-1-1-2023** — XBRL Calculations 1.1 Recommendation, summation-item relationships, calculation consistency, rounding, duplicate facts, and non-fatal inconsistency posture — https://www.xbrl.org/Specification/calculation-1.1/REC-2023-02-22/calculation-1.1-REC-2023-02-22.html
- **EXT-XBRL-CALC11-ADOPTION-2023** — XBRL guidance on adopting Calculations 1.1, rounded values, duplicate facts, incomplete calculation trees, and scoping limits — https://www.xbrl.org/guidance/adopting-calc1-1/

- **EXT-SDMX-CROSS-DOMAIN-CODELISTS-2026** — SDMX cross-domain code lists — https://sdmx.org/sdmx_cdcl/
- **EXT-FHIR-CONCEPTMAP-2026** — HL7 FHIR R5 ConceptMap resource — https://fhir.hl7.org/fhir/conceptmap.html
- **EXT-EUROSTAT-NACE-CORRESPONDENCE-2026** — Eurostat NACE correspondence tables — https://ec.europa.eu/eurostat/web/nace/correspondence-tables
- **EXT-NAICS-REVISION-CYCLE-2026** — U.S. Census NAICS 2022 implementation and revision cadence — https://www.census.gov/library/reference/code-lists/naics/2022/implementation-timeline.html
- **EXT-RFC9457-PROBLEM-DETAILS-2023** — RFC 9457 Problem Details for HTTP APIs — https://www.rfc-editor.org/rfc/rfc9457.html
- **EXT-RFC8785-JCS** — RFC 8785 JSON Canonicalization Scheme (JCS) — https://www.rfc-editor.org/rfc/rfc8785.html
- **EXT-RFC6902-JSON-PATCH** — RFC 6902 JSON Patch — https://datatracker.ietf.org/doc/html/rfc6902

- **EXT-SARIF-V210-SUPPRESSIONS** — OASIS SARIF v2.1.0 suppression object and status/justification posture — https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
- **EXT-OPA-DECISION-LOGS-2026** — Open Policy Agent decision logs — https://www.openpolicyagent.org/docs/management-decision-logs
- **EXT-CYCLONEDX-VEX-2026** — CycloneDX Vulnerability Exploitability Exchange use case — https://cyclonedx.org/use-cases/vulnerability-exploitability/
- **EXT-W3C-VC-DM-2-2025** — W3C Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/

- **EXT-RFC9334-RATS-ARCH** — RFC 9334 Remote ATtestation procedureS (RATS) Architecture — https://datatracker.ietf.org/doc/rfc9334/

- **EXT-RFC7009-OAUTH-REVOCATION** — RFC 7009 OAuth 2.0 Token Revocation — https://datatracker.ietf.org/doc/html/rfc7009

- **EXT-W3C-VC-BITSTRING-STATUS-2025** — W3C Verifiable Credentials Bitstring Status List v1.0 — https://www.w3.org/TR/vc-bitstring-status-list/
- **EXT-IN-TOTO-ATTESTATION-2026** — in-toto Attestation Framework subject/predicate statement model — https://github.com/in-toto/attestation/blob/main/spec/README.md
- **EXT-SLSA-PROVENANCE-1-0** — SLSA provenance v1.0 specification for build platform, buildDefinition, and materials posture — https://slsa.dev/spec/v1.0/provenance
- **EXT-CSAF-2-0** — OASIS Common Security Advisory Framework v2.0 for structured advisory, status, and remediation information — https://docs.oasis-open.org/csaf/csaf/v2.0/os/csaf-v2.0-os.html
- **EXT-CLOUDEVENTS-2026** — CloudEvents specification and common event metadata model — https://cloudevents.io/
- **EXT-SCITT-ARCHITECTURE-2026** — IETF SCITT architecture draft for transparent supply-chain statements — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/

- **EXT-NIST-CM8-INVENTORY-2026** — NIST SP 800-53 Rev. 5 CM-8 system component inventory control pressure — https://csf.tools/reference/nist-sp-800-53/r5/cm/cm-8/

- **EXT-OPENLINEAGE-SYMLINKS-2026** — OpenLineage symlinks dataset facet for alternate dataset identifiers — https://openlineage.io/docs/spec/facets/dataset-facets/symlinks/

- **EXT-SPDX-RELATIONSHIPS-2026** — SPDX 2.3 relationships between SPDX elements — https://spdx.github.io/spdx-spec/v2.3/relationships-between-SPDX-elements/

- **EXT-K8S-OWNER-DEPENDENTS-2026** — Kubernetes owners and dependents / ownerReferences documentation — https://kubernetes.io/docs/concepts/overview/working-with-objects/owners-dependents/

- **EXT-W3C-ODRL-2-2** — W3C ODRL Information Model 2.2 — https://www.w3.org/TR/odrl-model/
- **EXT-NIST-ABAC-800-162** — NIST SP 800-162 Guide to Attribute Based Access Control Definition and Considerations — https://csrc.nist.gov/pubs/sp/800/162/upd2/final
- **EXT-RFC7519-JWT** — RFC 7519 JSON Web Token (JWT), including the audience claim — https://datatracker.ietf.org/doc/html/rfc7519
- **EXT-RFC8707-OAUTH-RESOURCE** — RFC 8707 Resource Indicators for OAuth 2.0 — https://www.rfc-editor.org/rfc/rfc8707.html

- **EXT-OASIS-XACML-3-0** — OASIS XACML 3.0 Core Specification, obligations and advice associated with authorization responses — https://docs.oasis-open.org/xacml/3.0/xacml-3.0-core-spec-os-en.html

- **EXT-W3C-DPV-2026** — W3C Data Privacy Vocabulary, machine-readable metadata for use and processing of data and technologies — https://w3id.org/dpv/

- **EXT-NIST-OSCAL-ASSESSMENT-RESULTS-2026** — NIST OSCAL Assessment Results model for scoped assessment reports, observations, findings, risks, and expiry posture — https://pages.nist.gov/OSCAL/learn/concepts/layer/assessment/assessment-results/
- **EXT-W3C-VC-DATA-INTEGRITY-2025** — W3C Verifiable Credential Data Integrity 1.0 verification algorithms and verification-result posture — https://www.w3.org/TR/vc-data-integrity/
- **EXT-IN-TOTO-VERIFY-2026** — in-toto verification command documentation for layout expiry, threshold link metadata, authorized functionaries, and artifact-rule checks — https://in-toto.readthedocs.io/en/latest/command-line-tools/in-toto-verify.html

- **EXT-PROMETHEUS-ALERTING-RULES-2026** — Prometheus alerting rules documentation for pending/firing intervals and keep_firing_for anti-flapping posture — https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/

- **EXT-K8S-PROBES-2026** — Kubernetes liveness, readiness, and startup probes documentation for periodic diagnostic checks and readiness/liveness separation — https://kubernetes.io/docs/concepts/workloads/pods/probes/
- **EXT-PROMETHEUS-ALERTMANAGER-2026** — Prometheus Alertmanager alert grouping, deduplication, routing, silencing, and inhibition concepts — https://prometheus.io/docs/alerting/latest/alertmanager/
- **EXT-NIST-SP800-61R3-2025** — NIST SP 800-61 Rev. 3 Incident Response Recommendations and Considerations for Cybersecurity Risk Management — https://csrc.nist.gov/pubs/sp/800/61/r3/final
- **EXT-OTEL-EVENTS-2026** — OpenTelemetry semantic conventions for standalone events represented as LogRecords — https://opentelemetry.io/docs/specs/semconv/general/events/
- **EXT-NIST-OSCAL-POAM-2026** — NIST OSCAL Plan of Action and Milestones model for machine-readable issue/risk/action tracking — https://pages.nist.gov/OSCAL/learn/concepts/layer/assessment/poam/
- **EXT-RFC9413-PROTOCOL-MAINTENANCE** — RFC 9413 Maintaining Robust Protocols, active maintenance and ambiguity reduction over time — https://www.rfc-editor.org/rfc/rfc9413.html

- **EXT-OPA-POLICY-TESTING-2026** — Open Policy Agent policy testing documentation for policy tests and behavior evolution — https://www.openpolicyagent.org/docs/policy-testing
- **EXT-K8S-VALIDATING-ADMISSION-POLICY-2026** — Kubernetes ValidatingAdmissionPolicy documentation for rule-like admission checks, bindings, parameters, and failure behavior — https://kubernetes.io/docs/reference/access-authn-authz/validating-admission-policy/

- **EXT-OPA-POLICY-LANGUAGE-2026** — Open Policy Agent policy language / Rego documentation for declarative rule evaluation and unambiguous queries — https://www.openpolicyagent.org/docs/policy-language
- **EXT-W3C-PROFILES-VOCAB-2019** — W3C Profiles Vocabulary for machine-readable profile resources, roles, and validation/tool links — https://www.w3.org/TR/dx-prof/

- **EXT-OPENFEATURE-FLAG-EVALUATION-2026** — OpenFeature flag evaluation API details for evaluated value, variant, reason, error code, and metadata posture — https://openfeature.dev/specification/sections/flag-evaluation
- **EXT-OPENFEATURE-EVALUATION-CONTEXT-2026** — OpenFeature evaluation context for ambient targeting information used in rule-based evaluation — https://openfeature.dev/specification/sections/evaluation-context
- **EXT-CEDAR-VALIDATION-2026** — Cedar policy validation against schema for entity/action/context shape checks — https://docs.cedarpolicy.com/policies/validation.html

- **EXT-W3C-TRACE-CONTEXT-2026** — W3C Trace Context Recommendation for propagating trace identity and vendor context across service boundaries — https://www.w3.org/TR/trace-context/
