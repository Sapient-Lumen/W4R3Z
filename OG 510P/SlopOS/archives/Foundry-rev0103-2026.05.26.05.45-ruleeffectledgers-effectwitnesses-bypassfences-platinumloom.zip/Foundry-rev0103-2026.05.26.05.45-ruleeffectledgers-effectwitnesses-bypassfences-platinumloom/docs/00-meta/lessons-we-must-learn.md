# Lessons we must learn

Foundry should begin by learning from mistakes that old container, VM, compatibility, and snapshot systems keep making.

## 1) Packaging is not realization
Systems that blur image, bundle, template, runtime config, and live instance make it almost impossible to say what actually ran. Foundry must keep these layers separate.

## 2) “Feels like a container” is not enough truth
Kata-style and confidential-container systems are valuable partly because they reveal how much substrate difference can hide behind a familiar interface. Foundry should not launder that difference away.

## 3) Restore is where overclaiming gets easy
Snapshot and resume systems are useful, but they regularly trip over uniqueness, entropy, time, network state, and stale secrets. Foundry should assume restored continuity is a distinct class of claim, not just “started faster”.

## 4) Interface contracts beat ambient host folklore
Component-model work is compelling because it makes imports, exports, and worlds explicit. Foundry should steal that clarity instead of inheriting giant invisible host assumptions.

## 5) Runtime evidence is not local verdict
Confidential and attested runtimes generate valuable evidence, but the decision about what it means still belongs elsewhere. Foundry should export evidence cleanly and stop there.

## 6) Compat success should stay visibly foreign
A path that “works” through emulation, shims, or helpers can still carry different guarantees. Foundry should keep downgrade posture explicit instead of rewarding every compat success with native status.

## 7) Snapshot files and managers are part of the trust story
Firecracker is an important reminder that snapshot load/resume can be fast while snapshot files and their lifecycle still need separate protection and management. Foundry should not pretend persistence or transport of snapshots is a solved side detail.

## 8) Resume class beats “similar enough” folklore
If a warm image or snapshot is only valid for a reviewed class of hosts, CPU features, or transport surfaces, that class should be explicit. Foundry should prefer reviewed resume classes over best-effort similarity stories.

## 9) Generation witnesses are valuable even when they are not authority
VMGenID-style signals are a useful humility tool: they can tell a guest that continuity changed without claiming that all trust has been re-established.

## rev0005 additions
- Fast restore is not continuity magic; uniqueness, entropy, network assumptions, and freshness-bound evidence may all need reacquire.
- Package format, contract surface, runtime configuration, and live instance lifecycle should stay visibly different even when products want one deployment noun.
- Explicit capability routing and cross-domain policy are more honest than ambient host reachability.

## rev0007 additions
- Smooth cross-ground service use should stay explicit and policy-shaped instead of dissolving into ambient networking or host folklore.
- Generation-change signals are valuable precisely because they force re-evaluation instead of magical continuity.
- Runtime policy inputs and their integrity belong in the story whenever the foreign ground depends on them.
- Foreign-ground capability creation should be routed explicitly into a product or session rather than assumed ambiently.
- Integrity of runtime policy input belongs in the realization story even when confidentiality does not.
- Attestation success and secret/resource release should stay visibly different because they are often governed by different policies.

## rev0008 additions
- Subject-attached sidecars are often healthier than bloating the primary artifact, but attachment is still not the same as completeness or approval.
- Repository-scoped attachment and access control are useful because they keep related material close, not because they prove the foreign realization is acceptable.
- Measured policy input should remain inspectable as part of realization even when the runtime makes the foreign ground feel smooth.
## rev0011 additions
- Subject-attached sidecars are healthier when they stay explicitly attached to a primary artifact instead of impersonating the live realization story.
- Foreign-backed resource handles should remain visibly exterior even when the use-site feels smooth and local.
- Launch/admission success and secret/resource release success should stay visibly different because they are often governed by different policies.

## rev0013 additions
- Resume should expose its repair duties explicitly; otherwise systems overclaim freshness and readiness after restore.
- Foreign power is often variably available across products and configurations, so availability belongs in the meaning model rather than in deployment folklore.
- Nearby attachments need explicit fallback stories; discovery degradation is a first-class truth, not just an implementation detail.


- Smooth access is often a borrowed handle, not a copied local fact.
- Restore obligations need budget and readiness honesty, not hidden amortization folklore.

## rev0014 additions
- Borrowed and owned handle posture matters because a useful foreign thing is not automatically a local thing.
- Availability deserves a floor object: the weakest still-true capability posture after routing or product degradation.
- Restore hooks are a warning that repair work belongs in the public model, not in hidden readiness folklore.

## rev0015 additions
- Missing optional power can be a designed posture, not just a failure, and the model should say so.
- Borrowed foreign handles stay foreign even when the API feels smooth and local.
- Secret or resource release often deserves a separate latch even after attestation and partial readiness succeed.

## rev0016 additions
- Successful launch does not imply full locality when bytes or chunks are still hydrating on demand.
- Prefetch can narrow first-use pain without erasing the remaining locality debt.
- OCI compatibility of packaging does not settle readiness or locality of realization.

## rev0018 additions
- Compatibility should be witnessed explicitly rather than inferred from “it mounted” or “it started”.
- A foreign layer can be useful and still remain detachable, rollback-capable, and visibly non-native.
- Structure and backing cargo often have different locality, sharing, and integrity stories; they should not collapse into one blob.

## rev0018 additions
- Authentic payload bytes and authentic structure are different victories; Foundry should preserve both instead of smearing them into one “verified image” bit.
- Fast start often comes from metadata/bootstrap locality while payload bytes remain elsewhere; bootstrap speed is not full realization.
- Backing stores and Merkle-rooted payload checks are useful, but they still need a separate public story for directory/metadata integrity and later cold reads.

## Pass XIX addition
- Do not collapse configuration overlays into base/runtime cargo. Config-layer compatibility and attach/detach truth deserve their own surface.

## rev0020 additions
- A staged or downloaded generation is smaller than an active realization, even when it already passed integrity and compatibility checks.
- Configuration merge timing is part of realization truth; preparing `/etc` or policy changes too early can drift from the live basis.
- Rollback should be a first-class selector rather than an emergency ritual.
- Config overlays may deserve a smaller default execution posture than runtime/code layers.


## rev0021 additions
- A basis can be active enough to run and still remain only trial truth until an explicit later success mark arrives.
- Boot/install success, bless/commit success, and anti-rollback posture are different facts that should not collapse into one “current version” claim.
- Bounded fallback tries belong in the public model because hidden retry budgets quietly decide whether a new basis was ever durably current.
- Multi-resource basis changes may need coherence and confirmation before a later conflicting basis family is issued, but that wider seam should wait for another specimen.


## rev0023 additions
- Multiple basis pieces that only make sense together should have an explicit coherence target instead of relying on same-version folklore.
- A system should not silently advance to a conflicting newer family while the prior offered family is still unconfirmed; confirmation fences matter.
- Rollout/cohort hints can be operationally useful, but they stay smaller than install intent, currentness, or approval.


## rev0023 additions
- A floating ref, branch, channel, or cohort request is smaller than the exact basis that was actually reviewed, prepared, or activated.
- Exact mutable basis should be bound explicitly; old approval or install intent should not silently follow later selector drift.
- Channel choice, exact version pin, and rollback policy are different facts and should not be flattened into one “track” story.


## rev0025 additions
- An offered update edge or exact basis is smaller than local admissibility; server timing and local timing should not collapse into one truth.
- Local pause, freeze, and maintenance-window state are meaningful facts, not merely transient errors or “no update” responses.
- Rollout cohorts, wariness, and lock-manager scheduling can stay operationally useful while remaining weaker than basis truth or local approval.

## rev0025 additions
- An offered and locally admissible target can still be the wrong direct edge from this exact current state.
- Human-facing version labels are often too coarse; direct applicability may need a sharper prerequisite witness such as a digest, checksum, or state epoch.
- Barrier releases and minimum-version floors are semantically load-bearing; rollback should not be assumed to be the simple inverse of forward applicability.

## rev0026 additions
- A basis can be blessed current and still not leave ordinary rollback untouched; anti-downgrade state often ratchets forward only after an explicit later mark.
- Remembered last-known-good history is smaller than what remains rollback-safe once security/version floors advance.
- When older functional content must return after a floor ratchets, that return should stay visibly on a rescue path instead of impersonating ordinary rollback.


## rev0027 additions
- Basis replacement and persistent-state evolution are different clocks; one successful basis transition should not imply that durable state is still in the same semantic world.
- Explicit storage or config migration beats hidden “the new version will probably cope” folklore.
- Basis rollback may still require reset or reseed; rollback and continuity should not be treated as automatic synonyms.


## Pass XXVIII additions
- Old but still valuable basis/history should stay alive because of explicit roots, pins, leases, or holds, not because cleanup folklore happens to spare it.
- Deletion intent is smaller than collectability when cleanup or external teardown still remains outstanding.
- Retention and reclamation belong in the meaning model whenever rollback, audit, export, or recovery depend on old exact material staying present.


## Pass XXIX additions
- Admission withdrawal, lingering service to pre-existing work, and final reclaimability are different truths.
- A successor realization can become current for new work before its predecessor has honestly drained.
- Grace periods and quiesce boundaries are load-bearing whenever teardown would race old readers, sessions, or connections.

## Pass XXX additions
- A captured cut is smaller than the semantic strength people often project onto the word “snapshot”; crash-consistent, filesystem-consistent, and application-consistent should not collapse into one truth.
- Stronger capture classes usually depend on an explicit pause, flush, or freeze boundary; a write fence deserves to stay visible instead of hiding inside storage folklore.
- Restore may still owe replay or repair work after a valid cut is accepted; “restorable” and “comfortably resumed” are different facts.

## Pass XXXI additions
- A new desired basis/spec/request can already be real while green status still belongs to an older generation.
- Status should say which desired generation it actually reflects; otherwise old success surfaces silently overclaim freshness.
- Acceptance, application, and completion are often three different clocks, and a stale-status fence is healthier than one triumphant currentness badge.

## rev0032 additions
- Authoritative commit and local visibility often live on different clocks; systems that flatten them end up lying about freshness.
- Ordinary lag and replay-bridgeability are different truths; once history is compacted or retired, only snapshot/reseed remains honest.
- Progress beacons are useful evidence, but they are still smaller than an actual claim about applied visibility or repairability.


## rev0033 additions
- Local apply/load truth can still be smaller than what readers, traffic, or queries may honestly observe now.
- Warming, transactional isolation, and read-safety fences are load-bearing; they should not hide inside one cheerful active/ready bit.
- A withheld newer tail is a real fact, not an absence of facts; systems often carry newer state before they are ready to expose it.


## Pass XXXIV additions
- A newer current owner, leader, or active holder is smaller than proof that older holders can no longer mutate or serve authoritative results.
- Correct failover often needs an explicit monotonic fence witness; graceful shutdown alone is too optimistic.
- Write fencing and total disappearance are different promises; an older holder can be non-authoritative before it is fully gone.

## Pass XXXV additions
- A retry-equivalent request key is smaller than target identity, current live state, and current settlement.
- Reusing the same key only stays honest while the exact request or reviewed effect fingerprint still matches; changed meaning under the old key should fail before effect.
- Historical replay of a prior accepted answer is useful, but it is still smaller than fresh execution, present liveness, or a forever exactly-once guarantee.


## rev0036 additions
- The same effect key can still mean “original work is outstanding” rather than “replay the prior result”; timing class matters.
- Duplicate-safe retry memory should be modeled as a bounded horizon, not as a forever ledger of remembered effects.
- Expiry of duplicate memory is different from request mismatch and different from current live-state failure; the cube should keep those truths separate.


## rev0037 additions
- Simple absence, intentional gone/withdrawn state, and safe purge or reuse are different truths.
- Ordinary reads can truthfully return not-found while a tombstone or delete marker still exists and earlier history remains recoverable.
- Negative knowledge is often bounded, and purging withdrawal markers too early can resurrect stale data or misbind old identity.

## rev0038 additions
- Exact issued evidence is smaller than current validity; a token, lease descriptor, or certificate can remain exact while no longer being usable now.
- Revocation, expiry, and context-specific applicability are all current-state pressures that often require a separate live-validity witness instead of faith in the original artifact.
- Positive validity answers age; a recheck horizon or intentionally short-lived artifact is healthier than pretending yesterday's “good” answer is timeless.

## rev0039 additions
- A session or token can remain currently valid while still being too weak, too old, or insufficiently user-intended for one sensitive action.
- Assurance labels are often context-local and should not silently become a universal platform hierarchy.
- Present user intent, simple presence, and stronger local user verification are different facts and should not collapse into one cheerful authenticated bit.



## rev0040 additions
- A live-valid and even high-assurance artifact can still be unusable when presented by the wrong holder/key/channel.
- Receiver specificity is load-bearing; the same artifact may be good at one resource and wrong at another.
- Exact request-shaped proof is smaller than general live validity; method, route, nonce, or token-hash binding should not hide inside one cheerful authenticated bit.


## rev0041 additions
- A narrowed child artifact is smaller than its parent; reviewed derivation should stay visible instead of masquerading as raw-parent export.
- Healthy delegation/downscope stories are upper-bounded and attenuation-only; the child should never quietly broaden what the parent could do.
- Parent expiry, revocation, or lineage invalidation can continue to shadow descendants; standalone parseability is smaller than independent authority.

## Pass XLI additions
- **derivation witness** — exact parent-to-child lineage witness for one narrowed descendant artifact.
- **attenuation fence** — explicit upper-bound narrowing across target, action, audience, time, use, or condition.
- **ancestor shadow** — visible rule that parent or lineage state can still narrow descendant truth.
- **discharge witness** — parked future residue for third-party or contextual proof that satisfies one carried caveat.
- **child smaller than parent** — a standing anti-regrowth rule.


## rev0042 additions
- A derived child can still be unusable until one exact outside or contextual proof satisfies one carried caveat; child existence and caveat satisfaction are different truths.
- Carrying or showing prior actors is not the same as promoting them into current authority; audit/history should stay smaller than top-level claims and current actor truth.
- The safest steal is the carry-the-proof pattern, but only with explicit trusted-scope selection and current-actor primacy.

### New compact vocabulary under pressure
- **discharge witness** — exact outside or contextual proof that satisfies one carried caveat for one derived artifact.
- **caveat hold** — visible rule that one child artifact remains insufficient or withheld until one required caveat is satisfied.
- **actor-path card** — compact ordered multi-hop delegation trail kept for audit or continuity without promoting prior actors into current authority.

## Pass XLIII additions
- Datacubes need explicit evolution posture: candidate/development/stable/deprecated beats silent semantic drift.
- A human-friendly JSON export is not automatically a safe long-term compatibility contract.
- Status or summary surfaces should say which revision/generation they actually reflect; otherwise lag masquerades as truth.
- Unknown or unspecified posture is healthier than a boolean that will obviously need a third state later.
- Registries and semantic layers are expensive; earn them with repeated pressure instead of inventing them for elegance.

## Pass XLIV additions
- effective time and record time may need to stay visibly different where correction or late arrival matters.
- pending context is healthier than forcing fake completeness when real facts arrive before all descriptive joins settle.
- pre-aggregated exports and read models should stay visibly derived instead of impersonating cube truth.

## Pass XLV additions
- declare what one row means before letting dimension or measure debate bloom; grain comes first.
- snapshots, deltas, cumulative totals, and derived query results may all look numeric while obeying different aggregation laws.
- units and exactness should stay explicit instead of hiding inside names or dashboard folklore.
- ratios, distinct counts, and similar friendly outputs are often healthiest when derived from additive components rather than canonized as atomic facts.

## Pass XLVI additions
- a count, ratio, or “affected total” needs a declared population frame before it deserves interpretation.
- categories that look sibling-shaped may still overlap; additive rollup is a claim, not a default.
- absence and completion claims require visible coverage posture, not just observed activity rows.
- whole-population identity and subset identity are different truths and should not silently share one denominator.

## Pass XLVII additions
- Stable joins need identity smaller than current names, labels, or archive paths.
- Descriptive truth can move over time without changing the underlying member, so current labels should often be snapshots rather than timeless identity.
- Rename-safe evolution works better when identity is explicit and name changes are treated as metadata evolution instead of deletion-plus-creation folklore.
- Helpful labels are not automatically healthy cube axes; boundedness and grouping safety need explicit review.
- Design-phase family regrouping is editorial motion, not necessarily semantic replacement.
## Pass XLIX additions
- Values that look equally numeric may still belong to different exactness classes: exact-at-cut, bounded-estimate, advisory-rank, or query-shaped only.
- Approximate answers are healthiest when their bound witness stays explicit instead of hiding in engine folklore.
- Some ranked outputs are useful but not guaranteed; helpful order is smaller than exact ordered truth.
- Even exact values may remain restatable for a while, so correction horizons should stay visible when late-arrival or finalization lag matters.
- Snapshot counts, advisory hints, and approximate distincts should not silently share one denominator story.

## Pass L additions
- Derived values need a small **input cut** so branch-like or latest-like intent does not impersonate the actual source state.
- A compact **recipe witness** beats post-hoc folklore about which query, transform, or parameters produced a result.
- **Replay class** should distinguish replayable-from-pins, conditionally restatable, and advisory snapshot outputs.
- Execution metadata should be attached from the actual execution/materialization path, not from side hooks that can drift on retry.
- A standing anti-regrowth rule: **lineage smaller than reproducibility theater**.

## Pass LI additions
- Fast summaries, rollups, and pre-aggregations can stay useful while still losing row-level freedom; the loss should be explicit rather than hidden behind a friendly number.
- Some reductions are semantically safe only for the right aggregate kinds, so legal reaggregation should stay visibly different from arbitrary compression or synopsis.
- A bounded breadcrumb to one concrete contributing artifact can be more honest than either “no drill-through at all” or a premature universal lineage graph.
- Raw-retention posture is separate from summary validity: a correct aggregate may still be hot-drillable, cold-only, policy-blocked, or beyond retention.
- Once a projection or acceleration artifact becomes sticky to remove, it is already too expensive to have been treated as casual vocabulary.

## Pass LII additions
- The same count can stop being the same truth once an explicit view, row filter, masking rule, or export tier shapes what was visible.
- Masked, sanitized, threshold-gated, and fully visible payloads are different disclosure classes even when they share a field name.
- Cross-lens arithmetic is a claim, not a default; some values are only comparable inside one lens or only by monotone relation.
- Security-shaped views may legitimately reject faster plans or richer metadata if that is what secrecy requires.
- Aggregate release policies are a useful fence, but still smaller than a full privacy product.

## Pass LIII additions
- Page-shaped and cursor-shaped results are smaller than whole-population truth unless the cube keeps the slice semantics explicit.
- A query total is not one thing: exact, lower-bound, estimated, page-local, and unknown totals should not share one flattering field.
- Stable ordering is part of slice honesty; LIMIT/OFFSET without a declared ordering can yield an unpredictable subset.
- Continuation state can be useful without promising permanent resumability or result stability.
- Query convenience is smaller than durable population truth.

## Pass LIV additions
- event timestamps and closure frontiers are different truths; a bucket can look timely while still being explicitly incomplete.
- preview, on-time, reopenable, and finalized are different closure classes and should not silently share one row family.
- watermark/grace/lookback policy is part of result meaning, not just engine tuning.
- freshness claims should align with late-arrival apertures or the dashboard will overstate completeness.
- dropping late arrivals after a grace or trigger boundary is a semantic choice that should stay visible.


## Pass LV additions
- Ranked convenience is not the same thing as durable truth; the ordering recipe belongs in the public meaning, not in UI folklore.
- Score numbers are method-local and phase-local; BM25, distance, fusion, reranker, and unscored field order should not collapse into one generic scalar family.
- Stable windows/pages require an explicit tie-break story; repeated ranked views otherwise drift under equal scores and planner changes.

## Pass LVI additions
- Reconciled or winner-shaped rows are smaller than settled truth; the cube should remember how the winner was chosen.
- Ambiguity is a real semantic result, not merely an ETL failure or operator inconvenience.
- Losing candidates often deserve lightweight retention so later audit, replay, or policy change can revisit the decision.

## Pass LVII additions
- Sampled and preview-shaped values are smaller than population truth; the cube should say so explicitly.
- Deterministic/keyed samples, probabilistic keeps, block samples, and bounded previews are different species and should not share one generic “sampled” bit.
- Any lawful scale-up from a sample needs explicit factor/probability residue or an explicit refusal to expand.

## Pass LVIII additions
- Units should ride beside values as explicit machine-readable meaning instead of hiding inside names, dashboards, or tribal memory.
- Canonical base scales are healthier for interchange and aggregation than pretty display scales; bytes beat bits, seconds beat milliseconds, and ratios beat percentages.
- Some conversions are linear, some are affine, some are only display transforms, and some arbitrary/provider-native units should not be normalized at all.

## Pass LIX additions
- A lower number is not automatically subtraction or debt; it may be a visible reset boundary.
- Cumulative, per-period, since-restart, and expiring-lease values can all look “total-like” while obeying different continuity rules.
- Carryover is policy, not arithmetic folklore; some boundaries preserve nothing while others preserve tier or credit state.
- Reset detection can make stitching healthier, but precise reset time or lawful continuity may still remain bounded or unknown.
## Pass LX additions
- Shared or blended values are smaller than native facts unless the cube keeps the split rule explicit.
- Idle, overhead, unused-commitment, and rounding leftovers are different residues and should not silently disappear into recipient rows.
- Weighted or apportioned rows can conserve a source total locally while still remaining incomparable across bases.
- Allocation methodology belongs in public meaning, not in ETL folklore or finance tribal memory.
## Pass LXI additions
- Product semantic-layer taxonomies can change materially even when the underlying need is stable, so vendor nouns should stay smaller than archive law.
- Logical meaning and physical acceleration/layout are different truths and should not silently share one ontology.
- Design-time declarations and runtime observations are different truths; additive updates are healthier than magical overwrites.
- Experimental metadata should be namespaced and schema-pinned before it is standardized.
- Pinned cuts and explicit branches/tags are healthier than mutable “latest” folklore when experimentation is still active.
- Column-level lineage can be valuable while still remaining adjunct-sized rather than mandatory cube spine.

## Pass LXII additions
- A version number without a reviewed translation story is not yet comparability.
- Lossless rename, lossy rebucketing, deprecated source, and genuine incompatibility are different species and should not share one flattering “current” status.
- Old history is healthier when preserved under its original schema pin and only interpreted forward through explicit reviewed witnesses.
- Deprecation is healthier than name reuse, silent disappearance, or magical latest-version normalization.

## Pass LXIII additions
- Required support and optional support are different contracts; the cube should say which meaning families a reader actually understood.
- Unknown fields, enums, and adjuncts are often healthier when preserved than when flattened into friendly defaults.
- Convenience JSON/export surfaces are often exactly where unread semantics get lost; binary/pinned preservation deserves stronger trust.
- Partial understanding is smaller than absence; unread should not silently become false/none/zero.
- Stable-by-default plus opt-in experimental semantics is healthier than forcing every new family into one universal core.

## Pass LXIV additions
- Profiles are healthiest when they add constraints/conventions/extensions without pretending they changed base representation semantics.
- Multiple profiles need explicit precedence or explicit refusal; hidden consumer-local override folklore is not good enough.
- A tight base dialect plus optional overlays is healthier than one universal always-on profile stack.
- Stable-by-default with explicit opt-in overlays is healthier than hidden ambient activation.
- Once a profile changes base subject/measure/unit/schema truth, it should become a new lens, translation, or schema pin instead.

## Pass LXV additions
- Immutable version/snapshot identity is healthier than clock-only history lookup when reproducibility matters.
- Historical reinterpretation should be explicit restatement, not ambient latest-semantics overwrite.
- Producer/consumer migration windows are semantic state, not just operational clutter.
- Historical cuts can stay inspectable without being promoted to ambient current truth.
- A timestamp alone does not capture which schema/profile/history cut shaped an answer.

## Pass LXVI additions
- Mutable-source rows need an explicit ordering basis; one generic timestamp is too flattering.
- Snapshot rows, change rows, tombstones, invalidations, and descriptor-not-state rows are different species and should not share one generic “latest row” story.
- Delete handling is policy, not folklore; disappearance, invalidation, tombstone, and delete-marked new rows are distinct semantics.
- Change history can be bounded by schema and retention windows, so useful CDC surfaces are often weaker than permanent semantic memory.
- Complete for a cut is smaller than final forever; mutable-source answers need explicit revision posture.

## Pass LXVII additions
- Count-like values can disagree about what was counted once: native row, distinct subject, bridge association, higher-grain target, and sketch estimate are different species.
- Join safety is semantic residue, not just SQL shape; fanout and chasm posture should be preserved rather than inferred later from folklore.
- Higher-grain facts and management summaries should refuse drilldown below their lawful level rather than returning flattering nonsense.
- Distinct counts and approximate distinct counts may both look like counts while obeying different re-rollup laws.
- Bridge tables preserve relationship truth, but relationship truth is smaller than automatic additive truth.

## Pass LXVIII additions
- Percentages, rates, and averages need an explicit denominator story; a friendly label is not enough.
- Some ratios are display overlays or already-aggregated source answers and should not be casually re-aggregated.
- Coverage and completeness percentages need an opportunity set, not just an activity table.
- Ratio parts often deserve retention because recompute-from-parts is healthier than average-of-averages folklore.

## Pass LXIX additions
- **match cluster** — compact residue for candidate same-subject material that has not yet earned native identity promotion.
- **survivorship witness** — compact residue for how a representative row or value was chosen.
- **golden-row fence** — compact refusal boundary against treating a representative row as native truth everywhere.
- **cluster smaller than subject** — a standing anti-folklore rule.
- **survivor smaller than ontology** — a standing anti-regrowth rule.

## Pass LXX additions
- **assertion class** — compact residue for whether a row is a native observation, imported claim, validation result, policy verdict, heuristic score, or manual annotation.
- **confidence basis** — compact residue for what confidence, severity, or score means and whether unspecified differs from zero/fail.
- **verdict fence** — compact refusal boundary against treating advisory, local, or heuristic outcomes as source truth.
- **score smaller than fact** — a standing anti-folklore rule.
- **local verdict smaller than ontology** — a standing anti-regrowth rule.

## Pass LXXI additions
- **blank class** — compact residue for why a visible value is blank: unknown, masked, not applicable, unsupported, delete sentinel, or implicit-default-absent.
- **applicability basis** — compact residue for whether the value ever properly applied here and why it may be absent now.
- **coercion fence** — compact refusal boundary against turning blanks into `0`, `false`, empty string, deletion, or grouped “none” without review.
- **blank smaller than fact** — a standing anti-folklore rule.
- **rectangular export smaller than source semantics** — a standing anti-regrowth rule.



## Pass LXXII additions
- Eligibility is semantic residue, not just a WHERE clause; a measured row needs to say why it belonged to the counted world.
- Excluded, excepted, waived, out-of-scope, and non-claim cases are different species and should not share one flattering “not counted” bit.
- Summary reports are smaller than subject lists; a useful scoped count does not automatically imply enumerated whole-world truth.
- Error budgets and compliance always ride on an eligible event/window story, not on vague platform-total folklore.

## Pass LXXIII additions
- Bucket layout is semantic residue, not display chrome; thresholds belong to the meaning of the exported value.
- Qualitative severity and rough interpretation are smaller than the underlying scalar or evidence stack.
- Threshold drift breaks flattering comparability long before a human notices the badge text stayed the same.
- Bands, buckets, and badges need explicit fences before they can impersonate arithmetic truth.



## Pass LXXIV additions
- Thin semantic spines age better than giant vendor-shaped semantic-layer taxonomies.
- Materialized query results, rollups, and aggregate-aware tables are serving lanes, not canonical fact truth.
- Mutable heads, floating branches, and default-latest selectors are smaller than pinned snapshot/tag cuts when replay and audit matter.
- Temporality and monotonicity are semantic meaning, not formatting; delta/cumulative and counter/gauge posture must stay explicit.
- Assertions, lineage, and execution-parameter residue are valuable precisely because they remain smaller than the result family they verify or explain.

## Pass LXXV additions
- Browser mediation is not durable identity truth: choosers, account lists, provider config, login hints, and disconnect choreography are scoped evidence, not native account/session state.
- Login status is an identity hint, not a server-state oracle; unknown, stale, self-declared, and provider-local values must stay weaker than current truth.
- Prompt, activation, policy approval, legal consent, and reusable authorization basis are separate surfaces and must not be collapsed into one friendly prompt receipt.
- Trust chains, trust anchors, metadata policies, Trust Marks, and credential signatures are scoped witnesses, not global trust or issuer-suitability truth.
- Opaque or encrypted credential responses can improve privacy while reducing what the mediator can know; absence of mediator visibility is not a wallet inventory, all-claims view, or unlinkability guarantee.
- Grain comes before dimensions: every candidate observation family must state one-row meaning before choosing axes, measures, slices, or display names.


## Pass LXXVI additions
- A query result is a derived surface, not the cube; it needs to say what was asked, what cut/lens governed it, and what replay class applies.
- Display order is not semantic order unless the result carries an explicit ordering posture and tie-break witness.
- Data contracts, validation results, lineage, catalogs, and quality assertions are neighboring witnesses, not one fused trust object.
- Storage layout and multidimensional metadata are useful, but chunks, grids, files, manifests, dimensions, coordinates, and variables must not collapse into one ontology.
- Validation success is smaller than source truth; warnings, failures, skips, exemptions, and not-run checks must stay visibly distinct.

## Pass LXXVII additions
- Hierarchy is not aggregation law; parentage, presentation order, availability, valid combinations, and summation need separate witnesses.
- Calendar buckets need a calendar lens because week/year/fiscal/reporting boundaries can change the bucket a date belongs to.
- Geography rollups need a cut and relation kind; administrative boundaries, statistical geographies, legal releases, and grid containment are not interchangeable.
- Storage paths, Hive partitions, chunk grids, and manifests are physical organization until a semantic hierarchy scope says otherwise.
- A parent row is reusable only along the rollup path and aggregation guard that produced it.

## Pass LXXVIII additions
- Cache hits are not lawful reuse; reuse must be fenced by query contract, audience, policy/disclosure lens, schema/profile, calendar/geography lens, rollup path, validation state, and staleness posture.
- A materialized object needs a materialization cut: source cut, recipe version, build run, dependency cards, and output digest stay visible.
- Refresh success is not validation success, and validation success is not source truth.
- Target lag is a budget, not an observed freshness witness.
- Stale-if-error serving can be useful, but it must be visible, bounded, and smaller than current truth.

## Pass LXXIX additions
- Aggregate outputs can still disclose protected units; row export is not the only leakage path.
- Suppression is release-set residue, not null, zero, unknown, or absence.
- Primary suppression and complementary suppression must stay visibly distinct so margins and sibling cells do not reconstruct hidden values.
- Privacy-unit basis is part of the answer; row count, user count, device count, tenant count, household count, and company count are not interchangeable.
- Contribution bounds, noise family, perturbation method, and privacy-budget posture shape the meaning of released aggregates.
- Privacy budget refresh is a disclosure-composition fact, not just a freshness/materialization refresh.
- Clean-room output constraints and minimum group sizes are useful fences, but they are smaller than source truth, local authorization, or a publication-safety verdict.
- Differencing across neighboring queries, time windows, release sets, or audiences must cross an explicit fence before totals and subtotals are subtracted.

## Pass LXXX additions
- Keep **as-observed**, **estimated**, **imputed**, **provisional**, **revised**, **adjusted**, **forecast**, **processor-derived**, **synthetic**, **substituted**, **quality-flagged**, and **unknown** visibly distinct.
- Preserve an **observation-status card** near the value instead of relying on prose, chart labels, or dropped export columns.
- Use an **adjustment witness** for method family, recipe/model/spec digest, input cut, side-input cut, axis/window, diagnostics, and original-value retention posture.
- Put an **as-observed fence** around non-raw values so imputed or adjusted cells cannot answer raw-evidence queries, backfill source history, or mix into unadjusted denominators by accident.
- Treat **latest revised value smaller than historical vintage** as a standing anti-regrowth rule.
- Treat **status survives cache/export/chart** as a standing hygiene rule.

## Pass LXXXI additions
- **Balanced is not true** — arithmetic consistency or a green validation check is only one scoped result; it does not prove completeness, currentness, privacy safety, or source authority.
- **Control totals are scoped artifacts** — every total/margin/mirror needs scope, measure, unit, cut, lens, source family, and tolerance basis before it can discipline components.
- **Residuals need classes** — zero, rounding, truncation, duplicate conflict, hidden suppression, redaction, noise, imputation, stale cut, and unexplained imbalance are different stories.
- **Mirror checks are not winner selection** — cross-source disagreements should produce a reconciliation witness, not a silent authoritative replacement.
- **Suppression-aware totals must not leak hidden siblings** — a mismatch between visible components and total can be correct, and subtraction/drilldown may need refusal.
- **Rule digests beat premature DSLs** — pin the rule/profile/check expression that ran, but do not freeze one validation language as Foundry core.
- **Not-run is a real outcome** — design-phase surfaces, streaming cuts, missing evidence, or policy blocks may legitimately carry no reconciliation witness yet.
- **Forced balance is data laundering** — adding a fake other/residual row without a residue class and policy basis hides rather than fixes semantic debt.

## Pass LXXXII additions
- **Codes are local to a classification pin** — a bare code is not meaning until scheme, version/cut, namespace, member id, label, language, and status are named.
- **Labels are not keys** — display text may change for audience, locale, accessibility, or product clarity and must not become join, rollup, or comparison identity.
- **Mappings are witnesses, not upgrades** — a crosswalk/correspondence table can support one reviewed use, but it does not erase native history or become reversible by default.
- **Split and merge are cardinality scars** — one-to-one renames, one-to-many splits, many-to-one merges, and many-to-many mappings need different fences.
- **Deprecated is not deleted** — old category members should remain readable under their native lens instead of being recycled, hidden, or silently rewritten.
- **Same code does not mean same concept** — profile-local and scheme-local codes collide constantly; no bare-code grouping across pins.
- **Classification parentage is not aggregation law** — broader/narrower, code-list hierarchy, and correspondence position require separate rollup/aggregation evidence before arithmetic.
- **Unmapped is a first-class residue** — unresolved legacy or imported codes are not null, zero, `other`, failure, or current-category truth.

## Pass LXXXIII additions
- Tidy egress is the datacube danger zone: charts, CSVs, JSON exports, markdown summaries, support cards, and dashboard tiles can erase the residue that made a result meaningful.
- A sidecar digest is useful only when the sidecar carries cuts, witnesses, fences, and loss posture; it is not source truth or policy approval.
- Refusal is a feature: label-only, code-only, status-free, suppression-free, balance-free, or stale-cut exports should fail before they become believable folklore.
- Fixture pressure beats repeated open questions; a proposed noun should have at least one tiny case that fails without it.

## Pass LXXXIV additions
- Refusal is a semantic artifact, not just missing output, a log line, or a generic error.
- A safe refusal names the requested surface, rule id, semantic loss, and repair escapes before humans retry unsafe shapes elsewhere.
- Problem-details-shaped payloads are useful, but Foundry must not confuse typed refusal with HTTP transport doctrine or policy denial.
- An egress manifest is smaller than the source result; it records how a result tried to leave, not what the source truth is.
- A conformance gate is smaller than a verdict; it proves only that a local egress attempt had residue, sidecar, or receipt.


## Pass LXXXV additions
- **Compatibility is not a version bump** — a newer revision and a tidy changelog do not prove old egress residue still means the same thing.
- **Digest strings are smaller than semantic approval** — canonical bytes and hashes are useful witnesses, not trust, migration, or compatibility verdicts.
- **Schema validity is not regression safety** — well-formed sidecars, receipts, and manifests can still lose pins, cuts, statuses, loss profiles, or repair escapes.
- **Regression locks are fixture alarms** — they protect known semantic seams without becoming permanent policy guarantees.
- **Tamper cases beat prose warnings** — known dishonest mutations should fail deterministically before a new revision is considered clean.
- **JSON Patch-style operations are not migrations** — path-scoped mutations are useful for tests, but reviewed migration witnesses carry semantic authority.


## Pass LXXXVI additions
- **Waiver is not success** — a bounded exception must stay linked to the refusal or regression alarm it temporarily tolerates.
- **Expiry is semantic residue** — if a waiver expires only in a calendar reminder, it will become folklore.
- **Scope is part of the waiver** — consumer, cut, surface, revision, audience, and rule ids cannot widen silently.
- **Reviewer and owner must stay distinct** — fixture-local exceptions still need separation between requester and reviewer.
- **Non-waivable residue stays non-waivable** — classification pins, source cuts, suppression posture, balance residue, and query/result contracts cannot be waived into absence.
- **Renewal means replay** — carrying an exception forward requires rerunning the relevant refusal, regression, and waiver rules.

## Pass LXXXVII additions
- **Stable carrier is not stable interpretation** — sidecars, receipts, locks, waivers, and digests can remain unchanged while becoming invalid for a new consumer.
- **Consumer purpose is semantic residue** — review, operation, display, appraisal, and audit-like use need different inferences and fences.
- **Portable residue is not portable authority** — Foundry can move evidence, not SlopOS proof claims, Ward verdicts, ViewFS identity, Harbor membrane status, Steward lifecycle finality, Schell retention authority, or Helm repair consequence.
- **Forbidden inferences belong in the carrier** — saying what must not be inferred is part of preserving meaning.
- **Waivers must be rechecked on consumer change** — a waiver scoped to one consumer or audience cannot travel as default success.
- **Interpretation gates beat consumer folklore** — a target consumer must rerun named checks before treating carried residue as meaningful.


## Pass LXXXVIII additions
- **Delegation is not authority transfer** — a worker or notebook can carry residue without inheriting permission, approval, verdict, source truth, or sibling authority.
- **Actor chains need current-actor humility** — prior actors help audit the handoff, but they do not automatically become current relying-consumer authority.
- **Reliance must leave a receipt** — a relying consumer should record which warrant, acts, rules, residue, and refused inferences shaped the use.
- **Withheld residue is semantic residue too** — saying what did not travel prevents operator hints, waiver-as-approval, or sibling verdicts from leaking through a packet.
- **Delegation defaults to non-transitive** — purpose widening, audience widening, redelegation, or downstream research reuse needs a new warrant or a refusal.
- **Expired and revoked warrants fail even when bytes are unchanged** — a stable sidecar digest does not keep a delegation alive.

## Pass LXXXIX additions
- **Revocation is not deletion** — a carrier can become unsafe without erasing source rows, old receipts, or historical evidence.
- **Unchanged bytes can still be stale** — a matching digest does not prove the consumer saw the newest status notice or recall requirement.
- **Recall must be consumer-local** — one consumer's acknowledgment does not satisfy another consumer's purpose, audience, cache, or gate obligations.
- **Quarantine is not forgetting** — holding or blocking a stale surface is smaller than Schell retention authority or legal hold.
- **Replacement is not repair by implication** — a superseding artifact must be explicit and must not silently bless old reliance.
- **Status strings are not authority** — revoked, superseded, rescinded, and informational notices are carrier-status facts, not Ward verdicts, SlopOS truth, or Harbor external status.

## Pass XC additions
- **Replacement is not readmission** — a newer artifact, digest, sidecar id, cache refresh, or dashboard tile does not prove the recalled semantic loss was repaired.
- **Readmission is consumer-local** — an audit notebook gate does not admit Ward, dashboard cache, public export, ViewFS projection, or sibling authority.
- **Witness the repair class** — a replacement must name what semantic loss changed: pin restored, cut added, suppression restored, status preserved, loss profile repaired, or still missing.
- **Old history stays old** — recalled carriers, receipts, and caches remain citeable as recalled history instead of being rewritten into success.
- **Partial repair is a first-class posture** — partial replacement can be admitted for one narrow use while remaining blocked for verdict, public release, or transitive reuse.
- **Reopened means quarantined again** — a later notice covering an accepted replacement must reopen the packet and rerun gates before further reliance.

## Pass XCI additions
- **Readmitted is not distributed** — a replacement that passed a consumer-local readmission gate may still be absent from caches, notebooks, projections, delegated workers, or exports.
- **Delivery is not adoption** — support-bundle delivery, queue publish, cache refresh, registry reference, or file upload is weaker than a residue-carrying adoption receipt.
- **Old copies need posture** — stale artifacts must be retired as recalled history, quarantined, refused, or fenced; silence leaves them dangerous.
- **Propagation windows expose stragglers** — missing receipts after the window are not implicit success.
- **Adoption is not transitive** — audit adoption does not admit Ward, ViewFS, dashboard cache, public export, or delegated workers.
- **Partial adoption stays partial** — a preview can be useful without becoming Ward verdict, ViewFS custody, Harbor remediation, Helm repair completion, or SlopOS proof.

## Pass XCII additions

- Treat distribution target lists as seeds, not as the discovered universe.
- A failed listing or permission-denied zone is not absence; leave a coverage-gap fence and recheck hook.
- Alias matches and digest matches are not adoption receipts unless a reachability witness ties them to a canonical surface and local gate.

## Pass XCIII additions
- **Found is not safe-for-audience** — inventory can prove a surface exists without proving who should read it or why.
- **Audience is semantic residue** — operator group, service principal, external auditor, sibling cube, inherited group, unknown reader, and public web are different exposure stories.
- **Purpose is smaller than access** — the same reader may be allowed to render a dashboard but not to reuse a value as a Ward verdict, public release, source truth, or audit opinion.
- **Inherited access is not intended audience** — parent project, folder, workspace, or object-store ACL inheritance needs a witness and usually a fence before reuse.
- **Public link is not consent** — anonymous reachability does not become release approval, privacy basis, deletion proof, or authorization.
- **Exposure needs recency** — stale ACL snapshots and expired ledger windows should not close exposure checks.
- **Purpose fences preserve optionality** — blocking a widened purpose is not deletion, repair, or policy denial; it is semantic honesty until the right authority acts.

## Pass XCIV additions
- Exposure is not obligation satisfaction; a visible surface can still shed the semantic duties that made it interpretable.
- No-reexport, recall, sidecar, classification-pin, observation-status, and sibling-boundary obligations need carriers or refusal, not prose hope.
- Acknowledgment is scoped evidence, not permission, legal compliance, consent, public release, deletion, audit, custody, or sibling verdict.
- Public links and inherited groups are obligation-drift accelerants; they need fences before reuse.

## Pass XCV additions
- **Acknowledged is not fulfilled** — accepting a semantic duty does not prove the sidecar, pins, warning, recall route, no-reexport boundary, recheck, quarantine, or sibling boundary was actually carried out.
- **Completion is scoped evidence** — a completion witness for one consumer, surface, audience, purpose, carrier, and deadline cannot clear another boundary.
- **Deadlines are semantic residue** — recheck-after-execute and recall-after-release are different from before-reuse fulfillment.
- **Nonfulfillment is first-class** — pending, missed, refused, quarantined, public-link, inherited, and digest-mismatched duties need fences rather than folklore.
- **Fulfillment is not authority** — satisfying a semantic duty is not authorization, legal compliance, consent, public release, deletion, audit opinion, custody, repair completion, lifecycle finality, or sibling verdict.

## Pass XCVI additions
- **Completed is not verified** — a completion witness is a claim about duty discharge, not proof that the claim survived probing.
- **Samples are scoped and non-exhaustive** — a verified sample for one consumer, surface, audience, purpose, carrier, and probe basis cannot clear another boundary.
- **Contradiction is stronger than closure** — a sidecarless public CSV, stale inherited-access snapshot, or execute-before-recheck log must fence the completion claim it contradicts.
- **Verifier independence matters** — self-verification can be evidence, but only as conflicted evidence that needs a false-closure fence.
- **Verification is not audit opinion** — Foundry can record probes, samples, warnings, and errors without becoming compliance, certification, cryptographic proof, or sibling verdict.
- **The harness is a cube surface** — as checkers multiply, runner registration and fixture coverage become semantic drift risks too.

## Pass XCVII additions
- **Verified is not still-fresh** — a passing verification audit is a point-in-time result until a cadence and drift signals keep it live.
- **Clear signals are scoped** — a clear sidecar or recall-route probe does not clear unsampled surfaces, audiences, purposes, or future windows.
- **Flapping is evidence** — alternating pass/fail probes should fence reuse instead of being averaged into green.
- **Paused means not active** — retired or paused surfaces need recheck-before-reuse, not active freshness badges.
- **Monitoring words are dangerous** — alerts, probes, firing, readiness, and freshness are useful scars, not Foundry authority.
- **Coverage is not correctness** — a schema/fixture/checker manifest catches missing executable surfaces, but it does not prove the ontology is right.

## Pass XCVIII additions
- **Routed is not handled** — delivery, queueing, grouping, dedupe, inhibition, acknowledgment, or ticket shape does not clear drift.
- **Route residue must survive grouping** — dedupe cannot drop carrier ids, signal ids, fences, audiences, purposes, or blocked inferences.
- **Inhibition needs a fence** — silenced or inhibited semantic risk is not resolved; it must remain visible as unresolved.
- **Acknowledgment is weaker than resolution** — a receiver can know about a packet while reuse, public exposure, worker execution, or sibling promotion remains blocked.
- **Routing is consumer-local** — Ward, ViewFS, Harbor, SlopOS, and worker routes do not substitute for one another.
- **Specimen docs need executable twins** — a new specimen without rulebook, fixture, schemas, checker, runner entry, and docs-map coverage is prose drift.


## Pass XCIX additions
- **Routed is not resolved** — delivery, acknowledgment, ticket closure, duplicate labels, transfer labels, or pager state do not prove semantic disposition.
- **Disposition is scoped evidence** — a closure for one packet, consumer, surface, audience, purpose, and carrier cannot clear another one.
- **Transfer is not closure** — a handoff needs receiving scope, residual fences, and a resolution witness before reuse.
- **False positive needs contradiction** — a local “not a problem” label must carry contradictory evidence or remain fenced.
- **Fence clearance is explicit** — unresolved-signal fences and premature-closure fences do not vanish because a reviewer wrote resolved.
- **Closure is not authority** — Foundry closure evidence is not authorization, audit opinion, public-release approval, repair success, lifecycle finality, or sibling verdict.
- **Negative-case manifests are harness hygiene** — listing hard failures keeps fixture claims from drifting, but it does not prove completeness or semantic correctness.


## Pass C additions
- **Resolved is not reusable law** — closure, duplicate, false-positive, transfer, quarantine, or reviewer disposition must not become a rule without precedent and promotion evidence.
- **Precedent is scoped** — source ledger, witness, fence, carrier, consumer, surface, audience, and purpose residue must survive rule reuse.
- **Promotion needs negative cases** — positive examples alone create overfit archive law.
- **Deprecated is readable, not active** — superseded precedent may be kept for history but cannot silently drive current refusal.
- **Rule witnesses are not authority** — a local checker or rulebook sentence is not authorization, audit opinion, public-release approval, repair success, lifecycle finality, or sibling verdict.
- **Handoffs are structural evidence** — lifecycle-transition coverage catches skipped specimen links, but it is not ontology completeness or correctness proof.

## Pass CI additions
- **Promoted rules are still local** — a rule promoted from one closure does not become global precedence over another promoted rule.
- **Overlap is semantic residue** — conflicting consumers, surfaces, audiences, purposes, carriers, and rule targets must survive as collision scope.
- **Order is not precedence** — checker order, rulebook order, filename order, fixture order, and route order are operational accidents unless witnessed.
- **Ambiguity should fail visible** — equal-priority, contradictory, stale, deprecated, shadow, or divergent rules need fences rather than quiet defaults.
- **Rule indexes are hygiene, not governance** — machine-visible rule ids help find collisions, but they do not prove correctness or authorize policy.

## Pass CII additions
- **Precedence is not application** — a winning rule still needs a trace proving this carrier/context was evaluated.
- **Applicability is scoped** — consumer, surface, audience, purpose, carrier, rule target, and digest must survive the witness.
- **Skipped rules are evidence** — out-of-scope, deprecated, shadow, expired, or ambiguous rules must remain visible instead of disappearing.
- **Defaults are not decisions** — fallback outcomes and abnormal evaluation need blocked inferences, not green status.
- **Checker success is not semantic proof** — runner order and success messages are harness residue, not authority.

## Pass CIII additions
- **Applied is not effected** — a rule-evaluation trace can explain a result without proving that any carrier, export, projection, warning, quarantine, or no-op state changed.
- **Weak outcomes stay weak** — warn-only, audit-only, informational, shadow-only, deprecated, skipped, and default outputs need explicit no-effect or bypass residue before reuse.
- **Effect is scoped evidence** — a refusal bound for one public CSV, sidecar, audience, purpose, and carrier cannot clear Ward, ViewFS, Harbor, worker, or SlopOS surfaces.
- **Bypass is first-class** — attempted reuse around the effect ledger/witness should leave a fence rather than disappearing into the happy path.
- **Ids are cube surfaces** — cross-specimen trace, witness, fence, and ledger ids need reference-integrity checks or the executable chain can rot invisibly.
- **Effect is not authority** — Foundry can show effect binding without deciding authorization, audit opinion, public release, legal compliance, repair success, lifecycle finality, or sibling verdict.
