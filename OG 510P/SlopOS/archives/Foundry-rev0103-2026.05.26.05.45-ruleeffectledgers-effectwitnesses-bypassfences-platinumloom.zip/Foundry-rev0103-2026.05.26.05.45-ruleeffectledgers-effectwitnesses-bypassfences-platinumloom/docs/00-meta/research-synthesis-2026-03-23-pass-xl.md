# Research synthesis — pass XL

This pass keeps Foundry narrow and learns one more auth-adjacent lesson from current primary sources: **currently valid and even high-assurance is still smaller than correctly bound presentation**.

The pressure is easy to miss because many surfaces only say “token valid”, “session good”, or “authenticated”.
But several mature systems keep three more exact truths apart.

1. **Presenter binding matters.**
   RFC 9700 recommends sender-constrained access tokens and audience restriction as best current practice.
   RFC 8705 shows one transport-shaped version: certificate-bound access tokens where the resource server ensures the token was issued to the client presenting it.
   RFC 9449 shows one application-shaped version: DPoP binds the token/proof story to a public key and requires proof of possession rather than bare bearer replay.

2. **Receiver identity matters.**
   RFC 8707 exists because the client often needs to tell the authorization server where it intends to use the access token.
   RFC 9700 then makes the anti-lesson explicit: audience restriction is there so a token that leaks or is phished at one resource cannot simply be replayed at another.
   So “good token” remains smaller than “good at this receiver”.

3. **One exact presentation can be narrower still.**
   DPoP does not stop at key possession.
   It checks that the proof matches the current HTTP method and URI, can require a server-supplied nonce, and for resource access binds the proof to the exact access token via `ath`.
   So “right holder at the right receiver” can still be smaller than “right for this exact request shape now”.

That yields one conservative datacube seam:
- **presenter binding** — exact current presenter/key/channel binding required for one presentation to count;
- **audience fence** — exact intended receiver/resource boundary that keeps one artifact from becoming generic cross-resource truth;
- **request pin** — exact request-shaped binding that keeps one proof from impersonating a broader standing grant.

The important anti-regrowth rule is simple: **valid smaller than bound presentation**.
Foundry should be able to say that a foreign-backed artifact is still live and perhaps even strong enough, while also saying that it is wrong for this presenter, wrong for this receiver, or wrong for this exact presentation.

## What to steal without overcommitting
- **presenter binding** — a compact way to keep sender/holder proof visible without inventing a portable signer registry.
- **audience fence** — a compact way to keep receiver/resource specificity visible without inventing a giant resource catalog.
- **request pin** — a compact way to keep request-shaped proof visible without inventing a replay ledger or generic signed-request family.
- **valid smaller than bound** — a standing anti-regrowth rule.

## What to keep parked
Do not yet promote:
- a portable signer plane,
- a generic proof cache or replay ledger,
- a durable audience or tenant registry,
- or one universal fine-grained authorization family.

Those may become real later, but this pass only proves the smaller meaning seam.
