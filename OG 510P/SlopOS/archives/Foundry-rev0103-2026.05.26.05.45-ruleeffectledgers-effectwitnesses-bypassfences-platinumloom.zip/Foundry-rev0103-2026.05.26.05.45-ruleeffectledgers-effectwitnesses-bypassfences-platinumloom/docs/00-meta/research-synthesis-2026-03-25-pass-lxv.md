# Research synthesis — pass LXV

This pass stays conservative.
Foundry still should **not** promise one timeless “correct” historical answer while SlopOS-side semantics are still moving.
But it can steal one more durable lesson from versioned-schema, time-travel, and producer/consumer migration systems: **a historical answer needs an explicit interpretation cut, an explicit restatement lane, and an explicit fence against silent hindsight rewrite.**

The smallest durable seam from this pass is:
- **interpretation cut** — the compact identifier for the exact schema/profile/model/history cut that shaped the reading, preferably an immutable version/snapshot/tag or equivalent digest-bearing handle rather than a vague “latest as of this clock” story;
- **restatement lane** — the compact statement of whether the visible row is the original published reading, a replay under the same interpretation cut, a reviewed translated restatement under a newer cut, or a current-hindsight projection that must not impersonate the original;
- **hindsight fence** — the explicit rule that historical outputs may not be silently overwritten by newer semantics just because a newer model, profile matrix, or translation exists.

These are still smaller than a universal history-retention plane, a giant semantic diff engine, or one archive-wide “latest truth always wins” doctrine.
They simply let design-phase history stay reproducible without pretending that time alone fixes meaning.

## Lessons we must learn from the past

### 1) Immutable version/snapshot identity is healthier than clock-only history lookup
Iceberg makes the distinction very explicit.
Time travel can use `TIMESTAMP AS OF` or `VERSION AS OF`, but the durable reproducibility surface is the snapshot/tag/branch identity.
Delta Lake goes further and states a sharp warning: time travel by timestamp can break after copying the table, while time travel by version is unaffected.
That is exactly the kind of lesson Foundry should steal.
A historical datacube reading should prefer an interpretation cut that is pinned to an immutable revision/snapshot identity whenever possible, with timestamps treated as weaker convenience selectors.

### 2) Historical reinterpretation should be explicit, not ambient
OpenTelemetry schemas are useful here because they do not pretend old telemetry magically already speaks the latest conventions.
Schemas are versioned, telemetry carries a schema URL, and consumers may transform from the received schema to the target schema at the point of use.
That implies a vital design habit for Foundry: the historical row and the current consumer expectation are different objects, and any crossing between them deserves an explicit cut plus explicit restatement posture.

### 3) Producer/consumer migration windows are real semantic state, not mere operations trivia
Current dbt guidance is very clear that model versions plus deprecation offer a pathway for producers to sunset old models while giving consumers time to migrate across breaking changes.
The trade-off remains real: multiple versions cost clutter, but forcing everyone to move instantly is also costly.
Foundry should learn the same lesson.
When SlopOS meaning families change, the cube may need to preserve both the original historical reading and a later restated reading for some bounded window instead of pretending that one latest pointer erased history.

### 4) Historical tags and branches are useful because they preserve inspectable cuts without becoming mainline truth
Iceberg branches and tags are not only a storage trick.
They are a design lesson: experiments and historical cuts can remain inspectable and reproducible without being promoted to the current mainline meaning.
Foundry should steal that posture for design-phase semantic history.
An old interpretation cut can stay readable without becoming the ambient current interpretation for every consumer.

### 5) Hindsight needs a fence because clocks do not capture semantic drift by themselves
A timestamp says when something was looked at.
It does not fully say which schema pin, which profile matrix, which translated view, or which deprecation window semantics shaped the answer.
That is why a hindsight fence matters.
Without it, a future dashboard will be tempted to recompute all old rows through the newest semantics and then forget that the old published history ever differed.

## What to steal now
- an **interpretation cut** that names the exact semantic/model/profile/history cut that produced the answer;
- a **restatement lane** that distinguishes original historical reading from same-cut replay, translated restatement, or current-hindsight projection;
- a **hindsight fence** that blocks silent replacement of old published readings with current semantics;
- a habit of preferring **immutable version/snapshot identity** over timestamp-only selectors when reproducibility matters;
- and a rule that **translation/restate is smaller than overwrite**.

## What to keep parked
Do not yet promote:
- one universal semantic-diff engine;
- one mandatory archive-wide historical answer store for every possible cut;
- automatic restatement of all older rows whenever a newer schema/profile appears;
- or one promise that every old reading remains indefinitely restatable under every newer interpretation cut.

## Resulting recommendation
The next healthy move is not “teach the cube to rewrite its whole past whenever SlopOS changes.”
It is to let Foundry say, for any historically sensitive reading:
1. which **interpretation cut** produced it,
2. which **restatement lane** the visible row now occupies,
3. and where a **hindsight fence** blocked silent overwrite by newer semantics.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart discipline from Iceberg, Delta Lake, OpenTelemetry, and dbt.
