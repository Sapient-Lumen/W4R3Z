# SlopOS + companions evaluation — pass LXXVIII

This pass evaluates Foundry's next SlopOS-facing datacube seam: how cached, precomputed, materialized, continuously maintained, or stale-but-available results can be useful without becoming base truth.

## Verdict

Promote one narrow seam: **materialization cut**, **refresh witness**, and **reuse fence**.

This is a conservative promotion because it does not choose a materialized-view product, dynamic-table scheduler, streaming database, cache protocol, lakehouse table format, or freshness-policy language.
It only names the residue an emitted result must carry when it was served from a non-row-preserving, precomputed, cached, refreshed, or reused surface.

## SlopOS pressure

SlopOS already has several materialization-shaped boundaries:

- safe-open resolves a document once and gives a disposable runtime a request-local stable input rather than a live mutable alias;
- OpenURI refuses a generic portable download, staging, docref-minting, or hidden materialization seam;
- handler-local caching or downloads stay handler-local and non-authoritative;
- quarantined result rendering remains metadata-safe until a separate explicit open/review step crosses the exact object;
- Capshell keeps replay-stable output identity digest-addressed and pushes richer result structure into explicit sidecars;
- attribute query v0 is snapshot-first and handle-returning rather than live ambient watch state.

Foundry should mirror that posture for datacube answers.
If a SlopOS support card, attribute-query result, diagnostics table, or archive export is served from a materialized object, the result should say which cut produced it, how it was refreshed, and where reuse is allowed or refused.

## Companion pressure

- **Ward** has already explored resolution binding, tier witness, and hybrid seams. Foundry should borrow the caution without importing Ward's trust-specific vocabulary wholesale.
- **ViewFS** keeps artifact packages, bundles, and object identity honest; Foundry should avoid treating a materialized object path or bundle location as semantic cube identity.
- **Harbor** cares about crossings and aftermath; a materialized export needs an aftermath/reuse story if it crosses into another runtime or user-visible surface.
- **Helm** and **Schell** surface user-facing cards, terminal results, and helper outputs; these are where stale-but-fast outputs become dangerously persuasive.
- **Steward** pushes bootstrap/reconciliation discipline; a refresh witness is reconciliation evidence, not a verdict that the served answer is true.

## Promotion rationale

Specimen 70 named the query/result/validation seam.
Specimen 71 named the hierarchy/rollup seam.
Specimen 72 now names the serving/reuse seam.
Together, they let Foundry describe a result without confusing:

1. what was asked;
2. how it was grouped or reduced;
3. what was checked;
4. what was materialized or cached; and
5. whether that served object may be reused for this audience and request.

## Non-decisions preserved

- no universal materialization engine;
- no global cache hierarchy;
- no global target-lag language;
- no universal stale-if-error permission;
- no assumption that cache hit, materialized-view rewrite, refresh success, or asset-freshness pass means source truth;
- no hidden docref/file/import/persistence semantics for internal materialization;
- no audience-neutral reuse unless policy/disclosure lenses are in the reuse fence;
- no duplicating Ward's tier/resolution/hybrid vocabulary beyond the minimum bridge needed for Foundry outputs.

## Follow-through needed

Pressure-test specimen 72 against:
- one SlopOS support-card table served from a refreshed aggregate;
- one attribute-query result whose engine cache is valid for one policy lens but not another;
- one stale-if-error diagnostic card that must announce its stale posture;
- one materialized rollup invalidated by hierarchy/calendar/schema change;
- one companion-cube export that carries a cache-status/reuse witness but refuses to become durable truth.
