# Research synthesis — pass LIX

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from telemetry systems, cumulative/delta metric practice, and usage-billing systems: **a visible cumulative-looking value should not pretend to be one uninterrupted total unless the cube can say what re-anchors it, what state carries across that boundary, and whether cross-boundary stitching is actually lawful.**

The smallest durable seam from this pass is:
- **reset anchor** — the compact witness for the event or schedule that re-bases the family: process start, lease issuance, billing-cycle anchor, threshold-triggered re-anchor, manual reset, or explicit no-reset/lifetime posture;
- **carry class** — the compact witness for what, if anything, survives that boundary: none, residual credit, tier/state memory, observational-summary only, or another explicitly bounded carry rule;
- **continuity fence** — the compact witness for whether values across anchor boundaries are stitchable with reset detection, comparable only within one anchor span, restatable only via policy, or forbidden to flatten into one continuous total.

These are still smaller than a billing product, a forecasting plane, or a universal reset-normalization engine.
They simply keep future Foundry rows from laundering resets, rollovers, and reissued allowances into one flattering scalar.

## Lessons we must learn from the past

### 1) A lower number can be a semantic boundary, not negative work
Prometheus defines a counter as monotonically increasing except that it may reset to zero on restart, and its query functions make resets first-class: `resets()` counts them while `increase()` adjusts for breaks in monotonicity.
The lesson is that a visible drop is not always subtraction or debt; it can be a boundary event that needs to stay explicit.

### 2) Temporality and start-time posture matter when stitching cumulative-looking values
OpenTelemetry’s metrics data model and supplementary guidance separate cumulative from delta temporality and discuss reset detection explicitly.
Receivers with reset detection can often recover a correct rate after restart, but the precise moment of reset may still be unknown.
That means a future cube should not silently pretend that all cumulative-looking rows share one perfectly continuous history.

### 3) Some usage families reset on anchored periods, not only on crashes or restarts
Stripe’s billing docs make the billing-cycle anchor explicit and allow resetting it to `now`, which starts a new billing period.
Stripe’s usage-threshold docs further show that thresholds can optionally reset the billing-cycle anchor and that tiers reset at the end of the billing period or after a threshold-triggered anchor reset.
The lesson is that reset semantics are not just operational failure semantics; they can also be deliberate policy or commerce semantics.

### 4) Carryover is policy, not arithmetic folklore
Once a family can reset or re-anchor, the next honest question is what carries across the boundary.
Some families carry nothing, some preserve tier state, some preserve residual credit or debt, and some only export observational summaries that should never be reinterpreted as fresh spending authority.
Foundry should therefore preserve a **carry class** instead of guessing from adjacent dashboards.

## What to steal now
- a **reset anchor** beside any future counter-like, budget-like, lease-like, or period-anchored value family;
- a **carry class** so “new period,” “reissued lease,” and “same long-lived total” do not all flatten into one visual trend;
- a **continuity fence** so post-restart/post-rollover stitching stays visibly different from same-anchor comparison;
- and a habit of treating “since restart,” “this billing period,” “this lease,” and “lifetime cumulative” as different truths even when they share a measure name.

## What to keep parked
Do not yet promote:
- a universal reset/rollover engine;
- one cube-wide billing or entitlement cycle ontology;
- automatic restatement across every reset boundary;
- a forecasting or burn-rate product;
- or a claim that every counter-like value can be losslessly stitched into one lifetime total.

## Resulting recommendation
The next healthy move is not “build a universal cycle model inside the cube.”
It is to let Foundry say, for any future cumulative-, allowance-, or period-shaped family:
1. which **reset anchor** re-bases the value,
2. which **carry class** survives that boundary,
3. and what **continuity fence** limits any cross-boundary comparison or stitching.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from Prometheus, OpenTelemetry, and Stripe-style usage cycles.
