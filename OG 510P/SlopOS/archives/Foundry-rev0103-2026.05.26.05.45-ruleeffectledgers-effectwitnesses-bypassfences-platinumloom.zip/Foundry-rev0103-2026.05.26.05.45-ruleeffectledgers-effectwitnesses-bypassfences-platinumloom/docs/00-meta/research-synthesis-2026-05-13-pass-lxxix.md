# Research synthesis — pass LXXIX

This pass goes deeper on a datacube failure mode that becomes unavoidable once query contracts, rollups, materialization cuts, and reuse fences exist: aggregate outputs can leak even when no raw rows leave the cube.

That pressure is not hypothetical. Census tables, health reports, clean rooms, shared warehouse views, and dashboard tiles have decades of scar tissue around small cells, sparse cross-tabs, differencing, complementary suppression, perturbation, privacy-unit choice, and repeated-query composition. SlopOS is still in design phase, which is exactly when Foundry should avoid building a privacy product while still preserving the evidence that keeps aggregate releases honest.

The low-regret move is small: when a Foundry result is shaped by aggregate release policy, cell suppression, perturbation/noise, or differential-privacy budget posture, the result should carry a **disclosure cut**, a **suppression witness**, and a **differencing fence**.

Specimen 73 is therefore added. It is an aggregate-release honesty seam, not a privacy engine.

## Lessons we must learn from the past

### 1) Aggregate release is still disclosure
Statistical disclosure control exists because tables, maps, and aggregate outputs can reveal information about individuals, households, businesses, devices, tenants, or other protected units. The cube lesson is not “never aggregate.” It is that aggregate release must name the release regime that made a value visible.

### 2) Small cells are not the only risk
Small counts are obvious danger zones, but dominance, sparsity, linked margins, hierarchy totals, repeated cuts, and cross-table differencing can all leak. A one-cell threshold without release-set context is weaker than it looks.

### 3) Suppression is a statement about a release set, not a null value
Primary suppression hides cells that are directly risky. Secondary or complementary suppression may hide additional cells so the primary cells cannot be reconstructed from margins. Foundry must not let a suppressed cell become zero, unknown, not applicable, or missing-by-accident.

### 4) Noise and perturbation are not display rounding
ONS Census 2021 used record swapping, cell-key perturbation, and table-publication rules; Statistics Canada lists suppression, regrouping/top-coding, perturbation/noise, and rounding as disclosure-control techniques. The cube lesson: a perturbed or noisy value has a disclosure method and utility residue, not just a shorter decimal string.

### 5) The privacy unit is part of the answer
BigQuery differential privacy requires exactly one privacy-unit column, and OpenDP puts “identify the unit of privacy” first in the workflow. Snowflake’s entity-level aggregation policies show why row-level thresholds can be inadequate when one household, company, user, device, or tenant appears in many rows. Foundry should not treat “count of rows” as the same thing as “count of protected entities.”

### 6) Contribution bounds are semantic, not optimizer detail
Differentially private aggregations depend on contribution limits, clamping bounds, group-contribution limits, privacy parameters, and noise. Those knobs shape the meaning and comparability of the released value. If they are missing from the release residue, later readers will over-compare.

### 7) Budget exhaustion and refresh are release facts
AWS Clean Rooms differential privacy treats privacy budget as finite and consumed by queries; monthly budget refresh is explicitly dangerous when the same rows are repeatedly queried across refreshes. Foundry already has refresh witnesses, but privacy budget refresh is a release-composition fact, not just a materialization freshness fact.

### 8) Clean-room constraints teach restrictive-composition humility
AWS Clean Rooms aggregation constraints can require minimum distinct values in output rows even when the column is not named in the query, and restrictive controls compose across configured tables. Snowflake likewise has join and set-operator rules for aggregation-constrained tables. The cube lesson: the release rule is often stronger than the visible SQL shape.

### 9) Differential privacy is not a magic warranty
NIST frames differential privacy as a way to quantify privacy loss to entities, while BigQuery’s documentation explicitly calls out limitations, bad-faith analysts, timing/error/floating-point issues, and misclassification of identifiers. Foundry should record DP-shaped release evidence without promising that “DP flag present” equals safe-for-all-future-use.

### 10) SlopOS already has the right boundary style
SlopOS observation exports are pull-only, bounded, policy-killable, redaction-first, and non-authoritative; ATTRFS refuses app-visible count-only probes and ambient global indexing; quarantined result previews stay metadata-safe; Digital Credentials and FedCM stay browser/provider-local. Foundry should mirror that posture for aggregate datacube outputs: show the release seam, do not invent a global privacy plane.

## Nifty ideas to steal without over-freezing

- **disclosure cut** — compact residue for release policy digest, audience/lens, protected-unit basis, source cut, query contract, release-set identifier, suppression/noise/DP method, contribution bounds, and budget snapshot.
- **suppression witness** — compact per-result or per-cell residue for released, primary-suppressed, complementary-suppressed, coarsened, rounded, perturbed, noisy, budget-refused, policy-refused, or not-releasable posture.
- **differencing fence** — compact guardrail for whether this output can be compared, subtracted, joined, drilled, cached, or reissued alongside nearby outputs without reconstructing hidden cells.
- **release-set id** — a stable identifier for the table family or batch of cells whose suppressions/noise were evaluated together.
- **protected-unit basis** — person, household, tenant, device, company, app, origin pair, or other entity basis, kept separate from row grain.
- **entity-threshold witness** — row threshold versus distinct-entity threshold residue, including the entity key family where known.
- **budget-spend witness** — epsilon/delta/noise/query-count-style privacy-spend residue, explicitly smaller than a privacy guarantee.
- **composition window** — the time, audience, dataset, and release family over which repeated queries or refreshes compose.
- **zero-not-released rule** — a standing rule that omitted/suppressed cells must not be displayed, exported, joined, or chart-filled as zero.
- **same-release-set-only comparison** — a safe default for comparing thresholded or suppressed aggregates.
- **no-subtraction lane** — refusal posture for totals/subtotals where subtraction could recover a hidden sibling cell.
- **noise-family card** — deterministic perturbation, random perturbation, rounding, cell-key, DP noise, or other method residue without forcing Foundry to implement the method.

## What stays parked

- no Foundry-wide privacy product;
- no differential privacy runtime;
- no privacy budget authority;
- no universal SDC policy language;
- no global protected-entity registry;
- no promise that a threshold, suppression, clean-room rule, or DP clause is sufficient for adversarial release;
- no automatic secondary-suppression solver;
- no universal safe-publication verdict;
- no treating suppressed cells as null, zero, unknown, or absent;
- no treating noisy/perturbed aggregates as exact raw facts;
- no allowing cached/materialized aggregate releases to bypass the disclosure cut or differencing fence;
- no cross-audience reuse of aggregate results unless the reuse fence and disclosure cut both allow it.
