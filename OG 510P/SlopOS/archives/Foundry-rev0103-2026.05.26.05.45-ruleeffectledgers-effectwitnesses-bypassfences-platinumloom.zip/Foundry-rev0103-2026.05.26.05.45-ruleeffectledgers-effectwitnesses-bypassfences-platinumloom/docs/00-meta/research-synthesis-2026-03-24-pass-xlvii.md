# Research synthesis — pass XLVII

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from warehouse modeling, schema-evolution systems, and metrics practice: a cube stays healthier when it separates **stable identity** from **mutable labels**, and when it refuses to treat every convenient label as a safe grouping axis.

The smallest durable seam from this pass is:
- **identity anchor** — a stable member or field identity that survives rename, path drift, regrouping, or promotion between singleton and family surfaces;
- **label snapshot** — the human-facing name, title, path, or family label observed at one revision/cut, kept as description rather than join truth;
- **axis budget** — an explicit posture for whether one label family is bounded and reviewed enough to group on, or should stay display-only because it is too volatile or too high-cardinality.

These are still smaller than a full entity registry, alias-resolution service, or semantic-layer-wide naming contract.
They simply keep future Foundry rows from treating today’s display text as tomorrow’s durable identity, and they keep free-form labels from silently becoming datacube axes.

## Lessons we must learn from the past

### 1) Stable joins need identity beyond current names
Classic dimensional modeling keeps relearning that descriptive fields change while the thing being described continues.
Kimball’s surrogate-key guidance is the sharpest version of that lesson: warehouse joins should not depend on volatile production keys or mutable descriptive strings.
Foundry should therefore resist keying rows on current boundary titles, current relative paths, or present family labels.

### 2) Changing descriptions deserve their own history
Type 2 and validity-window practice exist because labels, tiers, memberships, and descriptions move over time without destroying the continuity of the underlying member.
Foundry should steal the small lesson: when a label matters, preserve it as a time-scoped snapshot instead of pretending it is timeless identity.

### 3) Rename-safe evolution wants explicit identity, not folklore
Iceberg’s field-ID discipline is especially valuable here.
Names and order can change while identity remains stable, and rename/reorder do not need to rewrite the truth underneath.
OpenTelemetry schema URLs add a companion lesson: if naming evolves, the change should be visible enough that consumers can translate rather than silently guessing.

### 4) Labels are not automatically safe dimensions
Metrics systems are useful because they punish this mistake quickly.
Prometheus explicitly warns that labels create cost and that high-cardinality or unbounded label values should not be used casually.
Foundry should steal the attitude: not every useful display label is a healthy cube axis.
Some labels should remain presentation-only until boundedness and reuse pressure are proven.

### 5) Design-phase archives drift by regrouping as much as by renaming
SlopOS is still evolving through family maps, singleton contracts, boundary clusters, and promotion rules.
That means a concept may keep its meaning while its title changes, its document moves, or its grouping surface changes.
A Foundry datacube keyed on the current archive layout would overfit to the current editorial cut instead of the more durable semantic object underneath.

## What to steal now
- a minimal **identity anchor** for any member/field/object that might survive rename or regrouping;
- a **label snapshot** whenever human-facing labels, titles, or paths matter for review or historical explanation;
- an **axis budget** on label families so reviewed-bounded axes stay visibly different from display-only or unbounded labels;
- restraint about using raw paths, URIs, actor chains, or free-form tags as grouping dimensions by default;
- the habit of treating alias/name mapping as an explicit future seam, not an accidental byproduct of string matching.

## What to keep parked
Do not yet promote:
- a universal entity registry;
- a global alias-resolution or canonical-name service;
- automatic label normalization or fuzzy matching;
- path-as-identity semantics;
- or a giant tag dictionary for all neighboring archives.

## Resulting recommendation
The next healthy move is not “design the whole identity model.”
It is to let Foundry say, for any future row or grouped result:
1. what stable identity it is about,
2. which human label was observed at this cut,
3. and whether that label family is even safe to aggregate on.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from dimensional modeling, schema evolution, and metrics practice.
