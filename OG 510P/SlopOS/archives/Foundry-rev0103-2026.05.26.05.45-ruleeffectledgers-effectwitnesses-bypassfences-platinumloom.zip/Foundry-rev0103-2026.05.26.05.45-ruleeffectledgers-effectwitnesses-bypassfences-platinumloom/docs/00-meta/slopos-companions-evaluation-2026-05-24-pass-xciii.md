# SlopOS and companions evaluation — 2026-05-24 pass XCIII

Focus: whether Foundry can account for audience and purpose exposure after surface inventory without claiming authorization, consent, public release, deletion, custody, audit opinion, or sibling authority.

## SlopOS pressure

SlopOS support surfaces can now be distributed, adopted, inventoried, and fenced across aliases. Rev0093 asks a different question: who can actually see each surface, and for what purpose? A support dashboard that is valid for SlopOS operators is not automatically valid for Ward appraisal, external audit, ViewFS projection, delegated-worker execution, or public preview.

Foundry can record that an external-audit CSV is exposed to a read-only auditor for external review, a dashboard tile is exposed to a service account for rendering, a SlopOS operator group can read the tile for support debug, a Ward preview tile carries a purpose-widening fence, a ViewFS projection inherited project access and stays quarantined, a worker cache is permission-denied, and a public link is blocked. Foundry still does not grant permission, validate identity, prove consent, approve public release, delete the link, or issue a SlopOS proof claim.

## Companion boundaries

| Companion | Exposure-accounting interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may seed intended audiences and support/debug purposes | SlopOS still owns policy, proof claims, and operator semantics |
| Harbor | may receive public-link or unknown-reader fences as external-status pressure | Harbor still owns public/external status and remediation verification |
| Ward | may use audience witnesses as appraisal inputs | Ward still owns appraisal and trust verdicts |
| Steward | may track rechecks for permission-denied or expired exposure evidence | Steward still owns lifecycle, retry budgets, and finality |
| Schell | may constrain what audience/access evidence can be retained | Schell still owns minimization, forgetting, and privacy authority |
| ViewFS | may expose trusted paths, inherited groups, and projection ACL snapshots | ViewFS still owns object identity, consent fences, and custody |
| Helm | may receive blocked exposure fences as repair/intervention inputs | Helm still owns repair custody and handback consequence |
| External audit notebook | may receive a read-only extract | exposure is not audit opinion or certification |
| Dashboard cache | may expose tile/service-account readers | exposure is not cache policy or access-control authority |
| Public-link scanner | may discover anonymous/public reachability | public reachability is not public release, consent, or deletion proof |

## What changed in this pass

- Added specimen 87 for exposure ledgers, audience witnesses, and purpose fences.
- Added an exposure accounting rulebook so audience/purpose gaps have named failure modes.
- Added v0 schemas for exposure ledgers, audience witnesses, and purpose fences.
- Added a specimen 87 fixture with complete, partial, and blocked exposure ledgers; within-scope, overexposed, unknown, public-link, inherited, and retired audience witnesses; and purpose fences for public, unknown, inherited, permission-denied, and purpose-widened exposure.
- Added `check_foundry_exposure_accounting.py` and wired it into `make check`.
- Reused ODRL party/action/constraint pressure, NIST ABAC subject/object/action/environment separation, JWT audience specificity, and OAuth resource-indicator explicitness while keeping Foundry smaller than policy engines, access-control products, token validation, privacy/consent systems, public-release workflows, and sibling verdict systems.

## Recommendation

Future Foundry revisions should treat surface inventory as a necessary input to exposure accounting, not as closure. A semantic carrier is not safe for a consumer merely because it was found; it needs an audience witness inside the intended purpose/access envelope or a purpose fence that blocks overexposure, unknown readers, public links, inherited permissions, and access-mode widening.
