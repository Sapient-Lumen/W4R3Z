# Research synthesis — pass XLIX

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from warehouse modeling, sketch systems, and analytics engines: a cube stays healthier when it separates **exact values, bounded estimates, advisory rankings, and query-shaped outputs**, and when any provisional value says how long correction is still expected.

The smallest durable seam from this pass is:
- **exactness class** — the small posture for whether a value is exact-at-cut, bounded-estimate, advisory-rank, or query-shaped only;
- **bound witness** — the algorithm, parameters, confidence/error, or ranking-basis residue that keeps non-exact values inspectable;
- **correction horizon** — the restatement/finalization window that keeps snapshot counts and late-arriving-fact corrections from pretending to be timeless truth.

These are still smaller than a full uncertainty algebra, sketch registry, approximate-query subsystem, or semantic-layer-wide metric contract.
They simply keep future Foundry rows from laundering “fast enough” or “helpful enough” outputs into exact cube truth.

## Lessons we must learn from the past

### 1) Approximate can be honest if the bounds are explicit
DataSketches is a strong reminder that approximation is not the same thing as hand-wavy guessing.
Its HLL documentation exposes error bounds and confidence posture directly, and its sketch docs keep algorithm choice visible.
Foundry should steal the smallest lesson: estimates are acceptable only when the estimate-shaped nature and its bound witness stay inspectable.

### 2) Some ranked answers are useful but not guaranteed
Modern analytics engines make this painfully clear.
Approximate top-k helpers are operationally valuable, but some of them explicitly say they may return frequent values that are not actually the most frequent values.
That means “rank-like answer” is smaller than “exact ordered truth” and should not hide behind one friendly count/result field.

### 3) Exactness is a semantic property, not just a performance note
ClickHouse keeps `uniq` visibly approximate and offers exact distinct variants separately.
That is the right instinct for Foundry too: exactness class belongs with the value, not only in the implementation story or query comment.

### 4) Even exact facts may remain restatable for a while
Kimball’s late-arriving fact guidance is the warehouse version of the same humility.
A fact can be exact relative to the event that happened and still require later correction because arrival time, effective context, or missing joins were delayed.
Foundry therefore should not flatten exact-at-cut and final-forever into one posture.

### 5) Design-phase neighboring archives already distinguish hints from stronger truth
SlopOS repeatedly keeps weaker value classes visible: view-scoped smart-folder queries are snapshot-first, CPU-capacity labels are placement hints only, and urgent notifications are advisory hints only.
Foundry should preserve that discipline in any future datacube instead of letting all these outputs collapse into one generic measure family.

## What to steal now
- an **exactness class** carried beside future values;
- a **bound witness** for any estimate, sketch, or rank-shaped output;
- a **correction horizon** for values still exposed to late-arrival, snapshot-scope, or finalization restatement pressure;
- restraint about using advisory ranks or approximate distincts as denominators, population claims, or canonical totals by default;
- the habit of treating sketch state and approximation metadata as explicit leaf evidence, not invisible engine folklore.

## What to keep parked
Do not yet promote:
- a global uncertainty or probability calculus;
- one universal sketch registry;
- automatic approximate/exact substitution rules;
- a giant query-engine capability matrix;
- or a canonical policy for every ranking/forecast/simulation shape.

## Resulting recommendation
The next healthy move is not “design all measure semantics.”
It is to let Foundry say, for any future numeric or ranked output:
1. what exactness class it belongs to,
2. which bound witness explains non-exactness or ranking basis,
3. and how long correction or restatement is still expected.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from sketches, analytics engines, and warehouse late-arrival practice.
