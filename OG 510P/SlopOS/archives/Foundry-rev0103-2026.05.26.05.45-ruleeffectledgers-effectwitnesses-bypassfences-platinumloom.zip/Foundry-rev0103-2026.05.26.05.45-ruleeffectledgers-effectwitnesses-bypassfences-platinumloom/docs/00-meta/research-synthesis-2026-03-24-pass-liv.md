# Research synthesis — pass LIV

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from stream processing, late-arriving data guidance, and incremental result maintenance: **time-bucketed values need explicit progress and closure posture instead of pretending that one timestamp makes them final**.

The smallest durable seam from this pass is:
- **watermark frontier** — the lower-bound progress witness that says how far event-time or source-completeness progress had advanced when the value was emitted;
- **closure class** — whether the value is preview, on-time, reopenable, or finalized for the declared family;
- **lateness aperture** — the declared late-arrival or restatement window the system still admits before treating the bucket as closed enough.

These are still smaller than a universal stream-processing product, a giant trigger algebra, or a single cube-wide scheduler model.
They simply keep future Foundry rows from laundering "what had arrived so far" into timeless finished truth.

## Lessons we must learn from the past

### 1) Event time and processing time are different truths
Flink’s time docs are explicit that event time exists because out-of-order events, late events, and replays make wall-clock progress a poor proxy for correctness.
Beam likewise treats watermarks as the mechanism that lets the system reason about early results and late results instead of pretending there is one final moment for every window.
Foundry should learn the same lesson before it lets a bucket timestamp impersonate completeness.

### 2) A watermark is a progress witness, not a magic finality stamp
Spark documents a watermark as a point before which the engine assumes no more late data will arrive, and uses it to decide when some windowed results can be finalized and when old state can be dropped.
That is useful discipline, but also a warning: the frontier is a declared system assumption, not metaphysical proof that no later correction exists.

### 3) Grace or allowed-lateness policy is part of meaning, not just engine tuning
Kafka Streams says a window’s grace period controls when results are final and that records arriving after the grace period are discarded for that window.
Beam’s trigger docs go further and warn that `AfterWatermark()` without a late trigger can lose late data.
Foundry should therefore treat lateness policy as semantic residue rather than invisible engine config.

### 4) Freshness logic must align with lookback or late-arrival policy
Current dbt guidance says that if incremental models use a lookback window to capture late-arriving data, freshness logic should align with that window.
That is exactly the warehouse version of the same lesson: a dashboard can look fresh while still being known-incomplete if the declared late-arrival aperture is hidden.

### 5) Early, on-time, reopenable, and final are different truths
Beam’s basic model allows early results before a window is complete and late results after the watermark passes the end of the window.
That means "the number we show now" and "the number we are willing to call final" may be related but should not silently share one class.

## What to steal now
- a **watermark frontier** beside any time-bucketed or completeness-sensitive value so consumers know how far source progress had advanced;
- a **closure class** so preview, on-time, reopenable, and finalized outputs stop collapsing into one flattering bucket family;
- a **lateness aperture** so the system admits how much late arrival or restatement it still tolerates;
- a habit of keeping progress truth smaller than final truth;
- and a habit of aligning freshness claims with late-arrival policy instead of treating them as unrelated dashboards.

## What to keep parked
Do not yet promote:
- a universal trigger or pane algebra;
- one cube-wide streaming/window engine contract;
- a mandatory watermark model for every non-temporal family;
- a promise that every source can expose identical lateness semantics;
- or a giant "realtime analytics" product vocabulary.

## Resulting recommendation
The next healthy move is not "design streaming."
It is to let Foundry say, for any future time-bucketed or completeness-sensitive value:
1. which **watermark frontier** or progress witness applied,
2. what **closure class** the current bucket belongs to,
3. and what **lateness aperture** still governs late corrections or restatement.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from Beam, Flink, Spark, Kafka Streams, and dbt’s current late-arrival guidance.
