# SlopOS plus companions evaluation — pass XL

SlopOS and the neighboring cubes support the same narrow lesson: **presenter, receiver, and request-shaped binding should stay visible, but the machinery that enforces them should remain provider- or component-local unless a later specimen proves otherwise**.

## SlopOS
SlopOS rev0678 already pins three nearby auth-mediation seams.
The `mcp-dpop-import-boundary-v0.md` posture says imported DPoP proof JWTs, embedded public keys, nonce challenges, and DPoP-bound token metadata remain provider-local sender-constraining and verifier machinery only.
The `mcp-token-passthrough-import-boundary-v0.md` posture says audience-bound MCP tokens and no-token-passthrough rules remain provider-local token-boundary mechanics only.
The `mcp-caller-auth-binding-import-boundary-v0.md` posture says session ids and same-user checks remain provider-local caller-binding and live auth-state mechanics only.

That means Foundry should **not** grow an auth broker, signer plane, or durable caller-identity substrate here.
It should only preserve the semantic seam so off-native realization can stay honest when a thing is live-but-wrongly-bound.

## Harbor
Harbor rev0020 already has specimen flow 16 around **resource audience, scope split, and auth target**.
That is strong support for keeping receiver/resource specificity visibly distinct from requested power.
Foundry can borrow the humility while still keeping Harbor's crossing and aftermath semantics separate from runtime-ground truth.

## Steward
Steward rev0099 already collects optional **holder-bound grant** pressure in its current posture.
That is useful confirmation that exact live power may require current holder proof rather than replayable bearer history.
Foundry does not need to import Steward's live claim machinery, but it should preserve the realization-side seam so foreign-backed effects do not silently become generic bearer power.

## Ward
Ward rev0020 keeps **attenuation event** and **receiver stance** visible.
That is a helpful warning that even after issuance or presentment, local receivers still interpret and narrow consequence under their own policy.
Foundry should therefore keep audience fences and request pins smaller than any durable local verdict.

## Resulting judgment
Promote only the smallest new trio:
1. **presenter binding** — current presenter/key/channel binding required for one presentation to count;
2. **audience fence** — exact receiver/resource boundary for one usable artifact;
3. **request pin** — exact method/route/nonce/token-hash style binding for one presentation.

Keep parked for now:
- portable signer identity,
- replay ledgers,
- generic audience registries,
- and a broader fine-grained authorization family.

That keeps Foundry aligned with SlopOS's design-phase discipline: preserve the seam, do not harden the subsystem too early.
