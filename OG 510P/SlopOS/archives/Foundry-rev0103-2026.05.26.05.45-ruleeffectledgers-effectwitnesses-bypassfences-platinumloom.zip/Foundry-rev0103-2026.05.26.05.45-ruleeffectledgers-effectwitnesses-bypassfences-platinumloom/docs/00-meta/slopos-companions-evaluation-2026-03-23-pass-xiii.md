# SlopOS + companions evaluation — pass XIII

This pass reads SlopOS and the siblings as pressure for Foundry to become better at **handle honesty** and **budgeted restore truth**.

## Lessons from the datacubes
1. **SlopOS already separates artifact, capability, and runtime-cycle truth.**
   Foundry should keep that split visible whenever a foreign runtime hands back something that looks local but is still boundary-backed.

2. **ViewFS and Schell both reward “apply/adopt later” honesty.**
   That suggests Foundry should never let a borrowed foreign handle impersonate a fully adopted local object.

3. **Steward's lifecycle surfaces make restore budgets legible.**
   Foundry should preserve the same kind of honesty for resumed foreign grounds: restored, reinitialized, adopted, and fully ready are not the same fact.

4. **Ward's attestation skepticism and Harbor's degradation stories both reinforce capability grades.**
   Foundry benefits from a vocabulary where foreign power can be required, optional, degraded, or absent without collapsing into a binary status bit.

## Resulting cube move
Do not decide yet whether `borrowed handle` and `capability grade` belong together or remain separate. Keep them as specimen nouns until they improve one routed-handle specimen, one snapshot/restore specimen, and one sidecar-discovery specimen.
