# SlopOS + companions evaluation — pass LXXI

This pass checks whether **blank class, applicability basis, and coercion fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant archive-wide null ontology, one universal imputation engine, or a promise that every blank can be compared, grouped, or filled the same way.

## Why SlopOS pressures this seam now

### 1) Imported profile material is useful before it is rectangular
`docs/30-architecture/mcp-userinfo-import-boundary-v0.md` deliberately keeps imported UserInfo/profile/email material provider-local.
That means a future cube may see omitted profile claims, optional booleans, or missing pictures that are useful for support and review while still remaining smaller than durable subject truth.
That is direct **blank class** pressure.

### 2) SlopOS already has policy-controlled redaction-sensitive labels
`docs/30-architecture/capability-graph-schema-v0.md` says node `label` is optional and policy-controlled/redacted.
So a missing label should not lazily become “unlabeled object,” empty string, or generic unknown.
That is both **applicability basis** and **coercion fence** pressure.

### 3) Profile and posture matrices already carry deliberate non-universality
`docs/00-meta/profile-claim-matrix.md` and `docs/00-meta/profile-posture-matrix.md` repeatedly separate REQ/OPT/NO/REC posture instead of pretending every family applies in every profile.
That means future cube cells will often be absent because a profile excludes the question, not because the answer is false or unknown.
That is direct **applicability basis** pressure.

### 4) Non-claims are different from absent evidence
`docs/20-assurance/non-claims.md` already names areas SlopOS intentionally does not claim yet.
A blank or omitted value in those areas should not be read as zero progress, failure, or silent negation.
That again argues for **blank class** and **coercion fence** instead of generic null folklore.

### 5) Closed-world schemas and optional fields make serializer loss plausible
Many SlopOS schemas use optional fields while also treating unknown keys/variants as rejection-worthy.
That combination is healthy, but it also means later exports, adjuncts, or bridge layers can still accidentally collapse “not provided” into a type default.
That is exactly the kind of design-phase pressure where Foundry should preserve the blank semantics rather than trust transport defaults.

### 6) Companions reinforce the same caution
Harbor, Ward, Helm, Schell, ViewFS, and Steward all have redacted, withheld, optional, or profile-shaped surfaces where empty-looking output is not one universal absence.
Together they say the same thing: neighboring archives want rectangular summaries, but they do not justify one generic null plane.

## SlopOS-side recommendation
If a future SlopOS-adjacent cube needs blank-sensitive rows, Foundry should let the row say:
- **what kind of blank it is,**
- **why the value is absent or inapplicable here,**
- and **where that blank must not be coerced into a tidier story.**

That is enough to keep design-phase imports, redacted labels, profile-excluded cells, and serializer-shaped defaults honest without freezing a giant missingness subsystem into the cube.
