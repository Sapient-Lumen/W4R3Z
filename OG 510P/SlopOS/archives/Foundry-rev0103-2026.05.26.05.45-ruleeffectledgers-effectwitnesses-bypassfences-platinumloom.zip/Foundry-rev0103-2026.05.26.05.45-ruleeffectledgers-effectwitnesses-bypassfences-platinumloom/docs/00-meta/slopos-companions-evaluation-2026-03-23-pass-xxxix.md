# SlopOS plus companions evaluation — pass XXXIX

This pass tested whether Foundry should preserve one narrow seam beside pass XXXVIII's validity vocabulary: *currently valid session or token* versus *strong enough*, *recent enough*, and *user-intended enough* for one sensitive action.
The answer is yes, but again only narrowly.

## What SlopOS and companions already contribute
The uploaded SlopOS archive already carries the core anti-flattery rule almost verbatim.
Its **MCP step-up auth import boundary** says imported `insufficient_user_authentication`, `acr_values`, `max_age`, and verifier-visible `acr` / `auth_time` / `amr` stay **provider-local reauthentication guidance and verifier context only**.
They do **not** become a portable assurance registry, recent-login oracle, user-presence proof, approval basis, or durable account/session truth on adjacent SlopOS seams.
That is exactly the discipline Foundry needs.

Other nearby SlopOS boundaries reinforce the same split:
- explicit local auth/login mediation stays smaller than portable proof export;
- login/account/session truth stays on its own seams;
- attestation freshness and collateral-status boundaries already resist turning old good evidence into present truth.

The companion cubes sharpen the same seam from neighboring directions:
- **Steward** keeps freshness decay and discoverable presence separate from live readiness or serving truth.
- **Ward** keeps evidence, status, and freshness on different clocks instead of letting one pass or one receipt overclaim too much.
- **Harbor** keeps time-bounded detours and return artifacts smaller than enduring trust or present readiness.

So the ecosystem already has better homes for a full assurance, session, or step-up control plane.
Foundry does not need to grow a second one.

## What Foundry should own instead
Foundry should own only the meaning split that keeps these facts distinct:
1. **assurance class** — context-local statement of what strength or class one action requires or one authentication event satisfied;
2. **recency fence** — explicit bound on how old the qualifying authentication event may be before the action must step up or reauthenticate;
3. **intent latch** — explicit present-user intervention requirement before one sensitive effect crosses.

That seam is smaller than an auth subsystem, smaller than a recent-login cache, and smaller than a portable presence-proof family.
It is just enough vocabulary to stop a live session from quietly impersonating a fresh, high-assurance, user-intended approval.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small truth that a subject can be:
- still currently authenticated enough for routine access,
- not recent enough for one sensitive action,
- not strong enough for that resource's local assurance bar,
- or missing explicit current user intent even though a session is still alive.

If Foundry misses that seam now, later revisions will be tempted to let live session continuity, valid token possession, or one provider's ACR labels quietly imply the strongest story available.
That would make the archive worse at explaining step-up auth, recent-login requirements, phishing-resistant reauthentication, WebAuthn UP-versus-UV behavior, and sensitive operations that need fresh user intent without pretending the whole session is dead.
