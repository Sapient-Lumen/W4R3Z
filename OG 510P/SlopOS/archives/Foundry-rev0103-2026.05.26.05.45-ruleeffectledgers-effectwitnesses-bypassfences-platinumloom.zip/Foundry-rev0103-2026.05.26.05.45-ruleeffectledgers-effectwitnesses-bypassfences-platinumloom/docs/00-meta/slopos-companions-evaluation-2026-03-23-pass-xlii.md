# SlopOS plus companions evaluation — pass XLII

SlopOS and the neighboring cubes support the same narrow lesson: **a derived child may still need one exact outside/context proof before honest use, and a longer delegation trail may be worth preserving for audit without being promoted into portable live authority**.

## SlopOS
SlopOS already leans hard in this direction.
Its capability and crypto forwarding surfaces keep delegation attenuation-only and route-bound rather than ambient.
`capability-lease-posture-v0.md` says a lease proxy may only attenuate the wrapped capability.
`cryptosvc-forwarding-boundary-v0.md` says cross-boundary crypto use, if allowed at all, is an explicit routed delegation and may preserve-or-narrow policy only.
And the auth-continuation/account-binding/export boundaries keep provider-local flow state, account mapping, and pending-auth internals from being promoted to portable substrate truth.

That means Foundry should **not** grow a generic discharge service, continuation wallet, or actor-chain registry here.
It should only preserve the realization-side seam so a foreign-backed child can be honest about still needing one exact satisfaction proof, while any longer actor history stays compact and explicitly smaller than current authority.

## Steward
Steward rev0099 already keeps the parent/child narrowing lesson explicit in `attenuated-grant-posture-v0.md`.
A derived grant may narrow target, action, audience, budget, or expiry, and parent state can still matter.
That supports Foundry’s discharge restraint: even if a child later carries one more outside proof, it is still not a fresh independent authority object.

## Ward
Ward rev0020 keeps source witness, derived proof, and local receiver consequence visibly separate.
That reinforces the same anti-lesson from another angle: a proof that satisfies one condition is still smaller than the final local verdict, and audit/history material is still smaller than current spend authority.

## Harbor
Harbor’s target/resource and audience fences continue to reinforce that presentment context matters.
That makes it easier for Foundry to keep actor-path material optional and bounded: exact presentment still matters more than a long pretty chain.

## Resulting judgment
Promote only the smallest new trio:
1. **discharge witness** — exact outside or contextual proof that satisfies one carried caveat for one derived artifact;
2. **caveat hold** — visible rule that one child artifact remains insufficient or withheld until one required caveat is satisfied;
3. **actor-path card** — compact ordered multi-hop delegation trail kept for audit or continuity without promoting prior actors into current authority.

Keep parked for now:
- a general caveat DSL,
- a discharge-wallet or proof-broker surface,
- a portable actor-chain registry,
- and any rule that multi-hop history is itself authorization truth.

That keeps Foundry aligned with SlopOS’s design-phase discipline: preserve the seam, do not harden the subsystem too early.
