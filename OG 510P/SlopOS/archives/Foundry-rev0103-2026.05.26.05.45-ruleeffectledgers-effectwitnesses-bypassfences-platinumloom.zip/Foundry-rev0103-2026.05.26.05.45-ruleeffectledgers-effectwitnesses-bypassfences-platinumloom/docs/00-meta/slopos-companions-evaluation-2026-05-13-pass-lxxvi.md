# SlopOS + companions evaluation — pass LXXVI

This pass evaluates Foundry's next SlopOS-facing datacube seam: how a query or emitted result leaves the cube without becoming the cube.

## Verdict

Yes, but only this small seam.
Foundry should add specimen 70 around **query contract**, **result envelope**, and **validation witness**.

This is a conservative promotion because it does not choose a warehouse engine, semantic-layer taxonomy, catalog plane, global query language, or data-contract runtime.
It simply gives SlopOS and companion cubes a way to carry the minimum honesty needed when a table, tile, support card, export, or machine-readable answer is derived from a pinned cut, policy lens, validation run, materialization, or query plan.

## What SlopOS keeps teaching now

### 1) Attribute queries want handles and contracts, not hidden state
SlopOS's attribute-query shape is already closed, typed, snapshot-first, handle-returning, and conservative when schema knowledge is absent.
Foundry should translate that into a query contract: what was asked, under which schema or predicate digest, against which cut, through which policy lens, and with which replay class.

### 2) View objects are surfaces over evidence, not evidence themselves
SlopOS view objects and UI-facing projections need a result envelope so display-friendly rows cannot silently outrank base truth.
The envelope must say whether rows were exact, bounded, estimated, paged, ordered, masked, sampled, accelerated, or policy-narrowed.

### 3) Trace processing shows why plan/config/predicate digests matter
SlopOS trace-processing contracts record procedure, config, and predicate digests for replay.
Foundry should steal that for datacube results: if a result depended on a transformation, validation suite, sandboxed filter, or policy expression, preserve the digest and cut instead of trusting the current implementation name.

### 4) Boundary indexes show how not to invent hidden families
SlopOS boundary indexes and singleton contracts fail closed rather than discovering invisible surfaces by wildcard.
Foundry should apply the same discipline to query/result families: no implicit catalog expansion, no unlisted derived tables, no accidental result kind just because a dashboard exported it.

### 5) Design-phase SlopOS makes output envelopes more valuable
Because SlopOS is still designing its families, Foundry should avoid freezing one data-model ontology.
A result envelope lets early SlopOS consumers ship useful reports while marking what remains provisional, derived, scoped, or unreplayable.

## What the companions add

### Harbor
Harbor's temporal witnesses, contract subsets, and lineage guards argue for contract subsets on results: only the clauses that actually governed the emitted answer should be attached.

### Ward
Ward's raw-evidence/appraisal split argues that validation witnesses and result envelopes must stay smaller than appraised truth.
A checked table is not a judged table.

### ViewFS
ViewFS's frozen manifests and durable receipts argue for materialization digests, exact cuts, and replay-class markers on result envelopes.
A preview, export, handle, and manifest are different species.

### Steward
Steward's request/live/approval split argues against treating a successful validation or user-visible export as an approval basis.
A validation witness can support a release decision, but it is not the decision.

### Schell and Helm
Schell and Helm keep helper surfaces and overlays smaller than durable substrate semantics.
That supports Foundry's stance that a dashboard, support-card table, or pretty page is a view over result evidence, not the durable evidence itself.

## Promoted specimen 70

### query contract
Candidate use:
- SlopOS attribute-query exports;
- support-card result tables;
- summary/result handles;
- dashboard-like query tiles;
- sibling-cube result exchange.

Refusals:
- no universal query language;
- no one semantic-layer taxonomy;
- no engine-specific plan as mandatory archive law;
- no treating a query string as enough without cut, lens, schema/predicate, and replay posture.

### result envelope
Candidate use:
- row/page/table exports;
- result handles;
- materialized or pre-aggregated answers;
- policy-narrowed or masked result sets;
- outputs whose count/order/freshness are easy to overread.

Refusals:
- no display order as durable ordering;
- no estimated count as exact count;
- no page-local truth as population truth;
- no acceleration path as canonical semantic identity.

### validation witness
Candidate use:
- schema/constraint checks;
- data-quality assertion outcomes;
- freshness/SLA checks;
- policy or contract-subset checks;
- not-run, skipped, exempt, warning, or blocking-severity residue.

Refusals:
- no validation success as source truth;
- no warning/failure collapse;
- no suite-wide pass as every future consumer's guarantee;
- no hidden promotion of a data-contract runtime.

## Low-regret next tests

- Run specimen 70 against one SlopOS attribute query result.
- Run it against one support-card or browser-mediated identity/trust report row from pass LXXV pressure.
- Run it against one Harbor contract-subset or lineage-guarded output.
- Run it against one Ward appraisal surface where the result was validated but still not judged.
- Keep the seam small until two unrelated consumers need the same fields.
