# Research synthesis — 2026-05-26 pass CI

This pass adds pressure for specimen 95: separately valid rules can collide after promotion.

## Outside pressure

- Open Policy Agent/Rego is useful because it treats policies as declarative rules over structured data and emphasizes correctness/unambiguity for queries. Foundry should steal the concern that rule outputs can be ambiguous, but not become a policy decision engine.
- Kubernetes ValidatingAdmissionPolicy is useful because multiple matching bindings/parameters are evaluated and must pass, with explicit failure, warning, audit, match-condition, missing-parameter, and failure-policy behavior. Foundry should steal explicit overlap/missing-parameter scars without becoming an admission controller.
- W3C Profiles Vocabulary is useful because profiles can describe constrained views of specifications and associate profile resources such as guidelines, validation tools, schemas, and term lists. Foundry should steal the idea of machine-visible rule resources while refusing profile negotiation or compatibility governance.
- JSON Schema dialect/vocabulary language is useful because schema semantics depend on the declared dialect/vocabulary. Foundry should steal dialect humility for rule surfaces without turning fixture schemas into permanent ontology.

## Foundry interpretation

rev0100 made closure-to-rule promotion explicit. rev0101 makes rule-to-rule collision explicit. A promoted rule is not a global priority. A rulebook line, checker order, filename order, or dashboard pipeline order cannot decide precedence without a collision ledger, precedence witness, and ambiguity fence.

## Kept out

No policy engine, admission controller, validation framework, standards profile registry, schema dialect authority, governance workflow, authorization model, public-release decision, audit opinion, repair workflow, lifecycle finality, or sibling verdict.
