# SlopOS / companions evaluation — pass XIX

Foundry still looks justified as its own companion cube.

## What the current cube ecology keeps proving
- **SlopOS** repeatedly separates foreign execution ground, imported object truth, and local adoption. Config overlays fit that pattern only if they stay distinct from base/runtime cargo.
- **Helm** benefits because shell-facing controls often need to explain whether a foreign layer changed runtime code, configuration, or both.
- **Schell** benefits because tool lanes frequently rely on foreign config overlays that are easier to attach/detach than full image replacement.
- **ViewFS** benefits because config overlays can expose files without redefining the underlying object identity.
- **Steward** benefits because activation and rollback semantics differ when only configuration changes.
- **Harbor** should stay distinct: crossing into a foreign ground is weaker than reasoning about what layer was attached.
- **Ward** should stay distinct: compatibility metadata is weaker than trust lineage or spendable verdict.

## Current recommendation
Keep the new Foundry nouns provisional. They are useful only if they preserve the split between:
1. base/runtime cargo,
2. configuration overlay,
3. compatibility proof,
4. and attach/detach consequence.
