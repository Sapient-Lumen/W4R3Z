# SlopOS + companions evaluation — pass LIV

This pass checks whether **watermark frontier, closure class, and lateness aperture** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal stream-processing substrate, a trigger algebra, or a permanent realtime product plane.

## Why SlopOS pressures this seam now

### 1) SlopOS jobs are already window-shaped, but explicitly not exact schedules
`job-portal-posture-v0.md` says `trigger.earliest` means **not before**, `trigger.latest` is an advisory window end for coalescing, and missed windows are not replay debt.
That means any future Foundry count of job runs by hour/day is already operating in a world where schedule time, observed execution time, and closure/finality posture can diverge.
A compact **closure class** is therefore honest residue, not ornament.

### 2) SlopOS observation export is pull-only bounded snapshot truth, not ambient latest-state truth
`observation-export-posture-v0.md` keeps exports explicit, bounded, redacted, and pull-only.
So a support bundle or diagnostics summary may be exact for one pull cut without being the whole truth of what would have appeared after later arrivals.
That pressures Foundry toward an explicit **watermark frontier** or source-progress witness whenever time-bucket summaries are built from snapshot-only evidence.

### 3) SlopOS ATTRFS query posture is snapshot-first
`attribute-query-schema-v0.md` notes Phase 1 is snapshot-first and handle-returning.
A time-series tile derived from repeated snapshot-first queries is therefore not automatically a "live now" stream result.
It benefits from explicit progress and late-correction posture rather than pretending that repeated snapshots magically imply final buckets.

### 4) ViewFS strengthens the same lesson from a neighboring cube
The current ViewFS archive already keeps continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, gap verdicts, and receipts separate.
That is exactly the sort of adjacent pressure Foundry should respect: follow-state progress is useful, but it is smaller than final completeness and smaller again than a timeless stable bucket.

## What to steal into Foundry

### watermark frontier
A compact witness for how far source progress or event-time completeness had advanced when the value was emitted.
Examples:
- source snapshot cut timestamp plus "no later than this pull" posture,
- sync/follow watermark residue from a companion feed,
- scheduler/ingest frontier saying what window-end has safely passed ordinary arrival,
- event-time lower-bound frontier when a source really has one.

This is smaller than a global stream engine.
It just prevents a bucket timestamp from pretending to mean "fully complete forever."

### closure class
A compact witness for how finished the current value is.
Examples:
- **preview** — useful early signal before the ordinary frontier clears the bucket end;
- **on-time** — ordinary frontier has crossed the bucket end, but declared late-correction posture still exists;
- **reopenable** — value was previously surfaced but late arrivals inside the aperture can still restate it;
- **finalized** — declared aperture has expired or the system explicitly sealed the bucket.

This is smaller than a pane/trigger algebra.
It simply stops every surfaced number from impersonating the same degree of finality.

### lateness aperture
A compact witness for how much late arrival or restatement the system still admits.
Examples:
- allowed lateness duration,
- grace period,
- lookback window,
- one-catch-up-run policy,
- manual-restatement-only posture,
- or `none` when late arrivals are intentionally dropped.

This is smaller than a universal scheduling or replay product.
It just makes the late-correction contract visible.

## Why this seam is small enough now
It does **not** require:
- a universal streaming API;
- a trigger registry;
- a pane vocabulary on every family;
- or a promise that every source can compute exact event-time watermarks.

It only says that once values become time-bucketed and completion-sensitive, Foundry should preserve:
1. how far progress had advanced,
2. how closed the bucket currently is,
3. and how much late correction is still admitted.

## Recommended Foundry posture
Promote **watermark frontier**, **closure class**, and **lateness aperture** as a narrow honesty seam for time-bucketed and completeness-sensitive values.
Keep the larger streaming/scheduler/product questions parked.

This matches current SlopOS discipline well: jobs already use best-effort windows rather than exact schedules, observation exports are explicit pull cuts rather than ambient latest-state truth, ATTRFS queries are snapshot-first, and ViewFS already teaches that watermarks and gap verdicts are smaller than final object truth.
