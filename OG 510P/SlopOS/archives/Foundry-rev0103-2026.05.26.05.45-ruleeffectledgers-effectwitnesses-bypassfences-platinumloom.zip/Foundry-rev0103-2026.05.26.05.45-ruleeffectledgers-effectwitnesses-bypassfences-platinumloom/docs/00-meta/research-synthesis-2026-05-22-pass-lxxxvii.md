# Research synthesis — 2026-05-22 pass LXXXVII

Focus: **consumer passports, portability witnesses, and interpretation gates**.

The previous pass made bounded semantic exceptions inspectable. This pass covers the next scar: a sidecar, refusal receipt, regression lock, or waiver that is valid for one consumer can become false when copied into another consumer's workspace. Foundry needs to say when semantic residue is portable, when it is consumer-local, and when a new consumer must cross an interpretation gate before using the surface.

## Existing pressure reused

- `EXT-W3C-PROV-DM-2013` keeps provenance smaller than the later assessment of quality, reliability, or trustworthiness. Foundry should preserve derivation and agent/activity evidence without letting it become a consumer verdict.
- `EXT-W3C-DQV-2016` keeps quality actor-relative: different users and communities may publish different assessments. Foundry should steal that actor-relative posture for consumer-specific interpretation without becoming a quality-scoring system.
- `EXT-W3C-DCAT3-2024` keeps catalog, dataset, data service, and distribution/discovery metadata separate from provenance, quality, validation, and trust. Foundry should borrow discovery humility without becoming a catalog product.
- `EXT-OPENLINEAGE-OBJECT-MODEL-2026` and `EXT-OPENLINEAGE-FACETS-2026` keep run/dataset/job facets extensible and named. Foundry should borrow the discipline of attaching scoped facets to events and datasets, not the entire lineage platform.
- SlopOS and companion-cube pressure keep boundary-family claims, appraisal verdicts, lifecycle authority, repair consequence, retention authority, and artifact identity outside Foundry.

## What rev0086 still allowed

Rev0086 could prove that a waiver was scoped and expiring. It did not yet prove that a consumer receiving the waived or sidecar-backed surface was the same consumer for which the sidecar, receipt, or waiver was meaningful. A future editor could still:

- copy a SlopOS operator support-card sidecar into an external audit notebook and treat it as audit evidence;
- let a Ward appraisal queue read a Foundry sidecar as a trust verdict;
- let ViewFS expose a projection sidecar without saying whether it is display-only, review-only, or reusable;
- reuse a waiver across a different consumer, audience, or purpose because the cut and surface looked the same;
- treat portable provenance as portable policy approval; or
- flatten sibling-cube authority boundaries into a generic `consumer: approved` flag.

Those are consumer-portability failures, not ordinary egress or waiver failures.

## Speculative read

Foundry needs a small **consumer interpretation seam** beside egress, regression, and waiver seams:

```text
consumer passport       = who the consumer is, what purpose/audience it claims, and what residue it requires
portability witness     = which residue can travel from source consumer to target consumer, and which residue cannot
interpretation gate     = checks that must rerun before a new consumer treats a carried surface as meaningful
verdict                 = still outside Foundry
```

The important move is negative: portability is not sameness. A digest, sidecar, receipt, lock, or waiver can be bit-stable while becoming consumer-invalid.

## New specimen pressure

Add specimen 81 around consumer passport, portability witness, and interpretation gate. The fixture must prove at least:

- every consuming surface names a consumer id, consumer kind, purpose, audience, and required residue families;
- consumer passports state forbidden inferences such as sidecar-as-truth, waiver-as-approval, or Ward-verdict transfer;
- every cross-consumer reuse has a portability witness naming portable and non-portable residue;
- interpretation gates rerun egress, regression, waiver, and portability rules before first use, revision carry-forward, audience change, or waiver change;
- sibling authority transfer is refused unless the sibling cube emits its own evidence;
- consumer-specific semantics cannot be inferred from stable digests or matching surface names; and
- negative cases fail for missing passport, missing purpose, missing witness, missing gate, audience widening, waiver reuse, and verdict transfer.

## Recommendation

Keep consumer passports fixture-local and reversible. Do not promote a discovery catalog, compatibility registry, trust exchange, policy handoff, product entitlement, or audit-evidence framework. The narrow Foundry job is to make cross-consumer interpretation explicit enough that portable residue does not become portable authority.
