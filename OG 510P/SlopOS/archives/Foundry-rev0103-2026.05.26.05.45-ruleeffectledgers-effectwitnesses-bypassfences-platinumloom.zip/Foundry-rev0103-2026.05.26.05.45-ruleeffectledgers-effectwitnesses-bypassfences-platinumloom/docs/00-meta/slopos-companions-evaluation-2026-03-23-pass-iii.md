# SlopOS and companion-cube evaluation — 2026-03-23 pass III

## Lessons to steal from SlopOS
- Foreign-cell, compat, cloud-substrate, and reacquire seams in SlopOS show that off-native realization needs several small cuts, not one giant runtime doctrine.
- SlopOS’s habit of pinning tempting seams early is especially relevant here, because container/cloud ecosystems are full of over-broad abstractions.
- The archive’s separation of exported evidence from local verdict is essential for any confidential or attested runtime story Foundry touches.

## Lessons to steal from siblings
- **ViewFS**: carriers, handles, and realized objects are not the same thing.
- **Helm**: projected foreign surfaces need visible provenance and downgrade honesty.
- **Schell**: helper lanes and operator workflows often need adoption gates before they count as native truth.
- **Ward**: runtime measurements must remain appraisal inputs, not verdicts.

## Resulting process choice
Foundry should add **followthrough items and promotion gates** before it adds a large substrate taxonomy.
