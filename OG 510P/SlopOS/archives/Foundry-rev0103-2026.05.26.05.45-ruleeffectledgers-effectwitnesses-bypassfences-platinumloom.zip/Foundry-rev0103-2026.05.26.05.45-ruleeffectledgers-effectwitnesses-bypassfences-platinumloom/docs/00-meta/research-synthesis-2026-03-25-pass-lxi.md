# Research synthesis — pass LXI

This pass stays deliberately conservative.
Foundry still should **not** freeze a giant semantic layer or a permanent all-purpose datacube ontology while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from current semantic-layer, lineage, table-format, and orchestration ecosystems: **experimental meaning should stay namespaced and schema-pinned until repeated pressure earns promotion, and physical acceleration/layout choices should stay visibly smaller than logical cube truth.**

The smallest durable seam from this pass is:
- **adjunct namespace** — a bounded namespaced lane for provisional metadata that is useful to one support/export/import/lineage surface without yet claiming cube-wide law;
- **schema pin** — an immutable pointer to the exact meaning of one adjunct payload so later label, vendor, or YAML-shape drift does not rewrite history;
- **promotion gate** — the compact posture for where that adjunct currently stands: local experiment, cross-surface candidate, promoted durable surface, rejected idea, or superseded predecessor.

These are still smaller than a universal semantic layer, a mandatory lineage graph, or a fixed global adjunct registry.
They simply keep design-phase discoveries from freezing too early or disappearing into folklore.

## Lessons we must learn from the past

### 1) Product semantic specs move faster than archive law should
Recent dbt semantic-layer work is a useful warning shot.
Even a mature product can materially simplify and rename its authoring spec in one major generation.
That means Foundry should steal the discipline of semantic declaration without fossilizing one vendor’s exact taxonomy or YAML nesting as permanent archive law.

### 2) Logical meaning and physical acceleration are different truths
Cube’s pre-aggregations are explicitly downstream accelerations chosen to satisfy query shapes, while Iceberg’s hidden partitioning and partition evolution keep physical layout from becoming part of the user-facing data contract.
The lesson for Foundry is that materializations, rollups, partitions, and acceleration hints should remain visibly smaller than logical cube meaning.

### 3) Design-time metadata and runtime observations should not collapse into one family
OpenLineage’s object model is useful here: it distinguishes design-time job/dataset metadata from runtime run observations and makes later run updates additive rather than magical rewrites.
Foundry should steal that split whenever a proposed support/export shape and an observed realized shape both matter.

### 4) Experimental metadata needs namespacing and immutable schema pointers before standardization
OpenLineage custom facets are a sharp example.
They require project-specific prefixes, immutable schema URLs, and allow later promotion to the standard.
That is almost exactly the discipline Foundry needs for design-phase datacube adjuncts: useful local experiments first, durable promotion later.

### 5) Experimental branches and pinned cuts beat mutable “latest” folklore
Iceberg’s branches and tags, plus Airflow’s URI-shaped asset identity, reinforce a healthy posture: experimentation and event wiring can stay real and reproducible without pretending that one mutable head, default branch, or current export is the only truth.
When Foundry tests new adjunct metadata or derived cuts, it should prefer pinned meaning over “whatever latest meant at the time.”

### 6) Column-level lineage is useful, but it can stay adjunct-sized
Dagster’s column-level lineage is emitted as materialization metadata rather than treated as the unavoidable base ontology of the whole platform.
That is the right lesson for Foundry too.
Column-level drill-through can be valuable, but it should earn promotion instead of sneaking into every core row family by default.

## What to steal now
- an **adjunct namespace** for imported/export-only/provisional metadata that is informative but not yet core;
- a **schema pin** for every such adjunct so meaning stays immutable even if labels or product specs drift;
- a **promotion gate** so local experiments, cross-surface candidates, promoted surfaces, rejected ideas, and superseded predecessors do not silently share one status;
- a standing split between **logical cube meaning** and **physical acceleration/layout**;
- and a habit of treating **design-time declarations** as different from **runtime observations**.

## What to keep parked
Do not yet promote:
- a universal semantic-layer taxonomy;
- one mandatory lineage graph or column-ontology plane;
- one cube-wide adjunct registry with hard governance ceremony;
- one global branch/head/latest truth model;
- or any claim that physical partitioning, rollups, or acceleration identities are themselves semantic identities.

## Resulting recommendation
The next healthy move is not “define the final datacube.”
It is to let Foundry say, for any provisional metadata family:
1. which **adjunct namespace** it lives in,
2. which exact **schema pin** defines its meaning,
3. and which **promotion gate** posture it currently occupies.

That keeps the cube aligned with SlopOS’s design-phase reality while still stealing smart discipline from dbt, Cube, Iceberg, OpenLineage, Airflow, and Dagster.
