# Research synthesis — pass XIII

This pass focuses on what foreign realization owes when resources are handles, not values, and when restore/readiness are still budgeted.

## Fresh outside lessons
1. **Resources that cross the boundary are often handles, not copyable facts.**
   The WIT reference says a resource is a handle to an entity that exists outside the component and may be passed by ownership or by borrowed reference. Foundry should keep stealing this aggressively whenever a foreign-backed thing feels smooth and local.

2. **Restore is not free; it has obligations and budget.**
   AWS SnapStart runtime hooks explicitly support after-restore re-initialization and dynamic configuration refresh, and the Lambda lifecycle docs expose Restore Duration separately. Foundry should treat post-restore work and tolerated restore cost as named truth, not hidden runtime folklore.

3. **Availability should stay typed.**
   Fuchsia's capability availability lets components declare expectations about whether a capability is required or optional. Foundry should continue to reject the vague idea that foreign power is simply “present”.

4. **Subject attachments can degrade in discovery without becoming false.**
   OCI 1.1 added `subject` plus the referrers API, while also documenting fallback-tag/index behavior when native referrers support is missing. Foundry should keep attachment discovery mode separate from adoption truth.

## Resulting Foundry pressure
Foundry should likely preserve at least four distinct things:
- **borrowed handle**: foreign-backed access that still lives elsewhere;
- **restore budget**: how much post-restore work or delay is acceptable before readiness claims narrow;
- **capability grade**: required, optional, degraded, or absent foreign power;
- **attachment mode**: native, fallback, or out-of-band sidecar discovery.

## Brilliant ideas worth stealing
- **borrowed handle card** — reminds the system that smooth access may still be foreign-owned and revocable;
- **restore budget** — a first-class bound on what reanimation owes before it may claim normal readiness;
- **capability grade** — richer than present/absent without becoming ambient folklore.
