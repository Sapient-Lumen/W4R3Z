# Research synthesis — pass LXIX

This pass stays conservative.
Foundry still should **not** freeze one archive-wide golden-record doctrine, one permanent “current row” ontology, or one mandatory survivorship engine.
But it can steal one durable lesson from current merge/upsert systems, master-data products, and row-lineage work: **a design-phase datacube needs to distinguish candidate same-subject clustering from survivorship-picked representatives, and it needs to stop representative rows from impersonating native subject truth.**

The smallest durable seam from this pass is:
- **match cluster** — the compact statement that several rows or imports are being treated as candidate same-subject material without claiming they are already one native subject;
- **survivorship witness** — the compact statement of how a representative row or field value was chosen: explicit source priority, latest-by-basis, completeness preference, policy-local tie-break, or another reviewed rule;
- **golden-row fence** — the compact statement of what the representative row is lawful for: display summary only, merge target only, review queue only, or forbidden as subject truth.

These are still smaller than a master-data program, one canonical person/device/account ontology, or a promise that a merge winner preserves all source history.
They simply stop deduplication from hardening into dishonest identity truth.

## Lessons we must learn from the past

### 1) Merge ambiguity is real and must stay visible
Current Databricks `MERGE` docs reject cases where multiple source rows match the same target row because the update is ambiguous.
That is exactly the lesson Foundry should steal.
When several imported rows might describe the same subject, a future cube should preserve the **match cluster** instead of acting as though one survivor was self-evident.

### 2) Merge behavior is policy, not ontology
Current Hudi record-merger docs make merge policy pluggable, including full and partial merge behavior.
That means “winning row” is not a fact of the world.
It is a reviewed reconciliation choice.
Foundry should therefore preserve a **survivorship witness** instead of laundering merge policy into natural subject truth.

### 3) Row lineage helps, but it does not magically backfill old identity certainty
Current Iceberg v3 row-lineage docs add row-id and commit sequence ideas, while also acknowledging that upgraded tables can have historical snapshots whose row lineage is absent or null.
That is a useful warning.
Lineage support can improve auditability without proving that historical merged rows were always one obvious entity.

### 4) Mature MDM systems already distinguish clusters from representatives
Microsoft DQS and Purview/Profisee materials keep matching/clustering, survivorship rules, and traceability visibly separate.
That is the stealable pattern.
A future cube can preserve cluster membership, representative choice, and source drill-through without pretending the survivor row is the subject itself.

### 5) Exactly-once write posture is not the same thing as identity truth
BigQuery’s Storage Write API distinguishes at-least-once default streams from exactly-once application-created streams with offsets.
That is useful pressure against a common mistake.
Even if ingestion is idempotent or exactly-once, several rows may still be duplicate candidates rather than one already-settled subject.

## What to steal now
- a **match cluster** field or adjunct that says several rows are candidate same-subject material without collapsing them into native identity;
- a **survivorship witness** that says how a representative row or value was chosen;
- a **golden-row fence** that blocks representative rows from silently becoming archive ontology;
- and a habit of keeping drill-through to originals even when one representative row is convenient for UI or export.

## What to keep parked
Do not yet promote:
- one archive-wide golden-record doctrine;
- one mandatory deduplication engine;
- one universal survivorship grammar;
- or a promise that representative rows are lawful for every join, alert, or historical replay.

## Resulting recommendation
The next healthy move is not “teach Foundry master-data management.”
It is to let Foundry say, for duplicate-sensitive families:
1. **which rows are only a candidate cluster,**
2. **how a representative was chosen,**
3. and **where that representative must not impersonate native truth.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart restraint from current merge, MDM, and lineage practice.
