# Research synthesis — pass XLII

This pass keeps Foundry narrow and learns one more delegation-adjacent lesson from current primary sources: **a narrowed child artifact can still be unusable until one exact outside or contextual proof arrives, and a multi-hop actor trail can matter for audit without becoming current authority**.

The pressure is easy to flatten because many systems only say “delegated token”, “exchanged credential”, or “actor chain”.
But the outside sources keep three smaller truths distinct.

1. **Some derived artifacts are not self-sufficient; they still need one carried caveat to be discharged.**
   The original macaroons paper says that a proof discharging a third-party caveat is itself a macaroon.
   Biscuit’s third-party blocks keep the same lesson in a newer public-key form: a token can carry checks whose satisfaction comes from an externally signed block, and the verifier can check that block offline without contacting the third party at verification time.
   So a child artifact may be well-formed yet still blocked on one exact satisfaction proof.

2. **That satisfaction proof should stay narrower than a general authority plane.**
   Biscuit is careful here: default trust still belongs to authority/verifier scope, and externally signed third-party blocks widen what can be checked only through explicit trusted scopes.
   In other words, “the child carries a discharge” is still smaller than “the system grew a general cross-domain authorization fabric”.

3. **Prior actors often matter for audit or continuity, but RFC 8693 keeps them informational only.**
   RFC 8693 allows nested `act` claims as a history trail, but says access-control decisions must only consider the token’s top-level claims and the current actor in `act`.
   The current SPICE actor-chain draft exists precisely because RFC 8693 leaves prior actors informational and does not define how a delegation path is preserved and validated across successive exchanges.
   That is a useful warning for Foundry: actor-path material may matter, but it should not quietly harden into portable authority just because it is present.

That yields one conservative datacube seam:
- **discharge witness** — exact outside or contextual proof that satisfies one carried caveat for one derived artifact;
- **caveat hold** — visible rule that one child artifact remains insufficient or withheld until one required caveat is satisfied;
- **actor-path card** — compact ordered multi-hop delegation trail kept for audit or continuity without promoting prior actors into current authority.

The important anti-flattening rule is simple: **current child, satisfied caveat, and historical path are different truths**.
Foundry should be able to say that one child artifact exists, one caveat is still outstanding or has been discharged, and one actor path is available for audit, without pretending those are all the same thing.

## What to steal without overcommitting
- **carry-the-proof pattern** — a child can carry its own external/context proof instead of forcing synchronous verifier lookups.
- **explicit trusted-scope selection** — outside proof should matter only where the verifier explicitly says it matters.
- **actor-path card** — compact preserved multi-hop history for audit or continuity when the workflow genuinely needs it.
- **current-actor primacy** — current authority remains separate from prior-actor history.

## What to keep parked
Do not yet promote:
- a generic caveat or policy language,
- a cross-domain actor-chain registry,
- a portable discharge-wallet surface,
- or any rule that prior actors become first-class authorization truth.

The SPICE actor-chain document is still an active Internet-Draft, so the lesson to import now is the pressure, not the full profile family.
