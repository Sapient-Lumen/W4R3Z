# Research synthesis — pass XXVII

This pass keeps Foundry narrow and learns one more thing from update ecosystems: **a basis can be installed, booted, blessed, and even rollback-governed while persistent state still belongs to a different semantic world.**

## Outside lessons
1. **OSTree treats `/var` like a volume, which means basis updates do not automatically refresh existing mutable state.**  
   Once `/var` is populated, later upgrades do not rewrite existing files there and deleted files from the new commit are not removed on existing systems. That is a blunt but healthy reminder: basis truth and persistent-state truth evolve on different clocks.

2. **RAUC makes data migration an explicit design choice rather than a hidden side effect of rootfs replacement.**  
   Its docs ask whether configuration formats change across versions, whether new applications can read and convert old data, whether obsolete data is acceptable, and whether storage should be single or redundant. In other words, the update story is incomplete until the data story is explicit.

3. **Mender warns that migration side effects are free-form and rollback is the integrator’s responsibility.**  
   State scripts may introduce persistent effects; if they do, those effects must be planned for across commit and rollback, including backup location and restoration steps. That is a strong anti-lesson against pretending the updater understands semantic state just because it can swap rootfs partitions.

4. **ChromeOS shows that basis rollback and state continuity can diverge hard enough to require reset.**  
   Its update engine notes that ordinary rollback is normally followed by a Powerwash that clobbers the stateful partition. That is the crispest reminder that “go back to the older basis” and “preserve the same persistent state” are not the same promise.

5. **Kubernetes keeps storage version separate from served API version and makes storage migration an explicit maintenance operation.**  
   The API server can serve one representation while objects remain stored in another; migrations explicitly rewrite objects off stale storage versions, and the deprecation policy requires users to be able to upgrade and then roll back without first converting everything to the newer API version. This is exactly the sort of seam Foundry should keep visible.

## Resulting Foundry move
Do not invent a generic persistence substrate, migration workflow engine, or universal data-schema registry.
For now, keep three specimen nouns alive:
- **state epoch** — the semantic/data-format world that persistent state currently belongs to;
- **migration cut** — an explicit event or receipt where persistent state is rewritten or reclassified into a new epoch;
- **reset rail** — an explicit non-continuous path when compatibility or rollback requires wiping, reseeding, or reinitializing state.

Also keep two adjacent ideas parked rather than promoted:
- **read corridor** — compact claim that one basis can safely read an older state epoch without rewriting it;
- **migration witness card** — future compact residue describing whether a migration cut happened, was deferred, or was avoided.

## Fresh ideas worth stealing
- **state epoch** — semantic/data-format epoch for persistent state, distinct from basis revision.
- **migration cut** — explicit crossing where persistent state changes epoch.
- **reset rail** — explicit non-continuous reset/reseed path when rollback or forward progress cannot preserve continuity.
- **read corridor** — future compact compatibility promise for read-without-rewrite behavior.
- **basis rollback smaller than state continuity** — a standing anti-regrowth rule.
