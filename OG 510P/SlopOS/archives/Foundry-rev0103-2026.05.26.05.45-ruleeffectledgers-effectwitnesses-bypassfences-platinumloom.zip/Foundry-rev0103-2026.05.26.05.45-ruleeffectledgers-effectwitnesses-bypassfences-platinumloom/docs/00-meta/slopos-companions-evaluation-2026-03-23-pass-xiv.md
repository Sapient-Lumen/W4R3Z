# SlopOS + companions evaluation — pass XIV

This pass reads SlopOS and the siblings as pressure for Foundry to become better at **foreign utility without fake locality**.

## Lessons from the datacubes
1. **SlopOS checkpoint/restore work already assumes resume is not magical continuity.**  
   That pressure says Foundry should keep restore duties explicit instead of letting resumed execution impersonate fresh readiness.

2. **SlopOS driver-host and compat-runtime work rewards explicit membranes.**  
   RFC-0083 makes containment and restartability part of the shape. Foundry should therefore keep owned-versus-borrowed foreign handles visible, not buried inside host folklore.

3. **Steward keeps restart and adoption stages distinct.**  
   Foundry should do the same for resumed, repaired, reacquired, and adopted foreign realization.

4. **ViewFS and Harbor both reward degradation honesty.**  
   If attachment discovery or capability routing degrades, Foundry should export an availability floor or fallback lease instead of pretending the strongest path still held.

## Resulting cube move
Do not decide yet whether `availability floor` belongs with `restore duty ledger` or beside it.  
Keep them separate specimen nouns until they improve:
- one routed-capability specimen,
- one restore specimen,
- and one sidecar-discovery specimen.
