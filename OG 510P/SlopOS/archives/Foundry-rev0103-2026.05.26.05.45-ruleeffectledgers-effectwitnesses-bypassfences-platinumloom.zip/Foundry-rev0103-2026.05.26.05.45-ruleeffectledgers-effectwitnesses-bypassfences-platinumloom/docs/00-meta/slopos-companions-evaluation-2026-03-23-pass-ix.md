# SlopOS / companions evaluation — 2026-03-23 pass X

This pass evaluated whether Foundry can adopt resource-handle and availability ideas without turning into a generic component framework clone.

## SlopOS pressure that matters most now

`rfcs/0009-component-manifests-and-capability-routing.md` remains the cleanest pressure: capability routing should stay explicit and lintable, not ambient. That supports pass X strongly.

The microVM posture files around generation witnesses, restore-repair barriers, and snapshot humility still reinforce the main restraint: foreign-ground continuity is a smaller claim than local adoption.

The broader foreign-ground and artifact-resolution cuts continue to argue that routed power, nearby evidence, and live realization must remain visibly different.

## Sibling pressure that matters most now

### Harbor
Harbor keeps reminding Foundry that the membrane result and the realization result are not the same object.

### Ward
Ward mirrors pass X neatly. Resource handles and routed power can verify or resolve cleanly while still remaining smaller than local release or approval.

### Schell and Helm
Schell wants explicit adoption after helper or provider turns; Helm wants visible user-facing consequences. Both support availability rails and virtualization grants as inspectable surfaces instead of hidden host folklore.

## Recommendation for Foundry rev0011

Foundry should keep these candidate nouns provisional:
- **resource handle**
- **availability rail**
- **virtualization grant**
- **failure-before-launch**

The pass X specimen should exist to kill over-wide versions early:
- if resource handle starts implying native objecthood, it is too strong;
- if availability rail turns into universal deployment doctrine, it is too frozen;
- if virtualization grant starts swallowing all policy or orchestration language, it is too wide.

Foundry is healthiest when it keeps foreign smoothness honest.
