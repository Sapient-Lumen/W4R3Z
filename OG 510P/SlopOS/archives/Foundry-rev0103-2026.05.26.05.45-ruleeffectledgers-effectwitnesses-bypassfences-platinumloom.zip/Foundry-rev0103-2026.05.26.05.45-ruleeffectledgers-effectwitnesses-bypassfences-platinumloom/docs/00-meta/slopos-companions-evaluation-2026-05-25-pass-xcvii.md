# SlopOS companions evaluation — pass XCVII

Rev0097 adds recheck/drift residue and audits the schema/fixture harness. The companion boundary remains strict: Foundry records semantic freshness posture; neighbors keep their own authority.

## SlopOS

SlopOS support cards benefit directly. A support card can now say that its sidecar, classification pins, observation-status badge, recall route, and no-reexport boundary were verified at a point in time and then rechecked or fenced later. Foundry still must not turn a clear drift signal into SlopOS proof.

## Ward

Ward preview packets need stale-verification fences when boundary text, classification pins, or verdict-disclaimers drift. Foundry may report the drift. Ward still owns appraisal and verdict.

## ViewFS

ViewFS projections are especially vulnerable to inherited access and alias rebinding. Foundry can require recheck cadences and drift signals for projection objects, but ViewFS still owns custody, object identity, trusted paths, and access authority.

## Steward

Delegated workers need pre-execute rechecks. Foundry can fence flapping worker signals or missed rechecks before reuse; Steward still owns retry, replay, pushback, lifecycle, and effect finality.

## Harbor

Public-link or external-notebook surfaces need recall-route and no-reexport drift signals. Foundry can show missing recall routes or stale carrier signals; Harbor still owns external crossing aftermath and implementation receipts.

## Schell

Schell remains the retention/minimization authority. Foundry can mark a stale verification around a retained or retired surface, but it must not decide forgetting, retention, legal hold, or privacy minimization.

## Helm

Helm repair and intervention traces can supply evidence that a probe was rerun or a guard restored. Foundry can consume that as drift evidence, not as repair completion.

## Refactor result

The schema/fixture coverage manifest reduces harness drift across all companions. It ensures new semantic carriers do not arrive as prose-only additions, and it ensures a checker is actually registered in `make check`.
