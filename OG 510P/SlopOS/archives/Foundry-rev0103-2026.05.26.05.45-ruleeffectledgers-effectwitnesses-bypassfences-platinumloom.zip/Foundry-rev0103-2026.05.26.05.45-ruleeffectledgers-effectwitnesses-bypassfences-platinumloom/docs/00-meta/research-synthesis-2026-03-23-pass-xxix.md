# Research synthesis — pass XXIX

This pass keeps the next seam deliberately narrow: **admission cut / drain epoch / grace fence**.
The outside systems keep repeating the same lesson in different clothes: a thing can stop admitting new work and still remain live enough that eager teardown would be dishonest.
Foundry should preserve that seam without importing a giant orchestration or quiesce framework.

## Primary lessons from the outside

### 1) Removed from visibility is still smaller than reclaimable
Linux RCU states the idea plainly: destructive work splits into two parts.
First, prevent anyone new from seeing the thing being destroyed.
Then wait for a **grace period** long enough that all pre-existing readers have dropped their references before freeing it.
That is an excellent anti-lesson for Foundry: *not newly reachable* is still smaller than *safe to reclaim*.

### 2) Successor live and predecessor draining can overlap honestly
Envoy hot restart keeps two truths visible at once.
The new process fully initializes itself, starts listening, and only then tells the old process to begin draining.
Existing connections are not transferred; they must finish during the drain process or be terminated later.
That is a strong reminder that replacement currentness and predecessor drain completion are different facts.

### 3) Terminating and serving can both be true
Kubernetes EndpointSlices keep `serving`, `terminating`, and `ready` distinct.
`ready` is effectively `serving && !terminating`, and a terminating endpoint may still be serving.
That is exactly the kind of seam Foundry should steal: "no longer admitted as the ordinary ready target" is still smaller than "not serving anything anymore".

## SlopOS/companion pressure
The uploaded SlopOS archive already has healthy instincts here.
Its quiesce and deferred-reclamation work suggests that the mechanism layer is being designed elsewhere.
Foundry therefore should stay on the meaning seam and avoid trying to become a lifecycle manager, supervisor, or RCU subsystem.

## Candidate nouns worth collecting
- **admission cut** — explicit point after which a realization should not take new externally triggered work;
- **drain epoch** — bounded overlap period where pre-existing work, readers, sessions, or connections may still complete;
- **grace fence** — explicit blocker before final teardown or reclamation while pre-existing use may still exist.

## Things to keep parked
- global freeze/orchestration state machines;
- universal in-flight counters or scheduler policy;
- a generic GC or destructor substrate;
- a promise that every foreign realization supports cooperative drain.

## Provisional judgment
Promote only the seam, not the mechanism.
Foundry should be able to say that a realization is *past admission*, *still draining*, and *not yet safe to reclaim*, while leaving the actual quiesce, supervision, and reclamation machinery to SlopOS and sibling cubes.
