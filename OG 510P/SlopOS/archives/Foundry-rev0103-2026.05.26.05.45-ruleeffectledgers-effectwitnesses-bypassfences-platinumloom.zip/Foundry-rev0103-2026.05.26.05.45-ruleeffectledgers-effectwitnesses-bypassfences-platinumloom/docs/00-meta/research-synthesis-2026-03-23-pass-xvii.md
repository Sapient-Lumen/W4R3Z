# Research synthesis — pass XVIII

This pass keeps Foundry narrow and learns one more thing from outside runtime systems: **a foreign layer can be compatibility-checked, detachable, and structurally separate from its backing cargo without ever pretending to be native base truth**.

## Outside lessons
1. **systemd-sysext keeps compatibility explicit.**  
   A system extension image must carry an `extension-release` file, and the mechanism is explicitly there to ensure ABI/API compatibility and prevent merging an incompatible image. Foundry should steal the discipline: foreign layers need a compact compatibility witness instead of ambient optimism.

2. **systemd’s extension model also keeps extension and base visibly distinct.**  
   The extension can be merged and later removed; compatibility is checked at merge time rather than silently assumed. Foundry should preserve detachable-layer honesty instead of pretending every successful attach becomes native base truth.

3. **composefs separates structure from cargo.**  
   The project stores metadata separately from non-empty file data, with the metadata tree mounted from an image and the file content living in a backing store that can be shared across mounts. Foundry should steal that shape: the mountable structural layer and the backing cargo are not the same thing.

4. **Integrity can span both structure and cargo without collapsing them.**  
   composefs can validate the backing content via fs-verity and can also validate the image itself with an expected digest. Foundry should keep structural witness and cargo witness distinct from live adoption.

## Resulting Foundry move
Do not decide yet whether the durable nouns are `extension witness`, `detachable layer`, and `backing cargo`, or whether one later collapses behind a smaller compatibility family.
For now, keep all three alive as specimen nouns and demand that they improve:
- one compat-checked attach specimen,
- one detach/rollback specimen,
- and one specimen where structural layer and backing cargo have different locality or integrity stories.

## Fresh ideas worth stealing
- **extension witness** — compact proof that a foreign layer matches the base it wants to join.
- **detachable layer** — foreign merge that remains visibly removable.
- **backing cargo** — content store distinct from the mountable structural layer.
- **structure/cargo split** — integrity can cover both without pretending they are the same object.

