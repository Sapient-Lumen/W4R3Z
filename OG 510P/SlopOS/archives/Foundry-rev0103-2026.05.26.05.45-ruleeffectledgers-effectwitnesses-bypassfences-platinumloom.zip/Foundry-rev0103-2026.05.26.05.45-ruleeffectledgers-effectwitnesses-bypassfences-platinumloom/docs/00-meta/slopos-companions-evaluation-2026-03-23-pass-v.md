# SlopOS and companion-cube evaluation — 2026-03-23 pass V

## Lessons to steal from SlopOS
- `foreign-cell-contract.md` remains the single strongest imported constitution: portalized interop, no ambient channels, closed ABI, and policy-killable lanes.
- The microVM family already contains the right non-folklore moves: reviewed resume classes, generation witnesses, restore repair barriers, resume admission evidence, and attestation reacquire posture.
- Confidential-computing boundary cuts in SlopOS point the same way as modern CoCo deployments: evidence inputs and release policy should stay separate.

## Lessons to steal from siblings
- **ViewFS** keeps package, carrier, realized object, and handle truth separate.
- **Harbor** reminds Foundry that admission and aftermath across a foreign crossing need their own honesty.
- **Ward** reminds Foundry that runtime measurements, generation witnesses, and boot claims remain appraisable material rather than local verdicts.
- **Schell** contributes humility about live checkout, helper lanes, and parallel repo/tool flows that may span multiple grounds without becoming one runtime truth.
- **Helm** contributes visible status surfaces that can mark projected, delegated, resumed, or foreign state rather than pretending it is all equally native.

## Process result
Foundry still should not unify OCI bundles, Wasm components, and resumed microVMs under one total object model. The pass-V outcome is a clearer process rule:
- keep package, contract, ground, and live instance as separate surfaces,
- keep continuity claims explicit and graded,
- and let Ward decide what runtime evidence means for trust.
