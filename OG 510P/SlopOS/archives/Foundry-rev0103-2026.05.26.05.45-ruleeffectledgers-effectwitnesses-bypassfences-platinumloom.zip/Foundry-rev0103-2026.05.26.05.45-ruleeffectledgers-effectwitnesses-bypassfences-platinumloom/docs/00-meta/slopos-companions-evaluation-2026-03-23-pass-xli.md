# SlopOS plus companions evaluation — pass XLI

SlopOS and the neighboring cubes support the same narrow lesson: **derived power should stay visibly narrower than its parent, and ancestor state should keep mattering, but the machinery that enforces that should remain local unless a later specimen proves otherwise**.

## SlopOS
SlopOS already leans hard in this direction.
Its capability semantics keep derivation attenuation-only.
`capability-export-schema-v0.md` says CH-CAPX is an envelope around opaque imported token/reference bytes rather than a portable caveat VM.
`capability-lease-posture-v0.md` says a lease proxy may only attenuate the wrapped capability.
`budget-payer-semantics-v0.md` says the portable delegation rule is still monotonic attenuation plus lineage.
And `mcp-id-jag-import-boundary-v0.md` keeps `subject_token` exchange and ID-JAG flows provider-local cross-domain bootstrap rather than a native token-exchange broker or account-binding substrate.

That means Foundry should **not** grow a generic delegation plane, token wallet, or actor-chain registry here.
It should only preserve the semantic seam so off-native realization can stay honest when one child artifact is narrower than the parent and still lives under ancestor shadow.

## Steward
Steward rev0099 already has an **attenuated grant** posture that is almost the same lesson in live-grant form.
Derived grants may only attenuate; parent and child identities stay distinct; and parent expiry, revocation, or consumption still matters.
Foundry does not need Steward's live grant mechanics, but it should preserve the realization-side seam so foreign-backed descendants do not silently impersonate fresh independent authority.

## Ward
Ward rev0020 already keeps **attenuation event** and **receiver stance** separate.
That is useful confirmation that a sender-side narrowing story is still smaller than the receiver's local consequence story.
Foundry can borrow the derivation humility while keeping Ward's appraisal and consequence semantics separate from runtime-ground truth.

## Harbor
Harbor's resource-audience and scope-split work reinforces the same point from the crossing side: exact target/resource narrowing is often load-bearing, and child credentials or routed proofs should not be treated as broad reissuance.
That supports an attenuation fence without importing Harbor's whole crossing/verdict story.

## Resulting judgment
Promote only the smallest new trio:
1. **derivation witness** — exact parent-to-child lineage witness for one narrowed descendant artifact;
2. **attenuation fence** — explicit upper-bound narrowing across target, action, audience, time, use, or condition;
3. **ancestor shadow** — visible rule that parent or lineage state can still narrow descendant truth.

Keep parked for now:
- discharge witnesses for third-party caveat satisfaction,
- actor-path cards for longer multi-hop delegation history,
- generic token-exchange or wallet surfaces,
- and a broader caveat or authorization language family.

That keeps Foundry aligned with SlopOS's design-phase discipline: preserve the seam, do not harden the subsystem too early.
