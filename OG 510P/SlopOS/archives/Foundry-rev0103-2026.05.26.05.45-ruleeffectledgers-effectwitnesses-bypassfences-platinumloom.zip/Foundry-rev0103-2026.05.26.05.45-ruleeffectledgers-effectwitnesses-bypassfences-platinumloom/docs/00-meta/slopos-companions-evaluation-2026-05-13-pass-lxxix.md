# SlopOS + companions evaluation — pass LXXIX

This pass evaluates Foundry's next SlopOS-facing datacube seam: aggregate release and disclosure-control honesty.

## Verdict

Promote one narrow seam: **disclosure cut**, **suppression witness**, and **differencing fence**.

This is a conservative promotion because it does not choose a privacy engine, suppression algorithm, differential-privacy implementation, clean-room product, or publication-policy language. It only names the residue a result must carry when it is released under aggregate disclosure controls.

## SlopOS pressure

SlopOS already contains repeated “bounded visibility” pressure that maps cleanly onto aggregate-release honesty:

- observation export is pull-only, bounded, redaction-first, policy-killable, and non-authoritative;
- ATTRFS is view-scoped, snapshot-first, handle-returning, and refuses app-visible count-only / existence-probe semantics;
- quarantined content may be discoverable by metadata-safe attributes without ambient full-text, OCR, embedding, summary, or preview leakage;
- result previews for quarantined objects stay metadata-safe until a separate explicit open/review step;
- Digital Credentials and FedCM are mediated/provider-local surfaces, not global account, wallet, or approval truth;
- support cards and diagnostics will want aggregate counts, cohorts, rates, and bands before SlopOS has a final product ontology.

Foundry should therefore carry release-policy residue beside aggregate results instead of letting SlopOS dashboards invent silent privacy folklore.

## Companion pressure

- **Harbor** has receiver-scoped disclosure and contract-subset pressure; Foundry should preserve release cuts without importing Harbor's credential/receiver semantics wholesale.
- **Ward** evaluates evidence and trust posture; Foundry should not turn a suppression pass, clean-room rule, or DP clause into Ward-like approval.
- **ViewFS** keeps artifact identity and package lineage honest; Foundry should not treat a released aggregate file or suppressed table as raw cube identity.
- **Helm** and **Schell** are where persuasive user-facing cards appear; their counts must not silently fill suppressed cells as zero or compare cross-lens tiles.
- **Steward** reinforces reconciliation discipline; a disclosure-control check is reconciliation evidence, not source truth.

## Promotion rationale

Specimen 48 already says policy-shaped values need a view lens, disclosure class, and comparability fence.
Specimen 70 says emitted results need a query contract, result envelope, and validation witness.
Specimen 72 says cached/materialized outputs need materialization and reuse evidence.
Specimen 73 adds the missing aggregate-release layer: when the result's visibility depends on suppression, perturbation, clean-room constraints, or privacy-budget posture, Foundry must say which release cut governed it, what was suppressed/noised/refused, and where differencing must stop.

## Non-decisions preserved

- no universal privacy plane;
- no DP engine, privacy-budget authority, or SDC solver;
- no global audience or protected-entity taxonomy;
- no assumption that a small-cell rule protects against all reconstruction;
- no treating clean-room output constraints as all-purpose authorization;
- no treating a differential-privacy clause as a blanket safety warranty;
- no hidden zero-filling, ratio-denominator repair, or chart-axis smoothing for suppressed cells;
- no reuse of aggregate outputs across materialization, audience, policy, calendar, geography, hierarchy, or release-set changes without explicit fences.

## Follow-through needed

Pressure-test specimen 73 against:

- one SlopOS support-card aggregate where a small cell is suppressed and a sibling margin would otherwise reveal it;
- one ATTRFS-style count request that must refuse app-visible existence-probe semantics;
- one observation-export table with redaction policy plus aggregate thresholding;
- one clean-room-style collaborator query where the stricter distinct-entity threshold wins;
- one DP/noisy release where privacy-unit misclassification would make the result unsafe;
- one cached/materialized aggregate where reuse across audiences would bypass the disclosure cut.
