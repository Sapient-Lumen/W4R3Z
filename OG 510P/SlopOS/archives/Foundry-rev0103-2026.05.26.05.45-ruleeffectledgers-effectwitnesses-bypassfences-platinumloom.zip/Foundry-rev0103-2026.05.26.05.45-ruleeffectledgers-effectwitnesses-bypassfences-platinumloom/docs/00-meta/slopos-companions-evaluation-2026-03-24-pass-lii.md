# SlopOS plus companions evaluation — pass LII

This pass adds one more datacube warning:
Foundry should model **which explicit view or export lens shaped a value, what disclosure class the visible payload belongs to, and whether cross-lens comparison is legal at all** before it lets identical-looking counts or summaries masquerade as universal cube truth.

## SlopOS
SlopOS already creates strong pressure in this direction.

`attrfs-posture-v0.md` says smart queries are **view-scoped**, **snapshot-first**, and **handle-returning**.
That means a future ATTRFS-derived count is never just “the count”.
It is the count seen through one explicit view binding and one snapshot cut.
So a future Foundry row should preserve a **view lens** for those outputs.

`observation-export-policy-schema-v0.md` and RFC-0076 say CH-OBSPOL carries an export **tier** (`sanitized` or `full`) plus explicit **redaction classes**.
That is direct pressure for a **disclosure class**.
A sanitized export count, a full operator count, and a masked support-facing count may all be useful, but they are not interchangeable payloads.

`diagnostic-snapshot-bundle-schema-v0.md` and RFC-0075 treat support bundles as explicit-authority exports bound to a policy/redaction profile.
That means any future incident summary row inherits the export lens that allowed it to exist.
So the datacube should not compare a sanitized bundle summary with a full internal bundle summary without an explicit **comparability fence**.

`inspect-snapshot-schema-v0.md` also keeps optional redaction classes near structured state.
That is another reminder that even “current state” is not automatically one audience-neutral truth once exports or summaries leave the origin.

So for a future Foundry datacube over SlopOS surfaces:
- an ATTRFS result count should carry the explicit **view lens** that shaped its reachable set;
- a CH-SNAPSHOT-derived support summary should carry a **disclosure class** tied to the export tier/redaction posture that made it visible;
- any cross-surface rollup that mixes sanitized and full views should carry a **comparability fence** rather than pretending the rows share one denominator story;
- and dashboards/feeds should be free to show a value while still admitting that a broader or more sensitive lens would produce a different one.

## Harbor, Ward, and ViewFS
Harbor already keeps preview/presentation surfaces smaller than durable source truth, which is a healthy neighbor for disclosure-class humility.
Ward keeps exported appraisal smaller than evidence truth, which reinforces that audience-visible residue is not the same as source-complete truth.
ViewFS keeps object/digest discipline strong enough that a value can preserve its lens without growing a giant policy product around it.

## Resulting judgment
Promote only the following small seam in this revision:
1. **view lens** — which explicit view/export/policy lens shaped the visible value;
2. **disclosure class** — what kind of visible payload survived that lens;
3. **comparability fence** — whether cross-lens arithmetic is same-lens-only, threshold-gated, monotone-only, or unsafe.

Keep parked for now:
- a universal authorization or tenant plane;
- a giant privacy-budget product;
- a cross-lens query rewriting engine;
- or a fully normalized catalog of audiences and entitlements.

That keeps Foundry aligned with SlopOS’s still-moving design and gives the datacube a safer path to future ATTRFS counts, sanitized support summaries, masked observability exports, and tiered operator dashboards without premature semantic freeze.
