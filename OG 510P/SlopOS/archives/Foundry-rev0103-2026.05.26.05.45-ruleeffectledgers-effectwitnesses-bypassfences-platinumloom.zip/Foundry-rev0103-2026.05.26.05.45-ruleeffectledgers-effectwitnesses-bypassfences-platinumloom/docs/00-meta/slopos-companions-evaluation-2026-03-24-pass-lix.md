# SlopOS + companions evaluation — pass LIX

This pass checks whether **reset anchor, carry class, and continuity fence** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal billing-cycle plane, a reset-normalization engine, or a general forecasting product.

## Why SlopOS pressures this seam now

### 1) SlopOS already mixes long-lived meters, short-lived leases, and observational usage summaries
`docs/30-architecture/meter-descriptor-schema-v0.md` gives Foundry counter-like and allowance-like families such as `mem_bytes`, `net_bytes`, `io_buf_bytes`, `cpu_ticks`, and count-like kernel references.
`docs/30-architecture/budget-lease-schema-v0.md` adds operation-scoped budget leases with optional expiry.
`docs/30-architecture/quota-replication-boundary-v0.md` then keeps replicated quota rows as observational additive spend summaries rather than fresh spend authority.
That is already enough pressure for Foundry to preserve **what anchor a visible number belongs to** instead of flattening all of them into one generic cumulative line.

### 2) Lease expiry and reissue are not the same thing as a monotonic service counter
A service-exported `net_bytes_sent_total` might be “since process start,” while an attached budget lease is “remaining under this issued payer slice until expiry.”
Those values may both look like simple magnitudes, but they live under different reset anchors and different continuity expectations.
That pressures Foundry toward an explicit **reset anchor**.

### 3) SlopOS already distinguishes authority from observational accounting
The quota-replication boundary is explicit that replicated quota summaries are additive observations under already-issued local credit, not remote admission authority.
That means any cross-window or cross-cluster stitching story has to stay visibly smaller than spend authority.
This pressures Foundry toward an explicit **continuity fence**.

### 4) Carryover semantics will matter before a full datacube exists
Even in design phase, support tiles and review surfaces will want to say things like:
- remaining under this lease,
- used this period,
- since restart,
- total to date,
- or reissued after threshold.
Those are not just formatting differences.
They are exactly the kind of quiet semantic drift that should be captured by **carry class** before it hardens into folklore.

## What to steal into Foundry

### reset anchor
A compact witness for the boundary that re-bases the family.
Examples:
- `process_start`
- `lease_issue`
- `billing_cycle_anchor`
- `threshold_reanchor`
- `manual_reset`
- `lifetime_none`

This is smaller than a giant lifecycle registry.
It just stops lower numbers from impersonating negative work.

### carry class
A compact witness for what persists across the boundary.
Examples:
- `none`
- `residual_credit`
- `tier_memory`
- `observational_only`
- `other_explicit`

This is smaller than a financial or entitlement engine.
It simply keeps period, lease, and long-lived cumulative semantics visibly different.

### continuity fence
A compact witness for how cross-boundary reasoning is allowed.
Examples:
- `stitchable_with_reset_detection`
- `same_anchor_only`
- `policy_restatement_required`
- `forbidden`

This is smaller than a replay or forecasting plane.
It just prevents charts and exports from silently inventing lifetime continuity.

## Why this seam is small enough now
It does **not** require:
- one universal cycle model for all usage families;
- one mandatory reset detector for every source;
- a global burn-rate or forecasting plane;
- or a promise that all counters, quotas, budgets, and provider meters can be stitched into one canonical cumulative story.

It only says that once Foundry emits a reset-sensitive or allowance-shaped value, it should preserve:
1. **what re-anchors it**,
2. **what carries across that boundary**,
3. and **what kind of continuity is lawful or forbidden**.

## Recommended Foundry posture
Promote **reset anchor**, **carry class**, and **continuity fence** as a narrow honesty seam for counters, budgets, leases, usage windows, and threshold-anchored families.
Keep the larger cycle/billing/forecasting questions parked.

This matches current SlopOS discipline well: SlopOS already treats payer state as explicit, already separates authority from observational quota replication, and is still early enough that Foundry should record only the smallest residue needed to keep restarts, reissues, and rollovers from turning into dashboard folklore.
