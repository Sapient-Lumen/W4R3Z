# SlopOS + companions evaluation — pass LXIX

This pass checks whether **match cluster, survivorship witness, and golden-row fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant master-data plane, one archive-wide deduplication engine, or a permanent “golden row = true subject” doctrine.

## Why SlopOS pressures this seam now

### 1) SlopOS already imports identity/profile-shaped material that can cluster without becoming native truth
`docs/30-architecture/mcp-userinfo-import-boundary-v0.md` explicitly keeps imported subject/profile/email material smaller than portable account or subject truth.
That means future cube rows built from imported identity/profile surfaces will often be **candidate same-subject material** before they earn native identity promotion.
That is direct **match cluster** pressure.

### 2) SlopOS repeatedly separates exact evidence from portable claims
The assurance and boundary docs keep imported claims, native boundaries, non-claims, and profile-specific posture visibly distinct.
That makes “representative row for convenience” tempting but dangerous.
A summary row may help a UI or export while still remaining smaller than the archive’s actual subject truth.
That is direct **golden-row fence** pressure.

### 3) Verification and approval surfaces can pick a winner without proving ontology
`docs/40-verification/worker-pool-verdict-summary-v0.md` is intentionally compact and family-local.
It tells us a reviewed summary may exist without promising a universal archive-wide winner grammar.
That reinforces the need for a **survivorship witness** when one representative row or field value is chosen for a narrow purpose.

### 4) Quarantine and imported-origin material will invite duplicate-sensitive summaries
The quarantine/import/posture family already creates pressure for rows like “best visible representative of this imported artifact/profile/subject cluster.”
But that still differs from “this is the native subject.”
Foundry needs a way to preserve cluster membership and representative-choice posture without letting the representative row become ontology.

### 5) Companions reinforce the same caution
Harbor, Ward, ViewFS, and Steward all carry summary-friendly surfaces where a representative row may be useful while still remaining smaller than source truth.
Together they say the same thing: neighboring archives want convenient representatives, but they do not justify a permanent golden-record doctrine.

## SlopOS-side recommendation
If a future SlopOS-adjacent cube needs duplicate-sensitive summaries, Foundry should let the row say:
- **this is a match cluster, not yet a native identity,**
- **this representative came from a reviewed survivorship witness,**
- and **this row has a fence that limits where it can stand in for the cluster.**

That is enough to keep design-phase identity/import pressure honest without freezing a giant MDM subsystem into the cube.
