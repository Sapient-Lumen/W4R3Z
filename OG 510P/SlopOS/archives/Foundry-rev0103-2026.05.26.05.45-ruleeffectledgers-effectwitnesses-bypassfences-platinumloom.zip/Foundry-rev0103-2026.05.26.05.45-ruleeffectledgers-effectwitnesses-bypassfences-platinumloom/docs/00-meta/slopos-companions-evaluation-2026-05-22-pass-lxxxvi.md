# SlopOS and companions evaluation — 2026-05-22 pass LXXXVI

Focus: whether Foundry can carry bounded semantic exceptions without turning them into approval, policy override, or hidden success.

## SlopOS pressure

SlopOS already treats evidence as something that can be replayed, rechecked, or refused. Foundry should follow that instinct when a semantic egress or regression failure is temporarily tolerated. A waiver must bind to the original refusal receipt or regression lock, name its scope, expire, and require replay. Otherwise the waiver becomes a second path around the very fences Foundry just made executable.

The pressure is not that Foundry should manage SlopOS permissions. The pressure is smaller: if a SlopOS-facing support-card preview uses a waiver, the waiver must say which cut, consumer, surface, rules, and loss posture were accepted, and the next revision must rerun the gate.

## Companion boundaries

| Companion | Semantic-waiver interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| Ward | may consume a waiver warrant as evidence that an appraisal surface was knowingly incomplete | Ward still owns appraisal, consequence, and trust verdicts |
| Harbor | may attach outside-fact/correction aftermath to a waiver review | Harbor still owns membrane authority and external status |
| Steward | may treat a waiver as lifecycle evidence during retry/replay windows | Steward still owns effect finality and operational lifecycle |
| Schell | may require waiver expiry when minimization or retention posture constrains drill-through | Schell still owns forgetting and minimization authority |
| ViewFS | may expose waiver warrants as projection sidecars near exported artifacts | ViewFS still owns object identity, trusted paths, and consent fences |
| Helm | may reference expired or rejected waivers during repair/intervention traces | Helm still owns repair custody and intervention consequence |
| SlopOS | may consume waiver ids beside CH-* support-card exports | SlopOS still owns SlopOS boundary families and proof claims |
| External audit notebook | may rely on a preview waiver only within the named cut and expiry | does not promote Foundry into an audit, policy, or risk-acceptance product |

## What changed in this pass

- Added specimen 80 for waiver warrants, expiry witnesses, and exception replay gates.
- Added a semantic waiver rulebook so temporary exceptions have named failure modes before they appear in fixtures.
- Added v0 schemas for semantic waiver warrants and exception replay gates.
- Added a specimen 80 fixture with active, expired, and rejected waivers plus replay gates and negative cases.
- Added `check_foundry_semantic_exceptions.py` and wired it into `make check`.
- Added SARIF, OPA decision-log, and CycloneDX VEX pressure while keeping Foundry smaller than static-analysis triage, policy-decision logging, vulnerability management, or risk-acceptance workflow.

## Recommendation

Future Foundry revisions should never treat a waiver as success. A waiver is a bounded exception attached to a refusal or regression alarm. It must expire, replay, and remain scope-specific; otherwise the correct outcome is another refusal receipt or a regression failure.
