# SlopOS and companion evaluation — pass XII

The current archive set repeatedly refuses magical continuity, magical availability, and magical attachment completeness.

## What the current archives are teaching Foundry
- SlopOS's confidential-computing and result-sidecar families keep evidence, policy input, and result export visibly distinct. Foundry should continue exporting smaller truths rather than pretending runtime realization settles appraisal.
- Schell and Helm both treat foreign/helper lanes as needing explicit adoption and visible downgrade posture. Foundry becomes healthier when it remains blunt about what is still foreign.
- ViewFS keeps carriers, objects, and durable references separate. That same instinct should keep Foundry from flattening packages, sidecars, handles, and live instances.

## Most useful pressure for the next pass
Foundry should pressure-test whether **restore obligation** and **availability class** deserve first-class objects or whether one can remain a compact annotation on launch/adoption surfaces.
