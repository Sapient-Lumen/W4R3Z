# Research synthesis — pass XXXII

This pass keeps the next seam deliberately narrow: **commit frontier / apply frontier / delta horizon**.
Outside systems keep repeating the same lesson in different clothes: one point marks what the authority has durably accepted, another marks what one reader/replica/cache/process has actually ingested or applied locally, and a third boundary marks how far back incremental catch-up is still possible before snapshot, reseed, or reinitialization becomes necessary.
Foundry should preserve that seam without importing a universal replication protocol, consensus substrate, or log-shipping plane.

## Primary lessons from the outside

### 1) Committed and applied are different truths
etcd exposes this seam with unusual honesty.
Its status surface publishes both `raftIndex` (current committed index) and `raftAppliedIndex` (current applied index) for a responding member.
That is exactly the humility Foundry should steal.
A system can truthfully say “the authoritative stream has committed through N” while still admitting that one member or consumer has only applied through M.

PostgreSQL teaches the same lesson from a different stack.
The primary exposes current WAL locations, standbys expose received and replayed WAL locations, and the docs explicitly point to differences between `sent_lsn`, receive positions, and replay positions as meaningful lag signals.
That means “durably produced” and “visible here after replay” stay separate facts even in a very mature replication story.

### 2) Catch-upability is smaller than freshness
etcd’s watch and history model adds the next important seam.
Watches are resumable only while the needed revision remains in the available history window.
If a client asks from a compacted revision, the watch is canceled and the server reports the compact revision; if a slow follower asks for log entries before a compacted index, the leader sends a snapshot instead.
That is the pattern to steal: being behind is one fact, but being *incrementally bridgeable from here* is a different fact.

PostgreSQL makes the same boundary painfully operational.
If a standby falls behind far enough that required WAL files are gone, it may no longer be able to continue replication; the docs say the standby will need to be reinitialized from a new base backup.
So lag has two regimes: ordinary lag that delta catch-up can bridge, and history loss where only snapshot/reseed truth remains honest.

### 3) Progress beacons are useful, but they are not the same as visibility truth
etcd progress notifications and watch revisions are great because they let a client reason about how stale one watch stream is.
But even there, the docs warn that a local watch-progress revision may be lower than a quorum read if the connected node is partitioned.
That is another good steal for Foundry: progress beacons are useful residue, not a replacement for the distinction between authoritative commit and one observer’s applied/visible point.

## SlopOS/companion pressure
The uploaded SlopOS archive already leans in the right direction.
It keeps replication, lag, checkpoint, quiesce, seed, and reseed surfaces separate enough that Foundry does not need to import a full replication control plane.
`adrs/0006-cross-cluster-replication-contracts-v0.md`, `cluster-phase1-envelope-v0.md`, `worker-pool-quiesce-state-v0.md`, `worker-pool-seed-surface-v0.md`, and the proof/invariant registries all point the same way: slow followers, checkpoint cuts, and reseed/reset boundaries are real pressures, but they do not yet need one giant universal noun.

That makes the Foundry move smaller and cleaner.
Foundry should preserve one public seam for:
- what exact state has durably entered the authoritative stream (**commit frontier**),
- what exact state one realization or observer has actually ingested/applied locally (**apply frontier**),
- and how far back incremental catch-up is still honest before snapshot/reseed takes over (**delta horizon**).

## Candidate nouns worth collecting
- **commit frontier** — highest authoritative, durably accepted change point for one stream, history, or basis lineage.
- **apply frontier** — highest change point that one realization, replica, cache, or observer has actually ingested/applied locally.
- **delta horizon** — earliest still-usable point for incremental catch-up before snapshot/reseed/reinitialization becomes necessary.

## Things to keep parked
- a universal replication-role taxonomy;
- a native consensus/leader-election object family;
- a promise that every lagging subject can always bridge incrementally;
- any flattening of commit truth, visibility truth, and reseed necessity into one “freshness” bit.

## Provisional judgment
Promote only the seam, not the machinery.
Foundry should be able to say that the authoritative history is committed through one **commit frontier**, that one realization has only caught up through a lower **apply frontier**, and that incremental catch-up remains honest only while the gap stays within one **delta horizon**.
That is especially valuable while SlopOS is still plastic enough to avoid hiding log-retention, snapshot, and replay/reseed boundaries behind one flattering replication status object.
