# SlopOS plus companions evaluation — pass XXXV

This pass tested whether Foundry needs a small meaning seam for *retry-equivalent foreign effect versus changed request versus prior replayable outcome*.
The answer is yes, but again only narrowly.

## What SlopOS and companions already contribute
The uploaded SlopOS archive already has the right instincts for this area.
Its request-state postures for network, background, entropy, and timeproof lanes repeatedly refuse to let requester-chosen request identity impersonate portal-owned live state.
Its request-idempotency boundary goes further and freezes the exact anti-mistake Foundry needs: the same scoped request key means exact replay of one canonical request, not mutable upsert, merge, replace, or broadened meaning under one old key.
That is the right house style.

The companions strengthen the same direction:
- **Steward** already names a tiny effect-key seam, keeps effect fingerprint separate from target identity, distinguishes duplicate suppression from mismatch and still-processing, and refuses a giant exactly-once myth.
- **Helm** already keeps request acceptance, local durability, replication posture, receiver adoption, and final settlement distinct, which means it naturally resists treating “same key got a prior answer” as universal current truth.
- **ViewFS** keeps accepted offers, committed versions, writable sessions, and receiver-local adopted binds visibly separate, which reinforces the rule that one remembered request or receipt is smaller than current live state.

So the ecosystem already has better homes for broad workflow, receipt, and queue semantics.
Foundry does not need to grow a second one.

## What Foundry should own instead
Foundry should own only the semantic split that keeps these facts separate:
1. **effect key** — which foreign mutation attempts count as the same retry-equivalent requested effect;
2. **fingerprint fence** — what exact canonical request/effect shape must still match before that key can safely reuse prior work;
3. **prior-outcome anchor** — which earlier accepted outcome or receipt may honestly be replayed for an exact duplicate-safe retry.

That seam is smaller than a queue, smaller than a settlement center, and smaller than a transaction protocol.
It is just enough vocabulary to stop later docs from flattening “same key”, “same effect”, “prior accepted answer”, and “current live state” into one flattering blob.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small truth that one foreign-backed mutation can be:
- identified as the same retry-equivalent request,
- rejected because the request under that key has drifted materially,
- or answered by replaying a prior accepted outcome without implying fresh execution or present settlement.

If Foundry misses that seam now, later revisions will be tempted to let client tokens, request IDs, and historical receipts stand in for live foreign state or for a mythical exactly-once guarantee.
That would make the archive worse at explaining network-timeout retries, duplicate-safe launch/start requests, publish/create ambiguity, and provider APIs that intentionally keep mismatch, outstanding, replayed, and expired-window outcomes distinct.
