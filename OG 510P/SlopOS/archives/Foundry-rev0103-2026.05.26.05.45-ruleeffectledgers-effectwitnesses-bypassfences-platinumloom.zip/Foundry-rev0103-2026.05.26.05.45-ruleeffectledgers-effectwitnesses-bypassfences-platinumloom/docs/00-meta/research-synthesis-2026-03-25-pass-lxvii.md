# Research synthesis — pass LXVII

This pass stays conservative.
Foundry still should **not** freeze one universal join planner, one universal hierarchy law, or one flattering doctrine that every count-like value is safely rollup-friendly.
But it can steal one more durable lesson from semantic-layer join planners, BI relationship guidance, bridge-table modeling, and cube engines: **a design-phase datacube needs to say what got counted once, what fanout/bridge shape touched the answer, and when regrouping that answer would misrepresent reality.**

The smallest durable seam from this pass is:
- **contribution basis** — the compact statement of what the visible count/total counted once: native row, distinct subject, bridge association row, higher-grain target row, sketch family, or another reviewed basis;
- **fanout class** — the compact statement of which join/relationship shape affected the answer: none, one-sided fanout with explicit dedupe, bridge many-to-many, higher-grain projection, approximate-decomposed, or refused chasm;
- **reaggregation fence** — the compact statement of what regrouping or rollup is still lawful: native rollup, same-basis only, do-not-group-below-level, same-sketch-family only, or forbidden.

These are still smaller than a universal semantic join graph, a built-in bridge-weighting algebra, or one permanent hierarchy model.
They simply stop helpful counts from hardening into dishonest totals.

## Lessons we must learn from the past

### 1) Fanout mistakes are old, common, and still expensive
Looker’s current symmetric-aggregates guidance is refreshingly blunt: one-to-many joins make it easy to compute incorrect sums, averages, and counts, so the engine works by counting each fact the correct number of times, and it depends on a unique primary key plus the correct join relationship.
That is exactly the lesson Foundry should steal.
A count-like value is not honest merely because it is numeric; the cube should say what got counted once.

### 2) Safe join semantics are better when relationship posture is explicit instead of improvised
Current dbt MetricFlow guidance says entity types determine join logic and that the engine avoids fan-out or chasm joins based on those entity types.
That is useful pressure for Foundry.
A future count should not have to smuggle its join safety in implementation folklore; the answer should preserve a compact **fanout class** instead.

### 3) Higher-grain facts need a lawful floor below which summaries should stop pretending
Current Power BI many-to-many and higher-grain-fact guidance is unusually practical.
When a fact lives at a higher grain than the dimension rows, Microsoft recommends controlling summarization with measures and returning `BLANK` when users drill below the lawful level.
That is a very strong model for Foundry’s **reaggregation fence**.
Some answers should simply refuse regrouping below the level that made them honest.

### 4) Distinct counts and approximate distinct counts are different species
Analysis Services still treats distinct count as special enough to deserve a dedicated measure group, while Cube’s current docs explicitly distinguish non-additive `count_distinct` from additive/decomposable `count_distinct_approx`.
That is a direct warning for Foundry.
A row that says “unique artifacts” and a row that says “approximate unique artifacts from HLL-like sketches” may both look like counts, but they do not share one natural re-rollup law.

### 5) Bridge tables are relationship truth, not proof of safe additive reuse
Microsoft’s current dimensional guidance says multivalued dimensions should be implemented with bridge tables that store many-to-many relationships between entities.
That is useful because it keeps bridge rows visible as relationship artifacts rather than pretending they are the same thing as atomic measurement rows.
Foundry should steal that discipline and keep bridge association counts visibly smaller than native subject counts.

## What to steal now
- a **contribution basis** field or adjunct that says what was counted once: subject, association, target row, or sketch family;
- a **fanout class** that says whether the answer came from native rows, deduped one-to-many joins, many-to-many bridge associations, higher-grain projections, or another reviewed shape;
- a **reaggregation fence** that keeps dashboards and exports from drilling or summing below the lawful level;
- a habit of preserving **distinct subject counts** separately from **association-row counts**;
- and a habit of treating **higher-grain target/summary rows** as smaller than detailed-dimension truth.

## What to keep parked
Do not yet promote:
- one universal hierarchy or rollup planner across the whole cube;
- one bridge-weighting or allocation algebra for every many-to-many family;
- one mandatory distinct-entity doctrine for every count-like answer;
- or a promise that every higher-grain value can always be safely apportioned downward.

## Resulting recommendation
The next healthy move is not “teach Foundry every trick from Looker, dbt, Power BI, SSAS, and Cube.”
It is to let Foundry say, for bridge-heavy and regrouping-sensitive families:
1. **what got counted once,**
2. **what join/fanout shape touched the answer,**
3. and **where reaggregation stops being honest.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart restraint from current semantic-layer and BI modeling practice.
