# Research synthesis — pass XLIV

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal semantic layer while both Foundry and SlopOS remain in design motion.
But it can steal a few more durable ideas from mature warehouse, semantic-layer, and schema-evolution systems.

The smallest durable seam from this pass is:
- **effective time** — when a fact was true on the foreign ground or in the modeled world;
- **record time** — when Foundry learned, accepted, or restated that fact;
- **pending context** — explicit incomplete dimensional context rather than fake completeness.

These are still smaller than a full bitemporal engine, universal metric grammar, or automatic restatement plane.

## Lessons we must learn from the past

### 1) One clock is usually a lie
XTDB and classic bitemporal systems are useful reminders that “when it was true” and “when we knew it” are often different axes.
Warehouse practice teaches the same thing through valid-from/valid-to and retroactive correction handling.
Foundry does not need a universal bitemporal substrate yet, but it should leave room for **effective time** and **record time** to stay visibly different where pressure demands it.

### 2) Late context is normal, not exceptional
Kimball-style early-arriving facts and late-arriving dimensions keep showing up because reality rarely waits for perfectly ordered ingestion.
A datacube that insists on full context before any fact may exist either drops real information or invents fake certainty.
Foundry should therefore allow **pending context** rather than forcing premature completeness.

### 3) Stable field identity is healthier than name worship
Iceberg’s field-ID discipline is the right lesson to steal.
Names, order, and display labels move more often than people want to admit.
Foundry should therefore avoid assuming that the first useful field name is the eternal noun identity.
That does **not** mean creating a giant registry now; it means leaving room for promoted nouns to have identity stronger than one early label.

### 4) Product taxonomies are useful and still unstable
dbt’s semantic-layer work is helpful because it separates relation-spine concepts from descriptive and metric concepts.
But its own docs are also a warning: product-shaped nouns and boundaries move, and even “measures” can later be deprecated in favor of other shapes.
Foundry should steal the **thin semantic spine** instinct without freezing vendor-specific taxonomy as archive law.

### 5) Acceleration is a derived view, not the cube itself
Cube’s pre-aggregations are valuable precisely because they are **materialized query results** and aggregate-awareness machinery, not primary truth.
That is the lesson to steal.
Future Foundry read models, summaries, or pre-aggregated exports should remain visibly derived, freshness-scoped, and revision-hooked.
They should not silently become the canonical cube.

## What to steal now
- a minimal **effective time / record time** split on the few surfaces where retroactive correction or lag genuinely matters;
- explicit **pending context** instead of forcing unknown dimensions to masquerade as complete rows;
- room for future **promoted noun identity** to outlive one early field label;
- a **thin semantic spine** smaller than any vendor product taxonomy;
- **derived acceleration views** that stay visibly downstream from the cube’s core meaning model.

## What to keep parked
Do not yet promote:
- a universal bitemporal engine for every Foundry fact;
- a warehouse-wide restatement planner;
- a giant noun/field registry;
- one permanent metric/measure taxonomy copied from any current tool;
- or a built-in aggregate-awareness planner.

## Resulting recommendation
The next healthy move is not “finish the datacube.”
It is to make it possible for future Foundry surfaces to say:
1. when something was true,
2. when Foundry learned it,
3. and whether some dimensional context is still pending.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing genuinely durable lessons from older systems.
