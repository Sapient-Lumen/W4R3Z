# SlopOS + companions evaluation — pass LVIII

This pass checks whether **unit witness, canonical scale, and conversion fence** are real pressures in the current neighboring archives or just attractive outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal unit registry, a normalization engine, or an automatic conversion layer across every numeric family.

## Why SlopOS pressures this seam now

### 1) SlopOS already mixes several incompatible numeric families inside one design neighborhood
`rfcs/0012-resource-meters-space-banks-and-budgets.md` names `mem_bytes`, `cpu_time`, `io_buf_bytes`, and `net_bytes` as explicit resource kinds, while `rfcs/0034-kernel-object-quotas-and-cap-budgets.md` adds count-like reference objects such as `cap_slot`, `endpoint`, `irq_obj`, and `notify_obj`.
That is already enough pressure for Foundry to preserve a visible **unit witness** rather than a generic `amount` story.

### 2) SlopOS will almost certainly want pretty displays that are smaller than interchange truth
The same meter/budget cluster invites shells and support surfaces to render milliseconds as seconds, byte counts as KiB/MiB/GiB, and utilization as percentages.
That pressures Foundry toward an explicit **canonical scale** so display convenience does not become storage or comparison truth.

### 3) SlopOS also has provider-native or policy-native quantities that should not be auto-normalized away
Capability budgets, operation-scoped budget leases, and portal-local allowances are not obviously comparable to bytes or seconds just because they are all numeric.
That means future value families need a **conversion fence** whenever the quantity is native-only, contextual, or only display-transformable.

### 4) Companion cubes already pressure count-like, rate-like, and summary-like values to coexist
Ward and IF-OBS style measurement exports will naturally want durations, byte counts, rates, ratios, and support-friendly percentages in the same neighborhood.
Without a small honesty seam, those values will look uniformly numeric while silently resisting lawful aggregation or conversion.

## What to steal into Foundry

### unit witness
A compact witness for the exact unit the visible value carries.
Examples:
- `By` or `byte`,
- `s`,
- `1` / ratio,
- count-like non-units such as `{cap_slot}`,
- or an explicit provider-native unit that is not promised to normalize globally.

This is smaller than a giant unit ontology.
It just stops naked numbers from carrying hidden meaning.

### canonical scale
A compact witness for the preferred interchange scale.
Examples:
- bytes rather than bits,
- seconds rather than milliseconds,
- ratio rather than percent,
- or `native_only` where no cross-surface normalization is promised.

This is smaller than a global formatting policy.
It simply keeps the cube’s storage/comparison truth distinct from UI prettification.

### conversion fence
A compact witness for what kind of conversion is legal.
Examples:
- `linear`,
- `affine`,
- `display_only`,
- `contextual`,
- `forbidden`.

This is smaller than a math engine.
It just prevents shells and exports from silently inventing comparability.

## Why this seam is small enough now
It does **not** require:
- one universal code list for every possible unit in the ecosystem;
- automatic pretty-unit selection;
- a valuation model for arbitrary/provider-native credits;
- or a guarantee that every percentage or rate can be reconstructed from raw components in Phase 1.

It only says that once Foundry emits a unit-bearing value, it should preserve:
1. **what unit** the value actually uses,
2. **what canonical scale** the family prefers,
3. and **what kind of conversion** is lawful or forbidden.

## Recommended Foundry posture
Promote **unit witness**, **canonical scale**, and **conversion fence** as a narrow honesty seam for unit-bearing, scale-sensitive, and display-transformed values.
Keep the larger normalization/valuation/formatting questions parked.

This matches current SlopOS discipline well: SlopOS already treats payer/usage families as explicit, already keeps budgets and capabilities semantically distinct, and is still early enough that Foundry should record only the smallest residue needed to keep future numbers from turning into folklore.
