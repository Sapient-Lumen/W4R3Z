# SlopOS + companions evaluation — pass LXXII

This pass checks whether **eligibility basis, exclusion class, and whole-world fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant population ontology, one archive-wide denominator grammar, or a permanent doctrine that every visible summary card speaks for the whole system.

## Why SlopOS pressures this seam now

### 1) Profile planning surfaces already create eligibility pressure
`docs/00-meta/profile-claim-matrix.md` explicitly marks claims as `REQ`, `REC`, `OPT`, or `NO` across profiles.
That means a future cube row like “claim coverage” or “claim pass rate” will often be about a **profile-qualified eligible subset**, not the whole archive.
That is direct **eligibility basis** pressure.

### 2) Threat-model scope and non-claims already create exclusion pressure
`docs/10-threat-model/threat-model.md` names in-scope attack classes and separately names out-of-scope classes.
`docs/20-assurance/non-claims.md` keeps canonical exclusions such as side channels, liveness guarantees, malicious hardware, and broad provenance claims visibly outside default scope.
That means a future dashboard or scorecard could easily mistake “not in scope” for “passed”, “zero”, or “not observed” unless the cube preserves an **exclusion class**.

### 3) Profile posture is not one universal denominator
`docs/00-meta/profile-posture-matrix.md` makes posture relevance vary across workstation, cloud substrate, embedded appliance, and agent OS shapes.
A future “coverage” or “adoption” total that ignores those profile-specific applicability cuts would overstate platform-wide comparability.
That is both **eligibility basis** and **whole-world fence** pressure.

### 4) Existing report surfaces are often deliberately family-local summaries
`docs/40-verification/worker-pool-verdict-summary-v0.md` says `verdict.summary` is a family-local, compact case-indexed table and explicitly keeps broader verdict taxonomies and constructor-global result services out of scope.
That means a useful summary row may still be smaller than a full subject list or archive-wide verdict plane.
That is direct **whole-world fence** pressure.

### 5) Existing observational bundles already carry explicit scope
`docs/30-architecture/capability-graph-schema-v0.md` gives `CH-CAPG v0` an explicit `scope` and describes it as a bounded, possibly redacted snapshot of a particular domain/component or view.
That is exactly the kind of report that produces a truthful local number or graph without justifying any “whole system authority graph” conclusion.
That is both **eligibility basis** and **whole-world fence** pressure.

### 6) Companions reinforce the same caution
Harbor, Ward, Steward, ViewFS, Helm, and Schell all carry profile-scoped, audience-scoped, or family-local summaries that are useful precisely because they are bounded.
Together they say the same thing: neighboring archives want scoped counts and scores, but they do not justify a universal whole-world denominator story.

## SlopOS-side recommendation
If a future SlopOS-adjacent cube needs scope-sensitive metrics or report rows, Foundry should let the row say:
- **why this subject/event/window was eligible,**
- **what kind of exclusion narrowed the visible world,**
- and **where that result must not be mistaken for archive-wide truth.**

That is enough to keep design-phase profile differences, non-claims, family-local summaries, and scope-bound observational exports honest without freezing a giant population engine into the cube.
