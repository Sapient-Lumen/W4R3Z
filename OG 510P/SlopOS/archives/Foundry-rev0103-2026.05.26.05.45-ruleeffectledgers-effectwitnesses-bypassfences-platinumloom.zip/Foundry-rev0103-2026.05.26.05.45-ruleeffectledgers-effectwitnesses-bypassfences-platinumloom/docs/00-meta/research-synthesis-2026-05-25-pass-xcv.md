# Research synthesis — 2026-05-25 pass XCV

Focus: **fulfillment receipts, completion witnesses, and nonfulfillment fences**.

The previous pass made semantic obligations travel with exposed surfaces. This pass closes the next gap: an audience can acknowledge an obligation and still never fulfill it, fulfill it late, fulfill it only for a different surface, or confuse "we promised to carry the residue" with "the residue was actually carried."

## New outside pressure

- `EXT-K8S-FINALIZERS` gives Foundry a cleanup scar: a finalizer delays resource deletion until specific cleanup conditions are satisfied. Foundry should steal the idea of a blocking completion hook, while refusing to become a Kubernetes controller, deletion workflow, or cleanup scheduler.
- `EXT-W3C-PROV-DM-2013` gives Foundry a provenance scar: entities, activities, agents, usage, and generation can record that an action actually occurred. Foundry should steal activity evidence and agent/surface linkage, while refusing to make provenance equal truth, quality, compliance, or audit opinion.
- `EXT-OASIS-XACML-3-0` and the prior obligation pass together pressure Foundry to keep obligations distinct from their discharge. A response can carry obligations, but a later enforcement point must do or refuse them. Foundry should steal that gap and make it fixture-visible without deciding authorization.
- `EXT-W3C-ODRL-2-2` continues to pressure Foundry to separate a duty from whether the duty was performed. Foundry should preserve the residue of performance, nonperformance, and deadline expiry, not build a rights-management system.

## What rev0094 still allowed

Rev0094 can say that a SlopOS dashboard, audit CSV, Ward preview, ViewFS projection, worker cache, shadow export, or public link acknowledged semantic obligations. It still leaves dangerous fulfillment gaps:

- an external-audit notebook acknowledges sidecar preservation, but the exported CSV checksum no longer matches the sidecar digest;
- a dashboard cache acknowledges observation-status display, but the rendered tile hides the status badge;
- a recall-route obligation is acknowledged, but no recall-contact probe or route registration evidence exists;
- a no-reexport obligation is acknowledged, but a notebook fork or shadow export appears without a new exposure ledger;
- a delegated worker acknowledges recheck-before-execute, but the recheck time is after execution;
- a ViewFS inherited group acknowledges quarantine, but the projection remains reachable as if admitted; or
- a Ward preview acknowledges the "not Ward verdict" boundary, but downstream use treats the preview as appraised.

Those are not merely acknowledgment failures. They are **fulfillment failures**.

## Speculative read

Foundry needs a tiny **fulfillment accounting seam** after obligation accounting:

```text
fulfillment receipt       = scoped closure record for acknowledged obligations, due windows, required completion evidence, and unresolved fences
completion witness        = consumer/surface-local evidence that a specific obligation was actually fulfilled, partially fulfilled, pending, missed, refused, or quarantined
nonfulfillment fence      = refusal card for missing, late, mismatched, partial, wrong-scope, digest-mismatched, or authority-laundered fulfillment
```

The seam should stay smaller than workflow, scheduling, cleanup controllers, legal compliance, audit, authorization, rights management, incident response, deletion, retention, custody, or sibling-cube verdicts. Foundry's job is not to make consumers behave. Its job is to prevent a dangerous sentence: "the consumer acknowledged the obligation, therefore the obligation was fulfilled."

## New specimen pressure

Add specimen 89 around fulfillment receipts, completion witnesses, and nonfulfillment fences. The fixture must prove at least:

- every fulfillment receipt names source obligation ledgers, acknowledgment witnesses, carrier ids, scope, obligations-to-fulfill, due windows, required completion witnesses, required fences, and authority boundaries;
- every obligation-to-fulfill names source obligation id, fulfillment type, due time, required evidence, applies-to scope, blocked inferences, and current status;
- every required completion witness is consumer/surface/audience-local, digest-linked when a carrier is named, and scoped to a source acknowledgment;
- completed witnesses cannot satisfy another consumer, audience, surface, purpose, carrier, or due window;
- partial, pending, missed, refused, quarantined, overdue, wrong-scope, public-link, inherited, or digest-mismatched completion needs a nonfulfillment fence;
- complete receipts cannot leave required obligations unfulfilled or only acknowledged;
- nonfulfillment fences must name missing evidence, required clearance, blocked uses, replay timing, and non-promises; and
- negative cases cover fulfillment receipt missing, source obligation missing, completion witness missing, acknowledged-as-fulfilled, deadline expiry, sidecar not carried, classification pin not verified, recall route untested, no-reexport unenforced, recheck missing before reuse, quarantine not applied, sibling boundary not enforced, completion scope mismatch, wrong consumer, partial-as-complete, digest mismatch, public-link fulfillment without fence, inherited fulfillment without rebinding, fulfillment-as-authorization, fulfillment-as-legal-compliance, fulfillment-as-audit-opinion, and sibling-verdict laundering.

## Recommendation

Keep fulfillment accounting fixture-local. Do not promote a workflow engine. The narrow Foundry move is to make semantic-duty discharge falsifiable: an obligation may be acknowledged, but reuse stays unsafe until completion evidence is attached or nonfulfillment is fenced.
