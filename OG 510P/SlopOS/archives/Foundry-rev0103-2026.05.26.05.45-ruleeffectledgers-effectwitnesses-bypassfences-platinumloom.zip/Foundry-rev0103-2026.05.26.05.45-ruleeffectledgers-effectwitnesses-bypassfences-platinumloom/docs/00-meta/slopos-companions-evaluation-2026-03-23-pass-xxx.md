# SlopOS plus companions evaluation — pass XXX

This pass tested whether Foundry needs a small meaning seam for *captured cuts that are weaker than they look*.
The answer is yes, but only narrowly.

## What SlopOS already contributes
The uploaded SlopOS archive already contains the mechanism instincts.
RFC-0037 frames cooperative checkpointing as explicit orchestration rather than hidden magic.
RFC-0108 says checkpoint capture needs a consistent cut.
The configuration pipeline also says breaking migrations should be snapshot-gated and recorded.
That is already the right control-plane direction.

## What Foundry should own instead
Foundry should own the semantic split that keeps three facts separate:
1. a cut was captured at all;
2. the cut crossed some stronger **write fence** or did not;
3. restore may still carry **recovery debt** before the result counts as comfortably resumed.

That seam is smaller than a checkpoint substrate and smaller than a persistence subsystem.
It is just enough vocabulary to stop later documents from flattening every snapshot into one flattering “safe restore point” story.

## Companion-cube fit
- **ViewFS** already keeps snapshot, package, and lineage truth honest; that supports a smaller Foundry claim that a captured cut may still vary in semantic strength.
- **Ward** keeps evidence smaller than verdict; likewise, a captured image is smaller than “restored cleanly and semantically complete”.
- **Harbor** keeps foreign crossings honest; that matters when a restored cut still needs outside rebind, replay, or service repair.
- **Steward** already carries operational maintenance and quiesce pressure more naturally than Foundry should.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small but load-bearing distinction between:
- **consistency class** — what kind of cut was truly captured,
- **write fence** — what stronger pause/freeze/flush boundary was crossed,
- **recovery debt** — what replay or repair still remains after restore.

If Foundry misses that seam now, later revisions will be tempted to let “snapshot,” “checkpoint,” “backup,” and “restore point” collapse into one cozy noun that quietly hides replay, crash recovery, and application-level repair obligations.
