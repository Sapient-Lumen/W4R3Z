# Research synthesis — pass LXIV

This pass stays conservative.
Foundry still should **not** turn every consumer preference, product posture, or export convention into base datacube law.
But it can steal one more durable lesson from profile- and dialect-shaped ecosystems: **a profile can add constraints, conventions, or extensions for one consumer without changing the base meaning family itself — as long as profile identity, precedence, and refusal boundaries stay explicit.**

The smallest durable seam from this pass is:
- **profile card** — the compact identifier for one applied profile, convention bundle, or overlay that shaped how a consumer/export path interpreted the row without claiming to redefine the base family;
- **precedence lane** — the compact statement of how multiple profiles are ordered, whether one wins, or whether conflict forces refusal;
- **overlay fence** — the explicit rule that a profile may add constraints, conventions, or display/export behavior, but must not silently rewrite the base subject/measure/unit/schema truth.

These are still smaller than a universal profile registry, an automatic negotiation protocol, or one global “effective profile” engine.
They simply let design-phase semantics stay layered without pretending the layer is the base.

## Lessons we must learn from the past

### 1) Profiles are healthiest when they add semantics without changing the underlying representation
RFC 6906 is the cleanest statement of the idea.
A profile lets a representation indicate additional semantics such as constraints, conventions, or extensions, but the profile is **not** supposed to alter the semantics of the representation itself.
That is exactly the humility Foundry needs: a profile card should travel beside the row, not impersonate the row’s base meaning.

### 2) Multiple profiles need explicit precedence or explicit refusal
ALPS is useful not because Foundry needs ALPS itself, but because it shows three healthy habits:
- one representation can be described by more than one profile,
- precedence among those profiles should be explicit,
- and the profile parameter can help negotiation without making profile knowledge mandatory for safe basic use.
That pushes Foundry toward a precedence lane instead of hidden consumer-local folklore such as “the UI profile usually wins” or “the later profile probably overrides the earlier one.”

### 3) Dialects can require a base vocabulary while still allowing optional or arbitrary overlays
OpenAPI 3.2.0 is a good reminder that a schema dialect can require a base vocabulary and still allow additional vocabularies or arbitrary properties.
It also defers some annotation semantics to the consuming application.
That is a strong cue for Foundry: base cube semantics can stay tight while profile cards remain optional overlays interpreted by specific consumers.

### 4) Stable-by-default plus opt-in unstable overlays is healthier than implicit activation
OpenTelemetry semantic-convention guidance says stable instrumentations must not emit unstable conventions by default, though they may support them via explicit opt-in.
That is precisely the posture Foundry should borrow.
A consumer/export profile can exist, and even be useful, without becoming the ambient default interpretation for every other consumer.

### 5) A profile is not a smuggling route for semantic mutation
Once a profile changes the base subject, measure, unit, aggregation, or schema meaning, it is no longer just a profile-shaped overlay.
At that point Foundry should require a new schema pin, translation witness, or explicit view lens instead of profile folklore.
That is the overlay fence.

## What to steal now
- a **profile card** that names the applied overlay by digest, URI, or stable local identifier;
- a **precedence lane** that says whether zero, one, or several profiles shaped interpretation and which ordering rules were in force;
- an **overlay fence** that blocks profiles from silently redefining base schema/measure/subject truth;
- a habit of letting profiles stay **consumer-local or export-local** until repeated pressure proves they belong in common law;
- and a rule that **opt-in overlays** are healthier than hidden ambient defaults.

## What to keep parked
Do not yet promote:
- one cube-wide profile registry with mandatory approval for every local profile;
- automatic multi-profile negotiation among all readers/exporters;
- a promise that every profile is dereferenceable forever or understood by every consumer;
- or a claim that profile stacking automatically yields a single lawful merged meaning.

## Resulting recommendation
The next healthy move is not “teach the cube every profile that SlopOS mentions.”
It is to let Foundry say, for any evolving consumer/export convention:
1. which **profile card** was applied,
2. which **precedence lane** decided order or refusal,
3. and where an **overlay fence** blocked a profile from masquerading as base semantic truth.

That keeps the cube aligned with SlopOS’s design-phase reality while still stealing smart discipline from RFC 6906, ALPS, OpenAPI, and OpenTelemetry.
