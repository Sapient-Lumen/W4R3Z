# SlopOS + companions evaluation — pass LXXIII

This pass checks whether **band class, threshold basis, and scalarization fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal severity ontology, one permanent threshold registry, or a doctrine that every visible tier/bucket/badge is safely comparable as a scalar.

## Why SlopOS pressures this seam now

### 1) Imported vulnerability priority signals already create band pressure
`docs/30-architecture/vex-priority-signal-boundary-v0.md` explicitly keeps imported CVSS / EPSS / KEV / vendor-severity style signals as evidence rather than native install/boot authority.
That means a future cube row like “urgency = high” or “priority percentile = 92” would often be a **banded or thresholded interpretation** of imported evidence, not base SlopOS truth.
That is direct **band class** and **threshold basis** pressure.

### 2) Profile posture matrices already carry qualitative tiers
`docs/00-meta/profile-posture-matrix.md` is full of profile-shaped posture cells that are useful precisely because they are a reviewed qualitative layer rather than one universal scalar.
A future dashboard could easily overread those cells as arithmetic grades or cross-profile totals unless the cube preserves **band class** and a **scalarization fence**.

### 3) Locality and topology hints already show threshold-shaped danger
`docs/30-architecture/memory-locality-authority-boundary-v0.md` keeps richer NUMA distance / HMAT latency-bandwidth / memory-tier facts as placement hints rather than authority semantics.
That is exactly the kind of surface where future buckets like “near”, “far”, or “gold tier memory” could become helpful while still being smaller than exact topology truth.
That is **threshold basis** pressure plus a need for a **scalarization fence**.

### 4) Existing verification summaries are category-heavy
`docs/40-verification/worker-pool-verdict-summary-v0.md` preserves compact verdict categories and case-indexed result posture rather than pretending the family emits one universal numeric health score.
That means a visible badge like `pass`, `warn`, or `fail` may be useful without supporting arithmetic or cross-family scalar comparison.
That is direct **band class** pressure.

### 5) Bucketed authorship and qualitative boundary taxonomies already exist
`docs/30-architecture/confidential-computing-boundary-index.md` buckets provider-native SNP fields by authorship class.
That is not a histogram, but it is still a reminder that bucketed taxonomies are often useful because they preserve kind distinctions, not because they collapse into one numeric ladder.

### 6) Companions reinforce the same caution
Harbor, Ward, Steward, ViewFS, Helm, and Schell all carry tier-like, audience-like, or family-local posture buckets that are useful precisely because they are bounded, policy-shaped, or display-shaped.
Together they say the same thing: neighboring archives want helpful bands and tiers, but they do not justify one archive-wide scalar doctrine.

## SlopOS-side recommendation
If a future SlopOS-adjacent cube needs banded or bucketed values, Foundry should let the row say:
- **what kind of band this is,**
- **which thresholds or rubric produced it,**
- and **where later readers must stop before treating it like a reusable scalar.**

That is enough to keep design-phase severity signals, qualitative posture matrices, locality hints, and verdict badges honest without freezing a giant risk-score or threshold-management subsystem into the cube.
