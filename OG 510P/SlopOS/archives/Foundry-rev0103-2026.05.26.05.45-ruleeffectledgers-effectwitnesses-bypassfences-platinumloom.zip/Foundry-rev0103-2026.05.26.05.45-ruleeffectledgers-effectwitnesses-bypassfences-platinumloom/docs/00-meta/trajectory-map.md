# Trajectory map

## Current thesis

Foundry should begin as a **small, high-signal companion cube** whose main job is to metabolize a missing class of cross-pressure before it can leak confusion into the rest of the ecology.

## Non-negotiables
1. Foundry owns a distinct pressure class and should not merely duplicate a sibling cube.
2. The cube may converse with sibling companions, but its public text stays clean of the sealed primary.
3. Early documents should freeze separations and non-decisions, not pretend a giant implementation stack already exists.
4. Outside examples are teachers, not templates.

## Immediate direction
- tighten the object model,
- keep the strongest distinctions visible,
- export compact artifacts that neighboring cubes could plausibly consume later,
- and grow only the subfamilies that survive repeated pressure.

## rev0083 trajectory adjustment

Foundry now treats **projection honesty** as sibling to off-native realization. A fact can remain semantically wrong after it leaves the cube even if the underlying runtime/story was honest. The immediate direction is therefore to make egress residue executable: tables, charts, JSON, CSV, markdown, support cards, and dashboard tiles must preserve meaning, point to meaning, or refuse flattening.

## rev0090 trajectory adjustment

Foundry now treats **replacement honesty** as the sequel to projection honesty. A recalled carrier can be followed by a newer carrier without being repaired for every consumer. The immediate direction is therefore to keep post-recall repair evidence small, explicit, and consumer-local: replacement witnesses show what changed; readmission gates show who may use it; old recalled history remains visible.

## rev0093 trajectory adjustment

Foundry now treats **exposure honesty** as the sequel to surface inventory. A semantic carrier can be correctly found and still be unsafe for a reader, purpose, access mode, inherited group, or public link. The immediate direction is therefore to keep audience/purpose evidence small and local: ledgers record scope, witnesses record observed exposure, and fences block unsafe widening without becoming authorization, consent, deletion, public release, or sibling verdicts.
