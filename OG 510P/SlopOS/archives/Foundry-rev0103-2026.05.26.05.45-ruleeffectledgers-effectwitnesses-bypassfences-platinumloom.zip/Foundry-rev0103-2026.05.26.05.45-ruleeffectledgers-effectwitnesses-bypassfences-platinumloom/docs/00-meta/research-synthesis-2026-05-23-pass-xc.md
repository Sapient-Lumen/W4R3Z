# Research synthesis — 2026-05-23 pass XC

Focus: **remediation packets, replacement witnesses, and readmission gates**.

The previous pass made carrier invalidation and recall explicit. This pass covers the next scar: after a revocation, a newer carrier can be mistaken for a fixed carrier. Foundry needs a tiny way to say what replacement was proposed, which semantic loss it repaired, which replay gates passed, which consumer may use it, and which overclaims remain refused.

## New outside pressure

- `EXT-IN-TOTO-ATTESTATION-2026` gives a useful subject/predicate instinct: a statement binds metadata to a particular subject and uses a predicate type to say how to interpret it. Foundry should steal that binding discipline for replacement witnesses without becoming a signed attestation framework.
- `EXT-SLSA-PROVENANCE-1-0` treats provenance as an attestation that a build platform produced artifacts through a build definition. Foundry should steal the produced-by / materials / builder separation without turning semantic-carrier readmission into software-supply-chain trust.
- `EXT-CSAF-2-0` structures security-advisory updates around product, vulnerability, status, and remediation information. Foundry should steal the subject/action/status humility without becoming a vulnerability advisory, PSIRT, or remediation governance system.
- Existing revocation/recall pressure still applies: `EXT-RFC7009-OAUTH-REVOCATION`, `EXT-RFC6960-OCSP`, `EXT-W3C-VC-BITSTRING-STATUS-2025`, `EXT-TUF-SPEC-2026`, and HTTP cache freshness examples all warn that old valid bytes can become unsafe after later status changes.

## What rev0089 still allowed

Rev0089 could say "this carrier is no longer safe" and prove affected consumers either acknowledged recall or were stale-fenced. It did not yet prove that a replacement carrier should be trusted for any consumer. A future editor could still:

- issue `sidecar_002` and treat the new id as repair;
- adopt a replacement that fixes classification pins but drops disclosure or waiver residue;
- release a dashboard cache because it refreshed, without a consumer-local readmission gate;
- claim Harbor remediation or Helm repair completion when Foundry only repaired a semantic carrier;
- admit an audit notebook replacement and silently reuse it for Ward, public export, or ViewFS projection;
- overwrite old recalled receipts and source rows instead of preserving historical evidence; or
- miss a later notice that should reopen a previously accepted replacement.

Those are readmission failures, not ordinary recall failures.

## Speculative read

Foundry needs a small **post-recall seam** beside stale-reliance fences:

```text
remediation packet   = the recalled carrier, notice scope, quarantine, candidates, required witnesses, and required gates
replacement witness  = old digest, new digest, correction class, replay evidence, residual risks, and non-promises
readmission gate     = consumer-local admitted/refused use after replay
source truth          = still outside Foundry
repair completion     = still outside Foundry
```

The negative move matters most: a replacement artifact is not readmission. Readmission is a scoped result of replayed gates.

## New specimen pressure

Add specimen 84 around remediation packets, replacement witnesses, and readmission gates. The fixture must prove at least:

- every replacement attempt links to the revocation notice, old carrier, affected consumers, quarantined artifacts, and required gates;
- every replacement witness names old and replacement artifact families, ids, digests, correction classes, evidence refs, replayed gates, history-preservation posture, residual risks, and non-promises;
- every readmission gate is consumer-local and names admitted uses, blocked uses, required inputs, replayed rules, and quarantine release;
- partial replacement remains partial and can stay blocked for some consumers while admitted for others;
- rejected replacement candidates leave machine-readable refusal evidence;
- later notices can reopen an accepted remediation packet; and
- negative cases cover digest mismatch, missing witness, missing gate, old-history rewrite, consumer-scope widening, and authority laundering.

## Recommendation

Keep remediation packets fixture-local and reversible. Do not promote a repair workflow, remediation registry, attestation system, status page, approval process, or sibling-cube verdict model. The narrow Foundry job is to prove that a recalled semantic carrier is re-admitted only for a named consumer/use after a replacement witness and replayed gates make the old semantic loss visible as repaired or still refused.
