# Research synthesis — pass LXXI

This pass stays conservative.
Foundry still should **not** freeze one archive-wide null algebra, one universal fill-default rule, or one permanent “empty means none” ontology.
But it can steal one more durable lesson from healthcare semantics, patch formats, and serialization discipline: **a design-phase datacube needs to distinguish why a value is blank, whether the value ever properly applied in this context, and where later readers must not coerce the blank into `0`, `false`, empty string, deletion, or “not applicable”.**

The smallest durable seam from this pass is:
- **blank class** — the compact statement of why a visible value is blank or non-valued: unknown, asked-unknown, temporarily unavailable, not asked, masked, not applicable, unsupported, delete sentinel, implicit-default-absent, or another reviewed class;
- **applicability basis** — the compact statement of whether the value ever properly applies here: subject-not-applicable, workflow-not-run, export-redacted, source-unsupported, provider-optional, merge-patch instruction, or another reviewed basis;
- **coercion fence** — the compact statement of what later consumers must not assume: unspecified-not-zero, not-false, not-empty-string, not-delete-equivalent, not-groupable-as-none, or forbidden.

These are still smaller than a giant missingness product, one archive-wide null vocabulary, or a promise that every export path can auto-fill safely.
They simply stop useful blanks from laundering themselves into flattering truth.

## Lessons we must learn from the past

### 1) “No value” is not one thing
HL7 v3 NullFlavor does not stop at one generic null.
It distinguishes not applicable, unknown, asked but unknown, temporarily unavailable, not asked, not available, and even “trace”.
That is a direct warning against one generic datacube `null`.
A future cube should preserve **blank class** instead of flattening all blank cells into one absence story.

### 2) Workflow and policy can both explain absence
FHIR’s Data Absent Reason codes go even further and distinguish unknown, asked-but-unknown, temporarily unknown, not asked, asked-but-declined, masked, not applicable, unsupported, error, and not performed.
That is exactly the discipline Foundry should steal.
A blank can come from workflow, support limits, privacy posture, or true non-applicability.
That is direct **applicability basis** pressure.

### 3) Null can be an instruction, not a missing observation
RFC 7396 JSON Merge Patch gives `null` a special meaning: remove the member from the target.
That means one visible `null` can be an operation rather than a statement about the subject.
Foundry therefore needs a **coercion fence** whenever blank-looking values can arrive from patch/update lanes.

### 4) Serialization defaults can erase presence
Protocol Buffers distinguishes implicit and explicit presence and recommends `optional` for proto3 basic types.
Under implicit presence, a missing scalar field collapses to a type default at read time.
That means absent can look like `false`, `0`, or empty string even when the sender never meant that.
Foundry should preserve **blank class** and **coercion fence** instead of trusting deserialized defaults.

### 5) “Not applicable” is healthier than fake zero
Both HL7 NullFlavor and FHIR Data Absent Reason keep non-applicability distinct from unknown and masked.
That is exactly the restraint a design-phase cube needs.
Rows that never properly had a value should not be counted as failures, zeros, or empty strings just because a UI likes rectangular tables.

### 6) Masked and declined are still different from unknown
FHIR keeps “masked” and “asked but declined” distinct from ordinary unknowns.
That is a strong model for SlopOS-adjacent exports too.
Security-controlled omission is not the same thing as ignorance, and the cube should not group them together unless a reviewed view says so.

### 7) Default-valued fields can hide semantic loss
The proto3 guide explicitly warns that for implicit-presence scalar fields there is no way to tell whether a field was explicitly set to the default or just not set at all.
That is a brutal reminder for future cube exports.
A future cube should not casually ingest default-looking booleans or numerics and assume they were asserted.

## What to steal now
- a **blank class** field or adjunct that distinguishes unknown, masked, not applicable, unsupported, delete-sentinel, and default-implicit-absent cases;
- an **applicability basis** that says whether the value ever properly applied here and why it may be absent;
- a **coercion fence** that blocks later readers from turning blanks into `0`, `false`, empty string, deletion, or grouped “none” without review;
- and a habit of keeping the original reason-coded blank visible even when a rectangular export would prefer one generic null.

## What to keep parked
Do not yet promote:
- one archive-wide null ontology;
- one global fill-default engine;
- one guarantee that all serializers preserve absence faithfully;
- or a promise that every blank can be compared, counted, or imputed the same way.

## Resulting recommendation
The next healthy move is not “teach Foundry missing data.”
It is to let Foundry say, for blank-sensitive families:
1. **what kind of blank this is,**
2. **why the value is absent or inapplicable here,**
3. and **where later consumers must not coerce it into something tidier.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart restraint from healthcare semantics, patch formats, and presence-aware serialization.
