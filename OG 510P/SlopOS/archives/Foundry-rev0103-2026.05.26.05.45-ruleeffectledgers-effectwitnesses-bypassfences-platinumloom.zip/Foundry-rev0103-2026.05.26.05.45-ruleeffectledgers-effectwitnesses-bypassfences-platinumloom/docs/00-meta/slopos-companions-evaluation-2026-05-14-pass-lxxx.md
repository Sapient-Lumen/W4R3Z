# SlopOS + companions evaluation — pass LXXX

This pass evaluates Foundry's next SlopOS-facing datacube seam: observedness, adjustment, imputation, and revised-value honesty.

## Verdict

Promote one narrow seam: **observation-status card**, **adjustment witness**, and **as-observed fence**.

This is a conservative promotion because it does not choose a status vocabulary, imputation algorithm, quality framework, seasonal-adjustment engine, forecasting model, or revision warehouse. It only requires a value to say when it is not simply an as-observed value at the named cut.

## SlopOS pressure

SlopOS already contains multiple sources of adjustment-like or status-like pressure:

- `CH-OBS` can export metrics, logs, trace summaries, boot summaries, and capability snapshots, which are not all the same kind of observation.
- `CH-OBSPOL` makes redaction/bounds explicit, so Foundry should likewise make adjusted/imputed/provisional posture explicit rather than hiding it in the value.
- `CH-SNAPSHOT` support bundles collect incident/support evidence under a redaction profile and optional session/boot binding; support summaries derived from these bundles should not impersonate raw event truth.
- Quarantined-derived-attribute boundaries already refuse semantic back-write onto risky source objects; Foundry should preserve the same parent-vs-derived humility for diagnostic values.
- MCP logging imports are provider-local diagnostic signals, not durable transcript/export truth; a Foundry metric derived from them needs status residue.
- FedCM/Digital Credentials boundaries showed the same pattern at identity time: mediation/presentation surfaces are useful, but they are not global account/wallet/source truth.
- SlopOS is still design-phase; early diagnostics and support tiles will likely be revised, reclassified, or replaced as schemas settle.

The seam therefore belongs in Foundry, but only as value-level residue.

## Companion pressure

- **Steward** is the strongest companion pressure: provisional terminal/shell state may confirm, refine, revise, or withdraw, and bootstrap reconciliation separates wake cause from present-tense condition truth. Foundry should import the lesson, not Steward's lifecycle vocabulary: adjusted/provisional values need visible status and later correction lanes.
- **ViewFS** keeps source identity, derived artifacts, package lineage, and visible list badges separate. Foundry should not let an adjusted diagnostic value become the source object's attribute truth.
- **Harbor** has temporal witnesses, contract subsets, and lineage guards. Foundry should borrow the contract-subset/vintage-cut instinct without becoming a Harbor crossing or credential surface.
- **Ward** evaluates claims and evidence. Foundry should not turn an adjustment witness or quality flag into a Ward verdict.
- **Helm** and **Schell** are likely to render user-facing cards, chips, and support summaries. Those renderers need a simple rule: if the value is adjusted/imputed/provisional, do not present it as raw observation without a visible fence.

## Lessons carried forward

1. A numeric value can be exact but imputed.
2. A value can be replayable but adjusted.
3. A value can be provisional but not blank.
4. A value can be revised without making the older vintage a lie.
5. A diagnostic processor output can be useful without being a native observation.
6. Status flags must travel through materialization, cache, export, and chart layers.
7. SlopOS support summaries need observedness honesty before product dashboards harden.

## Recommendation

Add specimen 74 and update ledgers/source hygiene accordingly. Keep the nouns local to value families where observed/imputed/adjusted/revised/provisional posture changes interpretation. Do not widen the seam into a global quality ontology or statistical pipeline language.

## Follow-up pressure to keep open

- Test one SlopOS `CH-OBS` metric that is directly emitted and one trace-processor summary that is derived.
- Test one `CH-SNAPSHOT` support bundle where a missing entry produces an imputed support count.
- Test one Steward provisional value that later confirms or withdraws.
- Test one ViewFS-style derived artifact whose value must not back-write onto the source object.
- Test one materialized/cache export where the status card must survive serving and charting.
