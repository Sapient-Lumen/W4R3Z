# SlopOS and companions evaluation — 2026-05-23 pass XCI

Focus: whether Foundry can account for post-readmission distribution and stale stragglers without claiming delivery success, cache policy, release approval, audit opinion, or sibling authority.

## SlopOS pressure

SlopOS support surfaces may re-admit a repaired sidecar, support-card table, or dashboard projection after a recall. Rev0090 can say the replacement is safe for one consumer/use. Rev0091 adds the missing next step: the replacement must be accounted for as it circulates to every relying consumer and surface, and old copies must be retired, quarantined, or fenced.

A SlopOS operator can provide the replacement carrier and readmission evidence. Foundry can record that a support bundle distributed it to external audit and dashboard cache, that Ward only partially adopted its preview, that ViewFS quarantined a projection, and that a delegated worker refused adoption after a warrant failure. Foundry still does not assert SlopOS proof, operator truth, cache invalidation, release approval, or sibling verdict.

## Companion boundaries

| Companion | Distribution/adoption interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may issue replacement carriers and name support surfaces that should receive them | SlopOS still owns source evidence, proof claims, and operator semantics |
| Harbor | may record external status or remediation impact after adoption evidence exists | Harbor still owns external status, public-safe impact, and remediation verification |
| Ward | may receive partial or complete adoption receipts as appraisal inputs | Ward still owns appraisal and trust verdicts |
| Steward | may observe delivery/retry/replay attempts around distribution | Steward still owns effect lifecycle, pushback, retry budgets, and finality |
| Schell | may constrain how old copies are retained, minimized, or deleted | Schell still owns forgetting, retention, and minimization authority |
| ViewFS | may display adopted, quarantined, or historical projections | ViewFS still owns object identity, trusted paths, consent, and projection custody |
| Helm | may carry repair/intervention traces for stale-copy cleanup | Helm still owns repair custody, intervention consequence, and handback |
| External audit notebook | may adopt a carrier for one review extract | adoption is not audit opinion or certification |
| Dashboard cache | may adopt a carrier for one tile while old CSVs remain fenced | cache refresh is not semantic repair or cache-control proof |
| Delegated worker lane | may refuse adoption when delegation authority is missing | refusal is not a new warrant or permission |

## What changed in this pass

- Added specimen 85 for distribution manifests, adoption receipts, and orphan-copy fences.
- Added a distribution/adoption rulebook so post-readmission circulation has named failure modes.
- Added v0 schemas for distribution manifests, adoption receipts, and orphan-copy fences.
- Added a specimen 85 fixture with completed, partial, and blocked distribution; adopted, partial, quarantined, and refused receipts; and blocked/quarantined/retired orphan-copy fences.
- Added `check_foundry_distribution_adoption.py` and wired it into `make check`.
- Reused CloudEvents envelope pressure, RFC 9111 cache/staleness separation, OCI subject/referrer graph pressure, and SCITT/Certificate Transparency visibility-without-accuracy caution while keeping Foundry smaller than eventing, cache, registry, transparency, approval, audit, or deployment systems.

## Recommendation

Future Foundry revisions should treat "readmitted" as weaker than "adopted by this consumer/surface." A replacement carrier needs a distribution manifest, per-target adoption/refusal/quarantine receipts, and orphan-copy fences before old copies can stop being stale reliance hazards.
