# SlopOS and companions evaluation — 2026-05-25 pass XCVI

Focus: whether Foundry can verify completion evidence without claiming audit opinion, certification, cryptographic proof, authorization, compliance, custody, repair completion, lifecycle finality, or sibling authority.

## SlopOS pressure

SlopOS support surfaces now carry sidecars, egress/refusal receipts, regression locks, waivers, consumer/delegation/revocation/readmission/distribution/inventory/exposure/obligation/fulfillment residue. Rev0096 asks whether the completion evidence behind those residues survives sampling.

A SlopOS dashboard may have a completion witness saying the observation-status badge displayed. Foundry now needs an evidence sample that probes the rendered tile. A support-card CSV may have a completion witness saying the sidecar survived; Foundry now needs a digest recomputation sample. A public-link scan may have a completion witness saying no-reexport was refused; Foundry now needs a public probe that can contradict a shadow export. A delegated worker may claim recheck-before-execute; Foundry now needs a time-ordered evidence sample rather than a self-authored closure claim.

## Companion boundaries

| Companion | Verification-audit interaction | Boundary Foundry must preserve |
| --- | --- | --- |
| SlopOS | may supply support-card probes, render snapshots, and operator-console samples | verification samples are not SlopOS proof claims or operator policy |
| Harbor | may receive false-closure fences for public links, recall routes, and outside-status contradictions | Harbor still owns membrane truth, correction, and remediation authority |
| Ward | may consume samples that preserve or fence "not Ward verdict" language | Ward still owns appraisal and trust verdicts |
| Steward | may consume recheck-before-execute contradiction samples | Steward still owns lifecycle finality and retry consequence |
| Schell | may constrain retained sample evidence and replay windows | Schell still owns minimization, forgetting, and privacy authority |
| ViewFS | may supply projection/quarantine samples and inherited-access freshness probes | ViewFS still owns object identity, consent fences, and custody |
| Helm | may use false-closure fences as repair inputs | Helm still owns repair custody and completion consequence |
| External audit notebook | may receive evidence samples and false-closure fences | Foundry still does not issue audit opinion or certification |
| Dashboard cache | may expose render probes and digest checks | verification is not cache policy or release approval |
| Delegated worker | may expose self-verification conflict and timing samples | verification is not execution permission or Steward finality |
| Public-link scanner | may contradict no-reexport or recall-route completion | public reachability is not public release, consent, or legal compliance |

## What changed in this pass

- Added specimen 90 for verification audits, evidence samples, and false-closure fences.
- Added a verification audit rulebook with named refusal modes for missing audits, missing source fulfillment, missing samples, completion-as-verification, self-verification, verifier conflict, scope mismatch, stale samples, ignored contradictions, partial-as-passed, digest mismatch, public/inherited samples without fences, and authority laundering.
- Added v0 schemas for verification audits, evidence samples, and false-closure fences.
- Added a specimen 90 fixture with passed, partial, and blocked audits; verified, contradicted, inconclusive, stale, unavailable, and quarantined samples; and false-closure fences for Ward wording ambiguity, ViewFS inherited freshness, worker recheck timing, public no-reexport contradiction, public recall-route absence, and verifier conflict.
- Refactored the checker harness through `tools/foundry_checklib.py` and rewrote `tools/check_foundry_all.py` to use the shared runner while keeping focused checkers independently runnable.
- Added `docs/30-architecture/checker-harness-audit-refactor-v0.md` so the audit/refactor has a durable surface.
- Added `tools/check_foundry_verification_audit.py` and wired it into `make check`.

## Recommendation

Future Foundry revisions should treat completion evidence as input to verification, not as verified closure. A sampled pass must remain scope-bound and non-exhaustive; a contradiction, stale sample, self-verification, public link, inherited access, or missing required sample must produce a false-closure fence before reuse.
