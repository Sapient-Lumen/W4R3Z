# SlopOS and companion-cube evaluation — 2026-03-23 pass VII

## What SlopOS keeps teaching Foundry
- `confidential-computing-boundary-index.md` and related claim boundaries validate the idea that foreign-ground evidence is structured material, not a single aura of trust.
- `microvm-attestation-reacquire-posture-v0.md` and `microvm-generation-witness-posture-v0.md` keep reinforcing restore humility and explicit generation change.
- `host-guest-channel-posture-v0.md` and component/manifest surfaces still argue for explicit channel and contract nouns.
- `foreign-cell-contract.md` continues to justify Foundry as a dedicated outer cube: foreign realization is a first-class meaning problem.

## What the siblings sharpened this pass
- **Harbor** keeps membrane crossings honest on the way in and out.
- **Ward** keeps attestation evidence and release decisions visibly separate.
- **ViewFS** keeps package, live realization, and durable reference distinct.
- **Schell** keeps adoption gates visible for helpers and sidecars.
- **Helm** keeps foreignness product-visible instead of hidden as implementation folklore.

## Pass-VII result
Foundry still should not promote a universal runtime or substrate object.

The sharper move is:
- add one specimen around policy-split attested foreign adoption;
- keep capability routing, admission policy, resource-release policy, and adoption visibly different;
- and let init-data integrity, generation change, and reacquire remain explicit rather than folded into “the runtime is fine”.
