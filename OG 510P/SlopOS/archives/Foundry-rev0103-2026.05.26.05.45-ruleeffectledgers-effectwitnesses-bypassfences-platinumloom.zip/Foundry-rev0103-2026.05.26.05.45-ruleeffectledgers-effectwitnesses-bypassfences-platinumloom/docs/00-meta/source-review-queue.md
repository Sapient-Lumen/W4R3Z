# Source review queue

Foundry is still in design phase.
This queue exists so moving or living sources do not silently harden into permanent cube truth.

## Review cadence
- re-check queued sources before promoting a candidate noun into stable vocabulary;
- re-check queued sources before promising long-lived compatibility for an export or status surface;
- if a queued source changed materially, update research synthesis, lessons, and the relevant specimen in the same revision.

## Current queue
- `EXT-GITLAB-ARCHITECTURE-DECISIONS-2026` — re-check before adding any heavier process gate than the current lightweight hygiene surfaces.
- `EXT-W3C-DESIGN-PRINCIPLES-2026` — re-check before creating a registry, extension-point family, or negotiation surface.
- `EXT-ALPS-PROFILE-2026` — re-check before promising multiple-profile precedence, negotiation, or override defaults.
- `EXT-OTEL-SEMCONV-GROUPS-2026` — re-check before making any overlay/profile semantics stable-by-default instead of opt-in.
- `EXT-OTEL-SCHEMAS-2026` — re-check before promoting any revision-hook or transform contract into durable export truth.
- `EXT-OTEL-SEMCONV-2026` — re-check before calling any new Foundry noun “stable” by default.
- `EXT-OTEL-VERSIONING-STABILITY-2026` — re-check before promising deprecation/removal posture or compatibility guarantees.
- `EXT-OTEL-SCHEMA-FILE-FORMAT-2026` — re-check before promoting any transform-carrier, translation-witness, or upgrade-fence contract into durable export truth.
- `EXT-OTEL-SEMCONV-NAMING-2026` — re-check before assuming renamed or deprecated fields remain silently forward-comparable.
- `EXT-PROTOBUF-BEST-PRACTICES-2026` — re-check before freezing enum/posture values or conflating storage with export shape.
- `EXT-PROTOBUF-PROTOJSON-2026` — re-check before treating JSON export as the long-term compatibility surface.
- `EXT-K8S-DEPRECATION-POLICY` — re-check before borrowing lifecycle promises for candidate/stable/deprecated lanes.
- `EXT-K8S-FEATURE-GATES-2026` — re-check before promoting any optional surface into baseline truth.
- `EXT-K8S-POD-GENERATION` — re-check before publishing any status/read model that can lag authoring intent.
- `EXT-DBT-SEMANTIC-MODELS-2026` — re-check before promoting any entity/dimension/metric family into durable archive vocabulary.
- `EXT-DBT-DIMENSIONS-2026` — re-check before generalizing effective-time or slowly-changing-context ideas across families.
- `EXT-DBT-MEASURES-2026` — re-check before freezing any product-shaped metric/measure taxonomy.
- `EXT-CUBE-PREAGG-2026` — re-check before treating a derived read model or pre-aggregated export as primary cube truth.
- `EXT-XTDB-TIME-2026` — re-check before promoting a wider effective-time/record-time contract or universal bitemporal plane.
- `EXT-CUBE-NON-ADDITIVITY-2026` — re-check before promoting non-additive or approximate read surfaces into primary cube truth.

- `EXT-DBT-ENTITIES-2026` — re-check before promoting whole-population versus subset identity or denominator semantics into durable archive vocabulary.
- `EXT-DBT-RATIO-2026` — re-check before freezing denominator-basis or normalization-lane semantics from the current ratio-metric authoring shape.
- `EXT-PROMETHEUS-NAMING-2026` — re-check before treating labels, buckets, or category cuts as safely summable partitions.
- `EXT-PROMETHEUS-HISTOGRAMS-2026` — re-check before treating visible averages, SLO ratios, or bucket-derived percentages as atomic cube truth.
- `EXT-LOOKERSTUDIO-RATIO-2026` — re-check before treating already-aggregated or display-layer ratio metrics as freely re-aggregatable facts.
- `EXT-PROMETHEUS-INSTRUMENTATION-2026` — re-check before treating any new free-form label family as a default grouping axis.
- `EXT-CLICKHOUSE-UNIQ-2026` — re-check before promoting approximate distinct outputs into durable exact-looking cube truth.
- `EXT-CLICKHOUSE-APPROXTOPK-2026` — re-check before promoting approximate rank outputs into correctness-bearing category or denominator semantics.
- `EXT-OPENLINEAGE-FACETS-2026` — re-check before promoting any durable derivation or replay metadata family.
- `EXT-OPENLINEAGE-EXECUTION-PARAMETERS-2026` — re-check before freezing recipe-witness fields or parameter-carrying result semantics.
- `EXT-LAKEFS-METADATA-SEARCH-2026` — re-check before treating moving refs or latest views as sufficient input-cut truth.
- `EXT-DBT-ARTIFACTS-2026` — re-check before promising replay or state comparison without durable derivation residue.
- `EXT-DBT-MANIFEST-JSON-2026` — re-check before freezing compiled-query or recipe-witness semantics for derived rows.
- `EXT-AIRFLOW-ASSETS-2026` — re-check before trusting side-hook metadata or non-execution-path derivation residues as durable truth.
- `EXT-DRUID-ROLLUP-2026` — re-check before treating any lossy rollup or summary family as equivalent to row-preserving source truth.
- `EXT-DRUID-PROJECTIONS-2026` — re-check before freezing any projection/materialization noun whose removal or reshaping would become operationally sticky.
- `EXT-PROMETHEUS-EXEMPLAR-STORAGE-2026` — re-check before promising exemplar-anchor retention, availability, or bounded breadcrumb durability.
- `EXT-POSTGRES-ROW-SECURITY-2026` — re-check before treating any cross-view total or filtered count as audience-neutral truth.
- `EXT-POSTGRES-SECURITY-BARRIER-2026` — re-check before assuming secure and broad lenses share one optimization or freshness story.
- `EXT-BIGQUERY-ROW-SECURITY-INTRO-2026` — re-check before flattening authorized-view, row-policy, and separate-table outputs into one comparability rule.
- `EXT-BIGQUERY-COLUMN-MASKING-2026` — re-check before promoting masked payloads into audience-neutral field semantics.
- `EXT-SNOWFLAKE-AGGREGATION-POLICIES-2026` — re-check before freezing threshold-gated aggregate release or comparability semantics.
- `EXT-POSTGRES-LIMIT-2026` — re-check before treating any page-shaped result or offset slice as durable population truth.
- `EXT-GRAPHQL-PAGINATION-2026` — re-check before freezing cursor/window-cut vocabulary or resumability promises.
- `EXT-ELASTIC-SEARCH-API-2026` — re-check before flattening relation-qualified or omitted totals into one generic count field.
- `EXT-BIGQUERY-GETQUERYRESULTS-2026` — re-check before treating page-local rows and whole-result counts as interchangeable cube facts.
- `EXT-MEILISEARCH-PAGINATION-2026` — re-check before promoting estimated totals into exact-looking cube vocabulary.
- `EXT-BEAM-BASICS-2026` — re-check before freezing any preview/on-time/finalized bucket vocabulary or watermarked early-result semantics.
- `EXT-FLINK-TIME-2026` — re-check before promoting event-time completeness or watermark-frontier posture across multiple families.
- `EXT-SPARK-WATERMARK-2026` — re-check before promising finalized bucket semantics or late-data drop posture for time-bucketed values.
- `EXT-KAFKA-STREAMS-GRACE-2026` — re-check before freezing grace-period or late-discard semantics into durable cube vocabulary.
- `EXT-DBT-STATE-AWARE-2026` — re-check before aligning freshness claims and late-arrival lookback posture across incrementally rebuilt families.
- `EXT-ELASTIC-QUERYDSL-2026` — re-check before flattening scored query-context results and unscored filter-context results into one generic score family.
- `EXT-WEAVIATE-VECTOR-SEARCH-2026` — re-check before freezing vector-score direction or assuming top-k implies meaningful absolute relevance.
- `EXT-WEAVIATE-HYBRID-2026` — re-check before promoting fused hybrid scores into durable cross-family or cross-query semantics.
- `EXT-AZURE-HYBRID-RANKING-2026` — re-check before treating BM25/vector/RRF/reranker stages as one universal ranking contract.
- `EXT-AZURE-BM25-SCORING-2026` — re-check before treating tied-score ordering or repeated ranked pages as naturally stable truth.
- `EXT-DATABRICKS-MERGE-INTO-2026` — re-check before treating ambiguous multi-match updates as if one source row obviously won.
- `EXT-DATABRICKS-DELTA-MERGE-2026` — re-check before assuming source-batch duplicates disappear automatically in upsert-shaped families.
- `EXT-HUDI-RECORD-MERGER-2026` — re-check before promoting a generic latest-wins doctrine instead of an explicit reconciliation recipe.
- `EXT-PURVIEW-PROFISEE-MDM-2025` — re-check before promoting golden/master/current-value nouns into permanent cube ontology.
- `EXT-DBT-INCREMENTAL-MODELS-2026` — re-check before flattening unique-key overwrite posture and duplicate-key ambiguity into one row story.
- `EXT-DBT-INCREMENTAL-STRATEGY-2026` — re-check before promising that append, merge, and history-preserving rebuilds mean the same thing.
- `EXT-BIGQUERY-TABLESAMPLE-2026` — re-check before treating block-sampled or clustered-table outputs as denominator-ready cube truth.
- `EXT-CLICKHOUSE-SAMPLE-2026` — re-check before promising deterministic-sample expansion or `_sample_factor` semantics across families.
- `EXT-OTEL-SAMPLING-CONCEPTS-2026` — re-check before promoting sampled telemetry families into durable cube vocabulary.

- `EXT-PROMETHEUS-WRITING-EXPORTERS-2026` — re-check before freezing canonical-scale defaults or treating percent-shaped outputs as primary cube truth.
- `EXT-PROMETHEUS-METRIC-TYPES-2026` — re-check before flattening restart-reset counters into permanent cumulative truth.
- `EXT-PROMETHEUS-QUERY-FUNCTIONS-2026` — re-check before promising cross-reset stitching or reset-adjusted derivation across families.
- `EXT-OTEL-METRICS-SUPPLEMENTARY-2026` — re-check before freezing reset-detection or unknown-reset-time semantics into durable cube vocabulary.
- `EXT-STRIPE-BILLING-CYCLE-2026` — re-check before promoting anchored-period usage families or explicit period-reset posture.
- `EXT-STRIPE-USAGE-THRESHOLDS-2026` — re-check before promising threshold-triggered re-anchor or carryover semantics across families.

- `EXT-FINOPS-SHARED-COSTS-2026` — re-check before promoting shared-burden, showback, or chargeback semantics into durable cube vocabulary.
- `EXT-OPENCOST-SPEC-2026` — re-check before freezing shared/idle/overhead allocation posture or cluster-burden rollups.
- `EXT-FOCUS-SPEC-2026` — re-check before promoting provider-native allocation methodology or amortized/shared-cost semantics.
- `EXT-DBT-SEMANTIC-SPEC-MODERNIZATION-2026` — re-check before freezing any vendor-shaped semantic-layer taxonomy or authoring shape into durable cube vocabulary.
- `EXT-DBT-MODEL-VERSIONS-2026` — re-check before treating one latest-version pointer as sufficient comparison truth across evolving families.
- `EXT-DBT-COORDINATE-VERSIONS-2026` — re-check before promising painless producer/consumer migration or silent version retirement.
- `EXT-OPENLINEAGE-OBJECT-MODEL-2026` — re-check before flattening design-time declarations and runtime observations into one metadata family.
- `EXT-ICEBERG-BRANCHING-2026` — re-check before treating mutable heads, default branches, or experiment outputs as durable cube truth.
- `EXT-DAGSTER-COLUMN-LINEAGE-2026` — re-check before promoting column-lineage or drill-through hints into mandatory core cube fields.
- `EXT-HUDI-TABLE-TYPES-2026` — re-check before freezing one ordering-basis doctrine for late-arriving or out-of-order families.
- `EXT-DELTA-CHANGE-DATA-FEED-2026` — re-check before treating current snapshots and row-level change events as interchangeable cube facts.
- `EXT-BIGQUERY-CHANGES-2026` — re-check before relying on time-window-limited/current-schema-limited change history as durable semantic memory.
- `EXT-DBT-SNAPSHOTS-2026` — re-check before flattening mutable-source ordering into one generic `updated_at` folklore.
- `EXT-DBT-HARD-DELETES-2026` — re-check before flattening delete handling into one universal disappearance story.
- `EXT-SQLSERVER-TEMPORAL-USAGE-2026` — re-check before treating transaction-time history as business-valid history for delayed-load families.

- `EXT-LOOKER-SYMMETRIC-AGGREGATES-2026` — re-check before flattening counted-once semantics, primary-key dedupe posture, or fanout-safe aggregation into one timeless rule.
- `EXT-DBT-JOIN-LOGIC-2026` — re-check before promising that entity/join posture or chasm refusal is stable enough to freeze into durable cube vocabulary.
- `EXT-POWERBI-MANY-TO-MANY-2025` — re-check before treating bridge-shaped or higher-grain answers as freely drillable and additive below their lawful level.
- `EXT-CUBE-TYPES-FORMATS-2026` — re-check before flattening exact distinct, approximate distinct, and row-duplication-safe counts into one generic count posture.
- `EXT-OPENLINEAGE-DQ-ASSERTIONS-2026` — re-check before flattening assertion results, quality posture, or validation outcomes into one durable truth plane.

- `EXT-GCLOUD-SLO-MONITORING-2026` — re-check before treating any eligible-event or windows-based operational score as archive-wide whole-system truth.

- `EXT-CUBE-MATCHING-PREAGG-2026` — re-check before treating acceleration matching success as proof that a summary lane is canonical truth.
- `EXT-LOOKER-AGGREGATE-AWARENESS-2026` — re-check before flattening aggregate-aware serving behavior and fanout-safe query semantics into one timeless cube rule.
- `EXT-DATAHUB-ASSERTIONS-2026` — re-check before treating assertion outcomes as if they directly replace the subject truth they verify.
- `EXT-W3C-FEDCM-2026` — re-check before promoting browser-mediated sign-in, account chooser, login hint, or disconnect semantics into durable cube vocabulary.
- `EXT-CHROME-FEDCM-2026` — re-check before assuming current browser support, active/passive mode behavior, or prompt semantics are stable enough for archive law.
- `EXT-GOOGLE-FEDCM-MIGRATION-2026` — re-check before treating migration-era browser sign-in choreography as settled identity truth.
- `EXT-W3C-LOGIN-STATUS-2026` — re-check before freezing login-status hints or browser-origin state into any durable account/session surface.
- `EXT-W3C-DIGITAL-CREDENTIALS-2026` — re-check before promoting user-agent mediated credential presentation, opaque-response, or protocol-agnostic wallet semantics.
- `EXT-CHROME-DIGITAL-CREDENTIALS-2026` — re-check before relying on current implementation support, selective-disclosure posture, or cross-device behavior as stable archive law.
- `EXT-OPENID-FEDERATION-1-0-2026` — re-check before promoting trust-chain, trust-anchor, metadata-policy, or Trust-Mark witnesses into durable cube vocabulary.
- `EXT-ODCS-3-1-2026` — re-check before freezing data-contract, contract-subset, SLA, or support/team/infrastructure clauses into result-envelope law.
- `EXT-OPENMETADATA-DATA-CONTRACTS-2026` — re-check before treating contract execution history, schema tests, semantic tests, or data-quality checks as durable cube truth.
- `EXT-FRICTIONLESS-TABLE-SCHEMA-2026` — re-check before freezing field-constraint or unsupported-constraint behavior into validation witnesses.
- `EXT-SUBSTRAIT-2026` — re-check before treating a plan digest, serialized query plan, or operation profile as a durable Foundry query contract.
- `EXT-DUCKDB-ORDER-PRESERVATION-2026` — re-check before promising stable ordering, page-order replay, or order-preserving transformations.
- `EXT-XARRAY-DATA-STRUCTURES-2026` — re-check before promoting axis, coordinate, attrs, or labeled-array semantics across cube families.
- `EXT-ZARR-V3-CORE-2026` — re-check before treating chunk grids, codecs, storage metadata, or hierarchy layout as semantic identity.
- `EXT-STAC-DATACUBE-2026` — re-check before borrowing dimensions/variables language for Foundry catalog or cube-shaped outputs.
- `EXT-STAC-EXTENSIONS-2026` — re-check before relying on STAC extension maturity, especially candidate datacube and table-access extensions.
- `EXT-DELTA-PROTOCOL-2026` — re-check before promoting table-log, transaction-cut, snapshot-isolation, or incremental-processing semantics.
- `EXT-GREATEXPECTATIONS-VALIDATION-RESULT-2026` — re-check before freezing validation-result object shape, suite-success posture, or statistics into validation witnesses.
- `EXT-W3C-DCAT3-2024` — re-check before promoting catalog-card or discovery-plane semantics into durable Foundry vocabulary.
- `EXT-SDMX-COG-2026` — re-check before borrowing code-list or cross-domain concept language into hierarchy-scope fields.
- `EXT-SDMX-AVAILABILITY-2026` — re-check before freezing availability-basis, partial-codelist, or valid-future-selection posture.
- `EXT-UNICODE-LDML-DATES-2026` — re-check before freezing calendar-lens fields around week start, min-days, reporting years, or locale calendars.
- `EXT-BIGQUERY-DATE-FUNCTIONS-2026` — re-check before depending on current BigQuery date bucket behavior as an example of calendar-lens pressure.
- `EXT-POSTGRES-DATETIME-FUNCTIONS-2026` — re-check before depending on current PostgreSQL ISO-week behavior as an example of calendar-lens pressure.
- `EXT-OGC-DGGS-2026` — re-check before borrowing DGGS hierarchy or sub-zone ordering language for spatial hierarchy scopes.
- `EXT-CENSUS-TIGER-2025` — re-check before using the current TIGER/Line release page as boundary-cut evidence.
- `EXT-ARROW-PARTITIONING-2026` — re-check before relying on current Arrow partitioning behavior to shape storage-layout fences.
- `EXT-BIGQUERY-MATERIALIZED-VIEWS-2026` — re-check before relying on current incremental/non-incremental materialized-view limits, smart tuning, or max-staleness behavior.
- `EXT-BIGQUERY-MATERIALIZED-VIEWS-USE-2026` — re-check before freezing incremental-update rejection, partition-alignment, or materialized-view bypass semantics.
- `EXT-SNOWFLAKE-DYNAMIC-TABLES-2026` — re-check before relying on current dynamic-table target-lag or refresh behavior.
- `EXT-SNOWFLAKE-TARGET-LAG-2026` — re-check before freezing actual-lag, downstream-target-lag, or skipped-refresh semantics.
- `EXT-MATERIALIZE-LIVE-DATA-2026` — re-check before borrowing live incremental maintenance language into refresh witnesses.
- `EXT-DAGSTER-FRESHNESS-POLICIES-2026` — re-check before treating current Dagster freshness-policy APIs or asset-health presentation as stable.
- `EXT-OPENLINEAGE-DATASET-TYPE-2026` — re-check before relying on current dataset-type facet materialized/external/temporary vocabulary.
- `EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026` — re-check before freezing privacy-unit, contribution-bound, noise, or limitation posture into aggregate-release witnesses.
- `EXT-OPENDP-WORKFLOW-2026` — re-check before relying on current OpenDP workflow language for privacy-unit and privacy-loss parameter posture.
- `EXT-EUROSTAT-SDC-CROS-2024` — re-check before relying on the current Eurostat CROS SDC portal as methodology/source taxonomy evidence.
- `EXT-SNOWFLAKE-ENTITY-PRIVACY-2026` — re-check before freezing row-vs-entity threshold examples or aggregation-policy interaction details.
- `EXT-AWS-CLEANROOMS-AGGREGATION-2026` — re-check before depending on current aggregation analysis-rule output-constraint behavior.
- `EXT-AWS-CLEANROOMS-ANALYSIS-RULES-2026` — re-check before depending on current restrictive-control composition and output-constraint disclosure behavior.
- `EXT-AWS-CLEANROOMS-DP-POLICY-2026` — re-check before freezing privacy budget, noise, and refresh-composition posture.
- `EXT-SDMX-OBS-STATUS-2026` — re-check before freezing any observation-status vocabulary, especially estimated/imputed/provisional/revised distinctions.
- `EXT-CF-CELL-METHODS-2026` — re-check before borrowing axis/method residue into adjustment witnesses.
- `EXT-CF-FLAGS-2026` — re-check before copying quality-flag examples or flag vocabulary into Foundry status cards.
- `EXT-NIST-OECD-IMPUTATION-2026` — re-check before treating imputed/substituted values as observed or blank-equivalent.
- `EXT-CENSUS-X13ARIMA-2025` — re-check before relying on current seasonal-adjustment software/features/diagnostic posture as a stable exemplar.
- `EXT-ALFRED-VINTAGES-2026` — re-check before depending on current ALFRED vintage access/service behavior as durable revised-value precedent.
- `EXT-IMF-DQAF-2003` — re-check before widening preliminary/revised/adjusted-value fields into a general quality framework.
- `EXT-EUROSTAT-DATA-VALIDATION-2026` — re-check before using validation reports or green checks as durable Foundry truth surfaces.
- `EXT-EUROSTAT-VALIDATION-LEVELS-2026` — re-check before widening within-table totals into cross-source, mirror, or external consistency semantics.
- `EXT-SDMX-VTL-2026` — re-check before freezing any rule-language, transformation-expression, or executable validation contract.
- `EXT-UNECE-GSBPM-5-2-2026` — re-check before turning reconciliation witnesses into a process/quality/metadata framework.

- `EXT-SDMX-CROSS-DOMAIN-CODELISTS-2026` — re-check before promoting code-list choices or cross-domain category values into durable Foundry vocabulary.
- `EXT-EUROSTAT-NACE-CORRESPONDENCE-2026` — re-check before borrowing correspondence-table or classification-transition language into code-drift fences.
- `EXT-NAICS-REVISION-CYCLE-2026` — re-check before assuming current classification revision cadence or category-change examples remain current.

- `EXT-OPA-DECISION-LOGS-2026` — re-check before relying on current OPA decision-log fields, trace/span posture, or masking semantics as stable waiver replay precedent.
- `EXT-CYCLONEDX-VEX-2026` — re-check before relying on current CycloneDX VEX state/justification/response posture as stable exception precedent.
- `EXT-TUF-SPEC-2026` — re-check before relying on current TUF specification language for rollback/freeze/stale-metadata pressure in recall fences.
- `EXT-IN-TOTO-ATTESTATION-2026` — re-check before relying on current in-toto statement/predicate guidance as stable replacement-witness precedent.
- `EXT-CLOUDEVENTS-2026` — re-check before promoting distribution/adoption event envelopes or notification metadata into durable archive vocabulary.
- `EXT-OCI-DISTRIBUTION-SPEC-REFERRERS` — re-check before freezing subject/referrer-like carrier distribution graphs.
- `EXT-SCITT-ARCHITECTURE-2026` — re-check before treating transparency or inclusion evidence as stable adoption/accountability vocabulary.

- `EXT-NIST-CM8-INVENTORY-2026` — re-check before widening surface-inventory, alias-resolution, relationship-edge, owner/dependent, or coverage-gap vocabulary beyond fixture-local v0.

- `EXT-OPENLINEAGE-SYMLINKS-2026` — re-check before widening surface-inventory, alias-resolution, relationship-edge, owner/dependent, or coverage-gap vocabulary beyond fixture-local v0.

- `EXT-SPDX-RELATIONSHIPS-2026` — re-check before widening surface-inventory, alias-resolution, relationship-edge, owner/dependent, or coverage-gap vocabulary beyond fixture-local v0.

- `EXT-K8S-OWNER-DEPENDENTS-2026` — re-check before widening surface-inventory, alias-resolution, relationship-edge, owner/dependent, or coverage-gap vocabulary beyond fixture-local v0.

- `EXT-W3C-DPV-2026` — re-check before borrowing DPV purpose, recipient, rights, processing, or measure vocabulary into obligation ledgers.

- `EXT-PROMETHEUS-ALERTING-RULES-2026` — re-check before relying on current Prometheus alert state, `for`, or `keep_firing_for` wording as stable drift-signal precedent.

- `EXT-K8S-PROBES-2026` — re-check before relying on current Kubernetes probe semantics as stable recheck/probe vocabulary.
- `EXT-PROMETHEUS-ALERTMANAGER-2026` — re-check before relying on current Alertmanager grouping, deduplication, routing, silencing, or inhibition wording as stable escalation/routing precedent.
- `EXT-OTEL-EVENTS-2026` — re-check before relying on current OpenTelemetry event semantic-convention status or fields as stable routing-witness vocabulary.

- `EXT-OPA-POLICY-TESTING-2026` — re-check before relying on current OPA policy-testing wording as stable rule-promotion precedent.
- `EXT-K8S-VALIDATING-ADMISSION-POLICY-2026` — re-check before borrowing current admission-policy fields or failure behavior into rule-promotion/overgeneralization vocabulary.- `EXT-OPENFEATURE-FLAG-EVALUATION-2026` — re-check before borrowing evaluation-detail or reason/default language into rule-evaluation traces.
- `EXT-OPENFEATURE-EVALUATION-CONTEXT-2026` — re-check before widening evaluation-context or targeting-key language into durable cube vocabulary.
- `EXT-CEDAR-VALIDATION-2026` — re-check before borrowing validation or schema-bound action/context language into rule-application checks.
