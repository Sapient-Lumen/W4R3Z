# Research synthesis — pass LXIII

This pass stays deliberately conservative.
Foundry still should **not** pretend that every reader, dashboard, export surface, or neighboring cube fully understands every newly introduced design-phase meaning family.
But it can steal one more durable lesson from current schema, protocol, and semantic-convention ecosystems: **required support must be explicit, unknown semantics should be preserved instead of erased, and unread meaning must not quietly collapse into false/none/zero.**

The smallest durable seam from this pass is:
- **support witness** — the compact record of which meaning families, vocabularies, or adjunct semantics the reader/export path claimed to understand, require, ignore, or refuse;
- **unknown residue** — the preserved uninterpreted payload, field, enum, or digest that survived even though the reader did not fully understand it;
- **falsehood fence** — the explicit rule that unsupported or unread semantics must not silently become `false`, `none`, `0`, `complete`, or `not_applicable`.

These are still smaller than a giant semantic registry, one universal extension catalog, or a mandatory backfill engine.
They simply keep design-phase interpretation honest.

## Lessons we must learn from the past

### 1) Required support and optional support are different contracts
JSON Schema is unusually useful here.
Its dialect/vocabulary model lets a meta-schema declare which vocabularies are required and which are optional.
Implementations that do not recognize a required vocabulary must refuse to process the schema, while unrecognized keywords from optional vocabularies are treated as annotations rather than failures or silent fake truth.
That is exactly the kind of humility Foundry needs while SlopOS families are still evolving.

### 2) Unknown semantics are healthier when they round-trip instead of disappearing
Protocol Buffers are helpful because old readers preserve unknown fields and proto3 also preserves unrecognized enum values.
The warning is equally important: those unknowns can be lost when data is flattened into JSON or copied field-by-field.
Foundry should steal the preservation instinct and avoid making friendly JSON/export surfaces the place where design-phase meaning silently dies.

### 3) Stable-by-default systems still need opt-in room for unstable meaning
OpenTelemetry’s current stability work is directly relevant.
The project is pushing toward stable-by-default distributions with explicit opt-in for unstable features, and its semantic-convention work is moving toward more federated conventions instead of one central final word.
That is a strong warning for Foundry: the cube should not force every new design-phase family into one permanently understood core vocabulary.

### 4) Development/stable/deprecated posture is useful only if unsupported readers stay honest
OpenTelemetry semantic-convention groups now carry explicit stability levels and are not meant to disappear just because a later stable replacement exists.
That supports a Foundry rule too: newer readers may understand more, but older readers should preserve that a development/deprecated family existed rather than laundering it into “not present”.

### 5) Erasing unread semantics is often worse than refusing to decide
W3C design principles continue to pressure systems toward explicit extension points and understandable processing behavior.
For Foundry, the practical lesson is simple: when a panel/export does not understand a required family, it should refuse or downgrade explicitly; when it ignores an optional family, it should say so and preserve the residue instead of pretending nothing happened.

## What to steal now
- a **support witness** that says which required and optional meaning families the reader or export path actually understood;
- **unknown residue** that keeps unread fields/enums/payload digests available for later readers or drill-through;
- a **falsehood fence** that forbids coercing unread semantics into flattering defaults such as zero, absent, false, or unsupported;
- a habit of keeping **binary/pinned preservation surfaces** stronger than convenience JSON/summary exports;
- and a rule that **required vocabulary failure** is healthier than partial misinterpretation.

## What to keep parked
Do not yet promote:
- one cube-wide extension registry with central approval for every new family;
- a mandatory opaque-carryover blob on every row whether needed or not;
- automatic negotiation among all consumer versions;
- or a promise that every unknown residue is always interpretable later.

## Resulting recommendation
The next healthy move is not “teach every consumer every new SlopOS adjunct now.”
It is to let Foundry say, for any evolving imported/exported/adjunct family:
1. which **support witness** the reader/export path declared,
2. which **unknown residue** survived unread,
3. and where a **falsehood fence** blocked silent coercion into ordinary-looking truth.

That keeps the cube aligned with SlopOS’s design-phase reality while still stealing smart discipline from JSON Schema, Protocol Buffers, OpenTelemetry, and the W3C.
