# SlopOS / companions evaluation — pass XXVII

Foundry still looks justified as its own companion cube, and this pass sharpens another seam that SlopOS is already culturally prepared to respect: **exact basis truth should not silently imply exact persistent-state continuity.**

## What the current cube ecology keeps proving
- **SlopOS** already has the right instincts for this seam. Its boot-manifest and boot-selector materials are careful about exact basis, pending/current/LKG posture, and rollback floors; its state-projection and init-state surfaces also show comfort with explicit bounded state descriptions instead of ambient folklore.
- **SlopOS** is still in the design phase, which makes this a cheap seam to preserve now. If basis activation, blessing, rollback, and recovery docs quietly imply that persistent state simply comes along for free, later docs will have to unteach that false symmetry.
- **Steward** is a useful sibling pressure here: its semantic-epoch posture proves that “epoch” is already a house style for freshness and stale-fence honesty. Foundry can borrow that discipline for persistent-state semantics without importing Steward’s shell-centric meaning.
- **ViewFS** also points the same way. Its mutable work-state and basis-drift materials already resist flattening exact basis truth, apply truth, and live mutable state into one cozy noun.
- **Ward** remains the right place for exported evidence or verdict logic. Foundry only needs the meaning cut that says a basis can be current while state still belongs to an older, newer, or reset-required epoch.

## Pressure on Foundry
Foundry should not invent a general migration runner, persistent-object database, or universal app-state schema language.
The stronger move is to keep one specimen where:
1. a new basis becomes installed and perhaps even blessed,
2. persistent state remains on an older **state epoch** for some time,
3. an explicit **migration cut** may later advance that epoch,
4. rolling basis backward may still leave persistent state too new or too different for clean continuity,
5. and a visibly separate **reset rail** stays available when compatibility cannot be preserved honestly.

## Collected but parked ideas
This pass also surfaces two good adjacent ideas that should stay parked:
- **read corridor** for compact “this basis can read that older state epoch without mutation” residue;
- **migration witness card** for compact “what happened to persistent state during this transition?” residue.

Those ideas are real, but they do not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `state epoch`, `migration cut`, or `reset rail` unless they improve:
- one shared-state / no-copy-on-upgrade specimen,
- one explicit storage- or config-migration specimen,
- and one rollback-or-recovery specimen that requires reset or reseed instead of pretending continuity.
