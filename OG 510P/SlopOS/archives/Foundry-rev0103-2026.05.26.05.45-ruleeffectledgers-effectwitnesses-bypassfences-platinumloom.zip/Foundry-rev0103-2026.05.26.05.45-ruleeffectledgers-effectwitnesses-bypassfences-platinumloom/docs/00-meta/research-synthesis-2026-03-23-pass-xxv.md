# Research synthesis — pass XXV

This pass keeps Foundry narrow and learns one more thing from update ecosystems: **an offered edge can be locally admissible and still fail to be a valid direct path from this exact current state.**

## Outside lessons
1. **Cincinnati keeps path truth explicit.**  
   Cincinnati represents updates as a directed acyclic graph of valid transitions, and Zincati’s own overview says the protocol supports complex update graphs with barriers and dead-ends. Foundry should steal the idea that not every tempting endpoint implies one valid direct edge from the current node.

2. **Mender makes current-state prerequisites explicit instead of trusting version folklore.**  
   Mender Artifacts may carry `Depends` fields that must match `Provides` fields already stored on the device. Its own example uses a root filesystem checksum, which means exact current-state identity can matter more than a human-facing version string.

3. **Omaha says versions can be too coarse for delta applicability.**  
   The protocol notes that a version number is usually insufficient to identify the binaries the client already has, so the server sends a more precise “differential fingerprint”, typically derived from a payload hash. Foundry should learn that a compact prerequisite witness may need to be sharper than “currently on v1.2.3”.

4. **RAUC keeps both compatibility and forward-only floors visible.**  
   RAUC requires a `compatible` string match, and its optional `min-bundle-version` rejects older bundles. RAUC also warns that this can complicate rollback stories when content and manifest-version floors diverge. That is a strong lesson: direct applicability and rollback symmetry are different truths.

5. **Sparkle keeps qualification checks explicit.**  
   Sparkle lets publishers add `sparkle:minimumSystemVersion` so that only qualified users are offered or allowed that update item. That is the same family of pressure in a smaller desktop form.

## Resulting Foundry move
Do not decide yet whether `prerequisite witness`, `applicability fence`, and `barrier hop` belong under live realization, basis lineage, or a still-smaller transition-validity sideband.
For now, keep them alive as specimen nouns and demand that they improve:
- one delta/checksum-sensitive specimen,
- one compatibility or minimum-version specimen,
- and one barrier-release or required-intermediate specimen.

Also keep two adjacent ideas parked rather than promoted:
- **delta fingerprint card** — compact exact-current-state label sharper than a version string;
- **incompatibility chip** — concise explanation of why a direct path is invalid right now.

## Fresh ideas worth stealing
- **prerequisite witness** — compact exact-current-state fact relevant to whether a direct transition is valid.
- **applicability fence** — required dependency/compatibility/floor check before a direct edge counts as real.
- **barrier hop** — explicit required intermediate step before a later target becomes valid.
- **delta fingerprint card** — future exact-current-state label parked for later pressure.
- **direct-edge smaller than valid-path** — a standing anti-regrowth rule.
