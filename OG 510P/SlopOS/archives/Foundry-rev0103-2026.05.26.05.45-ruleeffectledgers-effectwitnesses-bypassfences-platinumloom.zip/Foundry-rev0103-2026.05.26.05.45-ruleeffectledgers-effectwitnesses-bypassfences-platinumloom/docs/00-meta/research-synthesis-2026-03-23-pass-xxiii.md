# Research synthesis — pass XXIII

This pass keeps Foundry narrow and learns one more thing from update and package ecosystems: **a floating selector is useful operationally, but it is still smaller than the exact basis that was actually reviewed, prepared, or activated.**

## Outside lessons
1. **Nix keeps channels and exact profile generations visibly different.**  
   The Nix manual says channels conveniently retrieve the latest version, but their state is external to the expressions that rely on them and may limit reproducibility. By contrast, profiles are versioned generations backed by exact store paths. Foundry should learn that a follow surface is not yet a basis fact.

2. **OSTree keeps refs and revisions distinct.**  
   Official OSTree terminology says a ref is a text reference naming a particular commit, while Red Hat's OSTree terminology guide makes the operational consequence painfully clear: refs always resolve to the latest commit, whereas a revision is the SHA-256 for one specific commit. Foundry should steal that split directly.

3. **Chrome update policy separates release channel from exact version pin.**  
   Chrome Enterprise lets admins choose a release channel, but `Target version prefix` can narrow that to a major, minor, or exact version, and exact pinning uses a `$` suffix. The same guide notes that channel changes do not necessarily downgrade immediately; rollback remains an explicit choice. Foundry should keep channel intent, exact basis, and rollback policy from collapsing into one noun.

4. **Omaha protocol data keeps cohort metadata smaller than exact current basis.**  
   Chromium's protocol names `cohort`, `cohorthint`, `cohortname`, and `release_channel`, but those are channel/cohort semantics, not the exact installed version. Foundry should continue to park such rollout metadata outside basis truth.

5. **SlopOS already states the rule in a neighboring authority seam.**  
   `approval-basis-posture-v0.md` says approval evidence binds one exact action, not a floating mutable target such as current head or queue position, and rejects silent inheritance when the mutable basis drifts. Foundry should learn from that pressure without regrowing a giant approval-cache plane.

## Resulting Foundry move
Do not decide yet whether `follow selector`, `basis pin`, and `drift fence` belong under artifact identity, live realization, or continuity residue.
For now, keep them alive as specimen nouns and demand that they improve:
- one moving ref/branch specimen,
- one channel-with-exact-version-pin specimen,
- and one mutable-basis approval specimen.

Also keep one adjacent idea parked rather than promoted:
- **selector snapshot** — a compact “what this selector resolved to then” residue that may become useful later, but does not yet deserve first-class status.

## Fresh ideas worth stealing
- **follow selector** — floating branch/channel/ref/track request.
- **basis pin** — exact resolved revision, digest, or version.
- **drift fence** — explicit refusal to let old review or install intent follow a moved selector.
- **selector snapshot** — a small historical note about one earlier resolution event, still smaller than current truth.
- **pinned-over-floating rule** — a standing anti-regrowth rule.
