# SlopOS / companions evaluation — 2026-03-23 pass X

This pass evaluated whether Foundry can absorb sidecar-closure and resource-warrant ideas without turning into a generic packaging framework or a whole new orchestration stack.

## SlopOS pressure that matters most now

The component-manifest and capability-routing work remains the strongest native brace. SlopOS clearly prefers explicit routing, declared surfaces, and lintable boundaries over ambient host power.

The microVM and foreign-ground posture files still matter just as much. They keep reminding Foundry that restored continuity, attached evidence, and live realization are not the same strength of fact.

SlopOS also continues to reward small explicit export objects. If Foundry invents one all-purpose “runtime package truth” object, it will be pushing against the primary cube’s own direction.

## Sibling pressure that matters most now

### Harbor
Harbor keeps route and handoff truth smaller than realization truth.

### Ward
Ward keeps evidence and release separate, which helps Foundry resist treating attached sidecars as equivalent to local approval.

### Helm and Schell
Both continue to support explicit adoption, visible residue, and truth about foreign assistance.

## Recommendation for Foundry rev0011

Keep these candidate nouns provisional:
- **sidecar closure**
- **resource warrant**
- **foreign lease**
- **launch closure**
- **reacquire warrant**

The pass X specimen should exist to kill the over-wide versions early:
- if sidecar closure starts implying that attached evidence equals what ran, it is too strong;
- if resource warrant becomes a giant deployment taxonomy, it is too wide;
- if foreign lease becomes a universal runtime doctrine, it is too frozen.

Foundry is healthiest when it can say what was nearby, what was routed, what launched, and what still remained foreign.
