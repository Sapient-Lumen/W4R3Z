# Research synthesis — 2026-03-23 pass IV

This pass tightened Foundry around three sources of pressure:
1. a reread of the most relevant SlopOS cuts, especially foreign-cell, microVM snapshot/template/reacquire, and attestation-reacquire materials;
2. fresh official material on OCI image/runtime separation, WIT packages/interfaces/worlds, Kata, Confidential Containers, Firecracker snapshots, and SnapStart uniqueness lessons;
3. the process constraint that Foundry must collect substrate ideas without choosing one forever ground too early.

## What the datacubes reinforced
- SlopOS already has the right instincts for Foundry: foreign cells are membrane-governed, snapshot restore is not ambient continuity, and attestation freshness may need reacquire on generation change.
- SlopOS’s microVM template/resume-class work suggests a powerful process habit for Foundry: compatibility should be admitted as a class, not discovered by accident at restore time.
- ViewFS keeps reminding Foundry that a carrier, a bundle, and a realized object are not interchangeable.
- Ward is a standing guardrail: runtime evidence belongs here, but verdicts do not.

## What the outside sources reinforced
- OCI still provides a useful separation between image/index material and runtime bundle/lifecycle material.
- The component model is especially valuable because packages, interfaces, worlds, and canonical ABI all keep contract meaning explicit across language boundaries.
- Kata’s whole point is that something can feel container-like while actually being VM-backed; Foundry should steal the honesty, not erase the difference.
- Confidential Containers very usefully keeps attestation policy and secret-release/resource policy separate.
- Firecracker snapshot docs are a direct reminder that snapshot files, host communication, and network continuity remain part of the trust and lifecycle story.
- SnapStart’s uniqueness guidance is a compact anti-lesson: cloned or resumed state can replay unique IDs, secrets, or entropy unless the system explicitly refreshes them after initialization.

## Brilliant ideas worth stealing carefully
1. **Resume class**: an explicit reviewed class for where a warm image or snapshot may resume honestly.
2. **Ground capability statement**: a small typed object that says what this runtime ground actually promises.
3. **Snapshot truth card**: a compact statement of what continuity may and may not be assumed after restore.
4. **Generation witness export**: a small signal that continuity changed, without pretending the system has already re-verified everything.

## Current recommendation
Foundry should keep building **continuity specimens before registries**. The next promotions should happen only after one vocabulary survives a VM-backed flow, a component-model flow, and a restored-state flow.
