# Research synthesis — pass LVI

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from MDM survivorship systems, upsert/merge engines, and incremental warehouse tooling: **competing assertions should not silently collapse into one “winning” value without carrying the rule that chose the winner, the fact that the choice was ambiguous or not, and whether the losing candidates remain inspectable.**

The smallest durable seam from this pass is:
- **arbitration recipe** — the compact witness for how competing source rows or claims were reconciled: authoritative-source pick, latest-by-event-time, last-writer-by-commit, manual certification, attribute-level survivorship, or explicit no-merge/fail-closed posture;
- **ambiguity class** — the compact witness for whether the arbitration was unique, tie-broken, underdetermined, rejected as ambiguous, or intentionally left plural;
- **dissent retention** — the compact witness for whether losing candidates remain inspectable as sibling evidence, compressed lineage, or not retained at all.

These are still smaller than a universal MDM product, a global golden-record plane, or a cube-wide “best value” service.
They simply keep future Foundry rows from laundering conflict resolution into timeless single-source truth.

## Lessons we must learn from the past

### 1) Merge semantics fail when multiple candidates match and the system cannot honestly choose
Databricks says `MERGE` fails when more than one source row matches the same target row because the update is ambiguous and it is unclear which source row should be used.
That is a healthy warning for Foundry: ambiguity is a first-class result, not just an operator inconvenience.

### 2) “Latest” depends on which ordering story you chose
Apache Hudi distinguishes commit-time ordering from event-time ordering and says they produce different merged results because commit time can diverge from the business ordering users actually care about.
So Foundry should not let a naked winning value pretend its victory was natural; the ordering/arbitration recipe belongs in the residue.

### 3) Golden records are built by survivorship rules, not discovered as self-evident truth
Microsoft’s Purview + Profisee MDM guidance says golden records are populated by survivorship rules that selectively choose data from source systems and that the flow from source records to the master is traceable.
That is useful, but it is also the warning: a “golden” value is already the outcome of a recipe.

### 4) Incremental upserts only stay honest when identity and overwrite posture are explicit
dbt’s incremental docs say a `unique_key` determines whether old rows are updated or new rows are inserted, warn that duplicate rows for the same key may fail depending on database and strategy, and note that different strategies carry different overwrite/history behavior.
That means a durable cube should not pretend overwrite-vs-append-vs-history is a tiny implementation detail.

### 5) Duplicate suppression and overwrite are not the same as history preservation
dbt’s incremental-strategy docs distinguish `append`, `delete+insert`, and `merge`, and explicitly say `merge` behaves like SCD1 while SCD2 needs snapshots.
Foundry should learn the same humility: one winning row can be useful without being the whole truth.

## What to steal now
- an **arbitration recipe** beside any value family that reconciles competing claims or rows;
- an **ambiguity class** so rejected, tied, underdetermined, or still-plural cases stay visible;
- a **dissent retention** marker so consumers know whether losing candidates can still be inspected;
- a habit of treating “winner chosen” as smaller than “question settled”;
- and a habit of making overwrite/history posture explicit instead of hiding it behind one friendly row.

## What to keep parked
Do not yet promote:
- a universal golden-record service;
- one cube-wide survivorship DSL;
- a global precedence hierarchy across every source family;
- automatic policy/authority selection from bundle-carried metadata;
- or a permanent “latest-wins” doctrine for unresolved multi-source truth.

## Resulting recommendation
The next healthy move is not “build MDM inside the cube.”
It is to let Foundry say, for any future reconciled value family:
1. which **arbitration recipe** chose the visible winner or refused to choose,
2. what **ambiguity class** the reconciliation ended in,
3. and what **dissent retention** remains for the losing candidates.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from Databricks Delta `MERGE`, Apache Hudi record mergers, Purview/Profisee survivorship guidance, and dbt incremental modeling posture.
