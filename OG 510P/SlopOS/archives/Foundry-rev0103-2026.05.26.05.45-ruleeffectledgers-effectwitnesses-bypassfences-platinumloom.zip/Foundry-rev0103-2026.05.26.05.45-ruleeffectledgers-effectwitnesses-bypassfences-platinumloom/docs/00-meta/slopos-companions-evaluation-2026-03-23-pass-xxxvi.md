# SlopOS plus companions evaluation — pass XXXVI

This pass tested whether Foundry should preserve a second narrow seam beside pass XXXV's effect-key vocabulary: *same key while original work is still outstanding* versus *same key after replay memory expired*.
The answer is yes, but again only narrowly.

## What SlopOS and companions already contribute
The uploaded SlopOS archive already keeps the right anti-flattery law in several places.
Its request-idempotency boundary says the same scoped request key only replays the same canonical request and rejects changed payloads before effect.
Its request-state postures keep requester-chosen request identity smaller than current portal-owned live state.
Its ACP acceptance/completion posture likewise refuses to let one accepted request or receipt pretend to be current completion/live-state truth.

The companions sharpen the same seam from adjacent directions:
- **Steward** already names the exact pressure in public text: same effect key may yield `still-processing`, `duplicate-suppressed`, or `dedupe-window-expired`, and retention windows are policy rather than forever truth.
- **Helm** keeps accepted work, commit posture, and later settlement separate, which means one historical accepted answer is already smaller than “finished now”.
- **ViewFS** and **Schell** keep live adoption/attachment truth separate from earlier accepted or remembered actions, which reinforces the rule that historical request memory is not ambient currentness.

So the ecosystem already has better homes for workflow, queue, and settlement surfaces.
Foundry does not need to grow a second one.

## What Foundry should own instead
Foundry should own only the semantic split that keeps these facts distinct:
1. **pending duplicate** — a same-key, same-fingerprint retry that arrives while the original work is still unresolved;
2. **dedupe horizon** — the bounded interval during which duplicate-safe replay or suppression is still defined;
3. **expiry gate** — the boundary after which the old key no longer honestly buys replay/suppression.

That seam is smaller than a queue, smaller than a completion API, and smaller than a permanent dedupe ledger.
It is just enough vocabulary to stop later docs from flattening “same key” into one timeless promise.

## Why this seam is worth preserving now
SlopOS is still in design.
That is exactly when to preserve the small truth that a foreign-backed mutation retry can be:
- rejected or marked outstanding because the original keyed work is still in flight,
- safely answered from earlier duplicate memory,
- or treated as fresh again because the dedupe horizon has expired.

If Foundry misses that seam now, later revisions will be tempted to let request IDs, client tokens, or historical receipts quietly imply a still-live dedupe window or a settled current answer.
That would make the archive worse at explaining provider APIs where “same key” can mean *wait*, *replay*, or *fresh attempt again* depending on timing rather than payload mismatch.
