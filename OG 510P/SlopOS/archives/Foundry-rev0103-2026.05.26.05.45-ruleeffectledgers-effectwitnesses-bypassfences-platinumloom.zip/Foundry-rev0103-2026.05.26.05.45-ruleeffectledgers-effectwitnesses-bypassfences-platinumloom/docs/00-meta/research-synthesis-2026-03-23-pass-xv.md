# Research synthesis — pass XV

This pass keeps Foundry narrow and learns one more thing from outside runtime systems: **foreign power can be intentionally absent, and that absence deserves a first-class object instead of being hidden behind “best effort” folklore**.

## Outside lessons
1. **Fuchsia treats capability availability and even missing sources as model facts.**  
   Optional or rewritten-to-void routes are not just deployment accidents. Foundry should steal that honesty: degraded or absent foreign power deserves explicit meaning.

2. **WIT resources keep ownership posture explicit.**  
   Borrowed and owned handles are different things, and the component model does not pretend otherwise. Foundry should preserve borrow posture even when runtime ergonomics try to make everything feel local.

3. **Confidential Containers keeps attestation policy and secret release policy separate.**  
   A workload can attest cleanly and still fail to receive a secret because resource policy says no. Foundry should preserve a release latch instead of flattening attestation, readiness, and secret availability into one readiness noun.

4. **Restore and reinit work still matters.**  
   Snapshot and restore systems keep showing that resumed execution needs explicit repair. The absence of optional power and the deferral of secret release are part of that repair truth.

## Resulting Foundry move
Do not decide yet whether the durable noun is `void route`, `borrow rail`, or `secret latch`.
For now, keep all three alive as specimen nouns and demand that they improve:
- one routed-capability specimen,
- one borrowed/owned handle specimen,
- and one attested-but-not-yet-released specimen.

## Fresh ideas worth stealing
- **void route** — explicit acknowledgement that a capability path is absent by design or product posture.
- **borrow rail** — a visible lane for useful foreign-backed handles that remain borrowed rather than localized.
- **secret latch** — a release gate that stays separate from attestation and from base readiness.
- **degraded readiness class** — resumed or foreign work can be running while still waiting on optional power or secret release.
