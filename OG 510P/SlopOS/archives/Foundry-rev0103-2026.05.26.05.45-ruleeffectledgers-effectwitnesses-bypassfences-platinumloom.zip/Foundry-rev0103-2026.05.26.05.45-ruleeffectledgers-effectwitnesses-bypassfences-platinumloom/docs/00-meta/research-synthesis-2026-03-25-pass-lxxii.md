# Research synthesis — pass LXXII

This pass stays conservative.
Foundry still should **not** freeze one archive-wide eligibility grammar, one universal exclusion algebra, or one flattering doctrine that every visible metric/report speaks for the whole world.
But it can steal one more durable lesson from quality-measure practice and SLO/error-budget design: **a design-phase datacube needs to distinguish why a subject or event was eligible for a metric/report, what kind of exclusion removed or narrowed other candidates, and where later readers must not treat the resulting number as if it spoke for the entire archive.**

The smallest durable seam from this pass is:
- **eligibility basis** — the compact statement of why a row, subject, event, or window belonged to the eligible universe for this metric/report: initial-population, profile-qualified, in-scope-attack-class, request-based-eligible-event, family-local-case-set, or another reviewed basis;
- **exclusion class** — the compact statement of how other candidates were narrowed away: profile-no, non-claim, denominator-exclusion, denominator-exception, out-of-scope, policy-waived, low-traffic-window, or another reviewed class;
- **whole-world fence** — the compact statement of what later consumers must not assume: not-all-profiles, not-all-subjects, not-all-events, summary-not-subject-list, no-archive-wide-compliance-claim, or forbidden.

These are still smaller than a universal denominator engine, one archive-wide KPI registry, or a promise that every scoped summary may be extrapolated into platform truth.
They simply stop an eligible slice from laundering itself into “this is the whole system.”

## Lessons we must learn from the past

### 1) Eligibility is a first-class semantic choice
HL7 measure-scoring guidance separates cohort, proportion, ratio, and continuous-variable measures and repeatedly frames them in terms of **initial population** and then narrower population rules.
That is exactly the lesson Foundry should steal.
Before a number exists, there is already a decision about which subjects or events were eligible to be counted.
A future cube should therefore preserve **eligibility basis** instead of pretending every count begins from the same world.

### 2) Exclusion and exception are not interchangeable
HL7 measure-population terminology distinguishes denominator exclusion from denominator exception, and it also distinguishes measure-population exclusion for continuous-variable measures.
That is a direct warning against one generic “filtered out” bit.
Foundry should preserve **exclusion class** instead of flattening waivers, exclusions, and non-eligibility into one tidy absence story.

### 3) Summary counts are smaller than subject lists
FHIR measure-report types distinguish **subject-list** from **summary** reports.
That is a strong pattern for Foundry.
A summary count may be useful without proving that the cube can identify, enumerate, or reconcile every contributing subject.
That belongs in a **whole-world fence**.

### 4) Error budgets depend on eligible events, not on vague totality
Google Cloud’s SLO guidance defines error budget as `(1 − SLO goal) × (eligible events in compliance period)` and says compliance is the ratio of good events to total events over the compliance period.
That is the stealable idea.
Even when a metric sounds global, it may only speak about the event class and compliance window that were eligible for that SLO.

### 5) Event definition changes the population story
The same Google SLO guidance distinguishes request-based SLOs from windows-based SLOs.
That means even two operationally similar numbers can be about different eligible populations: requests versus intervals.
Foundry should therefore keep **eligibility basis** explicit instead of assuming all “availability” or “success-rate” numbers share one denominator story.

### 6) Ratio measures can draw their parts from different worlds
HL7 measure-scoring guidance says ratio measures may draw numerator and denominator from different initial populations.
That is a brutal reminder that a neat ratio can still hide population mismatch.
A future cube should not let a visible rate or share erase the fact that its parts may have started from different eligibility rules.

## What to steal now
- an **eligibility basis** field or adjunct that says why a row, event, or subject belonged to the metric/report’s eligible universe;
- an **exclusion class** that keeps non-claim, out-of-scope, waived, and rule-based narrowing visibly different;
- a **whole-world fence** that blocks later readers from treating a scoped report, profile-specific total, or eligible-event ratio as archive-wide truth;
- and a habit of preserving the scoped report shape itself even when a summary card would prefer one flattering universal number.

## What to keep parked
Do not yet promote:
- one archive-wide eligibility grammar;
- one universal exclusion engine;
- one permanent platform-total denominator plane;
- or a promise that all scoped metrics can be lawfully compared or extrapolated across profiles, worlds, and report types.

## Resulting recommendation
The next healthy move is not “teach Foundry all population math.”
It is to let Foundry say, for scope-sensitive families:
1. **why this row or event was eligible,**
2. **how exclusion narrowed the candidate world,**
3. and **where the result must not be mistaken for whole-system truth.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart restraint from quality-measure and SLO practice.
