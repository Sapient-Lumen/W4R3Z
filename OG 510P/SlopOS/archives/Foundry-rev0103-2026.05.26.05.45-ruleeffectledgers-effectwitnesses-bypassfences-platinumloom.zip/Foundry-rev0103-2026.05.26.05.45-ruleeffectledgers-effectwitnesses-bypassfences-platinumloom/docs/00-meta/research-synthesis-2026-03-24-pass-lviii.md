# Research synthesis — pass LVIII

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from telemetry standards, unit-coding systems, and metrics practice: **a visible numeric value should not pretend to be self-explanatory unless the cube can say what unit it carries, what canonical scale it belongs to, and whether any conversion across scales is actually lawful.**

The smallest durable seam from this pass is:
- **unit witness** — the compact witness for the exact unit or count-like non-unit the visible value carries: bytes, seconds, ratio/unity, count-like item units, or an explicitly provider-native unit that the cube does not pretend to normalize away;
- **canonical scale** — the compact witness for the preferred interchange scale the family should use when values are meant to aggregate or compare cleanly: bytes instead of bits, seconds instead of milliseconds, ratio instead of percent, or explicit native-only scale when conversion is not meant to occur;
- **conversion fence** — the compact witness for whether conversion is linear, affine, display-only, contextual/policy-bound, or forbidden.

These are still smaller than a universal unit registry, a metrics product, or an automatic normalization engine.
They simply keep future Foundry rows from laundering unit-bearing values into naked numbers.

## Lessons we must learn from the past

### 1) Units belong in explicit metadata, not in name folklore
OpenTelemetry defines metric instruments with a **name**, **kind**, **unit**, and **description**, and its semantic-conventions guidance says metrics that already carry unit metadata generally should **not** repeat the unit in the metric name.
That is the lesson: the cube should carry unit meaning beside the value instead of hiding it inside field names or dashboard lore.

### 2) Canonical base scales make aggregation healthier
Prometheus and OpenMetrics both push toward base units such as seconds and bytes, say ratios should be expressed as **0–1 ratios rather than percentages**, and recommend exposing raw numerator and denominator where possible because that aggregates better than a pre-baked percent.
Foundry should steal that discipline: make the preferred canonical scale visible before pretty display transforms take over.

### 3) Some conversions are lawful, some are only display transforms, and some are not safe at all
OpenMetrics notes that if non-base units cannot be avoided and conversion is not feasible, the actual unit should still stay visible.
UCUM goes further: it defines unit expressions semantically, treats differently written but equivalent expressions as members of the same equivalence class, and also says arbitrary units are no longer comparable or convertible with other arbitrary units.
Foundry should therefore keep a **conversion fence** instead of pretending every unit-shaped value can be normalized safely.

### 4) Ratios and utilization deserve a smaller honesty rule than percentages in dashboards
Prometheus says percent-like quantities should generally be stored as ratios and that the usual pattern is `A_per_B`.
That means the cube should keep the canonical scale at ratio/unity even if some shell or export chooses to render `87%`.

## What to steal now
- a **unit witness** beside any future value family whose meaning depends on bytes, seconds, ratios, count-like non-units, or provider-native units;
- a **canonical scale** so display-friendly milliseconds, bits, and percentages do not quietly become interchange truth;
- a **conversion fence** so linear, affine, contextual, and forbidden conversions stay visibly different;
- a habit of keeping raw additive numerators/denominators closer to truth than pre-baked percentages where possible;
- and a habit of treating provider-native credits, request units, and other arbitrary units as native-only unless an explicit conversion contract exists.

## What to keep parked
Do not yet promote:
- a cube-wide unit registry with mandatory universal codes for every family;
- automatic cross-family conversion or rescaling;
- one global policy for pretty display units;
- a general valuation plane for arbitrary/provider-native units;
- or a promise that every unit-bearing row is safely comparable just because it is numeric.

## Resulting recommendation
The next healthy move is not “build a universal unit system inside the cube.”
It is to let Foundry say, for any future value-bearing family:
1. which **unit witness** the visible value carries,
2. which **canonical scale** the family prefers for interchange and aggregation,
3. and what **conversion fence** limits any normalization or comparison.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from OpenTelemetry, Prometheus/OpenMetrics, and UCUM.
