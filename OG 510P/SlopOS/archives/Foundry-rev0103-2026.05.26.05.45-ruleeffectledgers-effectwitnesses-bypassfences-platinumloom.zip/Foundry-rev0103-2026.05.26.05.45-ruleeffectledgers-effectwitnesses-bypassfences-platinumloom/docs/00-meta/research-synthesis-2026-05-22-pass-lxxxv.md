# Research synthesis — 2026-05-22 pass LXXXV

Focus: **semantic diffs, regression locks, and tamper corpus gates**.

The prior pass made refused egress attempts durable. This pass tightens the revision boundary: a sidecar, refusal receipt, or egress manifest can pass today and still become dangerous tomorrow if a later revision changes its meaning while preserving friendly file names, fixture ids, or success-shaped check output.

## New external pressure added

- `EXT-RFC8785-JCS` supplies a compact discipline for canonical JSON bytes and digestable representations. Foundry should borrow the canonicalization instinct without pretending a digest proves semantic approval.
- `EXT-RFC6902-JSON-PATCH` supplies a path-scoped mutation vocabulary useful for fixture tampering and diff examples. Foundry should borrow the operation vocabulary without treating a patch as a reviewed semantic migration.

## Existing pressure reused

- `EXT-W3C-PROV-DM-2013` keeps revision evidence smaller than quality, reliability, or trustworthiness judgments.
- `EXT-OPENLINEAGE-FACETS-2026` keeps run/result facets useful while preventing one lineage graph from owning every semantic boundary.
- `EXT-JSON-SCHEMA-CORE-2026` keeps schemas as validation aids rather than ontology or compatibility authority.
- SlopOS canonical-byte and corpus/checker patterns pressure Foundry to make tampering deterministic instead of relying on prose memory.

## What rev0084 still allowed

Rev0084 could prove that a thin surface either carried residue or produced a refusal receipt. It did not yet prove that a future revision would detect when someone:

- dropped classification pins but kept the same sidecar id;
- changed a receipt rule id without explaining compatibility;
- reused an egress-manifest digest after mutating attempts;
- downgraded a loss profile from sidecar-only to allowed drill-through;
- changed a materialization or classification cut without a migration witness;
- genericized problem details so refusal looked implementation-shaped again; or
- removed the non-SlopOS consumer pressure that justified widening a receipt/sidecar field.

Those are regression failures, not ordinary schema failures. They are exactly the kind of failures a design-phase datacube tends to miss because every individual JSON object can still look well formed.

## Speculative read

Foundry now needs a **revision boundary contract** beside its egress contract:

```text
sidecar/receipt/manifest = what one egress attempt meant
semantic diff manifest   = what changed between two revisions
regression lock          = what must not silently change
tamper corpus gate       = which known dishonest mutations must fail
migration witness        = why a breaking-looking change is intentionally bounded
verdict                  = still outside Foundry
```

The important move is negative: do not let version bumps, digest strings, schema passes, or pretty diffs masquerade as compatibility. A digest says bytes changed or stayed the same. It does not say the semantic residue is still lawful for the same consumer.

## New specimen pressure

Add specimen 79 around semantic diff manifest, regression lock, and tamper corpus gate. The fixture must prove at least:

- baseline and candidate artifacts name revisions, roles, canonicalization posture, and digests;
- a non-SlopOS consumer exists before widening egress/receipt fields;
- additive diff entries can pass only when named as additive and witnessed;
- breaking or meaning-changing entries require a migration witness or a refusal posture;
- regression locks name protected paths and failure codes;
- tamper cases use path-scoped mutation operations; and
- the checker fails if required tamper cases, consumers, digests, or witnesses disappear.

## Recommendation

Keep semantic diff manifests and regression locks fixture-local for now. They should not become a global migration framework, schema registry, JSON Patch dialect, data-contract runtime, or cryptographic trust system. Their narrow job is to stop Foundry from declaring egress semantics stable merely because the current fixture corpus is tidy.
