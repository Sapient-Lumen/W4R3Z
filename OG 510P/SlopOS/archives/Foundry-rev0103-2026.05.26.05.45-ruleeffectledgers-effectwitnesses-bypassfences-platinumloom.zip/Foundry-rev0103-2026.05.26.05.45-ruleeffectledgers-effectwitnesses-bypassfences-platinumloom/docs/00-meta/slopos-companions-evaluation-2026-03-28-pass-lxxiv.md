# SlopOS + companions evaluation — pass LXXIV

This pass checks whether the pressure for a bigger semantic-layer story is finally strong enough to justify another Foundry specimen.

## Verdict
Not yet.
The pressure is real, but the healthiest move is still to **collect brilliant ideas without promoting them too early**.

The current round of SlopOS + companion pressure does justify two parked candidate seams:
- **serving lane / acceleration witness / raw fallback fence**
- **reference kind / mutable-head fence / historical-tag witness**

What it does **not** justify yet is a permanent semantic-layer taxonomy, one archive-wide acceleration doctrine, or a new guarantee that a floating branch/head is good enough for durable replay.

## What SlopOS keeps teaching

### 1) Design-phase family maps are discovery truth, not state truth
SlopOS keeps adding family maps, family indexes, and boundary coverage surfaces precisely so meaning cannot hide in accidental corners.
That is a strong datacube lesson.
A discovery/index surface is useful, but it is not automatically the same thing as current live state or canonical history.

### 2) Descriptor-not-state pressure is already everywhere
The lease-descriptor live-state seam, request-state adjunct surfaces, and many provider-native evidence boundaries all repeat the same warning: an issued descriptor, request artifact, or imported provider field is often **not** a current-state oracle.
That is why Foundry should stay suspicious of promoting any “latest summary table” or “current branch view” into durable truth too early.

### 3) SlopOS is still changing its own family boundaries
Because SlopOS itself is still in design phase, a heavy semantic-layer move would freeze the wrong thing too soon.
The right response is to keep better witness surfaces around meaning, serving path, and pinned cuts while resisting premature registry growth.

## What the companions keep teaching

### Harbor
Harbor’s datacube work keeps pressure on explicit measurement semantics, aggregation semantics, exactness, and time axes.
That strengthens the case that Foundry should keep thin semantic/member posture and serving-lane humility explicit instead of flattening them into one generic metrics bag.

### Ward
Ward keeps teaching that a familiar repeated question may still be raw, retained-summary, hybrid, or display-rollup truth.
That directly reinforces the parked **serving lane** idea.

### ViewFS
ViewFS keeps preview surfaces, frozen manifests, handles, and durable receipts visibly different.
The datacube analogue is that a row-preserving answer, a served summary, and a replayable pinned export should stay visibly different too.

### Steward
Steward keeps request-state, live state, and exact mutable-basis approval posture separate.
That reinforces the parked **mutable-head fence** idea: a moving target and an exact cut are not the same truth even when the UI wants one tidy “latest” noun.

### Schell and Helm
Both keep showing that humane surfaces, overlays, previews, and helper lanes can be useful while staying smaller than durable underlying truth.
That is another argument for serving-lane and pinned-cut discipline before any larger semantic-layer system is admitted.

## Recommended Foundry posture right now
1. **Do not add specimen 70 yet.**
   The right move is a consolidation pass, not another promotion.

2. **Park two candidate seams explicitly.**
   Keep them in questions/followthrough so they stay discoverable without pretending they are already archive law:
   - serving lane / acceleration witness / raw fallback fence;
   - reference kind / mutable-head fence / historical-tag witness.

3. **Require one real SlopOS consumer before promotion.**
   Good candidates would be:
   - one support/export tile or family-coverage summary that can be served from a derived/accelerated lane;
   - one publish/replay/report surface that wants branch/head convenience but still needs exact pinned-cut truth.

4. **Keep vendor nouns and physical layouts smaller than Foundry law.**
   Semantic-model YAML, aggregate tables, projections, rollups, branch labels, and validation artifacts are all useful teachers; none of them should be copied whole into permanent archive ontology yet.

## The low-regret next step
Use the repo/process surfaces to keep these candidate seams alive, keep researching, and wait for one concrete SlopOS export/summary lane plus one sibling-cube replay/branch case to converge on the same noun family.
That is enough progress for this revision while SlopOS itself is still moving.
