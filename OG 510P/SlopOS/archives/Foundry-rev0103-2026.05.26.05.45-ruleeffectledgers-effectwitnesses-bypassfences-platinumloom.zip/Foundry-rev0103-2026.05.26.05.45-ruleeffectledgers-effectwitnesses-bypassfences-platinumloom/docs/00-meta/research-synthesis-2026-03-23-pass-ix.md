# Research synthesis — 2026-03-23 pass X

This pass focused on another foreign-ground design trap: systems make a foreign thing feel smooth and then quietly stop telling the truth about where it actually lives and how it becomes available.

## New lessons from outside systems

### 1) WIT resources are a clean model for exterior things
The component-model docs describe resources as functionality implemented only on one side of a component boundary, often in another component or the host. Foundry should steal this aggressively: a **resource handle** can feel pleasant while still remaining visibly exterior.

### 2) Availability is part of the contract, not a runtime afterthought
Fuchsia’s capability-availability docs make a valuable point: some routed capabilities are essential and should fail early if not present, while others are optional. Foundry should treat **availability rail** as part of foreign-ground truth instead of letting capability absence turn into late runtime folklore.

### 3) Virtualization power should be routed into the product/session
Fuchsia RFC 0210 explicitly routes the ability to create virtual machines into a product session. That is a strong Foundry lesson: the **virtualization grant** should be explicit, routed, and inspectable rather than treated as ambient host background.

### 4) Policy split still matters after attestation
Confidential Containers’ current docs still distinguish attestation service policies from KBS resource policies. Foundry should keep that split while adding clearer language for routed power and handle availability.

## New lessons from SlopOS and companions

### SlopOS
- `rfcs/0009-component-manifests-and-capability-routing.md` remains the strongest native pressure here: capability routing as data still beats ambient host assumption.
- `microvm-generation-witness-posture-v0.md` and `microvm-restore-repair-barrier-posture-v0.md` continue to reinforce that foreign continuity claims need humility.
- The capability and foreign-ground posture files support pass X’s desire to keep routed power, runtime evidence, and adoption distinct.

### Siblings
- Harbor keeps the membrane story separate from the realization story.
- Ward keeps evidence and verdict distinct, which matters even more once foreign handles feel smooth.
- Schell and Helm both argue for inspectable adoption and visible residue instead of ambient helper folklore.

## Brilliant ideas worth stealing carefully

1. **Resource handle** — a typed exterior handle to something implemented elsewhere.
2. **Availability rail** — required versus optional routed power visible before launch.
3. **Virtualization grant** — explicit routed power to create foreign ground.
4. **Failure-before-launch** — capability absence caught early and truthfully.
5. **Exterior-resource warning** — a reminder that smooth handles are still not native objecthood.

## Current recommendation
Foundry still should not freeze a universal runtime descriptor.

The safer move is:
- keep routed power, resource handles, availability expectations, runtime evidence, and adoption distinct;
- use specimen flow 06 to test whether resource handle and availability rail deserve first-class Foundry vocabulary;
- and promote only the nouns that survive both component-model and virtualized-ground specimens without pretending smoothness equals native truth.
