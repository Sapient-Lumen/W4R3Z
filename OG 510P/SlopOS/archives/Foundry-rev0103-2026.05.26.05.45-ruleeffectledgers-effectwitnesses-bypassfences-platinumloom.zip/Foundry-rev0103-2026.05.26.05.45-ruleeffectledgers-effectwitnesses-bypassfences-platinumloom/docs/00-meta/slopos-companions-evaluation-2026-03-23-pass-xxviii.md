# SlopOS / companions evaluation — pass XXVIII

Foundry still looks justified as its own companion cube, and this pass sharpens another seam that SlopOS is already culturally prepared to respect: **current or rollback-relevant basis truth is still smaller than retention and collectability truth.**

## What the current cube ecology keeps proving
- **SlopOS** already says the important part out loud in its configuration pipeline: keep the privileged core out of GC, let user space decide retention, and keep at least `N` last-known-good generations plus any pinned audit targets. That is almost a direct invitation for Foundry to preserve the meaning seam without importing a whole cleanup controller.
- **SlopOS** is still in the design phase, which makes this cheap to preserve now. If generations, rollback selectors, state snapshots, and evidence bundles quietly fall under one vague “old stuff gets cleaned up later” story, later docs will have to unteach that ambiguity.
- **ViewFS** reinforces the same house style from another direction. Its seam map already distinguishes removing a name, moving to recoverable trash, retaining because of an explicit root, and actually purging collectible storage. Foundry can borrow that discipline for foreign-basis history without importing ViewFS object semantics.
- **Steward** is another healthy sibling pressure: its retention surface keeps remembered-but-useful state different from authoritative current state. Foundry can apply the same anti-folklore instinct to rollback generations, snapshots, and audit material.
- **Ward** remains the right place for verdicts about evidence; Foundry only needs the smaller truth that evidence or prior basis material may remain intentionally retained even after currentness moved on.

## Pressure on Foundry
Foundry should not invent a store manager, background collector, or one universal delete/purge workflow.
The stronger move is to keep one specimen where:
1. a basis stops being current,
2. it still survives because of an explicit **retention root**,
3. an explicit **reclaim fence** still blocks ordinary cleanup,
4. some **cleanup debt** must clear before release becomes honest,
5. and only then may ordinary reclamation proceed.

## Collected but parked ideas
This pass also surfaces two good adjacent ideas that should stay parked:
- **collectability class** for compact retained-versus-collectible labeling;
- **release witness card** for compact residue that retention was intentionally dropped after cleanup.

Those ideas are real, but they do not yet deserve durable Foundry vocabulary.

## Promotion restraint
Do not promote `retention root`, `reclaim fence`, or `cleanup debt` unless they improve:
- one generations-plus-garbage-collection specimen,
- one pinned deployment, snapshot, or lease-protected content specimen,
- and one delete-needs-cleanup specimen where intended removal still stays smaller than actual collectability.
