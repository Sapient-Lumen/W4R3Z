# SlopOS and companions evaluation — 2026-05-21 pass LXXXIII

Focus: whether Foundry can make the datacube seams from specimens 70 through 76 survive SlopOS-facing egress.

## SlopOS pressure

SlopOS now has strong boundary-family, singleton-contract, observation/export, diagnostic snapshot, portal, capshell-result, replay, resume, and append/truncation discipline. That creates a useful mismatch: SlopOS often has executable boundary guards, while Foundry's late datacube seams have mostly prose guards.

Foundry should adopt the SlopOS style here: compact docs, small schemas, fixtures, deterministic checkers, and refusal cases.

## Binding map pressure

The new binding map keeps Foundry from absorbing SlopOS authority:

- SlopOS owns boundary posture, receipts, profile-local authority, portal/replay contracts, and evidence emission.
- Foundry owns the semantic residue that says what an emitted result means after query, rollup, materialization, disclosure, adjustment, reconciliation, or classification drift.
- Ward, Harbor, Steward, Schell, ViewFS, and Helm own verdict, membrane, lifecycle, retention, artifact, and repair consequence respectively.

## Companion read

| Companion | Foundry may consume | Foundry must not absorb |
| --- | --- | --- |
| Ward | verdict/appraisal labels as pinned classifications | trust verdicts or consequence decisions |
| Harbor | outside-fact, correction, status, and aftermath residue as source cuts | membrane truth or external status authority |
| Steward | retry/replay/provisional reconciliation states as status inputs | lifecycle authority or effect finality |
| Schell | retention/minimization budgets constraining drill-through | forgetting authority or privacy policy engine |
| ViewFS | artifact/projection/semantic-extraction outputs as derived surfaces | filesystem or object identity model |
| Helm | repair-attempt traces and remainder bridges as operational evidence | repair custody or incident workflow |

## What changed in this pass

- Added a SlopOS/Foundry binding map so SlopOS surfaces name the Foundry residue they need without handing Foundry authority it should not own.
- Added specimen 77 to force a result-sidecar-or-refusal posture across table, chart, JSON, CSV, markdown, support-card, and dashboard egress.
- Added v0 JSON schemas for result envelopes and semantic sidecars.
- Added fixture bundles for specimens 70 through 76 plus one cross-specimen SlopOS support-card fixture.
- Added deterministic checkers for residue sidecars and specimen fixtures.
- Added a decision-debt index so repeated promotion questions are sorted by executable blocker rather than chronology alone.

## Recommendation

Treat `make check` as the minimum bar for future Foundry datacube revisions. New noun promotion should either include a fixture case that fails without the noun, or explicitly state why the noun remains prose-only.
