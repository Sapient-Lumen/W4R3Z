# SlopOS + companions evaluation — pass LXVII

This pass checks whether **contribution basis, fanout class, and reaggregation fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a universal join planner, a giant bridge-table registry, or one archive-wide rule that every count-like surface must reduce to the same entity grain.

## Why SlopOS pressures this seam now

### 1) SlopOS already has multi-signature evidence where “record count” and “signed-subject count” are different truths
`docs/30-architecture/signature-signer-acceptance-boundary-v0.md` is the clearest pressure point.
It says multiple signatures are exact signer evidence, that duplicate signatures do not auto-count by portable rule, and that signer-set/quorum acceptance stays explicit local policy.
A future Foundry panel therefore needs to distinguish at least:
- signature-record count,
- distinct signed-subject count,
- and accepted-signer-association count.
Those are different **contribution bases**, not one flattering generic total.

### 2) SlopOS already has evidence-set families where multiple attached artifacts do not become one native closure
`docs/30-architecture/provenance-evidence-set-boundary-v0.md` and `sbom-vex-evidence-set-boundary-v0.md` both keep multiple exact artifacts smaller than one native completeness or applicability closure.
That is classic **fanout class** pressure.
One subject may connect to several provenance or SBOM/VEX artifacts, so grouping by evidence kind can multiply a subject without proving that subject-level counts are additive across kinds.
Foundry needs a way to say when the visible answer counts association rows versus distinct subjects.

### 3) SlopOS already keeps family-index counts and member-doc counts at different levels of description
`docs/30-architecture/boundary-family-map.md` and the many `*-boundary-index.md` family surfaces make this easy to miss.
A family count is a higher-grain management view; member-doc counts live below it.
Those two levels are both useful, but they do not share one natural regrouping law.
That is exactly where a **reaggregation fence** earns its keep.
Some family-level summaries should refuse drilldown arithmetic instead of pretending the child rows inherit the same measure semantics.

### 4) SlopOS profile matrices are explicitly guidance-shaped and can expose the same underlying boundary surface through several higher-grain cuts
`docs/00-meta/profile-posture-matrix.md` and `profile-claim-matrix.md` are intentionally conservative and non-forking, but they are still profile-shaped overlays over many underlying surfaces.
If a future Foundry export says “how many boundaries are required by profile C” and another says “how many belong to family D-ATTEST,” those are valid higher-grain cuts over overlapping underlying docs.
Without **fanout class** and **reaggregation fence**, support views will be tempted to sum them into fake total coverage.

### 5) Companions reinforce the same restraint
Ward keeps snapshot/retraction stories smaller than one magical complete truth.
ViewFS repeatedly keeps object/history and lineage surfaces visibly scoped.
Harbor and Steward both carry multiple nearby receipts or policy-shaped artifacts without promising that attachment multiplicity naturally defines one additive entity count.
Together they say the same thing: neighboring archives already produce bridge-heavy and higher-grain summaries, so Foundry should preserve the counted-once basis before those summaries start cross-pollinating.

## What to steal into Foundry

### contribution basis
A compact statement of what got counted once.
Examples:
- `subject_digest_distinct`
- `signature_record_row`
- `subject_evidence_association_row`
- `family_target_row`
- `approx_subject_sketch`

### fanout class
A compact statement of which relationship shape affected the answer.
Examples:
- `none_native`
- `one_to_many_deduped`
- `bridge_many_to_many`
- `higher_grain_projection`
- `approx_decomposed`
- `chasm_refused`

### reaggregation fence
A compact statement of what regrouping is still honest.
Examples:
- `native_rollup_ok`
- `same_basis_only`
- `do_not_group_below_family`
- `same_sketch_family_only`
- `forbidden`

## Why this should stay narrow
Foundry does **not** need to force every SlopOS family into a star-schema exercise or bridge-table DSL.
Many current neighboring surfaces only need enough honesty to prevent three common lies:
- “every count is counting the same thing once,”
- “multi-attachment evidence is naturally additive across categories,”
- and “higher-grain management summaries can always be drilled into lower-level arithmetic.”

Contribution basis, fanout class, and reaggregation fence are enough to stop those lies without freezing one permanent hierarchy or one giant semantic layer.

## Recommendation
Promote this seam only as a **small reversible honesty layer** for bridge-heavy, evidence-set-heavy, and higher-grain summary families.
Keep any wider join planner, bridge algebra, or universal hierarchy law parked until at least two real consumers outside the current SlopOS pressure set prove they are necessary.
