# Research synthesis — 2026-05-23 pass XCI

Focus: **distribution manifests, adoption receipts, and orphan-copy fences**.

The previous pass made replacement readmission consumer-local. This pass covers the next scar: after a replacement sidecar is readmitted, downstream surfaces can still keep old cached CSVs, notebook extracts, delegated-worker copies, or projected tiles alive. Foundry needs a tiny way to say what was distributed, who adopted it, who refused or quarantined it, and which orphaned copies are still blocked.

## New outside pressure

- `EXT-CLOUDEVENTS-2026` gives a useful common-envelope instinct for event metadata across services and systems. Foundry should steal the idea that movement events need stable identity, source, type, subject, time, and data, without becoming an eventing standard or transport binding.
- `EXT-RFC9111-CACHING` keeps cache storage, freshness, revalidation, private/public scope, and stale behavior separate. Foundry should steal the stale/fresh/revalidate scar without turning orphan-copy fences into HTTP cache-control.
- `EXT-OCI-DISTRIBUTION-SPEC-REFERRERS` shows a distribution graph can attach artifacts to a subject digest through explicit references. Foundry should steal the subject-linked artifact posture without becoming an OCI registry, package manager, or supply-chain graph.
- `EXT-SCITT-ARCHITECTURE-2026` and `EXT-RFC9162-CERTIFICATE-TRANSPARENCY` reinforce the difference between making statements visible and proving the statements are accurate, ordered as issued, or semantically adopted. Foundry should steal accountability/log visibility without becoming a transparency service, log auditor, or trust framework.

## What rev0090 still allowed

Rev0090 could prove that a replacement was safe to re-admit for a named consumer/use. It did not yet prove that the admitted carrier actually displaced old relying surfaces. A future editor could still:

- point to a readmission gate while an old dashboard CSV remains current;
- deliver a support bundle and treat delivery as adoption;
- refresh a cache tile while leaving old extracted rows available for joins;
- let Ward partially adopt a preview and accidentally show it as a verdict-ready green surface;
- let ViewFS display a projection and accidentally treat display as custody;
- let a delegated worker keep a recalled local copy after its warrant was revoked;
- miss the propagation window because all target consumers did not receipt or fence; or
- use an external-audit receipt as proof that every consumer has adopted the new carrier.

Those are distribution/adoption failures, not readmission failures.

## Speculative read

Foundry needs a small **post-readmission circulation seam**:

```text
distribution manifest = carrier digests, superseded carriers, target consumers/surfaces, channels, propagation window, required receipts/fences
adoption receipt      = one consumer/surface saying adopted, partial, refused, quarantined, or superseded with residue and blocked uses
orphan-copy fence     = one stale/unacknowledged copy blocked until clearance evidence exists
delivery event        = useful evidence, not semantic adoption
cache refresh         = useful evidence, not repair or current truth
```

The negative move matters most: a readmission gate is not deployment. Deployment is not adoption. Adoption by one consumer is not transitive release.

## New specimen pressure

Add specimen 85 around distribution manifests, adoption receipts, and orphan-copy fences. The fixture must prove at least:

- every distribution attempt links to readmission gates, carrier ids/digests, superseded carrier digests, target consumers, target surfaces, required receipts, and propagation windows;
- every target consumer/surface leaves an adoption receipt, refusal/quarantine/partial receipt, or orphan-copy fence;
- adoption receipts carry local gate refs, residue carried, previous-carrier retirement posture, admitted uses, blocked uses, and non-promises;
- old cached/exported/notebook/delegated/projection copies are fenced or retired as history;
- partial adoption remains partial and cannot become Ward verdict, ViewFS custody, public release, or audit signoff;
- delivery channels remain evidence rather than truth; and
- negative cases cover missing manifest, missing receipt, stale copy without fence, expired propagation window, digest mismatch, target widening, channel-as-truth, and adoption-as-approval.

## Recommendation

Keep distribution/adoption fixture-local and reversible. Do not promote a message bus, registry, cache API, release workflow, package distribution protocol, catalog, transparency log, audit package, or sibling-cube status model. The narrow Foundry job is to prove that post-readmission circulation preserves semantic residue and leaves stale stragglers fenced.
