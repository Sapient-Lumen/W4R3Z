
# SlopOS + companions evaluation — pass LXXXII

This pass evaluates Foundry's next SlopOS-facing datacube seam: classification/version honesty for category-valued dimensions and local taxonomies.

## Verdict

Promote one narrow seam: **classification pin**, **crosswalk witness**, and **code-drift fence**.

This is a conservative promotion because it does not pick a taxonomy engine, SKOS model, SDMX registry, FHIR terminology server, OTel semantic-convention toolchain, or universal code-list family. It only requires a categorical value to say which scheme/version made it meaningful, whether a mapping was used, and where later consumers must not overread code or label sameness.

## SlopOS pressure

SlopOS already creates classification-drift pressure even before Foundry has a finished cube:

- boundary families, interface surfaces, profile letters, replication classes, policy classes, support-card outcome classes, observation-export classes, and redaction reasons are all category-shaped design artifacts;
- rev0695's FedCM/browser-federation boundary and the nearby Digital Credentials work introduce terms such as provider, relying party, account hint, browser mediation, presentation, issuer, verifier, trust mark, and credential response that are likely to split or rename as specs and local SlopOS boundaries settle;
- `CH-OBS` and `CH-OBSPOL` pressure future support panels to group by event family, redaction profile, result/outcome class, audience, and support-card reason;
- `CH-SNAPSHOT` and support bundles need manifest/bundle/diagnostic categories that may start local and later be harmonized;
- Phase/profile artifacts such as D-PART, D-CONC, CH-CFG, CH-REPLCONTRACT, and replication classes show that SlopOS already prefers explicit named surfaces over ambient prose, but that does not make early names timeless;
- SlopOS is still design-phase, so freezing a perfect taxonomy would be premature while omitting classification pins would create silent history rewrite.

## Companion pressure

- **Steward** has reconciliation and condition/cause posture that can be grouped under lifecycle/status codes. Foundry should preserve which status vocabulary cut was used rather than flattening provisional/confirmed/lost/unknown labels.
- **Harbor** has contract subsets and lineage guards; contract-family names and evidence grades are category-shaped but not all globally comparable.
- **Ward** has appraisal/verdict/status words that are especially tempting to reuse as generic health categories; Foundry should not let a Ward verdict label become a Foundry classification without a pin.
- **ViewFS** exposes package, manifest, prefix, folder, and list-shape categories; folder labels and prefix badges should not become concept identity.
- **Helm** and **Schell** produce operational lane/helper/category names that are useful for UI and process, but those names should not be borrowed into Foundry as durable categorical truth without a code-system cut.

## Why this does not duplicate existing specimens

- Specimen 58 covers schema translation. Specimen 76 covers category/code-list member meaning inside a row or dimension value.
- Specimen 61 covers historical interpretation cuts. Specimen 76 covers the classification/version/crosswalk evidence that often forms part of such a cut.
- Specimen 69 covers bands and thresholds. Specimen 76 covers arbitrary categorical members, including non-ordinal classes and local taxonomies.
- Specimen 71 covers hierarchy/rollup. Specimen 76 refuses to treat classification parentage or correspondence as aggregation law unless rollup evidence separately allows it.
- Specimen 75 covers totals and reconciliation. Specimen 76 prevents totals from reconciling across old/new classification members by bare label or code.

## Recommendation

Add specimen 76 and update source hygiene accordingly. Keep the nouns local to category-valued dimensions, profile/outcome/status/classification fields, imported semantic conventions, code-list-backed attributes, support-card groups, and exports where a classification cut or crosswalk changes interpretation.

Do not widen the seam into a taxonomy product or ontology until at least two unrelated consumers need the same classification-pin shape.

## Follow-up pressure to keep open

- Test one SlopOS boundary-family rename where old and new labels are losslessly crosswalked.
- Test one SlopOS outcome-class split where old rows cannot be projected into the new split without a reviewed backcast rule.
- Test one redaction/status/profile class imported from a local CH-* surface that later becomes shared across support cards.
- Test one external semantic convention import where a deprecated or renamed attribute must stay queryable under its native pin.
- Test one table that balances under an old classification but not under a new mapped classification.
- Test one JSON/chart export that can carry only labels and therefore must either include a sidecar or refuse classification-free flattening.
