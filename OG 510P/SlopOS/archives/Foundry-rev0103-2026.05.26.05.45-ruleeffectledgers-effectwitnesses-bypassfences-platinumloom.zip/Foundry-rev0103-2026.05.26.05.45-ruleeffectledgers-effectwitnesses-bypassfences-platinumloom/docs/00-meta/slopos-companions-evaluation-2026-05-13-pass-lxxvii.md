# SlopOS + companions evaluation — pass LXXVII

This pass evaluates Foundry's next SlopOS-facing datacube seam: how hierarchy, rollup, and grouping evidence travels with a result without creating a giant dimension model.

## Verdict

Yes, but only this small seam.
Foundry should add specimen 71 around **hierarchy scope**, **rollup path**, and **aggregation guard**.

This is a conservative promotion because it does not choose a calendar authority, geography engine, semantic-layer taxonomy, code-list model, XBRL/SDMX/RDF representation, or storage layout.
It simply gives SlopOS and companion cubes a way to say why a parent row, weekly bucket, geographic total, code-list group, or drilldown was lawful for one result.

## What SlopOS keeps teaching now

### 1) Attribute queries need dimension pickers without phantom slices
SlopOS CH-ATTRQ is closed, bounded, typed when a schema digest exists, snapshot-first, and handle-returning.
That posture pairs well with an availability basis: a UI can show valid dimension choices without pretending every legal code is populated under the current cut.

### 2) View objects and label atoms reject ambient hierarchy
SlopOS view objects keep name resolution explicit, and the namecert label-atom boundary rejects hidden dotted hierarchy, wildcard matching, and path grammars.
Foundry should preserve that same anti-folklore in datacube rollups: parentage must be declared by a hierarchy scope, not inferred from names, punctuation, paths, or display indentation.

### 3) Security-time posture keeps calendar authority out of the OS core
SlopOS already rejects a portable timezone/calendar admin plane for its security-time posture.
Foundry should not sneak one back in via datacube buckets.
Weekly, fiscal, reporting-year, and timezone-sensitive summaries need a calendar lens local to the result.

### 4) Trace processing shows why config digests matter
SlopOS trace processors preserve processor/config/predicate digests.
Foundry should copy that discipline for rollups: when a result is grouped or summarized, carry the rollup recipe digest and hierarchy version instead of relying on the current code name.

### 5) Boundary indexes show how to avoid hidden families
SlopOS boundary indexes keep companion import boundaries enumerated.
For Foundry, this argues against implicit hierarchy expansion: no unlisted parent families, no wildcard code-list rollups, no storage-folder discovery as dimension discovery.

## What the companions add

### Harbor
Harbor's temporal witnesses and lineage guards argue for membership-cut and reparenting posture on rollups.
A parent total should say whether it uses as-observed membership, as-of-cut membership, restated-current membership, or a bridge.

### Ward
Ward's appraisal split argues that a rollup can be well-formed and still not be judged fit for a purpose.
Aggregation guard is a data-shape witness, not an approval verdict.

### ViewFS
ViewFS's manifests and folder ghosts warn against treating path layout as truth.
Foundry should put a storage-layout fence around Hive partitions, chunk grids, and manifest placement.

### Steward
Steward's approval and reconciliation posture argues against treating a rollup preview as acceptance.
A grouped support card can assist review without becoming the approved plan, allocation, or adjudication.

### Schell and Helm
Schell and Helm keep helper overlays and shell views smaller than substrate semantics.
Foundry should let dashboards and support cards display hierarchy, but require a rollup path before that hierarchy becomes reusable cube meaning.

## Promoted specimen 71

### hierarchy scope
Candidate use:
- SlopOS attribute-query dimension pickers;
- support-card grouping menus;
- code-list backed status summaries;
- calendar/geography drilldown surfaces;
- sibling-cube exchange where the parent family is known but not native.

Refusals:
- no global taxonomy or path language;
- no parent inference from names, dots, folders, or indentation;
- no default member silently replacing unknown/not-applicable values;
- no valid-code-list member treated as populated coordinate.

### rollup path
Candidate use:
- weekly/monthly/fiscal result buckets;
- region/country/state/county/grid-cell summaries;
- parent rows over code lists or organizational structures;
- trace or support-card counters summarized above source grain.

Refusals:
- no current-parent hindsight rewrite without a restatement lane;
- no calendar bucket without week/fiscal/timezone/reporting-year lens;
- no geography parent without boundary/grid/version cut;
- no physical partition path as semantic rollup path.

### aggregation guard
Candidate use:
- additive measures;
- semi-additive balances;
- distinct counts and sketches;
- ratio-derived values;
- bridge-shaped many-to-many summaries;
- masks, policy-narrowed results, sampled values, and banded outputs.

Refusals:
- no sum-until-it-runs doctrine;
- no drilldown below lawful grain;
- no ratio, distinct count, sampled, masked, or banded value treated as simple additive fact;
- no validation success or query-result convenience as aggregation permission.

## Low-regret next tests

- Run specimen 71 against one SlopOS attribute-query dimension picker with unavailable choices.
- Run it against one support-card weekly summary that crosses an ISO/Gregorian/fiscal boundary.
- Run it against one geography-like grouping where administrative, statistical, legal-boundary, and grid containment meanings differ.
- Run it against one Harbor temporal membership change and one ViewFS folder/partition layout that looks hierarchical but is not semantic parentage.
- Keep the seam small until two unrelated consumers need the same fields.
