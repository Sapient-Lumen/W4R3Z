# Research synthesis — pass LXXXI

This pass goes deeper on a datacube failure mode that appears after grain, rollup, materialization, aggregate release, and observedness have all been treated carefully: a table can still look more reliable than it is because its totals, subtotals, margins, mirrors, balances, and residuals were flattened into one happy number.

The danger is not only arithmetic error. In a SlopOS-facing Foundry cube, support cards will want compact tables over `CH-OBS` counters, trace summaries, diagnostic snapshot bundles, redacted exports, support-bundle manifests, quarantined derived artifacts, Steward-style reconciliation state, and sibling renderers. Some totals will be native. Some will be recomputed from components. Some will be supplied by a different processor. Some will fail only because of rounding, suppression, redaction, imputation, stale materialization, or a changed policy lens. Some will pass arithmetic while mixing incompatible cuts.

The low-regret move is small: when a result relies on a total, subtotal, margin, mirror, invariant, or balance check, carry a **control-total card**, a **reconciliation witness**, and a **balance fence**.

Specimen 75 is therefore added. It is a reconciliation seam, not an accounting engine, statistics validator, VTL/XBRL clone, or proof system.

## Lessons we must learn from the past

### 1) Validation has levels; `total = parts` is only one kind of check
Eurostat separates structural validation from content validation and then climbs through within-dataset consistency, cross-dataset consistency, mirror checks, cross-domain checks, and external-organisation checks. Foundry should steal the layered view. A total check is useful, but it does not prove the table is true, complete, current, privacy-safe, or comparable.

### 2) Validation rules need owners and responsibilities
Eurostat's validation posture emphasizes documented rules, common standards, and assigned responsibilities. Foundry should not treat a reconciled table as self-explanatory. A balance result needs to say which rule or profile was used, which cut it applied to, and who/what produced the check.

### 3) Calculation relationships are not universal arithmetic truth
XBRL Calculations 1.1 exists because simple summation relationships are important and historically painful: rounded values and duplicate facts can create false failures or missed failures. It also makes calculation inconsistencies non-fatal to the report. Foundry should steal the humility: a balance witness should describe one consistency check and its severity, not become a global verdict.

### 4) Rounding and duplicate facts are first-class scars
XBRL's interval and rounding posture teaches Foundry not to collapse a residual into either `wrong` or `ignore`. A residual may be ordinary rounding, truncation, duplicate-value conflict, incomplete component set, policy suppression, redaction, or a real imbalance. The residual class matters.

### 5) A rule language can be useful without becoming Foundry's language
SDMX VTL is a standard language for validation and transformation rules, with a technology-neutral business-level ambition. Foundry should steal the idea of a rule digest and business-level expression, but should not freeze VTL, SQL, XBRL Formula, SHACL, dbt tests, or a bespoke DSL as the cube's permanent core.

### 6) Process models warn against hiding processing residue
GSBPM treats official-statistics production as a process with data, metadata, quality, process data, documentation, and evaluation loops. Foundry does not need to become GSBPM. It does need the scar: reconciliation is a process event with residue, not just a property of a final table.

### 7) Control totals are scoped, not magic
A control total might be a source-native total, a report margin, a benchmark population, a row count from a different cut, a signed invariant, a mirror value from another organization, or a hand-reviewed incident total. Each has a scope, lens, unit, measure, cut, policy, and tolerance. Calling all of them `total` loses the part that makes the check meaningful.

### 8) Balanced can still be incomparable
A table can balance internally while using an outdated hierarchy, a different calendar lens, a stale materialization, a suppressed release set, an adjusted numerator with raw denominator, or a revised vintage. The balance fence must be allowed to say `balanced_but_not_comparable` or `not_comparable_by_cut`.

### 9) Suppression, redaction, and noise make honest imbalance possible
Specimen 73 already says suppressed or budget-refused cells must not become zero. Specimen 75 extends that: if a published total and visible components do not sum because hidden siblings exist, that may be intentional. The table must expose the balance posture without leaking the hidden value by differencing.

### 10) SlopOS's design phase makes this urgent and small
SlopOS is still design-phase. Early support panels and diagnostic summaries will almost certainly mix direct counters, derived summaries, redaction profiles, provisional values, and later-reconciled state. Foundry should add a tiny control/reconciliation seam now, before dashboards and export formats silently normalize imbalance as either failure or correctness.

## Nifty ideas to steal without over-freezing

- **control-total card** — compact residue for the total, margin, invariant, benchmark, or mirror value being checked, including scope, measure, unit, cut, lens, source family, and tolerance basis.
- **reconciliation witness** — compact residue for rule digest, component set, operator/weights, checker/run, outcome, residual amount, residual class, evidence grade, and not-run/blocked reason.
- **balance fence** — compact guardrail that says whether downstream consumers may chart, export, subtract, compare, drill down, or reuse a result as balanced.
- **residual class** — exact-zero, rounding, truncation, duplicate-conflict, incomplete-components, suppression-hidden, redaction-hidden, noise-introduced, imputation-residue, stale-cut, not-comparable, or unexplained.
- **same-cut balance default** — do not reconcile across different source cuts, policy lenses, calendars, hierarchies, statuses, or vintages unless a mirror/cross-cut rule explicitly says so.
- **visible-residual row** — allow a published table to show an explicit residual bucket rather than silently forcing components to a flattering total.
- **suppression-aware total posture** — allow `total_visible_components_do_not_sum` without leaking hidden cells.
- **mirror-check witness** — record cross-source or cross-organization checks separately from within-table arithmetic.
- **rule-profile digest** — keep the exact validation/check expression or profile pinned without choosing one validation language.
- **not-balanced-yet outcome** — a valid status for design-phase/streaming/support surfaces; not every useful result has passed a reconciliation check.

## What stays parked

- no universal validation DSL;
- no XBRL, VTL, Formula, SQL, SHACL, dbt, or spreadsheet-calculation engine in core;
- no accounting ledger or official-statistics production framework;
- no global source-of-truth hierarchy for all totals;
- no automatic balancing adjustment;
- no rule that every table must balance before it can be viewed;
- no claim that balanced means complete, current, comparable, private, or true;
- no treating a subtotal mismatch as always-fatal;
- no treating suppressed, redacted, noisy, imputed, stale, or provisional residuals as ordinary arithmetic error;
- no hiding residuals by adding a fake `other` row unless the row has a residue class and policy basis.
