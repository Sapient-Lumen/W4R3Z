# Research synthesis — pass XXVIII

This pass keeps Foundry narrow and learns one more thing from update, snapshot, and storage ecosystems: **current or blessed is still not the same fact as retained from reclamation.** Systems repeatedly need one explicit reason why an old basis, snapshot, or evidence bundle must stay alive even when it is no longer current.

## Outside lessons
1. **Nix makes retention explicit through generations and GC roots.**  
   Old generations remain rollback-valuable precisely because they continue to root store paths; only after generations or explicit roots are removed can ordinary garbage collection reclaim the store objects. That is a strong reminder that “not current” is smaller than “safe to reclaim”.

2. **OSTree separates active/rollback deployments from pinning.**  
   A deployment may be booted, pending, or rollback, yet `ostree admin pin` still exists because operators sometimes need an exact deployment kept from default garbage collection for reasons smaller or different than mere currentness.

3. **containerd uses leases to protect future-needed content and snapshots.**  
   Its docs are unusually candid: clients create leases so resources may survive even when they are not currently seen as utilized. That is exactly the kind of humility Foundry should steal for staged, rollback, audit, or recovery material.

4. **ZFS keeps snapshot destruction honest with named holds.**  
   A snapshot with a hold cannot be destroyed; release is a separate act. That is the cleanest storage-world example that retention can be an explicit first-class state rather than a side effect of hope.

5. **Kubernetes finalizers keep deletion separate from cleanup completion.**  
   Objects marked for deletion can still remain present until specific cleanup conditions are satisfied. That is a good anti-lesson against treating “we intend to remove this” as identical to “it is now collectible everywhere that matters”.

## Resulting Foundry move
Do not invent a universal GC subsystem, retention controller, or deletion workflow plane.
For now, keep three specimen nouns alive:
- **retention root** — explicit reason/reference that keeps a basis, snapshot, or evidence object alive beyond current use;
- **reclaim fence** — explicit blocker that prevents ordinary reclamation or destroy from proceeding yet;
- **cleanup debt** — explicit outstanding work that must clear before the fence can fall and retention can honestly disappear.

Also keep two adjacent ideas parked rather than promoted:
- **collectability class** — compact status for current, retained, reclaim-blocked, or collectible posture;
- **release witness card** — future compact residue that cleanup debt cleared and a retention root was intentionally dropped.

## Fresh ideas worth stealing
- **retention root** — exact root/hold/lease/finalizer-style reason that keeps old but still valuable material alive.
- **reclaim fence** — explicit blocker that says “ordinary prune/delete/GC must stop here for now”.
- **cleanup debt** — named outstanding work before release becomes honest.
- **collectability class** — future compact label for retention posture without inventing a whole GC plane.
- **not current smaller than reclaimable** — a standing anti-regrowth rule.
