# Research synthesis — pass XXX

This pass keeps the next seam deliberately narrow: **consistency class / write fence / recovery debt**.
The outside systems keep repeating the same lesson in different clothes: a captured cut can be perfectly real and still be a weaker kind of truth than operators wish it were.
Foundry should preserve that seam without importing a universal checkpoint engine, backup control plane, or migration framework.

## Primary lessons from the outside

### 1) A snapshot can be real while still only crash-consistent
Microsoft’s VSS documentation is unusually clear about the stronger path.
Writers are told to freeze application write I/O, VSS flushes filesystem buffers, the filesystem is frozen briefly, the provider creates the shadow copy, and only then are writes thawed again.
That is the pattern to steal: a stronger capture class depends on an explicit **write fence**, not on wishful use of the word “snapshot”.

The negative form matters too.
Microsoft’s guidance for backups without writer participation says the result is merely a volume reflecting disk state at that instant, with incomplete or partial I/O possible; that is explicitly described as **crash-consistent**.
So Foundry should not let “captured” silently imply “application-consistent”.

### 2) Filesystem-level consistency is still smaller than clean logical shutdown
The `fsfreeze` manual page is a useful humility source.
It says freezing halts new modifications, lets ongoing transactions complete, and writes dirty data, metadata, and log information to disk to create a stable on-disk image.
But it also warns that even after freezing, the on-disk image can still reflect files in the process of unlinking until the filesystem is unfrozen or the snapshot is mounted cleanly.
That is a strong reminder that a low-level stable cut is real but still not the whole logical story.

PostgreSQL makes the same point from a database angle.
Its documentation says a filesystem snapshot taken while the server is running behaves as though the server had not been shut down properly; on restore, PostgreSQL will replay WAL, and a manual `CHECKPOINT` before the snapshot only reduces recovery time.
That is exactly the shape Foundry should preserve as **recovery debt**: a cut may be valid while still requiring later replay or repair before it counts as comfortably resumed.

### 3) Multi-volume and multi-object snapshots still do not magically become application-consistent
Kubernetes is explicit here.
The volume snapshot API does not itself provide application-consistency guarantees; users must prepare the application first, such as by pausing it or freezing the filesystem.
Kubernetes volume group snapshots then add another useful distinction: they can represent a common crash-consistent point across multiple volumes.
That is worth stealing because it keeps point-in-time grouping and application quiescence as two separate truths.

## SlopOS/companion pressure
The uploaded SlopOS archive already has good instincts here.
RFC-0037 treats cooperative checkpointing as an explicit orchestration seam, RFC-0108 says checkpoint capture needs a consistent cut, and the configuration pipeline already talks about snapshot-gated breaking migrations.
That means Foundry should not become the checkpoint manager.
It should only keep the meaning seam honest enough that sibling cubes can reference it later.

## Candidate nouns worth collecting
- **consistency class** — explicit class for what kind of cut was actually captured, such as crash-consistent versus application-consistent;
- **write fence** — explicit freeze, pause, or flush boundary that strengthens a cut beyond ordinary crash capture;
- **recovery debt** — explicit replay, repair, or restart work still owed before the captured state becomes comfortably resumed truth.

## Things to keep parked
- a universal checkpoint/backup lifecycle state machine;
- implicit claims that filesystem freeze equals full application quiescence;
- hidden automatic conversion from crash-consistent capture into “known-good resume”;
- a generic storage-controller or replication subsystem.

## Provisional judgment
Promote only the seam, not the machinery.
Foundry should be able to say that a cut is **crash-consistent**, that a stronger **write fence** was or was not crossed, and that **recovery debt** still remains after restore.
That is especially valuable while SlopOS is still plastic enough to keep checkpoint, backup, migration, and reset stories separate.
