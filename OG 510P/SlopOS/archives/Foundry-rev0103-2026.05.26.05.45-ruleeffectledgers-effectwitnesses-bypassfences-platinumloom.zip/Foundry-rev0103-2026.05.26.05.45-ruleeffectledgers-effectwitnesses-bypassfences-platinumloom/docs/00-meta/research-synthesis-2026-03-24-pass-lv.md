# Research synthesis — pass LV

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from search engines, hybrid retrieval stacks, and ranked-result APIs: **ranked values need explicit ordering semantics instead of pretending that every numeric score means the same thing or that one page/window is stably reproducible by default**.

The smallest durable seam from this pass is:
- **rank recipe** — the compact witness for what ordering procedure actually produced the visible order: unscored field sort, BM25-style relevance, vector-distance ordering, hybrid fusion, semantic rerank, or some other explicitly named recipe;
- **score family** — the compact witness for what the visible score means, including direction (`higher-is-better`, `lower-is-better`, `rank-only`, or `unscored`) and whether the number is local to one result set rather than a portable global quantity;
- **tie-break witness** — the compact witness for how equal-score or equal-rank rows are stabilized for paging, export, or later replay, or an explicit statement that no stable tie-break was preserved.

These are still smaller than a universal search plane, a full ranking-evaluation product, or a giant query-optimizer ontology.
They simply keep future Foundry rows from laundering ranked convenience into fake globally comparable truth.

## Lessons we must learn from the past

### 1) Scores are method-local and phase-local
Elasticsearch’s Query DSL docs say `_score` depends on query type and on whether a clause is run in query context or filter context.
Azure AI Search goes further: BM25, vector, hybrid RRF, and semantic reranking each use different algorithms and different score ranges, with semantic reranking reported separately as `@search.rerankerScore`.
Foundry should therefore not pretend that “score” is one universal scalar.

### 2) Distance and similarity do not even point in the same direction
Weaviate’s vector-search docs distinguish **distance** (lower is closer) from **similarity/certainty** (higher is closer), and note that certainty-style normalization only makes sense for some metrics.
Foundry should learn the same humility before it bakes a single sign convention into one generic score field.

### 3) Hybrid retrieval is a recipe, not a natural law
Weaviate’s hybrid-search docs are explicit that hybrid ranking combines vector and keyword results using a chosen fusion strategy, and that the strategy itself matters.
Azure AI Search similarly treats RRF as a separate scoring stage from BM25 and from semantic reranking.
So the ordering method belongs in the public residue, not in operator folklore.

### 4) Top-k always returns something unless thresholds are made explicit
Weaviate warns that vector search will still return a nearest result even when the absolute semantic match is weak, which is why thresholds, filters, and autocut mechanisms exist.
That is exactly the sort of past lesson datacubes forget when they flatten “top result” into “good result”.

### 5) Ties and windows are unstable unless the order is constrained
PostgreSQL’s docs warn that `LIMIT`/`OFFSET` without an `ORDER BY` that constrains rows into a unique order yields an unpredictable subset.
Azure AI Search likewise says equal-scored hits have undefined, unstable ordering and recommends an explicit `$orderby` tie-break.
Foundry should therefore treat stable pagination/export posture as explicit residue, not as an accidental side effect of seeing rows in an order once.

## What to steal now
- a **rank recipe** beside any ranked or advisory-ordered result family so consumers know whether they are looking at BM25, vector distance, hybrid fusion, semantic rerank, or merely one field sort;
- a **score family** so score direction, score range posture, and local-versus-portable meaning stay explicit;
- a **tie-break witness** so equal-score exports, pages, and replayed windows do not quietly reorder themselves;
- a habit of treating ranked convenience as smaller than population truth;
- and a habit of preserving score semantics even when the UI only wants one `score` column.

## What to keep parked
Do not yet promote:
- a universal search service or retrieval product plane;
- one cross-query or cross-engine score calibration algebra;
- a mandatory ranking contract for unranked/snapshot-first families;
- a giant evaluation/ground-truth regimen for every cube family;
- or one global notion of “relevance” that outruns the recipe that produced it.

## Resulting recommendation
The next healthy move is not “design search.”
It is to let Foundry say, for any future ranked or advisory-ordered value family:
1. which **rank recipe** produced the current order,
2. what **score family** the visible score belongs to,
3. and what **tie-break witness** made equal-score windows/export slices reproducible — or that none was preserved.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from Elasticsearch, Weaviate, Azure AI Search, and PostgreSQL ordering semantics.
