# Research synthesis — pass LXXVI

This pass goes deeper, but it stays narrow.
SlopOS is still in design phase, and Foundry should not answer uncertainty by inventing a giant semantic layer, lakehouse schema, contract engine, or global catalog ontology.

The low-regret move is to promote one small seam: when a query, tile, export, report, support-card table, or API result leaves the cube, it should carry a **query contract**, a **result envelope**, and a **validation witness** so later readers can tell what was asked, what was served, and what was checked.

Specimen 70 is therefore added.
It is an output-honesty seam, not a warehouse model, query language, data-contract runtime, or authority plane.

## Lessons we must learn from the past

### 1) A data contract is a boundary promise, not the data's soul
ODCS is useful because it treats schema, quality, SLA, support, team, infrastructure, and custom properties as contract sections rather than pretending a table's ontology lives in one field list.
OpenMetadata is useful because it ties contracts to schema, semantic expectations, data-quality tests, SLAs, and execution history.
The lesson for Foundry is to keep contract residue adjacent to a query or result, not to make every Foundry family inherit a universal contract object.

### 2) Constraints must say what they actually constrain
Frictionless Table Schema is a good small pattern: field constraints such as length, numeric bounds, patterns, and enums apply to the logical representation, and unsupported constraints should error rather than be silently ignored.
Foundry should steal the refusal posture: if a result claims a schema or validation basis that the consumer cannot understand, it should be marked unsupported rather than silently upgraded into trust.

### 3) Query representation is a replay aid, not ontology
Substrait shows the value of serializing compute operations and relational plans so different engines can interpret the same intended computation.
Foundry should steal the plan-digest / operation-description idea, while refusing to make a universal query grammar mandatory for every cube family.
The contract can say, "this result came from this query/plan/profile/cut," without requiring Foundry to become a query engine.

### 4) Output order is a claim, not a vibe
DuckDB's order-preservation docs are a useful warning: some clauses preserve order, but joins, grouping, aggregation, union-like operations, sampling, and other operations may not.
Foundry must make result ordering posture explicit: stable order, unordered, tie-broken order, page-local order, or output-only order.
Any dashboard row order that lacks a durable ordering witness is presentation, not semantic truth.

### 5) Dimensions, coordinates, variables, chunks, and storage layout are related but not identical
xarray's named dimensions and coordinates show why labeled axes matter.
Zarr's chunk grids, codecs, metadata documents, arrays, and groups show why storage layout matters.
The STAC datacube extension's dimensions and variables show why discoverable multidimensional metadata matters.
Foundry should keep these ideas separate: logical axis/cardinality/coordinate meaning is not the same as chunking, tile shape, file layout, or catalog convenience.

### 6) Snapshot and transaction logs are replay cuts, not semantic answers
Iceberg snapshots, metadata files, manifests, manifest lists, and optimistic metadata swaps provide excellent cut/replay discipline.
Delta's transaction protocol similarly exists to give ACID writes, snapshot isolation for reads, self-describing table metadata, and incremental processing over large file sets.
The Foundry lesson is to preserve exact cut and served-from posture, not to let table engine internals become the cube's durable meaning.

### 7) Catalog, provenance, and quality vocabularies are three different layers
DCAT helps describe catalogs, datasets, data services, and discovery.
PROV-DM helps say which entities, activities, agents, derivations, usages, and generations were involved.
DQV helps describe quality dimensions, metrics, and containers for quality metadata.
Those are all useful, but Foundry must not fuse discovery, lineage, and quality into one trust-shaped field.

### 8) Validation results are not source truth
OpenLineage's data-quality assertion facet separates assertion type, success, severity, column scope, expected/actual values, and assertion body; especially important, success and severity are independent.
Great Expectations' current validation result object similarly records success, individual expectation results, statistics, metadata, batch identity, and result location.
Foundry should preserve validation witnesses as witnesses: they can say what was checked and whether it passed, failed, warned, skipped, or was not run; they do not replace the subject they validate.

### 9) SlopOS query surfaces should return handles, envelopes, and cuts before they return folklore
SlopOS's attribute-query, tracing, trace-processing, view-object, and boundary-index contracts already point in the right direction: queries are closed, typed, cut-aware, sandboxed or bounded, and kept smaller than storage layout.
Foundry should mirror that discipline whenever a datacube result leaves core storage and becomes a UI tile, support card, table export, or machine-readable report.

## Nifty ideas to steal without over-freezing

- **query contract** — a compact record of the query/request shape, plan digest, input family/view, parameters, policy lens, engine/profile, and required cut/frontier.
- **result envelope** — a compact wrapper around an emitted result that says what was served, from where, at which cut, with which ordering, paging, row-count posture, disclosure lens, materialization digest, and replay class.
- **validation witness** — a compact result-adjacent witness for schema checks, data-quality checks, freshness/SLA checks, policy checks, or not-run/exempt posture.
- **ordering posture** — stable, unordered, tie-broken, page-local, output-only, or unknown; never inferred from current display order alone.
- **row-count posture** — exact, bounded, estimated, omitted, policy-masked, relation-qualified, or page-local.
- **served-from posture** — base rows, snapshot, materialized view, pre-aggregation, cache, sketch, sample, query engine, or external provider.
- **contract subset** — a small subset of a larger contract that actually applied to this result, instead of pretending the whole contract governed the output.
- **axis/coordinate card** — a small axis/coordinate/variable declaration for cube-shaped results that stays distinct from file chunking and storage layout.
- **catalog card** — discovery metadata for a dataset or result family that remains smaller than lineage, quality, or trust.
- **validation severity split** — keep pass/fail/skip/not-run separate from warning/error/blocking consequence.
- **replay expiry marker** — a compact warning when the result was produced from a cut or log window that may no longer be replayable.

## What stays parked

- no universal query language;
- no mandatory Substrait, SQL, GraphQL, SPARQL, or dataframe expression grammar;
- no global semantic layer or metric registry;
- no lakehouse table engine ontology;
- no single catalog/provenance/quality umbrella noun;
- no always-on data-contract runtime;
- no promise that validation success proves source truth;
- no promise that an exported table's order, row count, or page window is meaningful unless the result envelope says so;
- no automatic promotion of chunk layout, partitioning, manifest shape, or materialization strategy into semantic identity.
