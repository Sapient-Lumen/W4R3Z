# Research synthesis — pass XVIII

This pass keeps Foundry narrow and learns one more thing from outside runtime systems: **metadata truth and payload truth are often sealed differently, and early bootstrap locality is still smaller than full realization**.

## Outside lessons
1. **composefs makes the metadata/data split explicit.**  
   The project stores non-empty file data separately from the metadata image and can mount a structural tree over a backing store. Foundry should steal the shape: structure and payload may have different locality and integrity stories.

2. **composefs also shows how to seal both sides without collapsing them.**  
   Backing content can be validated with fs-verity, while the image itself can also be protected with fs-verity plus an expected digest. Foundry should keep metadata seal and payload root distinct rather than pretending one digest tells the whole story.

3. **fs-verity is honest about its scope.**  
   It transparently verifies read-only file contents via Merkle trees and efficient digests, but by itself it does not verify metadata such as directory structure, ownership, or permissions. Foundry should preserve that humility as a first-class lesson.

4. **Nydus names the bootstrap/data split that many lazy systems hide.**  
   RAFS keeps metadata in `bootstrap` while file data sits in separate chunked blobs, and the metadata contains everything needed to start. Foundry should therefore name the remaining non-locality after startup as bootstrap debt.

## Resulting Foundry move
Do not decide yet whether the durable nouns are `metadata seal`, `payload root`, and `bootstrap debt`, or whether one of them later hides behind a smaller realization family.
For now, keep all three alive as specimen nouns and demand that they improve:
- one structure-authentic but payload-remote specimen,
- one payload-verified cold-read specimen,
- and one specimen where startup succeeds before full locality arrives.

## Fresh ideas worth stealing
- **metadata seal** — explicit integrity story for structure and directory semantics.
- **payload root** — compact content witness for foreign-backed bytes.
- **bootstrap debt** — remaining non-locality after a fast start.
- **seal split** — structure assurance and payload assurance stay visibly different.
