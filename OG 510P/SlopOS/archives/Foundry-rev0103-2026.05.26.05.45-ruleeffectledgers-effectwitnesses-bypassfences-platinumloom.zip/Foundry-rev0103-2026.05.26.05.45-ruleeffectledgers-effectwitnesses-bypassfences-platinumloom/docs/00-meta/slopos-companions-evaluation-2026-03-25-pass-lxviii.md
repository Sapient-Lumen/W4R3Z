# SlopOS + companions evaluation — pass LXVIII

This pass checks whether **denominator basis, normalization lane, and ratio fence** are real pressures in the current neighboring archives or just elegant outside vocabulary.

## Verdict
Yes — the seam earns a cautious place in Foundry.
But it still does **not** justify a giant KPI registry, one archive-wide denominator grammar, or a mandatory ratio language across every current surface.

## Why SlopOS pressures this seam now

### 1) SlopOS already has coverage maps where the denominator can quietly slide
`docs/30-architecture/boundary-family-map.md` and `adjunct-family-map.md` are intentionally hygiene surfaces, but they make future percentages extremely tempting:
- “what percent of boundary docs belong to a family index?”
- “what percent of adjunct families have full evidence hooks?”
- “what percent of singleton docs are still intentional?”

Those are not one ratio.
The denominator could be all current boundary docs, only family-eligible docs, only same-revision maintained docs, or only surfaces owned by one profile slice.
That is direct **denominator basis** pressure.

### 2) SlopOS profile matrices invite coverage percentages whose denominator is not obvious from the chart title
`docs/00-meta/profile-posture-matrix.md` and `profile-claim-matrix.md` make it easy to ask questions like:
- “what percent of profile B boundaries are pinned?”
- “what percent of profile D claims are backed by explicit docs?”
- “what percent of the current archive is shared across all profiles?”

Those answers depend on whether the denominator is all rows in the matrix, only non-empty profile cells, only profile-owned obligations, or only surfaces currently wired into one index.
A future Foundry export should preserve that **denominator basis** instead of flattering the reader with one naked percentage.

### 3) Signature acceptance already pressures numerator/denominator honesty
`docs/30-architecture/signature-signer-acceptance-boundary-v0.md` keeps signature records, signer identity, duplicate signatures, and quorum/local-policy acceptance visibly separate.
A future support chart could easily ask:
- accepted signatures / presented signatures,
- distinct accepted signers / distinct eligible signers,
- or quorum-satisfied subjects / quorum-target subjects.

Those are meaningfully different ratios.
They need both an explicit **denominator basis** and an explicit **normalization lane** so “accepted signer rate” does not quietly switch from record-level to distinct-signer or eligible-signer truth.

### 4) Evidence-set and completeness surfaces already need opportunity-set honesty
`provenance-evidence-set-boundary-v0.md` and `sbom-vex-evidence-set-boundary-v0.md` repeatedly keep attached evidence artifacts smaller than a native completeness claim.
That means a future “coverage” panel may want ratios like:
- artifacts with provenance / artifacts expected to have provenance,
- subjects with SBOM / subjects in the cohort,
- vulnerabilities with VEX statements / vulnerabilities in the selected inventory scope.

Those are not plain activity ratios.
They pressure Foundry toward a **normalization lane** that can say whether the answer came from same-subject counts, coverage-minus-activity comparison, or another reviewed alignment.

### 5) Companions reinforce the same restraint
Ward, Harbor, Steward, and ViewFS all contain summary-shaped surfaces where a percentage or “health” ratio could be useful but the denominator is contextual: current-visible cohort, expected cohort, eligible cohort, or a management target set.
Together they say the same thing: neighboring archives are rich in support ratios, but the ratio truth is often smaller than the dashboard story.
That is exactly where a **ratio fence** earns its keep.

## What to steal into Foundry

### denominator basis
A compact statement of what the visible ratio divides by.
Examples:
- `distinct_subject_population`
- `eligible_subject_subset`
- `signature_record_population`
- `coverage_opportunity_set`
- `exposure_time_total`
- `common_dimension_joined_metric`

### normalization lane
A compact statement of how numerator and denominator were aligned before division.
Examples:
- `same_grain_direct`
- `common_dims_joined_subqueries`
- `weighted_recompute_from_parts`
- `coverage_minus_activity`
- `display_only_compare_total`

### ratio fence
A compact statement of what later recomputation is still honest.
Examples:
- `recompute_from_parts_only`
- `same_frame_only`
- `same_filter_only`
- `display_only_not_reusable`
- `forbidden`

## Why this should stay narrow
Foundry does **not** yet need:
- one universal denominator ontology;
- one mandatory ratio family on every measure;
- one archive-wide percent-of-total engine;
- or a promise that profile, family, and evidence coverage percentages can always be compared directly.

SlopOS is still in design phase.
That is precisely why this seam should stay small: capture denominator honesty now, and leave big KPI theology parked.
