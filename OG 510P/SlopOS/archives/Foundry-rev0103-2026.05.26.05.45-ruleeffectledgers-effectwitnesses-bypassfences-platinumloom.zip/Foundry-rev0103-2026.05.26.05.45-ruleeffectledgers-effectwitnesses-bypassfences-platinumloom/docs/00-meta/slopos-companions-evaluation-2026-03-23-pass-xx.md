# SlopOS / companions evaluation — pass XX

Foundry still looks justified as its own companion cube.

## What the current cube ecology keeps proving
- **SlopOS** already keeps config generations, activation state, and boot selection separate. That is exactly the pressure Foundry should accept: a prepared foreign generation is not the same thing as the live basis.
- **SlopOS** also keeps pending / tries / commit semantics explicit around boot selection, which argues for treating activation cut and rollback selector as honest neighboring truths rather than hiding them in one generic “updated runtime” object.
- **Helm** benefits because operator surfaces need to say whether a foreign change is staged, active, reverted, or only proposed.
- **Schell** benefits because command lanes often act against the current live basis while another foreign candidate is merely queued.
- **ViewFS** benefits because activation targets, live binds, and historical receipts already want different names.
- **Ward** benefits because compatibility or health evidence on a candidate generation stays smaller than proof that the candidate became the active realization.

## Pressure on Foundry
Foundry should not decide yet whether staged generation and booted basis belong inside artifact identity, runtime readiness, or aftermath residue.
The stronger move is to keep one more specimen where:
1. a candidate foreign generation exists,
2. it is still smaller than the current live basis,
3. activation happens at a named cut,
4. and rollback remains an explicit selector instead of emergency folklore.

## Promotion restraint
Do not promote `staged generation`, `activation cut`, `booted basis`, or `rollback selector` unless they improve:
- one candidate-only specimen,
- one explicit activation specimen,
- and one rollback / revert specimen.
