# Research synthesis — pass LI

This pass stays deliberately conservative.
Foundry still should **not** freeze a universal datacube schema while both Foundry and SlopOS remain in design motion.
But it can steal one more durable lesson from metrics systems, OLAP engines, and aggregate-aware caches: a cube stays healthier when a summarized value can say **what kind of fidelity was lost, whether there is a bounded breadcrumb back to narrower evidence, and whether the raw substrate is still retained at all**.

The smallest durable seam from this pass is:
- **loss class** — whether a value is row-preserving, attribute-lossy, bucketized, sketch-like, or summary-only;
- **exemplar anchor** — an optional bounded pointer to one or a few concrete contributing artifacts/events outside the aggregate itself;
- **raw-retention fence** — whether the narrower evidence still exists, is queryable only behind a colder path, or is gone.

These are still smaller than a universal drill-through API, a mandatory lineage graph, or a raw-retention policy plane.
They simply keep future Foundry rows from laundering “fast enough to chart” into “fully faithful forever.”

## Lessons we must learn from the past

### 1) Rollup buys speed by discarding row-level freedom
Druid states the trade-off plainly: ingestion-time rollup can dramatically shrink stored data, but you lose the ability to query individual events.
That is the right emotional posture for Foundry too.
A summary should never impersonate lossless source truth.

### 2) Some transformations are semantically safe, but only for the right stream kinds
OpenTelemetry’s metrics data model is valuable because it names a narrow set of transformations that preserve meaning for certain aggregate streams: temporal reaggregation, spatial reaggregation, and delta-to-cumulative conversion.
This is a reminder that Foundry should distinguish “legal reduction” from “useful but lossy convenience.”

### 3) Pre-aggregations are still query-shaped materializations
Cube is explicit that pre-aggregations are materialized query results chosen by aggregate awareness.
That is good discipline for Foundry: an acceleration artifact may be important, but it is still smaller than the underlying evidence world.

### 4) Exemplar breadcrumbs are a brilliant middle path
OpenMetrics allows histogram buckets to carry exemplars, and Prometheus describes exemplars as references to data outside of the MetricSet.
This is a beautiful steal for a design-phase datacube.
Not every summary needs full row lineage, but a bounded breadcrumb to one or a few concrete contributing artifacts can preserve drill-through honesty without making raw lineage the primary schema.

### 5) Some reductions remain valid even after granularity is dropped
OpenMetrics also notes that histogram buckets are cumulative so systems may drop non-`+Inf` buckets for performance reasons in a way that loses granularity yet still yields a valid histogram.
That is an important nuance: “lossy” is not the same as “meaningless,” but it does mean the loss should be explicit.

### 6) Projections are helpful and sticky
Druid’s projection docs are a cautionary tale: projections are stored within a segment, accelerate matching query shapes, and once defined become a datasource dimension that generally requires reingestion to remove.
That is exactly the sort of operational stickiness Foundry should avoid baking into its core vocabulary too early.

## What to steal now
- a **loss class** beside any summarized or accelerated value whose source fidelity changed;
- an **exemplar anchor** when one or a few concrete contributing artifacts can safely remain reachable as bounded drill-through breadcrumbs;
- a **raw-retention fence** so users can tell whether narrower evidence is still available, cold-only, policy-blocked, or gone;
- a habit of keeping acceleration artifacts visibly downstream from raw evidence truth;
- and a habit of treating exemplar links as optional bounded breadcrumbs, not as a back door to universal lineage.

## What to keep parked
Do not yet promote:
- a mandatory raw-event retention rule for every family;
- a universal drill-through API;
- a global exemplar store or quota plane;
- a built-in multi-stage rollup planner;
- or a full fidelity taxonomy beyond what repeated specimens actually need.

## Resulting recommendation
The next healthy move is not “design the whole acceleration layer.”
It is to let Foundry say, for any future summarized value:
1. what **loss class** it belongs to,
2. whether an **exemplar anchor** exists,
3. and where the **raw-retention fence** sits.

That keeps the cube aligned with SlopOS’s design-phase reality while stealing durable anti-folklore lessons from Druid rollups/projections, OpenTelemetry reaggregation, OpenMetrics exemplars, and Cube pre-aggregation discipline.
