# Research synthesis — 2026-03-23 pass XI

This pass focused on a Foundry pressure that old runtime ecosystems keep getting wrong: nearby attached metadata, explicit foreign handles, and resource-release policy are all useful, but they are not the same as live realization.

## New lessons from outside systems

### 1) OCI subject/referrers make attachment explicit without claiming completeness
OCI 1.1 adds a `subject` field that lets tools associate signatures, attestations, SBOMs, and other artifacts with a primary manifest. Foundry should steal that shape carefully: a **subject spine** or nearby attached evidence neighborhood can be useful without pretending it is the whole realization story.

### 2) WIT resources keep some capabilities visibly implemented on the other side
The WebAssembly component model’s WIT resources are a sharp reminder that smooth foreign use can still be exterior. Foundry should keep **resource handles** or similar nouns visibly foreign instead of laundering them into native objecthood.

### 3) Fuchsia capability routing keeps power and availability explicit
Fuchsia continues to treat capabilities and their routing/availability as first-class composition facts. Foundry should keep required versus optional foreign power explicit before and during launch.

### 4) Confidential Containers keeps attestation policy separate from secret release
Current Confidential Containers guidance continues to verify attestation and then conditionally release secrets. Foundry should preserve that split: a launch or attestation success should not silently imply resource or secret release. A **policy capsule** or **secret-release latch** can remain smaller than realization or adoption.

## New lessons from SlopOS and companions

### SlopOS
- The foreign-cell, compat, attestation, and import/materialization neighborhoods still reward small exported facts about what ground exists, what evidence exists, and what durable local adoption happened.
- The primary still appears to prefer explicit seams over one giant runtime description, which supports keeping subject spine, handles, and policy capsules separate.
- Since SlopOS remains design-phase, Foundry should keep harvesting these shapes as specimen pressure rather than freezing a total package/ground/runtime ontology.

### Siblings
- Harbor still reminds Foundry that arrival and adoption are different.
- Ward still reminds Foundry that attestation evidence and resource-release consequence are different.
- ViewFS still braces against handle inflation by distinguishing carriers, identities, and grants.
- Steward still supports typed followthrough after launch.
- Helm and Schell still reward explicit foreignness instead of laundering smooth compat into “native enough”.

## Brilliant ideas worth stealing carefully

1. **Subject spine** — a stable anchor for nearby attached evidence and contracts, still smaller than realization.
2. **Resource handle** — a typed, visibly foreign handle to something implemented across the boundary.
3. **Policy capsule** — a compact account of which policy inputs governed admission or release.
4. **Secret-release latch** — explicit state showing that secret/resource release is gated separately from launch success.
5. **Availability split** — required versus optional routed foreign power stays visible.

## What pass XI should not decide yet

Foundry still should not decide:
- whether subject spines and sidecar packs are first-class Foundry objects or imported registry/package relations with thinner Foundry wrappers;
- whether policy capsules belong to launch truth, evidence truth, or aftermath truth;
- whether resource handles should share one family across Wasm, VM, compat shims, and sidecars.
