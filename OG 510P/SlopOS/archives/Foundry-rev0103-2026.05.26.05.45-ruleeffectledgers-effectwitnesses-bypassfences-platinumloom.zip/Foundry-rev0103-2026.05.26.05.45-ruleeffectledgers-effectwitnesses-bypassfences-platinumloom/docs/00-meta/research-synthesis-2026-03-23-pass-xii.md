# Research synthesis — pass XII

This pass focuses on what foreign realization owes **after restore** and what it should admit about optionality and nearby attachments.

## Fresh outside lessons
1. **Restore needs explicit obligations.**
   SnapStart runtime hooks make “after restore” visible as a distinct phase. That is a strong clue for Foundry: restored execution may owe uniqueness repair, resource reacquire, or configuration refresh before it can truthfully claim normal readiness.

2. **Availability deserves first-class status.**
   Fuchsia capability availability distinguishes required from optional routed power. Foundry should likely steal that exact humility: some foreign power is necessary, some is opportunistic, and the absence of the latter should not silently falsify the former.

3. **Attachments still need a fallback story.**
   OCI 1.1 referrers use `subject` and the referrers API, but clients may need fallback tagged indexes when a registry lacks referrers support. That is a helpful anti-lesson: nearby evidence/contract attachments are real, but their transport/discovery path may degrade.

4. **Resource-like handles remain exterior.**
   WIT resources continue to model limited-lifetime entities passed indirectly by handles. Foundry should keep stealing that habit whenever something smooth and local is actually implemented across the boundary.

## Resulting Foundry pressure
Foundry should probably preserve at least four distinct things:
- **restore obligation**: what must be re-established after resume;
- **availability class**: required, optional, or unavailable foreign power;
- **attachment discovery mode**: native referrers, fallback tag/index, or out-of-band witness;
- **live adoption**: what was actually admitted after those realities were checked.

## Brilliant ideas worth stealing
- **restore obligation card** — a typed summary of what must happen after resume before readiness can be claimed;
- **availability class** — a first-class status for foreign power instead of folklore about what was “supposed to be there”;
- **referrer fallback card** — an explicit note that attachment discovery degraded but did not disappear.
