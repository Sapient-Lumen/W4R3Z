# Research synthesis — 2026-03-23 pass VI

This pass concentrated on a specific historical trap: once foreign execution starts feeling smooth, designers begin pretending the foreign ground has disappeared.

## New lessons from outside systems

### 1) Packaging, manifesting, and launching are still different jobs
OCI remains a strong anti-collapse model because it keeps image indexes, manifests, configs, layouts, and runtime bundle/config material as different surfaces. Foundry should keep stealing that refusal to flatten “what shipped” into “what ran”.

### 2) Explicit interface worlds beat invisible host assumptions
The Wasm component model remains one of the cleanest contemporary examples of interface honesty. WIT and the Canonical ABI make imports, exports, and low-level calling contracts explicit. Foundry should steal that habit for any foreign-cell contract that would otherwise hide behind host folklore.

### 3) Cross-domain service routing should be explicit, not ambient
Qubes qrexec and Fuchsia capability routing both reinforce the same idea from different worlds: isolation can stay strong while cross-domain service use remains explicit, typed, and policy-shaped. Foundry should prefer explicit service route objects over ambient network reachability or convenience shims.

### 4) Resume still needs humility after the performance win
Firecracker keeps warning that network connectivity is not guaranteed to survive resume. VMGenID support sharpens the same lesson by giving guests a signal that continuity changed. AWS SnapStart shows a related pattern in another environment: resumed instances may need after-restore hooks before they are safe to behave as normal. Foundry should keep treating restore as a distinct realization class, not just an implementation detail.

### 5) Integrity of runtime policy inputs belongs in the story
Confidential Containers’ init-data guidance is useful because it binds policy input integrity into attestation. Its sealed-secrets caveat is useful for the opposite reason: when integrity is missing, the archive should say so plainly. Foundry should keep policy input material visible rather than assuming the ground will silently make it safe.

## New lessons from SlopOS and companions

### SlopOS
- `foreign-cell-contract.md` continues to justify a dedicated cube: foreign realization is already an explicit design problem, not just an implementation remainder.
- `microvm-template-resume-class-posture-v0.md` is one of the clearest statements in the whole ecology: same-class-or-fail-closed beats “similar enough”.
- `microvm-attestation-reacquire-posture-v0.md` says the right thing about clone/restore: freshness-bound attestation and release sessions are reacquired, not resumed.
- `host-guest-channel-posture-v0.md` and the component/manifest surfaces suggest that explicit route and contract nouns are already available to steal.

### Siblings
- Harbor keeps reminding Foundry that a crossing into foreign ground still needs truthful aftermath at the membrane.
- Ward keeps reminding Foundry that runtime evidence is not the final verdict.
- Schell keeps contributing adoption-gate discipline for helpers and sidecars.
- ViewFS keeps contributing the refusal to confuse carrier, bundle, live handle, and realized object.

## Brilliant ideas worth stealing carefully

1. **Ground adoption card** — a typed object showing whether foreign execution has merely started, has been reviewed, or has been adopted as an expected operating ground.
2. **Service route object** — explicit route, rights, and policy for talking across grounds instead of ambient host reachability.
3. **Generation-change witness hook** — a small object that says restore happened and downstream caches must re-evaluate.
4. **Reacquire rail** — a first-class place where networks, secrets, attestation freshness, or policy inputs are reacquired after resume.
5. **Contract world card** — a compact representation of the declared interface world that the foreign ground claims to satisfy.

## Current recommendation
Foundry still should not freeze a universal runtime descriptor.

The safest next pressure test is three specimens:
- bundle / world / ground / live instance,
- snapshot resume plus freshness reacquire,
- and capability-routed foreign service use with explicit rights and restore-time humility.
