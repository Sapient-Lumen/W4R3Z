# Research synthesis — 2026-03-23 pass III

This pass tightened Foundry around three sources of pressure:
1. a deeper reread of SlopOS and the current companion cubes;
2. fresh official material on OCI layering, Wasm worlds/interfaces, VM-backed containers, confidential runtimes, and snapshotting lessons;
3. the explicit constraint that the primary cube must stay pressure-sterile.

## What the datacubes reinforced
- SlopOS keeps foreign-cell, cloud-substrate, template/reacquire, and attestation seams from collapsing into one implementation blob.
- ViewFS rewards precise carrier/identity/receipt distinctions.
- Helm and Schell both punish projected or remembered state that outruns what the system can still prove.
- Ward is a constant reminder that runtime evidence should not secretly become trust verdict logic.

## What the outside sources reinforced
- OCI still makes a useful image-versus-runtime-bundle separation;
- the Wasm component model gives a strong example of explicit packages, interfaces, and worlds;
- Kata keeps proving that VM-backed isolation can feel container-like without being semantically identical to a plain container;
- Confidential Containers explicitly separates attestation-service policy from secret-release policy;
- snapshot-based acceleration teaches that restored memory and disk state do not automatically preserve uniqueness, valid connections, or fresh ephemeral data.

## Founding result
Foundry should stay small and add **continuity specimens before registries**. The archive should especially resist inventing a universal runtime descriptor before it survives at least one VM-backed flow, one component-model flow, and one restored-state flow.
