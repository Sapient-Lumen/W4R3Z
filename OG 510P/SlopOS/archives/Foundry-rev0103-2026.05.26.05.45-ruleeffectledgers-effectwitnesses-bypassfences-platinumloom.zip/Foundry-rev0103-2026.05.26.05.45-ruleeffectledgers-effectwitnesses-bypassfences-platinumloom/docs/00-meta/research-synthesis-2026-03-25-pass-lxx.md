# Research synthesis — pass LXX

This pass stays conservative.
Foundry still should **not** freeze one archive-wide trust score, one universal verified/unverified boolean, or one permanent confidence algebra.
But it can steal one more durable lesson from provenance, quality-vocabulary, validation, intelligence, and data-quality assertion work: **a design-phase datacube needs to distinguish what kind of assertion a row is, what confidence or severity basis it carries, and when a local verdict must not impersonate source truth.**

The smallest durable seam from this pass is:
- **assertion class** — the compact statement of what kind of thing the row is: native observation, imported claim, validation result, policy verdict, heuristic score, or manual annotation;
- **confidence basis** — the compact statement of what any confidence/severity/score means: unspecified, STIX-style 0–100 confidence, SHACL severity, policy-local pass/fail, heuristic similarity score, or another reviewed scale;
- **verdict fence** — the compact statement of what later consumers must not assume: advisory-only, policy-local-only, unspecified-not-zero, warning-not-failure, not-source-equivalent, or forbidden.

These are still smaller than a universal trust score, one archive-wide claim-evaluation engine, or a permanent probability algebra for every import and verifier.
They simply stop useful claims, validation findings, and local approvals from collapsing into one flattering fact plane.

## Lessons we must learn from the past

### 1) Provenance can support assessment without being the assessment itself
W3C PROV-DM explicitly says provenance can be used to form assessments about quality, reliability, and trustworthiness.
That is exactly the restraint Foundry should steal.
Provenance helps us judge a row, but it is not identical to the row’s verdict.
A future cube should therefore preserve **assertion class** instead of letting provenance-bearing material impersonate native truth.

### 2) Quality is plural and actor-dependent
W3C DQV explicitly avoids declaring one objective meaning of quality and instead allows annotations, certificates, opinions, feedback, and policies from different actors.
That is direct pressure against one archive-wide trust score.
Foundry should preserve **confidence basis** and local posture instead of pretending all quality talk lives on one universal numeric ruler.

### 3) Validation severity belongs to validation results, not to the data itself
SHACL 1.2 keeps severity on validation results and provides explicit result severities such as info, warning, and violation.
That is a strong model for Foundry.
A warning or debug result is not the same thing as “the source row is false.”
That is exactly where a **verdict fence** belongs.

### 4) Advisory annotation and hard assertion are different species
Recent JSON Schema notes split `format` into annotation and assertion behavior.
That is a stealable lesson.
Foundry should keep advisory hints visibly smaller than enforceable truth and should not let “this looked okay” or “this format hint failed” impersonate ontology.

### 5) Missing confidence must stay unspecified
STIX 2.1 uses an explicit 0–100 confidence field and treats an absent confidence as unspecified.
That is a vital anti-folklore rule.
A future cube should not coerce missing confidence into zero, certainty, or failure.
That is direct **confidence basis** pressure.

### 6) Data-quality assertions belong in their own result lane
OpenLineage’s data-quality assertions facet keeps assertions as explicit assertion results rather than silently rewriting the dataset into a generic healthy/unhealthy noun.
That is the pattern Foundry should steal.
Quality assertions can be useful while still staying smaller than the subject itself.

### 7) Unspecified/default posture protects evolution
Protocol Buffers guidance keeps explicit `_UNSPECIFIED` posture and preserves unknown values instead of forcing false binary closure.
That is exactly the lesson Foundry needs when it starts carrying claim strength, severity, or validation posture across design-phase families.

## What to steal now
- an **assertion class** field or adjunct that distinguishes native observations from imported claims, validation findings, policy verdicts, heuristic scores, and manual notes;
- a **confidence basis** that says what any confidence, severity, or score means and whether unspecified differs from zero/fail;
- a **verdict fence** that blocks warnings, advisory hints, policy-local outcomes, and heuristic scores from silently becoming native truth;
- and a habit of preserving provenance, evidence, and original outputs even when a compact verdict is convenient for UI or export.

## What to keep parked
Do not yet promote:
- one archive-wide trust score;
- one universal claim-verification algebra;
- one global verified/unverified boolean;
- or a promise that local approval, warning, score, and source truth are commensurable.

## Resulting recommendation
The next healthy move is not “teach Foundry trust and truth.”
It is to let Foundry say, for claim- and validation-sensitive families:
1. **what kind of assertion this row is,**
2. **what any confidence/severity/score actually means,**
3. and **where a local or advisory verdict must not impersonate source truth.**

That keeps the cube aligned with SlopOS’s design-phase reality while stealing smart restraint from provenance, validation, and data-quality practice.
