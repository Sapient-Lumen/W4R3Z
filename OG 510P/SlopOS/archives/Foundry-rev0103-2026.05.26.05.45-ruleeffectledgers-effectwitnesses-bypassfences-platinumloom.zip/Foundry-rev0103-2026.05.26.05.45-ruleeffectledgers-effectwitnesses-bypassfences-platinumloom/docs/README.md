# Docs map

- `00-meta/` keeps charter, roadmap, trajectory, bibliography, lessons, datacube evaluation, research synthesis, decision debt, and repo/process discipline surfaces.
- `30-architecture/` carries the founding seam docs, promotion gates, specimen flows, SlopOS binding map, egress conformance rulebook, semantic regression rulebook, semantic waiver rulebook, consumer portability rulebook, delegation boundary rulebook, revocation/recall rulebook, remediation/readmission rulebook, distribution/adoption rulebook, surface inventory rulebook, exposure accounting rulebook, obligation accounting rulebook, fulfillment accounting rulebook, verification audit rulebook, recheck/drift rulebook, escalation/routing rulebook, disposition/resolution rulebook, rule-promotion rulebook, rule-collision rulebook, rule-evaluation rulebook, rule-effect-binding rulebook, checker-harness audit/refactor note, schema/fixture coverage audit, specimen-doc coverage audit, negative-case coverage audit, lifecycle-transition coverage audit, rule-surface index audit, checker-contract index audit, reference-integrity index audit, and non-decisions.
- `90-inspirations/` harvests stealable moves from outside systems and adjacent companion cubes.


- `fixtures/specimen-93-disposition-resolution/fixture.json`
- `docs/30-architecture/disposition-resolution-rulebook-v0.md`
- `tools/check_foundry_disposition_resolution.py`

Latest additions in rev0103:
- `docs/00-meta/research-synthesis-2026-05-26-pass-ciii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-ciii.md`
- `docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md`
- `docs/30-architecture/rule-effect-binding-rulebook-v0.md`
- `docs/30-architecture/reference-integrity-index-audit-v0.md`
- `schemas/foundry-rule-effect-ledger-v0.schema.json`
- `schemas/foundry-effect-witness-v0.schema.json`
- `schemas/foundry-bypass-fence-v0.schema.json`
- `schemas/foundry-reference-integrity-index-v0.schema.json`
- `fixtures/specimen-97-rule-effect-binding/fixture.json`
- `fixtures/reference-integrity-index/index.json`
- `tools/check_foundry_rule_effect_binding.py`
- `tools/check_foundry_reference_integrity_index.py`
- `docs/00-meta/lessons-we-must-learn.md`
- `docs/90-inspirations/steal-these-ideas.md`
Recent executable specimen anchors retained for coverage:
- `docs/30-architecture/specimen-flow-94-precedent-ledger-rule-promotion-witness-and-overgeneralization-fence.md`
- `docs/30-architecture/specimen-flow-95-rule-collision-ledger-precedence-witness-and-ambiguity-fence.md`
- `docs/30-architecture/specimen-flow-96-rule-evaluation-trace-applicability-witness-and-misapplication-fence.md`
- `docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md`
Negative-case coverage anchors retained for rev0103 rule-effect checks:
- `fixtures/specimen-97-rule-effect-binding/fixture.json`
- `docs/30-architecture/rule-effect-binding-rulebook-v0.md`
- `tools/check_foundry_rule_effect_binding.py`

Coverage anchors retained for executable specimens:
- `docs/30-architecture/rule-evaluation-rulebook-v0.md`
- `docs/30-architecture/specimen-flow-96-rule-evaluation-trace-applicability-witness-and-misapplication-fence.md`
- `fixtures/specimen-96-rule-evaluation/fixture.json`
- `tools/check_foundry_rule_evaluation.py`

Older docs-map anchors retained for specimen-doc coverage:
- `docs/30-architecture/specimen-flow-92-escalation-packet-routing-witness-and-unresolved-signal-fence.md`
- `docs/30-architecture/specimen-flow-93-disposition-ledger-resolution-witness-and-premature-closure-fence.md`
