# Start here

Foundry is the companion cube for off-native realization and projection honesty. It asks how SlopOS-adjacent artifacts, query results, support cards, exports, derived surfaces, closures, rule candidates, colliding promoted rules, applied/skipped rule evaluations, and now claimed rule effects stay meaningful when they leave native ground, get recalled, re-enter circulation, spread through caches/notebooks/projections/delegated workers, get found again across aliases, need exposure and obligation checks, fulfill and verify duties, keep verification fresh, route risky drift, disposition that drift, reuse closure as precedent, discover multiple promoted rules overlap, apply a winning rule to a concrete carrier/context, and then try to show that the rule actually bound an effect.

## What changed in rev0103

This pass adds the first post-application rule-effect layer and audits/refactors reference-integrity indexing:

- promoted specimen 97 around rule-effect ledgers, effect witnesses, and bypass fences;
- added a rule-effect-binding rulebook with named refusal modes for evaluation-without-effect, effect-without-trace, missing effect witness, missing bypass fence, wrong surface, scope widening, shadow/deprecated/default result activation, warning-as-enforcement, audit-only-as-block, public-release laundering, authorization/audit laundering, repair/lifecycle laundering, sibling-verdict laundering, checker-success-as-effect, runner-order-as-effect, and reference-integrity drift;
- added v0 schemas for rule-effect ledgers, effect witnesses, bypass fences, and reference-integrity indexes;
- added a specimen 97 fixture with bound, refused, quarantined, partial, no-effect, informational, superseded, missing, and bypass-detected examples;
- added bypass fences for public no-sidecar egress, Ward shadow/scope widening, ViewFS ambiguity, worker checker-success, deprecated/default effect, Harbor sibling authority, and reference-integrity drift;
- added `fixtures/reference-integrity-index/index.json` plus `tools/check_foundry_reference_integrity_index.py` so cross-specimen ids cannot dangle silently; and
- added `tools/check_foundry_rule_effect_binding.py` and wired both new checks into `make check`.

Read these three first:

1. [`docs/00-meta/research-synthesis-2026-05-26-pass-ciii.md`](docs/00-meta/research-synthesis-2026-05-26-pass-ciii.md)
2. [`docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-ciii.md`](docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-ciii.md)
3. [`docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md`](docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md)

Then inspect:

- [`docs/30-architecture/rule-effect-binding-rulebook-v0.md`](docs/30-architecture/rule-effect-binding-rulebook-v0.md)
- [`docs/30-architecture/reference-integrity-index-audit-v0.md`](docs/30-architecture/reference-integrity-index-audit-v0.md)
- [`fixtures/specimen-97-rule-effect-binding/fixture.json`](fixtures/specimen-97-rule-effect-binding/fixture.json)
- [`fixtures/reference-integrity-index/index.json`](fixtures/reference-integrity-index/index.json)
- [`tools/check_foundry_rule_effect_binding.py`](tools/check_foundry_rule_effect_binding.py)
- [`tools/check_foundry_reference_integrity_index.py`](tools/check_foundry_reference_integrity_index.py)

## New in rev0103

The short version: **application is not effect**. Foundry now requires a concrete rule-effect ledger and effect witness before a rule-evaluation result can be shown as having blocked, warned, quarantined, changed, or intentionally not changed a semantic carrier. A useful effect witness can exist without becoming policy, authorization, audit opinion, public-release approval, repair success, lifecycle finality, or a Ward/Harbor/Steward/ViewFS/SlopOS verdict.

Run `make check` from the repository root to verify the archive.
