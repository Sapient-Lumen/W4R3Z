# SlopOS revision 0800

- Revision: **0800**
- Lifecycle: **OPEN**
- Epoch: **EPOCH_ZERO**
- Phase: **CLOSURE**
- Archive: `SlopOS-rev0800-2026.07.15.03.06-proposerefine-valuesnapshot-custodyspine-fortiethforge.zip`
- Canonical predecessor: `SlopOS-rev0799-2026.07.15.02.20-activelane-sequencefence-revocationtaxonomy-thirtyninthforge.zip`
- Canonical predecessor SHA-256: `46d11f58cf34fec02c4095d63d38522fd92b5923cfc7b80857b1cba6af6a9df2`
- Objective: `E0-P0-PROPOSE-VALUE-REFINEMENT`
- Active decision: `docs/decisions/DEC-0048-P0-PROPOSE-VALUE-REFINEMENT-SQUARE.md`
- Evidence: `evidence/rev0800/`
- Release status: `PRIVATE_NO_LICENSE`

## Revision judgment

Rev0800 remains Epoch Zero. It closes neither the formal-currentness gate nor the
broad C++ refinement gate. It does replace one vague next step with a typed,
mutation-rejecting value relation for PROPOSE and a matching bounded HOL transformer.
That is enough progress for one revision and not enough for Epoch One.

## Bounded construction

The core and reference project private fixed-array/map state into an immutable
`AuthorityValueSnapshot`. The projections are independent; the shared type is a
canonical observation declaration. `canonical()` now renders that image rather than
reconstructing semantic order in parallel.

The separate refinement library classifies PROPOSE in this exact order:
out-of-scope, invalid, duplicate, capacity, sequence exhausted, accepted. Acceptance
requires one sorted fresh insertion, exact default tail, exact frame of every other
proposal/lease/resource, and one sequence advance. Denial requires the exact input
snapshot and outcome frame. A dedicated test reaches terminal sequence through a
private friend seam and rejects targeted mutations.

The HOL theory states the same bounded branch order and selected abstract update with
explicit finite value premises. Because the exact physical snapshot-to-HOL relation
and C++20 source evaluation are not mechanized, the result is recorded as formal
source plus bounded C++ value correspondence—not as implementation refinement.

## Vault and repository judgment

The old vault correctly anticipated canonical snapshots, independent model/core
transitions, and semantic result precedence. It also demonstrates the recurring
waste pattern: assurance registries and generators can multiply while the source
bridge remains open. Rev0800 promotes the laws and leaves the historical machinery
in custody.

Original source archives remain immutable. A possible content-addressed recovery
pack must preserve and verify every original container identity and reversible member
mapping. No pack, dedupe, recompression, or custody migration occurs here.

## Current and blocked

Current on the exact basis after closure evidence is generated: repository/custody
classification, active/full graph measurement, hosted GCC/Clang/sanitizer builds,
bounded authority model agreement, terminal sequence behavior, PROPOSE value
correspondence, and mutation rejection.

Blocked/open: pinned Isabelle2025-2 run, exact snapshot-to-HOL relation, C++20 source
and compiler semantics, refinement for ISSUE/INVOKE/REVOKE/OBSERVE, hostile filesystem
traversal, generation-qualified identity/reuse, dependent invalidation, in-flight
quiescence, privileged platform effect, independent review, Epoch Zero exit, and
release authorization.

## Next objective

Recover Isabelle2025-2 in a digest-pinned external cache and check `SlopOS_K0` on the
exact rev0800 construction basis. Then mechanize only the smallest projection from a
canonical proposal prefix to the HOL identifier/count/selected-proposal context. Do
not add another operation, DSL, generator, reuse mechanism, or platform rung before
that relation is reviewed.
