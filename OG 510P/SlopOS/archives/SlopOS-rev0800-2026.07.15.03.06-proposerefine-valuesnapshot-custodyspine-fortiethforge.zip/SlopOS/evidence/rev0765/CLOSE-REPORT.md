# Rev 0765 close report

## Gate result

- Archive identity:
  `SlopOS-rev0765-2026.07.10.21.40-caprep-valueimage-exactfacts-fifthforge.zip`.
- Office close: `OFFICE AUDIT PASS` under the GCC, Clang, and sanitized
  executables; all three reports are byte-identical.
- Reviewed construction basis: `SLOPOS_CONSTRUCTION_BASIS_V1`, 260 files,
  aggregate FNV `d1e17875b63b18d5`; GCC, Clang, and the GCC ASan/UBSan executable
  emitted byte-identical basis files.
- Currentness behavior was exercised during close: a basis frozen before late
  office-document edits was rejected as stale. The final basis was regenerated
  only after the active tree stopped changing, then accepted by every lane.
- GCC 14.2 warning-as-error Debug build and final CTest: 15/15 PASS.
- Clang 17 warning-as-error Debug build and final CTest: 15/15 PASS.
- GCC AddressSanitizer/UndefinedBehaviorSanitizer build and final CTest: 15/15
  PASS.
- Compiler replay agreement: GCC, Clang, and sanitized executables produced stress
  fingerprint `3c02eb6a3db9cc3c` for seed 7605 and 20,000 steps.
- Bounded explorer: `BOUNDED PASS`, depth 4, 1,264 states, 9,200 transitions,
  5,375 denials.
- Active trace replay: five traces PASS.
- KIR generation currency: source fingerprint `24ad3bc20606f593`, program
  fingerprint `7fae42e8d5b085c2`, eleven ordered guards.
- Bootstrap transcription currency: fingerprint `acf1174648fe47f7`.
- Capability value-manifest currency: fingerprint `78ce1a23cf908b80`.
- CAP-REP schema currency: fingerprint `5bd3e08716f9bdfe`.
- DERIVE fact witness: 6,963,200 cases, fingerprint `a2dea114ba75bbd5`.
- DERIVE success commit/frame witness: 577,368 cases, fingerprint
  `5a50b918f6bdfc7d`.
- DERIVE terminal frame witness: 577,368 cases, fingerprint
  `84f6af288db22ca5`.
- Four-operation accepted-sequence boundary and precedence witness: 25 cases,
  fingerprint `1b29e9f3f779ae41`.
- CAP-REP finite witness: 9,309,684 cases total across six recorded domains:

  | Domain | Cases | FNV-1a |
  |---|---:|---|
  | dead payload irrelevance | 3,935,232 | `1e22e1f412ffe725` |
  | admitted live projection | 1,617,408 | `6e344610047dea45` |
  | invalid live rejection | 1,574,244 | `3699a745de2dd9cd` |
  | projected/generated fact equality | 2,076,672 | `534eb0b6fcb69a79` |
  | projected successful commit/frame | 53,064 | `1412bbdae35d1775` |
  | terminal whole-array frame | 53,064 | `d7cee8290747b55d` |

- Vault integrity: all eight original source archives, every selected searchable
  manifest, the external rev0761 lineage archive, and the exact rev0761 anchors
  used by Excavation 009 pass their retained identity checks.
- Predecessor archive at close: SHA-256
  `aa487642e093af3ae2c8937586a17070b45a9626e688df8a7b3f8033d4a0af31`;
  `zipinfo` and `unzip -t` report no archive error. It is not nested in rev0765.
- Recovery provenance: the initially presented linked copy was unreadable, so the
  office recovered from the complete preserved rev0764 working/evidence trees. The
  later valid predecessor archive does not replace the fresh rev0765 generator,
  compiler, sanitizer, witness, trace, explorer, and office replays.
- Active source audit: no permanent Python, shell, Rust, C, or other non-C++
  implementation/harness source; Isabelle/HOL remains the standing proof-language
  exception; no build tree or recursive revision ZIP is shipped.
- Proof-hole scan: no exact `sorry`, `oops`, or `admit` marker in active Isabelle
  theories.
- Isabelle/HOL executable: `UNAVAILABLE`; no `THEOREM` ledger row is claimed.

## Construction delivered

Rev0765 completes bounded objective E0-P4 without adding a K0 operation, object
family, platform primitive, lifecycle mechanism, concurrency mechanism, or Runtime
surface. It introduces the first explicit source-value relation between the fixed
C++20 capability array and the formal capability map.

The active CAP-REP rule is presence-gated:

```text
in-range dead cell           -> formal None
in-range live admitted cell  -> formal Some(fieldwise value)
out-of-range slot            -> formal None
```

A dead cell's holder, generation, object, rights, and parent payload is inert. A
live cell is admitted only with nonzero holder/generation/object id, one of the
three active object tags, a seven-bit rights value, and either an in-range parent
or the explicit no-parent sentinel. The bridge describes values only. It does not
identify C++ object bytes, padding, addresses, enum ABI, or `std::array` layout with
formal state.

`include/slopos/k0/capability_representation.hpp` supplies the C++20 value
projection. `slopos-proof-emit` now generates the capability-value manifest and
Isabelle constants beside the existing bootstrap and trace artifacts. The formal
source is deliberately layered:

- `K0_Capability_Representation.thy` owns the generic proof-value cell/list
  relation, admission, lookup, dead-payload irrelevance, presence, bounds, and
  generic replacement;
- `K0_Derive_Representation.thy` owns the DERIVE-specific fact, child, update,
  frame, sequence, and rejection candidate lemmas.

The representation witness independently pressures dead cells, admitted live
values, invalid live values, projection-only fact extraction, successful child
installation, every-other-cell frame, and terminal whole-array frame. These finite
identities are bounded counterexample-search evidence, not universal proof.

## Defect found and corrected

The bridge exposed a hidden mismatch in the intermediate DERIVE fact record.
Generated C++ reports `requested_subset = false` when the requested rights mask is
invalid because validity is part of `rights_subset`. The formal fact definition had
previously decoded a set and could report subset true. The earlier `rights_valid`
guard meant final transition status already agreed, but exact fact correspondence
did not.

The formal source now states:

```text
requested_subset = requested_valid AND requested subset-of parent.rights
```

This changes no accepted/rejected result. It removes reliance on later guard
precedence to hide a distinct intermediate fact value.

## Vault excavation result

Excavation 009 compared rev0765's presence law with rev0760's abstract partial map
and rev0761's first fixed capability table. It preserved a distinction the new
epoch must not collapse:

```text
capability presence/value    optional authority record
slot lifecycle metadata      possible future allocation/reuse generation state
```

Current K0 has no deletion, reuse, revocation, stale-handle comparison, or
generation-bump operation. Therefore dead capability payload is not lifecycle
authority or currentness. If lifecycle enters later, it requires a separately named
type, relation, operation, and proof obligation. Excavation 009 also separates a
formal projected-authority frame from any future raw C++ object-byte frame claim.

## Claims not made

This revision is not a checked Isabelle theorem session, universal C++20
refinement, proof of the value projection's compiled evaluation, generator proof,
compiler-correctness argument, ABI proof, booted kernel, privileged mapping
implementation, platform isolation proof, concurrency proof, revocation system, or
object-lifecycle model. Formal `MAP`, `SEND`, and `RECEIVE` remain outside the
current representation/refinement bridge.

The load-bearing open edges remain separately recorded, including:

- `OBL-BOOT-REP-001`;
- `OBL-CAP-REP-CXX-001` and `OBL-CAP-REP-001`;
- `OBL-KIR-FACTS-CXX-001` and `OBL-KIR-FACTS-001`;
- `OBL-KIR-COMMIT-CXX-001` and `OBL-KIR-COMMIT-001`;
- `OBL-SEQUENCE-BOUND-001` and `OBL-SEQUENCE-REFINE-001`;
- `OBL-CXX-COMPILER-001` and `OBL-CPP-SEM-001`;
- `OBL-PLATFORM-001`.

## Next office

Execute E0-P5 in `docs/office/NEXT.md`. Check Isabelle availability first and
retain the exact session packet whenever a compatible checker exists. Regardless of
checker availability, construct one independent all-or-nothing C++20 materializer
for the fixed bootstrap, prove or pressure that its exact twelve-cell image enters
CAP-REP with accepted sequence zero, and compare that full image noncircularly with
model/core initialization. Add no command, object family, slot reuse, revocation,
generation rollover, platform effect, generalized IR, or Runtime subsystem.
