# SlopOS rev0767 close report

## Identity

- Revision: `0767`
- Epoch: zero
- Archive name:
  `SlopOS-rev0767-2026.07.11.04.22-isabellecoldstart-moonshotspine-officegate-seventhforge.zip`
- Bounded objective: decide and operationalize the theorem root, prove that a
  fresh or layer-lost office can recover it, re-excavate the moonshot product
  shape, and strengthen the repository without adding a K0 operation.
- Result: `CLOSED-CLEAN rev0767`.

## Decision: Isabelle is the sole theorem root

Isabelle/HOL 2025-2 is retained as the one authoritative theorem root. This is a
SlopOS-specific engineering decision, not a universal ranking of proof assistants.
The deciding facts are:

1. SlopOS is attempting a seL4-shaped relational refinement and security ladder,
   and the directly relevant maintained kernel-proof family is built primarily in
   Isabelle/HOL.
2. The current A0/D0/KIR/proof-value machine is naturally expressed as total
   transition systems, state relations, invariants, induction, records, finite
   words, maps, and Hoare-style obligations in HOL.
3. Isabelle has a mature imperative-program ecosystem worth measuring at the next
   edge: Simpl, the StrictC parser, and AutoCorres2. This does not prove C++20, but
   it offers a bounded source-semantics experiment without first inventing an
   entire low-level verification stack.
4. Abstract semantics, representation relations, initialization, source-island
   semantics, and later security theorems can remain in one checked session graph.
   A second authoritative prover would introduce a new translation theorem and a
   second evidence-currentness protocol.
5. The choice works in the actual constrained cloudtainer. The exact pinned
   release, headless runtime, HOL heap, SMT smoke test, and complete SlopOS session
   have all executed here.
6. Lean remains a serious reconsideration candidate. It is not selected now because
   doing so would require SlopOS to build the OS-refinement conventions, low-level
   libraries, C++ semantics bridge, batch evidence office, and operating system at
   the same time. That would nest a second moonshot inside the first.

The C++20 law remains unchanged. Active implementation, oracle, explorer, test
facility, evidence collector, office, and permanent executable orchestration are
C++20. Isabelle theory source is the standing proof-language exception. The single
shell installer is a narrowly pinned acquisition/extraction mechanism, not a proof
harness.

## Fresh-office continuity is now executable law

A future maintainer does not need this chat transcript. From a freshly extracted
revision they are directed by `README.md` and `OFFICE.md` to:

```text
cmake --preset debug
cmake --build --preset debug -j 2
build/debug/slopos-proof doctor --root .
build/debug/slopos-office open --root .
```

The C++20 tools distinguish `TOOLCHAIN_MISSING`,
`TOOLCHAIN_WRONG_VERSION`, and `TOOLCHAIN_READY`, exit nonzero on the first two,
and print the exact repository-rooted recovery command and guide. CMake registers
both `proof-toolchain-doctor` and `isabelle-session-current` unconditionally;
losing Isabelle cannot silently turn a 21-test graph into a smaller green suite.

The exact working installer supplied during rev0766 is retained byte-for-byte as
`tools/proof/bootstrap-isabelle-cloudtainer.sh`. Its repository and uploaded copies
both hash to:

```text
8669c15efd5e177ffa96e9517f110cd631648a93eddde52780d27947331ffbb9
```

`toolchains/isabelle.lock` binds Isabelle version, session, official archive,
container image manifest, distribution-layer digest and size, installer identity,
exact proof command, and isolated working directory. The 1.23 GB third-party layer
is intentionally not embedded in every SlopOS revision.

The recovery drill was run from a fresh copy with no build directory. It configured
and built the office, retained all 21 CTest entries, opened normally with the
installed toolchain, then simulated a lost launcher. Both `doctor` and `open` failed
nonzero and emitted the exact pinned installer command; `open` reported
`RECOVER_PINNED_ISABELLE_THEN_RERUN_OPEN`.

A real construction failure also improved the design: invoking `isabelle build -c`
from the repository root could remove the sibling CMake `build/` tree. The C++20
runner now executes from `build/isabelle-session` and passes the proof tree by
absolute path. A destructive fixture and a real sentinel replay establish that the
surrounding CMake build survives the clean proof action.

## Moonshot shape after the vault return

SlopOS is now described as one proof-carrying authority and isolation machine with
five named regions:

```text
A/B/C/D theorem + configuration bundles
                |
S  isolated services and compatibility domains
                |
P  mediated authority Runtime
                |
K  tiny privileged authority/isolation core
                |
M  platform realization and assumptions

E  proof, evidence, provenance, claim, and office machinery spans every edge
```

The product directions are:

- A: secure workstation;
- B: cloud micro-VM / hosted-compute substrate;
- C: embedded or separation-kernel-ish appliance;
- D: agent/automation OS in which LLMs are first-class developers and users but
  never ambient authorities.

They are not four kernel forks. Their differences are primarily configuration,
service, threat-model, platform-assumption, and theorem bundles over one small
K/M spine. Agent proposals, portals, validators, receipts, replay, provenance,
leases, and currentness belong primarily in P and E. Drivers, filesystems,
networking, UI, VMM services, compatibility, and agents belong in isolated S
components unless a demonstrated hardware-control requirement earns a narrow K
primitive.

The design keeps two chains explicit:

```text
authority: principal -> delegation -> admission -> effect -> currentness
assurance: requirement -> specification -> refinement -> source/binary/platform -> claim
```

The companion cubes and old SlopOS research repeatedly defend the same negative
law: evidence, representation, observation, review, intent, and model output do not
silently become authority or current effect.

## The infant actually built

The active machine remains deliberately hosted, sequential, and fixed-capacity:

- two domains;
- two private memory objects;
- one endpoint;
- twelve capability cells, four initially live;
- `DERIVE`, `MAP`, `SEND`, and `RECEIVE`;
- deterministic first-failure order;
- ordinary rejection atomicity;
- fail-closed finite sequence exhaustion;
- an independent clear reference model and kernel-shaped fixed-capacity core;
- deterministic traces, differential oracle, bounded explorer, finite witnesses,
  dual-compiler execution, and sanitizer pressure;
- one Isabelle session for A0, D0, KIR, sequence, capability representation,
  bootstrap, invariants, and refinement.

Rev0767 adds no K0 operation, object, platform primitive, concurrency mechanism, or
product feature. It builds the proof and office machinery that must exist before
such growth can be honest.

## Exact close evidence

### Construction and theorem evidence

- Active construction basis:
  `SLOPOS_CONSTRUCTION_BASIS_V1 315 51e9a8e62f26b16b`
- Construction-basis fingerprint in proof packet: `c42c12190c6c2f20`
- Proof-tree fingerprint: `442fe2767ac6d5a1`
- Isabelle: `Isabelle2025-2`
- Session: `SlopOS_K0`
- State: `SESSION_ACCEPTED`
- Proof-hole count: `0`
- Exact build options include `quick_and_dirty=false` and
  `naproche_server=false`.
- Current measured proof-run wall time: approximately 27 seconds.
- Current measured maximum resident set: approximately 835 MiB.
- The theorem ledger names 32 exact Isabelle lemmas; no unlisted implementation,
  compiler, binary, platform, or product theorem is inherited.

### C++20 and oracle evidence

- GCC 14.2 debug build: pass.
- GCC CTest: 21/21 pass, including the exact Isabelle session.
- Clang 17 debug build: pass; 20 nonduplicate tests pass.
- GCC ASan/UBSan: build passes; 19 CTest checks plus direct ASan/UBSan office-open
  pass with `detect_leaks=0`; external Isabelle is checked in the primary lane.
- A full sanitizer CTest log also reached 21/21 pass, but the surrounding
  cloudtainer call failed to return after CTest wrote its complete summary. It is
  retained as a transport observation, not used as the exit-code-bearing sanitizer
  claim.
- Eight canonical outputs agree byte-for-byte across GCC, Clang, and
  GCC/ASan/UBSan after removing only the lane label.
- Depth-4 explorer: 1,264 states, 9,200 transitions, 5,375 denials.
- Deterministic stress: 20,000 commands, final fingerprint
  `9d26edd480837a69`.
- Five active traces replay under the independent model/core oracle.

### Vault and office evidence

- Eight original source archives verify against retained checksums.
- Every searchable selection verifies against its own checksum manifest.
- The rev0761 external lineage anchor matches its recorded SHA-256.
- No recursive Epoch Zero revision ZIP is embedded in the active repository.
- The rev0760 moonshot selection catalogs workstation, hosted-compute, appliance,
  agent-control, boot provenance, platform, static partition, information-flow,
  secure UI, driver-domain, and capability-safe automation pressure.
- Final office audit: pass.
- Construction-basis currentness: pass.
- Fresh/lost-layer resume drill: pass.

## Open edges and non-claims

This revision does not prove C++20 operational semantics, C-versus-C++ equivalence,
compiler correctness, object layout or ABI, linker/binary correctness, boot,
page-table behavior, traps, interrupts, DMA/IOMMU, multicore, weak memory,
information flow, side-channel resistance, or any A/B/C/D product theorem. It is not
a booted kernel and does not have seL4-class assurance.

The load-bearing open edge remains:

```text
checked CAP-REP proof value
       <- ? ->
evaluated constrained C++20 capability-cell projection
```

## Next bounded office

Objective E0-P6 is one measured source-semantics bridge experiment. Acquire and pin
an Isabelle2025-2-compatible AutoCorres2 route and test only a tiny C-compatible
proof island for capability-cell projection. Retain it only if it reproducibly
narrows `OBL-CAP-REP-CXX-001` more than it enlarges the trust and dependency
surface. Otherwise record an exact rejection and formalize only the needed
constrained expression semantics or move the boundary into a smaller generated
semantic language.

No feature growth, second theorem root, platform breadth, or profile fork is
permitted as a substitute for learning from that edge.
