# SlopOS rev0766 close report

## Identity

- Revision: 0766
- Timestamp token: `2026.07.11.03.27`
- Archive: `SlopOS-rev0766-2026.07.11.03.27-isabelleroot-bootstraprep-profileproof-sixthforge.zip`
- Epoch objective closed: E0-P5
- Next bounded objective: E0-P6, one source-semantics bridge experiment for pure capability-cell projection

## Formal-verification decision

Isabelle/HOL 2025-2 is the sole active theorem root. Lean remains a documented
reconsideration candidate, not a parallel specification. Product implementation,
oracle, generator, explorer, proof runner, evidence, office, and vault machinery
remain C++20. Isabelle theories are the proof-language exception; the exact
user-supplied shell installer is the sole active transport-script exception.

The official AFP catalog exposes a 2026-02-07 AutoCorres2 release for
Isabelle2025-2. Rev0766 does not acquire or trust it. E0-P6 will measure the exact
release against one pure C-compatible proof island before deciding whether to retain
that source-semantics route.

## Exact checked result

- Toolchain: `Isabelle2025-2`
- Session: `SlopOS_K0`
- Command: `isabelle build -c -j 1 -o quick_and_dirty=false -d proof SlopOS_K0`
- Source proof-hole markers: zero
- Session exit: zero
- Required completion marker: `Finished SlopOS_K0`, present
- Proof-tree fingerprint: `208e61983015d17b`
- Construction-basis file count: 293
- Construction-basis body fingerprint: `d4f54a940cf7bcd1`
- Construction-basis evidence fingerprint: `c50c6128769eb1c3`
- Exact theorem-map rows: 32

The first real checker run exposed malformed theory transport, insufficient proof
steps, an environmental name collision, and an extensionality gap. Rev0766 repaired
those defects before promoting exact proof-value propositions. No C++ source,
compiler, binary, platform, or product theorem is inferred from HOL acceptance.

## Small construction

The independent all-or-nothing C++20 bootstrap materializer now validates the whole
fixed plan before exposing an image. The shipped plan yields:

- exact image fingerprint `9b6b382bb77b2156`;
- twelve capability cells;
- four live root capabilities;
- eight dead cells;
- accepted sequence zero;
- fifteen distinct malformed-plan rejection classes;
- exact private full-state agreement with separately installed model and core.

Generated Isabelle values and checked lemmas relate that exact image to the formal
capability map, the four roots, dead in-range slots, out-of-range absence, and
sequence zero. The general C++ evaluation and compiler edges remain open.

## Executable close replay

- GCC 14.2: 18/18 tests passed, including the fresh Isabelle session and office audit.
- Clang 17: 17/17 non-duplicate tests passed, including the office audit.
- GCC ASan/UBSan: 17/17 non-duplicate tests passed, including the office audit.
- Seven selected witness/explorer/stress outputs are byte-identical across GCC,
  Clang, and GCC ASan/UBSan.
- Five active traces replayed successfully.
- Depth-4 bounded exploration and deterministic 20,000-step seed 7606 passed.
- Eight original vault source archives and all searchable extraction checksum sets
  verified.
- The C++20 office audit passed independently in all three compiler lanes.

## Retained boundaries

This close does not establish ISO C++20 operational semantics, compiler or binary
refinement, page-table behavior, hardware isolation, boot correctness, multicore
correctness, DMA/IOMMU correctness, information-flow security, side-channel
security, or any A–D product-profile theorem. The four intended product shapes are
one core with profile-specific assumptions, configurations, services, and theorem
bundles—not four kernel forks.

The 2.2 GB Isabelle installation and verified 1.23 GB distribution layer are
external cache state and are intentionally absent from the revision archive. Their
exact identities and the byte-identical recovery script are retained in the cube.
