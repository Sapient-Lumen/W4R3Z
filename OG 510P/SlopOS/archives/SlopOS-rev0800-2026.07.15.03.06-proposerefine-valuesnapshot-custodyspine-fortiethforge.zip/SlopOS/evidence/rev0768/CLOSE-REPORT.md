# SlopOS rev0768 close report

## Identity

- Revision: `0768`
- Epoch: zero
- Archive name:
  `SlopOS-rev0768-2026.07.11.07.07-scalarbridge-autocorresboundary-layerrecovery-eighthforge.zip`
- Bounded objective: close or reject one source-semantics route at the
  capability-cell projection boundary, preserve a tiny C++20 machine, deepen the
  old-vault proof excavation, and prove that a lost proof-toolchain layer can be
  recovered without chat memory.
- Result: `CLOSED-CLEAN rev0768`.

## What was constructed

Rev0768 adds no K0 command, object family, platform primitive, concurrency model,
Runtime subsystem, or product-profile fork. It introduces a smaller proof-facing
implementation boundary inside the existing capability representation:

```text
Capability source value
    -> caprep::scalar::CellValue
    -> caprep::scalar::project
    -> canonical ProjectionValue
    -> existing LogicalCapability projection
    -> CAP-REP proof-value relation
```

`include/slopos/k0/capability_scalar_projection.hpp` is a fixed-width, total,
allocation-free, loop-free scalar decision kernel. It has three result tags:

- dead input: admitted absence, without inspecting payload authority;
- admitted live input: exact fieldwise present projection;
- malformed live input: rejected projection.

The production `project_capability_cell` path now delegates to this scalar kernel.
This removes `std::optional`, arrays, loops, and nested aggregate construction from
the smallest authority-bearing decision that the next source-semantics experiment
must explain. It does not claim that C++ evaluation or compiler behavior has been
proved.

An independent C++20 literal oracle checks the scalar boundary over three recorded
finite domains:

```text
dead       327,936 cases  FNV 3ff1f907c5d2a725
valid      134,784 cases  FNV 93209a6a66ab8da5
invalid    131,187 cases  FNV c6c604c5beb5e375
```

GCC, Clang, and GCC/ASan/UBSan produce byte-identical scalar witness output.

## Formal proof advance

`proof/K0_Capability_Scalar_Projection.thy` is part of the sole `SlopOS_K0`
Isabelle/HOL session. Eight exact lemmas are added and mapped in
`proof/theorems.tsv`:

1. admitted scalar kinds are exactly the three logical object kinds;
2. live-payload admission is equivalent to the explicit scalar guards;
3. every dead carrier projects to absence;
4. rejection is exactly live-and-not-admitted;
5. scalar admission is equivalent to the existing cell-admission relation;
6. every admitted live carrier projects to the exact present payload;
7. scalar and existing capability images agree;
8. dead payload changes are inert at the scalar projection boundary.

The complete theorem ledger now names 40 exact Isabelle lemmas. The exact pinned
session was accepted with:

```text
state                         SESSION_ACCEPTED
version                       Isabelle2025-2
session                       SlopOS_K0
quick_and_dirty               false
naproche_server               false
proof holes                   0
construction basis            SLOPOS_CONSTRUCTION_BASIS_V1 334 d45a5ecf41fe7ad0
basis fingerprint             4e56da9ae877a768
proof-tree fingerprint        68e92ba0e408268e
wall time                     27.13 seconds
maximum resident set          1,120,368 KiB
```

The new theorem class is deliberately `I0-value`, not `K0-source` or
`K0-executable`. `OBL-CAP-SCALAR-CXX-001` remains `OPEN_DEBT`; the source and
compiler edges have not been collapsed into the proof-value theorem.

## AutoCorres2 experiment

The office measured, rather than merely discussed, the planned AutoCorres2 route.
The exact Isabelle2025-2-compatible AFP source was:

```text
repository   isabelle-prover/mirror-afp-2025-2
commit       86a64272624c861704045a8beacee9c0178cdf2e
archive      afp-2025-2-86a64272624c861704045a8beacee9c0178cdf2e.tar.gz
bytes        119,775,327
sha256       994a3486f26d98f329d8c1da15dfad49c5499a50fbca858a5ed083be11fbdc57
selected     Simpl, Word_Lib, AutoCorres2
```

The dependency stack did not reach an accepted SlopOS island theorem within the
measured office. A live observation after more than seven minutes still showed
Simpl building, with roughly 2.15 GiB Poly/ML RSS and 1.26 GiB Java RSS. The
cloudtainer layer was subsequently lost. The revision does not claim that
AutoCorres2 caused that loss, and the vanished raw build log is not promoted as
checker evidence.

The route is rejected as a standing office dependency for this scalar target for a
more fundamental reason: even a successful theorem over a hand-written C island
would leave the relation to the authoritative C++20 source unproved. A maintained C
mirror is prohibited. AutoCorres2 remains gated research for a future authoritative
C island, a checked generated C/C++ common source, an externally cached cheap AFP
stack, or a proportionately larger C-facing component.

This is a route-specific engineering rejection, not a rejection of AutoCorres2 or
Isabelle. Isabelle remains the sole theorem root.

## Real lost-layer recovery drill

During the experiment, the ephemeral cloudtainer layer containing the unsealed
worktree, Isabelle installation, AFP source, and caches disappeared. The sealed
rev0767 archive remained available. Rev0768 was reconstructed from that archive and
then exercised the documented recovery law:

1. configure and build the C++20 office without Isabelle;
2. observe `TOOLCHAIN_MISSING` from both `slopos-proof doctor` and
   `slopos-office open` with nonzero exit;
3. receive the exact repository-rooted bootstrap command from the tools;
4. run the retained byte-pinned installer;
5. recover `Isabelle2025-2` and `TOOLCHAIN_READY`;
6. rerun the exact `SlopOS_K0` session successfully with zero proof holes;
7. reopen and audit the office from repository state alone.

The retained toolchain lock identifies:

```text
container manifest  sha256:9bd33b183c399327c5d554fc8cde27c29b5d2b20cdc6fe7a604caa3f951018fc
distribution layer  sha256:f7469e3dcdb67ea5c6876b5bd3e216c65aa130d917ca5c9ff52b8922026744eb
layer bytes         1,234,983,766
official archive    Isabelle2025-2_linux.tar.gz
official bytes      1,228,480,874
official sha256     a20a507bc7c1270d8be96a9f3fbec06345387789d2dc2c4d3df6260d47bfb33c
installer sha256    8669c15efd5e177ffa96e9517f110cd631648a93eddde52780d27947331ffbb9
```

The large third-party distribution remains outside the SlopOS revision archive.
Installation remains prerequisite machinery, not theorem evidence.

## Vault excavation and promoted law

Excavation 012 returns to exact rev0760 sources concerning static partitions,
verification-stack selection, claims and invariants, the abstract machine,
verification layering, minimum proof slicing, verification strategy, and
bootstrappable toolchains. Eleven text artifacts are copied into a checksummed
searchable selection under:

```text
vault/searchable/rev0760/source-semantics-proof-spine/
```

The excavation promotes four laws without restoring the old broad roadmap:

- functional-model theorems and implementation correspondence are separate proof
  obligations;
- the first strong product theorem should come from a small closed configuration,
  not from importing all four product vocabularies into K0;
- toolchain provenance and diverse compilation matter, but are separate from
  source refinement;
- a C proof island cannot acquire authority over C++20 merely by semantic
  resemblance or synchronized maintenance.

The source archives and all eight searchable checksum manifests verify. No recursive
Epoch Zero revision ZIP is embedded.

## Office and repository continuity

The compulsory open path now names DEC-0020 and the scalar projection document. The
office auditor checks:

- the scalar source boundary and production delegation;
- the new theory in the sole proof root;
- all three scalar obligations and exact witness fingerprints;
- 40 theorem mappings;
- the source-semantics vault excavation and VPR-021 through VPR-024;
- exact construction-basis and theorem-currentness evidence.

The next maintainer is directed to Objective E0-P7 only: close or reject one exact
source relation for the frozen scalar C++20 kernel. The permitted outcomes are a
direct mechanized semantics for the exact fragment, or a generated implementation
whose generator/source relation is itself checked. Reintroducing a hand-written C
mirror, a second theorem root, or feature growth is not an acceptable substitute.

## Exact implementation evidence

### Primary GCC lane

- GCC 14.2 clean debug build: pass.
- CTest: 22/22 pass.
- The graph includes the exact Isabelle session, office audit, and office open.
- Scalar, CAP-REP, bootstrap, sequence, DERIVE-fact, and DERIVE-commit witnesses:
  pass.
- Depth-4 explorer: 1,264 states, 9,200 transitions, 5,375 denials.
- Stress seed 7608: 20,000 commands, final fingerprint
  `73b823119769ea9f`.
- Five active traces replay with model/core agreement.

### Independent Clang lane

- Clang 17 clean debug build: pass.
- Nineteen native C++ tests and the exact toolchain doctor: 19/19 pass.
- The formal session is not duplicated in this secondary lane.
- Scalar, CAP-REP, bootstrap, sequence, DERIVE-fact, DERIVE-commit, explorer, and
  stress outputs agree exactly with GCC.

### GCC ASan/UBSan lane

- Clean sanitizer build: pass.
- Native tests 1–10 and 11–19 pass in two explicit CTest segments.
- Scalar, CAP-REP, bootstrap, sequence, stress, and office-open direct checks pass
  with `detect_leaks=0` and halt-on-error behavior.
- The formal session remains the responsibility of the primary lane; sanitizer
  silence is not a refinement theorem.

## Cold archive extraction drill

A provisional archive containing the exact active basis and pre-seal evidence was
extracted into a directory with no build tree. From that extraction:

- GCC 14.2 configured and built all 66 targets from scratch;
- the pinned Isabelle toolchain reported `TOOLCHAIN_READY`;
- the office opened successfully before a new proof run using retained close
  evidence;
- a fresh direct Isabelle session was accepted with the same proof-tree
  fingerprint and zero holes;
- an immediate repeated Isabelle CTest invocation was also accepted in 26.31
  seconds;
- the remaining 21 nonduplicate CTest entries passed 21/21, including office audit
  and office open;
- the bounded explorer repeated 1,264 states and 9,200 transitions;
- both active-tree and retained-evidence checksum manifests verified.

The final archive differs from that provisional archive only by addition of these
cold-drill logs and regenerated evidence checksums; the 334-file active construction
basis is unchanged.

## Non-claims and open edges

Rev0768 does not prove:

- general C++20 operational semantics;
- evaluation of the exact scalar C++20 function under a formal C++ source model;
- object layout, enum ABI, lifetime, aliasing, or undefined-behavior exclusion for
  arbitrary callers;
- compiler, linker, binary, or boot-image correctness;
- privileged page-table, trap, interrupt, timer, DMA/IOMMU, or device behavior;
- concurrency, multicore, weak-memory, information-flow, or side-channel security;
- any deployable A/B/C/D product theorem;
- seL4-equivalent assurance.

The infant remains hosted, sequential, and fixed-capacity: two domains, two private
memory objects, one endpoint, twelve capability cells, and DERIVE/MAP/SEND/RECEIVE.
The construction method grew; K0 did not.

## Next bounded office

Objective E0-P7 must connect the exact scalar C++20 source text to a checked semantic
object without pretending that tests or proof-value equivalence establish source
execution. It should begin by freezing the admitted syntax, type-width assumptions,
conversion rules, and result construction for `caprep::scalar::project`, then either:

1. formalize and prove an evaluator for that exact fragment in Isabelle while
   binding it mechanically to the source; or
2. generate the C++20 fragment from a smaller proved representation and check the
   generator/source identity.

Whichever route is chosen must retain the compiler/binary edge as a separate debt.
No new K0 feature is authorized until this experiment materially strengthens the
source relation or records a sharper rejection.
