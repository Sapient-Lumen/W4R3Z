# Content addressing, provenance, and attestation — bounded synthesis

A content digest answers “which bytes?” It does not by itself answer “who produced
or approved them?”, “under which process?”, “which configuration was used?”, or
“does this evidence satisfy my policy?”

Rev0798 therefore keeps four layers separate:

```text
manifest subject -> evidence observation -> verifier/reviewer decision -> release
```

SLSA and in-toto are useful future shapes because both require an explicit subject
and typed statement/predicate. Reproducible-builds work shows why the build
environment, timestamps, paths, ordering, and archive metadata need deliberate
control. No SLSA level, in-toto signature, reproducible build, or release attestation
is claimed in this revision.

Official sources accessed 2026-07-15:

- https://slsa.dev/spec/v1.2/build-requirements
- https://slsa.dev/spec/v1.2/verifying-artifacts
- https://in-toto.io/Statement/v1
- https://in-toto.io/attestation/test-result/
- https://reproducible-builds.org/docs/timestamps/
- https://reproducible-builds.org/docs/source-date-epoch/
- https://reproducible-builds.org/docs/build-path/
