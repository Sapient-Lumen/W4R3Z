# C++20 value-semantics route assessment — rev0773

## Question

What machinery closes the smallest honest value-semantics rung for the frozen
proof companion while preserving Isabelle as the sole theorem root and C++20 as the
permanent executable language?

The target was not “formalize C++.” It was one 90-line, no-include companion whose
authority-bearing behavior is a total scalar projection.

## Candidates reviewed

### 1. Closed Isabelle deep embedding — retained

Measured result:

```text
one new theory              716 lines / 32995 bytes
second theorem prover       none
new permanent executable    none
new K0 operation            none
frozen companion changed    no
mapped new theorems         6
supporting checked lemmas   18 total in the theory
```

The model contains only the used value constructs and makes failure explicit through
option-valued evaluation. It proved the exact raw aggregate image before scalar
observation and connected the result to the pre-existing parsed certificate.

Cost introduced:

- the AST is manually normalized rather than derived from tokens;
- the adequacy of its selected rules to the relevant C++20 clauses is not yet
  mechanized;
- source-to-AST adequacy remains a separate named obligation.

The retained route removes more uncertainty than it adds because those residuals are
smaller and more explicit than the former umbrella “C++20 semantics” debt.

### 2. AutoCorres2 / C island — not retained for this edge

AutoCorres2 is current Isabelle infrastructure for C program verification and
provides a C parser plus abstraction machinery. Primary project page:

```text
https://isa-afp.org/entries/AutoCorres2.html
```

Using it here would require either:

```text
hand-maintained C mirror
or
generated C source + exact generation proof
```

and then a checked C/C++ equivalence relation for the same source values. For this
companion that relation is not smaller than the direct closed model. It would also
add a large AFP/toolchain dependency to cold-start recovery before the first C++
source edge was closed.

AutoCorres2 remains a serious candidate for a future deliberately C-shaped platform
island, such as a tiny page-table primitive, when the product source and proof source
can genuinely be the same admitted text.

### 3. BRiCk/cpp2v — not retained as current authority

BRiCk provides a modern C++ formalization and `cpp2v` translation into Rocq/Coq:

```text
https://github.com/bluerock-io/BRiCk
https://skylabsai.github.io/BRiCk/
```

That makes it relevant evidence that broad modern-C++ verification machinery exists.
It does not fit current office law without adding:

- a second theorem root;
- a second proof toolchain and recovery protocol;
- a translation/currentness contract for cpp2v;
- an Isabelle/Rocq result correspondence or a governance rule for competing roots.

Those costs may be justified later for independent checking or a compiler-facing
subsystem. They are disproportionate for this frozen scalar value program.

### 4. Historical C++ semantics formalizations — research only

Older HOL/Isabelle and axiomatic C++ work informs the difficulty of values,
initialization, sequencing, and object semantics, but it is not a current C++20
source bridge that the cloudtainer can recover and run under the existing sole root.
No historical artifact was promoted by name alone.

### 5. GCC/Clang constant evaluation and differential execution — retained as tests

Selected compilers can compile the exact companion, evaluate static samples, assert
its type/range envelope, and agree with the active scalar projection over 593,907
calibrated cells. That is valuable counterexample pressure and implementation
conformance. It is not a language semantics or compiler-correctness theorem.

## Standards review

The public C++20-era working draft N4868 was used as the primary review surface:

```text
https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/n4868.pdf
```

The review focused on fundamental unsigned integer properties, equality and
relational operators, logical short-circuiting, conditional expressions, scoped
enumerations, aggregate initialization, `if`, and `return`.

The standard text helps identify the adequacy claim that remains. Reading it is not a
mechanized derivation from the exact token stream and creates no theorem evidence.

## Decision

Retain the direct Isabelle value-language model and classify its result narrowly:

```text
normalized AST semantics          THEOREM
selected implementation envelope  CONFORMANCE
source tokens -> normalized AST    OPEN_DEBT
compiler preservation              OPEN_DEBT
```

Do not install AutoCorres2, Rocq, BRiCk, or a general C++ frontend into the permanent
office for this rung.

## Stop condition

E0-P12 receives one bounded attempt at the exact source-to-normalized-AST relation.
The attempt may retain a route only if it is materially independent of the source
shape it claims to validate and smaller than the edge it removes. Otherwise record a
measured rejection, keep the adequacy debt explicit, and move to the first booted
static-isolation experiment.
