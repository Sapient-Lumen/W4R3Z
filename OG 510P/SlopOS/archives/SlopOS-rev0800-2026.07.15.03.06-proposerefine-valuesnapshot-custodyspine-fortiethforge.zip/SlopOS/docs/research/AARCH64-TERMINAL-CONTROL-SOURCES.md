# AArch64 terminal-control source notes

Last refreshed: 2026-07-14.

## Purpose

These sources constrain M0-P8R's engineering choice. They are not formal
semantics, Isabelle imports, live call-frame evidence, or permission to execute.

## Official Arm and ABI sources

1. **RET — Return from subroutine**
   - Arm A-profile A64 ISA, 2026-03.
   - `https://developer.arm.com/documentation/111108/2026-03/Base-Instructions/RET--Return-from-subroutine-`
   - The selected engineering reading is that RET is a subroutine-return branch
     and defaults to X30 when no register is written in the assembly spelling.
2. **BR — Branch to register**
   - Arm A-profile A64 ISA, 2026-03.
   - `https://developer.arm.com/documentation/ddi0602/2026-03/Base-Instructions/BR--Branch-to-register-`
   - This remains a distinct non-subroutine register-branch role.
3. **ERET — Exception return**
   - Arm A-profile A64 ISA, 2026-03.
   - `https://developer.arm.com/documentation/111108/2026-03/Base-Instructions/ERET--Exception-return-`
   - The selected engineering reading requires saved exception state and is not
     interchangeable with an ordinary leaf return.
4. **Procedure Call Standard for the Arm 64-bit Architecture**
   - ARM-software/abi-aa, AAPCS64 2025Q4.
   - `https://github.com/ARM-software/abi-aa/blob/main/aapcs64/aapcs64.rst`
   - X30/LR is the link register; X0-X7 are parameter/result registers.

The exact source-envelope label compiled into the certificate is:

```text
Arm A-profile A64 ISA 2026-03 RET+BR+ERET; AAPCS64 2025Q4 X30/LR
```

Its repository FNV is `b9c30a9a07f1ecaa`.

## Comparative seL4 engineering sources

These are design comparison, not normative basis:

- `seL4_tools/elfloader-tool/src/arch-arm/armv/armv8-a/64/mmu-hyp.S`
  uses ordinary callable assembly helpers with explicit `ret` after preserving
  the link register when nested calls are made.
- `seL4/src/arch/arm/64/head.S` uses explicit call edges during boot and keeps
  kernel entry/handoff logic separate from helper routines.

The relevant comparison is structural:

```text
helper return
!= boot handoff
!= exception return
```

No seL4 theorem or source property transfers to SlopOS.

## Selected role

`slopos_m0_s2_activate` is an M-layer leaf helper. Its caller must establish and
own X30. The function does not select a guest PC, boot continuation, ELR_EL2,
SPSR_EL2, or an adjacent fallthrough object.

## Open questions after selection

- Which exact call site establishes X30?
- What authority relation owns the continuation address?
- Which stage-1 mapping makes the continuation fetch-visible at EL2?
- Is pointer authentication or guarded-control-stack support selected later?
- What formal Arm model will establish RET behavior?
- How is completion of the preceding system-register and maintenance sequence
  related to the return?
- Which platform proof discharges the twelve live requirements?

## Non-collapse law

```text
official source
!= formal semantics
!= selected role
!= repaired bytes
!= live X30
!= return execution
!= completed continuation
```
