# C++20 unsigned/value refinement sources

**Accessed:** 2026-07-15  
**Use:** bounded design pressure for rev0800; no external source is imported as a
SlopOS theorem.

## ISO C++ working draft N4868

Source: *Working Draft, Standard for Programming Language C++*, N4868 (2020).

- https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/n4868.pdf

Relevant constraints:

- unsigned integer arithmetic is defined modulo one more than the largest
  representable value;
- `<cstdint>` exact-width typedefs such as `uint16_t`, `uint32_t`, and `uint64_t` are
  supplied only when the implementation has the corresponding exact-width integer
  type.

Rev0800 does not use modulo wrap as accepted-sequence semantics. It admits an
accepted state-changing operation only when `current != UINT64_MAX`, then advances
once. Static assertions record the exact widths on every compiled witness. These are
compiler conformance observations, not a proof of compiler correctness or of the
whole source body's intended meaning.

## seL4 refinement architecture

Source: Gerwin Klein et al., *seL4: Formal Verification of an OS Kernel*.

- https://sel4.systems/Research/pdfs/sel4-formal-verification-os-kernel.pdf

The useful design pressure is layered correspondence: relate representations and
state transitions explicitly rather than treating testing, source, or a low-level
artifact as the specification itself. SlopOS borrows that shape only. No seL4 theorem,
assumption set, language restriction, or platform conclusion transfers to this C++20
specimen.

## Isabelle system documentation

Official distribution/documentation entry points:

- https://isabelle.in.tum.de/
- https://isabelle.in.tum.de/dist/Isabelle2025-2/doc/jedit.pdf

The project pins Isabelle2025-2 as an external proof tool identity. Presence of theory
text, a hole scan, or a predecessor result is not a current session result. The tool
must run outside the living tree against the exact construction basis.

## Bounded inference

Together these sources support three engineering choices, not a completed proof:

1. name exact finite widths instead of assuming host integer folklore;
2. prevent semantically forbidden wrap before mutation even when unsigned wrap is
   language-defined; and
3. keep the executable value relation, HOL relation, C++ source semantics, compiler,
   and platform as separate edges.
