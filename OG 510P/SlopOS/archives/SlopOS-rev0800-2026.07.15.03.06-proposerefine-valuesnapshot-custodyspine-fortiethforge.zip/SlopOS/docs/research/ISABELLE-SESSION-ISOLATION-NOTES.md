# Isabelle2025-2 session-isolation source notes

## Scope

These notes record the primary-source facts used by DEC-0023. They justify the
shape of the SlopOS proof-process boundary; they do not turn the Isabelle runtime,
host operating system, or filesystem into proved components.

## Pinned primary source

The source is the **Isabelle2025-2 System Manual**, especially:

- Chapter 1.1, “Isabelle settings”; and
- Chapter 2.3, “Invoking the build process.”

The manual is shipped inside the pinned Isabelle application as
`doc/system.pdf`. The close packet records the actual `Isabelle2025-2` version
used by the C++20 runner.

## Facts retained

1. Isabelle initializes site settings and then user settings beneath
   `ISABELLE_HOME_USER`; the latter is normally derived from the process user
   home. A repository-private `HOME` therefore gives the SlopOS target session a
   repository-private user settings and heap/database namespace, subject to the
   pinned distribution's own settings logic.
2. `isabelle build -c` cleans selected sessions and their descendants before the
   requested build. `isabelle build -f` forces a fresh build of selected sessions
   and their requirements.
3. Isabelle's build documentation does not promise coordination between
   independent clients with overlapping session state; client-side coordination is
   required. SlopOS therefore serializes theorem-bearing runs with an exclusive
   repository lock.
4. `-j 1` limits local build jobs. The private settings additionally constrain
   prover threads and Java/PolyML heap ceilings for this cloudtainer.

## Local inference and observed defect

During the rev0769 replay, CMake products disappeared while the old proof test was
running from a proof workspace nested under the ordinary `build/` tree. The replay
did not isolate enough variables to prove that Isabelle's `-c` implementation alone
removed those files. DEC-0023 therefore records the event as an observed continuity
defect, not as a theorem about Isabelle internals.

The repair is stronger than that uncertain causal story requires:

```text
separate .slopos-work subtree
+ private HOME and target database
+ no -c or -f
+ exclusive lock
+ supervised process group
+ post-run CMake sentinel evidence
```

This design makes the target-session mutation boundary explicit and testable even if
the original loss involved an interaction among runner placement, interruption,
cleanup, or container behavior.

## What must be rechecked after an Isabelle upgrade

- user-home and heap/database path behavior;
- meanings of `-c`, `-f`, `-j`, and build options;
- session export command behavior;
- completion markers and log format used by the evidence runner;
- process-tree behavior under interruption;
- resource ceilings needed by the current theory graph.

No Isabelle upgrade is accepted merely because the theories appear to parse.
