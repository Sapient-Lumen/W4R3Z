# AutoCorres2 proof-island experiment — measured rejection as a standing bridge

## Question

Could Isabelle2025-2 AutoCorres2 cheaply prove the exact capability-cell projection
and materially narrow the C++20 source-semantics edge?

This was Objective E0-P6. The answer for the active cloudtainer and current source
shape is **not as the standing ordinary-office bridge**.

AutoCorres2 is not rejected as a verification system. It is a mature route from a
substantial C subset through the Simpl semantics into Isabelle/HOL. The rejection is
specific to one tiny SlopOS C++20 function, the active tool budget, and the absence
of a proved C-to-C++ correspondence.

## Exact source measured

The experiment acquired the Isabelle2025-2 AFP mirror at:

```text
repository  isabelle-prover/mirror-afp-2025-2
commit      86a64272624c861704045a8beacee9c0178cdf2e
archive     afp-2025-2-86a64272624c861704045a8beacee9c0178cdf2e.tar.gz
bytes       119775327
sha256      994a3486f26d98f329d8c1da15dfad49c5499a50fbca858a5ed083be11fbdc57
selected    thys/Simpl, thys/Word_Lib, thys/AutoCorres2
```

The official AFP entry is `https://isa-afp.org/entries/AutoCorres2.html`; the
release page identifies Simpl and Word Library as dependencies. Third-party source
was not added to the SlopOS revision archive.

## Command measured

```text
isabelle build -c -j 1 \
  -o quick_and_dirty=false \
  -o naproche_server=false \
  -d <AFP>/thys/Simpl \
  -d <AFP>/thys/Word_Lib \
  -d <AFP>/thys/AutoCorres2 \
  AutoCorres2_Main
```

A live process snapshot after more than seven minutes still showed `Simpl` being
built. The Poly/ML process was approximately 2.15 GiB resident and the coordinating
Java process approximately 1.26 GiB resident. Before the stack reached
`AutoCorres2_Main` or a SlopOS island theorem, the cloudtainer layer was lost. The
sealed rev0767 archive remained available; the worktree, Isabelle installation, AFP
source, build state, and unsealed logs did not.

The temporal association is not claimed as proof that AutoCorres caused the layer
loss. Because the unsealed raw log vanished with the layer, the resource snapshot is
an operator observation, not promoted checker evidence. The durable conclusion does
not depend on causation: this stack did not deliver a theorem within the ordinary
turn budget and would still prove C rather than the C++20 product source.

## Recovery result

The event supplied a real cold-office drill:

1. extract the sealed rev0767 archive;
2. build the C++20 office with no Isabelle installed;
3. observe `TOOLCHAIN_MISSING` from `doctor` and `office open`;
4. run the exact emitted bootstrap command;
5. obtain `TOOLCHAIN_READY` for Isabelle2025-2;
6. rebuild the exact `SlopOS_K0` session successfully with zero proof holes.

Rev0768 retains the machine logs for that recovery. This validates the recovery
mechanism; it does not make an external tool installation proof evidence.

## Why the route does not close the row

Even a successful AutoCorres theorem over a hand-written C function would leave:

```text
C proof-island source
   ?= C++20 scalar::project source
   ?= compiler interpretation
   ?= linked executable behavior
```

A manually synchronized C mirror is another unproved implementation. A generated C
mirror adds generator and C/C++ common-subset obligations. Neither may be relabeled
as `OBL-CAP-SCALAR-CXX-001` without an exact correspondence theorem.

For a thirty-line scalar decision, the Simpl/Word_Lib/AutoCorres dependency and
session envelope are larger than the theorem gain unless the C/C++ correspondence
is solved first.

## Decision

- Do not make AutoCorres2 an office prerequisite or normal CTest dependency.
- Do not keep a hand-maintained C mirror in the active proof spine.
- Keep Isabelle/HOL as the sole theorem root.
- Preserve AutoCorres2 as a future optional research route when one of these gates
  fires:
  - SlopOS deliberately admits C as authoritative implementation source for a
    proof island;
  - an exact generated C/C++ common-source relation is checked;
  - the AFP stack is externally cached and its marginal office cost is small;
  - a larger C-facing platform component makes the dependency proportionate.
- Pursue the direct scalar-value semantics boundary now and keep exact C++
  evaluation plus compiler preservation open.

This is a measured route rejection, not a proof-system popularity judgment.
