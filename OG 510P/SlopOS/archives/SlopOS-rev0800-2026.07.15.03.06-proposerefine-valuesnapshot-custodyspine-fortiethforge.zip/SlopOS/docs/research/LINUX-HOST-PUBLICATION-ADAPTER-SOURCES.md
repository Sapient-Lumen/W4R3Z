# Linux host-publication adapter source assessment

## Selected primary engineering sources

This note records the current source basis for the narrow rev0795 Linux adapter.
It does not import source prose as theorem premises.

### Linux `mmap(2)`

Primary page:

```text
https://man7.org/linux/man-pages/man2/mmap.2.html
```

Selected constraints:

- with a null address hint, the kernel chooses a page-aligned address;
- `MAP_ANONYMOUS` creates a mapping not backed by a file and initialized to
  zero;
- `MAP_PRIVATE` requests a private copy-on-write mapping;
- the call returns `MAP_FAILED` on failure.

Rev0795 independently checks exact selected extent and returned alignment before
copying. It does not rely on zero initialization for correctness.

### Linux `mprotect(2)`

Primary page:

```text
https://man7.org/linux/man-pages/man2/mprotect.2.html
```

Selected constraints:

- the address must be page aligned;
- `PROT_READ`, `PROT_WRITE`, and `PROT_EXEC` request corresponding access modes;
- architecture, kernel, and process-personality details can affect effective
  behavior;
- success reports acceptance of the host request, not AArch64 stage-2 state.

The adapter requests `PROT_READ | PROT_EXEC` after exact copy/readback and never
executes the page.

### Linux `sysconf(3)`

Primary page:

```text
https://man7.org/linux/man-pages/man3/sysconf.3.html
```

Selected constraint:

- `_SC_PAGESIZE` / `_SC_PAGE_SIZE` exposes the runtime page size.

The selected experiment rejects any result other than exactly 4,096 bytes.

## Source-to-claim fence

```text
manual page
!= formal POSIX semantics
!= libc implementation theorem
!= Linux-kernel correctness
!= returned mapping ownership theorem
!= guest/physical publication
!= AArch64 page-table or cache effect
```

These sources constrain implementation choices and future review. A later formal
Linux or architecture model must be admitted as a separately identified proof
input.
