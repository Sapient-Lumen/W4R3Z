# C++20 proof-route assessment — rev0768

## Standing constraints

- authoritative implementation and permanent executable harness: C++20;
- sole theorem root: Isabelle/HOL 2025-2;
- no hand-maintained shadow implementation may be treated as refinement;
- tests, finite exploration, SMT, and sanitizers retain bounded/auxiliary classes;
- source, compiler, binary, platform, and profile edges remain separate;
- no new K0 operation or M0 mechanism enters merely to make a proof route look
  substantial.

## Route A — generated restricted C++20 from KIR-0

**Retained implementation/refinement skeleton.**

Advantages:

- one closed guard programme emits C++ and Isabelle data;
- no duplicated authoritative DERIVE guard policy;
- exact source/program fingerprints and fail-closed parsing;
- direct high-speed C++20 counterexample pressure;
- visible value/fact/commit/sequence/compiler debts.

Limits:

- generator correctness remains trusted;
- generated identity does not prove C++ interpretation;
- no admitted-subset C++20 operational semantics is present;
- compiler/ABI/binary behavior remains open;
- KIR-0 is intentionally not a general transition language.

Route A remains active, but its next work is one source edge, not another operation.

## Route B — C parser and AutoCorres2 proof island

**Measured and rejected as standing office machinery for the current edge.**

Rev0768 acquired an exact Isabelle2025-2-compatible AFP source identity and began a
clean `Simpl`/`Word_Lib`/`AutoCorres2_Main` build. The dependency stack remained in
`Simpl` after more than seven minutes and used multiple GiB of resident memory before
the environment was lost. No SlopOS theorem was accepted through it. The resource
observation is retained without claiming that the build caused the later layer loss.

The decisive semantic cost is independent of resources: AutoCorres2 establishes C
semantics. The product source is C++20. A hand-maintained C mirror creates another
implementation relation; a common schema removes text drift but does not prove C
and C++ interpretation. Therefore Route B does not close
`OBL-CAP-SCALAR-CXX-001` or `OBL-CAP-REP-CXX-001` in its measured form.

Route B reopens only when:

- a component is authoritatively written in C for a shockingly good proof/platform
  reason;
- a checked common-source translation relates the C and C++ artifacts;
- an externally cached, reproducible stack is proportionate to a larger named edge;
- or the target is a C-facing platform boundary for which the C theorem directly
  applies.

## Route C — direct semantics for the admitted scalar C++ fragment

**Selected E0-P7 route candidate.**

The active scalar function uses only fixed-width unsigned values, a Boolean,
comparisons, Boolean connectives, conditionals, and aggregate return. A shallow
Isabelle semantics can be restricted to exactly those constructs. A deterministic
C++20 source binder must reject any unrecognized syntax and bind the formal term to
the exact active source.

Advantages:

- theorem speaks about the language fragment actually admitted;
- no C/C++ shadow relation;
- semantic surface follows the tiny function rather than general C++20;
- compiler/binary edge remains visible.

Costs:

- the source binder/parser becomes trusted until separately verified;
- ISO C++ details must be stated rather than assumed from intuition;
- widening the function can widen the semantics and proof maintenance;
- a source hash alone is not interpretation.

Retain only if the binder plus semantics is smaller and clearer than the edge closed.

## Route D — generated authoritative scalar source

**Second E0-P7 candidate.**

One tiny closed semantic source could emit the C++20 body and Isabelle term. This is
acceptable only if the source language, emitter mapping, and generated artifacts are
small, deterministic, fail-closed, and independently pressure-tested. Shared input
eliminates hand-copy drift. It does not make emitter correctness or C++ evaluation a
theorem automatically.

This route is attractive when the direct source binder would be larger than a tiny
closed grammar. It is rejected if it becomes a general KIR or hides a new interpreter
inside the trusted core.

## Route E — compiler IR or binary semantics

**Long-term route, not an Epoch Zero construction target.**

Compiler AST/IR validation, proof-producing translation, translation validation, or
binary-level verification could eventually remove larger language/compiler
assumptions. Building a general C++ frontend or binary verifier before one scalar
source theorem is disproportionate.

## Auxiliary routes

CBMC/ESBMC, sanitizers, fuzzing, differential testing, exhaustive finite search, and
SMT remain valuable counterexample engines. They do not replace the Isabelle theorem
root or silently close source/compiler arrows. A proof-producing auxiliary route may
be reconsidered only with an explicit checker and claim boundary.

Lean, Rocq, HOL4, F*, Dafny, Why3, and temporal tools remain specialist or
reconsideration options. None currently closes the C++20 bridge without creating
another authoritative stack.

## Rev0769 measured outcome

Route D was selected for the one scalar target, but only in a deliberately narrow
form:

1. `K0_Capability_Scalar_Source.thy` owns a closed seven-atom program and a total
   evaluator.
2. Six Isabelle lemmas establish that the exact program evaluator equals
   `v0_scalar_project` and preserves the canonical dead, rejected, and present
   cases.
3. A closed Isabelle/ML renderer emits one C++20 header from the normalized program
   value.
4. The permanent C++20 proof runner exports that exact generated file after the
   accepted session and rejects any byte difference from the header compiled by the
   repository.
5. The renderer remains trusted, and ISO C++20 parsing/evaluation, compiler, ABI,
   binary, boot, and platform behavior remain open obligations.

The first reflection implementation used Isabelle dynamic code evaluation for the
closed program value. In this cloudtainer it expanded into disproportionate generated
code and memory pressure. It was removed rather than normalized into standing
machinery. The retained route uses kernel-checked simplifier normalization under the
exact program definition before reflecting the finite constructor value. This is a
local resource measurement, not a general judgment on Isabelle code generation.

Route C is no longer a competing current implementation. Its useful core becomes the
next bounded translation-validation experiment: independently tokenize or bind only
the exact generated fragment, reject all other syntax, and relate the resulting
canonical form to the seven-atom program. That experiment may narrow
`OBL-CAP-SCALAR-CXX-001`; it cannot close the compiler edge.

## Route state entering rev0772

1. Keep Route A as the implementation/refinement skeleton.
2. Retain Route D for `caprep::scalar::project` because it now removes theorem/source
   drift with an exact accepted-export/active-byte gate.
3. Keep Route B quarantined behind DEC-0020 gates.
4. Retain the measured Route C exact-fragment binder from E0-P8 against the exact
   Route D output, with its parser implementation and language adequacy named as debt.
5. Retain the E0-P9 direct HOL structural evaluator and independent C++20 bounded
   witness; do not mistake either for ISO C++20.
6. E0-P10 retained the proof-owned self-contained companion and rejected the
   derivation checker because it merely moved trust.
7. Promote no umbrella obligation from generated bytes, certificate identity,
   structural execution, or bounded agreement.
8. Defer Route E until an admitted source-semantics relation and a platform mapping
   primitive justify carrying proof toward binary behavior.
9. Add no operation, platform primitive, C mirror, second prover, third evaluator,
   or general C++ frontend during this front-edge experiment.

## Rev0772 measured route choice

The no-include companion is retained as the next semantics target. A binder
derivation checker is rejected at current scale. Direct tiny Isabelle semantics is
preferred for E0-P11 because old HOL C++ semantics is not a current Isabelle/C++20
frontend and a C/AutoCorres2 mirror would add a C/C++ equivalence edge. AutoCorres2
may reopen only for identical or mechanically related source whose added relation is
measurably smaller.
