# Revocation, reclamation, path safety, and evidence sources

This note records design pressure, not imported authority.

## Capability withdrawal and reuse

The seL4 Reference Manual 15.0.0 distinguishes deleting derived capabilities,
destroying now-unreferenced objects, resetting untyped-memory watermarks, and later
zeroing/retyping. It also documents object-specific effects and partial-completion
cases for `seL4_CNode_Revoke`. SlopOS therefore must not model revoke as an
instantaneous universal “erase and safely reuse” operation.

Cornucopia and Cornucopia Reloaded treat temporal safety as a relation among
withdrawal, quarantine, global reference discovery, and delayed reuse. Recent 2026
PoisonCap and CHERI-D preprints explore architectural metadata/identity to reduce
revocation/reuse cost. These works reinforce the need for explicit generations and
reclamation clocks, but they do not select a SlopOS mechanism or prove its model.

## Path resolution

Linux `openat2(2)` exposes `RESOLVE_BENEATH`, `RESOLVE_IN_ROOT`,
`RESOLVE_NO_MAGICLINKS`, and `RESOLVE_NO_SYMLINKS`. A future Linux repository walker
should use descriptor-relative resolution and explicit policies rather than assume a
lexically safe path remains beneath a root on a hostile, changing filesystem. The
current C++ walker is scoped to a quiescent trusted extraction; hostile-filesystem
refinement remains open.

## Evidence identity

The in-toto attestation specification separates predicate, statement, envelope, and
bundle. A statement binds metadata to a subject digest; an envelope handles
authentication/serialization. SlopOS likewise treats a digest as immutable subject
identity, not approval, proof, or container self-authentication.

## Primary links

- https://sel4.systems/Info/Docs/seL4-manual-latest.pdf
- https://www.cl.cam.ac.uk/research/security/ctsrd/pdfs/2020oakland-cornucopia.pdf
- https://www.cl.cam.ac.uk/research/security/ctsrd/pdfs/202404asplos-cornucopia-reloaded.pdf
- https://arxiv.org/abs/2605.13210
- https://arxiv.org/abs/2606.19055
- https://man7.org/linux/man-pages/man2/openat2.2.html
- https://github.com/in-toto/attestation/blob/main/spec/README.md
- https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md
- https://github.com/in-toto/attestation/blob/main/spec/v1/digest_set.md
