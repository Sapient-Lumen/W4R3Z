# AArch64 executable-visibility source notes

Last refreshed: 2026-07-14.

## Purpose and proof boundary

These sources constrain the finite M0-P11 engineering assessment. They are not
formal Arm semantics, Isabelle axioms, cache-effect evidence, or a platform
support claim.

## Official Arm source family

1. **Concurrent modification and execution of instructions**
   - Arm Architecture Reference Manual DDI 0487, B2.2.5.
   - `https://developer.arm.com/documentation/ddi0487/mb/-Part-B-The-AArch64-Application-Level-Architecture/-Chapter-B2-The-AArch64-Application-Level-Memory-Model/-B2-2-Atomicity-in-the-Arm-architecture/-B2-2-5-Concurrent-modification-and-execution-of-instructions--CMODX-`
2. **About cache maintenance in AArch64 state**
   - Arm Architecture Reference Manual DDI 0487, D7.5.8.
   - `https://developer.arm.com/documentation/ddi0487/mb/-Part-D-The-AArch64-System-Level-Architecture/-Chapter-D7-The-AArch64-System-Level-Memory-Model/-D7-5-Cache-support/-D7-5-8-About-cache-maintenance-in-AArch64-state`
3. **DC CVAU — clean by VA to Point of Unification**
   - AArch64 instruction index, 2026-03.
   - `https://developer.arm.com/documentation/111107/2026-03/AArch64-Instructions/DC-CVAU--Data-or-unified-Cache-line-Clean-by-VA-to-PoU`
4. **IC IVAU — invalidate by VA to Point of Unification**
   - AArch64 instruction index, 2026-03.
   - `https://developer.arm.com/documentation/111107/2026-03/AArch64-Instructions/IC-IVAU--Instruction-Cache-line-Invalidate-by-VA-to-PoU`
5. **A64 system/base instruction index**
   - DSB and ISB descriptions, 2026-03.
   - `https://developer.arm.com/documentation/111107/2026-03/AArch64-Instructions`
6. **CTR_EL0 — Cache Type Register**
   - AArch64 register index, 2026-03.
   - `https://developer.arm.com/documentation/111107/2026-03/AArch64-Registers/CTR-EL0--Cache-Type-Register`

The selected source-envelope label is:

```text
Arm DDI 0487 M.c B2.2.5+D7.5.8; Arm A-profile A64 ISA 2026-03
DC CVAU+IC IVAU+DSB+ISB; CTR_EL0 2026-03
```

Its repository FNV is `aa82407dbca17a74`. This binds the label only.

## Conservative intent branch

M0-P11 selects a conservative branch in which explicit D-cache clean and
I-cache invalidation are both required:

```text
CTR_EL0.IDC selected premise = 0
CTR_EL0.DIC selected premise = 0
```

It also selects 64-byte D/I line geometry, making the 36-byte page-aligned code
range one line in each selected geometry. None of these values has been read
from a PE. They are named premises for falsification.

The selected intent order is:

```text
exact bytes already copied as a pure value
require actual machine-memory publication
require effective R/X/privileged and non-write permission
DC CVAU intent for 0x40008000
DSB ISH completion intent
IC IVAU intent for 0x40008000
DSB ISH completion intent
ISB context-synchronization intent on the executing PE
bind entry-state record
check terminal transfer
```

This is not an implementation of `__clear_cache`, not an instruction stream,
and not a theorem that the order is sufficient on a concrete platform.

## Structural finding independent of cache premises

The exact source/object specimen ends after the final `ISB`; the pure target
tail is zero. No return, branch, exception return, or explicit separately bound
fallthrough continuation exists. Therefore entry readiness is blocked before
cache effects can become the decisive question.

## Open architecture questions

- Which product profile and machine target supplies actual `CTR_EL0` values?
- Is the selected code range addressed at EL2 through a stable stage-1 regime?
- Which shareability domain is correct for the actual code backing?
- Which agent performs maintenance, and on which PE will entry occur?
- What changes if IDC or DIC is one?
- What synchronization is required for another PE?
- What terminal semantic role should the activation fragment have?
- Which formal architecture model can eventually discharge any of these facts?

## Non-collapse law

```text
official source
!= formal semantics
!= selected premise
!= observed platform fact
!= maintenance instruction execution
!= completion
!= fetch visibility
!= entry
!= execution
```
