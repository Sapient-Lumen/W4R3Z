# Research notes — authority attenuation and repository office

**Accessed:** 2026-07-15  
**Use:** design pressure only; no external source is imported as a SlopOS theorem.

## Authority

- Google Research, *Macaroons: Cookies with Contextual Caveats for Decentralized
  Authorization in the Cloud* — caveats support decentralized delegation while
  attenuating where, when, by whom, and for what purpose a request is authorized.
  https://research.google/pubs/macaroons-cookies-with-contextual-caveats-for-decentralized-authorization-in-the-cloud/
- seL4 Reference Manual, current official manual — capability derivation, minting
  reduced rights, and revocation of descendants provide pressure for monotone
  attenuation and explicit revocation lineage.
  https://sel4.systems/Info/Docs/seL4-manual-latest.pdf

Inference for SlopOS: subject/resource/action/time/use attenuation is incomplete
without an operation magnitude ceiling. Rev0798 adds `max_amount`; it still does not
implement cryptographic credentials, derivation trees, or distributed revocation.

## Repository and provenance

- Linux `openat2(2)` — `RESOLVE_BENEATH` and `RESOLVE_NO_SYMLINKS` illustrate a
  descriptor-based path-resolution lane for hostile trees.
  https://man7.org/linux/man-pages/man2/openat2.2.html
- NIST FIPS 180-4 — SHA-256 is a standardized message-digest algorithm used to
  detect changed messages; it does not authenticate an actor.
  https://csrc.nist.gov/pubs/fips/180-4/upd1/final
- SLSA v1.2 build provenance — provenance binds artifacts to a build definition and
  builder context; verification checks expectations rather than treating a digest
  alone as provenance.
  https://slsa.dev/spec/v1.2/build-provenance
- in-toto Statement v1 — an attestation statement binds a typed predicate to an
  explicitly identified subject.
  https://in-toto.io/Statement/v1
- Reproducible Builds documentation — timestamps, build paths, environment, and
  archive metadata are common reproducibility variables.
  https://reproducible-builds.org/docs/perimeter/

Inference for SlopOS: Office V2 manifests are exact local content identities, not
signed provenance. A future close should add external reviewer/build attestations
and record build-environment variability rather than overloading the manifest.
