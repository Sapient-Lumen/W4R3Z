# Lean, Isabelle, and the SlopOS code-bridge decision

## Question

Why not Lean, and what formal stack can actually carry a C++20 kernel project in
this cloudtainer toward a seL4-class style of assurance?

## Criteria

The relevant criteria are not theorem-prover popularity in the abstract. SlopOS
needs:

1. relational refinement across multiple state-machine layers;
2. operating-system and security proof precedent;
3. finite words, maps, records, nondeterminism, invariants, and information-flow
   machinery;
4. a credible route toward implementation semantics;
5. deterministic headless operation under tight memory and command windows;
6. evidence capture that can be driven by the permanent C++20 harness;
7. a small trusted checker and explicit proof assumptions;
8. continuity for LLM developers reopening the cube.

## Isabelle/HOL

Strengths:

- the seL4 proof stack and L4.verified ecosystem are direct evidence that the logic,
  proof language, libraries, and engineering style can scale to kernel refinement;
- classical HOL is a natural fit for relational state machines and security
  invariants;
- Isabelle sessions are batchable, deterministic, and easy to bind to a source
  basis;
- the LCF architecture minimizes trusted proof checking;
- AutoCorres2 and the C parser offer a concrete, though C-only, implementation bridge, and AFP publishes an exact Isabelle2025-2 release;
- Isabelle2025-2 is now installed reproducibly from a pinned, verified distribution
  layer in this cloudtainer.

Costs:

- proof engineering is demanding;
- the distribution is large;
- startup/build work must respect the cloudtainer's memory and execution windows;
- no maintained general C++20 front end closes the implementation edge for us;
- Isar and Isabelle-specific libraries require deliberate office documentation.

Assessment: **best primary theorem root for the current mission**.

## Lean 4

Strengths:

- dependent type theory supports expressive specifications;
- the core kernel checks proof terms and tactics remain outside the soundness core;
- excellent metaprogramming and an increasingly strong automation ecosystem;
- one language can express programs, specifications, proofs, and generated checkers;
- likely strong ergonomics for LLM-assisted formal development;
- easier installation footprint may be possible in some constrained environments.

Costs for this project now:

- no direct equivalent of the mature seL4/L4.verified refinement corpus and working
  practices that SlopOS is trying to imitate;
- no immediately available maintained general C++20-to-Lean semantics bridge;
- building an OS refinement library, implementation semantics, and project
  conventions at once would move scientific risk into infrastructure;
- a second root would require authoritative-spec translation, theorem mapping,
  dependency pinning, proof currentness, and divergence governance.

Assessment: **technically credible, strategically inferior as the primary root
today**. Lean should remain a bounded reconsideration candidate, especially for a
future independently checked artifact or an AI-proof-engineering experiment, but
not a parallel source of truth.

## Other candidates

### Rocq/Coq

A strong small-kernel prover with major verified-systems and compiler precedent.
The project could be done there, but switching would abandon the closest kernel
refinement ecosystem without solving C++20 semantics. No current advantage justifies
that migration.

### HOL4

Very strong LCF-style assurance and binary/architecture work, including use in
systems verification. It is a credible specialist component for a future binary or
ISA edge, not a reason to duplicate the current high-level root.

### F*, Dafny, Why3, Verus-style systems

These can provide excellent deductive verification close to code, usually with SMT
automation. Their practical C++20 connection and trusted translation story do not
currently replace the top-level refinement root. They may later close a component
obligation if their exact trust envelope is recorded.

### CBMC / ESBMC

Useful bounded C/C++ model checkers. They are attractive for finite core code and
undefined-behaviour pressure but remain bounded unless a particular proof mode and
trust story says otherwise. They belong beside the harness.

### TLA+ / Apalache

Excellent for distributed/concurrent design exploration and temporal properties,
but not the selected implementation-refinement root. Consider later for P0 service
protocols or lifecycle models, not K0 duplication.

## Cloudtainer result

The user-supplied installer route succeeded. It obtains the final Isabelle
distribution layer through the authenticated Docker registry mirror, verifies the
pinned manifest, exact layer size, and SHA-256, extracts only the Isabelle tree,
and installs a launcher without retaining credentials. The active cube keeps the
exact working script and lock record; the 1.23 GB external layer and installation
remain outside revision archives.

The first actual session run was valuable: it found malformed theory transport and
several proofs that source inspection had treated as plausible. After repair, the
whole `SlopOS_K0` session accepts under Isabelle2025-2 with
`quick_and_dirty=false`. This is the strongest evidence in favour of using a real
checker from the beginning: it changed the artifact rather than merely validating
our confidence.

## Implementation bridge conclusion

No prover choice erases the C++20 semantic gap. The honest options are:

1. constrain and model the needed C++ semantics ourselves, then prove a relation;
2. generate a tiny implementation subset from a proved representation and prove
   the generator/translation;
3. isolate C-compatible source and use AutoCorres2, while proving the C/C++ meaning
   agrees;
4. connect at compiler IR or binary level later;
5. change implementation language, which is economically unavailable and rejected
   by project law.

Epoch Zero originally chose a measured combination of 1–3. Rev0768 acquired
an exact Isabelle2025-2-compatible AFP source, began the Simpl/Word_Lib/AutoCorres2
stack, and rejected that route as a standing office dependency or authoritative
C++20 bridge. The resource envelope was large for the scalar target, and a theorem
about a hand-written C island would still leave the C-to-C++ relation open. The
retained next route is a direct or generated exact-source relation for the frozen
scalar C++20 fragment; AutoCorres2 remains gated research rather than normal
machinery.

## Decision

Use Isabelle/HOL 2025-2 as the single theorem root. Keep Lean on the research watch
list, not in the active proof dependency graph. Preserve all executable proof
orchestration and testing in C++20. Keep AutoCorres2 behind DEC-0020's explicit
reconsideration gates; do not make it ordinary office machinery or a substitute for
an authoritative C++20 source relation.

## Operational conclusion through rev0769

The choice is now enforced rather than advisory. A fresh CMake graph always contains
the exact-version doctor and full `SlopOS_K0` session; C++20 office tools emit the
pinned recovery command when an ephemeral Isabelle layer is missing. This lowers
Isabelle's operational risk. Rev0769 also made one checked source program own the
scalar decision and made the active generated header an exact accepted-session
export; the renderer, C++ evaluator, and compiler risks remain unresolved and
explicit.

Lean remains on the watch list under explicit gates. Installation convenience or
LLM familiarity alone is not a gate because neither closes the source, compiler,
platform, or configuration edge.
