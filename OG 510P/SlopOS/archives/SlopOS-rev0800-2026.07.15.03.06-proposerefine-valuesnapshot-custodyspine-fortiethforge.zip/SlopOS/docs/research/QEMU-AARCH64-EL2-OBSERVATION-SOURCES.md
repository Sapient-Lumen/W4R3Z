# QEMU and AArch64 EL2 observation sources

## Scope

This note records the engineering sources used to choose the rev0796 chamber.
It does not import web prose or architecture documentation as formal semantics.
All live claims remain bounded to exact bytes, exact command values, and exact
observed output.

## Primary QEMU sources

- QEMU download and release surface:
  `https://www.qemu.org/download/`
- QEMU system-emulator targets and Arm `virt` generic virtual platform:
  `https://qemu.readthedocs.io/en/master/system/targets.html`
- QEMU invocation, generic loader, semihosting, machine, CPU, SMP, and memory
  options:
  `https://qemu.readthedocs.io/en/master/system/invocation.html`

The official documentation describes QEMU as a generic emulator and the Arm
`virt` machine as a generic virtual platform. The generic loader is useful for
developers who already control the guest layout. Neither description establishes
hardware equivalence or boot provenance.

QEMU warns that semihosting exposes host facilities and should be enabled only
for trusted guests. Rev0796 therefore enables it only for the byte-pinned
observer and only as a fixed report/exit channel. No untrusted guest exists in
the chamber.

## Primary Arm register sources

- CurrentEL, Current Exception Level:
  `https://developer.arm.com/documentation/ddi0601/2026-03/AArch64-Registers/CurrentEL--Current-Exception-Level`
- ID_AA64PFR0_EL1, AArch64 Processor Feature Register 0:
  `https://developer.arm.com/documentation/ddi0601/2026-03/AArch64-Registers/ID-AA64PFR0-EL1--AArch64-Processor-Feature-Register-0`
- ID_AA64MMFR0_EL1, AArch64 Memory Model Feature Register 0:
  `https://developer.arm.com/documentation/ddi0601/2026-03/AArch64-Registers/ID-AA64MMFR0-EL1--AArch64-Memory-Model-Feature-Register-0`
- ID_AA64MMFR1_EL1, AArch64 Memory Model Feature Register 1:
  `https://developer.arm.com/documentation/ddi0601/2026-03/AArch64-Registers/ID-AA64MMFR1-EL1--AArch64-Memory-Model-Feature-Register-1`

The observer also reads MIDR_EL1, HCR_EL2, VTCR_EL2, and VTTBR_EL2. The finite
C++20 parser extracts only the minimum fields needed to reject obviously wrong
chamber output. These checks are engineering screens, not formal register
semantics.

## Source classification

```text
official issue / page / version
  constrains selection and review
  != theorem premise supplied by the web
  != operational semantics
  != implementation correctness
  != hardware observation
```

## Selected interpretation fence

The selected report is accepted only when:

- decoded CurrentEL is 2;
- the selected EL2 feature field is nonzero;
- the selected 4 KiB granule field is in the supported finite set;
- the selected PA-range field is in the closed accepted range;
- the selected VMID field is in the closed accepted set; and
- HCR_EL2, VTCR_EL2, and VTTBR_EL2 are all zero.

This admits only the result name `OBSERVED_EL2_ENVELOPE_STAGE2_INACTIVE`. It does
not establish that the selected M0 stage-2 configuration can be installed or
activated.

## Revisit triggers

Refresh this assessment when QEMU, the selected machine/CPU profile, Arm
register issue, observer toolchain, field extraction, or the intended M0
architecture envelope changes.
