# seL4 primary-source notes

**Consulted:** 2026-07-10; rechecked 2026-07-11
**Purpose:** constrain SlopOS proof architecture; no claim transfer

## Primary project sources

- Isabelle release page: <https://isabelle.in.tum.de/>
- Isabelle installation: <https://isabelle.in.tum.de/installation.html>
- proof overview: <https://sel4.systems/Verification/proofs.html>
- proof assumptions: <https://sel4.systems/Verification/assumptions.html>
- L4.verified repository overview: <https://github.com/seL4/l4v/blob/master/README.md>
- L4.verified C parser: <https://github.com/seL4/l4v/blob/master/tools/c-parser/README.md>
- AutoCorres: <https://github.com/seL4/l4v/blob/master/tools/autocorres/README.md>
- AutoCorres release-file README:
  <https://github.com/seL4/l4v/blob/master/tools/autocorres/tools/release_files/README>
- AutoCorres2 AFP entry: <https://isa-afp.org/entries/AutoCorres2.html>
- Word Library AFP entry: <https://www.isa-afp.org/entries/Word_Lib.html>

## Version and cloudtainer posture on 2026-07-11

The official Isabelle site identifies **Isabelle2025-2 (January 2026)** as the
current release. The active rev0768 lock pins that exact version; the pin was first exercised in rev0766.

The user-supplied registry-mirror route succeeded in this cloudtainer. The exact
Docker image manifest, distribution-layer digest/size, installer SHA-256/FNV, and
session command are recorded in `toolchains/isabelle.lock`. The installed
application and verified 1.23 GB layer remain external to the cube. The first
`SlopOS_K0` run found real syntax/proof defects; after repair the complete session
accepted with `quick_and_dirty=false`.

The official AFP entry publishes an **Isabelle2025-2 AutoCorres2 release dated
2026-02-07**. Rev0768 additionally identified the compatible AFP mirror commit and
attempted the dependency build. The build did not reach a SlopOS proof island within
the retained experiment, and the C/C++ semantic relation remained open regardless.
AutoCorres2 is therefore not a standing office dependency. Exact details and
non-claims are in `docs/research/AUTOCORRES2-EXPERIMENT.md`.

This changes the active status from rev0765. Formal rows are no longer left as
candidates merely because the checker is absent. Exact propositions mapped in
`proof/theorems.tsv` may be `THEOREM` only while the current revision's retained version, basis,
proof tree, zero-hole scan, command, exit, and complete log remain current.

## Observed proof architecture

The public l4v repository separates abstract specification, generated design
specification, C specification, abstract invariants, abstract→design refinement,
design→C refinement, access-control/information-flow proofs, and binary refinement
for supported configurations. It identifies a C parser producing Simpl with a C
memory model and AutoCorres as proof-producing abstraction above that semantics.
Generated specifications are part of normal proof-build discipline.

SlopOS follows that pressure by separating A0, D0, KIR/proof values, constrained
C++20, compiler/binary, and platform edges. This is structural inspiration only; no
seL4 theorem or assurance transfers to SlopOS.

The proof overview distinguishes functional correctness, binary correctness where
supported, security properties, and verified initialization. It also makes
configuration/property scope explicit. SlopOS therefore needs claim-specific
chains and profile theorem bundles rather than one global “verified” label.

## Observed assumptions discipline

The assumptions page names assembly, hardware, cache/TLB management, boot code,
virtual-memory modeling boundaries, DMA, and side channels, while explaining how
binary verification can remove compiler/linker trust for supported configurations.
The useful lesson is not a numeric TCB comparison; it is that low-level reality
connections remain explicit and claim-specific.

## C versus C++ consequence

The public parser and AutoCorres ecosystem are C-oriented. AutoCorres2 is a maintained
AFP route for verification of C programs in Isabelle. These sources do not provide a
direct general C++20 translation for the active SlopOS core.

Therefore SlopOS must not call generated C++ “on the seL4 C refinement path.”
Rev0768 measured the official AutoCorres2 route and rejected it as standing machinery
for the scalar CAP-REP edge. Reconsideration requires an authoritative C component,
checked common-source mapping, proportionate cached stack, or another exact C-facing
obligation under DEC-0020.

## Fixed-width word consequence

AFP Word_Lib supplies established fixed-width word machinery relevant to eventual
formal `uint64_t` carriers. The current epoch retains the first sequence schema over `nat`
plus an explicit `< 2^64` relation because that keeps the current theorem boundary
simple and visible. A later migration to word types must be driven by a source-
semantics or platform proof need, not by cosmetic resemblance to C++.

## Resource consequence

The l4v material makes clear that C refinement and generated specifications are
substantial maintained proof infrastructure. Epoch Zero therefore keeps a tiny
session, exact theorem mapping, generated-artifact currency, and one measured source
experiment at a time. Tool availability no longer justifies unchecked accumulation;
proof scale still justifies refusing broad formalization before the first edge is
closed.
