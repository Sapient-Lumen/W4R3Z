# AArch64 source/object source classification

## Primary engineering sources

M0-P9 uses only primary sources to constrain its engineering envelope:

- Arm-software/abi-aa, **ELF for the Arm 64-bit Architecture (AArch64)**
  (`aaelf64`), for the AArch64 ELF machine and object conventions;
- LLVM/Clang command-line and cross-compilation documentation, for the selected
  `--target=aarch64-none-elf` and `-march=armv8-a` invocation; and
- the exact installed Clang 17 version output retained in
  `toolchains/aarch64-assembler.lock`.

The stable upstream locations used during rev0787 were:

```text
https://github.com/ARM-software/abi-aa/blob/main/aaelf64/aaelf64.rst
https://clang.llvm.org/docs/CrossCompilation.html
https://clang.llvm.org/docs/ClangCommandLineReference.html
```

## Classification law

```text
official ABI document
!= formal ELF semantics

compiler documentation
!= assembler correctness proof

identified tool replay
!= general toolchain correctness
```

These sources constrain selection and make review reproducible. They are not
imported as axioms or executable dependencies of Isabelle.

## Selected local observations

`readelf` reports the selected object as:

```text
ELF64, little endian, ET_REL, EM_AARCH64
zero program headers
five section headers
.text at offset 64 with 36 bytes and AX flags
.symtab with three entries
no relocations
```

The permanent authority for those finite facts is the C++20 parser, generated
manifest, exact bytes, and Isabelle relation—not the diagnostic text of
`readelf`.
