# AArch64 caller-edge and X30 source classification

## Selected source envelope

The M0-P10R value contract uses these engineering sources:

1. **Arm Architecture Reference Manual, DDI 0487 M.c**
   - Used as the selected architecture issue identity for branch-and-link
     semantics and the wider AArch64 envelope.
   - `https://developer.arm.com/documentation/ddi0487/latest`

2. **Arm A-profile A64 ISA, 2026-03 — BL**
   - The instruction description states that `BL` writes `PC+4` to X30 and
     branches to a PC-relative immediate target.
   - `https://developer.arm.com/documentation/111108/2026-03/Base-Instructions/BL--Branch-with-Link-`

3. **Arm A-profile A64 ISA, 2026-03 — NOP**
   - Used only for the selected projected continuation word.
   - `https://developer.arm.com/documentation/111108/2026-03/Base-Instructions/NOP--No-Operation-`

4. **Arm A-profile A64 ISA, 2026-03 — RET**
   - The instruction description identifies X30 as the default register for
     subroutine return.
   - `https://developer.arm.com/documentation/111108/2026-03/Base-Instructions/RET--Return-from-subroutine-`

5. **AAPCS64, 2025Q4**
   - Names r30/X30 as LR, the link register, in the procedure-call standard.
   - `https://github.com/ARM-software/abi-aa/blob/main/aapcs64/aapcs64.rst`

The generated contract records the compressed source identity:

```text
Arm DDI 0487 M.c BL; Arm A-profile A64 ISA 2026-03 BL+NOP+RET;
AAPCS64 2025Q4 X30/LR
```

Its FNV-1a identity is `72abaf8a484aaf78`.

## Classification

These sources constrain the selected finite values. They are not imported as
formal Isabelle semantics. A source issue, URL, mnemonic, encoding, or ABI role
does not prove:

- a caller artifact exists;
- an instruction is fetch-visible;
- BL executes;
- X30 contains the continuation;
- RET executes or completes; or
- the machine boots or isolates domains.

## Why the contract is projected

The current pure loader page already contains the repaired helper but contains
zero words at the selected caller addresses. Therefore the honest current
result is a projected word/address contract with blocked readiness, not a
current caller or live call-edge claim.
