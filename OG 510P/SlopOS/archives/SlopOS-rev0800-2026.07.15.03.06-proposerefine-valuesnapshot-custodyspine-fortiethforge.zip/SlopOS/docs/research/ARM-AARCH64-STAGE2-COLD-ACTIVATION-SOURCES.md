# Arm AArch64 stage-2 cold-activation source notes

## Purpose and boundary

These notes constrain M0-P6, M0-P7, and the bounded M0-P8 instruction-selection
experiment.  They are engineering research inputs.  They are not imported Arm
operational semantics, proof-assistant axioms, or evidence of privileged
execution.

Last refreshed: 2026-07-14.

## Pinned source identities

The active certificate records two source identities:

```text
Arm Architecture Reference Manual issue     DDI 0487 M.c
AArch64 register index snapshot             2026-03
Arm issue text FNV-1a                       e9f1504e6d1ba137
register index text FNV-1a                  0035cfbb86cab299
```

The fingerprints bind the repository's selected issue labels.  They do not
fingerprint the full external publications and are not authenticity evidence.

## Official source family

Only official Arm material may supply normative engineering meaning for this
edge:

1. **HCR_EL2 — Hypervisor Configuration Register**
   - AArch64 register index, 2026-03 publication line.
   - `https://developer.arm.com/documentation/ddi0601/2026-03/AArch64-Registers/HCR-EL2--Hypervisor-Configuration-Register`
2. **VTCR_EL2 — Virtualization Translation Control Register**
   - Arm Architecture Reference Manual register description.
   - `https://developer.arm.com/documentation/ddi0487/maa/-Part-D-The-AArch64-System-Level-Architecture/-Chapter-D24-AArch64-System-Register-Descriptions/-D24-2-General-system-control-registers/-D24-2-224-VTCR-EL2--Virtualization-Translation-Control-Register`
3. **VTTBR_EL2 — Virtualization Translation Table Base Register**
   - current AArch64 register index, 2026-03 publication line.
   - `https://developer.arm.com/documentation/111107/2026-03/AArch64-Registers/VTTBR-EL2--Virtualization-Translation-Table-Base-Register`
4. **Stage-2 translation**
   - official Arm learning-path overview.
   - `https://developer.arm.com/documentation/102142/0100/Stage-2-translation`
5. **TLB maintenance**
   - Arm Architecture Reference Manual chapter.
   - `https://developer.arm.com/documentation/ddi0487/mc/-Part-D-The-AArch64-System-Level-Architecture/-Chapter-D8-The-AArch64-Virtual-Memory-System-Architecture/-D8-17-TLB-maintenance?lang=en`
6. **Break-before-make**
   - Arm Architecture Reference Manual subsection.
   - `https://developer.arm.com/documentation/ddi0487/mb/-Part-D-The-AArch64-System-Level-Architecture/-Chapter-D8-The-AArch64-Virtual-Memory-System-Architecture/-D8-17-TLB-maintenance/-D8-17-1-Using-break-before-make-when-updating-translation-table-entries`
7. **A64 base instruction index**
   - official 2026-03 instruction descriptions for later bounded selection of
     `MSR`, `DSB`, `ISB`, and `TLBI` classes.
   - `https://developer.arm.com/documentation/ddi0602/2026-03/Base-Instructions`

Secondary examples may locate sections.  They may not become the normative
basis for a mnemonic, operand, immediate, scope, or ordering premise.

## Selected finite envelope

```text
AArch64 EL2 stage 2
4 KiB granule
39-bit IPA
start level 1
40-bit selected PA size field
8-bit selected VMID regime
DS = 0
LPA2 not selected
HCR_EL2.FWB = 0
root table integer value 0x40000000
VMID 1
VTCR_EL2 integer value 0x23559
VTTBR_EL2 integer value 0x0001000040000000
HCR_EL2 integer value 0x0000000080000001 (VM|RW)
```

Rev0784 used `HCR_EL2=0x1`.  Rev0785 rejects that tuple and records the
correction rather than rewriting history.  The selected envelope expects lower
EL1 to execute in AArch64 state, so both `VM` and `RW` are selected.

## M0-P7 premise discipline

The finite certificate names thirty-two required premises.  They include
architecture and feature availability, legal field combinations, memory type,
table installation/publication, cold-start and single-PE conditions, absence of
concurrent table/DMA mutation, availability of context synchronization and
VMID-scoped invalidation/completion events, EL2 effect, exception freedom, and
observation after completion.

A set bit means only “this premise is required by the selected relation.”  It
does not mean the repository has proved the premise.

## Questions deliberately left to M0-P8 and later

- Which exact A64 instruction class realizes each of the ten abstract events?
- What operands and immediate fields are selected for system-register writes,
  barriers, and invalidation?
- Which scope/shareability domain is required for the selected table memory?
- Does the cold-start assumption eliminate every break-before-make obligation?
- What formal Arm model, if any, can discharge the selected event semantics?
- What source-to-encoding and encoding-to-binary route is acceptable?
- What changes for multicore, live updates, reused VMIDs, nested
  virtualization, LPA2, FWB, implementation-specific caches, or devices?

## Non-collapse law

```text
official source citation
!= formal architecture semantics
!= selected instruction class
!= instruction encoding
!= source or binary identity
!= privileged execution
!= completed architecture effect
!= hardware observation
```
