# Cloudtainer hygiene — rev0800

- Treat `/mnt/data` as durable session storage; build and tool caches are disposable.
- Reconstruct from the named predecessor and verify its SHA-256 before trusting
  partial state.
- Never package `.git`, `build*`, `.slopos-work`, compiler caches, extracted vault
  scratch trees, or downloaded external toolchains.
- Inspect ZIP member paths and kinds before extraction; reject traversal, absolute
  paths, symlinks, devices, sockets, and multiple top-level roots.
- Keep source/evidence timestamps non-authoritative. Subject identities use canonical
  path, class, lane, type, mode, bytes, and SHA-256.
- Use separate GCC, Clang, sanitizer, full-research, and cold-extraction build dirs.
- Limit parallelism in constrained containers. Resource exhaustion is an environment
  observation, not a source defect.
- Keep heavyweight Isabelle/QEMU layers in digest-pinned external caches with
  resumable downloads and explicit space/process limits.
- External tool absence remains a blocked gate. Source inspection and predecessor
  logs are not substitutes for execution.
- Preserve original vault archive bytes. Any deduplicated recovery pack is a separate
  derivative with reversible mappings and reconstruction checks.
- Generate manifests only from a quiescent tree; evidence is written afterward and
  is excluded from both subjects.
- The final ZIP SHA-256 is computed after closure and retained outside the archive to
  avoid self-reference.
