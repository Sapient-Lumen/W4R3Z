# Recovery procedure — rev0800

1. Return to the externally named ZIP; never reconstruct lineage from an unverified
   partial working directory.
2. Hash every candidate predecessor archive and record which one is canonical. A
   same-number sibling is an alternate branch, not an implicit merge.
3. Inspect the ZIP before extraction: require one top-level `SlopOS/` root, safe
   relative paths, regular files/directories only, and no source-tree build output.
4. Extract into a fresh directory. Verify no symlink, special object, nested living
   root, `.git`, `.slopos-work`, compiler cache, or downloaded toolchain entered.
5. Run office audit, custody audit, and resume before using any current claim.
6. Reapply living changes as small reviewable patches. Preserve `vault/` bytes and
   keep evidence outside construction/custody identities.
7. Recover Isabelle/QEMU only in a separate disposable cache by immutable digest.
   Verify before extraction, cap resource use, and keep partial downloads resumable.
8. If an external tool is absent or recovery fails, leave its gate BLOCKED and
   continue from the supplied archive. Never manufacture or inherit a success log.
9. Regenerate construction/custody manifests only after all living changes stop.
10. Package, cold-extract, rebuild, rerun the focused witness/office audits, compare
    embedded manifests, then compute the final transport digest externally.

A cold extraction may produce host-specific timestamp or permission observations;
those are not subject identity. Path safety, object kind, file mode as represented in
the manifest, byte length, and SHA-256 are the binding fields.
