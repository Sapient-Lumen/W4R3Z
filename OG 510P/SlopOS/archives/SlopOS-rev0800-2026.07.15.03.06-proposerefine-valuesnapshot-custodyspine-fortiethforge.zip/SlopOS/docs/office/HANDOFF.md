# Cold handoff — rev0800

## Read first

Use `spec/office/read-order.tsv`. The decisive files are the mission review,
DEC-0048, construction 003, the PROPOSE refinement boundary, this handoff, the office
state/next files, and `evidence/rev0800/README.md`.

## Reproduce the active hosted lane

```sh
cmake -S . -B /tmp/slopos-build-gcc -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DSLOPOS_BUILD_LEGACY_M0=OFF
cmake --build /tmp/slopos-build-gcc --parallel 2
ctest --test-dir /tmp/slopos-build-gcc --output-on-failure \
  -E '^(proof-toolchain-doctor|isabelle-session-current|office-audit|office-custody-audit|office-open|office-close-remains-open)$'
/tmp/slopos-build-gcc/slopos-harness --authority-propose-refinement
/tmp/slopos-build-gcc/slopos-test-authority-propose-refinement
/tmp/slopos-build-gcc/slopos-office audit --root .
/tmp/slopos-build-gcc/slopos-office custody-audit --root .
/tmp/slopos-build-gcc/slopos-office resume --root .
```

The historical lane is explicit:

```sh
cmake -S . -B /tmp/slopos-build-full -G Ninja \
  -DCMAKE_BUILD_TYPE=Debug \
  -DSLOPOS_BUILD_LEGACY_M0=ON
ninja -C /tmp/slopos-build-full -n
```

Do not make it the default again.

## Resume objective

Recover Isabelle outside the repository, check the exact `SlopOS_K0` session, then
mechanize the smallest projection from the canonical C++ proposal prefix to the HOL
identifier/count/selected-proposal context. Keep the checker outside the authority
library and do not add an operation or source DSL in the same step.

## Forbidden promotions

- no predecessor proof result copied to rev0800;
- no executable checker called deductive C++ refinement;
- no canonical text, digest, or byte packet called a representation theorem;
- no alternate branch copied as a second living root;
- no emulator observation called hardware correctness;
- no lease withdrawal called dependent invalidation, quiescence, reclamation,
  external recall, or evidence supersession;
- no identifier reuse without generation and stale-reference law;
- no archive dedupe or recompression in place; and
- no heavyweight external toolchain extracted into the living project.

## Close expectation

`slopos-office close-check --root .` must fail while formal, broad refinement,
independent-review, and epoch-exit gates remain nonpass. That failure is correct.
