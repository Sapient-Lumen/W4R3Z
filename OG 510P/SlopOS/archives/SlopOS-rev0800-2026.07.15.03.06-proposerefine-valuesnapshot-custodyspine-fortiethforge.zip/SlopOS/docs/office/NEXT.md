# Next bounded objective — rev0800

## E0-P0R2 — check and connect the PROPOSE square

Perform the next work in this order:

1. recover the pinned Isabelle2025-2 executable in an external digest-pinned cache;
2. run the exact `SlopOS_K0` session against the quiescent rev0800 construction
   basis and record either accepted output or the smallest counterexample;
3. define one minimal relation from `AuthorityValueSnapshot` to
   `p0_propose_context`; and
4. prove/check that one accepted PROPOSE and every selected denial commute under
   explicit premises.

The relation must name:

- exact 16/32/64-bit carrier assumptions used by the C++ specimen;
- proposal capacity eight and resource capacity four;
- sorted occupied proposal prefix and exact default tail;
- identifier set/count projection;
- sequence equality and terminal meaning;
- selected proposal projection;
- first-failure precedence; and
- which lease/resource/prior-proposal fields are framed versus deliberately
  abstracted.

## Exit tests for this bounded objective

- Isabelle2025-2 checks the exact theory source, or the gate remains BLOCKED with an
  exact diagnostic;
- GCC, Clang, and GCC ASan/UBSan keep the focused concrete witness green;
- targeted mutation rejection remains green;
- core/reference/checker transition logic remains independent;
- no new operation, DSL, parser, generator, living root, reuse mechanism, or platform
  rung enters; and
- proof/correspondence ledgers state the remaining C++ source/compiler/ABI exclusions.

Only after this objective is reviewed should the office choose generation-qualified
identity/reuse or one real privileged effect as the next semantic edge.
