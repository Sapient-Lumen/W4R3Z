# Excavation 015 — structural evaluator and assumption fence

## Question

What did the old SlopOS and companion cubes already know about the dangerous jump
from a representation or successful parse to evaluation, authority, and effect?

## Exact sources

The complete copied bytes and hashes are retained under
`vault/searchable/rev0760/structural-evaluator-assumption-fence/`:

| Source | Relevant pressure |
|---|---|
| SlopOS RFC 0027, definitional models and differential testing | Keep a simple definitional model and independent implementation, but treat agreement as bug-finding pressure rather than self-authentication. |
| SlopOS ACP validator semantics | A proposal, parse, validation result, admission result, and authoritative effect are different events with different failure laws. |
| Schell parse floors and evaluation humility | A parser must not claim semantics for constructs or environments it did not admit and examine. |
| Foundry rule-effect ledgers and effect witnesses | Selection, recorded intent, and an effect witness do not silently become the effect itself or prove that bypass paths are absent. |

## Recovered law

The common law is stronger than “test your parser”:

```text
representation != admission
admission != execution
execution != effect
agreement != proof
proof != authority
historical evidence != current evidence
```

Each arrow needs a named relation, a fail-closed boundary, and evidence current for
its exact construction basis.

## Application to rev0771

The rev0770 certificate evaluator delegated immediately to the already checked
source evaluator. That was safe as a conservative theorem but circular as evidence
about the recorded C++20 fragment structure. Revision 0771 therefore:

- keeps exact certificate admission separate;
- executes certificate comparisons, joins, branch polarities, tags, and initializers
  in a direct HOL model;
- adds an independently represented C++20 structural interpreter;
- compares that interpreter with compiled `scalar::project` over the exact existing
  593,907-cell witness domain;
- preserves parser, preprocessing, ISO C++20, compiler, ABI, binary, and platform
  debt as open.

## What was not promoted

The excavation does not activate ACP, Foundry ledgers, Schell language machinery,
a general parser, a generic effect system, or a new kernel object. It does not make
differential agreement a proof. It does not make a certificate authoritative merely
because it was emitted by the current binder.

## Next pressure

The next bounded experiment should reduce one trust edge rather than add another
semantic copy. Two admissible candidates are:

1. generate a self-contained, no-include, no-project-macro proof-owned companion
   fragment and measure which preprocessing assumptions disappear;
2. derive a materially smaller certificate checker/record and measure whether the
   binder trust base shrinks rather than moves.

A measured rejection is progress. Neither experiment may be relabeled an ISO C++20
or compiler proof.
