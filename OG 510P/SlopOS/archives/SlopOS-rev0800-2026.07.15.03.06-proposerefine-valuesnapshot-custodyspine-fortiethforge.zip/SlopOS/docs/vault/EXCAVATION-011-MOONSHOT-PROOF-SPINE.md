# Excavation 011 — moonshot shape, assurance spine, and proof-office recovery

## Questions

1. Does the old vault require four kernels or one small core with four bounded
   configuration/theorem bundles?
2. Which workstation, hosted-compute, appliance, and agent pressures belong in the
   privileged core, mediated Runtime, isolated services, platform model, or evidence
   office?
3. What does the old evidence/currentness law imply when the theorem checker is
   external to an ephemeral cloudtainer?
4. Which ambition should influence the first booted experiment without inflating
   Epoch Zero?

## Exact sources read

Two byte-preserved searchable selections were used. Their local `SHA256SUMS` files
bind every source; the sealed rev0760 archive remains canonical.

### Product/proof-shape selection

| Source | Finding retained |
|---|---|
| `vault/searchable/rev0760/proof-product-shape/docs/00-meta/charter.md` | one coherent capability-oriented OS ambition with explicit proof posture |
| `vault/searchable/rev0760/proof-product-shape/docs/00-meta/profile-claim-matrix.md` | A–D are profile-specific claim bundles over a shared substrate |
| `vault/searchable/rev0760/proof-product-shape/docs/00-meta/roadmap.md` | proof architecture, initialization, implementation correspondence, and later security layers must be staged |
| `vault/searchable/rev0760/proof-product-shape/docs/30-architecture/hypervisor-first-evaluation.md` | hosted-compute pressure is real, but hypervisor-first is a platform direction rather than permission for immediate breadth |
| `vault/searchable/rev0760/proof-product-shape/docs/30-architecture/multicore-architecture-options.md` | sequential and concurrent refinement layers should remain distinct |
| `vault/searchable/rev0760/proof-product-shape/docs/40-verification/minimum-viable-proof-slice.md` | the old “minimum” slice coupled too many kernel, portal, SMP, recovery, and evidence concerns |
| `vault/searchable/rev0760/proof-product-shape/docs/40-verification/verification-strategy.md` | bounded evidence, source refinement, theorem proving, and assumptions retain separate roles |
| `vault/searchable/rev0760/proof-product-shape/docs/60-engineering/phase1-profile-focus.md` | cloud/agent pressure and workstation north star were already distinguished |

### Moonshot/system selection

| Source | Finding retained |
|---|---|
| `vault/searchable/rev0760/moonshot-shape/rfcs/0002-mile-high-paradigms-and-targets.md` | workstation, hosted, appliance, and agent pressures were intended to integrate through shared primitives |
| `vault/searchable/rev0760/moonshot-shape/docs/10-threat-model/deployment-profiles.md` | profiles change adversaries, assumptions, devices, operators, and availability claims; they are not branding labels |
| `vault/searchable/rev0760/moonshot-shape/docs/50-platform/target-platform.md` | platform portability is an assumption/theorem surface, not a slogan |
| `vault/searchable/rev0760/moonshot-shape/docs/50-platform/boot-chain-provenance.md` | source, build, boot, and running-image identity eventually belong in one claim chain |
| `vault/searchable/rev0760/moonshot-shape/docs/70-llm-control/README.md` | LLMs are untrusted proposers whose effects require deterministic validation and explicit authority |
| `vault/searchable/rev0760/moonshot-shape/docs/70-llm-control/llm-threats.md` | prompt text, confidence, and intent do not create authority; confused-deputy and exfiltration pressure are first class |
| `vault/searchable/rev0760/moonshot-shape/docs/70-llm-control/acp-validator-semantics.md` | admission, denial, failure, effect, replay, and currentness need exact separate semantics |
| `vault/searchable/rev0760/moonshot-shape/rfcs/0021-static-partition-policy-profile.md` | a closed static-partition configuration is a plausible first strong product theorem |
| `vault/searchable/rev0760/moonshot-shape/rfcs/0047-decentralized-information-flow-control.md` | information flow is eventual system theorem pressure, not an Epoch Zero object family |
| `vault/searchable/rev0760/moonshot-shape/rfcs/0080-capability-mediated-ui-compositor-and-secure-attention.md` | secure workstation assurance needs trusted-path theorems above kernel isolation |
| `vault/searchable/rev0760/moonshot-shape/rfcs/0083-driver-hosts-and-compatibility-runtimes.md` | risky drivers and legacy systems belong in isolated service/compatibility domains |
| `vault/searchable/rev0760/moonshot-shape/rfcs/0115-capability-safe-shell-and-automation.md` | human and agent automation should share explicit capability-mediated execution rather than ambient shell privilege |

## Findings

### 1. The enduring system is two explicit chains

The strongest common idea is not the old feature list. It is the refusal to collapse
these relations:

```text
authority: principal -> delegation -> admission -> effect -> currentness
assurance: requirement -> specification -> refinement -> source/binary/platform -> claim
```

Most companion-cube distinctions are domain-specific defenses of the same law:
evidence, representation, observation, review, selection, or intent do not silently
become authority or current effect.

### 2. K, M, P, S, and E were interleaved

The old roadmap mixed privileged kernel mechanism, machine realization, portal and
agent Runtime policy, isolated services, and evidence/currentness schemas. That
created false pressure for one “minimum” slice to include mapping, IPC, SMP,
networking, receipts, replay, recovery, provenance, and agents.

The new epoch separates:

- **K:** privileged authority and isolation;
- **M:** machine mechanisms and platform assumptions;
- **P:** mediated authority Runtime;
- **S:** isolated services and compatibility domains;
- **E:** theorem, build, provenance, claim, and office currentness.

Only K/M mechanisms enter the privileged proof core. Security importance alone does
not imply privilege.

### 3. Moonshot breadth is carried by theorem and configuration envelopes

The four profiles are mutually useful pressures when they do not become kernel
forks:

- C pressures closed configuration, partition disjointness, bounded resources, and
  initialization;
- B pressures virtualization, tenant isolation, second-stage mappings, image
  provenance, and operator lifecycle;
- A pressures device, human-session, trusted-path, compatibility, and recovery
  boundaries;
- D pressures proposal/admission/effect/currentness, provenance, leases, and
  non-ambient automation.

Their privileged intersection is intentionally small. One common K/M spine can be
learned first from a narrow static C/B configuration; A and D then consume that spine
through P/S rather than import workstation or agent nouns into K.

### 4. Cloud/agent first and embedded proof first can coexist

The old phase-one material selects cloud/agent pressure for early operator value.
The static-partition material offers a cleaner first closed-world theorem target.
There is no contradiction: P/D may be prototyped on an existing host while a C-like
configuration is the first booted K/M isolation proof. Sequencing one does not cancel
the other.

### 5. Proof-carrying provenance is the long-term integrator

The old roadmap's valuable end state binds a running configuration to source,
configuration, build recipe, theorem bundle, and assumptions under a named verifier.
The current construction-basis manifest, theorem map, proof-tree fingerprint, and
retained checker packet are the infant E-layer form. They do not yet establish
binary identity, booted-image identity, platform state, or remote attestation.

### 6. External proof tooling is governed like current evidence

A theory file and historical log do not establish current acceptance when the exact
checker is absent. The vault's currentness law therefore applies to Isabelle itself:
version and availability are explicit office state; recovery is pinned and
reproducible; normal tests cannot silently omit the session; theorem-bearing work
requires a fresh accepted run against the current basis.

### 7. Isabelle is means, not product identity

The old vault wanted a seL4-shaped proof stack but did not settle the assistant. The
new epoch selects Isabelle because it minimizes relevant proof-infrastructure
invention and has survived the actual cloudtainer. SlopOS remains the
proof-carrying authority/isolation machine, not “an Isabelle project.”

## Promotions

- **VPR-017 — One K/M/P/S/E architecture and four profile theorem bundles.**
- **VPR-018 — Keep authority-to-effect and specification-to-claim chains explicit;
  model or agent output remains proposal material until deterministically admitted
  under explicit authority.**
- **VPR-019 — Exact proof-toolchain availability and version are office-currentness
  facts; missing or wrong tooling fails visibly and emits deterministic recovery.**
- **VPR-020 — Proof-carrying provenance is the long-term integration target; current
  basis/proof packets are its seed and not a binary/platform claim.**

## Quarantine

- Do not restore the old subsystem roadmap or coupled minimum proof slice.
- Do not fork the privileged core by product profile.
- Do not add agent, receipt, UI, filesystem, network, driver, lifecycle, or generic
  information-flow object families to K during Epoch Zero.
- Do not treat model output, proof transcripts, receipts, exports, observations, or
  generated files as authority merely because they exist.
- Do not introduce multicore, virtualization breadth, or devices before the
  sequential source/refinement strategy and one booted mechanism earn them.
- Do not change theorem roots to avoid a recoverable installation problem.
