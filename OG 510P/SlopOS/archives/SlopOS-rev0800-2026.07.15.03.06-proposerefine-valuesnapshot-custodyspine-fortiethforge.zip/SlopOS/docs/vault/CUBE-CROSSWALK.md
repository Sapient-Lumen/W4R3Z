# Companion-cube crosswalk

| Cube | Adversarial lesson retained | Not imported into K0 |
|---|---|---|
| Foundry | intended application is not actual effect | rule/effect object families |
| Harbor | response is not reliance or consent | UI event taxonomies |
| Helm | exported proof is evidence only; reviewed-basis drift requires fresh review | export/retention kernel objects |
| Schell | presentation and review are not effect | release/change workflow schemas |
| Steward | dependency/readiness evidence is not service effect | topology lifecycle schemas |
| ViewFS | names and projections are not authority | mount/watch compatibility objects |
| Ward | verification evidence is not verdict, remedy, currentness, or authority | appraisal/remedy schemas |

These are test pressures for the Runtime and for invalid-inference checks.  They are
not independent validation because the cubes share SlopOS ancestry.

Excavation 005 preserves exact Helm and Ward source extracts under
`vault/searchable/companions/`; shared ancestry still prevents treating them as
independent validation.

Excavation 006 returns to the boss SlopOS cube rather than treating companion
agreement as independent support.  It promotes deterministic bounded-sequence
exhaustion and denial non-consumption while leaving portal and ordering schemas in
quarantine.

Excavation 007 again returns to the boss SlopOS cube. The old abstract machine,
capability law, invariant ledger, obligation registry, TCB note, and trusted-operation
registry provide proof discipline but no concrete fixed-array representation. Epoch
Zero therefore creates `CAP-REP` locally and imports no companion schema or CSpace
ontology.

Excavation 008 uses a narrow pair of Foundry specimens only to recover the old
separation between rule evaluation and committed effect. It also recovers the boss
SlopOS first-failure rule. Shared ancestry means this is continuity evidence, not
independent confirmation; no Foundry ledger, witness, or bypass-fence object enters
K0.

Excavation 039 returns to the boss SlopOS rev0761 and rev0769 lines. It promotes the
independent model/core boundary, typed canonical observation, semantic result
precedence, and the explicit admission that generated syntax does not prove C++
semantics. It does not import the old snapshot code, transition registries,
proof-packet machinery, or alternate program emitter. The current PROPOSE checker is
a small downstream observer, not a new normative machine.
