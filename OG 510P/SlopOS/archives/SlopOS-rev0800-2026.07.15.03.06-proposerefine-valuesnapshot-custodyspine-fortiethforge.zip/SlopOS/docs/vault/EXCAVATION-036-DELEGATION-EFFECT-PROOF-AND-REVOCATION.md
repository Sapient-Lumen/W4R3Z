# Vault excavation 036 — delegation, effect, proof, and revocation

**Source custody:** eight preserved cubes under `vault/source-archives/`  
**Excavation date:** 2026-07-15

## Promoted invariant

Across old SlopOS, Foundry, Harbor, Schell, Steward, Ward, Helm, and ViewFS, the most
valuable recurring structure is an effect fence:

```text
selected rule / proposal / response / receipt / observation
    is not
bound authority / admitted transition / committed effect / current proof
```

Foundry’s rule-effect ledgers and bypass fences make the failure concrete: a selected
rule or checker success cannot be displayed as if it changed a carrier unless a
separate effect witness exists. Harbor’s response/reliance boundary, Ward’s proof
intake/currentness, Steward’s narrowing gates, and Schell’s drift/release deltas are
variations of the same non-promotion law.

Rev0798 promotes the invariant, not the entire vocabulary. It appears as Office V2
claim/gate/evidence separation and as the authority machine’s proposal/lease/invoke/
observe event separation.

## Old SlopOS RFC pressure

Selected rev0760 RFCs remain useful:

- RFC-0013: deterministic replay is debugging/evidence and must have an explicit
  nondeterminism boundary; replay does not authorize an effect.
- RFC-0019: epoch/generation revocation gives a simple use-site check but requires a
  no-resurrection discipline and explicit wrap/reuse assumptions.
- RFC-0028: automation policy should be veto-only or narrowing, never an ambient
  source of new authority.
- RFC-0030: content-address evidence binds exact bytes but must keep artifact
  identity, evidence, and authority separate.
- RFC-0054 / RFC-0069: authority diffs and consent receipts are explanatory/binding
  surfaces, not grants by themselves.
- RFC-0066: leases and limited-use proxies should attenuate authority and fail closed
  on time/use scope.

Rev0798 adds one correction absent from the first specimen draft: effect magnitude
must also be attenuated. A one-use lease without a magnitude ceiling is still broad
authority.

## Quarantined material

- global schema/noun adoption;
- automatic porting of old Python checkers;
- large policy engines, registries, dashboards, watchers, sync/admin planes;
- cryptographic credential claims without key/trust/revocation design;
- distributed revocation, keepalive renewal, or “latest” state lookup;
- replay as runtime authority;
- receipts as completion/currentness;
- a derivation tree merely because seL4 has one.

## Promotion test

An old-vault idea enters living construction only when it supplies one of:

- a counterexample that a current test can reproduce;
- an invariant represented in an existing typed ledger;
- a proof obligation tied to a current operation;
- a mechanism that reduces privilege or assumptions; or
- a measured rejection that changes the next action.

Otherwise it remains custody pressure.
