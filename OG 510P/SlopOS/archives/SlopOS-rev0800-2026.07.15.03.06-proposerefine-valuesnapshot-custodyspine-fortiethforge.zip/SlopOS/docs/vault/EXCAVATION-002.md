# Excavation 002 — What the vault changes now

This pass searched the predecessor's textual surface and promoted only ideas that
constrain the active machine.  The deepest useful seam is the distinction among:

1. declared or presented intent;
2. validated authority;
3. accepted transition;
4. actual authoritative effect;
5. evidence describing that effect.

K0 now embodies that seam as:

```text
BootstrapPlan --validate/install--> root authority
Command + current capability --transition--> accepted effect or explicit denial
Canonical observation/trace ----------------> evidence only
```

The vault also warns against a common failure mode: adding a new noun for every
boundary case.  Epoch Zero therefore has only domain, memory, endpoint, capability,
mapping, and message.  Provenance, receipts, currentness, and richer policy remain
outside K0 until a concrete transition requires them.

The searchable vault and generated catalog support deeper later passes.  No count or
keyword hit is itself an architectural vote.
