# Excavation 019 — closed boot policy, initial authority, and effect boundaries

## Sources revisited

The first-physical selection now also byte-preserves the old boot manifest, general
configuration, DMA posture, initial-state snapshot, and D-INITSNAP RFC alongside the
static-partition and address-net material.

These files are valuable research, not active schema authority.

## Finding 1 — time-zero authority should be a pinned value

The old CH-INIT idea correctly sought an explicit object/capability/mapping snapshot
rather than implicit bootstrap code. The enduring lesson is not its schema; it is
that initial authority should be closed, bounded, inspectable, and bound to an exact
boot artifact.

**Promotion:** M0-STATIC2 is one immutable policy and one exact abstract plan. It has
no patch/apply/watch language and no hidden hardware discovery.

## Finding 2 — artifact identity is below neither policy nor effect

The old CH-BOOT text distinguished the digest of a configuration from evidence that
it was the applied configuration. That distinction survives:

```text
policy bytes != admitted policy value
admitted value != plan
plan != encoded tables
encoded tables != selected live roots
selected roots != observed isolation
```

**Promotion:** every rung receives its own obligation; no digest or proof packet
silently becomes installation effect.

## Finding 3 — closed configuration reduces but does not erase proof work

Static partitioning removes dynamic lifecycle and allocator states, making exhaustive
policy/plan reasoning practical. It does not prove descriptor encoding, table walks,
TLB state, boot selection, or hardware behavior.

**Promotion:** close the finite policy and plan now; keep architecture and boot rows
not started.

## Finding 4 — DMA is outside the first claim

The old DMA posture was unusually clear: CPU translation isolation cannot imply DMA
containment. A no-device initial configuration is a scope fence, not an IOMMU theorem.

**Promotion:** M0-STATIC2 assigns no DMA-capable device and makes no DMA/device claim.
Future device profiles must add an explicit IOMMU/SMMU relation or weaken the claim.

## Finding 5 — effect evidence needs a separate state machine

Across SlopOS and the companion cubes, accepted policy, selected action, recorded
response, and actual effect repeatedly diverge. The new installation ledger preserves
that warning in executable form: it can certify completion of the exact abstract
record set, but remains explicitly below page-table effect.

## Result

The old vault supplied pressure for a much smaller active artifact. None of CH-CFG,
CH-BOOT, CH-INIT, CH-PART, or CH-ADDRNET is promoted. Their distinctions now shape
one finite C++20/Isabelle construction that can be falsified before architecture
code begins.
