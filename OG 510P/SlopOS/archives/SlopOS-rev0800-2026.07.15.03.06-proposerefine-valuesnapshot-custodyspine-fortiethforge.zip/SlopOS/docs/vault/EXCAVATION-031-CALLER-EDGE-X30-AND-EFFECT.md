# Excavation 031 — caller edge, X30, and effect

## Question

What should the old SlopOS and Foundry research contribute while the new epoch
crosses from a current `RET X30` helper value toward one possible caller?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/caller-edge-x30-effect-law/MANIFEST.tsv
```

It contains selected unsafe-obligation, initial-state, effect-contract,
boot-provenance, ordering-token, effect-witness, and Foundry rule/effect
material. These sources are genealogically related pressure, not independent
proof and not active executable schemas.

## Findings

### 1. A numeric continuation is not live X30

The old initial-state and effect-contract materials repeatedly separate a
required value from an observed current value. `call_site + 4` can be exact
without X30 ever containing that number.

### 2. Caller authority is edge-local

The callee cannot mint evidence that a caller executed a branch-and-link.
Foundry's rule/effect law and the old ordering-token posture both reject
self-issued evidence crossing an ownership boundary.

```text
callee-selected continuation
!= caller-established call edge
```

### 3. A word relation is not an instruction effect

An exact BL encoding can be checked as arithmetic. It does not establish source,
object, installation, fetch, decode, execution, exception freedom, or link-
register effect.

### 4. Shared value-page membership is not current caller presence

The selected projected range lies inside the same admitted 4 KiB RX value page
as the helper. The current loader bytes at that range are still zero. Numeric
containment and permission intent do not launder absent bytes into a caller.

### 5. Call and return completion are separate propositions

Even a future established call edge would not establish that the helper returns,
that the continuation is executable, or that the return completed without an
exception or control transfer.

### 6. Readiness remains monotone and fail-closed

The correct current readiness is `BLOCKED_PROJECTED_CALLER_ARTIFACT`. The
contract may expose the exact missing work; it cannot discharge that work by
naming it.

## Promotions

This excavation promotes VPR-115 through VPR-122 only. No old call schema,
ordering-token runtime, effect witness, boot record, or generic control-flow
language is reactivated.
