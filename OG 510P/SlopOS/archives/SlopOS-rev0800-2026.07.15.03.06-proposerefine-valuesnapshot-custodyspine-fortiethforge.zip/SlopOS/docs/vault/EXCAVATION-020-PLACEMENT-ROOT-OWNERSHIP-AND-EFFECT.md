# Excavation 020 — placement, root ownership, and effect

## Sources reread

| Preserved source | Bytes | SHA-256 |
|---|---:|---|
| `vault/searchable/rev0760/first-physical-static-isolation/rfcs/0022-address-decoding-nets-and-page-table-gen.md` | 3907 | `965df2670b4081d3b33be8ddb88c94c6122ed65b391ac02607bc06b8eba20627` |
| `vault/searchable/rev0760/first-physical-static-isolation/docs/30-architecture/address-decode-net-schema-v0.md` | 1855 | `d90a88bc756d5115d4824af3f6b6fe6d2e1d63a50976489e46294aa2e91e78f9` |
| `vault/searchable/rev0760/first-physical-static-isolation/adrs/0002-phase1-static-partition-profile.md` | 2564 | `472b5b7be739fe41b50443c7bb4e761f7e6e494ae16afd390f40f2dfdd8c74a0` |
| `vault/searchable/rev0760/foundation/docs/20-assurance/unsafe-obligation-registry.md` | 2720 | `4dbc694c11c14ea179cb9e6a08c3fa735169db0e202b0a97caddae9ac1862535` |
| `vault/searchable/rev0760/first-physical-static-isolation/rfcs/0024-initial-state-snapshots-and-cap-distribution-language.md` | 3537 | `ec26484e1da59e51ab32196986c3d7c2fd62e543f73cdccec2f71edcf4a29f3e` |
| `vault/searchable/rev0760/first-physical-static-isolation/docs/30-architecture/boot-manifest-schema-v0.md` | 6741 | `a759dac93e4a4a35c9961be687295de88fdc57a399b46c886c831448289f359b` |

The sources are pressure and lineage, not active schema authority.

## Recovered laws

### Translation structure is explicit data

The old RFC correctly separated an auditable translation graph from ad-hoc privileged
page-table mutation.  Epoch Zero retains the separation but rejects the old broad
schema.  Rev0779 owns one closed graph value, not a generic address-net language.

### No implicit or mystery edge

Closed-world validation and deny-by-absence survive promotion.  A table descriptor
that resolves globally is not sufficient: each root must own the complete path it
can traverse.  The discovered cross-domain-edge counterexample makes this law
concrete.

```text
valid descriptor shape
!= valid child for this root
```

### Generation, admission, placement, and effect differ

The old generator/checker split remains useful only when each transition is named:

```text
abstract plan
!= generated descriptor values
!= admitted graph value
!= placed bytes
!= selected root
!= register effect
!= hardware walk
!= isolation theorem
```

### Time-zero authority is a separate artifact

The old initial-snapshot work warns against allowing a placement graph to become an
implicit complete boot state.  Capabilities, objects, mappings, memory contents,
root/control records, and boot selection eventually need an explicit common
initial-state relation.  Rev0779 does not invent that language prematurely.

### Unsafe page-table effect begins later

The old unsafe registry named exclusive ownership, table aliasing, and TLB protocol
as preconditions of page-table updates.  Those are not satisfied by a pure graph
value.  M0-P4 may describe a load/admission transaction, but physical mutation and
TLB effect remain fenced until their own implementation and proof obligations exist.

## Active promotions

- **VPR-049 — Root-owned reachability:** every selected root constrains the set of
  descendant table placements it may traverse; globally valid cross-owner edges
  reject.
- **VPR-050 — Placement/effect fence:** exact graph bytes and placement records do
  not imply physical placement, root selection, register effect, or hardware walk.
- **VPR-051 — Closed graph before generic schema:** build and prove one exact graph
  before considering a reusable address-net language or allocator.
- **VPR-052 — Initial state is wider than translations:** no translation artifact
  silently becomes the complete time-zero authority state.

## Quarantine

CH-ADDRNET, CH-BOOT, CH-INIT, general SoC topology, generic MMU APIs, device-tree
import, dynamic allocation, runtime patching, and full platform completeness remain
quarantined.  They may return only when a failed bounded construction demands them.
