# Excavation 014 — exact binding and proof-process law

## Question

What should the old SlopOS and companion research contribute to the first direct
binding between proof-generated C++20 text and the Isabelle theorem root, and what
must remain quarantined?

This excavation reads the vault as pressure, not authority.  The active decision is
made by the current tiny construction and its failures.

## Sources reopened

| Source | Preserved path | SHA-256 | Pressure recovered |
|---|---|---|---|
| IDL digest and ordinal policy | `vault/searchable/rev0760/canonical-program-generated-source/docs/60-engineering/idl-digest-and-ordinal-policy.md` | `b1b56cb1931548fa5785a03b6d65eee52675945f2089b32780b0b7f394d417a3` | Identity should bind a canonical IR, not incidental text. |
| Privileged-interface IDL/codegen RFC | `vault/searchable/rev0760/canonical-program-generated-source/rfcs/0011-idl-and-codegen-for-privileged-interfaces.md` | `775fb00870dd6896088d2670280a5bf630a9b06afe3676aa373ed2c3f5e35ffe` | Definitions are data, generated code is derived, and drift is fail-closed. |
| Address-net/table generation RFC | `vault/searchable/rev0760/canonical-program-generated-source/rfcs/0022-address-decoding-nets-and-page-table-gen.md` | `965df2670b4081d3b33be8ddb88c94c6122ed65b391ac02607bc06b8eba20627` | Generation and validation are separate; installed effects require another relation. |
| Proof-evidence manifest | `vault/searchable/rev0760/evidence-law/docs/20-assurance/proof-evidence-manifest-v0.md` | `ddde9b60cfc68e0ef51a70d4d01d0551e38e51a70614147d33160e3ff8a42c8f` | A joined manifest does not upgrade lint or currentness into proof. |
| Proof-import rebind fixtures | `vault/searchable/rev0760/evidence-law/docs/40-verification/proof-import-rebind-fixtures-v0.md` | `769a63b6a341763c111ff40f6bfb20941088d5c50a337140f9449c63ab2e904b` | Even verified external proof needs exact local rebinding and grants no action authority. |
| Ward verification-intake boundary | `vault/searchable/companions/ward/docs/30-architecture/verification-intake-proof-drift-guards-and-metadata-lineage-audit.md` | `5f0a6648db60e09fd5d4fc6d9f198b014fc2ef1f89663aba1470f72a30920081` | Verification receipts do not execute remedies, clear quarantine, or update current state. |
| Helm proof-portability ADR | `vault/searchable/companions/helm/adrs/0060-audit-export-before-proof-portability-runtime.md` | `73458debc9f12dd48b058a273f14955b29da3ca8ff28fd8964d53ffa1f6024af` | Portable proof bundles remain evidence-only until locally rebound. |
| Alternate rev0769 program-emitter branch | `vault/searchable/rev0769-alternate-program-emitter/` | collection manifest in that directory | A tiny closed DSL can remove copy drift, but source authority direction must be singular. |

## Recovered laws

### 1. Canonical structure outranks raw text, but structure is not semantics

The old IDL work correctly rejected raw-source digests as semantic identity.  Rev0770
therefore does not stop at the header fingerprint.  The independent C++20 binder
extracts a finite certificate recording constants, operators, atom order, branch
polarity, tags, aggregate fields, and assertions.  Isabelle checks that certificate
against one admitted value.

The promotion is deliberately narrow:

```text
raw bytes --C++20 binder--> finite certificate --Isabelle--> admitted relation
```

A hash remains only a currentness identity.  The certificate relation remains only
the finite relation actually checked.  Neither is ISO C++20 evaluation.

### 2. Generation and validation must have different failure surfaces

The proof-owned Isabelle/ML renderer creates the header.  The C++20 binder reads the
whole header independently and rejects unknown syntax or emits a visibly different
certificate for admitted near misses.  Shared output bytes do not substitute for this
second path.

The alternate rev0769 branch usefully demonstrated a closed C++20 DSL and bounded
emitter witness, but made that DSL the authoring authority.  Importing it into the
active branch would create two semantic roots.  Its code remains quarantined as a
comparison corpus; only its lesson about closed grammars and explicit emitter debt is
promoted.

### 3. Local rebind is required even for checked proof output

The old proof-import fixtures distinguish external verification from local evidence
admission.  The same rule applies inside one repository.  Isabelle acceptance is
bound locally to:

- the exact theorem map;
- proof-tree fingerprint;
- active construction basis;
- exact generated certificate artifacts;
- exact source export/active byte equality;
- exact toolchain and invocation envelope.

A previous packet is never current merely because the theorem names still exist.

### 4. Evidence production is an effectful operation

The old cubes repeatedly separated observation, selection, review, and evidence from
authority and effect.  Rev0770 found the corresponding office-level failure: a proof
command using a global clean path could damage the CMake build that invoked it and
could outlive an interrupted tool call.

Therefore the proof process has its own effect law:

```text
proof evidence may mutate only repository-private disposable proof state;
it must not silently mutate the source tree, CMake build, ambient user session,
or a concurrent proof run.
```

DEC-0023 implements that law with a private `HOME`, a private workspace, an exclusive
lock, no global clean/fresh switch, and a supervised worker process group.

### 5. Parser size is trust debt, not hidden progress

The exact binder is intentionally closed but is still approximately 1,200 physical
C++ source lines for a 371-token input.  That ratio is not evidence that a home-grown
C++ frontend should grow.  It is a hard scaling warning.

Promotion for this revision is limited to one fragment and one certificate.  A second
fragment requires either:

- a materially smaller reusable checked derivation mechanism;
- an independently justified formal C++ frontend/semantics route;
- or a measured result showing that duplicating the binder removes more named debt
  than it creates.

## Promoted into the active epoch

- canonical finite certificate rather than digest-only interpretation;
- whole-input and end-of-file recognition;
- deterministic theory/manifest artifacts checked before Isabelle acceptance;
- exact local rebind of theorem evidence to current source and basis;
- explicit parser, preprocessing/include, ISO-language, compiler, ABI, binary,
  and platform debts;
- repository-private proof execution and concurrent-session exclusion;
- alternate-branch preservation without mixed authority.

## Quarantined

- a general C++ parser grown opportunistically from the exact binder;
- a digest treated as a semantic theorem;
- generated code treated as authoritative merely because it is generated;
- a second authoring DSL competing with the HOL source program;
- an imported theorem packet treated as current without local replay;
- a proof command allowed to clean ambient state;
- mutation-test volume promoted into universal parser correctness.

## Consequence for the next office

The next useful proof step is structural evaluation of the finite certificate.  It
must execute the recorded operators, joins, branch polarities, tags, and fields rather
than immediately delegating to the seven-atom source evaluator.  Even success leaves
parser adequacy for ISO C++20 and compiler preservation open.
