# Excavation 013 — canonical program and generated privileged source

## Question

Does the predecessor contain a design law that helps relate a checked semantic
program to active privileged source without allowing generated equality to masquerade
as source or compiler proof?

## Exact selection

The byte-bound selection lives at:

```text
vault/searchable/rev0760/canonical-program-generated-source/
```

It contains five exact rev0760 sources plus a local README and SHA-256 manifest:

- RFC-0011, IDL and code generation for privileged interfaces;
- the IDL digest and ordinal policy;
- RFC-0022, address-decoding nets and page-table generation;
- the compact assurance-case template;
- the layered verification strategy.

The old files are research lineage. Their D-IDL, CH-* schemas, Rust plan, and
page-table surface are not active Epoch Zero design.

## Findings

### 1. Canonical semantic data should outrank incidental source spelling

RFC-0011 describes interface definitions as data and generated stubs as derived
artifacts. The digest policy explicitly prefers compiler-produced canonical IR over
raw source text because formatting and import order are not semantics.

**Promotion:** for the scalar bridge, the closed HOL source program is the canonical
semantic object. The C++ header is a derived construction artifact. Its exact bytes
must remain current, but raw text is not promoted into theorem authority.

### 2. Generated privileged output needs a fail-closed drift gate

The old generator contract required pinned input and generator identity, generated
conformance tests, a manifest, and a build failure on output drift.

**Promotion:** the C++20 proof runner exports the generated header from the accepted
Isabelle session and rejects missing, stale, or altered active bytes. The ordinary
build compiles the active generated path; the formal test graph cannot silently skip
the comparison.

### 3. Generator trust must remain visible

The predecessor correctly proposed generation but did not thereby prove that a
generator preserves semantics. Canonical IR and byte-current output remove ordinary
drift, not translation correctness.

**Promotion:** the closed Isabelle/ML renderer is an explicit trusted translation
component. `SOURCE_BYTES_CURRENT` is CONFORMANCE evidence. The ISO C++20 parser,
evaluator, compiler, ABI, and platform edges remain open.

### 4. Explicit data plus a narrow privileged validator is reusable later

RFC-0022 treats translation topology as bounded explicit data, allows an external
generator to synthesize tables, and keeps a narrow privileged validator and later
mechanized correspondence. That is a useful future pattern for a static B/C boot
configuration.

**Quarantine:** no address net, page table, MMU API, device graph, or platform fact
enters K0 now. The pattern becomes relevant only after the scalar/source and compiler
edges are sufficiently understood and one platform experiment is admitted by a new
decision.

### 5. Assurance arguments must preserve layer and non-claim boundaries

The compact assurance case decomposes a claim into invariants, transition
preservation, implementation/refinement evidence, and platform/boot assumptions.
The verification strategy likewise separates abstract spec, executable model,
implementation, and refinement.

**Promotion:** the new source-program theorem, generated-byte conformance, C++
finite witness, compiler debt, and platform non-claim remain separate obligation
rows and evidence classes.

## Promotions

- **VPR-025:** canonical proof-facing programs may own tiny privileged decisions;
  generated source is derived and must be byte-current.
- **VPR-026:** generated-output identity is conformance, not source semantics or
  compiler proof.
- **VPR-027:** every renderer, parser, validator, and binder is named in the trusted
  boundary until a checked correspondence removes it.
- **VPR-028:** explicit-data-plus-validator is retained as future static platform
  pressure, not imported into infancy.

## Negative result

The excavation does not validate the old IDL architecture, old schema vocabulary,
or a generic generator framework. Rev0769 adopts one closed seven-atom source
program and one header because the fragment is small enough to audit. Generalizing
it before a second proven need would recreate planning saturation.
