# Excavation 029 — helper return, handoff, and effect

## Question

What should the old SlopOS and Foundry research contribute when the new epoch
must choose the terminal semantic role of one EL2 activation fragment?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/terminal-control-handoff-effect-law/MANIFEST.tsv
```

It contains selected old boot-manifest, initial-state, boot-provenance,
effect-contract, unsafe-boundary, effect-witness, and Foundry rule/effect
material. It is related research and adversarial pressure, not active calling
convention, boot authority, or proof.

## Findings

### 1. Helper completion is not boot handoff

The old boot material binds boot artifacts, policy, and handoff state
explicitly. A helper that adjusts EL2 control values does not become the boot
selector or guest entry point merely because it runs during bring-up.

### 2. Return authority belongs to a caller edge

A return register is not ambient continuation authority. The caller must create
the link, own the continuation, and provide a fetch-visible same-EL target.

### 3. Function metadata is evidence, not execution

The `%function` source annotation and ELF symbol support the callable role. They
do not establish a live call, X30 value, stack state, or completed return.

### 4. Exception return has different state

The old initial-state law requires explicit time-zero authority and state.
ERET cannot be inferred without ELR/SPSR and target-state contracts.

### 5. Fallthrough requires owned adjacent bytes

Zero-filled tail or physical adjacency is not a continuation. A fallthrough
role requires an exact adjacent artifact, placement, visibility, and ownership
relation.

### 6. Selecting meaning does not repair bytes

The effect-witness law applies directly:

```text
selected role
!= selected instruction present
!= loaded instruction
!= executed instruction
!= completed control transfer
```

### 7. Stable semantic prefixes should remain stable

The nine M0-P8 words realize the selected architecture events. Terminal return
is a routine-composition edge and should not be laundered into an extra event.
The cascade can preserve the event prefix while changing source/object/loader/
visibility artifacts around it.

## Promotions

This excavation promotes VPR-099 through VPR-106 only. No old boot schema,
handoff object, generic ABI, loader, return wrapper, effect witness, or
exception-frame format is reactivated.
