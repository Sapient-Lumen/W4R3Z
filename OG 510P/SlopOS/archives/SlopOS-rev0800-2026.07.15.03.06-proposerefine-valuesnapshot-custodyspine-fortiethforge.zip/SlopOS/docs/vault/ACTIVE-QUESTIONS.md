# Active vault-derived questions — rev0800

## Proof and authority

1. What is the smallest checked relation from `AuthorityValueSnapshot` to
   `p0_propose_context` that preserves identifiers, count, sequence, selected
   proposal, and deliberate frame/abstraction choices without reproducing the C++
   transition in HOL?
2. Can that relation be proved against the present C++ source with a genuinely small
   source-semantics boundary, or would a new parser/generator add more trust than it
   removes?
3. Which operation should follow PROPOSE only after the vertical edge closes: ISSUE
   as another non-effect authority construction, or INVOKE as the first effectful
   admission? What specific counterexample selects one?
4. Is generation-qualified identity required before the first privileged effect, or
   can the first slice safely retain fixed capacity and permanent no-reuse?
5. For the first nontrivial revoke, which dependent state is invalidated, how are
   in-flight completions fenced, and what observable event permits reclamation?

## Repository and custody

6. Can the manifest walker gain descriptor-relative hostile-mutation resistance in a
   Linux adapter while keeping the portable C++20 value semantics unchanged?
7. What exact metadata is required for a content-addressed recovery pack to
   reconstruct original ZIP container bytes, rather than only reproduce extracted
   payloads?
8. How should a derivative pack prove completeness, reversibility, and old-to-new
   mapping without becoming a second ambiguous custody root?
9. Which archived M0 constructions can be reduced to compact counterexamples and
   premises, leaving their full implementations only in custody?

## Office and exit

10. What independent review artifact is sufficient to challenge a final exact basis
    without building another general attestation platform?
11. Which proof/tool cache identities and resource limits make Isabelle/QEMU recovery
    repeatable without placing heavyweight external layers inside the subject?
12. What is the smallest real effect adapter that can distinguish admission,
    mechanism, completion, and current observation without reopening the whole
    historical platform ladder?
