# Excavation 006 — finite accepted-sequence law

**Excavated:** 2026-07-10
**Source cube:** SlopOS rev0760
**Purpose:** resolve the old-vault question raised by the rev0763 C++ commit witness

## Question

Does the old cube supply a usable rule for a finite accepted-transition counter, or
would fail-closed exhaustion be a new Epoch Zero invention?

## Exact source set

Byte-identical copies are preserved under
`vault/searchable/rev0760/sequence-law/`:

| Source | Bytes | SHA-256 | Relevant old rule |
|---|---:|---|---|
| `docs/70-llm-control/acp-validator-semantics.md` | 48500 | `5374d5729c15fd3f8a288ad1e74bb98bec4055556eae4bccce2deab00516c6e5` | bounded accepted sequences preserve their declared invariant; exhaustion rejects deterministically |
| `docs/40-verification/portal-net-request-sequence-corpus-v0.md` | 12712 | `e7d553b12beab787b71604681a51d894f00cd85b182f5b3b1393d344f406b7e1` | denial and duplicate paths do not consume accepted order positions; state changes only on acceptance |
| `docs/30-architecture/ordering-token-schema-v0.md` | 3615 | `05b60d6977b05fe6713254b4e8614ee28638beda151b4f56e8ef2286d77483dc` | sequence fields are bounded by an implementation-defined maximum and are non-authoritative witnesses |
| `docs/30-architecture/ordering-token-posture-v0.md` | 7432 | `f38f3b7dd565c7559dc8f2948a18b94fc4a451d065e6e8e2659ac0acfe0d446c` | no implicit kernel-global sequencer or portable arithmetic authority follows from a sequence field |
| `docs/30-architecture/replay-stream-schema-v0.md` | 1566 | `bd77cb03c4b4ec5ab32d0936ccd7751479f5b520c1a720496c861f0c2f595424` | an old replay schema used a monotone `u64`, exposing the same finite-representation pressure without defining wrap |

The selection inventory is
`vault/searchable/rev0760/sequence-law/SHA256SUMS`.

## Finding

The old cube did contain the essential fail-closed law: for an explicitly bounded
authority-relevant sequence, exhaustion rejects deterministically.  Its executable
sequence corpus also made the rule **denial does not consume sequence** a
first-class invariant.  Therefore
DEC-0011 does not invent a permissive exception or silently reinterpret an old
counter; it narrows an existing rule to K0's accepted-transition ordinal.

The old cube did **not** define:

- the exact terminal value for this K0 counter;
- result precedence at the terminal value;
- a C++ unsigned-integer relation to an Isabelle natural;
- reboot/reset/epoch behavior;
- whether a global machine ordinal should be portable or authoritative.

Those remain Epoch Zero design and proof work.  In particular, the current
`accepted_sequence` is an internal deterministic observation and correspondence
coordinate.  It is not a capability, ordering token, reservation API, conflict-key
stream, or grant of authority.

## Promoted rule

`VPR-010` promotes only this finite-machine law:

1. accepted effects consume exactly one sequence position;
2. rejected operations consume none and preserve the exact pre-state;
3. the finite representation never silently wraps;
4. an otherwise accepting operation at the terminal value rejects deterministically;
5. sequence position remains evidence/observation, never authority.

DEC-0011 selects the concrete Epoch Zero guard placement: ordinary structural,
existence/conflict, authority, and operation-capacity checks retain precedence;
`sequence_available` is the final guard before commit.

## Rejected imports

No portal request, CH-ORDERTOK, ACP fuel, dedupe, receipt, replay-stream, restart,
persistence, stream-owner, or epoch schema enters K0.  The old documents supplied a
boundary law, not an implementation package.

## Construction pressure

The next office can now implement sequence exhaustion without another general
excavation.  It must update all four accepting K0 operations, D0, the generated
DERIVE program, exact precedence tests, and the finite witnesses together.  Any
future proposal to reset or widen the counter requires new pressure and a separate
decision.
