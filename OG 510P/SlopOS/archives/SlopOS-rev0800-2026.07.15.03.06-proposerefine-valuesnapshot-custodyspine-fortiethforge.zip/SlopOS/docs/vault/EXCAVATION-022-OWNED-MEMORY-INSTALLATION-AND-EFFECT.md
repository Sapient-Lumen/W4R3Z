# Excavation 022 — owned memory, installation, and effect

## Why this excavation exists

M0-P5 is the first new-epoch construction that copies selected table bytes
into an object named memory.  That naming creates a predictable laundering
risk: a reader may infer real physical placement, current hardware effect, or
isolation merely because a pure C++ value has page-shaped fields.

The old vault was reread specifically for how it separated initial state,
placement, ownership, atomic activation, memory backing, and effect.
Byte-preserved sources are under:

```text
vault/searchable/owned-memory-install-effect-law/
```

They remain research pressure only.

## Preserved sources

| Source | Recovered pressure |
|---|---|
| `unsafe-obligation-registry.md` | A page-table update requires exclusive mapping-object ownership, no mutable alias, and a defined TLB protocol; naming a page-table function does not discharge those premises. |
| `init-state-snapshot-schema-v0.md` | A time-zero description needs an installation/match obligation; the description is not the installed state. |
| RFC-0024 | Initial object/capability/mapping state should be a pinned artifact and checked against actual initialization rather than left implicit. |
| RFC-0051 | Atomic activation should expose one deterministic current-state switch and preserve the previous authoritative state on failure. |
| `memory-locality-authority-boundary-v0.md` | Placement facts and proximity hints do not create ownership or authority. |
| `microvm-memory-backing-posture-v0.md` | Anonymous/file/memfd/shared backing and host page-size choices are implementation-local mechanisms, not portable semantic promises. |
| Foundry rule-effect rulebook | Selection, checker success, a ledger, and an intended application are not a bound effect without the actual effect edge. |

Exact bytes and SHA-256 values are recorded in the focused `MANIFEST.tsv`.

## Promoted laws

### Description is not installation

```text
initial-state description
!= admitted installation input
!= installed pure state
!= machine memory
```

The new formal transition therefore distinguishes the request, precondition,
initial memory, installed memory, and acceptance bit.

### Placement identity is not address authority

```text
aligned integer identity
!= host pointer
!= physical address validity
!= lifetime
!= exclusive write authority
```

M0-P5 uses integer page identities and byte arrays only.  No cast or
dereference crosses this line.

### Admission is not effect

```text
selected packet
!= sealed admission ledger
!= copied pure page value
!= physical bytes written
!= current live root
```

The packet and ledger are checked again before the pure copy.  Even the
accepted copy remains below physical effect.

### Atomicity is a state relation, not a slogan

The formal relation returns either the unique installed value or the exact
input memory.  The constrained implementation validates before mutation and
the harness compares complete snapshots on rejection.  This closes a finite
value-level frame property only.

### Backing mechanism remains a later platform choice

The old cloud/microVM work listed anonymous memory, files, memfd, shared
mappings, huge pages, and prefaulting as runtime-local mechanism.  Epoch Zero
therefore does not allow the hosted `std::array` backing of `MemoryValue` to
become a statement about the eventual micro-hypervisor's allocation or memory
coherence model.

## Explicitly not promoted

The following old surfaces remain quarantined:

- generalized initial-state schemas;
- runtime snapshot/export or desired-state planes;
- host guest-RAM backing APIs;
- NUMA or memory-tier policy surfaces;
- update/rollback product machinery;
- generalized effect ledgers and witness schemas;
- a broad unsafe registry copied into new privileged code.

## Consequence for the proof ladder

The active ladder now reads:

```text
policy
-> abstract plan
-> descriptor and graph values
-> placement/admission packet
-> pure owned-memory installation relation
-X-> physical store
-X-> live root and architecture protocol
-X-> hardware observation
-X-> booted isolation
```

M0-P6 must consult authoritative Arm material before recording a selected
activation protocol.  No old-vault phrase may supply architecture semantics.
