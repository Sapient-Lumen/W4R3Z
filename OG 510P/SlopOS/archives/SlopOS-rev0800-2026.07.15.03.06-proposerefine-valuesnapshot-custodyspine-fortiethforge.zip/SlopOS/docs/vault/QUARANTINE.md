# Vault quarantine — rev0800

The following remain non-authoritative custody material:

- the complete rev0760 RFC/noun/schema/checker universe;
- hundreds of archived Python tools and mirrored registries/manifests;
- old release, dashboard, sync, watch, admin, policy-engine, lifecycle, portal, and
  ordering surfaces;
- any claim that replay, receipt, audit, rule selection, UI text, model output, or
  canonical rendering is authority or current state;
- generation revocation without no-resurrection and wrap/reuse analysis;
- lease renewal by ambient keepalive;
- content addressing presented as provenance or approval;
- old proof/evidence packets relabeled for a changed active basis;
- ordinal continuation of the M0 rung ladder; and
- companion-cube agreement treated as independent validation.

Quarantine is not rejection of every underlying idea. It prevents historical scale,
vocabulary, and implementation choices from silently becoming present authority.

## Rev0799 quarantine retained

- the alternate `living/epoch-zero/` branch is evidence, not a second normative root;
- slot reuse, subtree revocation, dependent mapping invalidation, in-flight
  cancellation, reclamation, external recall, and evidence supersession remain
  outside the specimen;
- PoisonCap and CHERI-D are research pressure, not selected mechanisms;
- historical M0/AArch64 targets are opt-in `full-research`; and
- in-place vault deduplication is forbidden.

## Rev0800 quarantine

- rev0761 snapshot/digest/rendering implementations are not copied into the current
  authority layer;
- old proof registries, operation registries, and transition schemas do not enter the
  living repo merely because their discipline is useful;
- the rev0769 alternate program emitter and its generated PROPOSE-like bridge pattern
  are not generalized into a new language;
- `AuthorityValueSnapshot` is not persistence, storage authority, a wire format, an
  ABI promise, or a mutable view into the core;
- the executable PROPOSE checker is not a theorem prover and cannot authorize a
  transition;
- the new HOL declarations are not current theorem evidence until Isabelle2025-2
  checks the exact basis; and
- a content-addressed recovery pack remains a design, not custody replacement, until
  completeness/reversibility and original-container identities are demonstrated.
