# Excavation 033 — caller visibility, entry, and effect

## Question

What should the old cubes contribute while SlopOS moves from a current pure
caller/helper value toward a live call-and-return experiment?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/caller-visibility-entry-effect-law/MANIFEST.tsv
```

It includes old SlopOS unsafe-obligation, initial-state, effect-contract,
memory-locality, ordering, boot-provenance, and effect-witness material together
with Foundry rule/effect pressure. These sources are lineage and adversarial
requirements, not active machine authority or independent proof.

## Findings

### 1. Pure current bytes are not machine publication

The old initial-state and update material distinguishes a declared image from
installation and current effect. The same law applies to the generation-3 page:
its exact pure value does not establish that any processor-visible memory holds
those bytes.

### 2. Numeric permissions are not effective permissions

A permission value can be checked as data. It does not establish stage-1 or
stage-2 configuration, root selection, translation stability, W^X effect, or the
absence of a conflicting writable alias.

### 3. Cache intent is not cache completion

The old effect-witness material rejects promotion from requested or recorded
work to completed effect. A named D-cache publication or I-cache visibility
premise is not a barrier instruction, cache-maintenance execution, completion,
or observation.

### 4. Entry records are not live entry state

An intended PC, EL, execution-state bit, and X30 value are initial-state inputs.
They do not establish a register file, stack, exception mask, scheduler handoff,
or actual control transfer.

### 5. Fetched bytes are not BL completion

Even a future fetch observation is narrower than decode, issue, retirement,
architectural branch completion, callee entry, or X30 observation. Every edge
requires its own proposition.

### 6. Numeric X30 is not observed X30

The projected `PC+4` value is arithmetic. It does not establish that a processor
wrote or retained X30, that the callee sees it, or that a later RET consumes it.

### 7. RET permission is not completed return

A terminal `RET X30` word, same-EL policy, and effective executable permission
remain distinct from execution, completion, continuation fetch, and post-return
state.

### 8. Evidence about readiness is not readiness effect

A complete assessment, theorem packet, receipt, or audit can correctly report
that all prerequisites are named and none are discharged. The evidence must not
become an implicit discharge mechanism.

## Promotions

This excavation promotes VPR-131 through VPR-138 only. No historical boot
schema, effect object, cache operation, register API, memory writer, scheduler,
or execution mechanism is reactivated.
