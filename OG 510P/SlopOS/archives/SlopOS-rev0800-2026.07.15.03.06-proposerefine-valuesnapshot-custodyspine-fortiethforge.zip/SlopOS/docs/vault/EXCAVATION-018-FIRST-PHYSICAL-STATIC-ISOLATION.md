# Excavation 018 — first physical static-isolation construction

## Purpose

Revision 0773 looked beyond the scalar proof bridge without admitting a new machine
feature. The question was not “which old Phase 1 plan should be revived?” It was:

> Which distinctions from the old static-partition and hypervisor material would let
> the first physical SlopOS construction remain small enough to refine honestly?

A byte-preserved selection now lives under
`vault/searchable/rev0760/first-physical-static-isolation/`. It contains the old
accepted static-partition ADR, compiled-configuration ADR, hypervisor-first
assessment, closed exit budget, partition-policy and address-net sketches, and the
layering note. The old names and schemas remain research, not active law.

## Finding 1 — the first physical claim should be a closed configuration

The old D-PART material was strongest where it described a fixed composition rather
than a general virtualization service: explicit domains, disjoint resources, and
only declared communication. That shape agrees with the current two-domain hosted
infant and with the need for a finite refinement target.

**Promotion:** the first physical construction should be one named, immutable
configuration with two domains, disjoint memory, no assigned DMA-capable device, and
at most one explicit communication object. It is not yet a dynamic VM manager,
workstation, or appliance framework.

## Finding 2 — authoring, admission, and installation are three events

The old compiled-configuration decision correctly kept policy evaluation and rich
authoring outside privilege. But “a validator accepted the policy” still does not
mean page tables were installed correctly.

The new epoch therefore separates:

```text
unprivileged configuration authoring
  -> canonical admitted policy value
  -> checked installation plan
  -> architecture-specific tables/register effects
  -> observed booted isolation
```

**Promotion:** the privileged core may decode and validate a closed, bounded policy
value and install an already constrained plan. It must not contain a general policy
language, template engine, hardware-discovery engine, or hidden fallback.

## Finding 3 — non-overlap is not page-table correctness

A theorem that two physical ranges are disjoint is useful but insufficient. It does
not show that generated page-table entries represent those ranges, that the CPU uses
the intended translation root, that stale TLB entries are absent, or that another
translation path exists nowhere.

**Promotion:** future obligations must preserve four distinct rungs:

1. policy well-formedness and declared resource non-overlap;
2. abstract installation-plan correspondence to the policy;
3. selected architecture encoding correspondence for page-table and control values;
4. boot/platform evidence that the installed state is the state actually used.

No test or theorem at one rung promotes another implicitly.

## Finding 4 — address-net machinery is pressure, not first scope

The old D-ADDRNET proposal correctly identified silent translation paths and table
synthesis as future isolation hazards. Its graph and completeness machinery would,
however, be larger than the first two-domain target.

**Promotion:** the first platform model should name one CPU translation path and one
fixed page granularity. General address graphs, IOMMUs, bridges, device trees, and
heterogeneous SoC completeness remain quarantined. The first construction should be
shaped so that a later explicit address-net relation can replace assumptions rather
than requiring a rewrite.

## Finding 5 — DMA is an explicit non-claim, not a hand-wave

The old hypervisor-first material correctly says strong device isolation needs an
IOMMU story or a downgraded claim. The first physical SlopOS image can avoid lying by
assigning no DMA-capable device to either untrusted domain and by keeping device
access outside its claim.

**Promotion:** the initial isolation theorem is CPU-memory isolation only. DMA,
IOMMU, interrupt remapping, passthrough, and device ownership require separate later
bundles.

## Finding 6 — the entry/exit set must be smaller than the platform

The old exit-surface budget’s enduring lesson is the closed-set rule: raw hardware
may expose many causes, but the privileged machine should admit only a tiny normalized
set, rejecting everything else.

**Promotion:** the first booted configuration should have no rich emulation and no
open-ended hypercall surface. Its normalized privileged event set is fixed before
implementation. Growth requires a failed construction, proof obligation, or selected
profile theorem—not convenience.

## Finding 7 — platform choice is not yet earned

This cloudtainer currently provides GCC 14, Clang/LLD 17, CMake, and Ninja, but no
`qemu-system-x86_64` or `qemu-system-aarch64` executable. That is an operational fact,
not an architecture decision. Installing an emulator, selecting x86-64 versus
AArch64, selecting a boot protocol, and admitting an architecture model must occur in
one bounded platform decision after the scalar source bridge is frozen.

**Promotion:** do not write architecture-specific K0 code while E0-P12 is open. The
next physical objective begins with a toolchain/emulator recovery decision and a
minimal platform theorem envelope, not with page-table constants scattered through
C++.

## Candidate first physical theorem bundle

The first candidate bundle, provisionally named `M0-STATIC2`, should eventually
contain only claims of this shape:

```text
P0  one canonical two-domain policy is well formed
P1  private physical ranges are disjoint
P2  the one shared object is exactly the declared exception, if present
P3  the abstract install plan represents P0
P4  selected page-table values represent the abstract plan
P5  boot selects those roots under explicit platform assumptions
P6  unsupported privileged events reject or halt without widening authority
P7  the observed trace is replayable against the admitted design machine
```

`M0-STATIC2` must explicitly exclude DMA, devices, multicore, scheduling fairness,
information flow, side channels, live lifecycle, migration, persistence, rich
interrupt routing, workstation trusted paths, and agent Runtime semantics.

## Resulting law

```text
policy authoring != policy admission
policy admission != installation plan
installation plan != encoded page tables
encoded page tables != selected live translation roots
CPU-memory isolation != DMA isolation
static two-domain configuration != general hypervisor product
```

## What was not promoted

- the old CH-PART or CH-ADDRNET schemas as active formats;
- a general hypervisor ABI or VM-exit decoder;
- dynamic partition creation or lifecycle;
- device assignment, IOMMU, DMA, or interrupt remapping;
- a platform architecture or boot protocol;
- a QEMU dependency before its recovery path is decided;
- any new K0 command in rev0773.
