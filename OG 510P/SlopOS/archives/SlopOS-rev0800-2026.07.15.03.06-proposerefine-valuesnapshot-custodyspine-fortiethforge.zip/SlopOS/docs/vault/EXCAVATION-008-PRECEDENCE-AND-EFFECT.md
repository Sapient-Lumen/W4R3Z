# Excavation 008 — terminal-resource precedence and observed effect

**Excavated:** 2026-07-10
**Sources:** SlopOS rev0760 and Foundry rev0103
**Construction question:** where should sequence exhaustion sit, and what may an
accepted result claim?

## Exact selected sources

Byte-identical review copies live under
`vault/searchable/precedence-effect-law/`; the local `SHA256SUMS` is authoritative
for this selection.

| Source | Bytes | SHA-256 | Pressure |
|---|---:|---|---|
| SlopOS `acp-denial-precedence-posture-v0.md` | 4,738 | `a03437f407719f0d3ad6892dcc4e9d8ccbd3bee1a36bf0357d13d6f7a42cac29` | deterministic first failure is part of stable semantics; a later precondition must not mask dead authority |
| SlopOS `acp-denial-precedence-fixtures-v0.md` | 8,180 | `870144da500b78796b6b8b681d45c399a99c882bff836455ac969d445c8978bc` | overlapping failures need explicit winner/loser cases rather than incidental branch order |
| SlopOS `acp-acceptance-completion-posture-v0.md` | 5,623 | `38cdce42cb5c396c15a3afc284eb895bf83e2f85c67b5232b29fc075733ebaad` | acceptance records one bounded effect, not downstream completion or current external truth |
| Foundry `rule-effect-binding-rulebook-v0.md` | 3,933 | `42616e94a6178127e80af363726121da9d7f567abb727e9d337a2611ab6a1f02` | selection/evaluation/checker success is not effect; effects need explicit binding |
| Foundry `specimen-flow-97...md` | 2,217 | `af464c16eae8189d8c3ed93839d113dd2e3fc578640a0d7748a7b3130368a743` | effect evidence must remain scoped and cannot become authority |

## Finding

The old SlopOS precedence rule was domain-specific, but its useful kernel-shaped
core survives: result precedence is semantic, not incidental control flow. The
terminal sequence condition is a late resource/admission fact. It should be tested
only after structural, existence/conflict, authority, ownership, and capacity facts
that already determine the operation's result.

Foundry supplies the complementary warning. Passing all guards is still not effect.
For K0, effect begins only when the committed state write and sequence advance occur.
`Status::ok` reports that bounded transition effect; it does not claim persistence,
platform realization, downstream execution, or current external truth.

Together these sources justify the exact Epoch Zero split:

```text
facts -> first failing status
all guards -> commit state effect + one sequence advance
result/trace -> observation of that transition, not new authority
```

## Promotion VPR-012

Only two laws enter the active cube:

1. **First-failure precedence is part of the transition contract.** A newly added
   late guard cannot overwrite an earlier valid rejection class.
2. **Acceptance denotes the committed local transition effect only.** A decision,
   generated guard success, test pass, trace, or receipt-like observation is not the
   effect itself and does not become authority.

The 25-case terminal witness is the first active application: it pins both the
winning earlier failures and the final exhaustion result, then checks actual state
before and after.

## Rejected imports

ACP lanes, approvals, policy windows, receipt schemas, losing-condition bundles,
rule-effect ledgers, effect witnesses, bypass fences, completion statuses, and
portable currentness services remain quarantined. They are valuable research
patterns, not K0 nouns.
