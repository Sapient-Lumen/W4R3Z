# Excavation 034 — host publication adapter and effect

## Question

What should the old SlopOS, ViewFS, and Foundry research contribute when the
new epoch first touches a real host mapping API?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/host-publication-adapter-effect-law/MANIFEST.tsv
```

It contains selected old SlopOS unsafe-boundary, memory-locality, backing,
initial-state, effect-contract, and effect-witness material; ViewFS host-adapter,
operation-catalog, and trace-reporting material; and Foundry rule/effect
pressure. The sources are lineage and adversarial requirements, not active
schemas or independent proof.

## Findings

### 1. Host mapping is not guest or physical publication

A host virtual mapping and copied bytes establish a local process observation.
They do not identify guest physical address, machine address, stage-2 table
entry, root, ownership domain, or processor-visible currentness.

### 2. Mapping success is not address authority

The kernel may return a page-aligned address for the selected request. The
adapter must still check extent and alignment. The numeric host pointer grants
no authority outside the returned mapping and has no correspondence to the
pure `0x40008000` identity.

### 3. Protection request is not effective architecture permission

A successful `mprotect` call is evidence that the host accepted one VMA
protection request. It does not prove stage-1/stage-2 R/X/non-W behavior,
absence of aliases, instruction-fetch permission, or durable W^X across a
machine.

### 4. Readback is not fetch visibility

Byte equality through a process load is narrower than D-cache publication,
I-cache visibility, translation stability, instruction fetch, decode, or
execution.

### 5. Cleanup receipt is not rollback

A successful `munmap` result is a bounded host observation. It does not prove
that all aliases, caches, logs, or downstream effects were reversed. A failed
cleanup must remain explicit and cannot be normalized into success.

### 6. Adapter trace is not effect authority

ViewFS's host-adapter and operation-catalog work reinforces that a compatibility
adapter needs explicit operation scope and trace reporting. The report describes
what the adapter attempted and observed; it does not grant permission or upgrade
an observation into another subsystem's effect.

### 7. Host conformance is not formal host semantics

Real tests, sanitizers, and manual-page review are useful counterexample
pressure. They do not establish C++, libc, syscall, or kernel operational
semantics.

### 8. Cross-layer evidence cannot discharge by resemblance

The Linux experiment resembles parts of a future AArch64 publication sequence.
Resemblance is not refinement. Its receipt is structurally prevented from
discharging the fourteen rev0794 machine premises.

## Promotions

This excavation promotes VPR-139 through VPR-146 only. No old host-adapter
schema, filesystem compatibility layer, operation catalog, trace format, effect
object, memory writer, loader, or boot mechanism is reactivated.
