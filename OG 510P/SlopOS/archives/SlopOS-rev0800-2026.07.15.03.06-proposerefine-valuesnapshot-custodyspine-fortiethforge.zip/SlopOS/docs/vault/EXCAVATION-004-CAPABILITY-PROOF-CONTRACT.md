# Excavation 004 — capability and proof contract

**Excavated:** 2026-07-10
**Source cube:** SlopOS rev0760
**Purpose:** constrain the first generated `DERIVE` body and the proof ladder

## Exact source set

The following byte-identical copies now live under
`vault/searchable/rev0760/foundation/`:

| Source | SHA-256 | Use in Epoch Zero |
|---|---|---|
| `docs/30-architecture/capability-semantics.md` | `14b1e5065cfc241bdb046ac33b8d9bbf757f20d164e02dc6c7d5aa2fab135bae` | no ambient authority; attenuation-only derivation; same object or explicit subobject; parent metadata |
| `docs/30-architecture/capability-rights-registry.md` | `26a2b408d3c300386155c6754f6a6f20bb337710de12a355fbf00f5368f5ac64` | monotone rights; boundary checks fail closed |
| `docs/30-architecture/abstract-machine.md` | `2026860787519f1ef58da7289a91e97711c2dc82b22887fc122580751e1df917` | capabilities, mapping authority, ownership, explicit transitions |
| `docs/20-assurance/unsafe-obligation-registry.md` | `4dbc694c11c14ea179cb9e6a08c3fa735169db0e202b0a97caddae9ac1862535` | low-level acts require named preconditions, preserved invariants, and evidence |
| `docs/20-assurance/tcb.md` | `12fb701e8e6d74988429880cd3868842078d50cdd94c37928e978f46460ebe82` | claim-specific TCB and narrow hypervisor/static-partition posture |
| `adrs/0002-phase1-static-partition-profile.md` | `472b5b7be739fe41b50443c7bb4e761f7e6e494ae16afd390f40f2dfdd8c74a0` | static partitions and minimal explicit channels remain the platform direction |
| `adrs/0004-config-as-compiled-artifact-and-generations.md` | `589642118272a8ad4dcf345833b26901f2867c69f01d414054492b3b58555372` | privileged core validates/applies compiled data; generation is explicit |
| `adrs/0007-verification-stack-and-first-mechanized-spec.md` | `03b3db7b4c2b8c81a15622a89de27d6fa5ad2df94930e506242c7c362311b372` | executable model and differential replay are lower evidence than theorem refinement |
| `crates/portal_net_model/src/lib.rs` | `311a7091398dcdb51208c55c69e847b8a18c0732d5d7703375f0da51df4b6d86` | total fail-closed transition style; denial/rejection without accepted commit |

The full selected inventory and hashes are in
`vault/searchable/rev0760/foundation/SHA256SUMS`.

## Rules promoted into the current DERIVE contract

1. **Possession is the authority premise.**  A request does not gain authority from
   identity, evidence, configuration prose, or successful validation elsewhere.
2. **Derivation is attenuation.**  Child rights are a subset of parent rights.
3. **Target continuity is explicit.**  Epoch Zero derives only the same object and
   copies the current generation.  Subobject derivation is not admitted.
4. **Lineage is recorded.**  The child names its parent slot.  This is evidence for
   future reasoning, not active revocation semantics.
5. **Failure is total and ordered.**  Every admitted input receives one exact status.
   Earlier structural failures dominate later authorization failures.
6. **Rejection is atomic.**  A rejected `DERIVE` leaves all authoritative state and
   the accepted-sequence counter unchanged.
7. **The privileged body is syntax-poor.**  Policy evaluation and rich configuration
   stay outside; the core executes checked finite data.

These rules produced the exact ten-guard KIR program and fixed successful commit
shape in rev0763.

## Rules deliberately not promoted

Rev0760 lists several revocation choices: none, object generations, membranes, and
derivation-tree revocation.  Epoch Zero carries `generation` and `parent` fields to
avoid a representation rewrite, but implements none of those revocation semantics.
In particular:

- no slot reuse;
- no generation bump;
- no stale-handle acceptance rule;
- no subtree walk;
- no claim that parent metadata makes revocation sound;
- no `REVOKE` command despite the reserved right bit.

The old broad proof slice also coupled portals, recovery, SMP, and network behavior.
Those remain quarantined.  The current proof root uses only the capability law that
survived contact with the tiny construction.

## Pressure on the next proof step

The old unsafe registry’s useful abstraction is retained in language-neutral form:
a privileged act must state preconditions, state footprint, preserved invariants,
and evidence.  For generated `DERIVE`, that becomes the split obligations for fact
extraction, commit shape, and compiler execution.  The next office should reduce one
of those obligations, not add another K0 operation.
