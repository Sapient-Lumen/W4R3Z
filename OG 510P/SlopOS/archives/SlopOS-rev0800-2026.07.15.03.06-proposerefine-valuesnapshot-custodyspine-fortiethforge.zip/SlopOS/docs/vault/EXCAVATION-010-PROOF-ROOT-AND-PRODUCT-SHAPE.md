# Excavation 010 — proof root and four-profile product shape

## Question

Does the predecessor vault require a different prover, a different product split,
or a wider first implementation than the new Epoch Zero course?

## Exact anchors

The following files were extracted unchanged from the sealed rev0760 archive into
`vault/searchable/rev0760/proof-product-shape/`.

| Anchor | SHA-256 | Finding |
|---|---|---|
| `adrs/0007-verification-stack-and-first-mechanized-spec.md` | `03b3db7b4c2b8c81a15622a89de27d6fa5ad2df94930e506242c7c362311b372` | wanted a proof-assistant root in the seL4/L4.verified style, but left the exact prover open and coupled the first path to unavailable Rust tooling |
| `docs/00-meta/charter.md` | `b642cb9b28e6ff9a2574c2ee97f15b6de9b940a7907607843cd1fa62ad669808` | seL4-class assurance, explicit abstract machine/refinement, minimized TCB, hypervisor-first candidate, explicit assumptions |
| `docs/00-meta/profile-claim-matrix.md` | `3df038a67a0d730b2fc87804a355990dce8952a109149f1614b4bbeab8f7ae2b` | A–D are claim bundles over one substrate, not forks; capability, isolation, state, boot, unsafe/trust, and fail-closed ABI are common |
| `docs/00-meta/profile-posture-matrix.md` | `532741fe89a96e330f2532afe72a0aa7ee652b4167f8e958fb716bf47c0580c7` | enormous profile surface demonstrates why the new core must refuse profile vocabulary until a mechanism is demanded |
| `docs/00-meta/roadmap.md` | `bc5018d0f976865c2de1a10ee7811da1c0895166f820c2e93feb32159fb7a9f6` | expected abstract spec, isolation prototype, selected verification path, then a meaningful mechanically proved slice |
| `docs/30-architecture/hypervisor-first-evaluation.md` | `8be5c633b3f55159ff0abf13391527adfbf691ca07762093b6ba2aec5be2655d` | hypervisor-first concentrates proof on second-stage translation, exits, interrupts, scheduling, and capability enforcement |
| `docs/30-architecture/multicore-architecture-options.md` | `a09d42c60a10cef2fe599fb5c73477f990cd033af5ffaac3d8243c60544e00e8` | multicore is eventually load-bearing but needs its own staged memory/concurrency proof, not inclusion in the first slice |
| `docs/40-verification/minimum-viable-proof-slice.md` | `1fd9e5d14fd603e06748674cf94ae586d3a0a10086aa2c5e39403f460e31fe88` | the old “minimum” combined too many kernel, portal, recovery, and SMP obligations; new Epoch Zero is right to split them |
| `docs/40-verification/tooling-landscape.md` | `d3a9b41fd789e33fd2e1568d248496eb473f97596f132a5eb09a7666a63e0b8a` | correctly separated bounded checks, differential testing, deductive tools, and ITP, but did not select one operational root |
| `docs/40-verification/verification-strategy.md` | `597cd0e89f90e244fab816158d8d5f2afb9dd287a7087751954a85a2ceb4fe33` | layered specification/refinement and model-check-fast posture should be retained after replacing Rust-specific machinery |
| `docs/60-engineering/phase1-profile-focus.md` | `46b5734424a7bbea291d6c6338fc28693a8d6770519d413ec89213bf838fceed` | cloud/agent micro-VM was the first product pressure; workstation remained north star; receipt progress was profile-level, not kernel proof |

The extracted set has its own `SHA256SUMS`; the sealed archive remains canonical.

## Findings

### 1. The vault supports one core and profile theorem bundles

The predecessor explicitly said the A–D matrix was not a fork. The new Epoch Zero
should preserve that architectural economy. The radical redesign is a reduction in
active mechanism and proof scope, not a retreat from the product family.

### 2. The vault supports Isabelle, but does not dictate it

The old ADR required a proof-assistant root following seL4/L4.verified and left the
actual assistant as a target. Current external evidence plus a successful local
installation and accepted session now justify selecting Isabelle/HOL. Rust-specific
Kani/Verus choices are historical research, not active gates.

### 3. The old minimum proof slice was not minimum

It combined capability integrity, memory isolation, multicore reasoning, portal
semantics, recovery, transcript evidence, and network mediation. That coupling
explains planning saturation. The new sequence—one transition schema, one explicit
representation relation, one atomic initial image, then one source-semantics edge—is
more faithful to the old goal of meaningful proof than the old checklist was.

### 4. Hypervisor-first remains a product-level candidate, not an Epoch Zero excuse

B and much of D benefit from a micro-hypervisor spine; C can use a static-partition
profile; A may place compatibility and risky workloads in VMs. But the first proof
work should not introduce VM exits, interrupt controllers, page tables, and SMP
simultaneously. One mapping primitive comes only after the source/refinement bridge
has a credible shape.

### 5. Multicore is deferred, not denied

The eventual product family cannot honestly ignore multicore. The vault correctly
identified memory ordering and concurrency as separate proof pressure. Epoch Zero
therefore keeps a sequential abstract/design/core baseline and plans a later
concurrent refinement layer rather than contaminating every current theorem with an
unsettled execution model.

## Promotions

This excavation promotes:

- **VPR-014 — One core, profile-specific theorem bundles; no product fork by
  vocabulary.**
- **VPR-015 — Select one operational theorem root; bounded and deductive tools keep
  non-overlapping evidence roles.**
- **VPR-016 — Hypervisor-first is future platform pressure; source/refinement closure
  precedes platform breadth.**

## Rejections

- Reject the old Rust-specific verification stack as active law because Rust cannot
  be economically executed here.
- Reject dual Isabelle/Lean roots in infancy.
- Reject the old “minimum” coupling of portal, recovery, SMP, and kernel isolation.
- Reject any inference that broad product ambition requires broad initial K0 code.
