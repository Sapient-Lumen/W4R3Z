# Excavation 009 — absence, slot metadata, and the frame boundary

**Excavated:** 2026-07-11
**Source surfaces:** SlopOS rev0760 abstract research and first Epoch Zero rev0761
**Purpose:** test the new CAP-REP law against earlier concrete design choices

## Question

Does the old vault support the rev0765 rule that payload in a dead capability cell
is inert, or did prior work rely on semantically meaningful data in an empty slot?

## Exact anchors reviewed

| Source | SHA-256 | Exact lines | Pressure |
|---|---|---:|---|
| `vault/searchable/rev0760/foundation/docs/30-architecture/abstract-machine.md` | `2026860787519f1ef58da7289a91e97711c2dc82b22887fc122580751e1df917` | 6–15, 28–35, 49–64 | capabilities are an abstract finite map; derivation is explicit; preservation is a separate theorem obligation |
| `vault/searchable/rev0760/foundation/docs/30-architecture/capability-semantics.md` | `14b1e5065cfc241bdb046ac33b8d9bbf757f20d164e02dc6c7d5aa2fab135bae` | 7–27, 54–61 | slot container shape is intentionally open; authority is target+rights+metadata; derivation preserves target and records lineage |
| `vault/searchable/rev0761/spec/initial-state.md` | `571a64ac0a7425d2b0f965a4bd97f45341906e6f194855e9c6cba566e046262b` | 12–37 | first Epoch Zero placed a generation on every slot and explicitly retained generation while the slot was empty |
| `vault/searchable/rev0761/spec/transition-system.md` | `93539a761ae68abf6016839fe5f23775e4c067443b194f9906639ff782f5a49d` | 3–22, 24–41 | total transition law; rejection frames canonical state; a capability reference includes expected slot generation; mint leaves the source unchanged |
| `vault/searchable/rev0761/spec/result-precedence.md` | `ed19f263e139283868009c7fc85577576d4967fe5d5dfa71e351d99cc2d997d4` | 1–17 | empty/stale and occupied states were distinct semantic results with fixed precedence |
| `vault/searchable/rev0761/include/slopos/k0/types.hpp` | `76610232ec66720c4b25d1df53b605ed08b6d931e4d4fde7d7e7a783fb1fa261` | 10–22, 95–114, 121–149 | generation lived in capability references and destination commands; object layout was explicitly not the wire format |
| `vault/searchable/rev0761/include/slopos/core/machine.hpp` | `43e37eb487dc92b9ac834ce05b5ff98ae3238b3575104c4fb7a46d420c3f41b7` | 20–32, 49–60 | each slot had generation plus occupancy beside capability payload; fixed storage alone did not define authority projection |
| `vault/searchable/rev0761/src/core/machine.cpp` | `eb5547990769980741e9e5bbe3a01b02404e3a9b87bb33360f7a38980d570164` | 32–88, 224–245, 269–303 | reset retained default slot generations, root install changed occupancy/payload, and snapshots emitted only occupied capabilities |
| `vault/searchable/rev0761/include/slopos/k0/snapshot.hpp` | `d20d3c9ef5356c5c4f2968453648d2692d941a3bb7d2a75e1c17351dffbbae36` | 12–25, 42–58 | canonical capability observations carried occupied entries and slot generation but not a twelve-cell absence image |
| `vault/searchable/rev0761/src/common/snapshot.cpp` | `e18a2fb0f264d23915564f81037622820ea5be89600c2f01445fa3b8c9649ad2` | 55–107 | canonical serialization iterated compact occupied capability entries; it erased the identity of untouched empty cells |
| `vault/searchable/rev0761/proof/isabelle/SlopOS_K0_Abstract.thy` | `9c834bd5d42be6103407b755dd79cc9035e7f79420cbc3c5988d6f96d51b5156` | 22–55 | old formal state used a partial capability map and did not relate it to concrete slot storage |

## Finding: the vault contains two different kinds of “empty”

The rev0760 abstract work supports presence-gated authority directly: `Caps` is a
finite partial map, and a capability is an authority record. An absent map entry is
not a weak or zero-right capability.

The first Epoch Zero rev0761 introduced a second concept: an **empty slot with live
slot-generation metadata**. That design used expected generations to detect stale
references before revocation and reuse existed. Its statement that empty slots
retain generation is not compatible with interpreting every field of the current
`Capability` record as inert whenever `live == false`—unless slot generation is
modeled separately from the absent capability.

This is not a reason to weaken CAP-REP. It is a reason to keep two semantic objects
separate:

```text
capability presence/value    optional authority record
slot lifecycle metadata      optional future allocation/reuse generation state
```

Rev0765 has no slot reuse, deletion, revocation, or stale-handle operation. Therefore
only the first object belongs in the active K0 relation. A future design may add
slot metadata, but it must not smuggle it in by retroactively declaring dead
capability payload authoritative.

## Snapshot finding: observation is not the representation relation

Rev0761's canonical snapshot surface, implemented by `snapshot()`, compacted
occupied capabilities into canonical entries and therefore did useful work for
model/core differential testing. It did not retain an
entry for each empty slot, and its serializer iterated only the compact count. That
means it cannot establish either of the two new CAP-REP facts that matter most:

- every formal index outside the twelve cells is absent;
- every concrete cell other than the destination is framed, including empty cells
  whose inert payload might differ.

The snapshot remains a behavioral observation surface. It is not imported as the
proof carrier. E0-P5 may compare bootstrap observations against an independent value
image while checker work proceeds whenever machinery exists, but it must not infer
the complete initial relation from compact snapshot equality alone.

## Frame consequence

The old transition law repeatedly made nonmutation explicit: rejection preserves the
canonical state; mint does not alter its source; accepted installation changes the
destination. Rev0765 sharpens this for the current representation:

- a successful DERIVE changes one capability presence/value entry;
- every other capability projection is equal;
- terminal rejection changes no capability cell or sequence;
- mutating payload inside an already-dead cell does not change the formal capability
  map, though it may change raw storage and therefore is not byte equality.

The last distinction matters. **Formal authority frame** is not automatically
**byte-for-byte object frame**. The active generated DERIVE happens to preserve the
whole C++ array on rejection and every nondestination C++ cell on success; the
finite witness checks that stronger source-value property. CAP-REP itself promises
only projected authority equality.

## Promotion and rejection

This excavation promotes **VPR-013 — absence cannot carry hidden lifecycle
authority**:

- dead capability payload is inert with respect to capability authority;
- any future live metadata for an empty slot must have a separate type and relation;
- absence, stale reference, and lifecycle generation must not be collapsed merely
  because one old prototype stored them together.

VPR-013 is narrower than importing the rev0761 slot model. It protects VPR-011 from
future semantic drift while leaving lifecycle machinery fenced out.

Rejected imports remain revocation, deletion, slot reuse, expected-generation
commands, per-domain CSpace topology, stale-handle results, and generation bumping.
They can return only after a concrete operation and proof obligation require them.

## Construction consequence

The active CAP-REP theory and C++ witness should retain dead-payload irrelevance.
Office review must reject any future change that reads holder, object, rights,
generation, or parent from a dead `Capability` to authorize an operation. If slot
lifecycle enters later, add a separate `SlotState`-like structure and an explicit
relation rather than weakening the presence law.
