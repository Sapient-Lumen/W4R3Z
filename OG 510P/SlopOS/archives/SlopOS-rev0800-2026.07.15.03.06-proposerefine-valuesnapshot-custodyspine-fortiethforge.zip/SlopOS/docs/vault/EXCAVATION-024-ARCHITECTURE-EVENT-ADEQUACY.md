# Excavation 024 — architecture event, instruction, and effect

## Question

What should the old cubes contribute while SlopOS crosses from a pure activation
intent protocol toward architecture-specific realization?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/architecture-event-adequacy-law/MANIFEST.tsv
```

It contains selected rev0760 material on unsafe obligations, proof layering,
page-table generation, boot identity, initial state, boot-chain provenance, and
effect-witness laundering, together with Foundry's runtime-evidence, rule/effect,
and effect-witness pressure.

The old material is genealogically related research, not independent proof and
not active machine authority.

## Findings

### 1. Source authority and semantic authority are distinct

An official architecture manual can constrain fields and instruction selection.
A citation, issue number, or copied paragraph is still not an operational
semantics accepted by Isabelle.

### 2. Event names are an intermediate language

The old cubes repeatedly distinguish request, validation, admission, effect,
and evidence.  Applied here:

```text
intent label
!= abstract architecture event
!= instruction class
!= instruction encoding
!= source or binary
!= privileged execution
!= completed effect
!= hardware observation
```

M0-P7 closes only the first relation.

### 3. Premise enumeration is not discharge

A complete list of assumptions is valuable because it prevents hidden ambient
facts.  It does not establish support, legality, currentness, or truth on a PE.

### 4. Sealed history is not current correctness

Rev0784's archive remains authentic lineage even though its selected HCR value
is no longer current.  The correction must preserve and reject the old tuple,
not erase it and not silently accept it.

### 5. Cold activation and live update are different proof objects

The selected certificate assumes no live prior stage-2 regime, no concurrent
observer, and no reused live VMID.  It cannot be generalized into break-before-
make or multicore update adequacy.

### 6. CPU translation remains narrower than device confinement

Even a future completed stage-2 CPU theorem says nothing by itself about DMA,
SMMU configuration, interrupt routing, passthrough, or device ownership.

## Promotions

This excavation promotes VPR-067 through VPR-072 only.  No historical schema,
workflow, parser, effect object, boot format, or architecture API is reactivated.
