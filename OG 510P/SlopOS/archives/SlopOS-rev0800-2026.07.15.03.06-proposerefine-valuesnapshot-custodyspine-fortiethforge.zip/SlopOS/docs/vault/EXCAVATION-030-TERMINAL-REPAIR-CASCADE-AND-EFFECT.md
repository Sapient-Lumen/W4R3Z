# Excavation 030 — terminal repair, generation coherence, and effect

## Question

What should the old cubes contribute when a selected semantic repair changes an
exact source/object/loader/visibility chain?

## Sources reread

The focused byte-preserved selection is bound by:

```text
vault/searchable/terminal-repair-cascade-law/MANIFEST.tsv
```

It includes old SlopOS material on unsafe obligations, effect contracts, boot
identity, initial state, proof layering, and effect-witness laundering, plus
Foundry rule/effect pressure. These sources are research lineage, not active
machine authority.

## Findings

### 1. A selected repair is not a completed repair

The rev0790 terminal contract selected `RET X30` and predicted the dependency
cascade. That selection did not alter source or object bytes. A new relation is
required to establish that the selected repair became current.

### 2. Generation coherence is an authority boundary

Each artifact can be valid in isolation while the composition is false:

```text
new source + old object
new object + old loader
new loader + old visibility
```

A close must reject these mixtures explicitly rather than relying on timestamps
or filenames.

### 3. Object extent stability is not object identity stability

The repaired ELF remains 560 bytes. Its content, section offsets, text size,
function size, digest, and semantic identity all change. Equal length is not
lineage or semantic equality.

### 4. A changed blocked reason is not readiness

The repaired fragment no longer falls through, so terminal control is present.
Readiness remains blocked because platform and live-register premises are
undischarged. More precise diagnosis is not authority growth.

### 5. Terminal bytes are not live return state

`RET X30` in a selected object does not establish a call edge, a valid X30, an
owned continuation, executable visibility, same-EL return permission, or
instruction execution.

### 6. A repair witness is not effect

A manifest, digest, theorem packet, differential test, or cold replay proves
only its named relation. None performs a physical load, branch, return, or boot.

## Promotions

This excavation promotes VPR-107 through VPR-114 only. No historical patch
workflow, loader, boot object, effect schema, or generalized artifact graph is
reactivated.
