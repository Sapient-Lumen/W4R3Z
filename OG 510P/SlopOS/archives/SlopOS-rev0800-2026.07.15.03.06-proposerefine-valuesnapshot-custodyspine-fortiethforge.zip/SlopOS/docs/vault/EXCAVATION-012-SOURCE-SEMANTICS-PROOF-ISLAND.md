# Excavation 012 — source semantics, proof islands, and compiler trust

## Questions

1. What did the predecessor cube already know about the implementation-refinement
   edge that should constrain rev0768?
2. Which parts of the old proof stack remain valid after C++20 replaced Rust?
3. Does old planning support a C mirror, a large proof dependency, or a smaller
   proof-facing source boundary?
4. Which eventual moonshot obligations should remain visible without entering K0?

## Exact sources read

A byte-preserved selection is in:

```text
vault/searchable/rev0760/source-semantics-proof-spine/
```

Its `SHA256SUMS` binds ten copied sources from the sealed rev0760 archive.

| Source | Finding retained |
|---|---|
| `adrs/0002-phase1-static-partition-profile.md` | one static two-domain profile is the right first closed-world platform pressure |
| `adrs/0007-verification-stack-and-first-mechanized-spec.md` | one theorem root, multiple evidence classes, and an executable reference model should coexist without collapsing claims |
| `docs/20-assurance/assurance-claims.md` | capability integrity, mapping discipline, unsafe confinement, initialization, and later SMP are distinct claim families |
| `docs/20-assurance/invariant-registry.md` | global capability and mapping invariants belong above implementation details and require transition preservation |
| `docs/20-assurance/proof-obligation-registry.md` | proof obligations need owners, assumptions, evidence maturity, and explicit next work |
| `docs/30-architecture/abstract-machine.md` | the abstract machine is an authority model, not an encoding or implementation layout |
| `docs/40-verification/layering-patterns.md` | differential testing, bounded checking, theorem proving, and refinement serve separate layers |
| `docs/40-verification/minimum-viable-proof-slice.md` | the old “minimum” coupled capability, isolation, unsafe, SMP, portal, recovery, and evidence work and was not actually minimum |
| `docs/40-verification/verification-strategy.md` | seL4-style refinement is the aspiration; bounded and deductive tools must not impersonate the theorem root |
| `rfcs/0061-bootstrappable-toolchains-and-ddc.md` | reproducibility and diverse compilation reduce supply-chain risk but do not prove compiler correctness |

## Findings

### 1. The old language choice was contingent; its proof separation was not

The Rust-specific Kani, Verus, and unsafe-registry choices do not govern the new
C++20 epoch. The enduring structure is:

```text
abstract invariant
  -> deterministic design
  -> admitted source semantics
  -> compiler/binary relation
  -> platform/configuration claim
```

Rev0768 therefore keeps the C++ source and compiler rows open instead of replacing
old Rust tool names with a fashionable C++ analyzer.

### 2. A proof island must remove a larger edge than it adds

The old stack already warned against equating tool presence with proof maturity.
AutoCorres2 can deliver excellent C semantics, but a C theorem plus an unproved C++
mirror adds a correspondence edge at exactly the point SlopOS needs to remove one.
A large dependency is justified only when its theorem reaches authoritative source.

### 3. The old minimum slice was planning saturation

The predecessor attempted capability integrity, mapping isolation, unsafe
confinement, multicore structure, network portals, receipts, recovery, and evidence
portability in one “minimum” milestone. Rev0768 instead narrows one cell projection:
absence, admission, rejection, exact field image, and dead-payload inertness.

### 4. Representation remains below authority semantics

The abstract machine and invariant registry do not select `std::array`, enum ABI,
padding, pointer identity, or a source language. The new scalar value kernel is
therefore an explicit lower-layer relation. It may be changed if source proof
pressure demands it without changing the abstract capability law.

### 5. Compiler trust cannot be laundered through source proof

The old DDC RFC correctly treats reproducibility and diverse compilation as
mitigation, not functional correctness. Even a future exact C++ source theorem
leaves compiler, link, binary, boot, and platform relations. Rev0768 names those
rather than promising that “verified C++” ends the ladder.

### 6. Static partition pressure remains later and valuable

A two-domain static appliance-like configuration is still the cleanest first
platform theorem. It does not justify beginning page tables while the source edge is
open. The scalar boundary is a prerequisite construction method, not product
retreat.

## Promotions

- **VPR-021 — A proof route earns admission only when it removes more named
  correspondence than it creates.** A C theorem does not close C++ without an exact
  bridge.
- **VPR-022 — Make authority-bearing source decisions small, total, canonical, and
  value-shaped before proving them.** The first instance is the capability scalar
  projection boundary.
- **VPR-023 — Source proof, compiler preservation, binary identity, boot, and
  platform realization remain distinct moonshot edges.** Reproducibility and DDC
  are later mitigations, not substitutes.
- **VPR-024 — A real layer-loss recovery is office evidence only when the sealed
  cube diagnoses absence, emits exact recovery, and freshly rechecks the theorem
  session.** Historical logs or a restored launcher alone do not suffice.

## Quarantine

- Rust-specific Kani/Verus gates and unsafe syntax as the current implementation
  boundary;
- the old coupled minimum proof slice;
- a hand-maintained C mirror of C++ product behavior;
- AutoCorres2 as an ordinary office dependency or automatic C++ claim;
- broad compiler bootstrapping, DDC, binary translation validation, SMP, mapping
  hardware, portal, agent, or profile machinery in the current K0 objective;
- any claim that a tiny scalar theorem proves `std::array`, compiler, ABI, binary,
  boot, DMA, or product isolation.
