# Excavation 028 — visibility, entry, terminal control, and effect

## Question

What should the old SlopOS and Foundry research contribute when the new epoch
tries to move from pure loaded bytes toward executable entry?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/executable-visibility-entry-effect-law/MANIFEST.tsv
```

It contains old boot, initial-state, memory-locality, unsafe-boundary,
layering, effect-contract, and Foundry rule/effect material. It is related
research and adversarial pressure, not independent proof or active cache/entry
authority.

## Findings

### 1. Readback is not publication

A pure array can contain exact bytes while no machine memory object exists.
Even physical readback would still require an observation and trust boundary.

### 2. Permission intent is not fetch authority

A numeric R/X/non-write value does not establish any effective translation,
MPU, VMA, page-table, or privilege state.

### 3. Maintenance intent is not visibility

A cache-maintenance label, selected instruction name, issued instruction,
completed instruction, and observed fetch visibility are different claims.

### 4. Assessment acceptance is not readiness

The old cubes repeatedly separate evidence intake from verdict and effect. M0-P11
applies the same law: a certificate can be accepted precisely because it
accurately reports that entry is blocked.

### 5. Entry record is not entry state

PC, EL, and register values in a record do not establish live registers,
PSTATE, stack, masks, exception routing, ownership, or authority to transfer
control.

### 6. Terminal control is part of the semantic contract

The current fragment ends with `ISB` and a zero fallthrough word. Calling it a
function or entry point without choosing return, branch, exception return, or
proved fallthrough semantics would launder an absent decision into execution.

### 7. Repair must start at meaning, not bytes

Appending `RET`, `BR`, `B`, or `ERET` merely to make disassembly look complete
would choose a calling/boot contract implicitly. The semantic role must be
selected first, then the instruction, source/object, loader, and proof ladder
must be regenerated honestly.

## Promotions

This excavation promotes VPR-091 through VPR-098 only. No old cache API,
loader, boot schema, entry mechanism, effect witness, or generic instruction
language is reactivated.
