# Excavation 026 — source, object, loader, and effect

## Question

What should old SlopOS and Foundry research contribute while the new epoch moves
from instruction values to one source/object specimen?

## Sources reread

The exact selected slice is bound by:

```text
vault/searchable/source-object-loader-effect-law/MANIFEST.tsv
```

It includes old proof-layering, unsafe-obligation, compiled-artifact,
boot-provenance, bootstrappable-toolchain, and Foundry rule/effect material.
The material is genealogically related research, not independent proof and not
active schema authority.

## Findings

### 1. Source bytes are not source semantics

Exact text identity prevents accidental drift but does not establish parsing,
macro expansion, directive meaning, instruction selection, or diagnostics.

### 2. An identified replay is not a general tool theorem

Reproducing one object with one exact Clang build is valuable conformance
evidence. It does not quantify over other source files, options, versions,
hosts, or assembler states.

### 3. Object identity is not loader placement

An ELF object, section address of zero, symbol value, alignment, or hash does not
select a destination, grant executable permission, establish lifetime, or
perform a copy.

### 4. Relocation absence is not loader correctness

Zero relocation records narrow the next edge. They do not prove section
placement, permission setup, instruction-cache visibility, entry-state
construction, or branch correctness.

### 5. Metadata is not execution authority

A global function symbol and executable section flag are descriptions. They do
not authorize execution or establish privilege, entry registers, stack,
exception state, or effect.

### 6. Execution remains narrower than completion

Even future execution evidence cannot silently become proof of register,
barrier, invalidation, translation, boot, or isolation effect.

## Promotions

This excavation promotes VPR-079 through VPR-084 only. No old build schema,
loader, compiler wrapper, binary-attestation object, or generalized effect
ledger becomes active implementation.
