# Excavation 017 — source-value semantics, correspondence debt, and layer loss

## Purpose

Rev0773 reopened the rev0760 source-semantics/proof-spine selection and the
rev0761–0772 active lineage while deciding whether the frozen proof companion could
receive an honest value-semantics theorem. The old vault does not dictate the new
epoch. It supplies pressure against repeating known category errors.

## Sources revisited

The searchable review surface included:

```text
vault/searchable/rev0760/source-semantics-proof-spine/
  docs/30-architecture/abstract-machine.md
  docs/40-verification/verification-strategy.md
  docs/40-verification/layering-patterns.md
  docs/40-verification/minimum-viable-proof-slice.md
  adrs/0007-verification-stack-and-first-mechanized-spec.md
  rfcs/0061-bootstrappable-toolchains-and-ddc.md

vault/searchable/rev0760/canonical-program-generated-source/
  docs/20-assurance/assurance-case.md
  docs/40-verification/verification-strategy.md
  docs/60-engineering/idl-digest-and-ordinal-policy.md
  rfcs/0011-idl-and-codegen-for-privileged-interfaces.md
  rfcs/0022-address-decoding-nets-and-page-table-gen.md

active Excavations 012–016
```

## Finding 1 — source proof and compiler trust are distinct

The old verification stack aimed at refinement while the toolchain/DDC material
separately treated compiler provenance and trusting-trust pressure. That separation
is sound. A theorem about a source-level value program cannot acquire compiler,
optimizer, linker, binary, or boot meaning from reproducibility or diverse compiler
agreement.

**Promotion:** the new value theorem ends at the normalized AST. Compiler
preservation remains a named later edge.

## Finding 2 — canonical structure outranks raw spelling, but does not interpret it

The old IDL and generated-artifact material preferred canonical representations over
raw text and required versioned generation/currentness. Rev0769–0772 correctly used
that idea for the seven-atom source program, exact exported bytes, finite certificate,
and proof companion.

But canonical structure can be wrong about source meaning. A parser-selected AST or
manually written AST is not made authoritative by having a digest or by agreeing
with another representation.

**Promotion:** the deep AST theorem is accepted only for its own closed definition.
Exact source-to-AST adequacy becomes `OBL-CAP-SCALAR-COMPANION-ADEQUACY-001`.

## Finding 3 — the smallest source island should expose raw result shape

The old abstract-machine nucleus sought a small precise refinement target. The
companion is useful because its result is a closed scalar aggregate with canonical
absent, rejected, and present images. Proving only the final scalar observation could
hide an incorrect raw aggregate behind a lossy decoder.

**Promotion:** prove exact raw companion projection first, then prove the separate
observation theorem.

## Finding 4 — implementation width is an assumption envelope, not a theorem shortcut

The companion uses `unsigned long` to avoid includes and project declarations. The
admitted proof carrier needs only 0…65535. This supports a small parameterized
premise, not an assumption that every ABI has one exact width or representation.

**Promotion:** Isabelle receives an explicit `max_ulong >= 65535` premise. The
C++20 harness separately asserts and reports that selected compilers satisfy the
envelope. The two facts remain differently classified.

## Finding 5 — standards review is design evidence, not checker evidence

The C++20 working draft identifies the intended rules for short-circuit operators,
conditional selection, aggregate initialization, scoped enumerations, and statement
execution. It helps expose omissions in a model. It does not show that the exact
source stream parses to the model or that every modeled rule is adequate.

**Promotion:** retain clause anchors in DEC-0026 and the proof document while keeping
source adequacy open.

## Finding 6 — a proof island must remove more edge than it imports

This is the enduring conclusion of Excavation 012. AutoCorres2 is excellent C
machinery, and BRiCk/cpp2v is serious modern C++ machinery, but either route would
introduce a mirror/cross-language edge or a second theorem root for this tiny target.
The direct Isabelle model closes the value rule set with less new permanent trust.

**Promotion:** one closed value-language theory is retained; no new prover,
general frontend, C mirror, or permanent non-C++ executable enters the cube.

## Finding 7 — cloudtainer loss is a normal adversary of office continuity

During rev0773 the cloudtainer discarded the unsealed worktree and the external
Isabelle installation. The exact rev0772 seal and uploaded installer remained
available. The office was reconstructed from the seal, the pinned layer was
recovered through the retained installer, and the complete current Isabelle session
was rerun before any theorem was promoted.

No pre-loss manual output, partial staging tree, or checkpoint became predecessor or
evidence.

**Promotion:** layer loss is now a repeated tested recovery scenario, not an
exceptional anecdote. The sealed cube plus external pinned toolchain identity must be
sufficient to reopen the office. Unsealed edits have no authority after loss until
reconstructed and replayed.

## Resulting law

```text
source bytes != normalized AST
normalized AST theorem != ISO-source adequacy
selected implementation envelope != universal language theorem
source theorem != compiler preservation
compiler preservation != booted platform effect
recovered tool executable != current theorem evidence
```

## What was not promoted

- a general C++ parser or formal semantics stack;
- a C mirror or AutoCorres2 dependency;
- a Rocq/Coq theorem root;
- compiler correctness from GCC/Clang agreement;
- ABI or object-layout claims from `unsigned long`;
- runtime authority for the proof companion;
- any new K0 operation or product-profile mechanism.
