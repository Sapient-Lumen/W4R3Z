# Excavation 032 — caller artifact, generation, and effect

## Question

What should the old SlopOS and Foundry research contribute when a projected
caller becomes current in one new pure-memory generation?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/caller-artifact-generation-effect-law/MANIFEST.tsv
```

It contains selected old unsafe-obligation, initial-state, effect-contract,
atomic-update, ordering-token, effect-witness, boot-provenance, memory-authority,
and Foundry rule/effect material. The sources are genealogically related design
pressure, not independent proof and not active executable schemas.

## Findings

### 1. Artifact currentness and machine currentness are different

The old effect-contract and boot-provenance material repeatedly separate an
accepted artifact from selected live effect. The generation-3 page value can be
exact while no processor can fetch it.

```text
current pure artifact
!= current machine memory
```

### 2. Generation is authority, not decoration

The old atomic-update work treats mixed basis as a first-class failure. A valid
rev0792 caller-edge contract, valid helper object, and valid caller object do not
compose when their loader generations disagree.

```text
individually valid values
+ mixed generation
= rejected construction
```

### 3. Atomic validation precedes mutation

The old initial-state and effect-witness material rejects partial authoritative
mutation during validation. The selected C++20 and HOL relations therefore
validate the complete preimage before producing one new immutable value.

### 4. Byte preservation is separately proved

An eight-byte insertion does not inherit a blanket frame theorem. Helper bytes,
the gap, the page suffix, and both guards are separately checked. A small patch
cannot silently rewrite its context.

### 5. Caller ownership does not arise from co-location

The caller and helper share one numeric value page. Co-location does not grant
the helper authority to claim that the caller was published, fetched, or
executed. The edge remains caller-local.

### 6. A produced object is not a call effect

Foundry’s rule/effect law applies directly:

```text
source selected
!= object produced
!= bytes installed
!= bytes visible
!= BL executed
!= X30 observed
!= RET completed
```

Each edge needs its own authority and evidence.

### 7. More precise denial is progress

The readiness moves from “projected caller artifact” to “machine publication and
visibility missing.” This is a narrower, more useful denial; it is not readiness
and must not be narrated as execution progress.

## Promotions

This excavation promotes VPR-123 through VPR-130 only. No old update manager,
boot record, generation service, ordering runtime, ELF loader, effect witness,
or generic control-flow schema is reactivated.
