# Excavation 007 — finite capability-map representation pressure

**Excavated:** 2026-07-10
**Source cube:** SlopOS rev0760 foundation selection
**Purpose:** constrain the next C++ array-to-Isabelle map relation without importing
old subsystems

## Question

After closing the explicit sequence-wrap source mismatch, what does the old vault
require of the relation between K0's fixed C++ capability array and the formal
`nat ⇒ capability option` map?

## Exact anchors reviewed

| Source | SHA-256 | Exact lines | Retained pressure |
|---|---|---:|---|
| `vault/searchable/rev0760/foundation/docs/30-architecture/abstract-machine.md` | `2026860787519f1ef58da7289a91e97711c2dc82b22887fc122580751e1df917` | 6–15, 28–35, 49–64 | capability state is a finite map; derivation is explicit; initialization and preservation are separate theorem steps |
| `vault/searchable/rev0760/foundation/docs/30-architecture/capability-semantics.md` | `14b1e5065cfc241bdb046ac33b8d9bbf757f20d164e02dc6c7d5aa2fab135bae` | 7–27, 54–61 | slots contain authority records; derivation preserves target/lineage and attenuates rights; dispatch is closed and fail-closed |
| `vault/searchable/rev0760/foundation/docs/20-assurance/invariant-registry.md` | `c3b5a8d2181d7995a8f2e872388ece41756d44a0983b83a62c432afa101afb7c` | 3–4, 11–12, 20–22 | object representation invariants and transition preservation must be visible in abstract, executable, and mechanized surfaces |
| `vault/searchable/rev0760/foundation/docs/20-assurance/proof-obligation-registry.md` | `258d59359a8b71bbb4857c39e51d988750a611e06bcb052336fd3d1652fee9c7` | 3–12, 20–28 | refinement gaps need identifiers, assumptions, evidence, and next closure work rather than thematic prose |
| `vault/searchable/rev0760/foundation/docs/20-assurance/tcb.md` | `12fb701e8e6d74988429880cd3868842078d50cdd94c37928e978f46460ebe82` | 1–18 | trusted mechanisms and excluded hardware/compiler boundaries remain explicit and claim-specific |
| `vault/searchable/rev0760/foundation/docs/20-assurance/unsafe-obligation-registry.md` | `4dbc694c11c14ea179cb9e6a08c3fa735169db0e202b0a97caddae9ac1862535` | 3–13 | each trusted operation needs explicit preconditions, preserved invariants, evidence, and bounded review scope |

## Finding

The old cube supplies a strong proof shape but **does not supply** a concrete
array-to-formal map encoding. Its abstract state deliberately says “finite map” and
leaves CSpace representation open. Therefore Epoch Zero must define the relation
itself rather than pretending that a C++ `std::array<Capability, 12>` is already the
formal map.

The narrow relation pressure is:

```text
CAP-REP(A, C) :=
  (∀ slot < 12.
     A[slot].live ⟷ (∃cap. C(slot) = Some cap ∧ cap = cap_of(A[slot])))
  ∧ (∀ slot ≥ 12. C(slot) = None)
```

`cap_of` may read holder, object, rights, generation, and parent only from a live
cell. When `live == false`, the remaining C++ fields are inert storage and must not
create a formal capability or authority edge. This presence-gating rule is the
critical bridge obligation.

For a live cell, the relation must additionally state:

- holder is nonzero and denotes an admitted domain;
- object kind/id denotes an admitted object;
- rights is a valid mask mapped to the corresponding formal set;
- generation is nonzero;
- parent is either `kNoCapSlot`/`None` or an in-range slot according to the admitted
  invariant;
- corresponding field values are equal under explicit finite-number conversions.

The relation must not mention C++ addresses, padding, object bytes, enum ABI, or
container layout. Those are compiler/ABI obligations, not formal authority values.

## Promoted rule

`VPR-011` promotes only **presence-gated representation**: inactive storage bytes or
default fields do not denote authority. A capability exists in the formal map iff
the admitted in-range C++ cell is live and related field-by-field.

## Rejected imports

This excavation does not promote CapNodes, CSpace trees, revocation, generation
bumping, slot reuse, move/copy operations, leases, subobjects, new rights, object
creation/deletion, thread objects, address spaces, interrupts, persistence, or old
unsafe-site implementations.

## Construction consequence

The next bounded objective should mechanize and executable-check `CAP-REP` for the
existing twelve-slot DERIVE surface before adding any operation. It should prove or
at least sharpen:

1. generated fact extraction reads exactly the related source/destination facts;
2. a successful generated commit changes exactly one previously absent map entry;
3. all other slots are framed;
4. terminal sequence rejection frames the entire array;
5. dead-cell payload fields are observationally and formally inert.

This is a bridge objective, not a request to generalize the machine.
