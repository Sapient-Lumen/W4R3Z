# Excavation 035 — emulator observation and platform truth

## Question

What should the old SlopOS and companion-cube work contribute when the new epoch
first executes a byte-pinned observer under an AArch64 system emulator?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/emulator-observation-platform-truth-law/MANIFEST.tsv
```

It contains selected old SlopOS platform, boot, initial-state, address-decoding,
microVM-memory, and effect-witness material, plus ViewFS host-adapter and
Foundry rule/effect pressure. The material is genealogically related research,
not independent confirmation and not active machine authority.

## Findings

### 1. Emulator identity is not emulator correctness

A byte-pinned executable, OCI manifest, machine name, CPU name, and command
remove ambiguity about what was run. They do not prove QEMU's implementation,
timing, architecture model, or host dependencies correct.

### 2. Emulator observation is not hardware observation

The old platform material repeatedly separates target assumptions from host
fixtures. A TCG register report is evidence about one exact emulator chamber.
It does not silently become evidence about silicon, firmware, a cloud VM, or an
embedded appliance.

### 3. EL2 presence is not stage-2 authority

Reading CurrentEL and an EL2 feature field does not authorize writes, prove
control-field legality, establish table publication, or show that the selected
stage-2 regime can become current.

### 4. Feature values are not premise discharge

The old initial-state and address-decode work warns against ambient facts. A
feature register value can help reject an incompatible profile. It does not by
itself discharge publication, permission, cache, entry, call/return, or
isolation premises.

### 5. Zero controls are not initialization or activation proof

Observed zero HCR_EL2, VTCR_EL2, and VTTBR_EL2 values say only that those exact
reads returned zero in the selected chamber. They do not prove reset history,
firmware behavior, other hidden state, authority, or readiness for mutation.

### 6. Generic-loader placement is not boot provenance

QEMU's loader puts the selected ELF into the chamber and associates it with CPU
zero. This is a useful bounded transport. It is not a firmware chain, measured
boot, secure boot, loader theorem, or complete initial-state construction.

### 7. Semihosting output is not product authority

The report and exit receipt are exact evidence artifacts. They do not become a
product console, trusted path, agent authority, user consent, or machine effect.

### 8. Single-PE TCG is not concurrency evidence

The chamber intentionally removes multicore and concurrent writers. No result
may be generalized to SMP, reused VMIDs, live update, device DMA, interrupt
routing, or side channels.

## Promotions

This excavation promotes VPR-147 through VPR-154 only. No old boot schema,
host-adapter API, effect witness, emulator abstraction, or generalized platform
model is reactivated.
