# Vault excavation 037 — office boundary, resumability, and proof currentness

## Finding

The old cubes are unusually rich in handoff material but demonstrate a failure mode:
resumability can turn into a second implementation made of prose, schemas, indexes,
checkers, and mirrored manifests. The archived SlopOS rev0760 cube alone contains
1,812 files: 944 Markdown files, 699 Python tools, 121 RFCs, and 144 fixture files.
Its largest changelog is over one megabyte; one test harness is nearly 800 kilobytes.
This scale preserves history but makes it difficult to know which statement is
current machine law.

The living rev0797 project repeated the pattern in C++: a roughly 5,773-line office
source embedded revision-specific truth. The result was internally contradictory
human/machine state and costly revision churn.

## Promoted correction

Resumability needs one typed spine, not exhaustive repetition:

- `revision.tsv`: exact lifecycle and subject;
- `read-order.tsv`: one contiguous cold-resume order;
- `decisions.tsv`: one active decision;
- `evidence.tsv`: observations bound to named subject tokens;
- `claims.tsv`: what is current/open/blocked/not claimed;
- `gates.tsv`: what closure requires;
- construction/custody manifests: exact recomputable identities.

Human documents explain these values but do not create parallel truth. Generic code
validates structure and semantics, not expected prose sentences.

## Proof currentness

Ward and the older SlopOS office repeatedly pressure the same law: a valid old proof
packet is still historical when source, generated inputs, theorem map, or toolchain
subject changes. Rev0798 therefore leaves Isabelle evidence `BLOCKED` rather than
copying rev0796 status. A source-level hole scan is useful hygiene but not theorem
execution.

## Archive recursion

Evidence and final ZIP bytes cannot both be part of the subject they describe without
recursive instability. The correction is layered identity: active construction,
vault custody, evidence objects, and external archive digest. A closure receipt can
name the first two while remaining honest that it does not authenticate its own final
container.

## Long-term cleanup

Over time, old repeated objects can be stored once by digest and referenced from
self-contained periodic recovery bundles. That work is deferred until the current
subject and proof gates close; building a content-addressed archive platform now would
repeat the infrastructure-first failure.
