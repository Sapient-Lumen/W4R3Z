# Vault promotions — rev0800

Promotions are narrow living laws with exact anchors. They are never wholesale code,
schema, registry, or directory imports.

## Standing promotions

1. **Effect binding:** proposals, selected rules, receipts, observations, and checker
   success are not committed effects without a distinct admitted effect transition.
2. **Veto-only narrowing:** policy and automation may deny or attenuate; they do not
   mint ambient authority.
3. **Lease attenuation:** subject, resource, action, magnitude, validity interval,
   use count, and withdrawal are explicit at use.
4. **No-resurrection debt:** future generation/epoch revocation must state wrap,
   object reuse, persistence, stale references, and reclamation.
5. **Evidence currentness:** evidence binds an exact subject; predecessor evidence
   becomes historical after construction changes.
6. **Content identity boundary:** digests identify bytes but do not supply approval,
   provenance, execution, proof, or release authority.
7. **Reliance fence:** reliance on an observer does not make that observer the source
   of authority.

## Rev0799 promotions retained

- proper-descendant revocation targeting as design pressure;
- capability identity shaped as `(slot, generation)` before reuse;
- dependent mappings naming exact authority references;
- historical-message preservation rather than retroactive deletion;
- whole-snapshot denial framing;
- separation of withdrawal, invalidation, quiescence, reclamation, recall, and
  evidence supersession; and
- explicit active/full build authority.

None of these is promoted as a current canonical implementation or mechanized proof.

## Rev0800 promotions

From rev0761 snapshot and architecture material:

- core and reference may share command declarations, constants, and canonical
  observation structures, but not transition functions, authority checks, mutation
  helpers, or invariant implementations;
- a canonical value image is useful only when its abstraction/refinement relation is
  separately stated; digest/rendering is downstream;
- result precedence is semantic whenever multiple faults can coexist; and
- denied transitions frame the selected authoritative observation exactly.

From rev0769 emitter material:

- byte-current generated C++ and Isabelle artifacts can remove accidental drift, but
  do not establish C++ abstract-machine or compiler semantics;
- a source bridge should be admitted only when it closes more trust than its parser,
  binder, and generator add.

From the current construction:

- one shared `AuthorityValueSnapshot` is admitted as a declaration-level observation
  type;
- core, reference, and PROPOSE checker independently populate/transform it;
- the checker is downstream from authority and cannot become a production admission
  dependency; and
- terminal values may be reached by private test seams without widening production
  mutation authority.
