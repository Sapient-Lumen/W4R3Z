# Vault source anchors — rev0798 excavation

Preserved archive digests are recorded in `vault/source-archives/SHA256SUMS` and the
current custody manifest. Selected conceptual anchors:

- SlopOS rev0760: `rfcs/0013-deterministic-record-replay-boundary.md`
- SlopOS rev0760: `rfcs/0019-revocation-epochs-and-indirection.md`
- SlopOS rev0760: `rfcs/0028-veto-only-policy-bundles-for-automation.md`
- SlopOS rev0760: `rfcs/0030-artifact-references-and-content-addressed-evidence.md`
- SlopOS rev0760: `rfcs/0054-authority-diffs-and-consent-receipts.md`
- SlopOS rev0760: `rfcs/0066-capability-leases-and-limited-use-proxies.md`
- SlopOS rev0760: `rfcs/0069-capability-diffs-for-consent-and-receipts.md`
- Foundry rev0103: `docs/30-architecture/rule-effect-binding-rulebook-v0.md`
- Foundry rev0103: `docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md`
- Harbor rev0111: response/reliance event material under `docs/30-architecture/`
- Ward rev0099: verification intake and proof-drift material under `docs/`
- Steward rev0201: dependency-gate and narrowing material under `docs/`
- Schell rev0270: release-delta, drift-review, and reliance-fence material under
  `docs/80-terminal/`

Paths above are anchors inside preserved ZIPs and do not make those files active
construction.

## Rev0799 source anchors

- Canonical rev0798 archive SHA-256: `0c578545f56fc6e7367e888040aacd00b35fe371d1c6919c3e04d716aa4165b9`
- Alternate rev0798 archive SHA-256: `0df20b40358d44770576607ea05f77fee9b2866eb24ee34748495f882a2a4af0`
- Alternate design anchors:
  `living/epoch-zero/docs/AUTHORITY-AND-REVOCATION.md`,
  `ADR-0003-revoke-proper-descendant-subtree.md`,
  `ADR-0004-generation-qualified-capability-identity.md`,
  `ADR-0005-preserve-accepted-messages.md`, and
  `proof/REVOCATION-LAWS.md`.
- Immutable vault measurements:
  `evidence/rev0799/vault-archive-inventory.tsv`,
  `vault-overlap.tsv`, and `vault-scan-summary.tsv`.
- Online primary sources:
  `evidence/rev0799/research-sources.tsv` and
  `docs/research/REVOCATION-RECLAMATION-PATH-SAFETY-SOURCES.md`.

## Rev0800 representation-spine anchors

- `vault/searchable/rev0761/include/slopos/k0/snapshot.hpp`
- `vault/searchable/rev0761/src/common/snapshot.cpp`
- `vault/searchable/rev0761/docs/decisions/0003-independent-model-core-and-oracle.md`
- `vault/searchable/rev0761/docs/proof-architecture.md`
- `vault/searchable/rev0761/spec/result-precedence.md`
- `vault/searchable/rev0761/spec/transition-system.md`
- `vault/searchable/rev0769-alternate-program-emitter/docs/proof/CAP-SCALAR0-SOURCE-BRIDGE.md`
- `docs/vault/EXCAVATION-039-REPRESENTATION-SPINE-AND-CUSTODY-PACKAGING.md`
- `evidence/rev0800/research-sources.tsv`
- `evidence/rev0800/vault-scan-summary.tsv`

These anchors support law-level promotion only. The old implementations and source
archives remain custody.
