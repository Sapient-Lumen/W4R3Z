# Excavation 039 — representation spine and custody packaging

## Sources examined

Living review copies were read from the preserved vault, including:

- `vault/searchable/rev0761/include/slopos/k0/snapshot.hpp`;
- `vault/searchable/rev0761/src/common/snapshot.cpp`;
- `vault/searchable/rev0761/docs/decisions/0003-independent-model-core-and-oracle.md`;
- `vault/searchable/rev0761/docs/proof-architecture.md`;
- `vault/searchable/rev0761/spec/result-precedence.md`;
- `vault/searchable/rev0761/spec/transition-system.md`;
- the rev0760 source-semantics/proof-evidence selections; and
- `vault/searchable/rev0769-alternate-program-emitter/docs/proof/CAP-SCALAR0-SOURCE-BRIDGE.md`.

These are continuity evidence from SlopOS ancestry, not independent validation.

## Recovered heart

Rev0761 had already found three durable laws:

1. the constrained core and readable model may share commands and canonical
   observation values, but not transition/authority checks;
2. result precedence is part of semantics, not diagnostic presentation; and
3. every denied transition must preserve the complete canonical state.

Those laws are promoted. The old `Snapshot` implementation itself is not copied. It
combined canonical values, textual rendering, and an FNV diagnostic digest, but did
not define a proof-facing relation or source-semantics bridge. Rev0800 rebuilds only
the smaller P0 snapshot needed now.

## Proof-sprawl finding

Rev0760's verification/evidence registries were rich but extremely broad: hundreds of
future placeholders, evidence tokens, reverse links, and profile surfaces surrounded
a small number of high-maturity obligations. That machinery made navigation look
like assurance progress while leaving the implementation bridge open.

The correction is not to discard ledgers. It is to keep one row per live obligation,
one exact evidence subject, and one explicit exclusion. A new generator, proof DSL,
or registry family is inadmissible merely to avoid writing a small relation by hand.

## Generator warning

The rev0769 alternate emitter is unusually honest: generated C++ and Isabelle from a
closed guard program removed one drift edge but did not establish C++ abstract-machine
meaning, compiler preservation, ABI behavior, or platform effect. Rev0800 therefore
does not introduce a PROPOSE DSL. The concrete body is small enough to freeze and
inspect directly.

## Severe waste corrected

Before rev0800, `canonical()` reconstructed and rendered semantic order separately in
both implementations. Text was simultaneously a test oracle, representation
boundary, and diagnostic. The typed snapshot now owns canonical order; rendering is
a downstream view. This removes duplicated semantic sorting and lets mutation tests
address exact fields instead of parsing prose.

## Custody packaging pressure

The eight immutable source archives contain substantial exact payload duplication,
but their original container bytes and member paths are lineage. In-place dedupe
would trade recoverable history for ambiguous storage savings.

A future derivative **custody recovery pack** may be worthwhile, but only with all of
these properties:

1. every original ZIP remains present or independently recoverable by its external
   SHA-256;
2. every original member path, type, mode/time metadata, compression metadata,
   uncompressed extent, CRC, and payload digest is recorded;
3. content-addressed payload blobs use a cryptographic digest and explicit format
   version/domain separation;
4. an old-container-to-blob map is total and reversible;
5. rematerialization is checked against the original container digest, not only
   member payloads;
6. the pack is a new custody object, never a silent replacement for the old archive;
7. partial corruption and missing blobs fail closed; and
8. the living project consumes only source anchors/indexes, never ambient authority
   from the pack.

No such pack is constructed in rev0800. The safe correction over time is to design a
small offline verifier and test it against copies, then obtain an explicit custody
migration decision. Storage pressure alone is not authority to rewrite history.

## Quarantine retained

- wholesale rev0761 core/snapshot import;
- rev0760 proof/evidence registry families;
- a generated PROPOSE language;
- FNV fingerprints presented as cryptographic identity;
- canonical text presented as a representation theorem; and
- vault deduplication or recompression in place.
