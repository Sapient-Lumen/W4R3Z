# Excavation 003 — Proof and implementation pressure from the predecessor

This pass was constrained to documents that can change the Epoch Zero proof root.
Exact searchable paths and hashes are recorded in `SOURCE-ANCHORS.md`.

## Promoted pressure

The predecessor convergence policy (`vault/searchable/rev0761/vault/selected/rev0760/docs/00-meta/convergence-policy.md`) already recognized
that repeated boundary variants should eventually become generators, executable
models, proofs, or implementations, and that low-level archive consistency is not a
substitute for stronger evidence.  Epoch Zero turns that into a hard admission rule:
new prose must attach to a build, trace, theorem, counterexample, or explicit debt.

The dashboard (`vault/searchable/rev0761/vault/selected/rev0760/docs/00-meta/datacube-dashboard.md`) made the evidence imbalance visible.
That diagnosis is retained, but the old maturity-scale machinery is replaced by the
smaller active claim taxonomy.  The point is to move evidence, not preserve every
label.

The verification ADR (`NOT FOUND`) is valuable as a record
of proof ambition and unsafe-boundary discipline.  Its Rust-specific gates are not
active law.  The enduring requirement is an implementation-language semantics edge,
which now appears as I0/KIR-0 and `OBL-CPP-SEM-001`.

The old abstract machine (`vault/searchable/rev0761/vault/selected/rev0760/docs/30-architecture/abstract-machine.md`) remains a useful semantic seed,
but it was too informal to be the theorem root.  Epoch Zero narrows it to explicit
state, total commands, exact denial behavior, and fixed capacities represented in
C++20 and Isabelle.

## Quarantined coupling

The minimum viable proof slice (`vault/searchable/rev0761/vault/selected/rev0760/docs/40-verification/minimum-viable-proof-slice.md`) combined
capability integrity, memory isolation, unsafe confinement, SMP reasoning,
commutativity, and a large network-portal corpus.  Epoch Zero rejects that bundle as
“minimum.”  DERIVE and one MAP path are enough to expose the C++ semantics problem.

The portal network model (`NOT FOUND`) remains good service-level
research on request identity, replay, denial, and recovery.  It does not exercise
page tables, traps, or privileged isolation, and therefore remains P0 Runtime
research rather than evidence for K0.

## New conclusion

The predecessor's most important contribution to the proof effort is not a ready
specification.  It is a set of distinctions that stop evidence, configuration,
replay, and intended effect from silently becoming authority.  The compiled
bootstrap plan and denial-atomic transition law are the smallest active embodiment
of those distinctions.
