# Excavation 025 — instruction realization, source, and effect

## Question

What can the old SlopOS and Foundry material contribute while M0 crosses from
abstract architecture events to exact instruction-value candidates?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/instruction-realization-effect-law/MANIFEST.tsv
```

It includes old unsafe-obligation, effect-contract, boot-manifest,
effect-witness-laundering, address-decoding/page-table, and Foundry rule/effect
material. These are pressure and lineage, not independent proof.

## Findings

### 1. Instruction selection is not execution authority

An instruction class and operand can be a useful finite design commitment.
Neither a mnemonic nor a 32-bit word authorizes or performs privileged effect.

```text
abstract event
!= instruction class
!= instruction word
!= source
!= object
!= loaded bytes
!= live register entry
!= execution
!= completion
!= observation
```

M0-P8 closes only the finite event-to-value relation.

### 2. Register-entry values are separate input state

The old initial-state and effect-contract work repeatedly warns against ambient
preconditions. An `MSR ..., Xn` candidate must name the value expected in Xn.
That value is still not evidence that Xn actually contains it.

### 3. A selected word is not an assembler theorem

The old proof-layering material distinguishes generated artifacts from compiler
and binary claims. The same law applies to assembly: a selected natural value
can be checked exactly without asserting that a particular source spelling,
assembler version, ELF object, relocation model, or loader produces it.

### 4. A witness does not become effect

Foundry's rule/effect and effect-witness work remains directly relevant.
Reference/core agreement, a wire digest, an accepted certificate, a proof
packet, and an object identity establish their exact propositions only.

### 5. Completion is not inferred from issue

Even a future executable instruction specimen cannot infer that DSB, ISB, TLBI,
or system-register effects completed merely because an instruction was fetched
or retired. Architecture completion and observation require their own semantics
and premises.

### 6. Cold-start scope remains closed

The selected sequence is still bound to the single-PE, no-live-stage-2,
no-concurrent-writer, no-DMA-mutation envelope of M0-P7. It is not a live-update
or multicore sequence.

## Promotions

This excavation promotes VPR-073 through VPR-078 only. No historical schema,
effect object, loader, assembler wrapper, inline-assembly mechanism, or generic
instruction language is reactivated.
