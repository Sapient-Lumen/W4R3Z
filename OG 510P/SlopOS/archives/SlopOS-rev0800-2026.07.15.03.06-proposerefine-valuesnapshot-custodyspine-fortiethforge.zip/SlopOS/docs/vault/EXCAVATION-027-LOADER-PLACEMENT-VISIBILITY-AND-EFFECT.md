# Excavation 027 — loader placement, visibility, and effect

## Question

What should old SlopOS and Foundry research contribute while the new epoch moves
from one exact object specimen to a pure loader-placement value?

## Sources reread

The byte-preserved selection is bound by:

```text
vault/searchable/loader-placement-visibility-effect-law/MANIFEST.tsv
```

It includes old boot-manifest, boot-provenance, initial-state, memory-locality,
effect-contract, layering, and Foundry rule/effect material. The material is
related research and adversarial pressure, not independent proof and not active
loader authority.

## Findings

### 1. Numeric destination is not address authority

Alignment and arithmetic non-overlap make a placement value checkable. They do
not establish that an address exists, is owned, is writable, has a lifetime, or
refers to the intended memory object.

### 2. Permission intent is not installed permission

A read/execute/non-write value is useful design input. It is not a page-table,
MPU, host-VMA, stage-1, or stage-2 update and cannot authorize instruction fetch.

### 3. Copied bytes are not executable visibility

Exact readback from a pure byte array establishes only that array relation. It
does not establish D-cache publication, I-cache invalidation, instruction-fetch
coherence, or observation by a PE.

### 4. Visibility is not entry state

Even coherent executable bytes do not establish a branch target, exception
level, stack, live registers, masks, vector state, or control-register state.

### 5. Entry state is not execution or completion

A complete entry-state description still does not prove fetch, decode,
retirement, synchronization completion, architecture effect, or isolation.

### 6. Receipts and readback remain bounded evidence

Foundry's rule/effect work again rejects laundering an accepted request, digest,
copy receipt, readback, or theorem into machine effect. Every artifact carries
only its exact proposition.

## Promotions

This excavation promotes VPR-085 through VPR-090 only. No old loader, boot
schema, effect object, memory-backing API, executable-mapping mechanism, or
permission language becomes active implementation.
