# Excavation 038 — revocation, reclamation, and build authority

## Sources examined

- Canonical `SlopOS-rev0798-2026.07.15.00.47-epochzeroclosure-officev2-attenuatedauthority-thirtyeighthforge.zip` (`0c578545f56fc6e7367e888040aacd00b35fe371d1c6919c3e04d716aa4165b9`).
- Alternate `SlopOS-rev0798-2026.07.15.04.30-epochzeroclosure-revocationproof-officev2-thirtyeighthforge.zip` (`0df20b40358d44770576607ea05f77fee9b2866eb24ee34748495f882a2a4af0`), especially its
  `living/epoch-zero/` K0 revocation chamber.
- Eight preserved source ZIPs under `vault/source-archives/`.
- Current primary sources recorded in `evidence/rev0799/research-sources.tsv`.

## Promoted concepts

The alternate chamber correctly pressures four missing concepts:

- capability identity should be `(slot, generation)`, not a naked numeric slot;
- subtree revocation should target a current proper descendant and preserve siblings;
- dependent mappings should name the exact authority reference that admitted them;
- accepted messages/evidence should survive withdrawal and keep the historical
  generation they named.

These are promoted as design obligations, not copied as canonical implementation or
proof. Its second living root is quarantined.

## Six revocation clocks

| Clock | Question | Rev0799 status |
|---|---|---|
| Future-use withdrawal | Can this authority admit a later transition? | Implemented for one lease. |
| Dependent-state invalidation | Which current state exists only because of it? | Open. |
| In-flight cancellation/quiescence | What already admitted work can still complete? | Open. |
| Storage/identifier reclamation | When may slots, objects, or memory be reused? | Open; no reuse. |
| External recall | Can effects/copies outside the machine be recovered? | Generally impossible without protocol; open. |
| Evidence supersession | How is an accepted fact made obsolete without erasure? | Open. |

The clocks must not be collapsed. A future-use denial does not reclaim storage; a
reclaimed slot does not prove stale references are impossible; deleting a record
would destroy truthful history rather than supersede it.

## Vault measurement

The immutable scan found 8 archives, 36,940,652 ZIP bytes, 9,711 regular members,
91,595,299 uncompressed payload bytes, 7,989 unique SHA-256 payloads, 1,455 duplicate
groups, and 1,722 duplicate occurrences beyond first. There were zero unsafe path
members and zero mismatches against `SHA256SUMS`.

The largest cross-archive overlap is 1,392 exact payload hashes between the old
SlopOS and ViewFS cubes. This may indicate copying, common generation, or shared
inputs; bytes alone do not establish authorship, chronology, authority, or semantic
equivalence.

## Correction over time

Do not rewrite source ZIPs. Build digest catalogs and source-anchor indexes outside
custody. A later content-addressed vault envelope is acceptable only if it stores the
original container digest, every member path/metadata/payload digest, and a reversible
old-to-new mapping. Until then, duplicated bytes are a known custody cost.

## Build authority finding

The canonical build graph allowed paused research to demand tools and work from every
session. Moving it behind explicit opt-in is conceptually the same kind of authority
attenuation as the runtime specimen: an available historical target is not permission
for it to control the default office.
