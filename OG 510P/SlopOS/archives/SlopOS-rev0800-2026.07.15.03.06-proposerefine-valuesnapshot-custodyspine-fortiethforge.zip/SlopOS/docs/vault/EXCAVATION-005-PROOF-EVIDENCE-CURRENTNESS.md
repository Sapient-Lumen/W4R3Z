# Excavation 005 — proof evidence, reviewed basis, and currentness

## Question

What must survive from the old SlopOS and companion cubes so that generated proof
artifacts and future theorem logs cannot be mistaken for current authority or
closure after the construction changes?

## Exact sources reviewed

| Source | Searchable copy | SHA-256 |
|---|---|---|
| rev0760 assurance levels | `vault/searchable/rev0760/evidence-law/docs/20-assurance/assurance-claims.md` | `221c92dfa32cefd276cd430224c39f78283b47aee061a161be52c3e8faa8bdc1` |
| rev0760 canonical non-claims | `vault/searchable/rev0760/evidence-law/docs/20-assurance/non-claims.md` | `90d091bb71bdb5c9e85f7c18f0cb3758a548ef4e5db65c164be05c193452f181` |
| rev0760 proof/evidence join | `vault/searchable/rev0760/evidence-law/docs/20-assurance/proof-evidence-manifest-v0.md` | `ddde9b60cfc68e0ef51a70d4d01d0551e38e51a70614147d33160e3ff8a42c8f` |
| rev0760 proof-import rebinding | `vault/searchable/rev0760/evidence-law/docs/40-verification/proof-import-rebind-fixtures-v0.md` | `769a63b6a341763c111ff40f6bfb20941088d5c50a337140f9449c63ab2e904b` |
| rev0760 convergence policy | `vault/searchable/rev0760/evidence-law/docs/00-meta/convergence-policy.md` | `22c7d9c7dc0910e1da825a13ebb70a6c2e1373c5042d8775e46de91cb2e2ee4e` |
| Helm reviewed-basis drift ADR | `vault/searchable/companions/helm/adrs/0017-reviewed-basis-drift-requires-fresh-review.md` | `ed9ccea28adf91a478c8be4c8d3a6aaadc9e41097703785659fa3be3cbbb9848` |
| Helm proof-portability boundary | `vault/searchable/companions/helm/adrs/0060-audit-export-before-proof-portability-runtime.md` | `73458debc9f12dd48b058a273f14955b29da3ca8ff28fd8964d53ffa1f6024af` |
| Ward proof-drift architecture | `vault/searchable/companions/ward/docs/30-architecture/verification-intake-proof-drift-guards-and-metadata-lineage-audit.md` | `5f0a6648db60e09fd5d4fc6d9f198b014fc2ef1f89663aba1470f72a30920081` |
| Ward verification-intake threats | `vault/searchable/companions/ward/docs/10-threat-model/verification-intake-threat-model.md` | `68707962bc80caca13d5773f3662fff5096016ce793664fa03b3c06b3c75ec8f` |

The original ZIPs remain byte-preserved under `vault/source-archives/`; searchable
copies are exact review surfaces with local checksum inventories.

## Findings

### 1. Evidence maturity must not collapse

The old cube distinguished engineering evidence, bounded/model evidence, checked
refinement, and stronger security properties.  Its proof/evidence manifest also
said explicitly that an E0 join or drift gate does not become mechanized proof.
Epoch Zero keeps a smaller taxonomy, but the anti-collapse rule is load-bearing.

### 2. Proof support is an exact edge, not a thematic mention

The old manifest distinguished evidence actually named by an obligation from broad
reverse links.  Epoch Zero should likewise require an obligation row to identify
its exact theorem, log, bounded domain, or corpus.  A nearby proof document is not
support by association.

### 3. Reviewed-basis drift invalidates currentness

Helm's sharp rule is directly applicable: a strong action based on reviewed mutable
state cannot silently follow a newer basis.  For SlopOS, a theorem or test result is
a strong claim action.  Source, theory, generated data, compiler envelope, or claim
changes require fresh review and replay.

### 4. Portable proof remains evidence only

Helm and Ward both reject the inference from exported or verified proof to current
truth, action authority, remedy completion, or quarantine clearance.  In this repo,
a proof log can support a precisely scoped formal claim; it cannot by itself prove
the active C++ executable, authorize a transition, or close a different obligation.

### 5. Convergence means machinery, not suffix growth

The old convergence policy correctly stopped repeated document/corpus variants once
a generator, model, or proof obligation could express the pattern.  Rev0763 applies
that lesson by replacing competing DERIVE transcriptions with one generator and by
adding executable finite witnesses rather than another bridge essay alone.

## Promotions

- `VPR-008`: proof evidence is scoped and non-authoritative.
- `VPR-009`: evidence currentness is bound to an exact reviewed construction basis.
- DEC-0010 implements both through the C++20 construction-basis manifest and close
  audit.

## Rejected imports

Epoch Zero does not import the old evidence-ID universe, proof-export runtime,
retention object model, verification receipt taxonomy, quarantine workflow, or
status-pointer machinery.  Their shared law is promoted; their domain schemas stay
quarantined.
