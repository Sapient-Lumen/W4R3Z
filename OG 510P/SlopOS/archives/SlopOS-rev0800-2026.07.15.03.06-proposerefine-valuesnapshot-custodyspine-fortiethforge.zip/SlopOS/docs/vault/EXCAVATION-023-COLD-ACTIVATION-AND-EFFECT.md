# Excavation 023 — cold activation, currentness, and effect

## Why this excavation exists

M0-P6 is the first new-epoch construction whose labels resemble privileged
architecture actions.  That resemblance creates a severe laundering hazard:
a proven order over names such as `SELECT_ROOT_VALUE`, `INVALIDATE`, and
`ENABLE_STAGE2` can be misread as proof that instructions executed or hardware
state changed.

The old SlopOS vault and the Foundry effect materials were reread for exactly
this boundary.

## Recovered pressure

### Page-table update obligation

The old `U-1002` obligation required exclusive mapping-object ownership, no
mutable alias, and a defined TLB protocol.  The obligation did not permit a
page-table helper name or successful return value to stand in for those
premises.

### Initial-state and boot manifests

Old boot and initialization material separated a declared artifact, an
installation obligation, selected current state, and evidence that a runtime
matched it.  A manifest was never itself the machine state.

### Effect contracts and witnesses

Foundry repeatedly distinguished:

```text
selected rule
!= admitted application
!= effect attempt
!= committed effect
!= observed current consequence
```

A receipt or witness could describe an edge without creating that edge.

## Promoted laws

```text
installed pure bytes
!= published table memory
!= selected root value
!= register write
!= synchronization completion
!= TLB invalidation completion
!= stage-2 enable effect
!= observed hardware translation
```

```text
protocol label
!= architecture instruction
!= instruction execution
!= architecture event
```

```text
artifact identity
!= authority to install or activate the artifact
```

```text
CPU stage-2 translation confinement
!= DMA / SMMU / device confinement
```

## How Construction 006 applies the laws

- It binds exact predecessor identities but never dereferences their numeric
  addresses.
- It uses a closed label alphabet rather than pretending to emit instructions.
- It treats request validation, accepted prefix, sealed state, and hardware
  effect as different objects.
- It frames every rejected value transition.
- It records architecture adequacy as open debt.

## Explicitly not promoted

The following remain quarantined:

- generalized effect-contract and witness schemas;
- broad boot-manifest or desired-state control planes;
- arbitrary register-programming APIs;
- reusable TLBI/barrier abstraction layers;
- runtime currentness or attestation products;
- a broad unsafe obligation registry copied into active implementation.

## Consequence

The next office must not write assembly merely because the value protocol is
now executable and formally checked.  It must first define an explicit
architecture-assumption/admissibility object and close or reject the mapping
from each intent label to required abstract architecture events.
