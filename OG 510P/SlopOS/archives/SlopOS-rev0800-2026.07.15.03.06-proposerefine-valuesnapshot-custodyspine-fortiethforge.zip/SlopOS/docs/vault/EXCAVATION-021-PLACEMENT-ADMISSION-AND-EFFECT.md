# Excavation 021 — placement, admission, and effect

## Sources reread and preserved

The following files were copied byte-for-byte into
`vault/searchable/placement-admission-effect-law/`.  They are research pressure,
not active schema or implementation authority.

| Preserved source | Bytes | SHA-256 |
|---|---:|---|
| `SlopOS-rev0760/docs/30-architecture/boot-manifest-schema-v0.md` | 6741 | `a759dac93e4a4a35c9961be687295de88fdc57a399b46c886c831448289f359b` |
| `SlopOS-rev0760/docs/30-architecture/init-state-snapshot-schema-v0.md` | 2515 | `c72861372a2cea908f8b59137b9ea3116a08d232b98febd1ec5c8caad2ee004c` |
| `SlopOS-rev0760/rfcs/0022-address-decoding-nets-and-page-table-gen.md` | 3907 | `965df2670b4081d3b33be8ddb88c94c6122ed65b391ac02607bc06b8eba20627` |
| `SlopOS-rev0760/docs/30-architecture/address-decode-net-schema-v0.md` | 1855 | `d90a88bc756d5115d4824af3f6b6fe6d2e1d63a50976489e46294aa2e91e78f9` |
| `SlopOS-rev0760/docs/20-assurance/unsafe-obligation-registry.md` | 2720 | `4dbc694c11c14ea179cb9e6a08c3fa735169db0e202b0a97caddae9ac1862535` |
| `SlopOS-rev0760/docs/30-architecture/effect-contract-schema-v0.md` | 14032 | `bf9c881d41cea42842fdbb085e8fd7609bd36c776822247420eaef454a1717bf` |
| `SlopOS-rev0760/docs/40-verification/effect-witness-laundering-fixtures-v0.md` | 3421 | `0e2343e62dc17381f67071c9e8a063edbc7b06e97fc514bb171a698e0c3e0d5f` |
| `SlopOS-rev0760/fixtures/cross_cube_pressure/foundry_selected_rule_is_not_effect.json` | 1207 | `a8237b1b40291e70fd2a2805a62e5afad0f6d03bc6d0a18c9fff58b4fe8f6d71` |
| `Foundry-rev0103/adrs/0002-runtime-evidence-is-not-a-verdict.md` | 181 | `e67a69105e727b8f07f74e56ee2ee606431c2088584d051a775d8e527c25c505` |
| `Foundry-rev0103/docs/30-architecture/rule-effect-binding-rulebook-v0.md` | 3933 | `42616e94a6178127e80af363726121da9d7f567abb727e9d337a2611ab6a1f02` |
| `Foundry-rev0103/docs/30-architecture/specimen-flow-97-rule-effect-ledger-effect-witness-and-bypass-fence.md` | 2217 | `af464c16eae8189d8c3ed93839d113dd2e3fc578640a0d7748a7b3130368a743` |
| `Foundry-rev0103/schemas/foundry-rule-effect-ledger-v0.schema.json` | 1652 | `db481506fefd28ab3d8ffdd49326c52fa8a0b8608c1128d5e98b4393b8fd9ab3` |
| `Foundry-rev0103/schemas/foundry-effect-witness-v0.schema.json` | 1538 | `64faddcade1968e66d88ae4fcda8f28d648fb8ec42f7b448e5496a2aca48a60a` |
| `Foundry-rev0103/fixtures/specimen-97-rule-effect-binding/fixture.json` | 41152 | `8d339b065d70056918a9ee7d1a1ec755029fcc546186b5bf6f2ed24cf311d31d` |

## Recovered distinctions

### Artifact identity is not application authority

The old boot and initial-state work correctly demanded bindings among
configuration, artifacts, installed state, and boot selection.  It was too
broad for the present infant, but its central warning survives:

```text
identified bytes
!= authority to place those bytes
```

The M0-P4 packet names one graph and six intended destinations.  It neither
owns those destinations nor authorizes a write.

### Admission is not installation

The old address-net/page-table generator work separated build artifacts from
privileged validation.  Rev0780 sharpens the sequence:

```text
generated value
-> selected value
-> admitted packet
-X-> physical effect
```

A completed packet ledger is evidence that a finite admission relation
accepted its expected records.  It is not evidence that a memory cell changed.

### Installation is not root selection

The old CH-BOOT and CH-INIT material coupled too many future concerns, but it
correctly kept installed artifacts and selected boot state separately bound.
The active law is:

```text
bytes copied into an owned memory value
!= root selected by a live privileged register
```

M0-P5 may construct only the left side as a pure model.  Register state remains
a later obligation.

### Witness is not effect

Foundry's rule-effect ledger and effect-witness work repeatedly distinguishes
selection, intended application, a record of attempted application, and actual
effect.  SlopOS promotes that law without importing Foundry schemas:

```text
receipt or witness
!= effect
```

This applies equally to a packet manifest, C++ admission observation,
Isabelle theorem packet, and future deployment receipt.

### Unsafe page-table mutation begins after ownership and protocol

The old unsafe registry named exclusive table ownership, alias control, and TLB
protocol as prerequisites of page-table update.  The current packet satisfies
none of those physical preconditions.  Raw pointers, volatile access,
registers, barriers, and TLB operations therefore remain forbidden in M0-P4.

## Active promotions

- **VPR-053 — Admission/effect separation:** accepting the exact packet does
  not establish that any destination changed.
- **VPR-054 — Artifact/application authority separation:** digest or
  fingerprint identity does not authorize application of the identified
  artifact.
- **VPR-055 — Installation/root separation:** installed bytes and live root
  selection are distinct states and require a named relation.
- **VPR-056 — Effect evidence is bounded:** a receipt or witness establishes
  only its exact recorded proposition; it cannot silently import effect.

## Quarantine

CH-BOOT, CH-INIT, CH-ADDRNET, generic deployment manifests, dynamic table
allocators, general relocation formats, host-address loaders, page-table
mutation APIs, register programming, TLB protocols, effect-witness schemas,
and product-profile boot surfaces remain quarantined.

They may return only after a failed bounded construction identifies a precise
missing field, relation, or theorem.
