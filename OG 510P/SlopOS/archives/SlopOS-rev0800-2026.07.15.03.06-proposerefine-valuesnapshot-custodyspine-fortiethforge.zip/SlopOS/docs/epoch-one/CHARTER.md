# Epoch One charter — proposed, not entered

Epoch One begins only after the Epoch Zero closure receipt is independently reviewed
and deliberately selected. Its purpose is one useful, end-to-end authority/effect
slice, not a restart of the platform ladder.

Candidate entry work:

1. one hosted authority walking skeleton with generation-qualified identities and
   explicit revocation clocks; and
2. one smallest privileged effect or measured substrate adapter whose authority,
   admission, machine action, and completion observation are connected.

Epoch One must compare from-scratch privileged machinery against an existing small
isolation substrate before committing to a larger kernel/hypervisor surface. It may
reuse historical M0 evidence as pressure but cannot promote it automatically.

Rev0799 has **not** entered Epoch One.
