# Epoch Zero charter — corrected closure state

Epoch Zero establishes the smallest trustworthy language for SlopOS claims and one
recoverable construction process. Revision 0798 reopened a premature exit; revisions
0799 and 0800 retain the corrected state: the epoch is in `CLOSURE`, not complete.

Epoch Zero owns:

- the non-promotion laws between intent, authority, admission, effect, observation,
  completion, evidence, proof, and currentness;
- the living-project versus preserved-vault boundary;
- exact subject identity and fail-closed repository classification;
- the sole theorem root and explicit theorem exclusions;
- a bounded C++20 harness with independent model/core/checker pressure;
- at least one concrete representation/step relation attempted honestly rather than
  implied by canonical text;
- cold-resume and closure procedures; and
- an explicit, reviewed gate into Epoch One.

It does not own a production kernel, hypervisor, device model, distributed identity,
trusted UI, release product, or hardware-isolation claim.
