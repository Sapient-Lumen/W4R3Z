# Epoch Zero construction 001 — Office V2 authority specimen

**Status:** hosted executable specimen; not Epoch One entry

## State and events

- proposal: id, subject, resource, action, amount, consumed;
- lease: id, subject, resource, action, maximum amount, validity interval, remaining
  uses, revoked;
- resource: counter value, last effect time, observation availability;
- events: `PROPOSE`, `ISSUE`, `INVOKE`, `REVOKE`, `OBSERVE`.

Only `INVOKE` can mutate the protected resource. A successful invocation consumes
the exact proposal and one lease use in the same transition. Every denial returns an
outcome with `effect_committed=false` and leaves canonical state unchanged.

## Admission fence

Invocation requires:

- existing unconsumed proposal and existing lease;
- actor equals proposal subject;
- exact proposal/lease subject, resource, and action agreement;
- proposal amount no greater than lease `max_amount`;
- lease not revoked;
- `not_before <= now <= expires_at`;
- at least one remaining use; and
- no uint64 overflow in the selected increment.

The implementation exposes distinct denial codes so tests can detect precedence and
avoid collapsing all failures into an ambiguous boolean.

## Observation fence

Observation is a pure read. It returns current, stale, or unavailable relative to a
caller-supplied `now` and `max_age`. It cannot make a stale value current, authorize
an invocation, or change state.

## Independent model and exploration

`AuthorityCore` uses fixed arrays with capacities 8 proposals, 8 leases, and 4
resources. `AuthorityReference` uses ordered maps. The depth-five exploration uses a
nine-command alphabet and checks 59,049 traces / 295,245 transitions. This is bounded
model agreement, not exhaustive behavior for arbitrary IDs, times, capacities, or
sequences.

## Formal boundary

`proof/P0_Authority_Lease.thy` proves abstract proposal/lease registration does not
change the counter, denied invocation frames state, revoked/oversize leases cannot
commit, successful invocation has the exact counter and consumption effects, and
observation frames state.

The theory uses natural numbers and one selected proposal/lease. It excludes finite
capacity, uint64 overflow, duplicate IDs, first-failure order, serialization, clocks,
persistence, concurrency, and C++ refinement. Those exclusions are open proof work,
not implementation details that may be silently assumed.
