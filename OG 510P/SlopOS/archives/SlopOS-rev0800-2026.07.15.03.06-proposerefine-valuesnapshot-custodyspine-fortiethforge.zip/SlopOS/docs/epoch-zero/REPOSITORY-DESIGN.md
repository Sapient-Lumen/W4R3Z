# Epoch Zero repository design — rev0800

## Subject lanes

| Lane | Examples | Construction | Custody | Behavior |
|---|---|---:|---:|---|
| construction | source, tests, proof, docs, specs | yes | no | hash exactly |
| custody | `vault/` | no | yes | hash exactly; preserve bytes |
| evidence | `evidence/` | no | no | bind results; never enter the subject |
| ignored | `build*`, `.git`, `.slopos-work` | no | no | skip traversal and packaging |
| transport | detached `.zip` | no | no | exclude; digest externally |
| reject | unknown, symlink, special | no | no | fail closed |

The classifier is ordered. Higher-priority custody/evidence rules dominate generic
`.zip` transport classification. Unknown state reaches a mandatory reject fallback.

The V2 manifest identity is a stable lexical table of relative path, path class,
audit lane, object type, permission mode, byte count, and SHA-256. Evidence and the
transport container are excluded to avoid self-reference.

## Authority/refinement source layout

```text
include/slopos/k0/authority.hpp
    shared command/value declarations and production interfaces

src/p0/authority.cpp
src/p0/authority_reference.cpp
    independent transition implementations and independent snapshot projections

include/slopos/k0/authority_propose_refinement.hpp
src/refinement/authority_propose.cpp
    one observational PROPOSE expected-state relation; no reverse dependency

tests/support/authority_sequence_test_peer.hpp
tests/test_authority_propose_refinement.cpp
    private terminal seam and mutation pressure

proof/P0_Authority_Propose_Refinement.thy
    abstract bounded semantics; no generated C++ parser
```

The production authority library must never link against the refinement library.
Core, reference, and checker may share value declarations but not validation or
mutation helpers. This intentional duplication is a defense against common-mode
semantic defects.

## Current limitation

Repository traversal assumes a quiescent controlled tree. It re-stats selected
metadata but does not provide descriptor-held path safety against a hostile
concurrent mutator. A future platform adapter may strengthen that boundary; it must
not be retroactively inferred from the portable manifest code.
