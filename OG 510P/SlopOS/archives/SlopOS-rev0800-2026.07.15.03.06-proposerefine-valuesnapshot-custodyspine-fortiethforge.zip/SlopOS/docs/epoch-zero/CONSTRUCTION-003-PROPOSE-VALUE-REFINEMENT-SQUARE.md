# Epoch Zero construction 003 — PROPOSE value refinement square

## Objective

Close the smallest honest part of `E0-AUTHORITY-CPP-REFINEMENT-001`: make one valid
PROPOSE step and each of its deterministic denial branches observable as exact typed
state transformations, while retaining a visible gap to C++20 semantics.

## Delivered

- `AuthorityValueSnapshot`, a complete copy-only canonical observation;
- independently implemented core/reference projections;
- a separate expected-state/checker library for PROPOSE;
- exact first-failure classification and whole-state frame checks;
- concrete terminal and max-minus-one execution through a test-only seam;
- mutated outcome/post-state rejection;
- a bounded HOL PROPOSE transformer and theorem declarations;
- proof/correspondence ledgers that distinguish formal source, executable evidence,
  and remaining source-semantics debt.

## Claim

On the tested hosted builds, every focused concrete PROPOSE case from a well-formed
snapshot agrees between the fixed-array core, map-backed reference, and independent
expected-state checker. The terminal command returns
`DENIED_SEQUENCE_EXHAUSTED` without state change. An available accepted command
inserts exactly one proposal and advances exactly once.

This is `BOUNDED_CPP_VALUE_CORRESPONDENCE`. It is not an Isabelle-checked theorem for
rev0800, a universal C++20 evaluation theorem, compiler correctness, concurrency,
persistence, or a privileged effect.

## Why Epoch Zero remains open

The pinned theorem session has not run, the exact vertical representation relation is
not mechanized, four authority operations remain outside this concrete edge, and no
platform effect is justified end to end. The revision improves the foundation but
does not satisfy the epoch exit charter.

## Stop rule honored

No operation, reuse mechanism, platform target, parser, generator, second living
root, or new authority-bearing service was added. The next actor should first recover
and run Isabelle externally. If that remains impossible, the only admissible proof
construction is a smaller exact source/value binding for this frozen PROPOSE body,
not another broad semantics framework.
