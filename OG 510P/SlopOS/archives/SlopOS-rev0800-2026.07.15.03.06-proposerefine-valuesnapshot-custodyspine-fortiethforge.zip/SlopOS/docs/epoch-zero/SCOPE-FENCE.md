# Epoch Zero scope fence — rev0800

## Current claims permitted

- exact construction and custody identities on a quiescent local tree;
- fail-closed classification of unknown paths, symlinks, special objects, and
  ZIP-named directories;
- hosted C++20 behavior for the declared finite authority specimen;
- bounded agreement between independently structured core and reference machines;
- a typed copy-only canonical authority value image;
- bounded PROPOSE agreement with an independent expected-state transformer,
  including exact denial frame, accepted insertion, finite sequence behavior, and
  targeted mutation rejection; and
- abstract Isabelle propositions present in the checked-in theory source, becoming
  current theorem evidence only after the exact pinned session runs.

## Claims forbidden

- a current Isabelle result while Isabelle2025-2 is absent;
- a C++/Isabelle, C++ abstract-machine, compiler, binary, object-layout, or ABI
  refinement theorem;
- refinement of ISSUE, INVOKE, REVOKE, or OBSERVE by analogy with PROPOSE;
- cryptographic authentication, signatures, provenance trust, human approval, or
  release authority from a digest;
- race-safe hostile filesystem traversal;
- trusted wall-clock time, persistence, crash consistency, concurrency, distributed
  revocation, or replay protection beyond the selected in-memory sequence;
- safe identifier reuse, dependent invalidation, quiescent reclamation, external
  recall, or evidence supersession from lease withdrawal;
- QEMU/Arm correctness, hardware isolation, DMA/device isolation, multicore, timing,
  side-channel, availability, or information-flow security;
- a custody migration from a content-addressed index; or
- product readiness, public release, or an inferred Epoch One transition.
