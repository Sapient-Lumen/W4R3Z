# Epoch Zero construction plan — rev0800

## Active sequence

1. Keep the typed office and exact construction/custody identities reproducible from
   a cold extraction.
2. Preserve the active/full lane split: 103 fresh active Ninja steps and 253
   full-research steps on the recorded configuration. Historical M0/AArch64 work is
   opt-in only.
3. Freeze the rev0800 PROPOSE value-image checker and its production dependency
   direction. Use failures as counterexamples, not invitations to broaden the API.
4. Recover Isabelle2025-2 in an external digest-pinned disposable cache and run the
   exact `SlopOS_K0` session.
5. Mechanize the smallest canonical-snapshot-to-HOL projection and the single
   PROPOSE commuting square.
6. Only after that review, choose one successor: generation-qualified no-resurrection
   identity or one real privileged effect slice. Do not assume both are required in
   the same revision.
7. Obtain independent review of the exact final basis and exclusions before any
   Epoch Zero exit proposal.

## Admission rule

A new operation, model, parser, generator, proof island, platform mechanism, service,
or custody migration enters only after naming:

- the invariant or arrow it closes;
- the counterexample that requires it;
- the smaller alternative considered and rejected;
- the additional trusted/evidence surface; and
- the exact claim that remains excluded.

## Frozen and paused lanes

- `SLOPOS_BUILD_LEGACY_M0=ON` preserves the long M0/AArch64 ladder as research. It is
  not ordinary closure work.
- The alternate rev0798 revocation chamber remains branch evidence, not a second
  current implementation.
- The old snapshot, registry, emitter, and packet families remain vault material.
  Laws may be promoted with anchors; implementations are not merged wholesale.
- Source archive bytes remain immutable. A future recovery pack is a derivative and
  cannot silently replace custody.

## Stop condition

Stop any revision that adds breadth without closing a named semantic edge. In
particular, stop before adding another authority operation, PROPOSE DSL, generated
bridge, identifier reuse path, or platform rung while the current vertical relation
is still open.
