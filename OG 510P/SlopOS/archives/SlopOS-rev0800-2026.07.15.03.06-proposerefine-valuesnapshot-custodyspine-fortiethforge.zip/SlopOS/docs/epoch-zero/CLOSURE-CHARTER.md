# Epoch Zero closure charter

Epoch Zero establishes a small, falsifiable authority/effect foundation and a
resumable office. It does not close because enough revisions, theorems, platform
packets, generated artifacts, or emulator traces exist.

## Required exit gates

1. One exact current formal session on the final construction basis, with no proof
   holes and a recorded tool identity.
2. At least one checked concrete C++20-to-abstract representation and step relation
   for the active authority machine, including finite widths, capacity, denial
   framing, and first-failure order.
3. One intentionally selected end-to-end effect slice whose authority, admission,
   privileged mechanism, completion, and observation are distinct and scoped.
4. Generation/reuse law either proved and implemented or explicitly absent from the
   selected slice.
5. Exact construction and custody identities reproduce from a cold extraction.
6. A second actor reviews the final basis, exclusions, and close receipt.
7. Epoch One entry is deliberately selected; it is not inferred from momentum.

## Current state

Rev0800 passes the bounded construction, custody, active-build, hosted-test,
terminal-sequence, vault-scan, and executable PROPOSE value-correspondence gates once
its evidence packet is reproduced. Formal currentness remains BLOCKED; the exact
snapshot-to-HOL/C++ source relation, independent review, real-effect slice, and epoch
exit remain OPEN. The office must therefore stay OPEN.

## Scope fences

Epoch Zero does not promise a scheduler, network stack, filesystem, shell, agent
runtime, persistence service, distributed revocation, safe reclamation, hardware
isolation, certification, or product profile. Historical M0 work is research input,
not a hidden exit gate.
