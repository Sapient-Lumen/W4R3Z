# Construction 002 — active lane and authority sequence fence

## Purpose

Close two concrete defects without widening the machine: default build authority
was too broad, and the hosted authority sequence could wrap after mutation.

## Repository construction

`CMakeLists.txt` contains the active common/K0/P0/tool/test graph. Historical M0 and
AArch64 targets live in `cmake/SlopOSLegacyM0.cmake` and are instantiated only when
`SLOPOS_BUILD_LEGACY_M0=ON`. `slopos-generate` is active-only;
`slopos-generate-legacy` exists only in the full lane. Isabelle mirrors this split
with `SlopOS_K0` and `SlopOS_M0`.

Measured fresh Ninja dry runs:

```text
active lane:        96 steps
full-research lane: 246 steps
```

This is not deletion. It is an authority boundary around paused research.

## Sequence construction

For each state-changing operation, the core/reference order is:

```text
parse/select command
-> operation-specific validation and deterministic first failure
-> capacity/scope/time/amount/overflow checks
-> accepted_sequence_advance(sequence)
-> if unavailable: DENIED_SEQUENCE_EXHAUSTED, whole-state frame
-> perform exactly one selected mutation
-> publish advance.next
```

`OBSERVE` performs no sequence advance. The production classes expose no sequence
setter. `tests/test_authority_sequence_exhaustion.cpp` compiles private copies with
a friend seam only under `SLOPOS_AUTHORITY_SEQUENCE_TEST_SEAM`.

## Witness scope

The witness proves by execution only that the compiled core/reference agree for the
focused terminal cases and preserve canonical state. It does not prove C++20
semantics, compiler correctness, concurrency, crash consistency, persistence, or
refinement to Isabelle. The abstract wrapper is deliberately operation-agnostic;
the next obligation must connect one concrete command.

## Revocation scope

Current REVOKE marks one existing lease revoked, blocking later use. It does not
walk descendants, invalidate mappings, cancel in-flight work, reclaim storage,
recall external effects, or supersede evidence. No slot reuse occurs.
