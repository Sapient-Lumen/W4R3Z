# Construction 005 — M0 AArch64 stage-2 owned-memory value

## Bounded purpose

Construction 005 closes the first explicit copy/readback rung without crossing
into machine effect:

```text
selected graph value
  -> selected placement/admission packet
  -> sealed admission observation
  -> pure eight-page owned-memory value
  -> atomic six-page copy and exact readback
  -X-> host or physical memory write
```

It exists because the old cube repeatedly separated intended effect, admitted
effect, observed residue, and current effect—but did not provide a tiny
executable memory transition whose failure frame could be checked end to end.

## State shape

The constrained state has fixed capacity:

```text
slot 0  guard before   id 0x3ffff000  owner 0  fill a5
slot 1  alpha L1       id 0x40000000  owner 1  zero -> graph page 0
slot 2  alpha L2       id 0x40001000  owner 1  zero -> graph page 1
slot 3  alpha L3       id 0x40002000  owner 1  zero -> graph page 2
slot 4  beta L1        id 0x40003000  owner 2  zero -> graph page 3
slot 5  beta L2        id 0x40004000  owner 2  zero -> graph page 4
slot 6  beta L3        id 0x40005000  owner 2  zero -> graph page 5
slot 7  guard after    id 0x40006000  owner 0  fill 5a
```

The adjacent numeric identities are selected finite values.  Their adjacency
is useful for exact frame pressure but does not imply one real contiguous
allocation.

## Input binding

`InstallInputValue` carries exact copies of:

- the 512-byte packet wire;
- the 24,576-byte graph wire;
- the final sealed admission observation;
- the exact table order `[0,1,2,3,4,5]`; and
- expected memory generation 1.

The core decodes the selected packet and graph anew, reproduces the sealed
ledger observation, and checks every binding before copying.  The reference
compares against independently built selected values and validates its own
vector state.

## Transition precedence

The exact rejection precedence is:

```text
already installed
bad initial metadata
stale generation
bad packet
bad sealed admission
bad graph
bad order
bad capacity
repeated page identity
missing destination
wrong owner
invalid guard/table role
nonzero destination payload
accepted atomic install
```

Precedence is part of the selected executable observation, not yet a general
API promise.

## Accepted post-state

Acceptance changes only:

- six installable payloads;
- generation from 1 to 2;
- installed flag from false to true;
- installed packet, graph, and admission identities; and
- install sequence from 0 to 1.

Page identities, owners, roles, installable flags, page count, version, and
both guard payloads are unchanged.

## Artifacts

```text
include/slopos/m0/aarch64_s2_owned_memory.hpp
src/m0/aarch64_s2_owned_memory.cpp
tools/slopos_aarch64_s2_owned_memory_main.cpp
tests/test_aarch64_s2_owned_memory.cpp
tests/test_aarch64_s2_owned_memory_noalloc.cpp
generated/m0/aarch64-s2-owned-memory.txt
generated/m0/aarch64-s2-owned-memory.bin
proof/generated/M0_AArch64_S2_Owned_Memory_Generated.thy
proof/M0_AArch64_S2_Owned_Memory.thy
```

`--emit` owns generated artifacts; `--check` rejects drift; `--witness`
prints the exact selected construction and non-claims.

## Proof/evidence partition

| Claim | Evidence kind |
|---|---|
| exact finite page identities, owners, extents | Isabelle theorem |
| selected formal request is accepted | Isabelle theorem |
| rejected formal request/state frames memory | Isabelle theorem |
| accepted formal result is canonical | Isabelle theorem |
| installed descriptor payloads equal graph tables | Isabelle theorem |
| guards frame accepted formal transition | Isabelle theorem |
| exact little-endian 24,576-byte C++ copy | bounded differential test |
| all 719 noncanonical orders reject | bounded exhaustive test |
| all 24,576 dirty target positions reject | bounded exhaustive test |
| constrained transition performs no observed allocation | test observation |
| C++ source/compiler/platform realizes HOL relation | open |
| values are installed in machine physical memory | open |

## Stop line

Construction 005 contains no raw owning pointer, host-address dereference,
physical-address cast, `volatile`, MMIO, inline assembly, register access,
barrier, cache/TLB maintenance, exception path, boot, guest, device, DMA/SMMU,
multicore behavior, new K0 command, or isolation claim.
