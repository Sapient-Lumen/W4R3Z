# Construction 019 — repository identity and Office V2

## Objective

Replace a revision-hardcoded audit monolith with a small generic office whose facts
are typed data, and make the vault/living-project boundary executable.

## Components

- `src/common/sha256.cpp`: internal SHA-256 with standard known-answer tests;
- `src/common/repository.cpp`: ordered policy parser, classifier, canonical manifest,
  and exact verification;
- `src/office/schema.cpp`: TSV parsing, safe relative paths, proof-hole marker scan;
- `src/office/audit.cpp`: revision/read-order/required/decision/evidence/claim/gate/
  proof-ledger validation and basis verification;
- `src/common/office.cpp`: human outputs for audit, status, resume, open, bases, and
  closure receipt;
- `spec/office/*.tsv`: revision-specific truth.

## Key properties tested

- known SHA-256 vectors, including a multi-block NIST vector;
- stable lexical manifest order;
- vault ZIP remains custody and evidence ZIP remains evidence;
- detached living ZIP is transport, not source;
- evidence mutation does not change construction identity;
- vault mutation changes custody identity but not construction identity;
- source bytes or permission mode change construction identity;
- exact manifest verification;
- unknown path, symlink, special object, and ZIP-named directory rejection.

## Claim boundary

The construction proves no cryptographic implementation certification, provenance,
signature, hostile filesystem race safety, or archive authenticity. It establishes a
small, executable subject boundary under the quiescent local-tree premise.
