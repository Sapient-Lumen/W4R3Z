# Construction 001 — Hosted K0 transition core

**Evidence:** TEST + CONFORMANCE + BOUNDED within recorded scopes
**Not:** booted kernel, C++ refinement theorem, platform isolation proof

`CoreMachine` is a fixed-capacity C++20 state machine with no observed allocation in
authoritative transitions. It installs the compiled bootstrap, derives attenuated
capabilities, maps private memory, and transfers bounded endpoint values.

`ReferenceMachine` uses a different hosted representation and does not share
transition logic. `Oracle` applies every command to both, checks independent
invariants, exact results/canonical states, and denial atomicity.

## Generated `DERIVE` construction

The authoritative core `DERIVE` policy is `generated::apply_derive`, emitted from
`spec/kir0-derive.program`. The same eleven-guard source emits Isabelle data and a
binding manifest. There is no handwritten core policy duplicate.

Independent pressures surround it:

- the clear reference model and differential oracle;
- exact eleven-denial precedence plus successful commit;
- 6,963,200 finite fact cases;
- 577,368 successful whole-array commit/frame cases;
- 577,368 terminal whole-array rejection frames;
- generated-artifact currency and deterministic fingerprints.

The fact witness previously found a real absent-source default-value ambiguity. The
sequence extension then found the final finite-carrier obligation and made it a
source-level gate rather than an assumption.

## Sequence boundary construction

All four accepting operations call the checked source primitive only after their
ordinary checks and before the first mutation. Maximum-minus-one advances to
maximum. At maximum, an otherwise accepting operation returns
`sequence_exhausted`; invalid, absent, conflicting, denied, full, or empty commands
retain their established earlier result.

A dedicated test executable uses DEC-0012's compile-time-only friend peer to install
boundary sequence state in model and core. Production libraries expose no setter,
command, trace token, or bootstrap field for this purpose. The 25-case witness checks
both machines, exact frames, invariants, result equality, and stable identity.

## Demonstrated path

```text
root cap slot 0
  -> DERIVE alpha slot 4 with {map, read}
  -> MAP alpha page 3 through slot 4
  -> reject beta use of alpha slot 4 without mutation
endpoint send cap slot 2
  -> SEND alpha value 42
  -> RECEIVE beta through slot 3
```

## Construction boundary

There is no trap entry, page-table write, address-space switch, scheduler, interrupt,
DMA, or boot path. Formal MAP/SEND/RECEIVE remain stubs. The next work is the exact
C++ capability-array/formal-map relation for the existing DERIVE surface, not another
command or platform mechanism.
