# SlopOS moonshot map

> **Rev0797 direction:** Epoch Zero is complete as a foundation. The active path now
> prototypes P/E authority semantics in parallel with one direct K/M isolation
> effect and benchmarks an existing substrate before broad native-kernel expansion.
> See DEC-0045 and the mission/epoch review.
## North star

SlopOS is attempting a **proof-carrying authority and isolation operating system**:
one narrowly privileged machine whose runtime effects and assurance claims can both
be followed through explicit, mechanically checked relations.

The eventual product family is intentionally broad:

- **A — secure workstation:** human sessions, applications, input/display, devices,
  updates, compatibility, and recovery without ambient authority;
- **B — cloud micro-VM / hosted compute substrate:** tenant isolation, second-stage
  translation, bounded exits/vCPUs, image provenance, attestation, lifecycle, and
  auditable operation;
- **C — embedded / separation-kernel-ish appliance:** closed configuration, static
  partitions, device ownership, bounded resources/schedules, and deterministic
  recovery;
- **D — agent/automation OS:** LLMs as first-class developers and users while model
  output remains proposal material, never authority.

These are not four kernels. They are profile-specific configurations, services,
assumptions, and theorem bundles over one common spine. Going for broke means
preserving that end-to-end ambition while making the trusted center smaller, not
trying to implement all four surfaces during Epoch Zero.

## One system, five named regions

```text
                    A / B / C / D profile bundles
             configuration + service + theorem + assumptions
                                  |
              S — isolated services and compatibility domains
       drivers, filesystems, networking, UI, VMM services, agents
                                  |
                P — mediated authority Runtime
      proposals, validators, portals, policy, receipts, provenance,
              leases, revocation, replay, and currentness
                                  |
                         narrow explicit K ABI
                                  |
                K — privileged authority/isolation core
       domains, objects, capabilities, mappings, endpoints, traps,
              bounded scheduling and low-level mediation
                                  |
                    M — machine/platform realization
       CPU, MMU, page tables, TLB, interrupt/timer, IOMMU/DMA,
                   boot, firmware, and platform assumptions

E — evidence and office machinery spans every edge without becoming runtime
    authority: specifications, theorem maps, generated-artifact currentness,
    construction bases, proof packets, build identity, claim scope, and handoff.
```

K is privileged because it must control authority or hardware isolation. P and S may
be security-critical, but should remain unprivileged whenever a narrow K primitive
suffices. E establishes what may honestly be claimed about K/M/P/S; it does not
create a capability, authorize a transition, or prove an unmentioned layer.

The predecessor cube's most distinctive work—proposal/admission separation,
provenance, currentness, denial, effect witnesses, receipts, replay, and
invalid-inference fences—primarily belongs in P and E. The from-scratch core exists
only where privilege, hardware control, isolation, or a very small trusted path
requires it.

## Two explicit chains

SlopOS is coherent only while both chains remain inspectable.

```text
authority chain
  principal intent
    -> explicit delegation / capability
    -> deterministic admission
    -> committed local effect
    -> later completion and currentness observations

assurance chain
  security requirement
    -> A0 abstract semantics and invariant
    -> D0 deterministic design/refinement
    -> I0 admitted source semantics or proof-facing IR
    -> constrained C++20 implementation relation
    -> compiler / ABI / binary relation
    -> M0 platform and configuration assumptions
    -> profile-scoped claim
```

Intent is not authority. Admission is not effect. A receipt is not current effect.
A theorem about A0 is not a theorem about evaluated C++, a binary, hardware, or a
product configuration. This common law is the deepest useful inheritance from the
old datacube and its companion cubes.

## Common K theorem envelope

Every profile that claims SlopOS isolation must eventually select a named
configuration whose evidence covers at least:

1. capability integrity, derivation, and monotone attenuation;
2. object, capability, mapping, endpoint, and scheduling-state well-formedness;
3. authorized spatial sharing and exclusion of unauthorized writable aliases;
4. a total, fail-closed privileged ABI with exact rejection frames;
5. initialization correctness from a validated static artifact;
6. bounded low-level operations with explicit preconditions and preserved
   invariants;
7. a source-to-machine chain whose compiler, ABI, binary, platform, and deployment
   assumptions are explicit.

No profile inherits boot, DMA/IOMMU, multicore, timing, availability,
information-flow, side-channel, device, or human-trusted-path claims from a generic
“verified core” label. Each is a separate theorem family or explicit non-claim.

## Profile theorem and configuration bundles

### A — secure workstation

K/M pressure: protected address spaces, interrupt/device mediation, IOMMU where
claimed, robust process/session isolation, and recovery primitives.

P/S pressure: human identity and session authority, trusted attention, input/display
focus, application and compatibility confinement, update/rollback, filesystem and
network portals, understandable denials, and device-service isolation.

A is the richest north star and therefore a poor first physical proof slice. It is
the eventual test that SlopOS can serve a human without recreating ambient
workstation authority.

### B — cloud micro-VM / hosted compute substrate

K/M pressure: hypervisor mode, stage-2 translation, closed exit handling, bounded
vCPU/interrupt state, tenant separation, static or bounded resource assignment, and
IOMMU/device rules where passthrough is claimed.

P/S pressure: image provenance, jobs, lifecycle, operator APIs, network/storage
portals, quotas, attestation evidence, receipts, and recovery.

B supplies leading platform pressure and composes naturally with D. It does not
justify virtualization machinery before the sequential source/refinement spine is
credible.

### C — embedded / separation-kernel-ish appliance

K/M pressure: fixed configuration, static partitions, explicit shared memory,
resource/schedule bounds, device ownership, and deterministic initialization.

P/S pressure: deliberately small and application-specific.

C is likely the cleanest first booted theorem-bearing configuration. A closed world
of two partitions, disjoint memory, and one explicit communication path can teach
mapping, initialization, traps, interrupts, and platform assumptions without
dynamic policy breadth.

### D — agent/automation OS

K/M pressure: primarily the common isolation ABI plus safe hosted-compute
mechanisms. Agents do not receive special kernel ontology merely because they are
first-class users.

P/S pressure: model output is proposal material; deterministic validators decide;
authority is explicit and attenuable; effects are separately witnessed; provenance
and currentness are explicit; leases and revocation bound privilege; receipts and
replay are deterministic; observations and verification do not silently become
permission.

D is where the old cube and subcubes have the greatest immediate leverage. Its
Runtime can be prototyped on an existing substrate while K matures, then consume K
only through mechanisms its experiments actually demand.

## The proof machine

```text
security property and abstract invariant                         A0
                   | invariant preservation / simulation
exact deterministic transition and observation semantics        D0
                   | design refinement
closed proof-facing implementation semantics or tiny proof IR    I0
                   | source evaluation + representation
restricted C++20 core                                            K0 source
                   | compiler / ABI / binary correspondence
machine mechanisms and boot/configuration                        M0
                   | profile assumptions and theorem selection
named deployable A / B / C / D configuration
```

Isabelle/HOL is the one theorem root for this graph. C++20 remains the implementation
and permanent executable-harness language. A small C proof island may be measured as
an implementation-semantics bridge, but it cannot silently stand for C++20. Finite
exploration, sanitizers, differential testing, compiler comparison, SMT, and future
model checkers are separate evidence engines rather than theorem promotion paths.

The seL4-shaped lesson is not “write a huge proof after the kernel.” It is to make
each semantic level, generated artifact, configuration, correspondence edge, and
assumption visible early enough that code can falsify the proof and the proof can
constrain the code.

## What the infant currently is

The active construction is a hosted, sequential, fixed-capacity authority machine:

- two domains, two private memory objects, one endpoint, and a twelve-cell
  capability table materialized from a validated static bootstrap plan;
- a clear reference model and structurally separate kernel-shaped C++20 core;
- `DERIVE`, `MAP`, `SEND`, and `RECEIVE` with deterministic first-failure order,
  denial atomicity, and fail-closed sequence exhaustion;
- canonical traces, differential execution, bounded exploration, finite witnesses,
  sanitizer lanes, and dual-compiler pressure;
- one Isabelle session containing A0, D0, KIR/proof-value, sequence,
  capability-representation, bootstrap, invariant, and refinement theories;
- exact theorem/obligation mapping, a construction-basis manifest, retained proof
  packets, and cold-start proof-toolchain recovery;
- no boot, page-table write, trap, interrupt, scheduler, device, multicore,
  information-flow theorem, or product-profile security claim.

This is not a miniature product. It is the first falsification instrument for the
semantic, implementation, proof, and office architecture.

## Construction eras

### Epoch Zero — make refinement possible

- keep the office and exact Isabelle toolchain recoverable and fail-closed;
- close or reject one honest C++ source-semantics bridge route;
- make schema, generated values/code, initialization, and representation relations
  proof-bearing;
- admit one tiny platform mechanism only after the source strategy survives;
- reject product and concurrency breadth.

### Epoch One — one booted static-isolation story

- one architecture and emulator-first machine target;
- existing boot path, one core, and static configuration;
- two protection domains with disjoint memory and one explicit shared object or
  endpoint;
- a deterministic booted trace replayed against D0;
- explicit page-table, TLB, trap, interrupt, boot, and platform assumptions;
- likely C-profile theorem pressure first, with B-compatible mechanism choices where
  they remain small.

### Epoch Two — hosted-compute and Runtime pressure

- stage-2 translation and a deliberately closed exit surface only if earned;
- bounded vCPU/interrupt state and static resource assignment;
- a hosted P authority Runtime with receipts, provenance, currentness, and replay;
- B/D operator-visible experiments without claiming workstation completeness.

### Later epochs — broaden claims, not merely features

- multicore as a separate concurrent refinement layer;
- IOMMU/DMA and isolated device domains;
- information-flow and explicit declassification;
- binary/boot correspondence for selected configurations;
- workstation trusted path and human/device authority;
- richer lifecycle, compatibility, storage, networking, and service ecosystems;
- reproducible release, supply-chain evidence, and eventually proof-carrying
  provenance for named deployable images.

## Admission filter

A proposed feature enters current K only when every answer is concrete:

1. Why does it require privilege or direct hardware control?
2. Which selected profile/configuration and theorem needs it now?
3. Which abstract invariant and exact transition will represent it?
4. Which refinement edge becomes harder, and what is the added trust surface?
5. What failed proof, failed construction, counterexample, or measured Runtime
   experiment demanded it?
6. Why can it not remain in P, S, the host, or the vault?
7. What bounded exit evidence will show that the experiment earned retention?

Without those answers, it is not current implementation scope.

## Rev0773 bridge closure and first physical waypoint

Revision 0773 makes the assurance chain more honest without expanding K. The frozen
proof companion now has a checked normalized value-AST semantics, exact raw aggregate
result, and scalar observation under an explicit carrier envelope. The exact source
bytes are **not** yet related to that AST, and compiler/ABI/binary/platform
preservation remains beyond it.

After one bounded E0-P12 attempt, the scalar bridge freezes. The next physical
waypoint is not “start a hypervisor.” It is the candidate `M0-STATIC2` theorem bundle
from Excavation 018:

```text
one immutable two-domain policy
  -> policy well-formedness and disjoint private ranges
  -> one constrained abstract installation plan
  -> one architecture-specific table encoding
  -> one explicit boot/root-selection envelope
  -> one replayable observed trace
```

The first claim is CPU-memory isolation only. It excludes DMA, devices, multicore,
rich interrupts, scheduling fairness, dynamic lifecycle, information flow, timing,
and every A/B/C/D product-level claim. That exclusion is what lets the moonshot
begin as a proof-bearing infant rather than as an unbounded feature shell.
