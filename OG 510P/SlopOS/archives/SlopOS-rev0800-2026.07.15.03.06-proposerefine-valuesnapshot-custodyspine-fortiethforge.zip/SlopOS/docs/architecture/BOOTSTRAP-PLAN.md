# Bootstrap plan

The active C++20 `BootstrapPlan` declares:

- domains 1 (`alpha`) and 2 (`beta`);
- private memory objects 1 and 2, owned respectively by alpha and beta;
- endpoint 1;
- alpha root memory cap in slot 0;
- beta root memory cap in slot 1;
- alpha send cap in slot 2;
- beta receive cap in slot 3.

Root memory caps carry derive, map, read, write, and revoke.  Endpoint caps carry
only their communication role plus the rights explicitly shown in code.  Empty slots
begin at 4.

A deterministic 64-bit FNV-1a fingerprint binds plan fields in explicit byte order.
It is a reproducibility fingerprint, not a cryptographic commitment.  Traces reject
a different fingerprint.  The proof emitter writes the same numeric fields into
`proof/generated/K0_Bootstrap_Generated.thy`.
