# SlopOS threat model V0 — Epoch Zero closure

**Revision:** 0798
**Status:** active narrow model; no product or hardware claim

## In-scope adversaries for the hosted authority specimen

- untrusted proposal producer, including model/agent output;
- wrong actor, subject, resource, action, or amount;
- duplicate, missing, consumed, revoked, not-yet-valid, expired, or exhausted lease;
- overflow attempt on the protected uint64 counter;
- stale or unavailable observation presented as current;
- malformed command values within the public C++ type boundary;
- accidental evidence/vault/build/transport inclusion in active repository identity;
- unknown path, symlink, special object, or misleading `.zip` directory.

## Assets

- protected resource state;
- exact authority scope and use budget;
- denial framing and single-transition consumption;
- separation of effect from observation;
- construction/custody boundary;
- evidence currentness and explicit proof exclusions;
- cold-resume truth.

## Trusted/assumed

- one process/thread and quiescent in-memory state;
- caller-supplied monotonic-enough time for the selected run;
- controlled, quiescent local filesystem during manifest generation;
- correct C++ compiler/runtime, SHA-256 implementation, OS, and storage;
- no malicious administrator replacing the identified process or tree;
- no persistence, crash, rollback, distributed delegation, or concurrent mutation;
- no secret-key authentication or trusted human UI.

## Explicit non-goals

- production capability system or generalized policy engine;
- cryptographic credential authenticity;
- hostile filesystem race safety;
- persistent or distributed revocation and no-resurrection proof;
- QEMU/Arm correctness, secure boot, hardware isolation, DMA/devices, multicore,
  weak memory, timing, speculation, side channels, or availability;
- network identity, remote attestation, release, or product readiness.

## Security rules

**Proposal is not authority.** Registering a proposal cannot change the protected
resource.

**Lease is attenuated authority.** It names exact subject/resource/action and bounds
magnitude, time, and use count. Admission only narrows.

**Denial frames state.** Any failed invocation leaves proposals, leases, resources,
and sequence unchanged.

**Effect is distinct.** Only an admitted invocation commits the protected increment,
consumes the proposal, and consumes one use.

**Observation is not effect or authority.** Current/stale/unavailable reports do not
mutate or authorize.

**Evidence is exact-subject.** A log or theorem packet applies only to the exact basis
and premises it names.

**Custody is not construction.** Archived cubes can pressure design but cannot become
active law by co-location.
