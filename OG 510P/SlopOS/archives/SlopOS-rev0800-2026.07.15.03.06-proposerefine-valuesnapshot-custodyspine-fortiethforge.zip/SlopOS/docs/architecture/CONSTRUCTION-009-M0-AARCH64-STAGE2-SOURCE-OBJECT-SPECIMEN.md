# Construction 009 — M0 AArch64 stage-2 source/object specimen

## Purpose

Construction 009 inserts a narrow source/object rung between the accepted M0-P8
instruction values and any future loader or execution mechanism.

```text
M0-P8 exact instruction words
  -> one exact assembly source
  -> one identified assembler replay
  -> one exact relocatable-object value
  -> one fixed-capacity structural parser
  -X-> loader placement, execution, completion, or effect
```

## Active files

```text
spec/m0/aarch64-s2-activation.S
toolchains/aarch64-assembler.lock
include/slopos/m0/aarch64_s2_object.hpp
src/m0/aarch64_s2_object.cpp
tools/slopos_aarch64_s2_object_main.cpp
tests/test_aarch64_s2_object.cpp
tests/test_aarch64_s2_object_noalloc.cpp
generated/m0/aarch64-s2-activation.o
generated/m0/aarch64-s2-object-specimen.txt
proof/generated/M0_AArch64_S2_Object_Generated.thy
proof/M0_AArch64_S2_Object.thy
```

All permanent implementation and executable harness code is C++20. Isabelle/HOL
is the approved theorem-language exception.

## Parser design

The constrained parser uses no dynamic allocation and admits only the selected
560-byte object. It validates, in fail-closed order:

1. exact object extent;
2. ELF magic and identification bytes;
3. ET_REL and EM_AARCH64 identities;
4. fixed header values and absence of program headers;
5. five exact section headers and absence of relocation section types;
6. exact section names through the selected string table;
7. exact `.text` and `.note.GNU-stack` properties;
8. nine exact little-endian instruction words;
9. three exact symbol entries and names; and
10. exact whole-object FNV and byte identity.

A rejected parse returns an empty `ObjectFacts` value. It does not repair,
normalize, partially accept, or infer omitted metadata.

The hosted reference parser uses a different strategy: complete vector-backed
byte-image equality followed by construction of the selected facts.

## Generated currentness

The C++20 generator owns four exact artifacts:

```text
assembly source bytes
object bytes
human-readable manifest
Isabelle natural/list constants
```

`--check` byte-compares all four against the active C++20 values. The assembler
replay is separately gated by exact version line, target, architecture, command,
and resulting object bytes.

## Mutation boundary

The harness flips every bit of the selected source and object independently:

```text
339 * 8 = 2712 source mutations
560 * 8 = 4480 object mutations
7192 total
```

Every mutation rejects. This is a bounded exact-specimen fence, not proof that
all malformed ELF objects reject or that the parser implements a general ELF
standard.

## Stop line

Construction 009 contains no:

```text
general ELF API
linker
relocation application
loader address or executable mapping
instruction-cache maintenance
raw physical pointer
MMIO or volatile access
inline assembly execution
exception vector or branch entry
system-register write
barrier/TLBI execution
boot, guest, DMA, device, or multicore mechanism
new K0 command
hardware-translation or isolation theorem
```
