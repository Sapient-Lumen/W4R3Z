# Construction 003 — M0 AArch64 stage-2 placed value graph

## Bounded object

This construction closes one value-level rung only:

```text
exact M0-STATIC2 plan
  -> two selected 512-entry level-3 table values
  -> two root-owned three-level table-value chains
  -> pure finite walk
  -> exact recovered M0-STATIC2 plan
```

It is not a memory image with effect and not a live translation regime.

## Selected finite graph

| Item | Exact value |
|---|---:|
| Domains / roots | 2 |
| Levels per domain | 3 (L1, L2, L3) |
| Table values | 6 |
| Entries per table | 512 |
| Descriptors | 3,072 |
| Serialized table bytes | 24,576 |
| Nonzero descriptors | 38 |
| Leaf mappings | 34 |
| Distinct mapped physical pages | 33 |
| Cross-domain physical intersection | `{48}` |
| IPA bits | 39 |
| Start level | 1 |
| Selected graph FNV-1a64 | `32ec119640d7e72d` |

Placements are `0x40000000` through `0x40005000` in 4 KiB steps.  Alpha owns
indices 0–2 and beta owns indices 3–5.  Root records are `(domain=1, vmid=1,
root=0x40000000)` and `(domain=2, vmid=2, root=0x40003000)`.

## Independent C++20 paths

The hosted reference path uses dynamic maps/vectors to assemble sparse semantic
tables before copying them into the observation structure.  The constrained core
path uses only fixed arrays and direct index construction.  They share public value
types and selected constants, but not construction loops.

The walker checks:

1. domain and root-record identity;
2. 39-bit IPA bound;
3. exact root placement and level;
4. selected table-descriptor shape;
5. exact expected child placement for that root's owned chain;
6. selected level-3 descriptor shape; and
7. page offset preservation.

An absent descriptor yields a fault.  A malformed root, cross-domain child edge,
wrong level, duplicate/missing table, or altered leaf yields `MALFORMED_GRAPH`.

## Exact-image admission

`parse_selected_table_image` is intentionally not a general page-table parser.  It
accepts exactly 24,576 bytes and then compares against the selected canonical image.
All 196,608 single-bit mutations are rejected.  This is bounded drift and corruption
pressure, not cryptographic integrity or general parser correctness.

## Formal relation

`proof/M0_AArch64_S2_Graph.thy` reasons over exact natural-number/list values.  It
proves table placement/alignment, distinct roots and VMIDs, exact upper edges,
root-owned chains, table/image extents, exact pure walks, boundary faults, and exact
recovery of `m0_static2_plan`.

The proof does not model C++ evaluation, physical memory, Arm translation execution,
registers, cache/TLB state, exception behavior, DMA, or boot.

## Stop line

Do not add a generic table allocator, dynamic map API, register write, barrier, TLB
operation, exception vector, guest, device, or new K0 command to this construction.
Those are separate obligations and must be earned by a later bounded experiment.
