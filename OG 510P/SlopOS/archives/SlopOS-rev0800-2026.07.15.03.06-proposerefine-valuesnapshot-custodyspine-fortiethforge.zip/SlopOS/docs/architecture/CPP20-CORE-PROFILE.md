# C++20 core profile

The active core permits value types, fixed `std::array` storage, explicit loops,
scoped enumerations, `constexpr` helpers, and total return values.  It forbids
exceptions, RTTI, virtual dispatch, dynamic allocation during transitions, owning
raw pointers, ambient policy lookup, implicit narrowing, address identity, and
unchecked representation casts.

Core source is compiled with `-fno-exceptions -fno-rtti` where supported.  Every
external integer is range-checked before conversion.  Rights masks are validated
against the defined bit universe.  Array access is preceded by a bound check.

The profile is intentionally narrower than ordinary C++20.  Its eventual purpose
is not style consistency but a tractable implementation semantics.  A construct
that cannot be represented economically in KIR-0 should not enter the authoritative
transition path merely because the compiler accepts it.

## Finite arithmetic rule

Unsigned modulo behavior is not permission to wrap an authoritative counter.  Every
finite increment that participates in a formal relation must have an explicit
availability guard or an explicitly modeled modulo meaning.  DEC-0011 chooses the
former for `accepted_sequence`.
