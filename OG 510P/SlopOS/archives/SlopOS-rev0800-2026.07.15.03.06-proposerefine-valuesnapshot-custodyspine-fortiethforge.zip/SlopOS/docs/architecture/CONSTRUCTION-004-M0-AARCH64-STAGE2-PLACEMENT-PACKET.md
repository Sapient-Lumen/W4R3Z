# Construction 004 — M0 AArch64 stage-2 placement/admission packet

## Bounded purpose

Construction 004 adds one closed value and admission rung above the rev0779
placed graph.  It makes intended placement inspectable without performing
placement.

```text
M0-STATIC2 plan
  -> selected leaf values
  -> selected six-table graph value
  -> selected placement/admission packet
  -> exact admission ledger
  -X-> physical memory effect
```

## Selected packet

| Field | Exact value |
|---|---:|
| packet version | 1 |
| wire bytes | 512 |
| header bytes | 64 |
| graph bytes | 24,576 |
| graph FNV | `32ec119640d7e72d` |
| plan FNV | `cc05f08f4bbc162c` |
| semantic FNV | `a1d0b02ad4351902` |
| table records | 6 |
| root records | 2 |
| admission records | 10 |
| reserved zero bytes | 112 |
| complete one-bit mutations | 4,096 |

### Table records

| Ordinal | Owner | Level | Source | Bytes | Destination | Table FNV |
|---:|---:|---:|---:|---:|---:|---|
| 0 | 1 | 1 | 0 | 4096 | `0x40000000` | `3734cf8882c34ab6` |
| 1 | 1 | 2 | 4096 | 4096 | `0x40001000` | `d0e97a0840295346` |
| 2 | 1 | 3 | 8192 | 4096 | `0x40002000` | `c8bc3efc9e202248` |
| 3 | 2 | 1 | 12288 | 4096 | `0x40003000` | `73b1650800d402a6` |
| 4 | 2 | 2 | 16384 | 4096 | `0x40004000` | `a24d6f88207eaaf6` |
| 5 | 2 | 3 | 20480 | 4096 | `0x40005000` | `bd42b6e2e4767328` |

The source extents are offsets into the exact selected graph artifact.  The
destination fields are integer values only.  Neither field is interpreted as a
host pointer.

### Root ownership

Alpha binds domain 1 / VMID 1 to table ordinal 0 and owns ordinals 0–2.
Beta binds domain 2 / VMID 2 to table ordinal 3 and owns ordinals 3–5.
Both retain the rev0779 IPA width 39 and start level 1.

### Admission relation

```text
0 IMAGE
1 TABLE 0
2 TABLE 1
3 TABLE 2
4 TABLE 3
5 TABLE 4
6 TABLE 5
7 ROOT 0
8 ROOT 1
9 SEAL
```

A record is accepted only when it is the exact next selected record.
Unknown, duplicate, missing, stale, or reordered records do not mutate the
ledger.  `SEAL` is accepted only after all preceding records.

## Independent C++20 paths

### Hosted reference

The reference constructor uses `std::map`, `std::vector`, and ordinary hosted
containers.  Its ledger records accepted values in a vector.

### Constrained core

The constrained constructor uses fixed arrays and bounded loops.  Its ledger
has fixed capacity, performs no transition-time allocation, and uses no
exceptions, RTTI, raw owning pointers, volatile access, or address
dereference.

The two paths share data declarations and the selected predecessor graph, but
not construction loops or ledger transition storage.

## Wire admission

The wire is canonical little-endian.  Decoding checks magic, version, exact
offsets and counts, all reserved-zero fields, graph and plan identities,
record shapes, semantic fingerprint, selected value equality, and exact
length.  It is intentionally an exact selected-packet decoder, not a general
format negotiation surface.

FNV is a deterministic drift identity, not a cryptographic authenticator.
The complete one-bit mutation test is a bounded fence around this one 512-byte
value, not a general corruption theorem.

## Generated and checked artifacts

```text
generated/m0/aarch64-s2-placement-packet.txt
generated/m0/aarch64-s2-placement-packet.bin
proof/generated/M0_AArch64_S2_Placement_Packet_Generated.thy
proof/M0_AArch64_S2_Placement_Packet.thy
```

`slopos-aarch64-s2-packet --emit` generates them.  `--check` rejects drift.
Only an accepted basis-bound Isabelle session can promote mapped theorem rows.

## Non-claims

Construction 004 does not provide:

- owned physical-memory objects or byte copying;
- source/destination address interpretation;
- raw pointers, MMIO, volatile access, or assembly;
- VTTBR_EL2, VTCR_EL2, or HCR_EL2 programming;
- barriers, cache maintenance, or TLB invalidation;
- hardware translation or exception behavior;
- boot, guest execution, devices, DMA/SMMU, or multicore behavior;
- a C++ source, compiler, ABI, or binary theorem;
- CPU-memory or product-profile isolation.

## Next pressure

M0-P5 may build one pure fixed-capacity owned-memory value and an atomic
copy/readback relation.  The copied bytes must be observable through the pure
model with exact frame properties, but the experiment still may not interpret
the model as live physical memory.
