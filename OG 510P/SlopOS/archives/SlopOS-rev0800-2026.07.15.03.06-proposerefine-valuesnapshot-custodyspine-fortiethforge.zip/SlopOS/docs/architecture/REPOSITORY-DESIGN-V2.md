# Repository design V2 — typed subjects, directed dependencies, non-recursive evidence

## Six repository lanes

The repository is one tree with six ordered semantic lanes:

| Lane | Typical paths | Construction basis | Custody basis | Law |
|---|---|---:|---:|---|
| construction | source, proof, tests, docs, specs | yes | no | hash exactly; mutable only by deliberate revision |
| custody | `vault/` | no | yes | preserve exact bytes; never promote by co-location |
| evidence | `evidence/` | no | no | bind observations to a subject; never recurse into the subject |
| ignored | `.git`, `build*`, `.slopos-work` | no | no | local/transient; never package |
| transport | detached `.zip` | no | no | hash externally after closure |
| reject | unknown, symlink, special object | no | no | fail the manifest and office audit |

Classification is numeric-priority ordered. An archive under `vault/` is custody,
not generic transport; a `.zip` under `evidence/` remains evidence. A mandatory final
reject rule prevents accidental subject growth.

## Four identities that must not collapse

1. **Construction identity** — all living files that define behavior, proof source,
   office law, and current documentation.
2. **Custody identity** — exact preserved vault files and directories.
3. **Evidence-object identity** — each log/receipt as an observation of named
   construction or custody subjects.
4. **Transport identity** — final ZIP bytes, computed and retained outside the ZIP.

The C++20 manifest code emits stable lexical rows containing path, path class, audit
lane, object type, permission mode, byte count, and SHA-256. Evidence is excluded so
it can name a basis without recursively changing it.

## Living dependency direction

The P0 authority/refinement slice follows this dependency law:

```text
public authority value declarations
          ^
          |
production AuthorityCore / AuthorityReference
          ^                     ^
          | observation only    | observation only
independent refinement checker  tests / hosted harness

Isabelle abstract source  <--- no generated C++ parser or reverse dependency
```

More precisely:

- `slopos_authority` owns state and transition authority. It does not depend on the
  refinement checker.
- `AuthorityCore` and `AuthorityReference` may share command/value declarations,
  constants, and canonical observation structures. They may not share transition
  functions, validation helpers, state mutation helpers, or invariant checks.
- `slopos_authority_refinement` depends on the public value image and independently
  computes one PROPOSE expected step. It is an observer and cannot mutate production
  state.
- private test targets may compile source copies with a friend seam to reach terminal
  sequence values. No setter enters the production API.
- Isabelle source may share reviewed vocabulary, but it does not import a generated
  program or claim an exact C++ relation until that relation is separately proved.

This direction keeps a checker defect from becoming authority logic and prevents the
proof harness from silently becoming the implementation.

## Canonical value-image rule

Canonical text is presentation, not the representation boundary. A proof-facing
value image must be typed, total over its selected state, copy-only, and deterministic.
For rev0800, occupied proposals/leases are sorted into prefixes, unused tails are
exact defaults, resources are copied in full, and the finite sequence is explicit.
No claim is made about object bytes, padding, ABI, persistence, or wire compatibility.

## Vault recovery-pack boundary

A future storage-saving derivative may be content addressed, but only outside the
custody basis. Its minimum reversible record is:

```text
original archive path + SHA-256
member path + member kind + uncompressed length + payload SHA-256
container ordering/metadata needed for the chosen reconstruction claim
payload-object location
reconstruction result + exact original archive digest comparison
```

A payload-deduplicated tree that cannot reproduce or at least unambiguously map every
original container is an index, not a custody replacement. Rev0800 performs no
recompression, dedupe, or migration.

## Security boundary

The current walker is for a quiescent controlled tree. It rejects symlinks and
special objects and re-stats type, mode, and size after hashing, but it does not hold
descriptor-relative resolution against a hostile concurrent mutator. A future Linux
adapter may use descriptor-based APIs such as `openat2` beneath a stable root, but
that platform-specific claim must remain separate from the portable C++20 manifest
semantics.

## Provenance and approval boundary

SHA-256 detects changed bytes under its algorithm assumptions. It does not identify
an author, reviewer, builder, or approval policy. Attestation may later bind subject,
process, and verifier identity, but a digest by itself never authorizes construction,
proof currentness, release, or execution.
