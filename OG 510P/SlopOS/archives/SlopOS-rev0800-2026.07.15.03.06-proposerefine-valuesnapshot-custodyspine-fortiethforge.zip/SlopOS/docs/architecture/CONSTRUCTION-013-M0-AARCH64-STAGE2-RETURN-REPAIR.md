# Construction 013 — M0 AArch64 stage-2 return repair

## Purpose

Construction 013 makes the terminal word selected by Construction 012 current
through the source, object, loader, visibility, generated-proof, and ledger
layers without collapsing any layer into physical effect.

```text
terminal semantic selection
!= source repair
!= object regeneration
!= loader-value regeneration
!= visibility-value regeneration
!= live entry or execution
```

## Active surfaces

```text
spec/m0/aarch64-s2-activation.S
include/slopos/m0/aarch64_s2_object.hpp
src/m0/aarch64_s2_object.cpp
include/slopos/m0/aarch64_s2_loader.hpp
include/slopos/m0/aarch64_s2_visibility.hpp
src/m0/aarch64_s2_visibility.cpp

include/slopos/m0/aarch64_s2_return_repair.hpp
src/m0/aarch64_s2_return_repair.cpp
tools/slopos_aarch64_s2_return_repair_main.cpp
tests/test_aarch64_s2_return_repair.cpp
tests/test_aarch64_s2_return_repair_noalloc.cpp

generated/m0/aarch64-s2-return-repair.txt
generated/m0/aarch64-s2-return-repair.bin
proof/generated/M0_AArch64_S2_Return_Repair_Generated.thy
proof/M0_AArch64_S2_Return_Repair.thy
```

## Repaired bytes

The source appends exactly:

```text
  ret
```

The identified assembler replay produces the exact terminal bytes:

```text
c0 03 5f d6
```

at `.text` offset 36. The first 36 `.text` bytes remain the M0-P8 event-word
image. The ELF object remains 560 bytes because the section table layout shifts
inside the same selected finite object extent.

## Independent C++20 relation

The repair certificate carries both generations. It does not infer old values
from filenames or retain only the new tuple. This makes mixed-generation
rejection executable and visible.

The status precedence is:

```text
BAD_VERSION
BAD_EXTENT
BAD_TERMINAL_CONTRACT
BAD_LEGACY_TUPLE
BAD_CURRENT_TUPLE
BAD_PREFIX
BAD_TERMINAL_WORD
BAD_READINESS
BAD_SEMANTIC_FINGERPRINT
ACCEPTED
```

Wire-level magic, extent, integrity, and reserved-byte checks precede value
admission. Every rejected decode returns an empty candidate. Every rejected
formal transition returns the exact prior state.

## Selected wire

```text
magic                    SLOPRPR1
wire bytes                    512
one-bit mutations           4,096
old/new event prefixes           9 words each
stored wire integrity          FNV-1a
```

FNV is a deterministic currentness/corruption fence, not authentication.

## Current layer result

The repaired visibility assessment has a valid terminal observation:

```text
final instruction       RET X30
terminal kind           RETURN_X30
fallthrough word        0
```

Its readiness remains blocked because no external premise was discharged:

```text
visibility premises     required 0xffff, discharged 0
live return contract    required 0x0fff, discharged 0
entry ready             false
```

## Stop line

Construction 013 performs no:

```text
host-address interpretation
physical-memory write
mapping or permission installation
cache maintenance
instruction-cache synchronization
system-register access
inline assembly or compiler intrinsic
call or return execution
live X30 observation
exception path
boot or guest execution
DMA/SMMU/device operation
multicore operation
new K0 command
hardware-translation or isolation claim
```

## Falsification hooks

Reopen this construction if:

- the assembler replay changes any byte;
- the first nine instruction words change;
- the terminal word is not exactly `0xD65F03C0`;
- the object extent or metadata changes without an explicit new relation;
- any old/new mixed tuple is accepted;
- a generated artifact is stale;
- Isabelle rejects a mapped proposition; or
- a claim treats terminal presence as live entry readiness.
