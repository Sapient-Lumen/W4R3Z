# Construction 015 — M0 AArch64 caller-artifact cascade

## Purpose

Construction 015 turns the projected rev0792 caller into an exact current
**pure value artifact** without pretending that the artifact is machine-visible
or executed.

```text
projected BL/X30 edge
  -> source bytes
  -> one exact ELF object
  -> exact two-word text
  -> generation-checked pure page update
  -> finite admission and install relations
  -X-> publication, fetch, BL, X30, RET, or boot effect
```

## Active surfaces

```text
spec/m0/aarch64-s2-caller.S
generated/m0/aarch64-s2-caller.o

include/slopos/m0/aarch64_s2_caller_artifact.hpp
src/m0/aarch64_s2_caller_artifact.cpp
tools/slopos_aarch64_s2_caller_artifact_main.cpp
tests/test_aarch64_s2_caller_artifact.cpp
tests/test_aarch64_s2_caller_artifact_noalloc.cpp

generated/m0/aarch64-s2-caller-artifact.txt
generated/m0/aarch64-s2-caller-artifact.bin
generated/m0/aarch64-s2-caller-memory.bin
proof/generated/M0_AArch64_S2_Caller_Artifact_Generated.thy
proof/M0_AArch64_S2_Caller_Artifact.thy
```

Active implementation and all permanent executable harness code remain C++20.
Isabelle/HOL remains the sole proof-language exception.

## Closed artifact envelope

The constrained parser admits exactly one 528-byte ELF64 little-endian AArch64
relocatable object:

```text
program headers   0
sections          5
symbols           3
relocations       0
.text offset      64
.text extent      8
.text alignment   4
function size     8
```

Unknown or changed identification, file type, machine, header, section,
string-table, symbol-table, relocation, text, or object-identity values reject.
This is a closed specimen checker, not a general ELF parser.

## Pure memory relation

The prior and installed values each contain three 4 KiB pages. The middle page
contains the helper and caller. The transition requires the exact generation-2
preimage and commits one generation-3 value atomically:

```text
before target = helper[40] @ zero[4056]
after target  = helper[40] @ zero[24] @ caller[8] @ zero[4024]
```

The two guard pages are unchanged. Validation never mutates the input value.
Mixed generation, changed helper preimage, changed caller preimage, dirty
unrelated bytes, or stale predecessor identity rejects with exact frame.

## Independent implementations

The reference path:

- recognizes the complete selected object bytes;
- materializes facts and memory pages through hosted containers; and
- performs validate-then-copy installation.

The constrained path:

- reads fixed offsets only after explicit bounds checks;
- stores section, symbol, wire, and memory state in fixed arrays;
- performs a fixed-capacity atomic copy; and
- performs no observed allocation after warmup.

The paths share data declarations, selected constants, and fingerprint
primitives. They do not share object parsing or installation loops.

## Executable pressure

The C++20 harness checks:

- exact reference/core equality;
- source, object, text, and predecessor currentness;
- exact BL/NOP and helper `RET X30` values;
- all 1,688 source-bit mutations;
- all 4,224 object-bit mutations;
- all 4,096 wire-bit mutations;
- all 64 text-bit mutations;
- all 4,096 single-byte prior-target mutations;
- generation and mixed-preimage framing;
- exact caller readback and helper/gap/suffix/guard preservation; and
- warmed constrained-path no-allocation.

The assembler doctor and replay are unconditional tests. Tool absence or object
drift cannot silently remove the edge from the test graph.

## Formal relation

The generated theory exports exact finite values and byte lists. The handwritten
theory defines:

- one closed request record and total status relation;
- one admission transition;
- one three-page pure-memory state;
- one total atomic install relation;
- exact source/object/text and range lemmas;
- exact byte-frame lemmas;
- precedence and mixed-generation rejection lemmas;
- admission/install frame lemmas; and
- preservation of the caller-edge predecessor theorem.

```text
C++20 selected bytes and values
  -> C++20 generated Isabelle constants      currentness edge
  -> Isabelle finite list/state relation      checked theorem
  -X-> C++20 or assembler semantics
  -X-> machine memory or Arm execution
```

## Stop line

Construction 015 performs no:

```text
host pointer or physical-address access
page-table or mapping update
permission installation
cache maintenance
inline assembly or compiler intrinsic
BL, NOP, RET, BR, BLR, or ERET execution
live X30 read or write
stack, exception, scheduler, or boot mechanism
DMA/SMMU/device mechanism
multicore behavior
new K0 command
hardware translation or isolation theorem
```
