# Construction 007 — finite AArch64 stage-2 architecture-event adequacy

## Position on the ladder

```text
closed policy
  -> admitted plan
  -> selected descriptor values
  -> root-owned graph values
  -> placement/admission packet
  -> pure owned-memory installation
  -> pure cold-activation intent protocol
  -> conditional architecture-event certificate       [this construction]
  -X-> instruction realization / source / execution / hardware effect
```

Construction 007 narrows one question: *if* the selected source, feature, memory,
cold-start, privilege, synchronization, and noninterference premises hold, does
the twelve-label intent protocol expose a complete closed event ordering for
the next instruction-selection experiment?

The answer for the selected finite specimen is yes.  The premises themselves
remain open.

## Data model

The active value has:

- exact source identities for Arm ARM DDI 0487 M.c and the 2026-03 AArch64
  register index;
- thirty-two named premise bits, all required;
- twelve selected feature bits, all required;
- the corrected M0-P6 activation/control identities;
- the exact rev0784 activation/HCR identities as rejected lineage;
- twelve protocol-to-event bindings;
- ten distinct ordered abstract events;
- one semantic fingerprint;
- one deterministic 256-byte wire and wire fingerprint.

The first and last bindings are value-only.  The ten interior bindings map to
ordinals zero through nine without gaps.

## C++20 reference and core

`build_reference_certificate()` uses vector-backed intermediate collections.
`build_core_certificate()` writes the fixed-capacity value directly.  Admission
is a total function over the finite certificate.  Wire decoding is strict:
magic, exact extent, fingerprint, zero reserved bytes, typed fields, semantic
identity, and selected relation must all hold.

Rejection creates no authoritative state.  The value checker has no mutable
machine state to repair or partially apply.

## Mutation and allocation pressure

The harness flips every one of 2,048 bits in the selected 256-byte wire.  Every
mutant rejects.  This is exact bounded pressure around the selected wire; it is
not cryptographic integrity, parser completeness, or a claim about arbitrary
formats.

After warmup, the constrained build/serialize/decode/status path performs no
observed global allocation.  This observation does not prove absence of all
allocation or undefined behavior under every compiler/platform.

## Formal relation

The Isabelle model contains:

- a closed request record;
- a total precedence-ordered status function;
- one admitted-state constructor;
- a rejection-frame theorem;
- exact generated source/control/mapping constants;
- legacy tuple rejection;
- exact binding/event image and distinctness;
- preservation of the already-proved sealed M0-P6 run.

The C++20 and Isabelle artifacts are kept current by generated source checks and
basis-bound proof evidence.  Formal C++ and formal Arm correspondence remain
separate open obligations.

## Stop line

This construction contains no inline assembly, compiler intrinsic, system
register access, physical address dereference, volatile/MMIO access, barrier,
TLBI, cache maintenance, exception path, guest, boot, DMA/SMMU/device behavior,
multicore behavior, new K0 object, or isolation theorem.
