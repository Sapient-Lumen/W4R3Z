# Construction 018 — M0 AArch64 EL2 observation chamber

## Purpose

Construction 018 is the first SlopOS artifact to execute on an AArch64 system
emulator. It is an observation chamber, not a boot path and not a stage-2
activation mechanism.

```text
M0-P13R finite host-publication value
  -> exact QEMU/observer/report chamber
  -> finite C++20 observation certificate
  -> finite Isabelle value theorem
  -X-> hardware truth, publication, activation, execution, isolation
```

## Repository surfaces

```text
include/slopos/m0/aarch64_el2_observation.hpp
src/m0/aarch64_el2_observation.cpp
include/slopos/host/qemu_el2_observer.hpp
src/host/qemu_el2_observer.cpp
tools/slopos_aarch64_el2_observation_main.cpp
tests/test_aarch64_el2_observation.cpp
tests/test_aarch64_el2_observation_noalloc.cpp
tests/test_qemu_el2_observer.cpp

spec/m0/aarch64-el2-observer.S
spec/m0/aarch64-el2-observer.ld
generated/m0/aarch64-el2-observer.elf
generated/m0/aarch64-el2-observation.txt
generated/m0/aarch64-el2-observation.bin
proof/generated/M0_AArch64_EL2_Observation_Generated.thy
proof/M0_AArch64_EL2_Observation.thy

toolchains/qemu-aarch64.lock
toolchains/aarch64-el2-observer.lock
tools/platform/bootstrap-qemu-aarch64-cloudtainer.sh
```

## Permanent-language boundary

The model, supervisor, parser, generator, mutation harness, evidence collector,
and office remain C++20. Isabelle/HOL remains the theorem-language exception.
The 1,719-byte observer assembly is a separately identified pre-runtime entry
exception. It owns no K0 semantics and exposes no reusable privileged API.

## Finite certificate

The canonical certificate is 512 bytes. It binds:

- sealed M0-P13R contract and live-receipt identities;
- exact QEMU extent, FNV, version, machine, CPU, and command identities;
- exact observer source/linker/ELF extents and FNV identities;
- exact report extent and FNV identity;
- exact eight-register order and values;
- six decoded finite fields;
- one result code;
- twelve required/observed value bits; and
- fourteen required but zero discharged machine-premise bits.

A stored FNV provides deterministic currentness/corruption pressure, not
cryptographic authenticity.

## Independent paths

The hosted reference report parser uses streams and vector-backed intermediate
values. The constrained parser uses fixed prefixes, fixed offsets, fixed arrays,
and no transition-time allocation. The reference certificate builder copies
through hosted collections; the core builder assigns fixed arrays directly.

The two paths share closed declarations and selected constants, not report
parsing or construction loops.

## Process chamber

The C++20 supervisor invokes:

```text
qemu-system-aarch64
-L <pinned-rootfs>/usr/local/share/qemu
-no-user-config
-machine virt-10.0,virtualization=on,secure=off,highmem=off,
         dtb-randomness=off,gic-version=3
-cpu cortex-a57
-accel tcg,thread=single
-smp 1
-m 64M
-display none
-serial none
-monitor none
-nodefaults
-no-reboot
-semihosting-config enable=on,target=native
-device loader,file=<exact-observer.elf>,cpu-num=0
```

The supervisor uses a process group so timeout or output overflow can terminate
the entire chamber. It combines stdout/stderr intentionally because the
selected semihosting channel writes to the QEMU process stream. The exact
report, not its stream origin, is the admitted observation artifact.

## Observer reproducibility

The image-current test executes exactly:

```text
/usr/local/swift/usr/bin/clang
  --target=aarch64-none-elf -march=armv8-a -c <source> -o <object>

/usr/local/swift/usr/bin/ld.lld
  -T <linker-script> <object> -o <elf>
```

It then byte-compares the reconstructed ELF with the selected generated image.
This is one identified conformance replay, not a general assembler/linker
theorem.

## Executable pressure

The current harness establishes:

```text
reference/core report agreement
reference/core certificate agreement
exact selected wire roundtrip
4,096 / 4,096 one-bit mutations rejected
status-precedence examples
negative report classifications
no observed allocation on the warmed constrained value path
exact QEMU doctor
exact observer rebuild
live exact report and exit
ambient LD_PRELOAD removed in the child
```

A live receipt's semantic identity excludes elapsed wall-clock time. Timing is
reported as diagnostic data only.

## Formal relation

The generated theory exports natural constants and finite lists. The handwritten
theory defines one total request/status relation, one admitted predicate, one
machine-discharge predicate, and one state transition. Its propositions concern
only exact generated finite values.

## Stop line

Construction 018 contains no:

```text
stage-2 control write
page-table mutation
DSB / ISB / TLBI
BL / X30 / RET
stack or heap in the observer
guest payload
scheduler
exception vector
real boot chain
DMA, SMMU, device, or interrupt mechanism
multicore behavior
new K0 command
hardware or isolation theorem
```

## Falsification hooks

Reopen or reject the chamber when:

- exact QEMU, observer, report, command, or predecessor bytes drift;
- the observer rebuild is not byte-identical;
- QEMU no longer reports the selected machine/CPU profile;
- the live run times out, emits extra output, or exits nonzero;
- the finite parser paths disagree;
- an authoritative source contradicts the selected register-field screening;
- Isabelle rejects a mapped proposition; or
- any claim crosses from emulator observation into hardware or effect.
