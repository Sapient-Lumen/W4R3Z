# Construction 016 — M0 AArch64 caller readiness assessment

## Purpose

Construction 016 turns the sealed rev0793 pure artifact into a closed readiness
question without laundering design values into machine effect.

```text
current generation-3 caller/helper pure value
  -> exact value facts
  -> exact machine-premise inventory
  -> exact ordered readiness assessment
  -> accepted blocked state
  -X-> publication, permission, visibility, entry, execution, or return
```

## Active surfaces

```text
include/slopos/m0/aarch64_s2_caller_readiness.hpp
src/m0/aarch64_s2_caller_readiness.cpp
tools/slopos_aarch64_s2_caller_readiness_main.cpp
tests/test_aarch64_s2_caller_readiness.cpp
tests/test_aarch64_s2_caller_readiness_noalloc.cpp

generated/m0/aarch64-s2-caller-readiness.txt
generated/m0/aarch64-s2-caller-readiness.bin
proof/generated/M0_AArch64_S2_Caller_Readiness_Generated.thy
proof/M0_AArch64_S2_Caller_Readiness.thy
```

All permanent executable implementation and harness code is C++20. Isabelle/HOL
is the sole proof-language exception.

## Closed value shape

The assessment contains:

```text
12 value-requirement observations
14 machine-premise discharge bits
16 ordered assessment steps
one intended entry observation
one 512-byte canonical wire
one semantic FNV
one wire FNV
```

The selected value observes every value requirement and discharges no machine
premise. Consequently it is internally valid while remaining blocked.

## Independent builders

The hosted reference path constructs requirement, premise, and step collections
through hosted containers before closing the result. The constrained path fills
fixed arrays directly. Shared surfaces are limited to closed types, enum codes,
selected constants, wire offsets, and fingerprint primitives.

The builders do not share an assessment-construction loop.

## Wire and rejection frame

The exact 512-byte little-endian wire binds all predecessor identities, masks,
ranges, words, entry fields, steps, readiness, and semantic identity. Reserved
bytes are canonical zero. The decoder checks magic, extent, wire FNV, and
reserved bytes before admitting fields.

A rejected decode returns an empty value. A rejected formal transition returns
the exact prior state. No failure path repairs, normalizes, partially discharges,
or advances the assessment.

## Executable evidence

The permanent C++20 tests establish only the selected bounded specimen:

- reference/core equality;
- exact predecessor and artifact identities;
- exact requirement and premise masks;
- exact range/word/entry values;
- exact status/readiness precedence;
- strict wire round-trip;
- rejection of all 4,096 one-bit wire mutations;
- rejection of all 120 pairwise step swaps; and
- no observed allocation on the warmed constrained build/serialize/decode/status
  path.

Two compilers, sanitizers, and mutation pressure remain conformance evidence, not
ISO C++ or machine theorems.

## Formal relation

The generated theory exports natural values and finite lists. The handwritten
theory defines one request record, one total status relation, one total readiness
relation, one admitted predicate, one entry-ready predicate, and one total state
transition.

The checked proposition family is finite-value currentness and framing. It does
not include memory publication, MMU behavior, caches, registers, or instruction
execution.

## Stop line

Construction 016 contains no:

```text
raw host or physical pointer use
mmap, mprotect, or memory writer
page-table or permission installation
volatile, MMIO, assembly, or compiler intrinsic
cache or TLB maintenance
register read or write
instruction fetch or execution
exception vector or stack
boot or guest
DMA/SMMU/device mechanism
multicore behavior
new K0 command
hardware-translation or isolation theorem
```

## Falsification hooks

Reopen M0-P12R when any of these occurs:

- a sealed predecessor identity changes;
- the generation-3 page or caller/helper ranges change;
- a value requirement cannot be derived from current source;
- a machine premise is accidentally treated as observed;
- a step reorder is admitted;
- a selected blocked value reports entry-ready; or
- any office claim crosses the stop line.
