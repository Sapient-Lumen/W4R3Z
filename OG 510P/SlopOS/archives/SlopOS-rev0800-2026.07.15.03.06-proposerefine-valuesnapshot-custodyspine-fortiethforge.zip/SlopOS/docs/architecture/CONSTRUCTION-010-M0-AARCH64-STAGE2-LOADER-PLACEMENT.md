# Construction 010 — M0 AArch64 stage-2 loader placement

## Purpose

Construction 010 inserts a pure placement/copy rung between the exact M0-P9
object specimen and any executable-visibility or entry mechanism.

```text
M0-P9 exact object and text bytes
  -> one numeric destination and permission-intent value
  -> one pure three-page initial state
  -> one total validate-then-copy relation
  -> one exact installed byte-array value
  -X-> mapping, cache visibility, entry, execution, or effect
```

## Active files

```text
include/slopos/m0/aarch64_s2_loader.hpp
src/m0/aarch64_s2_loader.cpp
tools/slopos_aarch64_s2_loader_main.cpp
tests/test_aarch64_s2_loader.cpp
tests/test_aarch64_s2_loader_noalloc.cpp
generated/m0/aarch64-s2-loader-placement.txt
generated/m0/aarch64-s2-loader-placement.bin
generated/m0/aarch64-s2-loader-memory.bin
proof/generated/M0_AArch64_S2_Loader_Generated.thy
proof/M0_AArch64_S2_Loader.thy
```

All permanent executable machinery is C++20. Isabelle/HOL is the approved
proof-language exception.

## Independent implementations

The reference builder materializes text and page collections through hosted
vectors before producing the closed values. The core builder and installer use
fixed arrays, explicit loops, exact-width fields, and validation-before-commit.
They share selected declarations and fingerprint primitives, not construction
or installation loops.

## Canonical wire

The 256-byte little-endian wire contains exact extents, destination and prior
interval values, owner and permission intent, predecessor identities, text
identity, the complete 36-byte payload, canonical zero reserve, and a terminal
wire FNV. Magic, extent, wire FNV, and reserved bytes are checked before value
admission. A rejected decode returns an empty placement.

## Pure memory relation

The initial and installed values each contain three 4 KiB byte arrays. No array
is interpreted as an addressable host object. The middle page is the only
installable page. The core checks all metadata, identities, roles, guards, and
zero target bytes before copying; commit occurs only after every precondition
passes.

## Falsification corpus

The harness checks all bits of the wire and selected payload, every target-byte
dirty position, and every guard-byte mutation. Rejection must return the exact
input memory. Success must equal the generated installed value, return exact
36-byte readback, preserve the 4,060-byte zero tail, and preserve both guards.

## Generated currentness

The C++20 generator owns one manifest, one 256-byte wire, one 12,288-byte pure
memory image, and one Isabelle constant theory. `--check` byte-compares every
artifact to the active construction.

## Stop line

Construction 010 contains no:

```text
general ELF loader or relocation engine
host/physical pointer or raw address dereference
memory allocation or executable host mapping
page-table, MPU, VMA, or permission update
D-cache or I-cache operation
barrier, TLBI, branch, exception entry, or register setup
inline assembly or privileged execution
boot, guest, DMA/SMMU/device, or multicore mechanism
new K0 command
hardware-translation or isolation theorem
```
