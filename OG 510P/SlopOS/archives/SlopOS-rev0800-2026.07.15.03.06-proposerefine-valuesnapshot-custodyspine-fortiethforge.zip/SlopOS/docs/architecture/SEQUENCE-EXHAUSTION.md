# Accepted-sequence exhaustion

**Posture:** implemented C++20 source semantics in rev0764; formal DERIVE
propositions first checked in rev0766 and replayed on every theorem-bearing close
**Source conformance:** `OBL-SEQUENCE-SOURCE-001`
**Concrete boundary witness:** `OBL-SEQUENCE-OPERATIONS-001`
**Checked formal schema/DERIVE scope:** `OBL-SEQUENCE-SCHEMA-001`,
`OBL-SEQUENCE-DERIVE-001`
**Umbrella correspondence debt:** `OBL-SEQUENCE-BOUND-001`
**Focused universal implementation debt:** `OBL-SEQUENCE-REFINE-001`
**Decision:** DEC-0011

## Problem

The formal `accepted_sequence` is a natural number. The C++20 machine stores
`std::uint64_t`. Starting from zero makes wrap operationally remote, but does not
make natural-number `Suc` equivalent to finite unsigned arithmetic. A proof-oriented
finite machine must define its terminal state.

The sequence is authoritative machine state only in the sense that transitions and
results carry it; it is not authority to perform an operation. Silent wrap would
violate the formal relation and collapse distinct accepted histories onto the same
observation.

## Implemented rule

`Status::sequence_exhausted` is a distinct deterministic rejection. An operation
whose ordinary checks would otherwise accept rejects without mutation when the
current sequence is `2^64 - 1`.

Existing semantic checks retain precedence:

```text
input/shape
  -> existence/conflict
  -> authority/ownership
  -> operation-specific capacity or availability
  -> sequence_available
  -> commit
```

The final gate is present in generated `DERIVE`, and independently in model/core
`MAP`, `SEND`, and `RECEIVE`. Every accepted path uses
`accepted_sequence_advance`; the helper produces no successor at terminal state.

## Checked formal shape

The abstract state remains natural-valued. The admitted proof relation is:

```text
SEQ-REP(n, u) := n = unsigned_value(u) ∧ n < 2^64
available(n)  := n < 2^64 - 1
available(u)  := u != UINT64_MAX
```

The pinned Isabelle session accepts exact mapped lemmas establishing the finite
progress-or-terminal split and generated DERIVE agreement with D0, including
sequence exhaustion and successful proof-value sequence advance. The theorem map
records premises and exclusions.

Those theorems are not a theorem about C++ `uint64_t` evaluation or compiler
lowering. Formal MAP/SEND/RECEIVE remain stubs. Their concrete sequence gates are
tested but are not elevated into formal refinement claims.

## Boundary construction

DEC-0012 permits one private compile-time test peer because executing the terminal
number of transitions is infeasible. The production machine API, command set,
bootstrap plan, and trace language contain no sequence mutation operation.

The boundary witness covers:

- maximum-minus-one acceptance to maximum for all four operations;
- terminal rejection and exact state frame for all four;
- preservation of prior invalid, absent, conflict, authority, full, and empty
  results at terminal state.

It records 25 cases with FNV-1a `1b29e9f3f779ae41`.

## Remaining evidence boundary

The source rule is implemented, generated artifacts are current, finite C++
witnesses exercise the boundary, and the named formal DERIVE propositions are
checked. The C++ capability-array/state relation, actual unsigned expression
semantics, compiler behavior, and formal semantics for non-DERIVE operations remain
open universal edges. `OBL-SEQUENCE-REFINE-001` and the broader
`OBL-SEQUENCE-BOUND-001` therefore stay open.

## Rejected alternatives

- **Wrap:** conflicts with formal naturals and history distinction.
- **Saturate while continuing to accept:** loses monotone accepted-event identity.
- **Use a wider integer:** only moves an undefined terminal rule.
- **Assume exhaustion unreachable:** an operational estimate is not machine
  semantics.
- **Expose a setter/command:** creates an unjustified runtime mutation surface.
