# Construction 014 — M0 AArch64 caller-edge and X30 contract

## Purpose

Construction 014 closes the smallest honest value relation between the repaired
helper and a possible caller. It deliberately leaves the caller artifact absent.

```text
current repaired helper value
  -> projected caller addresses and instruction words
  -> exact PC+4/X30 relation
  -> total admission relation
  -X-> caller bytes, fetch, call, register state, or return effect
```

## Active surfaces

```text
include/slopos/m0/aarch64_s2_caller_edge.hpp
src/m0/aarch64_s2_caller_edge.cpp
tools/slopos_aarch64_s2_caller_edge_main.cpp
tests/test_aarch64_s2_caller_edge.cpp
tests/test_aarch64_s2_caller_edge_noalloc.cpp

generated/m0/aarch64-s2-caller-edge.txt
generated/m0/aarch64-s2-caller-edge.bin
proof/generated/M0_AArch64_S2_Caller_Edge_Generated.thy
proof/M0_AArch64_S2_Caller_Edge.thy
```

## Selected finite layout

```text
0x40008000 .. 0x40008028  current repaired helper
0x40008028 .. 0x40008040  current zero padding
0x40008040                 projected BL helper
0x40008044                 projected NOP continuation / X30 value
0x40008048 .. 0x40009000  current zero page remainder
```

The projected words are deliberately not written by this construction. Both
independent builders read zeros at `0x40008040` and `0x40008044` from the current
pure loader memory.

## BL value relation

For A64 `BL`, the selected immediate relation is:

```text
target        = call_site + sign_extend(imm26 << 2)
continuation  = call_site + 4
```

For the selected values:

```text
call_site     = 0x40008040
target        = 0x40008000
delta         = -64
imm26         = 0x03fffff0
word          = 0x97fffff0
continuation  = 0x40008044
```

The C++20 encoder checks alignment and signed 28-bit branch reach. The decoder
checks the opcode and reconstructs the selected target. This is finite word
arithmetic, not a theorem about instruction execution.

## Independent C++20 paths

The hosted reference path uses hosted intermediate collections and the
reference loader install. The constrained path uses fixed arrays and the core
loader install. They share closed declarations and selected constants, not a
construction loop.

The harness checks:

- exact reference/core equality;
- selected predecessor identities;
- exact range and permission values;
- BL encode/decode consistency;
- current zero words at both projected caller addresses;
- current `RET X30` helper terminal word;
- total status precedence and empty rejection frame;
- exact 512-byte serialization;
- rejection of all 4,096 one-bit mutations; and
- no observed allocation after warming the constrained path.

## Formal relation

The generated theory exports natural values, one signed delta, and finite
requirement lists. The handwritten theory defines one request record, one total
status relation, one admission state transition, exact finite lemmas, and a
preservation theorem for the return-repair relation.

```text
C++20 selected values
  -> generated Isabelle constants       currentness edge
  -> Isabelle finite relation            checked proposition
  -X-> C++20 language semantics
  -X-> Arm instruction execution
  -X-> live register or return effect
```

## Stop line

Construction 014 performs no:

```text
source/object generation for the caller
pure or physical caller installation
host pointer or physical-address access
cache maintenance or executable visibility effect
inline assembly or compiler intrinsic
BL, BLR, RET, BR, or NOP execution
live X30 read or write
stack, exception, scheduler, or boot mechanism
DMA/SMMU/device mechanism
multicore behavior
new K0 command
hardware translation or isolation theorem
```
