# Construction 002 — M0-STATIC2 closed policy and abstract install ledger

## Purpose

This is the first construction below the hosted K0 authority model and above any
architecture-specific translation mechanism. It tests whether SlopOS can carry one
closed resource policy through admission, deterministic planning, installation
accounting, generated proof values, and explicit non-claims.

## Seven policy records

The 192-byte wire contains a 24-byte header and seven 24-byte records:

| Record | Meaning |
|---|---|
| 0 | physical aperture `[0,64)` |
| 1 | monitor reservation `[0,16)` |
| 2 | domain 1 identity, virtual bases, label |
| 3 | domain 2 identity, virtual bases, label |
| 4 | domain 1 private physical range `[16,32)` |
| 5 | domain 2 private physical range `[32,48)` |
| 6 | shared physical page 48 and both virtual destinations |

The header binds magic, version, record count, total byte count, and FNV-1a payload
fingerprint. Decode checks every field, reserved zeros, range arithmetic, ownership,
permission masks, exact selected policy equality, and the payload fingerprint. This
is a closed artifact, not a forward-compatible schema.

The mutation witness flips each of 1,536 bits independently and requires every
single-bit mutation to be rejected. This is bounded corruption evidence; it is not a
cryptographic integrity claim.

## Plan compilation

The constrained planner loops over the two admitted domains and appends fixed-array
records. The hosted reference planner instead scans the physical aperture, discovers
membership, constructs a dynamic collection, and sorts it canonically. They share
value types and policy admission, but not plan enumeration logic.

Both must produce:

```text
mapping_count             34
private mappings          32
shared mappings            2
distinct physical pages   33
only cross-domain alias   physical page 48
virtual key uniqueness    (domain, virtual page)
```

## Install ledger

The installer is not a page-table writer. It is a small state machine that answers:
“Has the complete admitted abstract plan been installed exactly once?”

Commands are one exact mapping record or `seal`. An unknown mapping, duplicate,
incomplete seal, or post-seal command is rejected and frames canonical state. Record
order is intentionally irrelevant; forward and reverse-order traces converge. The
constrained implementation uses no transition-time allocation, verified by the
C++20 allocation witness.

## Refinement ladder position

```text
closed policy bytes
  -> admitted Static2Policy value                 C++ CONFORMANCE/BOUNDED
  -> exact abstract install plan                  Isabelle THEOREM + C++ oracle
  -> install-completion ledger                    C++ BOUNDED
  -> architecture descriptor/table image          NOT STARTED
  -> live roots and boot selection                 NOT STARTED
  -> CPU-memory isolation claim                    NOT STARTED
```

Every arrow remains separately named. The installation ledger is useful preparation
for later effect witnesses, but it is not itself hardware effect.
