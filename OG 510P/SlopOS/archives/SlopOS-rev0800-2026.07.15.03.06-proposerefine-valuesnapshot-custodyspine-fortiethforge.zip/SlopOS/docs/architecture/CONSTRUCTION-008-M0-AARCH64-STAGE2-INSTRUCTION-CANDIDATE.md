# Construction 008 — M0 AArch64 stage-2 instruction candidate

## Purpose

Construction 008 is the first exact instruction-value rung below the M0-P7
architecture-event certificate. It is intentionally smaller than a source file,
object file, executable image, boot path, or architecture semantics.

```text
M0-P5 exact installed byte value
  -> M0-P6 finite cold-activation labels
  -> M0-P7 conditional abstract architecture events
  -> M0-P8 exact instruction-value candidate
  -X-> source / object / loader / execution / effect
```

## Repository surfaces

```text
include/slopos/m0/aarch64_s2_instruction.hpp
src/m0/aarch64_s2_instruction.cpp
tools/slopos_aarch64_s2_instruction_main.cpp
tests/test_aarch64_s2_instruction.cpp
tests/test_aarch64_s2_instruction_noalloc.cpp

generated/m0/aarch64-s2-instruction-candidate.txt
generated/m0/aarch64-s2-instruction-candidate.bin
proof/generated/M0_AArch64_S2_Instruction_Generated.thy
proof/M0_AArch64_S2_Instruction.thy
```

All active implementation and harness code is C++20. Isabelle/HOL is the
approved proof-language exception.

## Candidate shape

The value has:

```text
three register-entry records
ten realization records
nine 32-bit instruction words
one 512-byte canonical wire
one semantic FNV
one wire FNV
```

The realization row for `PUBLISH_TABLE_BYTES` uses
`PRIOR_OWNED_MEMORY_VALUE`, has no instruction ordinal, and carries no
instruction word. The other nine rows use `A64_INSTRUCTION`, ordinals zero
through eight, and exact instruction words.

## Independent implementations

The hosted reference path uses vector-backed intermediate collections before
copying into the closed candidate. The constrained path assigns only fixed
arrays.

Shared surfaces are limited to:

- closed types;
- enum codes;
- selected constants;
- serialization field layout; and
- fingerprint primitives.

The two builders do not share a construction loop.

## Wire layout

The selected 512-byte little-endian wire contains:

```text
0x000..0x007  magic "SLOPINS1"
0x008..0x017  version and exact counts
0x018..0x04f  source, predecessor, and semantic identities
0x050..0x07f  three 16-byte register-entry records
0x080..0x11f  ten 16-byte realization records
0x120..0x143  nine 32-bit words
0x144..0x1f7  canonical zero reserve
0x1f8..0x1ff  wire FNV over bytes 0x000..0x1f7
```

Reserved bytes and record-reserved fields must be zero. The decoder checks
magic, extent, wire FNV, and reserved bytes before constructing a value. A
rejected decode returns an empty candidate.

## Executable evidence

The C++20 tests establish only the selected bounded specimen:

- reference/core equality;
- exact predecessor identity binding;
- exact register-entry values;
- exact event order and realization shape;
- exact nine-word image;
- status precedence;
- exact wire round-trip;
- all 4,096 one-bit mutations rejected;
- no observed allocation on the warmed constrained path.

Sanitizers and two compilers remain conformance evidence. They are not an ISO
C++ source theorem.

## Formal relation

The generated theory exports only natural values and finite lists. The
handwritten theory defines:

- one request record;
- one total status relation;
- one admitted predicate;
- one state transition;
- exact generated-value lemmas;
- exact predecessor-binding lemmas;
- explicit rejection-precedence lemmas;
- rejection-frame theorem;
- selected admission theorem; and
- preservation of the accepted M0-P7 adequacy certificate.

The theorem boundary is the finite generated value relation. No theorem
contains an Arm instruction-step relation.

## Trust and currentness

The active chain is:

```text
C++20 selected constants
  -> C++20 generated manifest / binary / Isabelle constants
  -> generated-currentness check
  -> construction-basis identity
  -> isolated Isabelle2025-2 session
  -> exact theorem-ledger rows
```

Every arrow is named. No arrow is silently promoted into source, binary,
execution, or hardware correspondence.

## Failure behavior

Malformed wire values reject before admission. Semantically changed candidates
reject at a deterministic precedence. The formal rejected transition returns
the exact prior state. Neither rejection path repairs, normalizes, partially
admits, or advances the candidate.

## Stop line

Construction 008 contains no:

```text
inline assembly
compiler intrinsic
ELF parser
object bytes
relocation processing
loader
raw pointer or host-address interpretation
system-register access
volatile or MMIO
privileged instruction execution
barrier or TLBI completion
exception path
boot or guest
DMA/SMMU/device mechanism
multicore behavior
new K0 command
hardware-translation theorem
isolation theorem
```

## Falsification hooks

M0-P8 must be reopened when any of these occurs:

- a pinned normative source contradicts a selected word or operand;
- the selected M0-P7 event relation changes;
- an exact source/object specimen cannot produce the word image;
- the entry-value contract proves insufficient;
- a formal Arm model rejects the sequence or assumptions;
- a generated-currentness or theorem-ledger check fails; or
- any claimed implication crosses the stop line.
