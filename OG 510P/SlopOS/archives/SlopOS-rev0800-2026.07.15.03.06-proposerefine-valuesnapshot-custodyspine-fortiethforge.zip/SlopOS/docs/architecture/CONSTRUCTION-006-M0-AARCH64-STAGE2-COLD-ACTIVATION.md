# Construction 006 — M0 AArch64 stage-2 cold-activation value machine

## Bounded purpose

Construction 006 adds one finite transition rung above the pure installed
memory value:

```text
canonical installed pure memory
  + selected graph/packet/admission identities
  + selected root/control integers
  + twelve intent labels
  -> total fail-closed protocol state machine
  -> one sealed canonical prefix
  -X-> instruction or hardware effect
```

It exists to let implementation and theorem work discover ordering,
currentness, state-framing, and identity mistakes before privileged code
exists.

## Request shape

`ActivationRequest` carries:

- exact rev0781 memory generation, memory FNV, and installed-byte FNV;
- exact packet, graph, and sealed-admission FNVs;
- root domain, VMID, IPA width, start level, PA width, VMID width, granule,
  and root-table integer value;
- selected `VTCR_EL2`, `VTTBR_EL2`, and `HCR_EL2` integer values; and
- the complete twelve-label protocol.

Every field is rechecked on every transition.  That redundancy is deliberate:
a protocol prefix cannot silently inherit authority from an unbound external
request object.

## State shape

The constrained state stores:

- a phase in `0..12`;
- twelve monotonic phase facts and a sealed fact;
- the accepted fixed-capacity protocol prefix;
- installed-memory, packet, graph, and admission identities after phase 1;
- the selected `VTCR_EL2` value after phase 4;
- root identity and `VTTBR_EL2` after phase 5; and
- the selected `HCR_EL2` value after phase 10.

`activation_state_well_formed` defines one canonical value for every reachable
phase.  Prefix cells beyond the phase are `NONE`; each selected field is zero
until the phase that admits it.

## Transition shape

```text
advance(request, candidate):
  reject malformed current state
  reject sealed state
  validate request categories in fixed precedence
  require candidate == selected_protocol[phase]
  apply exactly one phase mutation
  increment phase
```

The reference and core implementations duplicate the validation and transition
logic using different storage.  The oracle compares full observations and
snapshots after every case.

## Exhaustive finite pressure

For each of twelve canonical prefix states, the harness tries every label in
the twelve-label alphabet:

```text
12 phases * 12 candidate labels = 144 reachable choices
12 accepted
132 rejected with exact state frame
```

Additional fixtures mutate state shape and every request category.  The test
establishes that malformed state precedes sealed-state handling and that the
selected run seals exactly at phase 12.

## Selected control decomposition

The C++20 construction checks the selected bit packing explicitly:

```text
VTCR_EL2 =
  T0SZ 25
  SL0 1
  IRGN0 1
  ORGN0 1
  SH0 3
  TG0 0
  PS 2
  VS 0
  DS 0
  = 0x23559

VTTBR_EL2 = (VMID 1 << 48) | 0x40000000
          = 0x0001000040000000

HCR_EL2 selected value = VM bit mask = 1
```

This is selected integer algebra only.  Architecture field interpretation and
protocol adequacy remain separate obligations.

## Artifacts

```text
include/slopos/m0/aarch64_s2_activation.hpp
src/m0/aarch64_s2_activation.cpp
tools/slopos_aarch64_s2_activation_main.cpp
tests/test_aarch64_s2_activation.cpp
tests/test_aarch64_s2_activation_noalloc.cpp
generated/m0/aarch64-s2-cold-activation.txt
proof/generated/M0_AArch64_S2_Activation_Generated.thy
proof/M0_AArch64_S2_Activation.thy
```

`--emit` owns generated text, `--check` rejects drift, and `--witness` prints
the selected value/protocol/non-claim packet.

## Proof/evidence partition

| Claim | Evidence kind |
|---|---|
| selected finite constants and protocol | generated Isabelle definitions + theorem |
| canonical prefix-state invariant | Isabelle theorem |
| exact selected transition at each phase | Isabelle theorem |
| rejection returns exact formal state | Isabelle theorem |
| selected run reaches sealed phase 12 | Isabelle theorem |
| 144/12/132 finite case counts | Isabelle theorem and C++20 enumeration |
| reference/core equality on every reachable choice | bounded C++20 oracle test |
| exact request precedence fixtures | bounded C++20 test |
| constrained path has no observed allocation | test observation |
| C++20 realizes the HOL transition for all executions | open |
| labels adequately map to Arm architecture events | open |
| instructions execute and hardware observes effects | open |

## Stop line

Construction 006 contains no `volatile`, MMIO, inline assembly, register
intrinsic, raw system-register encoding, barrier, cache maintenance, TLBI,
exception vector, physical dereference, boot, guest, device, DMA/SMMU,
multicore, new K0 command, hardware-translation claim, or isolation claim.
