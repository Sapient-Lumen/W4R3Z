# Product profile and proof matrix

This matrix records intended theorem pressure, not present claims. The system-level
placement and staged gates are in `docs/architecture/MOONSHOT-MAP.md`. All four shapes
share one privileged core and may select different services, configurations,
assumptions, and theorem bundles.

| Property family | A workstation | B cloud micro-VM | C embedded appliance | D agent OS | Epoch Zero location |
|---|---:|---:|---:|---:|---|
| Capability integrity | required | required | required | required | A0/D0/KIR seed |
| Spatial isolation | required | required | required | required | future MAP/M0 |
| Total fail-closed ABI | required | required | required | required | D0/K0 seed |
| Initialization correctness | required | required | required | required | bootstrap CAP-REP seed |
| DMA/IOMMU isolation | required where devices exist | required where passthrough exists | profile-dependent but explicit | inherited from host profile | future M0/profile |
| Virtualization / stage-2 translation | optional | required | generally absent or specialized | usually required by hosted shape | future B/D M0 |
| Static partition/schedule | optional | optional | required | optional | future C bundle |
| Human input/display/session authority | required | absent | appliance-specific | optional human mediation | future A/P0 |
| Tenant information flow | not primary | required when claimed | optional | policy/profile dependent | later security bundle |
| Proposal is not authority | recommended | recommended | optional | required | P0 Runtime law |
| Provenance/currentness/receipts/replay | recommended | required | recommended | required | P0 Runtime seed later |
| Remote attestation | optional | required for claimed deployments | optional | recommended | profile/platform |
| Multicore correctness | eventual | eventual | profile-dependent | inherited | later refinement layer |
| Timing/side-channel claim | narrow or absent | narrow or absent | profile-specific | narrow or absent | explicit non-claim now |

## Shared-core fence

A feature does not enter K0 merely because one product profile needs it. K0 receives
only mechanisms whose privileged placement is justified by isolation, authority,
latency, or hardware control. Workstation UI, cloud lifecycle, appliance policy, and
agent receipts belong outside K0 whenever a small kernel primitive suffices.

## First product pressure

The old vault selected a cloud/agent micro-VM as the first product pressure while
keeping workstation as north star. Epoch Zero preserves that direction but does not
let P0 receipt semantics substitute for the K0 isolation proof. The immediate proof
machine remains profile-neutral and tiny.

## Rev0773 first-physical convergence note

The candidate `M0-STATIC2` configuration is shared C/B pressure, not a fifth product
profile and not proof that either profile is delivered. C contributes the closed,
static composition; B contributes the expectation that the eventual mechanism can
be hosted under a virtualization-oriented machine layer. A and D consume no new K
ontology from this step.

The initial bundle must remain profile-neutral at the mechanism level:

| Candidate fact | Common or profile-specific? | Explicit exclusions |
|---|---|---|
| two domains with disjoint private physical ranges | common K/M seed | DMA, side channels, availability |
| one declared communication object | common K seed | general IPC policy, network/storage semantics |
| fixed configuration and install plan | C-leading common seed | dynamic VM lifecycle, hotplug |
| selected translation-root installation | B/C platform seed | general hypervisor exits, nested virtualization |
| replayable boot observation | common E seed | remote attestation, production provenance |

No matrix row advances from `NOT_STARTED` or `OPEN_DEBT` merely because this candidate
is documented. Only a later checked construction and named theorem bundle may change
claim status.
