# Construction 011 — M0 AArch64 executable-visibility assessment

## Purpose

Construction 011 asks whether the exact 36-byte M0-P10 loaded value is ready to
cross from pure readback into executable-entry preparation.

```text
exact pure loaded bytes
  -> exact accepted visibility assessment
  -> BLOCKED_TERMINAL_CONTROL_FLOW
  -X-> entry readiness
  -X-> cache effect or execution
```

The result is a measured rejection of entry readiness, not a failure of the
loader-placement theorem.

## Active C++20 surfaces

```text
include/slopos/m0/aarch64_s2_visibility.hpp
src/m0/aarch64_s2_visibility.cpp
tools/slopos_aarch64_s2_visibility_main.cpp
tests/test_aarch64_s2_visibility.cpp
tests/test_aarch64_s2_visibility_noalloc.cpp

generated/m0/aarch64-s2-visibility-assessment.txt
generated/m0/aarch64-s2-visibility-assessment.bin
proof/generated/M0_AArch64_S2_Visibility_Generated.thy
proof/M0_AArch64_S2_Visibility.thy
```

All permanent executable machinery is C++20. Isabelle/HOL remains the sole
proof-language exception.

## Two distinct decisions

The construction deliberately separates:

```text
certificate_status
readiness_outcome
```

The selected wire is a valid, exact certificate. Its readiness outcome is
blocked. No caller may infer entry authorization from certificate acceptance.

## Closed value shape

The 512-byte wire binds:

- rev0788 loader semantic and installed-memory identities;
- rev0787 object, specimen, and instruction identities;
- selected architecture-source envelope identity;
- exact code range and one selected D/I cache line address;
- selected 64-byte D/I line geometry premises;
- sixteen required and zero discharged external premises;
- eleven exact ordered intent steps;
- exact PC, EL, X0, X1, X2, fallthrough, final-word, and next-word facts;
- explicit absence of a terminal-control kind; and
- semantic and wire currentness fingerprints.

## Independent implementations

The hosted reference builder uses vector-backed intermediate collections for
cache-line and protocol records. The constrained builder writes fixed arrays
directly. They share only closed declarations, selected constants, loader
interfaces, and fingerprint primitives.

## Fail-closed checks

The certificate checker has explicit precedence for:

```text
BAD_VERSION
BAD_EXTENT
BAD_SOURCE_IDENTITY
BAD_LOADER_IDENTITY
BAD_OBJECT_IDENTITY
BAD_LINE_GEOMETRY
BAD_PREMISE_CONTRACT
BAD_PROTOCOL
BAD_ENTRY_RECORD
BAD_SEMANTIC_FINGERPRINT
ACCEPTED
```

Wire magic, exact extent, wire FNV, and zero-reserved checks precede value
admission. Malformed input returns an empty certificate.

## Executable pressure

The permanent harness covers:

```text
4,096 one-bit wire mutations
55 pairwise protocol-step swaps
source/loader/object/geometry/premise/entry mutations
reference/core equality
strict wire roundtrip
warmed constrained no-allocation path
```

The mutation fence establishes only the selected finite representation.

## Formal model

The generated theory exports natural values and lists. The handwritten theory
defines:

- one finite certificate status;
- one readiness outcome;
- one accepted-assessment predicate;
- one entry-ready predicate;
- one total assessment transition; and
- exact acceptance, blocking, precedence, frame, and predecessor lemmas.

The accepted transition records the blocked outcome. It does not authorize or
simulate a machine transition.

## Structural counterexample

The selected fragment has no terminal transfer:

```text
entry PC        0x40008000
code end        0x40008024
last word       0xd5033fdf
next word       0x00000000
terminal kind   NONE
```

This is stronger than an undischarged platform premise. Even if every external
cache, permission, and entry-state premise became true, the current artifact
would still lack a defined next control-flow action.

## Stop line

Construction 011 contains no:

```text
inline assembly or compiler intrinsic
host or physical pointer interpretation
machine-memory write
page-table, MPU, VMA, or permission update
cache-maintenance or barrier execution
branch, return, exception return, or live entry
boot, guest, device, DMA/SMMU, or multicore mechanism
new K0 command
hardware-translation or isolation theorem
```
