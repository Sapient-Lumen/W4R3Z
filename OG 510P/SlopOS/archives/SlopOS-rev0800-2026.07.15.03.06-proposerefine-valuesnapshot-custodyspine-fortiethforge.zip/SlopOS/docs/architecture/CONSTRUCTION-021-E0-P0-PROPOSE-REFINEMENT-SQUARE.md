# Construction 021 — E0 P0 PROPOSE value refinement square

## The square constructed

```text
AuthorityCore private arrays             AuthorityCore after PROPOSE
          | snapshot()                              | snapshot()
          v                                         v
canonical AuthorityValueSnapshot --expected step--> canonical snapshot
          |                                         |
          | still-open mechanized relation          | still-open relation
          v                                         v
P0 bounded command/context --------HOL step--------> P0 bounded context
```

The upper edge is executable and mutation rejecting. The lower edge is stated in
Isabelle/HOL source. The vertical edges are deliberately not colored green: source
semantics, array extraction, compiler behavior, and exact abstraction remain open.

## C++20 construction

`AuthorityValueSnapshot` is a fixed value image with no pointer, map, iterator,
allocator, or textual field. `AuthorityCore::snapshot()` insertion-sorts the occupied
fixed-array values into a fresh image without allocation. `AuthorityReference` walks
its ordered maps into the same shape. `canonical()` now renders the snapshot rather
than independently reconstructing semantic order.

`authority_propose_expected()` is a third, non-authoritative state transformer for
one operation only. It does not call either implementation's validation or mutation
helpers. `check_authority_propose_step()` first rejects malformed value images, then
requires exact outcome and post-state equality. It detects, among other faults:

- a wrong decision or published sequence;
- a missing or misplaced proposal insertion;
- mutation of an earlier proposal or any lease/resource;
- a non-default or gapped unused tail; and
- a non-PROPOSE command passed across the scope fence.

The production authority library has no dependency on this checker. The harness can
run it with `slopos-harness --authority-propose-refinement`; a dedicated test compiles
private core/reference copies with the terminal sequence seam.

## Formal construction

`P0_Authority_Propose_Refinement.thy` adds a bounded proof-facing command and context.
It defines 16-bit and 64-bit value bounds, capacity eight, resource bound four, and
one nested first-failure function. Its theorem declarations cover precedence, denial
framing, exact identifier registration, one count/sequence advance, selected proposal
registration, lease/counter framing, and preservation of context validity.

The theory imports the existing P0 sequence wrapper. It does not import a C++ parser
or semantics, and its identifier set abstracts away physical slot ordering. This is
why the formal gate remains BLOCKED and the broad implementation refinement remains
OPEN even when all C++ witnesses pass.

## Trust and effect boundary

PROPOSE is not a protected-resource effect. Acceptance records an intent value and a
new evidence sequence position. The protected counters, resource observations, and
leases remain unchanged. This small non-effect theorem matters because later effect
proofs must not silently treat proposal registration as execution authority.

## Measured cost

The final evidence packet records active/full Ninja graph sizes and compiler/test
runs. Any increase is attributable to one header, one independent refinement source,
one focused test, and one HOL theory—not a reopened platform ladder or general proof
framework.
