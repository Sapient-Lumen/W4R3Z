# Trace contract

Active traces are deterministic command streams for the hosted K0 model/core oracle.
They are executable evidence inputs, not authority, recovery logs, or proof objects.

## Header and command law

A trace names its format version and then contains only admitted bootstrap and K0
commands. Parsing is total and fail-closed. Numeric fields have explicit grammar and
bounds; command order is preserved exactly.

The trace format has no operation for setting accepted sequence, changing internal
machine tables, installing arbitrary capabilities, or bypassing bootstrap
validation. DEC-0012's terminal-state peer is confined to one separately compiled
test target and is intentionally unavailable to traces.

## Observation law

Replay compares:

- exact result status/value/accepted sequence;
- canonical model and core state after every command;
- independently evaluated invariants;
- exact pre/post state equality for rejection.

Addresses, object layout, padding, unordered-container iteration, compiler enum ABI,
and pointer identities never enter the canonical trace observation.

## Sequence law

An accepted trace command consumes exactly one sequence value only when a successor
exists. A terminal otherwise-accepting command returns `sequence_exhausted` without
mutation. Earlier invalid, not-found, conflict, authority, full, and empty statuses
retain precedence. Traces cannot directly construct the terminal value; the boundary
witness is separate finite test evidence.

## Claim boundary

Trace agreement is CONFORMANCE/TEST evidence for exact streams. It does not establish
universal state coverage, C++ source semantics, compiler correctness, persistence,
or replay safety across machine versions.
