# Mission heart and epoch review — rev0800

**Judgment:** remain `EPOCH_ZERO / CLOSURE / OPEN`.
**Living project:** the repository top level, except the repository lanes explicitly
classified as custody, evidence, transport, or ignored state.
**Old vault:** immutable lineage, counterexample pressure, and quarantine. It is not
the current architecture merely because it is present.

## The heart of the mission

SlopOS is an experiment in **effect sovereignty**:

> A consequential effect may occur only after a current intent is bound to explicit,
> attenuated authority, deterministic admission selects the smallest justified
> mechanism, and completion/currentness remains separately observable. Every claim
> about that path must be connected to an exact specification, implementation basis,
> and platform scope.

The two coupled chains are:

```text
intent -> explicit attenuated authority -> deterministic admission
       -> smallest justified effect -> completion/currentness observation

requirement -> abstract specification -> refinement relation
            -> source/compiler/binary -> platform-scoped evidence
```

The negative laws are equally central:

```text
proposal != authority
possession != admission
admission != effect
effect != completion or current state
observation != authority
evidence != proof
digest != approval
historical proof != current proof
vault material != living project
```

This is the mission's smallest stable heart. A kernel, hypervisor, agent runtime,
proof generator, archive index, or emulator ladder is useful only when it closes one
of these arrows without collapsing two of the nouns.

## What the project has already earned

The current cube has real foundations:

- one typed office with fail-closed construction/custody/evidence/transport lanes;
- exact, non-recursive construction and custody manifests;
- a small hosted authority specimen with proposal, lease, invocation, withdrawal,
  observation, finite capacity, deterministic first failure, and finite sequence;
- independent map-backed and fixed-capacity C++20 transition implementations;
- canonical observations, bounded exploration, sanitizer lanes, and private seams
  for semantically reachable but operationally infeasible terminal values;
- explicit proof obligations, theorem maps, claim exclusions, and a substantial
  Isabelle source tree; and
- preserved old cubes whose bytes are custody rather than ambient design authority.

Rev0800 adds a narrow but important bridge. Core and reference independently project
their private state into one typed, copy-only `AuthorityValueSnapshot`. A third
library independently classifies one PROPOSE step and predicts its exact outcome and
post-state. It rejects targeted mutations to decisions, insertion, sequence,
prior proposals, leases, resources, and canonical empty tails. A corresponding HOL
transformer states the same bounded first-failure order and selected update.

## What is still missing

The smallest missing spine is now easier to name:

1. **Formal currentness.** Isabelle2025-2 has not checked the changed `SlopOS_K0`
   session on the rev0800 construction basis.
2. **A mechanized vertical relation.** The executable snapshot and HOL context have
   compatible meanings, but no checked relation projects the sorted proposal prefix,
   count, sequence, resources, and selected proposal into the abstract context.
3. **C++20 source semantics.** Executing GCC/Clang binaries is evidence, not a theorem
   that `AuthorityCore::apply` and `snapshot()` have the intended C++ abstract-machine
   meaning or that a compiler preserves it.
4. **The remaining authority operations.** ISSUE, INVOKE, REVOKE, and OBSERVE do not
   inherit the PROPOSE relation by analogy.
5. **Identity and reclamation law.** No identifier or slot is reusable identity;
   generation, lineage, stale-reference rejection, dependent invalidation,
   quiescence, and reclamation remain open.
6. **One real privileged effect slice.** The current counter increment is hosted
   semantics, not an end-to-end protected platform effect with admitted authority,
   machine action, completion, and current observation.
7. **Independent review.** No second actor has challenged the exact final basis and
   accepted its exclusions.

## Where the old work went severely wrong or became wasteful

### 1. Observation formats substituted for relations

The vault repeatedly built canonical snapshots, digests, renderers, packets, and
binding manifests. Those are useful, but a canonical string or byte packet is not a
refinement relation. Rev0800 corrects one instance by making the proof boundary a
typed value image and by keeping rendering downstream. The exact C++/HOL vertical
relation remains openly unproved rather than being implied by matching text.

### 2. Assurance machinery multiplied faster than semantic edges

Old revisions accumulated registries, emitters, generated programs, proof packets,
and platform certificates. The rev0769 emitter work was unusually honest: generated
C++ and Isabelle syntax still did not establish C++ semantics. The waste begins when
such machinery is counted as closure. Current progress is budgeted by a closed
semantic edge and the trust it removes, not artifact volume.

### 3. History commandeered the ordinary build

The preserved M0/AArch64 ladder once forced assembler and platform discovery into
routine K0/P0 work. Rev0799 moved it behind `SLOPOS_BUILD_LEGACY_M0=ON`. Rev0800 keeps
that repair: a fresh dry run is 103 active steps and 253 full-research steps. The
seven-step active increase is one refinement library/test, not a reopened platform
program.

### 4. Multiple living roots blurred authority

An alternate rev0798 branch contained its own coherent `living/epoch-zero/` tree.
Wholesale merge would have created two normative architectures. The correction is
law-level promotion with exact source anchors; branch implementations remain
historical evidence.

### 5. Revocation collapsed distinct clocks

Future-use withdrawal, dependent invalidation, in-flight cancellation, reclamation,
external recall, and evidence supersession were treated as one operation. That is a
serious safety error because it authorizes reuse and completion claims too early.
The current implementation claims only future-use lease withdrawal.

### 6. Vault duplication invited destructive cleanup

The eight source archives contain 9,711 regular members, 7,989 unique payload hashes,
and 1,722 duplicate occurrences beyond first. The waste is real, but in-place dedupe
would destroy original container identity and provenance. The safe correction is a
separate content-addressed recovery pack with original archive digests, reversible
member mappings, and a proof that reconstructed containers match. Rev0800 specifies
that direction but performs no migration.

### 7. Tool recovery threatened the subject it was meant to verify

Large Isabelle/QEMU layers must not be unpacked inside the living project or treated
as prerequisites for preserving work. They belong in digest-pinned disposable
caches, with size/process limits and resumable acquisition. Failure leaves a visible
BLOCKED gate; it does not justify copying old proof evidence.

### 8. The office could become self-referential

Evidence cannot be part of the subject whose identity it records, and a ZIP cannot
authenticate its own final digest. Construction and custody identities exclude
evidence; the transport digest remains external. Cold extraction checks the embedded
subject manifests without pretending to authenticate the container.

## Epoch decision

Epoch Zero is not merely initial scaffolding. It is the period in which the project
must learn to make one authority/effect claim without hidden promotion, ambiguous
identity, or unreproducible proof currentness. Rev0800 closes a bounded executable
PROPOSE value edge and states its abstract counterpart, but it does not close the
vertical proof, formal session, real-effect, review, or deliberate-exit gates.

Therefore the honest path is to remain in Epoch Zero. Recover the pinned Isabelle
session outside the subject, check the exact basis, and then mechanize the smallest
snapshot-to-HOL projection. Do not add another operation, source DSL, generator,
reuse mechanism, or platform rung until that relation either closes or produces a
specific counterexample that requires a different path.
