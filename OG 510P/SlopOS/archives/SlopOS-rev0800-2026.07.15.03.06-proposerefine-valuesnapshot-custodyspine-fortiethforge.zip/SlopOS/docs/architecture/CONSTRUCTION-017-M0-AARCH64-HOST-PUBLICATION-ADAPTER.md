# Construction 017 — M0 AArch64 hosted publication adapter

## Purpose

Construction 017 implements the first bounded platform adapter below the exact
rev0794 readiness block while refusing to call host behavior AArch64 effect.

```text
pure generation-3 page
  -> finite host-publication contract
  -> injected Linux operation boundary
  -> one terminal host receipt
  -X-> guest/physical publication or execution
```

## Active surfaces

```text
include/slopos/m0/aarch64_s2_host_publication.hpp
src/m0/aarch64_s2_host_publication.cpp
tools/slopos_aarch64_s2_host_publication_main.cpp

include/slopos/host/linux_publication_adapter.hpp
src/host/linux_publication_adapter.cpp

tests/test_aarch64_s2_host_publication.cpp
tests/test_aarch64_s2_host_publication_noalloc.cpp

generated/m0/aarch64-s2-host-publication.txt
generated/m0/aarch64-s2-host-publication.bin
proof/generated/M0_AArch64_S2_Host_Publication_Generated.thy
proof/M0_AArch64_S2_Host_Publication.thy
```

All permanent executable code and harness machinery is C++20. Isabelle/HOL is
the sole proof-language exception.

## Separation of contract and adapter

The M0 contract is a pointer-free fixed value. It binds rev0794 readiness,
caller-artifact and installed-memory identities, generation, owner, permission
value, source page identity/fingerprint, requested host protection values, and
ordered steps.

The Linux adapter receives only the accepted contract and a byte span. Host
operations are injected through one fixed function table:

```text
page_size
map_rw
protect_rx
unmap
```

This gives the C++20 tests deterministic failure injection without embedding a
mock object hierarchy or virtual dispatch in the constrained path.

## Single-use transition

An adapter object admits at most one publication attempt. Reuse rejects before
calling the platform. This is a local lifetime fence; it is not a global replay
or revocation theorem.

The live transition is:

```text
fresh
-> contract checked
-> host page extent checked
-> private anonymous RW mapping returned
-> mapping alignment checked
-> exact page copied
-> exact pre-transition readback checked
-> host RX/non-W request returned success
-> exact post-transition readback checked
-> cleanup attempted
-> complete or explicit cleanup failure
```

## Alignment correction

Implementation pressure exposed a missing local precondition: although the live
`mmap` route should return a page-aligned address, the injected adapter boundary
could return a misaligned pointer. Rev0795 therefore checks:

```text
reinterpret_cast<uintptr_t>(mapping) % 4096 == 0
```

before copying. A misaligned mapping is rejected and cleanup is attempted before
any protection transition. The test platform provides an explicit misaligned
case. This check establishes only alignment within the host adapter.

## Failure framing

The receipt retains both `status` and `primary_status`. Cleanup runs after every
post-map terminal path. If cleanup succeeds, the primary status remains the
status. If cleanup fails, the final status is `REJECTED_CLEANUP`, while the
primary status preserves what the operation had otherwise reached.

A cleanup failure does not claim rollback, release, or harmlessness. The fake
platform intentionally remains mapped in that test.

## Executable evidence

The C++20 suite covers:

- contract reference/core equality;
- exact source-page fingerprint;
- 4,096 one-bit wire mutations;
- 45 pairwise step swaps;
- stale contract and dirty source rejection before mapping;
- wrong extent and mapping failure;
- misaligned mapping rejection plus cleanup;
- partial copy and pre-readback corruption;
- protection transition failure;
- post-transition corruption;
- cleanup failure with retained primary status;
- single-use rejection; and
- one real Linux terminal receipt.

The warmed constrained contract/adapter path performs no observed global
allocation. This does not prove C++ object-lifetime, compiler, libc, syscall, or
kernel semantics.

## Generated currentness

C++20 emits the manifest, canonical wire, and Isabelle constants. `--check`
compares exact active bytes. Currentness proves only that checked generated
inputs match the active generator output.

## Formal relation

The handwritten Isabelle theory defines one total contract-status relation, one
host-experiment permission predicate, one AArch64-discharge predicate, one total
state transition, and a finite classification of host outcomes.

The key formal asymmetry is:

```text
selected host experiment is permitted
AND
selected AArch64 machine publication is not discharged
AND
every modeled Linux outcome does not discharge it
```

No syscall appears in the logic.

## Cross-compiler correction

The independent Clang lane rejected one unused internal `kMagicOffset` constant
that GCC had not diagnosed under the selected flags. The constant had no runtime
or wire-format role and was removed. The lane failure is retained as evidence
that two compilers are an active counterexample boundary, not decorative
repetition.

## Stop line

Construction 017 contains no:

```text
execution from the host mapping
AArch64 instruction or register access
physical or guest address interpretation of the host pointer
stage-1/stage-2 table update or root selection
cache, barrier, or TLB maintenance
exception path, boot, or guest
DMA/SMMU/device mechanism
multicore behavior
new K0 command
hardware-translation or isolation theorem
```

## Falsification hooks

Reopen this construction when:

- host page extent or alignment differs from the selected contract;
- a supposedly rejected path calls later platform operations;
- cleanup status is lost or treated as rollback;
- the live receipt reports AArch64 premise discharge;
- the selected page or predecessor identity changes;
- a compiler/sanitizer lane disagrees; or
- any document equates the host outcome with guest effect.
