# K0 abstract machine

## State

K0 state contains:

- a finite capability table;
- a finite mapping table indexed by domain and virtual page;
- one bounded endpoint queue;
- an accepted-transition sequence number.

A capability names its holder, target object, rights bitset, generation, and parent
slot. Epoch Zero does not yet reuse slots, so generation is carried but is not yet
exercised as revocation authority.

The formal accepted sequence is a natural number. The C++ source carrier is
`std::uint64_t`. They are related only while the formal value is below `2^64`.
Sequence terminal is `2^64 - 1`; an otherwise accepting command at terminal state
returns `sequence_exhausted` and preserves state. Sequence is an observation and
admission-resource coordinate, not authority.

## Commands

`DERIVE(actor, source, destination, requested_rights)` installs a child only when
the source is live, held by the actor, includes `derive`, the destination is empty,
requested rights are a subset of source rights, and sequence advance is available.

`MAP(actor, capability, page, permissions)` creates one mapping only when the cap is
live, held by the actor, targets a private memory object owned by the actor, includes
`map`, contains the requested read/write permissions, the virtual page is unmapped,
capacity is available, and sequence advance is available. A mapping stores the
authorizing capability slot for audit.

`SEND(actor, capability, value)` appends to the endpoint queue only with matching
holder, endpoint target, `send`, queue capacity, and sequence availability.

`RECEIVE(actor, capability)` removes the oldest matching value only with matching
holder, endpoint target, `receive`, a matching queued value, and sequence
availability.

Every command is total. Structural, existence/conflict, authority, and
operation-capacity results precede sequence exhaustion. Failure returns a status and
the exact pre-state. Only an accepted command consumes one sequence value.

## Initial invariants

- **I1 attenuation:** every derived cap's rights are a subset of its parent's rights.
- **I2 mapping authority:** every mapping cites a live memory cap held by the mapped
  domain with `map` and all mapping permissions.
- **I3 private ownership:** private memory is mapped only into its owner domain.
- **I4 denial atomicity:** rejected commands preserve authoritative state.
- **I5 handle validity:** every live cap targets an existing object of the expected kind.
- **I6 well-formedness:** capacities, unique slots, pages, and queue bounds hold.
- **I7 finite sequence:** the C++ sequence never wraps; acceptance is possible only
  when a representable successor exists.

## Representation boundary

The C++ core stores capabilities in twelve fixed cells while the formal state uses
`nat ⇒ capability option`. Rev0765 now supplies a proof-facing source-value image and
a candidate relation with presence gating, field conversion, out-of-range absence,
dead-payload irrelevance, one-slot update, and frame behavior.

That does not yet close `OBL-CAP-REP-001`. Rev0768 isolates the first source
sub-edge in `caprep::scalar::project` and checks its mathematical value semantics;
`OBL-CAP-SCALAR-CXX-001` still requires exact C++ evaluation, while the richer
wrapper, array, compiler, ABI, and execution edges remain separate. No byte-layout or
compiled refinement claim follows from similar record fields or finite witnesses.
