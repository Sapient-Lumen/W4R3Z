# Construction 020 — Epoch Zero hosted authority specimen

This construction is mirrored by the more operational
`docs/epoch-zero/CONSTRUCTION-001-CLOSURE-OFFICE-V2-AUTHORITY-SPECIMEN.md`.

Its purpose is to falsify authority-boundary mistakes with the smallest state machine
that still contains proposal, lease, invocation, revocation, effect, and observation.
It is not a product policy engine, capability kernel, persistence service, or trusted
clock.

The fixed-capacity `AuthorityCore` and map-backed `AuthorityReference` share value
structures but not state storage or transition code. Bounded exploration enumerates a
nine-command adversarial alphabet, compares outcomes and canonical state after every
transition, and reports the first divergence with its trace.

The most important correction made during construction was adding `max_amount` to
the lease. Without it, a one-use, one-second lease still authorized an arbitrarily
large increment.
