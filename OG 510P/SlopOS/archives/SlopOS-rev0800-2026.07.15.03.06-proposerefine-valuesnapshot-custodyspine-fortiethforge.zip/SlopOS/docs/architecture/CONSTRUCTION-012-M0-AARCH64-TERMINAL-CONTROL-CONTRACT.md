# Construction 012 — M0 AArch64 terminal-control contract

## Purpose

Construction 012 resolves the meaning defect discovered by M0-P11 without
patching the binary first.

```text
accepted visibility assessment
  + closed control-transfer alternatives
  + exact live-input requirements
  + exact cascade consequences
  -> selected CALLABLE_RETURN_X30 contract
  -X-> repaired bytes, entry, or execution
```

## Repository surfaces

```text
include/slopos/m0/aarch64_s2_terminal.hpp
src/m0/aarch64_s2_terminal.cpp
tools/slopos_aarch64_s2_terminal_main.cpp
tests/test_aarch64_s2_terminal.cpp
tests/test_aarch64_s2_terminal_noalloc.cpp

generated/m0/aarch64-s2-terminal-contract.txt
generated/m0/aarch64-s2-terminal-contract.bin
proof/generated/M0_AArch64_S2_Terminal_Generated.thy
proof/M0_AArch64_S2_Terminal.thy
```

All permanent executable machinery is C++20.

## Value shape

The 512-byte value binds:

- the exact M0-P11 assessment identity;
- the exact M0-P10 loader, M0-P9 object/specimen, and M0-P8 instruction
  identities;
- six ordered alternative records;
- twelve exact live requirements;
- ten ordered cascade rows;
- the current and projected code extents;
- target register X30;
- one selected `RET X30` natural word; and
- semantic and wire fingerprints.

## Independent implementations

The hosted reference path uses vectors for alternative/cascade materialization.
The constrained path uses only fixed arrays. Both invoke the prior exact
visibility/loader builders to bind predecessor identities.

The core transition surface does not allocate, parse text, inspect host
addresses, invoke an assembler, or modify the active source/object.

## Canonical wire

```text
0x000..0x007  magic "SLOPTER1"
0x008..0x013  version and exact counts
0x014..0x027  basis/live masks and selected terminal word
0x028..0x02f  selected role/outcome/register/count plus reserve
0x030..0x07f  source/predecessor/extents/semantic identities
0x080..0x0df  six 16-byte alternative records
0x0e0..0x12f  ten 8-byte cascade records
0x130..0x1f7  canonical zero reserve
0x1f8..0x1ff  wire FNV
```

Malformed input returns an empty contract. Semantic rejection preserves the
prior formal state.

## Alternative semantics

Only the first row is selected. The other rows are not aliases:

```text
return via X30
branch via separately named register
direct boot branch
exception return
proved adjacent fallthrough
no terminal transfer
```

The current artifact has the evidence needed to choose the first role and lacks
the state needed for the other four active transfer styles. The sixth preserves
the known non-readiness defect.

## Current-versus-projected boundary

```text
active final word             ISB
active code bytes             36
active code end               0x40008024
active terminal kind          NONE

selected future terminal      RET X30
projected code bytes          40
projected code end            0x40008028
```

No generated artifact below M0-P8R is silently rewritten. The projected extent
is a consequence value, not a loaded image.

## Executable evidence

The harness establishes only the closed specimen:

- reference/core equality;
- exact predecessor identities;
- exact unique role selection;
- exact live mask with zero discharge;
- exact alternative outcomes;
- exact cascade actions;
- all 4,096 one-bit mutations rejected;
- all 15 alternative swaps rejected;
- all 45 cascade swaps rejected;
- empty rejection output; and
- no observed allocation on the warmed constrained path.

## Formal relation

Isabelle defines one total status relation, admitted predicate, repair-required
predicate, and state transition. It proves exact generated values, closed and
distinct alternatives, unique selection, X30/RET contract, preservation/change
rows, rejection frame, selected transition, preservation of M0-P11 assessment,
and continued M0-P11 blocked readiness.

## Stop line

Construction 012 adds no:

```text
RET to the active assembly
changed ELF object
changed loader extent or memory image
changed visibility certificate
live link-register value
host or physical pointer interpretation
cache operation
branch or return execution
exception return
boot or guest entry
DMA/SMMU/device mechanism
multicore behavior
new K0 command
hardware translation or isolation theorem
```
