# DEC-0037 — M0 AArch64 executable-visibility assessment

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P11 only
- Depends on: DEC-0028 through DEC-0036
- Supersedes: no sealed construction

## Decision

SlopOS admits one exact **assessment certificate** for the M0-P10 loaded pure
value. The certificate names a conservative single-PE AArch64 cache-visibility
intent sequence, sixteen external premises, one explicit entry record, and one
structural terminal-control-flow check.

The certificate itself is accepted as an exact assessment. The loaded fragment
is **not entry-ready**:

```text
certificate status     ACCEPTED
readiness outcome      BLOCKED_TERMINAL_CONTROL_FLOW
entry ready            false
```

This separation is load-bearing. Acceptance of an assessment is not acceptance
of code for entry or execution.

## Exact selected assessment

```text
certificate version             1
wire bytes                    512
wire one-bit mutations       4096
protocol steps                  11
step-pair swaps                  55
required external premises       16
discharged external premises      0
selected D-cache line bytes      64
selected I-cache line bytes      64
selected D-cache lines            1
selected I-cache lines            1
code range       [0x40008000, 0x40008024)
entry PC                       0x40008000
fallthrough PC                 0x40008024
final selected word            0xd5033fdf  (ISB)
fallthrough word               0x00000000
terminal kind                  NONE
source-envelope FNV            aa82407dbca17a74
loader semantic FNV            eeb86170d0078916
loader installed-memory FNV    da161913c6998db2
object FNV                     403a5c3a0ee255fe
source/object semantic FNV     15a2851fdf5adcd5
instruction-candidate FNV      3e606113c95c0b62
assessment semantic FNV        f33930b3d84b2cf7
wire FNV                       8681c1db9f554ee5
```

The 64-byte cache-line values are selected premises for one bounded assessment.
They are not a claim about an observed PE or product platform.

## Exact intent protocol

```text
BIND_INSTALLED_VALUE
REQUIRE_MACHINE_PUBLICATION
REQUIRE_EFFECTIVE_PERMISSION
CLEAN_DATA_TO_POU                 DC CVAU intent
COMPLETE_DATA_CLEAN               DSB ISH intent
INVALIDATE_INSTRUCTION_TO_POU     IC IVAU intent
COMPLETE_INSTRUCTION_INVALIDATION DSB ISH intent
SYNCHRONIZE_FETCH                 ISB intent
BIND_ENTRY_STATE
CHECK_TERMINAL_TRANSFER
SEAL_ASSESSMENT
```

The sequence is selected from official Arm architecture and 2026-03
instruction/register documentation. It is an engineering intent relation only.
No instruction is emitted or executed by M0-P11.

## Sixteen external premises

The certificate names, but does not discharge:

1. machine memory contains the exact selected bytes;
2. effective read permission;
3. effective execute permission;
4. effective write permission is absent;
5. privileged fetch is permitted;
6. translations are stable for the selected range;
7. the selected VA is valid for cache maintenance;
8. selected D-cache line geometry is correct;
9. selected I-cache line geometry is correct;
10. `CTR_EL0.IDC=0` in the selected conservative branch;
11. `CTR_EL0.DIC=0` in the selected conservative branch;
12. one executing PE;
13. no concurrent writer;
14. no DMA or device mutation;
15. entry is at EL2 in AArch64 state; and
16. X0/X1/X2 contain the selected VTCR/VTTBR/HCR values.

A required bit is not a true premise. The discharged mask is exactly zero.

## Terminal-control-flow counterexample

The exact M0-P9 source/object specimen contains nine instructions and ends with
`ISB`. The exact M0-P10 copied page has zero-filled bytes immediately after the
36-byte fragment. Therefore:

```text
last instruction at 0x40008020    ISB
next word at 0x40008024            0x00000000
explicit terminal transfer        absent
```

The repository cannot honestly call the fragment entry-ready. It has not yet
selected whether the fragment is:

- a callable routine that returns through X30;
- a fragment that branches through an explicit continuation register;
- a boot handoff using a direct branch;
- an exception-return path with explicit ELR/SPSR state; or
- a deliberately contiguous fallthrough fragment with a separately placed and
  proven continuation.

Appending a convenient instruction before choosing that semantic role would
hide the real design decision.

## C++20 evidence

Independent hosted-reference and fixed-capacity C++20 builders agree on the
selected certificate. The permanent harness checks:

- exact predecessor and source identities;
- exact line geometry, premise masks, protocol, and entry record;
- exact accepted-certificate/blocked-readiness separation;
- all 4,096 single-bit wire mutations;
- all 55 pairwise protocol-step swaps;
- deterministic empty rejection facts; and
- no observed allocation through the warmed constrained build, status,
  readiness, serialization, and decode path.

FNV-1a remains a finite currentness/corruption fence, not authenticity.

## Isabelle root

`M0_AArch64_S2_Visibility.thy` proves exact finite facts about the selected
certificate, protocol, line values, external-premise mask, entry record,
terminal observation, certificate acceptance, blocked readiness, non-readiness,
status precedence, rejection framing, exact assessment transition, and
preservation of M0-P10 loader admission.

The theorem root imports no formal Arm cache, instruction, entry, or execution
semantics.

## Non-claims

M0-P11 does not establish:

```text
machine-memory publication
effective page-table, MPU, VMA, stage-1, or stage-2 permission
actual DC CVAU, IC IVAU, DSB, or ISB execution
cache-maintenance completion or fetch visibility
observed CTR_EL0 values or cache-line geometry
live EL2, PC, X0, X1, X2, X30, SP, PSTATE, ELR, or SPSR state
instruction fetch, decode, retirement, return, branch, or exception return
boot, CPU isolation, DMA/SMMU/device isolation, or multicore correctness
```

## Next experiment

M0-P8R must choose or reject the semantic role and terminal-control contract of
the activation fragment before changing its instruction, source/object, loader,
or visibility identities. A measured refusal to choose is valid if no role is
yet justified.
