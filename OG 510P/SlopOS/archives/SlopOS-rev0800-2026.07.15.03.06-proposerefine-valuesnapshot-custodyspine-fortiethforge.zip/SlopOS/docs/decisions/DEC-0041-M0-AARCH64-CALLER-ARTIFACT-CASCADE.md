# DEC-0041 — M0 AArch64 caller-artifact cascade

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P11R only
- Depends on: DEC-0039 and DEC-0040
- Supersedes: no sealed historical fact

## Decision

SlopOS admits one exact **caller source/object/pure-loader artifact cascade** for
the projected rev0792 `BL`/X30 edge. The cascade makes the two selected caller
words current in a new immutable pure-memory generation while preserving the
repaired helper and every unrelated byte.

```text
sealed rev0792 projected caller-edge contract
  + exact 211-byte assembly source
  + exact 528-byte AArch64 ELF object
  + exact 8-byte BL/NOP text image
  + exact generation-2 pure loader memory
  + atomic generation-3 pure loader update
  -> accepted finite caller-artifact cascade
  -X-> machine-memory publication
  -X-> effective executable permission
  -X-> instruction-fetch visibility
  -X-> BL execution or observed X30
  -X-> RET execution or completed return
```

Acceptance proves a closed value relation. It does not establish a call edge in
a processor.

## Exact source and object

```text
source path        spec/m0/aarch64-s2-caller.S
source bytes       211
source FNV         450556c451bf54cd
source SHA-256     05a21a9903fd882efbc35dc21ee41b6f45e5cdb9dfd5b5687d3bfdb6ba95b32e

object path        generated/m0/aarch64-s2-caller.o
object bytes       528
object FNV         0782ca8f69f67328
object SHA-256     0ed7c6e781b9ff823d9e9956c78b2432bdb76bcef07a3a711b23374f6685a2f7
text bytes         8
text FNV           96c0b135d893d511
relocations        0
```

The exact source body is:

```asm
.arch armv8-a
.text
.balign 4
.global slopos_m0_s2_call
.type slopos_m0_s2_call, %function
slopos_m0_s2_call:
  bl . - 64
  nop
.size slopos_m0_s2_call, .-slopos_m0_s2_call
.section .note.GNU-stack,"",%progbits
```

The selected ELF64 little-endian `ET_REL`/`EM_AARCH64` object has five sections,
three symbols, zero program headers, and zero relocations. Its `.text` image is:

```text
f0 ff ff 97  1f 20 03 d5
```

which decodes as the already selected natural values:

```text
0x97fffff0  projected BL from 0x40008040 to 0x40008000
0xd503201f  NOP at continuation 0x40008044
```

The exact identified replay remains:

```text
clang version 17.0.0 (https://github.com/swiftlang/llvm-project.git 10999b6d034fe318f3d56c83bddb6572593a8bb0)
clang --target=aarch64-none-elf -march=armv8-a -c INPUT -o OUTPUT
```

One exact replay is conformance evidence, not general assembler correctness.

## Pure loader update

The caller and helper share one previously admitted 4 KiB monitor-owned RX
non-write **value page**:

```text
page             0x40008000 .. 0x40009000
helper            0x40008000 .. 0x40008028
zero gap          0x40008028 .. 0x40008040
caller            0x40008040 .. 0x40008048
remaining suffix  0x40008048 .. 0x40009000
```

The selected update is exactly:

```text
prior generation       2
installed generation   3
prior memory FNV       71a3734c1ac2f759
caller placement FNV   7a79f895a17ab727
installed memory FNV   e75835fa071041d1
visibility-value FNV   1e7bff8aa852f236
```

Only offsets 64 through 71 of the target page change. The helper’s first forty
bytes, the twenty-four-byte gap, all bytes from offset 72 onward, and both guard
pages are preserved. The helper terminal remains `RET X30 = 0xd65f03c0`.

No mixed-generation tuple is accepted. Validation precedes mutation; every
rejected install returns the exact prior pure-memory value.

## Exact finite certificate

```text
wire bytes                512
source mutations         1688
object mutations         4224
wire mutations           4096
text mutations             64
prior-page mutations     4096
value requirements         18
live requirements           7
semantic FNV       2e63155fe84fcc6e
wire FNV           c74eadac74b82132
```

All eighteen value requirements are observed. They cover current predecessors,
exact source/object/text identities, zero relocations, range separation,
permission intent, exact prior memory, helper and guard framing, current caller
readback, exact generation advance, projected-word agreement, terminal
preservation, mixed-generation rejection, and explicit visibility debt.

All seven live requirements remain undischarged:

```text
machine bytes published
effective RX permission
caller fetch visibility
call edge executed
X30 observed at continuation
same-EL return permitted
return completed
```

Therefore:

```text
caller_artifact_present = true
call_edge_established   = false
readiness               = BLOCKED_MACHINE_PUBLICATION_AND_VISIBILITY
```

## Total fail-closed order

Value admission uses this precedence:

```text
BAD_VERSION
BAD_EXTENT
BAD_SOURCE_IDENTITY
BAD_ASSEMBLER_IDENTITY
BAD_OBJECT_IDENTITY
BAD_PREDECESSOR
BAD_ADDRESS_PROFILE
BAD_OWNER_PERMISSIONS
BAD_WORD_RELATION
BAD_PRIOR_MEMORY
BAD_GENERATION
BAD_CURRENT_MEMORY
BAD_VALUE_MASK
BAD_LIVE_MASK
BAD_READINESS
BAD_SEMANTIC_FINGERPRINT
ACCEPTED
```

Wire magic, extent, stored wire fingerprint, and reserved-byte checks precede
value admission. Rejected decoding returns an empty value. Rejected installs
and formal transitions frame their exact prior state.

## C++20 machinery

```text
include/slopos/m0/aarch64_s2_caller_artifact.hpp
src/m0/aarch64_s2_caller_artifact.cpp
tools/slopos_aarch64_s2_caller_artifact_main.cpp
tests/test_aarch64_s2_caller_artifact.cpp
tests/test_aarch64_s2_caller_artifact_noalloc.cpp
```

The hosted reference path uses complete-byte recognition and hosted
collections. The constrained path performs explicit bounded ELF reads and uses
fixed-capacity state. They share closed declarations and selected constants,
not parser or installation loops.

The permanent C++20 harness establishes exact reference/core agreement, strict
serialization, exact assembler replay, all finite mutation fences above, exact
state framing, and no observed allocation on the warmed constrained path.

## Isabelle root

`M0_AArch64_S2_Caller_Artifact.thy` checks exact finite propositions about:

- source, object, text, ELF, predecessor, address, word, and generation values;
- exact prior/current page lengths and byte slices;
- helper, gap, suffix, and guard framing;
- exact current caller readback;
- total status precedence and mixed-generation rejection;
- rejected admission and install framing;
- selected admission and atomic pure-memory installation; and
- preservation of the rev0792 caller-edge admission.

The theory imports no ISO C++ semantics, assembler semantics, ELF loader
semantics, Arm instruction-step relation, register file, cache model, or machine
memory.

## Non-claims

This decision does not establish:

```text
general source or assembler correctness
general ELF parsing or loader correctness
physical or host memory publication
effective stage-1/stage-2 executable permission
data-cache or instruction-cache effect
instruction fetch, BL execution, or live X30
same-EL RET permission, execution, or completion
exception, stack, scheduler, or boot state
CPU isolation
DMA/SMMU/device isolation
multicore or information-flow security
```

## Next bounded experiment

M0-P12R may construct one exact caller-visibility and entry-readiness assessment
that consumes the current generation-3 pure value and names the remaining
machine-publication, permission, cache, fetch, X30, and return premises. It must
remain blocked unless those premises are independently discharged and must stop
before executing the caller or helper.
