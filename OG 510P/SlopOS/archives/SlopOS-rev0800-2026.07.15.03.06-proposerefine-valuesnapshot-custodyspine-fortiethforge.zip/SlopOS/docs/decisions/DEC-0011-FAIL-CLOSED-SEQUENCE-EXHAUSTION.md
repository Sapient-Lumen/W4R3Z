# DEC-0011 — Accepted-sequence exhaustion is fail-closed

**Status:** accepted and implemented at source level in rev0764
**Selected:** rev0763
**Implemented:** rev0764
**Concrete boundary evidence:** `OBL-SEQUENCE-OPERATIONS-001`
**Source conformance:** `OBL-SEQUENCE-SOURCE-001`
**Formal DERIVE candidate:** `OBL-SEQUENCE-DERIVE-001`
**Retained umbrella debt:** `OBL-SEQUENCE-BOUND-001`
**Focused universal edge:** `OBL-SEQUENCE-REFINE-001`

## Decision

The C++20 accepted-transition sequence never wraps. At `uint64_t` maximum, a
command that has passed its ordinary input, existence/conflict, authority, and
operation-capacity checks returns `sequence_exhausted` and leaves authoritative
state unchanged.

The exhaustion check is the final guard before commit for every currently accepting
operation. This preserves established invalid/denial/capacity precedence and avoids
exposing counter state to commands that were already inadmissible.

The formal state retains a natural-number sequence. The admitted source relation is
explicit:

```text
Rseq(n, u)    := n = unsigned_value(u) ∧ n < 2^64
available(n)  := n < 2^64 - 1
available(u)  := u != UINT64_MAX
```

Thus maximum-minus-one may advance to maximum, while maximum cannot advance. The
counter is an admission/resource bound and observation coordinate; it is not
capability authority.

## Concrete placement

- `DERIVE`: final generated KIR guard `sequence_available`.
- `MAP`: after input, capability, occupancy, object, ownership, and table-capacity
  checks; before mapping insertion.
- `SEND`: after input, capability, authority, and queue-capacity checks; before
  append.
- `RECEIVE`: after input, capability, authority, and matching-message checks; before
  removal.

All accepted paths use `accepted_sequence_advance`; no accepting path performs an
unchecked increment.

## Evidence posture

Rev0764 has source-level formal representation, generated-source conformance,
independent model/core boundary tests, terminal-frame witnesses, and finite fact and
commit witnesses. It does not have a retained Isabelle checker run, a formal
transition for MAP/SEND/RECEIVE, a universal C++ capability-array relation, or a
proof that a named C++ compiler preserves the source transition.

Accordingly, `OBL-SEQUENCE-SOURCE-001` records the now-explicit source rule.
`OBL-SEQUENCE-BOUND-001` deliberately retains the older umbrella correspondence
claim as `OPEN_DEBT`; it was not repurposed merely because the source bug was fixed.
`OBL-SEQUENCE-REFINE-001` names the narrower CAP-REP/formal/compiled edge that must
advance next.

## Non-decisions

This decision does not add persistence, reboot epochs, distributed ordering,
cryptographic counters, receipt identities, revocation generations, a reset
operation, or a general resource-exhaustion framework.
