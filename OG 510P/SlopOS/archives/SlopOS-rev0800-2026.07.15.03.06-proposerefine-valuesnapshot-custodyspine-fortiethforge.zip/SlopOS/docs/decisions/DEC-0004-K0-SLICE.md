# DEC-0004 — Epoch Zero K0 slice

**Status:** accepted

K0 contains two domains, two private memory objects, one endpoint, fixed capability
slots, fixed mapping slots, and a bounded endpoint queue.  The initial operations
are derive, map, send, and receive.  Revocation, scheduling, interrupts, multicore,
persistence, networking, filesystems, agents, portals, and compatibility layers are
out of active scope.

The root capabilities are installed from a compiled bootstrap plan.  The privileged
machine validates and installs that plan; it does not discover policy from ambient
configuration.  The same C++20 plan definition emits a human-readable trace header
and an Isabelle transcription.  This binding is deterministic evidence, not a proof
that compiled C++ realizes the theorem model.
