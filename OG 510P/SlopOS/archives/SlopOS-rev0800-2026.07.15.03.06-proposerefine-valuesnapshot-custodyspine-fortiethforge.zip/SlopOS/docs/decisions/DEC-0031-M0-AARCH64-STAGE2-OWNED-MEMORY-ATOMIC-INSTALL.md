# DEC-0031 — M0 AArch64 stage-2 owned-memory atomic installation

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P5 only
- Supersedes: no earlier decision
- Depends on: DEC-0028, DEC-0029, DEC-0030

## Decision

SlopOS admits one pure, fixed-capacity owned-memory value above the selected
placement packet.  The value contains exactly eight abstract page values:

```text
one guard-before page
six installable table pages
one guard-after page
```

The six table page identities equal the selected packet destinations.  Their
owners equal the packet table owners.  Page identity is an integer in the
model; it is not a C++ pointer, host virtual address, physical address, or
permission to write a machine.

One total installation operation validates the exact selected packet, sealed
admission observation, graph bytes, copy order, generation, capacity,
identity uniqueness, ownership, guard values, and zero destination payloads.
It either:

```text
accepts and commits all six page payloads once
```

or:

```text
rejects and returns the complete prior memory state unchanged
```

No partial authoritative state is externally observable.

## Exact selected value

| Field | Value |
|---|---:|
| memory version | 1 |
| page bytes | 4,096 |
| total page values | 8 |
| installable page values | 6 |
| frame page values | 2 |
| serialized page payload bytes | 32,768 |
| copied graph bytes | 24,576 |
| guard bytes | 8,192 |
| initial generation | 1 |
| installed generation | 2 |
| guard-before identity | `0x3ffff000` |
| guard-after identity | `0x40006000` |
| packet semantic FNV | `a1d0b02ad4351902` |
| graph FNV | `32ec119640d7e72d` |
| sealed admission FNV | `e11907ffe581eac8` |
| initial memory FNV | `9bb3493b247d1ccc` |
| installed memory FNV | `0f5d2f8c81d299d2` |
| installed page-byte FNV | `9ce4d5ca56ccb72d` |

The two guard pages use deterministic fills `0xa5` and `0x5a`.  They are
observational frame sentinels, not hardware red zones or a memory-safety
mechanism.

## Independent executable paths

The hosted reference uses vector-backed page payloads, value search, and a
candidate copy committed only after complete validation.  The constrained
core uses one fixed `MemoryValue`, fixed arrays, bounded loops, and a direct
validate-copy-commit transition.  They share declared wire/value types and
the selected predecessor artifacts, but not storage representation or the
main validation/copy implementation.

The constrained path is compiled without exceptions and RTTI.  Its warmed
construction, input production, install, snapshot, and serialization path
performs no observed global allocation.

## Bounded pressure

The permanent C++20 harness checks:

- independent selected input, observation, and post-state agreement;
- exact six-page readback and two-page frame preservation;
- representative stale, truncated, reordered, capacity, identity, owner,
  guard, dirty-target, and repeated-install rejections;
- all 720 six-table copy orders, admitting exactly the canonical order;
- all 24,576 one-byte dirty target positions, rejecting every case without
  state change; and
- generated artifact currentness under GCC, Clang, and the sanitizer lane.

These are bounded witnesses.  They are not an ISO C++20 semantics theorem.

## Formal root

`M0_AArch64_S2_Owned_Memory.thy` defines one finite memory state, one finite
request, one total precondition, and one atomic transition.  Isabelle proves
selected acceptance, canonicality of every accepted result, rejection
atomicity, exact graph-value readback, guard framing, and preservation of the
already checked packet/graph/plan correspondence.

The formal payload is represented at the selected 64-bit descriptor-value
level.  The exact little-endian byte copy remains a separately labelled C++20
bounded witness.  Neither is silently treated as a theorem about the other.

## Rejected alternatives

### Interpret destination integers as pointers

Rejected.  Integer alignment and ownership records do not establish host
address validity, lifetime, aliasing, provenance, physical mapping, or write
authority.

### Mutate pages while validating

Rejected.  A failure after an early copy would violate the project-wide
denial/frame law.  Validation precedes authoritative mutation.

### Treat the packet ledger as installation

Rejected.  Admission describes an allowed next value transition; it is not
that transition and still less a physical effect.

### Jump directly to register writes

Rejected.  It would collapse owned bytes, machine placement, current roots,
architecture protocol, and hardware observation into one unauditable edge.

## Non-claims

This decision does not establish:

- a general memory allocator or object model;
- host-pointer or physical-address interpretation;
- C++ source, compiler, ABI, binary, or platform correctness;
- volatile, MMIO, assembly, or page-table writes;
- physical ownership, cache coherence, or concurrent visibility;
- VTTBR_EL2, VTCR_EL2, or HCR_EL2 programming;
- barrier, cache-maintenance, or TLB-invalidation correctness;
- Arm hardware translation, faults, or exception behavior;
- boot, guest execution, devices, DMA/SMMU, or multicore behavior;
- CPU-memory isolation or any A/B/C/D product theorem.

## Consequence

The next rung may reason about a selected activation protocol as a pure state
machine only after authoritative architecture sources are recorded.  It may
not use this owned-memory value as evidence that bytes exist at a machine
physical address or that any root is live.
