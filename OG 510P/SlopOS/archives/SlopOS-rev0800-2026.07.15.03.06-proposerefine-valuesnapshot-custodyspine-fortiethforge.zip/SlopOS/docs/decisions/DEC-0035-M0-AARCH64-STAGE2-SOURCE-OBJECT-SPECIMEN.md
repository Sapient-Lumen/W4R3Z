# DEC-0035 — M0 AArch64 stage-2 source/object specimen

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P9 only
- Depends on: DEC-0028 through DEC-0034
- Supersedes: no sealed construction

## Decision

SlopOS admits one exact AArch64 assembly source and one exact ELF64
little-endian relocatable object as a **source/object specimen** for the nine
instruction words accepted by M0-P8.

The specimen closes this finite relation only:

```text
339 exact source bytes
  + one identified Clang 17 invocation
  + one 560-byte ELF64/ET_REL/EM_AARCH64 object
  + one exact 36-byte .text image
  + five exact section records
  + three exact symbol records
  + zero relocations
  -> one admitted source/object value
  -X-> general assembler correctness, loading, execution, or effect
```

## Exact identities

```text
source bytes                   339
source FNV                     b9f106f99598adad
source SHA-256                 6ed7876dffc406588d82a24f68d1b3c44fcb961995360ceeecfefb34a227a773
object bytes                   560
object FNV                     403a5c3a0ee255fe
object SHA-256                 88412fa5669683832775ccc2683b12b214db54e9d2145975871f50b0de7d8101
semantic FNV                   15a2851fdf5adcd5
.text bytes                    36
sections                       5
symbols                        3
relocations                    0
source one-bit mutations       2712
object one-bit mutations       4480
total one-bit mutations        7192
```

The exact identified replay is:

```text
clang version 17.0.0
  (https://github.com/swiftlang/llvm-project.git
   10999b6d034fe318f3d56c83bddb6572593a8bb0)

clang --target=aarch64-none-elf -march=armv8-a -c INPUT -o OUTPUT
```

The version line and command template have independent FNV identities in
`toolchains/aarch64-assembler.lock`.

## Closed object envelope

The fixed-capacity core parser accepts only:

```text
ELF class             ELFCLASS64
byte order            ELFDATA2LSB
file type             ET_REL
machine               EM_AARCH64
program headers       none
section headers       five, 64 bytes each, starting at byte 240
sections              NULL, .strtab, .text, .note.GNU-stack, .symtab
.text                 offset 64, extent 36, flags ALLOC|EXEC, alignment 4
symbols               null, $x mapping symbol, global 36-byte function
relocation sections   none
```

The `.text` words equal the nine M0-P8 instruction words exactly.

## Independent C++20 surfaces

The hosted reference path recognizes the complete frozen byte image through a
vector-backed representation. The constrained path parses exact-width fields,
section records, names, symbols, and words into fixed arrays and checks complete
byte identity. They share declarations and the selected image, not parsing
logic.

The permanent C++20 harness checks:

- reference/core agreement;
- strict status precedence and empty rejection facts;
- all 7,192 one-bit source/object mutations;
- exact identified assembler replay;
- generated source, object, manifest, and Isabelle currentness; and
- no observed allocation through the warmed core parse/build/status path.

## Formal boundary

Isabelle checks exact finite values, list extents, ELF/header/section/symbol
facts, zero relocation count, exact word correspondence, total status,
rejection framing, selected admission, and preservation of M0-P8 admission.

It does not formalize assembly syntax, Clang, ELF loading, AArch64 instruction
execution, or Arm architecture effects.

## Non-claims

M0-P9 does not establish:

```text
general assembly-language semantics
general Clang integrated-assembler correctness
general ELF parsing or validation
linking or relocation application
loader placement or permissions
instruction-cache synchronization
live X0/X1/X2 register contents
privileged execution or exception freedom
DSB/ISB/TLBI/register completion
hardware translation, boot, or isolation
DMA/SMMU/device or multicore correctness
```

## Next experiment

M0-P10 may construct one immutable loader-placement **value**: exact destination
extent, page permissions, source-object identity, entry offset, and a pure
fixed-capacity copy/readback relation. It must stop before executable mapping,
instruction-cache maintenance, branch/exception entry, privileged execution,
or hardware effect.
