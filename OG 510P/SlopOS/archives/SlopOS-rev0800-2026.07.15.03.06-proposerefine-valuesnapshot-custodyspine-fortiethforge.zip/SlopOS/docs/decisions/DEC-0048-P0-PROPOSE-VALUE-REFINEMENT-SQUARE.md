# DEC-0048 — P0 PROPOSE value refinement square

**Status:** ACTIVE  
**Epoch:** EPOCH_ZERO / CLOSURE  
**Revision:** 0800

## Context

Rev0799 repaired terminal accepted-sequence wrap and named the next missing edge: a
concrete relation between one hosted authority command and the P0 sequence wrapper.
The existing comparison used `canonical()` text. That was adequate for differential
testing but too weak and indirect for proof work: textual rendering hid fixed tails,
made the serializer carry semantic weight, and offered no typed post-state to an
independent checker.

The old vault contains both the right discipline and the warning. Rev0761 allowed an
independent model and constrained core to share canonical observation declarations
while forbidding shared transition and authority checks. Rev0769 showed that a
closed generated guard program can remove drift without establishing C++20 source or
compiler semantics. The living project should recover the first rule and retain the
second limit.

## Decision

1. Expose `AuthorityValueSnapshot`, a copy-only canonical value image. Occupied
   proposals and leases are packed in ascending identifier order; every unused tail
   entry is the exact default value; resources and the finite sequence are copied in
   full. It is neither persistence nor a mutation interface.
2. Keep `AuthorityCore` and `AuthorityReference` transition implementations
   independent. Each projects its own private storage to the shared value type.
3. Place the PROPOSE correspondence checker in a separate
   `slopos_authority_refinement` library. The authority library does not depend on
   it. The checker names the exact branch order:

   ```text
   out-of-scope -> invalid -> duplicate -> capacity
                -> sequence-exhausted -> accepted
   ```

4. For an accepted command, require the exact sorted insertion, exact default tail,
   unchanged leases/resources/prior proposals, and one sequence advance. For every
   denial, require the exact whole snapshot and exact outcome frame.
5. Compile exact-width and capacity assumptions into the witness with static
   assertions: unsigned 16/32/64-bit carriers, eight proposal slots, eight lease
   slots, and four resources.
6. Add a private terminal-sequence test target. Production code receives no sequence
   setter. Mutated outcomes and post-states must be rejected by the checker.
7. State a matching HOL value transformer in
   `P0_Authority_Propose_Refinement.thy`: explicit natural-number width bounds,
   fixed capacity, ordered first failure, exact denial frame, exact selected proposal
   registration, one sequence advance, and context-validity preservation.
8. Keep the formal gate BLOCKED until the pinned Isabelle2025-2 session runs. Keep
   the implementation-refinement gate OPEN because no mechanized C++20 source,
   object-representation, ABI, compiler, concurrency, or full-array-to-HOL relation
   has been established.

## Consequences

One concrete semantic edge is materially narrower: the hosted implementation is no
longer compared only by rendered text, and the expected transformer can reject
specific state mutations. The HOL source now chooses PROPOSE and its first-failure
semantics instead of leaving the sequence transformer abstract.

This is a value correspondence square, not a completed C++ refinement theorem. The
HOL context observes an identifier set/count and selected proposal registration; the
C++ witness observes every snapshot cell. Their exact vertical relation is still an
open proof obligation.

## Rejected alternatives

- **Make `canonical()` the representation relation:** rejected because formatting is
  not a typed state relation and can omit physical frame defects.
- **Share validation helpers between core, reference, and checker:** rejected because
  one defect could be reproduced three times.
- **Generate C++ and Isabelle from a new PROPOSE DSL:** rejected because the current
  counterexample does not justify another parser/generator/trust surface.
- **Expose a production sequence setter:** rejected because it widens mutation
  authority solely for an unreachable test state.
- **Call the executable checker a proof:** rejected because compiler execution is
  bounded evidence, not deductive source semantics.
- **Continue to ISSUE/INVOKE/REVOKE in the same revision:** rejected by the one-edge
  progress budget.
