# DEC-0007 — The C++20 semantics bridge is part of the machine

**Status:** accepted foundation; route selected for `DERIVE` by DEC-0008

The project will not equate source review or trace agreement with a proof about C++.
The bridge is designed from Epoch Zero rather than postponed until after a kernel
exists.

The current direction is a deliberately tiny **SlopOS Verified C++20 Subset** for
authoritative transitions, paired with an implementation-level formal language
called KIR-0.  KIR-0 must model fixed arrays, bounded indices, scalar bitmasks,
conditionals, total results, and explicit record updates—nothing more at first.

DEC-0008 selected the generated-core route for `DERIVE`.  The following two routes
remain architectural options only for future bodies, and neither is presumed:

1. formally define a syntax-directed translation for the restricted C++ shape and
   make a C++20 checker emit a correspondence witness; or
2. make KIR-0 the authoritative transition program and generate the restricted
   C++20 body with a proof-producing, independently checkable translation scheme.

The `DERIVE` experiment generated one closed body and localized the remaining fact,
commit, finite-sequence, compiler, and platform debts.  It does not force generation
for later operations.  `OBL-CPP-SEM-001` remains open until the claimed executable
scope is actually connected to formal implementation semantics.
