# DEC-0013 — Capability representation is a presence-gated value relation

**Status:** accepted and implemented as source/candidate-proof machinery in rev0765
**Objective:** E0-P4
**Primary obligation:** `OBL-CAP-REP-001`
**Dependent obligations:** `OBL-KIR-FACTS-001`, `OBL-KIR-COMMIT-001`,
`OBL-SEQUENCE-REFINE-001`, `OBL-CXX-COMPILER-001`, `OBL-CPP-SEM-001`

## Decision

The active bridge between the fixed C++20 capability table and the Isabelle
capability map is a relation over **source-language values**, not a claim that their
representations are identical.

For each admitted slot below twelve:

```text
cell.live == false  <=>  formal map(slot) = None
cell.live == true   <=>  formal map(slot) = Some(fieldwise_projection(cell))
```

Every formal slot at or above twelve is `None`. A dead cell's holder, generation,
object, rights, and parent payload is inert. It is not validated as a capability and
cannot denote authority, lineage, currentness, or an object merely because the
storage contains suggestive values.

A live cell is admitted only when its typed value fields satisfy the current K0
value invariants:

- holder is a nonzero `uint16_t` value;
- generation is nonzero;
- object kind is exactly domain, memory, or endpoint and object id is nonzero;
- rights uses only the seven admitted bits;
- parent is either the `uint16_t` sentinel `65535`/formal `None` or an in-range
  capability slot.

The C++ proof-facing projection is `include/slopos/k0/capability_representation.hpp`.
The generic candidate Isabelle cell/list relation is
`proof/K0_Capability_Representation.thy`; DERIVE fact, child, update, frame,
sequence, and rejection specialization lives only in
`proof/K0_Derive_Representation.thy`. The C++20 proof emitter transcribes the active
constants and schema fingerprint into
`proof/generated/K0_Capability_Encoding_Generated.thy` and
`generated/k0/capability-encoding.txt`.

## Exact-fact correction

During construction, the bridge exposed a previously hidden mismatch. Generated
C++ fact extraction reports `requested_subset = false` when the requested rights
mask is invalid because `rights_subset` includes validity. The formal fact record
previously decoded a right set and could report subset true even while
`requested_valid = false`.

The ordered guard outcome did not differ because `rights_valid` precedes
`requested_subset`, but exact fact correspondence did. The formal definition now
gates subset by requested validity:

```text
requested_subset := requested_valid AND requested ⊆ parent.rights
```

This is a semantic correction to the proof-facing fact record, not a change to
accepted or rejected transition behavior.

## Evidence posture

Rev0765 adds an independent C++20 value-projection witness with exact frozen domains
for:

- dead-payload irrelevance;
- all admitted live field projections over a bounded Cartesian domain;
- rejection of invalid live cells;
- generated fact equality through the projected map;
- successful one-cell DERIVE projection plus all-other-cell frame;
- terminal DERIVE whole-array frame.

The two Isabelle files contain candidate definitions and lemmas for out-of-range
absence, dead-cell irrelevance, exact DERIVE facts, one-cell update, frame,
sequence advance, and formal rejection preservation. Without a retained Isabelle
checker run, these rows remain `CANDIDATE_THEOREM`. The finite C++ witness remains
`BOUNDED`.

## Nonclaims

CAP-REP does not establish:

- C++ object layout, padding, byte representation, pointer provenance, enum ABI, or
  `std::array` layout;
- ISO C++20 operational semantics for the generated transition;
- compiler, optimizer, linker, standard-library, host, or hardware correctness;
- the validity of an arbitrary live cell outside the admitted relation;
- revocation, slot reuse, generation bumping, object lifecycle, concurrency, or
  platform isolation;
- formal refinement for MAP, SEND, or RECEIVE.

These boundaries are deliberate. `OBL-CXX-COMPILER-001` and
`OBL-CPP-SEM-001` remain open.

## Construction consequence

No new K0 operation or platform effect may enter merely because the value relation
now has source. E0-P5 connects the fixed bootstrap and sequence zero to this relation
through an independent all-or-nothing C++20 value image. A compatible Isabelle
checker is run and retained whenever available before any theorem row advances; its
absence does not block the bounded construction. Implementation continues to teach
the proof, but feature growth remains fenced.

## Rev0766 checked-status addendum

The rev0765 decision text above records the state at activation. Rev0766 installed
the pinned Isabelle2025-2 toolchain, repaired checker-demonstrated theory defects,
and obtained acceptance for the exact CAP-REP/DERIVE proof-value lemmas mapped in
`proof/theorems.tsv`. Those exact formal rows are now `THEOREM` when the retained
the current revision evidence is current.

This promotion does not change the decision's nonclaims. In particular,
`OBL-CAP-SCALAR-CXX-001`, `OBL-CAP-REP-CXX-001`, the generated fact/commit C++
edges, compiler/ABI behavior, and platform effects remain open. Rev0768 refined the
single-cell decision into `caprep::scalar::project`, checked its mathematical value
semantics, and rejected AutoCorres2 as a standing C++ bridge. Rev0769 added the
checked seven-atom source program and exact accepted-export/active-header byte gate.
Rev0770 added a fail-closed whole-input exact-fragment binder and deterministic
finite certificate. Rev0771 adds a direct HOL structural evaluator and independent
C++20 fragment interpreter without widening the machine. Binder correctness,
preprocessing, ISO C++20 adequacy and UB exclusion, compiler, ABI, binary, and
platform effects remain open. E0-P10 subsequently retained one measured front-edge
reduction without closing those debts.

## Rev0772 self-contained-companion addendum

E0-P10 retains one proof-only source spelling generated from the same checked scalar
program. It replaces imported fixed-width names and macros with `bool` and
`unsigned long`, and removes every source directive and project declaration from the
companion translation unit. The exact 593,907-case C++20 witness agrees with the
active fixed-width projection under selected compiler lanes.

This does not change CAP-REP, the richer `Capability` wrapper, object layout, the
active kernel source, or admitted K0 behavior. `unsigned long` exact width, C++20
expression/initialization semantics, compiler preservation, and universal
companion-to-active correspondence remain named debt. DEC-0025 owns the scope.
