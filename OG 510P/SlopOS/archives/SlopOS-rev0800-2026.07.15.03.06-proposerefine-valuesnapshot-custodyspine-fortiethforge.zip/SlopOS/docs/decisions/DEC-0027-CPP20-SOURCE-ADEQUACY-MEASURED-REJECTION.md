# DEC-0027 — Freeze the scalar island after measured source-adequacy rejection

Status: accepted in rev0776

## Decision

The bounded E0-P12 attempt to prove that the exact frozen 2,570-byte C++20
companion token stream parses, binds, types, and normalizes to the admitted HOL
value-language AST is **rejected as a local proof route**. The open relation remains
recorded as `OBL-CAP-SCALAR-COMPANION-ADEQUACY-001`; it is not declared false and it
is not silently discharged.

No further scalar-front-end machinery is admitted during epoch-zero unless a later
measured decision supplies one of:

1. a maintained formal C++ semantics covering the exact selected fragment and its
   implementation envelope;
2. a translation-validation route whose trusted surface is smaller than the edge it
   closes; or
3. a proof-producing compiler/frontend path with an explicit checker and exact
   source/ABI scope.

## Why the bounded route was rejected

The exact bytes, source audit, binder certificate, compiler acceptance, bounded
compiled agreement, normalized AST, and checked AST evaluator establish useful but
separate facts. None gives ISO C++20 tokenization, declaration binding, type and
conversion rules, aggregate initialization, control-flow meaning, or compiler
preservation.

A tiny Isabelle parser for only this spelling would prove the meaning of a new
proof-owned micro-language unless its rules were themselves connected to C++20. A
second parser generated from the same source template would add agreement without
independence. Reconstructing a general C++ front end inside the current proof root is
larger than the scalar island and delays the first machine-realization experiment.

## Retained value

The scalar island remains frozen and useful:

```text
exact generated source bytes                         CONFORMANCE
finite structural certificate                        THEOREM + CONFORMANCE
closed normalized value-language evaluation          THEOREM
selected implementation range/type checks            CONFORMANCE
bounded companion/active compiled agreement           BOUNDED
source-to-AST and compiler preservation               OPEN_DEBT
```

The source, generated companion, tests, ledgers, and exact Isabelle theorems remain
active. Rejection of the attempted bridge is not rejection of C++20, Isabelle, or the
future compiler-correctness moonshot.

## Consequence

Epoch-zero moves to `M0-STATIC2`, while preserving the C++ source-semantics debt as a
named future ladder edge. No product or platform claim may borrow assurance from the
frozen scalar island beyond its exact propositions.
