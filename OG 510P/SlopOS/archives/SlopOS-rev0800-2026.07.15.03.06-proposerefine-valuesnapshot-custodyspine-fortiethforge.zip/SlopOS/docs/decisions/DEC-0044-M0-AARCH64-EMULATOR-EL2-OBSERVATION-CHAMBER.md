# DEC-0044 — M0 AArch64 emulator EL2 observation chamber

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P14R only
- Depends on: DEC-0043 and the sealed rev0795 construction
- Supersedes: no prior emulator or hardware claim

## Decision

SlopOS admits one exact, emulator-only AArch64 observation chamber. The chamber
binds:

```text
sealed rev0795 host-publication values
+ one byte-pinned QEMU 11.0.2 system emulator
+ one closed virt-10.0 / cortex-a57 / single-PE TCG profile
+ one byte-pinned freestanding observer image
+ one C++20 process supervisor and strict report parser
-> one finite observation certificate
-X-> machine-premise discharge, stage-2 effect, boot, or isolation
```

The accepted result is named:

```text
OBSERVED_EL2_ENVELOPE_STAGE2_INACTIVE
```

It means only that the selected emulator/report relation observed the selected
finite register values and that `HCR_EL2`, `VTCR_EL2`, and `VTTBR_EL2` were all
zero. It does not authorize or perform a stage-2 transition.

## Exact chamber

```text
QEMU version line
  QEMU emulator version 11.0.2 (https://github.com/tianon/docker-qemu)

QEMU bytes
  36,138,712

QEMU SHA-256
  3b6c3b1c5ad413eebc6c3afd57d600bfb2810455ffeef4160795174a4b85b81f

machine
  virt-10.0,virtualization=on,secure=off,highmem=off,
  dtb-randomness=off,gic-version=3

CPU
  cortex-a57

accelerator / PEs / RAM
  tcg,thread=single / 1 / 64 MiB

observer entry
  0x40200000
```

The selected OCI index, manifest, config, required layers, deliberately omitted
firmware-only layer, executable identity, and recovery script identity are
recorded in `toolchains/qemu-aarch64.lock`.

## Exact observer

The observer is an explicit, narrowly quarantined exception to the C++20 law:

```text
spec/m0/aarch64-el2-observer.S
spec/m0/aarch64-el2-observer.ld
generated/m0/aarch64-el2-observer.elf
```

It is allowed only because the selected machine begins before a C++20 runtime
or ABI can honestly exist. The permanent supervisor, parser, evidence collector,
model, mutation harness, and office machinery remain C++20.

The observer contains no `BL`, `RET`, X30 use, stack, heap, stage-2 register
write, page-table write, DSB, ISB, TLBI, K0 transition, scheduler, or guest
payload. It reads eight registers, writes fixed-width hexadecimal fields into a
static report, uses semihosting to emit that report, and exits.

## Exact selected report

```text
SLOPOS_EL2_OBSERVATION_V1
CURRENT_EL=0000000000000008
MIDR_EL1=00000000411fd070
ID_AA64PFR0_EL1=0000000001000222
ID_AA64MMFR0_EL1=0000000000001124
ID_AA64MMFR1_EL1=0000000000000000
HCR_EL2=0000000000000000
VTCR_EL2=0000000000000000
VTTBR_EL2=0000000000000000
END=1
```

The selected finite decoder derives:

```text
CurrentEL decoded value   2
EL2 feature field         2
PA range field            4
TGran4 field              0
TGran4_2 field            0
VMID bits field           0
```

These are repository-level natural values. The theorem root does not import Arm
operational semantics for the reads or their architectural meaning.

## Machine-premise law

The certificate requires all twelve observation-value facts and records all
twelve as observed. It separately retains all fourteen rev0794 AArch64 machine
premises and discharges zero:

```text
required observation mask   0x0fff
observed observation mask   0x0fff
required machine mask       0x3fff
discharged machine mask     0x0000
```

A forged discharge mask is rejected. EL2 presence, feature values, or zero
stage-2 controls do not establish machine publication, effective permission,
translation stability, cache completion, live entry/fetch, BL/X30/RET
completion, boot, or isolation.

## C++20 supervisor contract

The permanent supervisor:

- verifies exact QEMU extent and FNV identity;
- verifies the exact version line and required machine/CPU availability;
- verifies observer source, linker, and ELF identities;
- rebuilds the observer through the identified Clang/LLD path and byte-compares
  the result;
- launches without a shell using `fork` and `execv`;
- creates and owns a process group;
- removes ambient `LD_PRELOAD` in the child;
- supplies only the selected QEMU rootfs library and data paths;
- bounds output and time;
- captures one combined stdout/stderr stream;
- requires exit zero and the exact report; and
- maps every failure to an explicit terminal status.

Semihosting is admitted only as the trusted byte-pinned observer's report/exit
channel. It is not a product interface or an authority boundary.

## Isabelle boundary

Isabelle checks exact finite values, status precedence, acceptance, rejection
framing, zero machine discharge, and preservation of the M0-P13R theorem. It
does not prove the C++20 implementation, QEMU, Clang/LLD, the ELF loader, the
Arm registers, semihosting, or the host kernel.

## Non-claims

M0-P14R does not establish:

```text
formal QEMU correctness
emulator-to-hardware equivalence
formal Arm register or instruction semantics
boot firmware provenance
generic-loader correctness
stage-2 register authority or initialization correctness
stage-2 publication or activation
effective translation or permission
cache or TLB completion
guest execution
CPU isolation
DMA, SMMU, device, or interrupt isolation
multicore or concurrency correctness
product readiness
```

## Next bounded step

M0-P15R may load one exact generation-3 page into a fixed emulator RAM extent
and have the same bounded observer read/fingerprint it. That remains an emulator
publication/readback observation and must still stop before stage-2 control
writes, permission claims, execution from the page, guest entry, or isolation.
