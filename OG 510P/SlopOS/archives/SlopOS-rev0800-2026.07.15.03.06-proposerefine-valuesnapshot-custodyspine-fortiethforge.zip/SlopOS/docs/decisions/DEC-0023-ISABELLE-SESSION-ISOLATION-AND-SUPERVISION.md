# DEC-0023 — Isabelle session isolation and proof-process supervision

- Status: accepted for Epoch Zero
- Revision: 0770
- Refines: DEC-0015 and DEC-0018
- Applies to: the permanent C++20 proof runner and every theorem-bearing office check

## Context

A fresh rev0769 replay exposed a defect in the previous office law. The runner used
`isabelle build -c` while placing its working directory beneath the repository's
ordinary `build/` tree. CMake products disappeared during that proof test, and an
interrupted long run demonstrated that expensive prover work could outlive its
calling tool layer. The replay did not isolate enough variables to prove that
Isabelle's clean switch alone removed the CMake files; the defect is the unsafe
combined process/filesystem boundary, not an unsupported accusation about Isabelle
internals. A proof command that can damage or outlive the office invoking it is not a
trustworthy evidence gate.

The defect was found by replay, not by prose review. The pinned Isabelle2025-2
System Manual confirms that `-c` cleans selected sessions and descendants, `-f`
forces selected sessions and requirements fresh, user settings live beneath
`ISABELLE_HOME_USER`, and independent build coordination is a client concern. The
retained source reading is `docs/research/ISABELLE-SESSION-ISOLATION-NOTES.md`.
  Rev0770 therefore treats the
proof process itself as an effectful construction component whose filesystem,
process, resource, and concurrency boundaries must be explicit.

## Decision

### One private target-session workspace per repository

Every `slopos-proof check` uses only:

```text
workspace root      <repo>/.slopos-work/isabelle
working directory   <repo>/.slopos-work/isabelle/run
HOME                <repo>/.slopos-work/isabelle/home
SlopOS heap/database <repo>/.slopos-work/isabelle/home/.isabelle/heaps
lock                 <repo>/.slopos-work/isabelle-session.lock
```

The workspace is excluded from the construction basis, language audit, revision
archive, and source tree.  It is disposable execution state, never evidence.

Before a theorem run, the C++20 runner acquires the exclusive lock and clears only
`<repo>/.slopos-work/isabelle`.  A second runner fails closed rather than deleting or
sharing the first runner's target session.  The lock file is outside the cleared
subtree and remains held for the complete build/export transaction.

### No global clean or fresh build switch

The exact target command is:

```text
HOME=<repo>/.slopos-work/isabelle/home \
isabelle build -v -j 1 \
  -o quick_and_dirty=false \
  -o naproche_server=false \
  -d <repo>/proof SlopOS_K0
```

The runner does not pass `-c` or `-f`.  A newly cleared private `HOME` contains no
SlopOS target database, so the selected target is rebuilt without asking Isabelle to
clean unrelated sessions or rebuild distribution ancestors.  The pinned Isabelle
Pure/HOL distribution heaps remain external read-only prerequisites; no theorem row
claims they were rebuilt by SlopOS.

The private settings file pins one session worker, two internal Isabelle threads, a
1,536 MiB Java ceiling, a 2,048 MiB Poly/ML ceiling, and one Poly/ML GC thread for
the current 4 GiB cloudtainer.  Rev0781 raised the earlier one-thread/1,536 MiB ML
envelope only after that envelope failed to complete the unchanged accepted theory
graph within the close window.  These are deterministic operational limits, not
theorem premises unless a future claim explicitly names them.

### Supervised process tree

The C++20 runner forks a supervisor, then a worker process group containing the exact
Isabelle command and descendants.  On Linux the supervisor requests a parent-death
signal.  `SIGTERM`, `SIGINT`, or `SIGHUP` to the supervisor terminates the complete
worker group, escalating to `SIGKILL` only after a bounded grace period.  Isabelle
output is streamed while also retained in the evidence log so a long silent tool
call is not mistaken for an idle office.

This is process containment, not a proof of Isabelle or JVM correctness.

### Evidence binding

The evidence packet records:

- exact command and Isabelle version;
- private working, home, heap, and lock paths;
- proof-tree and construction-basis fingerprints;
- proof-hole count and session completion marker;
- C++20 exact-fragment binding state and identities;
- generated-source export command and byte comparison.

`TOOLCHAIN_READY`, `SESSION_ACCEPTED`, `BINDING_CURRENT`, and
`SOURCE_BYTES_CURRENT` remain distinct states.

## Enforcement

The ordinary CTest graph always contains the doctor and exact session check.  Unit
fixtures establish that:

- `-c` and `-f` are absent;
- the private `HOME`, working directory, heap path, and lock path are exact;
- a competing session lock rejects before Isabelle is invoked;
- a destructive child action below the private working directory cannot erase a
  CMake sentinel;
- the evidence packet retains every isolation field;
- generated-source mismatch still rejects after a successful theorem build.

Cold-extraction close evidence must additionally show that the CMake executables
remain present after the real Isabelle check and that no Isabelle/Java/PolyML worker
survives completion.

## Non-claims

This decision does not prove:

- Isabelle, Poly/ML, Scala, Java, operating-system, or filesystem correctness;
- absence of every resource-exhaustion or kernel-level orphan failure;
- hermeticity of the external Isabelle distribution or imported HOL heap;
- compiler, ABI, binary, boot, or platform semantics for SlopOS;
- that a successful process run closes any obligation not mapped in the theorem
  ledger.

## Recovery law

A lost `.slopos-work/` directory requires no repair; the next proof check recreates
it.  A lost Isabelle distribution still follows DEC-0018 and the pinned bootstrap
script.  A stale lock with no owning process is released by the kernel when the old
file descriptor disappears; deleting the pathname is neither required nor sufficient
while a live owner exists.
