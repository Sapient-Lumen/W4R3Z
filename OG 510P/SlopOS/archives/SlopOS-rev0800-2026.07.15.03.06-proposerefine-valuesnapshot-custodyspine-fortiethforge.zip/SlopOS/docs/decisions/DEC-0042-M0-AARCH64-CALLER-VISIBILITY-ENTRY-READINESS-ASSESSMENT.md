# DEC-0042 — M0 AArch64 caller visibility and entry-readiness assessment

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P12R only
- Depends on: DEC-0037 through DEC-0041
- Supersedes: no sealed historical fact

## Decision

SlopOS admits one exact **caller visibility and entry-readiness assessment** for
the sealed generation-3 caller/helper pure value. The assessment closes the
value-side inventory and keeps every machine-side premise independently visible.

```text
sealed rev0793 generation-3 caller/helper pure value
  + twelve exact value requirements
  + fourteen explicit machine premises
  + sixteen ordered assessment steps
  + one total fail-closed readiness relation
  -> accepted blocked assessment
  -X-> machine publication
  -X-> effective permission
  -X-> cache or translation effect
  -X-> live entry state
  -X-> BL / RET execution or completion
```

Acceptance proves that the assessment is a complete current value. It does not
convert any undischarged premise into a machine fact.

## Exact predecessor and artifact bindings

The assessment binds the sealed rev0793 tuple exactly:

```text
caller artifact FNV       2e63155fe84fcc6e
installed memory FNV      e75835fa071041d1
caller-edge FNV            f043cb390debd722
return-repair FNV          9c783eb50a1689e3
helper-visibility FNV      1b85bcad6a8fc3c3
caller placement FNV       7a79f895a17ab727
visibility-value FNV       1e7bff8aa852f236
caller source FNV          450556c451bf54cd
caller object FNV          0782ca8f69f67328
caller text FNV            96c0b135d893d511
generation                 3
owner                       0
permission value            13
```

The selected value ranges and terminal words are:

```text
page          0x40008000 .. 0x40009000
helper        0x40008000 .. 0x40008028
caller        0x40008040 .. 0x40008048
call site     0x40008040
callee entry  0x40008000
continuation  0x40008044
expected X30  0x40008044
BL word       0x97fffff0
NOP word      0xd503201f
RET X30 word  0xd65f03c0
```

These are values, not live addresses, fetched instructions, or register
observations.

## Twelve observed value requirements

The selected observed mask is exactly `0x0fff`. It records:

```text
PREDECESSOR_CURRENT
CALLER_ARTIFACT_EXACT
GENERATION3_MEMORY_EXACT
HELPER_BYTES_PRESERVED
CALLER_BYTES_CURRENT
RANGES_EXACT
CALL_PROJECTION_EXACT
HELPER_TERMINAL_EXACT
OWNER_EXACT
PERMISSION_VALUE_EXACT
MIXED_GENERATION_REJECTED
LIVE_DEBT_EXPLICIT
```

All twelve are finite repository facts already supported by the rev0793 source,
object, pure-memory, and formal-value chain.

## Fourteen undischarged machine premises

The selected required mask is exactly `0x3fff`; the discharged mask is exactly
zero:

```text
MACHINE_BYTES_PUBLISHED
EFFECTIVE_READ_PERMISSION
EFFECTIVE_EXECUTE_PERMISSION
EFFECTIVE_WRITE_ABSENT
TRANSLATIONS_STABLE
DCACHE_PUBLICATION_COMPLETE
ICACHE_VISIBILITY_COMPLETE
CALLER_ENTRY_PC_LIVE
CALLER_FETCH_VISIBLE
BL_COMPLETION_OBSERVED
X30_OBSERVED_AT_CONTINUATION
SAME_EL_RETURN_PERMITTED
RET_COMPLETION_OBSERVED
CONTINUATION_FETCH_VISIBLE
```

Premise presence is not premise truth. No source, proof, test, receipt, or
fingerprint in this revision establishes any of these fourteen propositions of
a live machine.

## Exact entry record

The selected record describes the intended entry envelope only:

```text
current EL              2
execution state         AArch64
same-EL return required true
entry PC observed       false
X30 observed            false
```

The numeric entry/continuation relation is exact, including
`continuation = call_site + 4`. The record does not claim a processor entered at
that PC or held the selected X30 value.

## Ordered assessment protocol

The sixteen steps are exact and closed:

```text
BIND_PURE_ARTIFACT
REQUIRE_MACHINE_PUBLICATION
REQUIRE_EFFECTIVE_READ
REQUIRE_EFFECTIVE_EXECUTE
REQUIRE_EFFECTIVE_WRITE_ABSENT
REQUIRE_TRANSLATION_STABILITY
REQUIRE_DCACHE_PUBLICATION
REQUIRE_ICACHE_VISIBILITY
BIND_CALLER_ENTRY
REQUIRE_CALLER_FETCH
REQUIRE_BL_COMPLETION
OBSERVE_X30
REQUIRE_SAME_EL_RETURN
REQUIRE_RET_COMPLETION
REQUIRE_CONTINUATION_FETCH
SEAL_ASSESSMENT
```

Reordering any pair changes the selected value and is rejected. The order is a
finite readiness contract, not an architecture execution trace.

## Exact finite certificate

```text
assessment version       1
wire bytes              512
value requirements       12
machine premises         14
ordered steps            16
single-bit mutations   4096
pairwise step swaps      120
semantic FNV        e28497c1b92213c4
wire FNV            369b5613a4c20c68
selected readiness  BLOCKED_MACHINE_PUBLICATION
entry ready         false
```

The FNV values are deterministic currentness/corruption fences, not
cryptographic authenticity.

## Total fail-closed order

Value admission uses a deterministic precedence that rejects stale version,
extent, predecessor, artifact, generation, ownership/permission, address/word,
value-mask, machine-mask, step order, readiness, and semantic identity drift.
Wire magic, exact extent, stored wire fingerprint, and reserved bytes precede
value admission. Rejected decoding returns an empty assessment. Rejected formal
transitions return the exact prior state.

## Independent C++20 surfaces

```text
include/slopos/m0/aarch64_s2_caller_readiness.hpp
src/m0/aarch64_s2_caller_readiness.cpp
tools/slopos_aarch64_s2_caller_readiness_main.cpp
tests/test_aarch64_s2_caller_readiness.cpp
tests/test_aarch64_s2_caller_readiness_noalloc.cpp
```

The hosted reference path uses hosted collections; the constrained path writes
fixed arrays directly. They share closed declarations and selected constants,
not construction loops. The permanent C++20 harness checks exact agreement,
strict serialization, status/readiness precedence, all 4,096 one-bit mutations,
all 120 pairwise step swaps, rejection framing, and no observed allocation on
the warmed constrained path.

## Isabelle root

`M0_AArch64_S2_Caller_Readiness.thy` checks exact finite propositions about:

- extents and closed requirement/premise sets;
- exact masks and the fact that all machine premises remain outstanding;
- exact predecessor, artifact, source, object, text, generation, owner, and
  permission values;
- exact ranges, entry addresses, words, and `PC+4` continuation relation;
- absence of live PC/X30 observations;
- exact step kinds, premises, ordinals, and addresses;
- selected acceptance and exact blocked readiness;
- selected non-readiness;
- precedence and rejection-state frame;
- selected admission and transition; and
- preservation of the rev0793 caller-artifact admission.

The theory imports no live memory, page-table, cache, register-file, exception,
or Arm instruction-step semantics.

## Non-claims

This decision does not establish:

```text
host or physical memory publication
stage-1 or stage-2 permission installation
translation stability
cache maintenance or instruction visibility
live PC, X30, PSTATE, EL, stack, exception, or scheduler state
BL issue, retirement, or completion
RET permission, execution, or completion
continuation fetch
boot or guest execution
CPU memory isolation
DMA/SMMU/device isolation
multicore or information-flow security
```

## Next bounded experiment

M0-P13R may construct one exact **hosted publication adapter experiment** in
C++20. It may allocate one anonymous host page, copy the selected generation-3
bytes, verify readback, transition the host mapping from writable to read/execute
through a quarantined adapter, and record exact syscall results. It must not
execute the page and must not claim AArch64 physical publication, stage-2
permission, cache completion, or any of the fourteen machine premises above.
