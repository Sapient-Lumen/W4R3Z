# DEC-0016 — One verified core, four profile theorem bundles

**Status:** accepted
**Revision activated:** 0766

## Product intent

SlopOS is aiming, without pretending infancy has achieved it, at four product
shapes:

- **A:** secure workstation;
- **B:** cloud micro-VM / hosted compute substrate;
- **C:** embedded / separation-kernel-ish appliance;
- **D:** agent and automation operating system in which LLMs are first-class
  developers and users but never ambient authorities.

These are not four kernel forks. They are one small privileged core plus
profile-specific configurations, assumptions, services, and theorem bundles.

## Shared theorem spine

Every profile must inherit a common core bundle for capability integrity, spatial
isolation, state well-formedness, total fail-closed interfaces, initialization, and
explicit low-level assumptions. A profile may claim only the additional properties
whose configuration and platform obligations are discharged for that profile.

## Profile additions

- A adds human-session, input/display, device, DMA/IOMMU, legacy-domain, and local
  confidentiality/integrity obligations.
- B adds virtualization, second-stage translation, vCPU/interrupt, tenant
  separation, lifecycle, image/provenance, and remote-verification obligations.
- C adds static partition, schedule, device assignment, bounded resource,
  deterministic recovery, and appliance configuration obligations.
- D adds proposal/admission/effect separation, provenance, currentness, receipts,
  replay, revocation, and policy mediation. Most of this belongs in P0 Runtime, not
  the privileged K0 core.

A proof about one profile never silently promotes another. The product matrix is a
claim-selection surface, not an implementation branch plan.
