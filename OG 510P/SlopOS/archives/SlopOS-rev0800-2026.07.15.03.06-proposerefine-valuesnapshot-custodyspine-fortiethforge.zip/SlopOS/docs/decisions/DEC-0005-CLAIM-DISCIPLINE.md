# DEC-0005 — Claim and evidence discipline

**Status:** accepted

Every substantial statement is classified as one of:

- **THEOREM:** discharged by the named proof checker over the named formal model;
- **BOUNDED:** exhaustively established only for an explicit finite universe/depth;
- **CONFORMANCE:** two interpretations produced equal observations for a named
  corpus or generated exploration;
- **TEST:** examples or randomized executions passed;
- **STATIC:** compile-time or static-tool condition passed;
- **DESIGN:** intended semantics, not yet established;
- **DEBT:** named missing link required for a stronger claim.

“Verified,” “proved,” “safe,” and “refines” may not appear unqualified in active
status reports.  Evidence paths and tool versions accompany claims.
