# DEC-0003 — Proof root and refinement ladder

**Status:** accepted and refined through rev0773

The sole primary theorem root is Isabelle/HOL 2025-2. Active implementation and
permanent harness machinery remain C++20; Isabelle theories are the standing
proof-language exception under DEC-0014.

## Ladder

1. **A0 abstract authority machine** — permitted effects and safety invariants,
   without C++ table layout or accidental failure precedence.
2. **D0 deterministic design machine** — capacities, total outcomes, ordered guards,
   observations, and exact state updates.
3. **I0/KIR-0 admitted implementation semantics** — deliberately closed transition
   schemas and value relations small enough to connect to source and proof.
4. **K0 C++20 core** — fixed-capacity compiled implementation.
5. **M0 platform model** — later boot, address spaces, page tables, traps,
   interrupts, memory ordering, DMA/IOMMU, compiler/ABI, and hardware assumptions.

The intended chain is D0 refines A0; I0 represents/refines D0 for admitted schemas;
named C++ source evaluation represents I0; a compiler/binary edge preserves that
source behaviour; and a platform realization satisfies M0. Every arrow is a
separate obligation.

## Current concrete root

For `DERIVE`, one closed KIR program generates the authoritative C++20 transition
body, Isabelle guard data, and a source/binding manifest. CAP-REP and SEQ-REP state
explicit value relations rather than treating C++ objects as mathematical records.

Rev0766 established:

- a reproducibly installed and pinned Isabelle2025-2 toolchain;
- a C++20 proof runner with exact evidence states and basis/proof-tree binding;
- an accepted `SlopOS_K0` session with proof holes disabled;
- an independent all-or-nothing bootstrap value materializer;
- generated bootstrap value constants and checked theorems relating four live roots,
  eight dead cells, out-of-range absence, and accepted sequence zero to the formal
  initial capability map.

Rev0767 additionally makes exact toolchain readiness and recovery a C++20 office
invariant; the session is never conditionally omitted from CTest. Rev0769 makes the
closed scalar program proof-owned and requires exact accepted-export/active-header
byte equality. Rev0770 binds the complete admitted generated C++20 fragment to a
finite certificate and checked certificate/program relation while preserving parser,
renderer, language, compiler, and binary obligations as separate debt.

The accepted formal theorems are enumerated in `proof/theorems.tsv`. They do not
prove evaluated C++ source behaviour, object layout, compiler execution, boot, or
platform isolation.

## Currentness rule

A theorem supports only its exact theory, definitions, assumptions, generated
inputs, session, checker version, proof tree, and construction basis. The evidence
packet under the active revision must say `SESSION_ACCEPTED`, version
`Isabelle2025-2`, session `SlopOS_K0`, and carry matching basis/proof-tree
fingerprints. Any drift requires a fresh run.

## Rev0772 front-edge addendum

Revision 0772 keeps the same theorem root and adds no proof language. The exact
seven-atom program now drives a second generated source artifact: a no-directive,
no-include, no-project-declaration C++20 proof companion. Two mapped Isabelle lemmas
establish companion-program identity and mathematical evaluation; the C++20 runner
requires exact companion export/active byte equality.

This is a narrower landing zone for a later source-language semantics proof, not a
new refinement layer. The active fixed-width kernel header remains K0 source. The
proof companion is A0/I0 evidence machinery, and its correspondence to active source
is presently bounded. ISO C++20 value semantics, compiler/ABI/binary preservation,
and platform execution remain separate arrows.


## Rev0773 normalized-value addendum

Revision 0773 keeps Isabelle/HOL 2025-2 as the sole theorem root and adds no proof
language. A closed normalized value-language model now gives the frozen proof
companion an exact raw result and scalar observation under explicit carrier and
unsigned-long-envelope premises. The theorem does not own the exact source token
stream.

The next arrow remains separately named:

```text
exact proof-owned companion bytes
  -> exact concrete tokens/declarations/name binding
  -> admitted normalized value AST
```

Compiler/ABI/binary and M0 platform arrows remain later obligations. The provisional
`M0-STATIC2` rows are planning boundaries only and are not theorem or implementation
claims.
