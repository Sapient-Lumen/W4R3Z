# DEC-0024 — Separate certificate admission, structural execution, and compiled effect

**Status:** accepted

## Decision

The Epoch Zero scalar bridge now distinguishes three events that earlier revisions
compressed too aggressively:

1. **certificate admission** — the finite certificate is exactly the sole canonical
   certificate admitted by the active theorem root;
2. **structural execution** — an evaluator interprets the certificate's recorded
   constants, comparisons, joins, branches, tags, and present-field initializers;
3. **compiled effect** — the constrained C++20 `scalar::project` function executes
   under a particular preprocessing, language, compiler, ABI, binary, and platform
   envelope.

Isabelle/HOL owns the first two events for the finite proof language. The permanent
C++20 harness contains an independently represented structural interpreter and a
bounded differential witness. Neither fact closes the third event.

The authority-facing evaluators fail closed:

```text
unadmitted certificate -> rejected
malformed structural program -> rejected / no value
admitted well-formed certificate -> structurally evaluated value
```

The canonical admission predicate is exact certificate equality. This avoids a
second hand-maintained list of field constraints becoming a competing authority.

## Why

The rev0770 certificate theorem established that the parsed artifact was canonical,
but its evaluator immediately delegated to the older seven-atom source evaluator.
That proved the result only after assuming away the question E0-P9 was meant to ask:
what do the recorded operators, branch polarities, tags, and initializer order do?

The new evaluator removes that circular shortcut without pretending to be an ISO
C++20 semantics. It is deliberately finite, total at its public boundary, and small
enough to inspect and check.

## Permanent machinery

- `proof/K0_Capability_Scalar_Cpp20_Fragment.thy` defines and proves the direct
  finite evaluator;
- `include/slopos/k0/cpp20_scalar_fragment.hpp` and
  `src/proof/cpp20_scalar_fragment.cpp` implement the independent constrained
  C++20 interpreter;
- `slopos-cpp20-fragment` emits a deterministic witness packet;
- the normal CTest and Isabelle gates require the current binder and fragment
  witness before accepting the theorem session.

The C++ interpreter must not call `caprep::scalar::project` internally. Only the
external witness compares its result with compiled `project` behavior.

## Exact claim

For every HOL proof-value capability cell and every admitted finite certificate, the
direct HOL structural evaluator returns exactly `v0_scalar_project`. Every
unadmitted finite certificate is rejected by the authority-facing evaluator.

For the exact bounded C++ witness domain, the independent C++20 structural
interpreter agrees with compiled `scalar::project`, rejects 33 certificate
mutations at admission, and detects a malformed present-initializer shape.

## Non-claims

This decision does not prove:

- correctness or completeness of the C++20 binder parser;
- preprocessing, includes, macro expansion, translation phases, or token identity;
- ISO C++20 expression, aggregate-initialization, conversion, object-lifetime, or
  undefined-behavior semantics;
- compiler, optimizer, ABI, link, binary, boot, hardware, or platform refinement;
- general C++ parsing or a reusable source-language frontend;
- any K0 operation beyond the existing hosted infant.

## Consequence

`OBL-CAP-SCALAR-CPP20-EVAL-001` is `THEOREM` and
`OBL-CAP-SCALAR-CPP20-EVAL-WITNESS-001` is `BOUNDED`.
`OBL-CAP-SCALAR-CPP20-PARSER-001`,
`OBL-CAP-SCALAR-CPP20-PREPROCESS-001`,
`OBL-CAP-SCALAR-CXX-001`, and the compiler/binary/platform obligations remain open.
The next experiment must reduce one of those assumptions measurably rather than add
another evaluator or a new kernel feature.
