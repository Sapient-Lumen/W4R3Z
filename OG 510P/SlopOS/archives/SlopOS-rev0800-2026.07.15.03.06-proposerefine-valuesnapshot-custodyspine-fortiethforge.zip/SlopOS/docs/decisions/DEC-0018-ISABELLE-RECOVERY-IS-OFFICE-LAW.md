# DEC-0018 — Isabelle recovery is fail-closed office law

**Status:** accepted
**Revision activated:** 0767

## Problem

The authoritative theorem checker is external tool state. Revision archives
intentionally exclude the approximately 1.2 GB Isabelle distribution, compressed
layer, heaps, settings, and build tree. A fresh session can therefore contain valid
proof source but no checker.

Rev0766 documented installation and retained a working bootstrap, but its CMake graph
registered the formal session only when the exact Isabelle executable happened to be
present at configure time. Losing the cloudtainer layer could produce a smaller,
green CTest run. Prose was correct; the ordinary machine path was not fail-closed.

## Decision

Proof-toolchain state is a live office-currentness fact with exactly these probe
states:

```text
TOOLCHAIN_MISSING
TOOLCHAIN_WRONG_VERSION
TOOLCHAIN_READY
```

Every office open performs an exact runtime probe for `Isabelle2025-2`. The active
repository carries all non-secret information needed to recover that installation
and emits one deterministic repository-rooted command whenever the probe is not
ready.

The responsibilities are separated deliberately:

- `slopos-proof doctor` is a fast C++20 launcher/version probe;
- `slopos-office open` combines the closed-tree office audit and live probe and exits
  nonzero unless both pass;
- `slopos-proof check` is the C++20 full-session runner and evidence writer; it
  invokes Isabelle from `.slopos-work/isabelle/run`, never from the repository root,
  with `HOME=.slopos-work/isabelle/home`; removes and recreates that private workspace
  before every selected-session build; holds a repository-private exclusive lock; and
  passes `naproche_server=false` because the bundled unrelated file-format service
  otherwise remains resident after a headless build in this cloudtainer;
- `tools/proof/bootstrap-isabelle-cloudtainer.sh` is the sole active shell exception
  and only transports, verifies, extracts, launches, tunes, and smoke-tests the
  pinned distribution;
- `toolchains/isabelle.lock` records version, session, official archive identity,
  Docker manifest/layer identity, installer identity, and exact proof command;
- `docs/office/RECOVERY.md` is the compulsory lost-layer protocol.

CMake registers `proof-toolchain-doctor` and `isabelle-session-current`
**unconditionally**. Toolchain absence or version drift must fail the normal test
graph rather than remove formal verification from it.

## Required behavior

- `doctor` stops after resolving the launcher and running `isabelle version`;
- `open` prints required/observed version, executable, recovery guide, recovery
  script, exact command, and next action;
- the full checker uses an absolute proof-directory argument, a remove-and-recreate
  construction-excluded workspace, repository-local HOME/heaps, and an exclusive
  session lock, so ambient target heaps and concurrent runs cannot establish current
  acceptance;
- the exact batch command disables the unrelated Naproche server, and close evidence
  confirms that no such persistent helper remains after the session;
- missing or wrong tooling blocks theorem-bearing semantic work;
- a full `check` remains mandatory at opening and at every theorem-bearing close;
- a local uploaded layer may be used only through the same exact size and digest
  checks;
- the distribution, caches, heaps, credentials, and user settings never enter a
  revision archive;
- vague `UNAVAILABLE` is not an accepted active status.

## Evidence states remain distinct

```text
TOOLCHAIN_READY       launcher identity accepted
SESSION_REJECTED      exact session attempted and failed
SESSION_ACCEPTED      exact session completed successfully
THEOREM_EVIDENCE      accepted run bound to the current basis and proof tree
```

A version probe is not theorem evidence. Generated theory text, a source-hole scan,
an old proof log, C++ tests, or a previously accepted basis do not substitute for the
current exact session.

## Consequences

A future human or LLM can recover the checker from repository state without relying
on chat memory, diagnose the exact failure, and replay the proof graph. Operational
inconvenience is no longer a reason to change theorem roots or accumulate unchecked
formal source.

A proof-toolchain recovery-only office may close without theorem progress only when
no theorem-bearing basis changed and the precise failure/recovery result is recorded.
All ordinary theorem-bearing closes require `SESSION_ACCEPTED` under the exact
current construction basis.
