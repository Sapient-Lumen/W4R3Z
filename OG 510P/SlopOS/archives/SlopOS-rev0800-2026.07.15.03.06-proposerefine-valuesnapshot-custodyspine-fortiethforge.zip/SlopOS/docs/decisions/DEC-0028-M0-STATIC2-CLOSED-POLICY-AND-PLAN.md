# DEC-0028 — Admit one closed M0-STATIC2 policy and installation plan

Status: accepted in rev0776

## Decision

The first active M-layer construction is one immutable, two-domain, CPU-memory
policy named `M0-STATIC2`. It is deliberately smaller than a hypervisor profile,
configuration language, page-table generator, or boot image.

Its selected physical page aperture is:

```text
0 .. 15    monitor-reserved; not mapped into either domain
16 .. 31   domain 1 private pages
32 .. 47   domain 2 private pages
48         exactly declared shared page
49 .. 63   unused by the selected plan
```

Each domain sees its sixteen private pages at virtual pages `0..15` and sees physical
page 48 at virtual page 16. All selected mappings are read/write at this abstract
rung. The plan therefore contains 34 mapping records and 33 distinct physical pages.

## Active representations

1. `Static2Policy` is the C++20 mathematical value used by the harness.
2. A fixed 192-byte, seven-record little-endian wire value is the only admitted
   policy artifact in this revision.
3. An independent hosted reference planner and constrained fixed-capacity planner
   must produce the same ordered 34-record plan.
4. Independent reference and constrained installers admit each exact record once,
   reject unknown or duplicate records without state change, and seal only after all
   34 records are present.
5. A C++20 generator emits an exact Isabelle plan constant and a human-readable
   witness. Isabelle proves properties of those exact generated values.

The generator/currentness edge is visible and does not become a theorem about C++
source semantics.

## Claim boundary

This revision closes only policy-value and abstract-plan propositions. It supplies
bounded C++ evidence for wire admission and install-ledger behavior. It does **not**
claim:

- page-table descriptor correctness;
- table placement, roots, control-register values, TLB protocol, or live selection;
- boot or guest execution;
- DMA/IOMMU or device isolation;
- interrupts, multicore, scheduling, information flow, timing, or side channels;
- a general configuration, VM, workstation, appliance, or agent product.

## Next rung

Architecture encoding remains a separate obligation. It may begin only with one
selected architecture, page granule, translation regime, emulator/tool recovery
contract, and explicit assumption ledger. The abstract plan must not be retrofitted
to match convenient descriptor constants.
