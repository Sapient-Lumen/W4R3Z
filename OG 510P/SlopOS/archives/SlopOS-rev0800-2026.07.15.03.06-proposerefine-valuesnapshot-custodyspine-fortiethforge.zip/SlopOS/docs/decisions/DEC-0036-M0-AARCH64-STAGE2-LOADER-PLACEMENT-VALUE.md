# DEC-0036 — M0 AArch64 stage-2 loader-placement value

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P10 only
- Depends on: DEC-0028 through DEC-0035
- Supersedes: no sealed construction

## Decision

SlopOS admits one exact **pure loader-placement value** that binds the selected
M0-P9 object and its 36-byte `.text` slice to one aligned numeric destination,
one closed permission-intent value, and one atomic three-page copy/readback
relation.

The admitted relation is only:

```text
M0-P9 exact 560-byte object identity
  + exact source slice [64, 100)
  + numeric destination 0x40008000
  + monitor owner 0
  + read | execute | privileged intent, not write
  + zero target and two immutable guard pages
  -> exact pure installed byte-array value
  -X-> address existence, mapping effect, I-cache visibility, entry, execution
```

## Exact selected value

```text
placement version              1
wire bytes                   256
page bytes                  4096
memory pages                   3
memory bytes               12288
object bytes                  560
text source offset             64
text bytes                     36
prior pure-memory interval     [0x3ffff000, 0x40007000)
guard before                  0x40007000
target                         0x40008000
guard after                    0x40009000
owner                          0
permission intent              13 = R | X | privileged
entry offset                   0
object FNV                     403a5c3a0ee255fe
specimen FNV                   15a2851fdf5adcd5
instruction FNV                3e606113c95c0b62
text FNV                       b256472bea5150c2
placement semantic FNV         eeb86170d0078916
wire FNV                       8cf61eaddd97066c
initial memory FNV             cf9df8ad60a39348
installed memory FNV           da161913c6998db2
```

The three-page frame begins exactly at the end of the prior pure table-memory
value. This is arithmetic disjointness between selected numbers. It does not
establish physical existence, provenance, lifetime, ownership, or authority to
write the named addresses.

## Permission intent is not installed permission

The selected permission value contains read, execute, and privileged intent and
contains no write intent. It is a declarative value only. It does not change a
page table, MPU, MMU, VMA, host mapping, stage-1 mapping, stage-2 mapping, or
instruction-fetch permission.

## Atomic pure installation

The selected initial state has:

```text
frame-before page filled with 0xc3
target page filled with 0x00
frame-after page filled with 0x3c
```

The accepted transition copies exactly the 36 text bytes to the start of the
target page, leaves the 4,060-byte target tail zero, preserves both guard pages,
updates only finite metadata, and returns one exact installed state. Every
rejected transition returns the complete input state.

## C++20 evidence

Independent hosted-reference and fixed-capacity core paths agree. The permanent
harness checks:

```text
2,048 one-bit placement-wire mutations
  288 one-bit text-payload mutations
4,096 dirty-target byte cases
8,192 guard-frame byte cases
```

Every case rejects. The warmed constrained build, encode, decode, initial-state,
install, readback, frame, and memory-serialization path performs no observed
global allocation. These are bounded observations, not ISO C++ semantics or a
platform theorem.

## Isabelle root

`M0_AArch64_S2_Loader.thy` checks exact finite values, alignment, arithmetic
non-overlap, permission intent, entry offset, source/object binding, total
status precedence, exact installed readback, guard framing, rejection atomicity,
selected admission, and preservation of M0-P9 admission.

## Non-claims

M0-P10 does not establish:

```text
host or physical pointer interpretation
address existence, provenance, lifetime, or write authority
general loader semantics
relocation or linking
page-table or MPU permission installation
data-cache or instruction-cache visibility
branch or exception entry
live register, stack, or exception state
privileged execution or architecture completion
hardware translation, boot, CPU isolation, DMA, or device isolation
```

## Next experiment

M0-P11 may construct one finite executable-visibility **intent protocol** that
names publication, permission-selection, cache-maintenance, synchronization, and
entry-readiness obligations under an explicit architecture envelope. It must
still stop before instructions are executed or any cache, mapping, branch, or
hardware effect is claimed.
