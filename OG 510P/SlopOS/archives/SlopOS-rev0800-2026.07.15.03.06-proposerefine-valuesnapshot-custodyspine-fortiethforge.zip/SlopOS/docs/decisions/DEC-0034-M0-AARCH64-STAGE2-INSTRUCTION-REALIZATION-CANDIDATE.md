# DEC-0034 — M0 AArch64 stage-2 instruction-realization candidate

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P8 only
- Depends on: DEC-0028 through DEC-0033
- Supersedes: no earlier sealed construction

## Decision

SlopOS admits one finite **instruction-value candidate** relating the ten
repository-defined M0-P7 abstract architecture events to either:

1. the exact prior owned-memory publication value already established by M0-P5;
   or
2. one exact A64 instruction class, operand form, instruction ordinal, and
   32-bit natural-number word.

This decision closes a finite value relation. It does not claim that a source
spelling, assembler, object, loader, execution environment, Arm PE, or physical
effect realizes that relation.

## Why this rung exists

The proof ladder was previously:

```text
installed value
-> finite activation labels
-> conditional abstract architecture events
-> ?
-> privileged architecture effect
```

Crossing that gap in one step would silently import too much. M0-P8 therefore
freezes the smallest candidate vocabulary that can be falsified before source,
object, execution, or effect machinery is admitted.

The first event, `PUBLISH_TABLE_BYTES`, is deliberately **not** represented by
an invented instruction. It is bound to the prior exact owned-memory value. The
remaining nine events receive one exact instruction-value candidate each.

## Exact selected candidate

```text
candidate version              1
wire bytes                   512
realization rows              10
instruction words              9
register-entry records         3
single-bit mutations        4096

instruction source issue       Arm A-profile A64 ISA 2026-03
instruction source FNV         1d5322862c78e024
candidate vocabulary FNV       6441523671b10ba9
M0-P7 adequacy FNV             83ad24b9253947b3
M0-P6 activation FNV           670fe80725b1dca9
candidate semantic FNV         3e606113c95c0b62
wire FNV                       9250d00b1b9ec4d3
```

The exact register-entry contract is:

```text
X0 -> VTCR_EL2  = 0x0000000000023559
X1 -> VTTBR_EL2 = 0x0001000040000000
X2 -> HCR_EL2   = 0x0000000080000001
```

The exact ordered instruction words are:

```text
0  DSB ISHST                0xD5033A9F
1  MSR VTCR_EL2, X0         0xD51C2140
2  MSR VTTBR_EL2, X1        0xD51C2101
3  ISB SY                   0xD5033FDF
4  TLBI VMALLS12E1IS        0xD50C83DF
5  DSB ISH                  0xD5033B9F
6  ISB SY                   0xD5033FDF
7  MSR HCR_EL2, X2          0xD51C1102
8  ISB SY                   0xD5033FDF
```

The candidate event relation is:

```text
PUBLISH_TABLE_BYTES
  -> PRIOR_OWNED_MEMORY_VALUE

COMPLETE_TABLE_PUBLICATION
  -> DSB / ISHST / word 0

SELECT_VTCR_EL2
  -> MSR_REGISTER / VTCR_EL2_X0 / word 1

SELECT_VTTBR_EL2
  -> MSR_REGISTER / VTTBR_EL2_X1 / word 2

SYNCHRONIZE_SELECTION
  -> ISB / SY / word 3

INVALIDATE_SELECTED_VMID
  -> TLBI_SYS / VMALLS12E1IS / word 4

COMPLETE_INVALIDATION
  -> DSB / ISH / word 5

SYNCHRONIZE_INVALIDATION
  -> ISB / SY / word 6

ENABLE_STAGE2_VM_RW
  -> MSR_REGISTER / HCR_EL2_X2 / word 7

SYNCHRONIZE_ENABLE
  -> ISB / SY / word 8
```

## Register-entry contract

The candidate includes explicit entry values for X0, X1, and X2. This prevents
the source/object rung from silently assuming that a register already contains
the selected value.

The contract is still a value. It does not establish:

- an ABI or calling convention;
- live register contents;
- preservation of other registers;
- exception-level entry;
- stack or memory validity;
- instruction fetch;
- privilege;
- or execution.

Those are future obligations.

## Total fail-closed order

For decoded candidate values, the selected precedence is:

```text
BAD_VERSION
BAD_WIRE_EXTENT
BAD_SOURCE_IDENTITY
BAD_ADEQUACY_IDENTITY
BAD_ACTIVATION_IDENTITY
BAD_REGISTER_ENTRIES
BAD_EVENT_ORDER
BAD_REALIZATION_SHAPE
BAD_INSTRUCTION_WORDS
BAD_SEMANTIC_FINGERPRINT
ACCEPTED
```

Wire magic, exact extent, stored wire fingerprint, and reserved-byte checks
precede value admission. Every ordinary rejection returns the empty candidate.
The formal transition frames the prior admission state.

## Independent C++20 surfaces

The hosted reference builder materializes registers, realizations, and words
through vector-backed intermediate values. The constrained builder assigns
fixed arrays directly. They share declarations and selected constants, not
construction loops.

The permanent C++20 harness checks:

- exact reference/core agreement;
- exact register-entry and word identities;
- total status precedence;
- strict little-endian 512-byte round-trip;
- empty rejection framing;
- rejection of every one of 4,096 single-bit wire mutations; and
- no observed global allocation through the warmed constrained build,
  serialization, decode, and status path.

FNV-1a is a deterministic finite-currentness and corruption fence, not
cryptographic authenticity.

## Isabelle root

`M0_AArch64_S2_Instruction.thy` defines a total finite status relation, one
admission transition, and exact lemmas for source, predecessor identities,
register-entry values, event order, mechanism shape, instruction words,
precedence, rejection framing, selected admission, and preservation of the
M0-P7 adequacy admission.

The generated natural values are proof inputs. Isabelle acceptance does not
prove the C++20 generator, compiler, object, or machine.

## Language law

The implementation and permanent harness remain C++20. Isabelle/HOL is the
approved theorem-language exception. No Python or shell enters the active
instruction model. The narrow shell toolchain bootstrap remains independently
identified and audited.

## Non-claims

M0-P8 does not establish:

```text
formal Arm operational semantics
instruction legality for every implementation
source-text parsing
source or assembler correctness
ELF/object correspondence
relocation absence
loader placement
entry register state
instruction fetch or privileged execution
barrier/TLBI completion
register or translation effect
hardware observation
boot or guest execution
CPU-memory isolation
DMA/SMMU/device isolation
multicore correctness
```

## Next experiment

M0-P9 may construct one exact source/object specimen:

- one preserved assembly source;
- one finite C++20 ELF64 little-endian parser;
- one exact 36-byte `.text` image containing the nine selected words;
- exact section, symbol, and relocation-absence evidence;
- and a finite Isabelle value relation.

That experiment must still stop before assembler correctness, general ELF
semantics, loader placement, register entry, execution, completion, or effect.
