# DEC-0029 — Admit one root-owned AArch64 stage-2 placed value graph

Status: accepted in rev0779

## Decision

The next M-layer rung is one immutable **value graph** over the already selected
`M0-STATIC2` mapping plan.  It contains two domain roots and six 4 KiB translation
-table values: one level-1, one level-2, and one level-3 table per domain.

The selected graph is deliberately closed:

```text
alpha root (domain 1, VMID 1)  0x40000000 -> 0x40001000 -> 0x40002000
beta root  (domain 2, VMID 2)  0x40003000 -> 0x40004000 -> 0x40005000
```

Every table placement is 4 KiB aligned and distinct.  Each root may traverse only
its own three-table placement partition.  A descriptor that is locally shaped like
a table descriptor but points into the other domain's chain is malformed and must
fail closed.

The level-3 values remain the exact rev0778 reconstruction: private physical pages
16–31 for alpha, 32–47 for beta, and physical page 48 shared once in each domain.
The pure value walker must recover the exact 34-record abstract plan.

## Why root ownership is part of the value contract

The first C++20 test admitted a dangerous near miss: descriptor shape and global
table existence were sufficient for an alpha edge to enter beta's chain.  No live
hardware existed, but the counterexample exposed a real authority seam.  The
constrained walker and structural validator now check the expected child placement
at every upper-level edge.  Root identity therefore constrains descendant graph
membership; it is not decorative metadata.

## Active evidence

- independent hosted and fixed-capacity C++20 graph construction;
- a pure C++20 walker and exact-plan recovery check;
- exact little-endian serialization of 3,072 descriptors / 24,576 bytes;
- rejection of all 196,608 one-bit mutations of the selected image;
- no observed allocation in the constrained build/walk/recover/serialize/parse path;
- generated-currentness binding for the manifest, binary image, and Isabelle value;
- Isabelle/HOL structural and exact-value lemmas for placements, roots, owned
  chains, table extents, pure walks, and plan recovery.

## Claim boundary

This decision does **not** establish that the graph is stored in physical memory,
that a CPU reads it, that `VTTBR_EL2` or `VTCR_EL2` has any value, that barriers or
TLB maintenance are correct, that a guest boots, or that CPU isolation holds.  It
does not cover DMA, IOMMU/SMMU, devices, interrupts, multicore, information flow,
side channels, availability, or any A/B/C/D product theorem.

The architecture constants remain a selected value envelope.  SlopOS has not yet
imported formal Arm operational semantics.  The exact graph theorem therefore
cannot silently discharge the broader architecture-encoding obligation.

## Next rung

M0-P4 may construct one **placement/admission packet** that binds the exact graph
bytes, physical destination ranges, root/control value records, and an immutable
load plan.  It must remain a pure value/transaction artifact and stop before actual
memory writes, register writes, barriers, TLB operations, boot, or hardware claims.
