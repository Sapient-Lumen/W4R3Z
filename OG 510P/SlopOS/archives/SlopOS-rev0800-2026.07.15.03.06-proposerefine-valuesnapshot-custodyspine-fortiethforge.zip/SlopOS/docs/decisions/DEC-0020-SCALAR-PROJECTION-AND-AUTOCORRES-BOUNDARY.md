# DEC-0020 — Scalar projection boundary; AutoCorres2 is not the standing C++ bridge

- Status: accepted
- Epoch: zero
- Revision: 0768

## Context

The first source/refinement gap was the relation between checked CAP-REP proof
values and `project_capability_cell` in constrained C++20. The previous body mixed
admission, `std::optional`, array-backed rights, enum decoding, and logical output
construction. AutoCorres2 offered an established Isabelle route for C, but not for
C++20.

A live AutoCorres2 dependency build consumed an ordinary office window without
reaching a SlopOS theorem and was followed by a cloudtainer layer loss. More
fundamentally, a theorem over a C mirror would not establish equivalence to the C++
product source.

## Decision

1. Keep Isabelle/HOL 2025-2 as the sole theorem root.
2. Reject AutoCorres2 as a standing office dependency and as a claimed closure of
   the C++ source edge. Preserve it as a gated research option.
3. Introduce `caprep::scalar::project` as the one proof-facing C++20 value kernel
   for capability-cell admission and field projection.
4. Restrict that function to fixed-width scalar values, canonical value outputs,
   comparisons, Boolean operators, conditionals, and aggregate return.
5. Route `project_capability_cell` through the scalar kernel.
6. Check the corresponding mathematical value semantics in
   `K0_Capability_Scalar_Projection.thy`.
7. Retain exact C++ evaluation, wrapper correspondence, compiler/ABI, binary, and
   platform behavior as separate open obligations.
8. Do not introduce a hand-written C mirror.

## Consequences

The proof-value relation is stronger and the future source target is much smaller.
The active implementation has one new internal value boundary but no new K0 object,
command, authority, or product feature.

The scalar Isabelle theorem is not a C++ theorem. The finite C++ witness is not a
universal theorem. AutoCorres2 remains available only under the reconsideration
gates in `docs/research/AUTOCORRES2-EXPERIMENT.md`.

The next source experiment must either connect the exact scalar C++ source to the
checked value term or move that exact implementation boundary to a generated,
smaller language. It may not broaden K0 to avoid the edge.
