# DEC-0019 — SlopOS is one proof-carrying authority machine

**Status:** accepted
**Revision activated:** 0767

## Decision

The moonshot product shape is one coherent architecture with five named regions:

- **K:** a minimal privileged authority/isolation core;
- **M:** the machine realization and explicit platform assumptions beneath K;
- **P:** a mediated user-space authority Runtime;
- **S:** isolated services, drivers, compatibility domains, and product surfaces;
- **E:** a claim, proof, evidence, provenance, build, and office-currentness system
  spanning every relation without becoming runtime authority.

The secure workstation, cloud micro-VM substrate, embedded appliance, and
agent/automation OS are configurations, service selections, assumptions, and theorem
bundles over this shared architecture. They are not four kernels and do not justify
broadening K during Epoch Zero.

## Unifying product proposition

SlopOS keeps both chains explicit and reviewable:

```text
authority:
  principal intent -> delegation/capability -> admission -> committed effect
                    -> later completion/currentness observation

assurance:
  requirement -> specification -> refinement -> source/compiler/binary/platform
              -> configuration-scoped claim
```

Receipts, traces, proof logs, names, model output, reviews, or agent statements are
evidence about a chain. They do not themselves create runtime authority, current
effect, or proof of an unmentioned edge.

## Construction consequence

Epoch Zero remains a tiny sequential hosted foundation. It must establish a durable
proof loop, representation relations, initialization, one source-semantics edge, and
then one booted isolation story before importing profile services, multicore,
networking, filesystems, UI, agent control planes, or generalized lifecycle.

The likely first physical theorem experiment is a narrow static C or B configuration
because it minimizes dynamic authority and platform surface. This is experiment
sequencing, not cancellation of A, B, C, or D.

## Proof consequence

All profiles inherit one common functional-correctness and authority/isolation spine.
Each then names additional configuration, platform, Runtime, service, security, and
availability obligations. A theorem in one profile never silently promotes another.

E evidence is claim-scoped and currentness-bound. It cannot authorize a K/P
transition or stand in for compiler, binary, boot, hardware, or deployment evidence.

## Relationship to prior decisions

This decision strengthens DEC-0016 and makes the K/M/P/S/E separation explicit. It
does not supersede the C++20 law, the sole Isabelle root, the vault quarantine, or
the current prohibition on feature growth.
