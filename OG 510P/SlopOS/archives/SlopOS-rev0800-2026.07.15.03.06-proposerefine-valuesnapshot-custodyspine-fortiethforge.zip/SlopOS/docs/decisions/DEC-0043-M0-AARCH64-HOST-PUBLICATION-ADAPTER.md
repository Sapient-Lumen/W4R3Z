# DEC-0043 — M0 AArch64 hosted publication adapter

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P13R only
- Depends on: DEC-0036, DEC-0037, DEC-0041, and DEC-0042
- Supersedes: no sealed machine-effect claim

## Decision

SlopOS admits one bounded Linux-host publication experiment around the exact
rev0794 generation-3 page value. The experiment is a quarantined platform
adapter, not an AArch64 realization and not a new K0 mechanism.

```text
accepted blocked rev0794 readiness value
  + exact 4,096-byte generation-3 page
  + one anonymous private host mapping
  + exact host-page extent and alignment checks
  + exact copy and two readbacks
  + one host RW -> RX protection request
  + compulsory cleanup attempt and receipt
  -> terminal hosted experiment outcome
  -X-> AArch64 machine publication
  -X-> effective stage-2 permission
  -X-> cache or TLB completion
  -X-> instruction fetch or execution
```

The selected live outcome is `PUBLISHED_AND_CLEANED`. That name is local to the
host adapter. It means only that the adapter observed the selected bounded
Linux operations and released the mapping. The receipt carries
`aarch64_machine_premise_discharged=0`.

## Exact finite contract

```text
contract version                    1
wire bytes                         512
single-bit wire mutations        4,096
value requirements                  11
ordered contract steps              10
pairwise step swaps                 45
host page bytes                   4,096
generation                           3
owner                                0
source permission value             13
initial host protection              3  (read | write)
requested final host protection      5  (read | execute)
map flags                            3  (private | anonymous)
cleanup required                     1
value mask                      0x07ff
required AArch64 machine mask   0x3fff
discharged AArch64 machine mask 0x0000
readiness FNV              e28497c1b92213c4
caller artifact FNV        2e63155fe84fcc6e
installed memory FNV       e75835fa071041d1
source page identity       0000000040008000
source page FNV            d8cd55f6dcbc8456
contract semantic FNV      180df825d4869c0c
contract wire FNV          1b6bba4fdaa65275
```

FNV values are deterministic currentness and finite-corruption fences, not
cryptographic authentication.

## Exact ordered contract

```text
BIND_BLOCKED_READINESS
BIND_SOURCE_PAGE
REQUIRE_HOST_PAGE_EXTENT
MAP_PRIVATE_ANONYMOUS_RW
COPY_EXACT_PAGE
VERIFY_PRE_TRANSITION_READBACK
REQUEST_RX_NONWRITE
VERIFY_POST_TRANSITION_READBACK
CLEANUP_MAPPING
SEAL_EXPERIMENT
```

Reordering any pair changes the selected value and is rejected.

## Linux adapter boundary

The platform-dependent implementation is isolated behind:

```text
include/slopos/host/linux_publication_adapter.hpp
src/host/linux_publication_adapter.cpp
```

The abstract contract and generated proof values contain no raw pointer, POSIX
header, syscall number, or host address. The live operations use:

```text
sysconf(_SC_PAGESIZE)
mmap(nullptr, 4096, PROT_READ | PROT_WRITE,
     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0)
mprotect(mapping, 4096, PROT_READ | PROT_EXEC)
munmap(mapping, 4096)
```

The adapter also checks that the returned address is aligned to the exact
4,096-byte selected extent before copying. This is a host-local precondition;
it does not identify guest physical address `0x40008000` or prove any page-table
relationship.

## Receipt and fail-closed order

The exact selected live receipt records:

```text
status                              PUBLISHED_AND_CLEANED
stage                               COMPLETE
host page bytes                     4096
copied bytes                        4096
mapping alignment verified         true
pre-transition readback verified   true
RX transition returned success     true
post-transition readback verified  true
cleanup attempted                   true
cleanup succeeded                   true
mapping released                    true
AArch64 premise discharged          false
receipt FNV                         06bc7b4234722a07
```

The adapter is single-use. Negative paths cover stale contract, stale source,
wrong host page extent, mapping failure, misaligned mapping, partial copy,
pre-transition corruption, protection failure, post-transition corruption,
cleanup failure, and reuse. Every path records a primary outcome and cleanup
state. If cleanup fails, the receipt reports `REJECTED_CLEANUP`, preserves the
primary outcome separately, and does not claim release or rollback.

## Independent C++20 surfaces

The finite contract retains independent hosted-reference and fixed-array core
builders. Platform behavior is tested through an injected fixed function table
and through one real Linux run. The permanent C++20 harness establishes only:

- exact reference/core contract agreement;
- strict 512-byte serialization and empty decode rejection;
- rejection of all 4,096 one-bit wire mutations;
- rejection of all 45 step swaps;
- fail-closed platform status precedence;
- cleanup framing and single-use behavior;
- exact live host receipt on this execution; and
- no observed allocation on the warmed constrained path.

Two compilers, sanitizers, and a real syscall run remain bounded conformance and
counterexample pressure.

## Isabelle root

`M0_AArch64_S2_Host_Publication.thy` proves exact finite propositions about the
contract, masks, predecessor identities, page value, protection plan, step
lists, total status, state frame, selected permission of the host experiment,
and preservation of rev0794's blocked/not-entry-ready result.

The theory additionally proves that every modeled Linux terminal outcome fails
to discharge the AArch64 machine-publication predicate. It imports no Linux,
POSIX, VMA, MMU, cache, instruction, or Arm operational semantics.

## Normative host-source assessment

The engineering selection is constrained by the Linux man-pages project:

- `mmap(2)` documents page-aligned kernel-selected addresses for a null hint,
  anonymous zero-filled mappings, and private mappings;
- `mprotect(2)` requires a page-aligned address and defines the requested read,
  write, and execute access modes while noting architecture/personality effects;
- `sysconf(3)` exposes `_SC_PAGESIZE`.

These documents constrain the adapter. They are not imported as Isabelle
axioms, a Linux-kernel correctness proof, or a portable POSIX theorem.

## Non-claims

Rev0795 does not establish:

```text
formal Linux or POSIX semantics
Linux-kernel or C-library correctness
host virtual address ownership beyond the live mapping
absence of writable aliases elsewhere
AArch64 physical or guest memory publication
stage-1 or stage-2 page-table installation
actual guest R/X/non-W permission
D-cache, I-cache, barrier, or TLB completion
instruction fetch or execution
live PC, X30, EL, PSTATE, stack, exception, or scheduler state
boot, guest execution, CPU isolation, DMA/SMMU/device isolation
multicore or information-flow security
```

## Next bounded objective

The next office must stop extending hosted analogies. M0-P14R is a platform-
realization acquisition gate: pin one emulator-first AArch64 machine/toolchain
and obtain one non-executing EL2-entry/feature observation specimen. The first
acceptable result may be measured rejection. No stage-2 activation or guest
execution is authorized until the platform identity and observation boundary are
closed.
