# DEC-0038 — M0 AArch64 terminal-control semantic contract

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P8R only
- Depends on: DEC-0028 through DEC-0037
- Supersedes: no sealed construction

## Decision

SlopOS selects `CALLABLE_RETURN_X30` as the semantic role of the current
`slopos_m0_s2_activate` fragment.

The fragment is an **M-layer leaf helper** invoked by a more complete EL2
monitor/coordinator. It consumes the already selected X0/X1/X2 control values,
performs the nine M0-P8 architecture-event realization instructions, and is
intended to return at the same exception level to a caller-owned continuation
in X30.

This decision selects meaning only. It does not modify the active 36-byte source,
ELF object, loader value, visibility certificate, or live machine.

## Why this role is selected

The current finite evidence says:

```text
global symbol                    slopos_m0_s2_activate
ELF symbol kind                  function
entry address                    exact symbol start
ordinary value inputs            X0 / X1 / X2
stack use in current fragment     none
ELR_EL2 / SPSR_EL2 contract       absent
boot destination contract        absent
adjacent continuation bytes      absent
terminal instruction             absent
```

The least-assumptive coherent role is therefore a leaf subroutine:

```text
caller establishes X30
caller owns and validates the continuation
helper returns at EL2 through X30
helper does not choose a guest or boot destination
```

Official Arm material distinguishes `RET` as a subroutine return, defaulting to
X30, from `BR` as a non-subroutine register branch and from `ERET`, which restores
architectural exception state. AAPCS64 names X30/LR as the link register. Those
sources constrain the selection; they are not formal semantics or proof of a
live call frame.

## Closed alternatives

The six alternatives remain distinct:

```text
CALLABLE_RETURN_X30
  SELECTED

EXPLICIT_BRANCH_REGISTER
  REJECTED_NO_NAMED_REGISTER

DIRECT_BOOT_CONTINUATION
  REJECTED_NO_BOOT_TARGET

EXCEPTION_RETURN
  REJECTED_NO_EXCEPTION_STATE

CONTIGUOUS_FALLTHROUGH
  REJECTED_NO_ADJACENT_CONTINUATION

NO_TERMINAL_TRANSFER
  REJECTED_NOT_ENTRY_READY
```

The rejections are local to the current artifact and mission. They do not claim
that another future SlopOS path may never use BR, B, ERET, or proved fallthrough.

## Selected future terminal value

The selected repair target is one `RET X30` word:

```text
selected target register     X30
selected word count          1
selected natural word        0xD65F03C0
current code range           [0x40008000, 0x40008024)
projected repaired range     [0x40008000, 0x40008028)
```

The word is a contract output. It is not present in the active source/object and
does not become executable evidence merely because the certificate contains it.

## Required live contract

The selected role requires all twelve live predicates:

```text
ENTRY_EL2_AARCH64
X0_SELECTED_VALUE
X1_SELECTED_VALUE
X2_SELECTED_VALUE
X30_CONTINUATION_VALUE
X30_FOUR_BYTE_ALIGNED
X30_FETCH_VISIBLE
X30_OWNED_BY_CALLER
CALL_EDGE_ESTABLISHES_LINK
SAME_EL_RETURN_PERMITTED
LEAF_STACK_NOT_REQUIRED
RET_WORD_FETCH_VISIBLE
```

The discharged mask remains zero. Contract selection is not live-entry
readiness.

## Cascade ledger

The repair cascade is explicit:

```text
M0-P8 event words      PRESERVE
M0-P9 source           CHANGE
M0-P9 object           CHANGE
M0-P10 loader          CHANGE
M0-P11 visibility      CHANGE
code base              PRESERVE
M0-P6 activation       PRESERVE
M0-P7 adequacy         PRESERVE
proof ledgers          CHANGE
entry readiness        REMAINS_OPEN
```

The return is terminal control, not an additional M0-P7 architecture event. The
nine event-realization words remain a stable prefix.

## Exact certificate

```text
certificate version           1
wire bytes                  512
alternatives                  6
live requirements            12
cascade rows                 10
single-bit mutations       4096
alternative swaps            15
cascade swaps                45

source FNV            b9c30a9a07f1ecaa
visibility FNV        f33930b3d84b2cf7
loader FNV            eeb86170d0078916
object FNV            403a5c3a0ee255fe
specimen FNV          15a2851fdf5adcd5
instruction FNV       3e606113c95c0b62
semantic FNV          12d9da8b2ab05e31
wire FNV              306a43e621efbf9c
```

## Independent C++20 surfaces

The hosted reference builder materializes alternative and cascade records
through dynamic hosted collections. The constrained core builder assigns fixed
arrays directly. They share declarations and selected constants, not
construction loops.

The permanent C++20 harness checks exact equality, status precedence, all 4,096
one-bit wire mutations, every pairwise alternative and cascade swap, empty
rejection facts, and no observed allocation through the warmed constrained
build/status/serialize/decode path.

## Isabelle root

`M0_AArch64_S2_Terminal.thy` proves exact finite facts about the closed
alternatives, unique selection, X30/RET value contract, undischarged live inputs,
current-versus-projected extent, exact cascade, total fail-closed status,
rejection framing, selected transition, preservation of M0-P11 assessment, and
preservation of its terminal-control block.

No formal Arm call/return, ABI, C++20, assembler, loader, or machine semantics
are imported.

## Language law

The implementation and permanent harness remain C++20. Isabelle/HOL is the sole
approved theorem-language exception. The active source/object specimen remains
unchanged in this revision.

## Non-claims

M0-P8R does not establish:

```text
a live BL/BLR call edge
a live X30 value
X30 ownership, alignment, mapping, or fetch visibility
actual RET bytes in the active object
loader placement of the projected word
cache visibility of the projected word
live EL2 entry state
RET execution or completed control transfer
formal AAPCS64 or Arm operational semantics
boot, CPU isolation, DMA/SMMU/device isolation, or multicore correctness
```

## Next experiment

M0-P9R may perform one coherent artifact cascade that appends the selected
`RET X30` to the source/object specimen and updates loader and visibility values.
It must keep M0-P8 event words and the code base stable and must stop before live
entry or execution.
