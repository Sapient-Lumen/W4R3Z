# DEC-0000 — Epoch Zero permanent choices

> **Rev0797 interpretation:** DEC-0045 preserves the authority/evidence laws and
> existing theorem root, but ends Epoch Zero and permits bounded measurement of
> implementation-proof routes and substrates. “Permanent” is no longer read as a
> ban on an explicit evidence-backed superseding decision.
**Status:** accepted and load-bearing
**Revision activated:** 0761; re-stated without dilution through 0773

## Decisions that must survive revision churn

- SlopOS is being rebuilt rather than incrementally extending the predecessor
  datacube.
- The predecessor and companion-cube research are preserved in a quarantine vault.
  Preservation does not make their schemas active.
- C++20 is the active implementation language and permanent executable harness,
  generator, oracle, proof-runner, evidence, and office language.
- Rust is optional future work, not a prerequisite and not a reason to plan instead
  of build.
- Isabelle/HOL 2025-2 is the single primary theorem root and the standing
  proof-language exception. Lean is a bounded reconsideration candidate, not a
  parallel source of truth.
- The repository carries a clear hosted reference model and a separately represented
  fixed-capacity kernel-shaped core. Differential testing must not be achieved by
  sharing transition logic.
- K0 privileged authority/isolation, M0 platform realization, P0 mediated Runtime,
  isolated S0 services, and E0 proof/evidence office are distinct regions. Security
  importance does not by itself justify privilege, and evidence never becomes
  runtime authority.
- The four product shapes—workstation, cloud micro-VM, embedded appliance, and agent
  OS—share one core and use profile-specific assumptions and theorem bundles. They
  are not four kernel forks.
- The subcubes are adversarial requirement sources and invalid-inference fixtures;
  they are not kernel dependencies.
- The immediate machine is static, deterministic, uniprocessor, hosted/emulator
  first, and deliberately too small to hide uncertainty.
- Implementation teaches design. A new abstraction earns admission from a
  counterexample, failed proof, measured source-semantics need, or demonstrated use;
  prose volume is not evidence.
- SlopOS will not claim seL4-class assurance until a theorem chain reaches formal
  implementation semantics and the relevant compiler, platform, initialization,
  hardware, and deployment assumptions are explicit and discharged for a named
  configuration.
- Proof and test evidence are current only for their exact reviewed construction
  basis. Presence, export, verification, or a green old log does not create runtime
  authority or close a different obligation.
- The accepted-transition sequence is finite in C++; fail-closed exhaustion is part
  of the semantics and no runtime setter/backdoor is admitted.
- Concrete representation relations are proof obligations, not assumptions induced
  by similar field names. Capability presence is a proof-facing value relation while
  C++ source, compiler, ABI, and execution edges stay separate.
- Dead capability payload denotes no authority. Future empty-slot lifecycle metadata
  must be modeled separately.
- Initialization enters the same relation stack as transitions. The fixed plan is
  independently materialized all-or-nothing into an exact twelve-cell proof value
  image before it is related to the formal initial map.
- The permanent proof harness distinguishes toolchain absence, wrong version,
  rejected session, and accepted session; theorem promotion requires exact retained
  evidence.
- Fresh-office recovery is machine-visible: the C++20 doctor performs a cheap exact
  version probe, the C++20 office-open gate fails closed, and the sole pinned shell
  installer emits no proof claim. No maintainer may continue theorem-bearing work
  under a vague “tool unavailable” state.
- A proof-owned self-contained C++20 companion may narrow preprocessing and
  declaration-environment debt only when it is generated from the same semantic root,
  byte-current, kept outside runtime authority, and accompanied by an explicit residual
  ISO C++20/compiler assumption fence. It is not a second implementation.
- A checked normalized source-language AST owns only that AST. Exact source-token,
  parsing, binding, and normalization adequacy remain separate until explicitly
  proved; selected implementation type/range assertions remain conformance rather
  than universal language or compiler theorems.
- A proposed checker, parser, derivation record, or semantic copy is rejected when it
  merely relocates the disputed trust or duplicates an existing exact gate. Measured
  rejection is construction progress.
- The first physical isolation claim, when begun, is one immutable two-domain
  configuration rather than a general hypervisor surface. Policy authoring, policy
  admission, abstract installation planning, architecture encoding, selected live
  translation roots, and observed isolation remain separate obligations; a first
  CPU-memory claim explicitly excludes DMA and devices.

## Required response to conflict

A later document that conflicts with this record is not silently newer law. It must
name this decision, explain the evidence that changed, and explicitly supersede the
affected clause.
