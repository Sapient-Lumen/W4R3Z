# DEC-0025 — Retain one self-contained proof-owned C++20 companion

**Status:** accepted

## Decision

Epoch Zero retains one Isabelle-generated, proof-only C++20 companion for the scalar
capability projection:

```text
generated/proof/slopos/k0/proof/capability_scalar_companion.hpp
```

The companion is generated from the same canonical seven-atom HOL source program as
the active kernel scalar header. It is not a second semantic authority and it is not
called by K0. Its purpose is to remove a measurable front-edge assumption surface
before the project attempts source-language semantics.

The admitted companion spelling contains:

- no preprocessing directives;
- no includes;
- no macros or fixed-width integer macros;
- no standard-library names;
- no imported project declarations or typedefs;
- no casts, allocation, exceptions, RTTI, assembly, volatile access, pointers, or
  references;
- only one namespace, one scoped enumeration, two aggregates, six constants, four
  total `constexpr` functions, `bool`, and `unsigned long`.

The active generated kernel header remains the implementation artifact. The
companion remains proof-owned evidence machinery. A bounded permanent C++20 witness
compiles both and compares their scalar outputs over the exact existing 593,907-cell
calibrated domain.

## Why this candidate earned retention

Revision 0771 left two first-edge debts:

```text
active source bytes -> binder certificate          parser trust
source spelling     -> translation unit            preprocessing/include trust
```

The companion does not prove the active binder. It does remove the recursive include
path, project-header lookup, fixed-width typedef lookup, project macro expansion, and
macro-spelled literal dependencies from a second, proof-owned spelling of the exact
same mathematical decision.

Measured source surfaces in the retained basis are:

| Component | Lines | Bytes |
|---|---:|---:|
| Active exact-fragment binder implementation | 1,211 | 47,374 |
| Binder public header | 203 | 6,545 |
| Self-contained generated companion | 90 | 2,570 |
| Companion witness implementation | 368 | 14,963 |
| Companion witness public header | 69 | 2,383 |

The 90-line companion removes more front-edge environmental machinery than it adds.
The larger witness is ordinary bounded evidence machinery; it is not trusted to
supply universal source semantics.

## Why the derivation-checker candidate is rejected

A separate source-span/production checker was considered and rejected for this
revision. To establish more than exact certificate equality it would have to do one
of three things:

1. trust binder-selected token spans and therefore inherit the disputed extraction;
2. tokenize and parse enough of the 2,320-byte active header independently, becoming
   another frontend comparable in semantic surface to the 1,211-line binder; or
3. check only the already emitted finite certificate, duplicating an equality gate
   Isabelle already checks.

None supplies a material trust reduction at bounded cost. The candidate may be
reopened only with a design demonstrably smaller than the binder and with a named
edge it removes rather than relocates.

## Exact checked and bounded claims

Isabelle checks:

```text
v0_capability_scalar_companion_program
  = v0_capability_scalar_source_program

v0_scalar_source_eval v0_capability_scalar_companion_program cell
  = v0_scalar_project cell
```

The C++20 office checks exact exported/active companion bytes. The build also
compiles the generated file directly as a C++20 source target with no project include
directories before the bounded harness includes it. The permanent witness checks:

```text
source bytes                  2570
source SHA-256                6ecd6982a5c377dd204ef5010264cdbf5e6f614d6839915cbb596972a69bb71e
source length-FNV-1a          2edd08779c5baa00
dead cases                    327936 / 3ff1f907c5d2a725
valid cases                   134784 / 93209a6a66ab8da5
invalid cases                 131187 / c6c604c5beb5e375
total cells                   593907
```

The checked HOL theorem owns mathematical program identity. Exact byte currentness
owns only generated-artifact identity. The compiled witness owns only bounded
counterexample pressure under its selected compilers and host.

## Assumptions actually removed

For the companion route, the following are no longer premises:

- `#include` search and recursive inclusion;
- `<cstdint>` and project-header content;
- `std::uint*_t` availability and implementation mapping;
- `UINT*_C` and `UINT*_MAX` macro definitions;
- project namespace/type declaration lookup;
- project macro or conditional-compilation state.

The active K0 header still has these premises. The companion narrows a proof route;
it does not rewrite implementation ancestry.

## Assumptions deliberately left open

The source still passes through C++ translation phases. Even with no directives,
source decoding, line splicing, preprocessing-token formation, directive analysis,
token conversion, syntactic/semantic analysis, translation, linking, and execution
remain relevant. The draft's phase model is recorded at
`https://eel.is/c++draft/lex.phases`.

The companion also retains named C++20 questions:

- `unsigned long` has a minimum width of 32 but an implementation-defined exact
  width; the admitted values fit below 65,536 and perform no arithmetic that depends
  on a particular wider width;
- equality, logical conjunction/disjunction, short-circuit order, conditional
  selection, enum values, aggregate element order, copy initialization, object
  lifetime, constant evaluation, return-value construction, and name lookup must
  receive an admitted language semantics;
- compiler, optimizer, ABI, link, binary, loader, and platform preservation remain
  separate;
- correspondence from this proof-only spelling to the active fixed-width kernel
  spelling is currently bounded, not universal.

The relevant standard clauses are pinned by URL in the proof note, not treated as
machine-checked imports.

## Consequence

`OBL-CAP-SCALAR-COMPANION-001` is `THEOREM` for the HOL program identity and result.
`OBL-CAP-SCALAR-COMPANION-WITNESS-001` is `BOUNDED` for compiled agreement.
At rev0772 close, `OBL-CAP-SCALAR-COMPANION-SEM-001` remained `OPEN_DEBT`.
DEC-0026 now narrows and promotes only the normalized AST value-evaluation relation;
`OBL-CAP-SCALAR-COMPANION-ADEQUACY-001` carries the still-open exact source-to-AST
edge.

`OBL-CAP-SCALAR-CXX-001`, the active binder/parser debt, ISO C++20 adequacy, the
compiler envelope, ABI, binary, and platform debts remain open. The companion may
not become an implementation dependency or be cited as proof of those edges.
