# DEC-0046 — Epoch Zero closure, Office V2, and one hosted authority specimen

**Status:** ACTIVE  
**Revision:** 0798  
**Date:** 2026-07-15

## Decision

SlopOS remains in `EPOCH_ZERO / CLOSURE / OPEN`.

The project will not resume the historical M0 certificate-rung sequence. It will
first make the repository subject, office lifecycle, evidence bindings, and epoch
exit mechanically coherent. In parallel it may build one small hosted authority
specimen that exercises the mission without claiming isolation or Epoch One entry.

Office V2 is data-driven. Revision-specific facts live in typed TSV files. Generic
C++ code validates schemas, exact path classes, evidence bindings, claims, gates,
and proof ledgers. The active construction basis and preserved vault custody basis
are separately SHA-256 manifested.

The hosted authority specimen has five events:

```text
PROPOSE -> ISSUE LEASE -> INVOKE -> REVOKE -> OBSERVE
```

Proposal registration and lease issuance are not protected effects. Invocation is
admitted only for the exact subject/resource/action, within a nonzero magnitude
ceiling, time interval, and remaining-use budget, and before revocation. Denial
frames state. Observation does not authorize or mutate.

## Why

Rev0797 corrected the vault boundary but also performed an unjustified epoch
promotion. Its human and machine state disagreed, current proof evidence did not
exist for the changed basis, and the office was a 5,773-line revision-coded source
file. An epoch transition cannot be more weakly governed than a runtime effect.

Vault excavation also exposed a concrete lease defect: old limited-use/time-scoped
language can still authorize an arbitrarily large operation unless effect magnitude
is attenuated. The first specimen therefore includes `max_amount`.

## Consequences

- Epoch One documents are future-entry law, not current state.
- Formal-source theories may be present while the formal-session claim remains open.
- Independent C++ model agreement is strong testing, not a refinement theorem.
- SHA-256 manifests identify content but are not signatures or actor approval.
- Filesystem identity is claimed only for a quiescent local tree.
- Missing Isabelle/QEMU layers remain blocked gates rather than reconstructed prose.
- A future close requires a final exact-basis rerun and an independent reviewer.

## Rejected paths

- **Continue M0-P15R:** rejected; it would add another pre-effect certificate without
  discharging the platform premises already named.
- **Declare Epoch One because a P-layer demo exists:** rejected; a hosted demo is an
  Epoch Zero falsification specimen until foundation closure gates pass.
- **Keep hardcoded office checks:** rejected; they made every revision a source-code
  fork and rewarded adding checks rather than clarifying state.
- **Put vault bytes in construction identity:** rejected; custody can pressure design
  but cannot silently become active machine law.
- **Treat all ZIPs alike:** rejected; preserved vault archives, evidence objects, and
  detached transport have different roles and priority matters.
- **Close with self-authored green tests:** rejected; final exact-basis independent
  review remains a required gate.

## Exit condition

This decision may be superseded only after the gates in
`docs/epoch-zero/CLOSURE-CHARTER.md` pass or a new bounded decision explicitly
redefines one of them with reasons and a narrower claim.
