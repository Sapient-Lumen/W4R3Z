# DEC-0045 — Exit Epoch Zero and separate vault custody from construction

**Status:** accepted for rev0797 transition  
**Revision activated:** 0797  
**Supersedes:** the rev0796 instruction that M0-P15R must be the next construction;
the special inclusion of `vault/source-archives/*.zip` in the active construction
basis  
**Preserves:** vault quarantine, K/M/P/S/E separation, the sole Isabelle theorem
root for existing proofs, exact claim fences, and the prohibition on silent
promotion between evidence and authority

## Decision

Epoch Zero is complete as a foundation. Rev0797 begins an open transition to Epoch
One. It does not inherit `CLOSED-CLEAN` proof currentness from rev0796 because active
source and construction-basis semantics change.

The repository has two independent identities:

1. **active construction basis** — living source, proof, specification, generated
   artifact, active documentation, tests, toolchain locks, and office rules; and
2. **vault custody basis** — immutable preserved archives, searchable selections,
   and lineage material under `vault/`.

`docs/vault/` remains active construction. `vault/` is excluded from construction.
`evidence/`, build outputs, VCS metadata, work directories, and detached ZIP files
are also excluded from the active basis.

The active basis and custody basis use cryptographic digests in retained evidence.
FNV may remain a fast deterministic implementation fingerprint but is not the sole
identity for custody, provenance, or adversarial evidence.

Construction-basis V2 is an immediate boundary correction, not the final hermetic
format. E1-P0 must drive classification from the repository-boundary schema, reject
unclassified paths/symlinks/special files unless explicitly admitted, include file
type and mode in cryptographic identity, and separate construction/theorem audit from
custody and bundle-release audit.

## Why

Rev0796's construction basis included all 444 files under `vault/`, including eight
preserved source archives. This made custody bytes a theorem-currentness dependency
and contradicted the project's stated architecture.

The broader review also found that the project had accumulated sixteen pre-effect
M0 rungs and a revision-hardcoded office while still producing no privileged
stage-2 effect and no P-layer authority walking skeleton. Continuing to M0-P15R
would deepen the same local optimum.

## Epoch-One construction order

1. **E1-P0 — office/boundary repair:** finish the schema-driven successor to basis
   V2, add custody manifest and independent custody lane, reject unclassified
   filesystem state, replace revision-coded prose checks with declarative schemas,
   and restore a closeable office without relabeling old proof packets.
2. **E1-P1 — hosted mediated-authority skeleton:** proposal, scoped grant/lease,
   deterministic admission, one effect adapter, effect witness, currentness,
   revocation, denial, and replay outside K.
3. **E1-P2 — direct fixed isolation effect:** one exact stage-2 control effect,
   one permitted guest access, one denied access, and an explicit comparison with a
   current small isolation substrate.

P and M may proceed in parallel. P may not claim hardware isolation; M may not claim
product authority semantics.

## Admission rule after rev0797

No new M0 rung is admitted unless it does at least one of the following:

- discharges a named machine premise;
- is necessary to execute the immediate fixed privileged effect; or
- removes or merges an existing rung.

No revision identifier, predecessor hash, expected prose sentence, or decision list
should be compiled into the office engine when it can be represented as typed
revision data.

## Language and substrate rule

C++20 remains the current living implementation and permanent-harness default until
a separate decision changes it. “Permanent” does not prohibit a bounded comparison
for the tiny proof-bearing privileged slice. C/AutoCorres2, a constrained Rust
verification route, and exact object/machine translation validation may be measured
on the same function. No route earns authority by reputation or language name.

A seL4/Microkit or equivalent comparison is required before a broad native K/M
commitment. Reuse does not import claims outside the exact selected configuration
and verification status.

## Release rule

Public release is blocked until the owner selects an active-project license and
inherited material is audited. This decision does not select legal terms.

## Consequences

- rev0797 is intentionally `OPEN-TRANSITION`;
- rev0796 theorem evidence remains historical evidence for the sealed rev0796 basis;
- the living rev0797 basis requires a fresh office/proof close before any theorem is
  called current for rev0797;
- the vault remains byte-preserved and independently auditable; and
- progress is measured by authority/isolation traces and discharged premises, not
  revision count, target count, or prose volume.
