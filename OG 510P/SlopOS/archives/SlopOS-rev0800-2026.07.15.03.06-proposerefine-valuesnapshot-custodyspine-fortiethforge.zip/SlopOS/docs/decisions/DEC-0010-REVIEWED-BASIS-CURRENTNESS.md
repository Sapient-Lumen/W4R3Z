# DEC-0010 — Proof evidence is bound to a reviewed construction basis

**Status:** accepted and implemented for office close
**Revision:** 0763

## Decision

A test report, theorem log, generated artifact, or imported proof bundle is evidence
only for the exact construction basis against which it was produced.  It does not
remain current after an unreviewed change to source, theory, generated data, command
contract, trace, claim ledger, compiler envelope, or governing decision.

Every clean close therefore records `evidence/rev####/construction-basis.tsv`,
produced by the permanent C++20 command:

```text
slopos-office basis --root <repository-root>
```

The manifest enumerates the active tree, excluding build products, revision evidence,
Git internals, and prohibited revision ZIPs.  The eight immutable ZIP payloads under
`vault/source-archives/` remain included so their bytes cannot drift behind an
unchanged checksum manifest.  The basis records byte counts and deterministic
FNV-1a fingerprints and carries an aggregate fingerprint.  The office audit requires
byte-for-byte equality between the recorded manifest and the active tree.

FNV-1a is a drift detector, not a cryptographic authenticity mechanism.  Release
evidence separately records SHA-256 inventories and archive integrity.

## Consequences

- A changed reviewed basis requires fresh tests and, for theorem claims, a fresh
  checker run.
- An Isabelle source file without a retained successful checker log remains
  `CANDIDATE_THEOREM`.
- A theorem or external verification receipt never closes an obligation merely by
  being present.  The obligation ledger must name its exact scope and evidence.
- Imported proof material is rebound locally to subject, artifact, revision, scope,
  assumptions, checker/tool version, and retained log before it can support a claim.
- Evidence does not grant runtime authority, clear quarantine, establish current
  machine state, or prove a compiled C++ path unless its claim explicitly reaches
  those objects.

## Source pressure

This decision promotes the old SlopOS proof-evidence maturity discipline and the
Helm/Ward rule that reviewed-basis drift requires fresh review and verification
intake does not become authority.  Exact sources and hashes are recorded in
`docs/vault/EXCAVATION-005-PROOF-EVIDENCE-CURRENTNESS.md`.
