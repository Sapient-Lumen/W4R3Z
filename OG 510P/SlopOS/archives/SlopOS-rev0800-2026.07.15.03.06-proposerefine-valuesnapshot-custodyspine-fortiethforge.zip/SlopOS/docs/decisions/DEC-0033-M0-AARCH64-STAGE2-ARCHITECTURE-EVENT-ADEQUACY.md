# DEC-0033 — M0 AArch64 stage-2 architecture-event adequacy certificate

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P7 only
- Depends on: DEC-0028 through DEC-0032
- Supersedes: the rev0784 selection of `HCR_EL2=0x1` as a current value

## Decision

SlopOS admits one finite, source-scoped **conditional certificate** relating the
closed twelve-label M0-P6 protocol to ten repository-defined abstract
architecture events under thirty-two named premises.

The certificate is not formal Arm semantics.  It is an exact statement of what
must be true before the project may attempt an instruction-realization edge.
Premise presence is not premise truth, and an accepted certificate does not
perform or authorize privileged effect.

## Load-bearing correction

Rev0784 selected `HCR_EL2=0x1`, enabling `HCR_EL2.VM` while leaving
`HCR_EL2.RW` clear.  The selected product envelope requires lower EL1 to execute
in AArch64 state.  Rev0785 therefore selects:

```text
HCR_EL2.VM = 1
HCR_EL2.RW = 1
HCR_EL2    = 0x0000000080000001
```

This changes the exact M0-P6 final-state fingerprint from:

```text
rev0784  fb6debd0b996a329
rev0785  670fe80725b1dca9
```

The rev0784 tuple is retained as rejected lineage.  It is not deleted, aliased,
or accepted as a fallback.

## Closed mapping

The two endpoints are value-only:

```text
BIND_INSTALLED_MEMORY  -> no architecture event
SEAL                   -> no architecture event
```

The ten interior labels map one-to-one and in order:

```text
PUBLISH_TABLE_BYTES          -> PUBLISH_TABLE_BYTES
COMPLETE_TABLE_PUBLICATION   -> COMPLETE_TABLE_PUBLICATION
SELECT_CONTROL_VALUE         -> SELECT_VTCR_EL2
SELECT_ROOT_VALUE            -> SELECT_VTTBR_EL2
SYNCHRONIZE_SELECTION        -> SYNCHRONIZE_SELECTION
INVALIDATE_SELECTED_CONTEXT  -> INVALIDATE_SELECTED_VMID
COMPLETE_INVALIDATION        -> COMPLETE_INVALIDATION
SYNCHRONIZE_INVALIDATION     -> SYNCHRONIZE_INVALIDATION
ENABLE_STAGE2                -> ENABLE_STAGE2_VM_RW
SYNCHRONIZE_ENABLE           -> SYNCHRONIZE_ENABLE
```

These names are repository-defined abstract events.  None is an alias for an
A64 mnemonic, instruction encoding, source fragment, assembled byte sequence,
privileged execution, completion observation, or hardware state.

## Exact certificate

```text
certificate version          1
wire bytes                  256
named premises               32
selected feature bits        12
protocol bindings            12
ordered abstract events      10
single-bit mutations       2048
Arm manual issue              DDI 0487 M.c
register index snapshot       2026-03
activation fingerprint        670fe80725b1dca9
legacy activation fingerprint fb6debd0b996a329
VTCR_EL2                       0000000000023559
VTTBR_EL2                      0001000040000000
HCR_EL2                        0000000080000001
legacy HCR_EL2                 0000000000000001
semantic fingerprint          83ad24b9253947b3
wire fingerprint              ab45c45edc0d2f79
```

The wire is little-endian and has one exact selected representation.  A stored
FNV-1a integrity field is a finite currentness/corruption fence, not a
cryptographic authenticity claim.

## Thirty-two premises

The exact names are compiled into
`include/slopos/m0/aarch64_s2_adequacy.hpp` and emitted in the selected witness.
They cover architecture/EL2 availability, stage-2 and granule support, IPA/PA/
VMID envelope, LPA2/DS/FWB choices, table alignment and memory type,
installation/publication, cold-start and single-PE conditions, absence of
concurrent writers/DMA mutation, control-field legality, availability of
synchronization/invalidation/completion events, EL2 effect, exception freedom,
and observation after completion.

The certificate requires all thirty-two bits.  It does not establish any bit.
Each premise must later be discharged, imported from a formal architecture
model, or retained as an explicit platform assumption.

## Total fail-closed order

For certificate values, the selected precedence is:

```text
BAD_VERSION
BAD_WIRE_EXTENT
BAD_SOURCE_IDENTITY
BAD_PREMISE_MASK
BAD_ACTIVATION_IDENTITY
BAD_CONTROL_IDENTITY
BAD_FEATURE_ENVELOPE
BAD_BINDINGS
BAD_EVENT_ORDER
BAD_SEMANTIC_FINGERPRINT
ACCEPTED
```

Wire-level magic, extent, integrity, and reserved-byte failures precede value
admission.  The exact rev0784 activation/HCR pair fails at
`BAD_ACTIVATION_IDENTITY`; the old HCR paired with the current activation
identity fails at `BAD_CONTROL_IDENTITY`.

## Independent C++20 surfaces

The hosted reference builder materializes bindings and events in vectors.  The
constrained builder writes fixed arrays directly.  They share declarations and
selected constants, not construction loops.  The permanent C++20 harness
checks exact agreement, status precedence, the full 2,048 one-bit wire corpus,
and no observed global allocation through the warmed constrained build,
serialize, decode, and status path.

## Isabelle root

`M0_AArch64_S2_Adequacy.thy` defines the finite request, total status relation,
admission state, rejection frame, selected mapping, legacy rejection, and
binding to the already-checked M0-P6 sealed run.  It proves only exact HOL values
and relations under the generated constants.

No theorem in this decision imports Arm operational semantics or ISO C++20
semantics.

## Rejected alternatives

### Keep `HCR_EL2=1` because rev0784 was sealed

Rejected.  A seal preserves lineage; it does not make a contradicted value
current.

### Name concrete instructions in M0-P7

Rejected.  Instruction class, operands, encoding, source spelling, assembled
bytes, execution, completion, and observation are separate edges.

### Treat source URLs as formal premises

Rejected.  Official documentation constrains engineering selection but is not a
machine-checked operational model.

### Generalize into an architecture protocol language

Rejected.  Epoch Zero needs one closed falsifiable specimen.  Generic protocol
machinery would hide rather than close the current edge.

## Non-claims

This decision does not establish:

- truth or currentness of any named premise;
- formal Arm architecture semantics;
- a sufficient or legal instruction sequence;
- any A64 mnemonic, operand, immediate, or instruction encoding;
- C++ source/compiler/ABI/binary correspondence;
- system-register access, barriers, TLBI, cache maintenance, or completion;
- table publication, physical placement, or a live translation root;
- boot, guest execution, CPU-memory isolation, or fault behavior;
- DMA, SMMU, interrupt-remapping, or device isolation;
- multicore, concurrency, information flow, timing, or side channels;
- completion of any A/B/C/D product theorem bundle.

## Consequence

M0-P8 may construct or reject one exact A64 instruction-realization candidate
for the ten abstract events.  It may not execute those instructions or claim a
binary or hardware effect.
