# DEC-0015 — Checked theorem evidence is construction-bound

**Status:** accepted
**Revision activated:** 0766

## Decision

`THEOREM` means that the named theorem was accepted by the pinned Isabelle session
for the exact active source tree. It never means that a similarly named C++
function, compiler output, platform action, or product claim has been proved.

The permanent C++20 proof runner owns checker discovery, exact-version refusal,
proof-hole scanning, process execution, evidence packet creation, and deterministic
recovery diagnosis. It records
four explicit states:

```text
TOOLCHAIN_MISSING
TOOLCHAIN_WRONG_VERSION
SESSION_REJECTED
SESSION_ACCEPTED
```

The former vague `UNAVAILABLE` state is retired. `slopos-proof doctor` reports the
first two states before a full run; DEC-0018 requires CTest and office opening to
fail visibly rather than omit formal work.

## Required evidence

A current theorem-bearing close requires all of:

- exact reported version `Isabelle2025-2`;
- session `SlopOS_K0`;
- `quick_and_dirty=false`;
- zero source proof-hole markers;
- successful checker exit;
- the exact `Finished SlopOS_K0` completion marker in retained checker output;
- proof-tree fingerprint;
- exact `construction-basis.tsv` and its fingerprint;
- `proof/theorems.tsv` rows mapping every `THEOREM` obligation to exact theory and
  theorem names;
- office audit agreement with the evidence packet.

Changing active source, generated proof input, theorem mapping, toolchain pin, or
claim scope invalidates currentness and requires a fresh run.

## Boundary

Isabelle acceptance closes only the formal proposition represented by the listed
lemma under its definitions and assumptions. C++ source evaluation, translation,
compiler, ABI, library, boot, hardware, DMA, timing, and physical-world edges stay
open until separately named evidence closes them.
