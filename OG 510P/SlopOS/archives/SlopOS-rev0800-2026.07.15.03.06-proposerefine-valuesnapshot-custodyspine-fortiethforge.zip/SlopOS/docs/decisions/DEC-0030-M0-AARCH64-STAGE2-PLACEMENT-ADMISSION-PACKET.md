# DEC-0030 — M0 AArch64 stage-2 placement/admission packet

- Status: Accepted for Epoch Zero
- Scope: M0-P4 exact value and admission relation only
- Supersedes: no prior decision
- Depends on: DEC-0028, DEC-0029, `M0-S2-PLACED-GRAPH`

## Context

Rev0779 owns one exact 24,576-byte six-table graph value and a pure walker.  A
placement number inside that graph is not evidence that bytes were copied to a
memory object, that the object was exclusively owned, that a root was selected,
or that the architecture completed the required effect protocol.

The next useful rung is therefore not a loader.  It is a closed packet that
binds the already checked graph and abstract plan to proposed source extents,
destination values, root ownership, and an explicit admission order.

## Decision

M0-P4 owns exactly one immutable 512-byte little-endian packet:

```text
64-byte header
6 x 32-byte table records
2 x 32-byte root records
10 x 8-byte admission records
112 zero reserved bytes
```

The selected packet binds:

- graph byte count `24576`;
- graph FNV `32ec119640d7e72d`;
- abstract plan FNV `cc05f08f4bbc162c`;
- packet semantic FNV `a1d0b02ad4351902`;
- six adjacent 4 KiB source extents covering the graph exactly once;
- six distinct, adjacent, 4 KiB-aligned destination values
  `0x40000000..0x40005000`;
- alpha ownership of table ordinals 0–2 and beta ownership of 3–5;
- root ordinals 0 and 3 with VMIDs 1 and 2;
- the exact admission sequence
  `IMAGE, TABLE0..TABLE5, ROOT0, ROOT1, SEAL`.

C++20 supplies independent hosted-reference and fixed-capacity constructors and
admission ledgers.  Ordinary rejection frames authoritative ledger state.
Strict decoding admits only the selected packet value.

Isabelle/HOL owns only exact finite propositions over generated packet values.
The C++20 generator remains outside those propositions.

## Effect fence

```text
requested placement
!= admitted placement
!= bytes installed
!= selected current root
!= completed architecture protocol
```

The packet is data, not authority to dereference its destination values.  The
admission ledger records a checked order, not physical effect.

## Rejected alternatives

- **Write through host pointers now:** rejected because no owned-memory model,
  source semantics, physical-address interpretation, or effect protocol exists.
- **Treat graph placements as already installed:** rejected as an invalid
  representation-to-effect inference.
- **Revive CH-BOOT, CH-INIT, or CH-ADDRNET wholesale:** rejected until a bounded
  construction demonstrates a field or relation that the closed packet lacks.
- **Use a script as the permanent packet checker:** rejected; the permanent
  builder, decoder, mutation fence, and ledger are C++20.

## Evidence and limits

The bounded witness checks differential construction, exact wire round-trip,
all 4,096 one-bit mutations, stale/truncated/reordered input, rejection framing,
and no observed allocation in the constrained path.  These checks do not prove
ISO C++20 semantics, compiler preservation, cryptographic integrity, physical
writes, register effect, barriers, TLB maintenance, hardware walk, boot,
DMA/device confinement, or CPU-memory isolation.

## Consequence

The next rung may introduce one pure fixed-capacity owned-memory value and an
atomic copy/readback relation.  It must still stop before raw host addresses,
MMIO, volatile access, assembly, registers, barriers, cache/TLB operations,
boot, guests, devices, DMA, multicore, or an isolation claim.
