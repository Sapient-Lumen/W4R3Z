# DEC-0012 — Terminal-sequence construction uses a private test-only peer

**Status:** accepted and implemented in rev0764
**Scope:** boundary evidence only

## Pressure

The terminal value cannot be reached by executing `2^64-1` accepted transitions in
a practical test. Directly exposing a sequence setter through the K0 command surface,
public machine API, bootstrap plan, trace format, or ordinary library symbol would
create a mutation channel with no machine meaning.

## Decision

A single dedicated test executable recompiles the model and core translation units
with `SLOPOS_SEQUENCE_TEST_SEAM`. Under that compile definition, each class grants
friend access to `SequenceTestPeer`, whose definition exists only in
`tests/support/sequence_test_peer.hpp`.

The production `slopos_model` and `slopos_core` targets are built without the
compile definition. They expose no sequence setter and accept no terminal-state
construction command. The peer may alter only `accepted_sequence_` on an already
installed machine.

## Required discipline

- no runtime command or trace token constructs arbitrary sequence state;
- no bootstrap field or configuration key controls it;
- no public inline setter exists;
- the seam cannot modify capabilities, mappings, messages, objects, or domains;
- boundary tests compare model/core, exact rejection frames, invariants, and stable
  witness identity;
- production source remains the same transition source compiled without the friend.

## Claim boundary

The seam is a test fixture, not part of K0 semantics, authority, recovery, replay,
or platform state. It supplies finite boundary evidence only. It does not prove the
universal C++/Isabelle or compiler relation.
