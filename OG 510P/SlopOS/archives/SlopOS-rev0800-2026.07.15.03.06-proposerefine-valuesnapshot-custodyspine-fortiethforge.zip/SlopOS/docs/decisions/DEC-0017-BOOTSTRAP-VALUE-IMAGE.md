# DEC-0017 — Bootstrap enters the proof stack through an atomic value image

**Status:** accepted
**Revision activated:** 0766

## Decision

The fixed Epoch Zero `BootstrapPlan` has a third, independent C++20 interpretation:
an all-or-nothing proof-facing materializer. It does not call the existing plan
validator and does not reuse either machine's installation routine.

A valid plan yields exactly twelve capability source-value cells and accepted
sequence zero. An invalid plan yields one canonical empty image and a precise
failure class; no partially installed authority image can escape.

The shipped image contains four live roots and eight dead cells. Isabelle relates
that generated value image to the formal partial capability map and proves the exact
four live roots, eight dead slots, out-of-range absence, and initial sequence
representation.

## Non-claims

This decision does not prove C++ object representation, `std::array` layout,
compiler lowering, ABI, domain/object descriptor storage, mappings, queues, boot
execution, or hardware initialization. Those remain separate obligations.
