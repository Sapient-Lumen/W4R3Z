# DEC-0040 — M0 AArch64 caller-edge and X30 value contract

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P10R only
- Depends on: DEC-0038 and DEC-0039
- Supersedes: no sealed historical fact

## Decision

SlopOS admits one exact **projected caller-edge value contract** for the repaired
`RET X30` helper. The contract binds one numeric call site, one numeric
continuation, one callee entry, one A64 `BL` word, one continuation `NOP` word,
and the X30 link-register role while proving that the caller bytes are **not yet
present** in the current pure loader value.

```text
sealed rev0791 return-repair relation
  + exact helper range and current RET X30 terminal word
  + projected caller range in the same admitted RX value page
  + exact BL relation: call site -> helper entry
  + exact continuation = call site + 4
  + exact X30 role
  -> accepted finite caller-edge value contract
  -X-> caller artifact presence
  -X-> instruction visibility
  -X-> executed BL or observed X30
  -X-> executed/completed RET
```

Acceptance means the proposed values are mutually consistent and current with
the sealed predecessor. It does not establish a call edge in a machine.

## Exact selected values

```text
page value range           0x40008000 .. 0x40009000
helper code range          0x40008000 .. 0x40008028
projected caller range     0x40008040 .. 0x40008048
call site                  0x40008040
continuation / X30 target  0x40008044
callee entry               0x40008000
BL byte delta              -64
BL imm26                   0x03fffff0
projected BL word          0x97fffff0
projected continuation     0xd503201f  (NOP)
current call word          0x00000000
current continuation word  0x00000000
helper terminal word       0xd65f03c0  (RET X30)
link register              X30
owner                      monitor (0)
permission value           13 (read + execute + privileged; no write)
```

The caller begins at the next 64-byte boundary after the helper. This is a
bounded value choice, not a cache-line theorem and not proof that the caller is
mapped or fetch-visible.

## Exact predecessor binding

The contract binds these sealed current identities:

```text
return-repair FNV          9c783eb50a1689e3
terminal-contract FNV      12d9da8b2ab05e31
loader FNV                 d2bec0624621d20b
visibility FNV             1b85bcad6a8fc3c3
instruction FNV            3e606113c95c0b62
source-envelope FNV        72abaf8a484aaf78
edge-identity FNV          ee8c8e5d5fac667a
contract semantic FNV      f043cb390debd722
wire FNV                   e110bb03ff754299
```

No predecessor field is inferred from a filename or from the projected word.

## Value and live requirements

All fifteen finite **value** requirements are observed:

```text
predecessor generation current
page and helper ranges exact
projected caller inside page and disjoint from helper
call site equals caller begin
continuation equals PC + 4
callee equals helper entry
four-byte alignment
BL delta encodable and selected word consistent
X30 selected as link register
current caller words absent
helper terminal RET current
monitor RX non-write value selected
```

All six **live** requirements remain undischarged:

```text
caller bytes installed
caller fetch-visible
call edge executed
X30 observed at the continuation
same-EL return permitted
return completed
```

The selected readiness is therefore:

```text
BLOCKED_PROJECTED_CALLER_ARTIFACT
caller_artifact_present = false
call_edge_established   = false
```

## Total fail-closed order

Value admission uses this precedence:

```text
BAD_VERSION
BAD_EXTENT
BAD_PREDECESSOR
BAD_PAGE_RANGE
BAD_HELPER_RANGE
BAD_CALLER_RANGE
BAD_OWNER_PERMISSIONS
BAD_ALIGNMENT
BAD_ADDRESS_RELATION
BAD_WORD_RELATION
BAD_CURRENT_ARTIFACT
BAD_VALUE_MASK
BAD_LIVE_MASK
BAD_READINESS
BAD_EDGE_IDENTITY
BAD_SEMANTIC_FINGERPRINT
ACCEPTED
```

Wire magic, extent, stored wire fingerprint, and reserved bytes are checked
before value admission. Rejected decoding returns an empty contract. Rejected
formal transitions preserve the exact prior state.

## C++20 machinery

The permanent executable surfaces are:

```text
include/slopos/m0/aarch64_s2_caller_edge.hpp
src/m0/aarch64_s2_caller_edge.cpp
tools/slopos_aarch64_s2_caller_edge_main.cpp
tests/test_aarch64_s2_caller_edge.cpp
tests/test_aarch64_s2_caller_edge_noalloc.cpp
```

The hosted reference builder and fixed-capacity core builder independently read
the current pure loader value. They agree that both projected caller words are
zero and that the repaired helper terminates with `RET X30`. The C++20 harness
also checks BL encode/decode arithmetic, total precedence, exact 512-byte wire
round-trip, every one of 4,096 one-bit wire mutations, and no observed
allocation on the warmed constrained path.

## Isabelle root

`M0_AArch64_S2_Caller_Edge.thy` checks exact finite propositions about:

- predecessor identities;
- exact page, helper, caller, call-site, continuation, and callee values;
- range separation and alignment;
- BL delta, imm26, and word arithmetic;
- exact NOP and RET words;
- absence of caller words from current loader memory;
- X30, owner, and permission values;
- complete value masks and empty live discharge;
- blocked readiness;
- fail-closed precedence;
- rejection framing;
- selected admission; and
- preservation of the rev0791 return-repair admission.

The theory imports no formal Arm execution semantics and proves no live
register state.

## Non-claims

This decision does not establish:

```text
current caller source or object bytes
caller installation or executable mapping
instruction-cache visibility
formal BL, NOP, or RET operational semantics
live X30 state
call-edge execution
same-EL return permission on a concrete PE
RET execution or completion
exception, stack, scheduler, or boot state
CPU isolation
DMA/SMMU/device isolation
multicore or information-flow security
```

## Next bounded experiment

M0-P11R may make one exact two-word caller stub current through a separate
source/object/pure-loader/visibility artifact cascade. It must stop before BL
execution, live X30 observation, RET execution, or boot.
