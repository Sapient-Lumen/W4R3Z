# DEC-0006 — Bootstrap policy is compiled data

**Status:** accepted

Epoch Zero policy is a small immutable `BootstrapPlan`: domain identities, object
ownership, endpoint identity, and initial capabilities.  A validator rejects duplicate
identities, invalid object references, illegal rights, invalid ownership, occupied
slot collisions, and capacity excess before state installation.

Both model and core install the same plan through independent code.  Active traces
carry the plan fingerprint.  The C++20 proof emitter writes the exact constants used
by the Isabelle bootstrap theory.  Runtime state never silently invents a root
capability.
