# DEC-0022 — exact C++20 fragment certificate

- Status: accepted for Epoch Zero
- Revision: 0770
- Supersedes: no prior decision
- Narrows: DEC-0007, DEC-0020, and DEC-0021

## Decision

The proof-owned scalar source program remains the semantic authority for the first
C++20 source bridge. The generated header remains the exact named export of that
accepted Isabelle session. A permanent C++20 component now consumes the **entire**
active generated header and emits a finite certificate. Isabelle checks that the
certificate is exactly the one admitted scalar program and that its finite evaluator
equals `v0_scalar_project`.

The active chain is:

```text
checked HOL seven-atom source program
        |
        | closed Isabelle renderer
        v
exact generated C++20 header bytes
        |
        | C++20 whole-input exact-fragment binder
        v
finite parsed certificate theory + manifest
        |
        | Isabelle equality/admission/evaluation lemmas
        v
checked finite certificate relation to v0_scalar_project
```

No stage silently inherits the claim of the stage above it.

## Why this direction

Rev0769 closed semantic-source-to-generated-byte drift but intentionally left the
interpretation of those bytes open. The next smallest useful edge is not a general
C++ frontend. It is an exact recognizer for the one generated fragment we actually
compile.

The old vault repeatedly distinguishes representation from authority and
currentness from effect. The same law applies here:

- generated text is not automatically a parsed program;
- a parsed certificate is not automatically a proof of the parser;
- a finite certificate evaluator is not automatically ISO C++20 evaluation;
- source evaluation is not automatically compiler or binary behavior.

The exact-fragment binder is therefore a translation-validation instrument, not a
replacement C++ semantics.

## Binder law

The active binder:

1. tokenizes the complete file and requires end-of-file after the admitted namespace;
2. recognizes every constant, helper body, Boolean operator, branch, tag, aggregate
   field, literal, and static assertion relevant to the scalar result;
3. rejects unknown tokens and unrecognized constructs;
4. records operator and field choices rather than normalizing near misses into the
   expected meaning;
5. emits a deterministic Isabelle theory and a deterministic manifest;
6. requires both emitted artifacts to be byte-current before Isabelle runs;
7. remains structurally separate from the Isabelle renderer and source evaluator.

DEC-0024 refines the next edge: certificate admission, direct structural execution,
and compiled effect are now separately represented. The certificate decision does
not own evaluation semantics.

The generated source fingerprint is `ab74f6e3b4e5ca79`. The current finite
certificate fingerprint is `267e8cdbc882f606`. These are currentness identities,
not semantic proofs.

## Checked claim

The Isabelle session now checks:

- the canonical finite certificate is admitted;
- it denotes the exact seven-atom source program;
- its admitted evaluator equals `v0_scalar_project`;
- the certificate emitted from the active header equals that canonical certificate;
- the emitted certificate is admitted and therefore has the exact program and
  evaluation relation.

These claims are mapped under `OBL-CAP-SCALAR-CPP20-CERT-001` and
`OBL-CAP-SCALAR-CPP20-PARSED-001`.

## Explicit non-claims

This decision does not prove:

- correctness or completeness of the C++20 binder;
- equivalence between the binder's token language and the ISO C++20 grammar;
- correctness of translation phases, included declarations, or the `UINT8_C`,
  `UINT16_C`, and `UINT16_MAX` macro environment;
- ISO C++20 constant, comparison, Boolean, branch, cast, or aggregate semantics;
- absence of undefined, unspecified, implementation-defined, or erroneous behavior
  outside what a separate language argument establishes;
- compiler preservation, ABI layout, linker behavior, loader behavior, binary
  identity, or platform execution;
- timing, side-channel, concurrency, or privileged-machine properties.

`OBL-CAP-SCALAR-CPP20-PARSER-001`,
`OBL-CAP-SCALAR-CPP20-PREPROCESS-001`, `OBL-CAP-SCALAR-CXX-001`, and
`OBL-CXX-COMPILER-001` therefore remain open.

## Process isolation

The C++20 proof runner executes Isabelle with a repository-local `HOME` under
`.slopos-work/isabelle/home`, a separate working directory under
`.slopos-work/isabelle/run`, and an exclusive repository-private lock. It removes and
recreates the workspace before building only the selected session.
This prevents unrelated per-user target-session state from supplying or receiving
SlopOS evidence. No `-c` or `-f` action is requested, and the disposable proof
workspace is disjoint from the CMake build that launched the proof.

A C++20 supervisor owns the Isabelle worker process group. If the runner is killed,
its supervisor terminates the worker group instead of leaving theorem-checking
processes alive in a constrained cloudtainer.

## Rejected alternatives

- making the C++ generator from the alternate rev0769 branch authoritative;
- trusting the renderer because it lives in an Isabelle theory;
- treating source-byte identity as interpretation;
- importing a general C++ frontend before this fragment demonstrates the need;
- using a C mirror and transferring its theorem to C++ by resemblance;
- hiding parser and ISO-language assumptions inside one umbrella claim;
- widening K0 to justify a more general verifier.

## Reconsideration

The exact binder may be replaced only when another route gives a smaller or better
checked trust edge for this same fragment. Replacement evidence must retain the
source-program theorem, exact generated-byte gate, explicit parser/language/compiler
separation, and deterministic office replay.
