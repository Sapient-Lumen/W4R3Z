# DEC-0001 — New epoch and sealed research vault

**Status:** accepted

The active repository begins from a small construction surface.  The old SlopOS
cube is retained byte-for-byte under `vault/lineage/` and its textual surface is
made searchable under `vault/searchable/`.  Interrupted transition work, when
found, is stored under `vault/recovered-unfinished/`.

Nothing in those locations is compiled, imported, or treated as active policy.
Promotion requires:

1. a source path and revision;
2. the problem the idea solves in the active epoch;
3. the smaller alternative considered;
4. the proof or implementation pressure justifying promotion;
5. an active decision record.

This protects valuable research while preventing six million words of inherited
surface area from becoming an implicit trusted base.
