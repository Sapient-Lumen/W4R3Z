# DEC-0039 — M0 AArch64 stage-2 return-repair cascade

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P9R only
- Depends on: DEC-0035 through DEC-0038
- Supersedes: no sealed historical fact; it makes the rev0790 predicted repair current

## Decision

SlopOS admits one exact, atomic value-level repair cascade that appends the
selected `RET X30` word to the active source/object specimen and regenerates the
dependent pure loader and visibility values. The relation preserves the sealed
rev0790 terminal-control contract as an exact preimage and rejects every named
mixed-generation tuple.

```text
sealed rev0790 preimage
  + preserved M0-P8 nine-word event prefix
  + preserved code base and instruction identity
  + selected terminal contract 0xD65F03C0 / X30
  -> repaired source
  -> repaired exact ELF object
  -> repaired pure loader value
  -> repaired visibility assessment
  -> one exact old/new repair certificate
  -X-> live X30
  -X-> platform premise discharge
  -X-> entry, execution, completion, boot, or isolation
```

The repair is a value relation. No source, object, loader, or certificate is
silently promoted into execution authority.

## Why a separate cascade object is required

Changing only the assembly source would leave a coherent-looking but false
repository. The exact object identity, object semantic identity, text
fingerprint, loader semantic identity, installed-memory identity, visibility
identity, code-end value, terminal observation, generated Isabelle constants,
and theorem rows all depend on the final word.

Conversely, overwriting the rev0790 terminal contract with current repaired
identities would erase the preimage it was designed to predict. The terminal
contract therefore remains exact historical/current proof input, while the new
repair object binds that preimage to the repaired generation.

## Exact cascade

```text
legacy source bytes                 339
current source bytes                345
source delta                          6

legacy object bytes                 560
current object bytes                560
object extent delta                   0

legacy text bytes                    36
current text bytes                   40
text delta                            4

code base                    0x40008000
legacy code end              0x40008024
current code end             0x40008028

preserved event words                 9
appended terminal word       0xD65F03C0
terminal interpretation          RET X30
```

Current identities are:

```text
source FNV                    5a4f6b2d5b0b42d4
object FNV                    90e9dae757b9f196
object semantic FNV           5d03577f6ff3be0e
loader semantic FNV           d2bec0624621d20b
installed-memory FNV          71a3734c1ac2f759
visibility semantic FNV       1b85bcad6a8fc3c3
repair semantic FNV           9c783eb50a1689e3
repair wire FNV               6fd20fc6f8300e23
```

The sealed preimage identities remain explicit:

```text
source FNV                    b9f106f99598adad
object FNV                    403a5c3a0ee255fe
object semantic FNV           15a2851fdf5adcd5
loader semantic FNV           eeb86170d0078916
installed-memory FNV          da161913c6998db2
visibility semantic FNV       f33930b3d84b2cf7
terminal-contract FNV         12d9da8b2ab05e31
```

## Atomic generation law

A repair candidate is accepted only when all fields belong to the selected old
and new generations. The status relation rejects at least these specimens:

```text
new source + old object
old source + new object
new object + old loader
new loader + old visibility
new visibility identity + old code end
changed M0-P8 event prefix
missing or changed RET word
claimed entry-ready outcome
```

A valid current file is not enough. The complete generation relation must be
current.

## Readiness result

The repaired source and object now contain the selected terminal transfer, so
the prior `BLOCKED_TERMINAL_CONTROL_FLOW` reason no longer applies. The selected
visibility result is now:

```text
certificate status     ACCEPTED
terminal kind          RETURN_X30
readiness              BLOCKED_UNDISCHARGED_PREMISES
entry ready            false
```

This is not a security regression and not an entry-readiness promotion. It is a
more precise blocked state. All sixteen visibility/platform premises and all
twelve live return requirements remain undischarged.

## C++20 machinery

The permanent executable implementation remains constrained C++20:

```text
include/slopos/m0/aarch64_s2_return_repair.hpp
src/m0/aarch64_s2_return_repair.cpp
tools/slopos_aarch64_s2_return_repair_main.cpp
tests/test_aarch64_s2_return_repair.cpp
tests/test_aarch64_s2_return_repair_noalloc.cpp
```

The hosted reference path uses vector-backed intermediate prefix values. The
constrained path uses fixed arrays. Both produce one 512-byte canonical wire.
All 4,096 one-bit wire mutations reject. The warmed constrained build,
serialize, decode, and status path performs no observed allocation.

## Isabelle root

`M0_AArch64_S2_Return_Repair.thy` checks exact finite propositions about:

- old and new extents;
- source and text deltas;
- unchanged object extent and code base;
- exact code-end extension;
- exact preimage and repaired identities;
- preserved event prefix and instruction identity;
- exact terminal word;
- unchanged terminal semantic contract;
- undischarged live and platform masks;
- blocked current readiness;
- mixed-generation rejection;
- rejection framing; and
- preservation of M0-P8 instruction admission and the terminal contract.

The theory imports no source semantics, assembler correctness, ELF loader
semantics, live register semantics, or Arm instruction-step semantics.

## Recovery and lineage

An unexplained detached writer modified an unsealed scratch tree during this
office. Those bytes were quarantined and were not allowed to become authority.
The active tree was re-extracted from sealed rev0790; only reviewed bounded
mechanical changes were reimplemented, regenerated, tested, and proved.

The exact rev0790 preimage and the detached candidate diff are preserved under:

```text
vault/epoch-zero/rev0791-terminal-repair-preimage/
```

## Non-claims

This decision does not establish:

```text
source-language or assembler semantics
general ELF or loader correctness
physical placement or executable mappings
cache or instruction visibility effect
live EL2, X0, X1, X2, or X30 state
call-edge establishment of X30
RET execution or same-EL return semantics
barrier, TLBI, or register completion
boot or guest execution
CPU isolation
DMA/SMMU/device isolation
multicore or information-flow security
```

## Next bounded experiment

M0-P10R may construct one exact caller-edge/X30 **value contract** that binds a
numeric continuation target, alignment, ownership role, and call-site identity.
It must remain a pure value and stop before live register state, branch-and-link
execution, return execution, or boot.
