# DEC-0009 — Preserve source archives without recursive revision nesting

**Status:** accepted
**Revision:** 0763

## Decision

The Epoch Zero archive is self-contained, but it will not embed the complete prior
Epoch Zero revision archive inside every new revision.  Recursive nesting would
make each close larger while adding no new recoverable information.

The durable vault has three layers:

1. `vault/source-archives/` contains byte-preserved rev0760 SlopOS and the seven
   supplied companion-cube archives, with SHA-256 inventory;
2. `vault/searchable/rev0760/{foundation,evidence-law,sequence-law}/` contains exact
   selected old-cube sources used by active decisions, preserving original relative
   paths and hashes;
3. `vault/searchable/rev0761/` contains the searchable first Epoch Zero repository
   snapshot inherited from rev0762.

The deleted nested rev0761 zip is represented by its historical hash in
`vault/lineage/SHA256SUMS` and by the searchable rev0761 snapshot.  Revision-specific
construction evidence remains under `evidence/`.

## Recovery rule

A future maintainer must be able to:

- verify every stable source archive with `vault/source-archives/SHA256SUMS`;
- locate every promoted old rule through `docs/vault/SOURCE-ANCHORS.md`;
- inspect the first Epoch Zero design without extracting an embedded zip;
- distinguish source-cube preservation from active Epoch Zero law.

If a future close changes the source-archive set, it must explain why and regenerate
the inventory.  Ordinary revision closes must not duplicate the predecessor zip.
