# DEC-0047 — Active lane, sequence, and revocation fences

**Status:** ACTIVE  
**Epoch:** EPOCH_ZERO / CLOSURE  
**Revision:** 0799

## Context

The canonical rev0798 combined active K0/P0 work with every historical M0/AArch64
construction in the default graph. Its authority specimen separated proposal,
lease, invocation, revoke, and observe, but accepted state-changing operations used
raw unsigned sequence increment. A second rev0798 branch contained a stronger
subtree-revocation prototype under a parallel living root.

## Decision

1. Keep the canonical rev0798 root as predecessor and one active project root.
2. Move M0/AArch64 targets and tests into `cmake/SlopOSLegacyM0.cmake`, disabled by
   default and enabled only by `SLOPOS_BUILD_LEGACY_M0=ON`/`full-research`.
3. Split Isabelle into active `SlopOS_K0` and paused `SlopOS_M0` sessions.
4. Make finite accepted-sequence availability an admission fence for PROPOSE,
   ISSUE, INVOKE, and REVOKE. Preserve all earlier validation/first-failure
   decisions. Keep OBSERVE read-only.
5. State the abstract sequence law in `P0_Authority_Sequence.thy`; do not claim a
   current theorem run or C++ refinement without their gates.
6. Treat revocation as six distinct clocks. The current C++ specimen claims only
   future-use withdrawal of one lease.
7. Do not reuse authority slots. Generation-qualified identity, lineage, dependent
   invalidation, and quiescence are prerequisites, not optional optimizations.
8. Preserve vault archives byte-for-byte; publish digest inventory/overlap evidence
   instead of deduplicating custody.

## Consequences

The ordinary graph is 96 steps instead of 246, while the full lane remains
reproducible. Terminal sequence wrap is no longer an admitted effect. The proof and
implementation claim ceilings become narrower but more truthful. Fixed-capacity
exhaustion remains preferable to ambiguous reuse.

## Rejected alternatives

- Delete M0/AArch64 work: rejected because it destroys evidence and reproducibility.
- Keep it default and rely on selective targets: rejected because configure-time
  assembler/QEMU authority and broad tests still burden every office.
- Saturate or wrap the sequence: rejected because either aliases distinct accepted
  histories or reports acceptance without a fresh evidence position.
- Copy the alternate `living/epoch-zero/` tree: rejected because it creates a second
  normative root.
- Add generation/reuse immediately: rejected until a representation relation can
  explain stale-reference safety.
- Call the abstract source `THEOREM CURRENT`: rejected while Isabelle2025-2 is absent.
