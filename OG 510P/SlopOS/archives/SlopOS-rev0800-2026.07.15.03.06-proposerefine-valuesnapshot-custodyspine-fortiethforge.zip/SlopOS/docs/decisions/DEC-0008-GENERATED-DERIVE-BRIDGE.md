# DEC-0008 — Generate the authoritative DERIVE body from KIR-0

**Status:** accepted and implemented for `DERIVE` only
**Revision:** 0763
**Narrows:** DEC-0007 and `OBL-CPP-SEM-001`

## Decision

For the first implementation-semantics experiment, SlopOS selects the
**generated-core** route.

`spec/kir0-derive.program` is the sole handwritten source of the ordered `DERIVE`
guard program.  The permanent C++20 tool `slopos-kir-compile` parses that closed
language and emits three artifacts atomically:

1. `generated/include/slopos/k0/generated/derive_policy.hpp`, containing the exact
   guard array, finite fact extractor, and commit body used by `CoreMachine`;
2. `proof/generated/KIR0_Derive_Generated.thy`, containing the same guard sequence
   as Isabelle/HOL data;
3. `generated/kir0/derive-binding.txt`, recording source lines and fingerprints.

`CoreMachine::derive` delegates to the generated body.  There is no second
handwritten C++ policy body.  The clear reference model remains independently
implemented and is checked against the generated core by the oracle.

## Why this route

The competing checked-source route was prototyped conceptually and stopped before
becoming permanent machinery.  A checker over C++ tokens would certify only a text
shape, not C++ meaning.  A checker over a compiler AST would import a large parser,
compiler version, and language-semantics boundary before one transition had earned
that cost.  Generating a tiny, rigid body from an eleven-guard program removes the most
immediate handwritten policy drift with a smaller admitted schema.

This is not a decision that every future transition must be generated.  It is a
successful, bounded experiment for one operation.  A later operation must show
that reuse remains simpler than another approach.

## Exactly what improved

The following question is now mechanically answered:

> Did the core execute the same ordered guard program that the Isabelle theory
> names?

The generator and currency test bind those artifacts by source and program
fingerprints.  Concrete tests exercise all eleven first-failure positions, exact statuses, rejection
atomicity, and the successful child shape.  Independent bounded witnesses now compare
6,963,200 fact cases, 577,368 whole-array successful commits, and 577,368
terminal whole-array frames against separately
encoded expectations, each with a stable finite-domain fingerprint.

## Exactly what remains open

Generation does **not** establish a theorem about compiled C++20.  The remaining
bridge is split rather than hidden:

- `OBL-KIR-FACTS-001`: the generated C++ fact extractor represents the formal
  `derive_facts_of` definition for every admitted state and command;
- `OBL-KIR-COMMIT-001`: the generated C++ commit update represents formal
  `derive_effect` and changes nothing else;
- `OBL-CAP-REP-001`: the fixed C++ capability array represents the formal map
  under explicit presence, bounds, and field relations;
- `OBL-SEQUENCE-SOURCE-001`: the generated/source accepting path visibly gates
  terminal sequence state before commit (now source-level conformance);
- `OBL-SEQUENCE-REFINE-001`: the focused DERIVE sequence rule is connected through
  `CAP-REP`, formal transition, generated facts/commit, and compiled execution;
- `OBL-SEQUENCE-BOUND-001`: the historical all-claimed-operation umbrella remains
  open until every included transition has that complete correspondence;
- `OBL-CXX-COMPILER-001`: compilation and execution preserve the admitted source
  behavior under a named compiler/ABI/platform envelope;
- `OBL-CPP-SEM-001`: umbrella debt closed only when the implementation-semantics
  chain is adequate for the claimed scope.

The generator itself is currently trusted for conformance evidence.  Its parser is
tested with malformed programs and generated artifacts are checked for currency,
but it is not verified.

## Scope guard

KIR-0 remains a closed `DERIVE` guard language plus one fixed commit schema.  It is
not a general IR, compiler, policy language, or kernel bytecode.  No loop, pointer,
dynamic allocation, exception, concurrency primitive, platform access, or generic
record update may enter through this decision without a new decision record.
