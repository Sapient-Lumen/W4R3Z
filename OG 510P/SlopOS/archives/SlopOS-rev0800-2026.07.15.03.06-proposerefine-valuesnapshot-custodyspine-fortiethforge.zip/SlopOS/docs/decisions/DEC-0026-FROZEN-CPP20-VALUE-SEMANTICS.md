# DEC-0026 — Admit one frozen C++20 value-language semantics rung

**Status:** accepted

## Decision

Epoch Zero admits one closed Isabelle/HOL value-language model for the exact
proof-owned scalar companion. The model lives in:

```text
proof/K0_Capability_Scalar_Cpp20_Value_Semantics.thy
```

It is the authoritative semantics only for the normalized syntax tree defined in
that theory. It is not a general C++ frontend and it does not silently assign
meaning to source tokens, a translation unit, compiler output, an ABI, or a machine.

The admitted model contains exactly the value-bearing constructs used by the frozen
companion:

```text
bool values
nonnegative unsigned-long values bounded by an explicit max_ulong
cell-field reads
==, !=, <, !
short-circuit && and ||
selected ?: evaluation
scoped projection tags as closed constructors
aggregate value construction
one local const bool binding
if and return
```

The companion carrier premise is explicit:

```text
v0_carrier_admitted cell
v0_cpp20_companion_envelope_admitted max_ulong
```

The second premise requires `max_ulong >= 65535`. It is sufficient for every
proof-facing scalar field and sentinel admitted by CAP-REP. The theorem does not
choose one ABI width or object representation.

## Checked result

The accepted Isabelle session establishes, among supporting lemmas:

```text
v0_cpp20_carrier_within_ulong
v0_cpp20_live_payload_expr_exact
v0_cpp20_companion_project_value_exact
v0_cpp20_companion_projection_observe_exact
v0_cpp20_companion_value_semantics_exact
v0_cpp20_companion_value_matches_certificate
```

The load-bearing result is:

```text
admitted carrier + admitted unsigned-long envelope
  -> normalized companion statement evaluation
  -> exact raw absent / rejected / present aggregate
  -> scalar observation
  -> v0_scalar_project
```

`OBL-CAP-SCALAR-COMPANION-SEM-001` is therefore promoted to `THEOREM`, but its
claim text is narrowed to this normalized value-language relation.

## The source boundary remains open

The following is a distinct obligation:

```text
OBL-CAP-SCALAR-COMPANION-ADEQUACY-001
```

It asks whether the exact frozen companion token/declaration/function stream parses,
binds, and normalizes to the admitted AST with the intended helper bodies and
`project` body under the relevant C++20 rules.

This obligation is not discharged by:

- byte identity;
- the no-directive/no-include source audit;
- reading the standard;
- GCC or Clang accepting the file;
- constant evaluation through `static_assert`;
- the 593,907-case compiled witness;
- equality with the older finite certificate;
- the theorem about the normalized AST.

The compiler, ABI, binary, boot, and platform relations remain separate as well.

## Selected implementation envelope

The permanent C++20 companion audit now records four compile-time facts for every
selected build lane:

```text
implementation_unsigned_long_integer
implementation_unsigned_long_unsigned
implementation_unsigned_long_covers_floor
companion_value_fields_are_unsigned_long
```

The corresponding static assertions fail the build unless the selected
implementation represents every companion scalar value in `unsigned long` with at
least the admitted 0…65535 range. This is
`OBL-CAP-SCALAR-COMPANION-ENVELOPE-001`, classified as `CONFORMANCE`, not a theorem
about all C++20 implementations or any compiler's preservation of source meaning.

## Standards review boundary

The proof design was checked against the public C++20-era working draft N4868,
including the clauses conventionally named:

```text
[basic.fundamental]
[expr.eq]
[expr.rel]
[expr.log.and]
[expr.log.or]
[expr.cond]
[dcl.enum]
[dcl.init.aggr]
[stmt.if]
[stmt.return]
```

Primary review copy:

```text
https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/n4868.pdf
```

That review constrains what the admitted model must eventually be shown adequate
to. It is not imported or mechanized and therefore supplies no theorem by itself.

## Rejected alternatives for this rung

### A general C++ frontend

Rejected. The target is a frozen 90-line companion and the needed dynamic fragment
is tiny. Admitting a broad parser and semantic stack before proving this exact edge
would add more trust, dependency, and recovery surface than it removes.

### BRiCk/cpp2v as a second root

Not adopted. BRiCk is serious modern C++ proof infrastructure, but its `cpp2v` route
lands in Rocq/Coq and would create a second theorem root plus a new cross-prover
correspondence problem. It remains research pressure for a later independent or
compiler-facing experiment.

### AutoCorres2 through a C mirror

Not adopted for this edge. AutoCorres2 is valuable Isabelle machinery for C, not
C++20. A C island would require an exact C/C++ same-meaning relation and would become
a second implementation spelling unless generated and checked more narrowly than
the direct value-language model. The present experiment showed no such reduction.

### Compiler agreement as semantics

Rejected. GCC/Clang/sanitizer agreement remains bounded counterexample pressure and
selected-implementation evidence. It cannot promote source-language or compiler
correctness.

## Consequences

- Isabelle/HOL remains the sole theorem root.
- C++20 remains the sole permanent executable harness and implementation language.
- The frozen companion bytes remain unchanged.
- No new K0 operation or runtime dependency is added.
- The exact normalized value semantics are now checked rather than merely planned.
- The unresolved edge is smaller and named: exact source-to-normalized-AST adequacy.
- E0-P12 receives one bounded office to close or sharply reject that edge; after that
  the scalar island is frozen and Epoch Zero returns to the first physical isolation
  construction unless a concrete counterexample demands otherwise.
