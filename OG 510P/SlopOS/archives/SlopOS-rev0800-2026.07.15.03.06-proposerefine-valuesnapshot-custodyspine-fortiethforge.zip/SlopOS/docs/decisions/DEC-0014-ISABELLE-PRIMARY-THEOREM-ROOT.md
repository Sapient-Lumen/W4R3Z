# DEC-0014 — Isabelle/HOL is the primary theorem root

**Status:** accepted
**Revision activated:** 0766

## Decision

SlopOS uses **Isabelle/HOL 2025-2** as its one authoritative interactive theorem
prover for Epoch Zero. Isabelle theories are a narrow proof-language exception to
the C++20 law. Active implementation, executable models, generators, witnesses,
proof orchestration, evidence capture, and office tooling remain C++20.

Lean is not rejected as incapable. Lean 4 has a small proof-checking kernel,
dependent types, strong extensibility, and an explicit software-verification
mission. It is not selected as a second root because the present SlopOS problem is
not “find a pleasant general prover.” It is to build a seL4-shaped, relational
refinement stack for a kernel and eventually connect implementation semantics to
that stack. Isabelle/HOL has the closest directly relevant precedent, proof style,
and surrounding L4/AutoCorres ecosystem.

## Consequences

- `proof/ROOT` names the only authoritative formal session: `SlopOS_K0`.
- A theorem is not current because a `.thy` file exists. It is current only when the
  exact pinned session accepts with `quick_and_dirty=false`, no proof-hole marker,
  and evidence bound to the active construction basis and proof tree.
- We do not duplicate A0, D0, KIR, or representation relations in Lean.
- SMT solvers, bounded model checkers, fuzzers, sanitizers, differential tests, and
  exhaustive finite explorers remain auxiliary evidence. They do not become a
  second theorem authority.
- AutoCorres2 may be evaluated only as an Isabelle-side C source-semantics bridge.
  It does not parse general C++20 and cannot silently close a C++ theorem edge.

## Reconsideration gate

A bounded Lean experiment may be admitted only when it names one obligation that it
can close better than the current route, carries no second authoritative
specification, and is removed or quarantined after the decision. A full switch or a
second root requires one of:

1. a maintained Lean route closes a named C/C++ or kernel refinement edge that the
   Isabelle route cannot;
2. Isabelle is shown by measured work, not taste, to block the proof programme; or
3. independent proof checking is deliberately funded as a product objective with a
   translation/currentness design of its own.

## Toolchain pin

The accepted checker is exactly `Isabelle2025-2`. The repository records the
version, Docker image manifest, distribution-layer digest, size, and installer
identity in `toolchains/isabelle.lock`. The third-party distribution is kept outside
revision ZIPs.

The comparative rationale is maintained in `docs/proof/WHY-ISABELLE.md`. Fresh
session and lost-layer recovery are governed by DEC-0018 and
`docs/office/RECOVERY.md`; toolchain readiness is necessary but is not theorem
evidence.
