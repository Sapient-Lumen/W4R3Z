# DEC-0032 — M0 AArch64 stage-2 cold-activation value protocol

- Status: accepted for epoch zero
- Decision owner: SlopOS epoch-zero office
- Scope: M0-P6 only
- Supersedes: no earlier decision
- Depends on: DEC-0028 through DEC-0031
- Amended by: DEC-0033 in rev0785

## Decision

SlopOS admits one **pure finite value protocol** above the rev0781 owned-memory
installation relation.  It binds the exact installed-memory, packet, graph, and
admission identities to one selected AArch64 stage-2 root/control envelope and
twelve closed protocol labels.

The protocol is an intent model.  It contains no instruction bytes, inline
assembly, system-register access, barrier, cache operation, TLBI operation,
exception path, or hardware observation.

```text
BIND_INSTALLED_MEMORY
PUBLISH_TABLE_BYTES
COMPLETE_TABLE_PUBLICATION
SELECT_CONTROL_VALUE
SELECT_ROOT_VALUE
SYNCHRONIZE_SELECTION
INVALIDATE_SELECTED_CONTEXT
COMPLETE_INVALIDATION
SYNCHRONIZE_INVALIDATION
ENABLE_STAGE2
SYNCHRONIZE_ENABLE
SEAL
```

A transition accepts exactly the next selected label.  All request and state
failures return the exact prior protocol state.

## Exact selected input

| Field | Selected value |
|---|---:|
| protocol version | 1 |
| installed-memory generation | 2 |
| installed-memory FNV | `0f5d2f8c81d299d2` |
| installed-byte FNV | `9ce4d5ca56ccb72d` |
| packet FNV | `a1d0b02ad4351902` |
| graph FNV | `32ec119640d7e72d` |
| sealed-admission FNV | `e11907ffe581eac8` |
| root domain | 1 |
| VMID | 1 |
| IPA bits | 39 |
| start level | 1 |
| selected PA bits | 40 |
| selected VMID bits | 8 |
| granule bytes | 4,096 |
| root table value | `0x0000000040000000` |
| selected `VTCR_EL2` value | `0x0000000000023559` |
| selected `VTTBR_EL2` value | `0x0001000040000000` |
| selected `HCR_EL2` value | `0x0000000080000001` (`VM|RW`) |
| final protocol-state FNV | `670fe80725b1dca9` |

Rev0785 corrects the selected `HCR_EL2` value from rev0784's `VM`-only
`0x1` to `VM|RW = 0x80000001`, because the selected envelope requires lower
EL1 to execute in AArch64 state.  The old tuple and final fingerprint
`fb6debd0b996a329` remain explicit rejected lineage.  A sealed predecessor is
history authority, not authority to keep a contradicted current value.

The `VTCR_EL2` value is constructed from the selected finite fields
`T0SZ=25`, `SL0=1`, `IRGN0=1`, `ORGN0=1`, `SH0=3`, `TG0=0`, `PS=2`,
`VS=0`, and `DS=0`.  The `VTTBR_EL2` value binds VMID 1 to the selected
root-table integer value.  These decompositions are checked facts about the
selected integers; they are not yet a proof that the values are legal or
sufficient for a concrete Arm PE.

## Total fail-closed precedence

The active C++20 machines and Isabelle model use this order:

```text
BAD_STATE
ALREADY_SEALED
BAD_VERSION
BAD_MEMORY_IDENTITY
BAD_GRAPH_IDENTITY
BAD_ROOT_IDENTITY
BAD_CONTROL_VALUE
BAD_PROTOCOL
BAD_STEP
ACCEPTED
```

The order is part of the selected construction.  A malformed sealed state is
`BAD_STATE`, not `ALREADY_SEALED`.  Rejection never repairs or advances state.

## Independent C++20 implementations

The hosted reference stores the accepted history in a vector and mutates
independent scalar fields.  The constrained core stores a fixed-capacity state
and accepted-prefix array.  They share value declarations and selected
constants but do not share transition implementations.

The permanent harness checks all 144 reachable `(phase, candidate-label)`
cases.  Exactly 12 accept and 132 reject without mutation.  Representative
request and state mutations establish the precedence categories.  The warmed
core request/build/run/snapshot/fingerprint path performs no observed global
allocation.

## Formal root

`M0_AArch64_S2_Activation.thy` models the same closed alphabet, selected
request, canonical prefix states, status precedence, total transition, and
selected run.  Isabelle is required to establish the mapped finite-state
lemmas before close.

The theorem root proves facts about values and a pure relation.  It does not
supply Arm operational semantics or ISO C++20 execution semantics.

## Architecture-source law

Normative architecture meaning must come from an explicitly pinned Arm
architecture envelope.  The current official-source notes identify the
register descriptions, stage-2 overview, TLB-maintenance chapter, and
break-before-make section used to constrain the next investigation.

Those sources motivated the separation among publication, root/control
selection, synchronization, invalidation, enable, and observation.  They do
**not** yet establish that the twelve labels map to one adequate instruction
sequence.

## Rejected alternatives

### Emit assembly now

Rejected.  That would cross from a value protocol into source, compiler,
instruction, privilege, and hardware-effect claims before the architecture
adequacy edge exists.

### Treat label names as architecture commands

Rejected.  `SYNCHRONIZE_SELECTION` and `INVALIDATE_SELECTED_CONTEXT` are
semantic intent labels, not aliases for a particular DSB, ISB, or TLBI
instruction.

### Generalize the protocol surface

Rejected.  Epoch Zero needs one closed falsifiable specimen, not a generic
register-programming DSL.

### Infer activation from installed bytes

Rejected.  Installation, publication, current root selection, invalidation,
enablement, and hardware observation remain distinct layers.

## Non-claims

This decision does not establish:

- legality or sufficiency of the selected values on a concrete Arm PE;
- an Arm instruction sequence or barrier/TLBI operand;
- table-memory cacheability, shareability, visibility, or physical placement;
- system-register access, exception level, or privilege correctness;
- compiler, ABI, binary, boot-image, or instruction identity;
- TLB invalidation, hardware translation, fault, or observation;
- guest execution, CPU-memory isolation, DMA/SMMU/device isolation;
- multicore, concurrency, information-flow, timing, or side-channel claims;
- completion of any A/B/C/D product profile.

## Consequence

The next bounded proof question is architecture-to-intent adequacy.  It must
pin an exact architecture/feature envelope and either close or reject a mapping
from these twelve labels to required abstract architecture events.  No actual
register effect is authorized by this decision.
