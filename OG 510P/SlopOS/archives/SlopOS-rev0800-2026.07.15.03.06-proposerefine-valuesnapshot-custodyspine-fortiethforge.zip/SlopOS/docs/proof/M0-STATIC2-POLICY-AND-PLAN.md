# M0-STATIC2 proof boundary

## Authoritative files

```text
include/slopos/m0/static2.hpp
src/m0/static2.cpp
generated/m0/static2-policy.txt
proof/generated/M0_Static2_Generated.thy
proof/M0_Static2.thy
```

`slopos-static2 --emit` owns the generated witness and Isabelle constant.
`slopos-static2 --check` rejects drift. The exact generated theory is then accepted
inside the sole `SlopOS_K0` Isabelle2025-2 session.

## Checked propositions

The active policy lemmas establish, for the exact generated constants:

- the 64-page aperture and 16-page monitor reservation;
- disjoint private ranges `[16,32)` and `[32,48)`;
- private ranges avoid the monitor;
- page 48 is inside the aperture and outside monitor/private ranges;
- the declared monitor/private/shared partition is exactly pages `0..48`.

The active plan lemmas establish, for the exact 34-tuple generated plan:

- exact plan length;
- exact domain set `{1,2}`;
- uniqueness of every `(domain, virtual page)` key;
- exact physical image `{16..<49}`;
- exact read/write permission value;
- exactly two page-48 shared records;
- every cross-domain physical alias is that shared page;
- every private mapping has the selected offset translation.

## What the proof does not establish

The generated theory is a C++20-produced proof input. Currentness proves that the
checked file is exactly what the active generator emits; Isabelle does not thereby
prove the generator, compiler, FNV implementation, wire decoder, planners, or
installers. Their behavior is separately constrained by compile-time checks,
differential tests, mutation tests, allocation tests, and deterministic witnesses.

No M0 theorem names a page-table bit, architecture register, boot event, or deployed
isolation claim. Those remain future rungs.
