# Proof note — repository boundary

`E0_Repository_Boundary` proves properties of an abstract path-class projection:

- vault is not construction;
- living construction is not custody;
- evidence joins neither subject;
- unknown paths reject;
- vault mutation preserves construction projection;
- living mutation preserves custody projection;
- evidence mutation preserves both projections; and
- unequal recorded/observed identities are not current.

It does not model path parsing, policy priority, SHA-256, permissions, archive
semantics, filesystem traversal, symlinks, concurrent mutation, or C++ code. Those
are covered only by executable tests and explicit premises in rev0798. A future
refinement proof must connect the ordered TSV policy and canonical manifest to this
projection or replace the theory with a closer executable model.
