# Proof boundary — M0 AArch64 caller readiness assessment

## Checked proposition family

The Isabelle2025-2 session checks exact finite facts about:

- assessment extent and closed requirement/premise counts;
- exact observed and required masks;
- zero discharged machine-premise mask;
- exact rev0793 predecessor and artifact identities;
- exact source/object/text identities, generation, owner, and permission value;
- exact page, helper, caller, callsite, callee, continuation, and X30 values;
- exact BL, NOP, and RET X30 words;
- exact EL/AArch64/same-EL value record;
- absence of live PC and X30 observations;
- exact sixteen-step order and associated premise/address lists;
- selected acceptance and exact `BLOCKED_MACHINE_PUBLICATION` result;
- selected failure of the entry-ready predicate;
- deterministic precedence examples;
- rejection-state frame;
- selected admission and state transition;
- preservation of rev0793 caller-artifact admission; and
- nonzero generated identities.

## Assumption boundary

The fourteen machine premises are finite names and bits. Isabelle proves that
they are required and undischarged. It does not prove any premise true.

In particular, the root imports no semantics for physical memory, stage-1 or
stage-2 permissions, translation walks, D/I caches, barriers, TLBs, instruction
fetch, registers, exception levels, BL, RET, or boot.

## Correspondence boundary

```text
current C++20 readiness value
  -> generated natural/list constants          currentness evidence
  -> Isabelle finite readiness relation         checked theorem
  -X-> ISO C++20 source semantics
  -X-> host or physical publication
  -X-> permission or translation effect
  -X-> cache visibility
  -X-> live PC/X30 state
  -X-> BL/RET execution or completion
  -X-> booted isolation
```

Reference/core agreement, mutation testing, sanitizers, and no-allocation
observation remain bounded executable evidence.

## Rejection theorem

The formal transition is total. A request whose status is not accepted returns
the exact prior readiness state. This says nothing about rollback of a partially
modified live machine, because no live-machine modification exists in this
construction.

## Promotion rule

`OBL-M0-S2-CALLER-READINESS-001` may remain `THEOREM` only while all of these
are current:

- generated manifest, wire, and Isabelle constants;
- exactly 36 mapped lemma rows;
- zero-hole Isabelle2025-2 acceptance;
- exact construction-basis and proof-tree identities;
- the rev0793 caller-artifact theorem; and
- the explicit machine-premise and non-effect boundary.

No machine premise may be promoted by editing the selected mask. It requires a
separate construction and separately scoped evidence.
