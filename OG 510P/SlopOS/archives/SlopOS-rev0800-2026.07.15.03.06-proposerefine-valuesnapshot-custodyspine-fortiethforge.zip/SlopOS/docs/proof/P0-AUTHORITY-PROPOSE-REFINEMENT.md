# P0 authority PROPOSE refinement boundary

## Layers

| Layer | Artifact | Current status |
|---|---|---|
| Abstract authority | `P0_Authority_Lease.thy` | source present; current session blocked |
| Finite sequence wrapper | `P0_Authority_Sequence.thy` | source present; current session blocked |
| Bounded PROPOSE value semantics | `P0_Authority_Propose_Refinement.thy` | source present; current session blocked |
| C++ canonical projection | `AuthorityValueSnapshot` and two `snapshot()` implementations | compiled witness |
| Independent expected transformer | `authority_propose.cpp` in refinement library | bounded executable evidence |
| C++ source semantics | none selected | open debt |
| Compiler/binary/platform relation | none selected | open debt |

## Exact first failure

Within the selected PROPOSE transformer:

```text
operation scope
then id/actor/subject/resource/action/amount validity
then duplicate identifier
then proposal capacity
then accepted-sequence availability
then acceptance
```

A terminal sequence does not override invalid, duplicate, or capacity decisions.
This ordering is semantic because multiple faults can coexist.

## Snapshot relation currently executed

A snapshot is well formed when:

- occupied proposal and lease entries form prefixes;
- identifiers are nonzero, strictly ascending, and individually valid;
- empty tails are exact default objects;
- proposal/lease resource and action values are in the selected finite domains; and
- resources and sequence are represented in full.

For acceptance, the checker computes a sorted fresh insertion and requires every
other cell to frame. For denial, it requires byte-independent value equality of the
entire typed snapshot. The check is stronger than rendered-string equality but does
not state anything about C++ object bytes or padding.

## HOL relation currently stated

The HOL context contains a finite identifier set, its count, and a sequenced selected
authority state. Explicit predicates bound command carriers to 16/64-bit value
ranges. The accepted transition inserts the identifier, increments count and
sequence, and applies `p0_register_proposal`; denial returns the exact context.

The abstraction deliberately loses physical proposal-array order and older proposal
payloads. Therefore the executable and formal edges share a carefully reviewed
vocabulary but do not yet have a mechanized total relation. Calling this a completed
commuting proof would be false.

## Current theorem evidence rule

The source contains no `sorry`, `oops`, `admit`, `axiomatization`, or oracle escape.
That scan is hygiene only. The declarations become current theorem evidence only
when the pinned Isabelle2025-2 executable checks `SlopOS_K0` against the exact
construction basis and the evidence packet binds that run.

## Smallest next proof

Run the pinned session first. Then decide whether a relation from canonical proposal
prefixes to the HOL identifier/context projection can be stated without introducing a
new source language. Only after that relation is checked should the project consider
an exact C++ expression/statement semantics experiment.
