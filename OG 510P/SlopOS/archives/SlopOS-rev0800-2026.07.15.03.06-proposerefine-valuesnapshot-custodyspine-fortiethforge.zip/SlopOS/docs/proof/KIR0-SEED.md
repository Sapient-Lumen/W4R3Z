# KIR-0 `DERIVE` seed

Rev0764 introduced one ordered eleven-guard program and one fixed successful commit
schema. Rev0765 added the value-level capability representation relation. Rev0766
runs the formal chain through a real pinned checker and adds exact initial
representation.

## Authority chain

1. `spec/kir0-derive.program` is the only handwritten guard-order source.
2. `slopos-kir-compile` emits the core C++20 policy, Isabelle guard data, and binding
   manifest.
3. `generated/k0/capability-encoding.txt` and
   `K0_Capability_Encoding_Generated.thy` carry one generated proof-facing value
   encoding into C++20 and Isabelle.
4. `CoreMachine::derive` delegates to the emitted body; it has no handwritten policy
   duplicate.
5. `ReferenceMachine::derive` remains structurally independent.
6. `KIR0_Derive.thy` defines formal facts/outcome and checked equality to D0;
   `K0_Capability_Representation.thy` defines the presence-gated twelve-cell
   proof-value relation; `K0_Derive_Representation.thy` proves mapped fact, commit,
   frame, rejection, and sequence propositions.
7. `K0_Refinement.thy` proves the mapped KIR→D0→A0 success chain and formal denial
   frame.
8. `K0_Sequence.thy` isolates the finite natural-number schema.
9. The independent bootstrap materializer and generated bootstrap image establish
   the checked proof-value initial CAP-REP/sequence-zero propositions.
10. `proof/theorems.tsv` is the exact claim map. It prevents “the session passed”
    from becoming a global implementation claim.

## Evidence obtained

- malformed-source rejection and byte-current artifact checks;
- compile-time first-failure guard enumeration;
- concrete exact precedence for eleven denials plus success;
- an active generated precedence trace through model/core/oracle;
- independent fact equality over 6,963,200 cases, fingerprint
  `a2dea114ba75bbd5`;
- independent whole-array successful commit/frame equality over 577,368 cases,
  fingerprint `5a50b918f6bdfc7d`;
- independent terminal whole-array frame equality over 577,368 cases, fingerprint
  `84f6af288db22ca5`;
- 25 model/core sequence-boundary and precedence cases across all operations,
  fingerprint `1b29e9f3f779ae41`;
- generated capability schema fingerprint `5bd3e08716f9bdfe` and manifest
  fingerprint `78ce1a23cf908b80`;
- CAP-REP dead/live/invalid/fact/frame witnesses over 9,309,684 cases;
- an independent bootstrap witness with fifteen malformed classes and exact image
  fingerprint `9b6b382bb77b2156`;
- exact mapped Isabelle lemmas accepted under Isabelle2025-2 with proof holes
  disabled and retained against the current construction basis.

The fact witness exposed a default-value ambiguity. The commit witness exposed the
finite-sequence mismatch. CAP-REP exposed dead payload versus lifecycle metadata.
The first real checker run exposed malformed theory transport and proof gaps. The
bootstrap image exposed initialization as a separate relation rather than an assumed
snapshot. Executable and formal pressure have therefore changed or sharpened the
machine before it grew.

## Claim boundary

Checked formal lemmas are `THEOREM` only for the propositions, premises, and
exclusions in `proof/theorems.tsv`. Finite C++ witnesses remain `BOUNDED` or `TEST`.
Generated identity removes selected hand-copy edges; it does not establish C++ source
semantics, generator correctness, object layout, compiler correctness, or platform
isolation.

The next formal pressure remains on the same scalar seam, not on another operation.
Rev0769 added a checked scalar source program and exact export/header currentness.
Rev0770 added the whole-input binder and finite certificate. Rev0771 adds direct HOL
structural execution and an independent constrained C++20 fragment interpreter with
bounded compiled-agreement evidence. None validates the binder, preprocessing,
renderer, ISO C++20 interpretation, compiler, ABI, or binary. E0-P10 retained one front-edge landing zone. Rev0773 checks only its normalized value-language construct set; E0-P12 owns exact source-to-AST adequacy. A C mirror and third evaluator are not admitted.

## Rev0772 no-KIR-growth note

No KIR atom, guard, command, commit rule, or generated DERIVE body changed. The
self-contained companion is generated directly from the already checked scalar
source program and is proof-only. E0-P10 therefore changes neither KIR authority nor
transition semantics.
