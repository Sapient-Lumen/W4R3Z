# Proof boundary — M0 AArch64 EL2 observation chamber

## Checked proposition family

The Isabelle2025-2 session checks exact finite facts about:

- certificate version and extents;
- twelve required and observed value bits;
- fourteen required and zero discharged machine-premise bits;
- exact M0-P13R predecessor binding;
- exact QEMU extent and selected generated identities;
- nonzero machine, CPU, and command identities;
- exact observer source/linker/ELF extents;
- exact report extent and identity;
- exact eight-register kinds and values;
- exact decoded CurrentEL, EL2, PA-range, granule, and VMID values;
- zero observed HCR_EL2, VTCR_EL2, and VTTBR_EL2;
- exact selected result;
- total selected acceptance;
- selected admission and non-discharge;
- rejection of forged discharge and stale predecessor/tool/profile/image/report/
  register/decoded/result values;
- rejection-state framing;
- selected state transition;
- preservation of the M0-P13R permitted/undischarged propositions; and
- nonzero generated identities.

## Assumption boundary

The theory imports no operational semantics for QEMU, AArch64 registers,
generic loading, semihosting, Clang, LLD, ELF, or the host kernel. It treats all
selected identities and observed values as generated natural constants.

The proposition:

```text
m0_el2_observation_current_el = 2
```

is a theorem about the generated decoded natural value. It is not a theorem that
QEMU or hardware executed at EL2 correctly. Likewise, zero control values are
not initialization, authority, publication, or activation theorems.

## Correspondence boundary

```text
exact QEMU/observer process output
  -> strict C++20 report parser                bounded executable evidence
  -> generated finite constants               currentness edge
  -> Isabelle finite status relation           checked theorem
  -X-> ISO C++20 semantics
  -X-> Clang/LLD/ELF semantics
  -X-> QEMU correctness
  -X-> Arm operational semantics
  -X-> emulator/hardware correspondence
  -X-> machine-premise truth
  -X-> stage-2 or isolation effect
```

## Rejection theorem

The formal observation transition is total. Any request whose finite status is
not accepted returns the exact prior formal admission state. This says nothing
about process cleanup, emulator rollback, host-kernel behavior, or machine
rollback.

## Promotion rule

`OBL-M0-EL2-OBSERVATION-001` may remain `THEOREM` only while all of these are
current:

- exact generated manifest, wire, and Isabelle constants;
- exact 30 mapped lemma rows;
- zero-hole Isabelle2025-2 `SlopOS_K0` session;
- exact construction-basis and proof-tree identities;
- accepted M0-P13R predecessor theorem rows;
- exact QEMU and observer locks;
- explicit zero machine-premise discharge; and
- explicit emulator/hardware/effect non-claims.

The hardware/platform observation and refinement obligation remains open.
