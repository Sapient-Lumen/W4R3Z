# Proof boundary — M0 AArch64 executable-visibility assessment

## Checked proposition family

The Isabelle2025-2 root checks exact finite facts about:

- certificate, wire, premise, and protocol extents;
- nonzero official-source-envelope identity;
- exact binding to M0-P10 loader and installed-memory identities;
- exact binding to M0-P9 object/specimen and M0-P8 instruction identities;
- exact 36-byte code range;
- selected 64-byte D/I cache-line values and one-line arithmetic containment;
- sixteen required and zero discharged external premises;
- exact eleven-step order, mechanism, scope, and address lists;
- exact PC, EL2/AArch64, X0/X1/X2, fallthrough, last-word, next-word, and
  terminal-kind values;
- selected certificate acceptance;
- selected `BLOCKED_TERMINAL_CONTROL_FLOW` outcome;
- selected non-entry-readiness;
- fail-closed representative precedence;
- rejection-state framing;
- exact accepted-assessment transition; and
- preservation of M0-P10 loader admission.

## Dual-result boundary

```text
certificate accepted
!= external premises discharged
!= entry ready
!= execution authorized
```

The accepted theorem is about an assessment certificate. The same theorem root
proves that the assessed artifact is not entry-ready.

## Architecture boundary

The root has no formal semantics for:

- `CTR_EL0` fields;
- points of unification;
- `DC CVAU`, `IC IVAU`, `DSB`, or `ISB`;
- cache maintenance, visibility, or context synchronization;
- live register or exception-level state; or
- fetch, decode, retirement, branch, return, or exception return.

Official Arm sources constrain engineering selection only.

## Premise boundary

The required natural mask is exactly `65535`; the discharged mask is exactly
zero. Isabelle proves those values. It does not establish any platform premise.

## Terminal boundary

The current exact finite facts are:

```text
last word       0xd5033fdf
fallthrough     0x40008024
next word       0x00000000
terminal kind   0 / NONE
```

The proof concludes only that the selected readiness function returns the
blocked-terminal outcome. It does not prove a general A64 control-flow decoder.

## Correspondence boundary

```text
C++20 selected assessment
  -> generated natural/list constants              currentness evidence
  -> Isabelle finite assessment relation            checked theorem
  -X-> ISO C++20 semantics
  -X-> formal Arm cache or instruction semantics
  -X-> live machine entry or effect
```

## Promotion rule

`OBL-M0-S2-VISIBILITY-ASSESSMENT-001` may remain `THEOREM` only while:

- all generated artifacts are current;
- all mapped M0-P11 lemmas exist;
- the complete zero-hole `SlopOS_K0` session is accepted;
- construction-basis and proof-tree identities are exact;
- M0-P10 theorem evidence remains current; and
- visibility readiness, terminal repair, cache effect, entry, and execution
  remain separate explicit debt.
