# Frozen C++20 companion value semantics

## Purpose

This document describes the exact theorem gained in rev0773 and the relations it
does not establish. The target is the proof-only companion:

```text
generated/proof/slopos/k0/proof/capability_scalar_companion.hpp
```

Its bytes remain those sealed in rev0772:

```text
bytes                 2570
lines                 90
SHA-256               6ecd6982a5c377dd204ef5010264cdbf5e6f614d6839915cbb596972a69bb71e
length-prefixed FNV   2edd08779c5baa00
```

## Current ladder

```text
checked seven-atom scalar program
  -> checked proof-companion program identity
  -> exact generated companion bytes                         CONFORMANCE
  -> exact source tokens/declarations normalize to AST       OPEN_DEBT
  -> admitted closed value-language AST evaluation           THEOREM
  -> observation equals v0_scalar_project                    THEOREM
  -> selected implementation has sufficient ulong carrier   CONFORMANCE
  -> compiler preserves source meaning                       OPEN_DEBT
  -> ABI / linked binary / boot / platform effect            OPEN_DEBT
```

The important change is that the value-language semantics rung is no longer an
unstructured promise. It is an executable deep embedding in the sole Isabelle root.
The source-to-AST rung above it remains open and cannot be inferred backward from the
theorem.

## Theory artifact

```text
proof/K0_Capability_Scalar_Cpp20_Value_Semantics.thy
```

Current source identity before close evidence is produced:

```text
lines       716
bytes       32995
SHA-256     88a6abe73e2ed72e2898687dcce7866825d4db6579bf775ccc2dca12143eb156
```

The theory imports the checked parsed-certificate relation so its final theorem can
compare two independently represented proof-facing paths. It does not call the
compiled companion or active scalar kernel.

## Values and environments

The value carrier is deliberately smaller than C++:

```text
V0CxxBool bool
V0CxxULong nat
```

An unsigned-long value is produced only when the natural value is no greater than
the explicit `max_ulong` parameter. The environment contains exactly one capability
cell and an optional local `parent_present` binding. There is no memory, pointer,
lifetime, aliasing, object representation, overload resolution, exception, dynamic
allocation, concurrency, volatile access, or library state.

That absence is a scope fence, not a claim that those C++ topics are simple.

## Expression and statement rules

The AST directly represents the needed expressions. Its evaluator is total into an
option type and fails closed on type mismatch or an unavailable local. Logical
conjunction and disjunction short-circuit; conditional evaluation selects exactly
one branch; aggregate construction requires the complete expected value shape.

The statement language has only:

```text
return projection-expression
const bool parent_present = expression; statement
if (expression) statement else statement
```

The exact helper expressions and `project` statement are closed definitions rather
than parser output. This is why token-to-AST adequacy remains separate.

## Raw result before observation

The theorem first proves the exact raw companion aggregate, including all zeroed
fields in absent and rejected results. Only then does a separate observation map the
raw scoped tag and fields to `v0_scalar_projection`.

This separation prevents a lossy observation from hiding a wrong aggregate image.
It also avoids making an ABI or object-layout claim: the raw object here is an HOL
record value, not C++ storage.

## Mapped theorem set

The theorem ledger retains six load-bearing lemmas:

| Lemma | Role |
|---|---|
| `v0_cpp20_carrier_within_ulong` | proves every admitted proof field fits the explicit envelope |
| `v0_cpp20_live_payload_expr_exact` | proves the normalized short-circuit helper result |
| `v0_cpp20_companion_project_value_exact` | proves exact raw absent/rejected/present aggregate evaluation |
| `v0_cpp20_companion_projection_observe_exact` | proves raw observation equals the scalar projection |
| `v0_cpp20_companion_value_semantics_exact` | composes normalized execution with observation |
| `v0_cpp20_companion_value_matches_certificate` | relates the normalized program to the checked finite certificate path |

Supporting lemmas separately establish every helper expression, constant, branch,
local binding, initializer, and selected conditional.

## Explicit premises

The main theorem requires:

```text
v0_carrier_admitted cell
v0_cpp20_companion_envelope_admitted max_ulong
```

CAP-REP bounds holder, generation, object kind, object id, rights, parent sentinel,
and slot constants within 0…65535. The envelope therefore needs only
`max_ulong >= 65535`.

The theory does not infer the implementation's `max_ulong`. The C++20 harness
separately checks the selected implementation with `std::numeric_limits<unsigned
long>` and static field-type assertions. Those observations are conformance evidence,
not premises smuggled into Isabelle.

## Exact non-claims

The checked theory does not prove:

- that the 2,570 companion bytes tokenize, parse, bind, or normalize to the AST;
- that the admitted rules are a complete formalization of ISO C++20;
- enum underlying type, object layout, padding, ABI, or calling convention;
- compiler front-end, optimizer, code generator, assembler, or linker preservation;
- equivalence between the companion and active fixed-width source for all values;
- binary identity, boot identity, platform execution, or privileged effect;
- timing, constant-time behavior, concurrency, information flow, or product
  isolation.

## Permanent executable pressure

The C++20 companion audit now emits:

```text
implementation_unsigned_long_integer=PASS
implementation_unsigned_long_unsigned=PASS
implementation_unsigned_long_covers_floor=PASS
companion_value_fields_are_unsigned_long=PASS
```

The witness still exercises exactly 593,907 cells and must preserve the rev0772
fingerprints. GCC, Clang, and sanitizer lanes are expected to produce identical
canonical witness output. This pressure can expose a bad premise or implementation
drift; it cannot promote the open adequacy or compiler obligations.

## Next proof edge

`OBL-CAP-SCALAR-COMPANION-ADEQUACY-001` is the sole bounded E0-P12 target:

```text
exact frozen source bytes
  -> C++20 tokens and declarations
  -> names/helpers/project association
  -> exact admitted normalized AST
```

A successful route must reduce this relation without adding a general frontend,
second theorem root, or merely self-certified parser. A measured rejection is valid.
After one bounded office, the scalar bridge is frozen so the project can spend proof
budget on the first physical two-domain isolation construction.
