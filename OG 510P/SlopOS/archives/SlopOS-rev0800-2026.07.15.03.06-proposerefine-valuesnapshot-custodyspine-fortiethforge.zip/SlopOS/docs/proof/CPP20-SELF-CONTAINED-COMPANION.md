# C++20 self-contained proof companion

## Purpose

The proof companion is a deliberately tiny source-language landing zone between the
checked seven-atom HOL program and a deliberately split C++20 semantics argument:

```text
canonical HOL program
  -> checked companion-program identity
  -> Isabelle/ML-rendered self-contained C++20 bytes
  -> exact exported/active byte gate
  -> exact source-to-normalized-AST adequacy            OPEN
  -> admitted normalized value-language semantics       THEOREM
  -> selected compiler/binary behavior                  OPEN

active generated kernel source
  -> independently compiled bounded agreement with companion
  -> universal active-source correspondence            OPEN
```

It removes project preprocessing machinery from the landing zone. It does not turn
source spelling into semantics. Rev0773 closes the normalized AST evaluation rung as
`OBL-CAP-SCALAR-COMPANION-SEM-001`; the distinct source-to-AST relation is now
`OBL-CAP-SCALAR-COMPANION-ADEQUACY-001` and remains `OPEN_DEBT`.

## Frozen artifact

```text
generated/proof/slopos/k0/proof/capability_scalar_companion.hpp
```

Current identity:

```text
bytes                            2570
lines                            90
SHA-256                          6ecd6982a5c377dd204ef5010264cdbf5e6f614d6839915cbb596972a69bb71e
raw FNV-1a                       6bf926414dc04328
length-prefixed FNV-1a           2edd08779c5baa00
```

The length-prefixed fingerprint is the office/harness currentness identity. SHA-256
is the retained archival identity. FNV is not a security digest.

## Admitted source surface

The entire generated source file uses only:

```text
namespace definition
enum class with three enumerators
two final aggregate structs
bool
unsigned long
integer literals with UL suffix
six namespace-scope constexpr constants
four constexpr noexcept functions
const by-value parameters
member access
==, !=, <, !, &&, ||, ?:
if / return
aggregate direct-list initialization
```

There are no pointers, references, arrays, dynamic storage, mutable globals,
user-defined constructors, inheritance, templates, overload sets, implicit function
calls, signed arithmetic, shifts, aliasing, unions, casts, library calls, or platform
access.

The C++20 source audit is permanent C++20 machinery:

```text
build/debug/slopos-cpp20-companion --root . --audit-only
```

It fails if directives, includes, macros, standard-library names, imported project
declarations, casts, dynamic/exception tokens, or the required closed shape drift.
The audit is conformance pressure, not a complete lexer or parser proof.

## Proof-owned identity

`K0_Capability_Scalar_Source.thy` defines
`v0_capability_scalar_companion_program` as exactly the canonical source program and
checks:

```text
v0_capability_scalar_companion_program_exact
v0_scalar_companion_eval_exact
```

The same theory's ML renderer reads the closed constructors and emits both active
kernel source and proof companion source. The proof runner exports both named files
and requires exact byte equality with the checked-in artifacts before accepting a
current session packet.

The renderer remains a named trusted translation component. The theorem proves the
input program identity; it does not prove that the emitted C++ tokens denote that
program.

## Bounded compiled correspondence

CMake first compiles the exact generated companion as its own C++20 source target,
with no project include directories. The bounded harness then includes the generated
companion before project headers, includes the active generated scalar kernel, and
compares value-shaped results. Successful compilation in either position is still a
compiler observation, not a language theorem.

The witness covers exactly:

```text
dead cells       327936 / 3ff1f907c5d2a725
valid cells      134784 / 93209a6a66ab8da5
invalid cells    131187 / c6c604c5beb5e375
total            593907
```

It is run under GCC, Clang, and a sanitizer lane. Static assertions exercise absent,
present, rejected, and constant identities during constant evaluation. None of this
is a universal language or compiler theorem.

## Exact front-edge reduction

The active kernel header imports fixed-width aliases and macros. The companion does
not. Therefore these assumptions are absent from the companion route:

```text
include search
recursive phase-1-through-4 processing of headers
<cstdint> content
imported project type declarations
UINT16_C / UINT8_C / UINT16_MAX macro expansion
project namespace lookup
conditional project preprocessor state
```

The C++ draft describes recursive include and macro work in phase 4:
`https://eel.is/c++draft/lex.phases`.

No-directive source does **not** skip the other translation phases. Source decoding,
line splicing, preprocessing-token formation, token conversion, syntactic and
semantic analysis, constant evaluation, translation, linking, and execution remain.

## Value-semantics fence

The companion intentionally uses `unsigned long` because C++20 guarantees at least
32 value bits for `long`/`unsigned long`; its exact width remains implementation-
defined. See `https://eel.is/c++draft/basic.fundamental`.

All admitted natural values are at most 65,535. The function performs only copies,
comparisons with representable constants, Boolean operations, and selection. It does
not add, subtract, multiply, shift, wrap, reinterpret storage, or depend on padding
bits. This sharply narrows the integer proof but does not machine-check the standard.

The rev0773 deep embedding now models the value rules listed below for a closed,
manually normalized AST. The still-open source-adequacy argument must establish that
the exact token/declaration stream receives those rules under C++20. Together the
argument must cover at least:

- equality and relational comparison after the applicable standard conversions;
- left-to-right short-circuit `&&` and `||`;
- `?:` selection and common unsigned-long type;
- scoped-enum identity and equality;
- aggregate membership/order and list initialization;
- `bool` values and contextual conversion;
- by-value parameter/member reads and returned prvalue construction;
- constant initialization/evaluation where the build relies on it;
- absence of undefined, unspecified-result, and implementation-defined behavior that
  can change the projection value within the admitted envelope.

Primary draft anchors:

```text
https://eel.is/c++draft/expr.eq
https://eel.is/c++draft/expr.rel
https://eel.is/c++draft/expr.log.and
https://eel.is/c++draft/expr.log.or
https://eel.is/c++draft/expr.cond
https://eel.is/c++draft/dcl.enum
https://eel.is/c++draft/dcl.init.aggr
https://eel.is/c++draft/expr.const
```

These URLs are review inputs, not theorem premises imported into Isabelle.

## Rev0773 checked value-language result

`K0_Capability_Scalar_Cpp20_Value_Semantics.thy` introduces a closed AST and
option-valued evaluator for exactly the companion's values, helpers, aggregate
construction, local binding, branches, and return. Under `v0_carrier_admitted` and
`max_ulong >= 65535`, Isabelle proves the exact raw companion projection and then
proves its observation equals `v0_scalar_project`.

The permanent C++20 audit separately asserts that each selected implementation has
an unsigned integer `unsigned long` carrier covering 65,535 and that every companion
value field has exact `unsigned long` type. Those checks are conformance evidence,
not a universal language or compiler theorem.

The full theorem scope and exclusions are in
`docs/proof/CPP20-FROZEN-VALUE-SEMANTICS.md` and DEC-0026.

## Why not a C mirror now

AutoCorres2 remains valuable for later C-like proof islands, but a manually
maintained C mirror would introduce a C/C++ correspondence exactly where this
experiment is trying to reduce correspondence. Older HOL C++ semantics work is not
an off-the-shelf Isabelle/C++20 frontend, and importing a second prover root would
violate the singular-root law.

The direct Isabelle route earned retention. AutoCorres2 remains gated for a later
C-shaped source island only when product and proof source can genuinely coincide.
BRiCk/cpp2v remains research pressure rather than a second theorem root. E0-P12 may
attempt only the exact frozen source-to-normalized-AST adequacy relation; no tool is
retained merely because it runs.

## Maintenance law

Any companion byte, renderer, program, domain, fingerprint, or C++ audit change
requires:

1. exact Isabelle acceptance through `slopos-proof check`;
2. both generated-source byte-currentness gates;
3. GCC, Clang, sanitizer, and bounded companion witnesses;
4. theorem/obligation/correspondence/trusted-base review;
5. fresh construction-basis and office-close evidence.
