# M0 AArch64 stage-2 placed-graph proof boundary

## Authoritative theories

```text
proof/generated/M0_AArch64_S2_L3_Generated.thy
proof/M0_AArch64_S2_L3.thy
proof/generated/M0_AArch64_S2_Graph_Generated.thy
proof/M0_AArch64_S2_Graph.thy
```

The generated theories are exact value imports emitted by C++20 and guarded by
`--check`.  The hand-written theories own the propositions.  Generator currentness
does not prove generator correctness or ISO C++20 semantics.

## Checked value rungs

The level-3 theory establishes the selected descriptor constants, exact table/image
sizes, zero tails, decoded page sequences, present-entry counts, cross-domain
physical intersection, and equality between decoded selected leaves and the exact
34-record M0 plan.

The placed-graph theory then establishes:

- six exact, pairwise distinct, aligned placement values;
- two exact root/control records with distinct domain and VMID fields;
- four exact upper-level edges;
- descendant edges confined to the placement partition owned by each root;
- six 512-entry table values and 24,576 serialized bytes;
- 38 nonzero descriptors;
- exact alpha and beta pure-walk page sequences;
- selected unmapped boundary faults; and
- equality between the graph-recovered plan and `m0_static2_plan`.

## Assumptions and exclusions

The model is an exact finite HOL value model.  It assumes the selected constants and
list values imported by the generated theories.  It does not import formal Arm
operational semantics and does not prove:

```text
C++ source evaluation
compiler or ABI preservation
binary identity
physical placement or memory ownership
VTTBR_EL2 / VTCR_EL2 / HCR_EL2 effect
barriers, cache coherency, or TLB maintenance
hardware translation walks or faults
boot or guest execution
DMA / SMMU / device confinement
CPU-memory isolation
```

Accordingly `OBL-M0-STATIC2-ENCODING-001` remains open debt.  The new theorem rows
close narrower exact-value obligations only.

## Counterexample retained as proof pressure

The C++20 walker initially accepted an alpha upper edge targeting beta's valid table.
The value was descriptor-shaped and globally resolvable, but violated root ownership.
The active implementation now requires the exact expected child placement at each
step, and the Isabelle theory records the corresponding owned-chain proposition.
This is evidence that implementation is teaching the model rather than merely
instantiating prose.
