# Proof-owned program to generated C++20 source

## Purpose

This document records the generated-source edge added in rev0769, the exact-fragment certificate added in rev0770, direct structural execution added in rev0771, the self-contained companion added in rev0772, and the closed normalized value-language rung added in rev0773. It is the operational companion to DEC-0021 through DEC-0026.

## Artifact chain

```text
HOL datatype v0_scalar_source_atom
        |
        v
HOL value v0_capability_scalar_source_program
        |
        | checked evaluator theorem
        v
v0_scalar_source_eval program cell = v0_scalar_project cell
        |
        | closed Isabelle/ML renderer (named trusted translation)
        v
Isabelle generated-file export
        |
        | exact C++20 proof-runner byte comparison
        v
generated/include/.../capability_scalar_kernel.hpp
        |
        | include into active C++20 build
        v
caprep::scalar::project
        |
        | OPEN: parsed-source/evaluation/compiler relation
        v
compiled executable behavior
```

## Checked theorem layer

`proof/K0_Capability_Scalar_Source.thy` defines the source-program atoms, the exact
ordered program, and a total evaluator. Six mapped lemmas establish:

- the payload atom list is exactly scalar payload admission;
- source-program evaluation exactly equals `v0_scalar_project`;
- dead input produces canonical absence;
- rejection is exactly live plus inadmissible payload;
- admitted live input produces the exact present image;
- dead payload is inert.

The renderer does not define these facts. They are ordinary HOL propositions checked
by the pinned Isabelle session.

## Renderer boundary

The Isabelle/ML renderer is deliberately closed:

- no file reads;
- no general parser or macro language;
- no arbitrary user text splice;
- no loops or recursion derived from unbounded source data;
- one fixed mapping from seven closed atoms to fixed C++ expressions;
- one fixed header skeleton;
- one generated-file export name.

The renderer uses kernel-checked simplifier normalization to inspect the exact closed
HOL program value. It does not invoke a heavyweight dynamic code evaluator. This
keeps the cloudtainer resource footprint close to the existing proof session.

The renderer remains in the trusted base because Isabelle proves the program's
value semantics, not the semantic adequacy of each emitted C++ token.

## Byte-currentness gate

The C++20 proof runner performs these steps after the theorem session succeeds:

1. clears an isolated `.slopos-work/isabelle/run/source-export` directory;
2. invokes `isabelle export` for the exact session/theory/export name;
3. requires the exact exported path to exist;
4. requires the active generated header to exist;
5. records byte counts and independent FNV fingerprints;
6. compares the complete byte strings;
7. accepts the session only when they are identical.

The recorded state is one of:

```text
SOURCE_NOT_CHECKED
SOURCE_EXPORT_FAILED
EXPORTED_SOURCE_MISSING
ACTIVE_SOURCE_MISSING
SOURCE_BYTE_MISMATCH
SOURCE_BYTES_CURRENT
```

Only `SOURCE_BYTES_CURRENT` can accompany `SESSION_ACCEPTED`.

## Evidence classification

| Claim | Evidence class | Why |
|---|---|---|
| source-program evaluator equals `v0_scalar_project` | THEOREM | checked HOL propositions |
| active generated header equals Isabelle export | CONFORMANCE | exact artifact identity check |
| selected C++ inputs agree with independent oracle | BOUNDED | finite counterexample pressure |
| active header parses to the admitted finite certificate | THEOREM + CONFORMANCE | exact generated certificate relation plus binder currentness |
| binder parsing is universally correct for the admitted fragment | OPEN_DEBT | parser proof absent |
| admitted finite certificate has the mathematical scalar result | THEOREM | direct HOL structural evaluator |
| independent C++20 certificate interpreter agrees with compiled projection | BOUNDED | 593,907-cell witness; not language semantics |
| generated header has ISO C++20 source-program semantics | OPEN_DEBT | preprocessing and ISO C++20 adequacy absent |
| compiler preserves admitted source behavior | OPEN_DEBT | compiler/binary envelope absent |
| booted machine enforces isolation | NOT_STARTED | no M0 construction/refinement |

## Why byte identity matters but is insufficient

Without byte identity, a theorem can refer to one program while the compiler sees
another. With byte identity, that drift is removed. But byte identity alone says
nothing about the meaning a C++20 implementation assigns to the bytes. The next
bridge must bind exact syntax and semantics rather than repeat another digest.

## Rev0770 exact-fragment extension

The permanent C++20 binder now consumes the entire active header, records every
semantic constant/operator/order/branch/tag/field decision in a finite certificate,
and emits byte-current Isabelle and manifest artifacts. Isabelle checks the parsed
certificate is exactly canonical, admitted, denotes the seven-atom program, and has
the exact scalar projection result.

The result is finite translation validation. It does not establish binder parser
correctness or ISO C++20 meaning.

## Next bounded experiment

E0-P11 checked the frozen companion's normalized value semantics under explicit carrier and unsigned-long-envelope premises. E0-P12 now targets only exact source-to-token/declaration/binding/AST adequacy. Keep ISO-wide, compiler, ABI, binary, platform, and active-kernel correspondence edges explicit and open.

## Rev0772 self-contained companion route

The proof root now exports two exact source artifacts from one canonical program:

```text
active kernel header     fixed-width project-facing spelling, 2320 bytes
proof companion          built-in-only self-contained spelling, 2570 bytes
```

The active header continues through the whole-input binder/certificate route. The
companion bypasses includes, project macros, fixed-width aliases, and project
namespace declarations, then receives an exact byte gate and bounded compiled
agreement with the active projection. This reduces preprocessing/declaration
surface without claiming a parser or language theorem.

See DEC-0025 and `CPP20-SELF-CONTAINED-COMPANION.md`. The next proof question is the
small exact C++20 value-semantics edge for the frozen companion, not another source
spelling or evaluator.


## Rev0773 normalized value-language relation

`proof/K0_Capability_Scalar_Cpp20_Value_Semantics.thy` models exactly the frozen
companion's value-bearing constructs and proves its raw aggregate and observed scalar
result under the admitted carrier and explicit `max_ulong >= 65535` envelope. The
permanent C++20 harness separately reports selected-implementation type/range facts.

The source export/currentness state remains necessary but insufficient. E0-P12 must
bind the exact proof-owned bytes through concrete syntax and name binding to the
existing normalized AST, or record a measured rejection. No theorem in rev0773
interprets the source bytes merely because they were generated by Isabelle.
