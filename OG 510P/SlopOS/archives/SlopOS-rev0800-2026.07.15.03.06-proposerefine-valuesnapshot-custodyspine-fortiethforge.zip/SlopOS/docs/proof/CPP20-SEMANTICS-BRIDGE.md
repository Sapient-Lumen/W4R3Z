# C++20 implementation-semantics bridge

## The unskippable problem

A theorem about A0, D0, KIR, scalar proof values, CAP-REP, or the generated
bootstrap image is not yet a theorem about a compiled C++20 executable.
Source-language parsing and evaluation, object/value representation, array indexing
and lifetime, unsigned arithmetic, optimizer transformations, compiler correctness,
ABI, libraries, linker, loader, operating system, and hardware remain between them.
Testing finds contradictions in that chain; it does not silently supply the chain.

## Rev0769 generated-source bridge

```text
closed scalar HOL program
  -- checked HOL evaluator --> v0_scalar_project
  -- trusted closed Isabelle/ML renderer --> generated C++20 header export
  -- C++20 proof-runner byte gate --> active compiled source bytes
  -- OPEN exact-fragment parser/value semantics --> ISO C++20 source evaluation
  -- OPEN compiler/ABI/binary semantics --> executable behavior
  -- OPEN M0 refinement/assumptions --> privileged platform effect
```

The checked formal spine and exact source identity are real. The renderer,
C++ evaluator, compiler, and platform arrows remain real debts. No row inherits the
status of the row above it.

## Why this source route was selected

A general C++20 frontend is larger than the first scalar decision. A hand-maintained
C mirror creates a C-to-C++ relation. A source hash identifies bytes but does not
interpret them. The selected route therefore separates three questions:

1. **What is the authority decision?** A checked seven-atom program.
2. **Which source bytes are active?** The exact accepted Isabelle export.
3. **What do those bytes mean under C++20 and compilation?** Still open.

That is smaller and more honest than claiming “proof by generation.”

## Current scalar artifact chain

```text
CellValue / ProjectionValue fixed-width carriers
       |
       v
v0_capability_scalar_source_program
       |
       | six source-program lemmas
       v
v0_scalar_source_eval = v0_scalar_project
       |
       | closed renderer (trusted translation)
       v
generated capability_scalar_kernel.hpp
       |
       | accepted-export/active-byte identity
       v
compiled caprep::scalar::project source artifact
       |
       | OPEN syntax and ISO C++ value semantics
       v
source evaluation
```

The wrapper into `LogicalCapability` remains a later CAP-REP source relation.

## Evidence now present

| Edge | Current evidence | Claim class |
|---|---|---|
| KIR grammar and generation | malformed tests, source/program fingerprints, byte-current triple output | TEST + CONFORMANCE |
| exact guard precedence | compile-time positions, eleven concrete first failures, active trace | STATIC + TEST |
| generated facts versus independent C++ encoding | 6,963,200 cases; `a2dea114ba75bbd5` | BOUNDED |
| generated successful commit/frame | 577,368 cases; `5a50b918f6bdfc7d` | BOUNDED |
| generated terminal DERIVE frame | 577,368 cases; `84f6af288db22ca5` | BOUNDED |
| scalar mathematical admission/image | eight exact mapped lemmas | THEOREM over proof values |
| closed scalar source-program evaluation | six exact mapped lemmas | THEOREM over finite HOL program/value semantics |
| accepted export equals active generated header | complete byte equality, counts, fingerprints | CONFORMANCE |
| active header parses to a byte-current finite certificate | whole-input C++20 binder, malformed/near-miss tests, deterministic theory and manifest | CONFORMANCE |
| parsed certificate equals admitted program certificate | seven exact mapped Isabelle lemmas across canonical and parsed certificates | THEOREM over finite certificate/value semantics |
| scalar production C++ pressure | 327,936 dead; 134,784 valid; 131,187 invalid cases with frozen fingerprints | BOUNDED |
| CAP-REP value projection and DERIVE relations | mapped Isabelle lemmas plus frozen finite witnesses | THEOREM + BOUNDED, by named layer |
| bootstrap proof-value image | mapped Isabelle lemmas plus exact independent shipped-image witness | THEOREM + BOUNDED, by named layer |
| finite sequence boundary | mapped formal lemmas plus 25 model/core terminal cases | THEOREM + TEST, by named layer |
| model/core active behavior | traces, stress, depth-4 exploration, dual compiler, sanitizer close evidence | CONFORMANCE + BOUNDED |
| renderer maps each C++ token to intended syntax | exact exported bytes, but no renderer proof | TRUSTED / OPEN_DEBT |
| exact-fragment binder correctly extracts all relevant C++ syntax | fail-closed implementation and tests, but no parser theorem | TRUSTED / OPEN_DEBT |
| normalized proof-companion value-language AST has exact scalar result | accepted Isabelle lemmas under carrier/envelope premises | THEOREM |
| exact companion source stream normalizes to that AST under C++20 | no source-adequacy theorem | OPEN_DEBT |
| compiled C++ semantics | no compiler/binary theorem | OPEN_DEBT |
| privileged platform effect | no M0 construction or refinement | NOT_STARTED |

## Generated source states

The proof runner records exactly:

```text
SOURCE_NOT_CHECKED
SOURCE_EXPORT_FAILED
EXPORTED_SOURCE_MISSING
ACTIVE_SOURCE_MISSING
SOURCE_BYTE_MISMATCH
SOURCE_BYTES_CURRENT
```

A theorem-bearing `SESSION_ACCEPTED` requires the last state. The gate is deliberately
stronger than a source hash: it exports from the exact accepted session and compares
all bytes. It is deliberately weaker than a semantic theorem: it does not assign
meaning to those bytes.

## Renderer trust boundary

The renderer is closed and finite:

- it normalizes one closed source-program definition;
- it recognizes only seven constructors;
- it emits one fixed skeleton and fixed token mapping;
- it performs no arbitrary file read or source splice;
- it cannot become a general template engine without a new decision.

The first dynamic code-evaluation attempt was operationally disproportionate in the
cloudtainer. The retained implementation uses simplifier normalization and finite
constructor reflection. This reduces execution cost; it does not prove the renderer.

## AutoCorres2 posture

AutoCorres2 remains valuable Isabelle machinery for a substantial C subset. It is
not a standing dependency here because a theorem over a hand-maintained C mirror
would leave another authoritative C-to-C++ correspondence and the dependency cost
was disproportionate for this scalar target. DEC-0020 records narrow reconsideration
gates. No C theorem is used to support the current C++ claim.

## Remaining named debts

### `OBL-CAP-SCALAR-CPP20-PARSER-001`

Relate the permanent binder's tokenization and extraction to the admitted exact
fragment. Whole-input acceptance and mutation tests are counterexample pressure, not
a universal parser theorem.

### `OBL-CAP-SCALAR-CPP20-PREPROCESS-001`

Bind the admitted source spelling to one named include and preprocessing envelope.
The exact binder sees `UINT8_C`, `UINT16_C`, `UINT16_MAX`, and named headers as
source tokens; it does not prove their macro expansion, included declarations, or
translation-phase behavior. This edge may close either through a separately checked
environment or by simplifying the proof-owned fragment until those dependencies
vanish.

### `OBL-CAP-SCALAR-CXX-001`

Relate exact evaluation of the active generated C++20 scalar function to the checked
source program and `v0_scalar_project` for every related fixed-width source value.
Byte identity and bounded witnesses do not close this.

### `OBL-CAP-REP-CXX-001`

Relate the concrete `Capability` wrapper, scalar input conversion, generated scalar
function, and logical decoder to `capability_array_rep`. This must not inherit a
future scalar theorem without checking conversion and output construction.

### `OBL-KIR-FACTS-CXX-001` and `OBL-KIR-COMMIT-CXX-001`

Relate evaluated generated DERIVE fact/commit source to the proof-value facts and
updates. Finite enumeration is pressure, not universality.

### `OBL-CXX-COMPILER-001`

Name a compiler/version/flags/ABI envelope and establish that the admitted source
behavior survives translation and linking. This is intentionally later than the
first exact source-value semantics.

### `OBL-CPP-SEM-001`

Compose representation, scalar, fact, commit, sequence, and compiler edges for the
claimed K0 scope. This umbrella cannot close from one helper theorem.

## Rev0770 exact-fragment certificate

E0-P8 succeeded at the finite certificate layer. The whole active header now parses
fail-closed into a deterministic certificate; Isabelle checks that certificate is
exactly the admitted one, denotes the seven-atom source program, and has the checked
scalar projection result. The current identities are source `ab74f6e3b4e5ca79` and
certificate `267e8cdbc882f606`.

Revision 0771 narrows the next edge. `K0_Capability_Scalar_Cpp20_Fragment`
executes the admitted finite comparisons, joins, branch polarities, tags, and typed
initializers directly and proves the parsed certificate result without calling
`v0_scalar_source_eval`. A separately represented constrained C++20 interpreter
executes the same certificate and agrees with compiled `scalar::project` over the
593,907-cell bounded witness domain.

This still does not close the C++ edge. Binder adequacy, preprocessing/includes/
macros, ISO C++20 value semantics and UB exclusion, compiler/optimizer/ABI/link/
binary preservation, and platform execution remain separately open.

## Next bounded experiment

E0-P11 retained the closed normalized value-language theorem and rejected larger cross-language routes for this target. E0-P12 admits only an exact source-token/declaration/binding/normalization relation for the frozen companion or a measured rejection. No third evaluator, platform growth, or feature work substitutes for that exact experiment.

## Rev0772 front-edge reduction

The retained companion changes the bridge topology:

```text
                       active fixed-width kernel source
                      /                              \
canonical HOL program                                  bounded compiled agreement
                      \                              /
                       self-contained proof companion
                                  |
                     exact source-language semantics OPEN
```

The companion's translation unit has no directive, include, macro, project name,
cast, allocation, pointer, reference, or library call. This removes the active
header's include/macro/declaration environment from the companion edge. It does not
remove source decoding, token formation, parsing, name binding internal to the file,
C++ expression and aggregate semantics, implementation-defined `unsigned long`
width, compiler lowering, ABI, binary, or execution.

E0-P11 may build a tiny Isabelle semantics for precisely this frozen construct set
or retain a same-bytes C/AutoCorres2 route only if its C-to-C++ relation is smaller
than the direct route. A general frontend, hand-maintained mirror, or third evaluator
remains out of scope.

## Rev0773 normalized value-semantics rung

E0-P11 produced one checked semantics result and split the former companion umbrella:

```text
exact frozen companion bytes
  -> exact source-to-normalized-AST adequacy                    OPEN_DEBT
  -> closed Isabelle companion AST evaluation                  THEOREM
  -> exact raw aggregate and scalar observation                THEOREM
  -> selected implementation unsigned-long envelope            CONFORMANCE
  -> compiler / ABI / linked binary preservation               OPEN_DEBT
```

`K0_Capability_Scalar_Cpp20_Value_Semantics` models only the companion's built-in
values, field reads, comparisons, short-circuit joins, selected conditional,
aggregate construction, one local binding, `if`, and `return`. Its main theorem is
conditional on CAP-REP's admitted carrier and an explicit `max_ulong >= 65535`
envelope. It proves neither token parsing nor general ISO C++20 semantics.

The former `OBL-CAP-SCALAR-COMPANION-SEM-001` is now a narrowly worded theorem
obligation. `OBL-CAP-SCALAR-COMPANION-ADEQUACY-001` owns the exact source-token,
name-binding, helper-body, and normalization relation. The C++20 harness separately
owns `OBL-CAP-SCALAR-COMPANION-ENVELOPE-001` through compile-time selected-lane
checks. No row inherits compiler status.

E0-P12 receives one bounded attempt at the source-to-AST relation. Whether it closes
or is measured and rejected, the scalar island then freezes so proof and construction
can return to the first physical two-domain isolation experiment.
