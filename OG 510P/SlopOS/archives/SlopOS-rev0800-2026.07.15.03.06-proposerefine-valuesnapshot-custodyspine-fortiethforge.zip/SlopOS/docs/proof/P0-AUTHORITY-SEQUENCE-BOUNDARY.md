# P0 authority sequence boundary — rev0800

`proof/P0_Authority_Sequence.thy` wraps an abstract authority-state transformer with
the finite accepted-sequence law. It states terminal rejection and exact frame,
available acceptance, exactly-one sequence advance, exact selected effect, authority
and sequence frame on exhaustion, and representability preservation after success.

## Rev0800 successor

`proof/P0_Authority_Propose_Refinement.thy` selects one concrete abstract transformer
for PROPOSE. It adds:

- explicit natural-number images of 16-bit and 64-bit command carriers;
- proposal capacity eight and resource bound four;
- ordered scope, invalid, duplicate, capacity, and terminal-sequence guards;
- exact context frame for every denial;
- exact identifier insertion, count increment, selected proposal registration, and
  sequence advance for acceptance; and
- preservation of lease, protected counter, and context validity.

The C++ witness projects both private implementations through
`AuthorityValueSnapshot` and compares one concrete PROPOSE step with an independent
expected-state transformer. A private test seam reaches terminal sequence without
adding production mutation authority.

## Deliberate remaining gap

The upper executable edge and lower HOL edge are not yet connected by a checked
vertical relation. The HOL context abstracts physical proposal ordering and older
proposal payloads; the C++ snapshot observes every proposal/lease/resource cell.
There is also no selected C++20 source semantics, object-representation theorem,
compiler relation, concurrency model, or ABI theorem.

Therefore rev0800 may claim bounded C++ value correspondence and formal source. It
may not claim C++/Isabelle implementation refinement.

## Currentness

The theory files are registered and scanned for proof-hole markers. Isabelle2025-2
is absent, so no changed theorem declaration is current evidence. A predecessor
session result cannot be inherited by a changed construction basis.

## Next proof unit

After the pinned session runs, define a minimal relation that maps:

```text
sorted occupied proposal prefix -> finite identifier set and count
snapshot sequence               -> p0_sequence_value
selected inserted proposal      -> p0_state_proposal
unchanged leases/resources      -> explicit frame premises or deliberate abstraction
```

Prove only the PROPOSE square. Do not widen to ISSUE/INVOKE/REVOKE/OBSERVE or invent
a source language unless this relation exposes a specific obstruction.
