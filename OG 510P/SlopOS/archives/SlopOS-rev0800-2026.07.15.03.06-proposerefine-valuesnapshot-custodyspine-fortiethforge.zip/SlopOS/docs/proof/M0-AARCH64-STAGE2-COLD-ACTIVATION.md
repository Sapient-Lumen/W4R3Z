# Proof boundary — M0 AArch64 stage-2 cold activation

## The theorem object

The formal object is one finite transition system over:

- a twelve-constructor step datatype;
- one exact selected request;
- one canonical state for each phase `0..12`;
- one ten-result status datatype with fixed precedence; and
- a total transition that returns the input state on every rejection.

The proof object is not assembly and is not an Arm execution model.

## Checked propositions

The activation obligation maps exact lemmas for:

- protocol codes, length, and distinctness;
- exact binding to the rev0781 installed-memory, packet, graph, and admission
  identities;
- selected IPA/start-level/PA/VMID/granule fields;
- exact selected `VTCR_EL2` and `VTTBR_EL2` arithmetic;
- canonical prefix-state well-formedness;
- selected status and selected next-prefix transition;
- wrong-step and general rejection framing;
- malformed-state precedence;
- exact selected twelve-step run and sealed final state; and
- exact finite case counts `144`, `12`, and `132`.

## Formal state relation

```text
state_wf state =
  phase(state) <= 12
  and state = canonical_prefix_state(phase(state))
```

This strong invariant is intentional.  Epoch Zero has not admitted arbitrary
recovery, partial initialization, or asynchronous architecture events.

## Correspondence boundary

The C++20 core contains richer phase booleans and fixed arrays.  The Isabelle
state makes the same selected data current at the same phase and defines all
other fields by the canonical prefix.  Generated constants bind the exact
request values.

Current evidence is:

```text
C++20 generated constants/currentness
+ independent reference/core exhaustive witness
+ Isabelle finite value theorems
```

It is not a proof of ISO C++20 evaluation, compiler preservation, binary
identity, system-register semantics, or Arm execution.

## Architecture assumption fence

The selected register integers are admitted only as finite values.  A later
obligation must state:

- the exact Arm architecture release and implemented feature envelope;
- register field legality and reserved-bit premises;
- required memory attributes and table publication premises;
- required synchronization and invalidation abstract events;
- the VMID/TLB context affected by each event;
- cold-versus-live update assumptions; and
- what observation establishes completion.

Until then, `SYNCHRONIZE_*`, `INVALIDATE_*`, and `ENABLE_STAGE2` remain
uninterpreted intent labels in this theorem layer.

## Exclusions

The theorem does not establish instruction choice, register write access,
exception level, barrier scope, TLBI operand, cache maintenance, physical
placement, coherent visibility, live root currentness, translation, faults,
boot, guest execution, CPU isolation, DMA/SMMU/device isolation, concurrency,
information flow, timing, or product completion.
