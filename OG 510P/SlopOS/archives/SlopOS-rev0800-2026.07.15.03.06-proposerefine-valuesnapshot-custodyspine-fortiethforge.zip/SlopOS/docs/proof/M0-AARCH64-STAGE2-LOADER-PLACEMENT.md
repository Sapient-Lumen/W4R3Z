# Proof boundary — M0 AArch64 stage-2 loader placement

## Checked proposition family

The Isabelle2025-2 root checks exact finite facts about:

- placement, wire, page, memory, object, and text extents;
- exact 4 KiB alignment of the selected destination;
- adjacency and arithmetic disjointness from the prior pure table-memory range;
- the exact read/execute/privileged and non-write permission-intent value;
- exact entry offset and 36-byte text extent;
- exact binding to M0-P9 object, specimen, and M0-P8 instruction identities;
- total selected status and representative fail-closed precedence;
- exact three-page initial and installed list values;
- exact text readback, zero tail, and guard frame;
- rejection atomicity and acceptance canonicality;
- selected admission; and
- preservation of M0-P9 source/object admission.

## Correspondence boundary

```text
C++20 selected placement and memory values
  -> generated Isabelle natural/list constants       currentness evidence
  -> Isabelle finite placement/install relation       checked theorem
  -X-> ISO C++20 source semantics
  -X-> address provenance or physical memory semantics
  -X-> general loader, page-table, or cache semantics
  -X-> entry state, execution, completion, or isolation
```

The root proves propositions about generated finite values. It does not prove
the generator, compiler, host arrays, operating-system mappings, or hardware.

## Permission boundary

The natural value 13 is proved equal to the selected read, execute, and
privileged intent combination and unequal to the corresponding writable value.
It is not an installed permission theorem.

## Installation boundary

The formal transition is a pure total function. Accepted input returns one exact
installed list value. Rejected input returns the exact prior value. This is not
rollback of a partially modified machine and not evidence that machine memory
changed.

## Promotion rule

`OBL-M0-S2-LOADER-PLACEMENT-001` may remain `THEOREM` only while:

- all four generated artifacts are byte-current;
- all 26 exact lemma rows map to present declarations;
- the complete zero-hole `SlopOS_K0` session is accepted;
- the session is bound to the active construction basis and proof tree;
- M0-P9 theorem evidence remains current; and
- address, mapping, cache, entry, execution, and effect debt remains explicit.
