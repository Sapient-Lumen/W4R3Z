# Proof boundary — M0 AArch64 hosted publication adapter

## Checked proposition family

The Isabelle2025-2 session checks exact finite facts about:

- contract version, wire/page extents, requirement count, and step count;
- exact value-observation mask and exact zero AArch64 discharge mask;
- equality to rev0794 readiness, caller-artifact, and installed-memory values;
- generation, owner, permission value, source-page identity, and page FNV;
- selected host RW then RX/non-W protection values and cleanup requirement;
- exact ten step kinds, ordinals, protections, flags, offsets, byte extents, and
  identities;
- selected contract acceptance and host-experiment permission;
- selected failure of the AArch64 machine-publication predicate;
- rejection of a forged nonzero machine-discharge mask;
- deterministic predecessor/protection/step rejection examples;
- rejection-state frame and selected state transition;
- preservation of rev0794's blocked and not-entry-ready theorems;
- terminal classification of the two cleanup-complete host outcomes;
- impossibility of deriving AArch64 discharge from any modeled Linux outcome;
- and nonzero generated fingerprints.

## Deliberate abstraction boundary

The logic contains no pointer, address space, VMA, file descriptor, syscall,
page fault, permission check, Linux task, kernel, libc, cache, TLB, register, or
instruction-step semantics.

The modeled Linux outcome datatype is a finite evidence classification, not an
operational semantics of `mmap`, `mprotect`, or `munmap`.

## Correspondence boundary

```text
selected C++20 finite contract
  -> generated natural/list constants          currentness evidence
  -> Isabelle finite contract relation          checked theorem

live Linux adapter run
  -> exact C++20 receipt                         bounded observation
  -X-> formal Linux/POSIX semantics
  -X-> C++/compiler/libc/kernel correctness
  -X-> AArch64 publication or permissions
  -X-> cache/TLB completion
  -X-> fetch, execution, boot, or isolation
```

The theorem that Linux outcomes never discharge AArch64 publication is a theorem
of the selected finite classification. It does not state that the real kernel
behaved correctly; it prevents the active proof vocabulary from using the
receipt as a discharge token.

## Rejection theorem

A rejected contract request returns the exact prior formal state. The live
adapter separately records cleanup attempt and result. Formal state framing does
not imply rollback of a host mapping when cleanup fails.

## Promotion rule

`OBL-M0-S2-HOST-PUBLICATION-CONTRACT-001` may be `THEOREM` only while all of the
following are current:

- generated manifest, wire, and Isabelle constants;
- exactly 34 mapped lemma rows;
- zero-hole Isabelle2025-2 acceptance;
- exact rev0794 predecessor identities;
- construction-basis and proof-tree evidence;
- the zero AArch64-discharge mask; and
- the explicit Linux/AArch64 non-correspondence boundary.

The live receipt remains `BOUNDED`. Linux semantics and AArch64 physical
publication remain open debts.
