# Claim taxonomy

## THEOREM

A named theorem checker accepted a named source under recorded versions and
assumptions.  The claim is limited to the formal objects in that theorem.

## BOUNDED

All states or command sequences within stated finite bounds were enumerated and
satisfied the property.  Increasing the bound is new evidence, not a restatement.

## CONFORMANCE

Independent implementations agreed on result and canonical observation for a named
corpus.  Shared defects and behavior outside the corpus remain possible.

## TEST

Selected examples, fuzz cases, or regressions passed.

## STATIC

A compile-time predicate, warning policy, sanitizer configuration, or source audit
passed.  This does not imply semantic correctness.

## DESIGN

An intended rule or architecture has been recorded but not established.

## DEBT

A known missing argument.  Debt must name the stronger claim it blocks and the next
concrete experiment.
