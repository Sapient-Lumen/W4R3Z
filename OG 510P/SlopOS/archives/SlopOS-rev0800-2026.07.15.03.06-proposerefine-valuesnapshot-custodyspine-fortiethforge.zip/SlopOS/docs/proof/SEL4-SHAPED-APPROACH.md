# A seL4-shaped proof approach for SlopOS

SlopOS borrows proof architecture and discipline, not assurance, code, or theorem
results. seL4's public proof material makes three facts load-bearing: functional and
security claims are layered; initialization has its own correctness burden; and
assembly, boot, hardware, DMA, compiler/binary, and side-channel assumptions remain
visible even in a mature verified kernel.

## SlopOS layers

### A0 — abstract authority specification

A0 says which authority effects are permitted. It avoids C++ layout, exact
slot-search behaviour, and serialization choices. Current A0 formalizes a small
`DERIVE` authority step only.

### D0 — deterministic design specification

D0 chooses capacities, exact first-failure precedence, observations, and update.
Rejection frames state. Formal `MAP`, `SEND`, and `RECEIVE` remain incomplete rather
than pretending the whole C++ machine is modeled.

### I0/KIR-0 — restricted implementation semantics

KIR-0 denotes the exact ordered eleven-guard `DERIVE` program and commit schema. The
same source generates C++ policy and Isabelle data. CAP-REP and SEQ-REP state the
value relations required to connect finite storage and sequence carriers to formal
maps and naturals.

Rev0766 closed a first initialization edge:

```text
fixed BootstrapPlan
  -> independent atomic C++20 value materializer
  -> generated twelve-cell proof value image
  -> Isabelle CAP-REP theorem
  -> exact formal initial capability map + sequence zero
```

The session is now accepted by Isabelle2025-2. The remaining gap is not “unchecked
proof syntax.” It is the harder universal relation from evaluated C++20 source,
through compiler/binary semantics, to those proof values.

### K0 — C++20 transition core

K0 is fixed-capacity C++20 beside a clear model, differential oracle, deterministic
traces, invariant checks, precedence tests, independent finite witnesses, and
bounded exploration. These systems search for counterexamples and preserve
conformance; they do not close an unbounded refinement edge.

### M0 — platform realization

M0 later introduces page tables, second-stage translation, traps, interrupts,
context switching, caches/TLBs, DMA/IOMMU, memory ordering, boot, and exact platform
configuration. Each mechanism enters with a state footprint, precondition,
preserved invariant, and assumption/proof plan.

## Resumable checker boundary

Rev0767 makes the external checker an explicit office state. A fresh build always
registers a fast toolchain doctor and the full session. Missing or wrong Isabelle
therefore blocks formal work and emits deterministic recovery instead of silently
removing proof tests. This is evidence-currentness machinery, not a theorem about
SlopOS or Isabelle.

## Product shape

A, B, C, and D are theorem/configuration bundles over one core. Workstation UI,
cloud lifecycle, appliance policy, and agent receipts remain outside K0 unless a
small privileged mechanism is demonstrably necessary. P0 proposal/receipt/replay
semantics never substitute for K0 mapping/isolation proof.

## Work order

1. Keep the pinned Isabelle session mandatory for theorem-bearing closes.
2. Keep exact theorem/obligation mapping and evidence currentness machine-audited.
3. Preserve the scalar mathematical theorem, source-program theorem,
   generated-byte conformance, and bounded witness as separate evidence classes.
4. Preserve the rev0771 exact admission/direct structural evaluator, the rev0772 self-contained companion, and rev0773 closed value-language semantics as narrow implementation-semantics rungs; do not promote source adequacy, ISO-wide, or compiler claims from byte identity or bounded agreement.
5. In E0-P12, close or sharply reject only the exact frozen source-to-AST edge; do not add another source spelling, general frontend, or checker.
6. Keep the binder and renderer named in the trusted base and AutoCorres2 behind
   DEC-0020 gates; do not maintain a C mirror.
7. Add no K0 operation merely to show activity.
8. Admit one platform mapping primitive only after the source/refinement route is
   sharper.
9. Introduce multicore later as its own refinement layer with a memory model.

The method is “implementation teaches proof, proof constrains implementation.” It is
neither prose-first completion nor implementation-first formalization debt.

## Rev0772 source landing zone

The companion is useful only insofar as it makes one implementation-semantics edge
small enough to attack from the Isabelle root. This follows the seL4 lesson of
narrow, explicit refinement interfaces; it does not import seL4's C parser, compiler
assumptions, theorem statements, or assurance claims into C++20 SlopOS.

## Rev0773 source-semantics refinement lesson

The seL4-shaped lesson is now executable at one tiny C++20 boundary: the proof names
a normalized source-language value model, proves its exact raw and observed result,
and refuses to infer the relation from bytes to that model or from the model to a
compiled binary.

This is not equivalent to seL4's C refinement chain. It is a scoped SlopOS rung with
explicit premises and residuals. E0-P12 may attempt the exact source-to-AST adequacy
relation once; then the project must spend the next construction budget on a
physical two-domain isolation story rather than indefinitely elaborating the scalar
bridge.
