# C++20 structural fragment evaluator

## Purpose

The scalar bridge is intentionally a chain rather than a single assertion:

```text
proof-owned seven-atom program
  -> exact generated C++20 bytes
  -> whole-input finite certificate
  -> exact certificate admission
  -> direct finite structural execution
  -> bounded comparison with compiled C++20 effect
  -> open ISO C++20 and compiler envelope
```

Revision 0771 adds the direct structural-execution link. It does not rename the open
links as solved.

## Isabelle model

`K0_Capability_Scalar_Cpp20_Fragment.thy` interprets the finite certificate
language directly. Its semantic vocabulary is deliberately closed:

- four natural-number comparisons;
- conjunction and disjunction;
- conditional negation;
- seven scalar atoms;
- a nonempty payload fold;
- absent, rejected, and present tags;
- seven typed present-field initializers;
- explicit branch polarities and parent conditional selection.

Raw execution returns `v0_scalar_projection option`: `None` denotes a malformed
finite program shape. The authority-facing evaluator first requires exact admission
and otherwise returns `V0ScalarRejected`. It does not call
`v0_scalar_source_eval`.

The checked theorem progression is:

```text
admitted presence expression        = live bit
admitted payload expression         = live-payload admission
admitted present initializers       = exact present value image
admitted raw structural execution   = Some v0_scalar_project
admitted authority evaluation       = v0_scalar_project
unadmitted authority evaluation     = rejected
parsed admitted certificate         = same direct result
```

The theorem ledger maps each proposition separately. A theorem about the finite
language acquires no statement about a parser, compiler, or processor.

## C++20 interpreter

The permanent C++20 interpreter uses fixed-size arrays, explicit enums, no dynamic
allocation in evaluation, no exceptions, and no RTTI. It is represented separately
from generated `scalar::project` and does not call that function. Its gate requires
exact equality with the canonical certificate. Its raw path exposes the critical
separation test: an assertion-only mutation may remain structurally executable but
is still unadmitted.

`slopos-cpp20-fragment` checks:

```text
source bytes                 2320
source FNV-1a                ab74f6e3b4e5ca79
certificate FNV-1a           267e8cdbc882f606
dead cases                   327936 / 3ff1f907c5d2a725
valid cases                  134784 / 93209a6a66ab8da5
invalid cases                131187 / c6c604c5beb5e375
certificate mutations        33
```

The total compiled-agreement domain is 593,907 cells. This is high-speed
counterexample pressure and regression identity, not universal semantics.

## Assumption fence

The new relation closes only:

```text
admitted finite certificate
  -> checked structural projection value
```

These remain named and open:

```text
active source bytes
  -> binder certificate              parser soundness
source spelling
  -> preprocessed translation unit   include/macro/translation-phase envelope
preprocessed C++20 fragment
  -> source-language value           ISO C++20 adequacy and UB exclusion
source-language value
  -> executable behavior             compiler/optimizer/ABI/link/binary
executable behavior
  -> machine effect                  boot/platform/hardware assumptions
```

A self-contained proof-owned companion fragment may reduce preprocessing debt, but
identical spelling does not automatically prove semantics. A smaller derivation
record/checker may reduce binder trust, but a new checker is itself an admitted
component. The next experiment must report which assumptions were removed, added,
or merely moved.

## Maintenance law

Any change to the scalar header, certificate schema, fragment evaluator, generated
parsed theory, witness domain, or expected fingerprints requires:

1. the whole-input binder currentness check;
2. the C++20 fragment unit and witness tests;
3. the exact Isabelle session through `slopos-proof check`;
4. theorem/obligation ledger review;
5. fresh construction-basis and close evidence.

## Rev0772 relation

The structural certificate evaluator remains the active-header path. Revision 0772
does not replace, generalize, or call it from the proof companion. The companion is a
separate generated spelling of the same canonical HOL program and receives only a
byte gate plus bounded compiled comparison. This avoids a third evaluator while
shrinking the source environment presented to the next language-semantics proof.
