# Proof note — hosted authority fences

The active theory `P0_Authority_Lease` is a semantic pressure model, not an
implementation certificate.

Checked-in theorem intentions:

- proposal registration is not protected effect;
- lease registration is not protected effect;
- commit is exactly abstract admission;
- denied invocation frames the whole selected state;
- revoked and over-magnitude leases cannot commit;
- successful invocation adds exactly the proposal amount;
- successful invocation consumes the proposal and one lease use;
- revocation blocks later selected-lease use;
- observation frames state.

Open correspondence obligations:

- represent finite arrays/maps and missing entries;
- align duplicate/capacity and denial-precedence behavior;
- account for uint16/uint32/uint64 ranges and overflow;
- model four resources and multiple proposals/leases;
- show canonical serialization is observational only;
- state clock trust and concurrency assumptions;
- prove or generate a checked refinement relation for `AuthorityCore`.

Until those close, C++ differential exploration is `CURRENT` test evidence and the
implementation-refinement claim remains `OPEN`.
