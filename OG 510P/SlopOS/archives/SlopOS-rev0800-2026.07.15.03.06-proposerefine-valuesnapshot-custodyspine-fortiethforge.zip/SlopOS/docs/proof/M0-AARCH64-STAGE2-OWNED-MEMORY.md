# M0 AArch64 stage-2 owned-memory proof boundary

## Authoritative theories

```text
proof/generated/M0_AArch64_S2_Owned_Memory_Generated.thy
proof/M0_AArch64_S2_Owned_Memory.thy
```

The generated theory imports exact selected identities and fingerprints.  The
handwritten theory owns the state records, request record, precondition,
transition, and propositions.  A generated constant is an explicit theorem
input; its existence does not prove the C++20 generator.

## Formal state

The formal page type is a tuple:

```text
(identity, owner, installable, descriptor-value payload)
```

The formal memory record contains generation, installation state, selected
identity fields, sequence, and eight pages.  Payloads are lists of the 512
selected descriptor values per table rather than a formalization of the C++
little-endian byte encoder.  This keeps the theorem honest about its layer.

The formal request binds the selected generation, packet identity, graph
identity, sealed-admission identity, copy order, and six graph payloads.

## Total transition

```text
install request memory =
  if exact_precondition request memory
  then (canonical_installed_memory, True)
  else (memory, False)
```

This is intentionally small.  It makes atomicity and rejection framing
structural rather than attempting to derive them from an unformalized C++
exception or allocation model.

## Mapped propositions

`OBL-M0-S2-OWNED-MEMORY-VALUE-001` maps exact lemmas for:

- version, page, and byte extents;
- exact distinct identities;
- exact owner and installable fields;
- guards outside all selected destinations;
- six 512-word payloads / 24,576-byte selected extent;
- zero initial installable payloads;
- exact selected request;
- selected precondition and accepted transition;
- exact installed metadata;
- exact installed graph-value readback;
- guard frame preservation;
- general rejection atomicity;
- canonicality of every accepted result; and
- preservation of packet/graph/static-plan correspondence.

## Correspondence boundary

The C++20 reference and core use 4,096-byte arrays and copy the exact graph
wire.  The Isabelle model uses 512 natural-number descriptor values per page.
The current bridge is:

```text
selected generated descriptor values
  + exact C++ little-endian graph artifact
  + generated-currentness
  + bounded reference/core readback agreement
```

It is not a proof of ISO C++20 source semantics, serialization correctness for
all inputs, compiler preservation, or platform execution.  Those edges remain
listed rather than inferred.

## Assumptions and exclusions

The theorem root assumes its imported generated constants.  It does not import
formal Arm operational semantics.  It establishes no real address validity,
object lifetime, alias model, physical ownership, concurrent visibility,
register state, barrier/TLB protocol, hardware walk, boot, guest, device,
DMA/SMMU, multicore, timing, side-channel, or product theorem.

The exact proposition “rejection returns the same formal memory value” must
not be widened to “arbitrary C++ execution cannot partially write memory.”
That latter claim needs a source/compiler/platform semantics edge.
