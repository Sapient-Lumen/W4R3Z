# M0 AArch64 stage-2 placement-packet proof boundary

## Authoritative theory edge

```text
proof/generated/M0_AArch64_S2_Placement_Packet_Generated.thy
proof/M0_AArch64_S2_Placement_Packet.thy
```

The generated theory imports exact natural-number and finite-list values
emitted by the C++20 packet generator.  The handwritten theory owns the
propositions.  Generated currentness, C++ compilation, and test success do not
prove the generator or ISO C++20 semantics.

## Exact propositions

The theory checks only the selected packet value:

- packet version 1, 512 wire bytes, and a 24,576-byte graph extent;
- equality of packet graph identity and rev0779 graph identity;
- nonzero selected plan and packet fingerprints;
- six exact 4 KiB source extents covering the graph image;
- six exact, distinct, 4 KiB-aligned destination values;
- equality between packet destinations and graph placements;
- exact table ownership, levels, and nonzero table fingerprints;
- exact root domains, VMIDs, table ordinals, destinations, and ownership
  intervals;
- root destinations are members of the selected table destinations;
- exact `IMAGE, TABLE0..5, ROOT0..1, SEAL` admission values;
- exact distinct sequences zero through nine; and
- preservation of the already checked graph-to-`m0_static2_plan`
  correspondence.

The theorem ledger maps each theorem name to
`OBL-M0-S2-PACKET-VALUE-001`.  A row is current only when the exact
construction basis and exact Isabelle2025-2 session packet are accepted.

## Assumptions

The generated constants are trusted only as explicit theorem inputs.  The
theory does not claim they were computed correctly by C++, serialized
correctly by a compiler, loaded into memory, or selected by hardware.

The graph-to-plan proposition depends on the rev0779 graph and static-plan
theories.  It does not widen their assumptions or exclusions.

## Explicit exclusions

```text
ISO C++20 source semantics
compiler / ABI / binary preservation
cryptographic authentication
physical ownership or copying
host-pointer or physical-address interpretation
VTTBR_EL2 / VTCR_EL2 / HCR_EL2 effect
barriers, caches, or TLB maintenance
Arm hardware walks or faults
exception handling
boot or guest execution
DMA / SMMU / device confinement
multicore behavior
CPU-memory isolation
A / B / C / D product completion
```

## Why this rung exists

A seL4-shaped refinement ladder must expose rather than skip the relation
between abstract configuration, representation, admitted installation input,
physical effect, and live machine state.  This packet closes only the admitted
value relation.  It creates a stable object for the next pure-memory
experiment without laundering intent or evidence into effect.
