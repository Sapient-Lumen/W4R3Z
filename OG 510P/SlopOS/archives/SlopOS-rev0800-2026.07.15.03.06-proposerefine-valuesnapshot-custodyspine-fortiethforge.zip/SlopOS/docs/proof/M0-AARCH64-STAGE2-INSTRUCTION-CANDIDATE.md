# Proof boundary — M0 AArch64 stage-2 instruction candidate

## Checked proposition family

The Isabelle2025-2 session checks exact finite facts about:

- candidate version and extents;
- nonzero source and vocabulary identities;
- exact equality to the selected M0-P7 adequacy identity;
- exact equality to the corrected M0-P6 activation identity;
- three register-entry numbers, targets, and values;
- equality of those values to selected VTCR_EL2, VTTBR_EL2, and HCR_EL2
  natural values;
- exact ten-event order and distinctness;
- one prior-value endpoint and nine instruction mechanisms;
- exact instruction ordinals and exact nine 32-bit natural values;
- equality between realization encodings and the instruction-word list;
- total selected status and selected precedence examples;
- rejection framing;
- selected admission and selected state transition;
- preservation of the exact M0-P7 adequacy admission; and
- nonzero semantic and wire fingerprints.

## Assumption boundary

The theory imports no formal Arm instruction semantics. Numeric word equality
does not establish instruction decoding, legality, privilege, effect, exception
freedom, completion, or observation.

The source-issue and vocabulary fingerprints are generated natural values. They
identify the selected engineering basis; they do not make prose or web pages
axioms of Isabelle/HOL.

## Correspondence boundary

```text
selected C++20 candidate
  -> generated natural constants              currentness evidence
  -> Isabelle finite value relation            checked theorem
  -X-> ISO C++20 source semantics
  -X-> source spelling / assembler semantics
  -X-> ELF/object or loader semantics
  -X-> live register-entry state
  -X-> Arm instruction execution
  -X-> barrier/TLBI/register completion
  -X-> hardware translation or isolation
```

Reference/core agreement, exhaustive single-bit mutation testing, two compilers,
sanitizers, and no-allocation observation remain bounded executable evidence.

## Rejection theorem

The formal transition is total. If the finite status is not accepted, the exact
prior instruction-admission state is returned. This theorem says nothing about
a malformed physical instruction stream, an exception, or machine rollback.

## Promotion rule

`OBL-M0-S2-INSTRUCTION-REALIZATION-001` may be `THEOREM` only while all of these
are current:

- generated manifest, binary, and Isabelle constants;
- exact 30 mapped lemma rows;
- zero-hole Isabelle2025-2 session;
- exact construction-basis identity;
- accepted M0-P6 and M0-P7 predecessor theorem rows; and
- the explicit source/object/execution/effect non-claim.

The architecture-effect obligation remains open.
