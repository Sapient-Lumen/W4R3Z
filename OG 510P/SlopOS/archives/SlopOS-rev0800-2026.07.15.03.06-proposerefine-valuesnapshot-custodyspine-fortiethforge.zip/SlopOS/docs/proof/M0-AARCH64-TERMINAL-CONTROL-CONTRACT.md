# Proof boundary — M0 AArch64 terminal-control contract

## Checked proposition family

The Isabelle2025-2 root checks exact finite facts about:

- certificate extent and source identity;
- equality to the accepted M0-P11 visibility identity;
- equality to inherited loader/object/specimen/instruction identities;
- complete decision basis;
- twelve required and zero discharged live predicates;
- six distinct alternatives and exactly one selected outcome;
- selected role `CALLABLE_RETURN_X30`;
- selected register 30 and selected natural word `0xD65F03C0`;
- unchanged current code base/end and four-byte projected growth;
- exact ten-row preserve/change/open cascade;
- total fail-closed status and selected precedence cases;
- rejection framing;
- selected transition;
- preservation of M0-P11 assessment admission; and
- preservation of M0-P11 blocked-terminal readiness.

## Assumption boundary

The theorem root does not know the operational meaning of RET, BR, B, BL, BLR,
or ERET. It does not import AAPCS64, Arm pseudocode, ELF execution, or live
register semantics.

The source-envelope fingerprint is a generated natural value. It binds the
engineering basis but does not make an online document an Isabelle axiom.

## Correspondence boundary

```text
C++20 terminal-contract value
  -> generated Isabelle constants            currentness
  -> Isabelle finite selection relation       checked theorem
  -X-> active source/object repair
  -X-> live X30 or call edge
  -X-> Arm return execution
  -X-> completed control transfer
```

Mutation, swap, two-builder, sanitizer, and no-allocation evidence remain
bounded executable pressure.

## Current artifact theorem

The selected semantic contract and the current M0-P11 block coexist:

```text
contract selected
AND
binary repair required
AND
current visibility remains BLOCKED_TERMINAL_CONTROL_FLOW
```

Selection does not launder projected bytes into the current object.

## Promotion rule

`OBL-M0-S2-TERMINAL-CONTRACT-001` may be `THEOREM` only while:

- the generated contract manifest, wire, and theory are current;
- every mapped terminal lemma exists;
- Isabelle2025-2 accepts the complete zero-hole session;
- the construction basis binds the exact predecessor artifacts; and
- `OBL-M0-S2-TERMINAL-REPAIR-001` and live-entry readiness remain open.
