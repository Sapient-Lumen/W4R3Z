# C++20 exact-fragment binding

## Purpose

This document describes the first direct bridge from active generated C++20 source
text back into the Isabelle theorem root. It is intentionally much smaller than a
C++20 semantics and much stronger than a digest-only currentness check.

## Artifacts

```text
generated/include/slopos/k0/generated/capability_scalar_kernel.hpp
    active proof-generated C++20 source

include/slopos/k0/cpp20_scalar_binding.hpp
src/proof/cpp20_scalar_binding.cpp
    permanent C++20 whole-input binder

tools/slopos_cpp20_bind_main.cpp
    --check / --emit office entry point

generated/k0/capability-scalar-cpp20-binding.txt
    deterministic human/machine manifest

proof/generated/K0_Capability_Scalar_Cpp20_Parsed.thy
    deterministic finite parsed certificate

proof/K0_Capability_Scalar_Cpp20_Certificate.thy
    admitted certificate language and evaluator

proof/K0_Capability_Scalar_Cpp20_Relation.thy
    exact parsed-certificate relation lemmas
```

## Exact admitted fragment

The binder accepts one closed file shape. The semantic subset contains:

- namespace declarations and the exact named scalar types;
- six unsigned integer constants;
- three helper predicates;
- equality, inequality, unsigned less-than, conjunction, disjunction, and negation;
- the live-presence branch followed by the payload-admission branch;
- three exact projection tags;
- one fixed-order aggregate result;
- one conditional parent-present scalar and one same-carrier cast;
- three exact `static_assert` declarations;
- the two exact generated/namespace line comments; arbitrary comments and any
  backslash-bearing line comment are rejected;
- whitespace that does not change tokens;
- end-of-file immediately after the admitted closing braces.

Loops, pointers, arrays, allocation, recursion, exceptions, RTTI, virtual dispatch,
atomics, volatile access, semantic macros, templates beyond the named fixed-width
carriers, object-representation operations, and trailing declarations are rejected.

## Certificate shape

The finite certificate records rather than assumes:

- all generated constants;
- each comparison operator;
- each Boolean join operator;
- payload atom order;
- zero-comparison operators and literals;
- presence and payload branch negation;
- absent, rejected, and present tags;
- aggregate field order;
- parent-present comparison and conditional direction;
- static-assert values.

A parseable near miss can therefore produce a **different** certificate. Isabelle
rejects that certificate unless it is exactly the admitted one. Unknown or broader
syntax is rejected before certificate generation.

## Current identities

```text
source bytes:              2320
source FNV-1a identity:    ab74f6e3b4e5ca79
certificate FNV-1a identity: 267e8cdbc882f606
binder token count:        371
```

The identities detect drift. The theorem comes from the finite certificate equality
and evaluator relation, not from the hashes.

## Fail-closed order

The proof runner performs these gates in order:

```text
pinned Isabelle version
proof-hole scan
C++20 binder parse
binder theory/manifest byte currentness
isolated exact Isabelle session build
named generated-source export
exported/compiled header byte equality
```

Failure at any stage yields `SESSION_REJECTED`; no later stage is allowed to promote
a theorem claim.

## Independence and remaining trust

The binder is independent of the Isabelle/ML renderer in implementation language,
representation, and control flow. It is not formally verified. Its parser and
certificate emitter are part of the current trusted translation-validation base,
with mutation and malformed-input tests as counterexample pressure.

The checked result is:

```text
binder-emitted finite certificate
  = admitted finite certificate
  -> checked source program
  -> v0_scalar_project
```

The unchecked result is still:

```text
ISO C++20 evaluation of the active function
  = finite certificate evaluation
```

The include/preprocessor environment is also beyond that. The active file names
`<cstdint>`, `<limits>`, `capability_scalar_types.hpp`, `UINT8_C`, `UINT16_C`, and
`UINT16_MAX`; the binder records their spelling but does not prove macro expansion,
header identity, fixed-width carrier availability, or translation-phase behavior.
Those facts remain `OBL-CAP-SCALAR-CPP20-PREPROCESS-001` before the evaluator and
compiler edges.

The compiler/ABI/binary edge remains beyond that.

## Commands

```text
cmake --preset debug
cmake --build --preset debug -j 2
build/debug/slopos-cpp20-bind --check --root .
build/debug/slopos-proof check --root . --evidence evidence/rev####
```

`slopos-generate` regenerates the certificate artifacts after the proof-owned source
header has intentionally changed. Regeneration is not acceptance; the exact Isabelle
session must still check the resulting finite certificate.

## Rev0772 binder disposition

The active kernel header still requires this binder. E0-P10 does not promote its
parser debt. A separate derivation checker was rejected because no bounded design
validated binder decisions independently without rebuilding comparable frontend
logic. The proof companion provides a narrower alternate landing zone; it does not
make the active binder obsolete or proved.
