# Proof boundary — M0 AArch64 caller-artifact cascade

## Checked proposition family

The Isabelle2025-2 session checks exact finite facts about:

- the 512-byte certificate and source/object/text/page extents;
- the exact closed ELF section, symbol, relocation, and text envelope;
- source, assembler, object, caller-edge, repair, helper, loader, visibility,
  placement, and memory identities;
- exact page, helper, caller, owner, permission, and word values;
- exact generation `2 -> 3`;
- closed eighteen-value and seven-live requirement lists;
- complete value masks, empty live discharge, artifact presence, and blocked
  readiness;
- exact prior and installed 4 KiB page values;
- helper-prefix, gap, suffix, caller-readback, and guard-page framing;
- representative total-status precedence and mixed-generation rejection;
- rejected admission and install framing;
- selected admission and atomic pure-memory install; and
- preservation of rev0792 caller-edge admission.

## Assumption and semantics boundary

The source and object are generated constants. Isabelle checks propositions
about those constants. It does not prove source parsing, assembler correctness,
ELF loader semantics, C++20 execution, or a compiler-to-binary relation.

```text
current caller bytes in a pure list
!= bytes published in machine memory
```

```text
selected RX non-write permission value
!= effective executable mapping
```

```text
BL bytes at a numeric address
!= fetched or executed BL
```

```text
numeric continuation = call site + 4
!= observed live X30
```

```text
current RET X30 helper bytes
!= permitted, executed, or completed return
```

## Correspondence boundary

```text
exact source/object/current pure-memory values
  -> independent C++20 reference/core agreement   bounded executable evidence
  -> generated Isabelle constants                 currentness evidence
  -> Isabelle finite admission/install relation   checked theorem
  -X-> ISO C++20 or assembler semantics
  -X-> loader/mapping/cache semantics
  -X-> Arm call/return execution
  -X-> boot or isolation
```

Mutation tests, exact assembler replay, two compilers, sanitizers, and
no-allocation observation remain bounded counterexample pressure.

## Atomicity boundary

The formal install relation accepts only the exact selected request and exact
selected preimage. Every failed precondition returns `(memory, False)`. This is
atomicity of one pure immutable value relation; it is not a theorem about
machine writes, caches, torn physical updates, concurrency, or crash recovery.

## Promotion rule

`OBL-M0-S2-CALLER-ARTIFACT-001` may be `THEOREM` only while:

- source, object, generated manifest, wire, memory image, and theory constants
  are current;
- every mapped lemma exists in the active theory;
- the proof root contains zero proof-hole markers;
- the exact Isabelle2025-2 session is accepted against the active construction
  basis; and
- publication, permission, cache, execution, X30, return, boot, and isolation
  non-claims remain explicit.

`OBL-M0-S2-CALLER-EDGE-LIVE-001`, `OBL-M0-S2-LOADER-EFFECT-001`, and
`OBL-M0-S2-VISIBILITY-READY-001` remain open.
