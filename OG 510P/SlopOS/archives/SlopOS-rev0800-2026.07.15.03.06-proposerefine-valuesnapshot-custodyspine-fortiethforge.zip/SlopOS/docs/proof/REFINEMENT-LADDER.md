# Refinement ladder and evidence map

The status column is claim-specific. A checked mathematical proposition does not
inherit a C++ source, compiler, platform, or product claim.

| Edge or artifact | Required evidence | Current rev0773 status |
|---|---|---|
| A0 authority/admission relation | formal definitions and invariants | source present; exact listed lemmas `THEOREM` |
| D0 exact `DERIVE` transition | executable formal function with eleven-result precedence | source present; exact denial/simulation lemmas `THEOREM` |
| finite sequence schema | accepted lemmas for representable advance/terminal split | `THEOREM` for mapped proposition |
| D0 success is A0-admitted | accepted Isabelle theorem | `THEOREM` |
| D0 rejection preserves formal state | accepted Isabelle theorem | `THEOREM` |
| bootstrap plan transcription | C++20 emitter, fingerprint, generated theory, currency check | CONFORMANCE |
| bootstrap proof-value image represents initial capability map/sequence zero | independent image, generated values, CAP-REP, accepted lemmas | `THEOREM` for proof values + BOUNDED shipped-image witness |
| evaluated C++ bootstrap realizes the proof-value theorem | admitted source semantics plus compiler envelope | OPEN_DEBT |
| KIR source validity | closed C++20 parser and malformed-input tests | TEST + STATIC |
| KIR source to C++/Isabelle artifacts | deterministic generation, binding fingerprints, byte-current check | CONFORMANCE; generator trusted |
| generated KIR outcome equals D0 | accepted Isabelle theorem | `THEOREM` |
| KIR→D0→A0 success | accepted Isabelle theorem | `THEOREM` |
| exact C++ DERIVE guard precedence | eleven first-failure exits plus success | TEST + STATIC |
| generated fact extractor versus independent encoding | exact finite domain and fingerprint | BOUNDED: 6,963,200 / `a2dea114ba75bbd5` |
| generated successful commit/frame versus independent encoding | whole-array/result equality over exact finite domain | BOUNDED: 577,368 / `5a50b918f6bdfc7d` |
| generated terminal DERIVE frame | whole-array/result equality over same finite domain | BOUNDED: 577,368 / `84f6af288db22ca5` |
| scalar dead projection | independent literal oracle | BOUNDED: 327,936 / `3ff1f907c5d2a725` |
| scalar valid present image | independent literal oracle | BOUNDED: 134,784 / `93209a6a66ab8da5` |
| scalar malformed rejection | independent literal oracle | BOUNDED: 131,187 / `c6c604c5beb5e375` |
| scalar mathematical function matches CAP-REP admission/image | accepted Isabelle lemmas | `THEOREM` over mathematical fixed-width values |
| closed seven-atom source-program evaluator equals scalar function | accepted Isabelle lemmas | `THEOREM` over finite HOL program/value semantics |
| active generated scalar header equals accepted session export | named export plus complete byte comparison | CONFORMANCE; `SOURCE_BYTES_CURRENT` required |
| renderer maps source atoms to admitted exact-fragment C++20 syntax | proof-owned export plus exact whole-input certificate relation | CONFORMANCE for the named 2,320-byte fragment; renderer and general language adequacy remain OPEN_DEBT |
| admitted finite certificate structural evaluation equals mathematical scalar function | direct checked finite evaluator | `THEOREM`; rev0771 closed this exact HOL edge |
| independent C++20 certificate interpreter agrees with compiled scalar projection | bounded differential execution | `BOUNDED`: 593,907 cells, 33 admission mutations, fixed fingerprints |
| normalized proof-companion value-language execution equals mathematical scalar function | accepted closed-AST semantics plus carrier/envelope premises | `THEOREM`; exact source-to-AST adequacy remains open |
| selected implementation companion carrier covers all admitted values | compile-time type/range checks in every selected lane | CONFORMANCE; not a universal ABI/compiler theorem |
| exact frozen companion source normalizes to admitted AST | independent exact source-token/declaration/name-binding adequacy relation | OPEN_DEBT |
| exact active C++ scalar evaluation equals mathematical scalar function | active parser/preprocessing + companion adequacy + active/companion relation + compiler envelope | OPEN_DEBT |
| CAP-REP dead/live/invalid value projection | independent proof-facing C++ value encoding | BOUNDED: 3,935,232 / 1,617,408 / 1,574,244 with frozen fingerprints |
| CAP-REP projected fact equality | generated fact record equals projection-only fact path | BOUNDED: 2,076,672 / `534eb0b6fcb69a79` |
| CAP-REP projected success/terminal frame | exact child image and frame observations | BOUNDED: 53,064 each / `1412bbdae35d1775`, `d7cee8290747b55d` |
| CAP-REP proof values represent formal map | accepted presence/live/dead/update lemmas | `THEOREM` for proof values; C++ wrapper/source edge open |
| proof-value DERIVE facts equal formal facts | accepted CAP-REP fact theorem | `THEOREM`; generated C++ evaluation open |
| proof-value capability update equals formal effect | accepted update/frame/sequence/rejection lemmas | `THEOREM`; source/store/compiler edge open |
| bootstrap malformed classes and exact model/core image | independent C++20 materializer and private full-state seam | BOUNDED: 15 malformed, 4 live, 8 dead / `9b6b382bb77b2156` |
| four-operation terminal boundary/precedence | private-seam model/core cases | TEST: 25 / `1b29e9f3f779ae41` |
| model/core active behavior | independent transition surfaces, traces, stress | CONFORMANCE when close evidence records it |
| finite state prefix | exact alphabet/depth/state-limit exploration | BOUNDED when close evidence records it |
| finite sequence corresponds through claimed implementation | full state relation plus source/compiled edge | OPEN_DEBT |
| compiled executable preserves admitted source | compiler/ABI/binary argument or proof | OPEN_DEBT |
| platform realizes mapping/isolation | machine-interface refinement plus assumptions | NOT_STARTED |
| workstation/cloud/appliance/agent properties | shared-core theorem plus profile configuration/platform/service bundles | NOT_STARTED; no profile claim |

## Evidence non-inheritance

- Generated equality removes a hand-copy edge; it is not renderer, language, or
  compiler correctness.
- Isabelle acceptance applies only to the exact proposition and premises in
  `proof/theorems.tsv`.
- A finite witness is not a universal representation theorem.
- A private test seam supplies boundary construction, not machine semantics.
- Dual-compiler agreement is not ISO C++ semantics.
- Depth-4 exploration is not unbounded refinement.
- Generation and parent fields are not revocation/currentness proofs.
- A C proof island does not automatically denote the C++20 implementation.
- A source hash identifies text; it does not interpret the language.
- A prior theorem or test log is stale after construction-basis or proof-tree drift.

DEC-0010, DEC-0015, DEC-0020, DEC-0021, and
`docs/proof/PROOF-EVIDENCE-ACCEPTANCE.md` govern currentness.

## Rev0772 companion landing zone

Revision 0772 adds a proof-only side landing zone, not a new architectural layer:

```text
A0/I0 canonical scalar program
  -> checked identical companion program
  -> exact self-contained C++20 bytes               CONFORMANCE
  -> exact C++20 value of frozen construct set      OPEN_DEBT
  -> compiler/ABI/binary preservation               OPEN_DEBT

companion compiled value
  <-> active fixed-width scalar value               BOUNDED
```

The active K0 source path and all M0/profile arrows remain unchanged. No theorem may
cross from the companion to active source, compiler, binary, or platform by naming
similar fields or observing the bounded witness.

## Rev0773 normalized companion rung

```text
exact companion bytes                                      CONFORMANCE
  -> exact source/token/binding normalization              OPEN_DEBT
  -> closed companion AST and value evaluation             THEOREM
  -> exact raw aggregate                                   THEOREM
  -> scalar observation                                    THEOREM
  -> selected implementation ulong carrier                CONFORMANCE
  -> compiler / ABI / linked binary                        OPEN_DEBT
```

The active K0 source path and every M0/profile arrow remain unchanged. The theorem
ledger maps six load-bearing rev0773 lemmas; it does not map standard clauses or
compiler observations as premises.

## Future M0-STATIC2 ladder — not started

Excavation 018 names the first possible physical construction without promoting any
platform claim. Its rungs are deliberately separate:

| Future edge | Required evidence | Rev0773 state |
|---|---|---|
| one canonical two-domain policy is well formed and private ranges are disjoint | closed policy value plus Isabelle definitions and lemmas | NOT_STARTED |
| admitted policy maps to one bounded abstract installation plan | total planner plus exact plan-refinement theorem | NOT_STARTED |
| selected architecture entries encode the abstract plan | admitted page-table/control-register semantics and source relation | NOT_STARTED |
| boot selects the encoded roots and rejects unsupported privileged events | bounded boot source, platform assumptions, image identity, emulator/hardware evidence | NOT_STARTED |
| resulting CPU-memory behavior refines the two-domain isolation machine | machine-interface refinement and trace relation | NOT_STARTED |

The bundle excludes DMA, IOMMU, device assignment, interrupt remapping, multicore,
scheduling fairness, information flow, side channels, persistence, migration, rich
lifecycle, workstation trusted paths, and agent Runtime semantics. These exclusions
are theorem boundaries, not implied future failures.
