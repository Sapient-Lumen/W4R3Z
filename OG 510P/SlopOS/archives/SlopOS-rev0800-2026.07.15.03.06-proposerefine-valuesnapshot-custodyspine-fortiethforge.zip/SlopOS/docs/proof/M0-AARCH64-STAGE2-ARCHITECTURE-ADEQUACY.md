# Proof boundary — M0 AArch64 stage-2 architecture-event adequacy

## Checked proposition family

The Isabelle session checks exact finite facts about:

- certificate extent, source identities, premise and feature masks;
- corrected `HCR_EL2 = VM | RW` arithmetic;
- equality to the current M0-P6 activation/control values;
- exact twelve binding rows and ten ordered events;
- value-only endpoints, event-image completeness, and distinctness;
- total status precedence and exact selected acceptance;
- rejection of the rev0784 activation/HCR lineage;
- rejection framing;
- exact admitted state; and
- preservation of the selected M0-P6 sealed-run theorem.

## Assumption boundary

The thirty-two certificate premises are names and required bits.  Isabelle does
not prove them true of an Arm PE.  In particular, the current root has no formal
semantics for system-register effects, DSB/ISB/TLBI, translation-table walks,
cache/TLB visibility, exception levels, implementation features, or platform
concurrency.

## Correspondence boundary

```text
C++20 selected certificate bytes
  -> generated Isabelle constants            currentness evidence
  -> Isabelle finite relation                 checked theorem
  -X-> ISO C++20 source semantics
  -X-> compiler / ABI / binary semantics
  -X-> formal Arm operational semantics
  -X-> privileged execution or observation
```

The theorem ledger must not widen these propositions.  Mutation tests,
reference/core agreement, sanitizers, and no-allocation observations remain
bounded executable evidence.

## Promotion rule

`OBL-M0-S2-ACTIVATION-ARCH-ADEQUACY-001` may be a theorem only while the exact
generated constants, mapped lemma rows, zero-hole Isabelle2025-2 session, and
construction basis are current.  Instruction realization and formal Arm
adequacy remain separate open obligations.
