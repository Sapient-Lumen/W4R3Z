# Capability scalar projection boundary

## Purpose

The authority-bearing decision for one capability cell is now carried by four
separate artifacts with four separate claims:

```text
include/slopos/k0/capability_scalar_types.hpp
  fixed-width proof-facing source values

proof/K0_Capability_Scalar_Source.thy
  closed seven-atom semantic program and checked evaluator

generated/include/slopos/k0/generated/capability_scalar_kernel.hpp
  exact Isabelle-exported C++20 constants, predicates, and project function

include/slopos/k0/capability_scalar_projection.hpp
  named compile-time conformance images/examples
```

The function classifies one cell as exactly one of:

```text
ABSENT    cell is dead; payload is not inspected and has no authority
PRESENT   cell is live and every admitted payload predicate holds
REJECTED  cell is live and at least one admitted payload predicate fails
```

For `PRESENT`, it copies the admitted logical fields and canonicalizes the absent
parent to `parent_present=false, parent=0`. `ABSENT` and `REJECTED` have canonical
zero payloads. `project_capability_cell` converts this scalar value into the richer
proof-facing logical C++ types.

This is a source and proof construction boundary. It is not a claim that C++20,
the compiler, or the binary has been formally interpreted.

## Proof-owned semantic program

`K0_Capability_Scalar_Source.thy` defines exactly seven atoms:

```text
Live
HolderNonzero
GenerationNonzero
ObjectIdNonzero
ObjectKindAdmitted
RightsAdmitted
ParentAdmitted
```

The program is closed and ordered. `Live` is the presence gate. The remaining six
atoms form the payload-admission conjunction. A total evaluator returns canonical
absence before inspecting payload admission, canonical rejection when a live
payload fails, and the exact present image otherwise.

Six mapped lemmas under `OBL-CAP-SCALAR-SOURCE-PROGRAM-001` establish:

1. the six payload atoms evaluate iff `v0_scalar_live_payload_admitted`;
2. the exact seven-atom evaluator equals `v0_scalar_project` for every proof-value
   cell;
3. dead input produces canonical absence;
4. rejection is exactly live plus inadmissible payload;
5. admitted live input produces the exact present source image;
6. dead payload is inert.

These lemmas compose with the eight earlier scalar/CAP-REP lemmas under
`OBL-CAP-SCALAR-THEORY-001`. They do not assign meaning to emitted C++ tokens.

## Generated active source

A closed Isabelle/ML renderer normalizes the exact closed program and maps only the
seven admitted constructors to a fixed C++20 header skeleton. It reads no arbitrary
source file and accepts no user text splice. Isabelle records the generated file in
the `SlopOS_K0` session.

After the theorem build, the permanent C++20 proof runner:

1. exports the exact named generated file from the accepted session;
2. requires the active header to exist;
3. records both byte counts and fingerprints;
4. compares complete byte strings;
5. rejects the proof run unless the state is `SOURCE_BYTES_CURRENT`.

That is `OBL-CAP-SCALAR-SOURCE-BYTES-001 = CONFORMANCE`. It removes silent
proof/source drift. It does not prove the renderer's semantic adequacy or ISO C++20
interpretation.

## Deliberately admitted generated C++20 surface

`scalar::project` uses only:

- `bool`, `std::uint8_t`, and `std::uint16_t` values;
- aggregate value input and output;
- named fixed constants;
- equality, inequality, and unsigned less-than comparisons;
- Boolean conjunction and disjunction;
- ordered conditionals and one conditional expression;
- one same-carrier canonicalization cast;
- aggregate return.

It uses no allocation, pointer identity, lifetime manipulation, raw-object cast,
union, aliasing, loop, recursion, exception, RTTI, virtual dispatch, optional,
array, container, I/O, volatile access, atomic, thread, or signed-overflow-dependent
operation. The type header binds required integer widths.

This list is the candidate exact source-semantics fragment. It is not yet a checked
parser or ISO C++20 evaluator.

## Formal mathematical value semantics

`proof/K0_Capability_Scalar_Projection.thy` defines:

```text
v0_scalar_live_payload_admitted
v0_scalar_project
v0_scalar_projection_admitted
v0_scalar_projection_capability
```

Eight mapped lemmas establish object-kind-domain equivalence, payload-admission
equivalence, canonical dead and rejection images, CAP-REP admission equivalence
under fixed-width carriers, exact present fields, exact logical capability image,
and dead-payload inertness.

The exact lemma map is in `proof/theorems.tsv`. Together with the source-program,
certificate-admission, direct-fragment, and parsed-certificate lemmas, the current
formal layer has thirty-six scalar-specific propositions.

## C++20 witness

`tests/test_capability_scalar_projection.cpp` compares the production function with
a structurally separate literal value oracle over three recorded finite domains:

```text
dead inputs       327,936 cases   FNV 3ff1f907c5d2a725
valid live inputs 134,784 cases   FNV 93209a6a66ab8da5
invalid live      131,187 cases   FNV c6c604c5beb5e375
```

The witness is normal-CTest counterexample pressure. It is not a proof for all C++
source values, compiler behavior, ABI behavior, or binary execution.

## Exact claim split

```text
OBL-CAP-SCALAR-THEORY-001
  THEOREM: mathematical scalar admission/image relation

OBL-CAP-SCALAR-SOURCE-PROGRAM-001
  THEOREM: closed source-program evaluator equals mathematical projection

OBL-CAP-SCALAR-SOURCE-BYTES-001
  CONFORMANCE: active header bytes equal accepted Isabelle export

OBL-CAP-SCALAR-WITNESS-001
  BOUNDED: selected production C++ values agree with independent oracle
```

These remain open:

```text
OBL-CAP-SCALAR-CXX-001
  exact generated C++20 evaluation realizes the checked source program

OBL-CAP-REP-CXX-001
  Capability wrapper + scalar kernel + decoder realize CAP-REP

OBL-CXX-COMPILER-001
  named compiler/ABI preserves admitted C++20 behavior

OBL-CPP-SEM-001
  compiled K0 transition scope refines I0/D0
```

No theorem row inherits those edges merely because source is generated or tiny.

## Next boundary

Rev0770 added the whole-input binder and finite certificate. Rev0771 separates
exact admission from a direct finite HOL evaluator and adds an independent C++20
fragment interpreter with bounded compiled-agreement evidence. This is exact-
fragment CONFORMANCE, named mathematical theorems, and bounded counterexample
pressure; it is not a proof of the binder, preprocessing, renderer, ISO C++20,
compiler, ABI, binary, or platform. `OBL-CAP-SCALAR-CXX-001` remains open. E0-P10 retained the companion landing zone; rev0773 checks its normalized value semantics, and E0-P12 addresses only the exact source-to-AST edge.

## Rev0772 companion pressure

The scalar value decision now has a proof-only built-in-type source spelling with no
external declarations. Its checked program identity and bounded compiled agreement
increase pressure on accidental active-source behavior while preserving the exact
same absent/rejected/present projection. No CAP-REP definition or K0 transition was
changed.
