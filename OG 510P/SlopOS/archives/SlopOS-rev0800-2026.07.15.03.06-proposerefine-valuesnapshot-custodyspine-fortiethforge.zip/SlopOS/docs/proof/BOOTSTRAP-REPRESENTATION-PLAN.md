# Bootstrap representation plan — E0-P5 result

## Objective

Make initial authority enter the same value/representation stack as transitions
without adding a command, platform mechanism, or circular observation API.

## Construction completed

`bootstraprep::materialize` independently validates the complete fixed plan and
returns either:

```text
precise failure class + canonical empty image
```

or:

```text
exact twelve-cell Capability source-value image + accepted sequence zero
```

It does not call `bootstrap_plan_valid` and does not share either machine's install
routine. The shipped plan yields four live root cells and eight dead cells. Fifteen
malformed classes are exercised; no rejected plan exposes a partial image.

A private test-only peer observes all twelve model/core cells without adding a
production inspection API. The independent image equals both machine initial
capability tables, sequence zero, and empty mapping/message state. Compact canonical
observation remains deliberately distinct from a complete raw frame.

The C++ emitter generates
`proof/generated/K0_Bootstrap_Representation_Generated.thy`, including exact cells
and fingerprint `9b6b382bb77b2156`. Isabelle proves:

- every generated cell is admitted;
- CAP-REP holds for the generated array and formal initial map;
- slots 0–3 equal the four generated bootstrap roots;
- slots 4–11 are absent;
- every out-of-range slot is absent;
- accepted sequence zero satisfies SEQ-REP.

## Evidence classes

- C++ materializer and malformed-plan cases: bounded/conformance evidence;
- model/core full-state equality through the private peer: test evidence;
- generated value image: source-value binding, not object layout;
- accepted Isabelle lemmas: formal value-relation theorems;
- C++ object evaluation, compiler, ABI, boot, and platform realization: open debts.

## Remaining bootstrap edges

`OBL-BOOT-REP-001` remains open as an umbrella because the full claim crosses the
C++ and compiler boundary. It is decomposed into:

- checked value-relation theorem;
- independent finite C++ witness;
- universal C++ source-value correspondence debt;
- existing compiler/platform debts.

No future office may call initialization proved merely because the formal value
image theorem and finite executable witness agree.
