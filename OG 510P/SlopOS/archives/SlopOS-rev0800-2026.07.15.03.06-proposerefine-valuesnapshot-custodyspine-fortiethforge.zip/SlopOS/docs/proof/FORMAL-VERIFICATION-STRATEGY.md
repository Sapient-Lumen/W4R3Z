# Formal verification strategy for the SlopOS product family

## Aim and honesty boundary

The product ambition is deliberately extreme: one authority-centred system capable
of supporting a secure workstation, a cloud micro-VM substrate, a static embedded
appliance, and an agent/automation OS. The proof programme must be designed for that
ambition from the beginning. Epoch Zero itself remains a tiny sequential hosted
machine and claims only the propositions and finite observations it actually
establishes.

“seL4-shaped” means the following discipline:

1. security-relevant behaviour is stated over an abstract machine;
2. deterministic design choices are separated from abstract permission;
3. each implementation layer has an explicit refinement or representation edge;
4. initialisation is proved, not assumed from a convenient snapshot;
5. source, compiler/binary, assembly, boot, hardware, DMA, and side-channel
   assumptions remain visible;
6. tests continue beside proofs because they find specification mistakes and cover
   unverified assumptions and configurations.

It does not mean that SlopOS inherits any seL4 theorem or assurance claim.

## The selected machinery

### Authoritative theorem root: Isabelle/HOL 2025-2

Isabelle/HOL owns unbounded mathematical claims for A0, D0, I0/KIR, representation
relations, refinement, invariants, initialisation, and later M0 platform models.
The session is pinned and checked with proof holes disabled. The immediate reasons
are:

- direct seL4/L4.verified precedent for operating-system refinement and security;
- classical higher-order logic and mature relational/state-machine proof practice;
- a small LCF-style trusted proof kernel;
- mature finite-word and systems libraries;
- an existing C-semantics ecosystem through the C parser and AutoCorres2 that can
  be measured for proportionate C-facing proof islands without being confused with
  general C++20 semantics;
- a self-contained distribution that now runs in the constrained cloudtainer.

### Permanent executable machinery: C++20

C++20 owns:

- the clear reference model;
- the separately represented fixed-capacity core;
- deterministic command and observation formats;
- differential oracle execution;
- finite explorers and witnesses;
- fuzz targets and corpus replay;
- generated KIR/proof-facing value artifacts;
- the Isabelle process runner and evidence packets;
- office audit, currentness, vault integrity, and resumption.

The model and core may share value declarations and wire/schema constants, but not
transition logic. Generated implementation bodies remain explicit trust/translation
surfaces rather than becoming proof by construction through naming.

### Auxiliary engines

The following may be added when they close a named obligation:

- GCC and Clang with warnings-as-errors;
- ASan/UBSan and later compiler-specific hardening;
- libFuzzer or equivalent C++20 fuzz drivers;
- exhaustive bounded state exploration;
- CBMC or ESBMC for bounded C++ properties;
- SMT within Isabelle or as counterexample machinery;
- model-based concurrency exploration when concurrency exists.

Every bounded result states its domain. No auxiliary engine promotes a theorem row.

## Refinement ladder

```text
A0  abstract authority/security machine
  ^  abstract simulation and invariant preservation
D0  deterministic design machine
  ^  exact outcome, precedence, update and observation refinement
I0  admitted implementation semantics / KIR / value relations
  ^  source evaluation and representation correspondence
K0  constrained C++20 privileged implementation
  ^  compiler/ABI/binary correspondence
M0  platform mechanisms and assumptions
  ^
physical machine and deployment configuration
```

The arrows are obligations, not decoration. A proof at one layer cannot jump an
arrow.

### A0

A0 describes what effects may occur: authority attenuation, object ownership,
mapping permission, communication permission, isolation, and state invariants. It
must avoid C++ storage choices and accidental API precedence.

### D0

D0 fixes capacities, total results, first-failure order, state updates, sequence
consumption, and observations. Rejection is an exact frame. D0 can be executable in
Isabelle and mirrored by a deliberately clear C++ reference model.

### I0/KIR

I0 admits only a small language of implementation-relevant operations. KIR-0 is not
a general compiler IR. It is a closed transition schema whose guards and commit
shape can be inspected, generated, and proved. Representation relations such as
CAP-REP and SEQ-REP live here.

### K0

K0 is a constrained C++20 core with fixed capacities, explicit identities, no
exceptions/RTTI in the trusted core, no transition-time dynamic allocation, and
quarantined low-level operations. C++20 itself does not supply memory safety or
refinement. Those are proof and engineering obligations.

### M0

M0 eventually models page-table writes, second-stage translation, TLB/cache
maintenance, trap/interrupt entry, context switching, DMA/IOMMU, memory ordering,
boot, and platform configuration. M0 assumptions are profile- and configuration-
specific. A hosted transition proof is not a platform isolation proof.

## C++ source-semantics route

General C++20 currently lacks a SlopOS-ready, seL4-like automatic route into the
Isabelle refinement stack. The strategy is therefore incremental:

1. keep each authority-bearing C++ decision extremely small and source-visible;
2. express proof-facing value conversions explicitly and canonically;
3. prove the mathematical relation independently before claiming source behavior;
4. use bounded independent C++ witnesses to attack the candidate relation;
5. measure existing C semantics only when an authoritative C edge or checked common
   source removes more correspondence than it creates;
6. formalize only the exact admitted C++ fragment or generate one tiny authoritative
   source when that is smaller than importing a general frontend;
7. name compiler/ABI/binary assumptions separately;
8. investigate compiler IR or binary verification only after a source theorem is
   worth carrying downward.

Rev0768 performed the first route measurement. AutoCorres2 is retained as gated
research, not a standing dependency: it gives real C semantics but does not turn a
hand-maintained C mirror into authoritative C++20 behavior.

Rev0769 selected the generated-authoritative-source route at the smallest useful
scale. A closed seven-atom HOL program owns the scalar admission decision; its
evaluator is proved equal to `v0_scalar_project`; a closed Isabelle/ML renderer emits
the active C++20 header; and the permanent C++20 proof runner requires exact
accepted-export/active-header byte equality. This removes silent theorem/source
drift. It does not prove the renderer, parser, ISO C++20 evaluator, compiler, ABI, or
binary.

Rev0770 completes E0-P8 at the finite certificate layer. A permanent C++20
whole-input binder emits a deterministic parsed certificate; Isabelle checks that it
is exactly canonical, admitted, denotes the seven-atom source program, and has the
exact scalar projection result. A source digest, common schema, `constexpr`, or
finite witness remains insufficient. Binder correctness and admitted ISO C++20
semantics remain open.

## Product theorem bundles

The common kernel bundle should eventually contain:

- capability integrity and attenuation;
- spatial isolation and authorized mapping;
- object/capability/mapping well-formedness;
- total, fail-closed privileged transitions;
- initialization/configuration correctness;
- bounded low-level trust interfaces;
- explicit compiler/platform assumptions.

Profile bundles extend rather than fork it:

| Profile | Additional proof pressure |
|---|---|
| A — workstation | IOMMU/device assignment, input/display authority, human session boundaries, compatibility-domain confinement, update/recovery |
| B — cloud micro-VM | stage-2 translation, VM exits, vCPU/interrupt state, tenant noninterference, image lifecycle, attestation/provenance |
| C — embedded appliance | static partitioning, schedule/resource bounds, device ownership, deterministic recovery, fixed configuration correctness |
| D — agent OS | proposal/admission/effect separation, provenance/currentness, receipts/replay, lease/revocation, policy non-bypass; primarily P0 Runtime |

Information-flow and concurrency claims are deliberately later theorem families.
They require explicit observations, scheduling/memory models, declassification, and
non-claims; neither should be smuggled into functional correctness.

## Why the root is singular

Lean is kept as a serious reconsideration candidate because its small kernel,
dependent types, executable definitions, metaprogramming, and likely LLM ergonomics
are valuable. It is not a parallel root. The present risk is the source/platform
refinement chain, and duplicating A0/D0 in another prover would add translation and
currentness obligations without closing C++ semantics. A switch requires one of the
measured gates in `docs/proof/WHY-ISABELLE.md`.

## Toolchain continuity is part of proof currentness

The logical theorem does not depend on a cloudtainer path, but the office's claim
that the current tree was checked does. `slopos-proof doctor` and
`slopos-office open` expose missing, wrong, and ready states. The pinned shell
installer is transport only; the permanent harness and evidence machinery are
C++20. Formal tests are registered unconditionally, so missing Isabelle cannot
produce an accidentally green reduced suite.

## Current closure

Rev0773 establishes only:

- an accepted Isabelle2025-2 `SlopOS_K0` session for the exact current
  A0/D0/KIR/scalar/source-program/certificate/value-semantics/CAP-REP/SEQ-REP/
  bootstrap tree;
- deterministic fresh-cloudtainer diagnosis and recovery, with formal tests always
  present in the CTest graph;
- sixty-eight exact formal propositions listed in `proof/theorems.tsv`;
- exact accepted-session export and active byte currentness for the generated kernel
  source and self-contained proof companion;
- whole-input binding and finite-certificate conformance for the active fixed-width
  scalar header;
- direct checked structural execution of the finite certificate;
- a closed normalized companion value-language AST/evaluator, exact raw aggregate
  result, separate scalar observation, and agreement with the certificate under the
  admitted CAP-REP carrier and explicit unsigned-long envelope;
- selected-implementation C++20 type/range checks and bounded companion-to-active
  agreement over the recorded 593,907-cell domain;
- explicit source-to-AST, compiler, ABI, binary, platform, DMA, concurrency,
  information-flow, and product-profile debt;
- a byte-preserved old-vault selection and NOT_STARTED ladder for one future
  two-domain static-isolation construction.

It does not establish exact source-to-AST adequacy, a complete ISO C++20 semantics,
renderer or binder correctness, compiler/binary preservation, a booted kernel,
page-table or TLB correctness, DMA isolation, multicore safety, information flow,
side-channel resistance, or any A/B/C/D product security claim.

## Near-term order

1. Keep the full Isabelle checker and generated-source export gate mandatory for
   theorem-bearing closes.
2. Preserve exact theorem-to-obligation mapping, proof evidence currentness, and the
   distinct theorem/conformance/bounded/debt classes.
3. Preserve the E0-P9 direct finite evaluator and independent C++20 witness as
   separate theorem and bounded-evidence layers.
4. Preserve E0-P10's self-contained proof companion and measured checker rejection.
5. Preserve E0-P11's closed normalized companion value semantics and its explicit
   carrier/envelope premises; do not promote `OBL-CAP-SCALAR-CXX-001` from
   structural or bounded agreement.
6. In E0-P12, close or sharply reject only the exact frozen source-to-AST relation;
   do not add a general frontend, second root, C mirror, or third evaluator.
7. Freeze the scalar source island at the E0-P12 exit.
8. Select one emulator/architecture/boot/proof envelope for the future
   `M0-STATIC2` construction before writing architecture-specific K0 source.
9. Keep policy admission, abstract installation plan, page-table encoding, selected
   live roots, and observed CPU-memory isolation as separate proof edges.
10. Introduce multicore, devices/DMA, richer lifecycle, and profile breadth only as
    later independently named layers.

## Rev0772 strategy update

E0-P10 retained the smallest source-language landing zone found so far. The companion
is generated from the Isabelle root, self-contained, exact, and outside runtime
authority. Its two new theorem rows raise the mapped ledger to sixty-two exact
propositions. The C++20 witness adds 593,907 bounded comparisons under each selected
lane.

The next formal task is not another model. It is to give the frozen companion
construct set an admitted semantics and prove that semantics returns the checked
scalar projection. A tiny Isabelle deep embedding is the default experiment because
it preserves one theorem root. AutoCorres2/C remains conditional on same-source bytes
and an explicitly smaller C/C++ equivalence obligation. Neither route may claim
compiler or binary preservation.

## Rev0773 strategy update

The direct Isabelle route earned retention for the frozen companion. The new theory
checks a closed value-language AST, exact raw aggregate result, and scalar observation
under the CAP-REP carrier and an explicit unsigned-long envelope. The theorem does
not own the token stream.

The remaining scalar source edge is now one relation:

```text
exact 2570 companion bytes -> exact admitted normalized AST
```

E0-P12 may close or sharply reject that relation. It may not add a general C++
frontend, a second prover root, a C mirror, or another semantic evaluator merely to
produce more evidence. Selected compiler type/range assertions remain conformance;
compiler preservation remains an independent later obligation. After E0-P12 the
source island freezes and the strategy returns to the first physical static-
isolation construction.
