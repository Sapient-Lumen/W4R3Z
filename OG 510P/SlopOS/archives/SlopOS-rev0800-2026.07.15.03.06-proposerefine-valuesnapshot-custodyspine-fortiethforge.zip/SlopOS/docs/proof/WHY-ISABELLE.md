# Why Isabelle is the SlopOS theorem root

This is the short operational answer a future office must be able to recover without
re-running the original tool debate.

## Decision in one sentence

**Isabelle/HOL 2025-2 is the sole authoritative theorem root because SlopOS is
attempting a seL4-shaped relational refinement and security programme, and
Isabelle is the only evaluated route that combines the directly relevant kernel
proof precedent, mature state-machine/HOL infrastructure, an obligation-by-obligation
imperative-semantics research path, and a working pinned installation in this
cloudtainer.**

This is a project-specific choice, not a claim that Isabelle is universally the best
proof assistant.

## The proof problem actually being solved

SlopOS does not mainly need a language for proving isolated algebraic facts. It needs
one proof graph that can eventually connect:

```text
A0 abstract authority and isolation machine
  <- refinement -
D0 deterministic executable design machine
  <- representation/refinement -
I0 admitted source semantics or a deliberately tiny proof island
  <- implementation relation -
K0 constrained C++20 implementation
  <- compiler/binary validation -
B0 binary image
  <- platform assumptions/refinement -
M0 machine and deployment configuration
```

Across that graph we need inductive transition systems, finite-word reasoning,
state invariants, Hoare-style reasoning, relational refinement, initialization,
access-control properties, later information-flow statements, and exact assumption
tracking. That shape is unusually close to the maintained seL4/L4.verified proof
family.

## Why Isabelle wins this role

1. **The precedent matches the intended proof architecture.** The maintained seL4
   formal specifications and most of their proofs are Isabelle/HOL developments.
   SlopOS is not copying seL4's code or claiming its results, but it is deliberately
   learning from the same ladder: abstract specification, executable/design level,
   implementation semantics, functional correctness, and stronger security layers.

2. **HOL is a natural fit for the current machine.** K0 is presently a total,
   sequential transition system over explicit finite state. Classical higher-order
   logic, datatypes, recursive functions, inductive definitions, records, sets,
   partial maps, and word libraries fit this work without first inventing a new
   foundational style.

3. **There is an existing imperative-program route worth measuring.** Simpl,
   StrictC, and AutoCorres2 provide an Isabelle-side environment for reasoning about
   a substantial C subset. They do not prove C++20, and they do not erase the
   C-versus-C++ or compiler edge. Rev0768 measured that route and rejected it as a
   standing office dependency for the present scalar target: its dependency/resource
   envelope was disproportionate, while a hand-written C island would leave the
   authoritative-language relation open. This measured rejection strengthens rather
   than weakens Isabelle's role; the theorem root remains useful while source-bridge
   machinery is selected obligation by obligation.

4. **One checker can own the whole formal proposition graph.** Abstract definitions,
   representation relations, source-island semantics, initialization lemmas, and
   later security theorems can live in one session graph. This avoids a translation
   theorem and currentness protocol between two authoritative provers during the
   most fragile stage of the project.

5. **It works in the actual office.** The pinned `Isabelle2025-2` installation,
   headless launcher, HOL heap, SMT smoke test, and complete `SlopOS_K0` session have
   all run in this cloudtainer. A clean session currently completes in roughly half
   a minute and below one GiB of resident memory. That turns formal source into
   routine executable evidence rather than a future promise.

6. **The trust posture is legible.** Isabelle follows the LCF tradition: automation
   may be large, but accepted theorems must pass the logical kernel. SlopOS still
   records Isabelle, its runtime, imported sessions, axioms, oracles, generated
   theory text, and external solver use as part of a claim-specific trust story; the
   word “kernel” is not a magic eraser for assumptions.

## Why not Lean as the primary root now?

Lean 4 is a serious proof assistant. Its small proof-checking kernel, dependent type
theory, executable definitions, metaprogramming, and modern language design may be
excellent for verified functional software and for agent-assisted proof authoring.
Those strengths are real.

They do not currently remove SlopOS's hardest burden. There is no evaluated,
maintained Lean route that imports the constrained C++20 semantics we need or gives
us the seL4-style kernel refinement stack nearly for free. Selecting Lean now would
mean simultaneously constructing:

- the OS refinement libraries and proof conventions;
- the low-level word/imperative-state infrastructure needed by this project;
- the implementation-semantics bridge;
- the evidence and batch-office integration;
- and SlopOS itself.

That is a second moonshot nested inside the first. It might eventually be justified,
but it is not the smallest path to one load-bearing theorem.

Lean is therefore a **reconsideration candidate and possible independent checker**,
not a parallel source of truth. No A0, D0, KIR, representation, or security
specification is duplicated in Lean during Epoch Zero.

## What Isabelle does not solve

Selecting Isabelle does **not** establish any of the following:

- ISO C++20 operational semantics;
- equivalence of a C proof island and the authoritative C++20 function;
- compiler or optimizer correctness;
- ABI, object-layout, linker, or binary correctness;
- boot, page-table, interrupt, DMA/IOMMU, or hardware correctness;
- multicore or weak-memory correctness;
- information-flow, side-channel, or product-profile security.

Those are separate edges and assumptions. The point of the choice is to give them
one honest theorem root, not to make them disappear.

## Reconsideration triggers

Re-open the prover decision only if measured evidence shows one of these:

1. a maintained alternative closes a named SlopOS source/refinement obligation that
   Isabelle cannot close proportionately;
2. the pinned Isabelle route becomes operationally unavailable despite the retained
   recovery machinery;
3. Isabelle proof maintenance demonstrably dominates implementation progress for a
   representative slice;
4. independent dual checking is explicitly funded, including a translation,
   semantic-equivalence, and evidence-currentness design.

Taste, syntax preference, popularity, or one impressive toy proof is not enough.

## Operational pin

The required version is exactly `Isabelle2025-2`. Run:

```text
build/debug/slopos-proof doctor --root .
```

If it does not report `TOOLCHAIN_READY`, follow `docs/office/RECOVERY.md`. A theorem
claim is current only after the exact `SlopOS_K0` session is accepted and its proof
packet is bound to the active construction basis.


## Structural concrete-image proof law

Large concrete images are proved from small explicit prefixes, replicated/default tails, and composition lemmas. Whole-image blind normalization is not accepted as a scalable proof strategy. Scalar identities may use Isabelle evaluation where the proposition and resulting theorem remain small and reviewable. A timeout or resource exhaustion is never theorem evidence.
