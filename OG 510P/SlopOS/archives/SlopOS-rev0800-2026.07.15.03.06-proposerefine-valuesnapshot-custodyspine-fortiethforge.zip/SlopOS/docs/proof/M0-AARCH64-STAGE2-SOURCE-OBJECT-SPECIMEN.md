# Proof boundary — M0 AArch64 stage-2 source/object specimen

## Checked proposition family

The Isabelle2025-2 root checks exact finite facts about:

- source/object/text extents and section/symbol/relocation counts;
- exact source and object list lengths and their non-equality;
- ELF magic and the selected header tuple;
- exact section-header projections;
- zero relocation count;
- exact symbol-table projections;
- exact nine text words and equality to M0-P8 words;
- nonzero source, assembler, command, predecessor, object, and semantic IDs;
- total selected status and precedence examples;
- rejection-state framing;
- selected admission and state transition; and
- preservation of M0-P8 instruction-candidate admission.

## Correspondence boundary

```text
C++20 selected source/object bytes
  -> generated Isabelle natural/list constants     currentness evidence
  -> Isabelle finite value/status relation          checked theorem
  -X-> assembly-language semantics
  -X-> Clang integrated-assembler semantics
  -X-> ISO C++20 parser semantics
  -X-> general ELF or loader semantics
  -X-> instruction execution or architecture effect
```

The theorem root proves propositions about the generated finite values. The
theorem root does not formalize assembly syntax or prove the C++20 generator,
compiler, host filesystem, Clang binary, assembler, loader, or machine.

## Assembler replay boundary

The exact Clang version and command reproduce the selected object byte-for-byte.
This is a conformance observation retained by CTest. It is not an assembler
correctness theorem, and no theorem depends on invoking Clang during proof.

## Promotion rule

`OBL-M0-S2-SOURCE-OBJECT-SPECIMEN-001` may remain `THEOREM` only while:

- all generated artifacts are byte-current;
- the 21 exact lemma rows map to present declarations;
- the complete zero-hole `SlopOS_K0` session is accepted;
- the session is bound to the active construction basis and proof tree;
- M0-P8 theorem evidence remains current; and
- loader/execution/effect debt remains explicit.
