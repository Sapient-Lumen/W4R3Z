# Generated `DERIVE` translation schema

This is the deliberately closed translation contract selected by DEC-0008. It is a
design and evidence map, not a theorem about ISO C++20 or the compiled executable.

## One policy source

`spec/kir0-derive.program` contains a fixed header, exactly eleven distinct ordered
guards, and `COMMIT derive`. The C++20 parser rejects unknown, duplicate, missing,
accepting, reordered-set, wrong-commit, and trailing forms. From that source it
atomically emits:

- the C++20 guard array, fact extractor, and commit body used by `CoreMachine`;
- the Isabelle/HOL guard list;
- a source-line/fingerprint binding manifest.

Current source FNV-1a is `24ad3bc20606f593`; normalized-program FNV-1a is
`7fae42e8d5b085c2`. These detect ordinary drift and are not cryptographic
commitments.

## Fact schema

| Fact | Generated C++ intention | Formal counterpart |
|---|---|---|
| `actor_nonzero` | actor is not reserved domain zero | `actor ≠ 0` |
| `source_in_range` | source index is below capacity | `source < cap_slot_limit` |
| `destination_in_range` | destination index is below capacity | `destination < cap_slot_limit` |
| `distinct_slots` | source and destination differ | `source ≠ destination` |
| `rights_valid` | requested mask uses only seven admitted bits | explicit `requested_valid` |
| `source_live` | bounded source cell is live | bounded lookup is `Some` |
| `destination_empty` | bounded destination cell is not live | bounded destination is `None` |
| `holder_matches` | live source holder equals actor | `cap_holder parent = actor` |
| `derive_held` | live source mask contains derive | `Derive ∈ cap_rights parent` |
| `requested_subset` | requested mask is a valid subset of live source mask | `requested_valid ∧ requested ⊆ cap_rights parent` |
| `sequence_available` | accepted sequence is not `UINT64_MAX` | `accepted_sequence < 2^64 - 1` |

Source-dependent facts are live-gated. The formal subset fact is also validity-gated;
rev0765 corrected this exact-fact distinction after CAP-REP exposed that set decoding
alone could report subset true for an invalid mask even though final result
precedence remained unchanged. Out-of-range cells use inert placeholder
values, while earlier range guards prevent them from authorizing commit. Sequence
availability is deliberately last so it cannot override an earlier structural or
authority result. The fact extractor computes only this pure Boolean before guard
interpretation; the checked successor is invoked only after the ordered guards decide
`COMMIT`. The commit body then defensively checks the helper result before its first
state write. Guard reordering is semantic and requires regeneration plus fresh
evidence.

### Finite fact witness

`test_derive_fact_witness.cpp` independently scans the capability array and uses
literal mask and terminal-value operations rather than generated predicates. It
compares all eleven facts over the structural domain at both sequence zero and
sequence terminal.

The recorded domain is exactly **6,963,200 cases**, fingerprint
`a2dea114ba75bbd5`. This is bounded evidence, not a universal
array-to-formal-map proof. `OBL-KIR-FACTS-001` remains open.

## Commit schema

When all guards hold, `apply_derive` performs one indexed update:

```text
next := accepted_sequence_advance(current)
require next.available
child = { live = true,
          holder = actor,
          generation = source.generation,
          object = source.object,
          rights = requested,
          parent = source_slot }
capabilities[destination] := child
accepted_sequence := next.value
result := ok / derived_slot(destination) / next.value
```

Every other capability cell remains value-equal. Rejection performs no array or
sequence write.

### Finite commit/frame witness

`test_derive_commit_witness.cpp` calls the generated body directly and compares it
with an independently constructed whole-array expected state and result over every
ordered distinct slot pair, actors 1–3, valid derive-bearing parent masks, all valid
requested subsets, patterned frames, representative objects/generations, and
sequence values 0, 42, and maximum-minus-one.

It records two same-domain witnesses:

- **577,368 successful commits**, fingerprint `5a50b918f6bdfc7d`;
- **577,368 terminal rejections with exact whole-array frame**, fingerprint
  `84f6af288db22ca5`.

`OBL-KIR-COMMIT-001` remains open because finite C++ agreement plus candidate
CAP-REP source is not yet an Isabelle-accepted theorem about the array relation,
language semantics, or compiler behavior.

## Concrete cross-operation boundary witness

`test_sequence_exhaustion.cpp` recompiles private model/core test variants under
DEC-0012 and records **25 cases**, fingerprint `1b29e9f3f779ae41`. It covers
maximum-minus-one acceptance, terminal rejection, exact frames, and prior-result
precedence for DERIVE, MAP, SEND, and RECEIVE.

This supplies concrete source behavior where MAP/SEND/RECEIVE formal definitions are
still stubs. It does not silently claim their D0 refinement.

## Checked proof-value edges and remaining implementation edges

Rev0766's pinned Isabelle session accepts the exact mapped formal propositions for:

- presence-gated CAP-REP proof values;
- exact generated/formal DERIVE facts;
- proof-value child update and formal capability-map frame;
- checked proof-value sequence advance and formal KIR rejection frame;
- KIR outcome agreement with D0 and successful KIR→D0→A0 simulation.

These do not close the following:

- `OBL-CAP-REP-CXX-001`: evaluated C++ capability values and projection code must
  realize the checked proof-value relation;
- `OBL-KIR-FACTS-CXX-001`: generated C++ fact evaluation must realize the checked
  fact theorem;
- `OBL-KIR-COMMIT-CXX-001`: generated C++ store/result/sequence/frame behavior must
  realize the checked proof-value commit theorem;
- `OBL-SEQUENCE-REFINE-001`: the finite carrier and checked successor must be
  connected through actual C++ source and compiled semantics;
- `OBL-SEQUENCE-BOUND-001`: the broader all-operation umbrella remains open while
  MAP/SEND/RECEIVE lack full formal/compiled coverage;
- `OBL-CXX-COMPILER-001`: compiler, ABI, library, binary, and host behavior remain
  explicit;
- `OBL-CPP-SEM-001`: umbrella edge; bounded witnesses and generated identity cannot
  close it.

## Scope fence

KIR-0 still has no variables, loops, pointers, calls, allocation, exceptions,
concurrency, generic stores, or platform effects. `COMMIT derive` is one named closed
schema. Do not turn this into a compiler project or add a machine operation. The
active next objective is one source-semantics experiment for capability-cell
projection. It does not permit a wider KIR.
