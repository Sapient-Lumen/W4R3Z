# Trusted base and assumptions

Trust is claim-specific. There is no single undifferentiated “SlopOS TCB” yet.

## Checked theorem evidence trusts

A current `THEOREM` row trusts:

- the exact Isabelle2025-2 distribution and its LCF-style proof kernel;
- Isabelle/HOL and imported theories/components named by `proof/ROOT`;
- the definitions, theorem statements, and proof methods in the exact active proof
  tree;
- Poly/ML and the runtime used to construct proof terms, while theorem acceptance is
  mediated by Isabelle's kernel architecture;
- generated Isabelle theory/value text admitted by the session;
- the repository's proof-tree scanner/fingerprint and construction-basis selection
  for currentness;
- the host filesystem/process environment insofar as it delivers the checked files
  and complete process result to the office.

Toolchain availability and exact version are office-currentness facts. The C++20
doctor/open gates and unconditional tests reduce accidental non-execution, but those
diagnostics do not check theorems.

The transport is supply-chain machinery rather than a theorem premise:
`toolchains/isabelle.lock` pins manifest, layer, size, and installer identity. The
distribution remains external. This is not a reproducible-build proof of Isabelle.

The C++20 `slopos-proof` runner does not prove lemmas. It locates and version-checks
the tool, rejects source proof-hole markers, invokes the exact session, captures the
complete result, exports named generated source, checks byte currentness, and binds
the evidence to the current basis/proof tree. Bugs can corrupt currentness/reporting;
they cannot create an Isabelle theorem the kernel did not accept.

A theorem row trusts only its proposition and explicit premises in
`proof/theorems.tsv`. It does not trust a similarly named C++ function, generated
source interpretation, compiler, or product profile.

## Proof-owned scalar source trust

The new source-program theorem additionally trusts:

- `v0_capability_scalar_source_program` as the intended finite authority decision;
- `v0_scalar_source_eval` as its HOL evaluator;
- simplifier normalization used to expose the closed constructor list to ML;
- the exact mapped source-program propositions.

The theorem does **not** trust the renderer as a semantics-preserving C++ compiler.

The generated-source conformance claim additionally trusts:

- the Isabelle/ML renderer's fixed constructor-to-token mapping and header skeleton;
- Isabelle generated-file/export plumbing;
- the C++20 runner's exact export path and byte comparison;
- the filesystem/build graph that causes the compared active header to be compiled.

The renderer is a named trusted translation component. The byte gate establishes
identity of exported and active text, not semantic adequacy of the mapping.

## Current executable evidence trusts

- host CPU, operating system, process loader, and filesystem;
- selected GCC or Clang compiler, linker, target ABI, and flags;
- portions of the C++ standard library used by each component;
- CMake, Ninja/Make, and CTest orchestration;
- trace parser, canonicalizer, oracle, invariants, explorer, and tests;
- bootstrap declarations and shared value types used by model/core;
- correctness and independence assumptions of each witness encoding.

Independent model/core transition code and two compilers reduce correlated defects,
but shared contracts and host assumptions remain. Sanitizers and warning policies
constrain this trust; they do not verify the language or compiler.

The sequence and bootstrap private peers are test-only construction seams. Production
behavior exposes no sequence setter or full capability-table inspection API. Friend
access and separate test builds are construction discipline, not a security boundary.

## Generated and proof-value evidence additionally trusts

- `slopos-kir-compile` parsing and emission;
- `slopos-proof-emit` capability, bootstrap, theory, and trace emission;
- the closed KIR grammar and fixed commit schema;
- proof-facing fixed-width scalar carriers and generated constants;
- `capability_representation.hpp` as the richer candidate source-value wrapper;
- `bootstrap_representation.hpp` as the independent candidate initialization image;
- `accepted_sequence_advance` source semantics;
- FNV-1a only as a drift fingerprint, not a security digest;
- generated include paths, build graph, and office currency checks.

Isabelle acceptance establishes emitted proof values/propositions, not general
emitter correctness as an interpretation of C++ source. Every generated route keeps
its source, translation, language, and compiler boundaries named.

## Source-semantics route trust

AutoCorres2, Simpl, Word_Lib, a C parser, and a C mirror are not standing trusted
components. The measured C route did not close authoritative C++20 behavior.

The current scalar route contains these distinct layers:

```text
HOL source program/evaluator       checked theorem layer
Isabelle/ML renderer               trusted translation layer
accepted export == active header   conformance/currentness layer
whole-input binder certificate     trusted extraction + conformance layer
exact certificate admission        checked theorem layer
direct HOL structural execution    checked theorem layer
independent C++20 interpreter       bounded executable-evidence layer
compiled scalar::project effect     bounded executable-evidence layer
ISO C++20 value interpretation     open semantic layer
compiler/ABI/binary                open translation layer
```

Rev0770 added the exact-fragment binder and finite certificate. Rev0771 adds direct
HOL structural execution and an independently represented C++20 interpreter. The
binder remains trusted for extraction; malformed and near-miss tests are
counterexample pressure. The C++20 interpreter is trusted as a witness/oracle
component and does not prove the compiled function. Isabelle checks the finite
certificate language, not the parser, preprocessor, C++ standard, compiler, or
processor. A source digest cannot replace a parser; admission cannot replace
execution; structural execution cannot replace language semantics.


## Rev0770 proof-execution isolation

The proof runner launches Isabelle with repository-local `HOME` under
`.slopos-work/isabelle/home`, so target-session databases and heaps cannot be
inherited from or written to ambient per-user Isabelle state. System Pure/HOL heaps remain imported
trusted inputs. The runner uses `.slopos-work/isabelle/run`, removes and recreates the private
workspace before each selected-session build, and holds an exclusive
`.slopos-work/isabelle-session.lock`.

A C++20 supervisor owns the Isabelle worker process group. Parent death triggers
worker-group termination. This reduces orphaned-process and cross-session-currentness
risk; it is operational containment, not a theorem about the prover runtime.

## Rev0770 exact-fragment binder trust

The current source bridge additionally trusts:

- the C++20 tokenizer/parser in `cpp20_scalar_binding.cpp` to consume the full file
  and extract every relevant construct faithfully;
- its certificate emitter and atomic-currentness writes;
- the generated parsed theory and manifest byte checks;
- the proof runner's ordering of binder currentness before Isabelle acceptance;
- filesystem bytes and process environment used by those checks.

The finite Isabelle certificate language, exact parsed-certificate equality, program
relation, and evaluator relation are checked theorem content. The binder parser,
preprocessor/include environment, ISO C++20 adequacy, compiler, ABI, and binary
remain open obligations.


## Rev0771 structural-evaluator trust

The direct HOL fragment theorem additionally trusts:

- the finite certificate datatype and exact canonical admission predicate;
- the definitions of comparisons, joins, branch polarity, tags, typed field
  initialization, and malformed-shape handling in
  `K0_Capability_Scalar_Cpp20_Fragment`;
- the mapped propositions and their premises in `proof/theorems.tsv`.

The theorem does not trust the C++20 binder, preprocessor, compiler, or runtime.

The bounded C++20 fragment witness additionally trusts:

- `cpp20_scalar_fragment.cpp` as an independently represented interpreter;
- the witness generator's finite cell enumeration, mutation set, canonicalization,
  and fingerprints;
- compiled `scalar::project` under the selected compiler, ABI, host, and flags.

The interpreter must not call `scalar::project`; the HOL evaluator must not call
`v0_scalar_source_eval`. This independence reduces correlated implementation error,
but 593,907 agreements remain bounded evidence rather than universal semantics.

The workspace/process incident record is operational evidence only. Accepted theorem
status comes solely from the supervised C++20 runner and its exact retained packet.

## Later compiler, binary, and platform trust

The C++20 bridge must account for capability presence/field projection, exact fact
extraction, commit/frame behavior, finite accepted-sequence behavior, source
construct semantics, compiler/linker behavior, ABI and integer representation, then
platform mechanisms such as trap entry, page-table/second-stage updates, TLB/cache
management, boot state, DMA/IOMMU, interrupts, context switching, memory ordering,
and hardware behavior.

Product claims add configuration-specific assumptions:

- workstation device/input/display and compatibility-domain boundaries;
- cloud virtualization, lifecycle, tenant and attestation configuration;
- embedded static schedule/resource/device assignment;
- agent Runtime proposal/admission/effect, provenance/currentness, receipts,
  revocation, and policy mediation.

These remain separate assumptions or obligations. They are not smuggled into a
generic claim that “the core is small,” “source is generated,” or “the session
passed.”

## Rev0772 self-contained-companion trust

The companion theorem additionally trusts the definition of
`v0_capability_scalar_companion_program` and the exact mapped propositions. The
companion byte-currentness claim additionally trusts the Isabelle/ML companion
renderer, generated-file export path, C++20 runner pairwise byte comparison, and
filesystem/build graph.

The bounded companion witness additionally trusts:

- `cpp20_scalar_companion.cpp` and its exact finite-domain enumeration;
- the source audit's token-pattern exclusions and required-shape checks;
- the selected compiler, flags, ABI, host, and active generated projection;
- the calibrated counts and fingerprints.

The companion's lack of directives/imports removes those *source premises*; it does
not make the translation unit self-proving. C++ source decoding and tokenization,
`bool`/`unsigned long` semantics, enum and aggregate initialization, constant
execution, compiler lowering, ABI, binary, and platform remain open. The active
fixed-width source still retains its binder and preprocessing assumptions. The
rejected derivation checker adds no trusted component.

## Rev0773 normalized value-semantics trust

The new theorem layer trusts the definitions in
`K0_Capability_Scalar_Cpp20_Value_Semantics` for:

- the closed value, field, expression, projection-expression, statement, and
  environment datatypes;
- the option-valued evaluator and explicit short-circuit/selected-branch rules;
- the manually normalized companion helper expressions and `project` statement;
- the raw companion projection record and its scalar observation;
- the explicit `max_ulong >= 65535` envelope premise;
- the exact mapped propositions in `proof/theorems.tsv`.

Isabelle checks the consequences of those definitions. It does not check that the
2,570 source bytes tokenize, bind, or normalize to them. That relation is
`OBL-CAP-SCALAR-COMPANION-ADEQUACY-001`.

The C++20 envelope evidence additionally trusts `std::numeric_limits` and type traits
as provided by each selected build implementation, the compiler's constant
evaluation, and the office's output capture. Static assertions make disagreement a
build failure, but remain selected-implementation conformance rather than source,
compiler, ABI, or binary proof.

BRiCk/Rocq, AutoCorres2, and any general C++ frontend remain outside the active
trusted base. The external C++ draft was a review input only.
