# Capability representation relation — CAP-REP

## Purpose

`CAP-REP` is the first explicit relation between the active fixed-capacity C++20
machine shape and the Isabelle state. It addresses a gap the old cube correctly
named but never encoded: a twelve-cell `std::array<Capability, 12>` is not
automatically the formal partial map `nat ⇒ capability option`.

The bridge remains deliberately split:

1. C++ source values and candidate projection functions;
2. generated constants/fingerprints shared with proof source;
3. Isabelle proof-value definitions and checked lemmas;
4. independent finite C++ witnesses searching for counterexamples;
5. still-open evaluated-C++ and compiler/binary correspondence.

## Concrete value schema

The active C++ capability value is:

```text
Capability {
  bool       live;
  uint16_t   holder;
  uint16_t   generation;
  ObjectRef  object { uint8_t kind; uint16_t id; };
  uint16_t   rights;
  uint16_t   parent;
}
```

The proof emitter binds the currently admitted values:

```text
capacity             12
no-parent sentinel   65535
no-domain/no-object  0
object tags           domain=1, memory=2, endpoint=3
right bits            1,2,4,8,16,32,64
admitted rights       0..127
```

The manifest fingerprint is generated from text; the C++ schema fingerprint is
generated from the type-level constants and right/object tags. They detect ordinary
source drift. Neither is a cryptographic commitment or proof of compiler behavior.

Active identities are:

```text
capability-value manifest  78ce1a23cf908b80
CAP-REP schema             5bd3e08716f9bdfe
bootstrap value image      9b6b382bb77b2156
```

## Proof-value relation

For a proof-facing logical array `A` and formal state `s`:

```text
CAP-REP(A,s) :=
  every in-range cell has admitted finite carrier values
  AND every live in-range cell satisfies the live capability invariant
  AND caps(s) = project(A)

project(A)(slot) :=
  None                               when slot >= 12
  None                               when slot < 12 and A(slot).live = false
  Some(fieldwise_capability(A(slot))) otherwise
```

Field conversion is explicit:

- holder/generation/object-id proof values become formal naturals;
- object tags select `DomainObject`, `MemoryObject`, or `EndpointObject`;
- each admitted rights bit becomes membership in the corresponding formal right
  set;
- parent `65535` becomes `None`; an in-range parent becomes `Some slot`.

The relation does not inspect bytes, padding, addresses, compiler-chosen enum
representation, or container layout.

## Presence law

Presence is the authority gate. For a dead proof-value cell, all other payload
fields are semantically inert. Two dead cells project to the same formal absence
even when one contains zeroes and the other contains maximum, invalid-tag, or
out-of-range-looking payload values.

This is stronger and clearer than treating a default object or zero rights as
absence. A live bit is not itself sufficient to admit authority: a live cell must
also satisfy the field invariants. Invalid live values fall outside CAP-REP rather
than being silently normalized.

The old vault also pressures a separate concept: possible future slot-lifecycle
metadata. CAP-REP absence does not erase or invent such metadata. Current K0 has no
reuse, deletion, revocation, or stale-handle operation, so no lifecycle state is in
the relation.

## DERIVE fact and commit bridges

`project_derive_facts` consumes only the projected logical map. It does not rescan
raw `Capability` fields. The finite witness compares this value-level path to the
generated fact extractor over 2,076,672 exact cases.

Construction exposed one exact-fact defect: an invalid requested mask could be a
set-theoretic subset after decoding even though generated C++ reports
`requested_subset = false`. The formal fact now uses:

```text
requested_valid AND decoded_requested ⊆ parent.rights
```

The final transition result had not differed because validity is an earlier guard.
Exact intermediate-state correspondence still matters.

For an admitted live source and valid requested mask, the proof-value child equals
the formal parent record updated with holder, rights, and parent slot while
preserving object and generation. Checked Isabelle lemmas cover exact facts,
one-cell update, all-other-formal-slot frame, sequence representation, and formal
KIR rejection under explicit premises.

## Checked formal status

The exact pinned Isabelle2025-2 session accepts the CAP-REP and DERIVE proof-value
lemmas listed in `proof/theorems.tsv`. These rows are `THEOREM` for their stated
propositions. The theorem map explicitly excludes C++ object layout, evaluated
source behavior, compiler execution, raw-byte frame, lifecycle, and platform claims.

The generated bootstrap proof value is also related by checked lemmas to the exact
formal initial capability map and sequence zero. That theorem establishes the
proof-value initial relation, not the execution of C++ installation code.

## Exact finite witness identity

`tests/test_capability_representation.cpp` records:

| Domain | Cases | FNV-1a |
|---|---:|---|
| dead payload irrelevance | 3,935,232 | `1e22e1f412ffe725` |
| admitted live projection | 1,617,408 | `6e344610047dea45` |
| invalid live rejection | 1,574,244 | `3699a745de2dd9cd` |
| projected/generated fact equality | 2,076,672 | `534eb0b6fcb69a79` |
| successful projected commit/frame | 53,064 | `1412bbdae35d1775` |
| terminal whole-array frame | 53,064 | `d7cee8290747b55d` |

These remain bounded counterexample searches. They do not close
`OBL-CAP-REP-CXX-001`, `OBL-KIR-FACTS-CXX-001`,
`OBL-KIR-COMMIT-CXX-001`, the compiler edge, or their umbrella debts.

## Remaining edge and next experiment

The standing boundary is:

```text
checked proof-value projection theorem
  <- explicit source relation ->
actual evaluation of constrained C++20 Capability values and projection code
  <- compiler/binary relation ->
executable observation
```

Rev0769 decomposes the first arrow further. `caprep::scalar::project` owns only
the fixed-width absent/present/rejected decision; eight checked scalar lemmas state
its mathematical image; six checked source-program lemmas state that the closed
seven-atom evaluator equals that image; and the active generated header must be the
exact accepted Isabelle export. The richer wrapper still reads `Capability` fields
and constructs logical C++ library values. Rev0770 adds a whole-input binder and
finite certificate; rev0771 adds direct HOL structural execution and an independent
C++20 fragment interpreter. Binder, preprocessing, renderer, ISO C++20, wrapper,
compiler, ABI, and binary remain separate. Rev0773 checks the frozen companion's normalized value-language rung; E0-P12 targets only exact source-to-AST adequacy, not a general C++ semantics claim. Dual compilers, sanitizers, generated bytes, hashes, certificates, or finite witnesses do not close those arrows.

## Rev0772 companion boundary

The self-contained companion concerns only the scalar cell projection that feeds
CAP-REP. It does not represent the twelve-cell array, richer C++ `Capability`
objects, array layout, bootstrap installation, or transition state. Universal
companion-to-active and scalar-to-CAP-REP source relations remain open beyond the
existing formal value theorem and bounded witnesses.
