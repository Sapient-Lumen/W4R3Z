# Proof boundary — M0 AArch64 caller-edge and X30 contract

## Checked proposition family

The Isabelle2025-2 session checks exact finite facts about:

- the 512-byte contract extent and closed requirement lists;
- exact binding to rev0791 return-repair, terminal, loader, visibility, and
  instruction identities;
- the selected page, helper, and projected caller ranges;
- caller containment in the value page and disjointness from the helper;
- exact call site, PC+4 continuation, and helper entry;
- four-byte alignment;
- the `-64` BL byte delta, imm26 value, and selected 32-bit word;
- exact projected NOP and current helper `RET X30` values;
- absence of the projected caller words from current loader memory;
- X30, owner, permission, value-mask, live-mask, and readiness values;
- selected acceptance and representative fail-closed precedence;
- rejection-state framing;
- selected transition; and
- preservation of rev0791 return-repair admission.

## Assumption and semantics boundary

The BL arithmetic is a finite value relation. The root contains no Arm
instruction-step relation, no architectural register file, no exception level,
no memory-fetch semantics, no AAPCS execution theorem, and no concrete platform
premise discharge.

```text
numeric continuation = call_site + 4
!= live X30 observed at that value
```

```text
selected BL word decodes to helper entry
!= BL fetched, executed, or completed
```

```text
helper ends in RET X30
!= same-EL return permitted or completed
```

## Correspondence boundary

```text
current C++20 loader value
  -> independent current zero-word observations     bounded executable evidence
selected projected words and addresses
  -> generated Isabelle constants                   currentness evidence
generated constants
  -> Isabelle finite admission relation              checked theorem
  -X-> ISO C++20 source semantics
  -X-> assembler/object/loader relation for caller
  -X-> Arm instruction and register semantics
  -X-> live call/return effect
```

Mutation testing, reference/core agreement, sanitizers, and no-allocation
observation remain bounded counterexample pressure.

## Promotion rule

`OBL-M0-S2-CALLER-EDGE-001` may remain `THEOREM` only while:

- all generated caller-edge artifacts are current;
- every mapped lemma exists in the active theory;
- the proof root has zero proof-hole markers;
- the exact Isabelle2025-2 session is accepted against the active construction
  basis; and
- the projected-artifact and live-state non-claims remain explicit.

`OBL-M0-S2-CALLER-EDGE-LIVE-001` remains open.
