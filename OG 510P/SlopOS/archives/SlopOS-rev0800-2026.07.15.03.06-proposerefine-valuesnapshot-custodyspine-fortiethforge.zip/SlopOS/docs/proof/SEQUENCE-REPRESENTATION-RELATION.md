# Accepted-sequence representation relation

## Purpose

This note names the exact bridge introduced by DEC-0011. It prevents the Isabelle
natural number, the C++20 `std::uint64_t`, and an informal idea of “monotone
sequence” from being treated as interchangeable without premises.

## State relation

Let `n` be `accepted_sequence` in the formal `k0_state`, and let `u` be
`accepted_sequence_` in a C++ machine state.

```text
SEQ-REP(n, u) := n = unsigned_value(u) ∧ n < 2^64
```

The active C++ type supplies exactly the range `0 .. 2^64-1`. The formal state uses
`nat`, so representability is a relation, not a type identity.

The source-level availability predicates are:

```text
formal: n < (2^64 - 1)
C++20:  u != UINT64_MAX
```

Under `SEQ-REP`, these predicates agree.

## Accepted step lemma shape

For any currently accepting operation, assuming:

1. pre-state `SEQ-REP(n, u)`;
2. all earlier structural, authority, occupancy, and capacity guards hold;
3. sequence availability holds;
4. the operation's non-sequence state relation holds;

then the source transition should establish:

```text
n' = n + 1
u' = u + 1
SEQ-REP(n', u')
result.sequence = u'
```

The C++ helper computes `u + 1` only in the branch where `u != UINT64_MAX`.
Maximum-minus-one therefore advances to maximum without wrap.

## Exhausted step lemma shape

Assuming pre-state `SEQ-REP(n, u)`, all earlier guards hold, and sequence
availability does not hold:

```text
n = 2^64 - 1
u = UINT64_MAX
status = SequenceExhausted / sequence_exhausted
state' = state
result.sequence = u
```

For `DERIVE`, the terminal guard is generated from the same KIR source consumed by
Isabelle and C++. For `MAP`, `SEND`, and `RECEIVE`, the C++ model/core source carries
the same placement, while their formal transition definitions remain intentionally
incomplete.

## Result precedence

Sequence availability is never consulted as the winning result until every earlier
operation-specific guard has passed. At terminal state:

- malformed input remains `invalid_argument`;
- absent capability/object remains `not_found`;
- occupied destination/mapping remains its established conflict result;
- missing authority remains `denied`;
- full/empty operation capacity remains its established result;
- only an otherwise accepting operation returns `sequence_exhausted`.

This order is part of the transition relation, not presentation policy.

## Evidence and remaining gap

Current evidence consists of:

- the formal definitions, state-predicate bridge lemmas, and candidate
  progress-or-terminal theorem in `proof/K0_Sequence.thy`;
- the generated eleven-guard DERIVE source binding;
- 6,963,200 independent fact-extraction cases;
- 577,368 successful DERIVE commit cases and 577,368 terminal frame cases;
- 25 model/core boundary and precedence cases across all four operations;
- ordinary bounded exploration and stress from representable low sequences.

This closes a source-level design/conformance mismatch under
`OBL-SEQUENCE-SOURCE-001`; it does not close the historical universal claim. The
umbrella `OBL-SEQUENCE-BOUND-001` remains open until every operation included in an
implementation-refinement claim has checked formal semantics and a complete
state/compiled correspondence. The focused DERIVE edge is named separately as
`OBL-SEQUENCE-REFINE-001` and remains open until `CAP-REP`, the generated fact and
commit relations, and the compiler envelope are connected. `OBL-KIR-FACTS-001`,
`OBL-KIR-COMMIT-001`, and `OBL-CXX-COMPILER-001` therefore also remain open.
