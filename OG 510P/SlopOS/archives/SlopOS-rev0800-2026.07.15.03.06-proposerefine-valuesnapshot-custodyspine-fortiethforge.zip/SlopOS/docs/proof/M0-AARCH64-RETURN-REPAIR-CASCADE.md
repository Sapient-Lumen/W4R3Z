# Proof boundary — M0 AArch64 return-repair cascade

## Checked propositions

The Isabelle2025-2 root checks exact finite facts about:

- 339-to-345 source growth;
- unchanged 560-byte object extent;
- 36-to-40 text growth;
- preserved code base and four-byte code-end extension;
- exact legacy and current source, object, specimen, loader, memory, and
  visibility identities;
- equality of both nine-word prefixes to the M0-P8 words;
- exact appended `RET X30` word;
- exact preservation of the rev0790 terminal-contract identity;
- current terminal-kind migration from `NONE` to `RETURN_X30`;
- current readiness migration from terminal-control blockage to undischarged-
  premise blockage;
- zero discharge of sixteen platform premises and twelve live-return
  requirements;
- explicit mixed-generation rejection;
- rejected-transition framing;
- selected admission and transition; and
- preservation of M0-P8 instruction admission and terminal selection.

## Representation boundary

```text
C++20 exact old/new values
  -> generated Isabelle naturals/lists       currentness edge
  -> HOL finite status/transition relation   checked theorem
  -X-> C++20 operational semantics
  -X-> assembler correctness
  -X-> general ELF or loader semantics
  -X-> live Arm register or instruction semantics
```

The theorem says nothing about a physical machine unless separately related to
one through discharged premises and an admitted implementation semantics.

## Preimage law

The rev0790 terminal contract remains a theorem about the exact rev0790
preimage. It is not rewritten to pretend it was always about the repaired
object. The new repair theory owns the old/new relation.

This distinction prevents two forms of proof laundering:

1. replacing historical inputs and continuing to cite an old theorem; and
2. treating an authentic historical theorem as proof of a later artifact.

## Mixed-generation law

The formal status relation is total. A current source with a legacy object, a
current object with a legacy loader, or a current loader with a legacy
visibility identity is rejected. Rejection preserves the exact prior repair
state.

## Readiness boundary

The terminal-control defect is repaired at the value level. The formal result
is still not entry readiness:

```text
terminal present = true
live X30 established = false
platform premises discharged = false
entry ready = false
```

## Promotion rule

`OBL-M0-S2-TERMINAL-REPAIR-001` may remain `THEOREM` only while:

- all regenerated object/loader/visibility/repair artifacts are current;
- the assembler replay is exact;
- the rev0790 preimage is byte-preserved;
- the theorem ledger maps every current lemma;
- the construction basis matches;
- Isabelle2025-2 accepts with zero proof holes; and
- source, execution, and hardware non-claims remain explicit.
