include_guard(GLOBAL)

# Historical M0 and AArch64 research remains reproducible, but it is not
# part of the ordinary Epoch Zero closure lane.
function(slopos_add_legacy_m0_targets)
  # M0-P9 uses one exact, identified assembler only as a conformance replay.
  find_program(SLOPOS_AARCH64_ASSEMBLER
    NAMES clang
    HINTS /usr/local/swift/usr/bin
    REQUIRED)
  set(SLOPOS_QEMU_AARCH64
    "/mnt/data/slopos-qemu-11.0.2/rootfs/usr/local/bin/qemu-system-aarch64"
    CACHE FILEPATH "Pinned QEMU AArch64 system-emulator binary")
  set(SLOPOS_QEMU_ROOTFS
    "/mnt/data/slopos-qemu-11.0.2/rootfs"
    CACHE PATH "Pinned QEMU OCI rootfs")


  # First M-layer construction: a closed two-domain policy, independent hosted
  # reference/constrained planners, and a fixed-capacity installation ledger.
  add_library(slopos_m0_static2 STATIC src/m0/static2.cpp)
  slopos_target(slopos_m0_static2)
  target_link_libraries(slopos_m0_static2 PUBLIC slopos_common)

  add_library(slopos_m0_aarch64_s2_l3 STATIC src/m0/aarch64_s2_l3.cpp)
  slopos_target(slopos_m0_aarch64_s2_l3)
  target_link_libraries(slopos_m0_aarch64_s2_l3 PUBLIC slopos_m0_static2)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_l3 PRIVATE -fno-exceptions -fno-rtti)
  endif()

  # M0-P3: one immutable, placed, three-level stage-2 value graph.
  add_library(slopos_m0_aarch64_s2_graph STATIC src/m0/aarch64_s2_graph.cpp)
  slopos_target(slopos_m0_aarch64_s2_graph)
  target_link_libraries(slopos_m0_aarch64_s2_graph PUBLIC
    slopos_m0_aarch64_s2_l3)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_graph PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P4: one immutable graph placement/admission packet.  This remains a
  # pure value and ledger construction; it performs no memory or register effect.
  add_library(slopos_m0_aarch64_s2_packet STATIC
    src/m0/aarch64_s2_packet.cpp)
  slopos_target(slopos_m0_aarch64_s2_packet)
  target_link_libraries(slopos_m0_aarch64_s2_packet PUBLIC
    slopos_m0_aarch64_s2_graph)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_packet PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P5: one pure fixed-capacity owned-memory value and atomic installation
  # relation.  It copies the admitted graph into owned byte arrays only; it does
  # not interpret host addresses or perform physical/register effect.
  add_library(slopos_m0_aarch64_s2_owned_memory STATIC
    src/m0/aarch64_s2_owned_memory.cpp)
  slopos_target(slopos_m0_aarch64_s2_owned_memory)
  target_link_libraries(slopos_m0_aarch64_s2_owned_memory PUBLIC
    slopos_m0_aarch64_s2_packet)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_owned_memory PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P6: one pure finite cold-activation intent protocol.  It binds the
  # selected installed-memory value to root/control values and a closed order;
  # it performs no register access, barrier, TLBI, or hardware effect.
  add_library(slopos_m0_aarch64_s2_activation STATIC
    src/m0/aarch64_s2_activation.cpp)
  slopos_target(slopos_m0_aarch64_s2_activation)
  target_link_libraries(slopos_m0_aarch64_s2_activation PUBLIC
    slopos_m0_aarch64_s2_owned_memory)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_activation PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P7: one finite, source-scoped conditional mapping from the closed
  # activation labels to repository-defined abstract architecture events.  This
  # is a certificate value, not formal Arm semantics or instruction execution.
  add_library(slopos_m0_aarch64_s2_adequacy STATIC
    src/m0/aarch64_s2_adequacy.cpp)
  slopos_target(slopos_m0_aarch64_s2_adequacy)
  target_link_libraries(slopos_m0_aarch64_s2_adequacy PUBLIC
    slopos_m0_aarch64_s2_activation)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_adequacy PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P8: exact finite event-to-A64 instruction value candidate.
  add_library(slopos_m0_aarch64_s2_instruction STATIC
    src/m0/aarch64_s2_instruction.cpp)
  slopos_target(slopos_m0_aarch64_s2_instruction)
  target_link_libraries(slopos_m0_aarch64_s2_instruction PUBLIC
    slopos_m0_aarch64_s2_adequacy)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_instruction PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P9: one exact AArch64 assembly/ELF64 relocatable-object specimen.
  # The fixed-capacity core parser admits only the selected 560-byte object; the
  # identified assembler replay is conformance evidence, not a correctness theorem.
  add_library(slopos_m0_aarch64_s2_object STATIC
    src/m0/aarch64_s2_object.cpp)
  slopos_target(slopos_m0_aarch64_s2_object)
  target_link_libraries(slopos_m0_aarch64_s2_object PUBLIC
    slopos_m0_aarch64_s2_instruction)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_object PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P10: one exact pure loader-placement value and atomic copy/readback relation.
  # This applies no mapping, cache protocol, entry state, execution, or hardware effect.
  add_library(slopos_m0_aarch64_s2_loader STATIC
    src/m0/aarch64_s2_loader.cpp)
  slopos_target(slopos_m0_aarch64_s2_loader)
  target_link_libraries(slopos_m0_aarch64_s2_loader PUBLIC
    slopos_m0_aarch64_s2_object)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_loader PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P11: one exact executable-visibility assessment certificate.  It names
  # publication, effective-permission, cache-maintenance, synchronization, and
  # entry-state obligations, and records a measured terminal-control-flow block.
  # It performs no cache operation, branch, entry, or privileged effect.
  add_library(slopos_m0_aarch64_s2_visibility STATIC
    src/m0/aarch64_s2_visibility.cpp)
  slopos_target(slopos_m0_aarch64_s2_visibility)
  target_link_libraries(slopos_m0_aarch64_s2_visibility PUBLIC
    slopos_m0_aarch64_s2_loader)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_visibility PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P8R: one exact terminal-control semantic contract. It selects a
  # callable leaf-helper return through X30 while leaving the active source,
  # object, loader, and visibility artifacts unchanged and still blocked.
  add_library(slopos_m0_aarch64_s2_terminal STATIC
    src/m0/aarch64_s2_terminal.cpp)
  slopos_target(slopos_m0_aarch64_s2_terminal)
  target_link_libraries(slopos_m0_aarch64_s2_terminal PUBLIC
    slopos_m0_aarch64_s2_visibility)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_terminal PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P9R: one exact, mixed-generation-rejecting return repair relation.
  # It binds the rev0790 preimage to the repaired source/object/loader/visibility
  # chain without performing a load, register write, call, return, or hardware effect.
  add_library(slopos_m0_aarch64_s2_return_repair STATIC
    src/m0/aarch64_s2_return_repair.cpp)
  slopos_target(slopos_m0_aarch64_s2_return_repair)
  target_link_libraries(slopos_m0_aarch64_s2_return_repair PUBLIC
    slopos_m0_aarch64_s2_terminal)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_return_repair PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P10R: one exact projected caller-edge/X30 value contract. It selects
  # a non-overlapping BL+NOP caller value later in the existing RX page while
  # proving that those bytes, the call edge, and live X30 remain absent.
  add_library(slopos_m0_aarch64_s2_caller_edge STATIC
    src/m0/aarch64_s2_caller_edge.cpp)
  slopos_target(slopos_m0_aarch64_s2_caller_edge)
  target_link_libraries(slopos_m0_aarch64_s2_caller_edge PUBLIC
    slopos_m0_aarch64_s2_return_repair)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_caller_edge PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P11R: one exact caller source/object/pure-loader cascade. It updates only
  # the selected two-word caller range in the existing pure loader value, rejects
  # mixed generations, and retains machine publication, visibility, BL, X30,
  # return, boot, and isolation as explicit debt.
  add_library(slopos_m0_aarch64_s2_caller_artifact STATIC
    src/m0/aarch64_s2_caller_artifact.cpp)
  slopos_target(slopos_m0_aarch64_s2_caller_artifact)
  target_link_libraries(slopos_m0_aarch64_s2_caller_artifact PUBLIC
    slopos_m0_aarch64_s2_caller_edge)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_caller_artifact PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P12R: one exact caller visibility and entry-readiness assessment. It
  # consumes the generation-3 pure artifact, orders fourteen machine premises,
  # and remains blocked without performing publication, cache, fetch, BL, X30,
  # RET, boot, or isolation effect.
  add_library(slopos_m0_aarch64_s2_caller_readiness STATIC
    src/m0/aarch64_s2_caller_readiness.cpp)
  slopos_target(slopos_m0_aarch64_s2_caller_readiness)
  target_link_libraries(slopos_m0_aarch64_s2_caller_readiness PUBLIC
    slopos_m0_aarch64_s2_caller_artifact)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_caller_readiness PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P13R: one exact pure host-publication contract plus one quarantined Linux
  # adapter.  The model remains pointer-free; only the host library includes
  # mmap/mprotect/munmap and it never executes the selected page.
  add_library(slopos_m0_aarch64_s2_host_publication STATIC
    src/m0/aarch64_s2_host_publication.cpp)
  slopos_target(slopos_m0_aarch64_s2_host_publication)
  target_link_libraries(slopos_m0_aarch64_s2_host_publication PUBLIC
    slopos_m0_aarch64_s2_caller_readiness)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_s2_host_publication PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  if(NOT CMAKE_SYSTEM_NAME STREQUAL "Linux")
    message(FATAL_ERROR "M0-P13R requires the selected Linux host adapter")
  endif()
  add_library(slopos_host_linux_publication STATIC
    src/host/linux_publication_adapter.cpp)
  slopos_target(slopos_host_linux_publication)
  target_link_libraries(slopos_host_linux_publication PUBLIC
    slopos_m0_aarch64_s2_host_publication)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_host_linux_publication PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  # M0-P14R: one exact emulator observation certificate. The model remains a
  # pure finite C++20 value; the host supervisor launches one byte-pinned QEMU
  # chamber and a byte-pinned freestanding observer without mutating stage-2.
  add_library(slopos_m0_aarch64_el2_observation STATIC
    src/m0/aarch64_el2_observation.cpp)
  slopos_target(slopos_m0_aarch64_el2_observation)
  target_link_libraries(slopos_m0_aarch64_el2_observation PUBLIC
    slopos_m0_aarch64_s2_host_publication)
  if(CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
    target_compile_options(slopos_m0_aarch64_el2_observation PRIVATE
      -fno-exceptions -fno-rtti)
  endif()

  add_library(slopos_host_qemu_el2_observer STATIC
    src/host/qemu_el2_observer.cpp)
  slopos_target(slopos_host_qemu_el2_observer)
  target_link_libraries(slopos_host_qemu_el2_observer PUBLIC
    slopos_m0_aarch64_el2_observation)


  add_executable(slopos-static2 tools/slopos_static2_main.cpp)
  slopos_target(slopos-static2)
  target_link_libraries(slopos-static2 PRIVATE slopos_m0_static2)

  add_executable(slopos-aarch64-s2-l3 tools/slopos_aarch64_s2_l3_main.cpp)
  slopos_target(slopos-aarch64-s2-l3)
  target_link_libraries(slopos-aarch64-s2-l3 PRIVATE slopos_m0_aarch64_s2_l3)

  add_executable(slopos-aarch64-s2-graph
    tools/slopos_aarch64_s2_graph_main.cpp)
  slopos_target(slopos-aarch64-s2-graph)
  target_link_libraries(slopos-aarch64-s2-graph PRIVATE
    slopos_m0_aarch64_s2_graph)

  add_executable(slopos-aarch64-s2-packet
    tools/slopos_aarch64_s2_packet_main.cpp)
  slopos_target(slopos-aarch64-s2-packet)
  target_link_libraries(slopos-aarch64-s2-packet PRIVATE
    slopos_m0_aarch64_s2_packet)

  add_executable(slopos-aarch64-s2-owned-memory
    tools/slopos_aarch64_s2_owned_memory_main.cpp)
  slopos_target(slopos-aarch64-s2-owned-memory)
  target_link_libraries(slopos-aarch64-s2-owned-memory PRIVATE
    slopos_m0_aarch64_s2_owned_memory)

  add_executable(slopos-aarch64-s2-activation
    tools/slopos_aarch64_s2_activation_main.cpp)
  slopos_target(slopos-aarch64-s2-activation)
  target_link_libraries(slopos-aarch64-s2-activation PRIVATE
    slopos_m0_aarch64_s2_activation)

  add_executable(slopos-aarch64-s2-adequacy
    tools/slopos_aarch64_s2_adequacy_main.cpp)
  slopos_target(slopos-aarch64-s2-adequacy)
  target_link_libraries(slopos-aarch64-s2-adequacy PRIVATE
    slopos_m0_aarch64_s2_adequacy)

  add_executable(slopos-aarch64-s2-instruction
    tools/slopos_aarch64_s2_instruction_main.cpp)
  slopos_target(slopos-aarch64-s2-instruction)
  target_link_libraries(slopos-aarch64-s2-instruction PRIVATE
    slopos_m0_aarch64_s2_instruction)

  add_executable(slopos-aarch64-s2-object
    tools/slopos_aarch64_s2_object_main.cpp)
  slopos_target(slopos-aarch64-s2-object)
  target_link_libraries(slopos-aarch64-s2-object PRIVATE
    slopos_m0_aarch64_s2_object)

  add_executable(slopos-aarch64-s2-loader
    tools/slopos_aarch64_s2_loader_main.cpp)
  slopos_target(slopos-aarch64-s2-loader)
  target_link_libraries(slopos-aarch64-s2-loader PRIVATE
    slopos_m0_aarch64_s2_loader)

  add_executable(slopos-aarch64-s2-visibility
    tools/slopos_aarch64_s2_visibility_main.cpp)
  slopos_target(slopos-aarch64-s2-visibility)
  target_link_libraries(slopos-aarch64-s2-visibility PRIVATE
    slopos_m0_aarch64_s2_visibility)

  add_executable(slopos-aarch64-s2-terminal
    tools/slopos_aarch64_s2_terminal_main.cpp)
  slopos_target(slopos-aarch64-s2-terminal)
  target_link_libraries(slopos-aarch64-s2-terminal PRIVATE
    slopos_m0_aarch64_s2_terminal)

  add_executable(slopos-aarch64-s2-return-repair
    tools/slopos_aarch64_s2_return_repair_main.cpp)
  slopos_target(slopos-aarch64-s2-return-repair)
  target_link_libraries(slopos-aarch64-s2-return-repair PRIVATE
    slopos_m0_aarch64_s2_return_repair)

  add_executable(slopos-aarch64-s2-caller-edge
    tools/slopos_aarch64_s2_caller_edge_main.cpp)
  slopos_target(slopos-aarch64-s2-caller-edge)
  target_link_libraries(slopos-aarch64-s2-caller-edge PRIVATE
    slopos_m0_aarch64_s2_caller_edge)

  add_executable(slopos-aarch64-s2-caller-artifact
    tools/slopos_aarch64_s2_caller_artifact_main.cpp)
  slopos_target(slopos-aarch64-s2-caller-artifact)
  target_link_libraries(slopos-aarch64-s2-caller-artifact PRIVATE
    slopos_m0_aarch64_s2_caller_artifact)

  add_executable(slopos-aarch64-s2-caller-readiness
    tools/slopos_aarch64_s2_caller_readiness_main.cpp)
  slopos_target(slopos-aarch64-s2-caller-readiness)
  target_link_libraries(slopos-aarch64-s2-caller-readiness PRIVATE
    slopos_m0_aarch64_s2_caller_readiness)

  add_executable(slopos-aarch64-s2-host-publication
    tools/slopos_aarch64_s2_host_publication_main.cpp)
  slopos_target(slopos-aarch64-s2-host-publication)
  target_link_libraries(slopos-aarch64-s2-host-publication PRIVATE
    slopos_host_linux_publication)

  add_executable(slopos-aarch64-el2-observation
    tools/slopos_aarch64_el2_observation_main.cpp)
  slopos_target(slopos-aarch64-el2-observation)
  target_link_libraries(slopos-aarch64-el2-observation PRIVATE
    slopos_host_qemu_el2_observer)


  add_custom_target(slopos-generate-legacy
    COMMAND $<TARGET_FILE:slopos-static2> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-l3> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-graph> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-packet> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-owned-memory> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-activation> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-adequacy> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-instruction> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-object> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-loader> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-visibility> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-terminal> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-return-repair> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-caller-edge> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-caller-artifact> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-caller-readiness> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-s2-host-publication> --emit --root ${PROJECT_SOURCE_DIR}
    COMMAND $<TARGET_FILE:slopos-aarch64-el2-observation> --emit --root ${PROJECT_SOURCE_DIR}
    DEPENDS slopos-static2 slopos-aarch64-s2-l3 slopos-aarch64-s2-graph
      slopos-aarch64-s2-packet slopos-aarch64-s2-owned-memory
      slopos-aarch64-s2-activation slopos-aarch64-s2-adequacy
      slopos-aarch64-s2-instruction slopos-aarch64-s2-object
      slopos-aarch64-s2-loader slopos-aarch64-s2-visibility
      slopos-aarch64-s2-terminal slopos-aarch64-s2-return-repair
      slopos-aarch64-s2-caller-edge slopos-aarch64-s2-caller-artifact
      slopos-aarch64-s2-caller-readiness
      slopos-aarch64-s2-host-publication
      slopos-aarch64-el2-observation
    COMMENT "Regenerating paused M0 and AArch64 research artifacts")
endfunction()

function(slopos_add_legacy_m0_tests)
    add_executable(slopos-test-static2 tests/test_static2.cpp)
    slopos_target(slopos-test-static2)
    target_link_libraries(slopos-test-static2 PRIVATE slopos_m0_static2)
    add_test(NAME static2-policy-plan-install COMMAND slopos-test-static2)

    add_executable(slopos-test-static2-noalloc tests/test_static2_noalloc.cpp)
    slopos_target(slopos-test-static2-noalloc)
    target_link_libraries(slopos-test-static2-noalloc PRIVATE slopos_m0_static2)
    add_test(NAME static2-core-no-allocation COMMAND slopos-test-static2-noalloc)

    add_test(NAME static2-generated-current
      COMMAND slopos-static2 --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-l3 tests/test_aarch64_s2_l3.cpp)
    slopos_target(slopos-test-aarch64-s2-l3)
    target_link_libraries(slopos-test-aarch64-s2-l3 PRIVATE slopos_m0_aarch64_s2_l3)
    add_test(NAME aarch64-s2-l3-value-image COMMAND slopos-test-aarch64-s2-l3)

    add_executable(slopos-test-aarch64-s2-l3-noalloc tests/test_aarch64_s2_l3_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-l3-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-l3-noalloc PRIVATE slopos_m0_aarch64_s2_l3)
    add_test(NAME aarch64-s2-l3-core-no-allocation COMMAND slopos-test-aarch64-s2-l3-noalloc)
    add_test(NAME aarch64-s2-l3-generated-current COMMAND slopos-aarch64-s2-l3 --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-graph
      tests/test_aarch64_s2_graph.cpp)
    slopos_target(slopos-test-aarch64-s2-graph)
    target_link_libraries(slopos-test-aarch64-s2-graph PRIVATE
      slopos_m0_aarch64_s2_graph)
    add_test(NAME aarch64-s2-placed-graph-value
      COMMAND slopos-test-aarch64-s2-graph)

    add_executable(slopos-test-aarch64-s2-graph-noalloc
      tests/test_aarch64_s2_graph_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-graph-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-graph-noalloc PRIVATE
      slopos_m0_aarch64_s2_graph)
    add_test(NAME aarch64-s2-placed-graph-no-allocation
      COMMAND slopos-test-aarch64-s2-graph-noalloc)

    add_test(NAME aarch64-s2-placed-graph-generated-current
      COMMAND slopos-aarch64-s2-graph --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-packet
      tests/test_aarch64_s2_packet.cpp)
    slopos_target(slopos-test-aarch64-s2-packet)
    target_link_libraries(slopos-test-aarch64-s2-packet PRIVATE
      slopos_m0_aarch64_s2_packet)
    add_test(NAME aarch64-s2-placement-packet
      COMMAND slopos-test-aarch64-s2-packet)

    add_executable(slopos-test-aarch64-s2-packet-noalloc
      tests/test_aarch64_s2_packet_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-packet-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-packet-noalloc PRIVATE
      slopos_m0_aarch64_s2_packet)
    add_test(NAME aarch64-s2-placement-packet-no-allocation
      COMMAND slopos-test-aarch64-s2-packet-noalloc)

    add_test(NAME aarch64-s2-placement-packet-generated-current
      COMMAND slopos-aarch64-s2-packet --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-owned-memory
      tests/test_aarch64_s2_owned_memory.cpp)
    slopos_target(slopos-test-aarch64-s2-owned-memory)
    target_link_libraries(slopos-test-aarch64-s2-owned-memory PRIVATE
      slopos_m0_aarch64_s2_owned_memory)
    add_test(NAME aarch64-s2-owned-memory-atomic-install
      COMMAND slopos-test-aarch64-s2-owned-memory)

    add_executable(slopos-test-aarch64-s2-owned-memory-noalloc
      tests/test_aarch64_s2_owned_memory_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-owned-memory-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-owned-memory-noalloc PRIVATE
      slopos_m0_aarch64_s2_owned_memory)
    add_test(NAME aarch64-s2-owned-memory-no-allocation
      COMMAND slopos-test-aarch64-s2-owned-memory-noalloc)

    add_test(NAME aarch64-s2-owned-memory-generated-current
      COMMAND slopos-aarch64-s2-owned-memory --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-activation
      tests/test_aarch64_s2_activation.cpp)
    slopos_target(slopos-test-aarch64-s2-activation)
    target_link_libraries(slopos-test-aarch64-s2-activation PRIVATE
      slopos_m0_aarch64_s2_activation)
    add_test(NAME aarch64-s2-cold-activation-value-machine
      COMMAND slopos-test-aarch64-s2-activation)

    add_executable(slopos-test-aarch64-s2-activation-noalloc
      tests/test_aarch64_s2_activation_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-activation-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-activation-noalloc PRIVATE
      slopos_m0_aarch64_s2_activation)
    add_test(NAME aarch64-s2-cold-activation-no-allocation
      COMMAND slopos-test-aarch64-s2-activation-noalloc)

    add_test(NAME aarch64-s2-cold-activation-generated-current
      COMMAND slopos-aarch64-s2-activation --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-adequacy
      tests/test_aarch64_s2_adequacy.cpp)
    slopos_target(slopos-test-aarch64-s2-adequacy)
    target_link_libraries(slopos-test-aarch64-s2-adequacy PRIVATE
      slopos_m0_aarch64_s2_adequacy)
    add_test(NAME aarch64-s2-architecture-adequacy-certificate
      COMMAND slopos-test-aarch64-s2-adequacy)

    add_executable(slopos-test-aarch64-s2-adequacy-noalloc
      tests/test_aarch64_s2_adequacy_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-adequacy-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-adequacy-noalloc PRIVATE
      slopos_m0_aarch64_s2_adequacy)
    add_test(NAME aarch64-s2-architecture-adequacy-no-allocation
      COMMAND slopos-test-aarch64-s2-adequacy-noalloc)

    add_test(NAME aarch64-s2-architecture-adequacy-generated-current
      COMMAND slopos-aarch64-s2-adequacy --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-instruction
      tests/test_aarch64_s2_instruction.cpp)
    slopos_target(slopos-test-aarch64-s2-instruction)
    target_link_libraries(slopos-test-aarch64-s2-instruction PRIVATE
      slopos_m0_aarch64_s2_instruction)
    add_test(NAME aarch64-s2-instruction-candidate
      COMMAND slopos-test-aarch64-s2-instruction)

    add_executable(slopos-test-aarch64-s2-instruction-noalloc
      tests/test_aarch64_s2_instruction_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-instruction-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-instruction-noalloc PRIVATE
      slopos_m0_aarch64_s2_instruction)
    add_test(NAME aarch64-s2-instruction-no-allocation
      COMMAND slopos-test-aarch64-s2-instruction-noalloc)

    add_test(NAME aarch64-s2-instruction-generated-current
      COMMAND slopos-aarch64-s2-instruction --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-object
      tests/test_aarch64_s2_object.cpp)
    slopos_target(slopos-test-aarch64-s2-object)
    target_link_libraries(slopos-test-aarch64-s2-object PRIVATE
      slopos_m0_aarch64_s2_object)
    add_test(NAME aarch64-s2-source-object-specimen
      COMMAND slopos-test-aarch64-s2-object)

    add_executable(slopos-test-aarch64-s2-object-noalloc
      tests/test_aarch64_s2_object_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-object-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-object-noalloc PRIVATE
      slopos_m0_aarch64_s2_object)
    add_test(NAME aarch64-s2-source-object-no-allocation
      COMMAND slopos-test-aarch64-s2-object-noalloc)

    add_test(NAME aarch64-s2-source-object-generated-current
      COMMAND slopos-aarch64-s2-object --check --root ${PROJECT_SOURCE_DIR})
    add_test(NAME aarch64-s2-object-assembler-doctor
      COMMAND slopos-aarch64-s2-object --assembler-doctor
        --clang ${SLOPOS_AARCH64_ASSEMBLER})
    add_test(NAME aarch64-s2-source-object-assembler-current
      COMMAND slopos-aarch64-s2-object --assemble-check
        --root ${PROJECT_SOURCE_DIR}
        --clang ${SLOPOS_AARCH64_ASSEMBLER})
    set_tests_properties(aarch64-s2-source-object-assembler-current PROPERTIES
      DEPENDS "aarch64-s2-object-assembler-doctor;aarch64-s2-source-object-generated-current;aarch64-s2-source-object-specimen")

    add_executable(slopos-test-aarch64-s2-loader
      tests/test_aarch64_s2_loader.cpp)
    slopos_target(slopos-test-aarch64-s2-loader)
    target_link_libraries(slopos-test-aarch64-s2-loader PRIVATE
      slopos_m0_aarch64_s2_loader)
    add_test(NAME aarch64-s2-loader-placement
      COMMAND slopos-test-aarch64-s2-loader)

    add_executable(slopos-test-aarch64-s2-loader-noalloc
      tests/test_aarch64_s2_loader_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-loader-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-loader-noalloc PRIVATE
      slopos_m0_aarch64_s2_loader)
    add_test(NAME aarch64-s2-loader-no-allocation
      COMMAND slopos-test-aarch64-s2-loader-noalloc)

    add_test(NAME aarch64-s2-loader-generated-current
      COMMAND slopos-aarch64-s2-loader --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-visibility
      tests/test_aarch64_s2_visibility.cpp)
    slopos_target(slopos-test-aarch64-s2-visibility)
    target_link_libraries(slopos-test-aarch64-s2-visibility PRIVATE
      slopos_m0_aarch64_s2_visibility)
    add_test(NAME aarch64-s2-visibility-assessment
      COMMAND slopos-test-aarch64-s2-visibility)

    add_executable(slopos-test-aarch64-s2-visibility-noalloc
      tests/test_aarch64_s2_visibility_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-visibility-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-visibility-noalloc PRIVATE
      slopos_m0_aarch64_s2_visibility)
    add_test(NAME aarch64-s2-visibility-no-allocation
      COMMAND slopos-test-aarch64-s2-visibility-noalloc)

    add_test(NAME aarch64-s2-visibility-generated-current
      COMMAND slopos-aarch64-s2-visibility --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-terminal
      tests/test_aarch64_s2_terminal.cpp)
    slopos_target(slopos-test-aarch64-s2-terminal)
    target_link_libraries(slopos-test-aarch64-s2-terminal PRIVATE
      slopos_m0_aarch64_s2_terminal)
    add_test(NAME aarch64-s2-terminal-contract
      COMMAND slopos-test-aarch64-s2-terminal)

    add_executable(slopos-test-aarch64-s2-terminal-noalloc
      tests/test_aarch64_s2_terminal_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-terminal-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-terminal-noalloc PRIVATE
      slopos_m0_aarch64_s2_terminal)
    add_test(NAME aarch64-s2-terminal-no-allocation
      COMMAND slopos-test-aarch64-s2-terminal-noalloc)

    add_test(NAME aarch64-s2-terminal-generated-current
      COMMAND slopos-aarch64-s2-terminal --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-return-repair
      tests/test_aarch64_s2_return_repair.cpp)
    slopos_target(slopos-test-aarch64-s2-return-repair)
    target_link_libraries(slopos-test-aarch64-s2-return-repair PRIVATE
      slopos_m0_aarch64_s2_return_repair)
    add_test(NAME aarch64-s2-return-repair
      COMMAND slopos-test-aarch64-s2-return-repair)

    add_executable(slopos-test-aarch64-s2-return-repair-noalloc
      tests/test_aarch64_s2_return_repair_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-return-repair-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-return-repair-noalloc PRIVATE
      slopos_m0_aarch64_s2_return_repair)
    add_test(NAME aarch64-s2-return-repair-no-allocation
      COMMAND slopos-test-aarch64-s2-return-repair-noalloc)

    add_test(NAME aarch64-s2-return-repair-generated-current
      COMMAND slopos-aarch64-s2-return-repair --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-caller-edge
      tests/test_aarch64_s2_caller_edge.cpp)
    slopos_target(slopos-test-aarch64-s2-caller-edge)
    target_link_libraries(slopos-test-aarch64-s2-caller-edge PRIVATE
      slopos_m0_aarch64_s2_caller_edge)
    add_test(NAME aarch64-s2-caller-edge-contract
      COMMAND slopos-test-aarch64-s2-caller-edge)

    add_executable(slopos-test-aarch64-s2-caller-edge-noalloc
      tests/test_aarch64_s2_caller_edge_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-caller-edge-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-caller-edge-noalloc PRIVATE
      slopos_m0_aarch64_s2_caller_edge)
    add_test(NAME aarch64-s2-caller-edge-no-allocation
      COMMAND slopos-test-aarch64-s2-caller-edge-noalloc)

    add_test(NAME aarch64-s2-caller-edge-generated-current
      COMMAND slopos-aarch64-s2-caller-edge --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-caller-artifact
      tests/test_aarch64_s2_caller_artifact.cpp)
    slopos_target(slopos-test-aarch64-s2-caller-artifact)
    target_link_libraries(slopos-test-aarch64-s2-caller-artifact PRIVATE
      slopos_m0_aarch64_s2_caller_artifact)
    add_test(NAME aarch64-s2-caller-artifact-cascade
      COMMAND slopos-test-aarch64-s2-caller-artifact)

    add_executable(slopos-test-aarch64-s2-caller-artifact-noalloc
      tests/test_aarch64_s2_caller_artifact_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-caller-artifact-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-caller-artifact-noalloc PRIVATE
      slopos_m0_aarch64_s2_caller_artifact)
    add_test(NAME aarch64-s2-caller-artifact-no-allocation
      COMMAND slopos-test-aarch64-s2-caller-artifact-noalloc)

    add_test(NAME aarch64-s2-caller-artifact-generated-current
      COMMAND slopos-aarch64-s2-caller-artifact --check --root ${PROJECT_SOURCE_DIR})
    add_test(NAME aarch64-s2-caller-artifact-assembler-doctor
      COMMAND slopos-aarch64-s2-caller-artifact --assembler-doctor
        --clang ${SLOPOS_AARCH64_ASSEMBLER})
    add_test(NAME aarch64-s2-caller-artifact-assembler-current
      COMMAND slopos-aarch64-s2-caller-artifact --assemble-check
        --root ${PROJECT_SOURCE_DIR}
        --clang ${SLOPOS_AARCH64_ASSEMBLER})
    set_tests_properties(aarch64-s2-caller-artifact-assembler-current PROPERTIES
      DEPENDS "aarch64-s2-caller-artifact-assembler-doctor;aarch64-s2-caller-artifact-generated-current;aarch64-s2-caller-artifact-cascade")

    add_executable(slopos-test-aarch64-s2-caller-readiness
      tests/test_aarch64_s2_caller_readiness.cpp)
    slopos_target(slopos-test-aarch64-s2-caller-readiness)
    target_link_libraries(slopos-test-aarch64-s2-caller-readiness PRIVATE
      slopos_m0_aarch64_s2_caller_readiness)
    add_test(NAME aarch64-s2-caller-readiness-assessment
      COMMAND slopos-test-aarch64-s2-caller-readiness)

    add_executable(slopos-test-aarch64-s2-caller-readiness-noalloc
      tests/test_aarch64_s2_caller_readiness_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-caller-readiness-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-caller-readiness-noalloc PRIVATE
      slopos_m0_aarch64_s2_caller_readiness)
    add_test(NAME aarch64-s2-caller-readiness-no-allocation
      COMMAND slopos-test-aarch64-s2-caller-readiness-noalloc)

    add_test(NAME aarch64-s2-caller-readiness-generated-current
      COMMAND slopos-aarch64-s2-caller-readiness --check --root ${PROJECT_SOURCE_DIR})

    add_executable(slopos-test-aarch64-s2-host-publication
      tests/test_aarch64_s2_host_publication.cpp)
    slopos_target(slopos-test-aarch64-s2-host-publication)
    target_link_libraries(slopos-test-aarch64-s2-host-publication PRIVATE
      slopos_host_linux_publication)
    add_test(NAME aarch64-s2-host-publication-contract
      COMMAND slopos-test-aarch64-s2-host-publication)

    add_executable(slopos-test-aarch64-s2-host-publication-noalloc
      tests/test_aarch64_s2_host_publication_noalloc.cpp)
    slopos_target(slopos-test-aarch64-s2-host-publication-noalloc)
    target_link_libraries(slopos-test-aarch64-s2-host-publication-noalloc PRIVATE
      slopos_host_linux_publication)
    add_test(NAME aarch64-s2-host-publication-no-allocation
      COMMAND slopos-test-aarch64-s2-host-publication-noalloc)

    add_test(NAME aarch64-s2-host-publication-generated-current
      COMMAND slopos-aarch64-s2-host-publication --check --root ${PROJECT_SOURCE_DIR})
    add_test(NAME aarch64-s2-host-publication-live
      COMMAND slopos-aarch64-s2-host-publication --host-witness)
    set_tests_properties(aarch64-s2-host-publication-live PROPERTIES
      DEPENDS "aarch64-s2-host-publication-contract;aarch64-s2-host-publication-generated-current")

    add_executable(slopos-test-aarch64-el2-observation
      tests/test_aarch64_el2_observation.cpp)
    slopos_target(slopos-test-aarch64-el2-observation)
    target_link_libraries(slopos-test-aarch64-el2-observation PRIVATE
      slopos_m0_aarch64_el2_observation)
    add_test(NAME aarch64-el2-observation-certificate
      COMMAND slopos-test-aarch64-el2-observation)

    add_executable(slopos-test-aarch64-el2-observation-noalloc
      tests/test_aarch64_el2_observation_noalloc.cpp)
    slopos_target(slopos-test-aarch64-el2-observation-noalloc)
    target_link_libraries(slopos-test-aarch64-el2-observation-noalloc PRIVATE
      slopos_m0_aarch64_el2_observation)
    add_test(NAME aarch64-el2-observation-no-allocation
      COMMAND slopos-test-aarch64-el2-observation-noalloc)

    add_executable(slopos-test-qemu-el2-observer
      tests/test_qemu_el2_observer.cpp)
    slopos_target(slopos-test-qemu-el2-observer)
    target_link_libraries(slopos-test-qemu-el2-observer PRIVATE
      slopos_host_qemu_el2_observer)
    add_test(NAME qemu-el2-observer-supervisor
      COMMAND slopos-test-qemu-el2-observer
        ${PROJECT_SOURCE_DIR} ${SLOPOS_QEMU_AARCH64} ${SLOPOS_QEMU_ROOTFS})

    add_test(NAME aarch64-el2-observation-generated-current
      COMMAND slopos-aarch64-el2-observation --check --root ${PROJECT_SOURCE_DIR})
    add_test(NAME qemu-aarch64-toolchain-doctor
      COMMAND slopos-aarch64-el2-observation --qemu-doctor
        --root ${PROJECT_SOURCE_DIR}
        --qemu ${SLOPOS_QEMU_AARCH64}
        --qemu-rootfs ${SLOPOS_QEMU_ROOTFS})
    add_test(NAME aarch64-el2-observer-image-current
      COMMAND slopos-aarch64-el2-observation --image-check
        --root ${PROJECT_SOURCE_DIR}
        --qemu ${SLOPOS_QEMU_AARCH64}
        --qemu-rootfs ${SLOPOS_QEMU_ROOTFS})
    add_test(NAME qemu-aarch64-el2-live-observation
      COMMAND slopos-aarch64-el2-observation --live-witness
        --root ${PROJECT_SOURCE_DIR}
        --qemu ${SLOPOS_QEMU_AARCH64}
        --qemu-rootfs ${SLOPOS_QEMU_ROOTFS})
    set_tests_properties(aarch64-el2-observer-image-current PROPERTIES
      DEPENDS "qemu-aarch64-toolchain-doctor;aarch64-el2-observation-generated-current;aarch64-el2-observation-certificate")
    set_tests_properties(qemu-el2-observer-supervisor PROPERTIES
      DEPENDS "qemu-aarch64-toolchain-doctor;aarch64-el2-observer-image-current")
    set_tests_properties(qemu-aarch64-el2-live-observation PROPERTIES
      DEPENDS "qemu-aarch64-toolchain-doctor;aarch64-el2-observer-image-current;qemu-el2-observer-supervisor")

  set(SLOPOS_LEGACY_M0_TEST_DEPENDENCIES "static2-generated-current;static2-policy-plan-install;aarch64-s2-l3-generated-current;aarch64-s2-l3-value-image;aarch64-s2-placed-graph-generated-current;aarch64-s2-placed-graph-value;aarch64-s2-placement-packet-generated-current;aarch64-s2-placement-packet;aarch64-s2-owned-memory-generated-current;aarch64-s2-owned-memory-atomic-install;aarch64-s2-cold-activation-generated-current;aarch64-s2-cold-activation-value-machine;aarch64-s2-architecture-adequacy-generated-current;aarch64-s2-architecture-adequacy-certificate;aarch64-s2-instruction-generated-current;aarch64-s2-instruction-candidate;aarch64-s2-source-object-generated-current;aarch64-s2-source-object-specimen;aarch64-s2-object-assembler-doctor;aarch64-s2-source-object-assembler-current;aarch64-s2-loader-generated-current;aarch64-s2-loader-placement;aarch64-s2-visibility-generated-current;aarch64-s2-visibility-assessment;aarch64-s2-terminal-generated-current;aarch64-s2-terminal-contract;aarch64-s2-return-repair-generated-current;aarch64-s2-return-repair;aarch64-s2-caller-edge-generated-current;aarch64-s2-caller-edge-contract;aarch64-s2-caller-artifact-generated-current;aarch64-s2-caller-artifact-cascade;aarch64-s2-caller-artifact-assembler-doctor;aarch64-s2-caller-artifact-assembler-current;aarch64-s2-caller-readiness-generated-current;aarch64-s2-caller-readiness-assessment;aarch64-s2-host-publication-generated-current;aarch64-s2-host-publication-contract;aarch64-el2-observation-generated-current;aarch64-el2-observation-certificate;qemu-aarch64-toolchain-doctor;aarch64-el2-observer-image-current;qemu-el2-observer-supervisor;qemu-aarch64-el2-live-observation" PARENT_SCOPE)
endfunction()
