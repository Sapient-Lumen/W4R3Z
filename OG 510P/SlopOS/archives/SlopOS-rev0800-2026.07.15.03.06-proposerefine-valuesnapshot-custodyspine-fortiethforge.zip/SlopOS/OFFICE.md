# SlopOS office procedure — revision 0800

The office is the resumable state of the project, not a ceremony and not a proof.
All commands assume the repository root is current.

## Re-open

1. Verify the detached ZIP externally when a digest is available. An embedded digest
   cannot authenticate its own container.
2. Confirm one `SlopOS/` root, no source-tree build output, no symlink/special file,
   no second living tree, and no extracted external toolchain.
3. Read `spec/office/read-order.tsv` in order.
4. Configure `SLOPOS_BUILD_LEGACY_M0=OFF`. Historical M0/AArch64 work is explicit
   research, never ordinary closure authority.
5. Run `slopos-office audit`, `custody-audit`, and `resume` before changing claims.
6. Run `slopos-harness --authority-propose-refinement` before modifying the P0
   authority body or snapshot relation.
7. Treat absent Isabelle/QEMU as visible blocked gates. Source text and emulator
   history are not substitutes.

## Work law

- Change the smallest surface that closes one named edge.
- Preserve `vault/` bytes; promote bounded laws with source anchors, never edit
  history in place.
- Keep core, reference, and checker transition logic independent. Shared value
  declarations are permitted; shared authority/validation helpers are not.
- Treat `AuthorityValueSnapshot` as a copy-only observation, not storage, API
  authority, or persistence.
- Regenerate subject manifests only after the construction tree is quiescent.
- Evidence describes a basis and is excluded from that basis. It does not authorize
  the basis.
- Keep proposal, authority, admission, effect, observation, completion, evidence,
  and proof separately named.
- A denied operation frames every selected observable component unless its semantics
  explicitly say otherwise.
- No numeric identifier is reusable identity until generation, lineage, stale
  reference rejection, and reclamation are in the relation.

## External tool recovery

Recover proof/emulator layers outside the living tree by immutable digest, in a
resumable disposable cache. Verify before extraction and cap space/process use. A
failed recovery leaves the project untouched and the gate BLOCKED. Never copy a
predecessor proof result to a changed subject.

## Close a revision

1. Build and run all available active hosted tests under the declared compilers.
2. Record unavailable tools without euphemism.
3. Run proof-hole and TSV-shape checks.
4. Generate exact construction and custody manifests with `slopos-office`.
5. Run office/custody audits against those manifests.
6. Generate an OPEN receipt; `close-check` must remain nonzero while any required
   claim or gate is not current/pass.
7. Package one top-level `SlopOS/`, cold-extract it, rebuild the active lane, rerun
   audits/witnesses, compare embedded manifests, and keep the archive digest external.

A new actor resumes from `docs/office/HANDOFF.md`. Prefer correcting a false relation
or wasteful default over widening the machine.
