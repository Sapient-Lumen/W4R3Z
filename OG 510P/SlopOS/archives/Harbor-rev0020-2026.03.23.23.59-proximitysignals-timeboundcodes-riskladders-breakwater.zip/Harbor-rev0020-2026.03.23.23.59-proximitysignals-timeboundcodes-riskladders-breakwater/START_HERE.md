# Start here

This archive is still small on purpose. The immediate goal is not completeness; it is to keep the first durable separations honest while collecting good ideas without freezing them too early.

## What Harbor owns now
- exchange membrane; portal routing; callback/reentry discipline; verified-association humility; materialization versus grant honesty; aftermath receipts

## What changed in rev0020
- added a pass XIX research synthesis centered on resource audiences, scope splits, and auth targets;
- added a pass XIX evaluation against SlopOS plus the sibling cubes;
- added a sixteenth specimen selected to preserve optionality instead of freezing a universal object model;
- refreshed ledgers/manifests/context surfaces and reran hygiene checks.

## What to read first
- charter
- lessons we must learn
- pass XIX research synthesis
- specimen flow 16
- promotion gates and specimen tests

## What to avoid right now
- inflating the archive with giant registries before the object model is stable;
- letting successful turns or strong-looking evidence masquerade as durable local truth;
- letting one umbrella object quietly swallow neighboring strengths of fact.

## New in rev0020
- **resource audience** — new specimen noun collected this pass.
- **scope split** — neighboring strength kept distinct rather than folded into an older object.
- **auth target** — reminder of the new split this revision is protecting.
