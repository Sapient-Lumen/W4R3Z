# ADR 0002: Callbacks do not equal verdicts

- Status: accepted

Harbor records callback and return-path facts, but durable trust meaning and appraisal consequences belong in Ward.
