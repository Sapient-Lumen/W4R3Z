# ADR 0001: Harbor is an exchange membrane

- Status: accepted

## Context
The companion ecology needs one cube that owns route, admission, detour, outcome, and aftermath truth for crossings.

## Decision
Harbor is founded as the exchange membrane rather than a generic networking, browser, or filesystem cube.

## Consequences
Harbor can stay narrow enough to converse with Helm, Schell, ViewFS, Steward, Ward, and Foundry without swallowing them.
