# Specimen flow 06 — structured detour parcel and adoption clocks

This specimen exists to test whether Harbor can absorb structured-request pressure without pretending that a prepared ask, a returned proof, and a durable local consequence are all one thing.

## Scenario
A local client needs a browser-mediated approval turn for a fine-grained operation. The requested consequence is richer than a flat scope string. Some devices support newer dynamic route narrowing; older ones do not. The result may land in controlled document availability rather than a durable grant.

## Flow
1. The client prepares a **structured detour parcel** describing the requested consequence.
2. Harbor stages that parcel and emits only a route-facing detour reference for the browser leg.
3. Route selection proceeds under the current environment’s capabilities. A newer device may honor narrowed dynamic rules; an older one may ignore them and fall back differently.
4. The remote side returns a callback or proof-bearing response linked to the staged parcel.
5. Harbor records:
   - parcel reference,
   - route class used here,
   - any compatibility shadow (“narrowing honored here / not guaranteed elsewhere”),
   - callback proof class,
   - resulting availability class (opened, controlled availability, or no durable consequence).
6. Local adoption decides whether the aftermath becomes a durable object relation, durable account relation, or remains only an inspectable route result.

## What this specimen is trying to preserve
- Requested consequence is structured and inspectable.
- Browser detour carries less mutable state than the whole request.
- Route truth is honest about environment/version variance.
- Controlled availability stays stronger than route success.
- Durable adoption remains a later, explicit act.

## Candidate nouns under pressure
- **structured detour parcel**
- **compatibility shadow**
- **adoption clocks**
- **availability class**
- **route class used here**

## Kill criteria
Reject these nouns if any of the following happens:
- the parcel starts implying durable trust or durable grant by itself;
- the compatibility shadow is read as universal route truth;
- adoption clocks become mandatory architecture rather than a small honesty tool;
- Harbor starts swallowing ViewFS identity/grant language or Ward trust language.

## If Harbor survives the specimen
If Harbor *can* survive it, then pass X has found a promising smaller set:
- a prepared parcel smaller than durable consequence,
- a route result honest about compatibility variance,
- and separate clocks for parcel age, returned proof age, and durable adoption age.
