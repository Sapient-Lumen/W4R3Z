# Architecture overview

Harbor is strongest when it tells the truth about **crossing** rather than pretending crossing is itself success.

The founding Harbor chain is:

1. **request envelope** — what the caller is asking for;
2. **route set** — what routes are even eligible right now;
3. **admission decision** — which route was actually allowed;
4. **detour state** — chooser, browser, callback, provider-local wait, or user review;
5. **outcome class** — launch, reveal, open-in-place, materialize, grant, handback, or refusal;
6. **aftermath receipt** — what Harbor can honestly say happened and what stronger work remains elsewhere.

Harbor does **not** own:
- durable object identity (that pressure belongs with ViewFS),
- durable trust verdicts (that pressure belongs with Ward),
- runtime realization or continuity on foreign ground (that pressure belongs with Foundry),
- shell/compositor policy as a whole (that pressure belongs with Helm),
- or lifecycle/accounting truth for long-running work (that pressure belongs with Steward).

Harbor’s job is to make exchange events **legible** to those neighboring cubes without flattening them.

## rev0003 posture additions
- keep snapshot, callback, and provider success signals visibly weaker than durable local consequence;
- prefer one or two specimen artifacts before inventing family-wide registries;
- track downgrade and freshness as first-class modifiers instead of folding them into a success bit.
