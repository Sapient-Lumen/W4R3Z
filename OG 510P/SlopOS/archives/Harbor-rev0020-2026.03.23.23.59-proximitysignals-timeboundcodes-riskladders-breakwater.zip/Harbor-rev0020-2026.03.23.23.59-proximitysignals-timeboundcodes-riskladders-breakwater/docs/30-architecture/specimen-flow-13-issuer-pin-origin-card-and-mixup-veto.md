# Specimen flow 13 — issuer pin, origin card, and mix-up veto

Goal: keep callback continuity, authority identity, and local adoption visibly separate.

## Scenario
A local client supports two authorization authorities over time and eventually uses a shared callback surface.
A detour returns with exact route shape and an apparently valid code or continuation.
The finish also carries explicit authority identity.
Local policy refuses adoption because the finish came from a different authority than the one prepared for the crossing.

## Proposed Harbor objects
1. **issuer pin**
   - the expected authority identity for this crossing;
   - lives alongside route preparation without becoming durable account or grant truth.

2. **origin card**
   - compact residue about which authority actually emitted the finish;
   - stronger than plain callback arrival and weaker than durable local adoption.

3. **mix-up veto**
   - explicit local refusal when route/finish shape is plausible but authority identity diverges;
   - keeps the rejection accountable instead of flattening it into a generic callback failure.

4. **second-provider cliff**
   - reminder residue that a flow safe in a one-provider world became ambiguous after another authority was added.

## Why this specimen matters
It pressure-tests whether Harbor can remain honest when:
- the callback is exact,
- the finish is legitimate for *some* authority,
- and local policy still needs a typed veto because it is the *wrong* authority for this crossing.

## Promotion rule
Do not promote `issuer pin`, `origin card`, or `mix-up veto` unless they improve:
- one shared-callback specimen,
- one “single provider became two” specimen,
- and one clean callback that still fails local adoption on authority mismatch.
