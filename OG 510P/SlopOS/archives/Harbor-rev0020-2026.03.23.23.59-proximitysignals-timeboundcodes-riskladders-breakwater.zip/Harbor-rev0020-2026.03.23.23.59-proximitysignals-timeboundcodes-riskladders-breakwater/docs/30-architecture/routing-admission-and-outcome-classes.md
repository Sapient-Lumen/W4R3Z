# Routing, admission, and outcome classes

Harbor begins by freezing a low-regret distinction:

- **routing** asks which paths are possible;
- **admission** asks which path is allowed now;
- **outcome** asks what kind of thing actually happened.

Those are not the same facts.

A URI, imported provider hint, or share target may have many imaginable routes:
browser detour, chooser surface, direct open, local materialization, delegated handoff, or visible refusal.
Harbor exists so neighboring cubes do not have to infer one of those facts from another.

## Outcome classes worth keeping separate

1. **Reveal** — show a thing or route without granting stronger authority.
2. **Launch** — ask another surface or service to begin doing work.
3. **Open-in-place** — hand out scoped access while the source stays authoritative.
4. **Materialize** — produce a fresh local or shell-owned object.
5. **Grant** — produce an explicit follow-on capability for some next step.
6. **Handback** — return a result, callback token, or selected route to the caller.
7. **Refuse** — block with a reason that remains inspectable.

## Guardrails

- chooser success is not launch success;
- callback arrival is not consent success;
- successful open is not durable grant persistence;
- materialized bytes are not proof that the source route was trusted;
- reveal is not equivalent to authority.
