# Specimen flow 02 — verified association to controlled import

This specimen is intentionally chosen because old ecosystems blur three things that should stay separate:
1. a route looks affiliated with an app or site;
2. a detour or opener really happened;
3. a durable local object or grant now exists.

Harbor should preserve the split.

## Flow sketch

### 1. Route offer arrives
A route offer carries:
- a subject (`https://…`, `file://…`, or provider-local route token),
- optional affiliation material (Digital Asset Links, associated-domain material, provider self-description, registry metadata),
- and the current request context.

At this stage Harbor may mint a **route offer** or **request envelope**, but not a durable trust object.

### 2. Affiliation appraisal happens locally
The system may conclude any of the following:
- no usable affiliation evidence,
- weak affiliation hint,
- verified affiliation relation,
- or conflict between claims.

The output is an **affiliation hint card**, not a grant and not a winner-takes-all handler verdict.

### 3. A detour is admitted under lease
If the system chooses to leave the local surface (browser detour, external opener, provider-owned chooser), Harbor mints a **detour lease** with:
- expected return class,
- expiry,
- restart/reset behavior,
- and minimal aftermath promises.

### 4. Return-path proof is classified
On return, Harbor records one proof class such as:
- exact-match callback proof,
- claimed-HTTPS association return,
- local receipt-only completion,
- or no bindable return.

This stays a **route proof class**, not a trust verdict.

### 5. Optional handoff into controlled import
Only if the flow explicitly requests controlled import/materialization does Harbor hand into a ViewFS-adjacent lane that may mint:
- a controlled local object,
- a temporary carrier,
- or a refusal / quarantine result.

That handoff should produce a visibly separate aftermath receipt.

## What this specimen is testing
- Can one vocabulary hold affiliation hints, detour leases, and proof classes without turning them into giant universal route truths?
- Can Harbor stop before object truth and still remain useful?
- Can the same aftermath language support both “opened elsewhere” and “materialized locally” without lying?

## Non-decisions preserved
- no universal handler registry;
- no universal verified-link trust object;
- no universal grant object;
- no guarantee that an affiliated route becomes a preferred route.
