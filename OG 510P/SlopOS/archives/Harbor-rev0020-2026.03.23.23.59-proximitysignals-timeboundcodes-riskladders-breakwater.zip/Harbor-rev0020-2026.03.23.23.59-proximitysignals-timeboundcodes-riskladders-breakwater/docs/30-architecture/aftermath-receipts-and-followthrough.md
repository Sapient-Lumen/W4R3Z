# Aftermath receipts and followthrough

Harbor should never end its story at “the request returned”.

Many crossings only become useful after a visible aftermath:
- a launched tool may still need Steward-owned readiness truth;
- a materialized object may still need ViewFS-owned identity and placement truth;
- a returned auth artifact may still need Ward-owned appraisal;
- a foreign launch may still need Foundry-owned runtime evidence.

Harbor therefore exports **aftermath receipts** that are intentionally modest.

A good Harbor receipt says:
- what route was actually taken,
- which detours happened,
- what outcome class occurred,
- which neighboring cube now owns the next stronger truth,
- and what remained unresolved.

That keeps Harbor from bluffing completeness just because it was the first membrane crossed.
