# Specimen flow 04 — ephemeral browser detour and fallback ladder

This specimen exists to pressure-test a browser-auth or associated-domain route *without* letting Harbor overclaim what came back.

## Story

A local tool wants to initiate a sign-in or account-linking turn. It prefers an associated native route if available, but it is also willing to use a browser detour and to fall back to a website if native handling is unavailable. The tool requests that the browser turn be **ephemeral** so prior cookies and browsing residue are not reused if the platform supports that posture.

## Candidate objects

- **request envelope** — what the local claimant asked Harbor to do.
- **route set** — declared preferred route classes (associated native route, browser detour, website fallback).
- **detour isolation request** — a typed request for an ephemeral/isolated browser turn, distinct from route proof or trust consequence.
- **association hint** — affiliation material suggesting that an app and site belong together, still weaker than current route truth.
- **fallback ladder** — the ordered route classes and the actual landing point.
- **return fence** — the detour came back, but local rebound or adoption is still required.
- **aftermath receipt** — the final Harbor-visible outcome class.

## Flow

1. A caller submits a request envelope with a preferred route set.
2. Harbor consults local declarations plus affiliation hints. Hints may narrow or refine choice, but they do not silently widen native eligibility.
3. The platform either:
   - takes the preferred native route,
   - launches an ephemeral browser detour,
   - or falls back to the website/browser path.
4. A callback or return may arrive. Harbor records **callback proof** or **return evidence**, but not durable account truth.
5. If the return path, claimant, or device rebound is weak, Harbor emits a **return fence** / **rebound-needed** aftermath.
6. Only after local adoption does a stronger sibling handoff occur:
   - Ward for durable trust or account consequence,
   - ViewFS if controlled import/materialization starts,
   - Steward if there is an explicit follow-on action.

## Anti-collapses this specimen protects

- ephemeral browser session ≠ stronger trust
- association hint ≠ current route truth
- callback arrival ≠ durable success
- website fallback ≠ route failure
- same-brand app/site relation ≠ local adoption

## What to watch

If Harbor cannot describe this specimen without smuggling browser session state, affiliation, callback proof, and durable consequence into one blob, then its object model is still too early.
