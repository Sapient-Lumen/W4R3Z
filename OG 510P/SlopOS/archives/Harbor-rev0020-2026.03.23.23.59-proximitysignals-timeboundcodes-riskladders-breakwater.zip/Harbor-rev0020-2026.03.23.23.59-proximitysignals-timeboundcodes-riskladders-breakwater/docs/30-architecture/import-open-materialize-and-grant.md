# Import, open, materialize, and grant

Harbor should preserve a four-way separation that other systems routinely blur:

- **import** — admit outside material into the local ecology;
- **open-in-place** — keep source authority outside but grant scoped access;
- **materialize** — create a fresh local artifact or object derived from the crossing;
- **grant** — create explicit follow-on authority for later work.

The separation matters because one event may lead to another without being the same event.

Examples:
- a chooser can end in an open grant without materialization;
- a dropped object can materialize locally without preserving any enduring route back to the source;
- a callback may produce a grant without any visible imported artifact;
- a preview can reveal enough for review but still not authorize materialization.

Harbor therefore wants to keep both **fresh identity** and **lineage** visible:
a newly materialized thing should be able to say what crossing produced it, while still being honest that it is now a different local object class.
