# Specimen flow 05 — pushed auth request and proof-bound return

This specimen is intentionally narrow. It exists to pressure-test one modern auth-shaped membrane without deciding that Harbor is “the auth cube”.

## The situation

A local tool needs the user to complete a browser-based authorization turn.
The modern ecosystem pressure is:
- stage as much request intent as possible off the browser leg,
- keep the browser-visible turn user-controlled,
- and make the return exchange harder to replay.

That points toward a shape inspired by PAR + PKCE + DPoP, but Harbor should steal only the membrane lessons it can own honestly.

## Candidate Harbor objects

### 1) Auth parcel (candidate)
A prepared detour intent that:
- was staged before the user-visible browser turn,
- may have a provider-local backing request payload,
- may expose only an opaque request reference to the detour path,
- is smaller than a durable continuation or account relation.

Open question:
should Harbor own this as a first-class object, or merely record that a route was backed by provider-staged state?

### 2) Detour lease (candidate)
A bounded interval between local initiation and return.
It can expire, be cancelled, or return weakly.
It does **not** imply the system may poll, replay, or resume indefinitely.

### 3) Callback proof (candidate)
Evidence that a return is linked to the initiating flow.
This may be stronger than “some callback happened” and weaker than “the same local claimant may now spend”.

### 4) Proof-bound exchange (candidate)
A local follow-on exchange that is linked to the initiating flow and resists replay better than a plain bearer-shaped return.
This is where DPoP is inspirational: Harbor can observe that the return exchange was proof-bound without turning Harbor into the final trust authority.

### 5) Adoption gate (candidate)
The point where a useful return either becomes a local next step or remains merely informative.
This keeps Harbor honest when the return is operationally helpful but not yet durable local truth.

## Walkthrough

1. A local initiator prepares an auth parcel.
2. The parcel is staged provider-side or request-side and yields a detour-ready opaque reference.
3. Harbor launches a browser detour under user-controlled routing.
4. The detour returns a callback or equivalent local re-entry signal.
5. The system evaluates callback proof:
   - same initiating flow?
   - same local claimant?
   - same route context?
6. A follow-on exchange may occur and may be proof-bound rather than plain bearer-shaped.
7. Harbor records aftermath without overclaiming:
   - detour returned,
   - callback proof strength,
   - exchange proof posture,
   - whether local adoption happened.

## The anti-collapse rules

- The opaque request reference is **not** a durable continuation broker.
- Callback proof is **not** the same as durable account relation.
- Proof-bound exchange is **not** the same as local spendable trust.
- Browser detour posture is **not** the same as browser-session truth.
- Harbor records the membrane honestly and then hands off.

## Why this specimen matters
If Harbor cannot survive this specimen without collapsing into Ward or into generic orchestration, then the candidate nouns are too big.

If Harbor *can* survive it, then pass VIII has found a promising small vocabulary:
- auth parcel,
- detour lease,
- callback proof,
- proof-bound exchange,
- adoption gate.

That is still only a candidate set, but it is a better candidate set than one giant “auth success” object.
