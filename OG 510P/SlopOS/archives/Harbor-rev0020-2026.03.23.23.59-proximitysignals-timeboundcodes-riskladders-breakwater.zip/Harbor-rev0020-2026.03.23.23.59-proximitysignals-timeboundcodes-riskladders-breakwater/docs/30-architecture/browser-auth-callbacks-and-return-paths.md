# Browser auth, callbacks, and return paths

Harbor must absorb modern auth detours without becoming the durable trust cube.

The right split looks like this:

- Harbor owns **browser detours, callback shaping, state continuity, and visible return-path receipts**.
- Ward owns **credential meaning, trust roots, proof interpretation, and durable local verdicts**.

This keeps three temptations under control:

1. treating a browser round-trip as if it were already a durable trust judgment;
2. treating callback arrival as if it proved the same thing as a local user approval;
3. letting provider-local session state leak outward as native system truth.

Harbor therefore wants explicit artifacts like:

- `RouteRequest`
- `AdmissionReceipt`
- `BrowserDetourWitness`
- `CallbackReceipt`
- `OutcomeReceipt`

Any durable credential, account binding, or local trust consequence produced later should be handed to Ward rather than trapped inside Harbor.
