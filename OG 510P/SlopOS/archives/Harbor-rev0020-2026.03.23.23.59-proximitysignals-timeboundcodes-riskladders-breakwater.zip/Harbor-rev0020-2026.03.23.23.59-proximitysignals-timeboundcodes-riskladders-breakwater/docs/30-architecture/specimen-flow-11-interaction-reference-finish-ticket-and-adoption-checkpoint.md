# Specimen flow 11 — interaction reference, finish ticket, and adoption checkpoint

Goal: keep continuation liveness, finish method, and local adoption visibly separate even when one crossing can finish in several ways.

## Scenario
A local client starts a native-first approval. The authorization service may:
- finish through a redirected callback,
- hand off through a device-flow style ticket,
- or escalate to browser completion because native interaction is not sufficient.

Across all cases, the client receives a bounded way to continue or resume the crossing.

## Proposed Harbor objects
1. **interaction ref**
   - names the still-live crossing without claiming durable success;
   - expires independently of any later account binding or local adoption.

2. **finish ticket**
   - carries just enough material for the next completion step;
   - may be a callback proof, a `verification_uri_complete` packet, or a browser-escalation instruction.

3. **adoption checkpoint**
   - records the explicit local turn where a clean finish becomes durable local consequence;
   - may veto or narrow the consequence even after a legitimate finish.

## Why this specimen matters
It pressure-tests whether Harbor can remain honest when:
- one crossing has several legitimate finish modes,
- continuation is useful before success is durable,
- and cross-device/browser escalation is not an edge case.

## Promotion rule
Do not promote `interaction ref`, `finish ticket`, or `adoption checkpoint` unless they improve:
- one same-device callback specimen,
- one cross-device/user-code specimen,
- and one browser-escalation specimen.
