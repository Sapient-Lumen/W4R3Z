# Specimen flow 07 — consent parcel, return lease, and compatibility floor

This specimen exists to test whether Harbor can keep staged intent, successful return, and durable adoption visibly separate.

## Scenario
A local client prepares a browser-mediated turn for a structured ask. Some environments support richer route narrowing; others only support a lower common floor. The remote side returns a proof-bearing callback, but local adoption is still optional.

## Flow
1. The client prepares a **consent parcel** describing the requested consequence.
2. Harbor stages the parcel and emits only the minimal route-facing reference needed for the detour.
3. Harbor records the **compatibility floor** for this class of route: what is guaranteed everywhere versus what only newer environments may honor.
4. The route proceeds and may take a richer path or a fallback path.
5. On return, Harbor emits a **return lease** that says what can be claimed now:
   - same staged flow linkage,
   - route class used here,
   - fallback path taken if any,
   - controlled-availability aftermath if any,
   - explicit expiry for this temporary linkage.
6. Local policy may still veto durable adoption during an **adoption veto window**.
7. Only after explicit local adoption does any stronger local consequence exist.

## What this specimen is trying to preserve
- Prepared intent stays smaller than browser detour.
- Browser success stays smaller than durable local consequence.
- Compatibility variance is made visible without becoming universal doctrine.
- Fallback path becomes inspectable residue, not hidden folklore.
- Durable adoption remains an explicit later act.

## Candidate nouns under pressure
- **consent parcel**
- **return lease**
- **compatibility floor**
- **fallback memory**
- **adoption veto window**

## Kill criteria
Reject these nouns if any of the following happens:
- the parcel starts implying durable trust or grant by itself;
- the return lease is read as permanent truth instead of a temporary linkage object;
- the compatibility floor becomes an overgrown deployment taxonomy;
- Harbor starts swallowing ViewFS identity or Ward trust semantics.

## If Harbor survives the specimen
If Harbor *can* survive it, then pass X has found a promising smaller set:
- a staged ask smaller than the detour,
- a temporary return object smaller than durable consequence,
- and an honest baseline for route compatibility across environments.
