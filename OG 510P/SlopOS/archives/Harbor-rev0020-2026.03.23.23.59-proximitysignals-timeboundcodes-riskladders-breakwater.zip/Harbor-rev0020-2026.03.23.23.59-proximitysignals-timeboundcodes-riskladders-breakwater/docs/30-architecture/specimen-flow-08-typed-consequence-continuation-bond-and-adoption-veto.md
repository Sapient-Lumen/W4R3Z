# Specimen flow 08 — typed consequence, continuation bond, and adoption veto

This specimen exists to test whether Harbor can keep staged intent, proof-bearing return, and durable local consequence separate even when the detour is well-hardened.

## Scenario
A local client prepares a browser-mediated authorization turn with a typed requested consequence. The return path is exact, PKCE-bound, and the follow-on token exchange is sender-constrained. Even so, local adoption remains optional.

## Flow
1. The client prepares a **typed consequence card** describing the requested consequence before any detour begins.
2. Harbor stages a detour using the smallest outward route reference it can.
3. Harbor records the declared return target and the expected exactness class for the continuation.
4. The browser detour succeeds and returns to the declared target.
5. Harbor emits a **continuation bond** that says only what is now supportable:
   - which prepared crossing it links to,
   - how exact the return match was,
   - whether PKCE-style proof completed,
   - whether any proof-bound exchange succeeded,
   - when this temporary linkage expires.
6. Harbor **does not** yet mint durable local consequence.
7. Local policy or user review may apply an **adoption veto** even after the continuation bond exists.
8. Only if adoption explicitly occurs does a stronger local consequence exist, and that stronger consequence must still be typed separately from the bond.

## What this specimen is trying to preserve
- typed requested consequence remains smaller than the detour;
- continuation proof remains smaller than durable trust or durable local adoption;
- exact redirect matching and proof-bound exchange are informative without becoming identity verdicts;
- local refusal remains honest even after a technically clean continuation.

## Candidate nouns under pressure
- **typed consequence card**
- **continuation bond**
- **redirect exactness receipt**
- **adoption veto**
- **consequence split**

## Kill criteria
Reject these nouns if any of the following happens:
- the typed consequence card starts implying durable grant or trust on its own;
- the continuation bond survives long enough or looks strong enough to impersonate local durable truth;
- redirect exactness starts getting used as an identity or trust verdict;
- Harbor begins swallowing Ward trust semantics or ViewFS durable-identity semantics.

## If Harbor survives the specimen
If Harbor *can* survive it, then pass XI has found a promising smaller set:
- one object for staged request shape,
- one temporary object for proof-bearing continuation,
- and one explicit local refusal point before durable adoption.
