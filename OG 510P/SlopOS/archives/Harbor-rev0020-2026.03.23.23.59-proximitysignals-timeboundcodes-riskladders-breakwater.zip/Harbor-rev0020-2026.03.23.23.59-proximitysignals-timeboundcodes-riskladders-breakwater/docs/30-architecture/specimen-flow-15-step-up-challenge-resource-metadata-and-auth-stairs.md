# Specimen flow 15 — step-up challenge, resource metadata, and auth stairs

Goal: keep resource-originated assurance escalation, route discovery, and durable local adoption visibly separate.

## Scenario
A local client calls a protected resource with a valid access token.
The resource responds with `insufficient_user_authentication` and indicates stronger or fresher user authentication is required.
The challenge also points at protected resource metadata, which the client fetches and cross-checks before starting a browser detour to the correct authorization server.
The higher-assurance finish comes back cleanly, but local policy still decides whether the request becomes durable consequence.

## Proposed Harbor objects
1. **step-up challenge**
   - a typed route object saying the request was understood but the current assurance rung is too weak;
   - stronger than generic failure and weaker than durable consequence.

2. **resource metadata card**
   - compact discovery residue from the resource edge: resource identity, acceptable authorization servers, and supported scope hints;
   - stronger than folklore and weaker than durable trust.

3. **auth stair**
   - the same task continuing on a higher assurance rung;
   - useful because the rebound does not have to erase the original request shape.

4. **cross-check before climb**
   - standing reminder that route hints from the resource and the authorization side should be compared before the next detour.

## Why this specimen matters
It pressure-tests whether Harbor can remain honest when:
- the current token is real but insufficient,
- the resource edge teaches the client where to go next,
- the next detour succeeds at a higher assurance rung,
- and local adoption still stays separate.

## Promotion rule
Do not promote `step-up challenge`, `resource metadata card`, `auth stair`, or `cross-check before climb` unless they improve:
- one resource-originated step-up specimen,
- one metadata-guided rebound specimen,
- and one higher-assurance finish that still fails local adoption.
