# Specimen flow 03 — file-transfer middleman, route reset, and rebound-needed aftermath

This specimen is intentionally modest. It exists to keep Harbor from pretending that copy/paste, drag/drop, open, import, and materialize are one story.

## Scenario
A user drags a file-like thing from one app into another. The platform mediates the transfer through a middle-man exchange surface rather than handing broad direct path authority to the destination.

## Desired separations
- **route request** — “I want to transfer this”
- **middle-man exchange handle** — a temporary mediated carrier for the transfer
- **controlled import aftermath** — the destination may choose to materialize under stronger local rules later
- **route reset surface** — remembered route/default state can be reset back to pre-choice posture
- **return fence / rebound-needed aftermath** — the transfer was delivered, but durable local adoption still has to happen explicitly

## Flow sketch
1. Source emits a transfer request into Harbor with a declared payload class.
2. Harbor chooses a mediated exchange path, not a fake direct-open path.
3. Destination receives a middle-man exchange handle.
4. Destination may:
   - inspect and reject,
   - consume transiently,
   - ask ViewFS for controlled import/materialization,
   - or request a stronger durable grant.
5. Harbor emits an aftermath receipt that says what actually happened:
   - delivered-transiently,
   - expired-unclaimed,
   - rebound-needed,
   - or handed-off-to-controlled-import.

## Why this specimen matters
Without it, Harbor is at constant risk of lying in one of two directions:
- pretending that mediated transfer was already durable local adoption, or
- pretending that every exchange should be modeled as a generic “open”.

## Promotion test
This specimen is promotable only if the same Harbor nouns can still stay honest when:
- the payload is not a file but a route envelope,
- the transfer crosses a browser detour or provider callback,
- or the route state has been reset to a pre-choice posture before rehearing.
