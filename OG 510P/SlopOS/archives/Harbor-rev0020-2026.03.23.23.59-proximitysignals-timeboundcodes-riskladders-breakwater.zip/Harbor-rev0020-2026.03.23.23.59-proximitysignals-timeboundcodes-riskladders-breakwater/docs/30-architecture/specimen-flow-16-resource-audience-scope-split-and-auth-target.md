# Specimen flow 16 — resource audience, scope split, and auth target

Goal: keep requested power, redeeming resource, and local adoption visibly separate.

## Scenario
A local client asks for two kinds of access that use similar-looking scopes, but only one token should be redeemable at the mail API and not at the calendar API.
The detour begins with an explicit resource indicator, fetches protected-resource metadata, and cross-checks the listed authorization server before the browser leg starts.
The finish comes back with enough information to redeem at the intended resource, but local policy still verifies that the returned audience matches the original target before adoption.

## Proposed Harbor objects
1. **resource audience**
   - typed residue saying where the token is expected to be redeemed;
   - stronger than scope folklore and weaker than durable local trust.

2. **scope split**
   - reminder that `what` was requested and `where` it will be redeemed are different axes;
   - useful because one should not silently stand in for the other.

3. **auth target**
   - compact card naming the protected resource that shaped the detour and later adoption check;
   - stronger than provider brand and weaker than final permission.

4. **cross-check rail**
   - standing rule that resource metadata and authorization metadata should agree before local adoption proceeds.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- scopes are shared across multiple resources,
- the right authorization server is dynamically discovered,
- the finish is structurally valid,
- and yet local policy still vetoes adoption because the redeeming audience drifted.

## Promotion rule
Do not promote `resource audience`, `scope split`, `auth target`, or `cross-check rail` unless they improve:
- one shared-scope / different-resource specimen,
- one metadata-guided audience check,
- and one technically successful finish that still fails local adoption because the target was wrong.
