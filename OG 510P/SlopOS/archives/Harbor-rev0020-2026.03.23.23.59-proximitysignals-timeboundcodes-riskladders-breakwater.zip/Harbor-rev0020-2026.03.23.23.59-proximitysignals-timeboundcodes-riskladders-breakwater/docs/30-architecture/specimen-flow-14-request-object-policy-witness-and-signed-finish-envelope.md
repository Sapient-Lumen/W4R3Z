# Specimen flow 14 — request object, policy witness, and signed finish envelope

Goal: keep prepared intent, protected finish, and durable local adoption visibly separate.

## Scenario
A local client prepares an authorization crossing using a detached request object.
A trusted third party signs that prepared request as compliant with a narrower policy.
The authorization server fetches the request by reference and the user completes the browser detour.
The finish returns as a signed JWT envelope, but local policy still decides whether the crossing becomes durable local consequence.

## Proposed Harbor objects
1. **request object**
   - the prepared crossing intent, separable from the browser leg;
   - can be carried by value or by reference without becoming durable local truth.

2. **policy witness**
   - third-party signed residue that the prepared request satisfied a narrower policy;
   - stronger than an unreviewed request and still weaker than final local adoption.

3. **signed finish envelope**
   - protected finish material that carries issuer/audience/expiry plus response parameters;
   - stronger than plain callback arrival and weaker than durable local consequence.

4. **request/finish symmetry**
   - reminder residue that both the outbound request and the inbound finish can be integrity-bearing without becoming the same object.

## Why this specimen matters
It pressure-tests whether Harbor can remain honest when:
- the browser leg is intentionally small,
- the prepared request is already policy-reviewed,
- the finish comes back cryptographically protected,
- and local policy still needs an explicit adoption turn.

## Promotion rule
Do not promote `request object`, `policy witness`, or `signed finish envelope` unless they improve:
- one by-reference request specimen,
- one reviewed-policy specimen,
- and one signed finish that still fails local adoption.

