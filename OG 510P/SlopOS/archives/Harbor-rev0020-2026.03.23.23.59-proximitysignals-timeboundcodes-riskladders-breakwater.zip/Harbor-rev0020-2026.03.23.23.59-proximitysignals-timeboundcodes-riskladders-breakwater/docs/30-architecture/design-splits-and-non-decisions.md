# Design splits and non-decisions

## Splits Harbor is freezing early
- route eligibility versus admission decision;
- browser detour versus durable trust meaning;
- import/open/materialize/grant outcome classes;
- callback arrival versus completed consequence;
- aftermath receipt versus neighboring-cube completion.

## Non-decisions still open
- whether Harbor needs a single generic request envelope or a family of narrowly typed ones;
- how much route explanation belongs in the receipt versus a separate trace object;
- whether chooser, callback, and provider wait states should share one lifecycle vocabulary;
- how far Harbor should go in representing speculative routes that were never offered to the user;
- whether materialization lineage is a Harbor export or merely a handoff hint to ViewFS.

## Process non-decisions
- do not create a boundary-family map until at least three recurring seams have earned it;
- do not create a giant registry or schema family until at least two specimen tests need it;
- do not let a convenience integration define the cube’s permanent object model.

## rev0019 pressure note
- request object versus browser-visible leg;
- signed finish envelope versus durable local adoption;
- third-party policy witness versus local adoption.
