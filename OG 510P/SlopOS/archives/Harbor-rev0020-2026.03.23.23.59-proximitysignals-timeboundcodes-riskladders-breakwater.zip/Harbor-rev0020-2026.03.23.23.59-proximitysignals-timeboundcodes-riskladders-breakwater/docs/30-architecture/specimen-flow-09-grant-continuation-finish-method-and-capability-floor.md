# Specimen flow 09 — grant continuation, finish method, and capability floor

Goal: keep a richly-typed crossing alive across a detour without letting the continuation impersonate durable local success.

## Scenario
A local companion wants a reviewed consequence that may complete through:
- redirected browser return,
- direct backchannel completion,
- application URI rebound,
- or visible degradation to a web-only or chooser-only outcome.

## Proposed Harbor objects
1. **typed consequence card**
   - says what is being asked for;
   - remains smaller than any eventual local adoption.

2. **continuation shelf**
   - carries the live continuation locus and what finish methods remain legitimate;
   - expires independently from the original request card and independently from any later adoption.

3. **finish method card**
   - states which completion class actually occurred:
     - redirected callback,
     - direct completion,
     - app rebound,
     - user-code completion,
     - weak/no finish.

4. **capability floor**
   - the weakest still-true post-crossing statement, such as:
     - “request staged”,
     - “interaction completed but not locally adopted”,
     - “resource provider accepted but no durable local relation minted”.

## Why this specimen matters
It pressure-tests a cleaner split than “success/failure”:
request intent, liveness of the crossing, completion class, and local adoption each stay independently inspectable.

## Promotion rule
Do not promote `continuation shelf`, `finish method card`, or `capability floor` unless Harbor can show that they improve at least one browser flow, one app-link/application-URI flow, and one degraded/non-callback flow.
