# Promotion gates and specimen tests

Harbor should not promote a new durable noun unless it survives at least one specimen flow.

## Promotion gates
1. A proposed object must clearly name which stronger truths it refuses to claim.
2. It must survive one browser-based flow and one non-browser portal flow without changing meaning.
3. It must name which sibling cube owns the next stronger consequence.
4. It must not require Harbor to infer durable trust, object identity, or runtime continuity on its own.

## First specimen tests
- external-browser OAuth or MCP-style auth with exact callback proof classes;
- open-versus-import-versus-materialize comparison with explicit ViewFS handoff;
- verified association plus chooser flow where affiliation, eligibility, selection, and trust remain separate;
- provider-local session hint that improves UX without becoming durable native truth.
