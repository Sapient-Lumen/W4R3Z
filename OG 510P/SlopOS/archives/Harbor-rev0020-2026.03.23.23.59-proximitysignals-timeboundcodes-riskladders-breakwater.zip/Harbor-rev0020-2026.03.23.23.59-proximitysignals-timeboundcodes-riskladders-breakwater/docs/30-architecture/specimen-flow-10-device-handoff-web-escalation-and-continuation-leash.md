# Specimen flow 10 — device handoff, web escalation, and continuation leash

Goal: keep cross-device approval and risk-driven web escalation honest without pretending they are the same as a clean same-route callback.

## Scenario
A local client starts a native-first approval interaction. Three outcomes remain possible:
- direct native challenge completion,
- a device-flow style handoff that asks the user to finish on a secondary device with a user code,
- or a server-directed `redirect_to_web` escalation because account recovery or a higher-risk method requires a browser.

## Proposed Harbor objects
1. **handoff docket**
   - tells the user exactly what to do elsewhere;
   - may include a verification URI, short user code, or other bounded cross-device instructions.

2. **continuation leash**
   - keeps the current crossing reopenable for polling, challenge follow-up, or later pickup;
   - expires independently of any later local adoption.

3. **web escalation card**
   - says the provider intentionally moved completion into the browser;
   - records why the local challenge was not sufficient.

4. **local adoption gate**
   - keeps “approved elsewhere” distinct from “adopted here”.

## Why this specimen matters
It pressure-tests whether Harbor can remain truthful across:
- same-device completion,
- cross-device completion,
- and browser escalation,
without flattening them into generic success.

## Promotion rule
Do not promote `handoff docket`, `web escalation card`, or `continuation leash` unless they improve one same-device callback specimen, one device-code/cross-device specimen, and one degraded no-return specimen.
