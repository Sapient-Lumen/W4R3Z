# Specimen flow 17 — proximity signal, timebound code, and risk ladder

Goal: keep cross-device handoff material bounded, contextual, and smaller than local adoption.

## Scenario
A user begins a session-transfer or device-authorization flow on a large shared screen and completes the approval on their phone.
The transfer code is short-lived and single-use, and the system gathers one or more proximity signals before offering the most powerful completion path.
If the devices appear implausibly far apart, or if the handoff code was replayed or copied into a new context, the flow can still continue at a lower-risk rung or demand extra review instead of pretending the crossing was clean.

## Proposed Harbor objects
1. **proximity signal**
   - bounded evidence that the consumption device and authorization device are plausibly near each other;
   - stronger than route folklore and weaker than durable trust.

2. **timebound code**
   - handoff token that is explicitly short-lived and limited-use;
   - stronger than a generic URL and weaker than a durable continuation.

3. **risk ladder**
   - typed follow-on path that can narrow, step up, or veto based on attack signals;
   - stronger than a warning and weaker than a final verdict.

4. **initiation verification**
   - explicit check that the user understands which device or task actually started the flow;
   - important because clean callback shape is not enough in cross-device settings.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- the unauthenticated gap between devices is attackable,
- some proximity evidence is available but imperfect,
- handoff material is intentionally brief and replay-resistant,
- and the safest truthful outcome is a narrowed or stepped-up continuation rather than generic success.

## Promotion rule
Do not promote `proximity signal`, `timebound code`, `risk ladder`, or `initiation verification` unless they improve:
- one same-room cross-device approval specimen,
- one distant-device anomaly specimen,
- and one copied-code exploit specimen that still yields honest weak aftermath instead of magical success.
