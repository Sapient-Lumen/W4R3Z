# Specimen flow 12 — backchannel challenge, finish envelope, and veto floor

Goal: keep out-of-band challenge, integrity-bearing finish, and local narrowing visibly separate.

## Scenario
A local native client starts an approval using a direct or backchannel-style challenge.
The user completes strong interaction on another device or a privileged surface not controlled by the local client.
Later, the local client receives a bounded finish packet with integrity protection or strong binding to the earlier challenge.
Local policy still refuses to mint the strongest possible consequence because route posture, device continuity, or review context is weaker than desired.

## Proposed Harbor objects
1. **backchannel challenge**
   - names the in-flight crossing without claiming where or how the user will finish it;
   - can outlive one local UI surface without becoming a durable session object.

2. **finish envelope**
   - carries the structured or signed completion residue;
   - says enough to prove continuity with the earlier challenge but remains smaller than durable local trust or grant.

3. **finish provenance**
   - records whether completion came through redirected callback, out-of-band user code, poll/ping, or browser escalation.

4. **veto floor**
   - records the weakest still-true local aftermath after the finish is locally narrowed or refused;
   - keeps legitimate finish distinct from locally adopted consequence.

## Why this specimen matters
It pressure-tests whether Harbor can remain honest when:
- the user interaction happens away from the consumption device,
- the finish packet has real integrity,
- and the local system still chooses not to fully adopt the outcome.

## Promotion rule
Do not promote `backchannel challenge`, `finish envelope`, or `veto floor` unless they improve:
- one same-device callback specimen,
- one out-of-band or cross-device specimen,
- and one locally-vetoed finish specimen.
