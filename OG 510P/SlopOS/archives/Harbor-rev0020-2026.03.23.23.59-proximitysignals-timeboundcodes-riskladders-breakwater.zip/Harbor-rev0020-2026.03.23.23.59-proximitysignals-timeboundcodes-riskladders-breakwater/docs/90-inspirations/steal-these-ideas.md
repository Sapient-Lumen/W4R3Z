# Steal these ideas

## From outside systems
- XDG portals: keep exchange mediated and user-controlled instead of turning convenience into ambient authority.
- Android and Apple link systems: treat affiliation as real but weaker than present route truth; keep graceful fallback explicit.
- `ASWebAuthenticationSession` ephemeral mode: isolate detours without pretending isolation upgrades trust.
- FedCM: let the browser mediate identity without making browser UI count as total local consent.
- MCP authorization/discovery: keep metadata and callback exactness useful, but smaller than durable route verdicts.
- PAR: move more mutable intent off the browser leg and into a prepared, referenceable parcel.
- DPoP: make return exchange harder to replay without confusing proof-of-possession with durable trust.

## From sibling cubes
- Helm: reset cards, review surfaces, and inspectable chooser residue are product features.
- Schell: provider/helper returns often need explicit adoption instead of automatic promotion.
- ViewFS: open, import, materialize, and durable identity must not collapse.
- Steward: aftermath names should stay typed and accountable.
- Ward: browser success still needs local appraisal before it becomes durable trust.
- Foundry: crossings that land in foreign ground need especially truthful aftermath receipts.

## New steals for rev0008
1. **Opaque auth parcel** — let the detour carry a reference instead of the whole mutable request.
2. **Request reference** — an expiring handle to one prepared detour intent.
3. **Proof-bound return** — linkage strong enough to resist replay better than plain callback success.
4. **Detour-binding card** — explain what the system knows about same-flow / same-claimant / same-session without overclaiming.
5. **Aging split** — request references, callback proofs, and durable adoptions should age on different clocks.
## New steals for rev0011
1. **Typed consequence card** — a staged request object that says what is being asked before any detour succeeds.
2. **Continuation bond** — a temporary proof-bearing linkage between prepared crossing, return path, and follow-on exchange.
3. **Redirect exactness receipt** — compact residue about how exact the return match really was.
4. **Adoption veto** — an explicit refusal point even after a clean continuation arrives.
5. **Consequence split** — keep requested consequence, route consequence, and adopted consequence visibly separate.

## New steals for rev0013
1. **Continuation shelf** — a small live object that says the crossing can still progress and how.
2. **Finish method card** — redirected callback, direct completion, app rebound, or weak finish kept visibly distinct.
3. **Capability floor** — the weakest still-true aftermath after degraded or partial completion.
4. **Interaction mode split** — separate how a detour starts from how it may legitimately finish.
5. **Non-bearer continuation** — a reminder that continuation power can be bound and smaller than durable adoption.


- **handoff docket** — small, user-legible instruction packet for out-of-band completion.
- **web escalation card** — why the flow had to move into the browser.
- **continuation leash** — bounded liveness object for a crossing that is still in flight.

## New steals for rev0014
- **interaction ref** — a compact pointer to a crossing that is still live.
- **finish ticket** — a bounded continuation packet for callback, handoff, or browser escalation.
- **adoption checkpoint** — the explicit local turn that accepts or vetoes durable consequence.
- **reasoned finish mode** — keep direct, rebound, handoff, escalation, timeout, and denial visibly different.
- **continuation smaller than adoption** — a standing anti-regrowth rule.

## New steals for rev0015
- **backchannel challenge** — a truthful object for in-flight user work that is happening elsewhere.
- **finish envelope** — a structured or signed finish packet smaller than durable local adoption.
- **veto floor** — the weakest still-true aftermath when local policy narrows consequence after a legitimate finish.
- **finish provenance** — explicit finish-mode residue: redirect, handoff, poll, ping, or browser escalation.
- **signed smaller than adopted** — a standing anti-regrowth rule.

## New steals for rev0016
- **issuer pin** — the expected authority identity for a live crossing.
- **origin card** — compact residue about which authority actually emitted the finish.
- **mix-up veto** — explicit refusal when finish shape is clean but authority identity is wrong.
- **second-provider cliff** — a standing anti-regrowth warning for products that begin single-provider.
- **origin smaller than adoption** — a standing anti-regrowth rule.

## New steals for rev0019
- **request object** — detached prepared intent that can travel by value or by reference.
- **policy witness** — third-party signed proof that a prepared crossing satisfies a narrower policy.
- **signed finish envelope** — integrity-bearing finish material smaller than durable adoption.
- **request/finish symmetry** — both ends can be protected without becoming one object.
- **review smaller than adoption** — a standing anti-regrowth rule.

## New steals for rev0019
- **step-up challenge** — typed residue that says the resource needs stronger or fresher user authentication.
- **resource metadata card** — compact route/discovery material about the resource and its acceptable authorization servers.
- **auth stair** — same task, but on a higher assurance rung.
- **cross-check before climb** — compare resource and authorization metadata before starting the next detour.
- **challenge smaller than adoption** — a standing anti-regrowth rule.

## Pass XIX additions
- **resource audience** — explicit redemption target, separate from scope.
- **scope split** — preserve what/where as different axes.
- **cross-check rail** — compare resource and authorization metadata before adoption.


## Pass XX additions
- **proximity signal** — bounded evidence that two devices are plausibly near each other.
- **timebound code** — short-lived, limited-use handoff material.
- **risk ladder** — typed narrowing or step-up path after suspicious cross-device signals.
- **initiation verification** — explicit reminder of which device/task actually started the flow.
