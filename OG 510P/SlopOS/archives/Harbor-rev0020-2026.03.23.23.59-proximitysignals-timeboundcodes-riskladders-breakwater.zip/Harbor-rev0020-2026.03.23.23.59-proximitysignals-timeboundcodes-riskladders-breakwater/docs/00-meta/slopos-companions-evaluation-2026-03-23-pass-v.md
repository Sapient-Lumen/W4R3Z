# SlopOS and companion-cube evaluation — 2026-03-23 pass V

## Lessons to steal from SlopOS
- `openuri-boundary-index.md` is effectively Harbor’s founding warning label: URI opening wants to regrow handler discovery, chooser control, callback reentry, launch completion, materialization, web permission, verified association, and install fallback unless each is nailed down explicitly.
- `auth-mediation-boundary-index.md` shows that redirects, login state, proof export, result export, credential mediation, and teardown are already treated as a family of separations. Harbor should borrow that habit, not collapse it.
- `import-to-docref-boundary-index.md` strongly suggests that Harbor should stop before durable object truth and then hand the flow onward in a typed way when controlled import or materialization really happens.
- The portal/net-request proof slice is a quiet but important style lesson: small proof-bearing specimens are more useful than giant platform theories.

## Lessons to steal from siblings
- **Helm** contributes reset cards, change cursors, and inspectable user-facing mediation state.
- **Schell** contributes humility about helper lanes, provider-local behavior, and adoption gates; not every convenient route deserves native vocabulary.
- **ViewFS** contributes the strongest Harbor check of all: imported source, materialized local object, live handle, and local identity are different strengths.
- **Steward** contributes narrow aftermath classes such as denial, retry-later, partial completion, and accountable follow-on work.
- **Ward** contributes the discipline that callback proof, affiliation evidence, or browser success should not silently mint durable trust.
- **Foundry** contributes the reminder that route outcomes increasingly terminate in foreign execution or container-like worlds; Harbor should describe the crossing honestly without swallowing those runtimes.

## Process result
Harbor should not yet promote a universal handler registry, a universal route verdict, or a universal import object. The pass-V result is stronger and narrower:
- promote one more specimen,
- keep affiliation hints separate from route proof,
- keep route proof separate from local consequence,
- and let controlled import remain a handoff, not Harbor’s secret second job.
