# Research synthesis — pass XIII

This pass keeps Harbor embryonic while studying cross-device and partly browserless approval patterns without pretending one flow should dominate.

## Fresh outside lessons
1. **Device flow is a real out-of-band finish method, not an edge case.**
   RFC 8628 treats the secondary-device/browser step as the normal completion path for input-constrained clients. The local locus displays a verification URI and user code, while approval happens elsewhere. Harbor should therefore be honest about cross-device handoff instead of forcing everything into same-route callback language.

2. **User-code handoff needs both generosity and skepticism.**
   RFC 8628 explicitly says the user code needs enough lifetime for the user to retrieve another device and finish the flow, but also a short enough lifetime to limit phishing usefulness. That is a strong clue that Harbor should not model handoff tokens as durable adoption or quiet trust.

3. **“Browserless unless risk says otherwise” still wants a visible escalation card.**
   The current OAuth first-party apps draft proposes an Authorization Challenge Endpoint for native experiences, but it can still return `redirect_to_web` when the server decides that the user must finish in a browser due to risk, recovery, or unsupported authentication methods. Harbor should likely treat web escalation as a first-class finish detour, not as an embarrassing failure path.

4. **Challenge sessions are useful, but smaller than durable adoption.**
   The same first-party apps draft uses `auth_session` to keep a challenge alive across follow-up steps like OTP input. Harbor can steal the idea of a bounded continuation leash without equating it to local account binding or durable grant truth.

## Resulting Harbor pressure
Harbor should likely preserve at least four distinct things:
- **handoff docket**: what the current locus can honestly ask the user to do elsewhere;
- **continuation leash**: the bounded live thing that keeps the crossing reopenable;
- **web escalation card**: the explicit fact that the flow moved from native/local challenge to browser completion;
- **local adoption**: what was actually admitted after the out-of-band turn completed.

## Brilliant ideas worth stealing
- **handoff docket** — a card that says “finish this elsewhere” without pretending a durable return already exists;
- **web escalation card** — explicit explanation that the flow was intentionally pushed into the browser by policy or risk;
- **continuation leash** — a bounded continuation object that can be reopened, expired, or abandoned without impersonating durable adoption.
