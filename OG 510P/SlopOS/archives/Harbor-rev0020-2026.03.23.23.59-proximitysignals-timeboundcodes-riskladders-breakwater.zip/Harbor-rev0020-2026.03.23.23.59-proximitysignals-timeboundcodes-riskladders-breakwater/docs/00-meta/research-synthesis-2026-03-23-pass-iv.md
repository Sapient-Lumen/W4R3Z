# Research synthesis — 2026-03-23 pass IV

This pass tightened Harbor around three sources of pressure:
1. a reread of the most relevant SlopOS cuts, especially OpenURI, auth mediation, import/materialization, and portalized network/request proof slices;
2. fresh official material on MCP authorization, RFC 8252 / PKCE / OAuth 2.1 posture, XDG portals, Android verified links, and FedCM mediation;
3. the process constraint that Harbor must collect strong ideas without freezing one giant route/result taxonomy too early.

## What the datacubes reinforced
- SlopOS’s `openuri-boundary-index.md` is a warning label: route systems regrow handler oracles, callback planes, fake completion truth, and materialization authority unless the seams are individually pinned.
- SlopOS’s auth-mediation and portal-net materials argue for **small explicit surfaces** and against hidden continuity or ambient browser truth.
- ViewFS keeps repeating the most useful Harbor lesson: import, identity, handle possession, and durable recency are different strengths.
- Helm’s change-cursor and reset-card work suggests a portable design habit for Harbor: some user-facing mediation state should be restartable and inspectable rather than silently sticky.
- Schell and Steward both reward modest typed aftermath surfaces over giant stories about what “really happened.”

## What the outside sources reinforced
- MCP now explicitly models protected servers as OAuth 2.1 resource servers and MCP clients as OAuth 2.1 clients, which means Harbor should treat local-tool browser detours as routine, not exceptional.
- RFC 8252 still points native/public clients toward the external browser, while PKCE and OAuth 2.1 posture keep exact redirect handling and code-proof discipline central.
- XDG OpenURI remains a sharp example of user-controlled mediation, and the Documents portal is an equally sharp reminder that controlled file availability is not the same thing as generic open.
- Android verified links and Apple associated-domain style systems are strongest when read as **affiliation inputs**, not as route omniscience.
- FedCM is valuable precisely because the browser mediates the relationship between RP and IdP with user permission; that is useful Harbor pressure, but still not the same thing as durable local trust or durable system grant.

## Brilliant ideas worth stealing carefully
1. **Detour lease**: a bounded object for “we left, we may return, here is the proof class we expect.”
2. **Route reset card**: a typed way to return a route to pre-choice / pre-default posture when associations or defaults go stale.
3. **Weak-versus-strong aftermath classes**: admitted, denied, returned-with-proof, returned-without-bindable-proof, materialized, grant-issued.
4. **Controlled materialization handoff**: explicitly distinguish “the user let me open” from “the system created a durable controlled object for me.”

## Current recommendation
Harbor should keep building **specimens before families**. The next family or registry should only be promoted after at least three visibly different crossings survive with the same object vocabulary: browser-detour auth, generic open/reveal, and controlled import/materialization.
