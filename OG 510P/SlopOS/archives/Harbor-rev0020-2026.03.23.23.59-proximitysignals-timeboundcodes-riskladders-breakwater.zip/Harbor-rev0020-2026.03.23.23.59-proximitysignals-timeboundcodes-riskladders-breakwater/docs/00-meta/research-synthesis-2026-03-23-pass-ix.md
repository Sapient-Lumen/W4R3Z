# Research synthesis — 2026-03-23 pass X

This pass focused on a subtler Harbor failure mode: even when systems stop shoving everything through the browser, they still often flatten **requested consequence**, **route consequence**, and **local adoption consequence** into one result.

## New lessons from outside systems

### 1) RAR is a clue that requested consequence should stay structured
RFC 9396 introduces `authorization_details` for fine-grained authorization data in OAuth messages. Harbor should steal the shape, not the stack: a detour can begin with a **structured ask** rather than one flattened scope-like noun, and that structured ask should remain smaller than whatever durable local adoption follows.

### 2) PAR plus RAR suggests a two-step parcel instead of one giant detour
Taken together, RFC 9126 and RFC 9396 imply a healthy pressure pattern: detailed intent can be prepared and referenced while the browser leg carries less mutable state. Harbor should preserve the option for a **structured detour parcel** whose requested consequence is inspectable without letting the browser leg become the whole truth.

### 3) Dynamic route rules are compatibility-sensitive, not omnipotent
Android’s current App Links guidance says newer `dynamic_app_link_components` rules are ignored by older Android versions. Harbor should treat route-narrowing truth as **environment-sensitive**. A route can be narrowed on one device class while remaining broader or different elsewhere, which argues for a visible compatibility shadow.

### 4) Controlled file availability remains stronger than route success
The XDG document portal’s FUSE-backed controlled availability is still a stronger consequence than merely opening a URI. Harbor should keep route success, controlled availability, and durable grant on different clocks.

## New lessons from SlopOS and companions

### SlopOS
- `openuri-request-shaping-boundary-v0.md` remains the right brake: Harbor can learn from structured asks without swallowing full provider-specific request construction.
- `openuri-auth-session-boundary-v0.md` and `auth-continuation-export-boundary-v0.md` still reinforce that staged progress must not quietly become portable continuation truth.
- `import-to-docref-boundary-v0.md` and the fresh-identity/docref cuts continue to remind Harbor that controlled availability and durable local object identity are stronger than route success.

### Siblings
- ViewFS remains Harbor’s clearest sibling brace here: route success and controlled availability should stay weaker than durable object identity.
- Ward keeps Harbor from over-crediting structured asks or proof-bound returns as trust.
- Helm still turns fallback, review, and reset residue into visible product surfaces rather than hidden state.

## Brilliant ideas worth stealing carefully

1. **Structured detour parcel** — a typed request object smaller than the browser leg and smaller than durable adoption.
2. **Compatibility shadow** — a visible note that newer route narrowing exists in some environments but not all.
3. **Adoption clocks** — separate age/freshness for prepared parcel, returned proof, and durable aftermath.
4. **Outcome shadow** — a way to record “worked here” without claiming universal route truth.
5. **Scope-to-aftermath split** — requested consequence, route consequence, and local consequence remain different.

## Current recommendation
Harbor still should not freeze a universal outcome object.

The safer move is:
- keep structured ask, detour parcel, callback proof, controlled availability, and durable adoption separate;
- use specimen flow 06 to test whether compatibility shadow and adoption clocks deserve first-class Harbor vocabulary;
- and promote only the nouns that survive both newer and older route-capability environments without smuggling Ward or ViewFS into Harbor.
