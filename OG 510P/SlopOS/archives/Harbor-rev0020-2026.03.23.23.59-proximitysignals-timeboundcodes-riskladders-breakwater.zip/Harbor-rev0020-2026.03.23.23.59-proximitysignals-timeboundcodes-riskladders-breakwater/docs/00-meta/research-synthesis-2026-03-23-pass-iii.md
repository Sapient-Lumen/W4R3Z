# Research synthesis — 2026-03-23 pass III

This pass tightened Harbor around three sources of pressure:
1. a deeper reread of SlopOS and the current companion cubes;
2. fresh official material on browser-based auth, portals, verified links, and browser-mediated federation;
3. the explicit constraint that the primary cube must stay pressure-sterile.

## What the datacubes reinforced
- SlopOS keeps small boundary families enumerable so meaning pins do not silently regrow into giant ambient surfaces.
- ViewFS repeatedly teaches that import, grant, open, identity, and receipt are different strengths.
- Helm and Schell both reward laws and specimens over premature universal vocabulary.
- Steward rewards tiny typed status surfaces and release hygiene over mythology.

## What the outside sources reinforced
- browser-based authorization is still the least-bad baseline for native/public OAuth-style flows;
- exact redirect and callback handling matters more as local tools adopt MCP and related auth flows;
- XDG portals remain a strong example of user-controlled mediation and a clean split between portal frontends and session/host backends;
- verified link systems are valuable, but they answer affiliation questions, not every route/trust question;
- browser-mediated federation flows keep warning that login UI and data-processing consent are not the same thing.

## Founding result
Harbor should stay small and add **specimen flows before families**. The archive should especially resist freezing one giant “exchange result” object until it survives at least three different aftermath classes.
