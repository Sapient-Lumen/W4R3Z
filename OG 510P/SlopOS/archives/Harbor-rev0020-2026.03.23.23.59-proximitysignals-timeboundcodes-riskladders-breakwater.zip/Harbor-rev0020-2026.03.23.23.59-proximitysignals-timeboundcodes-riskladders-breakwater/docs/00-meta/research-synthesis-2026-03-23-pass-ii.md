# Research synthesis — 2026-03-23 pass II

This pass combined two inputs:
1. a readthrough of the current cube ecology to infer house style, neighbor boundaries, and repeated pressure points;
2. a fresh outside pass across official specifications and project documentation relevant to Harbor.

## What the current cube ecology teaches
- small, sharp separations age better than giant synthetic frameworks;
- typed receipts, grants, witnesses, and ladders are healthier than ambient folklore;
- sibling cubes become more valuable when they export modest truths instead of pretending to own the whole story;
- archive discipline matters: charter, trajectory, roadmap, question ledger, and assumption ledger give the cube continuity before it has a giant implementation story.

## What the outside sources reinforced
- user-controlled portals, browser-based auth, and exact callback handling are healthier than embedded or ambient exchange patterns;
- the same crossing often produces several different local consequences, so route, callback, and materialization should remain distinct;
- receipt modesty matters because useful aftermath often belongs to neighboring cubes.



## Resulting founding bet
Harbor should begin with a **small object model and visible non-decisions**, not with a giant implementation scaffold.
