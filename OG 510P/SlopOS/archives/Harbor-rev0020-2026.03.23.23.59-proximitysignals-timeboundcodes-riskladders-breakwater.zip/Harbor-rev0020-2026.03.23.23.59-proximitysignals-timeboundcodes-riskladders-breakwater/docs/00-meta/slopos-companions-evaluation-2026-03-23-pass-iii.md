# SlopOS and companion-cube evaluation — 2026-03-23 pass III

## Lessons to steal from SlopOS
- Boundary indexes are a superb anti-regrowth mechanism. Harbor should eventually have a small family map, but only after there are enough real seams to justify it.
- The OpenURI material in SlopOS is a direct warning that generic launch likes to regrow handler oracles, callback planes, completion mythology, and materialization authority if left unpinned.
- SlopOS repeatedly prefers exact receipts and explicit authority changes over folklore. Harbor should mirror that habit.

## Lessons to steal from siblings
- **ViewFS**: keep import, local identity, handle authority, and durable recency separate.
- **Schell**: make open questions first-class archive objects and do not let a shiny UX noun freeze the design.
- **Helm**: laws and specimens are better than giant machinery at this stage.
- **Steward**: release discipline and tiny typed surfaces help embryos stay honest.

## Resulting process choice
Harbor should add **followthrough items and promotion gates** before it adds any large registry or taxonomy.
