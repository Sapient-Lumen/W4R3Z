# Research synthesis — pass XIX

This pass keeps Harbor narrow and learns one more thing from mature authorization systems: **where a token will be redeemed should stay explicit, and it should not be smuggled inside scope or callback success**.

## Outside lessons
1. **RFC 8707 separates what from where.**  
   Scope describes what access is being requested, while the `resource` parameter lets the client explicitly say where the token will be used. Harbor should preserve this split instead of hiding resource identity inside generic route or grant objects.

2. **Audience restriction is a security property, not mere metadata.**  
   When the authorization server knows the intended protected resource, it can mint a token restricted to that audience and reduce token redirect risk. Harbor should therefore keep target identity visible through the whole detour.

3. **RFC 9728 pairs resource metadata with cross-check discipline.**  
   Protected-resource metadata can list acceptable authorization servers, and application profiles can cross-check resource and authorization metadata for consistency. Harbor should steal the idea that discovery and trust are adjacent but not identical.

4. **The uploaded cube ecology wants this exact separation.**  
   SlopOS and its companions repeatedly keep import/open/callback/session/aftermath distinct. Harbor can add explicit resource targeting without turning into a general account or token cube.

## Resulting Harbor move
Do not decide yet whether the durable nouns are `resource audience`, `scope split`, `auth target`, and `cross-check rail`, or whether one of them later compresses behind a smaller continuation family.
For now, keep them alive as specimen nouns and demand that they improve:
- one resource-targeted detour,
- one shared-scope / different-resource specimen,
- and one finish that is technically valid but vetoed because the target identity drifted.

## Fresh ideas worth stealing
- **resource audience** — explicit statement of where the token will be redeemed.
- **scope split** — reminder that requested power and redemption location are different axes.
- **auth target** — small card naming the protected resource that shaped the detour.
- **cross-check rail** — consistency check between resource metadata and authorization metadata before local adoption.
