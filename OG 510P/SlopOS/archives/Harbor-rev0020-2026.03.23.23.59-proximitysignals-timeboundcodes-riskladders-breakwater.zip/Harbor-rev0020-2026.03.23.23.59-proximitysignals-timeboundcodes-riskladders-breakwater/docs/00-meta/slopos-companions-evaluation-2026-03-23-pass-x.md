# SlopOS / companions evaluation — 2026-03-23 pass X

This pass evaluated whether Harbor can absorb consent-parcel and return-lease ideas without becoming either a policy engine or a universal object/identity cube.

## SlopOS pressure that matters most now

The `openuri-request-shaping` and auth-continuation/export seams remain the strongest native pressure. SlopOS clearly wants staged outward turns, returned proof, and durable local consequence to remain distinct strengths of fact. That continues to justify Harbor staying small and membrane-shaped.

The import-to-docref and fresh-identity cuts matter even more under pass X. They keep reminding Harbor that route success should not silently masquerade as durable local relation.

The broader boundary-index and singleton-contract habits in SlopOS are also a warning: if Harbor starts inventing one giant universal “exchange outcome”, it will be violating the primary cube’s own design discipline.

## Sibling pressure that matters most now

### ViewFS
ViewFS is still the main brace. Harbor can report route success and controlled availability, but durable local objecthood belongs elsewhere.

### Ward
Ward keeps the trust flank honest. A good return lease may say “same staged flow” without saying “durably admitted to spend.”

### Helm and Schell
Helm wants inspectable route residue and fallback surfaces; Schell wants provider/helper turns to require explicit adoption. Both support pass X strongly.

## Recommendation for Harbor rev0011

Keep these candidate nouns provisional:
- **consent parcel**
- **return lease**
- **compatibility floor**
- **fallback memory**
- **adoption veto window**

The pass X specimen should exist to kill the over-wide versions early:
- if consent parcel starts swallowing provider-specific request construction, it is too wide;
- if return lease starts impersonating durable trust or grant, it is too strong;
- if compatibility floor turns into universal route doctrine, it is too frozen.

Harbor is healthiest when it tells the truth about the crossing and then stops.
