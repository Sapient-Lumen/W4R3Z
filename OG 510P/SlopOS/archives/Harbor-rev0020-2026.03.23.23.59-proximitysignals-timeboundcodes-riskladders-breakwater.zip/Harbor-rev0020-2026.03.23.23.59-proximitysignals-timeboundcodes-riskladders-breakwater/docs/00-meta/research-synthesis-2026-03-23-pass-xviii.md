# Research synthesis — pass XVIII

This pass keeps Harbor narrow and learns one more thing from outside routing and authorization systems: **a resource can trigger a higher-assurance rebound without that rebound becoming durable local adoption**.

## Outside lessons
1. **RFC 9470 makes step-up a first-class resource challenge.**  
   A resource server can return `insufficient_user_authentication` and indicate stronger or fresher authentication requirements via `acr_values` or `max_age`. Harbor should preserve that as a typed route object: the request was intelligible, the token may be real, and yet the current assurance rung is not enough.

2. **RFC 9728 gives the resource a metadata surface of its own.**  
   A resource can advertise `authorization_servers`, `scopes_supported`, and a `resource_metadata` URL through `WWW-Authenticate`. Harbor should steal the discipline: the next detour can be discovered from the resource edge, not only from a preconfigured app worldview.

3. **RFC 9728 also insists on validation and cross-checks.**  
   The protected resource metadata must identify the actual resource that was contacted, and resource/authorization metadata can be cross-checked for consistency. Harbor should keep route discovery and route trust related but distinct.

4. **The uploaded cube ecology wants this separation.**  
   SlopOS’s OpenURI, auth-mediation, and MCP import seams already keep request shaping, callback, auth session, and aftermath separate. Harbor can therefore add a step-up staircase without collapsing into a generic account or token manager.

## Resulting Harbor move
Do not decide yet whether the durable nouns are `step-up challenge`, `resource metadata card`, and `auth stair`, or whether one of them later collapses behind a smaller continuation family.
For now, keep all three alive as specimen nouns and demand that they improve:
- one resource-originated step-up specimen,
- one metadata-discovered rebound specimen,
- and one local veto after a successful higher-assurance return.

## Fresh ideas worth stealing
- **step-up challenge** — resource-originated demand for stronger or fresher user auth.
- **resource metadata card** — small route/discovery residue from the resource edge.
- **auth stair** — same task, different assurance rung.
- **cross-check before climb** — compare resource and authorization metadata before the next detour.
