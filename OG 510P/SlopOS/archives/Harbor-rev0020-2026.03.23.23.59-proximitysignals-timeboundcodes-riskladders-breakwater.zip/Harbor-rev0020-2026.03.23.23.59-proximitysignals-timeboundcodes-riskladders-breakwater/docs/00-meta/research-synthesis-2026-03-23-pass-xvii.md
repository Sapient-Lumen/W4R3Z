# Research synthesis — pass XVIII

This pass keeps Harbor narrow and learns one more thing from outside routing and auth systems: **the detour request and the detour finish can both be integrity-bearing objects without either one becoming durable local adoption**.

## Outside lessons
1. **RFC 9101 exists because query-shaped authorization requests moving through user agents are easy to tamper with, hard to authenticate, and visible to intermediaries.**  
   JAR moves request parameters into a signed and optionally encrypted JWT, and it allows that request object to be sent by value or by reference. Harbor should steal the discipline: the browser leg can be smaller than the full initiating intent.

2. **RFC 9101 also introduces a strong “policy witness” idea.**  
   A trusted third party can pre-examine a request and sign that it complies with a policy before the authorization server processes it. Harbor should keep that witness smaller than local adoption: reviewed request is not the same thing as granted consequence.

3. **JARM gives the finish its own protected envelope.**  
   The authorization response can come back as a signed or signed-and-encrypted JWT carrying `iss`, `aud`, `exp`, and the response parameters. Harbor should steal the symmetry: signed finish is stronger than plain callback arrival and still weaker than durable local adoption.

4. **The uploaded cube ecology wants this separation.**  
   SlopOS keeps auth continuation provider-local and resists portable callback/token broker growth. Harbor can therefore add request-object and finish-envelope honesty without widening into generic browser or account truth.

## Resulting Harbor move
Do not decide yet whether the durable nouns are `request object`, `policy witness`, and `signed finish envelope`, or whether one of them later collapses behind a smaller family.
For now, keep all three alive as specimen nouns and demand that they improve:
- one JAR-by-reference specimen,
- one trusted-third-party policy-witness specimen,
- and one JARM finish that is cryptographically strong yet still vetoed locally.

## Fresh ideas worth stealing
- **request object** — the prepared crossing intent, separable from the browser leg.
- **policy witness** — third-party signed proof that the prepared request satisfied a narrower policy.
- **signed finish envelope** — protected finish material smaller than durable adoption.
- **request/finish symmetry** — both ends of a crossing can be integrity-bearing without becoming the same object.

