# SlopOS / companions evaluation — pass XIX

Harbor still looks justified as its own companion cube.

## What the current cube ecology keeps proving
- **SlopOS** keeps callback, auth session, provider hints, import boundaries, and aftermath separate; explicit resource targeting strengthens that habit instead of collapsing it.
- **Helm** benefits because user-visible chooser/open/rebound surfaces often need to say *which* protected resource a detour is about, not just which provider launched.
- **Schell** benefits because CLI/tool flows often reuse scopes across multiple APIs, making audience drift an operational hazard.
- **ViewFS** benefits because open/import/materialize flows often cross from one service edge to another, and the redeeming resource matters.
- **Steward** benefits because later actions should only inherit the audience actually granted, not every nearby permission string.
- **Ward** should stay distinct: a correct target is still weaker than durable trust.
- **Foundry** should stay distinct: a foreign ground may redeem a token, but target identity is still Harbor’s problem first.

## Current recommendation
Keep Harbor’s new nouns provisional. They are useful only if they preserve the split between:
1. requested power,
2. target resource,
3. detour finish,
4. and local adoption.
