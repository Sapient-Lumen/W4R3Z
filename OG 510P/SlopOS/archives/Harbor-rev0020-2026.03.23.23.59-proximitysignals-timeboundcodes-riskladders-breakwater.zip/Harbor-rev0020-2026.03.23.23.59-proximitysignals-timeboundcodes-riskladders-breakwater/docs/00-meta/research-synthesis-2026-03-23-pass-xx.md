# Research synthesis — pass XX

This pass keeps Harbor narrow and learns one more thing from mature cross-device authorization systems: **a handoff can be real without being safe enough for full-strength adoption, so proximity and time-boundedness should stay visible instead of hiding inside callback success**.

## Outside lessons
1. **The current OAuth cross-device security draft treats the unauthenticated gap as a first-class attack surface.**  
   The draft catalogs QR/user-code and session-transfer exploits where attackers change the context around a valid code. Harbor should keep cross-device handoff material smaller than durable success.

2. **Practical mitigations are plural, not singular.**  
   The draft recommends defense in depth, including proximity, short-lived/timebound codes, one-time or limited-use codes, limited scopes, short-lived tokens, sender-constrained tokens, and request-initiation verification. Harbor should steal the idea that risk can narrow or ladder a crossing without pretending the route is false.

3. **Proximity is useful as a risk signal even when it is imperfect.**  
   Shared network, geolocation, BLE/NFC/UWB, and similar checks can raise the bar, but the draft is explicit that privacy, VPNs, and spoofing limitations remain. Harbor should therefore preserve proximity as a signal, not promote it to timeless truth.

4. **The uploaded cube ecology wants bounded handoff objects.**  
   SlopOS and its companions already keep request, continuation, callback, and aftermath separate. Harbor can therefore add proximity/risk surfaces without turning into a general identity or transaction cube.

## Resulting Harbor move
Do not decide yet whether the durable nouns are `proximity signal`, `timebound code`, `risk ladder`, and `initiation verification`, or whether one later compresses behind a smaller cross-device family.
For now, keep them alive as specimen nouns and demand that they improve:
- one same-room handoff,
- one copied-code exploit,
- and one legitimate but lower-confidence finish that only climbs after additional review.

## Fresh ideas worth stealing
- **proximity signal** — bounded evidence that two devices are plausibly near enough for a stronger cross-device story.
- **timebound code** — short-lived, limited-use handoff material that is intentionally smaller than durable continuation.
- **risk ladder** — typed narrowing or step-up path instead of generic failure.
- **initiation verification** — explicit confirmation of which device/task actually started the crossing.
