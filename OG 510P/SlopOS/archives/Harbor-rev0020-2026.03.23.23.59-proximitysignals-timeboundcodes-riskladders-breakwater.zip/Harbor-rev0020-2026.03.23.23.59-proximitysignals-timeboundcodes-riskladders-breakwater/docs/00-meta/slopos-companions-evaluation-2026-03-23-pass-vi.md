# SlopOS and companion-cube evaluation — 2026-03-23 pass VI

## What SlopOS keeps teaching Harbor
- `openuri-boundary-index.md` is still the single best warning label: route convenience constantly tries to regrow handler discovery, chooser control, callback truth, browser session truth, verified association, and materialization.
- `openuri-callback-reentry-boundary-v0.md` confirms that Harbor should keep **return-path evidence** smaller than durable identity or trust.
- `auth-continuation-export-boundary-v0.md`, `auth-proof-export-boundary-v0.md`, and `auth-result-export-boundary-v0.md` collectively suggest a powerful anti-lesson: continuation, proof, and result are different strengths and should not be repacked into one “auth succeeded” fact.
- `import-to-docref-boundary-index.md` keeps insisting that Harbor must hand off honestly when controlled import or docref creation begins.
- `openuri-verified-association-boundary-v0.md` aligns with the outside research almost perfectly: affiliation belongs in the archive, but it is weaker than a route verdict.

## What the siblings sharpened this pass
- **Helm** reinforces that reset, inspectability, and user-facing mediation are core product surfaces rather than hidden debug affordances.
- **Schell** reinforces the idea of explicit adoption after helper or provider detours; Harbor should be comfortable with aftermath classes that stop short of “done”.
- **ViewFS** reinforces the distinction between exchanged payload, exported object, materialized object, and durable identity.
- **Steward** reinforces accountable aftermath naming: rebound-needed, review-needed, partial, and expired are more useful than generic success.
- **Ward** reinforces that a cross-device or provider-mediated approval may harden a session without proving the local thing Harbor wants to claim.
- **Foundry** reinforces that Harbor’s outputs increasingly feed foreign runtimes and therefore need truthful membrane receipts instead of lazy inferences.

## Pass-VI result
Harbor still should not promote a universal route verdict or giant exchange outcome object.

The sharper and more durable move is:
- promote one more specimen around mediated transfer and rebound-needed aftermath;
- keep affiliation, route proof, and local consequence visibly different;
- allow dynamic route refinements to narrow or exclude but not silently widen local scope;
- and add reset/rehearing surfaces as first-class hygiene rather than cleanup.
