# Research synthesis — 2026-03-23 pass VIII

This pass concentrated on a newer historical trap: ecosystems are getting better at shrinking what travels through the browser, but designers still keep over-crediting the browser leg after the fact.

## New lessons from outside systems

### 1) PAR is a clue that browser detours should carry less mutable intent
OAuth 2.0 Pushed Authorization Requests let a client push the authorization-request payload directly to the authorization server and receive a `request_uri` reference for the later browser leg. That is a beautiful Harbor lesson: **the browser detour does not need to be the whole request**. Harbor should preserve the option for a detour parcel that is smaller, more opaque, and more reviewable than the full initiating intent.

### 2) DPoP shows that proof-bound return exchange is narrower than trust
DPoP sender-constrains tokens by requiring proof of possession on the application layer, which helps detect replay attacks against access and refresh tokens. Harbor should steal the shape, not the full trust story: a return exchange can be **proof-bound** without Harbor pretending it now owns durable identity, durable session state, or spendable consequence.

### 3) XDG still teaches that mediation strength is part of the meaning
OpenURI remains a user-controlled way for sandboxed apps to open URIs, while FileTransfer explicitly acts as a middle-man for copy/paste and drag/drop. That pair continues to show Harbor the same thing: the **strength of the mediation path** is part of the truth and should survive into aftermath vocabulary instead of being hidden.

### 4) Dynamic route ecosystems still want honest narrowing
Android’s Dynamic App Links keep reinforcing a healthy rule: late-arriving route rules should refine or narrow within a previously declared scope, not silently widen authority after deployment. Harbor should continue resisting widening-by-metadata.

## New lessons from SlopOS and companions

### SlopOS
- `auth-continuation-export-boundary-v0.md` is a strong warning against quietly turning local auth progress into portable continuation handles; Harbor should stay careful even while studying detour leases and request references.
- `auth-proof-export-boundary-v0.md` and `auth-result-export-boundary-v0.md` support the pass VIII split between proof-bound exchange and durable result.
- `openuri-request-shaping-boundary-v0.md` is a good brake on letting Harbor absorb arbitrary request construction just because PAR exists elsewhere.
- `openuri-auth-session-boundary-v0.md` and the browser-session boundaries continue to reinforce that browser posture is weaker than durable native truth.

### Siblings
- Ward remains Harbor’s most important brake here: sender-constrained exchange is useful, but the spendable trust consequence still lives elsewhere.
- Schell keeps reinforcing explicit adoption after helper or provider turns, which fits Harbor’s new detour-binding question.
- Helm still turns route reset, explanation, and fallback into visible product surfaces instead of invisible technical residue.
- Foundry remains the mirror image: once a detour lands in foreign ground, Harbor’s aftermath language must stay even more truthful.

## Brilliant ideas worth stealing carefully

1. **Opaque auth parcel** — a staged request object that can be referenced by the detour without making the browser leg carry the whole mutable request.
2. **Request reference** — a typed, expiring handle that points at one prepared detour intent while remaining smaller than a reusable continuation surface.
3. **Proof-bound return** — a callback or token exchange that can prove linkage to the initiating flow without automatically upgrading into durable local consequence.
4. **Detour-binding card** — a small object that explains what the system knows about “same initiating flow”, “same claimant”, and “same local session” without flattening them.
5. **Aging split** — let request-reference age, callback-proof age, and durable adoption age stay on different clocks.

## Current recommendation
Harbor still should not freeze a universal outcome object.

The next safe shape is:
- keep staged request parcels, detour leases, callback proofs, proof-bound exchange, and durable consequence separate;
- use specimen flow 05 to test whether opaque request references deserve first-class Harbor vocabulary;
- and promote only the nouns that survive both browser-auth and non-browser transfer specimens without smuggling Ward into Harbor.
