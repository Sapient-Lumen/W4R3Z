# SlopOS + companions evaluation — pass XIV

This pass reads SlopOS and the siblings as pressure for Harbor to become better at **continuation truth without generic session inflation**.

## Lessons from the datacubes
1. **SlopOS workflow/router posture resists a generic resumable broker.**  
   RFC-0046 keeps portal request/session truth provider-owned, single-outcome, and family-local. Harbor should respect that by keeping any interaction reference smaller than a universal session object.

2. **SlopOS document and transfer work keeps aftermath typed.**  
   RFC-0089 and RFC-0094 both suggest that durable file handles, transfer payloads, and import identity should remain explicit aftermath classes. Harbor should therefore keep finish material weaker than materialization or durable grant truth.

3. **Schell already tolerates pending work without fake completion.**  
   That sibling pressure says Harbor can survive a state where a crossing is live, handoff-ready, or rebound-ready without claiming durable local adoption.

4. **ViewFS continues to defend fresh local identity.**  
   Harbor should not let a callback or handoff packet masquerade as the local object or durable document identity that only later workflows can establish.

## Resulting cube move
Do not decide yet whether `interaction ref` and `finish ticket` belong in one family.  
Keep them separate specimen nouns until they improve:
- one browser callback specimen,
- one device-handoff specimen,
- and one import/materialize-after-return specimen.
