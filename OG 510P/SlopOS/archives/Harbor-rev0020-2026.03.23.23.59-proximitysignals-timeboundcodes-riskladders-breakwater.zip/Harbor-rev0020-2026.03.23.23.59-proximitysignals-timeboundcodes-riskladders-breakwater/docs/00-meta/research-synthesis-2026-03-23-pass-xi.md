# Research synthesis — 2026-03-23 pass XI

This pass focused on a Harbor pressure that older detour systems keep getting wrong: the *requested consequence*, the *returned continuation*, and the *locally adopted consequence* keep collapsing into one flattering success shape.

## New lessons from outside systems

### 1) RAR shows that requested consequence deserves its own typed shape
RFC 9396 keeps fine-grained authorization intent inside `authorization_details` instead of forcing everything into one flat scope string. Harbor should steal that lesson without committing to OAuth-specific nouns: a **typed consequence card** can stay smaller than the detour and much smaller than any durable local adoption.

### 2) OAuth 2.1 keeps exact redirect matching and PKCE hard on purpose
The current OAuth 2.1 draft continues the move toward exact redirect comparison, PKCE for authorization-code clients, and the removal of older looser patterns. Harbor should preserve a **continuation exactness** layer so “the route came back somewhere plausible” does not impersonate “the return belongs to this prepared crossing”.

### 3) DPoP suggests proof-bound continuation, not proof-bound truth
RFC 9449 is valuable because it sender-constrains token use and reduces replay. Harbor should borrow the *shape* without overpromoting it: a **continuation bond** can say that this return and this follow-on exchange are cryptographically linked more tightly than a plain callback, while still remaining smaller than durable trust or durable local consequence.

### 4) FedCM migration pressure keeps route UX and trust consequence separate
Current FedCM guidance continues to push browser-mediated identity as a privacy-preserving UX adaptation to a changing web platform. That is useful pressure for Harbor because it keeps reminding us that browser mediation is a route and consent surface, not the end of local policy.

## New lessons from SlopOS and companions

### SlopOS
- The auth-continuation, auth-proof, account-binding, and import/materialization boundary families still reward **small export objects with explicit strength**. Harbor should keep continuation linkage smaller than account consequence.
- The many OpenURI and portal/net-request seams still argue that route class, local aftermath, and native durable relation should remain distinct.
- The primary is still visibly design-phase; Harbor should therefore collect these shapes as specimen pressure, not as frozen universal object families.

### Siblings
- ViewFS remains the best brace against route inflation because controlled availability and durable local identity are stronger than detour success.
- Ward keeps insisting that cryptographic proof or provider success is still smaller than spendable local consequence.
- Steward remains a reminder that follow-on actions need typed aftermath facts, not one overgrown “success” bit.
- Helm and Schell both continue to reward inspectable route residue, fallback memory, and explicit adoption.

## Brilliant ideas worth stealing carefully

1. **Typed consequence card** — a staged request object that says what is being asked, in typed form, before any detour succeeds.
2. **Continuation bond** — a temporary proof-bearing linkage between prepared crossing, return path, and any follow-on exchange.
3. **Redirect exactness receipt** — a compact account of how exact the return match really was.
4. **Adoption veto** — a first-class local refusal moment even after a clean continuation bond exists.
5. **Consequence split** — separate requested consequence, detour consequence, and adopted consequence instead of flattering all three into “completed”.

## What pass XI should not decide yet

Harbor still should not decide:
- whether typed consequence cards are Harbor-native objects or imported provider parcels with a thinner Harbor wrapper;
- whether continuation bonds belong in the aftermath family or should remain detour-local residue that can expire quickly;
- whether adoption veto is a generic Harbor move or only belongs to a few stronger route classes.
