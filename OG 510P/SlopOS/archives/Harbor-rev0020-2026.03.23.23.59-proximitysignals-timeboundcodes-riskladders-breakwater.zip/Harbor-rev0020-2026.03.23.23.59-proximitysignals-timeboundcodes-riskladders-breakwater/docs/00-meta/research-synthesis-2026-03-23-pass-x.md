# Research synthesis — 2026-03-23 pass X

This pass focused on a Harbor failure mode that older ecosystems keep understating: a detour can be narrow and well-mediated and still overclaim what happened afterward.

## New lessons from outside systems

### 1) PAR keeps the browser leg smaller on purpose
RFC 9126 is useful not just because it defines an endpoint, but because it demonstrates a healthy pressure split: detailed authorization request material can be staged off the browser leg and referenced later. Harbor should preserve the option for a **consent parcel** whose prepared intent remains inspectable without making the detour carry everything.

### 2) RAR suggests typed requested consequence rather than one flattened ask
RFC 9396 keeps fine-grained authorization intent structured. Harbor should steal that shape. The outbound ask can stay typed and smaller than any local durable adoption that might happen afterward.

### 3) Browser-mediated identity keeps UX narrower than trust
FedCM is a useful reminder that a browser can mediate identity turns without thereby answering every downstream trust or policy question. Harbor should keep a successful browser turn smaller than durable local consequence.

### 4) Portals keep route success smaller than controlled availability
XDG OpenURI and FileTransfer remain strong examples of mediation under user control, while the Documents portal shows that controlled availability is a stronger consequence than merely routing or opening. Harbor should keep **route consequence**, **controlled availability**, and **durable adoption** on different rails.

## New lessons from SlopOS and companions

### SlopOS
- The `openuri-*` and auth-continuation/export boundary families still act like the right brake: Harbor can study richer detour shaping without swallowing provider-specific request construction.
- The import/docref and fresh-identity cuts still argue that landed availability and durable local identity are stronger than a route succeeding.
- The broader boundary-index posture in SlopOS continues to reward small export objects rather than giant umbrella outcomes.

### Siblings
- ViewFS remains Harbor’s clearest brace against outcome inflation: availability, identity, and durable relation should keep different strengths.
- Ward keeps reminding Harbor that proof-bearing return is not yet spendable trust.
- Helm and Schell both continue to argue for inspectable residue and explicit adoption instead of silent promotion.

## Brilliant ideas worth stealing carefully

1. **Consent parcel** — a staged, typed ask smaller than the browser leg and much smaller than durable local adoption.
2. **Return lease** — a short-lived aftermath object that can prove same-flow linkage without pretending to be permanent local truth.
3. **Compatibility floor** — the minimum route behavior guaranteed across environments, with richer narrowing only above that floor.
4. **Fallback memory** — a residue object recording which fallback path actually happened here.
5. **Adoption veto window** — a local interval where a successful return can still be refused before it turns into durable consequence.

## What pass X should not decide yet

Harbor still should not decide:
- whether consent parcels are a first-class family or a tiny annotation on detour leases;
- whether return leases belong in Harbor proper or are only a receipt flavor;
- whether compatibility floors should be global route metadata or local explanation residue.
