# SlopOS / companions evaluation — pass XX

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps boundary truths small and dislikes silent upgrades from weak outside facts to native authority.
- **Helm** keeps chooser/review surfaces visible instead of flattening them into invisible success.
- **Schell** keeps adoption gates alive after technically successful helper or provider turns.
- **ViewFS** keeps open/import/materialize/grant as neighboring but non-identical aftermaths.
- **Steward** keeps launch/completion/followthrough typed instead of hiding them in one success bit.

## Harbor consequence
Cross-device handoff should remain an exchange-membrane concern rather than leaking into Ward or Steward too early.
The new move is therefore small: add one more specimen around proximity/risk-bounded continuation and refuse to decide a universal cross-device object model yet.

## Still-not-yet decisions
- Whether proximity should be represented as a card, score, class, or family of signals.
- Whether timebounded handoff material belongs with continuation or with route aftermath.
- Whether Harbor should name a dedicated exploit-recovery object or keep that in Steward/Ward.
