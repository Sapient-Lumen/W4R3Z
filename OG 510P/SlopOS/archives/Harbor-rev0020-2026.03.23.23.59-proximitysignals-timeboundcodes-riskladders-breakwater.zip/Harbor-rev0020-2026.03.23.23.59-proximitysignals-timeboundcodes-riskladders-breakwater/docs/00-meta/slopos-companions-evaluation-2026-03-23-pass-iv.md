# SlopOS and companion-cube evaluation — 2026-03-23 pass IV

## Lessons to steal from SlopOS
- The OpenURI family in SlopOS proves that one generic launcher surface is a magnet for hidden questions: scheme support, handler selection, callback/reentry, launch completion, materialization, grant, verified association, and session selection all try to sneak in.
- `portal-net-proof-slice-v0.md` is a good process lesson even when Harbor is not a network cube: choose one proof-bearing specimen instead of deferring every hard question to a later grand unification.
- SlopOS keeps exact outward facts small and typed. Harbor should preserve that style for callbacks, route aftermath, and follow-on grants.

## Lessons to steal from siblings
- **ViewFS**: aftermath honesty is more important than convenience nouns. One “successful” open may imply no local object, a temporary carrier, a durable handle, or a fresh identity.
- **Helm**: change cursors and reset cards suggest a pattern Harbor can reuse for route/default/session reset without overcommitting to one implementation.
- **Schell**: adoption gates and live-checkout humility suggest Harbor should mark detours and returns with exact strength labels instead of pretending every callback restores a stable live relation.
- **Steward**: typed retry/pushback/countdown rails suggest Harbor should treat denial, partial return, and follow-up-required as first-class aftermath classes.

## Process result
Harbor should keep the archive pressure-safe by promoting **one specimen at a time** and recording every tempting new noun in the question registry or followthrough queue before it becomes architecture.
