# Research synthesis — 2026-03-23 pass VII

This pass concentrated on a quieter historical trap: route systems often do the right thing technically but still leave behind the wrong *story* about what happened.

## New lessons from outside systems

### 1) Ephemeral browser sessions are a route-property, not a trust upgrade
Apple’s `ASWebAuthenticationSession` allows a caller to request an ephemeral browser session that avoids sharing cookies and other browsing data with the user’s normal browser state. That is a powerful Harbor lesson: **session isolation belongs in the detour story**, not in the durable consequence story. Harbor should not let “we used an isolated browser turn” magically upgrade the resulting callback into stronger trust or account truth.

### 2) Associated domains and universal links are affiliation plus graceful fallback, not omniscience
Apple’s associated-domain and universal-link material keeps teaching the same lesson as Android App Links in a slightly different tone: app/site affiliation and claimed URL handling are useful, but when the preferred app route is unavailable the system can fall back to the website. Harbor should steal the **fallback ladder** idea: app, browser, chooser, or no-action are different honest route outcomes.

### 3) Browser-mediated identity is helpful precisely because it is narrower than total consent
FedCM migration guidance keeps reinforcing that the browser shows the prompts and that third-party cookies are no longer the control plane. The stealable lesson is not “the browser now decides trust”; it is “identity mediation can be smaller, more private, and more bounded than broader local consent or spend.”

### 4) Discovery metadata still wants to impersonate eligibility
Current MCP authorization and discovery work is valuable, but Harbor should keep discovery metadata, provider self-description, exact callback handling, and durable local route eligibility visibly separate. The pressure is real, but the antidote is still the same: **route hints are not route verdicts**.

## New lessons from SlopOS and companions

### SlopOS
- `openuri-auth-session-boundary-v0.md` and `browser-session-export-boundary-v0.md` reinforce the idea that browser-session choice and browser-session result are smaller than durable local truth.
- `openuri-verified-association-boundary-v0.md` continues to argue that affiliation belongs in the archive but remains weaker than present route truth.
- `auth-continuation-export-boundary-v0.md`, `auth-proof-export-boundary-v0.md`, and `auth-result-export-boundary-v0.md` remain a superb anti-collapse family: continuation, proof, and result are not the same strength.
- `openuri-install-fallback-boundary-v0.md` quietly supports Harbor’s new fallback-ladder theme: missing preferred routes should degrade honestly instead of turning into accidental acquisition or fake success.

### Siblings
- Helm keeps reinforcing that reset and review are product surfaces, not debug leftovers.
- Schell keeps reinforcing explicit adoption after helper or provider detours.
- Ward remains the necessary brake: isolated or browser-mediated route turns are still weaker than durable trust spend.
- Foundry adds a useful mirror image: when Harbor returns into foreign execution, route honesty matters even more because the next ground may be visibly non-native.

## Brilliant ideas worth stealing carefully

1. **Detour isolation request** — a typed request that asks for an isolated browser/session context without pretending isolation equals stronger trust.
2. **Fallback ladder** — a small object that records the sequence of preferred route classes and where the system actually landed.
3. **Association horizon** — a lightweight way to remember that affiliation data has age, scope, and reset needs rather than permanent route certainty.
4. **Post-return adoption gate** — a gate that keeps a legitimate return weaker than durable success until the local claimant, device, or workflow adopts it explicitly.
5. **Residue budget** — route residue (cookies, remembered handlers, previous choices) should be inspectable, exhaustible, and resettable instead of silently hardening.

## Current recommendation
Harbor still should not freeze a universal outcome object.

The next safe shape is:
- keep route hints, route proof, session isolation, fallback, and durable consequence separate;
- use specimen flow 04 to test whether ephemeral detours and fallback ladders want their own objects;
- and promote only the nouns that survive both browser-auth and associated-domain style specimens without lying.
