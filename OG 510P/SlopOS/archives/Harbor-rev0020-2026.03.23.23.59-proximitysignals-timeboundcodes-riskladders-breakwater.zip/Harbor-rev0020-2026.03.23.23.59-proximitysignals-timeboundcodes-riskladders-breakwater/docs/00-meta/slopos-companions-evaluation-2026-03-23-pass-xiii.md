# SlopOS + companions evaluation — pass XIII

This pass reads SlopOS and the current companions as evidence that Harbor should get better at **cross-locus honesty** rather than broadening into generic auth architecture.

## Lessons from the datacubes
1. **SlopOS keeps auth continuation separate from durable auth result.**
   The primary archive already contains auth continuation, browser session, auth proof export, and auth result export as separate seams. Harbor should stay compatible with that discipline by making handoff and continuation objects smaller than any final local adoption object.

2. **Schell already cares about wake tickets, resident rooms, and handback leases.**
   That sibling pressure suggests Harbor should learn from out-of-band return patterns instead of assuming same-tab or same-route callbacks.

3. **ViewFS keeps imported identity and applied truth visibly separate.**
   Harbor should therefore avoid saying “the browser finished” when the only honest result is that a cross-device handoff has become eligible for a later local adoption step.

4. **Steward's lifecycle honesty is a warning against fake completion.**
   Harbor needs the same discipline for cross-device approval: a flow may be in-progress elsewhere, completed elsewhere, or adoption-ready locally, and those are not the same fact.

## Resulting cube move
Do not decide yet whether Harbor's durable vocabulary should center on `continuation leash` or `handoff docket`. For now, keep them as specimen nouns and demand that they improve at least one same-device callback flow and one cross-device/user-code flow.
