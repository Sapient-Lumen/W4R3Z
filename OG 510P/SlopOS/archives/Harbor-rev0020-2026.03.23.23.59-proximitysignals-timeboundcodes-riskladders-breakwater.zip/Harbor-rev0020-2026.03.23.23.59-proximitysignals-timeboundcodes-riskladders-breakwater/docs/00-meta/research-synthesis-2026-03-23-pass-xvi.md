# Research synthesis — pass XVI

This pass keeps Harbor narrow and learns one more thing from outside routing and auth systems: **a finished callback still needs explicit origin identity when one client can talk to more than one authorization authority**.

## Outside lessons
1. **RFC 9207 says the authorization response needs an explicit issuer identity.**  
   The `iss` parameter exists because a callback can arrive correctly shaped and still come from the wrong authorization server. Harbor should steal the discipline: return continuity needs an explicit origin card, not just route exactness.

2. **OAuth security guidance treats mix-up as a real class of failure, not a corner case.**  
   The danger appears the moment one client talks to more than one authorization server or later adds a second server. Harbor should assume that “one provider today” can become “many providers tomorrow”, especially in tool ecosystems.

3. **Issuer identity is still smaller than local adoption.**  
   Knowing which authority emitted a finish is stronger than a plain redirect and weaker than durable local acceptance. Harbor should preserve that intermediate truth rather than flattening it into either callback success or final adoption.

4. **The uploaded cube ecology reinforces this split.**  
   SlopOS keeps auth continuation provider-local, keeps OpenURI meaning seams enumerable, and avoids portable pending-auth folklore. Harbor can therefore add issuer honesty without widening local adoption.

## Resulting Harbor move
Do not decide yet whether the durable noun is `issuer pin`, `origin card`, or `mix-up veto`.
For now, keep all three alive as specimen nouns and demand that they improve:
- one single-provider specimen that later adds a second provider,
- one shared-callback / shared-surface specimen,
- and one clean callback that is rejected because issuer identity does not line up.

## Fresh ideas worth stealing
- **issuer pin** — the expected authority identity for this crossing, carried separately from callback proof.
- **origin card** — compact residue about which authority actually emitted the finish.
- **mix-up veto** — explicit local refusal when origin identity and prepared expectation diverge.
- **second-provider cliff** — a reminder that single-provider comfort often becomes multi-provider danger without any product rename.
