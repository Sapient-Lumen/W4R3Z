# Research synthesis — 2026-03-23 pass V

This pass stayed disciplined in two ways:
1. it reread the most relevant SlopOS and sibling cuts instead of treating the embryos as blank slates;
2. it harvested fresh outside ideas specifically for **anti-regrowth** rather than for premature architecture closure.

## What the past keeps teaching Harbor
- Native-app OAuth keeps repeating the same warning: the browser detour is normal, but the detour itself is not durable trust. RFC 8252 and current OAuth 2.1 posture still center the external browser, exact redirect handling, and proof of possession via PKCE; Harbor should treat these as a **return-path discipline**, not as a general launcher success story.
- XDG portals keep one of the best old lessons alive: a user-mediated open or file selection is a narrower fact than ongoing general authority. The Documents portal is especially useful because it separates user-selected access from broad filesystem reach.
- Android App Links and Apple associated domains are valuable precisely because they are **verifiable affiliation material**. They do not make every matching route safe, final, or system-native.
- FedCM sharpens another old lesson: a browser-mediated identity turn can reduce redirect chaos and privacy leakage, but the browser UI is not the same thing as local durable account relation or local system grant.
- MCP’s recent authorization and registry work adds a very current warning: self-reported server metadata, discovery metadata, and enterprise policy controls are important, but Harbor should not treat registry discovery or self-description as route truth or trust truth.

## What the cubes reinforced
- SlopOS’s OpenURI family is still the clearest proof that route surfaces regrow hidden questions unless each seam is pinned separately.
- SlopOS’s auth-mediation family keeps redirects, sessions, login state, proofs, results, and continuation mechanics distinct enough that Harbor does not have to guess where those seams belong.
- ViewFS keeps reminding Harbor that imported source refs, materialized objects, fresh local identities, and receipts are not the same event.
- Helm’s reset-card habit is becoming more central, not less: link/handler/session defaults need reset and rehearing surfaces instead of sticky implicit drift.
- Steward’s narrow aftermath rails remain a great counter-pressure against Harbor becoming a giant story generator.

## Brilliant ideas worth stealing carefully
1. **Affiliation hint card** — a typed object for “the platform or provider can verify some app/site relationship,” but one that cannot pretend to be a grant, a handler choice, or a local trust verdict.
2. **Detour lease** — a bounded object for browser or remote-provider excursions with explicit expiry, expected return channels, and aftermath strength labels.
3. **Return-path proof classes** — exact-match callback, claimed-HTTPS association, loopback return, local receipt-only return, or “no bindable return” should be visibly different classes.
4. **Chooser residue budget** — a process idea stolen from portal and default-app history: remembered choices should have an explicit reset/review surface and should never silently harden into invisible routing law.
5. **Controlled-import bridge** — a design move where a route outcome may lead into ViewFS-style controlled import/materialization without Harbor pretending that “open” always produces a native durable object.
6. **Registry humility** — imported MCP discovery or capability metadata should arrive as hints, not as first-class route truth.

## Current recommendation
Harbor should still avoid freezing a grand route taxonomy. The next safe move is to see whether one vocabulary survives at least two visibly different specimens:
- a browser-detour auth return, and
- a verified-association / controlled-import turn.

If the same nouns survive both, they may deserve promotion. If not, Harbor should keep the split visible instead of forcing a premature unification.
