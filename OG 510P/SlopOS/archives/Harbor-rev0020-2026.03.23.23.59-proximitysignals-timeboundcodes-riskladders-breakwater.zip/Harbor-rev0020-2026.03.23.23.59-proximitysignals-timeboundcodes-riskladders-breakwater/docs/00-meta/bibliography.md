# Bibliography

- **EXT-MCP-AUTH-2026** — Model Context Protocol, Understanding Authorization in MCP — https://modelcontextprotocol.io/docs/tutorials/security/authorization
- **EXT-MCP-AUTH-SPEC-2025** — Model Context Protocol Authorization spec (2025-06-18) — https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization
- **EXT-RFC-8252** — IETF RFC 8252, OAuth 2.0 for Native Apps — https://www.rfc-editor.org/rfc/rfc8252.html
- **EXT-RFC-7636** — IETF RFC 7636, Proof Key for Code Exchange — https://www.rfc-editor.org/rfc/rfc7636.html
- **EXT-OAUTH-2-1-2026** — IETF OAuth 2.1 draft — https://datatracker.ietf.org/doc/draft-ietf-oauth-v2-1/
- **EXT-XDG-PORTAL** — XDG Desktop Portal overview — https://flatpak.github.io/xdg-desktop-portal/
- **EXT-XDG-OPENURI** — XDG Desktop Portal, OpenURI — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html
- **EXT-XDG-DOCUMENTS** — XDG Desktop Portal, Documents — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
- **EXT-ANDROID-VERIFY-APP-LINKS** — Android Developers, Verify App Links — https://developer.android.com/training/app-links/verify-applinks
- **EXT-APPLE-ASSOCIATED-DOMAINS** — Apple, Supporting associated domains — https://developer.apple.com/documentation/xcode/supporting-associated-domains
- **EXT-FEDCM** — W3C Federated Credential Management API — https://www.w3.org/TR/fedcm/
- **EXT-MCP-SEPS-2026** — MCP SEPs index (including auth, registry, and enterprise-control work) — https://modelcontextprotocol.io/seps
- **EXT-MCP-ROADMAP-2026** — MCP roadmap security and authorization work — https://modelcontextprotocol.io/development/roadmap
- **EXT-DIGITAL-ASSET-LINKS** — Google Digital Asset Links — https://developers.google.com/digital-asset-links/v1/getting-started
- **EXT-APPLE-UNIVERSAL-LINKS** — Apple universal links and associated domains — https://developer.apple.com/documentation/xcode/supporting-universal-links-in-your-app
- **EXT-FEDCM-CHROME** — Chrome FedCM overview — https://developer.chrome.com/docs/identity/fedcm/overview
- **EXT-OAUTH-CROSS-DEVICE-2025** — IETF draft, Cross-Device Flows: Security Best Current Practice — https://datatracker.ietf.org/doc/draft-ietf-oauth-cross-device-security/
- **EXT-XDG-FILETRANSFER** — XDG Desktop Portal, FileTransfer — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
- **EXT-OAUTH-FIRST-PARTY-2026** — IETF draft, OAuth 2.0 for First-Party Applications — https://datatracker.ietf.org/doc/draft-ietf-oauth-first-party-apps/
- **EXT-ANDROID-DYNAMIC-APP-LINKS** — Android Developers, About App Links / Dynamic App Links — https://developer.android.com/training/app-links/about
- **EXT-FEDCM-W3C** — W3C Federated Credential Management API — https://www.w3.org/TR/fedcm/
- **EXT-APPLE-ASWEBAUTH-EPHEMERAL** — Apple, `prefersEphemeralWebBrowserSession` — https://developer.apple.com/documentation/authenticationservices/aswebauthenticationsession/prefersephemeralwebbrowsersession
- **EXT-APPLE-UNIVERSAL-LINKS-2026** — Apple, supporting universal links — https://developer.apple.com/documentation/xcode/supporting-universal-links-in-your-app
- **EXT-FEDCM-MIGRATION-2026** — Google Identity, FedCM migration guide — https://developers.google.com/identity/gsi/web/guides/fedcm-migration

- **EXT-RFC-9126** — IETF RFC 9126, OAuth 2.0 Pushed Authorization Requests — https://www.rfc-editor.org/rfc/rfc9126.html
- **EXT-RFC-9449** — IETF RFC 9449, OAuth 2.0 Demonstrating Proof of Possession (DPoP) — https://www.rfc-editor.org/rfc/rfc9449.html

- **EXT-RFC-9396** — IETF RFC 9396, OAuth 2.0 Rich Authorization Requests — https://www.rfc-editor.org/rfc/rfc9396.html
- **EXT-ANDROID-DYNAMIC-APP-LINKS-COMPAT** — Android Developers, Dynamic App Links compatibility FAQ — https://developer.android.com/training/app-links/faq
- **EXT-XDG-DOCUMENTS-FUSE** — XDG Desktop Portal, Documents & FUSE — https://flatpak.github.io/xdg-desktop-portal/docs/documents-and-fuse.html
- **EXT-FEDCM-PRIVACY-2025** — Privacy Sandbox FedCM overview — https://privacysandbox.google.com/cookies/fedcm

- **EXT-RFC-9635** — IETF RFC 9635, Grant Negotiation and Authorization Protocol (GNAP) — https://www.rfc-editor.org/rfc/rfc9635.html
- **EXT-RFC-8628** — IETF RFC 8628, OAuth 2.0 Device Authorization Grant — https://www.rfc-editor.org/rfc/rfc8628.html
- **EXT-CIBA-FINAL** — OpenID Client-Initiated Backchannel Authentication Core 1.0 — https://openid.net/specs/openid-client-initiated-backchannel-authentication-core-1_0-final.html
- **EXT-JARM-FINAL** — JWT Secured Authorization Response Mode for OAuth 2.0 — https://openid.net/specs/oauth-v2-jarm-final.html

- **EXT-RFC-9207** — IETF RFC 9207, OAuth 2.0 Authorization Server Issuer Identification — https://www.rfc-editor.org/rfc/rfc9207.html
- **EXT-RFC-9700** — IETF RFC 9700, Best Current Practice for OAuth 2.0 Security — https://www.rfc-editor.org/rfc/rfc9700.html
- **EXT-RFC-9470** — IETF RFC 9470, OAuth 2.0 Step Up Authentication Challenge Protocol — https://www.rfc-editor.org/rfc/rfc9470.html
- **EXT-RFC-9728** — IETF RFC 9728, OAuth 2.0 Protected Resource Metadata — https://www.rfc-editor.org/rfc/rfc9728.html
- **EXT-RFC-8414** — IETF RFC 8414, OAuth 2.0 Authorization Server Metadata — https://www.rfc-editor.org/rfc/rfc8414.html
- **EXT-OAUTH-CROSS-DEVICE-2026** — IETF draft, Cross-Device Flows: Security Best Current Practice — https://datatracker.ietf.org/doc/html/draft-ietf-oauth-cross-device-security-15
