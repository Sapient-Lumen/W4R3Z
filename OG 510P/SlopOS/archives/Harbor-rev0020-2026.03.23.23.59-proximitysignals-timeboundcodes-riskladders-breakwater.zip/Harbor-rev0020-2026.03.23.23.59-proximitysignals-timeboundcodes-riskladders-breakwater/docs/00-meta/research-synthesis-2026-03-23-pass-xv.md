# Research synthesis — pass XV

This pass keeps Harbor narrow and learns one more thing from outside routing and auth systems: **some crossings deserve a signed or structured finish object without letting that object become local adoption**.

## Outside lessons
1. **CIBA treats user interaction as legitimately out-of-band.**  
   The client can initiate a challenge and later receive status or a result without a browser redirect on the consumption device. Harbor should steal the honesty: a useful crossing may finish somewhere else, through another device or surface, without that making the local machine’s posture magically clear.

2. **JARM protects the finish payload, not the downstream policy.**  
   A signed or encrypted authorization response is a strong reminder that *finish residue can have integrity* while still remaining smaller than local adoption. Harbor should preserve the distinction between an authentic finish envelope and the later local decision to rely on it.

3. **OAuth hardening still rewards smaller and more explicit continuation.**  
   PKCE, pushed requests, typed requests, and exact redirect handling all point in the same direction: reduce mutable browser legs, keep finish modes typed, and make local adoption explicit.

4. **The current cube ecology keeps this split healthy.**  
   In the uploaded companion archives, Helm keeps review surfaces explicit, ViewFS keeps open/import/materialize separate, Steward keeps aftermath typed, and SlopOS keeps portal, consent, and lease ideas narrow instead of magical.

## Resulting Harbor move
Do not decide yet whether the durable noun is `backchannel challenge`, `finish envelope`, or `veto floor`.
For now, keep all three alive as specimen nouns and demand that they improve:
- one same-device callback specimen,
- one cross-device or out-of-band specimen,
- and one signed-finish / locally-vetoed specimen.

## Fresh ideas worth stealing
- **backchannel challenge** — a truthful object for an in-flight crossing whose user work is happening elsewhere.
- **finish envelope** — an integrity-bearing return packet that remains smaller than durable local consequence.
- **veto floor** — the weakest still-true local aftermath after a legitimate finish is locally narrowed or refused.
- **finish provenance** — a compact story of *how* the finish was obtained: redirected callback, device handoff, backchannel poll, ping, or browser escalation.
