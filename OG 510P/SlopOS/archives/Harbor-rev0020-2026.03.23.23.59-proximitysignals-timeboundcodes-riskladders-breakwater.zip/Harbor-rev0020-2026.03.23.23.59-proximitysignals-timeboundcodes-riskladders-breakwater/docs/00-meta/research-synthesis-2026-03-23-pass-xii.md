# Research synthesis — pass XII

This pass keeps Harbor embryonic while stealing a few cleaner habits from mature authorization and mediation systems.

## Fresh outside lessons
1. **GNAP makes continuation itself explicit.**
   GNAP formalizes a continuation URI plus a continuation access token and separates interaction start modes from interaction finish methods. That is a strong clue for Harbor: the thing that keeps a crossing alive is not the same object as the original request, the visible detour, or the final adopted consequence.

2. **Typed requested consequence still wants a smaller browser leg.**
   RAR and PAR remain a healthy combination: keep requested consequence structured, then shrink the browser leg to a reference or a small continuation-bearing turn. Harbor should avoid rediscovering giant mutable browser URLs or treating callback arrival as universal success.

3. **Proof-bound continuation is useful, but it is still not durable local truth.**
   DPoP and OAuth 2.1 hardening reinforce that exact redirect handling, PKCE, and sender-constrained exchange improve the return path. They do not answer the stronger local question: what is durably true after this crossing?

4. **Browser mediation still has a bounded scope.**
   FedCM remains a helpful warning: a browser-mediated identity step can be privacy-improving and user-legible while still being only one bounded admission step in a larger local workflow.

## Resulting Harbor pressure
Harbor should likely preserve at least four distinct moments:
- **typed request**: what consequence is being asked for;
- **detour/interaction start**: how the user leaves the current locus;
- **continuation / finish material**: what proves that the same crossing can progress or complete;
- **local adoption**: what consequence is actually admitted locally.

## Brilliant ideas worth stealing
- **continuation shelf** — a small first-class object for “this crossing is still live and here is how it may continue”;
- **finish method card** — a typed account of how a crossing can legitimately complete: redirected callback, direct HTTP completion, application URI rebound, or user-code return;
- **capability floor** — the weakest still-true statement after degraded routing or partial return, so Harbor can be honest without collapsing to binary failure.
