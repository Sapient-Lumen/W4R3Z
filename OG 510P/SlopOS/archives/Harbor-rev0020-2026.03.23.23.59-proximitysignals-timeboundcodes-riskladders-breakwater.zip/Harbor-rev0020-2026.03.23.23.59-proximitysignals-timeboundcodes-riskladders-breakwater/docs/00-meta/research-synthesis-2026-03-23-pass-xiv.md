# Research synthesis — pass XIV

This pass keeps Harbor narrow and learns one more thing from outside systems: **continuation and finish deserve their own truthful residue**.

## Outside lessons
1. **GNAP makes finish depend on an interaction reference.**  
   That is a strong hint that “the flow is still live” should be smaller than any final adopted consequence. Harbor should steal the habit of carrying a compact continuation reference instead of flattening everything into a generic callback-success object.

2. **RFC 8628 shows that cross-device completion needs a real handoff packet.**  
   `verification_uri`, `verification_uri_complete`, and `user_code` are not implementation trivia. They are evidence that a detour may need a bounded human-readable completion ticket that is operationally useful but still weaker than durable local success.

3. **First-party native OAuth work keeps browser escalation explicit.**  
   A native flow may proceed directly until risk, recovery, or unsupported methods force `redirect_to_web`. Harbor should therefore preserve *why* a flow changed finish mode instead of pretending every finish came back through the same route class.

4. **OAuth hardening continues to reward smaller browser legs.**  
   Typed request content, PKCE, exact redirect matching, and proof-bound continuation all point the same way: keep mutable intent, detour liveness, and durable local adoption separate.

## Resulting Harbor move
Do not decide yet whether the durable noun is `interaction reference`, `finish ticket`, or `adoption checkpoint`.  
For now, keep all three alive as specimen nouns and demand that they improve:
- one same-device callback flow,
- one cross-device handoff flow,
- and one risk-driven browser escalation flow.

## Fresh ideas worth stealing
- **interaction ref card** — a bounded pointer proving which crossing can still continue.
- **finish ticket** — a small handoff/rebound packet that says how completion can happen, without claiming that it already has.
- **adoption checkpoint** — the explicit local turn where Harbor admits a finish into durable local consequence.
- **reasoned finish mode** — redirected callback, device-code handoff, browser escalation, weak timeout, or denied completion should remain visibly different.
