# Research synthesis — 2026-03-23 pass VI

This pass was careful in a slightly different way than pass V. Instead of trying to prove a grand Harbor object model, it looked for **failure modes that remain invisible until a route crosses devices, apps, or mediation layers**.

## New lessons from outside systems

### 1) Cross-device approval can authorize the wrong session
Recent OAuth cross-device security work keeps stressing an ugly pattern: a user may present legitimate credentials or wallet material on one device, but the session that becomes authorized is the attacker-controlled session on another device. Harbor should therefore preserve a distinction between:
- **where the user approved**,
- **which detour instance asked for approval**,
- **which local process or route is claiming the return**, and
- **what class of aftermath is safe before same-device or same-route rebinding happens**.

This argues for a Harbor object that is weaker than durable success: a **return fence** or **rebound-needed** aftermath class.

### 2) File exchange middlemen are healthier than fake direct openness
The XDG FileTransfer portal is extremely useful as a pattern because it operates as a middle-man for drag-and-drop and copy-paste while taking care of exporting files through the Documents portal. Harbor should steal the idea that some exchanges are healthiest when they stay visibly mediated all the way through instead of pretending a file or object was “just there”.

### 3) Server-side route refinements should narrow, not widen
Android’s Dynamic App Links model is a surprisingly sharp design lesson. Server-side rules can refine or exclude routing behavior, but they do not get to widen the original static scope declared in the app manifest. Harbor should steal that shape:
- dynamic route hints may **narrow**,
- may **exclude**,
- may **reset to pre-choice posture**,
- but should not silently widen native eligibility beyond what the local side already declared.

### 4) First-party native challenge flows are tempting and valuable, but they do not erase risk detours
The current OAuth first-party applications draft shows why designers keep reaching for browserless or mostly-native challenge flows: they can give a tighter and calmer local UX. The lesson Harbor should steal is not “replace browser detours”; it is “model **challenge-native** and **risk-escalated browser detour** as separate route classes”.

### 5) Browser-mediated identity remains useful precisely because it is narrower than general trust
FedCM still points toward privacy-preserving browser mediation. The stealable idea is not just “let the browser help”; it is “keep **identity turn**, **permission turn**, **route turn**, and **local consequence** visibly different even when the UI feels unified”.

## New lessons from SlopOS and companions

### SlopOS
- The OpenURI boundary family already behaves like Harbor’s pressure atlas. The important lesson is procedural: once a seam becomes nameable, it stops smuggling itself in as launcher convenience.
- `openuri-callback-reentry-boundary-v0.md` and the auth/export boundaries suggest that return-path truth is already being treated as a crisp seam rather than an emotional idea of “we got back”.
- `import-to-docref-*` continues to confirm that Harbor should stop at the membrane and hand off when durable local object truth begins.

### Siblings
- Helm’s reset-card instinct is stronger after rereading Android’s reset flow. Reset is not an embarrassment; it is part of route hygiene.
- ViewFS gives Harbor a concrete honesty test: transfer, import, materialization, and fresh identity are not allowed to share one receipt.
- Ward keeps supplying the right resistance: successful return is not the same as trust spend.
- Foundry adds a growing reminder that some Harbor outcomes terminate in foreign grounds where route aftermath must stay honest without pretending the execution became native.

## Brilliant ideas worth stealing carefully

1. **Return fence** — an aftermath object for “the detour came back, but the route still needs local rebound, same-device proof, or explicit adoption before it becomes durable.”
2. **Middleman exchange card** — a typed object for copy/paste, drag/drop, or imported handoff where Harbor records mediation strength instead of flattening everything into “shared”.
3. **Dynamic narrowing rules** — a Harbor rule family in which route refinements may only narrow or exclude within a predeclared scope.
4. **Challenge-native / risk-browser split** — a design split that keeps native challenge UX and browser escalations under one archive without claiming they are the same class of turn.
5. **Chooser residue budget** — remembered route state should age, reset, and be inspectable instead of quietly hardening into forever defaults.

## Current recommendation
Harbor still should not freeze a complete taxonomy. The safest next move is to pressure-test three visibly different specimens:
- browser detour with callback proof,
- verified association plus controlled import,
- and mediated file transfer with route reset and rebound-needed aftermath.

If the same core nouns survive those three, they deserve promotion. If not, Harbor should prefer multiple honest aftermath classes over one impressive lie.
