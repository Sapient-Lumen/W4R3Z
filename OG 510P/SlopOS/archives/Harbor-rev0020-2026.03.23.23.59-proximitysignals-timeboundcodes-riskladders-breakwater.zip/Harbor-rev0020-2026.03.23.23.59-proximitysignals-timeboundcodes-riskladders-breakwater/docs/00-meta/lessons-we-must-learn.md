# Lessons we must learn

Harbor should begin by learning from mistakes that older portal, auth, and deep-link systems keep making.

## 1) Embedded auth convenience keeps rotting into a trust bug
Browser-based authorization survived because embedded auth surfaces kept making phishing, cookie confusion, and invisible session reuse too easy. Harbor should therefore treat **browser detours as a first-class route class**, not as a regrettable exception that will be abstracted away later.

## 2) Callback arrival is not the same as durable success
Old designs often act as if “the redirect came back” means the operation is complete and trustworthy. Harbor should keep callback proof, provider response, durable account binding, and local trust consequence as different objects.

## 3) Verified association is not route truth
App-link and associated-domain ecosystems are useful because they prove affiliation between an app and a web origin. They are dangerous when that proof is allowed to silently answer stronger questions such as “this route is definitely available now”, “the user prefers this handler”, or “this target is trusted forever”.

## 4) Open, import, materialize, and grant should stay different
Many ecosystems blur “open this”, “download this”, “save this”, and “give me durable access to this”. Harbor must resist that blur. A good membrane tells you what kind of aftermath happened instead of flattering you with one catch-all success bit.

## 5) Browser or portal UI is not generic consent
Browser-mediated identity and chooser UIs can be powerful and still not count as general legal, organizational, or durable trust consent. Harbor should keep review surfaces visible while refusing to let their existence settle every downstream policy question.

## 6) Provider-local session state should stay provider-local until proved otherwise
Session cookies, browser profiles, account pickers, or “already signed in” hints are helpful inputs. They are not portable system truth. Harbor should record them, if at all, as weak route context rather than as durable local state.

## 7) Route state sometimes needs an explicit reset card
Android’s verified-link workflow is a useful reminder that users and systems sometimes need to reset a route back to a **pre-default / pre-choice** posture. Harbor should consider a reset-card or reset-advice object instead of pretending route state only ever moves forward.

## 8) Controlled document mediation is a different strength than generic open
XDG’s Documents portal shows that “make this outside file available in a controlled way” is stronger and more durable than “open this URI under user control.” Harbor should not hide that difference inside a generic aftermath blob.

## 9) Detours deserve a lease-like object, not a magical in-between void
Between outbound request and callback arrival there is a real design object: a detour that can expire, be cancelled, or return weakly. Harbor should likely treat that interval as a first-class, bounded thing rather than an undocumented gap.

## rev0005 additions
- Verified association is useful, but affiliation must remain weaker than a grant, a handler choice, or a durable local relation.
- Registry discovery and provider self-description are hints that may improve routing, not truth that should automatically outrank local policy or user review.
- Browser-mediated identity turns reduce redirect chaos, but Harbor must still keep route proof separate from downstream trust or spend.

## rev0007 additions
- Cross-device approvals can authorize the wrong claimant unless Harbor keeps approval locus, return-path proof, and local rebound visibly separate.
- Dynamic route rules are healthiest when they narrow or exclude within a predeclared scope instead of silently widening local eligibility.
- Middle-man transfer surfaces are often more honest than fake direct openness because they preserve mediation strength all the way to controlled import.
- Ephemeral browser sessions are useful because they isolate cookie reuse and browsing residue, but that isolation is a route-property request rather than a durable trust consequence.
- Association files and universal-link/app-link systems should teach fallback honesty: a route may legitimately degrade to web, chooser, or no-action without becoming a lie.
- The place where a return lands still needs explicit local adoption; a legitimate callback can be operationally useful while remaining too weak for durable local success.

## rev0008 additions
- PAR is a sharp reminder that the browser leg can be reduced to an opaque request reference; Harbor should preserve the distinction between a staged request parcel and the user-visible detour.
- Sender-constrained return exchange is useful because it narrows replay, but proof-of-possession is still smaller than durable local trust or account consequence.
- Opaque request references, detour leases, and callback proofs probably age on different clocks; Harbor should not flatten them into one “still valid” bit.
## rev0011 additions
- Typed requested consequence should remain smaller than both the browser leg and any later adopted consequence.
- Exact redirect matching and proof-bound continuation are valuable because they reduce ambiguity and replay, but neither one is durable local truth.
- Browser-mediated identity or consent UX can be excellent and still remain only one route/admission step on the path to local adoption.

## rev0013 additions
- Continuation is not just leftover state; systems like GNAP suggest it deserves an explicit, bounded object with its own proof and expiry story.
- A crossing may have several legitimate finish methods, and Harbor gets healthier when completion class is typed instead of hidden in one generic callback-success bucket.
- Degraded or partial routes still need an honest weakest-truth object, otherwise products are tempted to overclaim or to erase useful residue entirely.


- Cross-device approval is not a pathological edge case; it deserves first-class honesty.
- Native-first flows still need an explicit browser-escalation story for risk, recovery, and unsupported methods.

## rev0014 additions
- Interaction references are useful precisely because they are smaller than full success and smaller than durable adoption.
- A finish packet that helps a user or client continue a crossing should not silently become the proof that the crossing is locally adopted.
- Same crossing, different finish methods is a normal condition; Harbor should tell the truth about which finish happened instead of normalizing everything into callback success.

## rev0015 additions
- Backchannel or out-of-band success is still a kind of route truth, not an automatic local adoption truth.
- Signed or integrity-protected finish material is powerful precisely because it can stay smaller than durable consequence.
- A locally narrowed aftermath deserves its own floor object; otherwise clean finishes overclaim or disappear.

## rev0016 additions
- Exact callback shape is not enough when one client can speak to more than one authority; route origin needs explicit identity.
- Adding a second provider later can retroactively turn an apparently safe callback shape into a mix-up risk.
- Issuer identity is strong enough to veto and still smaller than durable local adoption.

## rev0019 additions
- A protected request is still smaller than an adopted consequence; preparation should not quietly become success.
- A third-party policy witness can narrow or explain a crossing without turning Harbor into a universal consent or governance plane.
- Signed finish material is valuable precisely because it can remain smaller than durable local adoption.

## rev0019 additions
- A protected resource can truthfully say “the token is real but not strong or recent enough”; Harbor should preserve that step-up challenge as a route object instead of flattening it into generic failure.
- Resource metadata and authorization-server metadata are useful because they let a client discover and cross-check where to go next, not because they eliminate the need for local adoption.
- Same request, higher assurance is a normal staircase; Harbor should tell the truth about climb, rebound, and veto rather than pretending every successful detour is the same class of finish.

## Pass XIX addition
- Do not overload scope with resource identity. Keep requested power, redeeming audience, detour finish, and local adoption separate.

## Pass XX additions
- Cross-device handoff material can be real and still too weak for full-strength adoption.
- Proximity is often best treated as a risk signal, not as timeless route truth.
- Short-lived, limited-use codes are valuable precisely because they stay smaller than durable continuation.
- When a code is copied into a new context, the truthful result may be a weaker ladder rung or an explicit veto rather than generic failure.
