# Charter

        **Mission:** Harbor is the companion cube for boundary crossings: openings, imports, browser detours, callbacks, chooser turns, materialization, handback, and explicit follow-on grants.

        ## North-star sentence
        Crossing a membrane must never silently upgrade weak outside facts into native authority or local truth.

        ## Non-goals
        - becoming a generic networking or browser stack
- owning durable identity, trust roots, or local appraisal
- swallowing object identity, lifecycle truth, or shell ownership wholesale
- flattening import, open-in-place, reveal, launch, and materialize into one event


        ## Sibling pressure map
        - **Helm**: shell-owned front doors, chooser UX, reveal/open chrome, and user-review surfaces
- **Schell**: CLI and tool handoff, helper lanes, provider detours, and callback continuity
- **ViewFS**: import, open-in-place, fresh identity, and grant persistence
- **Steward**: launch/completion truth, follow-on actions, and accountable aftermath
