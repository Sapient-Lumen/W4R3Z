# SlopOS and companions evaluation — pass XVI

This pass keeps Harbor aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** keeps `auth-continuation-export` narrow and refuses to turn local login progress into a portable continuation broker. That makes issuer identity a Harbor problem, not an excuse to widen portable auth state.
- **SlopOS** also keeps OpenURI families enumerable, which is a good precedent for keeping return-origin facts typed instead of hiding them in one callback blob.
- **Helm** still wants reviewable front-door residue, so an origin card is useful only if it can be shown without pretending it is durable trust.
- **Schell** still wants provider/helper returns that may succeed operationally before they deserve promotion; multi-provider confusion is therefore realistic, not hypothetical.
- **ViewFS** still keeps import/open/materialize separate, which argues for keeping origin identity separate from adoption too.
- **Steward** still benefits from typed aftermath classes rather than one giant completion object.

## Pressure on Harbor
Harbor should not decide yet whether issuer identity belongs inside finish envelopes, inside continuation objects, or in its own small family.
The stronger move is to keep one more specimen where:
1. two possible authorities can legitimately answer,
2. the callback looks structurally fine,
3. issuer identity or origin identity still vetoes adoption,
4. and the archive preserves honest residue about what happened.

## Promotion restraint
Do not promote `issuer pin`, `origin card`, or `mix-up veto` unless they improve:
- one future-second-provider specimen,
- one shared redirect or shared callback specimen,
- and one case where a clean finish is locally refused because the authority is wrong.
