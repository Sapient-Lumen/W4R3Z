# SlopOS and companions evaluation — pass XVIII

This pass keeps Harbor aligned with the uploaded cube ecology without forcing premature closure.

## What the current cubes keep teaching
- **SlopOS** keeps auth-mediation and auth-continuation seams small and explicitly resists portable callback/token broker growth. That argues for keeping request objects and finish envelopes as Harbor residue, not exported account or grant truth.
- **SlopOS** also keeps import-to-docref and OpenURI families enumerable, which is a good precedent for typed crossing residue instead of one generic success blob.
- **Helm** still wants reviewable front-door residue, so a policy witness is useful only if it remains inspectable and smaller than durable trust.
- **Schell** still wants provider/helper turns that can succeed operationally before promotion; signed finish material therefore needs an explicit adoption veto.
- **ViewFS** still keeps open, import, materialize, and durable identity separate, which argues against letting signed finish material collapse outcome classes.
- **Steward** still benefits from typed aftermath classes rather than one giant completion object.

## Pressure on Harbor
Harbor should not decide yet whether request objects and finish envelopes belong inside detour leases, continuation objects, or a separate small family.
The stronger move is to keep one more specimen where:
1. the request is integrity-bearing before the browser leg,
2. the finish is integrity-bearing when it returns,
3. a third-party policy witness exists and is still smaller than local adoption,
4. and local policy may still refuse durable consequence.

## Promotion restraint
Do not promote `request object`, `policy witness`, or `signed finish envelope` unless they improve:
- one by-reference request specimen,
- one reviewed-policy specimen,
- and one signed finish that still fails local adoption.

