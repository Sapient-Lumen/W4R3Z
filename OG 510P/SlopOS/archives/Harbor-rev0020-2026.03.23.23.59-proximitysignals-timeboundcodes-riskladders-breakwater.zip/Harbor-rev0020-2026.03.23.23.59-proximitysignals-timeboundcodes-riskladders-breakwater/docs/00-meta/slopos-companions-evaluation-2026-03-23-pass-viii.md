# SlopOS / companions evaluation — 2026-03-23 pass VIII

This pass evaluated how Harbor should react to the newest pass VIII lessons without starting to impersonate either SlopOS internals or Ward’s trust lane.

## SlopOS lessons that matter right now

### 1) Continuation humility is already a deep local habit
`auth-continuation-export-boundary-v0.md` is one of the strongest warnings in the whole ecology: local auth progress should not silently widen into a generic continuation-handle broker. Harbor should respect that habit even while exploring **request references** and **detour leases**.

### 2) Proof and result are already smaller than each other
The auth proof / auth result boundaries in SlopOS strongly support Harbor’s pass VIII split. A proof-bound return can matter operationally while still remaining weaker than a durable result. Harbor should copy that compression without freezing exact SlopOS nouns.

### 3) Request shaping remains a separate pressure
`openuri-request-shaping-boundary-v0.md` keeps Harbor honest. PAR is inspiring because it shrinks the browser-visible leg, not because it invites Harbor to own arbitrary request-header/body construction or general auth choreography.

### 4) Import and controlled document paths stay stronger than generic opening
Nothing in pass VIII weakens the earlier Harbor lesson that open, import, materialize, transfer, and durable grant should remain visibly different. If anything, an opaque request parcel makes that distinction even more important because less of the action is visible in the detour itself.

## Companion-cube effects

### Helm
Helm should likely own the visible explanation of opaque auth parcels, fallback ladders, and detour-binding status without claiming those objects become shell truth by mere display.

### Schell
Schell is where Harbor’s new pass VIII ideas become useful quickly: helpers, browser detours, and token exchanges need honest adoption rails instead of secret continuation folklore.

### ViewFS
ViewFS still provides the clearest contrast class. A request reference is not a docref; a transfer receipt is not a durable local object; a controlled import is stronger than browser route success.

### Steward
Steward should keep aftermath and follow-through surfaces typed. Harbor’s pass VIII nouns should arrive as compact inspectable facts, not as giant orchestration vocabularies.

### Ward
Ward remains the essential containment neighbor. DPoP-like proof binding is useful, but durable admission, account relation, and spend still belong in Ward’s lane.

### Foundry
Foundry continues to sharpen Harbor’s humility: a detour that ends by launching or materializing foreign ground still needs aftermath that says what actually became local and what remained foreign.

## Recommendation for Harbor rev0008
Keep these candidate nouns alive, but only as candidates:
- opaque auth parcel;
- request reference;
- proof-bound return;
- detour-binding card.

Do **not** decide yet:
- whether request references are first-class Harbor objects or merely one subtype of detour lease;
- whether proof-bound return belongs in Harbor or is better represented as a cross-cube handoff toward Ward;
- whether the browser detour deserves one universal parcel object across auth, transfer, and reveal workflows.

The pass VIII specimen should exist precisely to kill weak versions of those ideas early.
