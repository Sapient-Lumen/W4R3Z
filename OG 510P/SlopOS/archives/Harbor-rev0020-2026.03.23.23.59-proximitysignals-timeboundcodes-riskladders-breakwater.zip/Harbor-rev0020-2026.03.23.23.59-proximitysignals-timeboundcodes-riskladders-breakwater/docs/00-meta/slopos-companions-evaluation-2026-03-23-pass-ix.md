# SlopOS / companions evaluation — 2026-03-23 pass X

This pass evaluated whether Harbor can absorb structured request ideas and compatibility-sensitive route truth without becoming either a policy engine or a file/object cube.

## SlopOS pressure that matters most now

`openuri-request-shaping-boundary-v0.md` is still the most important brake. SlopOS clearly wants request shaping to remain bounded and enumerable rather than becoming a giant generic exchange-construction surface. Harbor should therefore study structured detour parcels without trying to own every provider-specific ask shape.

`auth-continuation-export-boundary-v0.md`, `auth-proof-export-boundary-v0.md`, and `auth-result-export-boundary-v0.md` still strongly support pass X. A prepared parcel, a returned proof, and a durable consequence remain different strengths of fact.

`import-to-docref-boundary-v0.md`, `import-to-docref-fresh-identity-boundary-v0.md`, and the openuri/import seams all reinforce a useful Harbor restraint: a route that lands in controlled availability is still weaker than a durable local object relation.

## Sibling pressure that matters most now

### ViewFS
ViewFS is the main sibling brace for pass X. It keeps availability, identity, handles, and receipts separate, which helps Harbor avoid pretending that structured route success equals durable local objecthood.

### Ward
Ward continues to guard the trust flank. Structured parcels and proof-bound returns are operationally valuable, but durable trust and spend still live elsewhere.

### Helm and Schell
Helm wants inspectable fallback and adoption surfaces; Schell wants helper/provider turns to require explicit adoption. Both argue for compatibility shadows and adoption clocks instead of one giant success bit.

## Recommendation for Harbor rev0011

Harbor should keep these candidate nouns provisional:
- **structured detour parcel**
- **compatibility shadow**
- **adoption clocks**

The pass X specimen should exist to kill the over-wide versions early:
- if the parcel starts swallowing provider-specific request construction, it is too wide;
- if compatibility shadow starts implying permanent route truth, it is too strong;
- if adoption clocks become fake lifecycle doctrine, they are too frozen.

Harbor is healthiest when it stays the truthful membrane, not the whole story after the crossing.
