## rev0020 — proximity signals, timebound codes, and risk ladders
- added pass XX research synthesis and pass XX datacube evaluation;
- added specimen flow 17 around proximity signals, timebound codes, and risk ladders;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0020 — resource audiences, scope splits, and auth targets
- added pass XIX research synthesis and pass XIX datacube evaluation;
- added specimen flow 16 around resource audiences, scope splits, and auth targets;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0019 — step-up challenges, resource metadata, and auth stairs
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 15 around step-up challenges, resource metadata, and auth stairs;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0019 — request objects, policy witnesses, and signed finish envelopes
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 14 around request objects, policy witnesses, and signed finish envelopes;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0016 — issuer pins, mix-up vetoes, and origin cards
- added pass XVI research synthesis and pass XVI datacube evaluation;
- added specimen flow 13 around issuer pins, mix-up vetoes, and origin cards;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0015 — backchannel challenges, finish envelopes, and veto floors
- added pass XV research synthesis and pass XV datacube evaluation;
- added specimen flow 12 around backchannel challenge finish envelope and veto floor;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0014 — interaction references, finish tickets, and adoption checkpoints
- added pass XIV research synthesis and pass XIV datacube evaluation;
- added specimen flow 11 around interaction references, finish tickets, and adoption checkpoints;
- refreshed ledgers, context pack, manifests, and archive index for the new release.

# Changelog

## rev0013 — 2026-03-23
- continued online research with a stronger focus on GNAP-style continuations, finish methods, and capability-floor hygiene
- added a pass XII datacube evaluation, a pass XII research synthesis, and a ninth specimen selected to preserve optionality
- refreshed lessons, inspirations, ledgers, manifests, and context surfaces; then reran repo hygiene checks

## rev0011 — 2026-03-23
- continued online research with a stronger focus on typed requested consequences, continuation bonds, and adoption-veto hygiene;
- added a pass XI datacube evaluation, a pass XI research synthesis, and an eighth specimen selected to preserve optionality;
- refreshed lessons, inspirations, queues, manifests, and context surfaces; cleaned duplicate sections from prior passes; and reran repo hygiene checks.

## rev0008 — 2026-03-23
- continued online research with a stronger focus on PAR-style staged authorization, opaque request references, and DPoP-like proof-bound return exchange;
- added a pass VIII datacube evaluation, a pass VIII research synthesis, and a fifth specimen selected to preserve optionality;
- refreshed lessons, queues, manifests, and context surfaces; repaired duplicate lesson sections; and reran repo hygiene checks.

## rev0007 — 2026-03-23
- continued online research with a stronger focus on ephemeral browser sessions, associated-domain fallback, FedCM-style bounded identity mediation, and post-return adoption;
- added a pass VII datacube evaluation, a pass VII research synthesis, and a fourth specimen selected to preserve optionality;
- repaired changelog drift, refreshed queues/ledgers/manifests, and reran repo hygiene checks.

## rev0006 — 2026-03-23
- continued online research with a stronger focus on lessons from cross-device flows, dynamic routing, session hardening, capability routing, restore-time humility, and explicit rebound/reacquire patterns;
- added a pass VI datacube evaluation, a pass VI research synthesis, and a third specimen selected to preserve optionality;
- cleaned registry/ledger identifiers, refreshed bibliography and release metadata, and reran repo hygiene checks.

## rev0005 — 2026-03-23
- continued online research with a stronger focus on lessons worth stealing from mature ecosystems and current standards;
- added a pass V datacube evaluation, a pass V research synthesis, and a second specimen selected to preserve optionality;
- refreshed repo/process surfaces, queues, ledgers, bibliography, and release metadata while keeping the cube embryonic.

## rev0004 — 2026-03-23
- continued online research with a focus on anti-lessons, specimen flows, and option-preserving architecture moves;
- added a pass IV datacube evaluation plus a new research synthesis and a first concrete specimen document;
- refreshed lessons, inspiration, queues, ledgers, bibliography, and repo hygiene/process surfaces.

## rev0003 — 2026-03-23
- continued online research and a deeper readthrough of SlopOS plus companion cubes;
- added a lessons-from-the-past file, a datacube evaluation pass, and promotion gates/specimen tests;
- added followthrough/irreversible-decision hygiene surfaces and a runnable repo check.

## rev0002 — 2026-03-23
- deepened the founding embryo after reading the current cube ecology and official outside sources;
- sharpened the cube’s internal separations and neighbor boundaries;
- added roadmap, trajectory, ledgers, ADRs, and expanded architecture notes.
