# Cube audit report rev0198

## Scope
This audit targeted the post-rev0197 proof surface after coordination gates landed. The specific question was whether Steward had enough executable structure to keep generation rollout movement from inheriting truth from material freshness, probes, traffic binding, or rollback labels.

## Findings
- Steward had strong packet layers for material freshness, probe vantage, control verdict, traffic binding, and coordination, but the generation path connecting them was still mostly prose.
- The dangerous collapse was not in any single existing packet. It was the chain: projected material becomes reloaded, reloaded becomes ready, ready becomes promoted, promoted becomes serving/effect success, and rollback becomes compensation.
- `tools/run_lint_suite.py` still owned schema-registry table parsing directly. After the harness registry refactors, schema-registry parsing had become shared infrastructure in practice but not in code.

## Semantic addition
- Added `ST-GENPLAN v0`, `ST-RECONFAPPLY v0`, `ST-GENREADY v0`, and `ST-PROMOTION v0`.
- Added `tools/steward_rollout_generation_harness.py` and `docs/40-verification/rollout-generation-corpus-v0.md`.
- The new corpus rejects material-as-freshness, apply-as-readiness, readiness-as-global-readiness, promotion-as-serving/effect-success, stale-readiness promotion, abandoned-plan apply, full-promotion weight mismatch, rollback without origin, and duplicate generation-id drift.

## Refactor
- Added `tools/schema_registry_utils.py` as the shared parser for `docs/30-architecture/schema-registry.md` rows.
- Updated `tools/run_lint_suite.py` to consume the shared parser instead of owning a duplicate local table parser.
- Kept the refactor deliberately small: no schema-registry rewrite, no generated registry, and no new table format. The goal was to remove repeated parser ownership without destabilizing the release checks.

## Residual risk
The rollout-generation packets prove separations, not rollout adequacy. They do not decide canary policy, traffic implementation, health-check quality, rollback safety, compensation, deployment scheduling, or global service stability. Future work should pressure-test how these packets compose with sibling systems rather than expanding Steward into a deployment orchestrator.
