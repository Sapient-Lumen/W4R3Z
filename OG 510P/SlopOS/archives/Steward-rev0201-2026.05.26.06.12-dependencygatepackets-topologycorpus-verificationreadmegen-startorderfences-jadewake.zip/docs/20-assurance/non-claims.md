# Non-claims

Steward does **not** claim:
- a full systemd replacement;
- a final dependency language;
- a generic fd/object escrow broker;
- a final external admin API;
- a final shell language or terminal protocol;
- that all host service-manager ideas are bad.

The claim is narrower: Steward can be designed coherently by freezing only a few lifecycle seams and learning aggressively from prior systems.
- exactly-once activation-work delivery, exactly-once side effects, universal redrive, or a portable poison-message system;
- a global idempotency ledger, transaction coordinator, saga/compensation engine, or portable outbox service;
- a portable activation-state attachment filesystem, volume manager, secret/config store, storage scheduler, checkpoint/restore protocol, migration system, or path authority model;
- that the new lifecycle corpus proves any real runner, host adapter, or SlopOS deployment correct;
- that JSON Schema alone captures all canonicalization, duplicate-key, digest, or semantic-collapse rules;
- that systemd, Kubernetes, Envoy, NATS, Temporal, or any other external system has Steward-native lifecycle meaning without an adapter membrane;
- a durable workflow/event-history engine, audit product, service mesh, shell empire, or general host compatibility layer;
- a final admin API beyond observe-first exact-target operations and receipt-returning mutation requests;
- that the new channel-binding corpus proves any real load balancer, service mesh, DNS system, transport stack, broker, watch service, reconnect path, or endpoint-drain implementation correct;
- that ST-TBIND or ST-LIVECHAN are final route, traffic, connection, stream, subscription, or session-resumption APIs.
- that ST-DEMAND, ST-CUSTODY, ST-WORKDISP, or ST-EFFECT are final queue, broker, workflow, transaction, outbox, compensation, idempotency-ledger, or exactly-once APIs.
- that ST-STATEATT, ST-MATFRESH, ST-PROBE, or ST-CTRLVERDICT are final storage, material, health, rollout, repair, routing, incident, vault, identity, reload, or control-plane APIs.
- that ST-RTCYCLE, ST-INCARN, ST-RESIDENCY, or ST-RESUME are final process, scheduler, rollout, checkpoint/restore, hot-restart, cursor-resume, durable replay, or recovery APIs.
- that ST-RETRYADVICE, ST-RETRYBUDGET, ST-RETRYATTEMPT, or ST-HEDGEFATE are final retry engines, quota services, RPC frameworks, hedge racing systems, distributed idempotency ledgers, or exactly-once effect APIs.
- that ST-QUIESCE, ST-DRAIN, ST-ESCALATE, or ST-TERMCAUSE are final shutdown controllers, signal APIs, broker drain protocols, connection managers, crash analyzers, restart engines, or lossless-stop guarantees.
- that ST-DELEGATE, ST-REVIEW, ST-APPROVAL, or ST-AUTHCHECK are final governance, RBAC, owner-map, approval-UI, escalation, audit, Ward-replacement, or policy-engine APIs.
- that ST-RECEIPTCHAIN, ST-REDACTION, ST-EXPORTBUNDLE, or ST-REPLAYOBS are final audit logs, provenance systems, export formats, redaction engines, archival stores, evidence-review UIs, or authority/delegation mechanisms.
- that ST-IMPORT, ST-SRCAPPRAISE, ST-RECONPLAN, or ST-RECONDECISION are final import systems, trust engines, provenance ledgers, recovery controllers, audit products, migration tools, approval workflows, or current-state adoption APIs.
- Local observation packets do not prove current lifecycle state, readiness, serving, material freshness, authority, operation execution, demand drain, lossless continuity, or effect success.
- that ST-OBSSUB, ST-OBSDELIV, ST-OBSSYNC, or ST-OBSGAP are final event-bus, cursor-store, streaming transport, notification-service, remote-control, current-state, readiness, quiescence, lossless-delivery, or UI-framework APIs.
- that ST-ATTNHINT, ST-ATTNWATCH, ST-NOTICE, or ST-ATTNACK are final desktop notification, inbox, reminder, macro, approval, user-presence, user-read, UI framework, or automation APIs.
- that ST-PRECOND, ST-OPARBIT, ST-HOLD, or ST-PROGRESS are final scheduler, lock-service, queue manager, rollout controller, transaction, policy engine, progress API, or orchestration APIs.
- that ST-GENPLAN, ST-RECONFAPPLY, ST-GENREADY, or ST-PROMOTION are final rollout controllers, deployment orchestrators, config stores, service meshes, readiness APIs, rollback/compensation systems, or deployment-success guarantees.
- that ST-PRESSURE, ST-HEADROOM, ST-BACKPRESS, or ST-ADMGATE are final overload controllers, resource managers, schedulers, autoscalers, rate-limit services, quota wallets, admission controllers, repair systems, incident products, or demand/work-success APIs.
- that ST-ACTBRACKET, ST-IDLEHINT, ST-STOPDEFER, or ST-ACTACCT are final workflow-lease, idle-stop, billing, quota, activity-metering, drain, request-completion, keepalive, or effect-success APIs.
- that ST-DEPSPEC, ST-DEPCHECK, ST-DEPGATE, or ST-DEPFALLBACK are final topology, dependency planner, service graph, scheduler, mesh graph, repair, rollback, readiness, serving, or execution APIs.
