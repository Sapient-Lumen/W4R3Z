# Cube audit report rev0201

## Audit target
Verification documentation had become the same kind of manually-maintained index that schema documentation was before rev0200. `docs/40-verification/README.md` repeated the harness registry order, corpus paths, and packet-family names by hand.

## Finding
The registry already knew every harness script, corpus path, verification document, and packet-family owner. The verification README could drift without changing executable behavior.

## Refactor
Rev0201 adds a generated verification README path:

- `tools/gen_verification_readme.py` renders `docs/40-verification/README.md` from `tools/harness_registry.py`.
- `make verification-readme` regenerates it.
- `make handoff-release` runs the generator before context-pack and lint.
- lint checks the README exactly against the generated output.

## Semantic addition
Rev0201 also adds the dependency-gate proof slice so dependency declarations, checks, gates, and fallbacks stay weak and scoped rather than becoming topology authority, readiness, serving, failure, operation execution, work completion, or effect success.

## Result
The cube now has one less hand-maintained proof index and one more executable lifecycle-collapse fence.
