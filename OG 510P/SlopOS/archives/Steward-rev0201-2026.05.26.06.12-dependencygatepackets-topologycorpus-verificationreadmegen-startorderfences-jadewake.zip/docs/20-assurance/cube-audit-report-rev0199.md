# Cube audit report — rev0199

## Scope
This audit focused on the pressure/headroom/backpressure posture cluster and on schema-index drift after the harness registry refactors in rev0195 through rev0198.

## Findings
1. Pressure, headroom, and backpressure already existed as posture surfaces, but they were not executable. That left a dangerous gap where pressure could be rendered as failure, headroom as authorization, or backpressure as accepted demand without corpus rejection.
2. `schemas/README.md` was still a manual index. The schema registry and machine schema directory were checked, but the human schema index itself could silently drift.

## Changes made
- Promoted the pressure/admission seam into ST-PRESSURE, ST-HEADROOM, ST-BACKPRESS, and ST-ADMGATE closed packet profiles.
- Added `pressure-admission-corpus-v0` and `tools/steward_pressure_admission_harness.py`.
- Added a schema-index lint guard so `schemas/README.md`, `schemas/*.schema.json`, and schema-registry machine profile filenames must stay synchronized.

## Result
The cube now rejects pressure-as-failure, headroom-as-authority, backpressure-as-demand, gate-as-work, allow-with-exhausted-headroom, blocking-backpressure contradictions, and duplicate admission-gate id drift.
