# Cube audit report rev0197

## Scope
This audit targeted the post-rev0196 harness registry and the coordination surfaces that were still prose-only.

## Findings
- The shared harness registry was the execution source of truth, but it still did not say which packet families each harness owned.
- Schema-registry rows named checkers, while harness metadata named scripts, corpora, and docs. Those two maps could still drift semantically: a harness could be wired and documented while silently omitting one packet family from its declared ownership.
- Coordination posture existed in prose across preconditions, holds, progress windows, and operation arbitration, but there was no executable packet layer proving that coordination facts stay weaker than authorization, execution, readiness, serving, currentness, operation result, or effect success.

## Refactor
- Expanded `tools/harness_registry.py` entries with `packet_ids`.
- Added `harness_packet_map()` so lint can compare schema-registry packet IDs against harness-owned packet IDs.
- Tightened `tools/run_lint_suite.py` so each registry entry must declare packet IDs, each packet ID must appear in the owning script, and schema-registry checker rows must match the owning harness packet set.
- Preserved the single registry-driven `make corpus` path; this pass did not reintroduce per-harness Makefile duplication.

## Semantic addition
- Added the coordination-gate corpus with four closed packets: `ST-PRECOND v0`, `ST-OPARBIT v0`, `ST-HOLD v0`, and `ST-PROGRESS v0`.
- The corpus rejects the common coordination collapses: precondition-as-authorization, queued-as-executed, hold-as-stopped/failure, progress-as-readiness, accepted mutation despite active hold, stale precondition use, and expired progress without downgrade.

## Residual risk
The registry now proves packet-family ownership and execution wiring, not semantic adequacy. A packet family can still be too narrow or the corpus can still miss a real adapter failure mode. The next audit should sample packet schemas for repeated field idioms and consider extracting shared schema fragments only if the duplication is actively producing drift.
## Runtime refactor follow-up
After packet-family metadata landed, full lint revealed that spawning one Python process per harness had become slow enough to threaten interactive release work. `tools/run_corpora.py` now loads harnesses in-process through the same registry and calls their deterministic `build_cases`, `render_cases`, `load_corpus`, and `check_cases` functions directly. This keeps standalone harness CLIs intact while making `make corpus` and `make lint` use the same fast registry-driven path.
