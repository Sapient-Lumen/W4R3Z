# Cube audit report rev0195

## Scope
This audit targeted the release execution wiring that every new packet family depends on:

1. `Makefile` corpus execution;
2. `tools/run_lint_suite.py` corpus execution;
3. registered checker coverage in `docs/30-architecture/schema-registry.md`.

## Findings
- Revision 194 had improved lint into a registry-driven loop, but `Makefile` still enumerated every corpus harness separately.
- The checker-wiring guard still needed to compare registered schema checkers against a single authoritative harness registry rather than against two separately edited lists.
- Adding the status-channel corpus would have required editing Makefile and lint separately again if the registry was not centralized.

## Refactor
- Added `tools/harness_registry.py` as the single source of truth for corpus harness order.
- Added `tools/run_corpora.py` so `make corpus` delegates to the shared registry.
- Updated `tools/run_lint_suite.py` to import the same registry and to reject per-harness Makefile entries.
- Kept schema-registry checker coverage, schema/corpus accept-reject coverage, and corpus-doc coverage gates active.

## Residual risk
This refactor proves the corpus harnesses are wired through one local registry. It does not prove the registry's semantic completeness, and it does not prove any packet family is complete beyond the deterministic corpora that lint executes.
