# Cube audit report rev0196

## Scope
This audit targeted the corpus harness registry after rev0195 centralized execution.

## Findings
- The registry had become the execution source of truth, but it still only carried script paths.
- Corpus path and verification-doc coverage were checked elsewhere, so a future harness could still require coordinated edits across registry, README, and lint checks.
- Attention-notification packets would have added another surface that made the missing registry metadata more visible.

## Refactor
- Expanded `tools/harness_registry.py` from a bare script list into `HARNESS_ENTRIES` with `script`, `corpus`, and `doc` metadata.
- Kept `HARNESS_SCRIPTS` derived from that metadata so existing runners keep working.
- Added `check_harness_registry_metadata` to `tools/run_lint_suite.py` so every registered harness must name an existing script, corpus, and verification doc, and the script must declare its corpus path.

## Residual risk
The registry now proves local wiring shape, not semantic completeness. A harness can still be too weak, but it can no longer be added as an execution-only entry with untracked corpus/doc companions.
