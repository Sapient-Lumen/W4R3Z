# Cube audit report — rev0200

## Scope
This audit focused on the activity/accounting posture cluster and the schema index maintenance path after the rev0199 schema-index guard.

## Findings
1. `activity-accounting-posture-v0.md`, `activity-bracket-posture-v0.md`, and `stop-deferral-posture-v0.md` named the right distinctions, but those distinctions were still posture-only. A runtime could claim busy, idle, stop deferral, or accounted activity without an executable rejection of readiness, drain, keepalive, billing, or effect-success flattery.
2. `schemas/README.md` was checked for filename coverage, but it was still a manually maintained file. The stronger shape is to generate it from `schema-registry.md` and have lint compare the exact generated result.

## Changes made
- Promoted the activity-accounting seam into ST-ACTBRACKET, ST-IDLEHINT, ST-STOPDEFER, and ST-ACTACCT closed packet profiles.
- Added `activity-accounting-corpus-v0` and `tools/steward_activity_accounting_harness.py`.
- Added `tools/gen_schema_readme.py` and a `schema-readme` Makefile target.
- Tightened lint so `schemas/README.md` must exactly match the schema-registry-generated output, not merely mention the right filenames.

## Result
The cube now rejects activity-as-demand, busy-as-readiness, idle-as-stopped, stop-deferral-as-keepalive, deferral over closed brackets, deferral past bracket freshness, closed accounting over open brackets, accounting-as-billing, accounting-as-work-completion, and duplicate bracket-id drift.
