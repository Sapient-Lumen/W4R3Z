# Cube audit report rev0194

## Scope
This audit targeted two Steward cube surfaces that had begun to drift as the executable packet families accumulated:

1. the proof-slice inventory in `docs/40-verification/minimum-steward-proof-slice.md`;
2. the release lint runner in `tools/run_lint_suite.py`.

## Findings
- The proof-slice inventory still said the executable surface had eleven corpora after the local-observation provenance corpus was added.
- The lint runner had accumulated one function per harness, creating avoidable edit points for every new packet family.
- The registered-checker wiring guard was correct in spirit but depended on ad hoc source-string checks that were coupled to the old duplicated style.

## Refactor
- `tools/run_lint_suite.py` now uses one `HARNESS_SCRIPTS` registry and one loop to execute corpus harnesses.
- The checker-wiring guard now verifies registered harnesses against the registry-driven lint source and `make corpus` wiring.
- The minimum proof slice now names the local-observation and witness-surface corpora explicitly and updates its executable contract.

## Residual risk
This audit does not prove the cube is complete. It only closes one stale inventory surface and one code-duplication surface while adding executable witness-surface checks for future UI compression risks.
