# Paste-firewall posture v0

Purpose: define a **tiny paste-firewall seam** so pasted payloads can be previewed, staged, literalized, downgraded, or denied as an explicit shell/terminal policy choice instead of being mistaken for typed intent or silently rewritten by convenience heuristics.

## Posture
1. **Typed input and pasted payloads stay different truths**
   - Bracketed paste, clipboard insertion, reviewed selector insertion, replayed input, and fresh keystrokes are not the same class of event.
   - Steward should preserve that distinction so “bytes arrived” does not flatten into “the user typed this now”.
2. **A paste firewall acts on one concrete paste event**
   - The unit of policy should be one exact paste payload plus its provenance, target surface, and freshness.
   - Steward should not quietly turn a paste firewall into a global content filter for every future command line or transcript span.
3. **Preview, stage, and send are different outcomes**
   - A paste may be inserted directly, shown first, converted into a staged block, or denied/re-routed to a safer chooser or editor lane.
   - Those outcomes should remain explicit instead of hiding inside terminal folklore like “sometimes Enter did nothing”.
4. **Any transformation must be visible and explainable**
   - Literalize, strip-controls, normalize-newlines, or split-into-lines behavior can be useful.
   - Steward should never silently sanitize or rewrite a paste while pretending the shell received the original bytes unchanged.
5. **Control-heavy or multiline payloads may trigger stronger handling**
   - Escape/control sequences, suspicious newline density, and shell-meaningful prefixes are good reasons to step up from direct paste to preview, staging, or denial.
   - Steward should keep the reason visible rather than treating such moves as unexplained nannying.
6. **Exact shell context can narrow policy, but unknown context should stay humble**
   - A live prompt lease, exact current-command object, or reviewed chooser target may justify safer direct insertion.
   - When semantic footing is weak, Steward should prefer preview/stage over pretending it knows the destination context well enough.
7. **Paste-firewall outcomes are UX policy, not lifecycle authority**
   - Allowing or denying a paste can protect the shell surface and fresh intent.
   - It must not silently approve lifecycle control, widen grant scope, or substitute for reviewed execution authority.
8. **Remote or helper-mediated paste paths deserve provenance**
   - Clipboard helpers, OSC paths, remote relay layers, or shell-side injection helpers can all move pasted data.
   - Steward should preserve enough provenance to say what path was used instead of attributing every paste to the same local keyboard story.
9. **Risky paste should be stage-first when possible**
   - The healthiest phase-1 escalation is usually to land risky payloads in a staged/editable block with explicit send, not to invent an opaque deny-only wall.
   - That keeps the shell powerful while staying anti-folklore and policy-bounded.
10. **Keep the phase-1 contract tiny**
   - Phase 1 likely needs only: payload provenance, basic risk flags, selected handling mode, visible reason/diagnostic, and outcome (`inserted`, `staged`, `literalized`, `denied`, `expired`).
   - Avoid freezing a portable DLP engine, a universal shell sanitizer, or a giant policy grammar before repeated operating pressure exists.

## Phase-1 non-goals
- a universal malware / DLP content scanner for terminal input;
- silently rewriting commands while claiming the original paste was preserved;
- proving that a full-screen TUI or remote app is always safe for raw paste;
- replacing shell quoting or parser rules with terminal-side guesswork;
- inventing a giant paste-policy family before more than one tightly related seam truly exists.

## Adjacent docs
- `input-surface-posture-v0.md`
- `clipboard-surface-posture-v0.md`
- `session-injection-posture-v0.md`
- `prompt-lease-posture-v0.md`
- `current-command-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `assist-surface-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `fresh-intent-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-XTERM-BRACKETED-PASTE
- REF-BASH-READLINE-INIT
- REF-BASH-COMMANDS-FOR-TEXT
- REF-KITTY-CLIPBOARD
- REF-VSCODE-SHELL-INTEGRATION
- REF-GHOSTTY-RELEASE-130
