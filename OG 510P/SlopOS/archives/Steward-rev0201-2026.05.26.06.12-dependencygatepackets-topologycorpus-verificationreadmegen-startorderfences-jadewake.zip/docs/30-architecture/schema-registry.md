# Schema registry

| ID | Meaning | Human spec | Machine profile | Checker |
| --- | --- | --- | --- | --- |
| Steward canonical JSON v0 | closed canonical object profile for proof-slice authority objects | `canonical-json-profile-v0.md` | n/a | `../../tools/steward_lifecycle_harness.py` |
| CH-COMP v0 | component manifest | `component-manifest-schema-v0.md` | `../../schemas/ch-comp-v0.schema.json` | `../../tools/steward_lifecycle_harness.py` |
| CH-ACTSET v0 | activation set manifest | `activation-set-schema-v0.md` | `../../schemas/ch-actset-v0.schema.json` | `../../tools/steward_lifecycle_harness.py` |
| ST-OPREQ v0 | reviewed control-operation request | `control-operation-request-schema-v0.md` | `../../schemas/st-opreq-v0.schema.json` | `../../tools/steward_operation_harness.py` |
| ST-OPRECEIPT v0 | control-operation receipt | `control-operation-receipt-schema-v0.md` | `../../schemas/st-opreceipt-v0.schema.json` | `../../tools/steward_operation_harness.py` |
| ST-PRECOND v0 | exact lifecycle precondition witness | `precondition-witness-schema-v0.md` | `../../schemas/st-precond-v0.schema.json` | `../../tools/steward_coordination_gate_harness.py` |
| ST-OPARBIT v0 | operation arbitration/collision witness | `operation-arbitration-witness-schema-v0.md` | `../../schemas/st-oparbit-v0.schema.json` | `../../tools/steward_coordination_gate_harness.py` |
| ST-HOLD v0 | deliberate lifecycle hold witness | `hold-state-witness-schema-v0.md` | `../../schemas/st-hold-v0.schema.json` | `../../tools/steward_coordination_gate_harness.py` |
| ST-PROGRESS v0 | progress-window witness | `progress-window-witness-schema-v0.md` | `../../schemas/st-progress-v0.schema.json` | `../../tools/steward_coordination_gate_harness.py` |
| ST-PRESSURE v0 | scoped resource-pressure witness | `pressure-witness-schema-v0.md` | `../../schemas/st-pressure-v0.schema.json` | `../../tools/steward_pressure_admission_harness.py` |
| ST-HEADROOM v0 | scoped spendability/headroom witness | `headroom-witness-schema-v0.md` | `../../schemas/st-headroom-v0.schema.json` | `../../tools/steward_pressure_admission_harness.py` |
| ST-BACKPRESS v0 | backpressure/new-work pacing witness | `backpressure-witness-schema-v0.md` | `../../schemas/st-backpress-v0.schema.json` | `../../tools/steward_pressure_admission_harness.py` |
| ST-ADMGATE v0 | pressure/headroom/backpressure admission-gate decision witness | `admission-gate-witness-schema-v0.md` | `../../schemas/st-admgate-v0.schema.json` | `../../tools/steward_pressure_admission_harness.py` |
| ST-ACTBRACKET v0 | activity-bracket witness | `activity-bracket-witness-schema-v0.md` | `../../schemas/st-actbracket-v0.schema.json` | `../../tools/steward_activity_accounting_harness.py` |
| ST-IDLEHINT v0 | idle/busy/draining hint witness | `idle-hint-witness-schema-v0.md` | `../../schemas/st-idlehint-v0.schema.json` | `../../tools/steward_activity_accounting_harness.py` |
| ST-STOPDEFER v0 | bounded stop-deferral witness | `stop-deferral-witness-schema-v0.md` | `../../schemas/st-stopdefer-v0.schema.json` | `../../tools/steward_activity_accounting_harness.py` |
| ST-ACTACCT v0 | descriptive activity-accounting witness | `activity-accounting-witness-schema-v0.md` | `../../schemas/st-actacct-v0.schema.json` | `../../tools/steward_activity_accounting_harness.py` |
| ST-DEPSPEC v0 | lifecycle dependency declaration witness | `dependency-spec-witness-schema-v0.md` | `../../schemas/st-depspec-v0.schema.json` | `../../tools/steward_dependency_gate_harness.py` |
| ST-DEPCHECK v0 | dependency condition check witness | `dependency-check-witness-schema-v0.md` | `../../schemas/st-depcheck-v0.schema.json` | `../../tools/steward_dependency_gate_harness.py` |
| ST-DEPGATE v0 | dependency-informed lifecycle gate witness | `dependency-gate-witness-schema-v0.md` | `../../schemas/st-depgate-v0.schema.json` | `../../tools/steward_dependency_gate_harness.py` |
| ST-DEPFALLBACK v0 | dependency fallback/degraded-mode witness | `dependency-fallback-witness-schema-v0.md` | `../../schemas/st-depfallback-v0.schema.json` | `../../tools/steward_dependency_gate_harness.py` |
| ST-GENPLAN v0 | generation-plan witness | `generation-plan-witness-schema-v0.md` | `../../schemas/st-genplan-v0.schema.json` | `../../tools/steward_rollout_generation_harness.py` |
| ST-RECONFAPPLY v0 | reconfiguration-apply witness | `reconfiguration-apply-witness-schema-v0.md` | `../../schemas/st-reconfapply-v0.schema.json` | `../../tools/steward_rollout_generation_harness.py` |
| ST-GENREADY v0 | generation-readiness witness | `generation-readiness-witness-schema-v0.md` | `../../schemas/st-genready-v0.schema.json` | `../../tools/steward_rollout_generation_harness.py` |
| ST-PROMOTION v0 | generation-promotion witness | `promotion-witness-schema-v0.md` | `../../schemas/st-promotion-v0.schema.json` | `../../tools/steward_rollout_generation_harness.py` |
| ST-STATEATT v0 | state-attachment witness | `state-attachment-witness-schema-v0.md` | `../../schemas/st-stateatt-v0.schema.json` | `../../tools/steward_currentness_control_harness.py` |
| ST-MATFRESH v0 | material-freshness witness | `material-freshness-witness-schema-v0.md` | `../../schemas/st-matfresh-v0.schema.json` | `../../tools/steward_currentness_control_harness.py` |
| ST-PROBE v0 | probe-vantage witness | `probe-vantage-witness-schema-v0.md` | `../../schemas/st-probe-v0.schema.json` | `../../tools/steward_currentness_control_harness.py` |
| ST-CTRLVERDICT v0 | control-verdict witness | `control-verdict-witness-schema-v0.md` | `../../schemas/st-ctrlverdict-v0.schema.json` | `../../tools/steward_currentness_control_harness.py` |
| ST-TBIND v0 | traffic-binding witness | `traffic-binding-witness-schema-v0.md` | `../../schemas/st-tbind-v0.schema.json` | `../../tools/steward_channel_binding_harness.py` |
| ST-LIVECHAN v0 | live-channel witness | `live-channel-witness-schema-v0.md` | `../../schemas/st-livechan-v0.schema.json` | `../../tools/steward_channel_binding_harness.py` |
| ST-DEMAND v0 | demand-episode witness | `demand-episode-witness-schema-v0.md` | `../../schemas/st-demand-v0.schema.json` | `../../tools/steward_work_effect_harness.py` |
| ST-CUSTODY v0 | custody witness | `custody-witness-schema-v0.md` | `../../schemas/st-custody-v0.schema.json` | `../../tools/steward_work_effect_harness.py` |
| ST-WORKDISP v0 | work-disposition witness | `work-disposition-witness-schema-v0.md` | `../../schemas/st-workdisp-v0.schema.json` | `../../tools/steward_work_effect_harness.py` |
| ST-EFFECT v0 | effect-boundary witness | `effect-boundary-witness-schema-v0.md` | `../../schemas/st-effect-v0.schema.json` | `../../tools/steward_work_effect_harness.py` |
| ST-RTCYCLE v0 | runtime-cycle witness | `runtime-cycle-witness-schema-v0.md` | `../../schemas/st-rtcycle-v0.schema.json` | `../../tools/steward_lineage_resume_harness.py` |
| ST-INCARN v0 | incarnation-lineage witness | `incarnation-lineage-witness-schema-v0.md` | `../../schemas/st-incarn-v0.schema.json` | `../../tools/steward_lineage_resume_harness.py` |
| ST-RESIDENCY v0 | residency witness | `residency-witness-schema-v0.md` | `../../schemas/st-residency-v0.schema.json` | `../../tools/steward_lineage_resume_harness.py` |
| ST-RESUME v0 | resume/reconciliation witness | `resume-reconciliation-witness-schema-v0.md` | `../../schemas/st-resume-v0.schema.json` | `../../tools/steward_lineage_resume_harness.py` |
| ST-RETRYADVICE v0 | retry-advice witness | `retry-advice-witness-schema-v0.md` | `../../schemas/st-retryadvice-v0.schema.json` | `../../tools/steward_retry_settlement_harness.py` |
| ST-RETRYBUDGET v0 | retry-budget witness | `retry-budget-witness-schema-v0.md` | `../../schemas/st-retrybudget-v0.schema.json` | `../../tools/steward_retry_settlement_harness.py` |
| ST-RETRYATTEMPT v0 | retry-attempt witness | `retry-attempt-witness-schema-v0.md` | `../../schemas/st-retryattempt-v0.schema.json` | `../../tools/steward_retry_settlement_harness.py` |
| ST-HEDGEFATE v0 | hedge-fate witness | `hedge-fate-witness-schema-v0.md` | `../../schemas/st-hedgefate-v0.schema.json` | `../../tools/steward_retry_settlement_harness.py` |
| ST-QUIESCE v0 | quiesce/no-new-work gate witness | `quiesce-witness-schema-v0.md` | `../../schemas/st-quiesce-v0.schema.json` | `../../tools/steward_shutdown_harness.py` |
| ST-DRAIN v0 | old-work/live-channel drain witness | `drain-witness-schema-v0.md` | `../../schemas/st-drain-v0.schema.json` | `../../tools/steward_shutdown_harness.py` |
| ST-ESCALATE v0 | stop/escalation intervention witness | `escalation-witness-schema-v0.md` | `../../schemas/st-escalate-v0.schema.json` | `../../tools/steward_shutdown_harness.py` |
| ST-TERMCAUSE v0 | runtime-cycle termination-cause witness | `termination-cause-witness-schema-v0.md` | `../../schemas/st-termcause-v0.schema.json` | `../../tools/steward_shutdown_harness.py` |
| ST-DELEGATE v0 | scoped delegation-warrant witness | `delegation-warrant-witness-schema-v0.md` | `../../schemas/st-delegate-v0.schema.json` | `../../tools/steward_governance_harness.py` |
| ST-REVIEW v0 | operator-review witness | `operator-review-witness-schema-v0.md` | `../../schemas/st-review-v0.schema.json` | `../../tools/steward_governance_harness.py` |
| ST-APPROVAL v0 | approval-decision witness | `approval-decision-witness-schema-v0.md` | `../../schemas/st-approval-v0.schema.json` | `../../tools/steward_governance_harness.py` |
| ST-AUTHCHECK v0 | authorization-check witness | `authorization-check-witness-schema-v0.md` | `../../schemas/st-authcheck-v0.schema.json` | `../../tools/steward_governance_harness.py` |
| ST-RECEIPTCHAIN v0 | receipt-chain witness | `receipt-chain-witness-schema-v0.md` | `../../schemas/st-receiptchain-v0.schema.json` | `../../tools/steward_receipt_transport_harness.py` |
| ST-REDACTION v0 | redaction witness | `redaction-witness-schema-v0.md` | `../../schemas/st-redaction-v0.schema.json` | `../../tools/steward_receipt_transport_harness.py` |
| ST-EXPORTBUNDLE v0 | evidence-export bundle witness | `evidence-export-bundle-witness-schema-v0.md` | `../../schemas/st-exportbundle-v0.schema.json` | `../../tools/steward_receipt_transport_harness.py` |
| ST-REPLAYOBS v0 | replay-observation witness | `replay-observation-witness-schema-v0.md` | `../../schemas/st-replayobs-v0.schema.json` | `../../tools/steward_receipt_transport_harness.py` |
| ST-IMPORT v0 | import observation witness | `import-observation-witness-schema-v0.md` | `../../schemas/st-import-v0.schema.json` | `../../tools/steward_import_reconciliation_harness.py` |
| ST-SRCAPPRAISE v0 | source-appraisal witness | `source-appraisal-witness-schema-v0.md` | `../../schemas/st-srcappraise-v0.schema.json` | `../../tools/steward_import_reconciliation_harness.py` |
| ST-RECONPLAN v0 | reconciliation-plan witness | `reconciliation-plan-witness-schema-v0.md` | `../../schemas/st-reconplan-v0.schema.json` | `../../tools/steward_import_reconciliation_harness.py` |
| ST-RECONDECISION v0 | reconciliation-decision witness | `reconciliation-decision-witness-schema-v0.md` | `../../schemas/st-recondecision-v0.schema.json` | `../../tools/steward_import_reconciliation_harness.py` |
| ST-LOCALOBS v0 | local observation provenance witness | `local-observation-witness-schema-v0.md` | `../../schemas/st-localobs-v0.schema.json` | `../../tools/steward_local_observation_harness.py` |
| ST-OBSAPPRAISE v0 | local observation appraisal witness | `observation-appraisal-witness-schema-v0.md` | `../../schemas/st-obsappraise-v0.schema.json` | `../../tools/steward_local_observation_harness.py` |
| ST-OBSCURSOR v0 | observation cursor/gap witness | `observation-cursor-witness-schema-v0.md` | `../../schemas/st-obscursor-v0.schema.json` | `../../tools/steward_local_observation_harness.py` |
| ST-OBSATTACH v0 | local observation attachment/recheck decision witness | `observation-attachment-witness-schema-v0.md` | `../../schemas/st-obsattach-v0.schema.json` | `../../tools/steward_local_observation_harness.py` |
| ST-OBSSUB v0 | observation subscription witness | `observation-subscription-witness-schema-v0.md` | `../../schemas/st-obssub-v0.schema.json` | `../../tools/steward_status_channel_harness.py` |
| ST-OBSDELIV v0 | observation delivery witness | `observation-delivery-witness-schema-v0.md` | `../../schemas/st-obsdeliv-v0.schema.json` | `../../tools/steward_status_channel_harness.py` |
| ST-OBSSYNC v0 | observation sync-marker witness | `observation-sync-witness-schema-v0.md` | `../../schemas/st-obssync-v0.schema.json` | `../../tools/steward_status_channel_harness.py` |
| ST-OBSGAP v0 | observation gap/resync barrier witness | `observation-gap-witness-schema-v0.md` | `../../schemas/st-obsgap-v0.schema.json` | `../../tools/steward_status_channel_harness.py` |
| ST-ATTNHINT v0 | attention-hint witness | `attention-hint-witness-schema-v0.md` | `../../schemas/st-attnhint-v0.schema.json` | `../../tools/steward_attention_notification_harness.py` |
| ST-ATTNWATCH v0 | attention-watch witness | `attention-watch-witness-schema-v0.md` | `../../schemas/st-attnwatch-v0.schema.json` | `../../tools/steward_attention_notification_harness.py` |
| ST-NOTICE v0 | notification-delivery witness | `notification-delivery-witness-schema-v0.md` | `../../schemas/st-notice-v0.schema.json` | `../../tools/steward_attention_notification_harness.py` |
| ST-ATTNACK v0 | attention-acknowledgement witness | `attention-acknowledgement-witness-schema-v0.md` | `../../schemas/st-attnack-v0.schema.json` | `../../tools/steward_attention_notification_harness.py` |
| ST-WITCARD v0 | witness-card surface witness | `witness-card-schema-v0.md` | `../../schemas/st-witcard-v0.schema.json` | `../../tools/steward_witness_surface_harness.py` |
| ST-ACTIONAFFORD v0 | action-affordance surface witness | `action-affordance-witness-schema-v0.md` | `../../schemas/st-actionafford-v0.schema.json` | `../../tools/steward_witness_surface_harness.py` |
| ST-STATUSBARRIER v0 | status-barrier surface witness | `status-barrier-witness-schema-v0.md` | `../../schemas/st-statusbarrier-v0.schema.json` | `../../tools/steward_witness_surface_harness.py` |
| ST-SURFAUDIT v0 | surface audit/refactor witness | `surface-audit-witness-schema-v0.md` | `../../schemas/st-surfaudit-v0.schema.json` | `../../tools/steward_witness_surface_harness.py` |
