# Activation-material freshness posture v0

Purpose: name the smallest useful truth for **whether activation material, projected config, secrets, tokens, trust bundles, leases, or restored runtime material are fresh enough for one component context to use** without confusing attached bytes, delivered startup material, or successful restart with current authority.

This seam is intentionally small. It does **not** invent a secret manager, config store, vault, workload identity plane, trust-bundle service, certificate rotation system, key lifecycle API, reload controller, or credential filesystem. It answers one narrower question: **when a component has some material in hand, what compact witness prevents Steward from treating presence as freshness, authority, reload, or safe reuse after restart/restore?**

## Posture
1. **Material freshness is not attachment or delivery**
   - State attachment says that a file, mount, directory, projection, secret volume, tmp area, or external reference is present or detached.
   - Activation receipts say that Steward delivered named startup material to one runtime cycle.
   - Material freshness says whether that material is static for this incarnation, version-pinned, eventually projected, streamed, renewable, expired, revoked, redacted, reload-pending, reacquire-required, or unknown.
   - Steward should not let path presence, environment presence, descriptor delivery, or a successful restore stand in for current credential/config truth.

2. **Version, epoch, audience, and expiry are first-class chips**
   - Useful chips include `version-id`, `moving-latest-label`, `projection-epoch`, `fingerprint`, `audience`, `issuer`, `signer`, `not-before`, `expires-at`, `refresh-after`, `renew-by`, `revoked-at`, and `redacted-at`.
   - If any of these facts are not known, the honest state is `freshness-unknown`, not `probably-current`.
   - A latest label is a selector, not proof that the component observed the latest material.

3. **Static injection must say it is static**
   - Environment variables, activation-time service credentials, command-line material, and copied helper files often remain fixed until a fresh task, service activation, revision, or incarnation.
   - Static material can be safer than live mutation, but it must not masquerade as live rotation.
   - Useful states include `static-for-incarnation`, `static-for-revision`, `static-for-activation`, `restart-required`, and `new-incarnation-required`.

4. **Projected material is eventually current, not instantly current**
   - Projected config/secret/token/trust material may update through watch, cache, polling, atomic swap, or provider-specific read-through behavior.
   - Some mount modes, especially sub-path-like views, may never receive automated updates.
   - Steward should distinguish `projection-updated`, `projection-delay-possible`, `subpath-no-update-risk`, `consumer-reload-required`, `reload-observed`, and `split-read-risk` rather than claiming that the attached projection is current.

5. **Leases and renewable material are obligations, not ambient powers**
   - Dynamic secrets, service tokens, temporary credentials, or delegated material may require renewal before a deadline or replacement when renewal fails.
   - Revocation should be visible as a material fate, not rediscovered as random downstream failure.
   - Useful states include `lease-active`, `renewal-due`, `renewed`, `renewal-failed`, `expired`, `revoked`, `replacement-required`, and `parent-token-ended`.

6. **Trust bundles and identity documents can be streamed or redacted**
   - A workload identity source may stream complete current identity/bundle sets and later remove or redact entries.
   - Steward should preserve the difference between `identity-issued`, `bundle-updated`, `identity-redacted`, `bundle-redacted`, `default-identity-used`, and `hint-selected` without becoming an identity provider.
   - A removed identity should not stay usable just because a component cached a previous file or message.

7. **Restore and warm reuse require reacquisition checks**
   - Snapshot-derived material may include stale timestamps, unique IDs, secrets, entropy, leases, connections, trust bundles, or cached credentials.
   - After restore, the honest states are `reacquire-required`, `revalidate-required`, `after-restore-refresh-pending`, or `after-restore-refresh-passed` before any stronger use claim.
   - Steward should not treat warm start, SnapStart, CRaC, hibernation, or checkpoint restore as proof that material remained fresh.

8. **Consumer observation is separate from provider publication**
   - A provider may publish or rotate material while the component has not yet read, reloaded, or acknowledged it.
   - Steward should separate `provider-version`, `attached-version`, `consumer-observed-version`, `consumer-using-version`, and `acknowledged-version`.
   - This keeps `rotated upstream` from being mistaken for `component is using the new credential`.

9. **Failure to refresh should degrade explicitly**
   - If material cannot be fetched, renewed, reloaded, or validated, Steward should surface `unavailable`, `permission-denied`, `version-missing`, `audience-mismatch`, `fingerprint-mismatch`, `expired`, `revoked`, `stale`, or `unknown` as a bounded explanation.
   - The explanation should not automatically stop, restart, widen authority, or trigger repair policy unless another seam authorizes that action.

10. **Phase 1 shape is a witness, not a vault API**
    - A tentative `activation_material_freshness` witness can stay tiny: `component_id`, optional `incarnation_id`, `material_id`, `material_kind`, `delivery_or_attachment_ref`, optional `provider_ref`, optional `version_ref`, optional `projection_epoch`, optional `fingerprint`, optional `audience`, optional `issuer_or_signer`, optional `issued_at`, optional `expires_at`, optional `refresh_after`, optional `renew_by`, optional `freshness_state`, optional `consumer_state`, optional `restore_recheck_state`, optional `observed_at`, optional `proof_strength`, and optional `unknown_reason`.
    - Field names remain provisional until real Steward components show which facts must cross membranes.

## Executable packet settlement
`ST-MATFRESH v0` is the first executable settlement for this posture. It deliberately proves less than the full posture: closed decode, canonical digest, required non-implications, expiry/revocation sanity, reload-pending evidence refs, raw secret/token redaction, and flow-level rejection of freshness-as-reload-success or freshness-as-material-use.

The deterministic corpus in `../40-verification/currentness-control-corpus-v0.md` is the current promotion gate: new material-freshness language should preserve those cases or add a new accept/reject case before becoming stronger posture.

## Phase-1 non-goals
- a secret manager, config store, credential filesystem, vault, certificate authority, KMS, key lifecycle service, or workload identity provider;
- a universal reload controller, sidecar injector, config watcher, live-update bus, or trust-bundle distribution plane;
- automatic restart/rollout policy when material changes;
- treating `latest`, path presence, env presence, successful projection, activation delivery, or restore as proof that a component is using fresh material;
- exposing secret contents, raw private keys, bearer tokens, or trust anchors through the witness itself.

## Adjacent docs
- `activation-state-attachment-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `activation-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `activation-residency-posture-v0.md`
- `launch-context-posture-v0.md`
- `reconfigure-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `holder-bound-grant-posture-v0.md`
- `authority-narrowing-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-CREDENTIALS
- REF-K8S-PROJECTED-VOLUMES
- REF-K8S-SECRETS
- REF-K8S-CONFIGMAPS
- REF-CLOUD-RUN-SECRETS
- REF-AWS-ECS-SECRETS-ENVVAR
- REF-VAULT-LEASES
- REF-SPIFFE-WORKLOAD-API
- REF-AWS-LAMBDA-SNAPSTART
