# Detour-outcome posture v0

Purpose: define a **tiny typed detour-outcome seam** so a chooser/open/auth/approval detour can finish with one exact shell-visible outcome object, instead of forcing the shell to reinterpret the pending-request handle itself, guess from focus, or flatten every result into pasted text.

## Posture
1. **A completed outcome is not the pending request anymore**
   - A pending request names one interaction that is still in flight.
   - Once the provider responds, Steward should be allowed to mint one exact outcome object that records how the detour finished.
   - Reusing the pending-request handle itself as the lasting result would blur live interaction state and completed evidence.
2. **Outcome, grant/session, and return ticket are different truths**
   - A detour outcome says what came back: target chosen, denial, cancellation, expiry, or provider-lost finish.
   - A grant/session handle names live power that may continue after the chooser/approval closes.
   - A return ticket names one exact way the shell may rebind attention or reveal the result locally.
   - Steward should keep those truths separate instead of flattening them into one vague “portal object”.
3. **Typed outcomes beat scraped text summaries**
   - Useful outcome shapes include exact target anchors, reviewed selectors, denial summaries, approval receipts, result metadata, or `no selection` / `canceled` / `expired` truth.
   - The shell may still render a friendly sentence, but the semantic footing should remain the exact outcome object rather than copied text or focus guesses.
4. **One outcome should answer one finished question**
   - Phase 1 should prefer one exact detour result over a running workflow log or resumable history chain.
   - A chooser result, an approval answer, or an auth/browser completion can each finish as one compact outcome object with provenance and freshness.
5. **Rebind must stay explicit**
   - If the originating pane, prompt lease, or command frame still exists, Steward may bind the outcome back to that surface.
   - If not, Steward should be able to say `outcome available`, `rebind required`, or `open in witness` rather than silently retargeting to some convenient replacement shell surface.
6. **Live sessions may be yielded, but they should be named separately**
   - Some completions may also yield a session handle, grant handle, or restore-like token under the membrane.
   - The shell-visible outcome should describe that separately instead of pretending the finished chooser response and the later live session are the same object.
7. **Outcome cards should stay small and inspectable**
   - The custom shell+terminal should be able to show compact detour-outcome cards or chips near the owner frame.
   - Those cards may offer reveal, copy, reopen-review, or continue-with-result actions, but they should stay visibly weaker than fresh intent or lifecycle authority.
8. **Expiry and persistence should stay ordinary**
   - A detour outcome may be transient, remembered for a bounded time, or explicitly promoted into a receipt or target anchor.
   - Steward should not silently promote every outcome into durable workflow state, searchable global history, or a portable callback/resume substrate.
9. **Provider-owned response shaping stays provider-local**
   - Providers may encode response details through portal signals, activation tokens, local restore tokens, or other platform-specific mechanics.
   - Steward may project the resulting truth into one typed outcome object, but should not pretend the raw provider response is itself the portable contract.
10. **Keep the phase-1 seam smaller than a workflow engine**
    - The portable seam is only: one pending request may finish as one exact typed outcome, with explicit rebind or degrade paths.
    - Avoid freezing a universal detour-result schema, workflow-history family, or generic callback/result transport plane before repeated pressure proves Steward really needs it.

## Phase-1 non-goals
- a universal workflow-event log or resumable multi-step detour history;
- treating completed outcomes as bearer authority or as a substitute for live session/grant handles;
- silently retargeting completed outcomes to whatever pane happens to be active;
- a generic callback/result broker shared across providers, browsers, terminals, and helpers;
- durable global storage for every chooser/open/auth result by default.

## Adjacent docs
- `pending-request-posture-v0.md`
- `return-ticket-posture-v0.md`
- `grant-handle-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `proposal-lane-posture-v0.md`
- `current-command-posture-v0.md`
- `prompt-lease-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-REMOTE-DESKTOP
- REF-VSCODE-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
