# Activation-retry attempt posture v0

## Purpose
Name the smallest useful truth for a follow-up attempt after activation demand, live-channel, routing, overload, timeout, early-data, or restart ambiguity.

A retry, replay, transparent retry, hedge, reconnect-driven resend, or post-drain follow-up can be useful evidence, but it must not silently become proof of route binding, readiness, custody, work disposition, side-effect success, or exactly-once behavior.

This seam is deliberately narrower than a retry engine. It only asks one question: **what can Steward honestly say about this follow-up attempt and its relationship to the original intent?**

## What this witness may say
A retry-attempt witness may record:

- `retry_attempt_ref`: the exact follow-up attempt being described.
- `original_demand_ref`: the earlier demand, request, event, live-channel send, or activation item this attempt follows.
- `attempt_group_ref`: the retry / replay / hedge group, when multiple attempts belong to one user-visible intent.
- `attempt_ordinal`: first attempt, transparent retry, retry 2, hedge peer, resumed replay, manual retry, or operator-triggered retry.
- `issuer_ref`: client, runtime, proxy, supervisor, library, operator, controller, or remote peer that initiated the attempt.
- `surface_ref`: route, alias, channel, listener, queue, live-channel, or activation surface used for the attempt.
- `canonical_intent_ref`: the normalized request / effect intent used to judge whether the attempt is an exact replay, a same-key mismatch, a narrowed retry, a superseding request, or a new request.
- `safety_basis`: safe method, idempotent operation, idempotency key, effect key, transport never-applied evidence, explicit operator review, hedge-only, non-idempotent-but-reviewed, unsafe, or unknown.
- `commit_boundary`: uncommitted, maybe-sent, server-application-not-seen, response-headers-seen, partial-response-seen, request-body-buffer-overflow, external-effect-possible, external-effect-confirmed, or unknown.
- `retry_advice_ref`: optional `retry-after`, pushback, cooldown, 425/early-data retry-after-handshake, local backoff, or denial hint that influenced timing.
- `not_before`: earliest known follow-up time, if any.
- `budget_ref`: optional local retry budget, token bucket, retry quota, attempt limit, route-level retry budget, or adaptive limiter witness.
- `early_data_ref`: optional early-data / 0-RTT / replay-risk context.
- `winner_ref`: for hedged attempts, the attempt whose response was accepted.
- `loser_fate`: canceled, still-in-flight, ignored-after-winner, reset, completed-late, duplicate-effect-possible, or unknown.
- `outcome_link`: adjacent work-disposition, custody, effect-boundary, live-channel, probe, or traffic-binding witness that must carry stronger truth.

## States worth preserving
The first version only needs descriptive states, not a portable state machine:

- `fresh-attempt`: not a retry; included so attempt groups can show their first member.
- `transparent-retry`: library/runtime retry where the substrate can explain that the application was not reached or no committed response boundary was crossed.
- `safe-retry`: retry judged safe by method, operation class, or explicit reviewed contract.
- `idempotent-replay`: same canonical intent under the same reviewed idempotency/effect key.
- `same-key-mismatch`: the same key was reused for different canonical intent and must not silently mutate the earlier operation.
- `pushback-delayed`: follow-up is delayed by server pushback, `Retry-After`, local backoff, or another advisory cooldown.
- `budget-exhausted`: local or route-level retry quota/budget prevents another automatic attempt.
- `hedged`: speculative duplicate attempt issued before the original is known to have failed.
- `hedge-winner-known`: one hedge response was accepted and other attempt fates still need explicit cleanup or ambiguity.
- `maybe-applied`: the earlier attempt may have reached application or side-effect boundaries; automatic replay cannot claim safety by itself.
- `early-data-replay-risk`: early data, fast open, or similar replay-prone transport state affects the attempt.
- `manual-review-required`: automatic retry is intentionally blocked until a person or higher-level policy reviews the ambiguity.
- `retry-abandoned`: no more automatic attempts will be made by this issuer.
- `retry-unknown`: the issuer cannot honestly classify safety, commitment, or duplicate risk.

## Boundaries
Do not infer any of the following from a retry-attempt witness alone:

- that the component is ready or serving;
- that the traffic binding is current;
- that a live channel drained or resumed without loss;
- that admitted work is still in custody;
- that a work item completed, expired, or was discarded;
- that an external effect happened exactly once;
- that an idempotency key exists, is fresh, or matched canonical intent;
- that a server pushback, `Retry-After`, backoff delay, or token bucket is a reservation;
- that a hedged losing attempt caused no side effect;
- that replay through early data or session resumption is safe.

## Steward-shape constraints
For now, Steward should keep this seam explanatory and tiny:

- no global retry scheduler;
- no generic retry policy language;
- no RPC framework;
- no service mesh;
- no route-level retry budget service;
- no durable queue or broker;
- no distributed idempotency ledger;
- no exactly-once effect plane;
- no universal hedge racing subsystem;
- no automatic early-data replay authority.

## Why this belongs after live channels
Live-channel witnesses can say that a stream was closed, reset, drained, resumed, or gap-ambiguous. They should not decide whether the next send is a safe retry, an unsafe duplicate, a replay under the same canonical intent, or a brand-new request.

Traffic-binding witnesses can say which surface currently maps new demand. They should not decide whether a client may safely replay old intent through that surface.

Effect-boundary witnesses can say what side-effect boundary was crossed. They should not be guessed from retry behavior.

## SlopOS pressure
SlopOS already has a useful network-request idempotency pressure: a scoped request id can mean exact replay of the same canonical request, and mismatch should reject rather than mutate old intent. Steward should steal that narrow law, but should not import SlopOS's full network lease, request-state, or session-resumption vocabulary while both systems are still design-phase.

## Executable settlement
Revision 188 promotes the first retry/hedge subset into closed packets and a deterministic corpus:

- `ST-RETRYADVICE v0` records not-before, pushback, cooldown, rate-limit, or unknown retry timing as advice only.
- `ST-RETRYBUDGET v0` records local or scoped automatic-retry allowance/blocking as an observation, not a global capacity or route grant.
- `ST-RETRYATTEMPT v0` records original intent, attempt group, ordinal, canonical-intent digest, safety basis, commitment boundary, duplicate risk, early-data state, and adjacent references.
- `ST-HEDGEFATE v0` records winner response and loser fates while preserving duplicate ambiguity.

The corpus `../40-verification/retry-settlement-corpus-v0.md` and checker `../../tools/steward_retry_settlement_harness.py` reject retry advice as reservation, zero-budget automatic retry, same-key/different-intent replay, transparent retry after response commitment, unsafe early-data replay, effect-confirmed attempts without an effect witness, and hedge-loser cancellation as no-side-effect proof.

## Open question
- **OQ-0091**: what retry/replay attempt truth deserves portable names before Steward becomes a retry engine, RPC framework, service mesh, broker, durable queue, quota service, workflow engine, distributed idempotency ledger, or exactly-once plane?

## References
REF-GRPC-RETRY; REF-GRPC-HEDGING; REF-AWS-SDK-RETRY-BEHAVIOR; REF-AWS-BUILDERS-BACKOFF-JITTER; REF-ENVOY-HTTP-ROUTING; REF-GOOGLE-CLOUD-STORAGE-RETRY-STRATEGY; REF-HTTP-RFC9110; REF-RFC6585; REF-RFC8470-EARLY-DATA; REF-AWS-BUILDERS-IDEMPOTENT-APIS.
