# Pressure admission proof posture v0

Purpose: make resource pressure, spendable headroom, new-work backpressure, and admission gate decisions executable without turning any of them into lifecycle authority or success.

## Posture
1. **Pressure is not failure**
   - A pressure packet explains a scoped stall, saturation, quota, latency, reclaim, adapter, or operator signal. It does not prove failed, stopped, unhealthy, not-serving, or incident state.
2. **Headroom is not authority**
   - A headroom packet may say a restart budget, quota, concurrency lane, rate window, seat, or token bucket has room now. It does not approve the action, reserve future room, or bypass an authorization check.
3. **Backpressure is not demand acceptance**
   - A backpressure packet says how new work is being paced, queued, deferred, shed, or rejected. It does not create custody or a demand episode.
4. **Admission gates are not work**
   - An admission-gate packet records one allow, queue, defer, shed, reject, or unknown decision. A separate demand witness is still required before Steward can talk about accepted work.
5. **Retry-later is not a reservation**
   - Backpressure may carry a retry-after hint. That hint does not reserve headroom or grant future authority.
6. **Pressure-based choices require adjacent basis**
   - A non-allow gate must cite pressure, headroom, or backpressure basis. A gate that allows work cannot cite exhausted headroom or blocking backpressure as though they were positive proof.

## Non-goals
- a universal scheduler, autoscaler, overload controller, fair-queuing service, quota wallet, or rate-limit service;
- automatic repair, eviction, migration, or capacity planning;
- treating pressure/headroom/backpressure as readiness, serving, authorization, execution, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/pressure-admission-corpus-v0.jsonl`; the checker is `../../tools/steward_pressure_admission_harness.py`.
