# Assist-receipt posture v0

Purpose: define a **tiny exact assist-receipt seam** so a quick fix, suggestion, repair card, chooser follow-on, or similar helper can answer **why this appeared, what exact stronger anchor it binds to, how fresh it is, and why a stronger apply path may be disabled** without turning suggestion metadata into diagnosis truth, workflow state, or ambient shell authority.

## Posture
1. **An assist receipt binds to one stronger anchor or selector context**
   - The healthiest owner is one exact current-command object, command frame, command verdict, output slice, exact selector, exact diagnostic-bearing range, repair card, or other reviewed anchor.
   - Steward should resist folklore like “this suggestion probably belongs to whatever was nearby in the pane”.
2. **The suggestion and its receipt stay different truths**
   - The receipt explains provenance, anchor, freshness, and disabled reasons.
   - The suggestion itself remains a proposal, patch, repair card, chooser result, or other reviewable next move.
   - Steward should preserve those distinctions instead of smearing `why this is here` into the suggestion title alone.
3. **Why-it-appeared, why-it-is-disabled, and what-it-would-touch stay separate**
   - `matches current failure`, `targets this exact command`, `derived from these diagnostics`, `stale anchor`, `needs fresh intent`, and `policy blocked` are different truths.
   - A healthy assist receipt can answer all three without pretending any one of them proves the others.
4. **Exact provider-owned context outranks parse-lens folklore**
   - Exact shell metadata, exact command boundaries, exact diagnostics, exact receipts, and exact selector objects should outrank transcript scraping or regex guesses.
   - When only weaker footing exists, Steward should be allowed to say `assist receipt (candidate)` instead of flattering it into exactness.
5. **Receipts may resolve details lazily, but must keep identity stable**
   - A lightweight initial receipt may later reveal more detail such as bound diagnostics, changed spans, or richer disabled reasons.
   - Lazy detail is healthy as long as the receipt keeps the same reviewed anchor/provenance story instead of silently retargeting.
6. **Receipts should stay compact and terminal-friendly**
   - Phase 1 likely needs only: owning anchor, short why-this-appeared summary, provenance/source class, freshness, optional bound selector/diagnostic hints, and optional disabled reason.
   - Steward should avoid freezing a giant suggestion taxonomy, recommendation score language, or durable workflow queue too early.
7. **Receipts should teach even when the action is unavailable**
   - Hidden disappearance is weaker UX than `disabled with exact reason` when the user explicitly inspects or invokes the assist surface.
   - A stale, policy-blocked, or low-confidence suggestion can still help if its receipt explains the missing footing honestly.
8. **One small assist-receipt seam beats ambient suggestion mystique**
   - Terminal quick fixes, suggestion menus, repair cards, chooser follow-ons, and history-backed assists all want the same anti-folklore discipline.
   - Steward should keep this seam smaller than a universal recommendation engine, diagnosis graph, or workflow/explanation family.

## Phase-1 non-goals
- auto-applying a suggestion merely because its receipt exists;
- a universal scoring/ranking language for every future assist provider;
- turning candidate parse-lens receipts into exact provider truth;
- a durable suggestion inbox, workflow queue, or cross-session recommendation service;
- forcing every assist source to produce identical rich explanation structure.

## Adjacent docs
- `assist-surface-posture-v0.md`
- `repair-card-posture-v0.md`
- `injection-receipt-posture-v0.md`
- `command-patch-posture-v0.md`
- `current-command-posture-v0.md`
- `command-frame-posture-v0.md`
- `command-verdict-posture-v0.md`
- `output-slice-posture-v0.md`
- `parse-lens-posture-v0.md`
- `state-explainer-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-VSCODE-CODEACTION-API
- REF-LSP-317-CODEACTION
- REF-VSCODE-UPDATE-1072
- REF-VSCODE-SHELL-INTEGRATION
