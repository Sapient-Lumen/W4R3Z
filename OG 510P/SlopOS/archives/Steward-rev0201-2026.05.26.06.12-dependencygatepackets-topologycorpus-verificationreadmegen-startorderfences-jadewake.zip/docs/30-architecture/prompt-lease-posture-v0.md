# Prompt-lease posture v0

Purpose: define a **tiny live-prompt lease seam** so the current editable shell prompt can be treated as an exact, expiring object instead of transcript folklore or pane-local guesswork.

## Posture
1. **The live prompt is a fresh exact object, not just painted text**
   - When the shell can prove one current prompt/input zone, Steward should be allowed to treat it as one exact prompt lease.
   - That lease exists to support prompt-local cursor movement, exact current-command reveal, and nearby assist affordances without guessing from scrollback.
2. **Prompt lease and command frame stay distinct**
   - A prompt lease names the currently editable input footing.
   - A command frame names one broader interaction record that may later include the launched command, output, receipt, and exit/result.
   - Steward should keep those truths separate instead of pretending historical command frames remain editable prompts.
3. **Prompt-local luxuries belong only to the live lease**
   - Click-to-move, inline edit helpers, prompt-local widgets, and current-command chips should bind only to the active prompt lease.
   - Historical prompts should degrade to selection, reveal, or exact-frame actions instead of fake editability.
4. **Expiry should be explicit and ordinary**
   - Executing the command, replacing the prompt, losing prompt markers, crossing a semantic epoch, or degrading across a hop may end the current prompt lease.
   - Steward should treat lease expiry as normal lifecycle for shell input rather than as an error that must be hidden.
5. **Degrade from prompt lease to weaker exact objects, not to folklore**
   - When the live prompt expires, Steward may still preserve the associated command frame anchor, transcript landmark, or last-known command summary.
   - It should not keep pretending the old prompt is still the active editable surface.
6. **Prompt lease should compose with freshness and capability truth**
   - A prompt lease belongs to one pane / hop path / semantic epoch and may depend on proven prompt-marking support.
   - Rich prompt-local UX should be willing to disappear or relabel itself when the capability ledger or freshness fences say the footing is stale.
7. **The shell may publish one exact current-command object beside the lease**
   - A live prompt may expose the current editable command text or structured command object for copy, explain, or review.
   - That object is still weaker than the later reviewed launch or lifecycle receipt and should expire with the lease unless reissued.
8. **Prompt leases should stay observational first**
   - The lease helps the terminal know where prompt-local editing is safe and where current-command assistance can attach.
   - It should not become a hidden lifecycle control lane, transcript rewrite protocol, or portable shell-object universe.
9. **Reconnect and restore should prefer witness-first downgrade**
   - After reconnect, workspace restore, or shell resync, Steward may regain exact command frames before it regains a live prompt lease.
   - It should prefer honest `no live prompt` truth over silently restoring edit authority to stale transcript text.
10. **Keep the phase-1 contract tiny**
    - Phase 1 likely needs only the idea that one current prompt may be exact, expiring, and prompt-local.
    - Avoid freezing transcript-edit APIs, multi-prompt concurrency, or a giant live-input object algebra before real pressure exists.

## Phase-1 non-goals
- making historical prompts permanently editable;
- freezing a universal transcript-editing or shell-object protocol;
- assuming every shell, terminal, or multiplexer can preserve an exact live prompt across hops or reconnects;
- turning prompt-click UX into hidden lifecycle control authority;
- requiring one mandatory prompt-marker protocol beyond a small capability-gated baseline.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `current-command-posture-v0.md`
- `input-surface-posture-v0.md`
- `command-guide-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `capability-ledger-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `precision-fence-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-GHOSTTY-RELEASE-130
- REF-GHOSTTY-CONFIG-REFERENCE
- REF-ITERM2-SHELL-INTEGRATION
- REF-FISH-OSC-MARKERS
- REF-FISH-TERMINAL-COMPAT
- REF-VSCODE-SHELL-INTEGRATION
