# Backpressure witness schema v0

## Purpose
`ST-BACKPRESS v0` is the closed packet profile for one scoped new-work pacing or pushback observation. It records queue/defer/shed/reject posture without becoming demand acceptance, custody, readiness, serving, retry reservation, execution, or effect success.

## Required fields
- `schema`: constant `ST-BACKPRESS v0`.
- `witness_id`: packet witness id.
- `backpressure_id`: stable backpressure observation id.
- `cid`: component identity.
- `scope_ref`: exact admission or lane subject.
- `issuer`: closed issuer object.
- `observed_at_ms`: monotonic observation time.
- `admission_class`: `http`, `rpc`, `message`, `timer`, `callback`, `operator_action`, `background`, or `unknown`.
- `backpressure_state`: `none`, `queueing`, `defer`, `shed`, `reject`, `pushback`, or `unknown`.
- `new_work_policy`: `accept`, `pace`, `queue`, `defer`, `shed`, `reject`, or `unknown`.
- `pressure_refs` and `headroom_refs`: bounded exact basis refs.
- `retry_after_ms`: retry-later hint, or zero when absent.
- `queue_class`: bounded class/lane summary.
- `started_at_ms` and `expires_at_ms`: bounded freshness window.
- `reason`: bounded explanation.
- `basis_refs`: bounded evidence refs.
- `non_implications`: must include `not-authority`, `not-authorization`, `not-demand`, `not-custody`, `not-work-completion`, `not-readiness`, `not-serving`, `not-retry-reservation`, `not-execution`, and `not-effect-success`.

## Cross-field rules
- Non-`none` backpressure needs pressure or headroom basis.
- `defer` and `pushback` require `retry_after_ms` when known.
- Active backpressure must not already be stale.
- Raw substrate handles, secrets, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A backpressure witness never proves demand acceptance, custody, work fate, service health, readiness, serving, retry reservation, authorization, execution, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/pressure-admission-corpus-v0.jsonl`; the checker is `../../tools/steward_pressure_admission_harness.py`.
