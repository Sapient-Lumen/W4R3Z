# Readiness-generation posture v0

Purpose: keep mid-run readiness and status truth **freshly attributable to the generation it actually observed** instead of flattening everything into one cheerful `ready` bit for the whole runtime cycle.

This seam stays intentionally small. It does **not** invent a giant dependency planner, a universal condition algebra, or a cross-runtime rollout protocol. It only says that when readiness or related status is reported against mutable launch/spec state, Steward should preserve a tiny way to say **which generation that observation belongs to**.

## Posture
1. **Runtime-cycle witness and readiness generation stay separate**
   - A component may keep the same runtime cycle while its effective launch/spec/config generation changes, reloads, or partially rolls forward.
   - The runtime-cycle witness answers “which concrete run is this?”; readiness generation answers “which reviewed generation did this readiness/status observation actually cover?”
2. **Generation is attached to observed readiness/status, not guessed from latest intent**
   - If the supervisor or adapter knows a current spec / launch / config generation, it should not silently pretend every ready-like observation already covers that newest generation.
   - A readiness/status report may honestly belong to an older observed generation until the component or adapter confirms the newer one.
3. **Control-ready, serve-ready, and degraded/waiting state may share the same generation seam**
   - The usefulness is not limited to `ready=true`.
   - Waiting, reloading, draining, degraded, or not-yet-ready observations can also be much more honest when tied to the observed generation they describe.
4. **Generation is a freshness/comparison aid, not a public rollout engine**
   - Steward may use a tiny generation witness to explain stale status, fence shell actions, or color execution-ground cards.
   - It should not thereby freeze a universal deployment controller, reconcile loop vocabulary, or giant desired-versus-current planner.
5. **Generation may lag inside one live run and that is healthy**
   - If config changes, activation material changes, or reload work is in progress, the current runtime cycle may still be alive while status honestly says “observed generation N-1”.
   - That is better than claiming the newest generation is live before the leaf has really observed it.
6. **Unknown and mixed coverage are healthier than fake precision**
   - Some runtimes can report exact per-condition or per-status observed generations.
   - Others may only say that a newer reviewed generation exists but readiness still corresponds to the prior one, or that the mapping is unknown.
   - Steward should preserve those distinctions instead of backfilling certainty.
7. **Shell chrome should make generation drift legible without turning it into authority**
   - Ground cards, receipt cards, and command-frame chips may show compact labels like `ready@g12`, `waiting@g12 while desired g13`, or `generation unknown`.
   - Those labels orient the user; they do not themselves grant replay, stop, or mutation rights.
8. **Precondition witnesses may bind to readiness generation when that is the real stale fence**
   - Some reviewed actions care that the component is not merely the same runtime cycle but also ready for the same observed generation the user saw.
   - Steward should allow that exact stale-fence story without requiring ambient “latest status” lookups.
9. **Launch basis and readiness generation stay different**
   - Launch-basis evidence explains what crossed the launch boundary or was selected for child delivery.
   - Readiness generation explains which reviewed generation current status actually covers.
   - One should not quietly replace the other.
10. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional scalar or opaque witness saying which reviewed generation a status/readiness observation covers.
   - Broader condition graphs, rollout planners, and version-vector families remain intentionally undecided.

## Phase-1 non-goals
- a universal desired-versus-current rollout planner;
- freezing one cross-runtime meaning for every kind of `generation`;
- requiring every component to expose per-condition generation stamps;
- making readiness generation a permission token or a mutation authority channel;
- replacing runtime-cycle witnesses, launch receipts, or observation cursors with one grand unified version number.


## Rev0198 executable settlement
`ST-GENREADY v0` is the first closed packet for scoped generation-readiness evidence. It requires an apply ref, probe refs, an explicit scope, evaluation time, and expiry. It deliberately refuses to become global readiness, traffic binding, serving, stability, or effect success.

## Adjacent docs
- `readiness-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `launch-boundary-posture-v0.md`
- `activation-cause-posture-v0.md`
- `execution-ground-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `status-channel-posture-v0.md`

## References
- REF-K8S-PODS-OBSERVED-GENERATION
- REF-K8S-POD-LIFECYCLE
- REF-SD-NOTIFY
- REF-DINIT-SERVICE
