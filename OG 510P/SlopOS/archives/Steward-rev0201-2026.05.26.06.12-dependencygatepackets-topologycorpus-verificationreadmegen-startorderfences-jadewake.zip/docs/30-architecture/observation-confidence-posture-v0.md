# Observation confidence posture v0

Purpose: define how Steward can carry **confidence, provenance, and trust** on shell/terminal observations without pretending every marker, frame, or target is equally exact.

## Posture
1. **Confidence and trust are different fields**
   - Confidence answers “how exact is this observation?”
   - Trust answers “did this come from a source we are willing to treat as authenticated enough for higher-risk affordances?”
2. **A useful phase-1 model should stay tiny**
   - Steward should start with a compact model such as:
     - confidence: low / medium / high,
     - trusted: true / false,
     - provenance tag such as explicit-shell, marker-assisted, terminal-inferred, or user-specified.
   - Avoid a giant probabilistic scoring system.
3. **Per-field confidence beats pane-wide mythology**
   - cwd, command line, frame boundary, remote path hint, action target, or runtime-cycle witness attachment may have different confidence.
   - Steward should prefer field-level honesty over “this pane is trusted” folklore.
4. **Explicit shell reports should rank above buffer reconstruction**
   - Metadata sent directly by the shell is generally stronger than metadata reconstructed from visible bytes and markers.
   - Exact command lines or targets reported with an explicit trust signal should stay visibly distinct from best-effort guesses.
5. **Confidence may improve after the fact**
   - Some observations become clearer only after a command finishes, a receipt arrives, or a fresh prompt resync occurs.
   - Steward should allow an observation to be refined rather than forcing the first guess to be permanent truth.
6. **Trust must stay freshness-scoped**
   - A nonce-bound or equivalent trust signal belongs to one concrete semantic world, not forever.
   - Hops, shell resets, resync, or transport changes may downgrade trust even when visible text looks similar.
7. **Lower confidence should narrow actions, not break usability**
   - Low-confidence data can still justify copy, open, explain, or bookmark affordances.
   - Mutating actions such as rerun, stop same run, or inspect concrete remote targets should prefer higher-confidence and trusted observations.
8. **Confidence and trust are observational, not authority**
   - A trusted frame does not grant permission to mutate a component.
   - These annotations only help the UI decide how bold or cautious it should be.
9. **Downgrade should be visible when semantics cross layers**
   - SSH-like hops, tmux-like layers, fallback parsing, or lost markers should be allowed to lower confidence or strip trust explicitly.
   - Steward should prefer visible downgrade over silently preserving stale certainty.
10. **Currentness strength should stay scoped to the proving path**
   - A high-confidence bookmark, progress marker, or synced-through cursor may still speak only for one exact stream, publisher, or local observer.
   - Steward should allow `high confidence for this view` without implying `freshest globally` or `caught up to every stronger read class`.
11. **Plain terminal fallback remains valid**
   - Shell/terminal UX should get better when confidence and trust metadata are available.
   - Basic interactive use must remain possible without them.

## Phase-1 non-goals
- a universal probabilistic scoring engine;
- proving remote host identity or user identity through terminal metadata alone;
- letting trusted shell metadata bypass normal authorization checks;
- requiring every shell to report every field with equal precision;
- retroactively pretending stale metadata is still trusted after a semantic reset.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `action-surface-posture-v0.md`
- `precision-fence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `currentness-class-posture-v0.md`

## References
- REF-K8S-API-CONCEPTS
- REF-ETCD-LEASES
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-SHELL-INTEGRATION
- REF-OSC133-SPEC
- REF-FISH-TERMINAL-COMPAT
