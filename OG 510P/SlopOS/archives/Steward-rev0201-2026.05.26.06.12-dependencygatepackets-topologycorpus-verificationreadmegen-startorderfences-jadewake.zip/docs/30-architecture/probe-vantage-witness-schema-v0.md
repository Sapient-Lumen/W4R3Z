# Probe-vantage witness schema v0

## Purpose
`ST-PROBE v0` is the first closed packet for one Steward probe-vantage witness. It reports who probed what, from where, with what scope, result, threshold/freshness, and failure hint without turning one observation into readiness, serving, route authority, rollout settlement, remediation success, incident truth, or effect success.

The central rule: **green is not ready; red is not repair authority.**

## Machine profile
- Machine profile: `../../schemas/st-probe-v0.schema.json`
- Checker: `../../tools/steward_currentness_control_harness.py`
- Corpus: `../40-verification/corpora/currentness-control-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-PROBE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the observer/prober |
| `probe_kind` | `startup`, `readiness`, `liveness`, `grpc_health`, `balancer`, `mesh`, `synthetic`, `outside_in`, `adapter`, or `unknown` |
| `vantage_kind` | `local_runtime`, `supervisor`, `proxy`, `balancer`, `mesh`, `outside_in`, `user_path`, `adapter`, or `unknown` |
| `vantage_ref` | explicit vantage ref |
| `scope` | `process`, `port`, `endpoint`, `route`, `dependency`, `control_surface`, `user_path`, or `unknown` |
| `result` | `pass`, `fail`, `degraded`, `timeout`, `inconclusive`, `skipped`, `stale`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `freshness` | nested source vantage, observed time, freshness state, and optional recheck/expiry |
| `basis_refs` | bounded evidence refs supporting the observation |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `target_ref`, `endpoint_ref`, `route_binding_ref`, `live_channel_ref`, `material_freshness_ref`, `runtime_cycle`, `failure_hint`, `threshold_state`, `consecutive_failures`, and `next_due_ms`.

## Required non-implications
A valid packet must include:

- `not-readiness`
- `not-serving`
- `not-route-authority`
- `not-rollout-settlement`
- `not-remediation-success`
- `not-effect-success`
- `not-incident-truth`

When a probe references material, route, or channel witnesses, it may also include `not-material-freshness`.

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Raw host, process, endpoint, token, secret, bearer, or repair-action fields reject.
- A `pass` result cannot carry stale or unknown freshness.
- `fail`, `timeout`, and `degraded` results require `failure_hint`.
- `stale`, `unknown`, and `inconclusive` results require `unknown_reason`.
- `next_due_ms` cannot precede `observed_at_ms`.

## Rejected surfaces
The corpus rejects:

- probe packets claiming serving;
- stale probe observations reported as pass;
- failing probes without failure hints;
- hidden repair actions;
- duplicate JSON keys;
- flow-level promotion from probe pass to serving.

## Non-goals
- no health-check DSL, monitor, service mesh, load balancer, SLO/SLA system, canary controller, rollout controller, repair engine, or incident manager;
- no automatic restart, kill, withdraw, reroute, rollback, or repair authority from probe result alone;
- no inference from a local, cached, thresholded, sampled, fail-open, or outside-in observation to global readiness or serving.

## Adjacent docs
- `activation-probe-vantage-posture-v0.md`
- `material-freshness-witness-schema-v0.md`
- `control-verdict-witness-schema-v0.md`
- `traffic-binding-witness-schema-v0.md`
- `live-channel-witness-schema-v0.md`
- `readiness-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `canonical-json-profile-v0.md`
