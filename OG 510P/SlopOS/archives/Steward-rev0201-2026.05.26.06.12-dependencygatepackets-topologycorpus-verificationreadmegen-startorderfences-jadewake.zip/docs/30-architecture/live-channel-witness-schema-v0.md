# Live-channel witness schema v0

## Purpose
`ST-LIVECHAN v0` is the first closed packet for one Steward live-channel witness. It reports bounded truth about an already-existing connection, stream, subscription, watch, WebSocket, server-sent event stream, multiplexed RPC channel, or drainable message client without turning channel survival, drain, close, reset, resume, or cursor evidence into route, lifecycle, custody, completion, effect, rollout, or lossless-continuity truth.

The central rule: **a live channel is already inside some path; it is not new-demand binding, readiness, serving, custody, work completion, effect success, or lossless continuity.**

## Machine profile
- Machine profile: `../../schemas/st-livechan-v0.schema.json`
- Checker: `../../tools/steward_channel_binding_harness.py`
- Corpus: `../40-verification/corpora/channel-binding-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-LIVECHAN v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `live_channel_ref` | exact channel, stream, watch, subscription, or transport ref |
| `channel_kind` | `http2`, `http3`, `grpc`, `websocket`, `sse`, `watch`, `message_subscription`, `tcp`, `quic`, or `unknown` |
| `holder_ref` | holder or observer of the channel, such as proxy, client, component, sidecar, or adapter |
| `layer` | `listener`, `connection`, `stream`, `subscription`, `publisher`, or `application` |
| `channel_state` | `open`, `draining`, `closing`, `closed_cleanly`, `closed_abnormally`, `reset`, `peer_lost`, `resumed`, `lost`, or `unknown` |
| `freshness` | source vantage, observed time, freshness state, and optional recheck/expiry |
| `basis_refs` | bounded evidence refs supporting the channel observation |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields name related traffic surfaces, listener/subscription refs, component/revision/incarnation refs, peer refs, no-new-substream fences, drain state/deadline, last stream or event cursor, close signal, resume hint, route-binding ref, material-freshness refs, custody/disposition refs, and gap state.

## Non-implication vocabulary
A valid live-channel witness must include the base refusals:

- `not-readiness`
- `not-serving`
- `not-route-authority`
- `not-custody`
- `not-work-completion`
- `not-effect-success`
- `not-lossless-continuity`

It may also refuse `not-material-freshness`, `not-current-incarnation`, and `not-rollout-settlement` when those caveats matter.

## Drain and close rules
`drain_started` requires a `drain_deadline_ms` unless the witness explicitly uses a deadline-unknown state. This keeps “graceful” from becoming an unbounded marketing word.

Close signals are evidence, not fate. `close_sent`, `close_received`, `closing_handshake`, `closed_cleanly`, `closed_abnormally`, `reset`, `transport_error`, and `reason_disagrees` do not settle application work without adjacent custody, disposition, or effect-boundary witnesses.

## Resume and cursor rules
Resume hints and cursors are useful but weak. A bookmark, last-event id, watch resource version, reconnect hint, or accepted resume may still have gaps, duplicates, or stale identity. A resume hint must refuse lossless continuity, and it cannot claim `no_gap_proven` unless adjacent custody or disposition evidence is cited.

## Rejected surfaces
The corpus rejects:

- resume-as-lossless claims;
- channel packets that claim effect success;
- started drains without a deadline;
- raw bearer material;
- duplicate JSON keys.

## Non-goals
- no portable connection manager, socket API, RPC framework, WebSocket/SSE/watch service, pub/sub broker, stream multiplexer, reconnect scheduler, session-resumption plane, service mesh, sticky-session grammar, or endpoint-drain controller;
- no promise that open, cleanly closed, draining, reset, or resumed channels prove readiness, route authority, work completion, effect success, or no-loss continuity;
- no standardization of transport-specific close codes or RPC statuses as portable Steward truth.

## Adjacent docs
- `activation-live-channel-posture-v0.md`
- `traffic-binding-witness-schema-v0.md`
- `activation-traffic-binding-posture-v0.md`
- `activation-custody-posture-v0.md`
- `activation-work-disposition-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `activation-retry-attempt-posture-v0.md`
- `adapter-membrane-posture-v0.md`
- `canonical-json-profile-v0.md`
