# Approval-decision witness schema v0

## Purpose
`ST-APPROVAL v0` records a bounded approval decision for one exact Steward operation request digest. It answers: **who approved or denied this operation, for what scope, until when, and relying on which delegation warrant evidence?**

Approval is intentionally separate from delegation, review, authorization checking, operation receipt, runtime state, and effect settlement.

## Machine profile
- Machine profile: `../../schemas/st-approval-v0.schema.json`
- Checker: `../../tools/steward_governance_harness.py`
- Corpus: `../40-verification/corpora/governance-authorization-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-APPROVAL v0` |
| `witness_id` | generic Steward witness id |
| `approval_id` | approval id matching `apv_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object |
| `approver` | approving actor |
| `subject_op_ref` | operation request reference |
| `subject_request_digest` | canonical digest of the exact operation request |
| `decision` | `approved`, `denied`, `needs_review`, `expired`, `revoked`, or `unknown` |
| `approval_scope` | component, verb, optional runtime cycle, and maximum force class |
| `observed_at_ms` | integer decision observation time |
| `valid_until_ms` | integer decision expiry |
| `basis_refs` | bounded evidence refs |
| `required_warrant_refs` | delegation warrant ids the approval relies on |
| `non_implications` | explicit refusal list |

Optional fields: `second_approver_ref`, `denial_reason`, `revocation_ref`, `unknown_reason`, and `risk_class`.

## Binding rules
An `approved` decision must cite at least one delegation warrant ref. It must not already be stale at `observed_at_ms`. A `denied` decision must carry a reason. A `revoked` approval must cite `revocation_ref`.

`approval_scope.cid` must equal the root `cid`. The scope verb must match the operation being authorized by a later `ST-AUTHCHECK v0` packet.

## Force rule
An approval whose maximum force is `kill` must be classified as `break_glass`. This does not execute force; it only makes the stronger approval posture visible.

## Rejections
The corpus rejects:

- approved decisions without warrant basis;
- denied approvals without a reason;
- kill-level approval without break-glass risk class;
- approval packets claiming execution;
- digest mismatch when a later authorization check tries to use the approval.

## Non-goals
- no permanent delegation;
- no owner-of-record truth;
- no execution;
- no component state;
- no effect success;
- no broad permission grant.

## Adjacent docs
- `governance-authorization-posture-v0.md`
- `delegation-warrant-witness-schema-v0.md`
- `operator-review-witness-schema-v0.md`
- `authorization-check-witness-schema-v0.md`
- `approval-rung-posture-v0.md`
- `operation-arbitration-posture-v0.md`
