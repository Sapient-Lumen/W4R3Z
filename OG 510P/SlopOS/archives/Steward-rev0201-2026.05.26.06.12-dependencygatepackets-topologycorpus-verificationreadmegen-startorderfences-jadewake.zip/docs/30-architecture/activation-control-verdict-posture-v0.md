# Activation-control verdict posture v0

Purpose: name the smallest useful truth for **a control plane, supervisor, balancer, rollout loop, or operator adapter turning bounded observations into a scoped lifecycle or routing verdict** so Steward can keep raw probe evidence, readiness, serving, advertisement, rollout status, and policy action separate.

This seam is intentionally small. It does **not** invent a rollout controller, load balancer, service mesh, incident manager, autoscaler, remediation engine, health algebra, canary framework, or rollback system. It answers one narrower question: **when some actor has synthesized observations, thresholds, readiness gates, stability windows, holds, or operator input into a current verdict such as `progressing`, `eligible`, `withheld`, `ejected`, `stalled`, or `rollback started`, how can Steward show that verdict without pretending the observations themselves changed meaning or that the verdict is universal truth?**

## Posture
1. **A control verdict is not the same thing as the evidence it summarizes**
   - Probe-vantage witnesses say who checked what and what was observed.
   - Readiness, serve-state, presence advertisement, pressure, and material freshness witnesses each report their own scoped truth.
   - A control verdict is a later synthesis over some subset of those facts plus policy, thresholds, time windows, or manual decisions.
   - Steward should never let `healthy`, `ready`, `available`, `progressing`, `ejected`, or `rollback` collapse into the same green/red bit.

2. **The verdict issuer and scope must be explicit**
   - A kubelet, Deployment controller, service mesh proxy, DNS health system, load balancer, serverless traffic controller, Nomad deployment loop, ECS deployment circuit breaker, and human operator are different issuers.
   - Useful fields include `verdict_issuer`, `control_loop_ref`, `subject_ref`, `subject_kind`, `component_id`, optional `incarnation_id`, optional `revision_ref`, optional `endpoint_or_route_ref`, and `scope`.
   - If the issuer cannot be identified, the verdict should downgrade rather than masquerade as global lifecycle state.

3. **Verdict basis should be visible without becoming a proof empire**
   - A verdict can be based on probe results, readiness gates, observed generations, min-ready or min-healthy windows, failure thresholds, desired/observed revision drift, resource-admission failures, traffic percentages, outlier counts, manual promotion, or a rollback policy.
   - Steward should preserve small basis hints such as `probe-threshold`, `readiness-gate`, `stability-window`, `failure-threshold`, `traffic-split`, `manual-promotion`, `policy-hold`, `quota-or-placement-failure`, `outlier-ejection`, or `unknown-basis`.
   - It should not require every controller to reveal a full decision tree.

4. **Report-only verdicts and actuating verdicts are different powers**
   - Some systems report `ProgressDeadlineExceeded` or similar status without taking corrective action.
   - Others stop launching new tasks, eject a host from a load-balancing set, shift traffic, or roll back to the last completed deployment.
   - A verdict should therefore carry an `effect_class` such as `report-only`, `routing-only`, `admission-gating`, `restart-or-recreate`, `rollback-selected`, `rollback-started`, `manual-action-required`, or `unknown-effect`.
   - Steward should avoid implying rollback, restart, or reroute merely because a status condition says stalled.

5. **External gates are inputs, not hidden readiness magic**
   - Readiness gates and similar extension points are useful because they let an external controller contribute a condition to readiness.
   - They are dangerous if users cannot see that the ordinary container probe passed but an external gate is missing, false, stale, or owned by another controller.
   - Steward should make `gate-pending`, `gate-false`, `gate-stale`, `gate-missing`, and `gate-satisfied` visible when those facts explain a verdict.

6. **Progress, availability, stability, and rollout completion stay separate**
   - A target can be creating, scaling, becoming available, stable long enough, complete, stalled, failed, paused, or already rolled back.
   - `available` may mean a minimum availability condition, not universal end-user success.
   - `stable` may mean a controller-specific min-ready or min-healthy window has elapsed, not that every side effect or downstream dependency is safe.
   - Steward should preserve `progressing`, `available-minimum`, `stable-window-passed`, `complete`, `paused`, `stalled`, `failed`, and `unknown` as scoped verdicts, not global service adjectives.

7. **Routing and traffic verdicts are not serve-state**
   - A component may report `serving` while a balancer verdict withholds it from new traffic, sends only a percentage of traffic, keeps it as a tagged test URL, drains it, or ejects it locally.
   - Conversely, fail-open or stale DNS / route behavior can continue to send traffic to a target that no current probe would bless.
   - Steward should keep `eligible-for-new-traffic`, `weighted`, `shadow-or-tag-only`, `withheld`, `draining-only`, `ejected`, `fail-open`, and `unknown-route-verdict` separate from the component's own serve-state witness.

8. **Ejection and quarantine are local, timed, and policy-shaped**
   - Passive outlier systems can eject an endpoint because it behaved unlike peers, even though another observer or direct probe might disagree.
   - Ejection may be probabilistic, bounded by a maximum ejection percentage, subject to enforcement probability, or reset when membership changes.
   - Steward should show local ejection/probation truth with issuer, evidence class, window, and reset caveat rather than marking the component globally dead.

9. **Fail-open, insufficient-data, and inconclusive verdicts deserve first-class humility**
   - Some balancers or health systems deliberately keep routing when every target looks bad, or treat new/insufficient data as healthy, unhealthy, or last-known depending on configuration.
   - `fail-open`, `insufficient-data`, `using-last-known`, `new-target-assumed-healthy`, `new-target-assumed-unhealthy`, and `inconclusive` are safer labels than pretending the current state is ordinary success.
   - These labels are especially important for operator-visible SlopOS shells because they explain why traffic moved or did not move when probe evidence looked contradictory.

10. **Rollback selection, rollback start, and rollback completion are different verdicts**
    - A control plane may select a previous revision, begin rollback traffic movement, stop launching new tasks, or stall because there is no completed revision to return to.
    - Steward should not collapse those into `rolled back`.
    - Useful states include `rollback-eligible`, `rollback-selected`, `rollback-started`, `rollback-complete`, `rollback-unavailable`, `rollback-stalled`, and `rollback-unknown`.

11. **Manual promotion and hold states must remain visible**
    - Canary, blue/green, pause, manual promotion, and operator-verified gates are valuable precisely because they slow a controller down.
    - Steward should preserve `manual-promotion-required`, `operator-held`, `paused`, `canary-observing`, and `promotion-approved` without turning the lifecycle fabric into a canary system.
    - A generic `retry` button is weaker than a precise `promote canary`, `resume rollout`, `show gate owner`, or `show stalled basis` affordance.

12. **Verdict freshness and generation coverage should decay**
    - A verdict over desired generation 12 may be stale once desired generation 13 is accepted.
    - A routing decision can lag a traffic update; a rollout condition can persist until a new rollout starts; a health aggregate can be cached or thresholded.
    - Useful evidence includes `observed_generation`, `basis_as_of`, `decision_as_of`, `expires_or_recheck_by`, `last_transition`, `threshold_state`, and `staleness_reason`.
    - If Steward cannot prove freshness, it should say `last-known verdict` or `verdict freshness unknown`.

13. **Phase 1 shape is a verdict receipt, not a controller API**
    - A tentative `activation_control_verdict` witness can stay tiny: `component_id`, optional `incarnation_id`, optional `revision_ref`, optional `endpoint_or_route_ref`, `verdict_issuer`, optional `control_loop_ref`, `subject_kind`, `scope`, `verdict_state`, optional `basis_hint`, optional `effect_class`, optional `observed_generation`, optional `basis_refs`, optional `decision_as_of`, optional `expires_or_recheck_by`, optional `threshold_state`, optional `manual_action_hint`, optional `staleness_reason`, and optional `unknown_reason`.
    - Field names remain provisional until real Steward components show which verdict facts must cross membranes.

## Executable packet settlement
`ST-CTRLVERDICT v0` is the first executable settlement for this posture. It deliberately proves less than the full posture: closed decode, canonical digest, required non-implications, scoped issuer/subject/effect class, reasons for unknown/inconclusive verdicts, manual-action hints for stalled/failed/action-required verdicts, route-authority/remediation-success rejection, and flow-level rejection of eligible traffic gates based on degraded material without downgrade.

The deterministic corpus in `../40-verification/currentness-control-corpus-v0.md` is the current promotion gate: new control-verdict language should preserve those cases or add a new accept/reject case before becoming stronger posture.

## Phase-1 non-goals
- a universal rollout controller, canary controller, deployment planner, load balancer, service mesh, DNS failover system, remediation engine, autoscaler, incident manager, or SLO/SLA system;
- requiring every adapter to expose its thresholds, formulas, decision tree, or hidden controller internals;
- treating probe success as rollout success, traffic eligibility, rollback safety, or incident closure;
- treating a stalled or failed verdict as automatic restart, rollback, route withdrawal, quarantine, or repair authority;
- flattening report-only status, local proxy ejection, DNS aggregation, traffic split, serverless rollout, and deployment-circuit-breaker action into one status bit.

## Adjacent docs
- `activation-probe-vantage-posture-v0.md`
- `readiness-posture-v0.md`
- `readiness-generation-posture-v0.md`
- `stability-window-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `presence-advertisement-posture-v0.md`
- `activation-endpoint-witness-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `hold-state-posture-v0.md`
- `backpressure-witness-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-DEPLOYMENT
- REF-K8S-POD-CONDITIONS
- REF-NOMAD-UPDATE
- REF-AWS-ECS-DEPLOYMENT-CIRCUIT-BREAKER
- REF-ENVOY-OUTLIER-DETECTION
- REF-CLOUD-RUN-TRAFFIC-MIGRATION
- REF-ROUTE53-HEALTH-DETERMINATION
