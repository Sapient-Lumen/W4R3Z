# Activity-bracket witness schema v0

Purpose: define the closed human profile for `ST-ACTBRACKET v0`, an exact runtime-cycle-scoped activity bracket.

An activity bracket says that a concrete runtime cycle has, had, or ambiguously had one attributable activity scope in flight. It is useful for quiesce, stop deferral, idle-stop, and operator explanation. It is deliberately weaker than demand acceptance, custody, drain completion, work completion, readiness, serving, or external effect truth.

## Required fields
- `schema`: `ST-ACTBRACKET v0`.
- `witness_id`, `cid`, `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.
- `activity_bracket_id`: stable bracket id with `bracket_` prefix.
- `runtime_cycle_ref`: exact runtime-cycle witness or receipt ref.
- `activity_kind`: `request`, `message`, `stream`, `timer`, `operator_action`, `background`, `maintenance`, or `unknown`.
- `bracket_state`: `open`, `closing`, `closed`, `abandoned`, `expired`, or `unknown`.
- `began_at_ms`, `ended_at_ms`, and `stale_after_ms`.
- `in_flight_count`: bounded local count for this bracket.
- `stop_deferral_hint`: whether this bracket may support bounded stop deferral.
- `reason`: short redacted explanation.

## Required non-implications
`not-authority`, `not-authorization`, `not-demand`, `not-custody`, `not-work-completion`, `not-effect-success`, `not-readiness`, `not-serving`, `not-drain`, `not-quiesce`, `not-keepalive-lease`, and `not-lossless`.

## Rules
Open and closing brackets have no end time and must count at least one in-flight activity. Closed, abandoned, and expired brackets have zero in-flight count and cannot carry a stop-deferral hint. Unknown brackets cannot create stop deferral.

## Non-goals
This packet is not a workflow lease, distributed transaction, request-completion receipt, drain receipt, or keepalive grant.
