# Attention-watch posture v0

Purpose: define a **tiny exact attention-watch seam** so a user can arm **one exact frame / receipt / run / landmark watch** and later receive reveal, badge, bell, or toast behavior when that exact thing crosses a watched boundary, without turning Steward into a generic subscription bus, background workflow engine, or ambient reminder plane.

## Posture
1. **A watch binds to one exact anchor and one exact watched condition**
   - Good targets include one command frame, one transcript landmark, one receipt anchor, one detour outcome slot, or one component/run observation surface.
   - Good watched conditions include `frame finished`, `receipt settled`, `status barrier crossed`, `pending request responded`, or another narrow reviewed boundary.
   - Steward should resist pane-wide folklore like “tell me whenever this terminal probably seems done”.
2. **Armed, matched, delivered, revealed, canceled, expired, and stale are different truths**
   - A watch may be armed before the condition matches, matched before the chosen delivery path succeeds, and delivered before the user actually reveals the anchor.
   - Steward should preserve that separation instead of flattening everything into one flattering `alerted` bit.
3. **A watch is user-armed attention state, not approval or automation authority**
   - Watching a frame or run may justify a later badge, toast, bell, or reveal affordance.
   - It must not silently approve lifecycle mutations, rerun work, or widen shell powers merely because the user asked to be notified.
4. **Reveal should outrank arbitrary follow-on action**
   - The healthiest default after a watch triggers is to reveal or focus the exact frame, receipt, or card that crossed the watched boundary.
   - Steward should not let a watch become a hidden macro engine or action-at-a-distance scheduler.
5. **Thresholds and delivery preferences should stay explicit and local**
   - Minimum duration, focused-versus-unfocused delivery, and preferred delivery class (`chip`, `badge`, `bell`, `toast`) can be useful.
   - Those settings should remain attached to the exact watch or local shell policy instead of growing into a host-wide notification empire.
6. **Continuity loss should degrade honestly**
   - Hop loss, prompt expiry, frame replacement, cursor loss, or watch-path degradation may leave the anchor known-but-no-longer-live.
   - Steward should be allowed to say `watch armed; continuity lost`, `watch matched; reveal target stale`, or `watch expired before match` instead of guessing from pane position or clock time.
7. **Watches should appear as small exact shell objects when live**
   - A live watch should be inspectable as one small card/chip with target, watched condition, current state, and one cancel/clear path.
   - That keeps “watch this command” from dissolving into invisible terminal preference state.
8. **Exact shell and lifecycle objects should compose with watches**
   - Prompt leases, current-command objects, transcript landmarks, pending requests, detour outcomes, status barriers, and runtime-cycle witnesses are all healthier watch targets than guessed viewport neighborhoods.
   - Steward should prefer those exact objects before any transcript-parse fallback.
9. **Parse-lens fallback may assist, but must stay weaker**
   - When exact shell objects are unavailable, a weaker parse lens may still let the UI offer `watch this candidate command block`.
   - That offer should stay provenance-labeled and should not inherit the stronger affordances of exact frame- or receipt-backed watches.
10. **Keep the phase-1 contract tiny**
   - Phase 1 likely needs only: exact watched anchor, watched boundary kind, optional minimum duration, optional delivery preference, compact state, and one cancel/clear path.
   - Avoid freezing a universal watch DSL, scheduler, inbox, or cross-device reminder family before repeated operating pressure exists.

## Phase-1 non-goals
- a generic durable reminder or inbox system;
- a universal snapshot-plus-stream watch protocol for arbitrary objects;
- letting watch triggers execute commands or approve lifecycle mutations by default;
- promising identical toast/bell/badge capabilities on every host;
- treating pane identity or transcript position as sufficient public watch target semantics.

## Adjacent docs
- `attention-hint-posture-v0.md`
- `notification-surface-posture-v0.md`
- `transcript-landmark-posture-v0.md`
- `command-frame-posture-v0.md`
- `target-anchor-posture-v0.md`
- `status-barrier-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `pending-request-posture-v0.md`
- `detour-outcome-posture-v0.md`
- `return-ticket-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `parse-lens-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-MENU-ITEMS
- REF-GHOSTTY-RELEASE-130
- REF-WEZTERM-NOTIFICATION-HANDLING
- REF-VSCODE-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
