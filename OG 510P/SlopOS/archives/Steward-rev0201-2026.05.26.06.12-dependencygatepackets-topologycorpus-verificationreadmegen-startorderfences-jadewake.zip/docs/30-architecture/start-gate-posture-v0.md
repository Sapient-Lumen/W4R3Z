# Start-gate posture v0

Purpose: define a **tiny start-gate seam** so a requested activation can be **cleanly skipped, blocked, or shielded** without laundering that outcome into fake crash/failure truth.

This seam is intentionally small. It does **not** design a giant dependency planner, universal condition language, or startup workflow engine. It only says Steward should be able to answer a narrower question honestly: **what happened when a start was attempted, and was that a clean gate result or an actual start failure?**

## Posture
1. **`not started` is not always `failed`**
   - A start request may be skipped because a pre-start condition was unmet, blocked by a reviewed gate, or deferred behind a startup shield.
   - Steward should not flatten those outcomes into one vague `failed to start` story.

2. **Clean skip, hard denial, and actual startup failure are different truths**
   - `skipped`, `blocked`, `denied`, `assert-failed`, `precondition-failed`, and `spawn failed` answer materially different questions.
   - If an adapter can only prove `not admitted`, Steward may say that, but it should not silently promote that into crash or repair-required folklore.

3. **Startup shielding is distinct from later liveness judgment**
   - Some runtimes intentionally shield slow or first-run initialization from later liveness/readiness expectations until one startup boundary has been crossed.
   - Steward should preserve that honesty: `startup shielded` is different from both `ready` and `dead`.

4. **Gate truth belongs near activation truth, not hidden in logs**
   - If a component did not start because a condition, assertion, or local admission rule stopped it, shells and cards should be able to explain that directly.
   - Operators should not have to scrape host logs to distinguish `clean skip` from `failed start`.

5. **Start gates stay separate from durable enablement and temporary holds**
   - `manual only`, `disabled`, runtime masks, drains, and other durable/temporary policy postures remain separate seams.
   - A start-gate witness explains one attempted activation outcome; it does not replace baseline policy or hold-state truth.

6. **Gate results should compose with repair gates without collapsing into them**
   - Repeated startup failures may still consume restart budget or lead to repair-required state.
   - Repeated clean skips because a condition is unmet are a different pattern and should remain explainable as such.

7. **Phase 1 should keep the vocabulary tiny**
   - A healthy early shape is no more than an optional compact result such as `skipped`, `blocked`, `shielded`, `failed`, or `unknown`, plus optional gate class / reason when the adapter can really prove it.
   - Rich dependency solvers, giant policy graphs, and portable condition DSLs remain intentionally undecided.

## Explicit non-goals
- a universal dependency or boot-order planner;
- standardizing every possible pre-start condition language;
- treating all start prevention as failure;
- forcing every adapter to distinguish clean skip from hard denial equally well;
- turning startup shields into a giant rollout or controller-runtime family.

## Adjacent docs
- `activation-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `enablement-intent-posture-v0.md`
- `activation-overlay-posture-v0.md`
- `hold-state-posture-v0.md`
- `dynamic-condition-posture-v0.md`
- `readiness-posture-v0.md`
- `liveness-evidence-posture-v0.md`
- `restart-budget-posture-v0.md`
- `repair-gate-posture-v0.md`
- `state-explainer-posture-v0.md`

## References
- REF-SYSTEMD-UNIT
- REF-SYSTEMD-SERVICE
- REF-SYSTEMD-EXEC
- REF-K8S-PROBES
