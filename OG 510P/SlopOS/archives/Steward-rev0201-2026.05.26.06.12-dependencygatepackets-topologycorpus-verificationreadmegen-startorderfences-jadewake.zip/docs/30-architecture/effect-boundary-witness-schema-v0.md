# Effect-boundary witness schema v0

## Purpose
`ST-EFFECT v0` is the closed packet profile for a named side-effect boundary. It lets Steward say whether a local commit, outbox record, external submit, external acknowledgement, external confirmation, compensation, irreversible boundary, or ambiguity was observed without claiming exactly-once execution.

The profile is intentionally smaller than a transaction coordinator, global idempotency ledger, saga engine, outbox system, broker, or exactly-once plane.

## Required fields
- `schema`: constant `ST-EFFECT v0`.
- `effect_id`: stable packet-local effect identifier.
- `cid`: component identity.
- `issuer`: closed issuer object.
- `boundary_kind`: `none`, `local_commit`, `outbox_recorded`, `external_submitted`, `external_acknowledged`, `external_confirmed`, `compensated`, `irreversible`, or `unknown`.
- `effect_state`: `not_attempted`, `pending`, `submitted`, `confirmed`, `failed`, `compensated`, `ambiguous`, or `unknown`.
- `canonical_intent_digest`: digest of the canonical effect intent.
- `observed_at_ms`: monotonic packet-time observation.
- `basis_refs`: bounded supporting observations.
- `retention`: `none`, `bounded`, `expired`, or `unknown`.
- `duplicate_outcome`: `none`, `suppressed`, `same_intent_replay`, `same_key_mismatch`, `duplicate_possible`, or `unknown`.
- `non_implications`: must include at least `not-readiness`, `not-serving`, `not-work-completion`, `not-exactly-once`, and `not-rollbackable`.

## Optional fields
`effect_key`, `work_ref`, `disposition_ref`, `external_ref`, `outbox_ref`, `commit_ref`, `compensation_ref`, `retention_expires_at_ms`, and `ambiguity_reason`.

## Cross-field rules
- Bounded retention requires `retention_expires_at_ms`, and it must not precede `observed_at_ms`.
- `suppressed`, `same_intent_replay`, and `same_key_mismatch` require `effect_key`.
- `external_acknowledged`, `external_confirmed`, and `irreversible` require `external_ref`.
- `ambiguous` and `unknown` effects require `ambiguity_reason`.
- Exactly-once, rollbackability, current authority, raw bearer material, and host process identifiers are forbidden anywhere in the packet.

## Refusals
An effect-boundary witness never proves work completion, readiness, serving, exactly-once execution, rollbackability, or current authority.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/demand-custody-effect-corpus-v0.jsonl`; the checker is `../../tools/steward_work_effect_harness.py`.
