# Resume-reconciliation witness schema v0

## Purpose
`ST-RESUME v0` is the first closed packet for one Steward resume or reconciliation witness. It names restart replay, manager recovery, hot-restart handoff, snapshot restore, live-channel resume, demand redelivery, or custody reconciliation without pretending continuity is lossless, exactly once, the same runtime cycle, or proof of downstream work/effect fate.

The central rule: **resume means an explicit reconciliation attempt with a named safety basis and gap state; it is not same-cycle identity, readiness, serving, losslessness, custody, work completion, or effect success.**

## Machine profile
- Machine profile: `../../schemas/st-resume-v0.schema.json`
- Checker: `../../tools/steward_lineage_resume_harness.py`
- Corpus: `../40-verification/corpora/lineage-resume-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-RESUME v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming Steward, runtime, adapter, checkpoint manager, or observer |
| `resume_id` | scoped resume witness id matching `resm_[a-z0-9]{16}` |
| `resume_kind` | `manager_recovery`, `restart_replay`, `hot_restart_handoff`, `snapshot_restore`, `live_channel_resume`, `demand_redelivery`, `custody_reconcile`, or `unknown` |
| `resume_state` | `proposed`, `replayed`, `reconciled`, `degraded_unknown`, `blocked_stale_cycle`, `rejected_widening`, `handoff_pending`, `gap_ambiguous`, `abandoned`, or `unknown` |
| `continuity_class` | `none`, `activation_replay`, `escrowed_state`, `snapshot_restore`, `channel_cursor`, `custody_reconcile`, `effect_key_reuse`, or `unknown` |
| `safety_basis` | `digest_match`, `activation_digest_match`, `explicit_handoff`, `cursor_resume_with_gap`, `operator_review`, `no_safe_resume`, or `unknown` |
| `gap_state` | `none`, `possible_gap`, `known_gap`, `duplicate_possible`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `basis_refs` | bounded evidence refs supporting the witness |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `source_ref`, `previous_incarnation_id`, `target_incarnation_id`, `previous_runtime_cycle`, `target_runtime_cycle`, `activation_digest_ref`, `snapshot_ref`, `handoff_ref`, `cursor_ref`, `effect_key_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Required non-implications
A valid packet must include:

- `not-same-runtime-cycle`
- `not-readiness`
- `not-serving`
- `not-lossless`
- `not-exactly-once`
- `not-effect-success`
- `not-custody`
- `not-work-completion`

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Raw cursor material, bearer values, path/handle fields, host ids, tokens, and secrets reject.
- `replayed`, `reconciled`, `handoff_pending`, and `gap_ambiguous` states require `source_ref` and a target incarnation or runtime cycle.
- `activation_replay` requires `activation_digest_ref` and a digest-matching safety basis.
- `snapshot_restore` requires `snapshot_ref` and `target_incarnation_id`.
- `gap_ambiguous` requires a non-`none` `gap_state` and `unknown_reason`.
- `blocked_stale_cycle`, `rejected_widening`, `degraded_unknown`, and `unknown` require `unknown_reason`.
- Resume continuity cannot claim `previous_runtime_cycle == target_runtime_cycle` except when continuity is explicitly `none`.

## Rejected surfaces
The corpus rejects:

- resume packets claiming the same runtime cycle after turnover;
- gap ambiguity without a reason;
- lossless or exactly-once claims;
- resume as readiness, serving, custody, work completion, or effect success;
- manager recovery that hides unknown present-tense state.

## Non-goals
- no durable workflow engine, checkpoint/restore protocol, replay engine, queue redelivery protocol, stream cursor authority, or exactly-once plane;
- no promise that activation replay, cursor resume, or snapshot restore is lossless;
- no settlement of predecessor effects merely because a successor resumed.

## Adjacent docs
- `manager-recovery-reconciliation-posture-v0.md`
- `bootstrap-reconciliation-posture-v0.md`
- `activation-retry-attempt-posture-v0.md`
- `activation-live-channel-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `runtime-cycle-witness-schema-v0.md`
- `incarnation-lineage-witness-schema-v0.md`
- `canonical-json-profile-v0.md`
