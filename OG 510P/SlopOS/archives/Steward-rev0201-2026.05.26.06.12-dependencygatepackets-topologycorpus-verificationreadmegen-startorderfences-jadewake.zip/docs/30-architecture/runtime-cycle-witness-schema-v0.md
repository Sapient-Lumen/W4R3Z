# Runtime-cycle witness schema v0

## Purpose
`ST-RTCYCLE v0` is the first closed packet for one concrete Steward runtime-cycle witness. It names a start, active run, stop, terminal observation, loss, or unknown runtime observation without treating a process handle, pod name, allocation id, or stable component name as portable lifecycle truth.

The central rule: **a runtime cycle proves correlation and stale-target fencing, not readiness, serving, incarnation currentness, residency, custody, work completion, or effect success.**

## Machine profile
- Machine profile: `../../schemas/st-rtcycle-v0.schema.json`
- Checker: `../../tools/steward_lineage_resume_harness.py`
- Corpus: `../40-verification/corpora/lineage-resume-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-RTCYCLE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the runtime, runner, adapter, or Steward observer |
| `cycle_id` | opaque runtime-cycle witness matching `cycle-*` |
| `cycle_state` | `starting`, `active`, `stopping`, `terminated`, `lost`, or `unknown` |
| `cycle_role` | `primary`, `helper`, `predecessor`, `successor`, `sidecar`, `observer`, or `unknown` |
| `manifest_digest` | reviewed component manifest digest bound to the cycle |
| `start_reason` | `start_request`, `restart_policy`, `recovery_reconcile`, `hot_restart_successor`, `resume_restore`, `demand_activation`, `operator_repair`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `host_evidence_strength` | strength of local evidence without exporting the handle itself |
| `basis_refs` | bounded evidence refs supporting the witness |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `activation_digest`, `incarnation_id`, `end_cause`, `fence_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Required non-implications
A valid packet must include:

- `not-readiness`
- `not-serving`
- `not-incarnation-currentness`
- `not-residency`
- `not-custody`
- `not-work-completion`
- `not-effect-success`
- `not-host-handle-authority`

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- PID, cgroup, systemd unit, pod, container, node, allocation, raw handle, path, token, and secret fields reject.
- `terminated` and `lost` cycles require `end_cause`.
- `unknown` cycles require `unknown_reason`.
- `expires_or_recheck_by_ms` cannot precede `observed_at_ms`.
- A flow must reject reusing a terminated or lost `cycle_id` as a later active run.

## Rejected surfaces
The corpus rejects:

- raw PID-bearing runtime-cycle packets;
- terminal cycle observations without end cause;
- runtime-cycle packets claiming current incarnation;
- later active reuse of a terminated cycle id;
- accepted operations targeting a stale runtime cycle.

## Non-goals
- no portable PID, process-tree, cgroup, job object, pod, container, node, or allocation API;
- no promise of global ordering across components;
- no derivation from cycle equality to current incarnation, residency, readiness, serving, custody, work disposition, or effect success.

## Adjacent docs
- `runtime-cycle-witness-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `incarnation-lineage-witness-schema-v0.md`
- `resume-reconciliation-witness-schema-v0.md`
- `control-operation-request-schema-v0.md`
- `canonical-json-profile-v0.md`
