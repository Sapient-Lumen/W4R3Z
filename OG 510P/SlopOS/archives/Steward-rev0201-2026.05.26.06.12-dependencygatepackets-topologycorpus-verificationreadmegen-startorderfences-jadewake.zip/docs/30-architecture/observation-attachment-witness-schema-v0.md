# Observation attachment witness schema v0

## Packet
`ST-OBSATTACH v0` records Steward's local decision to attach, refuse, quarantine, or recheck a local observation after appraisal.

## Required meaning
The packet says how a local observation is attached to a non-authoritative surface: explanation, operator review, recovery hint, audit, history, or recheck request. When attached as weak basis, it must still name at least one non-observation native witness requirement.

## Required non-implications
Every packet must explicitly refuse:
- `not-execution`
- `not-authority`
- `not-current-state`
- `not-freshness`
- `not-readiness`
- `not-serving`
- `not-effect-success`

## Canonicalization
The machine profile is [`../../schemas/st-obsattach-v0.schema.json`](../../schemas/st-obsattach-v0.schema.json). Weak attachments must remain weak, recheck attachments require a concrete recheck time, and local observations cannot satisfy their own native-witness requirement.

## Refusals
Attachment is not promotion to native truth. A host manager active state, pod running phase, adapter green result, cursor advance, shell sighting, or file watcher event may explain why Steward will recheck; it must not become readiness, serving, freshness, authority, operation execution, or effect success.
