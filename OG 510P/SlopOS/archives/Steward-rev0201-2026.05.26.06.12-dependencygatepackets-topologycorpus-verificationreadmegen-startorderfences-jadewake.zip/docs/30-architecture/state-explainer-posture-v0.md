# State-explainer posture v0

Purpose: define a **tiny exact state-explainer seam** so Steward can answer questions like `why is this waiting?`, `why is this blocked?`, or `why did this repair card appear?` over one stronger anchor without turning shell UX into a giant diagnosis family, log scraper, or ambient workflow engine.

## Posture
1. **An explainer binds to one stronger owning anchor**
   - The healthiest owner is one exact component target, runtime-cycle witness, command verdict, command frame, pending request, repair gate, or other reviewed shell/lifecycle anchor.
   - Steward should resist folklore like “some nearby red text probably explains the current problem.”
2. **Explainer, status, and repair are different truths**
   - Status says *what is true now* (`waiting`, `degraded`, `cooling-down`, `repair-required`, `provider-lost`, and so on).
   - A state explainer answers *why that truth currently holds* in one compact human-facing way.
   - A repair card proposes one likely next fix.
   - Steward should preserve those distinctions instead of forcing every shell affordance to choose between raw status bits and a workflow engine.
3. **Prefer provider-owned facts over log archaeology**
   - Exact status strings, structured state trees, request/response state, exact receipt facts, and exact shell metadata should outrank transcript scraping or regex heuristics.
   - Logs and parse lenses can still help, but they must stay visibly weaker.
4. **Reason, supporting facts, and next legal move stay separate**
   - `waiting on peer`, `retry after 12s`, `approval missing`, `policy floor`, `prompt lease expired`, and `rebind required` are different truths.
   - A good explainer may link to supporting facts or one safe follow-on action, but it must not collapse cause, countdown, and mutation authority into one flattering sentence.
5. **The public explainer shape should stay small**
   - Phase 1 likely needs only: owning anchor, compact explainer kind, short human-readable message, optional supporting fact refs, freshness/provenance, and optional next-safe-view target.
   - Steward should avoid freezing a giant root-cause ontology, diagnostic query language, or durable incident object family too early.
6. **Explainers are observational and reviewable, not silent execution**
   - Revealing an explainer may open exact receipts, show a wait reason, or reveal which capability/freshness/policy fact is missing.
   - It must not silently clear a gate, rerun a command, or widen authority merely because the explanation was exact.
7. **Shell/terminal explainers should ride exact semantic anchors when possible**
   - Exact frame-local chips, failure cards, pending-request cards, status rails, or component-ground cards are healthy places for explainers.
   - Steward should prefer one explicit explainer card or hover over the exact anchor instead of pane-wide magic or scrollback folklore.
8. **Explainers should degrade honestly when footing is weak**
   - Exact provider-owned state, exact shell markers, and exact receipts outrank parse-lens candidates or guessed transcript spans.
   - Steward should be allowed to say `exact wait reason`, `candidate explanation`, `state changed since this explanation`, or `explanation stale` instead of flattering weaker footing.
9. **One tiny explainer seam beats a diagnosis empire**
   - Wait explainers, disabled-with-reason hovers, repair why-cards, and shell integration detail cards all want the same anti-folklore discipline.
   - Steward should keep the seam smaller than a portable doctor command, root-cause graph, or workflow/ticket family.

## Phase-1 non-goals
- a universal diagnosis ontology for every runtime, toolchain, or shell;
- treating explainers as mutation authority or replay permission;
- forcing every explainer to include a repair or quick fix;
- pretending parse-lens explanations are as strong as provider-owned state;
- turning explainers into durable incidents, tickets, or a cross-tool observability database.

## Adjacent docs
- `surface-diagnostics-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `dynamic-condition-posture-v0.md`
- `retry-advice-posture-v0.md`
- `repair-card-posture-v0.md`
- `command-verdict-posture-v0.md`
- `pending-request-posture-v0.md`
- `status-channel-posture-v0.md`
- `status-barrier-posture-v0.md`
- `parse-lens-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SD-NOTIFY
- REF-FUCHSIA-INSPECT-TREE
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1099
- REF-WEZTERM-SEMANTIC-ZONES
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
