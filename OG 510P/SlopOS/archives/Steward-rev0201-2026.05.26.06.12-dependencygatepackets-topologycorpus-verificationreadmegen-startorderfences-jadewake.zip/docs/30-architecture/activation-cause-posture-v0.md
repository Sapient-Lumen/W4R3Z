# Activation-cause posture v0

Purpose: define the smallest useful **start-of-cycle activation-cause vocabulary** so Steward can explain why one concrete runtime cycle started without cloning dependency planners, desktop focus policy, or ambient init folklore.

## Posture
1. **Activation cause belongs to the concrete runtime cycle**
   - “Why did this start?” attaches most naturally to one concrete runtime cycle, not only to the long-lived component identity.
   - Runtime-cycle witness plus activation-cause is a promising minimal pair for receipts, repair explainers, and shell-visible lifecycle cards.
2. **Keep the portable cause vocabulary small**
   - A useful phase-1 portable set likely looks close to:
     - manual / reviewed start,
     - first-request, socket-demand, or queue-nonempty activation,
     - typed trigger wake (for example device or environment availability) when the host can prove it cleanly,
     - restart / repair relaunch,
     - restore / replay-gated relaunch,
     - scheduled or policy-triggered wake,
     - unknown / implementation-lost detail.
   - Implementations may preserve richer local detail underneath.
3. **Prefer durable typed triggers over race-prone path watches**
   - Queue depth, socket demand, reviewed schedules, or typed environment/device triggers are healthier start causes than raw filesystem-change watches.
   - If an implementation only has weaker watch-path evidence, Steward should preserve that as downgraded/local detail instead of flattering it into the portable activation truth.
4. **Cause and readiness stay separate**
   - A request may wake a component before it is ready.
   - A repair relaunch may happen long before the component reaches serve-ready again.
   - Steward should not collapse “started because of X” into “healthy now”.
4a. **A trigger edge may need bootstrap reconciliation before it becomes present-tense truth**
   - A typed trigger wake is a useful start cause, but the triggering edge may already have passed by the time the component finishes startup and registers its own observers.
   - Steward should therefore allow one trigger-caused cycle to reconcile current condition separately from activation cause, and it should tolerate duplicate evidence from a bootstrap snapshot plus later callbacks.
5. **Triggers that arrive during stop should target a fresh cycle**
   - If a typed trigger or request lands while a component is intentionally stopping or draining, Steward should prefer explicit `queued for next cycle` truth over reviving the half-dead cycle in place.
   - That keeps stop progression, request identity, and later activation cause separate and explainable.
6. **Cause and launch basis stay separate**
   - “Started because of first request” and “received these exact listeners / selectors / capsules at launch” answer different questions.
   - The first is an explanatory start reason; the second is reviewed launch-boundary evidence.
7. **Cause and restart policy stay separate**
   - One cycle may end with crash and the next may start because policy retried it.
   - Another may end cleanly and later start because a new incoming request arrived.
   - Steward should preserve those as distinct truths rather than flattening them into one manager story.
8. **Attention hints should not impersonate start cause**
   - Desktop startup ids, activation tokens, focus hints, or shell foreground facts may accompany a start.
   - They should not become the portable answer to why the runtime cycle began.
9. **Receipts and shell chrome should show cause, not synthesize it**
   - Command frames, lifecycle cards, and explainers may display compact start-cause chips such as `manual`, `first request`, `repair relaunch`, `restore replay`, or `scheduled`.
   - Those should come from explicit Steward state/receipts when available, not from log scraping or guesswork.
10. **Unknown is healthy when fidelity is missing**
   - Some runtimes can explain exact request-triggered starts or manager retries.
   - Others may only know that the component started after being previously stopped.
   - Steward should preserve honesty about that precision gap.
11. **One tiny explanatory seam beats a giant causal graph**
   - Phase 1 mainly needs a compact answer to “why did this concrete cycle begin?”
   - It does not need a universal dependency-causality algebra, a distributed event graph, or a full initiator chain.
12. **Activation cause should compose with repair and replay**
   - Repair gates, replay gates, and workspace restore flows all benefit when they can tell whether a cycle is a fresh reviewed start, an automatic retry, or a remembered/reviewed replay.
   - Steward should keep that explanatory layer shared instead of letting each surface invent its own vague `started` badge.

## Phase-1 non-goals
- a universal cross-platform event-causality graph for every lifecycle transition;
- proving that every start can be attributed to one complete actor chain with perfect fidelity;
- collapsing start cause, launch basis, readiness, and restart policy into one status field;
- turning activation-cause into permission to stop, replay, or foreground a component;
- freezing a broad dependency-order or scheduler vocabulary before repeated pressure demands it.

## Adjacent docs
- `activation-posture-v0.md`
- `request-activation-posture-v0.md`
- `bootstrap-reconciliation-posture-v0.md`
- `termination-cause-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `repair-gate-posture-v0.md`
- `replay-gate-posture-v0.md`
- `workspace-snapshot-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-LAUNCHD-JOBS
- REF-SYSTEMD-SD-LISTEN-FDS
- REF-DBUS-SPECIFICATION
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
- REF-FUCHSIA-SYS2
- REF-FUCHSIA-RUNNER
- REF-WINDOWS-SERVICE-TRIGGER-EVENTS
- REF-WINDOWS-SERVICE-DEVICE-INTERACTION
- REF-LAUNCHD-SOCKETS
- REF-ANDROID-INIT-README
