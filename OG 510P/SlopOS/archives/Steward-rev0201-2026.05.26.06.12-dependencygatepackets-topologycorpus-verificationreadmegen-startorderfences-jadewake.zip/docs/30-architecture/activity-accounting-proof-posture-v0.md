# Activity-accounting proof posture v0

Purpose: settle the executable boundary for activity brackets, idle hints, bounded stop deferral, and descriptive accounting.

## Settlement in rev0200
`ST-ACTBRACKET v0`, `ST-IDLEHINT v0`, `ST-STOPDEFER v0`, and `ST-ACTACCT v0` are now closed machine profiles with a deterministic corpus under `docs/40-verification/corpora/activity-accounting-corpus-v0.jsonl`.

The proof slice rejects the following collapses:

1. activity bracket as demand, custody, drain, readiness, serving, keepalive lease, work completion, or effect success;
2. idle hint as stopped state, quiesce, drain completion, stop authority, readiness, serving, or currentness;
3. stop deferral as approval, clean exit, stopped state, drain completion, or immortal keepalive;
4. activity accounting as billing, quota debit, pressure, headroom, admission, demand, work completion, or external effect truth.

## Operating rule
Activity is useful evidence for local lifecycle policy only when it is exact, runtime-cycle scoped, freshness bounded, and explicit about what it does not prove. If a runtime cannot provide balanced bracket evidence, Steward may use a weaker idle hint; it must not invent precise in-flight work from CPU quiet, log silence, or shell folklore.

## Adjacent docs
- `activity-accounting-posture-v0.md`
- `activity-bracket-posture-v0.md`
- `quiesce-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `shutdown-settlement-corpus-v0.md`
- `pressure-admission-proof-posture-v0.md`
