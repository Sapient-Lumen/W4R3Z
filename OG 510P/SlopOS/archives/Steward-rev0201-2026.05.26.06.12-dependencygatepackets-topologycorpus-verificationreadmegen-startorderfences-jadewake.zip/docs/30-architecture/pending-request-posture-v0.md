# Pending-request posture v0

Purpose: define a **tiny provider-owned pending-request seam** so chooser/open/reveal/approval detours can remain attributable, cancelable, and shell-visible while the interaction is still in flight, without cloning a generic callback broker, portal object universe, or resumable workflow family.

## Posture
1. **A pending request is live interaction state, not ambient UI mood**
   - When Steward launches a chooser, portal-mediated open, approval sheet, or similar detour that may outlive one immediate reply, it should be allowed to name one exact pending request object.
   - That object exists so the shell can point to the in-flight interaction directly instead of hand-waving with “some dialog is probably open somewhere”.
2. **Provider-owned request state stays distinct from requester-chosen intent**
   - A command frame, proposal card, or chooser action may carry a requester-chosen target, selector, or request key.
   - The pending request itself should still be a provider-owned live object for the duration of the interaction, not a caller-minted callback mailbox or durable rendezvous identity.
3. **Pending request, live grant/session, and return ticket are different truths**
   - A pending request is one still-in-flight interaction.
   - A grant/session handle names a live power or longer-lived mediated session.
   - A return ticket names one exact way a completed detour may come back to the shell surface.
   - Steward should keep those truths separate instead of flattening them into one vague “portal thing”.
4. **One request should have explicit visible state**
   - Useful states include `pending`, `awaiting-user`, `responded`, `canceled`, `denied`, `expired`, `provider-lost`, and `rebind-required` where the footing can prove them.
   - `pending` is not `active grant`, and `responded` is not the same as “result already rebound to the original pane”.
5. **Cancel, close, or abandon should be first-class**
   - If the interaction can be canceled or closed, Steward should keep one exact path to do that.
   - Letting dead request chrome linger until timeout when the shell already knows the detour is no longer wanted is worse hygiene than an explicit closeable object.
6. **Results should arrive as typed outcomes, not by reinterpreting the handle itself**
   - Completion may yield a typed target anchor, selector, receipt, denial, or result summary.
   - The pending-request object itself should stay lifecycle/control state rather than becoming a bearer authority or a durable reopen token.
7. **Shell UX may surface small request cards or chips**
   - The custom shell+terminal should be able to show one compact pending-request card with owner frame, requested action, freshness/expiry, and eventual outcome.
   - That card is observational chrome plus an exact cancel/reveal target, not a hidden authority lane.
8. **Loss and expiry should degrade honestly**
   - If the originating pane disappears, the terminal reconnects, the provider restarts, or the request expires, Steward should degrade to explicit `result available`, `stale`, `provider lost`, or `rebind required` truth.
   - Silent retargeting to whichever pane is convenient would recreate the ambient folklore this seam exists to resist.
9. **List/watch universes stay out of phase 1**
   - Phase 1 may need one exact pending request plus its eventual outcome and cancel path.
   - It does not need a generic inventory, resume-later broker, cross-provider callback plane, or historical request database.
10. **Keep the phase-1 contract tiny and shell-friendly**
    - The point is to make mediated interactions legible in the shell and attributable in receipts.
    - Avoid freezing a whole portal/session algebra before repeated pressure proves Steward genuinely needs it.

## Phase-1 non-goals
- a generic callback URL, loopback redirect, or app-registered mailbox contract;
- a universal request list/watch/query API across providers or principals;
- treating pending-request identifiers as durable bearer authority or reopen selectors;
- silently widening a pending request into a long-lived session or persistent grant;
- a generic workflow-resume or background wakeup family.

## Adjacent docs
- `chooser-surface-posture-v0.md`
- `grant-handle-posture-v0.md`
- `request-context-posture-v0.md`
- `detour-outcome-posture-v0.md`
- `return-ticket-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `attention-hint-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-SESSION
- REF-XDG-PORTAL-OPENURI
