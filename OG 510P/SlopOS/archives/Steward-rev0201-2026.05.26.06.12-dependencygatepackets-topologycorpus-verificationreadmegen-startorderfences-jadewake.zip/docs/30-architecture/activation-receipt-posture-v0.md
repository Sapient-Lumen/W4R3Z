# Activation-receipt posture v0

Purpose: define a **tiny exact-run evidence seam** for startup material that Steward delivered to a concrete runtime cycle, without freezing a giant startup protocol or turning terminal folklore into architecture.

## Posture
1. **Activation receipts are about evidence first**
   - A receipt should answer compact questions such as: what reviewed startup material was delivered, to which concrete runtime cycle, and whether Steward observed acknowledgement of that delivery.
   - Possessing a receipt is not itself authority to reopen, duplicate, or export the delivered material.
2. **Receipts stay exact-run scoped**
   - Delivery evidence belongs to one concrete runtime cycle / launch attempt, not to the component identity forever.
   - A later restart may deliver similar keys again, but that is a new receipt context rather than proof that old startup material remained live.
3. **Delivered material should be named, not reconstructed**
   - Receipts should prefer reviewed keys, labels, or semantic names for delivered listeners, service names, escrow payloads, or activation tokens.
   - Phase 1 should avoid positional fd folklore, wrapper-script side agreements, or “everyone knows slot three is the admin socket.”
4. **Acknowledgement is distinct from delivery**
   - It is useful to say both that Steward delivered startup material and that Steward later observed the concrete run acknowledge or bind that material.
   - Delivery, acknowledgement, control-ready, and serve-ready are related but intentionally different truths.
5. **Receipts should stay compact and replay-friendly**
   - Phase 1 should prefer tiny summaries that can fit in lifecycle receipts, command frames, and explain surfaces.
   - Avoid freezing a full startup transcript, descriptor inventory browser, or host-specific introspection API.
6. **Missing acknowledgement must fail honest**
   - If a runtime cannot acknowledge delivered material, the receipt should be allowed to say delivered-but-unacknowledged or unknown rather than pretending optimism is truth.
7. **Foreground/focus authority stays separate**
   - If an action later carries a desktop/window activation token or other foregrounding hint, that token should remain separate from the activation receipt's target meaning.
   - Opening the right object and requesting focus are different concerns.
8. **Receipts must not become a hidden broker**
   - Phase 1 receipts are evidence about reviewed delivery, not a mailbox, export API, or cross-component transfer surface.

## Phase-1 non-goals
- a portable giant startup negotiation protocol;
- a generic descriptor inventory/search/watch surface;
- exporting raw activation handles, escrow payload contents, or desktop activation tokens through the receipt itself;
- guaranteeing that every runtime can provide acknowledgement at the same granularity;
- collapsing delivery receipts into readiness, health, or restart policy truth.

## Adjacent docs
- `activation-posture-v0.md`
- `activation-material-freshness-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `target-anchor-posture-v0.md`
- `context-handoff-posture-v0.md`

## References
- REF-SD-LISTEN-FDS-WITH-NAMES
- REF-SD-NOTIFY
- REF-LAUNCH-ACTIVATE-SOCKET
- REF-FUCHSIA-PROCESS-LIFECYCLE
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
- REF-DESKTOP-NOTIFICATIONS-SPEC
