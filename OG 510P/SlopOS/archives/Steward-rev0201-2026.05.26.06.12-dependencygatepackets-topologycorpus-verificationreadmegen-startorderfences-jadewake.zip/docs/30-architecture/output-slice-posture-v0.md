# Output-slice posture v0

Purpose: define a **tiny exact output-slice seam** so the shell+terminal can treat “this exact command output region” as one bounded object for copy, handoff, explain, and annotation, instead of scraping whatever text happens to be visible nearby.

## Posture
1. **An output slice is one bounded region tied to one stronger anchor**
   - The healthiest backing is one explicit command frame, semantic output zone, transcript landmark, receipt span, or another reviewed anchor.
   - Steward should resist pane-wide folklore like “whatever text was on screen after that command probably belongs together”.
2. **Command frame, command line, and output slice are different truths**
   - A frame may include prompt, command text, output, and completion status.
   - An output slice is the bounded output-bearing region or selected subregion the user actually means to copy, attach, annotate, or explain.
   - Steward should preserve that distinction instead of forcing every action to choose between “whole frame” and “raw selection”.
3. **Exact output should outrank visible-text scraping**
   - When semantic shell metadata exists, `select output`, `copy output`, `attach last failure`, or `open output in editor` should bind to that exact slice.
   - Visible-text heuristics and parse-lens guesses are useful fallbacks, but they must stay visibly weaker.
4. **Output slices are observational evidence, not control authority**
   - An output slice may support copy, attach, explain, note, reveal, or chooser/open flows.
   - It must not silently become permission to rerun, stop, restart, or mutate lifecycle state merely because the slice came from an exact frame.
5. **Subselection should be allowed without losing provenance**
   - Users may want the whole output region, one exact contiguous subspan, or one reviewed selection inside that output.
   - Steward should preserve enough provenance to say whether the current slice is the full output region, a user-selected subspan, or a weaker parsed candidate.
6. **Rich rendering and raw text stay distinct**
   - Output may include hyperlinks, images, plots, ANSI styling, semantic file links, or other richer renderables.
   - Steward should be allowed to carry plain-text form, richer render form, and anchor provenance separately instead of pretending pixels, ANSI bytes, and transcript truth are identical.
7. **Slices should admit expiry and stale footing honestly**
   - Scrollback trimming, prompt/frame loss, hop degradation, parser fallback, or replacement transcript state may weaken what is still exact.
   - Steward should be allowed to say `exact output`, `exact subslice`, `parsed candidate`, `stale`, or `trimmed` instead of pretending precision survived every buffer mutation.
8. **Good shell UX should be built on slices**
   - `Select output of last command`, right-click `copy output`, command-detail cards, last-failure attach, quick fixes, and proposal/context handoff all want the same small object.
   - Steward should prefer one explicit slice seam over many ad hoc “nearby output” interpretations.
9. **Copy-safe and machine-usable forms should coexist**
   - A slice may need plain text, HTML/ANSI-preserving render, and a structured bounded descriptor.
   - This keeps shell UX and downstream tooling useful without requiring every consumer to scrape prose or terminal bytes.
10. **Keep the phase-1 contract tiny**
   - Phase 1 likely needs only: owning anchor/frame, start/end bounds or exact region id, optional subspan selection, provenance/trust, plain-text export, optional richer render export, and visible stale/trimmed truth.
   - Avoid freezing a universal transcript-region algebra, rich terminal document model, or giant evidence warehouse before repeated operating pressure exists.

## Phase-1 non-goals
- a universal rich-text or notebook document model for terminal history;
- making output slices the canonical lifecycle record instead of receipts/transcripts;
- pretending parsed candidate spans are as strong as shell-reported semantic regions;
- silently exporting whole panes or unrelated scrollback when one exact output region was asked for;
- inventing a giant annotation/sharing/workflow family before more than one tightly related seam truly exists.

## Adjacent docs
- `command-frame-posture-v0.md`
- `context-handoff-posture-v0.md`
- `target-anchor-posture-v0.md`
- `transcript-landmark-posture-v0.md`
- `clipboard-surface-posture-v0.md`
- `media-surface-posture-v0.md`
- `assist-surface-posture-v0.md`
- `parse-lens-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1106
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-ADVANCED-PROFILE
- REF-ITERM2-COMMAND-SELECTION
- REF-ITERM2-SHELL-INTEGRATION
- REF-WEZTERM-SCROLL-TO-PROMPT
- REF-WEZTERM-SEMANTIC-ZONES
