# Quiesce witness schema v0

## Purpose
`ST-QUIESCE v0` is the closed packet for one no-new-demand gate on a concrete runtime cycle.

The central rule: **quiesce means new demand is fenced or being fenced; it is not stopped, drained, force-killed, effect-successful, channel-empty, work-empty, ready, or serving.**

## Machine profile
- Machine profile: `../../schemas/st-quiesce-v0.schema.json`
- Checker: `../../tools/steward_shutdown_harness.py`
- Corpus: `../40-verification/corpora/shutdown-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-QUIESCE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | supervisor, runtime, controller, adapter, operator, or observer reporting the gate |
| `quiesce_id` | canonical quiesce id matching `qsc_[a-z0-9]{16}` |
| `runtime_cycle_ref` | runtime-cycle fence for the concrete run being gated |
| `gate_state` | `requested`, `entering`, `no_new_work`, `exception_window`, `released`, `failed`, or `unknown` |
| `demand_policy` | class of new demand being gated |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the quiesce state |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `active_work_refs`, `allowed_exception_refs`, `release_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Non-implication vocabulary
A valid quiesce witness must include:

- `not-stopped`
- `not-drained`
- `not-force-kill`
- `not-effect-success`
- `not-no-live-channels`
- `not-no-inflight-work`
- `not-readiness`
- `not-serving`

## Quiesce rules
`no_new_work` requires an actual gate policy such as `no_new_external_demand`, `no_new_internal_demand`, `no_new_user_actions`, or `drain_only`; `observe_only` cannot be upgraded into a gate. `released` requires a `release_ref`. `unknown` requires `unknown_reason`.

The quiesce witness may name active work or allowed exceptions, but those lists are not proof that old work drained, channels closed, effects settled, or termination occurred.

## Rejected surfaces
The corpus rejects:

- quiesce packets that claim stopped, drained, no-live-channel, no-inflight-work, force-kill, readiness, serving, or effect success truth;
- no-new-work states backed only by observation;
- duplicate JSON keys;
- released or unknown states without the required basis.

## Non-goals
- no scheduler, queue, broker, admission service, connection manager, endpoint-drain controller, or force-kill API;
- no portable guarantee that a substrate can stop every possible new demand source.

## Adjacent docs
- `quiesce-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `stop-escalation-posture-v0.md`
- `shutdown-horizon-posture-v0.md`
- `live-channel-witness-schema-v0.md`
- `demand-episode-witness-schema-v0.md`
- `canonical-json-profile-v0.md`
