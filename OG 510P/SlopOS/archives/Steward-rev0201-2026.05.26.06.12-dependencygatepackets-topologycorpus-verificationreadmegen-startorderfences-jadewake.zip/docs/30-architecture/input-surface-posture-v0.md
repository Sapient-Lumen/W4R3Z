# Input-surface posture v0

Purpose: define a **tiny shell/terminal input seam** so richer keyboard, mouse, composition, and paste behavior stays explicit, international-friendly, and policy-bounded instead of becoming timing-hack folklore.

## Posture
1. **Live key events, composed text, and injected bytes are different classes**
   - OS/IME-delivered key events, composed text, bracketed paste payloads, replayed input, and UI-originated `send_text`/`send_key` style actions are not the same thing.
   - Steward should keep provenance visible so helper-generated input never masquerades as fresh human typing.
2. **Enhanced input should be capability-gated and opt-in**
   - Applications may request richer keyboard encodings, mouse reporting, or other input upgrades when the terminal supports them.
   - Steward should prefer explicit capability handshakes and visible downgrade over ambient assumptions about what `TERM`, timing, or historical success imply.
3. **Composition, IME, and dead keys are first-class, not edge cases**
   - International text entry and composed-key workflows are part of normal terminal life.
   - Steward should not sacrifice IME, AltGr, or dead-key correctness merely to make one modal shortcut system feel tidy.
4. **Modal key tables and leader sequences should stay visible and bounded**
   - Terminal-owned modes can be fantastic for chooser UIs, split management, resize controls, and command palettes.
   - Active modes should advertise themselves clearly and should have explicit rules for timeout, exit, and unknown-key handling.
5. **Unknown-key behavior must be explicit**
   - While a key table or sequence is active, unknown keys may be ignored, end the mode, be flushed to the program, or remain captured.
   - Steward should name that policy instead of letting accidental leakage into the shell become folklore.
6. **Prompt-local input affordances should remain prompt-local**
   - Click-to-move, prompt editing, and similar shell niceties should work only inside a live prompt/input zone with explicit semantic support.
   - Outside that zone, the same interaction should fall back to selection, exact-anchor actions, or no-op rather than guessing.
7. **Input suspension should be honest and local**
   - Read-only or mouse-reporting-off states are useful when the user wants selection and inspection to beat application capture.
   - Steward should keep those states explicit, scoped, and inspectable rather than burying them in opaque terminal toggles.
8. **Terminal keybindings should yield carefully around applications**
   - Terminal shortcuts, leader modes, and automation hotkeys are valuable, but they should be able to yield based on explicit context such as focused app class, prompt state, or reviewed user variables.
   - Steward should not require every full-screen app to lose because the terminal wanted one more global shortcut.
9. **Input semantics are descriptive, not authority-bearing**
   - Knowing which encoding, mode, or composition path produced input helps explain behavior and keep assist/replay features safe.
   - It should not itself authorize lifecycle control or silently upgrade replayable text into trusted intent.
10. **Enabled and active capture should stay distinct**
   - A terminal or helper may request that some richer input mode be armed, while the compositor or host decides when capture actually becomes active.
   - Steward should keep requested-versus-active input capture explicit instead of pretending the request itself means input is already flowing.
11. **Global or out-of-focus shortcuts should stay session-scoped**
   - Shortcut bundles that can fire beyond the focused prompt are useful, but they should be registered as explicit sessions with visible activation/deactivation and revocation.
   - Steward should not let convenience keybindings turn into an ambient always-on control myth.
12. **One explicit input seam beats scattered special cases**
   - Keyboard protocol choice, leader modes, bracketed paste, prompt-local click behavior, key injection, and read-only capture all want the same anti-folklore discipline.
   - Steward should prefer one small input-surface posture over many host-specific keyboard exceptions.

## Phase-1 non-goals
- freezing one universal cross-terminal keyboard protocol;
- requiring identical modal-key, IME, or dead-key behavior on every platform;
- turning terminal keymaps into a hidden lifecycle-control plane;
- treating replayed or helper-originated bytes as equivalent to fresh human typing;
- inventing a giant input-policy family before more than one closely related seam really exists;
- a portable global-shortcut or input-capture portal family in Phase 1.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `mode-baseline-posture-v0.md`
- `session-injection-posture-v0.md`
- `assist-surface-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `clipboard-surface-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `precision-fence-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `prompt-lease-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `request-context-posture-v0.md`

## References
- REF-KITTY-KEYBOARD-PROTOCOL
- REF-XTERM-BRACKETED-PASTE
- REF-XTERM-MODIFIED-KEYS
- REF-WEZTERM-KEYBOARD-CONCEPTS
- REF-WEZTERM-KEYBOARD-ENCODING
- REF-KITTY-MAPPING
- REF-GHOSTTY-RELEASE-130
- REF-GHOSTTY-KEYBIND-SEQUENCE
- REF-GHOSTTY-KEYBIND-ACTIONS
- REF-XDG-PORTAL-INPUTCAPTURE
- REF-XDG-PORTAL-GLOBALSHORTCUTS
