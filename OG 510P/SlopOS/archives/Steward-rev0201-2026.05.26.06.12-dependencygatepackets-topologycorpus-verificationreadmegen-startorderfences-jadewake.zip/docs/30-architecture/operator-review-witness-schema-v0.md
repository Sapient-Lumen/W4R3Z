# Operator-review witness schema v0

## Purpose
`ST-REVIEW v0` records a bounded human, repair-gate, sibling, or policy-adjacent review of a lifecycle operation request. It answers: **what was checked, by whom, against which request digest, and with what review verdict?**

A review can say a request is hygienic enough to proceed to approval or authorization checks. It is not itself approval, authorization, execution, or component state.

## Machine profile
- Machine profile: `../../schemas/st-review-v0.schema.json`
- Checker: `../../tools/steward_governance_harness.py`
- Corpus: `../40-verification/corpora/governance-authorization-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-REVIEW v0` |
| `witness_id` | generic Steward witness id |
| `review_id` | review id matching `rvw_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object |
| `reviewer` | reviewing actor |
| `subject_op_ref` | operation request reference |
| `subject_request_digest` | canonical digest of the operation request being reviewed |
| `review_type` | `preflight`, `risk`, `repair_gate`, `emergency`, `sibling`, or `posture` |
| `verdict` | `pass`, `block`, `needs_approval`, `needs_repair`, `expired`, or `unknown` |
| `checklist` | bounded checklist items |
| `observed_at_ms` | integer observation time |
| `basis_refs` | evidence refs |
| `non_implications` | explicit refusal list |

Optional fields: `finding_refs`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Checklist rules
A `pass` verdict must include at least:

- `target_fenced`
- `reason_present`
- `idempotency_bound`
- `no_host_target`

Other checklist items such as `fresh_intent`, `approval_present`, `drain_plan_present`, `rollback_plan_present`, `budget_checked`, and `privacy_minimized` can add evidence but cannot weaken the minimum pass rule.

## Staleness rule
If `expires_or_recheck_by_ms` is before `observed_at_ms`, the review must be `expired`. A stale review may remain historical evidence but cannot be used as a current pass.

## Rejections
The corpus rejects:

- pass verdicts missing exact target fencing;
- review packets claiming authorization;
- pass reviews whose recheck window is already stale;
- duplicate ids with different canonical bytes;
- raw host or secret material.

## Non-goals
- no approval;
- no authorization;
- no operation execution;
- no effect-success proof;
- no component-state assertion;
- no hidden repair action.

## Adjacent docs
- `governance-authorization-posture-v0.md`
- `delegation-warrant-witness-schema-v0.md`
- `approval-decision-witness-schema-v0.md`
- `authorization-check-witness-schema-v0.md`
- `preflight-lane-posture-v0.md`
- `repair-gate-posture-v0.md`
