# Observation sync witness schema v0

## Packet
`ST-OBSSYNC v0` records one exact-view sync marker, initial snapshot boundary, partial-window marker, or resync-required marker for a subscription.

## Required meaning
The packet says which subscription is synced through which sequence, which snapshot refs were used if any, which gaps remain if any, what view time the marker is based on, and which rechecks are required.

## Required non-implications
Every sync witness must explicitly refuse:

- `not-authority`
- `not-global-currentness`
- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-quiescence`
- `not-authorization`

## Canonicalization
The machine profile is [`../../schemas/st-obssync-v0.schema.json`](../../schemas/st-obssync-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
A synced-through marker is scoped to one exact view. It must not become global currentness, readiness, quiescence, or route authority. Known gaps are incompatible with a clean synced-through marker and must downgrade to resync-required or partial-window truth.
