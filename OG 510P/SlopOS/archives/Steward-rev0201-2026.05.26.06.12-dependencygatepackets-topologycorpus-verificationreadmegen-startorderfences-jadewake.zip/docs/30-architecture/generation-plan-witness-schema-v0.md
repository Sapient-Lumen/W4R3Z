# Generation-plan witness schema v0

`ST-GENPLAN v0` is a closed Steward packet for one planned component generation change.

## Purpose
A generation plan records that Steward intends, admits, defers, abandons, or cannot classify a proposed generation for a component. It may reference material, a prior generation, and rollback origin, but it does **not** prove material freshness, reload/application, readiness, serving, traffic binding, promotion, execution, rollback success, or effect success.

## Required fields
- `schema`: exactly `ST-GENPLAN v0`.
- `witness_id`: stable witness id.
- `cid`: component id.
- `issuer`: closed issuer object.
- `plan_id`: stable generation-plan id.
- `generation_id`: stable generation id.
- `prior_generation_ref`: exact prior generation ref, or `none` only for an initial generation.
- `material_refs`: digest or weak refs to planned material evidence.
- `change_kind`: `initial`, `reload`, `reconfigure`, `rollback`, `rollforward`, `hot_patch`, or `unknown`.
- `plan_state`: `planned`, `admitted`, `deferred`, `abandoned`, or `unknown`.
- `created_at_ms`: local monotonic creation time.
- `expires_at_ms`: local monotonic expiry time for active plan use.
- `rollback_from_ref`: source generation for rollback plans, otherwise `none`.
- `reason`: `none` for planned/admitted states, otherwise a bounded reason.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for material freshness, apply/reload, readiness, serving, traffic binding, promotion, execution, rollback success, and effect success.

## Rejection examples
- rollback plan with no `rollback_from_ref`;
- non-initial plan without a prior generation ref;
- active plan that is already expired;
- plan claiming material freshness, reload, readiness, promotion, serving, rollback success, or effect success.
