# Command-guide posture v0

Purpose: define a **tiny visible-guide seam** for shell/terminal command rails, sticky headers, and similar frame guides so command boundaries stay easy to see without turning chrome into transcript truth or ambient control.

## Posture
1. **Guides are views over command frames, not the canonical record**
   - A guide rail, sticky header, or hover card may summarize a command frame and its output.
   - The durable record remains the underlying command/output/receipt object, not the guide itself.
2. **Guides should bind to exact frame anchors when available**
   - Clicking, revealing, copying, or attaching context from a guide should resolve through the frame's explicit anchor, receipt ref, or witness when possible.
   - Guide text should not become the only locator for the target it summarizes.
3. **Visible guides should stay observational and user-invoked**
   - A guide may reveal a command, open exact output, show details, or expose safe next actions.
   - It must not become a hidden ambient control bus for lifecycle mutation.
4. **Noisy commands should be filterable**
   - Commands such as `clear`, pager transitions, or agent-like buffer residents may deserve less or no persistent guide chrome.
   - The guide surface should be allowed to hide or downrank noisy frames instead of pretending every semantic frame deserves equal visual weight.
5. **Terminal-guessed marks are useful scaffolding, not equal authority**
   - If a terminal can synthesize marks from Enter presses or similar fallback heuristics, those guides should remain visibly lower-confidence than shell-reported command boundaries.
   - Guess-based guides are better than nothing, but they must not silently inherit trusted-shell privileges.
6. **Guide details should stay compact and exact-object-backed**
   - Good guide details include command text, cwd summary, hop lineage, exit/result, duration, receipt refs, and freshness/confidence.
   - Avoid turning the guide into a pane-wide dashboard or a duplicate transcript.
7. **Sticky headers should degrade honestly**
   - When the terminal loses precision, the shell resyncs, or a frame goes stale, guide chrome should clear, relabel, or downgrade instead of preserving old certainty.
8. **Prompt-local editing affordances belong only to live prompt zones**
   - Clicking to move the cursor or reveal command details is excellent when the shell reports an active prompt/input zone.
   - Those affordances should not guess into historical output or blur the difference between live input and recorded transcript.
9. **One guide seam is healthier than many ad hoc frame widgets**
   - Rails, sticky headers, current-command cards, and scrollbar marks all want the same semantic inputs.
   - Steward should prefer one small guide seam under the chrome lane rather than separate bespoke micro-protocols for each widget.

## Phase-1 non-goals
- inventing a block-terminal worldview where guides replace ordinary scrollback;
- guaranteeing identical guide widgets in every terminal or multiplexer;
- treating terminal-synthesized prompt marks as trusted lifecycle truth;
- hiding stop/restart/reconfigure authority behind guide hover actions;
- freezing a giant theme/layout schema for terminal chrome.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`
- `prompt-lease-posture-v0.md`
- `attention-hint-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1103
- REF-VSCODE-UPDATE-1104
- REF-VSCODE-UPDATE-1109
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-ADVANCED-PROFILE
- REF-GHOSTTY-RELEASE-130
- REF-FISH-OSC-MARKERS
