# Witness card schema v0

## Packet
`ST-WITCARD v0` records one rendered witness card.

## Required meaning
A card explains a subject using bounded evidence refs. It names the truth class, headline state, missing stronger witnesses, display caveats, downgrade class, and non-implications.

## Required non-implications
Every card must explicitly refuse:

- `not-authority`
- `not-current-state`
- `not-freshness`
- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-execution`

## Canonicalization
The machine profile is [`../../schemas/st-witcard-v0.schema.json`](../../schemas/st-witcard-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
Weak, historical, stale, blocked, or unknown cards must not render as `settled`. Weak-basis cards must name the stronger witness classes still missing.
