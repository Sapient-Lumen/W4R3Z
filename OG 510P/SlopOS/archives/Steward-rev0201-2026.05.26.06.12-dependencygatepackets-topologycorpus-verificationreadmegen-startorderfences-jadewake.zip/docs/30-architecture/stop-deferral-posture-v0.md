# Stop-deferral posture v0

Purpose: pin a **tiny explicit stop-deferral seam** so "do not stop me yet" can stay attributable, bounded, and revocable without turning into a generic lease system, a hidden scheduler, or sticky keepalive folklore.

This doc is intentionally narrow. It does **not** design a general power-management API, a durable inhibit inventory, or a cross-component deadlock solver.

## Posture
1. **Stop deferral is a bounded grace request, not persistence**
   - A deferral says a concrete running leaf asks for a short grace window before stop, quiesce completion, or adjacent transition work proceeds.
   - It does not imply durable residency, future wakeup, or restart entitlement.
2. **Deferral is live, scoped, and fail-closed**
   - Any deferral belongs to one exact runtime-cycle witness / supervised leaf.
   - Leaf exit, replacement, disconnect, or explicit revocation ends the old deferral story.
   - Steward should prefer live handles or balanced begin/end style ownership over sticky booleans.
3. **Delay is the healthy default; indefinite veto is not**
   - Phase 1 should bias app-facing semantics toward bounded delay / grace rather than forever-blocking stop vetoes.
   - Any stronger block semantics should remain rare, policy-owned, and explicitly reviewable.
4. **Stronger policy may cut through deferral**
   - Operator force, repair-required state, hard timeout, or safety policy may end the waiting story even if the runtime still wants more time.
   - Cut-through should be visible and explainable, not magical.
5. **Deferral is about active transition protection, not scheduling**
   - This seam protects in-flight save/flush/drain windows while a component is actually active.
   - It is not a future reservation, background scheduler, or reboot-spanning keepalive registration.
6. **Deferral should carry a compact reason and budget when possible**
   - A tiny descriptive reason such as draining, flushing, saving, or operator-confirm-needed is useful.
   - Where a runtime can expose a remaining budget or countdown honestly, Steward may surface it observationally.
7. **Shell/terminal UX may reflect deferral, but only as observational chrome**
   - Exact frames or panes may show short-lived delaying / draining badges, countdowns, or explainers when tied to an exact anchor.
   - That chrome must not become hidden control authority.
8. **Optional seam; no fake universality**
   - Runtimes that cannot express stop deferral remain valid.
   - Steward should not infer deferral from CPU quiet, half-closed sockets, or a prompt that merely looks busy.

## Executable settlement
Rev0200 adds `activity-accounting-proof-posture-v0.md`, `activity-accounting-corpus-v0.md`, and closed ST-ACTBRACKET / ST-IDLEHINT / ST-STOPDEFER / ST-ACTACCT packet profiles. These executable checks keep activity, idle hints, stop deferral, and accounting separate from readiness, serving, custody, drain completion, keepalive authority, billing, work completion, and effect success.

## Phase-1 non-goals
- a generic distributed lease or scheduling plane;
- reboot- or session-spanning stop inhibition;
- a portable deadlock solver for mutually deferring components;
- treating historical receipts as proof that a deferral is still live now;
- turning shell chrome into lifecycle authority.

## Adjacent docs
- `activity-accounting-posture-v0.md`
- `activity-bracket-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `grant-handle-posture-v0.md`
- `quiesce-posture-v0.md`
- `status-channel-posture-v0.md`
- `session-variable-posture-v0.md`

## References
- REF-XPC-TRANSACTION-BEGIN
- REF-XPC-TRANSACTION-END
- REF-SYSTEMD-INHIBITOR-LOCKS
- REF-SYSTEMD-INHIBIT-MAN
- REF-XDG-PORTAL-INHIBIT
