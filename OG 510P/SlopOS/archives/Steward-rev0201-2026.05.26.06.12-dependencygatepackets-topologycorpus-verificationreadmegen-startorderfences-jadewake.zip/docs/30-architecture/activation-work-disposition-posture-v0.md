# Activation-work disposition posture v0

Purpose: name the smallest useful truth for **what became of one admitted activation demand, event, descriptor obligation, or background work item after custody changes, a holder exits, a channel closes, a lease expires, or a retry/dead-letter boundary fires**.

This seam is intentionally small. It does **not** invent a durable queue, general job-status API, delivery-guarantee algebra, transaction coordinator, poison-message system, or workflow runtime. It answers one narrower question: **after admission and custody, what fate can Steward honestly report for this exact activation work without pretending service, readiness, or exactly-once success?**

## Posture
1. **Disposition is later than admission and different from custody**
   - Admission says whether one exact attempt may enter the activation fabric.
   - Custody says who currently holds the work or whether that holder is ambiguous.
   - Disposition says what fate is known after a boundary: `completed`, `acknowledged`, `returned`, `redeliverable`, `redelivered`, `expired`, `dead-lettered`, `discarded`, `abandoned`, `detached`, `superseded`, or `unknown`.
   - Steward should not flatter `accepted`, `delivered`, or `held` into `done`.

2. **Acceptance is noncommittal unless another seam proves the later outcome**
   - HTTP 202 and SlopOS ACP-style acceptance/completion discipline are useful warnings: accepted-for-processing is not proof that processing completed or will even be acted on.
   - Steward should let an activation surface accept demand while still requiring a separate demand outcome, custody update, or work-disposition witness before claiming completion.

3. **Ack, delete, stop-self, and offset commit are semantic boundaries, not log vibes**
   - Many systems use a small explicit signal to say work is no longer owed: message ack/delete, Android `stopSelf(startId)`, queue delete, offset commit, or a provider-local completion marker.
   - A sent acknowledgement can race channel closure; a commit can occur before or after the side effect it is meant to represent.
   - Steward should record the strongest boundary it can actually prove, such as `ack confirmed`, `ack sent unconfirmed`, `offset committed`, `completion local-only`, or `ack unknown`.

4. **Crash/restart must not invent replay semantics**
   - Android's `START_NOT_STICKY`, `START_STICKY`, and `START_REDELIVER_INTENT` teach a useful distinction: after a killed service, the system may avoid restart, restart without redelivering the last intent, or restart and redeliver work.
   - Steward should make any comparable restart/resume promise explicit instead of letting component restart imply silent redelivery, silent drop, or silent success.

5. **Redelivery is a normal disposition, duplicates are a separate hazard**
   - Message and event systems repeatedly distinguish valid redelivery after missing acknowledgement from unexpected duplicate delivery.
   - Steward should preserve `redelivery expected`, `duplicate-risk`, `same item id`, `new wrapped dead-letter item`, and `delivery count approximate` when the substrate can prove them.

6. **Poison / dead-letter / discard is an explicit fate, not failure forgotten**
   - DLQ-style systems are useful because they isolate unconsumed work for later diagnosis, but they also have ordering, retention, and best-effort subtleties.
   - Steward should steal compact disposition truth such as `dead-lettered`, `discarded after age`, `discarded after attempts`, `retained for inspection`, or `redrive eligible`, not a universal poison-queue contract.

7. **Commit position and side-effect position can diverge**
   - Kafka's delivery-semantics discussion is the classic warning: committing before processing can lose work; processing before committing can duplicate work; stronger exactly-once behavior requires cooperating transactional boundaries.
   - Steward should treat effect keys, idempotency keys, external transaction handles, or activation-effect boundary witnesses as separate stronger evidence, not infer exactly-once from restart or queue membership.

8. **Termination and cleanup disposition are separate from runtime exit**
   - Kubernetes finalizers and terminal Pod phases show that deletion accepted, cleanup pending, terminal phase set, and object gone are separate lifecycle facts.
   - Steward should keep `marked for cleanup`, `cleanup pending`, `cleanup satisfied`, `force removed`, and `cleanup unknown` separate from runtime-cycle exit disposition and from activation-work success.

9. **Replacement and migration need an anti-split-brain marker**
   - Before a newer cycle claims disposition for work that an older cycle held, Steward should prefer a lease expiry, holder fence, channel close, explicit handoff acceptance, or provider-local revocation fact.
   - If none exists, `ambiguous holder` or `duplicate-risk` is healthier than pretending clean takeover.

10. **Disposition should feed repair and explanation, not become ambient control**
    - Useful chips include `accepted only`, `held`, `ack pending`, `redeliverable`, `redelivered`, `dead-lettered`, `expired`, `discarded`, `detached`, `abandoned`, and `outcome unknown`.
    - Those chips may support reviewed retry, inspect, cancel, or redrive actions, but the chip itself must not become a bearer queue handle or durable job object.

11. **Phase 1 shape is a witness, not a delivery API**
    - A tentative `activation_work_disposition` witness can stay tiny: `disposition_id`, `episode_id` or `custody_id`, `item_kind`, `attempt_or_delivery`, optional `last_holder`, optional `runtime_cycle`, `disposition`, optional `ack_strength`, optional `commit_or_fence`, optional `attempt_count`, optional `redelivery_state`, optional `retention_or_expiry`, optional `cleanup_state`, optional `effect_key`, and optional `basis`.
    - Field names remain provisional until concrete Steward components prove which details must be portable.

## Phase-1 non-goals
- a generic durable queue, dead-letter queue, redrive service, broker, job-status API, or workflow engine;
- exactly-once delivery, exactly-once side effects, distributed transactions, or a universal offset/commit model;
- treating accepted demand, active custody, successful runtime restart, or component health as proof of activation-work completion;
- hiding lost acknowledgements, approximate delivery counts, holder ambiguity, poison/discard policy, or duplicate risk behind a successful-looking lifecycle state;
- making Android service restart modes, RabbitMQ acknowledgements, Pub/Sub exactly-once, SQS DLQs, Kafka transactions, or Kubernetes finalizers into the portable Steward architecture.

## Adjacent docs
- `activation-admission-posture-v0.md`
- `activation-demand-episode-posture-v0.md`
- `activation-custody-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `exit-disposition-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `effect-key-posture-v0.md`
- `retry-advice-posture-v0.md`
- `fence-token-posture-v0.md`
- `continuity-escrow-posture-v0.md`
- `repair-gate-posture-v0.md`
- `state-explainer-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-HTTP-RFC9110
- REF-ANDROID-SERVICES
- REF-RABBITMQ-ACKS-CONFIRMS
- REF-RABBITMQ-CHANNELS
- REF-RABBITMQ-QUEUES
- REF-GCP-PUBSUB-BASICS
- REF-GCP-PUBSUB-EXACTLY-ONCE
- REF-GCP-PUBSUB-DEAD-LETTER
- REF-AWS-SQS-DEAD-LETTER-QUEUES
- REF-AWS-SQS-VISIBILITY-TIMEOUT
- REF-AWS-LAMBDA-ASYNC-ERROR-HANDLING
- REF-KAFKA-DESIGN
- REF-K8S-FINALIZERS
- REF-K8S-POD-LIFECYCLE
- REF-SYSTEMD-SERVICE

## Work-disposition executable settlement
Rev0185 settles the first executable packet as `ST-WORKDISP v0`, specified in `work-disposition-witness-schema-v0.md` and checked by `../40-verification/demand-custody-effect-corpus-v0.md`. The checker accepts local completion, acknowledgement, and expiry while rejecting local-completion-without-custody, degraded terminal disposition without reason, effect-success claims, and exactly-once folklore.
