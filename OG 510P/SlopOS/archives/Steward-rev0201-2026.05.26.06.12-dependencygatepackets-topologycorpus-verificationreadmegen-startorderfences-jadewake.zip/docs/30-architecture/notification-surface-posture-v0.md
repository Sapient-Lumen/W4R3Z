# Notification-surface posture v0

Purpose: define a **tiny notification escalation seam** so shell/terminal cues can become OS toasts, mark alerts, or similar attention wakeups without turning notification clicks into hidden shell execution or lifecycle control.

## Posture
1. **Notifications escalate exact anchors; they do not create new authority**
   - A notification should originate from an exact command frame, transcript landmark, receipt, or other reviewed anchor when possible.
   - Steward should resist pane-wide folklore where a generic toast stands in for current truth or fresh authorization.
2. **Focus-aware delivery should be first-class**
   - A command-finished toast is usually more useful when the pane, tab, or window is not focused, or when the command ran long enough to matter.
   - Steward should keep focus state, duration thresholds, and user-armed “watch this exact frame” flows explicit instead of one noisy global notification switch.
3. **Notification content should stay compact and non-authoritative**
   - Summary text, badges, and quick actions can help the user notice something.
   - Durable truth still belongs in the transcript, receipt, status view, or exact reveal target after the transient cue disappears.
4. **Clicks should prefer reveal/focus/open over arbitrary execution**
   - A notification action may reasonably reveal the exact frame, open a related receipt, or focus the right workspace target.
   - Steward should not let a toast click silently become “run this shell command now” or “approve this mutation” by ambient convention.
5. **Target binding and foreground activation should stay separate**
   - Revealing an exact frame or receipt is one concern; asking the desktop to foreground a window is another.
   - Steward should keep exact target selection separate from any platform activation token, focus request, or raise request.
6. **Capability drift should degrade honestly**
   - Some platforms support buttons, some only summary text, some support desktop notifications only from unfocused panes, and some alert through terminal-native mark flows instead.
   - Steward should expose those differences as visible delivery classes or downgrade reasons instead of pretending notification power is portable by magic.
7. **Origin, provenance, and helper path should remain inspectable**
   - Shell-reported command completion, terminal-generated mark alerts, BEL fallback, and remote helper generated notifications are not equivalent.
   - Steward should be able to explain why a notification exists, what anchor it used, and which helper path made it possible.
8. **Noise budgets matter**
   - Command-finished notifications are delightful right up until every short-lived helper or chatty pane starts yelling.
   - Steward should keep thresholds, per-kind filters, and explicit watch-this-command flows central to the seam.
9. **One notification seam beats scattered bells, alerts, and toast loopholes**
   - OS toasts, alert-on-mark flows, desktop-notification escape sequences, and terminal-local completion notifiers all want the same anti-folklore discipline.
   - Steward should prefer one small notification-surface posture over many per-host notification exceptions.

## Phase-1 non-goals
- a universal notification protocol for all applications on the host;
- using notification clicks as an approval bypass for lifecycle or shell mutations;
- promising durable inbox/history semantics for every transient notification;
- freezing a giant urgency or channel taxonomy for every future use case;
- guaranteeing identical button/action support on every platform.

## Adjacent docs
- `attention-hint-posture-v0.md`
- `transcript-landmark-posture-v0.md`
- `target-anchor-posture-v0.md`
- `action-surface-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `command-frame-posture-v0.md`
- `attention-watch-posture-v0.md`

## References
- REF-DESKTOP-NOTIFICATIONS-SPEC
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
- REF-GHOSTTY-RELEASE-130
- REF-WEZTERM-NOTIFICATION-HANDLING
- REF-ITERM2-SHELL-INTEGRATION
- REF-KITTY-DESKTOP-NOTIFICATIONS
- REF-KITTY-CONF
- REF-VSCODE-SHELL-INTEGRATION
