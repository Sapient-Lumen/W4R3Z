# Activation-live channel posture v0

Purpose: name the smallest useful truth for **a live connection, stream, subscription, watch, WebSocket, server-sent event stream, multiplexed RPC channel, or drainable message client that already exists across an activation boundary** so Steward can keep existing-channel fate separate from traffic binding, serve-state, readiness, admission, custody, work disposition, effect completion, and rollout truth.

This seam is intentionally small. It does **not** invent a connection manager, transport API, RPC framework, pub/sub broker, streaming protocol, session-resumption plane, service mesh, sticky-session grammar, or reconnect scheduler. It answers one narrower question: **for a named live conduit that may be open, draining, closing, reset, resumed, or lost while a component starts, stops, restarts, migrates, or changes route binding, what does Steward know and what must it not imply?**

## Posture
1. **Traffic binding is about new entry; live channels are already inside**
   - A route, alias, target group, service, DNS answer, or Gateway rule can stop sending new work while an older connection, stream, watch, or subscription is still delivering bytes, RPCs, events, or callbacks.
   - Conversely, a channel can be reset or closed even while the traffic surface still routes new demand elsewhere.
   - Steward should keep `new-demand binding` separate from `existing conduit still open`, `no-new-substreams`, `draining`, `closing`, `reset`, and `lost`.

2. **The channel holder and scope must be explicit**
   - Useful holders include a component incarnation, supervisor endpoint, sidecar/proxy, balancer, client library, watch client, browser object, message client, or compat adapter.
   - Useful scope fields include `live_channel_ref`, `holder_ref`, `traffic_surface_ref`, optional `listener_ref`, optional `subscription_ref`, optional `component_id`, optional `revision_ref`, optional `incarnation_id`, optional `peer_ref`, and optional `channel_kind`.
   - If the holder or scope is unknown, the witness should downgrade to `channel-holder-unknown` or `scope-unknown` instead of pretending that route, PID, pod, or service name identifies the live channel.

3. **Connection, substream, request, and message truth stay separate**
   - A single transport connection may contain many HTTP/2 streams, HTTP/3 streams, gRPC RPCs, WebSocket messages, SSE events, or watch events.
   - Closing or draining the outer channel does not prove the fate of every inner item, and completing one inner item does not prove the channel is safe to reuse.
   - Steward should distinguish `connection-state`, `stream-acceptance-state`, `substream-range`, `message-cursor`, `subscription-state`, and `per-work disposition refs` when those facts are available.

4. **No-new-work signals are not completion signals**
   - HTTP/2 and HTTP/3 GOAWAY-style fences can say that new streams or requests after a boundary should not be initiated or might not be processed.
   - They do not prove that earlier streams completed successfully, nor that later retries are safe unless the relevant method, idempotency, custody, and effect-boundary facts agree.
   - A live-channel witness should therefore carry `no-new-streams`, `last-accepted-stream`, `last-maybe-processed`, `retry-possible`, `retry-unsafe`, or `retry-unknown` rather than a vague `closed cleanly` bit.

5. **Graceful drain needs a deadline and a force path**
   - Graceful shutdown commonly means stop or discourage new work, allow in-flight work to finish for a bounded time, then force close or reset what remains.
   - Without the deadline and force-path witness, `graceful` becomes a marketing word rather than an operational truth.
   - Steward should expose `drain-started`, `drain-deadline`, `drain-extended`, `drain-complete`, `force-close-pending`, `force-closed`, and `deadline-unknown` when known.

6. **Drain is per layer, not a universal verb**
   - A listener can stop accepting new network connections while existing connections continue.
   - A connection can stop accepting new streams while existing streams continue.
   - A subscription can remove interest while callbacks still drain outstanding messages.
   - A publisher can stop new publishes while already-buffered data is flushed.
   - Steward should say which layer is draining instead of flattening listener, connection, stream, subscription, publisher, and application work into one `draining` status.

7. **Close handshakes and abnormal closure are different fates**
   - WebSockets, HTTP/2, HTTP/3, gRPC, TCP, QUIC, and message clients each expose different closure and reset evidence.
   - A clean close handshake may still leave application-level questions, and an abnormal close may leave both sides with different last-known reasons.
   - Useful states include `close-sent`, `close-received`, `closing-handshake`, `closed-cleanly`, `closed-abnormally`, `reset`, `peer-lost`, `transport-error`, and `reason-disagrees`.

8. **Resume hints are not continuity proof**
   - A watch bookmark, resource version, last-event id, reconnect delay, retry-after hint, resume token, session ticket, or client library retry may help a caller resume observation or reconnect.
   - It is not proof that no events were missed, no messages duplicated, no credential expired, or the same component incarnation still owns the channel.
   - Steward should keep `resume-hint`, `resume-attempted`, `resume-accepted`, `gap-possible`, `gap-known`, `duplicate-possible`, and `continuity-unknown` separate from channel liveness.

9. **Existing channels can pin old identity and material**
   - Long-lived channels may continue using older peer authentication, server-name choices, client certificates, projected tokens, route bindings, or incarnation references after a new revision or material version exists.
   - That can be valid, but it must not silently prove freshness or current authority.
   - A live-channel witness can cross-reference material-freshness, traffic-binding, and incarnation-lineage witnesses rather than copying their meanings.

10. **Existing channels do not settle rollout or rollback**
   - A rollback route can become active for new callers while older channels to the withdrawn revision continue to drain.
   - A canary can have sticky or connection-bound callers long after a control verdict says promotion, hold, or revert.
   - Steward should expose `channel-bound-to-old-target`, `channel-bound-to-new-target`, `channel-target-unknown`, and `route-moved-while-channel-open` instead of treating route state as channel fate.

11. **Backpressure and overload may act on channels before components stop**
   - A proxy or runtime may disable keepalive, send GOAWAY, reject new requests, reset expensive streams, close idle connections, or stop accepting new connections under pressure.
   - Those are protective channel decisions, not necessarily component death, route withdrawal, admission denial, or final work disposition.
   - Steward should let live-channel witnesses cite pressure, backpressure, adaptation, or control-verdict evidence without merging them.

12. **Observation streams need cursor humility**
   - Snapshot-plus-change watches, SSE streams, shell subscriptions, and lifecycle observation feeds can be current to a cursor yet still disconnect, compact, overflow, or resume with a gap.
   - `synced-through` is useful only with its source, scope, and continuity class.
   - Steward should prefer `stream-current-through`, `bookmark-only`, `cursor-resumable`, `compacted`, `overflowed`, `resync-required`, or `unknown-continuity` over pretending an open stream is global currentness.

13. **Channel fate can feed custody and disposition but cannot replace them**
   - If a channel closes before an ack, the work may be redeliverable, duplicated, unknown, abandoned, or already externally effected.
   - The channel witness can explain the transport boundary that made fate uncertain, but the fate still belongs to custody, work-disposition, or effect-boundary witnesses.
   - This prevents `connection closed` from becoming accidental exactly-once, exactly-never, or success folklore.

14. **Phase 1 shape is a live-channel witness, not a transport API**
   - A tentative `activation_live_channel` witness can stay tiny: `live_channel_ref`, `channel_kind`, `holder_ref`, optional `traffic_surface_ref`, optional `listener_ref`, optional `subscription_ref`, optional `component_id`, optional `revision_ref`, optional `incarnation_id`, optional `peer_ref`, `channel_state`, optional `new_substream_state`, optional `drain_layer`, optional `drain_state`, optional `drain_deadline`, optional `last_stream_or_event_cursor`, optional `close_signal`, optional `resume_hint`, optional `route_binding_ref`, optional `material_freshness_refs`, optional `custody_or_disposition_refs`, optional `basis_refs`, optional `observed_as_of`, and optional `unknown_reason`.
   - Field names remain provisional until real Steward components prove which live-channel facts must cross membranes.

## Executable packet settlement
`ST-LIVECHAN v0` is the first executable settlement for this posture. It deliberately proves less than the full posture: closed decode, canonical digest, required non-implications, drain-deadline discipline, resume/gap humility, raw bearer rejection, and channel-as-not-effect-success. It is not a final transport, connection, stream, or reconnect API.

The deterministic corpus in `../40-verification/channel-binding-corpus-v0.md` is the current promotion gate: new live-channel language should either preserve those cases or add a new accept/reject case before becoming stronger posture.

## Phase-1 non-goals
- a portable connection manager, socket API, HTTP/gRPC/WebSocket/SSE framework, pub/sub broker, watch service, event bus, stream multiplexer, reconnection scheduler, session-resumption plane, service mesh, sticky-session grammar, or endpoint-drain controller;
- promising that GOAWAY, close frames, graceful stop, deregistration delay, drain calls, bookmarks, or last-event ids prove work completion, side-effect success, no-loss continuity, or safe retry;
- treating a still-open connection as proof of readiness, health, current material, current incarnation, route authority, or rollout settlement;
- treating route withdrawal, controller verdicts, or probe failure as proof that all existing channels are gone;
- standardizing transport-specific closure codes, RPC statuses, QUIC/TLS resumption state, browser network behavior, or message-client buffer semantics as portable Steward truth.

## Adjacent docs
- `activation-traffic-binding-posture-v0.md`
- `activation-control-verdict-posture-v0.md`
- `activation-probe-vantage-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `activation-custody-posture-v0.md`
- `activation-work-disposition-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `activation-material-freshness-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-RFC9113-HTTP2
- REF-RFC9114-HTTP3
- REF-GRPC-GRACEFUL-SHUTDOWN
- REF-ENVOY-DRAINING
- REF-ENVOY-OVERLOAD-MANAGER
- REF-AWS-ALB-TARGET-GROUP-ATTRIBUTES
- REF-K8S-POD-ENDPOINT-TERMINATION-FLOW
- REF-RFC6455-WEBSOCKET
- REF-NATS-DRAIN
- REF-K8S-API-CONCEPTS
- REF-HTML-SERVER-SENT-EVENTS
