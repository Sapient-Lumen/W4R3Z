# Observation subscription witness schema v0

## Packet
`ST-OBSSUB v0` records one accepted observational subscription for an explicit Steward subject and bounded view.

## Required meaning
The packet says which consumer, subject, view kind, delivery mode, accepted event classes, and buffering limits were accepted by the status channel.

## Required non-implications
Every subscription witness must explicitly refuse:

- `not-authority`
- `not-mutation`
- `not-authorization`
- `not-current-state`
- `not-readiness`
- `not-serving`
- `not-effect-success`

## Canonicalization
The machine profile is [`../../schemas/st-obssub-v0.schema.json`](../../schemas/st-obssub-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
A subscription binds to an explicit subject. It must not target ambient current pane folklore, wildcard event firehoses, hidden mutation buses, or unbounded buffering. Acceptance of a subscription only proves that a bounded observation path exists; it does not prove current lifecycle state.
