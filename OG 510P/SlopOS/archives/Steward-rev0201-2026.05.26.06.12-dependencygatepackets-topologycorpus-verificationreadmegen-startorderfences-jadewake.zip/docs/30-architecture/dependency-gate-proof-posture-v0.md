# Dependency gate proof posture v0

## Rule
Steward may name dependency declarations, dependency checks, dependency-informed gates, and fallback modes only as scoped witnesses. None of those packets may impersonate topology authority, start-order planning, readiness, serving, authorization, demand acceptance, work completion, component failure, repair, rollback success, or effect settlement.

## Why this seam exists
Without this seam, any implementation pressure around “wait for database”, “cache is down”, “upstream is healthy”, or “start after peer” tends to collapse into a hidden orchestration graph. Steward needs enough vocabulary to explain a lifecycle request honestly without becoming a universal dependency planner or topology DSL.

## Packet settlement
- `ST-DEPSPEC v0` records the edge that is being considered.
- `ST-DEPCHECK v0` records a bounded condition check for that edge from one vantage.
- `ST-DEPGATE v0` records the lifecycle request decision that used the specs and checks.
- `ST-DEPFALLBACK v0` records degraded or fallback mode basis when a gate chooses `degrade`.

## Non-claims
- No global component topology authority.
- No final dependency-strength algebra.
- No portable scheduler, start-order planner, service graph, mesh graph, or recovery graph.
- No claim that upstream availability proves subject readiness or serving.
- No claim that upstream unavailability proves subject failure.
- No claim that fallback proves repair, rollback success, work completion, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/dependency-gate-corpus-v0.jsonl`; the checker is `../../tools/steward_dependency_gate_harness.py`.
