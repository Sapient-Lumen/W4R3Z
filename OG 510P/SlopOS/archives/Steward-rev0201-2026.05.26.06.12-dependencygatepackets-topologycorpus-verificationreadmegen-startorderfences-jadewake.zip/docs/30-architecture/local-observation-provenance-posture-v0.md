# Local observation provenance posture v0

## Purpose
Steward often needs to show what the local world seemed to say: a host manager reported active, an orchestrator reported running, a sidecar looked green, a stream cursor advanced, a watcher noticed changed material, or a shell observer saw a prompt transition. These facts are useful, but they are not Steward-native lifecycle truth.

This posture makes local observation provenance executable without letting host/runtime folklore become authority.

## Packet set
- `ST-LOCALOBS v0` records one weak categorical observation without raw substrate handles.
- `ST-OBSAPPRAISE v0` appraises that observation for narrow weak uses.
- `ST-OBSCURSOR v0` records continuity and gap state for observation streams.
- `ST-OBSATTACH v0` attaches, refuses, quarantines, or rechecks an observation after appraisal.

## Design rules
1. Local observation is weak evidence, not native truth.
2. Adapter confidence is scoped; it is not global trust.
3. Cursor movement is not currentness or lossless continuity.
4. Weak attachment must keep native Steward witnesses visible as still required.
5. Raw substrate identifiers stay under the adapter membrane.
6. Expired or quarantined appraisals cannot support weak-basis attachment.
7. Observation surfaces may explain why Steward rechecks; they may not execute lifecycle mutations.

## Boundary to existing packets
`ST-PROBE v0`, `ST-MATFRESH v0`, `ST-CTRLVERDICT v0`, `ST-TBIND v0`, `ST-LIVECHAN v0`, `ST-RTCYCLE v0`, and `ST-OPRECEIPT v0` remain native Steward witness families. Local observations may be cited as weak basis, but they do not replace those packets.

## Sibling boundaries
Ward owns global trust and delegation. ViewFS owns durable object/storage reference semantics. Schell and Helm own rich shell and repair surfaces. SlopOS owns primitive truth. Steward only records local observation provenance for lifecycle explanation and recheck discipline.

## Verification
The local-observation provenance corpus is [`../40-verification/local-observation-provenance-corpus-v0.md`](../40-verification/local-observation-provenance-corpus-v0.md). It checks raw-host-id rejection, currentness/readiness flattery rejection, cursor gap downgrade, expired appraisal refusal, local-only witness refusal, duplicate observation id drift, and adapter-green-as-current-state rejection.
