# Adapter membrane posture v0

## Purpose
Prevent host/runtime facts from impersonating Steward-native lifecycle truth.

Adapters are necessary. Their facts are useful. But Steward's public contract must not become “whatever systemd, Kubernetes, Envoy, NATS, or another substrate happened to call active, ready, drained, or retried.”

## Membrane rule
An adapter fact enters Steward as weak basis evidence unless a reviewed Steward witness promotes it within a named scope.

Promotion requires:

1. source and issuer;
2. observed subject;
3. host/runtime identity basis;
4. freshness and time basis;
5. mapping rule;
6. refusal list;
7. adjacent Steward witness if the claim is stronger than observation.

## Examples
| Adapter fact | May say | Must not imply |
| --- | --- | --- |
| systemd active | host unit reports active | CH-COMP readiness or serving |
| systemd fdstore redelivered fd | host manager returned a descriptor | CH-ACTSET authority or material freshness |
| Kubernetes Pod Running | a Pod phase was observed | readiness, serving, current route, or work completion |
| Kubernetes readiness probe passed | one probe/vantage passed | external traffic binding or effect safety |
| Envoy route retry occurred | proxy attempted retry by its policy | Steward retry safety, custody, or effect success |
| NATS drain started | client/broker entered drain path | lossless completion unless drain completion witness exists |

## Adapter receipt shape
An adapter receipt should name:

- `adapter_kind`;
- `adapter_subject`;
- `observed_fact`;
- `observed_at`;
- `freshness`;
- `identity_basis`;
- `mapping_claim`;
- `promoted_witness_ref`, if any;
- `does_not_prove`.

## Negative test posture
Every adapter that can feed lifecycle status should have at least one negative corpus or conformance case showing that its strongest tempting host fact does not automatically become Steward readiness, serving, authority, or effect truth.

The first proof-slice corpus includes weak adapter observations for systemd and Kubernetes.

## Non-goals
- no host-manager compatibility layer as native meaning;
- no Kubernetes conformance layer;
- no systemd unit grammar;
- no service-mesh policy import;
- no broker semantics import;
- no adapter-specific field leakage into CH-COMP or CH-ACTSET.

## References
REF-SYSTEMD-FDSTORE; REF-K8S-POD-LIFECYCLE; REF-K8S-PROBES; REF-ENVOY-HTTP-ROUTING; REF-NATS-DRAIN.


## Local observation packet settlement
Adapter facts that are useful but weaker than Steward-native witnesses should enter as `ST-LOCALOBS v0`, then pass through `ST-OBSAPPRAISE v0` and `ST-OBSATTACH v0` before they appear on explanation, operator-review, recovery-hint, audit, history, or recheck surfaces. Raw host identifiers and adapter handles stay behind the membrane. Cursor movement enters as `ST-OBSCURSOR v0` and cannot claim currentness, drain, or lossless continuity.
