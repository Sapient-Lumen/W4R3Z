# Generation-readiness witness schema v0

`ST-GENREADY v0` is a closed Steward packet for scoped readiness evidence about a particular component generation.

## Purpose
A generation-readiness witness records candidate, ready, degraded, failed, or unknown readiness for a generation after a specific apply attempt. It may use probe refs and an expiry. It does **not** prove global readiness, serving, traffic binding, promotion, stability, work completion, current state, or effect success.

## Required fields
- `schema`: exactly `ST-GENREADY v0`.
- `witness_id`, `cid`, and closed `issuer`.
- `readiness_id`: stable readiness id.
- `generation_ref`: exact generation id.
- `apply_ref`: exact apply id.
- `probe_refs`: exact probe or verdict refs used as basis.
- `ready_state`: `candidate`, `ready`, `degraded`, `failed`, or `unknown`.
- `readiness_scope`: `control_plane`, `serve_path`, `canary`, `operator_view`, or `unknown`.
- `evaluated_at_ms`: local monotonic evaluation time.
- `expires_at_ms`: local monotonic expiry time.
- `required_probe_count`: number of required passing probes.
- `passing_probe_count`: number of passing probes observed.
- `failure_reason`: `none` for candidate/ready states, otherwise a bounded reason.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for global readiness, serving, traffic binding, promotion, stability, work completion, current state, and effect success.

## Rejection examples
- ready state with too few passing probes;
- ready state whose evidence has expired;
- degraded, failed, or unknown state without a reason;
- packet claiming global readiness, serving, traffic binding, promotion, stability, or effect success.
