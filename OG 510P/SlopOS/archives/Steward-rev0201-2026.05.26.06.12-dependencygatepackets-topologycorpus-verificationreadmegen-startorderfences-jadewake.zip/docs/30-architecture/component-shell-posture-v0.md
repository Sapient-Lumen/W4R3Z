# Component-shell posture v0

Purpose: define a **tiny exact component-shell seam** so `shell into this component scope` can be a reviewed, policy-bounded helper action over one explicit target without collapsing into ambient cwd tricks, debugger attach, or service-lifecycle folklore.

## Posture
1. **Component shell entry should target one reviewed scope, not ambient session state**
   - A component shell should bind to one explicit component, ownership island, or similarly reviewed scope anchor.
   - Steward should resist helper-shell folklore like “whatever pane currently looks nearby must be the right scope”.
2. **Scoped shell entry, attach, control, and debug stay different truths**
   - A component shell is a helper execution context scoped to a target.
   - Observe-only attach, lifecycle control, debugger entry, and deep inspection remain separate lanes with their own review and policy gates.
   - Steward should keep those moves visibly distinct instead of flattering them into one vague “entered the service” story.
3. **The shell is adjunct to the target, not the target itself**
   - A helper shell may let the operator inspect files, run scoped commands, or gather evidence near the component.
   - It must not become the public identity of the component run, nor proof that the service leaf itself is alive, ready, or controllable.
4. **Expiry and replacement should stay ordinary and explicit**
   - If the target stops, restarts, reloads incompatibly, is replaced, or loses the relevant scope, the helper shell should be allowed to say `expired`, `rebind required`, `replaced`, or `scope lost`.
   - Steward should not quietly pretend an old helper shell still speaks for a newer concrete run.
5. **Scope details should be explicit and small**
   - Phase 1 likely needs only target anchor, helper program/layout choice, cwd or namespace layout hint when honest, hop lineage, freshness, and whether the shell is interactive or one-shot.
   - Avoid freezing a universal namespace-entry schema, remote-exec protocol, or giant tool-layout language before repeated pressure exists.
6. **Policy should bound what the helper shell can do**
   - Some component shells may be observe-only, tool-limited, namespace-limited, or denied entirely by policy.
   - Steward should allow explicit denials and downgraded recipes instead of assuming every reviewed target implies a powerful interactive shell.
7. **Lifecycle and shell UX should stay connected by exact anchors**
   - The originating action card, command frame, receipt, or component detail view should be able to say which exact component shell was opened and on what scope.
   - Later explain / reload / reveal flows should resolve through the same target anchor instead of pane folklore.
8. **Reload humility matters**
   - A component-scoped shell may be extremely useful beside explicit reload verbs.
   - But shell entry must not imply that reload is in-place, that resources were preserved, or that the helper shell automatically tracks the next generation without a fresh bind or explicit continuity proof.
9. **Keep the phase-1 contract tiny**
   - Phase 1 should stop at one reviewed component-shell entry seam plus ordinary expiry, downgrade, and provenance.
   - Avoid freezing debugger attach, durable session resurrection, namespace authoring, or cross-runtime exec protocols before the archive truly earns them.

## Phase-1 non-goals
- inventing a universal `exec into anything` protocol;
- treating helper shells as lifecycle authority or readiness proof;
- silently auto-rebinding old shells across replacement or restart;
- collapsing helper shell entry, debugger attach, and lifecycle mutation into one action;
- freezing a giant namespace / tool-layout / remote-exec family before repeated pressure exists.

## Adjacent docs
- `spawn-selector-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `launch-boundary-posture-v0.md`
- `control-target-posture-v0.md`
- `attach-lane-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `execution-ground-posture-v0.md`
- `ownership-island-posture-v0.md`
- `command-frame-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-FFX-COMPONENT
- REF-KUBECTL-EXEC
- REF-DOCKER-EXEC
