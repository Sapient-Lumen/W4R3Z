# Interface registry

| ID | Surface |
| --- | --- |
| IF-STEWARD | the user-space Steward lifecycle manager itself |
| IF-ACTIVATE | activation delivery path |
| IF-STATUS | compact current-state/status path |
| IF-REPAIR | repeated-failure cooldown / repair-gate observation and explicit clear path |
| IF-ADMIN | observe-first control-operation request/receipt path for reviewed lifecycle mutations |
| IF-PRECOND | precondition witness packet path for exact runtime-cycle, generation, cursor, material, hold, or barrier checks without authorization, lock, reservation, execution, or currentness claims |
| IF-OPARBIT | operation-arbitration packet path for queued, rejected, replaced, flushed, irreversible, or accepted collision decisions without operation-result or execution claims |
| IF-HOLD | hold-state packet path for deliberate lifecycle constraints without failure, stopped/off, drain-complete, readiness, or serving claims |
| IF-PROGRESS | progress-window packet path for in-progress, advanced, extended, held, stalled, or unknown movement without readiness, stability, serving, work-completion, or effect-success claims |
| IF-PRESSURE | pressure witness packet path for scoped stall, saturation, quota, latency, reclaim, adapter, or operator pressure without failure, readiness, serving, admission, execution, or effect-success claims |
| IF-HEADROOM | headroom witness packet path for scoped spendability, budget, quota, rate, concurrency, or manual-clear windows without approval, authority, reservation, admission, execution, or effect-success claims |
| IF-BACKPRESS | backpressure witness packet path for new-work pacing, queue, defer, shed, reject, or pushback observations without demand, custody, retry-reservation, serving, or effect-success claims |
| IF-ADMGATE | admission-gate witness packet path for pressure/headroom/backpressure-informed allow, queue, defer, shed, reject, or unknown decisions without authority, demand, custody, execution, readiness, serving, or effect-success claims |
| IF-DEPSPEC | dependency-spec witness packet path for scoped lifecycle dependency declarations without topology authority, start-order, readiness, serving, admission, work-completion, or effect-success claims |
| IF-DEPCHECK | dependency-check witness packet path for bounded available, degraded, unavailable, stale, or unknown dependency condition checks without subject readiness, serving, currentness, or failure claims |
| IF-DEPGATE | dependency-gate witness packet path for allow, block, defer, degrade, or unknown lifecycle request decisions without authorization, execution, start success, readiness, serving, or effect-success claims |
| IF-DEPFALLBACK | dependency-fallback witness packet path for planned, armed, active, revoked, expired, or unknown degraded modes without repair, rollback-success, readiness, serving, work-completion, or effect-success claims |
| IF-GENPLAN | generation-plan packet path for proposed/admitted/deferred generation changes without freshness, apply, readiness, promotion, or effect claims |
| IF-RECONFAPPLY | reconfiguration-apply packet path for runtime-cycle-bound reload/apply attempts without readiness, serving, promotion, all-worker update, or effect claims |
| IF-GENREADY | generation-readiness packet path for scoped, expiring generation readiness without global readiness, traffic binding, serving, stability, or effect claims |
| IF-PROMOTION | promotion packet path for scoped generation traffic shifts or rollback route restoration without serving, drain, work-completion, rollback-success, or effect claims |
| IF-SUBS | bounded snapshot-plus-change subscription path for observation views, including explicit resync/overflow hints when exact continuity is lost |
| IF-CURSOR | exact observation-cursor path for resume, synced-through markers, and honest continuity-loss reports on snapshot-plus-change views |
| IF-OBS | observation / transcript export |
| IF-SHELLTERM | shell and terminal semantic side channel |
| IF-CMDFRAME | command-frame observation path for prompt/input/output boundaries and receipts |
| IF-HANDSHAKE | shell/terminal capability-handshake and downgrade-observation path |
| IF-MODEBASE | shell/terminal prompt-critical mode-baseline and repair-observation path |
| IF-EPOCH | shell/terminal semantic-epoch freshness and stale-fence path |
| IF-HOPS | shell/terminal hop-lineage observation path for remote and multiplexer-aware context |
| IF-ACTIONS | explicit shell/terminal action-surface path for chips, hyperlinks, and palette entries bound to Steward targets |
| IF-ANCHORS | bounded exact-target anchor path for command frames, receipts, transcript spans, and concrete runs used by shell/terminal affordances |
| IF-HANDOFF | bounded command/context handoff path for exact command frames, output slices, receipts, and concrete runs |
| IF-ATTN | shell/terminal attention-hint path for command-finished, needs-input, warning, error, and progress-like cues |
| IF-NOTIFY | shell/terminal notification escalation path for OS toasts, mark-alert wakeups, and exact reveal/focus requests tied to concrete anchors |
| IF-CHROME | shell/terminal chrome lane for observational badges, tab titles, sticky headers, status cells, and similar non-transcript presentation surfaces |
| IF-COMPSHELL | reviewed helper-shell entry path scoped to one exact component / ownership target |
| IF-TRANSIENT | explicit promotion path from shell work to transient Steward-tracked object |
| IF-TRAFFIC | traffic-binding witness packet path for route/new-demand mapping observations and route-drain caveats |
| IF-LIVECHAN | live-channel witness packet path for connection, stream, subscription, watch, drain, cursor, close/reset, and resume ambiguity observations |
| IF-DEMAND | demand-episode witness packet path for accepted, buffered, delivered, timed-out, shed, lost, or unknown per-demand activation truth |
| IF-CUSTODY | custody witness packet path for current holder, handoff, lease, cancellation, loss, redelivery, and duplicate-risk truth |
| IF-WORKDISP | work-disposition witness packet path for local acknowledgement, completion, expiry, discard, redelivery, and unknown fate |
| IF-EFFECT | effect-boundary witness packet path for local commit, outbox, external submit/confirm, duplicate replay, mismatch, retention, compensation, irreversible, and ambiguous effect truth |
| IF-STATEATT | state-attachment witness packet path for scratch, tmp, projected material, runtime/state directories, persistent/sticky storage, snapshot-derived bytes, detach, cleanup, and unknown attachment truth |
| IF-MATFRESH | material-freshness witness packet path for config, secret, token, trust bundle, lease, projection, restored material, reload, renewal, revocation, expiry, and unknown freshness truth |
| IF-PROBE | probe-vantage witness packet path for startup, readiness, liveness, gRPC health, balancer, mesh, synthetic, cached, and outside-in check observations |
| IF-CTRLVERDICT | control-verdict witness packet path for controller, balancer, rollout, DNS-health, circuit-breaker, operator-adapter, repair-gate, and human-reviewed verdict observations |
| IF-RTCYCLE | runtime-cycle witness packet path for concrete run/cycle identity, terminal cause, and stale-target fences without exporting host handles |
| IF-INCARN | incarnation-lineage witness packet path for predecessor/successor, replacement, clone/restore, and currentness relations without settling work or effects |
| IF-RESIDENCY | residency witness packet path for placement, warm idle, frozen/restoring, active, evicting, lost, and unknown residency without implying readiness or serving |
| IF-RESUME | resume/reconciliation witness packet path for restart replay, manager recovery, hot handoff, snapshot restore, cursor resume, and explicit gap ambiguity |
| IF-RETRYADVICE | retry-advice witness packet path for not-before, pushback, cooldown, expired, superseded, manual-review, and unknown retry timing truth |
| IF-RETRYBUDGET | retry-budget witness packet path for scoped budget/quota/limiter observations and automatic-retry allow/block effects without capacity claims |
| IF-RETRYATTEMPT | retry-attempt witness packet path for attempt groups, canonical intent, safety basis, commitment boundary, early-data risk, duplicate risk, and outcome links |
| IF-HEDGEFATE | hedge-fate witness packet path for hedge winners, losing-attempt fates, cleanup ambiguity, and no-side-effect refusal |
| IF-QUIESCE | quiesce witness packet path for no-new-demand gates without stopped, drained, force-kill, or no-live-channel claims |
| IF-DRAIN | drain witness packet path for old-work, live-channel, demand, traffic, or component drain boundaries without lossless or effect-success claims |
| IF-ESCALATE | escalation witness packet path for stronger stop intervention without final stopped, clean-exit, graceful, or effect-success claims |
| IF-TERMCAUSE | termination-cause witness packet path for runtime-cycle end observations without drain-complete, restart-success, successor-ready, custody, or effect-success claims |
| IF-DELEGATE | delegation-warrant witness packet path for scoped, expiring, non-redelegable lifecycle authority evidence |
| IF-REVIEW | operator-review witness packet path for request hygiene and risk review without approval or authorization claims |
| IF-APPROVAL | approval-decision witness packet path for exact operation-digest approval or denial without execution claims |
| IF-AUTHCHECK | authorization-check witness packet path for allowed, denied, stale, needs-approval, or unknown lifecycle gate decisions without operation-result claims |
| IF-RECEIPTCHAIN | receipt-chain witness packet path for digest-linked lifecycle evidence without authority, current-state, effect-success, or complete-history claims |
| IF-REDACTION | redaction witness packet path for minimized receipt projections and stripped-class commitments without full-fidelity or secret-free proof claims |
| IF-EXPORTBUNDLE | evidence-export bundle packet path for handoff manifests bound to chain heads and redaction digests without authority or live-state claims |
| IF-REPLAYOBS | replay-observation packet path for import/replay verification and explicit gap downgrade without freshness or currentness claims |
| IF-IMPORT | import-observation packet path for inbound export/replay evidence without authority, freshness, live-state, or currentness claims |
| IF-SRCAPPRAISE | source-appraisal packet path for lifecycle-scoped weak-use appraisal without global trust or policy authority claims |
| IF-RECONPLAN | reconciliation-plan packet path for mapping imported evidence to local subjects without execution or lifecycle mutation claims |
| IF-RECONDECISION | reconciliation-decision packet path for history or weak-basis adoption, rejection, recheck, or quarantine without current-state, readiness, serving, or effect-success claims |
| IF-LOCALOBS | local observation packet path for host-manager, runtime, adapter, shell, watcher, and cursor-adjacent weak observations without raw substrate handles or native-truth claims |
| IF-OBSAPPRAISE | local observation appraisal packet path for limited weak-use decisions without global trust, policy, currentness, readiness, or serving claims |
| IF-OBSCURSOR | observation cursor packet path for stream continuity, overflow, reset, compaction, and gap downgrade without currentness, drain, or lossless-continuity claims |
| IF-OBSATTACH | local observation attachment packet path for weak basis, quarantine, refusal, and recheck decisions without execution, authority, freshness, readiness, serving, or effect-success claims |
| IF-OBSSUB | observation-subscription packet path for bounded exact-view watches without mutation, authorization, or current-state claims |
| IF-OBSDELIV | observation-delivery packet path for delivered, coalesced, dropped, heartbeat, or resync-required batches without lossless or currentness claims |
| IF-OBSSYNC | observation-sync packet path for exact-view snapshots and synced-through markers without global currentness, readiness, quiescence, or serving claims |
| IF-OBSGAP | observation-gap packet path for open or cleared stream gaps that block risky verbs until refresh without proving lossless continuity |
| IF-ATTNHINT | attention-hint packet path for exact lifecycle or shell cues without user-seen, completion, currentness, authorization, or mutation claims |
| IF-ATTNWATCH | attention-watch packet path for exact user-armed watches without automation, approval, authorization, execution, or current-state claims |
| IF-NOTICE | notification-delivery packet path for queued, delivered, failed, suppressed, or stale delivery without user-read, resolution, mutation, or effect-success claims |
| IF-ATTNACK | attention-acknowledgement packet path for reveal, focus, open, dismiss, or clear interactions without resolution, authorization, execution, or work-completion claims |
| IF-WITCARD | witness-card packet path for rendered evidence summaries with missing stronger witnesses, caveats, downgrade class, and non-implications |
| IF-ACTIONAFFORD | action-affordance packet path for exact, reviewable, stale-fenced UI actions without execution, approval, or authorization claims |
| IF-STATUSBARRIER | status-barrier packet path for blocking risky verbs until stale or missing evidence is refreshed without proving current state |
| IF-SURFAUDIT | surface-audit packet path for audit/refactor findings without becoming authority, fix, release, or correctness proof |
| IF-ACTBRACKET | activity-bracket packet path for runtime-cycle-scoped in-flight activity without demand, custody, drain, readiness, serving, work-completion, or effect-success claims |
| IF-IDLEHINT | idle/busy/draining hint packet path for bounded activity status without stopped-state, stop-authority, quiescence, drain, readiness, serving, or currentness claims |
| IF-STOPDEFER | stop-deferral packet path for bounded in-flight-work grace without approval, clean-exit, stopped-state, drain-completion, or keepalive-lease claims |
| IF-ACTACCT | activity-accounting packet path for descriptive usage meters without billing, quota-debit, pressure, headroom, admission, demand, work-completion, or effect-success claims |
