# Transient-promotion posture v0

Purpose: define a cautious seam for turning **shell-launched long-running work** into Steward-tracked objects without freezing a giant transient-unit language too early.

## Posture
1. **Promotion is explicit, not automatic**
   - A plain shell command stays a plain command unless the user, shell, or reviewed policy explicitly asks Steward to promote it.
   - Backgrounding with `&`-style folklore should not silently create a first-class Steward object.
2. **Promotion creates accountability, not permanent installation**
   - A promoted command may become a transient Steward-tracked component or service object with status, stop, receipt, and observation support.
   - That does not imply the work has become a durable boot-time service, a globally named component, or an autostarting background lease.
3. **Origin metadata matters**
   - A useful promotion path should remember where the work came from: command frame, cwd, trust/provenance, launch context digest, and optional user-facing label.
   - Promotion should preserve accountability to the initiating shell interaction instead of severing it.
4. **Normalized launch context beats shell-session leakage**
   - Promotion should not blindly inherit the whole ambient shell session.
   - Environment, cwd, stdio behavior, resource/budget hints, and activation bindings should be normalized into an explicit launch context.
5. **Transient promotion and background permission are different seams**
   - “Track this as a service object” is not the same thing as “let this persist forever” or “wake this later in the background”.
   - Long-lived persistence, autostart, and resume-after-reboot still belong to adjacent SlopOS background/jobs policy seams.
6. **Promotion is best for long-running or status-worthy work**
   - Local servers, watches, tailers, sync loops, build daemons, and similar commands are strong candidates.
   - Tiny one-shot commands usually do not need service-object treatment.
7. **Receipts should survive promotion**
   - The initiating command frame should be able to attach a receipt or pointer to the transient object so later status/explain UX can answer “what did that shell action become?”.
8. **Promotion should not require a universal transient grammar in phase 1**
   - A narrow first cut may only need name/label, argv image, normalized env subset, cwd, stdio mode, and a few lifecycle/accounting knobs.
   - Avoid reproducing a full systemd transient-unit property language before real pressure exists.
9. **Compat membranes are allowed, native meaning stays narrow**
   - Under a host membrane, implementation-specific backends may map a transient promotion to local machinery.
   - Native Steward meaning should still be expressed in Steward terms: accountability, observation, stop/restart posture, and bounded lifetime.

## Phase-1 non-goals
- a complete transient-unit property DSL;
- automatic promotion of every backgrounded shell command;
- making transient promotion the same thing as durable installation or autostart;
- standardizing every log retention or output-capture policy;
- pretending the shell job table is already a lifecycle fabric.


## Rev0198 executable settlement
`ST-PROMOTION v0` covers generation promotion and rollback records, not shell-command transient service promotion. The shared lesson is the same: promotion is an accountability edge, not execution, serving, drain completion, effect success, or compensation proof. Steward keeps transient process promotion pressure separate from generation traffic promotion.

## Adjacent docs
- `command-frame-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `supervision-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-GNU-SHEPHERD-TRANSIENT
- REF-GNU-SHEPHERD-TRANSIENT-MAKER
- REF-SYSTEMD-RUN
- REF-MOSH
