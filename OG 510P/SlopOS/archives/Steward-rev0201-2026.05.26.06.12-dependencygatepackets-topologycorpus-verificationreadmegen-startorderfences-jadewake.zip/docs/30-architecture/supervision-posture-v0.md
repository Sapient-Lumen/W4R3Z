# Supervision posture v0

Purpose: pin a first-phase meaning for Steward supervision.

## Posture
1. **Component-rooted, user-space supervision**
   - Steward supervises explicit component roots identified by `cid`, not raw PIDs, shell jobs, cgroups, or host process subtrees.
2. **Supervised services stay foreground and directly accountable**
   - A supervised component presents a directly accountable runtime root to Steward.
   - Phase 1 does not standardize self-daemonizing, double-fork, or “the real service escaped elsewhere” lifecycle patterns.
3. **Deterministic bounded stop → kill**
   - Portable lifecycle control is: request cooperative stop, wait bounded grace, then escalate to termination.
   - Signal names, jobspecs, pidfds, job objects, process contracts, and cgroup paths are implementation detail, not public Steward semantics.
4. **Restart is bounded and explicit**
   - Restart policy is manifest-bounded; no hidden infinite retry loops.
   - Cooldown / backoff details may vary by implementation, but crash-loop behavior must remain bounded and explainable.
   - If Steward later admits a stronger `full reset` action that replays init / prepare helpers or restarts all adjunct and main leaves together, that action must stay explicitly distinct from ordinary leaf restart and from replacement of the component object.
5. **Restart replays manifest + explicit launch context + activation only**
   - Restart cannot widen route sets, inherit ambient session baggage, or resurrect undeclared authority.
6. **No host-global service-manager DSL in v0**
   - Steward may eventually gain more planning or orchestration surfaces, but revision 2 still refuses to turn supervision into a giant all-in-one admin language.
7. **Compatibility remains sealed**
   - Host service managers may exist beneath a compat membrane, but their control surfaces do not become Steward's native contract.
8. **Cleanup is not the main runtime**
   - Short-lived cleanup/finalization helpers may exist, but they remain visibly separate from the supervised long-lived runtime root and must not become an excuse for the real service to escape accountability.
9. **A supervised leaf should stay nameable through restart pressure**
   - Steward should preserve explanation for which concrete runtime root is being retried, cooled down, or declared repair-required rather than collapsing restart pressure into anonymous process churn.
10. **Future edge semantics must stay few and visibly different**
   - If Steward later admits lifecycle-edge meaning, hard start-needs, optional waits/accompaniment, continuous upkeep, and cooperating-work completion should remain different named relations.
   - Phase 1 still refuses to freeze a universal dependency algebra; the point is to preserve distinctions, not to import a giant graph DSL.

## Phase-1 non-goals
- generic process inventory or watch APIs;
- portable pidfd or job-object control;
- process-tree targeting;
- adopting arbitrary foreign host processes into Steward lifecycle;
- portable support for self-daemonizing services as the normal supervision model.

## Adjacent docs
- `design-principles-v0.md`
- `component-manifest-schema-v0.md`
- `activation-posture-v0.md`
- `launch-context-posture-v0.md`
- `execution-group-posture-v0.md`
- `readiness-posture-v0.md`
- `quiesce-posture-v0.md`

## References
- REF-LAUNCHD-JOBS
- REF-DAEMONTOOLS-SUPERVISE
- REF-RUNIT-OVERVIEW
- REF-DINIT-AS-INIT
- REF-DINITCTL
- REF-ERLANG-OTP-SUPERVISOR
- REF-SOLARIS-SMF-RESTARTER
- REF-S6-SUPERVISE
- REF-S6-RC-WHY
- REF-SYSTEMD-UNIT
- REF-WINDOWS-JOB-OBJECTS
- REF-SOLARIS-PROCESS-CONTRACTS
- REF-LINUX-CGROUP-V2
