# Hold-state witness schema v0

`ST-HOLD v0` is a closed Steward packet for one deliberate lifecycle hold over an exact scope.

## Purpose
A hold witness records that selected lifecycle verbs are intentionally blocked or have been released/expired. It does **not** prove the component is failed, stopped, off, drained, current, authorized, executing, ready, serving, or effect-settled.

## Required fields
- `schema`: exactly `ST-HOLD v0`.
- `witness_id`: stable witness id.
- `cid`: component id.
- `issuer`: closed issuer object.
- `hold_id`: stable hold id.
- `scope_ref`: exact component, runtime-cycle, group, or operation scope.
- `hold_kind`: `maintenance`, `operator`, `policy`, `backpressure`, `repair_gate`, `drain`, `freeze`, or `unknown`.
- `hold_state`: `active`, `released`, `expired`, or `unknown`.
- `blocks_verbs`: verbs gated while active.
- `allows_work_classes`: observation-only or in-flight classes allowed while held.
- `started_at_ms`: local monotonic start time.
- `expires_at_ms`: local monotonic expiry boundary.
- `release_ref`: exact release witness or `none` while active.
- `reason`: bounded reason string.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for failure, stopped/off state, drain completion, effect success, current state, readiness, serving, authorization, and execution.

## Rejection examples
- active hold without blocked verbs;
- active hold whose expiry is already past;
- released hold without a release ref;
- expired hold whose expiry is in the future;
- failure, stopped/off, drained, authorization, execution, readiness, serving, currentness, or effect-success claims;
- raw host ids, paths, endpoints, descriptors, tokens, or command text.
