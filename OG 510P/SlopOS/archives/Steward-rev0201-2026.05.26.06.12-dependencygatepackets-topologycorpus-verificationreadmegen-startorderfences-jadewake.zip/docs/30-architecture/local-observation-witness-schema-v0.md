# Local observation witness schema v0

## Packet
`ST-LOCALOBS v0` records one weak local observation produced by an adapter, host manager, orchestrator API, shell observer, proxy, broker, watcher, or runtime-side observer.

## Required meaning
The packet says only that a named source, from a named vantage class, reported a bounded observation about a Steward subject at `observed_at_ms`.

It deliberately carries categorical state instead of raw substrate handles. A packet may say `source_kind: systemd`, `source_scope: host_manager`, `observation_class: unit_state`, and `observed_state: active`; it must not carry a unit name, PID, cgroup path, pod name, container id, raw endpoint, descriptor number, token, path, or scrollback text.

## Required non-implications
Every packet must explicitly refuse:
- `not-authority`
- `not-current-state`
- `not-freshness`
- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-execution`

## Canonicalization
The machine profile is [`../../schemas/st-localobs-v0.schema.json`](../../schemas/st-localobs-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
A local observation is not a native Steward lifecycle witness. It can be basis material for explanation, review, recovery hints, or recheck requests only through `ST-OBSAPPRAISE v0` and `ST-OBSATTACH v0`.
