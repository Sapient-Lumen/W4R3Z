# Failure-latch posture v0

Purpose: define a **tiny explicit failure-latch seam** so remembered failed / maintenance truth can stay visibly separate from current liveness, one-cycle termination cause, and restart-budget pressure.

## Posture
1. **A failed run may leave remembered state even after nothing is running**
   - One concrete runtime cycle can end, all supervised processes can be gone, and the fabric may still retain a failed/maintenance result that matters to operators.
   - Steward should not flatten that into either `still running somehow` or `nothing to see here anymore`.
2. **Failure latch is remembered operational truth, not current liveness**
   - `not running`, `serving=no`, and `failed (latched)` answer different questions.
   - The shell should be able to say both *nothing is live right now* and *the last failure is still latched and has not been cleared or aged out*.
3. **Latched failure, repair gate, and restart budget stay separate**
   - A restart budget says whether automatic retry may still happen.
   - A repair gate says whether automatic replay is currently withheld.
   - A failure latch says whether remembered failed/maintenance state still exists even after the current run is gone.
4. **Clearing remembered failure should be explicit when supported**
   - Historical systems often require an explicit `clear`, `reset-failed`, or equivalent action before the manager forgets the failed state.
   - Steward should preserve that distinction instead of teaching users that a stray restart, reboot, or later success silently erased the history.
5. **Aggressive collection/forgetting is a different policy choice**
   - Some substrates deliberately garbage-collect failed units or reset failure counts after a quiet period.
   - Steward should treat `latched until clear`, `aged out after quiet window`, and `collected` as different remembered-state stories instead of one vague `stopped` answer.
6. **Latched failure should keep compact explanation attached**
   - The healthiest remembered object is small but useful: last runtime-cycle witness, compact termination cause, when the latch was entered, what policy is keeping it, and how it can be cleared.
   - Steward should resist turning this into a giant incident database or log-retention empire.
7. **Operator UX should make remembered failure visible and actionable**
   - Cards and receipts should prefer compact truth such as `failed (latched)`, `maintenance (latched)`, `cleared`, `aged out`, or `collected` instead of forcing users to guess from missing processes or stale logs.
   - Healthy next moves are `explain`, `show last cycle`, `clear latch`, or `retry now` when policy allows.
8. **This seam stays smaller than a universal retention policy family**
   - Phase 1 likely needs only a tiny distinction between present latch, explicit clear, and optional age-out/collection detail.
   - Broader retention windows, archival guarantees, and audit-store semantics can stay provider-local until repeated pressure proves otherwise.

## Phase-1 non-goals
- promising that every substrate retains failure state across reboot or forever;
- freezing one portable retention-duration or age-out DSL;
- conflating remembered failed state with current liveness, current readiness, or current serve truth;
- turning compact failure memory into a full incident/ticket/log warehouse.

## Adjacent docs
- `termination-cause-posture-v0.md`
- `exit-disposition-posture-v0.md`
- `repair-gate-posture-v0.md`
- `restart-budget-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `state-explainer-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-UNIT
- REF-SYSTEMD-RUN
- REF-SYSTEMCTL
- REF-SMF-MAINTENANCE
- REF-WINDOWS-SERVICE-FAILURE-ACTIONS
