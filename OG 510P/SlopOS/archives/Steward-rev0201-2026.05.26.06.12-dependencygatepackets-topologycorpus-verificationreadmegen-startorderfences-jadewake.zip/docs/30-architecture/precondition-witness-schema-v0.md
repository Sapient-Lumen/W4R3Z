# Precondition witness schema v0

`ST-PRECOND v0` is a closed Steward packet for one evaluated precondition over an exact lifecycle target.

## Purpose
A precondition witness says that one reviewed basis was satisfied, failed, stale, or unknown at a specific evaluation time. It does **not** authorize the operation, reserve capacity, prove current state, execute a mutation, or settle an effect.

## Required fields
- `schema`: exactly `ST-PRECOND v0`.
- `witness_id`: stable witness id.
- `cid`: component id.
- `issuer`: closed issuer object.
- `precondition_id`: stable precondition id.
- `target_ref`: exact component, runtime-cycle, generation, cursor, material, or barrier target.
- `condition_kind`: `runtime_cycle_match`, `incarnation_match`, `generation_match`, `cursor_match`, `material_fresh`, `barrier_clear`, `hold_absent`, or `unknown`.
- `condition_state`: `satisfied`, `failed`, `stale`, or `unknown`.
- `required_refs`: exact witness/material/barrier refs evaluated.
- `evaluated_at_ms`: local monotonic evaluation time.
- `expires_at_ms`: local freshness boundary for using the result.
- `mismatch_reason`: `none` when satisfied; otherwise a bounded reason.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for authority, authorization, approval, execution, mutation, current state, readiness, serving, effect success, reservation, and lock ownership.

## Rejection examples
- ambient `current` targets;
- satisfied preconditions that are already expired;
- satisfied preconditions with a mismatch reason;
- failed/stale/unknown preconditions without a reason;
- authorization, approval, execution, lock, reservation, currentness, readiness, serving, or effect-success claims;
- raw host ids, paths, endpoints, descriptors, tokens, or command text.
