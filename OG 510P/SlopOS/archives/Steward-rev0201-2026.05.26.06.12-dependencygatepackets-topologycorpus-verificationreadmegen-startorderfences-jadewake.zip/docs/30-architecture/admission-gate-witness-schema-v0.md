# Admission-gate witness schema v0

## Purpose
`ST-ADMGATE v0` is the closed packet profile for one pressure/headroom/backpressure-informed admission gate decision. It records allow, queue, defer, shed, reject, or unknown gate truth without becoming authority, approval, demand acceptance, custody, work completion, execution, readiness, serving, or effect success.

## Required fields
- `schema`: constant `ST-ADMGATE v0`.
- `witness_id`: packet witness id.
- `admission_gate_id`: stable gate decision id.
- `cid`: component identity.
- `request_ref`: exact request or proposed-demand reference.
- `scope_ref`: exact admission lane or subject.
- `issuer`: closed issuer object.
- `observed_at_ms`: monotonic observation time.
- `decision_state`: `allow`, `queue`, `defer`, `shed`, `reject`, or `unknown`.
- `decision_basis`: `pressure`, `headroom`, `backpressure`, `policy`, `operator`, `mixed`, or `unknown`.
- `pressure_refs`, `headroom_refs`, and `backpressure_refs`: bounded exact basis refs.
- `decided_at_ms` and `expires_at_ms`: freshness window for the gate decision.
- `followup_demand_ref`: `none` or a separate demand witness ref when an allow path later creates one.
- `reason`: bounded explanation.
- `basis_refs`: bounded evidence refs.
- `non_implications`: must include `not-authority`, `not-authorization`, `not-approval`, `not-demand`, `not-custody`, `not-work-completion`, `not-readiness`, `not-serving`, `not-execution`, and `not-effect-success`.

## Cross-field rules
- Pressure, headroom, backpressure, and mixed decisions need exact basis refs.
- Non-allow decisions must not cite a followup demand witness.
- Allow decisions cannot rely on exhausted headroom or contradictory blocking backpressure.
- Raw substrate handles, secrets, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
An admission-gate witness never proves authority, approval, demand acceptance, custody, work completion, readiness, serving, execution, retry success, or external effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/pressure-admission-corpus-v0.jsonl`; the checker is `../../tools/steward_pressure_admission_harness.py`.
