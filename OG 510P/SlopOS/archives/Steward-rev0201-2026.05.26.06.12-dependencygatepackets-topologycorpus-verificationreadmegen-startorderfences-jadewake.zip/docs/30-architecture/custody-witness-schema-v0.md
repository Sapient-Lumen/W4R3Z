# Custody witness schema v0

## Purpose
`ST-CUSTODY v0` is the closed packet profile for present-tense responsibility over one activation demand, event, descriptor, delivered item, or background obligation.

It answers a narrow question: who currently holds the obligation, how strong was the handoff, and what does that not prove?

## Required fields
- `schema`: constant `ST-CUSTODY v0`.
- `custody_id`: stable packet-local custody identifier.
- `item_ref`: exact item or obligation under custody.
- `cid`: component identity.
- `issuer`: closed issuer object.
- `custody_state`: `held`, `delivered_unacknowledged`, `accepted_by_runtime`, `released`, `returned`, `redeliverable`, `abandoned`, `lost`, or `unknown`.
- `holder_ref`: current holder or last honest holder.
- `observed_at_ms`: monotonic packet-time observation.
- `duplicate_risk`: `none`, `possible`, `known`, or `unknown`.
- `basis_refs`: bounded supporting observations.
- `non_implications`: must include at least `not-readiness`, `not-serving`, `not-work-completion`, `not-effect-success`, and `not-exactly-once`.

## Optional fields
`demand_ref`, `work_ref`, `previous_holder_ref`, `next_holder_ref`, `transfer_boundary_ref`, `lease_expires_at_ms`, `runtime_cycle`, `cancellation_state`, and `loss_reason`.

## Cross-field rules
- `lease_expires_at_ms` must not precede `observed_at_ms`.
- `delivered_unacknowledged`, `released`, and `returned` require `transfer_boundary_ref`.
- `accepted_by_runtime` requires `runtime_cycle`.
- `lost`, `abandoned`, and `unknown` require `loss_reason`.
- Raw broker identifiers, host process identifiers, raw handles, secrets, and stronger lifecycle/effect claims are forbidden anywhere in the packet.

## Refusals
A custody witness never proves work completion, effect success, readiness, serving, losslessness, or exactly-once execution.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/demand-custody-effect-corpus-v0.jsonl`; the checker is `../../tools/steward_work_effect_harness.py`.
