# Decision map

Guiding compression: `design-principles-v0.md`.
Refusal / freeze-late companion: `non-decisions-v0.md`.

## D-SUPV
How component-rooted supervision works; see `supervision-posture-v0.md`.

## D-ACTIVATE
How activation handles and continuity escrow work; see `activation-posture-v0.md`.
How bounded continuity escrow itself stays explicit, redelivered, and separate from runtime-cycle identity or takeover proof; see `continuity-escrow-posture-v0.md`.

## D-ACTFANOUT
How one reviewed activation surface may feed one shared worker or per-demand worker instances without hardening a giant instance, backlog, or concurrency grammar; see `activation-fanout-posture-v0.md`.

## D-ACTDEMAND
How one exact demand accepted by an activation surface may be buffered, wake a target, be delivered, time out, be canceled, or be shed without becoming readiness, serving, a durable queue, or an autoscaler contract; see `activation-demand-episode-posture-v0.md`.

## D-ACTADMISSION
How one exact wake, start, or demand attempt may be admitted, denied, deferred, narrowed, throttled, shed, or left unknown before any runtime, readiness, serving, queue, or completion truth is claimed; see `activation-admission-posture-v0.md`.

## D-ACTCUSTODY
How one admitted demand, event, descriptor, or background obligation reports current holder, handoff strength, cancellation, expiry, redelivery, duplicate risk, or ambiguity without becoming a broker or proof of completion; see `activation-custody-posture-v0.md`.

## D-ACTWORKDISPOSITION
How one admitted activation demand, event, descriptor obligation, or background item reports acknowledged, redeliverable, redelivered, expired, dead-lettered, discarded, abandoned, detached, superseded, or unknown fate without becoming a queue, job-status API, redrive service, transaction coordinator, or exactly-once proof; see `activation-work-disposition-posture-v0.md`.

## D-ACTEFFECT
How one admitted activation work item reports no-effect, local-commit, outbox-recorded, external-submit, external-accept, external-confirm, compensation, irreversible-floor, duplicate-suppressed, mismatch, or unknown side-effect boundary truth without becoming a transaction coordinator, saga, outbox service, or exactly-once side-effect plane; see `activation-effect-boundary-posture-v0.md`.

## D-ACTINCARNATION
How one logical component keeps stable identity, concrete runtime-cycle witness, predecessor/successor relation, hot-restart overlap, in-place subcycle, replacement, clone/restore uncertainty, and stale-action fences separate without becoming a rollout controller, migration protocol, distributed lock, leader-election service, or global epoch sequencer; see `activation-incarnation-lineage-posture-v0.md`.

## D-ACTRESIDENCY
How placement intent, nominated location, bound allocation, warm idle, frozen/snapshotted state, restore-in-progress, active residency, eviction, loss, and unknown residency stay separate from component identity, incarnation lineage, readiness, serving, custody, work fate, and effects without becoming a scheduler, autoscaler, warm-pool manager, checkpoint/restore API, migration protocol, or topology DSL; see `activation-residency-posture-v0.md`.

## D-ACTSTATEATTACH
How runtime scratch, tmp, projected material, managed runtime/state directories, sticky or persistent volumes, snapshot-derived bytes, detached state, cleanup, and unknown attachment truth stay separate from readiness, serving, current incarnation, custody, work fate, and effects without becoming a filesystem namespace API, volume manager, secret/config store, storage scheduler, checkpoint/restore protocol, or migration system; see `activation-state-attachment-posture-v0.md`.

## D-ACTMATERIALFRESHNESS
How config, secrets, tokens, trust bundles, leases, projected material, static injection, and restored runtime material report version, epoch, audience, expiry, renewal, revocation, reload, reacquire, and unknown freshness without becoming a vault, config store, workload identity plane, trust-bundle distributor, reload controller, or secret-rollout system; see `activation-material-freshness-posture-v0.md`.

## D-ACTPROBEVANTAGE
How startup, readiness, liveness, service-specific health, balancer target, mesh, and synthetic probe observations preserve observer, scope, target, freshness, thresholds, cache, and identity basis without becoming readiness, serving, policy, rollout, or incident truth; see `activation-probe-vantage-posture-v0.md`.

## D-ACTCONTROLVERDICT
How controller, balancer, rollout, DNS-health, deployment-circuit-breaker, mesh, and operator verdicts preserve issuer, subject, scope, basis, freshness, effect class, and state without becoming raw observations, readiness, serving, route authority, rollback completion, remediation success, or incident truth; see `activation-control-verdict-posture-v0.md`.

## D-REQACT
How an exact first request may activate a component without hardening a giant bus or focus-control plane; see `request-activation-posture-v0.md`.

## D-PRESENCE
How reviewed discoverable presence can be published, renewed, withdrawn, or allowed to expire without collapsing into readiness, serving truth, or a giant registry plane; see `presence-advertisement-posture-v0.md`.

## D-LAUNCHCTX
How reviewed component entry and restart baseline stay explicit instead of inheriting ambient shell/session folklore; see `launch-context-posture-v0.md`.

## D-LAUNCHBOUNDARY
How current possession, launch eligibility, selected-for-child delivery, and receipt-only history stay separate instead of collapsing into inheritance folklore; see `launch-boundary-posture-v0.md`.

## D-ACTMATERIAL
Open decision surface: what named activation material, credential delivery, runtime directory, namespace entry, and config receipt vocabulary belongs in portable Steward before real components force a capsule shape; see `non-decisions-v0.md` and `trajectory-map.md` OQ-0070.

## D-REQCTX
How exact request ids, optional deadlines, and explicit cancellation stay small and attributable without freezing a giant RPC metadata plane; see `request-context-posture-v0.md`.

## D-GRANTHANDLE
How pending requests, stop deferrals, capture sessions, and similar transient powers stay exact, closeable, and fail-closed instead of dissolving into sticky mode bits; see `grant-handle-posture-v0.md`.

## D-CONSUME
How some transient powers may be one-shot or use-bounded so stale chips, old receipts, or replay affordances cannot quietly spend them twice; see `consumable-grant-posture-v0.md`.

## D-EFFECTKEY
How reviewed non-commutative actions may collapse duplicate retries, reject mismatched key reuse, and stay smaller than a durable exactly-once plane; see `effect-key-posture-v0.md`.

## D-RETRYADVICE
How denials, cooldowns, or explicit pushback may carry an exact earliest-follow-up hint without hardening into a quota, retry-throttling, or giant retry-policy plane; see `retry-advice-posture-v0.md`.

## D-PRECOND
How reviewed actions may carry exact veto-only stale fences against runtime cycles, observation cursors, semantic epochs, or other explicit local witnesses without freezing a query language; see `precondition-witness-posture-v0.md`.

## D-RENEWAL
How live claims can carry compact renew-or-expire budgets without hardening into a generic lease, watchdog, or leader-election plane; see `renewal-window-posture-v0.md`.

## D-ATTENGRANT
How an exact live grant may derive a narrower helper or follow-on grant without exposing the parent raw or hardening into a generic token-exchange / delegation plane; see `attenuated-grant-posture-v0.md`.

## D-FENCETOKEN
How reassignable live claims can carry an optional stale-holder fence or current-owner witness without hardening into a distributed lock, leadership, or sequencer plane; see `fence-token-posture-v0.md`.

## D-HOLDERBIND
How some exact live grants can require current holder proof instead of behaving like replayable bearer material, without hardening into a portable proof-of-possession or key-management plane; see `holder-bound-grant-posture-v0.md`.

## D-FRESHINTENT
How some higher-risk or foreground-sensitive shell actions can require fresh local one-shot intent evidence without hardening into a trusted-UI, biometric, or wildcard-consent plane; see `fresh-intent-posture-v0.md`.

## D-DESCHYGIENE
How inherited handles, stdio, and control channels stay explicit instead of becoming the real contract through descriptor accidents; see `descriptor-hygiene-posture-v0.md`.

## D-EXGROUP
How one component run may map to one reviewed multi-process workload under the membrane without freezing PID trees, cgroup paths, or job handles into public meaning; see `execution-group-posture-v0.md`.

## D-AUTHNARROW
How reviewed authority reduction and lock-state honesty stay explicit without freezing a giant portable sandbox grammar; see `authority-narrowing-posture-v0.md`.

## D-TRANSITIONHELPERS
How short-lived lifecycle helpers stay attributable, bounded, and separate from the supervised long-lived leaf; see `transition-helper-posture-v0.md`.

## D-READY
How startup, readiness, and liveness stay distinct; see `readiness-posture-v0.md`.
How optional liveness evidence can stay separate from readiness, useful work progress, and watchdog policy; see `liveness-evidence-posture-v0.md`.

## D-PROGRESS
How Steward distinguishes active bring-up/reload progress from stalled intermediate state without freezing a giant timeout or rollout grammar; see `progress-window-posture-v0.md`.

## D-HOLDSTATE
How deliberate `paused`, `draining`, `frozen`, or `start-prevented` truth stays separate from `stalled`, `failed`, or ordinary `off` without freezing a giant maintenance or inhibit family; see `hold-state-posture-v0.md`.

## D-STARTGATE
How one attempted activation may be cleanly skipped, blocked, startup-shielded, or failed without flattening every non-start into crash folklore or a giant dependency planner; see `start-gate-posture-v0.md`.

## D-CONTROLOP
How one exact lifecycle operation request may queue, finish, skip, time out, or be removed without collapsing into steady component state or a controller-runtime; see `control-operation-posture-v0.md`.
How reviewed operation requests and receipts become closed ST-OPREQ / ST-OPRECEIPT packets with exact targets, stale fences, idempotency keys, request digest binding, recovery downgrade, and explicit non-implications; see `control-operation-request-schema-v0.md`, `control-operation-receipt-schema-v0.md`, and `../40-verification/control-operation-corpus-v0.md`.
How overlapping lifecycle requests may reject, queue behind, replace, flush, or create an irreversible floor without hardening a giant transaction planner; see `operation-arbitration-posture-v0.md`.

## D-ACTIVITY
How in-flight work, idle hints, and drain accounting stay explicit without pretending every runtime fits one idle model; see `activity-accounting-posture-v0.md`. Rev0200 settlement: ST-ACTBRACKET / ST-IDLEHINT / ST-STOPDEFER / ST-ACTACCT packets make this seam executable without creating a workflow lease, idle-stop authority, billing system, or drain-completion protocol.

## D-ACTBRACKET
How explicit begin/end in-flight-work brackets stay attributable, bounded, and revocable without turning into a generic keepalive or lease plane; see `activity-bracket-posture-v0.md`.

## D-STOPDEFERRAL
How short stop or quiesce grace windows stay live, attributable, and cuttable without becoming a generic inhibit plane; see `stop-deferral-posture-v0.md`.

## D-SHUTDOWNHORIZON
How terminating / draining-now / graceful-deadline / extended-stop truth stays separate from stop request, stop deferral, and later force cut-through; see `shutdown-horizon-posture-v0.md`.

## D-STOPPROGRESS
Open decision surface: what pending-stop checkpoint, wait-hint, kill-escalation, termination-status, and cleanup-finished receipts belong in portable Steward before this becomes a lifecycle workflow engine; see `non-decisions-v0.md` and `trajectory-map.md` OQ-0071.
The first executable settlement is `ST-QUIESCE v0`, `ST-DRAIN v0`, `ST-ESCALATE v0`, and `ST-TERMCAUSE v0`; see `quiesce-witness-schema-v0.md`, `drain-witness-schema-v0.md`, `escalation-witness-schema-v0.md`, `termination-cause-witness-schema-v0.md`, `../40-verification/shutdown-settlement-corpus-v0.md`, and `../../tools/steward_shutdown_harness.py`.

## D-WAKEMEMORY
Open decision surface: what future-wake, reminder, alarm, queued-trigger, and inactive-continuity truth belongs in portable Steward before this becomes a scheduler, actor runtime, hibernation VM, or durable workflow engine; see `wake-memory-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0075 through OQ-0077.

## D-ACTDEMAND-OPEN
Open decision surface: what per-demand cold-start, buffer, timeout, cancellation, delivery, and shed facts deserve portable names before Steward becomes a request queue, activator, proxy, autoscaler, or durable work system; see `activation-demand-episode-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0078.
The first executable settlement is `ST-DEMAND v0`; see `demand-episode-witness-schema-v0.md`, `../40-verification/demand-custody-effect-corpus-v0.md`, and `../../tools/steward_work_effect_harness.py`.

## D-ACTADMISSION-OPEN
Open decision surface: what per-attempt admitted / denied / deferred / narrowed / throttled / shed truth deserves portable names before Steward becomes a policy engine, quota wallet, admission-controller framework, autoscaler, or durable queue; see `activation-admission-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0079.

## D-ACTCUSTODY-OPEN
Open decision surface: what per-holder / per-handoff custody, acknowledgement, expiry, cancellation, redelivery, and duplicate-risk truth deserves portable names before Steward becomes a broker, service mesh, workflow engine, global ownership graph, or exactly-once delivery system; see `activation-custody-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0080.
The first executable settlement is `ST-CUSTODY v0`; see `custody-witness-schema-v0.md`, `../40-verification/demand-custody-effect-corpus-v0.md`, and `../../tools/steward_work_effect_harness.py`.

## D-ACTWORKDISPOSITION-OPEN
Open decision surface: what per-work acknowledgement, redelivery, expiry, dead-letter, discard, abandon, detach, duplicate-risk, and unknown-fate truth deserves portable names before Steward becomes a queue, redrive service, transaction coordinator, job-status API, or exactly-once side-effect plane; see `activation-work-disposition-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0081.
The first executable settlement is `ST-WORKDISP v0`; see `work-disposition-witness-schema-v0.md`, `../40-verification/demand-custody-effect-corpus-v0.md`, and `../../tools/steward_work_effect_harness.py`.

## D-ACTEFFECT-OPEN
Open decision surface: what local-commit, outbox, external-submit/accept/confirm, duplicate-suppression, mismatch, compensation, irreversible-floor, and unknown-effect truth deserves portable names before Steward becomes a transaction coordinator, saga engine, global idempotency ledger, or exactly-once side-effect plane; see `activation-effect-boundary-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0082.
The first executable settlement is `ST-EFFECT v0`; see `effect-boundary-witness-schema-v0.md`, `../40-verification/demand-custody-effect-corpus-v0.md`, and `../../tools/steward_work_effect_harness.py`.

## D-ACTINCARNATION-OPEN
Open decision surface: what incumbent / successor / predecessor / hot-restart-overlap / in-place-subcycle / replacement / clone-restore / stale-incarnation truth deserves portable names before Steward becomes a rollout controller, migration protocol, distributed lock, leader-election service, or global epoch sequencer; see `activation-incarnation-lineage-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0083.

## D-ACTRESIDENCY-OPEN
Open decision surface: what pending-placement / nominated / bound / resident / warm-idle / frozen / snapshotted / restoring / evicting / evicted / lost / topology-basis truth deserves portable names before Steward becomes a scheduler, autoscaler, warm-pool manager, checkpoint/restore API, migration protocol, or topology DSL; see `activation-residency-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0084.

## D-ACTSTATEATTACH-OPEN
Open decision surface: what scratch / tmp / projected config or secret / runtime directory / component data or cache / persistent volume / sticky or migrated disk / snapshot-derived / detached / cleanup truth deserves portable names before Steward becomes a filesystem namespace API, volume manager, secret/config store, storage scheduler, stateful workload controller, or checkpoint/migration system; see `activation-state-attachment-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0085.
The first executable settlement is `ST-STATEATT v0`; see `state-attachment-witness-schema-v0.md`, `../40-verification/currentness-control-corpus-v0.md`, and `../../tools/steward_currentness_control_harness.py`.

Open decision surface: what config/secret/token/trust-bundle freshness, expiry, renewal, revocation, version, audience, projection, reload, and after-restore reacquire truth deserves portable names before Steward becomes a vault, config store, workload identity plane, trust-bundle service, reload controller, or secret-rollout system; see `activation-material-freshness-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0086.
The first executable settlement is `ST-MATFRESH v0`; see `material-freshness-witness-schema-v0.md`, `../40-verification/currentness-control-corpus-v0.md`, and `../../tools/steward_currentness_control_harness.py`.

## D-ACTPROBEVANTAGE-OPEN
Open decision surface: what probe observer, scope, path/service, threshold, cached/stale result, balancer/client gating, identity-basis, and failure-hint truth deserves portable names before Steward becomes a health-check DSL, service mesh, load balancer, monitor, SLO engine, rollout controller, or incident system; see `activation-probe-vantage-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0087.
The first executable settlement is `ST-PROBE v0`; see `probe-vantage-witness-schema-v0.md`, `../40-verification/currentness-control-corpus-v0.md`, and `../../tools/steward_currentness_control_harness.py`.

## D-ACTCONTROLVERDICT-OPEN
Open decision surface: what controller, balancer, rollout, DNS-health, deployment-circuit-breaker, and operator verdict truth deserves portable names before Steward becomes a rollout controller, canary framework, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, or incident manager; see `activation-control-verdict-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0088.
The first executable settlement is `ST-CTRLVERDICT v0`; see `control-verdict-witness-schema-v0.md`, `../40-verification/currentness-control-corpus-v0.md`, and `../../tools/steward_currentness_control_harness.py`.

## D-ACTTRAFFICBINDING-OPEN
Open decision surface: what route, alias, service, gateway, proxy, DNS, target-group, tagged-test, weighted, mirrored, sticky, draining, propagation, topology-preference, stale, and unknown traffic-binding truth deserves portable names before Steward becomes a load balancer, service mesh, DNS failover system, Gateway API implementation, route compiler, canary framework, or rollout controller; see `activation-traffic-binding-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0089.
The first executable settlement is `ST-TBIND v0`; see `traffic-binding-witness-schema-v0.md`, `../40-verification/channel-binding-corpus-v0.md`, and `../../tools/steward_channel_binding_harness.py`.

## D-ACTLIVECHANNEL-OPEN
Open decision surface: what live connection, stream, subscription, watch, WebSocket, server-sent event, gRPC, drain, GOAWAY, close-handshake, cursor, resume, gap, duplicate, and force-close truth deserves portable names before Steward becomes a connection manager, transport API, RPC framework, pub/sub broker, watch service, stream multiplexer, reconnect scheduler, session-resumption plane, service mesh, or sticky-session grammar; see `activation-live-channel-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0090.
The first executable settlement is `ST-LIVECHAN v0`; see `live-channel-witness-schema-v0.md`, `../40-verification/channel-binding-corpus-v0.md`, and `../../tools/steward_channel_binding_harness.py`.

## D-ACTRETRYATTEMPT-OPEN
Open decision surface: what retry, replay, transparent retry, hedge, reconnect resend, early-data replay, pushback, budget, canonical-intent-match, maybe-applied, duplicate-risk, and abandonment truth deserves portable names before Steward becomes a retry engine, RPC framework, service mesh, broker, durable queue, quota service, workflow engine, distributed idempotency ledger, or exactly-once plane; see `activation-retry-attempt-posture-v0.md`, `non-decisions-v0.md`, and `trajectory-map.md` OQ-0091.
The first executable settlement is `ST-RETRYADVICE v0`, `ST-RETRYBUDGET v0`, `ST-RETRYATTEMPT v0`, and `ST-HEDGEFATE v0`; see `retry-advice-witness-schema-v0.md`, `retry-budget-witness-schema-v0.md`, `retry-attempt-witness-schema-v0.md`, `hedge-fate-witness-schema-v0.md`, `../40-verification/retry-settlement-corpus-v0.md`, and `../../tools/steward_retry_settlement_harness.py`.

## D-LIFECYCLEOBS
How Steward names and surfaces minimal lifecycle observations; see `lifecycle-observation-posture-v0.md`.

## D-STATUS
How compact current-state reporting stays separate from logs and receipts; see `status-channel-posture-v0.md`.

## D-STATUSBARRIER
How emitted status/checkpoint updates stay distinct from barrier-confirmed currentness without freezing a giant event bus or controller-runtime; see `status-barrier-posture-v0.md`.

How synced-through markers can admit whether they are stream-local, read-backed, barrier-backed, or degraded without overclaiming one giant freshness algebra; see `currentness-class-posture-v0.md`.

## D-FRESHNESS
How live observations, status hints, and shell chrome visibly decay when their anchors or renewals go stale; see `freshness-decay-posture-v0.md`.

## D-SUBSCRIBE
How bounded observation subscriptions can provide snapshot-plus-change views without polling or a hidden control bus; see `observation-subscription-posture-v0.md`.

## D-OBSCURSOR
How snapshot-plus-change views can resume from an exact opaque cursor or admit continuity loss honestly without freezing a giant event-log contract; see `observation-cursor-posture-v0.md`.

## D-PROVISIONAL
How shell/terminal UX may surface tentative local state and later confirmation without turning prediction into lifecycle truth; see `provisional-state-posture-v0.md`.

## D-ATTENTION
How shell/terminal attention hints stay focus-aware, freshness-scoped, and non-authoritative instead of devolving into bell/title folklore; see `attention-hint-posture-v0.md`.

## D-NOTIFY
How shell/terminal notifications, toast wakeups, and mark-alert style escalations stay exact-anchor-bound, focus-aware, and action-bounded instead of becoming a hidden approval path; see `notification-surface-posture-v0.md`.

## D-ATTNWATCH
How user-armed `watch this frame / receipt / run` flows stay exact-anchor-bound, expiring, and reveal-first without becoming a generic subscription bus, reminder plane, or hidden automation path; see `attention-watch-posture-v0.md`.

## D-CHROME
How shell/terminal status bars, badges, sticky headers, titles, and progress chrome stay observational, freshness-scoped, and separate from the canonical transcript; see `chrome-lane-posture-v0.md`.

## D-CMDGUIDE
How visible shell/terminal command guides, sticky headers, and scrollbar-mark style rails stay exact-frame-bound, filterable, and separate from transcript truth; see `command-guide-posture-v0.md`.

## D-LANDMARKS
How marks, annotations, alerts, and exact jump targets stay anchor-bound, provenance-labeled, and separate from transcript truth or ambient control; see `transcript-landmark-posture-v0.md`.

## D-CTXINHERIT
How tabs, splits, reruns, and action-launched shells inherit cwd or domain context only as explicit per-action choices instead of pane folklore; see `context-inheritance-posture-v0.md`.

## D-SPAWNSELECT
How tabs, splits, reruns, and helper shells choose reviewed program/profile/domain/cwd recipes instead of ambient `$SHELL`, profile, or pane folklore; see `spawn-selector-posture-v0.md`.

## D-COMPSHELL
How `shell into this component scope` stays a reviewed, expiring helper action over one exact target instead of ambient cwd, vague attach, or debugger folklore; see `component-shell-posture-v0.md`.

## D-SPAWNPALETTE
How command palettes and launcher menus expose reviewed spawn recipes, visible denials, and exact launch explanations without becoming an ambient command hole; see `spawn-palette-posture-v0.md`.

## D-SHELVES
How recent commands, directories, and Steward objects stay context-scoped, freshness-labeled, and non-authoritative instead of hardening remembered convenience into live truth; see `remembered-shelf-posture-v0.md`.

## D-WORKSNAP
How saved layouts, restored panes, reconnected processes, revived processes, and content-only restores stay visibly distinct and reviewable instead of collapsing into session folklore; see `workspace-snapshot-posture-v0.md`.

## D-REPLAY
How remembered, restored, and suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore; see `replay-gate-posture-v0.md`.

## D-ASSIST
How quick fixes, suggestion menus, and current-input help stay anchored, reviewable, and advisory instead of becoming an ambient second shell; see `assist-surface-posture-v0.md`.

## D-ASSISTRECEIPT
How one exact suggestion can explain why it appeared, which stronger anchor it binds to, and why stronger apply paths may be disabled without turning assist metadata into ambient authority; see `assist-receipt-posture-v0.md`.

## D-REPAIRCARD
How failed or blocked commands/components can surface one reviewable likely-next-fix card with exact anchors, disabled reasons, and honest downgrade instead of rerun folklore or auto-remediation; see `repair-card-posture-v0.md`.

## D-SURFDIAG
How shell/terminal affordances explain why they are enabled, degraded, denied, or stale instead of behaving like magic; see `surface-diagnostics-posture-v0.md`.

## D-STATEEXPLAIN
How exact frames, runs, requests, or repair gates can answer `why waiting / blocked / repair-required / rebind-required` over one stronger anchor without becoming a diagnosis empire or workflow engine; see `state-explainer-posture-v0.md`.

## D-AUTOMATION
How scripts, hooks, remote-control APIs, and helper CLIs stay exact-targeted, permissioned, and inspectable instead of becoming an ambient second control plane; see `automation-surface-posture-v0.md`.

## D-SESSIONINJECT
How UI-originated commands, environment bundles, and similar session changes stay explicit, staged, history-aware, and policy-bounded instead of becoming ambient shell folklore; see `session-injection-posture-v0.md`.

## D-INJECTRECEIPT
How one reviewed insert / replace / env-load mutation can leave one exact shell-visible receipt over what changed without confusing session mutation with later execution truth; see `injection-receipt-posture-v0.md`.

## D-INPUTSURF
How keyboard encodings, composed text, modal key tables, prompt-local input affordances, and injected bytes stay explicit and policy-bounded instead of collapsing into terminal folklore; see `input-surface-posture-v0.md`.

## D-CLIPBOARD
How copy, paste, and remote clipboard flows stay exact, provenance-labeled, and policy-bounded instead of becoming ambient terminal folklore; see `clipboard-surface-posture-v0.md`.

How pasted payloads can be previewed, staged, literalized, or denied with visible reasons instead of masquerading as typed fresh intent or being silently rewritten; see `paste-firewall-posture-v0.md`.

## D-TRANSFER
How uploads, downloads, remote-file actions, and drag/drop handoff stay exact, direction-labeled, and policy-bounded instead of becoming ambient path folklore; see `transfer-surface-posture-v0.md`.

## D-MEDIASURF
How inline images, plots, doc previews, and background media stay exact-targeted, budgeted, and clearly separate from transfer/open folklore; see `media-surface-posture-v0.md`.

## D-LINKSURF
How detected text, declared hyperlinks, semantic file links, and exact object opens stay provenance-labeled, action-bounded, and clearly separate from generic open folklore; see `link-surface-posture-v0.md`.

## D-RETENTION
How persisted command, directory, paste, and host/user memory stays scopeable, erasable, and clearly remembered instead of becoming ambient retained authority; see `retention-surface-posture-v0.md`.

## D-CYCLE
How concrete runtime cycles may carry an opaque witness for attribution and stale-action fences; see `runtime-cycle-witness-posture-v0.md`.

## D-CONTROLTARGET
How lifecycle stop/restart/quiesce/explain actions bind to explicit component and concrete-run targets instead of PID, pane, or jobs-table folklore; see `control-target-posture-v0.md`.

## D-ISLAND
How shallow ownership islands can scope containment, activation, and exact lifecycle targeting without freezing a giant realm, topology, or discovery language; see `ownership-island-posture-v0.md`.

## D-ACTCAUSE
How Steward observes and explains why one concrete runtime cycle began without freezing a giant causal graph or dependency algebra; see `activation-cause-posture-v0.md`.

## D-TERMCAUSE
How Steward observes and explains why one concrete runtime cycle ended without freezing a giant fault taxonomy; see `termination-cause-posture-v0.md`. The closed packet settlement is `termination-cause-witness-schema-v0.md`.

## D-REPAIR
How repeated-failure cooldown and repair-required quieting stay explicit without freezing a giant retry-policy language; see `repair-gate-posture-v0.md`.

## D-RESTARTBUDGET
How automatic restart admissions stay bounded, windowed, and separate from repair-gate state, root-cause diagnosis, and timer folklore; see `restart-budget-posture-v0.md`.

## D-EXITDISPOSITION
How one runtime cycle's end meaning stays separate from retry eligibility, ignored disruptions, and broader work-unit failure without freezing a giant recovery taxonomy; see `exit-disposition-posture-v0.md`.
How durable future activation policy such as `manual`, `auto`, `auto-delayed`, `disabled`, or stronger start prohibition stays separate from current liveness, hold state, and activation cause without freezing a boot/install grammar; see `enablement-intent-posture-v0.md`.
How durable baseline activation intent, temporary runtime/operator overlays, and state-scoped verb admission compose into one effective activation answer without freezing a giant precedence stack; see `activation-overlay-posture-v0.md`.

## D-QUIESCE
How cooperative drain/gating works; see `quiesce-posture-v0.md`. The closed packet settlement is `quiesce-witness-schema-v0.md`.

## D-SHELLTERM
How shell and terminal exchange semantic lifecycle metadata; see `shell-terminal-integration-posture-v0.md`.
How weaker parsed structure over transcript/output can remain candidate-only, provenance-labeled, and clearly weaker than exact shell objects; see `parse-lens-posture-v0.md`.

## D-CMDFRAME
How explicit command-frame observations stay useful without becoming a control bus; see `command-frame-posture-v0.md`.

## D-CURRENTCMD
How the exact editable command beside the live prompt can be revealed, copied, diffed, or assisted without pane-wide guessing or transcript folklore; see `current-command-posture-v0.md`.

## D-COMMANDPATCH
How one reviewable mutation over one stronger command anchor can stay distinct from the source command, proposal lane, and later launched command without freezing a shell-rewrite family; see `command-patch-posture-v0.md`.

## D-PROMPTLEASE
How the current editable shell prompt can be an exact expiring object without turning transcript text into ambient authority; see `prompt-lease-posture-v0.md`.

## D-CONFIDENCE
How shell/terminal observations carry compact confidence, provenance, and trusted-ness without pretending every marker is equally exact; see `observation-confidence-posture-v0.md`.

## D-GROUND
How panes and command frames may show tiny truthful ground summaries without turning chrome, remembered context, or foreground ownership into lifecycle authority; see `execution-ground-posture-v0.md`.

## D-ATTACHLANES
How observe-only witness mode, interactive attach, lifecycle control, and debug entry stay visibly different lanes instead of one vague attached state; see `attach-lane-posture-v0.md`.

## D-ATTACHCONTINUITY
How reconnecting, resumed witness, expired, replaced, and lost attach truth stay separate from service lifecycle and silent retargeting; see `attach-continuity-posture-v0.md`.

## D-PROPOSALLANE
How agent/chat/notebook proposal work stays visibly weaker than exact shell input, reviewed execution, and canonical lifecycle transcripts; see `proposal-lane-posture-v0.md`.

## D-APPROVALRUNGS
How proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion stay visibly different powers with policy floors and honest downgrade; see `approval-rung-posture-v0.md`.

## D-EXCEPTIONWITNESS
How bypass-under-review, waived-under-expiry, and satisfied-gate truth stay visibly different without hardening into a giant waiver, break-glass, or policy-workflow family; see `exception-witness-posture-v0.md`.

## D-HEADROOM
How allowed, approved, and ready stay visibly separate from currently spendable restart / quota / rate-window headroom without hardening into a giant quota or wallet family; see `headroom-witness-posture-v0.md`.

## D-HISTORYLANE
How unified remembered search can span typed history, reviewed inserts, workflows, notebook blocks, and proposal memory without flattening them into one canonical execution record; see `history-lane-posture-v0.md`.

## D-PREFLIGHT
How explain, diff, speculative preview, reviewed saved plan, and apply stay visibly different moves with exact footing and honest stale/denied outcomes; see `preflight-lane-posture-v0.md`.

## D-PENDINGREQUEST
How one in-flight chooser/open/approval detour stays visible, cancelable, and attributable in the shell without freezing a generic callback or portal-object family; see `pending-request-posture-v0.md`.

## D-DETOUROUTCOME
How a completed chooser/open/auth/approval detour lands as one typed shell-visible result without confusing finished outcome, pending request, live grant, or return ticket truth; see `detour-outcome-posture-v0.md`.

## D-RETURNTICKET
How browser/auth/chooser detours return to the shell as exact expiring local hints without turning callback or focus folklore into lifecycle truth; see `return-ticket-posture-v0.md`.

## D-REVISIONSETTLEMENT
How reviewed desired revision, current observed revision, and last settled/stable revision stay visibly different without freezing a giant rollout controller; see `revision-settlement-posture-v0.md`.

## D-STABILITY
How `ready now` and `stable enough to admit or advance` stay distinct without freezing a rollout planner or health algebra; see `stability-window-posture-v0.md`.

## D-ACTIONS
How explicit shell/terminal action surfaces stay user-invoked, target-bound, and stale-fenced instead of becoming hidden ambient control; see `action-surface-posture-v0.md`.

## D-ANCHORS
How explicit shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without visible-text scraping or raw-capability leakage; see `target-anchor-posture-v0.md`.

## D-OUTPUTSLICE
How one exact command-output region can stay bounded, provenance-labeled, and reusable for copy / handoff / explain without turning nearby text or rich rendering into authority; see `output-slice-posture-v0.md`.

## D-COMMANDVERDICT
How one exact command result can stay compact, anchor-bound, and separate from full evidence or transcript guesswork so decorations, watches, and last-failure flows stay honest; see `command-verdict-posture-v0.md`.

## D-COMMANDEVIDENCE
How one exact command interaction can be packaged as bounded evidence for attach / explain / escalation without exporting whole scrollback or confusing evidence with authority; see `command-evidence-posture-v0.md`.

## D-EVIDENCEDRAFT
How one outbound reviewed subset can preserve provenance while trimming, masking, or briefly annotating exact evidence before attach / share / escalation without mutating source truth or becoming a workflow family; see `evidence-draft-posture-v0.md`.

## D-HANDOFF
How explicit command/context handoff stays bounded, exact when possible, and separate from ambient whole-scrollback sharing; see `context-handoff-posture-v0.md`.

## D-EPOCH
How shell/terminal observations and affordances admit “that belonged to an older semantic world” after hops, restarts, or resync; see `semantic-epoch-posture-v0.md`.

## D-HOPLINEAGE
How shell/terminal semantics can stay explicitly scoped to the actual remote/multiplexer path instead of a flat PTY fiction; see `hop-lineage-posture-v0.md`.

## D-CAPLEDGER
How pane/hop-scoped semantic support stays recorded, refreshable, and distinct from desired UX or remembered folklore; see `capability-ledger-posture-v0.md`.

## D-FENCES
How shell/terminal layers admit precision loss, capability drift, and resync boundaries instead of silently preserving stale certainty; see `precision-fence-posture-v0.md`.

## D-MODEBASE
How shell/terminal prompt-critical modes can return to a small known baseline or surface visible repair needs instead of relying on folklore and manual `reset` rituals; see `mode-baseline-posture-v0.md`.

## D-TRANSIENT
How long-running shell work may be promoted into transient Steward-tracked objects without freezing a giant transient-unit language; see `transient-promotion-posture-v0.md`.

## D-SERVESTATE
How `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, and `not serving` stay visibly separate from process liveness, readiness folklore, and discoverability without hardening into a giant traffic or service-mesh family; see `serve-state-witness-posture-v0.md`.

## D-PRESSURE
How scoped `ok` / `some` / `full` / `warning` / `critical` pressure truth stays visibly separate from serving mode, headroom, and failure without hardening into a giant autoscaling, scheduler, or reclaim-policy family; see `pressure-witness-posture-v0.md`.

## D-BACKPRESSURE
How `queued`, `retry-after`, `shed`, and `stop-accepting` truth stays visibly separate from pressure, headroom, and failure without hardening into a giant overload, fair-queuing, or traffic-shaping family; see `backpressure-witness-posture-v0.md`.

## D-ADAPTATION
How cache trim, reduced concurrency, optional-work deferral, and other protective response truth stays visibly separate from pressure, backpressure, and vague degraded folklore without hardening into a giant brownout, autoscaling, or remediation-policy family; see `adaptation-witness-posture-v0.md`.

## D-PROOFSLICE
How a small executable corpus becomes the first falsifiable Steward proof surface without pretending to verify a full implementation; see `../40-verification/minimum-steward-proof-slice.md` and `../40-verification/component-lifecycle-activation-corpus-v0.md`.

## D-SCHEMACANON
How CH-COMP and CH-ACTSET authority objects stay closed-world, duplicate-key-rejecting, and digest-stable instead of drifting as prose-only contracts; see `canonical-json-profile-v0.md`, `component-manifest-schema-v0.md`, and `activation-set-schema-v0.md`.

## D-SLOPOSBOUNDARY
How Steward acts as SlopOS companion and lifecycle witness fabric without strengthening or re-defining SlopOS primitive truth; see `slopos-boundary-crosswalk-v0.md`.

## D-COMPANIONS
How Steward keeps lifecycle-critical shell, desktop, boundary, trust, storage, and realization seams while leaving richer ownership to Schell, Helm, Harbor, Ward, ViewFS, Foundry, and SlopOS; see `companion-boundary-map-v0.md`.

## D-LIFECURRENT
How identity, activation, lifecycle, demand, effect, condition, retry-attempt, and human-surface witnesses relate without accidental implication; see `lifecycle-currentness-lattice-v0.md`.

## D-ADAPTERMEMBRANE
How systemd, Kubernetes, Envoy, NATS, and other host facts remain weak adapter observations unless promoted through Steward-native schemas or receipts; see `adapter-membrane-posture-v0.md`.

## D-MANAGERRECOVERY
How Steward restart, reconciliation, and lost present-tense observations degrade to explicit unknowns without treating host reconstruction as native lifecycle truth; see `manager-recovery-reconciliation-posture-v0.md`.

## D-TIMEDEADLINE
How monotonic deadlines, wall-clock protocol fields, issuer time, freshness windows, retry hints, and stop/drain budgets stay visibly different; see `time-and-deadline-posture-v0.md`.

## D-RECEIPTMIN
How lifecycle and activation receipts preserve proof-critical footing while redacting raw handles, tokens, descriptor numbers, command bodies, and host-private material by construction; see `receipt-minimization-posture-v0.md`.

## D-ADMINSURFACE
How the first Steward admin surface remains observe-first and exact-target-bound, with mutating requests returning receipts instead of becoming ambient PID/unit/pane control; see `admin-surface-posture-v0.md`.

## D-FREEZELATE
What Steward should intentionally leave unfrozen while SlopOS is still moving; see `non-decisions-v0.md`.

## Open questions
- OQ-0001 through OQ-0095 in `docs/00-meta/trajectory-map.md`.

## Revision 190 settled packet seam — governance authorization

Settled for v0: Steward may require a closed authorization-check packet before a lifecycle operation is executed. That packet can cite scoped delegation, review, and approval witnesses, and the corpus verifies that allowed authorization requires matching digest, delegatee, verb, component, runtime-cycle, freshness, and approval state.

Still open: how a product UI obtains approvals, how Ward represents stewardship charters, how on-call or owner-map systems feed warrants, how emergency break-glass is reviewed after the fact, and whether operation receipts should require an `ST-AUTHCHECK v0` ref for all mutating verbs or only higher-risk verbs.

## D-IMPORTRECONCILE
How imported evidence from recovery, sibling handoff, audit replay, support return, or adapter dump can be observed, appraised, mapped, quarantined, or attached as weak basis without becoming authority, currentness, freshness, readiness, serving, operation execution, or effect success; see `import-reconciliation-posture-v0.md`.

## Revision 192 settled packet seam — import reconciliation

Settled for v0: Steward may accept imported evidence only through closed import-observation, source-appraisal, reconciliation-plan, and reconciliation-decision packets. Weak-basis adoption requires a ready plan, weak source appraisal, released import, local witness requirements, and explicit non-implications.

Still open: which UI should show import quarantine, how long weak-basis attachments remain visible, which sibling cubes can produce importable evidence by default, and whether future adapter golden traces should emit ST-IMPORT directly or feed receipt transport first.

## D-LOCALOBS
How host-manager, orchestrator, adapter, shell, watcher, and observation-cursor evidence can be recorded, appraised, attached, quarantined, or converted into recheck pressure without becoming authority, currentness, freshness, readiness, serving, operation execution, demand drain, lossless continuity, or effect success; see `local-observation-provenance-posture-v0.md`.

## Revision 193 settled packet seam — local observation provenance

Settled for v0: Steward may record local observations only as closed local-observation, observation-appraisal, observation-cursor, and observation-attachment packets. Weak-basis attachment requires appraisal and at least one non-observation native witness requirement before any stronger lifecycle use.

Still open: which adapter golden fixtures should be first, how UI witness cards should render weak observation caveats, how long weak attachments remain visible, and which host/runtime samples should be discarded before packetization.


## D-WITSURFACE
How rendered witness cards, action affordances, status barriers, and surface audit/refactor receipts expose lifecycle evidence without strengthening it; see `witness-surface-posture-v0.md`.

## Revision 194 settled packet seam — witness surfaces and audit/refactor

Settled for v0: Steward may render lifecycle evidence through closed witness-card, action-affordance, status-barrier, and surface-audit packets. Mutating affordances must stay exact-target-bound, review-bound, authcheck-aware, stale-fenced, and visibly disabled when active barriers apply. Audit/refactor packets can name findings, required changes, and changed refs, but cannot claim a fix, release, proof of correctness, operation execution, or lifecycle authority.

Still open: which concrete product UI renders the cards, how witness cards compose across sibling cubes, how much surface audit should be shown to operators, and whether future release-provenance fixtures should get their own packet family or stay as receipt-transport/import-reconciliation pressure.
## D-STATUSCHANNEL
How bounded observation subscriptions, delivery batches, sync markers, and gap barriers let UIs follow Steward without creating a hidden event bus, hidden mutation channel, or current-state oracle; see `status-channel-proof-posture-v0.md`.

## Revision 195 settled packet seam — status channel and harness registry

Settled for v0: Steward may expose observation subscription transport only through closed subscription, delivery, sync-marker, and gap-barrier packets. Deliveries and sync markers are exact-view observation transport facts, not readiness, serving, global currentness, quiescence, lossless continuity, operation execution, or effect-success proof.

Still open: which concrete transport should carry the packets, how much UI should show gap barriers, whether status-channel snapshots should use the same affordance rendering bundle as witness cards, and which adapter golden traces should pressure stream overflow first.

## Decision: attention notification packets stay weak

`ST-ATTNHINT`, `ST-ATTNWATCH`, `ST-NOTICE`, and `ST-ATTNACK` may help surfaces wake or reveal exact anchors, but they do not prove user-seen, user-read, approval, authorization, execution, resolution, currentness, readiness, serving, or effect success. Mutating notification actions remain out of scope.
- rev0197 promoted coordination-gate packets: preconditions, arbitration, holds, and progress windows are executable evidence but not authorization, execution, readiness, serving, currentness, operation result, or effect success.

## D-ROLLOUTGEN
How generation plans, reconfiguration apply attempts, scoped generation readiness, and promotions or rollbacks stay separate from material freshness, reload success, serving, traffic truth, rollback success, work completion, and effect success; see `rollout-generation-proof-posture-v0.md`.

## Revision 198 settled packet seam — rollout generation

Settled for v0: Steward may represent generation rollout movement through closed generation-plan, reconfiguration-apply, generation-readiness, and promotion packets. Applied promotion requires scoped ready evidence and a traffic-binding ref, but still does not prove serving, drain, lossless transition, rollback success, work completion, or external effect success.

Still open: which concrete adapter golden traces should come first, how product UI should render generation chains, whether readiness generation should cite control-verdict packets directly or only probe refs, and how sibling deployment/release systems should hand off without making Steward a rollout controller.

## D-PRESSUREADMISSION
How scoped pressure, spendable headroom, new-work backpressure, and admission-gate decisions remain useful weak evidence without becoming failure, authority, demand acceptance, execution, readiness, serving, or effect success; see `pressure-admission-proof-posture-v0.md`.

## Revision 199 settled packet seam — pressure admission

Settled for v0: Steward may represent pressure, headroom, backpressure, and one admission-gate decision through closed packets. Gate allow requires non-contradictory basis; non-allow decisions must not claim demand acceptance.

Still open: which concrete adapters should emit the first pressure packets, whether UI should group pressure/headroom/backpressure cards, how long pressure evidence should remain visible after expiry, and whether later resource policy belongs in Steward or a sibling cube.

## D-DEPENDENCYGATE
How dependency declarations, dependency checks, dependency-informed lifecycle gates, and fallback/degraded-mode witnesses stay separate from topology authority, start order, readiness, serving, failure, operation execution, work completion, repair, rollback success, and effect success; see `dependency-gate-proof-posture-v0.md`.

## Revision 201 settled packet seam — dependency gates

Settled for v0: Steward may represent dependency gating through closed dependency-spec, dependency-check, dependency-gate, and dependency-fallback packets. Allow decisions require non-stale available hard-dependency checks; degrade decisions require an active fallback witness.

Still open: which concrete adapters should emit the first dependency check packets, how product UI should group dependency gates with pressure/admission and currentness/control cards, and whether future topology summaries should remain ViewFS/Ward/SlopOS pressure instead of becoming Steward API.
