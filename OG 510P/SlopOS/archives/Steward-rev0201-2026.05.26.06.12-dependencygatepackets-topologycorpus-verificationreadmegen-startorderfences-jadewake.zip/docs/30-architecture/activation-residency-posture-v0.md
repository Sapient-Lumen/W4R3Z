# Activation-residency posture v0

Purpose: name the smallest useful truth for **where or how a concrete activation incarnation is resident, reserved, warm, frozen, restored, evicting, evicted, lost, or unknown** without confusing that truth with component identity, incarnation lineage, admission, readiness, serving, custody, work disposition, side-effect completion, or checkpoint/migration folklore.

This seam is intentionally small. It does **not** invent a scheduler, autoscaler, warm-pool manager, checkpointer, live-migration protocol, topology authority, placement DSL, or universal hibernation VM. It answers one narrower question: **when the substrate can explain the residency state of an activation incarnation, what compact witness keeps Steward from treating placement, warmth, freeze, restore, or eviction as proof of service?**

## Posture
1. **Residency is not component identity or incarnation lineage**
   - Component identity answers which reviewed component is meant.
   - Incarnation lineage answers which concrete run/replacement/restore relation is being observed.
   - Residency answers whether that incarnation is pending placement, nominated, bound to a pool or node, initializing, warm idle, frozen, snapshot-derived, restoring, active, evicting, evicted, lost, or unknown.
   - Steward should not let a node name, allocation id, warm instance, snapshot id, or pool label silently stand in for identity or incarnation currentness.

2. **Placement intent, nomination, binding, and actual residency are different claims**
   - A requested placement constraint, preferred affinity, nominated node, bound allocation, and observed running location have different proof strength.
   - `nominated` is useful only if it is clearly weaker than `bound` or `resident`.
   - `bypass-scheduler` or direct host targeting should be visible as a risky basis, not hidden as ordinary placement truth.

3. **Warm idle is not readiness, serving, or durable work custody**
   - A warm or provisioned instance may reduce first-request latency, but it does not prove the component is ready for the relevant demand, currently serving, holding a specific obligation, or able to complete a future effect.
   - A warm instance can also be stale, policy-clamped, CPU-throttled, shutdown-eligible, or reserved for a different concurrency lane.
   - Steward should allow `warm-idle`, `preinitialized`, or `reserved` while still requiring readiness, admission, custody, and effect-boundary witnesses where those facts matter.

4. **Frozen or snapshotted is not ordinary continuity**
   - Freeze preserves some local state while external time, credentials, sockets, files, peers, clocks, randomness, and topology may have changed.
   - A snapshot template can create fast restore without proving that all old local assumptions are safe.
   - Steward should carry `freeze_basis`, `snapshot_template`, `restore_basis`, and `after_restore_check` style fields when available rather than treating thaw/restore as a normal start or a normal uninterrupted run.

5. **Restore ancestry should be explicit and scoped**
   - A restored incarnation may share heap, disk, cache, configuration, or initialized libraries with a template or predecessor.
   - That ancestry can be useful for debugging and performance, but it can also duplicate nonces, old connection state, old leases, or stale credential assumptions.
   - Residency witnesses should be able to name `template_id`, `snapshot_id`, `restore_generation`, or `restore-unknown` without becoming the whole checkpoint/restore API.

6. **Eviction and loss are residency fates, not proof of work fate**
   - A component can be evicted, preempted, node-lost, reclaimed, or migrated away while admitted work remains unknown, redeliverable, externally effected, or still held by some other custodian.
   - Steward should report `evicting`, `evicted`, `preempted`, `lost`, `reclaimed`, or `residency-unknown` separately from custody/disposition/effect truth.
   - Recreating a new resident incarnation should not silently mark old work as failed, completed, or safe to retry.

7. **Locality and topology are evidence, not ambient authority**
   - Node, pool, zone, region, accelerator, storage-locality, and trust-domain labels can be useful for policy and debugging.
   - Their authority depends on who asserted them and when they were observed.
   - Steward should prefer scoped fields such as `placement_basis`, `topology_basis`, `observed_by`, `current_as_of`, and `proof_strength` over treating labels as self-authenticating host truth.

8. **Residency should be attributed to one incarnation and one source**
   - A witness should bind to `component_id` and, where available, `incarnation_id` or `runtime_cycle_witness`.
   - It should also name the source: scheduler, supervisor, runner, platform, checkpoint manager, warm-pool manager, or observer.
   - If only the logical component is known, the honest state is `residency-unknown-for-incarnation`, not `the current run is here`.

9. **Residency currentness must decay**
   - Placement and warm-state observations can go stale quickly under autoscaling, draining, preemption, and maintenance.
   - A useful witness should include `observed_at`, optional `current_as_of`, optional `expires_or_recheck_by`, and a downgrade path to `last-known` or `unknown`.
   - This complements observation cursors and freshness decay; it should not become a global scheduler cache.

10. **Phase 1 shape is a witness, not a control plane**
    - A tentative `activation_residency` witness can stay tiny: `component_id`, optional `incarnation_id`, optional `runtime_cycle_witness`, `residency_state`, `basis`, optional `placement_basis`, optional `resident_location`, optional `pool_or_topology_class`, optional `warm_reason`, optional `snapshot_or_template_id`, optional `restore_basis`, optional `eviction_reason`, optional `observed_at`, optional `expires_or_recheck_by`, optional `proof_strength`, and optional `unknown_reason`.
    - Field names remain provisional until real Steward components show which facts must travel across membranes.

## Phase-1 non-goals
- a scheduler, autoscaler, placement solver, topology-spread language, or node-affinity DSL;
- a universal warm-pool, provisioned-concurrency, zygote, or preinitialization manager;
- a checkpoint/restore, live-migration, hibernation, or CRIU-like control API;
- a topology authority, trust-label system, node inventory, or device-allocation model;
- using node names, allocation ids, pod names, warm-instance ids, or snapshot ids as stable component identity;
- deriving admission, readiness, serving, custody, work disposition, or side-effect fate from residency alone.

## Adjacent docs
- `activation-incarnation-lineage-posture-v0.md`
- `wake-memory-posture-v0.md`
- `activation-admission-posture-v0.md`
- `activation-demand-episode-posture-v0.md`
- `activation-custody-posture-v0.md`
- `activation-work-disposition-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `readiness-generation-posture-v0.md`
- `stability-window-posture-v0.md`
- `progress-window-posture-v0.md`
- `hold-state-posture-v0.md`
- `pressure-witness-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-ASSIGN-PODS-TO-NODES
- REF-NOMAD-ALLOCATION-PLACEMENT
- REF-CLOUD-RUN-CONTAINER-CONTRACT
- REF-AWS-LAMBDA-RUNTIME-LIFECYCLE
- REF-AWS-LAMBDA-EXTENSIONS-API
- REF-OPENJDK-CRAC
