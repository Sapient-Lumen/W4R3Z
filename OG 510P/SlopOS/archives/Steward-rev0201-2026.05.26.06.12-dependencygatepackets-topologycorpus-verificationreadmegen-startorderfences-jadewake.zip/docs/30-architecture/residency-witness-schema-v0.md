# Residency witness schema v0

## Purpose
`ST-RESIDENCY v0` is the first closed packet for one Steward residency witness. It reports placement, nomination, binding, initialization, warm idle, frozen, restoring, active, evicting, evicted, lost, or unknown residency for a component incarnation or runtime cycle without turning topology or warmth into service truth.

The central rule: **resident, warm, frozen, or restored is not ready, serving, current incarnation, admission, custody, work completion, scheduler authority, or effect success.**

## Machine profile
- Machine profile: `../../schemas/st-residency-v0.schema.json`
- Checker: `../../tools/steward_lineage_resume_harness.py`
- Corpus: `../40-verification/corpora/lineage-resume-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-RESIDENCY v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the scheduler, runtime, adapter, platform, observer, or Steward source |
| `residency_id` | scoped residency witness id matching `res_[a-z0-9]{16}` |
| `residency_state` | `requested`, `nominated`, `bound`, `initializing`, `warm_idle`, `frozen`, `restoring`, `active`, `evicting`, `evicted`, `lost`, or `unknown` |
| `basis_kind` | `scheduler`, `supervisor`, `runner`, `adapter`, `warm_pool`, `checkpoint_manager`, `platform`, `observer`, or `unknown` |
| `proof_strength` | `steward_native`, `substrate_native`, `adapter_observed`, `operator_claim`, `last_known`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `basis_refs` | bounded evidence refs supporting the witness |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `incarnation_id`, `runtime_cycle`, `location_ref`, `pool_ref`, `topology_ref`, `snapshot_ref`, `restore_ref`, `warm_reason`, `eviction_reason`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Required non-implications
A valid packet must include:

- `not-readiness`
- `not-serving`
- `not-incarnation-currentness`
- `not-admission`
- `not-custody`
- `not-work-completion`
- `not-effect-success`
- `not-scheduler-authority`

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Raw node, allocation, pod, container, PID, unit, path, handle, token, and secret fields reject.
- Concrete residency states require `incarnation_id` or `runtime_cycle`.
- `nominated`, `bound`, `warm_idle`, and `active` require scoped `location_ref` or `pool_ref`.
- `frozen` and `restoring` require `snapshot_ref` or `restore_ref`.
- `evicted` and `lost` require `eviction_reason`.
- `unknown` requires `unknown_reason`.
- `expires_or_recheck_by_ms` cannot precede `observed_at_ms`.

## Rejected surfaces
The corpus rejects:

- host pod names and node/allocation-style raw identifiers;
- active residency without incarnation or cycle fence;
- frozen residency without restore ancestry;
- active residency being promoted into readiness.

## Non-goals
- no scheduler, autoscaler, warm-pool manager, topology authority, node inventory, checkpoint manager, migration protocol, or hibernation VM;
- no using residency as admission, readiness, serving, custody, work, or effect truth;
- no portable host-location authority beyond scoped evidence refs.

## Adjacent docs
- `activation-residency-posture-v0.md`
- `runtime-cycle-witness-schema-v0.md`
- `incarnation-lineage-witness-schema-v0.md`
- `activation-state-attachment-posture-v0.md`
- `resume-reconciliation-witness-schema-v0.md`
- `canonical-json-profile-v0.md`
