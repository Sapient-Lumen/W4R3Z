# Exit-disposition posture v0

Purpose: define a **tiny exit-disposition seam** so **how one runtime cycle ended** stays separate from **what policy should do next**.

This seam is intentionally small. It does **not** design a universal retry grammar, giant recovery policy language, or workflow controller. It only says Steward should be able to answer a narrower question honestly: **was this end treated as clean, retry-eligible, ignorable for budget purposes, or terminal for the broader work unit?**

## Posture
1. **End cause and next-step disposition are different truths**
   - `requested stop`, `clean completion`, `signal/crash`, `timeout`, `policy kill`, or `unknown` describe *how* a run ended.
   - `retry`, `do not retry`, `ignored for budget`, `fail work unit`, or `clean stop` describe *what that ending means for policy*.
   - Steward should not flatten those into one vague `failed` bit.

2. **A non-zero or unusual exit does not always mean the same thing**
   - Some systems explicitly treat selected exit statuses or signals as clean termination.
   - Others treat selected failures as reasons to stop retrying, or as reasons to fail the larger work unit immediately.
   - Steward should leave room for that honesty without standardizing every host-specific exit catalog.

3. **Expected interruption and external disruption should stay separate from software bug retries**
   - Operator-requested stop, graceful completion, and host/platform disruption often deserve different retry-budget meaning from an ordinary crash or logic bug.
   - If an adapter can prove that distinction, Steward should preserve it.

4. **Main-run disposition is different from helper or side-effect disposition**
   - Start/stop helpers, post-stop cleanup, adjunct helpers, and the accountable long-lived main run are different lifecycle actors.
   - A helper failure may matter, but it should not silently overwrite the main run's own end/disposition truth.

5. **Budget accounting should be able to ignore some endings**
   - A repair budget or retry window is healthier when it can say `ignored disruption`, `does not spend restart budget`, or `counted against retry budget`.
   - Steward should not force every non-success ending to spend the same budget.

6. **Permanent no-retry should be nameable without pretending the component is permanently dead**
   - `won't auto-retry until reviewed`, `completed`, or `larger work unit failed` are different from `currently retrying`.
   - Steward should preserve that distinction instead of teaching one fake crash-loop story.

7. **Phase 1 should keep the portable vocabulary compact**
   - A healthy early shape is one optional compact disposition such as `clean-stop`, `clean-complete`, `retry`, `no-retry`, `ignored`, `fail-unit`, or `unknown`, plus an optional exact termination-cause witness when the adapter can prove it.
   - Rich exit-code taxonomies, giant retry-policy languages, and universal recovery ladders remain intentionally undecided.

## Explicit non-goals
- standardizing every exit code or signal name across hosts;
- promising that every adapter can classify disruption, clean completion, and retryability equally well;
- turning helper exit codes into the public meaning of the main service lifecycle;
- forcing batch-job, daemon, and transient-helper semantics into one giant portable taxonomy;
- replacing restart-budget, repair-gate, or termination-cause seams with one overstuffed `result` blob.

## Adjacent docs
- `termination-cause-posture-v0.md`
- `restart-budget-posture-v0.md`
- `repair-gate-posture-v0.md`
- `start-gate-posture-v0.md`
- `transition-helper-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `enablement-intent-posture-v0.md`
- `activation-overlay-posture-v0.md`
- `state-explainer-posture-v0.md`

## References
- REF-SYSTEMD-SERVICE
- REF-LAUNCHD-SOCKETS
- REF-WINDOWS-SERVICE-FAILURE-ACTIONS
- REF-K8S-JOBS
- REF-K8S-POD-FAILURE-POLICY
- REF-ERLANG-OTP-SUPERVISOR
- `activation-work-disposition-posture-v0.md`
