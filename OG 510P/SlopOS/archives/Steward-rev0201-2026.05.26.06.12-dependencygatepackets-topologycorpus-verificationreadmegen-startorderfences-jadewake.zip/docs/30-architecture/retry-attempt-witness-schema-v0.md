# Retry-attempt witness schema v0

## Purpose
`ST-RETRYATTEMPT v0` is the first closed packet for one follow-up attempt inside a retry, replay, transparent retry, reconnect resend, post-drain resend, manual retry, or hedge group.

The central rule: **an attempt records what was tried and why it was considered safe or unsafe; it does not prove route currentness, readiness, serving, custody, work completion, effect success, no duplicate, or exactly-once behavior.**

## Machine profile
- Machine profile: `../../schemas/st-retryattempt-v0.schema.json`
- Checker: `../../tools/steward_retry_settlement_harness.py`
- Corpus: `../40-verification/corpora/retry-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-RETRYATTEMPT v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | client, proxy, runtime, library, mesh, queue, broker, operator, or observer that produced the attempt witness |
| `attempt_id` | canonical attempt id |
| `attempt_group_ref` | retry/replay/hedge group id |
| `attempt_ordinal` | zero-based attempt ordinal within the group |
| `attempt_state` | fresh, transparent retry, safe retry, idempotent replay, same-key mismatch, pushback-delayed, budget-exhausted, hedged, winner-known, maybe-applied, early-data risk, manual-review-required, abandoned, or unknown |
| `original_ref` | exact demand, request, channel send, or work item this attempt follows |
| `canonical_intent_digest` | digest of the canonical reviewed intent |
| `safety_basis` | safe method, idempotency/effect key match, transport-not-seen, commitment-not-crossed, retry-after-handshake, explicit review, hedge-only, unsafe, or unknown |
| `commit_boundary` | not-sent, transport-not-seen, application-not-seen, sent-unknown, response-headers-seen, partial-response-seen, request-body-overflow, external-effect-possible, external-effect-confirmed, or unknown |
| `duplicate_risk` | none, possible, known, mismatch-rejected, or unknown |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the attempt classification |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include idempotency/effect key refs, advice/budget refs, route/live-channel/demand/custody/work/effect refs, early-data state, winner ref, expiry/recheck, and unknown reason.

## Non-implication vocabulary
A valid retry-attempt witness must include:

- `not-readiness`
- `not-serving`
- `not-route-authority`
- `not-custody`
- `not-work-completion`
- `not-effect-success`
- `not-exactly-once`
- `not-no-duplicate`

## Attempt rules
Transparent retry requires transport-not-seen or commitment-not-crossed evidence and cannot cross an application or response commitment boundary. Idempotent replay requires an idempotency or effect key ref. Same-key mismatch must become `mismatch_rejected`. Pushback-delayed attempts require advice. Budget-exhausted attempts require a budget witness. External-effect-confirmed attempts require an adjacent effect witness ref.

Early-data retry after replay-risk rejection is only valid as `replayed_after_handshake` with `retry_after_handshake` safety basis. An unsafe early-data replay is rejected.

## Rejected surfaces
The corpus rejects:

- same idempotency/effect key with different canonical intent;
- transparent retry after response/application commitment;
- external-effect-confirmed without adjacent effect witness;
- `Retry-After` or pushback treated as a reservation;
- retry after 425/early-data risk sent in early data again;
- exactly-once, no-duplicate, readiness, serving, route-authority, custody, work-completion, or effect-success claims.

## Non-goals
- no RPC framework, retry engine, service mesh, broker, durable queue, workflow engine, distributed idempotency ledger, hedge-racing subsystem, or exactly-once plane;
- no claim that retry policy itself makes non-idempotent work safe.

## Adjacent docs
- `activation-retry-attempt-posture-v0.md`
- `retry-advice-witness-schema-v0.md`
- `retry-budget-witness-schema-v0.md`
- `hedge-fate-witness-schema-v0.md`
- `effect-boundary-witness-schema-v0.md`
- `demand-episode-witness-schema-v0.md`
- `live-channel-witness-schema-v0.md`
- `canonical-json-profile-v0.md`

## References
REF-GRPC-RETRY; REF-GRPC-HEDGING; REF-HTTP-RFC9110; REF-RFC8470-EARLY-DATA; REF-AWS-BUILDERS-IDEMPOTENT-APIS; REF-AWS-SDK-RETRY-BEHAVIOR.
