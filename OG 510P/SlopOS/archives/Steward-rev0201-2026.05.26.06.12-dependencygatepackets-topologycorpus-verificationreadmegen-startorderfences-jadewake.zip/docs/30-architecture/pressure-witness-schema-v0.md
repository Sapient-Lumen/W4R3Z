# Pressure witness schema v0

## Purpose
`ST-PRESSURE v0` is the closed packet profile for one scoped pressure observation. It records pressure class, level, window, freshness, and optional reclaim advice without claiming failure, readiness, serving, admission, backpressure, headroom, mutation, or effect success.

## Required fields
- `schema`: constant `ST-PRESSURE v0`.
- `witness_id`: packet witness id.
- `pressure_id`: stable pressure observation id.
- `cid`: component identity.
- `scope_ref`: exact subject or footing of the pressure observation.
- `issuer`: closed issuer object.
- `observed_at_ms`: monotonic observation time.
- `resource_class`: `cpu`, `memory`, `io`, `network`, `storage`, `queue`, `scheduler`, `composite`, or `unknown`.
- `pressure_signal`: `stall`, `saturation`, `quota`, `latency`, `reclaim`, `adapter`, `operator`, or `unknown`.
- `pressure_level`: `normal`, `some`, `full`, `warning`, `critical`, or `unknown`.
- `window_ms`, `measured_at_ms`, and `expires_at_ms`: bounded freshness window.
- `stall_percent_basis`: integer basis-points style stall/pressure summary, or zero when unavailable.
- `reclaim_advice`: `none`, `trim_optional`, `avoid_new_work`, `shed_optional`, `operator_review`, or `unknown`.
- `reason`: bounded explanation.
- `basis_refs`: bounded evidence refs.
- `non_implications`: must include `not-authority`, `not-authorization`, `not-readiness`, `not-serving`, `not-failure`, `not-admission`, `not-backpressure`, `not-headroom`, `not-execution`, and `not-effect-success`.

## Cross-field rules
- Known pressure must not already be stale at observation time.
- `normal` and `unknown` pressure cannot carry concrete reclaim advice.
- Raw host identifiers, paths, tokens, endpoints, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A pressure witness never proves failure, degraded serving state, readiness, admission denial, backpressure, headroom, authorization, execution, repair, autoscale, incident, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/pressure-admission-corpus-v0.jsonl`; the checker is `../../tools/steward_pressure_admission_harness.py`.
