# Attention-watch witness schema v0

`ST-ATTNWATCH v0` is a closed Steward packet for one exact user-armed watch.

## Purpose
An attention watch records that an exact anchor and exact condition are being watched. It is not automation, approval, authorization, or lifecycle execution.

## Required fields
- `schema`: exactly `ST-ATTNWATCH v0`.
- `witness_id`, `cid`, `issuer`.
- `watch_id`: stable watch id.
- `anchor_ref`: exact watched anchor.
- `condition_kind`: `frame_finished`, `receipt_settled`, `status_barrier_crossed`, `pending_request_responded`, `attention_hint_matched`, or `unknown`.
- `watch_state`: `armed`, `matched`, `delivered`, `canceled`, `expired`, `stale`, or `unknown`.
- `armed_at_ms`, `expires_at_ms`, `min_age_ms`.
- `delivery_preferences`: bounded attention channels.
- `reveal_target_ref`: exact target to reveal if the watch triggers.
- `cancel_ref`: exact cancel/clear target.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `matched_hint_ref`: a matching `ST-ATTNHINT` id when the watch is no longer merely armed.
- `unknown_reason`.

## Required non-implications
The packet must deny authority, automation, mutation, authorization, execution, current state, readiness, serving, and effect success.

## Rejection examples
- ambient terminal or current-pane watches;
- armed watches with already-matched hint refs;
- expired active watches;
- hidden automation or macro fields.
