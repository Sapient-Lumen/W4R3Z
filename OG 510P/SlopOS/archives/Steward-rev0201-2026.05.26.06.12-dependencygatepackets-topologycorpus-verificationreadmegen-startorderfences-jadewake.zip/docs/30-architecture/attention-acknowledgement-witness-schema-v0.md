# Attention-acknowledgement witness schema v0

`ST-ATTNACK v0` is a closed Steward packet for one reveal, dismiss, focus, open, or clear acknowledgement of an attention item.

## Purpose
An acknowledgement records a surface interaction with an exact notice/watch. It does not prove the underlying condition was resolved, that work completed, that a lifecycle state changed, or that an operation was approved.

## Required fields
- `schema`: exactly `ST-ATTNACK v0`.
- `witness_id`, `cid`, `issuer`.
- `ack_id`: stable acknowledgement id.
- `notice_ref`: matching `ST-NOTICE` id.
- `watch_ref`: matching `ST-ATTNWATCH` id.
- `ack_kind`: `dismissed`, `revealed`, `focused`, `opened_receipt`, `cleared`, or `unknown`.
- `ack_state`: `recorded`, `stale_target`, `denied_by_policy`, `lost`, or `unknown`.
- `actor_ref`: redacted actor/principal reference.
- `revealed_target_ref`: exact target reference.
- `acknowledged_at_ms`, `stale_after_ack_ms`.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Required non-implications
The packet must deny authority, authorization, mutation, execution, current state, readiness, serving, effect success, resolution, and work completion.

## Rejection examples
- acknowledgement times after observation;
- acknowledgement stale boundary before the acknowledgement;
- resolution, approval, execution, readiness, or effect-success claims;
- ambient reveal targets or raw host/UI handles.
