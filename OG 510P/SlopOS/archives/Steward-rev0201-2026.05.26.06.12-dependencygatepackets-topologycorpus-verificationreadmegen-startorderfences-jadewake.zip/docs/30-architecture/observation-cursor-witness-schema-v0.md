# Observation cursor witness schema v0

## Packet
`ST-OBSCURSOR v0` records one observation-stream cursor or continuity marker.

## Required meaning
The packet says a stream position advanced, stayed unchanged, reset, overflowed, compacted, became gapped, or is unknown. It binds that state to an opaque cursor digest and a sequence class.

Cursor movement is not current lifecycle state. It is not proof that demand drained, a route is current, a component is serving, an effect succeeded, or no observations were lost.

## Required non-implications
Every packet must explicitly refuse:
- `not-current-state`
- `not-lossless-continuity`
- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-demand-drained`

## Canonicalization
The machine profile is [`../../schemas/st-obscursor-v0.schema.json`](../../schemas/st-obscursor-v0.schema.json). Gapped, reset, lost, overflowed, or compacted continuity requires a downgrade reason.

## Refusals
A cursor may support a recheck request or replay warning. It cannot by itself settle freshness, completeness, drain, recovery, or current-enough-to-act truth.
