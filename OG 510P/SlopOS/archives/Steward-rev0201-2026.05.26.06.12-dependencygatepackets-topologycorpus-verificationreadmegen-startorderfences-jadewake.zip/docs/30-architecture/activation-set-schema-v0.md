# CH-ACTSET v0 activation set schema

## Purpose
Describe what Steward delivered to a component for one concrete activation cycle without exporting raw handles or turning host launch machinery into public semantics.

CH-ACTSET is descriptive evidence. It can be digested, receipted, and compared against CH-COMP. It is not a bearer token, inventory API, file-descriptor table, config store, vault, or watch surface.

## Machine-readable profile
The machine-readable schema profile is `../../schemas/ch-actset-v0.schema.json`.

The executable checker is `../../tools/steward_lifecycle_harness.py`.

The generated proof corpus is `../40-verification/corpora/component-lifecycle-activation-corpus-v0.jsonl`.

## Canonicalization
CH-ACTSET uses `canonical-json-profile-v0.md`:

- closed keys;
- duplicate keys reject;
- floats reject;
- enum variants reject unless listed;
- digest is `sha256:` over canonical bytes.

## Shape
Required fields:

- `schema = "CH-ACTSET v0"`
- `cid`
- `instance_nonce`
- `stable`: bounded list of supervisor-owned delivered activation descriptions;
- `escrowed`: bounded list of restored continuity descriptions.

Each entry contains:

- `key`: bounded label;
- `kind`: closed-world enum;
- `rights`: bounded unique summary;
- `origin`: `stable_export` or `escrow`.

## Constraints
- CH-ACTSET carries descriptions, not bearer handles;
- `handle`, `value`, `token`, `secret`, `raw`, `path`, `fd`, and descriptor-number fields reject;
- duplicate `(origin,key)` pairs reject;
- stable entries must be subsets of CH-COMP `activation.stable_exports`;
- escrow entries must be subsets of an enabled CH-COMP escrow allowlist;
- escrow entries must not exceed CH-COMP `max_items`;
- unknown keys and enum variants reject.

## Logging guidance
The digest of CH-ACTSET is the portable logging/export surface. Raw capability material must remain under the membrane and must not appear in exported receipts.

## Refusals
CH-ACTSET does not imply:

- path freshness;
- current credential authority;
- readiness;
- serving;
- custody;
- work completion;
- effect success;
- lossless restore;
- exact descriptor number preservation.

## References
REF-SYSTEMD-FDSTORE; REF-SPIFFE-WORKLOAD-API; REF-VAULT-LEASES; REF-K8S-SECRETS.
