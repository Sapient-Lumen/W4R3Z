# Repair-card posture v0

Purpose: define a **tiny exact repair-card seam** so failed or blocked commands/components can surface one reviewable likely-next-fix object without turning shell help into auto-remediation, transcript folklore, or a workflow engine.

## Posture
1. **A repair card binds to one exact stronger anchor**
   - The healthiest owner is one exact command verdict, command frame, output slice, repair gate, receipt, headroom witness, or other reviewed anchor.
   - Steward should resist folklore like “whatever red text was nearby probably means run this fix”.
2. **Repair cards are proposals, not diagnosis truth or execution**
   - A repair card may summarize one likely cause and one or a few likely next actions.
   - Its public meaning should stay `proposed fix`, not `root cause proven` and not `already applied`.
3. **Prefer reviewed selectors, recipes, or exact targets over synthesized shell text**
   - The strongest repair actions resolve to reviewed spawn selectors, exact open/reveal targets, bounded replay cards, or explicit Steward actions.
   - Freehand shell text can still exist as a downgrade, but it should stay visibly weaker.
4. **Failure reason, proposed action, and disabled reason stay separate**
   - `port busy`, `upstream missing`, `policy denied`, `retry after`, `repair required`, and `proposal blocked` are different truths.
   - A repair card should be able to say both *why it appeared* and *why one suggested action is currently disabled*.
5. **Input-time assist and post-command repair must not blur together**
   - Completions, inline docs, and current-command suggestions belong to the editable line.
   - Repair cards belong to a finished command/frame/verdict or another explicit post-command anchor.
6. **Cards should stay compact and reviewable**
   - Phase 1 likely needs only: owning anchor, short why-this-appeared summary, one or a few suggested actions, provenance/confidence, freshness, and optional disabled reason.
   - Steward should avoid freezing a giant diagnosis knowledge graph, universal remediation schema, or issue-routing family too early.
7. **Apply should usually stage, reveal, or invoke one explicit action**
   - `insert`, `stage`, `open`, `reveal`, `copy`, or one reviewed exact mutation are healthy outcomes.
   - Silent auto-rerun or hidden mutation should remain a stronger exceptional path, not the default meaning of the card.
8. **Cards should degrade honestly when exact footing is missing**
   - Exact shell metadata, reviewed receipts, and exact verdicts outrank parse-lens candidates or visible-text heuristics.
   - Steward should be allowed to say `repair card (exact)` versus `repair card (parsed candidate)` instead of flattering weaker footing.
9. **One small repair-card seam beats a remediation empire**
   - Quick fixes, likely-next-action cards, and frame-local explainers all want the same anti-folklore discipline.
   - Steward should keep this seam smaller than a portable workflow engine, package-manager doctor, or auto-remediation framework.

## Phase-1 non-goals
- auto-applying repairs because a likely fix exists;
- a universal diagnosis ontology for every toolchain/runtime error;
- forcing every repair to be representable as one shell command;
- turning repair cards into durable tickets, issue threads, or workflow queues;
- pretending parsed candidate repairs are as strong as exact shell/frame/receipt footing.

## Adjacent docs
- `assist-surface-posture-v0.md`
- `command-verdict-posture-v0.md`
- `command-frame-posture-v0.md`
- `command-evidence-posture-v0.md`
- `evidence-draft-posture-v0.md`
- `repair-gate-posture-v0.md`
- `retry-advice-posture-v0.md`
- `preflight-lane-posture-v0.md`
- `action-surface-posture-v0.md`
- `output-slice-posture-v0.md`
- `parse-lens-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1072
- REF-VSCODE-UPDATE-1102
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-AUGMENT-COMMAND-PALETTE
- REF-GHOSTTY-RELEASE-130
