# Notification-delivery witness schema v0

`ST-NOTICE v0` is a closed Steward packet for one attention delivery attempt.

## Purpose
A notification witness says that a bounded delivery path queued, delivered, suppressed, failed, or downgraded one exact attention item. Delivery is not proof that the user saw it, read it, approved it, resolved it, or executed anything.

## Required fields
- `schema`: exactly `ST-NOTICE v0`.
- `witness_id`, `cid`, `issuer`.
- `notice_id`: stable notice id.
- `watch_ref`: matching `ST-ATTNWATCH` id.
- `hint_ref`: matching `ST-ATTNHINT` id.
- `delivery_state`: `queued`, `delivered`, `suppressed`, `failed`, `stale`, or `unknown`.
- `delivery_class`: `none`, `chip`, `badge`, `bell`, `toast`, or `reveal_only`.
- `target_ref`: exact reveal/focus/open target.
- `delivery_actions`: only `reveal`, `focus`, `open_receipt`, or `dismiss`.
- `delivered_at_ms`.
- `downgrade_reason`.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Required non-implications
The packet must deny authority, user-seen, user-read, resolution, authorization, mutation, execution, current state, readiness, serving, and effect success.

## Rejection examples
- lifecycle actions such as restart, stop, kill, approve, authorize, run, or execute in `delivery_actions`;
- stale, failed, or suppressed delivery with no downgrade reason;
- claiming user-seen/read or resolution;
- raw endpoint, path, token, command, PID, or host object material.
