# Control-operation receipt schema v0

## Purpose
`ST-OPRECEIPT v0` is the first closed packet for settling, updating, or downgrading one Steward control operation. It keeps an operation result separate from component lifecycle truth.

The central rule: **operation completion is not component stopped, ready, serving, healthy, or effect-success truth.** A receipt may say a request was accepted, queued, running, denied, deferred, canceled, timed out, failed, completed, skipped, dependency-blocked, or unknown. It must not silently convert that result into adjacent lifecycle claims.

## Machine profile
- Machine profile: `../../schemas/st-opreceipt-v0.schema.json`
- Checker: `../../tools/steward_operation_harness.py`
- Corpus: `../40-verification/corpora/control-operation-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-OPRECEIPT v0` |
| `op_id` | operation id from the matching request |
| `cid` | Steward component id |
| `verb` | requested lifecycle verb |
| `request_digest` | canonical digest of the matching `ST-OPREQ v0` |
| `issuer` | issuer copied from or bound to the request |
| `phase` | one of `accepted`, `queued`, `running`, `finished` |
| `result` | terminal or non-terminal result label |
| `basis` | closed explanation of source and summary |
| `boundary_refs` | bounded refs to operation-boundary evidence |
| `non_implications` | explicit list of stronger truths the receipt refuses |

Optional fields are `observed_at_ms` and bounded `message`.

## Phase/result rules
- Non-finished receipts must use `result: none`.
- Finished receipts must use a terminal result other than `none`.
- `completed` requires at least one `boundary_ref`.
- Terminal-looking results such as `completed`, `timed_out`, `failed`, or `unknown` must include `not-component-terminal-state`.
- Recovery-source receipts must include `not-current-after-recovery`.

## Basis rules
`basis.source` is one of `steward`, `adapter`, `operator`, or `recovery`.

Adapter-backed receipts may say what an adapter observed about a job, queue item, or control path. They may not claim that the adapter result is native component state unless a separate Steward witness proves that stronger truth.

Recovery-backed receipts may preserve durable history while downgrading live/current state. A manager restart may say `unknown` for an in-flight operation, but it must not keep pre-recovery `queued` or `running` currentness without reconciliation.

## Non-implication vocabulary
The v0 non-implication vocabulary is deliberately blunt:

- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-component-terminal-state`
- `not-traffic-binding`
- `not-custody`
- `not-current-after-recovery`

This turns receipt humility into data instead of relying on UI copy.

## Rejected receipt surfaces
Receipts reject raw host/process fields and flattering component-state fields, including PID, cgroup path, host unit, systemd job path, pod/container id, shell job, raw log, scrollback, secret/token fields, `claims_ready`, `claims_stopped`, `claims_serving`, `component_state`, `ready`, `stopped`, and `serving`.

## Corpus obligations
The operation corpus rejects:

- receipt/request digest mismatch;
- queued receipts with terminal results;
- finished receipts with no terminal result;
- completed receipts without operation boundary evidence;
- operation completion that claims component stopped;
- timeout/failure/unknown receipts that omit component-state refusal;
- recovery receipts that omit currentness refusal;
- post-recovery reuse of pre-recovery queued/running currentness.

## Adjacent docs
- `control-operation-request-schema-v0.md`
- `control-operation-posture-v0.md`
- `manager-recovery-reconciliation-posture-v0.md`
- `adapter-membrane-posture-v0.md`
- `receipt-minimization-posture-v0.md`
- `termination-cause-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
