# Attention-notification proof posture v0

## Purpose
Make attention cues falsifiable without growing Steward into a notification service, inbox, reminder system, macro engine, or desktop UI framework.

## Packet split
- `ST-ATTNHINT v0`: one exact attention cue.
- `ST-ATTNWATCH v0`: one exact user-armed watch.
- `ST-NOTICE v0`: one delivery attempt or downgrade.
- `ST-ATTNACK v0`: one reveal/dismiss/focus/open acknowledgement.

## Non-collapse rules
1. A hint is not user-visible delivery.
2. A watch is not automation, approval, authorization, or execution.
3. A notification delivery is not proof the user saw, read, accepted, or resolved anything.
4. An acknowledgement is not condition resolution, work completion, readiness, serving, effect success, or operation execution.
5. Notification actions may reveal, focus, open a receipt, or dismiss; they may not run lifecycle mutations.
6. Ambient pane, terminal, host, PID, container, endpoint, path, token, or raw command handles are not valid public packet targets.
7. Expiry and downgrade are first-class; stale delivery should be recorded as stale instead of guessed as successful.

## Why this belongs in Steward
Steward already exposes exact lifecycle and witness surfaces. Users will want to watch exact frames, receipts, barriers, and pending lifecycle outcomes. This seam lets Steward name that attention behavior while preserving the stronger lifecycle packet boundaries.

## Why this does not become a sibling empire
- Schell still owns shell command semantics.
- Helm still owns broad UI/repair cards.
- Ward still owns approvals and delegation.
- Steward only records lifecycle-scoped attention evidence that is necessary to avoid weak UI cues being mistaken for authority or truth.

## Executable settlement
`../40-verification/attention-notification-corpus-v0.md` verifies the closed packets and rejects ambient watches, mutating notification actions, user-seen/read/resolution flattery, notice-without-watch/hint, notification-before-hint, ack-without-notice, watch-as-authorization, and duplicate notice id drift.
