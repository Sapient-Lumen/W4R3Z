# Bootstrap-reconciliation posture v0

Purpose: define one **tiny bootstrap reconciliation seam** so a freshly activated runtime cycle can say whether it has merely **woken because of a cause** or has also **reconciled present-tense condition truth** for the exact scope it cares about.

This seam stays intentionally small. It does **not** invent a universal watch bus, dependency planner, distributed cache, or global state snapshot protocol. It only says that when activation comes from a request, trigger, or demand surface that may race with current state, Steward should preserve one small truthful step between **why this cycle woke up** and **what condition it has now actually observed**.

## Posture
1. **Activation cause and present-tense condition stay different truths**
   - `woke because of device-arrival trigger`, `woke because queue became nonempty`, or `woke because first request arrived` explain *why the cycle began*.
   - They do not by themselves prove that the condition is still true once the runtime is fully up.
2. **Bootstrap reconciliation is one exact step, not a permanent control plane**
   - After startup, a component or adapter may need one explicit snapshot / enumeration / initial list / initial handshake before it can honestly claim current condition truth.
   - Steward should keep that as one small attributable step rather than silently treating the original trigger edge as forever-good truth.
3. **Bootstrap evidence and later live callbacks may legitimately duplicate each other**
   - A current-state sweep plus later live notifications can overlap.
   - Duplicate evidence across that boundary should be ordinary and should not force adapters to invent fake dedup folklore at the portable layer.
4. **Bootstrap reconciliation should compose with snapshot-plus-change observation**
   - If a substrate offers an initial snapshot followed by live updates, a synced-through marker after that bootstrap path is a healthier place to claim currentness than raw wake cause alone.
   - Steward should preserve whichever exact cursor, barrier, or bootstrap-complete marker the adapter can really prove.
5. **Bootstrap-complete is not the same as serve-ready**
   - A component may finish reconciling the condition it woke for and still not be ready to serve declared work.
   - Steward should keep bootstrap reconciliation separate from readiness, serving, and stability dwell truth.
6. **Exact scope matters**
   - Reconciliation may apply to one queue, one device class, one request namespace, one peer set, or another equally exact scope.
   - Steward should not flatter a scope-local reconciliation into global `all clear` truth.
7. **Unknown is healthier than fake certainty**
   - Some adapters can say `bootstrap reconciled`, `bootstrap pending`, or `bootstrap lost`.
   - Others may only know the activation cause and must admit that present condition truth is still unknown.
8. **Shell chrome may show compact bootstrap truth, but it stays explanatory**
   - Ground cards, lifecycle chips, or explainers may show compact labels such as `triggered; bootstrap pending`, `queue reconciled`, `device scan complete`, or `currentness unknown`.
   - Those labels explain footing; they do not widen authority or bypass review.
9. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `bootstrap_status` such as `pending` / `reconciled` / `lost` / `unknown`, exact scope label when known, and optional cursor/barrier witness if the adapter truly has one.
   - Broader subscription, caching, or dependency algebra remains intentionally undecided.

## Phase-1 non-goals
- a universal bootstrap callback or watch-registration API;
- a generic deduplication or event-sourcing framework;
- proving that every activation cause can be reconciled to one perfect current-state snapshot;
- flattening bootstrap-complete into readiness, serving, or policy approval;
- a global dependency or discovery plane for every dynamic condition.

## Adjacent docs
- `activation-cause-posture-v0.md`
- `dynamic-condition-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `readiness-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `currentness-class-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-WINDOWS-SERVICE-DEVICE-INTERACTION
- REF-K8S-API-CONCEPTS
- REF-DBUS-API-DESIGN
