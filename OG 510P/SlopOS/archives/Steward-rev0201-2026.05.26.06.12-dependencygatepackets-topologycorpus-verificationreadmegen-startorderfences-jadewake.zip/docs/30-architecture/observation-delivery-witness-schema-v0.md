# Observation delivery witness schema v0

## Packet
`ST-OBSDELIV v0` records one delivered, coalesced, dropped, heartbeat, or resync-required batch for an exact observation subscription.

## Required meaning
The packet says the subscription ref, sequence interval, delivery state, sorted delivered refs, cursor-after ref, redaction refs, and dropped-count boundary for one delivery batch.

## Required non-implications
Every delivery witness must explicitly refuse:

- `not-authority`
- `not-current-state`
- `not-readiness`
- `not-serving`
- `not-execution`
- `not-effect-success`
- `not-lossless`

## Canonicalization
The machine profile is [`../../schemas/st-obsdeliv-v0.schema.json`](../../schemas/st-obsdeliv-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
A delivery is not currentness. A cursor after a delivery is not lossless continuity. Dropped or resync-required delivery must be explicit, and delivered refs must be sorted so the same batch has one stable digest.
