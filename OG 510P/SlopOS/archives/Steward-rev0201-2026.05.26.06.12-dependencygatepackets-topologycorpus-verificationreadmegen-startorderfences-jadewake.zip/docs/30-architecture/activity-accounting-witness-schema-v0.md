# Activity-accounting witness schema v0

Purpose: define the closed human profile for `ST-ACTACCT v0`, a descriptive usage/accounting witness for activity brackets and scoped meters.

Activity accounting records bounded usage facts such as bracket counts, durations, messages, bytes, or coarse composite estimates. It exists to explain lifecycle policy and audit surfaces without turning usage into billing, quota debit, pressure, headroom, admission, demand, work completion, or effect success.

## Required fields
- `schema`: `ST-ACTACCT v0`.
- `witness_id`, `cid`, `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.
- `activity_accounting_id`: stable id with `actacct_` prefix.
- `scope_ref`: exact runtime, component, or policy scope ref.
- `bracket_refs`: exact bracket refs, when bracket-backed.
- `meter_class`: `activity_count`, `duration_ms`, `bytes`, `messages`, `cpu_ms`, `memory_byte_ms`, `composite`, or `unknown`.
- `unit`, `quantity`, `window_start_ms`, and `window_end_ms`.
- `estimate_state`: `exact`, `bounded`, `approximate`, or `unknown`.
- `settled_state`: `open`, `closed`, `partial`, `abandoned`, or `unknown`.
- `source_refs`: exact source refs.
- `reason`: short redacted explanation.

## Required non-implications
`not-authority`, `not-authorization`, `not-billing`, `not-quota-debit`, `not-pressure`, `not-headroom`, `not-admission`, `not-demand`, `not-work-completion`, and `not-effect-success`.

## Rules
Open accounting windows have no final end. Closed, partial, and abandoned accounting windows must close after they start. Exact accounting cannot use an unknown meter class. Flow validation rejects closed accounting over open brackets.

## Non-goals
This packet is not a billing record, quota spend, pressure signal, admission decision, demand receipt, or effect receipt.
