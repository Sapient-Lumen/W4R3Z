# Activation-admission posture v0

Purpose: define a **tiny activation-admission seam** so one exact wake, start, or activation-demand attempt can say whether it was **admitted**, **denied**, **deferred**, **narrowed**, **throttled**, **shed**, or **unknown** before Steward claims that any component is running, ready, serving, queued, or completed.

This seam is intentionally small. It does **not** invent a universal policy language, quota wallet, admission-controller framework, autoscaler, request queue, or workflow engine. It only answers one narrow question honestly: **what happened at the boundary where this exact activation attempt asked for permission to begin or enter an activation episode?**

## Posture
1. **Admission is not execution**
   - An activation attempt may be admitted without the component being started yet, delivered to yet, ready, serving, or guaranteed to complete the triggering work.
   - Steward should preserve `admitted` as boundary truth, not flatter it into `running`, `ready`, `delivered`, or `accepted by runtime`.

2. **Admission is per-attempt truth, not durable enablement state**
   - Durable `manual`, `auto`, `disabled`, or `start-prohibited` intent explains baseline future policy.
   - Activation admission explains what happened to **this exact request** under current overlays, headroom, freshness, user-intent, and context.
   - A component can be `auto` yet denied now because the lane is background-restricted, out of headroom, cooling down, or missing fresh local intent.

3. **Admission and demand episode are adjacent but different**
   - Admission answers whether a wake/start/demand may enter the activation fabric now.
   - The activation-demand episode answers what happened after a demand was accepted by an activation surface: buffered, waking, delivered, canceled, timed out, shed, or completed.
   - Keeping the split prevents `accepted at gate` from becoming an implicit queue, proxy, or service guarantee.

4. **Admission should name the winning boundary reason when knowable**
   - Useful compact reasons include `policy-denied`, `approval-missing`, `fresh-intent-required`, `background-restricted`, `disabled`, `start-prohibited`, `repair-required`, `cooldown-active`, `headroom-exhausted`, `rate-limited`, `condition-missing`, `conflicting-operation`, `narrowed`, `deferred`, `shed`, and `unknown`.
   - Phase 1 should prefer one winning reason plus optional diagnostics over a giant denial lattice.

5. **Deny, defer, throttle, narrow, and shed are different outcomes**
   - A permanent or policy-floor denial should not look like a retry-later throttle.
   - `deferred until condition`, `retry after`, `admitted with narrower material`, and `shed without wake` are materially different receipts.
   - Steward should surface those distinctions instead of a single vague `blocked` spinner.

6. **Admission may narrow a request, but hidden mutation is dangerous**
   - Some gates usefully clamp a deadline, reduce concurrency, remove optional startup material, pick a lower background tier, or require a foreground/reviewed lane.
   - Any such narrowing should be visible in the admission receipt; the caller and later explanation should not have to rediscover that the request quietly changed under the gate.

7. **Fresh user/context gates are first-class policy inputs, not folklore**
   - A foreground-sensitive start, attention-affecting wake, camera/microphone/location-adjacent helper, or background persistence request may require fresh local intent, visible UI footing, or a permitted background lane.
   - Steward should encode that as admission truth rather than infer it from focus, an environment variable, an old approval, or a background process label.

8. **Spendability gates belong beside policy gates**
   - Quota, concurrency, restart-budget, rate-window, and backing-service caps are not authorization, readiness, or liveness.
   - If the next activation is otherwise allowed but cannot be spent now, Steward should say `headroom exhausted` or `throttled` with exact scope when possible.

9. **Admission receipts must not become a portable policy engine**
   - A compact receipt can name attempt id, target, request basis, gate class, winning outcome, optional retry/defer hint, optional narrowed basis, and source freshness.
   - It should not expose a general rule language, external webhook contract, multi-tenant policy framework, or total order across every possible rejection.

10. **Unknown must remain available**
   - Some compat adapters will only know that a host refused start or that a request failed before a runtime existed.
   - `unknown admission` or `provider-local denial` is more honest than inventing a fake portable reason.

## Phase-1 non-goals
- a universal admission-controller or policy-webhook framework;
- a total denial precedence ladder across every Steward action family;
- a portable quota wallet, cost ledger, fair queue, or autoscaler;
- a durable request queue or exactly-once activation-delivery plane;
- treating admission receipts as current liveness, readiness, serving, or completion truth;
- silently mutating activation requests without receipt-visible narrowing.

## Adjacent docs
- `enablement-intent-posture-v0.md`
- `activation-overlay-posture-v0.md`
- `request-activation-posture-v0.md`
- `activation-demand-episode-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `backpressure-witness-posture-v0.md`
- `retry-advice-posture-v0.md`
- `approval-rung-posture-v0.md`
- `fresh-intent-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `start-gate-posture-v0.md`
- `operation-arbitration-posture-v0.md`
- `non-decisions-v0.md`

- `activation-custody-posture-v0.md`
- `activation-work-disposition-posture-v0.md`

## References
- REF-K8S-ADMISSION-CONTROLLERS
- REF-K8S-DYNAMIC-ADMISSION
- REF-AWS-LAMBDA-CONCURRENCY
- REF-AWS-LAMBDA-METRICS
- REF-CLOUD-RUN-AUTOSCALING
- REF-CLOUD-RUN-MAX-INSTANCES
- REF-ANDROID-FGS-BACKGROUND-STARTS
- REF-ANDROID-BACKGROUND-ACTIVITY-STARTS
- REF-HTML-USER-ACTIVATION
