# Transcript-landmark posture v0

Purpose: define a **tiny exact-landmark seam** for marks, annotations, alerts, and jump targets so transcript navigation and scratch notes stay powerful without turning scrollback chrome into ambient authority.

## Posture
1. **A landmark is a locator over an exact object, not transcript truth**
   - A mark, annotation, or jump target may point at a command frame, transcript span, receipt ref, or other exact anchor.
   - The canonical record remains the underlying frame/span/receipt object, not the landmark widget that surfaces it.
2. **Landmarks should carry visible provenance**
   - Shell-reported marks, manager-emitted lifecycle landmarks, user-added notes, and terminal-guessed fallback marks are not equivalent.
   - Steward should be able to label who or what created a landmark before the UI grants stronger affordances around it.
3. **Jump and reveal actions should resolve through anchors**
   - “Jump to mark”, “select output”, “open receipt”, or “show command details” should resolve through the landmark's explicit target anchor when possible.
   - Landmark text, scrollbar paint, or viewport position should not become the only locator for the thing the user meant.
4. **Annotations are scratchpads over exact spans, not hidden metadata pipes**
   - Notes on a command frame or output slice can be extremely useful for debugging and handoff.
   - They should stay local, bounded, and explicitly attached instead of becoming an ambient transcript side channel.
5. **Watch or alert behavior should bind to exact landmarks**
   - A focus-aware “watch this command” or “alert on next mark” affordance is healthy when it tracks a concrete mark or frame.
   - It should remain an observational cue, not a hidden lifecycle control or scheduling plane.
6. **Scrollbar marks, palettes, and next/previous navigation are discovery surfaces**
   - Rails, scrollbar annotations, next/previous mark actions, and landmark palettes are useful ways to browse exact landmarks.
   - They remain views over the landmark seam, not separate authority channels with their own semantics.
7. **Persistence should stay explicit and scoped**
   - Persisting user-added landmarks across restarts may be useful, but it should remain a deliberate local-storage choice.
   - Persisted landmarks should keep their host, hop, freshness, and provenance labels rather than pretending they are newly live.
8. **One landmark seam beats many ad hoc mark systems**
   - Command-finished marks, failure marks, user notes, receipt landmarks, and jump-to-output anchors all want the same anti-folklore discipline.
   - Steward should prefer one tiny landmark seam over a growing pile of per-widget bookmark hacks.

## Phase-1 non-goals
- inventing a global synchronized bookmark service;
- turning annotations into a hidden collaboration or approval plane by default;
- treating guessed marks or scrollbar paint as trusted control authority;
- auto-persisting every ephemeral mark forever;
- freezing a giant transcript or notebook schema.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `command-guide-posture-v0.md`
- `target-anchor-posture-v0.md`
- `remembered-shelf-posture-v0.md`
- `attention-hint-posture-v0.md`
- `attention-watch-posture-v0.md`
- `context-handoff-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1066
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-ACTIONS
- REF-ITERM2-MENU-ITEMS
- REF-ITERM2-FEATURES
