# Injection-receipt posture v0

Purpose: define a **tiny exact injection-receipt seam** so reviewed shell/session mutations such as `insert`, `replace`, env-bundle load, or history-suppressed tool insertion can leave one exact shell-visible receipt over **what changed in the live session** without pretending execution already happened or freezing an undo/history family.

## Posture
1. **Source suggestion, session mutation, and later launched command stay different truths**
   - A repair card, command patch, chooser follow-on, history hit, or tool action may propose a session change.
   - The reviewed mutation that actually lands in the prompt/session is a separate event.
   - If the user later presses Enter or otherwise launches work, that launch gets its own frame / receipt / verdict.
2. **Prompt edits and session-scope loads are different scopes**
   - `insert into live prompt`, `replace exact current command`, `stage in proposal lane`, `load into this shell session`, and `load into a helper subshell` are not synonyms.
   - The receipt should name the scope it touched instead of flattening all of them into vague “applied”.
3. **Review-before-mutate should still leave proof-after-mutate**
   - Stage-first UX is healthy, but once a reviewed mutation lands Steward should be able to say what exact text / selector / bundle was inserted, replaced, cleared, or loaded.
   - That receipt is smaller than a transcript export and smaller than an undo log.
4. **Injected-without-running and injected-then-ran stay separate**
   - Writing text to the terminal without running it is different from executing it immediately.
   - A tool-inserted leading-space / history-suppressed command is also different from ordinary typed shell history.
   - Steward should preserve those distinctions instead of laundering them into one flattering `executed` story.
5. **Mutation provenance and policy should stay visible**
   - Good receipt fields include source object, target scope, mutation mode (`inserted`, `replaced`, `loaded`, `cleared`, `staged`), freshness, history policy, and optional disabled / downgraded notes.
   - If a stronger mutation path was denied and Steward fell back to `copy` or `stage`, that downgrade should remain visible.
6. **Undo / clear may exist, but the receipt is smaller than an undo family**
   - A receipt may point to `clear`, `replace`, or `open diff` affordances when those are exact and safe.
   - Steward should not freeze a universal undo stack, edit history service, or replayable mutation log through this seam.
7. **Exact footing still outranks convenience**
   - If a live prompt lease, exact current-command object, or exact session target is gone, Steward should degrade to `candidate mutation` or `copy only` rather than pretending it still changed the old live thing.
8. **One small receipt seam beats many hidden shell side effects**
   - Command patches, assist surfaces, replay cards, environment loads, and history-backed insertions all want the same anti-folklore discipline.
   - Steward should prefer one tiny injection-receipt seam over a pile of half-hidden terminal side effects.

## Phase-1 non-goals
- a universal undo/history service for shell/session edits;
- a cross-shell AST or editable transcript protocol;
- a durable export/workflow queue for every injected mutation;
- silently treating injection receipts as execution receipts.

## Adjacent docs
- `session-injection-posture-v0.md`
- `command-patch-posture-v0.md`
- `current-command-posture-v0.md`
- `prompt-lease-posture-v0.md`
- `assist-receipt-posture-v0.md`
- `command-frame-posture-v0.md`
- `command-verdict-posture-v0.md`
- `surface-diagnostics-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-CODEACTION-API
- REF-VSCODE-UPDATE-1108
- REF-GIT-ADD
