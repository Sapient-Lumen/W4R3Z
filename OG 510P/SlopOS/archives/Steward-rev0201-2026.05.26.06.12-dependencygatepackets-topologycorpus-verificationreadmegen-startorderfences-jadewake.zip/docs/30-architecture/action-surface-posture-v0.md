# Action-surface posture v0

Purpose: define how Steward-aware shell/terminal affordances can expose **explicit user actions** without letting hyperlinks, command chips, or palette entries become hidden ambient authority.

## Posture
1. **Action surfaces are invitations, not authority**
   - A visible chip, hyperlink, context-menu item, or command-palette entry is an invitation the user may choose to invoke.
   - It must not by itself imply permission to mutate a component.
2. **Actions should bind to explicit targets**
   - A surfaced action should point at a concrete target such as a receipt digest, transcript slice, component id, runtime-cycle witness, or explicit document/object reference.
   - Avoid “act on whatever this pane probably refers to right now.”
3. **Observational actions and mutating actions stay distinct**
   - Open, copy, explain, inspect, bookmark, and attach-to-report actions are lower-risk observational operations.
   - Stop, restart, quiesce, re-run, or promote actions are mutating operations and should stay visibly separate.
4. **Mutating actions should be explicit and fenced**
   - A mutating action should normally require explicit user invocation and, when useful, carry stale-action fences such as an expected runtime-cycle witness or receipt/config digest.
   - If the target has drifted, Steward should fail clearly instead of acting on whatever is newest.
5. **Provenance and confidence should influence which actions appear**
   - High-confidence, shell-reported, nonce-bound frame data may justify richer affordances.
   - Low-confidence or scraped data should default to safer actions such as copy/open/explain rather than destructive controls.
6. **Keep the portable action descriptor tiny at first**
   - A useful phase-1 descriptor likely needs only:
     - local action id,
     - label,
     - action kind,
     - explicit target reference,
     - optional expected runtime-cycle witness / receipt fence,
     - provenance / confidence,
     - optional disabled reason.
   - Avoid freezing a giant universal command schema too early.
7. **Command palette and hyperlink rules are promising transports, not the architecture**
   - Hyperlinks, frame-local chips, and palette entries are useful UX carriers for explicit actions.
   - They should remain thin views over explicit Steward objects and operations rather than becoming a second hidden control plane.
8. **Action surfaces should degrade honestly across hops and multiplexers**
   - SSH-like hops, tmux-like layers, or reduced shell integration may remove exact target identity or confidence.
   - In that case the terminal should surface fewer or safer actions rather than pretending precision survived.
9. **Remote-aware action surfaces should preserve local/remote distinction**
   - “Open local file”, “open remote transcript”, and “inspect remote component” are different actions.
   - The UI should not silently collapse them together.
10. **Prefer user-visible failure over invisible fallback**
    - If an action cannot be completed because trust, cycle witness, or target identity is stale or unavailable, Steward should say so clearly.
    - Silent fallback to weaker targeting is exactly the kind of ambient folklore this project is trying to avoid.

## Phase-1 non-goals
- a giant terminal-controlled mutation bus;
- auto-running actions because text matched a regex;
- forcing all terminals to implement a rich graphical UI;
- a final stable wire format for every possible action target;
- turning the shell/terminal into the only place lifecycle actions can be invoked.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `control-target-posture-v0.md`
- `status-channel-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `termination-cause-posture-v0.md`
- `transient-promotion-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `non-decisions-v0.md`
- `precision-fence-posture-v0.md`
- `chooser-surface-posture-v0.md`

## References
- REF-GHOSTTY-RELEASE-120
- REF-KITTY-OPEN-ACTIONS
- REF-KITTY-PROTOCOL-EXTENSIONS
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-TMUX-CONTROL-MODE
