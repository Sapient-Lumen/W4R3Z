# Time and deadline posture v0

## Purpose
Keep Steward's time language honest across activation, readiness, stop grace, material freshness, retry advice, live-channel drain, and recovery.

Time fields are often where advisory evidence becomes fake authority. Steward should name whether a timestamp is a local deadline, an externally supplied hint, a freshness boundary, or a human display value.

## Clock classes
| Class | Use | Warning |
| --- | --- | --- |
| monotonic local time | deadlines, grace periods, freshness decay inside one manager | not portable across machines or restarts without calibration |
| wall-clock time | external protocol fields, human display, audit ordering | subject to skew and adjustment |
| issuer time | imported witness timestamp | trust depends on issuer and clock basis |
| observed-at time | when Steward saw a fact | not necessarily when the fact became true |

## Field vocabulary
Steward should prefer these names:

- `observed_at`: when Steward or an adapter observed the fact;
- `valid_after`: earliest known time the fact may be used;
- `not_before`: retry/admission lower bound;
- `expires_at`: hard expiry when known;
- `stale_after`: display/currentness downgrade boundary;
- `recheck_after`: advice to refresh, not a promise;
- `deadline_at`: local operation deadline;
- `grace_until`: stop/drain grace boundary;
- `issuer_clock_basis`: wall, monotonic, unknown, or translated.

## Retry timing
`Retry-After`, pushback, backoff, and cooldown hints are advisory lower bounds. They do not reserve capacity, prove acceptance, extend custody, or imply effect safety. A not-before witness should be separate from the retry-attempt and from any admission result. Revision 188 pins that split with `ST-RETRYADVICE v0`: `not_before_ms` can delay or guide a follow-up attempt, but the packet must still declare that it is not a grant, not a reservation, not budget capacity, and not retry success.

## Stop and drain timing
A stop grace deadline is not a stop result. A drain deadline is not proof that the channel drained. If the deadline expires, Steward should name the transition: escalated, force-closed, unknown, or still waiting under a stronger substrate rule.

## Freshness timing
A material or probe witness that was fresh at one time may be stale now. The UI must degrade or recheck rather than keep a green badge alive from old evidence.

## Recovery timing
After manager restart, monotonic deadlines from the prior process cannot be blindly reused. Durable receipts may retain historical times, but currentness must be reacquired or downgraded.

## Non-goals
- no universal time synchronization protocol;
- no global lease service;
- no rate-limit or quota calendar;
- no scheduler;
- no workflow timer family.

## References
REF-HTTP-RFC9110; REF-RFC8470-EARLY-DATA; REF-GRPC-RETRY; REF-K8S-CONTAINER-LIFECYCLE-HOOKS.
