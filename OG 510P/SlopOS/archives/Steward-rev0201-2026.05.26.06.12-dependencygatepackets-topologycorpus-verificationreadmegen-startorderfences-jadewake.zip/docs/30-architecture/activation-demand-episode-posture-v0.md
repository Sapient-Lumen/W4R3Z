# Activation-demand episode posture v0

Purpose: name the smallest useful truth for one demand that reaches a manager-owned activation surface while the target component may be cold, waking, draining, not yet ready, or scaling from zero, without turning Steward into a queue, proxy, autoscaler, browser service-worker runtime, or durable workflow system.

## Posture
1. **A demand episode begins before serving may be possible**
   - One request, connection, message, callback, or comparable demand may arrive at an activation surface while no suitable runtime cycle is ready.
   - Steward should be able to say the demand was accepted into an activation episode without implying that the component was already running, ready, or serving.
2. **Accepted, buffered, waking, delivered, and served are different truths**
   - Cold-start systems repeatedly blur these states in user-facing logs.
   - Steward should keep compact episode states such as `accepted`, `buffered`, `waking`, `delivered`, `accepted-by-runtime`, `completed`, `canceled`, `timed-out`, `shed`, `lost`, or `unknown` when the adapter can prove them.
3. **The episode is not the endpoint witness**
   - An activation endpoint may be `armed` long before any concrete demand appears.
   - A demand episode is the per-demand story after something actually arrives at that surface.
4. **The episode is not the activation cause by itself**
   - A first demand may explain why a runtime cycle begins, but the per-demand episode may also time out, be canceled, or be delivered to a different later cycle.
   - Activation-cause receipts should cite demand pressure without pretending the demand outcome is already known.
5. **Cold-start buffering must be budgeted and visible**
   - Serverless activators, browser event dispatchers, and mobile background schedulers all prove that waiting work needs time, count, and loss boundaries.
   - Steward should surface per-demand deadlines, caller cancellation, queue/buffer class, and timeout/shed reasons when available instead of hiding them behind vague startup delay.
6. **Delivery to the runtime and runtime acceptance are separate receipts**
   - A manager/proxy may hand a demand to a newly started component before the component has acknowledged useful ownership of it.
   - Steward should be able to say `delivered but unacknowledged`, `accepted by runtime`, or `delivery unknown` without guessing from logs.
7. **Demand episodes compose with fanout but do not define it**
   - One demand may wake a shared worker, create a per-demand worker instance, or be buffered until a worker appears.
   - The episode should record the delivery topology when known, but fanout topology remains a separate posture.
8. **Extendable event lifetime is useful, but not immortal keepalive**
   - Service-worker-style `wait until this event work settles` is a good shape for bounded event work.
   - Steward should steal the idea of an explicit event/work extension receipt, not a hidden power to keep components alive indefinitely.
9. **Background and exact-wake systems are policy-bounded**
   - Mobile and browser systems increasingly make exact wake, background execution, and long-running event work subject to explicit permission, quota, expiration, and cleanup hooks.
   - Steward should keep those as visible policy/budget facts rather than ambient OS generosity.
10. **Episode loss should be honest**
   - If the caller disconnects, the activator/proxy is restarted, the runtime never becomes ready, or the provider cannot prove delivery, the episode should end with explicit loss/degrade truth.
   - Silent retargeting to a newer request, pretending success after caller timeout, or laundering loss into component health would recreate the ambient folklore Steward is avoiding.
11. **Phase 1 shape is a witness, not an API family**
   - A tentative `activation_demand_episode` witness can stay tiny: `episode_id`, `surface`, `component`, `accepted_at`, optional `deadline`, optional `request_context`, `state`, optional `buffer_scope`, optional `runtime_cycle`, optional `delivery_strength`, optional `fanout_hint`, and optional `outcome_reason`.
   - Field names remain provisional until concrete Steward components prove which details must be portable.

## Phase-1 non-goals
- a generic durable request queue, message broker, activator, autoscaler, or traffic proxy;
- a universal backlog, fairness, or concurrency-control language;
- exactly-once demand delivery or replay semantics;
- treating accepted demand as readiness, serving, success, or authority;
- using buffered demand to bypass start gates, repair gates, hold state, caller deadlines, or cancellation;
- making browser service-worker, Knative, Cloud Run, Android, or iOS lifecycle rules the portable Steward lifecycle contract.

## Adjacent docs
- `activation-endpoint-witness-posture-v0.md`
- `activation-fanout-posture-v0.md`
- `activation-cause-posture-v0.md`
- `request-activation-posture-v0.md`
- `request-context-posture-v0.md`
- `wake-memory-posture-v0.md`
- `activity-bracket-posture-v0.md`
- `backpressure-witness-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `start-gate-posture-v0.md`
- `non-decisions-v0.md`

- `activation-custody-posture-v0.md`
- `activation-work-disposition-posture-v0.md`

## References
- REF-KNATIVE-SERVING-ARCHITECTURE
- REF-KNATIVE-SERVING-REQUEST-FLOW
- REF-KNATIVE-SCALE-TO-ZERO
- REF-CLOUD-RUN-CONTAINER-CONTRACT
- REF-CLOUD-RUN-REQUEST-TIMEOUT
- REF-MDN-EXTENDABLEEVENT-WAITUNTIL
- REF-W3C-SERVICE-WORKERS
- REF-CHROME-EXTENSION-SW-LIFECYCLE
- REF-ANDROID-WORKMANAGER-TASK-SCHEDULING
- REF-ANDROID-EXACT-ALARMS
- REF-APPLE-BACKGROUNDTASKS
- REF-APPLE-BGTASK-EXPIRATION-HANDLER
- REF-SYSTEMD-AUTOMOUNT

## Demand episode executable settlement
Rev0185 settles the first executable packet as `ST-DEMAND v0`, specified in `demand-episode-witness-schema-v0.md` and checked by `../40-verification/demand-custody-effect-corpus-v0.md`. The checker makes demand acceptance digestable while rejecting readiness, custody, work-completion, effect-success, exactly-once, secret-leakage, deadline inversion, and runtime-acceptance-without-cycle claims.
