# Traffic-binding witness schema v0

## Purpose
`ST-TBIND v0` is the first closed packet for one Steward traffic-binding witness. It reports bounded new-demand routing truth for a named traffic surface without letting route, service, alias, DNS, proxy, mesh, target-group, tagged-test, sticky, mirrored, weighted, or draining facts become lifecycle truth.

The central rule: **new-demand binding is not readiness, serving, admission, custody, work completion, external effect success, rollout settlement, deterministic per-request destiny, or live-channel fate.**

## Machine profile
- Machine profile: `../../schemas/st-tbind-v0.schema.json`
- Checker: `../../tools/steward_channel_binding_harness.py`
- Corpus: `../40-verification/corpora/channel-binding-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-TBIND v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `traffic_surface_ref` | named route, alias, service, gateway, DNS, target-group, test tag, or adapter surface |
| `binding_issuer` | closed object naming the observer/controller/proxy/balancer that issued the witness |
| `binding_state` | `desired`, `observed`, `applying`, `active`, `partially_applied`, `draining`, `stale`, or `unknown` |
| `binding_role` | `primary`, `mirror`, `shadow`, `tap`, or `observation_only` |
| `allocation_kind` | `none`, `weighted`, `direct`, `sticky`, `pinned`, `tagged`, `dns`, `topology_hint`, or `unknown` |
| `targets` | bounded target summaries, each with ref, role, weight, and target state |
| `freshness` | source vantage, observed time, freshness state, and optional recheck/expiry |
| `basis_refs` | bounded evidence refs supporting the binding observation |
| `non_implications` | explicit stronger truths this witness refuses |

Optional refs include `route_ref`, `service_ref`, `alias_ref`, `component_id`, `revision_ref`, `incarnation_id`, binding revision refs, and data-plane timing.

## Non-implication vocabulary
A valid traffic-binding witness must include the base refusals:

- `not-readiness`
- `not-serving`
- `not-admission`
- `not-custody`
- `not-work-completion`
- `not-effect-success`
- `not-rollout-settlement`
- `not-deterministic-per-request`

Draining bindings such as `no_new_work`, `draining_existing`, or `deregistration_delay` must also carry `not-live-channel-fate`. This prevents “route removed” from becoming “all old connections are gone.”

## Target rules
Targets are summaries, not portable endpoint authority. Each target has:

- `target_ref`
- `role`
- `weight`
- `state`

Active, applying, partially-applied, and draining bindings require at least one target summary. Weighted bindings require positive total target weight. Weights are allocation instructions and observation hints, not per-request guarantees.

The packet rejects host/runtime endpoint names such as pod names, container ids, host units, PIDs, process names, or cgroups. Those may be adapter evidence under the membrane, but they are not the portable route witness.

## Freshness rules
Freshness is scoped to a source vantage. `fresh`, `last_known`, `stale`, and `unknown` are distinct. Stale or unknown facts must explain why they downgraded. `expires_or_recheck_by_ms` cannot precede `observed_at_ms`.

## Rejected surfaces
The corpus rejects:

- route witnesses that claim readiness;
- active bindings with no target summary;
- missing non-implication sets;
- negative weights;
- raw pod-name endpoint leakage;
- duplicate JSON keys.

## Non-goals
- no portable load balancer, service mesh, DNS failover system, Gateway API implementation, route compiler, canary controller, topology router, or traffic simulator;
- no deterministic per-request routing promise from weights or locality hints;
- no route-state shortcut to readiness, serving, admission, custody, work completion, effect success, rollout settlement, rollback completion, or live-channel fate.

## Adjacent docs
- `activation-traffic-binding-posture-v0.md`
- `live-channel-witness-schema-v0.md`
- `activation-live-channel-posture-v0.md`
- `activation-control-verdict-posture-v0.md`
- `activation-probe-vantage-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `adapter-membrane-posture-v0.md`
- `canonical-json-profile-v0.md`
