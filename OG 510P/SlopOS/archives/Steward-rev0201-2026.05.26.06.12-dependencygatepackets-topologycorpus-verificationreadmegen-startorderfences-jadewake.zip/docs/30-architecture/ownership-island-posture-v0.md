# Ownership-island posture v0

Purpose: define a **tiny shallow ownership-island seam** so Steward can talk about containment, activation scope, and exact lifecycle targeting for one reviewed subtree without freezing a giant realm, topology, environment-inheritance, or discovery language.

## Posture
1. **An ownership island is a reviewed lifecycle boundary first**
   - An ownership island means one reviewed root component plus a bounded set of owned descendants that share one containment and restart story.
   - The seam exists to answer questions such as “what work belongs to this owner?” and “what should stop or explain together?” without making the whole component topology public API.
2. **Ownership tree and capability routes stay distinct**
   - Ownership says who controls existence and containment.
   - Capability routing says who may use which exported thing.
   - Steward should keep those truths separable instead of flattening them into one giant graph algebra.
3. **Control may target a component or a whole island**
   - A future lifecycle action should be allowed to mean “this component” or “this ownership island” when that scope is genuinely useful.
   - Island targeting is promising for quiesce, stop, explain, and restart-adjacent review, but it should stay smaller than a universal selector language.
4. **Activation scope may be island-local without becoming ambient**
   - A reviewed request or stable handle may wake one exact component or one exact reviewed island path.
   - Steward should not let island scope dissolve into ambient environment inheritance, bus names, or hidden service-discovery folklore.
5. **Parents own existence; children should not silently escape the island story**
   - If an island owner stops, owned child work should stop, transfer under a separately reviewed owner, or become visibly replaced.
   - Steward should avoid quiet orphaning that preserves accidental liveness while the ownership story changed underfoot.
6. **External observers may see summaries while internal structure stays partly opaque**
   - A shell, receipt, or explanation surface may show the current island name, root component, or reviewed purpose.
   - Outsiders do not need a full recursive topology dump just to understand the current control scope.
7. **Shell and terminal chrome may surface island truth as observation, not authority**
   - Breadcrumb rails, execution-ground chips, and action palettes may carry exact island targets or island summaries.
   - Those affordances remain explicit target objects; they do not make remembered chrome into ambient control power.
8. **Degrade honestly to narrower truth when exact island scope is unavailable**
   - If an adapter cannot preserve exact island membership across a hop, restart, or foreign runtime, Steward should fall back to `component` truth or deny the broader action.
   - It should not silently broaden or weaken the target and pretend the island survived intact.
9. **Keep the phase-1 public contract tiny**
   - Phase 1 likely needs only the idea that some components belong to one reviewed shallow ownership island, plus optional exact targeting/explanation at that scope.
   - Avoid freezing recursive selectors, topology queries, environment inheritance rules, or distributed placement meaning before repeated pressure exists.
10. **Treat islands as a containment convenience, not a constitutional empire**
   - The seam should help Steward explain grouped work and bounded restart/control scope.
   - It should not become a hidden excuse to invent a whole component-framework constitution inside Steward while SlopOS itself is still moving.

## Phase-1 non-goals
- freezing a universal realm tree grammar or recursive topology query API;
- defining one portable capability-routing, service-discovery, or environment-inheritance language;
- promising that every implementation can target arbitrary deep subtrees for every lifecycle verb;
- treating island identity as a replacement for component identity, runtime-cycle witnesses, or receipts;
- exporting internal child graphs, host process trees, or foreign runtime layouts as the public meaning of an island.

## Adjacent docs
- `control-target-posture-v0.md`
- `activation-posture-v0.md`
- `execution-group-posture-v0.md`
- `quiesce-posture-v0.md`
- `action-surface-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-FUCHSIA-REALMS
- REF-FUCHSIA-TOPOLOGY
- REF-ERLANG-OTP-SUPERVISOR
- REF-S6-SVC
