# State-attachment witness schema v0

## Purpose
`ST-STATEATT v0` is the first closed packet for one Steward state-attachment witness. It reports that a state-like object, projected material, scratch area, persistent volume, runtime directory, snapshot-derived cache, or external attachment is present, absent, restoring, detaching, stale, or unknown without turning that observation into lifecycle, freshness, path, custody, work, or effect authority.

The central rule: **attached is not fresh, usable, path-authorized, current-incarnation-safe, ready, serving, work-complete, or effect-successful.**

## Machine profile
- Machine profile: `../../schemas/st-stateatt-v0.schema.json`
- Checker: `../../tools/steward_currentness_control_harness.py`
- Corpus: `../40-verification/corpora/currentness-control-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-STATEATT v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the observer or attachment adapter |
| `attachment_ref` | stable ref for the attachment being described |
| `attachment_kind` | `image_readonly`, `runtime_scratch`, `incarnation_tmp`, `component_data`, `persistent_volume`, `projected_material`, `manager_runtime_dir`, `snapshot_derived`, `external_mount`, or `unknown` |
| `attachment_state` | `attaching`, `attached`, `detaching`, `detached`, `cleanup_pending`, `cleanup_complete`, `restored`, `stale`, or `unknown` |
| `authority_class` | `evidence_only`, `steward_attached`, `adapter_attached`, `substrate_attached`, `external_claim`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `basis_refs` | bounded evidence refs supporting the witness |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `runtime_cycle`, `incarnation_id`, `material_ref`, `snapshot_ref`, `freshness_ref`, `retention_class`, `lifetime_class`, `rebind_state`, `migration_state`, and `expires_or_recheck_by_ms`.

## Required non-implications
A valid packet must include:

- `not-readiness`
- `not-serving`
- `not-material-currentness`
- `not-custody`
- `not-work-completion`
- `not-effect-success`
- `not-path-authority`

Snapshot-derived attachments may also carry `not-current-incarnation`.

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Raw path, file descriptor, bearer, token, secret, host unit, PID, cgroup, pod, or container names reject.
- `projected_material` attachments require `material_ref`.
- `attached` and `restored` states require `runtime_cycle` or `incarnation_id`.
- `snapshot_derived` attachments require explicit `rebind_state`.
- `stale` and `unknown` attachment states require `unknown_reason`.
- `expires_or_recheck_by_ms` cannot precede `observed_at_ms`.

## Rejected surfaces
The corpus rejects:

- attachment witnesses carrying raw path authority;
- attachment witnesses claiming readiness;
- projected attachments without material refs;
- attached state without a cycle/incarnation fence;
- duplicate JSON keys.

## Non-goals
- no filesystem namespace API, volume manager, mount manager, checkpoint/restore protocol, migration system, stateful workload controller, storage scheduler, path-open API, or secret/config store;
- no bearer authority, path grant, volume handle, raw descriptor, or cross-component import token;
- no inference from attachment to freshness, current material use, readiness, serving, custody, work completion, or effect success.

## Adjacent docs
- `activation-state-attachment-posture-v0.md`
- `material-freshness-witness-schema-v0.md`
- `activation-material-freshness-posture-v0.md`
- `activation-residency-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `receipt-minimization-posture-v0.md`
- `canonical-json-profile-v0.md`
