# Activation-effect boundary posture v0

Purpose: name the smallest useful truth for **whether one admitted activation work item may already have crossed a side-effect boundary** after retry, acknowledgement, disposition, crash, restart, or late-arriving request ambiguity.

This seam is intentionally small. It does **not** invent a transaction coordinator, saga engine, outbox service, compensating-action framework, global idempotency ledger, or exactly-once side-effect plane. It answers one narrower question: **what externally visible effect boundary, if any, can Steward honestly name for this exact work without pretending work disposition, retries, or idempotency keys prove more than they do?**

## Posture
1. **Effect boundary is different from work disposition**
   - Work disposition says what became of the item in the activation fabric: acknowledged, redelivered, expired, dead-lettered, discarded, abandoned, detached, superseded, or unknown.
   - Effect boundary says whether the item may have produced or committed an externally visible effect: no effect begun, local-only preflight, local commit, outbox recorded, external submit sent, external accepted, external confirmed, compensating action required, compensated, irreversible, or unknown.
   - Steward should not let `acknowledged`, `completed`, `dead-lettered`, or `discarded` automatically imply `no side effect` or `effect completed once`.

2. **Effect keys name retry equivalence; they do not prove effect fate**
   - An effect key can help suppress duplicate mutation attempts or return a semantically equivalent response for a bounded window.
   - The key is not proof that the external effect never started, definitely completed, remains queryable, or can still be suppressed after retention expiry.
   - If the same key is reused with a different fingerprint, the useful truth is `effect-key-mismatch`, not a quiet upsert or a new lifecycle attempt.

3. **Caller-chosen intent beats parameter guessing**
   - Systems that infer duplicates from identical parameters can confuse two intentionally identical effects with one retry.
   - Steward should prefer caller-chosen or manager-chosen intent keys, reviewed fingerprints, and visible duplicate/mismatch outcomes when a non-commutative effect needs retry safety.

4. **Local commit and external publication are separate boundaries**
   - Transactional outbox patterns are valuable because they keep the local state mutation and the intent-to-publish record atomic under one local store boundary.
   - They do not by themselves prove the downstream broker accepted, delivered, consumed, acknowledged, or applied the effect exactly once.
   - Steward should steal `local commit plus outbox record` as evidence, not import an outbox service or event-sourcing architecture.

5. **Publisher confirms and consumer acknowledgements are orthogonal**
   - A broker may confirm publisher custody while consumer processing remains future work.
   - A consumer acknowledgement may delete or commit delivery without proving the publisher's original intent boundary, the handler's external side effects, or application-level consistency.
   - Steward should keep `publish-confirmed`, `delivery-acknowledged`, and `effect-confirmed` as different strengths when the substrate exposes them.

6. **Exactly-once claims require cooperating boundaries, not hope**
   - Some substrates offer stronger dedupe, transaction, or exactly-once processing within a defined scope.
   - Steward should record the scope and proof strength if available, but fall back to duplicate-risk / effect-unknown when the handler crosses non-cooperating systems.
   - The portable claim should be no stronger than the weakest boundary actually named.

7. **Compensation is application-specific and may fail**
   - A compensating action may undo, counteract, refund, or repair a completed effect, but it is not generic rollback.
   - It may need human choice, may not run in reverse order, may be retried, and may require its own progress evidence.
   - Steward should surface `compensation-available`, `compensation-started`, `compensation-succeeded`, `compensation-failed`, `manual-repair-required`, and `irreversible` as explanation hints, not a saga contract.

8. **Irreversible floors deserve explicit labels before retry/redrive**
   - Some effects cross a point where replay, cancellation, or cleanup cannot safely restore the prior world.
   - Before proposing automatic retry, redrive, or discard, Steward should be able to say `irreversible-floor-crossed`, `effect-unknown`, or `manual-review-required` when that is the strongest honest truth.

9. **Late-arriving requests can preserve response semantics without restoring current state**
   - A retry with a prior idempotency key may receive a semantically equivalent answer even after the originally created thing moved on or was deleted.
   - That is useful client-side, but it should not be mistaken for current runtime state, current ownership, or a fresh effect grant.

10. **Receipts should be useful for repair without becoming bearer authority**
    - Useful chips include `no effect begun`, `effect pending`, `local commit only`, `outbox recorded`, `publish confirmed`, `external accepted`, `effect confirmed`, `duplicate suppressed`, `effect key mismatch`, `compensation required`, `irreversible`, and `effect unknown`.
    - Those chips may support reviewed inspect, retry, compensate, reconcile, or manual-repair actions, but the chip itself must not become a queue handle, transaction token, or reusable grant.

11. **Phase 1 shape is a witness, not a transaction API**
    - A tentative `activation_effect_boundary` witness can stay tiny: `effect_boundary_id`, `episode_id` or `disposition_id`, optional `effect_key`, optional `effect_fingerprint`, `effect_family`, `boundary`, optional `proof_strength`, optional `idempotency_retention`, optional `publisher_or_external_ref`, optional `compensation_state`, optional `irreversible_floor`, optional `late_retry_state`, and optional `basis`.
    - Field names remain provisional until concrete Steward components prove which details must be portable.

## Phase-1 non-goals
- a global idempotency ledger, transaction coordinator, saga engine, workflow runtime, or compensating-action framework;
- a portable outbox service, event-store, broker, queue, redrive system, or exactly-once side-effect plane;
- claiming that acknowledgement, queue deletion, offset commit, handler return, component health, or runtime restart proves effect success;
- automatically retrying, redriving, compensating, or discarding work after an unknown or irreversible side-effect boundary;
- making Stripe idempotency, AWS client tokens, transactional outbox, Debezium outbox routing, RabbitMQ confirms, Pub/Sub exactly-once, Kafka transactions, or Azure compensating transactions into Steward's portable architecture.

## Adjacent docs
- `activation-work-disposition-posture-v0.md`
- `activation-custody-posture-v0.md`
- `activation-demand-episode-posture-v0.md`
- `activation-admission-posture-v0.md`
- `effect-key-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `fence-token-posture-v0.md`
- `retry-advice-posture-v0.md`
- `repair-gate-posture-v0.md`
- `state-explainer-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-AWS-BUILDERS-IDEMPOTENT-APIS
- REF-STRIPE-IDEMPOTENT-REQUESTS
- REF-AWS-TRANSACTIONAL-OUTBOX
- REF-DEBEZIUM-OUTBOX-EVENT-ROUTER
- REF-RABBITMQ-ACKS-CONFIRMS
- REF-GCP-PUBSUB-EXACTLY-ONCE
- REF-KAFKA-DESIGN
- REF-AZURE-COMPENSATING-TRANSACTION
- REF-IETF-IDEMPOTENCY-KEY
- REF-AWS-EC2-IDEMPOTENCY
- REF-AWS-ECS-IDEMPOTENCY

## Effect-boundary executable settlement
Rev0185 settles the first executable packet as `ST-EFFECT v0`, specified in `effect-boundary-witness-schema-v0.md` and checked by `../40-verification/demand-custody-effect-corpus-v0.md`. The checker names submit, confirmation, duplicate replay, same-key mismatch, bounded retention, and ambiguity without letting effect evidence become work completion, rollbackability, current authority, or exactly-once execution.
