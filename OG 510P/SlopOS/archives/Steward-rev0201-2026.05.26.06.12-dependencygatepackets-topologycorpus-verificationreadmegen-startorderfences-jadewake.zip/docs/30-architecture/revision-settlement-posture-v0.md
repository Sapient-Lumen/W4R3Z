# Revision-settlement posture v0

Purpose: keep **reviewed desired revision**, **currently observed revision**, and **most recently settled/stable revision** visibly different so lifecycle, reload, and rollout truth does not collapse into one flattering “updated” bit.

This seam stays intentionally small. It does **not** invent a universal controller-runtime, rollout planner, or canary grammar. It only says that when Steward accepts a newer reviewed basis, the archive should preserve a tiny honest way to say whether the live status already reflects that basis and whether any stronger settlement/stability threshold has been reached.

## Posture
1. **Desired revision, observed revision, and settled revision stay separate**
   - A reviewed request may establish a newer desired revision before the running component or adapter has actually observed it.
   - A component may then observe that revision before the system is willing to call it settled or stable enough for promotion, replacement, or “done” chrome.
2. **Acceptance is not settlement**
   - “The manager accepted the new basis” is weaker than “current status reflects that basis”, which is in turn weaker than “the new basis has settled cleanly enough to rely on”.
   - Steward should keep those truths distinct instead of letting one green badge impersonate all three.
3. **Observed revision belongs to exact status, not to latest hope**
   - If status still reflects an older revision, Steward should say so plainly even when a newer desired revision already exists.
   - That observed truth may legitimately lag inside one still-running runtime cycle.
4. **Settlement may depend on health, dwell, promotion, or explicit operator confirmation**
   - Some adapters can treat “observed and healthy long enough” as settled.
   - Others may require manual promotion, canary confirmation, or explicit rollback/revert handling before the newer revision should count as the current settled basis.
5. **Rollback and retry should anchor to settled revision, not just latest attempt**
   - When a newer revision stalls or fails, the archive should be able to say which earlier revision was last settled rather than forcing operators to infer that from logs or memory.
   - That remains useful even if the portable shape never grows into a full rollout engine.
6. **Unknown and mixed settlement are healthier than fake precision**
   - Some runtimes can prove desired, observed, and settled revision distinctly.
   - Others may only know desired and observed, or may only know that settlement is pending/unknown. Steward should preserve that honesty.
7. **Shell chrome should make revision drift legible without becoming authority**
   - Execution-ground cards, receipts, and command frames may show compact labels such as `desired r14`, `observed r13`, `settled r12`, `pending promotion`, or `settlement unknown`.
   - Those labels explain why the system is waiting; they do not themselves grant apply, promote, or rollback rights.
8. **This seam is smaller than a deployment controller**
   - Steward may use revision-settlement truth to explain reload progress, stale previews, rollback targets, or why replacement has not advanced yet.
   - It should not thereby freeze a universal reconcile loop, canary planner, or version-vector family.
9. **Exact footing still matters**
   - Revision-settlement truth should remain attributable to exact targets, exact reviewed bases, and exact observation footing.
   - If the grounding changes, Steward should prefer `stale`, `recheck`, or `unknown` over silently carrying old settlement forward.
10. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional desired/observed/settled triple (or weaker subset) plus compact pending/failed/unknown notes when the adapter can prove them.
   - Larger controller families remain intentionally undecided.

## Phase-1 non-goals
- a universal rollout / deployment / reconcile engine;
- a mandatory canary, blue-green, or promotion grammar;
- a universal rollback-policy algebra or stable-version wallet;
- forcing every runtime to expose desired, observed, and settled revision separately;
- treating settlement labels as approvals, delegation tokens, or hidden mutation rights.


## Rev0198 executable settlement
The rollout-generation corpus gives this posture a narrow proof slice without turning Steward into a deployment controller. `ST-GENPLAN`, `ST-RECONFAPPLY`, `ST-GENREADY`, and `ST-PROMOTION` keep planned, applied, ready, and promoted generations separate and reject rollback-as-compensation, promotion-as-serving, and stale-readiness promotion.

## Adjacent docs
- `readiness-generation-posture-v0.md`
- `stability-window-posture-v0.md`
- `progress-window-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `preflight-lane-posture-v0.md`
- `execution-ground-posture-v0.md`
- `decision-map.md`
- `non-decisions-v0.md`

## References
- REF-K8S-PODS-OBSERVED-GENERATION
- REF-K8S-DEPLOYMENT
- REF-NOMAD-UPDATE
- REF-NOMAD-DEPLOYMENT-STATUS
- REF-SD-NOTIFY
- REF-SYSTEMD-SERVICE
