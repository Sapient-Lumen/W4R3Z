# Control-operation request schema v0

## Purpose
`ST-OPREQ v0` is the first closed packet for a reviewed Steward lifecycle mutation. It carries one operator, automation, adapter, or repair-gate request such as `start`, `stop`, `restart`, `quiesce`, or `refresh` without letting the request target raw host folklore.

This schema is intentionally smaller than a remote-management API. It answers only: **what exact lifecycle operation was requested, by whom, against which Steward target, under which stale fences, and with which duplicate-suppression key?**

## Machine profile
- Machine profile: `../../schemas/st-opreq-v0.schema.json`
- Checker: `../../tools/steward_operation_harness.py`
- Corpus: `../40-verification/corpora/control-operation-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-OPREQ v0` |
| `op_id` | canonical operation id matching `op_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `verb` | one of `start`, `stop`, `restart`, `quiesce`, `refresh` |
| `issuer` | closed object naming request issuer kind and id |
| `target` | closed object naming the Steward component target and expected fences |
| `reason` | bounded human/audit reason, not raw secret or token material |
| `preconditions` | bounded list of witness refs used as stale fences or explicit waivers |
| `idempotency_key` | canonical duplicate-suppression key matching `idem_[a-z0-9]{16}` |

Optional timing fields use integer milliseconds only: `requested_at_ms`, `not_before_ms`, and `deadline_ms`. They are scheduling constraints, not capacity reservations.

## Target rules
A request target is always `kind: component`. Its `cid` must equal the root `cid`.

- `start` requires `target.expected_manifest_digest`.
- `stop`, `restart`, `quiesce`, and `refresh` require `target.expected_cycle`.
- `expected_activation_digest` and `expected_status_barrier` may narrow the request further.

The packet rejects portable authority by PID, cgroup path, host unit name, pod name, container id, terminal pane, shell job, or “latest matching service.” Adapters may retain those facts under their membrane, but the portable operation packet cannot target them.

## Preconditions
A precondition has `kind`, `ref`, and `state`. The v0 kinds are:

- `manifest_digest`
- `runtime_cycle`
- `fresh_intent`
- `repair_gate`
- `status_barrier`
- `activation_digest`
- `operator_approval`

`state` is either `present` or `waived`. A waiver is not authority; it is audit evidence that a fence was bypassed by a reviewed caller or sibling policy surface.

## Idempotency rule
The same `idempotency_key` may replay the same canonical request digest. It must not cover a different canonical operation intent. This keeps duplicate button presses, retries, terminal reconnects, and shell replay from widening a mutation.

## Timing rule
`not_before_ms` must not exceed `deadline_ms`. `requested_at_ms` must not exceed `deadline_ms`. These fields only bound when an operation request may be considered; they do not reserve capacity, assert readiness, or prove operation completion.

## Non-goals
- no portable PID/process API;
- no systemd unit or Kubernetes object targeting as native authority;
- no hidden broad RBAC model;
- no durable workflow graph;
- no effect-success or component-state claim in the request packet.

## Corpus obligations
The operation corpus rejects:

- raw PID targets;
- host unit targets;
- stop without a runtime-cycle fence;
- malformed idempotency keys;
- duplicate JSON keys;
- bad time windows;
- same idempotency key with different canonical intent.

## Adjacent docs
- `control-operation-posture-v0.md`
- `admin-surface-posture-v0.md`
- `control-target-posture-v0.md`
- `status-barrier-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `fresh-intent-posture-v0.md`
- `receipt-minimization-posture-v0.md`
