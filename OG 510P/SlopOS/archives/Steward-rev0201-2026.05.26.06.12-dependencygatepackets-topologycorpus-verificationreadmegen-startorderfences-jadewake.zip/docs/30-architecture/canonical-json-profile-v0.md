# Canonical JSON profile v0

## Purpose
Pin the minimum canonicalization rule Steward needs for CH-COMP, CH-ACTSET, and the first lifecycle corpus.

This is not a general serialization empire. It is a small authoring and digest profile so proof artifacts can agree on what bytes were reviewed.

## Profile
A Steward canonical JSON object in this profile has:

- UTF-8 encoding;
- object keys sorted lexicographically when rendered for digest;
- compact separators;
- no duplicate object keys at decode time;
- no floats;
- no NaN, infinity, comments, trailing commas, or implementation extensions;
- strings interpreted as Unicode scalar values, not shell text or host paths unless the containing schema says so;
- digest surface `sha256:<hex>` over the canonical bytes.

## Closed-world authority objects
Objects that can carry or constrain authority use closed-world decode. Unknown fields reject. Duplicate keys reject. Enum variants outside the declared set reject.

The first closed-world authority objects are:

- CH-COMP v0;
- CH-ACTSET v0.

Weak annotations may later have explicit extension slots, but an extension slot must never strengthen authority, widen activation, change lifecycle target identity, or supply raw bearer material.

## Why not broader now
Steward may later align with SlopOS's final canonical object profile. Until then, this profile is intentionally small and only powers the proof slice.

## Adjacent material
- `schema-registry.md`
- `component-manifest-schema-v0.md`
- `activation-set-schema-v0.md`
- `../../schemas/ch-comp-v0.schema.json`
- `../../schemas/ch-actset-v0.schema.json`
- `../40-verification/component-lifecycle-activation-corpus-v0.md`
