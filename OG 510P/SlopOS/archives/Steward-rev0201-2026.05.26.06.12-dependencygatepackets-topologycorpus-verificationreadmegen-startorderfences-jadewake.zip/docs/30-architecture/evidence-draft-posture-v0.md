# Evidence-draft posture v0

Purpose: define a **tiny exact evidence-draft seam** so Steward can derive a reviewable outbound subset from one exact command-evidence object, output slice, receipt span, or similar reviewed anchor before attach / share / escalation without flattening whole scrollback into ambient truth.

## Posture
1. **Source evidence and outbound draft are different truths**
   - The exact source object stays immutable and provenance-bearing.
   - An evidence draft is the reviewed outbound subset or masking of that stronger source.
   - Steward should preserve both truths instead of pretending a trimmed export is the original object.
2. **Drafts should start from the strongest exact anchors available**
   - The healthiest owners are exact command-evidence objects, output slices, receipt spans, runtime-cycle witnesses, or other reviewed anchors.
   - Parse-lens candidates and visible-text selection can seed a draft only as visibly weaker footing.
3. **Review-before-share should be first-class**
   - Before attach / export / escalate, Steward should let the user review what will leave the local surface.
   - That review should feel like a supported move, not a desperate fall back to copy/paste surgery.
4. **Omission and masking should preserve provenance**
   - Users may need to drop cwd, host lineage, exact timestamps, receipt refs, or selected output lines.
   - Steward should be able to say `derived from exact command evidence`, `trimmed`, `masked`, or `subselected` instead of laundering the draft back into pristine exactness.
5. **Small notes may be added without rewriting the source truth**
   - A draft may carry a short user note such as `why I am sending this` or `focus on this block`.
   - That note should be clearly additive metadata, not a mutation of the underlying command or output record.
6. **Export is a separate boundary-crossing act**
   - Creating a draft is not the same thing as sending it.
   - The draft should remain local, revisable, and cancelable until an explicit attach / share / export action occurs.
7. **Whole-pane export should remain exceptional**
   - If the user truly wants raw whole-frame or whole-pane bytes, Steward may still allow it.
   - But the normal path for `attach last failure` or `share this interaction` should start from one bounded exact object, then derive one reviewed outbound draft.
8. **The phase-1 contract should stay tiny**
   - Phase 1 likely needs only: source refs, bounded included fields/spans, omitted or masked fields, optional short note, and visible provenance labels.
   - Avoid freezing a universal issue-report schema, collaboration protocol, durable outbound queue, or cross-tool attachment bus before repeated pressure proves it is worth standardizing.

## Phase-1 non-goals
- turning drafts into durable workflow tickets, inbox items, or collaboration threads;
- silently mutating the underlying source evidence while the user trims or masks the outbound view;
- pretending parsed candidates or visible-text selections are as strong as exact source evidence;
- freezing a universal bug-report, chat-export, or share-template grammar;
- auto-exporting newly created drafts without an explicit boundary-crossing action.

## Adjacent docs
- `command-evidence-posture-v0.md`
- `output-slice-posture-v0.md`
- `context-handoff-posture-v0.md`
- `target-anchor-posture-v0.md`
- `parse-lens-posture-v0.md`
- `precision-fence-posture-v0.md`
- `paste-firewall-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-GIT-ADD
- REF-VSCODE-UPDATE-1106
- REF-VSCODE-CONTEXT-CONCEPTS
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-SELECT-TEXT-AT-MOUSE
