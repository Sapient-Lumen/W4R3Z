# Progress-window witness schema v0

`ST-PROGRESS v0` is a closed Steward packet for one bounded progress window during start, reload, resume, drain, or similar lifecycle movement.

## Purpose
A progress witness records that a lifecycle attempt is in progress, advanced, extended, held, stalled, or unknown relative to an explicit checkpoint and deadline. It does **not** prove readiness, stability, serving, work completion, effect success, authorization, execution, mutation, or current state.

## Required fields
- `schema`: exactly `ST-PROGRESS v0`.
- `witness_id`: stable witness id.
- `cid`: component id.
- `issuer`: closed issuer object.
- `progress_id`: stable progress id.
- `attempt_ref`: exact operation, runtime-cycle, or resume attempt ref.
- `checkpoint_ref`: exact checkpoint basis.
- `progress_state`: `in_progress`, `advanced`, `extended`, `held`, `stalled`, or `unknown`.
- `window_opened_ms`: local monotonic time the window began.
- `checkpoint_observed_ms`: local monotonic checkpoint observation time.
- `deadline_ms`: local monotonic deadline for the window.
- `extension_count`: bounded explicit extension count.
- `hold_refs`: active holds explaining held progress.
- `stall_reason`: `none` unless stalled or unknown.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for readiness, serving, stability, effect success, work completion, current state, authorization, execution, and mutation.

## Rejection examples
- held progress without an active hold ref;
- past-deadline progress still marked in progress, advanced, or extended;
- extended progress with zero extensions;
- stalled/unknown progress without a reason;
- readiness, stability, serving, execution, work-completion, currentness, or effect-success claims.
