# Rollout generation proof posture v0

Steward now treats component generation movement as a proof slice with four packet families:

- `ST-GENPLAN v0` — planned/admitted/deferred/abandoned generation intent;
- `ST-RECONFAPPLY v0` — runtime-cycle-bound application/reload attempt;
- `ST-GENREADY v0` — scoped, expiring readiness evidence for one generation;
- `ST-PROMOTION v0` — scoped promotion or rollback of a generation into traffic mapping.

## Boundary rule
Projected material is not freshness. Fresh material is not reload. Reload is not readiness. Readiness is not serving. Promotion is not effect success. Rollback of a route is not compensation for work already performed.

## Why this exists
Earlier Steward revisions had separate material-freshness, probe, traffic-binding, coordination, and operation packets. The missing seam was the generation path that connects them. Without this seam, a UI or adapter can accidentally say “new config is present” and render that as “new generation is live,” or say “canary promoted” and render that as “all work succeeded.”

## Non-goals
- No rollout controller.
- No scheduler.
- No service mesh.
- No config/vault plane.
- No durable workflow history.
- No global release orchestration.

## Required separations
- Generation plan does not prove material freshness, apply, reload, readiness, promotion, serving, or effects.
- Reconfiguration apply does not prove readiness, promotion, serving, all-worker update, current state, or effects.
- Generation readiness does not prove traffic binding, serving, global readiness, stability, or effects.
- Promotion does not prove serving, drain, lossless transition, work completion, rollback success, or effects.

## Executable settlement
`docs/40-verification/rollout-generation-corpus-v0.md` and `tools/steward_rollout_generation_harness.py` settle the first corpus. The harness rejects plan/apply/ready/promotion shortcuts, stale readiness promotion, abandoned-plan apply, duplicate generation drift, and semantic flattery.
