# Reconfigure posture v0

Purpose: define a **tiny in-place reconfigure seam** so `reload`, `refresh`, or `reread parameters` truth stays visibly separate from **restart**, **replacement**, and hidden signal folklore.

This seam is intentionally small. It does **not** design a config-management plane, package-upgrade workflow, or universal hot-reload contract. It only says Steward should be able to answer a narrower question honestly: **can this component apply some reviewed configuration or generation change in place, how was that attempted, and what happened next?**

## Posture
1. **In-place reconfigure is not restart**
   - A component may be able to reread parameters, refresh a running snapshot, or acknowledge a reload without tearing down the current runtime cycle.
   - Steward should keep that distinct from stop→start, full reset, or replacement of the component object.

2. **Support for reconfigure should be explicit**
   - Some components can genuinely apply selected changes in place.
   - Others cannot, or can do so only for a narrow subset.
   - Steward should prefer explicit truth such as `can reconfigure`, `cannot reconfigure`, or `unknown` over host folklore like “maybe send SIGHUP and hope”.

3. **A reconfigure request and its result are separate from config editing**
   - Editing desired config, committing a running snapshot, and asking the live component to apply that change are different events.
   - Steward should preserve those distinctions instead of flattening them into one vague `updated` bit.

4. **Asynchronous fire-and-forget reload is weaker than acknowledged reconfigure**
   - A bare signal or equivalent one-way nudge may start a reconfigure path, but without completion it is weak evidence.
   - When a substrate can prove completion or result, Steward should keep that stronger truth visible.

5. **Fallback from reconfigure to restart should stay explicit**
   - Some managers can offer `reload-or-restart` style helpers.
   - That can be useful locally, but Steward should avoid silently laundering a failed or unsupported in-place reconfigure into ordinary restart truth.
   - If fallback occurs, shells and receipts should be able to say so.

6. **Reconfigure admission is state-scoped**
   - A component may support in-place reconfigure in principle while not admitting it during `starting`, `stopping`, `draining`, or other transition states.
   - Steward should therefore keep `supports reconfigure`, `reconfigure admitted now`, and `reconfigure in progress` as different truths when the adapter can prove them.

7. **Result and freshness matter**
   - A useful phase-1 shape is no more than optional compact truth such as `reconfigure in progress`, `reconfigure applied`, `reconfigure failed`, `restart required`, or `unknown`, plus optional basis such as the observed generation or config revision when that footing is available.
   - Steward should resist turning this into a giant rollout, diff, or config-distribution family.

8. **Unknown is healthier than pretending universal hot reload**
   - Many components cannot safely reconfigure in place, and many substrates cannot prove much beyond `a reload request was sent`.
   - Steward should preserve that honesty rather than teaching an ambient “every service reloads” myth.

## Explicit non-goals
- a universal configuration schema, diff engine, or live-edit plane;
- promising every component can hot-reload;
- standardizing signal names or process-local config conventions as public meaning;
- silently converting failed/unsupported reconfigure into ordinary restart;
- turning reconfigure support into a giant compatibility matrix or rollout controller.


## Rev0198 executable settlement
The rollout-generation proof slice adds `ST-GENPLAN v0` and `ST-RECONFAPPLY v0` as the first machine-checkable settlement for this posture. The packets keep reconfigure admission, material-freshness refs, runtime-cycle-bound apply attempts, reload mode, restart-required outcomes, and failure reasons distinct. A successful apply witness still refuses readiness, promotion, serving, all-worker update, current state, and effect success.

## Adjacent docs
- `activation-overlay-posture-v0.md`
- `control-target-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `progress-window-posture-v0.md`
- `readiness-generation-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `start-gate-posture-v0.md`
- `exit-disposition-posture-v0.md`
- `state-explainer-posture-v0.md`

## References
- REF-SYSTEMD-SERVICE
- REF-SYSTEMD1-DBUS
- REF-SMF-REFRESH
- REF-SMF-RESTART
- REF-WINDOWS-CONTROLSERVICE
- REF-WINDOWS-SERVICE-STATUS
