# Control-operation posture v0

Purpose: define a **tiny explicit control-operation seam** so one requested `start`, `stop`, `restart`, `refresh`, or comparable manager-mediated lifecycle operation can be **queued**, **skipped**, **timed out**, **dependency-blocked**, **canceled**, or **completed** without being mistaken for the component's steady state, one-cycle termination cause, or broader workflow meaning.

This seam stays intentionally small. It does **not** invent a portable controller-runtime, rollout engine, workflow queue, or giant async job API. It only says Steward should be able to answer a narrower question honestly: **what happened to that exact lifecycle operation request?**

## Posture
1. **A requested operation is not the same as the component's current state**
   - `start requested`, `restart queued`, or `refresh canceled` describe one manager-mediated attempt.
   - `active`, `stopped`, `failed (latched)`, `serving`, or `maintenance` describe current or remembered component truth.
   - Steward should not flatten those into one vague state label.
2. **Queued, running, and finished operation truth should stay separate**
   - A lifecycle operation may be accepted and waiting, actively executing, or already removed with a result.
   - Steward should preserve that distinction when the adapter can prove it instead of pretending every requested action takes effect immediately.
3. **Finished operation result is different from unit/runtime result**
   - Historical managers can report operation results such as `done`, `canceled`, `timeout`, `dependency`, or `skipped` without implying that the underlying component entered `failed` state.
   - Steward should steal that honesty directly.
4. **Timeout of the wait path is not always timeout of the component itself**
   - Some substrates distinguish *the operation waiting too long* from *the unit state transition itself failing*.
   - Steward should preserve that split instead of laundering every timeout into crash or terminal failure folklore.
5. **Skip / blocked / dependency-removed should stay milder than failure when the footing can prove them**
   - Condition-unmet, state-inapplicable, or dependency-blocked operations often deserve different operator meaning from a true execution failure.
   - If the adapter can prove only `failed`, it may say that; otherwise Steward should keep `skipped`, `dependency blocked`, or `timed out waiting` visibly distinct.
6. **Operation receipts should stay exact and attributable**
   - A healthy compact receipt names the requested verb, the exact target, when it was queued or observed, optional correlation to the runtime-cycle or generation it was aimed at, and the current/final operation result.
   - This seam is about one exact request, not about generic event archaeology.
7. **Operation result should inform but not overwrite adjacent seams**
   - `start skipped` belongs next to start-gate truth.
   - `stop timed out` belongs next to stop-escalation truth.
   - `refresh done` or `refresh failed` belongs next to reconfigure truth.
   - Steward should keep those seams connected but not collapsed.
8. **Unknown is healthier than fake control-plane precision**
   - Some runtimes can expose first-class queued job state and terminal job results.
   - Others may only let Steward observe that an operation was requested and later infer success from state change. Steward should preserve that honesty.
9. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional exact operation receipt with `verb`, `target`, `phase`/`result`, and optional `reason` or `wait_scope` when provable.
   - Richer queue inspection, cancellation graphs, multi-step workflows, and historical job ledgers remain intentionally undecided.

## Executable packet seam
`ST-OPREQ v0` and `ST-OPRECEIPT v0` make this posture checkable. A request packet names an exact Steward component target, issuer, reason, stale fences, and idempotency key. A receipt packet binds back to the canonical request digest and names operation phase/result without claiming adjacent component state.

The deterministic `control-operation-corpus-v0` rejects PID targets, host-unit targets, missing cycle fences, receipt/request digest mismatch, idempotency-key widening, operation completion that claims component stopped, and manager-recovery paths that keep pre-recovery queued/running currentness.

## Phase-1 non-goals
- a portable async job API or controller-runtime;
- promising every adapter can enumerate queued lifecycle jobs;
- conflating operation timeouts with component crash, failed state, or restart-budget spending;
- a universal dependency-resolution or transaction planner surface;
- turning compact operation receipts into a long-lived workflow history database.

## Adjacent docs
- `action-surface-posture-v0.md`
- `control-operation-request-schema-v0.md`
- `control-operation-receipt-schema-v0.md`
- `control-target-posture-v0.md`
- `start-gate-posture-v0.md`
- `stop-escalation-posture-v0.md`
- `reconfigure-posture-v0.md`
- `status-channel-posture-v0.md`
- `state-explainer-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-UNIT
- REF-SYSTEMD1-DBUS
- REF-SVCADM
- REF-WINDOWS-SERVICE-STATUS

## Revision 190 governance gate

A control operation request is still only a request. Rev0190 adds an optional-but-checkable authority path before execution: `ST-AUTHCHECK v0` can cite `ST-DELEGATE v0`, `ST-REVIEW v0`, and `ST-APPROVAL v0` packets to show why Steward allowed, denied, stalled, or downgraded a lifecycle mutation.

The operation receipt remains separate. Authorization says the operation may be attempted; `ST-OPRECEIPT v0` says what happened to that attempt; narrower lifecycle witnesses such as quiesce, drain, escalation, and termination-cause say what actually became true.
