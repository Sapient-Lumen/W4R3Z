# Session-injection posture v0

Purpose: define a **tiny shell-session injection seam** so commands, environment bundles, and similar UI-originated session changes stay explicit, staged, provenance-labeled, and policy-bounded instead of becoming ambient shell folklore.

## Posture
1. **UI-originated session change is not the same thing as typed input**
   - A quick fix, replay card, environment-variable load, helper launch, or remote convenience action may end up affecting a live shell session.
   - Steward should keep that provenance visible instead of pretending the shell prompt spontaneously decided to do it.
2. **Staging and execution should stay separate when risk matters**
   - Loading an environment bundle, pasting a repaired command, or opening a helper subshell can be delightful.
   - Steward should prefer reviewable staging blocks, cards, or prompt previews over silent immediate execution when context or policy makes the action consequential.
3. **History policy should be explicit**
   - UI-originated commands may deserve ordinary shell history, suppressed shell history, or a separate Steward-side remembered lane depending on purpose.
   - Steward should never let command history effects be an accidental by-product of whichever wrapper trick happened to be available.
4. **Environment loads should be exact and scoped**
   - “Load into this session”, “load into a subshell”, and “apply to this reviewed workflow launch” are different meanings.
   - Steward should keep those scopes explicit and resist ambient rcfile edits or sticky global session mutation as the default convenience path.
5. **Dynamic secret/env loads should store selectors or commands, not ambient secret truth**
   - A secret-manager reference, external command, or reviewed variable bundle can be a useful source for session injection.
   - Steward should keep the provenance and retrieval route explicit and avoid treating a remembered load action as proof that the value is still current, safe, or even available.
6. **Remote or wrapped feature enablement must stay consented and inspectable**
   - Some richer terminal UX depends on remote helpers, shell rc hooks, tmux passthrough, or wrapper commands.
   - Steward should borrow the idea of explicit opt-in setup and visible downgrade rather than making remote magic part of the constitutional truth.
7. **Pane/session vars are observational hints, not authority**
   - Per-pane vars and shell-reported state can enrich status chrome, palette filtering, or receipts.
   - They should not quietly become privileged control input just because they arrived over a fancy side channel.
8. **Clearing, replacing, and expiry should be first-class**
   - If a UI can load env into a session or stage a command, it should also be able to clear, replace, or expire that state explicitly.
   - Steward should avoid “loaded once, good luck remembering how to undo it” ergonomics.
9. **One small injection seam beats many convenience loopholes**
   - Quick fixes, replay cards, environment bundles, remote helper setup, and command palettes all want the same anti-folklore discipline.
   - Steward should prefer one tiny session-injection posture over a pile of half-hidden special cases.

## Phase-1 non-goals
- a universal shell AST or command-intent language;
- silently mutating shell rc files or login profile state as a normal convenience path;
- a generic secret-manager abstraction for every provider;
- treating shell history suppression as a security boundary by itself;
- pretending remote wrapper availability is the same thing as portable lifecycle truth.

## Adjacent docs
- `assist-surface-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `replay-gate-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `session-variable-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `injection-receipt-posture-v0.md`
- `precision-fence-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-VSCODE-UPDATE-1108
- REF-WARP-ENV-VARS
- REF-WARP-SSH
- REF-WEZTERM-SHELL-INTEGRATION
