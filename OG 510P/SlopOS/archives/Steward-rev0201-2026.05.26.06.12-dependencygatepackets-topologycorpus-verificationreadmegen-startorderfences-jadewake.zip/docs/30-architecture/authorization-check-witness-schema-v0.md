# Authorization-check witness schema v0

## Purpose
`ST-AUTHCHECK v0` records Steward's bounded authorization check for one lifecycle operation request. It answers: **given the request digest, delegate, verb, component, review, delegation warrant, and approval evidence, is Steward allowed to pass this operation to execution?**

The packet is a gate decision. It is not an operation receipt. It does not prove the action ran, changed component state, drained work, stopped a runtime cycle, or produced an external effect.

## Machine profile
- Machine profile: `../../schemas/st-authcheck-v0.schema.json`
- Checker: `../../tools/steward_governance_harness.py`
- Corpus: `../40-verification/corpora/governance-authorization-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-AUTHCHECK v0` |
| `witness_id` | generic Steward witness id |
| `authz_id` | authorization-check id matching `auth_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object |
| `subject_op_ref` | operation request reference |
| `subject_request_digest` | canonical digest of the exact operation request |
| `delegatee` | actor being checked |
| `verb` | lifecycle verb being checked |
| `decision` | `allowed`, `denied`, `needs_approval`, `stale`, or `unknown` |
| `checked_at_ms` | integer check time |
| `basis_refs` | bounded evidence refs |
| `delegation_refs` | warrant refs considered |
| `approval_refs` | approval refs considered |
| `review_refs` | review refs considered |
| `non_implications` | explicit refusal list |

Optional fields: `runtime_cycle_ref`, `denial_reason`, `expires_or_recheck_by_ms`, `break_glass_ref`, `residual_risk`, and `unknown_reason`.

## Allowed-decision rules
An `allowed` decision requires non-empty delegation, approval, and review refs. In the flow checker those refs must bind together:

- active delegation is still within its validity window;
- delegatee matches;
- component and verb are in scope;
- runtime-cycle fence matches when present;
- approval decision is `approved` and not stale;
- approval and review digests match the authorization check digest;
- approval-required warrant refs are actually used by the check;
- review verdict is `pass`.

## Denial and staleness rules
`denied`, `needs_approval`, and `stale` decisions require `denial_reason`. `unknown` decisions require `unknown_reason`. A check with `expires_or_recheck_by_ms` before `checked_at_ms` cannot be `allowed`.

## Rejections
The corpus rejects:

- allowed authorization without approval refs;
- authorization packets claiming effect success or execution;
- stale decisions without reasons;
- allowed checks using expired delegations;
- approval digest mismatch;
- needs-approval review treated as pass;
- denied approval treated as authority;
- delegatee mismatch;
- verb outside delegation;
- duplicate warrant ids with different canonical bytes.

## Non-goals
- no operation execution;
- no component-state proof;
- no effect-success proof;
- no custody, readiness, serving, or drain truth;
- no global policy engine;
- no Ward replacement.

## Adjacent docs
- `governance-authorization-posture-v0.md`
- `control-operation-request-schema-v0.md`
- `control-operation-receipt-schema-v0.md`
- `delegation-warrant-witness-schema-v0.md`
- `operator-review-witness-schema-v0.md`
- `approval-decision-witness-schema-v0.md`
