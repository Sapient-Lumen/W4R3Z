# Drain witness schema v0

## Purpose
`ST-DRAIN v0` is the closed packet for one observed drain boundary over old work, old demands, live channels, traffic bindings, or a mixed component scope.

The central rule: **drain means a scoped old-work/channel set is draining, drained, partial, forced, deadline-hit, abandoned, or unknown; it is not stopped, lossless continuity, no-side-effect proof, effect success, force-kill, no-new-work, or readiness.**

## Machine profile
- Machine profile: `../../schemas/st-drain-v0.schema.json`
- Checker: `../../tools/steward_shutdown_harness.py`
- Corpus: `../40-verification/corpora/shutdown-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-DRAIN v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | runtime, supervisor, broker, queue, proxy, load balancer, adapter, or observer reporting the drain |
| `drain_id` | canonical drain id matching `drn_[a-z0-9]{16}` |
| `runtime_cycle_ref` | concrete runtime cycle being drained |
| `drain_scope` | `traffic_binding`, `live_channels`, `demand_queue`, `work_inflight`, `component`, `mixed`, or `unknown` |
| `drain_state` | `not_started`, `draining`, `drained`, `partial`, `deadline_hit`, `forced`, `abandoned`, or `unknown` |
| `pending_class` | `none`, `some`, `hidden`, or `unknown` |
| `horizon_ms` | bounded drain horizon used by the observer |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the drain state |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `quiesce_ref`, `traffic_binding_refs`, `live_channel_refs`, `demand_refs`, `work_refs`, `completion_ref`, `deadline_ms`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Non-implication vocabulary
A valid drain witness must include:

- `not-stopped`
- `not-effect-success`
- `not-no-side-effect`
- `not-lossless`
- `not-force-kill`
- `not-no-new-work`
- `not-readiness`

## Drain rules
`drained` requires `pending_class = none`. A component or mixed-scope drained witness must cite a quiesce witness. A past `deadline_ms` can only be reported with `deadline_hit`. `unknown` requires `unknown_reason`.

A drain packet may cite live-channel, demand, work, or traffic witnesses, but it does not settle external effects, exactly-once behavior, restart safety, or final termination.

## Rejected surfaces
The corpus rejects:

- drained packets with hidden or remaining pending work;
- component-drain completion without a quiesce basis;
- deadline-expired drain reports that still claim ordinary progress;
- raw endpoint leakage;
- drain events promoted into lossless, no-side-effect, stopped, force-kill, readiness, or effect-success truth.

## Non-goals
- no broker drain protocol, service-mesh drain API, load-balancer controller, durable queue, work tracker, or lossless shutdown guarantee;
- no universal representation of transport-specific close, reset, or acknowledgement details.

## Adjacent docs
- `activation-live-channel-posture-v0.md`
- `activation-traffic-binding-posture-v0.md`
- `activation-work-disposition-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `shutdown-horizon-posture-v0.md`
- `canonical-json-profile-v0.md`
