# Shutdown-horizon posture v0

Purpose: define a **tiny explicit shutdown-horizon seam** so Steward can say a component is **terminating with a current deadline / grace horizon** — and may still be draining or finishing bounded work — without confusing that with ordinary liveness, open-ended stop deferral, or a giant drain-orchestration protocol.

This seam stays intentionally small. It does **not** invent a portable connection-draining API, shutdown scheduler, or service-registry control plane. It only answers a narrower question honestly: **when stop/termination is already in motion, what is the currently known horizon for graceful completion, and what should that fact not be mistaken for?**

## Posture
1. **Shutdown horizon is not the same as stop request or stop deferral**
   - `stop requested` belongs to control-operation or stop-intent truth.
   - `please give me more time` belongs to stop deferral.
   - `terminating through 14:03:20Z` or `grace expires in 8s` belongs to shutdown-horizon truth.
2. **A component may be terminating yet still have bounded current-work truth**
   - Some substrates explicitly distinguish ordinary readiness/new-work admission from `terminating` / `serving while terminating` / `draining` states.
   - Steward should preserve that split instead of teaching users that `terminating` necessarily means `not serving anything at all`.
3. **The horizon should be outward-facing and bounded when the adapter can prove it**
   - Useful truths include `terminating`, `grace active`, `deadline 14:03:20Z`, `shutdown extended`, `deadline unknown`, or `force-after 8s`.
   - Steward should prefer one exact due-by or remaining-budget view over vague infinite patience.
4. **Extension is a real event, not silent patience**
   - If a runtime can legitimately extend a stop / shutdown deadline, that extension should stay visible and attributable.
   - `horizon extended` is healthier than a spinner that simply keeps lying longer.
5. **System-shutdown class stop may deserve its own attribution**
   - Some substrates distinguish ordinary operator stop from preshutdown or shutdown-class handling that blocks later system work only for a bounded time.
   - Steward should preserve the exact source class when known instead of flattening everything into plain `stop`.
6. **Shutdown horizon is different from carried-out cut-through**
   - A component may have a current graceful horizon now, yet later hit that horizon and be force-cut through.
   - Steward should keep `grace through 14:03:20Z` separate from later `forced after deadline` truth.
7. **Shell/terminal chrome should surface shutdown horizon compactly**
   - Useful chips include `terminating`, `draining until 14:03`, `grace 8s left`, `deadline extended`, `preshutdown`, or `deadline unknown`.
   - Useful exact actions include `show stop horizon basis`, `show latest extension`, or `show drain/serve witness` when policy allows.
8. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `shutdown_horizon` witness with compact state such as `terminating`, `extended`, `expired`, or `unknown`, plus optional `deadline`, `remaining`, and `source_class` when provable.
   - Traffic choreography, rollout sequencing, and cross-component drain scheduling remain intentionally undecided.

## Phase-1 non-goals
- a portable connection-draining or endpoint-weight API;
- a generic shutdown scheduler or maintenance calendar;
- promising every adapter can expose an exact deadline or extension path;
- a universal system-shutdown orchestration plane;
- inferring shutdown horizon from quiet logs, low CPU, or absent traffic.

## Adjacent docs
- `stop-deferral-posture-v0.md`
- `stop-escalation-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `presence-advertisement-posture-v0.md`
- `control-operation-posture-v0.md`
- `progress-window-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-ENDPOINTSLICES
- REF-K8S-POD-LIFECYCLE
- REF-HAPROXY-MANAGEMENT
- REF-SYSTEMD-SERVICE
- REF-WINDOWS-SERVICE-CONTROL-HANDLER
- REF-WINDOWS-SERVICE-PRESHUTDOWN-INFO
