# Stop-deferral witness schema v0

Purpose: define the closed human profile for `ST-STOPDEFER v0`, a bounded decision about whether in-flight activity temporarily defers forceful stop.

A stop-deferral witness explains why a stop request is honoring, deferring, denying, expiring, or forcing past declared activity. It is deliberately not a keepalive lease, approval, stopped-state receipt, clean-exit receipt, drain receipt, or effect-success proof.

## Required fields
- `schema`: `ST-STOPDEFER v0`.
- `witness_id`, `cid`, `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.
- `stop_deferral_id`: stable id with `stopdef_` prefix.
- `stop_request_ref`: exact stop operation request or receipt ref.
- `runtime_cycle_ref`: exact runtime-cycle ref.
- `activity_refs`: exact activity bracket refs.
- `decision_state`: `honor_until`, `defer`, `deny`, `force_after`, `expired`, or `unknown`.
- `decided_at_ms` and `force_after_ms`.
- `quiesce_ref`: exact quiesce ref or `none`.
- `reason`: short redacted explanation.

## Required non-implications
`not-authority`, `not-authorization`, `not-approval`, `not-stopped`, `not-drained`, `not-clean-exit`, `not-work-completion`, `not-effect-success`, and `not-keepalive-lease`.

## Rules
Honored deferrals must be bounded by a future `force_after_ms`. Denied, expired, and unknown decisions must not create future lease semantics. Flow validation rejects deferrals over closed brackets, wrong runtime cycles, and force windows that outlive bracket freshness.

## Non-goals
This packet does not replace quiesce, drain, escalation, termination-cause, or authorization witnesses.
