# Activation-fanout posture v0

Purpose: keep **manager-owned activation-surface fanout** explicit so Steward can say whether one reviewed demand surface wakes **one shared long-lived worker** or **one per-demand worker instance**, without cloning inetd/systemd templating grammar, a socket broker, or a generic concurrency API.

This seam stays intentionally small. It answers one narrower question: **when reviewed demand reaches one activation surface, does Steward expect a shared worker to take it, or a fresh worker instance per accepted demand?**

## Posture
1. **One activation surface and one worker topology are different truths**
   - A component may have one stable manager-owned demand surface and still choose very different service topology underneath.
   - `armed` answers whether demand can wake something; fanout answers what kind of worker topology that demand will wake.
2. **Shared-worker and per-demand-instance modes should stay separate**
   - Some activation surfaces wake one shared long-lived worker that accepts or drains many demands over time.
   - Others instantiate one worker per accepted connection/request/demand object.
   - Steward should keep those truths separate instead of flattening them into one vague `socket activated` story.
3. **Manager-accept and component-accept are also different truths**
   - Some substrates pass the listening surface to the worker so the worker accepts its own demand.
   - Others accept on behalf of the worker and hand over one accepted connection/request object.
   - Those choices change attribution, isolation, and backlog behavior and should not be hidden behind folklore about stdio or descriptor order.
4. **Fanout truth is not the same as serving truth or current multiplicity**
   - `per-demand instance` does not by itself mean instances are currently present.
   - `shared worker` does not by itself mean the worker is currently alive or serving.
   - Steward should keep fanout posture separate from activation-endpoint witness, serve-state witness, and runtime-cycle identity.
5. **The design tradeoff is real and worth naming**
   - Shared workers often amortize activation cost and can be better for performance-sensitive steady traffic.
   - Per-demand instances can simplify implementation, improve isolation, and fit sporadic or high-risk traffic better.
   - Steward should preserve that design tradeoff as explicit architecture truth instead of burying it inside compatibility mode or hidden adapters.
6. **Phase 1 only needs compact witness vocabulary**
   - A useful phase-1 shape is no more than compact truth such as `shared-worker`, `per-demand-instance`, or `unknown`, plus optional delivery basis such as `listen-surface` or `accepted-demand` when the adapter can prove it.
   - Steward should resist freezing template-instance naming rules, portable backlog semantics, or a giant socket/request transport family through this seam.
7. **Per-demand instances should stay attributable without becoming a giant instance algebra**
   - If one demand creates one short-lived worker, Steward may still want exact runtime-cycle receipts and compact demand-local attribution.
   - It does not need to standardize a portable per-connection service inventory, templated naming constitution, or generic instance-query API in phase 1.
8. **Endpoint-local caps and fairness should stay local for now**
   - Some substrates can cap concurrent per-demand instances or per-source fanout.
   - Those are promising local hints, but Phase 1 should surface them only as compact explanatory detail instead of freezing a universal fairness or admission-policy language.

## Phase-1 non-goals
- a portable inetd/systemd template-instance grammar;
- a universal concurrency/backlog/fairness/admission DSL;
- a generic per-connection service inventory or query API;
- turning descriptor delivery details into bearer authority or public contract;
- implying `per-demand-instance` proves stronger serving, readiness, or security on its own.

## Adjacent docs
- `activation-endpoint-witness-posture-v0.md`
- `activation-cause-posture-v0.md`
- `request-activation-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `descriptor-hygiene-posture-v0.md`
- `execution-group-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-SOCKET-ACTIVATION
- REF-LAUNCHD-SOCKETS
- REF-OPENBSD-INETD
