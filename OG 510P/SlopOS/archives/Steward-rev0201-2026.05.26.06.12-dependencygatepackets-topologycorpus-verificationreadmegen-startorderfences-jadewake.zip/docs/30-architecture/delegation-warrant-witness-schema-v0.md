# Delegation-warrant witness schema v0

## Purpose
`ST-DELEGATE v0` is a closed Steward packet for importing or recording scoped lifecycle delegation evidence. It answers a narrow question: **may this named delegate rely on this warrant for this component and verb, during this bounded window, with these caveats?**

The packet deliberately does not make Steward a Ward replacement. Ward, policy, or another governance source may issue the warrant, but Steward only checks whether the warrant is usable as evidence for a lifecycle operation.

## Machine profile
- Machine profile: `../../schemas/st-delegate-v0.schema.json`
- Checker: `../../tools/steward_governance_harness.py`
- Corpus: `../40-verification/corpora/governance-authorization-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-DELEGATE v0` |
| `witness_id` | generic Steward witness id |
| `warrant_id` | delegation warrant id matching `del_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming Ward, Steward, policy, operator, adapter, or related source |
| `delegator` | actor that issued or anchors the delegated authority |
| `delegatee` | actor that may rely on the warrant |
| `scope` | closed component scope naming allowed verbs and maximum force class |
| `status` | `active`, `expired`, `revoked`, `suspended`, or `unknown` |
| `effective_from_ms` | integer validity start |
| `expires_at_ms` | integer validity end |
| `observed_at_ms` | integer observation time |
| `basis_refs` | bounded evidence refs |
| `caveats` | bounded caveats such as approval requirement or no re-delegation |
| `non_implications` | explicit refusal list |

## Scope rules
The v0 scope is always `kind: component`. `scope.cid` must equal the root `cid`. Allowed verbs are limited to:

- `start`
- `stop`
- `restart`
- `quiesce`
- `refresh`
- `inspect`

`max_force` is one of `none`, `notify`, `soft_stop`, `interrupt`, `terminate`, `kill`, or `unknown`. The `no_force` caveat forbids strong intervention classes. The `observe_only` caveat restricts allowed verbs to `inspect`.

## Caveat rules
`no_redelegation` is mandatory in v0. Delegation chain growth is deliberately outside Steward's first governance proof slice.

Other caveats are checkable context, not hidden authority:

- `approval_required`
- `dual_control`
- `break_glass_only`
- `no_force`
- `observe_only`
- `repair_gate_required`
- `ticket_required`
- `privacy_minimized`
- `budget_required`
- `fresh_intent_required`

## Time and status rules
An `active` warrant must be observed inside the effective window. An `expired` warrant must be observed after `expires_at_ms`. A `revoked` warrant must cite `revocation_ref`. An `unknown` warrant must carry `unknown_reason`.

These rules make stale owner maps and copied approval screenshots weaker than live delegation evidence.

## Rejections
The corpus rejects:

- owner labels masquerading as delegated authority;
- active warrants outside their validity window;
- re-delegation fields;
- observe-only warrants carrying mutating verbs;
- duplicate JSON keys;
- raw PID, host unit, pod, container, terminal, token, secret, endpoint, or path material.

## Non-goals
- no global governance graph;
- no owner-of-record truth;
- no permanent authority;
- no role taxonomy;
- no raw RBAC import;
- no re-delegation chain;
- no execution, effect, readiness, or component-state claim.

## Adjacent docs
- `governance-authorization-posture-v0.md`
- `approval-decision-witness-schema-v0.md`
- `operator-review-witness-schema-v0.md`
- `authorization-check-witness-schema-v0.md`
- `control-operation-request-schema-v0.md`
- `control-operation-receipt-schema-v0.md`
- `companion-boundary-map-v0.md`
