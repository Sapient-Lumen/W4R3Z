# Receipt minimization posture v0

## Purpose
Ensure Steward receipts explain lifecycle truth without leaking raw authority, secrets, unnecessary operator context, or whole command transcripts.

Receipts are powerful because they travel. They must be digestable, scoped, and intentionally incomplete.

## Receipt classes
| Class | May export | Must not export |
| --- | --- | --- |
| component manifest receipt | CH-COMP digest, cid, schema id | embedded script text, host unit internals, ambient env |
| activation receipt | CH-ACTSET digest, cycle, issuer, delivery boundary | raw handles, fd numbers, tokens, secret values, paths as authority |
| lifecycle operation receipt | target anchor, cycle, verb, result boundary, reason | unrelated shell scrollback, ambient PID guesses |
| retry receipt | attempt group, canonical-intent digest, safety basis, timing hint | request body unless explicitly minimized, raw auth material |
| effect-boundary receipt | effect ref, boundary kind, issuer, confidence | full payload or compensating-secret material by default |
| adapter receipt | source, observed fact, scope, freshness | promotion to native truth without reviewed witness |

## Redaction by construction
Steward should prefer storing digests and scoped summaries instead of storing raw material and later redacting it. The redaction path is weaker than a schema that cannot carry the sensitive field.

CH-ACTSET therefore forbids fields such as raw tokens, raw values, raw paths-as-authority, descriptor numbers, and unreviewed handles.

## Retention stance
- lifecycle receipts are retained only as long as they are needed for explanation, stale-action fences, audit, or repair;
- high-risk evidence gets a retention class;
- copied shell cards and outbound evidence drafts are new artifacts with their own minimized content;
- deleting raw evidence must not mutate historical digest truth.

## UI split
Operator-visible cards may show less than audit material. The card should still include enough basis to avoid mystery: issuer, subject, scope, time/freshness, and what the receipt does not prove.

## Non-goals
- no full audit-log product;
- no SIEM schema;
- no vault;
- no evidence export empire;
- no generic privacy policy language.

## References
REF-SPIFFE-WORKLOAD-API; REF-VAULT-LEASES; REF-K8S-SECRETS; REF-CLOUD-RUN-SECRETS; REF-AWS-ECS-SECRETS-ENVVAR.
