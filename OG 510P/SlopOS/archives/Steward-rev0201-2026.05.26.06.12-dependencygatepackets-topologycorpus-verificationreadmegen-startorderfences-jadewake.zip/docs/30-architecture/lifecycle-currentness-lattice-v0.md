# Lifecycle currentness lattice v0

## Purpose
Compress Steward's many “X is not Y” rules into one small truth map.

This is not a state machine. It is a non-implication lattice for lifecycle witnesses.

## Axes
| Axis | Witnesses | Core warning |
| --- | --- | --- |
| Identity | component id, manifest digest, incarnation, runtime cycle | stable names do not retarget stale actions |
| Activation | activation set digest, activation receipt, material freshness | delivery does not imply freshness or readiness |
| Lifecycle | spawn, start gate, readiness, serve state, stop request, stop progress, termination cause | spawn is not ready; stop requested is not stopped |
| Demand | admission, demand episode, custody, work disposition | accepted or held work is not completion |
| Effect | local commit, outbox, external submit, external confirmation, compensation, unknown | retry and ack are not exactly-once effects |
| Condition | probe vantage, control verdict, traffic binding, live channel | green probes and active routes are scoped evidence |
| Attempt | retry group, attempt ordinal, canonical intent, budget, pushback, commitment boundary | retry is not safety unless the basis is named |
| Human surface | target anchor, status barrier, witness card, repair gate | chrome and nearby text are not authority |

## Relation labels
Steward should label edges using this vocabulary:

- `stronger-than`: a witness proves a narrower or stronger fact;
- `weaker-than`: a witness is useful basis but not enough;
- `independent`: facts can vary independently;
- `stale-fenced-by`: a witness must match current cycle/epoch before action;
- `requires-adjacent-witness`: a claim is valid only if another witness exists;
- `never-implies`: a tempting promotion is forbidden.

## First pinned non-implications
| Weak evidence | Must not imply | Required stronger or adjacent witness |
| --- | --- | --- |
| spawn observed | readiness | readiness witness after activation receipt |
| activation receipt | material freshness | material-freshness witness |
| material path exists | current authority | material-freshness witness with expiry/revocation basis |
| readiness | serving | serve-state witness |
| serving | route eligibility | traffic-binding witness |
| traffic binding | readiness | readiness/probe/serve evidence remains separate |
| live channel open | lossless drain or completion | live-channel drain/close and disposition/effect evidence |
| retry scheduled | capacity reserved | retry-advice witness only says not-before/pushback |
| idempotency key present | exactly once | canonical-intent match and effect/disposition witnesses |
| hedge canceled | no side effect | effect boundary or explicit substrate proof |
| stop requested | stopped | stop-progress terminal boundary or termination cause |
| host active/running | Steward ready | adapter-membrane promotion through reviewed witness |
| shell target text | lifecycle target | target anchor with current cycle |

## Lattice rule for UIs
A Steward UI may show weak evidence, but the card must say what the evidence does not prove. This turns the lattice into the product object: every witness card is a scoped statement plus a refusal list.

## Adjacent material
- `adapter-membrane-posture-v0.md`
- `time-and-deadline-posture-v0.md`
- `activation-retry-attempt-posture-v0.md`
- `../40-verification/component-lifecycle-activation-corpus-v0.md`
