# Manager recovery and reconciliation posture v0

## Purpose
Name what Steward may honestly say after Steward itself crashes, restarts, loses an adapter session, or rebuilds present-tense views.

A lifecycle manager is most tempted to lie during recovery. Steward must preserve durable receipts where it can and downgrade present-tense claims where it cannot.

## Recovery truth classes
| Class | Meaning | Export posture |
| --- | --- | --- |
| durable receipt | digestable fact written before manager loss | may be replayed as historical evidence |
| last-known live witness | present-tense fact observed before loss | must become stale or unknown unless renewed |
| adapter reconstruction | host/runtime fact re-read after recovery | weak basis until promoted through Steward witness rules |
| lost volatile state | subscription cursor, in-flight helper, non-durable pending operation | report as lost or unknown; do not recreate authority |
| reconciled current witness | fresh post-recovery witness with basis and time | may become current within its scope |

## Minimum durable set
The first version should persist only small receipts:

- CH-COMP digest;
- CH-ACTSET digest;
- activation receipt boundary;
- runtime-cycle id and end cause if known;
- stop/quiesce operation receipt;
- retry-attempt group and canonical-intent digest;
- effect-boundary witness digest, when one exists;
- status barrier cursor, if the subscription path supports it.

This is intentionally smaller than workflow history. Temporal's event-history model is useful pressure because it shows how durable replay can work, but Steward should not become a workflow engine just to recover lifecycle explanation.

## Reconciliation barriers
After recovery, Steward must not claim currentness until a fresh barrier is crossed:

- `recovered-historical`: durable facts replayed but no live status rechecked;
- `adapter-observed`: host/runtime state observed but not promoted;
- `witness-renewed`: Steward witness refreshed with issuer, basis, and time;
- `unknown`: no honest current statement available.

## In-flight operations
| Operation | Recovery posture |
| --- | --- |
| start | activation receipt may survive; readiness/serving becomes unknown unless refreshed |
| stop | stop request may survive; stopped requires terminal witness or fresh reconciliation |
| restart | old and new cycles must be re-identified; stale target actions fence |
| quiesce | no-new-work claim expires unless renewed or reconciled |
| retry | retry-attempt receipt survives; duplicate/effect fate remains separate |
| repair gate | durable latch may survive; clearance requires fresh reviewed receipt |
| subscription | resume from cursor when exact; otherwise admit continuity loss |

## Adapter humility
Steward may use host data to reconcile, but host facts remain under the adapter membrane. A Kubernetes Pod phase, a systemd active state, or a re-delivered descriptor can help explain recovery; none is automatically Steward readiness, serving, or portable authority.

## Non-goals
- no global workflow/event-history engine;
- no CRIU-like process snapshot story;
- no automatic reconstruction of raw handles;
- no pretending last-known live state is current;
- no hidden host-manager adoption as native truth.

## References
REF-TEMPORAL-EVENT-HISTORY; REF-SYSTEMD-FDSTORE; REF-K8S-POD-LIFECYCLE.
