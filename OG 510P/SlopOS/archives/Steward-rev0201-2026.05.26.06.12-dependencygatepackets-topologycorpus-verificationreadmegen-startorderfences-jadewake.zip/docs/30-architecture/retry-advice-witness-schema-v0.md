# Retry-advice witness schema v0

## Purpose
`ST-RETRYADVICE v0` is the first closed packet for one retry timing or pushback hint. It can report that an issuer observed overload, throttling, `Retry-After`, gRPC pushback, local backoff, repair-required delay, or manual-review need for one scoped follow-up attempt.

The central rule: **retry advice is timing guidance, not authority, capacity, admission, readiness, serving, effect success, or a promise that retry will work.**

## Machine profile
- Machine profile: `../../schemas/st-retryadvice-v0.schema.json`
- Checker: `../../tools/steward_retry_settlement_harness.py`
- Corpus: `../40-verification/corpora/retry-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-RETRYADVICE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | Steward, proxy, client, adapter, library, mesh, controller, or observer that issued the advice |
| `advice_id` | canonical retry-advice id |
| `advice_state` | `no_hint`, `not_before`, `cooling_down`, `pushed_back`, `rate_limited`, `budget_exhausted`, `manual_review_required`, `expired`, `superseded`, or `unknown` |
| `reason` | compact cause, such as overload, throttled, still-processing, early-data rejected, drain-in-progress, local backoff, policy-denied, repair-required, or unknown |
| `scope_ref` | exact scope for the hint, such as route, component, operation family, or attempt group |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the advice |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `attempt_group_ref`, `retry_after_source`, `not_before_ms`, `delay_ms`, `pushback_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Non-implication vocabulary
A valid retry-advice witness must include:

- `not-grant`
- `not-reservation`
- `not-admission`
- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-budget-capacity`
- `not-retry-success`

## Timing rules
Timed advice states require `not_before_ms` at or after `observed_at_ms`. `no_hint` cannot carry a hidden delay. Expired, superseded, manual-review-required, and unknown advice states require an explicit `unknown_reason` so copied shell cards or stale operator notes do not become fresh authority.

## Rejected surfaces
The corpus rejects:

- advice packets that claim reservation, grant, route currentness, readiness, serving, or effect success;
- not-before times in the past relative to the observation;
- `no_hint` packets carrying hidden delay values;
- raw endpoints, tokens, cookies, bearer material, and duplicate JSON keys.

## Non-goals
- no quota service, rate-limit family, generic retry-policy language, RPC framework, service mesh, durable retry scheduler, or global backoff ledger;
- no promise that a later retry is admissible or will succeed;
- no portable standardization of all protocol-specific retry headers or pushback formats.

## Adjacent docs
- `activation-retry-attempt-posture-v0.md`
- `retry-advice-posture-v0.md`
- `retry-budget-witness-schema-v0.md`
- `retry-attempt-witness-schema-v0.md`
- `time-and-deadline-posture-v0.md`
- `receipt-minimization-posture-v0.md`
- `canonical-json-profile-v0.md`

## References
REF-HTTP-RFC9110; REF-RFC6585; REF-RFC8470-EARLY-DATA; REF-GRPC-RETRY; REF-AWS-SDK-RETRY-BEHAVIOR; REF-AWS-BUILDERS-BACKOFF-JITTER.
