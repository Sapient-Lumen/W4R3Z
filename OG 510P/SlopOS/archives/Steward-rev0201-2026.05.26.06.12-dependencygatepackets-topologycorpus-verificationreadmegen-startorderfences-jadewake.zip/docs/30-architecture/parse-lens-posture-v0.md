# Parse-lens posture v0

Purpose: define a **tiny parse-lens seam** so Steward-aware shell/terminal UX can layer useful, inspectable structure over visible text when exact shell objects are unavailable, without letting transcript parsing masquerade as lifecycle authority or canonical truth.

## Posture
1. **A parse lens is advisory interpretation, not canonical shell truth**
   - A parse lens may look at transcript text, visible output, copied spans, or other shell-adjacent bytes and produce candidate structure.
   - That structure is useful, but it is weaker than exact shell-reported prompt leases, current-command objects, command frames, target anchors, or receipts.
2. **Exact objects outrank parse-lens results**
   - If Steward already has an exact current-command object, exact frame boundary, exact hyperlink target, or exact receipt anchor, parse-lens guesses should not overwrite it.
   - Parse lenses are for graceful enrichment and fallback, not for laundering weak parsing into stronger authority.
3. **Multiple lenses may coexist and disagree**
   - One lens may see a file path, another may see a diagnostic location, and a third may see a remote selector or service-ish token.
   - Steward should preserve provenance, confidence, and disagreement rather than pretending one global parser owns the transcript.
4. **Lens results should stay bound to explicit spans and freshness**
   - A parse-lens result should point at one concrete span, frame, or copied slice plus the relevant semantic epoch / hop lineage when available.
   - Scrollback rewrite, shell resync, hop change, or transcript compaction may stale or withdraw that result in ordinary ways.
5. **Lens affordances should be mostly observational first**
   - Good phase-1 affordances include reveal, copy canonical selector, explain why the lens matched, open a safer chooser, or stage a follow-on command.
   - Higher-risk actions should still require fresher exact binding, review, or explicit staging instead of firing straight off a parsed guess.
6. **Incremental refinement is better than regex folklore**
   - Parse lenses may refine, downgrade, or withdraw candidate structure as more text arrives or as a stronger parser becomes available.
   - Steward should allow that normal evolution instead of pretending the first weak parse was final truth.
7. **Parse lenses should help the terminal admit why a smart affordance appeared**
   - If a remote-file card, diagnostic rail, or explain chip came from a parse lens, the shell/terminal should be able to say so plainly.
   - This is healthier than magical clickability with no provenance story.
8. **Keep the phase-1 contract tiny**
   - Phase 1 likely needs only: lens id/class, bound span or anchor, candidate kind, normalized payload/selector, provenance/confidence, freshness state, and optional disabled reason.
   - Avoid freezing a universal transcript AST, parser plug-in marketplace, or cross-tool semantic bus before repeated pressure exists.

## Phase-1 non-goals
- a universal transcript AST or shell-language grammar;
- letting parse-lens results silently outrank exact shell or lifecycle objects;
- turning weak parsed candidates directly into hidden mutating authority;
- freezing a parser marketplace, grammar registry, or cross-product semantic interchange;
- pretending parse-lens refinement/withdrawal means the transcript itself changed.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `current-command-posture-v0.md`
- `link-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `action-surface-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `precision-fence-posture-v0.md`
- `context-handoff-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-TREESITTER
- REF-KITTY-HINTS
- REF-KITTY-OPEN-ACTIONS
- REF-VSCODE-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
