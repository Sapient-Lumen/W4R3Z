# Effect-key posture v0

Purpose: define a **tiny retry-safe effect-key seam** so some non-commutative Steward actions can collapse duplicate retries without turning Steward into a durable queue, exactly-once transport, or global dedupe ledger.

## Posture
1. **Effect keys name retry-equivalent intent, not target identity or live state**
   - An effect key says “this new attempt should be treated as the same requested effect as that earlier attempt if the reviewed effect fingerprint still matches”.
   - It is not the same thing as the component id, runtime-cycle witness, current grant handle, or live current-state proof.
2. **The same key with the same reviewed fingerprint may reuse prior outcome**
   - For reviewed action families that explicitly opt in, Steward may accept a duplicate attempt, suppress repeated side effects, and return the earlier outcome or receipt anchor.
   - Duplicate suppression should stay visible as its own outcome such as `duplicate-suppressed` or `replayed-prior-outcome` rather than pretending the new attempt was a fresh mutation.
3. **The same key with a different effect fingerprint should fail loudly**
   - Reusing an effect key for materially different action parameters, target scope, or grant bindings should produce a visible mismatch outcome.
   - Steward should not silently choose one winner, merge the requests, or reinterpret the old key to mean “roughly this family of action”.
4. **Retention windows are explicit policy, not forever truth**
   - A host or manager may honor an effect key for a bounded window and then forget it.
   - The portable contract should allow `dedupe-window-expired` or equivalent freshness loss instead of implying a permanent ledger of every past request.
5. **Effect keys should stay optional and narrow**
   - Many observational, read-only, or already-idempotent actions do not need one.
   - Steward should reserve effect keys for reviewed non-commutative operations that benefit from at-least-once-safe retry behavior.
6. **Outstanding work should be distinguishable from completed duplicates**
   - If the original attempt is still in flight, a later retry with the same key should be allowed to hear `still-processing`, `conflict`, or an equivalent pending outcome.
   - That is healthier than racing two concurrent effect applications or pretending work already finished when it has not.
7. **Historical evidence does not become current authority**
   - A prior receipt, transcript frame, or remembered command may show which effect key was used and what happened then.
   - It must not by itself recreate the dedupe window, prove a current live grant, or authorize new effect under the same key after policy expiry.
8. **Shell and terminal surfaces should show retry-safe truth honestly**
   - Action chips and request cards may say `retry-safe`, `duplicate suppressed`, `still processing`, `key mismatch`, or `dedupe window expired` when the path can prove those states.
   - That is healthier than a blind rerun button that hides whether a non-commutative action might happen twice.
9. **Keep the seam smaller than a generic exactly-once plane**
   - One optional effect key, one reviewed effect fingerprint, duplicate-versus-mismatch outcomes, and one bounded retention story are enough for Phase 1.
   - Steward should not freeze a giant transaction protocol, global operation ledger, or universal dedupe algebra through this seam.

## Phase-1 non-goals
- a portable exactly-once execution guarantee;
- a durable global log of every past request key;
- requiring every action to carry an effect key;
- automatic dedupe across semantically different action families;
- treating effect keys as resource ids, live grant state, or current readiness proof.

## Adjacent docs
- `request-context-posture-v0.md`
- `request-activation-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `grant-handle-posture-v0.md`
- `consumable-grant-posture-v0.md`
- `renewal-window-posture-v0.md`
- `replay-gate-posture-v0.md`
- `action-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-AWS-BUILDERS-IDEMPOTENT-APIS
- REF-GOOGLE-AIP-155
- REF-AWS-EC2-IDEMPOTENCY
- REF-AWS-ECS-IDEMPOTENCY
- REF-IETF-IDEMPOTENCY-KEY
- REF-STRIPE-IDEMPOTENT-REQUESTS
