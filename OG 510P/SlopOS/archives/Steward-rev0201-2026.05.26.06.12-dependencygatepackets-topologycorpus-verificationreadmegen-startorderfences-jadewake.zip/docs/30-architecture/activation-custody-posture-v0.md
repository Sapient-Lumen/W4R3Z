# Activation-custody posture v0

Purpose: name the smallest useful truth for **who currently holds one activation demand, wake obligation, delivered handle, or event-lifetime responsibility** as it moves from an activation surface through admission, buffering, wake, delivery, runtime acceptance, completion, cancellation, redelivery, or loss.

This seam is intentionally small. It does **not** invent a durable queue, ownership graph, transaction coordinator, workflow runtime, service mesh, or exactly-once delivery system. It answers one narrower question: **where is this exact obligation right now, what boundary handed it off, and what should that not be mistaken for?**

## Posture
1. **Custody is present-tense responsibility, not success**
   - A demand, connection, event, startup handle, or background obligation may be held by an activation surface, proxy, runner, runtime, queue, or helper without being completed.
   - Steward should keep `held`, `delivered`, `accepted`, `released`, `returned`, `abandoned`, `lost`, and `unknown` visibly separate from readiness, serving, and successful work.

2. **A handoff needs two edges when the adapter can prove them**
   - The previous custodian may release an item before the next custodian has acknowledged it.
   - The next custodian may receive a descriptor or event before it has accepted semantic responsibility.
   - Stronger receipts should name both `released by previous` and `accepted by next`; weaker receipts should say `delivered unacknowledged`, `release unknown`, or `acceptance unknown`.

3. **Visibility leases are a good custody metaphor, not a queue mandate**
   - SQS-style visibility timeout teaches a useful distinction: delivery makes a message in-flight, but only explicit delete/ack says the consumer is done.
   - If the lease expires, the work can become redeliverable; at-least-once systems may duplicate even during a lease.
   - Steward should steal `in-flight with expiry`, `extended`, `returned`, and `duplicate-risk` vocabulary, not a portable message-broker contract.

4. **Manager-held listeners and stored handles need custody receipts too**
   - Socket activation and fd stores show that a manager can own a public edge while runtime cycles come and go.
   - A descriptor handed to a service, uploaded to a store, duplicated by a manager, removed from a store, or left pinned after close are different custody facts.
   - Steward should not let descriptor order or process inheritance be the only evidence for who currently owns a public edge or pinned resource.

5. **Event lifetime is bounded custody, not immortal background execution**
   - Service-worker and worker-runtime APIs show the useful shape: an event can add lifetime promises, a response promise can hold the event open, and post-response work can have a hard bound or cancellation.
   - Steward should prefer exact `event held until promises settle`, `post-response work canceled`, or `background work detached` receipts over pretending every helper task is durable.

6. **Initialization gates are delivery custody, not readiness**
   - Durable-object-style delivery blocking during initialization is a good idea because it keeps requests from interleaving with unfinished state setup.
   - The same docs warn that such gates need tight bounds and reset behavior if initialization fails.
   - Steward should steal `blocked before delivery`, `init gate timed out`, and `reset before accepting demand` truth, not a single-threaded object runtime.

7. **Caller cancellation must either propagate or be admitted lost**
   - Request contexts show that client disconnects and deadlines should cancel downstream work when the path supports it.
   - If activation custody crosses a proxy, wake buffer, runner, or detached background lane that cannot receive cancellation, Steward should say `cancellation propagated`, `cancellation queued`, `cancellation not supported`, or `detached from caller` rather than losing the fact.

8. **Terminating and still-serving is a custody hazard worth naming**
   - Endpoint truth can be `serving` while also `terminating`, and traffic systems may still route to terminating endpoints under constrained conditions.
   - Steward should keep `accepting new demand`, `draining existing demand`, `serving while terminating`, and `closed to new demand` separate from component liveness.

9. **Custody can expire, be extended, or be force-released**
   - A live holder may renew a visibility lease, heartbeat a long activity, request more event lifetime, or be cut off by a drain/shutdown horizon.
   - Those extensions are progress/custody evidence, not completion.
   - The phase-1 vocabulary should allow `lease expires at`, `extended until`, `heartbeat stale`, `force released`, and `redelivery eligible` when a substrate can prove them.

10. **Duplicate and ambiguous custody are honest outcomes**
    - Compatibility substrates and distributed event systems often cannot prove exactly one current holder.
    - Steward should allow `ambiguous`, `duplicate-risk`, `at-least-once`, and `unknown holder` instead of laundering uncertainty into `owned by runtime` or `lost`.

11. **Shell cards should reveal custody without creating control authority**
    - Useful compact chips include `held by activation surface`, `buffered by activator`, `waking runner`, `delivered unacked`, `runtime accepted`, `awaiting ack/delete`, `redeliverable`, `detached`, `abandoned`, and `holder unknown`.
    - Those cards may explain or offer reviewed cancel/retry/reveal actions, but the card itself must not become a bearer queue handle or durable job object.

12. **Phase 1 shape is a witness, not a custody API family**
    - A tentative `activation_custody` witness can stay tiny: `custody_id`, `episode_id` or `operation_id`, `item_kind`, `holder`, `holder_scope`, `handoff_state`, optional `released_by`, optional `accepted_by`, optional `deadline_or_lease`, optional `cancellation_state`, optional `redelivery_state`, optional `duplicate_risk`, and optional `basis`.
    - Field names remain provisional until concrete Steward components prove which details must be portable.

## Phase-1 non-goals
- a generic durable queue, broker, scheduler, workflow engine, service mesh, or exactly-once delivery plane;
- a universal ownership graph, distributed lock, leader-election, or transaction coordinator;
- treating custody as authorization, readiness, liveness, serving, or completion;
- requiring every demand episode to have a durable holder object;
- guaranteeing background work after a caller has received a response or disconnected;
- hiding cancellation loss, descriptor duplication, redelivery risk, or holder ambiguity behind a successful-looking lifecycle state.

## Adjacent docs
- `activation-demand-episode-posture-v0.md`
- `activation-work-disposition-posture-v0.md`
- `activation-admission-posture-v0.md`
- `activation-endpoint-witness-posture-v0.md`
- `activation-fanout-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `request-context-posture-v0.md`
- `continuity-escrow-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `shutdown-horizon-posture-v0.md`
- `activity-bracket-posture-v0.md`
- `backpressure-witness-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-AWS-SQS-VISIBILITY-TIMEOUT
- REF-AWS-LAMBDA-ASYNC-ERROR-HANDLING
- REF-AWS-LAMBDA-INVOCATION-RETRIES
- REF-CLOUDFLARE-WORKERS-CONTEXT
- REF-CLOUDFLARE-DURABLE-OBJECT-STATE
- REF-W3C-SERVICE-WORKERS
- REF-GO-CANCEL-OPERATIONS
- REF-K8S-ENDPOINTSLICES
- REF-SYSTEMD-FDSTORE
- REF-SYSTEMD-SD-LISTEN-FDS
- REF-ENVOY-DRAINING
- REF-TEMPORAL-ACTIVITY-FAILURES

## Custody executable settlement
Rev0185 settles the first executable packet as `ST-CUSTODY v0`, specified in `custody-witness-schema-v0.md` and checked by `../40-verification/demand-custody-effect-corpus-v0.md`. The checker keeps present-tense holder truth separate from work completion, effect success, losslessness, and exactly-once behavior while requiring explicit handoff boundaries, lease ordering, runtime-cycle fences, and downgrade reasons.
