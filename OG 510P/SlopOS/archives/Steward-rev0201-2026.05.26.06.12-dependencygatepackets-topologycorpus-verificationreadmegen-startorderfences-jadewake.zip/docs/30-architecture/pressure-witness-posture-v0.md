# Pressure-witness posture v0

Purpose: define a **tiny pressure-witness seam** so scoped `ok` / `some` / `full` / `warning` / `critical` style pressure truth can stay visibly separate from liveness, approval, serving state, and operator intent.

This seam stays intentionally small. It does **not** invent a universal scheduler, balancer, autoscaler, reclamation policy plane, or kill/migrate/trim grammar. It only says that when a substrate can honestly report resource-pressure or stall pressure for one exact scope, Steward should preserve that truth instead of flattening it into vague `slow`, `busy`, or `degraded` folklore.

## Posture
1. **Pressure is observational truth, not authority**
   - Pressure can explain why a component trims caches, sheds optional work, drains admissions, or warns about likely trouble.
   - It must not itself become permission to widen authority, skip review, or mutate privileged state.
2. **Pressure is not the same as failure or serving mode**
   - A component may still be alive and serving while pressure is mounting.
   - `warning` / `critical` pressure therefore answer different questions from `failed`, `draining`, `maintenance`, or `not serving`.
3. **Scoped pressure is healthier than a global oracle**
   - Some substrates can report host-wide pressure, others can report cgroup-, job-, or service-scoped pressure.
   - Steward should preserve the exact scope it actually knows instead of pretending every pressure signal is globally comparable.
4. **Coarse levels beat fake precision**
   - Linux PSI's `some` / `full`, Fuchsia's `NORMAL` / `WARNING` / `CRITICAL`, or similarly compact levels are already useful.
   - If an adapter only knows `pressure present` or `pressure unknown`, Steward should say that instead of manufacturing a richer ladder.
5. **Stall pressure and reclaim advice are different truths**
   - A witness may describe observed stall pressure, an advisory level, or a concrete reclaim hint such as `drop caches` / `avoid new work` when the substrate says so.
   - Steward should keep those distinctions visible instead of collapsing them into one generic `under pressure` badge.
6. **Pressure may justify adaptation before eviction or failure**
   - Useful systems react early by trimming optional memory, slowing expensive background work, or deferring fresh admissions before they start killing or failing work.
   - Steward should preserve that earlier warning truth because it is often the difference between graceful adaptation and surprise eviction.
7. **Shell and terminal chrome should make pressure legible**
   - Execution-ground cards, command guides, and receipts may show compact truth such as `memory pressure: warning`, `cpu stall: some`, `io pressure: full`, or `scope: service cgroup`.
   - These labels explain operational footing; they do not become a portable autoscaler or traffic-control plane.
8. **Pressure events may coalesce, skip intermediate levels, or arrive late**
   - Some substrates poll, some notify on thresholds, and some debounce transitions.
   - Steward should allow `unknown`, `coalesced`, or last-known pressure truth rather than promising one uniform timing model.
9. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `pressure_class`, exact scope label, compact `pressure_level`, and whichever of `window_ms`, `stall_pct`, `source_class`, or `reason` the adapter can really prove.
   - Richer trigger registration, autoscaling, or kill/reclaim choreography remain intentionally undecided.

## Phase-1 non-goals
- a universal PSI/procfs/cgroup/env/socket watch protocol;
- a portable autoscaler, balancer, or scheduler feedback API;
- automatic kill, migrate, or reclaim policy encoded into the pressure seam itself;
- a portable writable pressure-trigger or threshold-registration family;
- pretending every pressure signal is equally fresh, equally scoped, or equally comparable.

## Adjacent docs
- `dynamic-condition-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `hold-state-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `execution-ground-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-LINUX-PSI
- REF-SYSTEMD-MEMORY-PRESSURE
- REF-FUCHSIA-MEMORY-RECLAMATION
- REF-K8S-NODE-PRESSURE-EVICTION

## Executable settlement
Closed packet profiles and corpus checks now live in `pressure-admission-proof-posture-v0.md`, `pressure-witness-schema-v0.md`, `headroom-witness-schema-v0.md`, `backpressure-witness-schema-v0.md`, `admission-gate-witness-schema-v0.md`, and `../40-verification/pressure-admission-corpus-v0.md`.
