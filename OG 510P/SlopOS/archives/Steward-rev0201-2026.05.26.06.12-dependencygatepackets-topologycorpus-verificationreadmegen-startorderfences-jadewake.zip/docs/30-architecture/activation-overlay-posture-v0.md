# Activation-overlay posture v0

Purpose: define a **tiny effective-activation seam** so durable baseline activation intent, temporary runtime/operator overlays, and currently admitted start/stop verbs stay visibly separate instead of collapsing into one vague `enabled` or `disabled` myth.

This seam is intentionally small. It does **not** design a package installer, preset engine, boot-target graph, or universal precedence stack. It only says Steward should be able to explain **why activation is effectively allowed or blocked right now** without laundering together durable policy, temporary overrides, and state-scoped control admission.

## Posture
1. **Baseline intent and effective activation are different truths**
   - A component may have baseline intent such as `auto` or `manual`, yet be temporarily blocked by a runtime/session/operator overlay.
   - A component may also have a stronger baseline prohibition while still being inspectable or stoppable if it is already running.
   - Steward should not flatten those into one smiling `enabled` bit.

2. **Temporary overlays should stay explicit instead of mutating baseline history**
   - A runtime-only mask, temporary disable, session-local hold, or other short-lived override is useful precisely because it is **not** the same thing as durable baseline policy.
   - Steward should prefer `baseline: auto; overlay: runtime start-prohibited` over silently rewriting history as if the baseline had always been `disabled`.

3. **Per-verb refusal is different from broad disablement**
   - Some systems can refuse manual start, refuse manual stop, or narrow accepted controls without globally denying observation or future automatic activation.
   - Steward should preserve that honesty when it can: `manual start refused`, `stop not accepted while start pending`, and `start prohibited` answer different questions.

4. **Effective activation should explain the composition**
   - Operators and shell surfaces often need the compact answer to `why can’t this start right now?`.
   - A healthy tiny shape is: baseline intent, optional temporary overlay, current hold/transition state, and resulting effective admission summary.

5. **Overlay scope, provenance, and expiry matter**
   - A temporary override should say who imposed it, what it applies to, and when it ends when that footing is available.
   - `runtime only`, `until reboot`, `until clear`, `session-local`, or `operator hold` are much healthier than silent invisible force.

6. **Provider-local layering is fine; the portable seam stays small**
   - Some runtimes have rich property layers or multiple override channels.
   - Steward does not need to standardize every underlying precedence rule.
   - Phase 1 likely needs only: baseline activation intent, optional overlay truth, optional stronger prohibition/refusal reason, and one compact effective admission summary.

7. **This seam stays separate from current liveness and serve-state truth**
   - `running`, `serving`, `draining`, `waiting`, or `maintenance` remain different seams.
   - Activation overlays answer `what future starts or operator verbs are effectively allowed right now?`, not `is useful work being served?`.

## Explicit non-goals
- a universal install / preset / runlevel / milestone grammar;
- standardizing every provider-specific precedence layer or repository merge rule;
- a giant policy language for every possible per-verb refusal;
- forcing every adapter to distinguish baseline, overlay, and effective admission equally well;
- pretending temporary overlays are durable historical truth.

## References
- REF-SYSTEMCTL
- REF-SYSTEMD-UNIT
- REF-SYSTEMD-DBUS-API
- REF-SMF-LAYERS
- REF-SVC-STARTD
- REF-WINDOWS-SERVICE-STATUS
