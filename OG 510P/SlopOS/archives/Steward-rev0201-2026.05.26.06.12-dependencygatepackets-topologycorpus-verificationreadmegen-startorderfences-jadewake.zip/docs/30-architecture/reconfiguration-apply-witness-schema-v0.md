# Reconfiguration-apply witness schema v0

`ST-RECONFAPPLY v0` is a closed Steward packet for one attempted application of a planned generation to an exact runtime cycle.

## Purpose
An apply witness records started, applied, failed, partial, rolled-back, or unknown reconfiguration movement. It binds a generation plan to a runtime cycle and material-freshness refs. It does **not** prove material freshness by itself, readiness, serving, traffic binding, promotion, all-worker update, current state, or effect success.

## Required fields
- `schema`: exactly `ST-RECONFAPPLY v0`.
- `witness_id`, `cid`, and closed `issuer`.
- `apply_id`: stable apply id.
- `plan_ref`: exact generation-plan id.
- `generation_ref`: exact generation id.
- `runtime_cycle_ref`: exact runtime-cycle id.
- `material_freshness_refs`: adjacent material freshness witness refs used for the apply.
- `apply_state`: `started`, `applied`, `failed`, `partial`, `rolled_back`, or `unknown`.
- `reload_mode`: `none`, `signal`, `api`, `restart`, `hot_swap`, `supervisor`, or `unknown`.
- `applied_at_ms`: local monotonic time for the latest observed apply movement.
- `restart_required`: boolean.
- `error_reason`: `none` for started/applied states, otherwise a bounded reason.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for material freshness, current state, readiness, serving, traffic binding, promotion, all-worker update, and effect success.

## Rejection examples
- applied state without material freshness refs;
- applied state with `reload_mode` of `none` or `unknown`;
- failed, partial, rolled-back, or unknown state without a reason;
- packet claiming readiness, traffic binding, promotion, all-worker update, or effect success.
