# Activation-probe vantage posture v0

Purpose: name the smallest useful truth for **who probed what, from which vantage, with what scope, and how stale the result is** so Steward can keep probe evidence separate from readiness, liveness, serving, admission, endpoint advertisement, residency, material freshness, and operator policy.

This seam is intentionally small. It does **not** invent a health-check DSL, mesh, load balancer, monitor, SLO engine, rollout controller, or incident system. It answers one narrower question: **when a runtime, supervisor, client, balancer, mesh, or observer reports probe-like evidence about an activation target, how can Steward preserve the vantage and scope without pretending the probe result is the whole service truth?**

## Posture
1. **Probe result is not readiness, liveness, or serving by itself**
   - A successful probe can show that one configured check passed from one vantage at one time.
   - It does not by itself prove the component is ready for all declared work, live in the watchdog sense, serving all new traffic, correctly published, current after restore, or safe for irreversible effects.
   - A failed probe can also be a route, credential, material, timeout, local dependency, balancer, network, or observer problem rather than proof that the component is dead.

2. **Vantage must be explicit**
   - A kubelet exec probe, a node-local HTTP probe, a gRPC client health watch, a mesh active probe, a balancer target check, a synthetic outside-in probe, and a component self-check have different meanings.
   - Steward should preserve `observer_class`, `observer_ref`, `path_or_service`, `transport`, `target_ref`, and `scope` when known instead of flattening everything into `healthy`.

3. **Probe scope must not drift silently**
   - Probing `/healthz`, one gRPC service name, one listener, one target group, one endpoint slice, one route, or one dependency set are different claims.
   - If the probe scope is `whole-server`, `service-specific`, `listener-only`, `dependency-light`, `dependency-full`, `balancer-target`, or `unknown`, that should be visible.
   - Steward should not let a cheap local check masquerade as full end-user path success.

4. **Startup shielding and steady-state probing stay separate**
   - Startup probes or startup gates can protect slow initialization from premature liveness or readiness actions.
   - Once the startup shield drops, later readiness/liveness/serving probes have their own cadence, failure thresholds, and consequences.
   - Steward should not infer that a component is unhealthy merely because a steady-state probe was withheld during startup.

5. **Probe freshness decays and cached probe truth must say so**
   - Probe results can be cached, thresholded, sampled, delayed, or observed through eventually consistent control planes.
   - Useful states include `current-pass`, `current-fail`, `initializing`, `threshold-pending`, `cached-pass`, `cached-fail`, `stale`, `observer-unavailable`, `disabled`, and `unknown`.
   - `current_as_of`, `next_due`, `expires_or_recheck_by`, `consecutive_failures`, or `threshold_state` are optional evidence, not a new global health timeline.

6. **Balancers and clients have probe policy, not omniscience**
   - Load balancers may have initial, healthy, unhealthy, draining, unused, disabled, unavailable, or fail-open behavior.
   - Clients may suppress or resume sends based on a watched service-specific health status.
   - Those behaviors are important for explaining traffic, but they are policy actions layered over probe evidence, not proof that the component itself has changed state.

7. **Terminating / draining probe truth composes with serve-state; it does not replace it**
   - A terminating endpoint can still be serving some traffic, and a draining target can still receive existing or fail-open traffic depending on the substrate.
   - Steward should preserve the probe vantage plus any separate `serve_state`, `shutdown_horizon`, and `presence_advertisement` witnesses rather than collapsing them into one green/red dot.

8. **Identity checks matter when endpoints are recycled**
   - A probe that reaches an IP, port, socket, or name does not necessarily prove that it reached the expected component incarnation.
   - When available, a probe should carry `expected_component_id`, `expected_incarnation_id`, `service_name`, `authority_name`, or `probe_identity_basis` so recycled endpoints, hot restarts, and stale discovery records do not pass as current truth.

9. **Probe failure classification should stay humble**
   - Useful failure hints include `timeout`, `response-mismatch`, `transport-failed`, `auth-failed`, `dependency-failed`, `observer-error`, `identity-mismatch`, `not-registered`, `target-draining`, `probe-disabled`, and `unknown`.
   - These hints guide explanation and repair, but they should not automatically restart, withdraw, reroute, or bless a component unless another seam authorizes that action.

10. **Phase 1 shape is a witness, not a health plane**
    - A tentative `activation_probe_vantage` witness can stay tiny: `component_id`, optional `incarnation_id`, optional `endpoint_or_route_ref`, `observer_class`, optional `observer_ref`, `probe_kind`, optional `scope`, optional `transport`, optional `path_or_service`, optional `target_ref`, optional `identity_basis`, `probe_state`, optional `failure_hint`, optional `consecutive_failures`, optional `threshold_state`, optional `current_as_of`, optional `expires_or_recheck_by`, optional `next_due`, optional `proof_strength`, and optional `unknown_reason`.
    - Field names remain provisional until real Steward components show which facts must cross membranes.

## Executable packet settlement
`ST-PROBE v0` is the first executable settlement for this posture. It deliberately proves less than the full posture: closed decode, canonical digest, required non-implications, explicit vantage/scope/freshness, failure hints for failing probes, stale-pass rejection, repair-action redaction, and flow-level rejection of probe-pass-as-serving.

The deterministic corpus in `../40-verification/currentness-control-corpus-v0.md` is the current promotion gate: new probe-vantage language should preserve those cases or add a new accept/reject case before becoming stronger posture.

## Phase-1 non-goals
- a universal health-check DSL, probe registry, monitor, service mesh, load balancer, SLO/SLA system, canary controller, rollout controller, incident manager, or red/green status ontology;
- requiring every component to expose HTTP, TCP, gRPC, exec, watchdog, or synthetic probes;
- treating probe success as authority, readiness, serving, stable advertisement, fresh material use, successful effect, or current incarnation proof;
- treating probe failure as automatic restart, kill, rollout rollback, withdraw, repair, or user-facing incident truth;
- hiding cached, sampled, thresholded, fail-open, outside-in, or path-limited observation behind one `healthy` bit.

## Adjacent docs
- `readiness-posture-v0.md`
- `liveness-evidence-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `presence-advertisement-posture-v0.md`
- `activation-endpoint-witness-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `activation-residency-posture-v0.md`
- `activation-material-freshness-posture-v0.md`
- `shutdown-horizon-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-PROBES
- REF-K8S-ENDPOINTSLICES
- REF-GRPC-HEALTH-CHECKING
- REF-ENVOY-HEALTHCHECKING
- REF-AWS-ALB-HEALTHCHECKS
- REF-AWS-ALB-TARGET-HEALTH
- REF-CLOUD-RUN-HEALTHCHECKS
