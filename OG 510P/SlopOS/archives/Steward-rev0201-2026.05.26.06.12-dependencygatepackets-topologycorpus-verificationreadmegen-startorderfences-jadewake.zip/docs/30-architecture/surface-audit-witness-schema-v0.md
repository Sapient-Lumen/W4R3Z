# Surface audit witness schema v0

## Packet
`ST-SURFAUDIT v0` records one audit/refactor witness for a rendered surface, evidence bundle, or cube hygiene surface.

## Required meaning
The packet names what was audited, the scope, finding state, findings, required changes, changed refs, and target revision.

## Required non-implications
Every audit packet must explicitly refuse:

- `not-fix`
- `not-authority`
- `not-current-state`
- `not-execution`
- `not-proof-of-correctness`
- `not-release`

## Canonicalization
The machine profile is [`../../schemas/st-surfaudit-v0.schema.json`](../../schemas/st-surfaudit-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
An audit identifies or records a refactor. It is not the refactor itself, not release evidence, and not proof that the audited surface is globally correct.
