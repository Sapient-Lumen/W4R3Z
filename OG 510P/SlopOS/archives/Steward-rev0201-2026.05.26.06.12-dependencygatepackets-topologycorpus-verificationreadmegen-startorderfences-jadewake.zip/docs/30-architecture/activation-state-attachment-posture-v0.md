# Activation-state attachment posture v0

Purpose: name the smallest useful truth for **which state-like material is attached to one activation incarnation, component identity, residency slot, projection, volume, snapshot, or external store** without confusing attached bytes with currentness, readiness, custody, work disposition, side-effect fate, or ambient filesystem authority.

This seam is intentionally small. It does **not** invent a volume manager, filesystem namespace API, secret/config store, checkpoint/restore protocol, migration system, storage scheduler, cache service, vault, or database model. It answers one narrower question: **when an activation episode can observe that files, directories, projections, scratch space, caches, volumes, runtime directories, or restored state are attached, what compact witness prevents Steward from treating that attachment as proof of service or safe replay?**

## Posture
1. **State attachment is not residency, identity, or continuity**
   - Residency says where or how an incarnation is placed, warm, frozen, restored, evicting, evicted, or lost.
   - Incarnation lineage says which concrete run/replacement/restore relation is being observed.
   - State attachment says what state-like material is attached, projected, mounted, redelivered, rebound, detached, cleaned, or unknown for that run or component.
   - Steward should not let a path, volume id, runtime directory, projected credential, snapshot artifact, or cache label silently stand in for current component identity or runtime-cycle truth.

2. **Lifetime class must be visible before reuse**
   - Useful classes include `image-readonly`, `runtime-scratch`, `incarnation-tmp`, `execution-environment-tmp`, `allocation-shared`, `component-data`, `component-cache`, `persistent-volume`, `manager-runtime-directory`, `projected-config`, `projected-secret`, `snapshot-derived`, `external-store`, `detached`, and `unknown`.
   - The class should be carried with a scope such as component, incarnation, residency slot, allocation, execution environment, request, or external object.
   - If the lifecycle of the attached material is not known, the honest state is `attachment-unknown`, not `persistent by hope`.

3. **Ephemeral floors are different kinds of ephemeral**
   - Some scratch survives a container crash but not Pod removal.
   - Some tmp storage is unique to one execution environment or instance and disappears when that environment stops.
   - Some writable container layers are unique to one container and disappear when the container is destroyed.
   - Steward should prefer explicit chips such as `survives-container-crash`, `lost-on-pod-removal`, `lost-on-instance-stop`, `lost-on-container-destroy`, `memory-backed`, or `quota-limited` over the flat word `ephemeral`.

4. **Persistent attachment is not current attachment**
   - Stable storage can outlive a concrete run, follow a logical identity across reschedule, or be rebound after restart.
   - That persistence does not prove the new incarnation has opened it, repaired it, replayed it, fenced stale owners, or observed the latest schema/currentness boundary.
   - Steward should keep `persistent-known`, `rebind-pending`, `rebound`, `needs-replay`, `stale-owner-risk`, `schema-check-pending`, and `attachment-current` separate.

5. **Best-effort migration and sticky attachment need humility**
   - Sticky or migrated state is useful performance/recovery evidence, but it may be best effort, node-dependent, partially transferred, or suitable only for recreatable cache data.
   - A migration failure should not silently become data-loss ignorance or successful continuity.
   - Useful states include `sticky-preferred`, `migration-started`, `migration-complete`, `migration-failed-data-lost`, `migration-failed-rolled-back`, and `recreate-required`.

6. **Projected material is not ordinary local mutable state**
   - Config, downward metadata, service-account tokens, trust bundles, and certificates can be projected into files, refreshed, atomically swapped, or fail to update under mount modes such as sub-path use.
   - A component may need to reload promptly, and split reads can observe mismatched pieces if the substrate warns about that risk.
   - Steward should let projected material carry `projection_source`, `projection_epoch`, `audience_or_signer`, `expires_or_refreshes`, `subpath-no-update-risk`, `reload-required`, and `projection-currentness` without making projections a general config store.

7. **Runtime directories and state directories are managed attachment, not ambient filesystem authority**
   - A service manager may create, clean, quota, or protect runtime/state/cache/log/config directories for a unit.
   - That is valuable because it ties some paths to unit lifecycle and can reduce UID-reuse hazards.
   - It does not mean the component may rely on arbitrary host paths, bind-mounted directory descriptors, or inherited filesystem reachability as portable Steward authority.

8. **Snapshot-derived state must be followed by explicit rebinding checks**
   - Restored memory, heap caches, tmp files, projected credentials, open descriptors, leases, clocks, entropy, peers, and topology can all be stale after the outside world moved on.
   - A state-attachment witness should be able to say `snapshot-derived`, `rebind-pending`, `projection-reload-pending`, `credential-reacquire-required`, `descriptor-reopen-required`, `lease-revalidate-required`, or `after-restore-state-check-passed` without promising transparent migration.

9. **Attachment witnesses are not path grants or bearer handles**
   - A witness may explain that a volume, directory, projection, scratch area, or external reference was attached or detached.
   - It should not itself authorize `open(path)`, mount mutation, secret readback, volume transfer, or cross-component state import.
   - Stronger file/object authority remains on existing explicit descriptor, namespace, portal, or capability seams.

10. **Cleanup and detach are first-class fates**
    - Detached state may be deleted, retained, garbage-pending, leaked, quarantined, or unknown.
    - Cleanup failure can create security, quota, privacy, or stale-owner risk even when the component is otherwise stopped.
    - Steward should allow `detached`, `cleanup-started`, `cleanup-complete`, `cleanup-failed`, `retained-by-policy`, `garbage-pending`, `orphaned`, `quarantined`, and `detach-unknown` as explanation chips.

11. **Phase 1 shape is a witness, not a storage API**
    - A tentative `activation_state_attachment` witness can stay tiny: `component_id`, optional `incarnation_id`, optional `residency_witness`, `attachment_id`, `attachment_kind`, `lifetime_class`, `scope`, `basis`, optional `path_or_mount_label`, optional `projection_or_volume_ref`, optional `snapshot_or_template_ref`, optional `persistence_expectation`, optional `migration_state`, optional `rebind_state`, optional `cleanup_state`, optional `observed_at`, optional `expires_or_recheck_by`, optional `proof_strength`, and optional `unknown_reason`.
    - Field names remain provisional until real Steward components show which facts must travel across membranes.

## Executable packet settlement
`ST-STATEATT v0` is the first executable settlement for this posture. It deliberately proves less than the full posture: closed decode, canonical digest, required non-implications, projected-material material refs, runtime-cycle/incarnation fences for attached/restored state, snapshot rebind state, raw path/handle redaction, and downgrade reasons for stale/unknown attachment.

The deterministic corpus in `../40-verification/currentness-control-corpus-v0.md` is the current promotion gate: new state-attachment language should preserve those cases or add a new accept/reject case before becoming stronger posture.

## Phase-1 non-goals
- a filesystem namespace API, path-open API, mount manager, volume manager, storage scheduler, or topology-aware storage placement DSL;
- a secret/config store, vault, projected-credential service, credential filesystem, or global app-state service;
- a database model, cache service, stateful workload controller, replication system, or schema migration plane;
- a checkpoint/restore, live-migration, hibernation, or state-transfer protocol;
- treating attached paths, mounted volumes, projected files, sticky disks, runtime directories, or restored heaps as proof of readiness, serving, current incarnation, custody, work disposition, or effect fate;
- making state-attachment witnesses into bearer authority, path grants, volume handles, or cross-component import tokens.

## Adjacent docs
- `activation-material-freshness-posture-v0.md`
- `activation-residency-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `activation-custody-posture-v0.md`
- `continuity-escrow-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `launch-boundary-posture-v0.md`
- `descriptor-hygiene-posture-v0.md`
- `authority-narrowing-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `retention-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-VOLUMES
- REF-K8S-PROJECTED-VOLUMES
- REF-K8S-STATEFULSET
- REF-NOMAD-EPHEMERAL-DISK
- REF-NOMAD-ALLOCATION-FILESYSTEMS
- REF-CLOUD-RUN-IN-MEMORY-VOLUMES
- REF-AWS-LAMBDA-EPHEMERAL-STORAGE
- REF-DOCKER-STORAGE
- REF-SYSTEMD-EXEC
- REF-FUCHSIA-STORAGE-CAPABILITIES
