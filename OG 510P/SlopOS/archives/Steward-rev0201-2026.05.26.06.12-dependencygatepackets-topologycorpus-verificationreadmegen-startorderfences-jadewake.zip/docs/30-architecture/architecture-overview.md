# Architecture overview

Steward is the **component lifecycle and activation fabric** for SlopOS.

The current compression of the architecture is in [`design-principles-v0.md`](design-principles-v0.md). Those principles intentionally stop short of freezing a giant service-manager worldview while SlopOS itself is still moving.

The matching refusal set is in [`non-decisions-v0.md`](non-decisions-v0.md). That file exists to keep “not decided yet” explicit instead of letting accidental defaults harden into architecture.

## What Steward probably owns
- component identity and lifecycle roots;
- optional shallow ownership islands for containment, activation scope, and exact control targeting while keeping topology algebra intentionally unfrozen;
- component start / stop / restart policy;
- foreground lifecycle accountability;
- explicit non-ambient launch context so component entry and restart do not depend on login-shell or session folklore;
- explicit authority narrowing and lock-state honesty so reviewed allowlists or delivered capabilities can reduce ambient authority without freezing a giant sandbox language;
- explicit descriptor hygiene so inherited handles, stdio attachment, and side channels do not become accidental contract;
- optional exact execution-group machinery under the membrane so one component run may map to one reviewed multi-process workload without turning process trees, cgroup paths, or job handles into public meaning;
- explicit attributable short-lived transition helpers that stay separate from the supervised long-lived leaf;
- supervisor-owned activation delivery plus compact activation receipts for exact-run startup material and acknowledgement;
- an explicit activation-fanout seam so one reviewed demand surface may feed one shared worker or one per-demand worker instance without freezing an inetd/systemd instance grammar or generic concurrency API;
- exact request-carried activation where the first meaningful delivery may wake the component without freezing a giant bus or focus-steering control plane;
- explicit activation-admission receipts so one wake, start, or demand attempt can be admitted, denied, deferred, narrowed, throttled, shed, or left unknown before execution or service truth is claimed;
- explicit coordination-gate witnesses so preconditions, operation arbitration, deliberate holds, and progress windows explain waiting/blocked/held/stalled state without claiming authorization, execution, currentness, readiness, serving, operation result, or effect success;
- explicit activation-custody witnesses so one admitted demand, event, descriptor, or background obligation can report its current holder, handoff strength, cancellation state, expiry, redelivery risk, or ambiguity without claiming completion;
- explicit activation-state attachment witnesses so runtime scratch, projected material, runtime/state directories, sticky or persistent volumes, snapshot-derived state, detach, and cleanup can be explained without claiming readiness, currentness, custody, work fate, or effects;
- explicit activation-material freshness witnesses so config, secrets, tokens, trust bundles, leases, and restored material can say whether they are static, versioned, projected, renewable, expired, revoked, reload-pending, reacquire-required, or unknown without claiming attachment or delivery proves current authority;
- explicit activation-probe vantage witnesses so startup, readiness, liveness, gRPC health, balancer, mesh, and synthetic checks can preserve observer, scope, path, thresholds, caching, and freshness without claiming readiness, serving, current incarnation, or policy action;
- explicit activation-control verdict witnesses so controllers, balancers, rollout loops, DNS-health systems, deployment circuit breakers, and operator adapters can expose issuer, subject, scope, basis, freshness, effect class, and verdict state without collapsing raw observations into routing, rollback, remediation, or incident truth;
- executable currentness/control packets so selected state-attachment, material-freshness, probe-vantage, and control-verdict facts are closed, digestable, freshness-scoped, and checked against attachment-as-currentness, freshness-as-reload, probe-as-serving, verdict-as-route, degraded-material traffic gates, and raw path/secret collapses;
- executable rollout-generation packets so generation plans, reconfiguration apply attempts, scoped generation readiness, and promotions/rollbacks are closed, digestable, freshness-scoped, and checked against material-as-freshness, reload-as-readiness, readiness-as-traffic, promotion-as-serving, rollback-as-compensation, and effect-success collapses;
- explicit activation-traffic binding witnesses so route, alias, service, gateway, proxy, DNS, target-group, tagged-test, weighted, mirrored, sticky, draining, stale, and unknown new-demand mappings can be explained without claiming readiness, serving, admission, custody, rollout, or rollback truth;
- explicit activation-live channel witnesses so existing connections, streams, subscriptions, watches, WebSockets, server-sent event streams, multiplexed RPCs, and drainable clients can report holder, drain layer, no-new-work fences, close/reset fate, cursor/resume hints, gap ambiguity, and force-close truth without claiming route binding, readiness, serving, custody, work disposition, effects, or rollout truth;
- executable traffic-binding and live-channel packets so selected route/channel facts are closed, digestable, freshness-scoped, and checked against readiness, serving, effect-success, lossless-continuity, and live-channel-fate collapses;
- explicit activation-retry attempt witnesses so retries, replays, transparent retries, hedges, reconnect resends, and post-drain attempts can report original demand, canonical-intent match, safety basis, pushback/backoff, budget, commitment boundary, and duplicate ambiguity without claiming route binding, custody, work disposition, effect success, or exactly-once truth;
- explicit receipt transport witnesses so chained lifecycle receipts, minimized redaction commitments, evidence export bundles, and replay/import observations can support handoff and recovery without becoming authority, live state, freshness, complete history, or effect success;
- explicit activation-work disposition witnesses so one admitted work item can report acknowledged, redeliverable, redelivered, expired, dead-lettered, discarded, abandoned, detached, superseded, or unknown fate without pretending admission, custody, restart, readiness, or serving means completion;
- explicit tiny wake-memory witnesses so future alarms, reminders, queued triggers, and inactive/hibernated continuity can explain later activation without pretending the component is currently running or ready;
- tiny exact request-context semantics so activation, chooser detours, and automation can carry optional deadlines and explicit cancellation without a giant RPC metadata plane;
- optional exact effect-key semantics so reviewed non-commutative actions can collapse duplicate retries, reject mismatched reuse, and stay smaller than a durable exactly-once ledger;
- optional compact retry-advice semantics so denials, cooldowns, or explicit pushback can carry earliest-follow-up hints without freezing a quota or giant retry-policy family;
- optional exact precondition-witness semantics so reviewed actions can stale-fence themselves against runtime-cycle, cursor, epoch, or anchor drift without ambient latest-lookups;
- exact closeable grant handles for pending requests, stop deferral, capture, and similar transient powers so they do not dissolve into sticky mode bits;
- optional parse lenses so weak transcript/output interpretation can still power smart cards and staged follow-on actions without masquerading as exact shell or lifecycle truth;
- optional compact consumable-grant semantics so some transient powers can be spent by use and become visibly consumed instead of replayable from stale history;
- optional compact attenuated-grant semantics so an exact live grant may derive a narrower helper or follow-on grant without exposing the parent raw or freezing a generic token-exchange / delegation plane;
- optional compact holder-bound-grant semantics so some exact live grants can require current holder proof instead of behaving like replayable bearer material;
- optional compact fresh-intent witnesses so some high-risk or foreground-sensitive actions can require recent local one-shot intent evidence instead of replayable transcript history or ambient automation;
- optional compact renewal windows so live claims can expire, renew, or admit staleness honestly without freezing a giant lease or watchdog plane;
- optional exact fence tokens or current-owner witnesses so reassignable live claims can reject stale holders without freezing a distributed lock, leader-election, or global sequencer plane;
- optional exact-run observation tricks under the membrane so runtime-cycle witnesses can be backed by non-reused host handles where available without turning those handles into portable meaning;
- executable lineage/resume packets so runtime-cycle, incarnation-lineage, residency, and resume/reconciliation facts are closed, digestable, freshness-scoped, and checked against cycle reuse, stale operation targets, residency-as-readiness, resume-as-same-cycle, lossless-continuity, and predecessor-effect settlement collapses;
- lifecycle observation vocabulary, compact status reporting, optional exact status barriers for currentness/attribution races, freshness-decay rules, bounded observation subscriptions, and optional exact observation cursors so views can resume or admit continuity loss honestly;
- explicit witness-surface packets so rendered cards, action affordances, status barriers, and surface audit/refactor receipts can expose evidence without claiming currentness, readiness, serving, authorization, execution, fixes, releases, or proof of correctness;
- explicit provisional-state semantics so lag-hiding shell/terminal UX stays visibly tentative until confirmation;
- explicit attention hints so command-finished, needs-input, warning, and progress-like shell/terminal cues stay user-filterable, freshness-scoped, and non-authoritative;
- explicit notification surfaces so OS toasts, mark-alert style wakeups, and similar escalation cues stay exact-anchor-bound, focus-aware, and action-bounded instead of becoming a hidden approval path;
- optional exact attention-watch handles so user-armed `watch this frame / receipt / run` flows stay expiring, reveal-first, and exact-anchor-bound instead of dissolving into generic notification preference or watch-bus folklore;
- optional runtime-cycle witnesses for correlating concrete runs;
- compact start-of-cycle activation observations for explaining why a concrete run began without freezing a giant causal graph;
- an optional tiny bootstrap-reconciliation seam so trigger/request-caused wake can stay separate from later present-tense condition reconciliation and currentness claims;
- compact end-of-cycle cause / termination observations for explaining why a concrete run ended;
- bounded repeated-failure cooldown and optional repair-gate semantics so crash loops become explicit evidence instead of hidden retry folklore;
- an explicit failure-latch seam so remembered failed / maintenance state can stay visibly separate from current liveness, retry-budget pressure, and quiet forgetting;
- bounded continuity escrow;
- an optional tiny continuity-escrow truth so `escrow current`, `redelivered`, or `flushed` can stay separate from runtime identity, serving/drain role, and proven takeover;
- an optional tiny presence-advertisement seam so `advertised`, `withheld`, `withdrawn`, `expired`, or `critical` can stay separate from readiness, serving truth, and runtime-cycle identity;
- readiness, optional tiny readiness-generation witnesses for stale-fencing mid-run config/reload drift, optional tiny progress windows so warming/reload work can be distinguished from stalled bring-up, an explicit tiny hold-state seam so `paused`, `draining`, `frozen`, or `start-prevented` truth stays separate from stall/failure/off, activity accounting, explicit activity brackets for runtimes that can support them, bounded stop deferral, an optional tiny shutdown-horizon seam so `terminating through <deadline>` or `deadline extended` stays separate from stop request and later cut-through, and quiesce semantics;
- optional tiny liveness-evidence semantics so watchdog/probe/check-in truth can stay separate from readiness, useful work progress, and later repair policy;
- lifecycle transcripts / receipts;
- shell/terminal semantic integration for lifecycle-aware UX;
- command-frame observations and receipt-friendly terminal ergonomics;
- optional exact output-slice objects so `copy output`, `select output`, `attach last failure`, and exact handoff can bind to one bounded region instead of nearby-text folklore;
- optional exact command-verdict objects so one exact command result can drive decorations, reveal/watch UX, and `attach last failure` selection without smearing together outcome summary, output, and transcript guesswork;
- optional exact command-evidence bundles so `attach last failure`, `share this exact command interaction`, and bounded troubleshooting handoff can package one reviewed command interaction without whole-scrollback export;
- optional exact evidence-draft objects so one bounded exact handoff can be trimmed, masked, or annotated before export without mutating the source evidence or falling back to raw copy/paste surgery;
- optional exact current-command objects beside live prompt leases so reveal / assist / copy / diff can bind to what the user is actually editing without transcript folklore;
- optional exact injection-receipt objects so reviewed insert / replace / load actions can leave one exact shell-visible receipt over what changed in the live session without pretending execution occurred or freezing an undo/history family;
- optional exact command-patch objects so repair / assist / history-backed rewrites can stage one reviewable mutation over one stronger command anchor without ambient fix-up magic or shell-grammar empire;
- optional exact repair-card objects so failed or blocked commands/components can surface one reviewable likely-next-fix card with visible why-this-appeared and disabled-reason truth instead of rerun folklore or hidden auto-remediation;
- optional exact detour-outcome objects so chooser/open/auth/approval completions can resolve as one typed shell-visible result instead of being inferred from stale request handles, pasted text, or focus folklore;
- an explicit attach-lane seam so observe-only witness mode, interactive attach, lifecycle control, and debug entry stay visibly different moves instead of one vague attached state;
- an explicit component-shell seam so `shell into this component scope` stays a reviewed, expiring helper action distinct from observe-only attach, lifecycle control, and debugger entry;
- an explicit attach-continuity seam so reconnecting, resumed witness, expired, replaced, and lost terminal presence stay separate from runtime-cycle or service-lifecycle truth;
- an explicit proposal-lane seam so agent/chat/notebook suggestion work stays visibly separate from exact shell input, reviewed execution, and canonical lifecycle transcripts;
- an explicit approval-rung seam so proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion stay visibly different powers with policy floors and honest downgrade;
- an explicit exception-witness seam so bypass-under-review, waived-under-expiry, and satisfied-gate truth stay visibly different without freezing a giant waiver or break-glass family;
- an explicit headroom-witness seam so allowed, approved, and ready stay visibly separate from currently spendable restart / quota / rate-window headroom;
- an explicit serve-state-witness seam so `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, and `not serving` stay visibly separate from mere process liveness, readiness folklore, and discoverability;
- an explicit enablement-intent seam so durable `manual`, `auto`, `auto-delayed`, `disabled`, and stronger `start-prohibited` truth stays visibly separate from current liveness, temporary holds, and activation causes;
- an explicit activation-overlay seam so durable baseline activation intent, temporary runtime/operator overrides, and state-scoped verb admission can compose into one explainable effective activation summary without freezing a giant precedence algebra;
- an explicit reconfigure seam so in-place reload / refresh support, state-scoped admission, and apply result stay visibly separate from restart, replacement, and config-edit truth;
- an explicit pressure-witness seam so scoped `ok` / `some` / `full` / `warning` / `critical` pressure truth stays visibly separate from serving mode, headroom, and failure;
- an explicit backpressure-witness seam so `queued`, `retry-after`, `shed`, and `stop-accepting` truth stays visibly separate from pressure, headroom, and failure;
- an explicit adaptation-witness seam so cache trim, reduced concurrency, optional-work deferral, and other protective responses stay visibly separate from pressure, backpressure, and vague degraded folklore;
- an explicit preflight-lane seam so explain, diff, speculative preview, reviewed saved plan, and apply stay visibly different moves with exact footing and honest stale/denied outcomes;
- an explicit revision-settlement seam so reviewed desired revision, observed revision, and last settled/stable revision stay visibly different without freezing a giant rollout controller;
- an explicit return-ticket seam so browser/auth/chooser detours can come back as exact expiring local hints without turning callback or focus folklore into lifecycle meaning;
- an explicit execution-ground seam so panes, command frames, and receipt cards can show cwd root, hop lineage, runtime-cycle witness, launch basis, and truth labels without pretending chrome is authority;
- explicit shell/terminal attention-hint surfaces for focus-aware alerts, badges, and progress-ish cues without hidden control;
- an explicit notification-surface seam for OS toasts, alert-on-mark wakeups, and exact reveal actions that remain compact, focus-aware, and clearly separate from durable truth;
- an explicit attention-watch seam for user-armed exact completion / settlement watches that remain small live objects instead of invisible pane preference or generic subscription state;
- an optional shell/terminal chrome lane for status bars, sticky headers, tab titles, and other non-transcript presentation surfaces that remain observational and freshness-scoped;
- an explicit command-guide seam for exact-frame guide rails, sticky headers, and similar visible command boundaries that stay filterable and distinct from transcript truth;
- an explicit transcript-landmark seam for marks, annotations, alerts, and exact jump targets that stay anchor-bound, provenance-labeled, and clearly separate from transcript truth or ambient control;
- an explicit context-inheritance seam for tabs, splits, reruns, and action-launched shells so same-cwd or same-domain comfort stays per-action, labelable, and policy-bounded;
- an explicit spawn-selector seam so tabs, splits, reruns, and helper shells can choose reviewed program/profile/domain/cwd recipes instead of ambient `$SHELL`, profile, or pane folklore;
- an explicit spawn-palette seam so launcher menus and command palettes expose reviewed recipes, visible downgrades, and exact launch explanations instead of acting as an ad hoc command hole;
- an explicit surface-diagnostics seam so shell/terminal affordances can explain capability, freshness, provenance, and policy reasons instead of behaving like magic;
- an explicit remembered-shelf seam so recent commands, directories, and Steward objects can stay keyed to host/hop context, freshness-labeled, and clearly non-authoritative;
- an explicit history-lane seam so unified remembered search can span typed history, reviewed inserts, workflows, notebook blocks, and proposal memory without flattening them into one canonical execution record;
- an explicit retention-surface seam so persisted command, directory, paste, and host/user breadcrumbs stay scopeable, erasable, and clearly remembered instead of becoming ambient retained authority;
- an explicit replay-gate seam so remembered, restored, or suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore;
- an explicit chooser-surface seam so file pickers, visible-text selectors, and context pickers can return exact targets or reviewed selectors instead of pasted-text folklore;
- optional small pending-request handles for chooser/open/reveal/approval detours so mediated UI interactions can stay attributable, cancelable, and shell-visible instead of becoming modal side effects;
- an explicit assist-surface seam so quick fixes, suggestion menus, and current-input help stay anchored, reviewable, and clearly advisory instead of becoming an ambient second shell;
- an explicit assist-receipt seam so one suggestion can answer why it appeared, what exact stronger anchor it binds to, and why stronger apply paths may be disabled without becoming ambient suggestion folklore;
- an explicit repair-card seam so failed or blocked commands/components can surface one reviewable likely-next-fix card with exact anchors, disabled reasons, and honest downgrade instead of transcript folklore or auto-remediation;
- an explicit state-explainer seam so exact frames, runs, requests, or repair gates can answer `why waiting / blocked / repair-required / rebind-required` over one stronger anchor without becoming a diagnosis empire or workflow engine;
- an explicit automation-surface seam so scripts, hooks, remote-control APIs, and helper CLIs stay exact-targeted, permissioned, and inspectable instead of becoming an ambient second control plane;
- compact confidence / provenance / trust annotations for shell/terminal observations and action gating;
- explicit user-invoked action surfaces for hyperlinks, chips, and palette affordances tied to explicit Steward targets;
- explicit target anchors so higher-value shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs instead of visible-text scraping;
- explicit bounded context handoff so exact command frames, output slices, receipts, and concrete runs can be attached or exported without ambient whole-scrollback sharing;
- an explicit command-verdict seam so one exact command result can travel as a compact shell-visible outcome for decorations, watches, and last-failure selection without becoming a giant shell-result taxonomy;
- an explicit command-evidence seam so one exact command interaction can travel as bounded evidence for `attach last failure`, `share this run`, or `escalate this result` without becoming a transcript-export empire;
- an explicit evidence-draft seam so one outbound reviewed subset can preserve provenance while dropping or masking fields before attach / share / escalation;
- explicit precision fences for shell/terminal trust and capability drift across hops or fallback paths;
- an explicit shell/terminal mode baseline and repair seam so prompt-critical markers, cursor modes, paste handling, and other UX-critical state can be freshly reasserted instead of left to folklore;
- an explicit paste-firewall seam so pasted payloads can be previewed, staged, literalized, or denied with visible reasons instead of being mistaken for typed fresh intent or silently rewritten;
- explicit capability handshakes so richer shell/terminal semantics can be enabled from fresh observed support instead of compatibility folklore;
- explicit pane/hop-scoped capability ledgers so rich shell/terminal affordances can key off what the current path actually preserved, degraded, or re-reported;
- explicit semantic epochs so stale shell/terminal certainty can be fenced after hops, resync, or shell reset;
- explicit shell/terminal hop lineage so remote-aware context, histories, and action targets stay scoped to the actual path rather than a flat PTY fiction;
- explicit promotion of selected shell-launched long-running work into transient accountable objects.

## What Steward probably does not own
- generic deferred work scheduling (that stays adjacent to jobs/background seams);
- a generic global timer language;
- a monolithic logging system;
- a generic process inventory API;
- a portable exactly-once mutation or dedupe-ledger plane;
- a general-purpose host service-manager compatibility layer as native meaning;
- every shell/runtime semantic in SlopOS;
- a universal trusted-UI, consent-cache, biometric, or passkey family;
- a universal shared-session / collaboration / remote-attach transport family;
- a universal reconnect-roaming / silent-retarget attach family;
- a universal unified remembered-search / synced-history / cross-lane memory family;
- a universal startup-timeout / progress-deadline / extend-timeout DSL.
- a universal scheduler / lock service / queue manager / transaction planner for coordination gates.
- a universal rollout controller / deployment orchestrator / service-mesh promotion engine / compensation framework for generation changes.
- a universal maintenance-window / disable-policy / drain-planner / inhibit-hold family.
- a universal scheduler / actor runtime / durable reminder / hibernation / workflow-history family.
- a universal liveness-probe / watchdog / degraded-health DSL.
- a universal service-registry / discovery-lease / balancer-membership DSL.
- a universal overload / fair-queuing / retry-budget / traffic-shaping family;
- a universal admission-controller / policy-webhook / quota-wallet / denial-lattice family;
- a universal custody broker / durable queue / workflow-history / exactly-once delivery family;
- a universal activation-work disposition, poison-queue, redrive, offset/commit, transaction, or exactly-once side-effect family;
- a universal activation-effect boundary, outbox service, saga, compensation framework, global idempotency ledger, or transaction coordinator family;
- a universal activation-incarnation lineage, rollout controller, migration protocol, distributed lock, leader-election service, hot-restart handoff API, or global epoch sequencer family;
- a universal activation-residency scheduler, autoscaler, warm-pool manager, checkpoint/restore API, live-migration protocol, topology authority, or placement DSL;
- a universal activation-state attachment filesystem namespace API, volume manager, storage scheduler, secret/config store, stateful workload controller, database/cache service, or checkpoint/migration state-transfer family;
- a universal activation-material freshness vault, credential filesystem, config store, workload-identity plane, certificate rotation service, trust-bundle distribution system, reload controller, or secret-rollout family;
- a universal activation-probe health-check DSL, service mesh, load balancer, monitor, SLO engine, rollout controller, incident system, or red/green ontology;
- a universal activation-control verdict rollout controller, canary framework, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, incident manager, or health algebra;
- a universal activation-live channel connection manager, transport API, RPC framework, pub/sub broker, watch service, stream multiplexer, reconnect scheduler, session-resumption plane, service mesh, sticky-session grammar, or endpoint-drain controller;
- a universal activation-retry retry engine, RPC framework, service mesh, route-level retry budget service, durable queue, broker, workflow engine, distributed idempotency ledger, hedge racing subsystem, or exactly-once effect plane;
- a universal brownout / autoscaling / remediation-policy / adaptive-tuning family.

## Design stance
Steward should cover the **responsibility areas** people expect from a competent modern service fabric, but not inherit the integrated, ambient, host-global worldview of a traditional Unix service manager.

That means:
- narrow public semantics,
- foreground, directly accountable lifecycle roots,
- host-specific implementation freedom under the membrane,
- visible non-decisions while SlopOS itself is still converging,
- open questions kept visible until pressure justifies freezing them,
- observational/state protocols and bounded subscription views hardening before giant mutation/control surfaces;
- repeated-failure quieting becoming explainable before any giant retry-policy language hardens;
- optional liveness evidence staying narrow and observational before any broader health-check or degraded-mode family is considered;
- optional presence-advertisement truth staying narrow and reviewable before any broader discovery-registry, lease, or balancer-membership family is considered;
- optional backpressure truth staying narrow and reviewable before any broader overload, fair-queuing, or traffic-shaping family is considered;
- optional adaptation truth staying narrow and reviewable before any broader brownout, autoscaling, or remediation-policy family is considered;
- retry-safe action keys staying explicit and narrow before any broader transaction or exactly-once plane is considered;
- bounded continuity escrow staying explicit and reviewable before any broader checkpoint/restore or generic state-broker family is considered;
- attenuation-only derived grants staying explicit and narrow before any broader delegation, impersonation, or token-exchange plane is considered;
- stale-fenced conditional actions staying explicit before any broader compare-and-swap, lock, or query language is considered;
- stale-holder fences staying explicit before any broader lock, leadership, or sequencer family is considered.
- holder-proof seams staying optional and exact before any broader proof-of-possession, key-lifecycle, or token-introspection family is considered.
- wake-memory witnesses staying descriptive before any broader scheduler, actor, hibernation, or durable-workflow family is considered.
- activation-admission receipts staying per-attempt and explanatory before any broader policy engine, quota wallet, fair queue, or admission-controller framework is considered.
- activation-custody witnesses staying descriptive before any broader broker, service mesh, workflow engine, or exactly-once delivery family is considered.
- activation-work disposition witnesses staying explanatory before any broader redrive, dead-letter, transaction, job-status, or exactly-once side-effect family is considered.
- activation-effect boundary witnesses staying explanatory before any broader outbox, saga, compensation, transaction, idempotency-ledger, or exactly-once side-effect family is considered;
- activation-incarnation lineage witnesses staying explanatory before any broader rollout, migration, hot-restart, restore, lock, leadership, or global epoch family is considered.
- activation-residency witnesses staying explanatory before any broader scheduler, autoscaler, warm-pool, checkpoint/restore, migration, topology, or placement family is considered.
- activation-state attachment witnesses staying explanatory before any broader filesystem, volume, secret/config, storage-scheduler, stateful-controller, checkpoint/restore, or migration family is considered.
- activation-material freshness witnesses staying explanatory before any broader vault, config-store, credential-rotation, workload-identity, trust-bundle, reload-controller, or secret-rollout family is considered.
- activation-probe vantage witnesses staying explanatory before any broader health-check DSL, mesh, load balancer, monitor, SLO engine, rollout, or incident family is considered.
- activation-control verdict witnesses staying explanatory before any broader rollout controller, canary framework, service mesh, load balancer, DNS failover, remediation, autoscaling, or incident family is considered.
- activation-traffic binding witnesses staying explanatory before any broader load balancer, service mesh, DNS failover, Gateway API, target-group manager, route compiler, canary framework, or rollout-controller family is considered.
- activation-live channel witnesses staying explanatory before any broader connection manager, transport API, RPC framework, pub/sub broker, watch service, stream multiplexer, reconnect scheduler, session-resumption plane, service mesh, sticky-session grammar, or endpoint-drain controller is considered.
- activation-retry attempt witnesses staying explanatory before any broader retry engine, RPC framework, service mesh, route-level retry budget service, durable queue, broker, workflow engine, distributed idempotency ledger, hedge racing subsystem, or exactly-once plane is considered.
- retry-settlement packets staying explanatory before any broader retry scheduler, rate-limit service, RPC framework, service mesh, hedge-racing subsystem, distributed idempotency ledger, or exactly-once effect plane is considered.

## Revision 188 retry / hedge settlement proof slice

Revision 188 extends executable packet settlement to retry and hedge truth. Steward now treats `ST-RETRYADVICE v0`, `ST-RETRYBUDGET v0`, `ST-RETRYATTEMPT v0`, and `ST-HEDGEFATE v0` as separate closed witnesses: a not-before hint, a local retry budget, one follow-up attempt, and a hedge winner/loser settlement cannot imply one another unless a later flow checker sees exact adjacent references and still preserves their non-implications.

The corpus intentionally rejects advice-as-reservation, zero-budget automatic retry, same-key/different-intent replay, transparent retry after commitment, unsafe early-data replay, external-effect confirmation without an effect witness, hedge loser cancellation as no-side-effect proof, and exactly-once wording. This keeps Steward descriptive over retry libraries, RPC stacks, service meshes, proxies, quota systems, and idempotency ledgers without becoming any of them.

## Revision 186 currentness / probe / verdict proof slice

Revision 186 extends executable packet settlement to the currentness-before-control chain. Steward now treats `ST-STATEATT v0`, `ST-MATFRESH v0`, `ST-PROBE v0`, and `ST-CTRLVERDICT v0` as separate closed witnesses: attached state, fresh material evidence, a green or red probe, and a controller verdict cannot imply one another unless a later flow checker sees the exact adjacent references and still keeps their non-implications.

The corpus intentionally rejects attachment-as-freshness, freshness-as-reload-success, probe-pass-as-serving, verdict-as-route-authority, eligible traffic gates based on degraded material, hidden repair action, raw path or secret leakage, and duplicate-key flattery. This keeps Steward descriptive over storage systems, vaults, probe frameworks, controllers, repair systems, and routes without becoming any of them.

## Revision 185 demand / custody / effect proof slice

Revision 185 extends executable packet settlement from control and route/channel facts into the work path. Steward now treats `ST-DEMAND v0`, `ST-CUSTODY v0`, `ST-WORKDISP v0`, and `ST-EFFECT v0` as separate closed witnesses: accepted demand, held custody, local work disposition, and external effect boundary cannot imply one another unless the flow checker sees the exact adjacent references.

The corpus intentionally rejects accepted-demand-as-completion, custody-as-effect-success, local-completion-as-effect-success, effect-before-work, mismatched reuse of the same effect key, inverted retention windows, secret leakage, host-manager identifiers, and exactly-once wording. This keeps Steward descriptive over brokers, queues, handlers, and outboxes without becoming any of them.

## Revision 183 executable operation packets

Revision 183 extends the proof surface from lifecycle objects into operator mutation packets. Steward now treats `ST-OPREQ v0` and `ST-OPRECEIPT v0` as closed, digestable packets for reviewed start/stop/restart/quiesce/refresh operations. The operation corpus checks exact component targets, manifest/cycle fences, idempotency-key reuse, request/receipt digest binding, receipt non-implications, and manager-recovery downgrade.

This still is not a remote management API or durable job system. It is the smallest packet seam needed to keep admin UI, shell action cards, repair gates, and adapter facts from turning one requested operation into false readiness, serving, stopped-state, effect success, or post-recovery currentness.

## Revision 182 verification stance

Revision 182 adds the first deliberately small executable proof surface instead of another broad posture sweep. Steward now treats CH-COMP, CH-ACTSET, canonical digesting, activation receipt boundaries, restart replay, stale runtime-cycle fences, quiesce/stop separation, adapter weakness, retry intent matching, and effect-boundary separation as corpus-checkable seams.

That proof surface is intentionally not a service-manager implementation. It is a falsification harness for the claims most likely to drift when Steward is adapted onto systemd, Kubernetes, service meshes, brokers, shells, or desktop repair surfaces. New posture should now either feed the proof slice, be recorded as sibling pressure, or remain deferred in `../00-meta/session-working-queue.md`.

## Revision 189 shutdown settlement proof slice

Revision 189 extends executable packet settlement to the shutdown chain. Steward now treats `ST-QUIESCE v0`, `ST-DRAIN v0`, `ST-ESCALATE v0`, and `ST-TERMCAUSE v0` as separate closed witnesses: a no-new-demand gate, a drain boundary, a stronger intervention, and an end-cause observation cannot imply one another unless a flow checker sees exact adjacent references and still preserves their non-implications.

The corpus intentionally rejects quiesce-as-stopped, quiesce-as-no-live-channels, drain-as-lossless, drained-with-pending-work, escalation-as-stopped, escalation-as-clean-exit, termination-as-effect-success, forced-stop-as-clean-exit, and successor-readiness flattery. This keeps Steward descriptive over shutdown surfaces without becoming a service manager, signal API, broker drain protocol, endpoint-drain controller, crash analyzer, or restart engine.

## Revision 190 governance authorization proof slice

Revision 190 extends executable packet settlement to the operator-governance path immediately before operation execution. Steward now treats `ST-DELEGATE v0`, `ST-REVIEW v0`, `ST-APPROVAL v0`, and `ST-AUTHCHECK v0` as separate closed witnesses: a scoped delegation warrant, a bounded request review, an exact approval decision, and a current authorization gate cannot imply one another unless the flow checker sees exact adjacent references and still preserves their non-implications.

The corpus intentionally rejects owner-label-as-delegation, active-but-expired warrants, re-delegation creep, observe-only mutation, review-pass-as-authorization, stale review-as-pass, approval-without-warrant, denied approval without reason, kill approval without break-glass classification, approval-as-execution, allowed authorization without approval refs, stale authorization without reason, expired-delegation use, approval digest mismatch, non-pass review, denied approval, delegate mismatch, verb widening, authorization-as-execution, duplicate warrant drift, and effect-success flattery.

This keeps Steward descriptive over Ward, org charts, RBAC systems, on-call tools, approval UIs, audit products, and escalation workflows without becoming any of them. The only public promise is that lifecycle mutation gates can be inspected and replay-checked without confusing governance evidence with operation receipts, lifecycle state, or external effects.

## Revision 192 import reconciliation proof slice

Revision 192 extends executable packet settlement across the evidence-import membrane. Steward now treats `ST-IMPORT v0`, `ST-SRCAPPRAISE v0`, `ST-RECONPLAN v0`, and `ST-RECONDECISION v0` as separate closed witnesses: an imported bundle, an appraisal of that source, a mapping plan, and a local adoption or quarantine decision cannot imply one another unless the flow checker sees exact adjacent references and still preserves their non-implications.

The corpus intentionally rejects accepted imports without redaction, unsorted imported receipt digests, import-currentness flattery, source appraisals that allow current-state use, expired appraisals, ready plans without local witnesses, reconciliation plans that try to execute lifecycle mutations, gapful plans without downgrade reasons, weak-basis decisions without local witnesses, history adoption with weak-basis scope, decisions without plans, quarantined imports being adopted, and import decisions being used to execute operations.

This keeps Steward descriptive over support handoffs, manager recovery imports, sibling-cube evidence, audit replays, and adapter dumps without becoming Ward trust, ViewFS storage, a provenance ledger, a migration system, an approval workflow, or a second lifecycle authority.

## Revision 194 witness-surface and audit/refactor proof slice

Revision 194 extends executable packet settlement to the rendered/control surface. Steward now treats `ST-WITCARD v0`, `ST-ACTIONAFFORD v0`, `ST-STATUSBARRIER v0`, and `ST-SURFAUDIT v0` as separate closed witnesses: a rendered card, a reviewable action affordance, a stale/status barrier, and an audit/refactor receipt cannot imply one another or stronger lifecycle truth unless exact adjacent packets say so.

The corpus intentionally rejects weak cards rendered as settled, rendered cards used as readiness, enabled mutating actions without exact operation request and authcheck refs, raw PID/host targets, clear barriers that secretly block verbs, active barriers without stale refs or refresh requirements, enabled actions that ignore active barriers, audits without findings or changed refs, and audit-as-fix or action-as-execution flattery. This pass also refactors `tools/run_lint_suite.py` into a registry-driven harness loop and records the proof-slice inventory drift as a cube audit finding.


## Local observation provenance packet settlement
Revised193 adds a weak observation layer below native Steward lifecycle witnesses. `ST-LOCALOBS` records categorical adapter/host/runtime observations; `ST-OBSAPPRAISE` limits how those observations may be used; `ST-OBSCURSOR` records observation-stream continuity and gaps; `ST-OBSATTACH` attaches observations only as weak basis, quarantine, refusal, or recheck. This keeps useful operational evidence visible without letting host folklore become readiness, currentness, serving, operation execution, demand drain, or effect truth.

## Revision 196 attention notification proof slice

Revision 196 extends executable packet settlement to attention and notification truth. Steward now treats `ST-ATTNHINT v0`, `ST-ATTNWATCH v0`, `ST-NOTICE v0`, and `ST-ATTNACK v0` as separate closed witnesses: an attention cue, an armed watch, a delivery attempt, and a reveal/dismiss/focus/open acknowledgement cannot imply one another or stronger lifecycle truth unless exact adjacent packets say so.

The corpus intentionally rejects ambient current-pane anchors, watch-as-automation, mutating notification actions, notification-as-user-seen, acknowledgement-as-resolution, notice-without-watch/hint, notice-before-hint, ack-without-notice, watch-as-authorization, and duplicate notice id drift. This keeps Steward descriptive over shell attention, UI wakeups, badges, toasts, exact reveal affordances, and acknowledgements without becoming a notification service, reminder inbox, macro engine, approval UI, user-presence plane, or desktop framework.


## Revision 200 activity-accounting proof slice

Revision 200 extends executable packet settlement to activity accounting. Steward now treats `ST-ACTBRACKET v0`, `ST-IDLEHINT v0`, `ST-STOPDEFER v0`, and `ST-ACTACCT v0` as separate closed witnesses: in-flight activity, busy/idle observation, bounded stop deferral, and descriptive usage accounting cannot imply one another or stronger lifecycle truth unless exact adjacent packets say so.

The corpus intentionally rejects activity-as-demand, bracket-as-custody, busy-as-readiness, idle-as-stopped, stop deferral as an immortal keepalive lease, deferral over closed brackets, deferral past bracket freshness, closed accounting over open brackets, accounting-as-billing, accounting-as-work-completion, and effect-success flattery. This keeps Steward descriptive over runtime transaction hints, idle-stop signals, stop grace, and usage meters without becoming a workflow lease plane, billing system, quota wallet, drain protocol, or request-completion API.
