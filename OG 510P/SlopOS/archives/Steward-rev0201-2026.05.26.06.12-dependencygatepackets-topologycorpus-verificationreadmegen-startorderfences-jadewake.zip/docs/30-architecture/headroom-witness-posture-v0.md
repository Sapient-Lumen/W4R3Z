# Headroom-witness posture v0

Purpose: define a **tiny headroom witness seam** so approval, authority, and readiness stay visibly separate from **currently spendable headroom** such as restart admissions, quota room, seat counts, or rate-limit windows.

This seam stays intentionally small. It does **not** invent a universal quota wallet, pricing ledger, fairness algebra, or portable scheduler. It only says that when a reviewed action or component is otherwise allowed, Steward should still be able to say whether the next step is actually *spendable now*, what exact ceiling is in play, and when that answer changes.

## Posture
1. **Allowed is not the same as spendable**
   - A reviewed action may be policy-allowed and still be blocked because the relevant restart, quota, seat, or rate window has no headroom left.
   - Steward should keep `allowed`, `approved`, `ready`, and `headroom exhausted` visibly separate instead of flattening them into one vague denial or busy spinner.
2. **Headroom is observational truth, not portable spend authority**
   - A headroom witness explains what the current ceiling or window says from one exact footing.
   - It should not itself become a bearer token, prepaid budget object, or proof that later spending will still succeed after drift.
3. **Ceiling, used, remaining, and reset/replenish hints should stay distinct when knowable**
   - Some systems can expose a hard ceiling and current used/remaining values.
   - Others can only expose `blocked until`, `window resets at`, `retry after`, or `unknown secondary limit`. Steward should preserve whichever of those are real instead of fabricating a fake complete meter.
4. **Primary and secondary ceilings are different truths**
   - A system may publish one primary remaining count while keeping other anti-abuse ceilings partially hidden or qualitatively different.
   - Steward should be willing to say `secondary headroom unknown`, `rate limited for undisclosed reason`, or similar truth instead of pretending every budget is perfectly inspectable.
5. **Headroom must stay scoped to an exact subject and window**
   - A witness should say what it applies to: restart admission for this component slot, quota for this namespace, rate window for this endpoint class, or another equally exact scope.
   - Headroom should not silently jump scope or masquerade as a global machine-wide truth.
6. **Reset, replenish, and manual clear are different mechanisms**
   - Some windows refill with time, some counters age out over a trailing interval, and some blocked states need explicit reset or operator action.
   - Steward should keep those paths separate instead of teaching users one mythical `wait a bit` story.
7. **Headroom denial should name the limiting class when possible**
   - `policy floor`, `approval missing`, `quota exhausted`, `restart budget exhausted`, `primary rate limit exhausted`, and `secondary rate limit hit` are healthier explanations than one generic `denied` state.
   - Even a compact witness becomes dramatically more useful when the limiting class is explicit.
8. **Shell chrome should make spendability legible without becoming authority**
   - Execution-ground cards, command frames, and receipts may show compact labels such as `restart 2/5 in 60s`, `quota 3 pods remaining`, `rate 41/5000 until 14:00`, `secondary limit unknown`, or `manual clear required`.
   - Those labels explain the spend boundary; they do not widen authority or bypass review.
9. **This seam is smaller than a quota family**
   - Steward may reuse the same tiny witness shape across restart, quota, seat, and rate-limit surfaces.
   - It should not thereby freeze a universal quota DSL, cost model, fairness engine, or cross-runtime wallet.
10. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `headroom_class`, exact scope label, and whichever of `ceiling`, `used`, `remaining`, `resets_at`, `retry_after`, `manual_clear_required`, or `unknown` the adapter can prove.
   - Richer aggregation and policy algebra remain intentionally undecided.

## Phase-1 non-goals
- a universal quota / wallet / token-bucket schema;
- pricing, cost-allocation, or fairness policy;
- promising that a previously observed remaining count guarantees later success;
- a portable enterprise-capacity planner or shared-cluster accounting dashboard;
- flattening primary, secondary, and hidden anti-abuse ceilings into one fake meter.

## Adjacent docs
- `restart-budget-posture-v0.md`
- `retry-advice-posture-v0.md`
- `approval-rung-posture-v0.md`
- `preflight-lane-posture-v0.md`
- `execution-ground-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-RESOURCE-QUOTAS
- REF-NOMAD-QUOTA
- REF-GITHUB-RATE-LIMITS
- REF-SYSTEMD-UNIT
- REF-SYSTEMCTL

## Executable settlement
Closed packet profiles and corpus checks now live in `pressure-admission-proof-posture-v0.md`, `pressure-witness-schema-v0.md`, `headroom-witness-schema-v0.md`, `backpressure-witness-schema-v0.md`, `admission-gate-witness-schema-v0.md`, and `../40-verification/pressure-admission-corpus-v0.md`.
