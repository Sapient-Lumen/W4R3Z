# Action affordance witness schema v0

## Packet
`ST-ACTIONAFFORD v0` records one visible action affordance.

## Required meaning
The packet says that a surface may show a disabled action, a reviewable action, an auth-required action, a recheck-required action, or an unknown action state for an exact target class.

Mutating affordances require an exact operation request digest, authorization-check ref, stale-fence refs, and `review_required: true` before they can be `enabled_for_review`.

## Required non-implications
Every affordance must explicitly refuse:

- `not-execution`
- `not-authorization`
- `not-approval`
- `not-effect-success`
- `not-current-state`
- `not-target-current`

## Canonicalization
The machine profile is [`../../schemas/st-actionafford-v0.schema.json`](../../schemas/st-actionafford-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
An affordance is not execution. It is not approval. It is not authorization. It must not target raw host/runtime identities such as PIDs, host units, pods, containers, cgroups, descriptors, paths, or endpoints.
