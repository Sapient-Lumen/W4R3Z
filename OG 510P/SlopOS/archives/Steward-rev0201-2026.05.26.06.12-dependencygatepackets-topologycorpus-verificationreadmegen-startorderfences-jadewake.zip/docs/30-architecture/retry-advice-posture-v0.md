# Retry-advice posture v0

Purpose: define a **tiny retry-advice / not-before hint seam** so denials, cooldowns, or explicit pushback can carry an exact earliest sensible follow-up time without turning Steward into a quota service, universal retry policy language, or ambient backoff folklore.

## Posture
1. **Retry advice is timing guidance, not authority or success promise**
   - A retry-advice hint says “before this time, the issuer does not expect a follow-up attempt of this exact kind to be useful or admissible”.
   - It is not a grant handle, renewal window, effect key, fence token, or proof that a later retry will succeed.
2. **Advice may be absent, and absence does not mean immediate safety**
   - Some denials are permanent, some require fresh review or repair, and some simply cannot estimate a good retry moment.
   - Steward should keep `retry-advice-missing` distinct from `retry now` instead of collapsing both into one vague “no hint” bucket.
3. **Relative and absolute forms may exist under the membrane, but the public meaning stays small**
   - Adapters may learn retry timing from local cooldown timers, absolute timestamps, or server pushback.
   - Publicly, Steward only needs one exact meaning: an earliest-follow-up hint scoped to one reviewed action or claim lineage.
4. **Cause stays separate from timing**
   - `cooling-down`, `rate-limited`, `still-processing`, `pushback`, and `repair-required` are not synonyms even when some of them happen to yield a wait time.
   - Steward should preserve the denial or delay reason separately from any retry hint.
5. **Retry advice is issuer-local and freshness-scoped**
   - A hint only makes sense within one issuer/action family/context.
   - Old shell frames, copied notes, or remembered shelves must not treat an earlier retry hint as current live truth after the context moved on.
6. **Hints should fail closed when they go stale or become impossible to honor**
   - `expired`, `superseded`, `still-processing`, `manual-clear-required`, and `retry-advice-unknown` should remain visibly different outcomes when the path can prove them.
   - That is healthier than silently guessing a fresh backoff window from stale history.
7. **Shell chrome should make waiting honest and useful**
   - High-value chips should be able to say `retry after 12s`, `try again at 14:03:12`, `still processing`, `wait for clear`, or `hint expired`.
   - That honesty is healthier than a dead-looking button or a blind rerun affordance.
8. **Keep the seam smaller than a quota / retry-policy family**
   - One optional retry-advice hint plus exact reason/outcome vocabulary is enough for Phase 1.
   - Steward should not freeze a portable RateLimit header family, retry-throttling ledger, or giant exponential-backoff grammar through this seam.

## Executable settlement
Revision 188 gives the advice seam a closed packet profile: `ST-RETRYADVICE v0` in `retry-advice-witness-schema-v0.md`, checked by `../../tools/steward_retry_settlement_harness.py` through `../40-verification/retry-settlement-corpus-v0.md`. The packet deliberately requires non-implications such as `not-grant`, `not-reservation`, `not-admission`, `not-readiness`, `not-serving`, `not-effect-success`, `not-budget-capacity`, and `not-retry-success`.

That same corpus pairs advice with `ST-RETRYBUDGET v0`, `ST-RETRYATTEMPT v0`, and `ST-HEDGEFATE v0` so a wait hint cannot be used as a hidden permission slip, capacity reservation, work-completion receipt, or side-effect settlement.

## Phase-1 non-goals
- a portable quota, rate-limit, or token-bucket plane;
- a universal exponential-backoff grammar or jitter DSL;
- requiring every denial or delay to produce a retry hint;
- treating retry advice as a grant that can be cached or replayed as authority;
- automatic blind retry loops hidden behind shell or lifecycle UX.

## Adjacent docs
- `effect-key-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `renewal-window-posture-v0.md`
- `repair-gate-posture-v0.md`
- `request-context-posture-v0.md`
- `grant-handle-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `action-surface-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-HTTP-RFC9110
- REF-GRPC-HEDGING
- REF-K8S-POD-LIFECYCLE
- REF-K8S-KUBELET-CONFIG
- REF-SYSTEMD-SERVICE
