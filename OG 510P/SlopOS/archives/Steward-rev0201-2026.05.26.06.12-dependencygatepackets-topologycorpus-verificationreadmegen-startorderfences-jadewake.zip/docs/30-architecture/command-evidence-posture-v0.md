# Command-evidence posture v0

Purpose: define a **tiny exact command-evidence seam** so Steward can package “this exact command interaction” as one bounded evidence object for `attach last failure`, `share this run`, `explain this result`, or `open this evidence elsewhere` without flattening whole scrollback into ambient truth.

## Posture
1. **A command-evidence object binds to one stronger owning interaction**
   - The healthiest owner is one exact command frame, exact output slice, runtime-cycle witness, receipt span, or another reviewed anchor.
   - Steward should resist handoff folklore like “whatever recent prompt, output, and cwd seem nearby probably belong together”.
2. **Frame, output slice, and evidence bundle are different truths**
   - A command frame is the primary command interaction boundary.
   - An output slice is one bounded output-bearing region.
   - A command-evidence object is the reviewed packaged subset the user actually means to attach, share, or escalate.
   - Steward should preserve those distinctions instead of making every follow-on choose between raw transcript bytes and whole-frame export.
3. **Exact shell metadata should outrank transcript reconstruction**
   - When shell integration or exact frame anchors exist, `attach last failure`, `share this command`, or `open evidence` should bind to those exact anchors.
   - Parse-lens reconstruction and visible-text selection are useful fallbacks, but they must stay visibly weaker.
4. **The minimal evidence bundle should stay small and obvious**
   - Phase 1 likely needs only: command text, exact output slice or selected bounded subspan, exit code / end cause when known, duration or start/end time, cwd / hop lineage when safe, confidence/provenance, and optional refs to receipts / runtime-cycle witnesses / transcript landmarks.
   - Avoid freezing a giant transcript-export, issue-report, or chat-attachment schema before repeated operating pressure proves it is worth standardizing.
5. **Redaction and omission should be first-class, not afterthoughts**
   - Users may want to drop cwd, host lineage, selected output lines, or receipt refs before export.
   - Steward should let fields be removed or masked without destroying the fact that the remaining bundle still came from one exact interaction.
6. **Evidence bundles are observational, not control authority**
   - A command-evidence object may justify copy, attach, explain, compare, or annotate.
   - It must not silently become permission to rerun, restart, stop, or mutate lifecycle state merely because it contains strong evidence from an exact frame.
7. **Failure context should be gatherable without whole-pane export**
   - `Attach last failure` should be able to package the most recent failed frame or runtime cycle with its exact output slice, end cause, and nearby witnesses.
   - That should not require exporting unrelated scrollback, ambient shell history, or hidden environment state.
8. **Human-readable and machine-usable forms should coexist**
   - A bundle may need a readable summary card, plain-text export, and a structured descriptor for downstream tools.
   - This keeps shell UX and tool handoff useful without forcing every consumer to scrape prose.
9. **Freshness and downgrade truth must stay visible**
   - A bundle belongs to a semantic epoch, hop lineage, and confidence context.
   - Steward should be allowed to say `exact command evidence`, `parsed candidate bundle`, `trimmed`, or `redacted` instead of pretending old or downgraded footing is still exact.
10. **Keep the phase-1 contract tiny**
   - Phase 1 should stop at one exact command interaction bundle plus visible provenance, bounded payload, and redaction affordances.
   - Avoid freezing a universal troubleshooting envelope, durable artifact warehouse, or cross-tool evidence bus before real pressure exists.

## Phase-1 non-goals
- ambient export of whole panes, whole shell history, or full environment state by default;
- turning command-evidence bundles into lifecycle authority or replay permission;
- a giant bug-report / chat-export / issue-template family;
- pretending parsed candidate bundles are as strong as shell-reported command/frame metadata;
- inventing a durable evidence warehouse or workflow engine before more than one tightly related seam truly exists.

## Adjacent docs
- `command-frame-posture-v0.md`
- `output-slice-posture-v0.md`
- `context-handoff-posture-v0.md`
- `target-anchor-posture-v0.md`
- `repair-gate-posture-v0.md`
- `termination-cause-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-VSCODE-UPDATE-1106
- REF-VSCODE-UPDATE-1107
- REF-VSCODE-UPDATE-1109
- REF-VSCODE-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-ADVANCED-PROFILE
- REF-ITERM2-COMMAND-SELECTION
- REF-WEZTERM-SELECT-TEXT-AT-MOUSE
