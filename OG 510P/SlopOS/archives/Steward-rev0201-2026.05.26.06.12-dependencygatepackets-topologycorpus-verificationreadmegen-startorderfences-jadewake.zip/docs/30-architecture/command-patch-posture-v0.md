# Command-patch posture v0

Purpose: define a **tiny exact command-patch seam** so repair cards, proposal lanes, and other shell helpers can stage one reviewable mutation over one stronger command anchor without auto-applying fixes, flattening transcript guesswork into authority, or freezing a giant shell-rewrite family.

## Posture
1. **A command patch binds to one stronger source command truth**
   - The healthiest owner is one exact current-command object, a replayable exact prior command, or another reviewed command-bearing anchor.
   - Steward should resist folklore like “whatever looked like the command nearby is probably the right thing to edit”.
2. **Source command, proposed patch, and launched command stay different truths**
   - The source command is the stronger exact or reviewable baseline.
   - The command patch is the candidate mutation over that source.
   - A later launched command is new launch truth with its own receipt/frame/verdict.
   - Steward should preserve those distinctions instead of laundering proposal text into execution history.
3. **Review-before-apply should be first-class**
   - A healthy patch usually shows before/after or changed-span truth and lets the user inspect what will change.
   - This mirrors why interactive patch selection is so effective elsewhere: users can review the difference before they accept it.
4. **Insert, replace, and run are different outcomes**
   - The healthiest defaults are often `insert into live prompt`, `replace exact current command`, `stage in proposal lane`, or `copy as reviewed text`.
   - Immediate execution can still exist, but it should stay a stronger explicit move rather than the default meaning of a patch.
5. **Exact live footing should outrank historical or parsed footing**
   - When one exact current-command object is still live, patch application may target that live anchor directly.
   - When only a remembered command, command evidence, or parse-lens candidate remains, Steward should downgrade honestly to `patch candidate`, `copy`, or `stage for review` instead of pretending the original live prompt still exists.
6. **Patch provenance and disabled reasons should stay visible**
   - Good metadata include who or what proposed the patch, what stronger anchor it was derived from, freshness/confidence, and why a higher-power apply path might currently be disabled.
   - `stale source`, `missing live prompt`, `policy blocked`, and `needs fresh intent` are different truths.
7. **Patches should stay smaller than shell grammar empire**
   - Phase 1 can work with exact before/after text, optional changed spans, source refs, provenance, and outcome state.
   - Steward should not require a universal shell AST, portable diff/patch language, or cross-shell rewrite engine before repeated pressure proves it is worth standardizing.
8. **Repair cards and proposal lanes may emit patches, but do not become them**
   - A repair card may suggest one command patch.
   - A proposal lane may carry one command patch for review.
   - The patch itself should remain the compact reviewable mutation object instead of being smeared across whole chat turns, cards, or transcripts.
9. **One small command-patch seam beats ambient fix-up magic**
   - Terminal quick fixes, assistant rewrites, rerun-with-flag affordances, and history-backed “write but don’t run” flows all want the same anti-folklore discipline.
   - Steward should keep this seam smaller than a universal fixer marketplace, transcript rewrite plane, or automation workflow family.

## Phase-1 non-goals
- freezing a universal shell diff or patch format across shells and runtimes;
- auto-applying command rewrites merely because a suggestion exists;
- treating parsed command candidates as equal to live exact current-command footing;
- a durable rewrite queue, fixer marketplace, or workflow engine;
- requiring every shell path to preserve exact changed-span structure equally well.

## Adjacent docs
- `current-command-posture-v0.md`
- `injection-receipt-posture-v0.md`
- `proposal-lane-posture-v0.md`
- `assist-surface-posture-v0.md`
- `repair-card-posture-v0.md`
- `session-injection-posture-v0.md`
- `command-frame-posture-v0.md`
- `command-evidence-posture-v0.md`
- `parse-lens-posture-v0.md`
- `preflight-lane-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-GIT-ADD
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-CODEACTION-API
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
