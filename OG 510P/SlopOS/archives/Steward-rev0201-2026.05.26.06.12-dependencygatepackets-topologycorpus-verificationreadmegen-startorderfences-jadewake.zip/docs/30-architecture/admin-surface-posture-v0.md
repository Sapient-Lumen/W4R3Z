# Admin surface posture v0

## Purpose
Define the smallest useful Steward operator surface without creating an ambient remote control bus.

The admin surface should be observe-first. Mutations should be exact-targeted, stale-fenced, and receipt-producing.

## Minimal verbs
Read-only verbs:

- `inspect <component>`: show manifest, current witnesses, and refusal list;
- `status <component>`: compact currentness view with freshness;
- `explain <witness-or-receipt>`: show basis, issuer, scope, and non-implications;
- `subscribe <component-or-receipt>`: bounded snapshot-plus-change view that can admit continuity loss.

Mutating verbs:

- `request start <component> --reason ...`;
- `request stop <component> --reason ...`;
- `request restart <component> --reason ...`;
- `request quiesce <component> --reason ...`;
- `repair-gate clear <component> --receipt ...`.

## Mutation requirements
Every mutating command should emit an `ST-OPREQ v0` packet and settle through one or more `ST-OPRECEIPT v0` packets. The packet pair keeps the operator surface exact without turning it into an ambient admin bus.

Every mutating command must include or resolve to:

- exact component id;
- expected manifest or runtime-cycle witness when relevant;
- caller/issuer;
- reason;
- precondition witness or explicit waiver;
- result receipt.

The v0 packet profiles are specified in `control-operation-request-schema-v0.md` and `control-operation-receipt-schema-v0.md`, with executable checks in `../40-verification/control-operation-corpus-v0.md`.

No mutating command may target raw PID, process group, cgroup path, pane text, job table row, host unit name, or “latest matching service” as portable authority.

## Output shape
Responses should be witness cards:

- subject;
- witness kind;
- issuer;
- basis;
- observed/current-as-of time;
- freshness/expiry;
- scope;
- stronger adjacent facts required;
- explicit “does not prove” list;
- available reviewed actions.

## Remote posture
A remote/admin API may later exist, but v0 does not freeze one. Local CLI and shell/terminal surfaces should exercise the same exact-target and receipt rules before any broad management plane is designed.

## Non-goals
- no ambient admin bus;
- no host process inventory;
- no raw PID control API;
- no hidden auto-remediation plane;
- no terminal-as-authority shortcut;
- no broad RBAC/delegation framework in Steward.

## Adjacent material
- `target-anchor-posture-v0.md`
- `control-target-posture-v0.md`
- `status-barrier-posture-v0.md`
- `receipt-minimization-posture-v0.md`
- `companion-boundary-map-v0.md`

## Revision 190 governance gate

The observe-first admin surface now has a narrow authority settlement lane. Mutating controls may show or require an `ST-AUTHCHECK v0` card before execution. The card is intentionally weaker than the operation receipt: it explains delegation, review, approval, denial, staleness, or missing evidence, but it must not claim the action ran.

This keeps button enablement, approval chips, break-glass prompts, and repair-gate clearances from becoming ambient lifecycle authority.
