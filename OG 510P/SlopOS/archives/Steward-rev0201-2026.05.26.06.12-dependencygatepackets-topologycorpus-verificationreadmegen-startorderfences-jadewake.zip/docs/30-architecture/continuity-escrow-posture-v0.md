# Continuity-escrow posture v0

Purpose: keep **manager-preserved narrow continuity objects**, **runtime-cycle identity**, **public continuity**, **takeover proof**, and **historical memory** separate so Steward can say `escrow current`, `redelivered`, `escrow absent`, `flushed`, or `unknown` without freezing a generic descriptor broker, whole-process resurrection story, or giant checkpoint/restore family.

This seam stays intentionally small. It answers one narrower question: **when a reviewed component stops and later starts again, did Steward preserve and redeliver one bounded allowlisted continuity object or handle set, and what should that fact not be mistaken for?**

## Posture
1. **Escrow preserves narrow reviewed continuity, not process identity**
   - Redelivered listeners, handles, or state capsules may let a fresh runtime cycle resume one bounded continuity story.
   - That does not make the new cycle “the same process”, and it must stay separate from runtime-cycle witnesses and execution-group identity.
2. **Escrow should be allowlisted, bounded, and named**
   - The healthy default is one reviewed component-local escrow lane with named items or a bounded payload shape.
   - Steward should resist turning escrow into an attic of anonymous leftover descriptors or arbitrary opaque blobs.
3. **Redelivery is an explicit launch fact**
   - If escrow survives restart, the next run should receive it because Steward or a reviewed adapter explicitly redelivered it.
   - Ground cards, launch receipts, or status chips should be able to say `redelivered` or `escrow current` rather than forcing users to infer continuity from quiet sockets or lucky behavior.
4. **Escrow can preserve a public edge without proving takeover**
   - Manager-preserved listeners or state may keep the public continuity story alive while a new leaf warms or while takeover is still pending.
   - Steward should therefore keep escrow truth separate from serving-state and takeover-state truth.
5. **Escrow handoff should end the old live story promptly**
   - Systems that support escrow often expect the old run to hand off the continuity object and then promptly exit rather than continuing a second competing live story.
   - Steward should preserve that discipline and avoid letting “escrowed” mean “the old leaf is still somehow half-alive forever”.
6. **Escrow is replace-current, not accumulate-forever**
   - One current continuity object per reviewed key or lane is healthier than a growing inventory of stale capsules.
   - If a newer escrow replaces an older one, the old continuity story should become historical rather than silently coexisting.
7. **Shell chrome should expose escrow truth compactly**
   - Useful chips include `escrow current`, `redelivered`, `escrow absent`, `flushed`, or `escrow unknown`.
   - Useful exact actions include `show escrow receipt`, `show redelivery basis`, or `show continuity owner` when policy allows.
8. **Phase 1 keeps the portable vocabulary tiny**
   - Phase 1 likely needs no more than optional `current` / `redelivered` / `absent` / `flushed` / `unknown` observations plus evidence anchors when the adapter can prove them.
   - Steward should resist freezing a generic checkpoint/restore protocol, cross-component transfer grammar, or wide state-broker plane.

## Phase-1 non-goals
- a portable CRIU-like whole-process checkpoint / restore contract;
- a generic descriptor or memory-object escrow broker for arbitrary apps;
- cross-component escrow transfer or import semantics;
- implying that escrow redelivery proves readiness, stable availability, or proven takeover;
- keeping multiple historical escrow payloads live as ambient operator-facing state.

## Adjacent docs
- `activation-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `launch-boundary-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `serving-state-posture-v0.md`
- `takeover-state-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

- `activation-custody-posture-v0.md`

## References
- REF-SYSTEMD-FDSTORE
- REF-FUCHSIA-COMPONENT-RUNNER
- REF-FUCHSIA-IDLE-STOP
- REF-LAUNCHD-JOBS
- REF-LAUNCHD-SOCKETS
