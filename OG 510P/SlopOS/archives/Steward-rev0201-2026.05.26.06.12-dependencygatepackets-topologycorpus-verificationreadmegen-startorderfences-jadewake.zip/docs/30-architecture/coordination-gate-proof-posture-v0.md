# Coordination-gate proof posture v0

## Purpose
Make coordination facts falsifiable without turning Steward into a scheduler, lock service, rollout controller, or transaction engine.

## Packet split
- `ST-PRECOND v0`: one exact precondition evaluation.
- `ST-OPARBIT v0`: one operation collision/ordering decision.
- `ST-HOLD v0`: one deliberate lifecycle hold.
- `ST-PROGRESS v0`: one bounded progress-window observation.

## Non-collapse rules
1. A precondition is evidence, not authorization, approval, reservation, execution, or current state.
2. Operation arbitration is an ordering/collision result, not the operation result.
3. A hold is deliberate constraint, not failure, stopped/off state, readiness, or drain completion.
4. A progress window is not readiness, stability, serving, work completion, or effect success.
5. Active holds must be visible to arbitration; accepting a blocked mutating verb is a reviewable contradiction.
6. Expired preconditions and expired progress windows downgrade instead of being silently refreshed.
7. Queue positions, irreversible floors, release refs, hold refs, and deadline extensions are explicit because hidden coordination state is where managers most often flatter users.

## Why this belongs in Steward
Steward already has operation requests, receipts, governance, shutdown, retry, and witness surfaces. Users still need to know why a reviewed action is waiting, blocked, held, or stalled without allowing those coordination facts to impersonate lifecycle state.

## Why this does not become a sibling empire
- Ward still owns broad delegation and governance.
- Helm still owns broad repair/intervention UI.
- SlopOS still owns constitutional primitive semantics.
- Steward only records the minimal lifecycle-scoped coordination evidence required to avoid unsafe promotion.

## Executable settlement
`../40-verification/coordination-gate-corpus-v0.md` verifies the closed packets and rejects ambient targets, expired satisfied preconditions, precondition-as-authorization, queued-as-executed, active holds without blocked verbs, hold-as-failure/stopped, progress-as-readiness, past-deadline progress without downgrade, accepted operations despite active holds, stale precondition use, and duplicate arbitration drift.
