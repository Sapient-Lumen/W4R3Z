# Promotion witness schema v0

`ST-PROMOTION v0` is a closed Steward packet for a planned, applied, rolled-back, aborted, or unknown generation promotion.

## Purpose
A promotion witness records scoped traffic-promotion movement for a generation. It may point at generation-readiness and traffic-binding refs. It does **not** prove readiness itself, serving, work completion, drain, lossless transition, global stability, rollback success, or effect success.

## Required fields
- `schema`: exactly `ST-PROMOTION v0`.
- `witness_id`, `cid`, and closed `issuer`.
- `promotion_id`: stable promotion id.
- `generation_ref`: exact generation id.
- `readiness_ref`: exact generation-readiness ref, or `none` when not applied.
- `traffic_binding_ref`: exact traffic-binding ref, or `none` when not applied.
- `promotion_state`: `planned`, `applied`, `rolled_back`, `aborted`, or `unknown`.
- `promotion_scope`: `none`, `shadow`, `canary`, `partial`, `full`, or `unknown`.
- `weight_percent`: integer 0 through 100.
- `previous_generation_ref`: exact previous generation ref, or `none` when not applicable.
- `applied_at_ms`: local monotonic observation time for promotion movement.
- `rollback_ref`: exact rollback/apply ref, or `none`.
- `reason`: `none` for planned/applied states, otherwise a bounded reason.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for readiness, serving, work completion, drain, losslessness, global stability, rollback success, and effect success.

## Rejection examples
- applied promotion without readiness and traffic-binding refs;
- full promotion with weight other than 100;
- rolled-back promotion without rollback and previous-generation refs;
- packet claiming serving, readiness, drain, rollback success, work completion, or effect success.
