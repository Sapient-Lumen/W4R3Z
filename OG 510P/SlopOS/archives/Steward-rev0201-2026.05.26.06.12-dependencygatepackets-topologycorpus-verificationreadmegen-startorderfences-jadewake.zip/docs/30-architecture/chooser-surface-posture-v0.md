# Chooser-surface posture v0

Purpose: define a **tiny exact-selection seam** so file pickers, visible-text selectors, context pickers, and similar shell/terminal chooser UI return explicit targets or selectors instead of smuggling ambient text folklore back into launch and open flows.

## Posture
1. **Chooser surfaces should resolve to exact selectors or anchors, not only pasted text**
   - A chooser may start from visible text, current cwd, a transcript frame, or a focused pane, but the useful result is an exact target anchor, spawn selector, doc handle, or other reviewed descriptor.
   - Steward should resist pickers that only stuff guessed text back into the prompt and silently hope it still means the same thing.
2. **Ephemeral-by-default is healthier than ambient remembering**
   - A chooser can be used for one immediate action without automatically becoming a durable favorite, recent item, or persistent grant.
   - Remembering should stay explicit and route through remembered shelves or workspace snapshots instead of hitchhiking on ordinary selection.
3. **Visible text can be a discovery source without becoming authority**
   - It is great to select a visible path, URL, receipt id, or line-number reference from output.
   - Steward should still distinguish “matched text on screen” from “reviewed object target”, with room for exact downgrade banners when only the weaker form is available.
4. **Chooser start context should stay explicit**
   - Starting from the focused pane cwd, last shell-reported cwd, a remembered shelf, or an exact frame anchor can all be useful.
   - The chooser should say which source it used instead of collapsing those into one vague “current location”.
5. **Choosers should be composable, but through declared pipes or return values**
   - A file picker feeding another tool, a visible-text selector opening an inspector, or a context picker attaching an exact command frame are all excellent UX.
   - Steward should prefer declared payloads and reviewed follow-on actions over hidden shell substitution tricks or ambient clipboard side effects.
6. **Long chooser detours should stay handle-shaped**
   - If a chooser or mediated open path involves asynchronous UI or user interaction, Steward should be able to represent it as a small pending request handle with eventual response, cancel, expiry, and optional deadline budget.
   - That is healthier than ambient modal magic with no exact object to point at from the shell.
7. **Chooser actions should prefer exact open/launch routes when available**
   - Choosing a file can mean open in editor, open terminal here, attach as context, or resolve a reviewed action surface.
   - The chooser should carry those as explicit actions over the chosen target rather than forcing every result through one paste-like path.
8. **Failure and downgrade should stay visible**
   - If only raw matched text survived, if a doc handle can no longer be reopened, or if policy denies the follow-on action, the chooser should say so explicitly.
   - Silent fallback is just another form of folklore.
9. **One chooser seam beats many magical mini-dialogs**
   - File pickers, object pickers, context pickers, and visible-text selectors all want the same anti-folklore discipline.
   - Steward should prefer one small chooser-surface posture over a pile of host-specific special cases.

## Phase-1 non-goals
- a universal picker extension protocol for every terminal and GUI host;
- automatically turning every chooser result into a durable recent-item or persistent grant;
- pretending visible matched text is always identical to a reviewed object reference;
- relying on ambient clipboard mutation as the only follow-on transport;
- freezing one universal chooser UI layout.

## Adjacent docs
- `action-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `spawn-palette-posture-v0.md`
- `remembered-shelf-posture-v0.md`
- `workspace-snapshot-posture-v0.md`
- `context-handoff-posture-v0.md`
- `precision-fence-posture-v0.md`
- `request-context-posture-v0.md`
- `pending-request-posture-v0.md`
- `detour-outcome-posture-v0.md`

## References
- REF-KITTY-CHOOSE-FILES
- REF-KITTY-HINTS
- REF-ZELLIJ-FILEPICKER
- REF-ZELLIJ-PLUGIN-PIPES
- REF-WINDOWS-TERMINAL-ADVANCED-PROFILE
- REF-XDG-PORTAL-REQUEST
- REF-GHOSTTY-RELEASE-130
