# Activation-traffic binding posture v0

Purpose: name the smallest useful truth for **a route, alias, listener rule, service abstraction, gateway, proxy, or traffic surface that maps new activation demand to one or more revisions, endpoints, incarnations, mirrors, or drain paths** so Steward can keep route authority, controller verdicts, probe observations, serving truth, endpoint arming, presence advertisement, admission, and work completion separate.

This seam is intentionally small. It does **not** invent a load balancer, service mesh, DNS failover system, canary framework, route compiler, traffic simulator, endpoint-selection API, or rollout controller. It answers one narrower question: **when callers would now enter through some named demand surface, what binding does that surface currently claim for new work, how fresh is that claim, and what should that binding not be mistaken for?**

## Posture
1. **Traffic binding is not a control verdict**
   - A controller or operator can decide that a revision is `eligible`, `withheld`, `stalled`, or `rollback-started` before the data plane has actually changed.
   - Conversely, a route can continue using a last-known, cached, fail-open, sticky, or propagation-lagged binding after the newest verdict changed.
   - Steward should keep `control verdict says move traffic` separate from `new demand is actually bound here now`.

2. **The demand surface and binding issuer must be explicit**
   - Useful surfaces include a manager-owned listener, service name, Gateway route, load-balancer target group, function alias, DNS answer policy, queue subscription, test tag URL, or mesh route.
   - Useful fields include `traffic_surface_ref`, `binding_issuer`, optional `control_loop_ref`, optional `route_ref`, optional `listener_ref`, optional `service_ref`, optional `alias_ref`, optional `component_id`, optional `revision_ref`, and optional `incarnation_id`.
   - If the issuer or surface cannot be identified, the binding should downgrade to `binding-unknown` instead of masquerading as global route truth.

3. **Desired, observed, and applied route truth stay separate**
   - A desired traffic split, route rule, or alias update may be accepted before every proxy, balancer, DNS system, client, or serverless edge has observed it.
   - An observed config may still be warming, partially applied, or waiting for data-plane propagation.
   - Steward should preserve `desired-binding`, `observed-binding`, `applying`, `active-binding`, `partially-applied`, `stale-binding`, and `unknown` when those distinctions explain surprises.

4. **Weights are allocation instructions, not per-request destiny**
   - Weighted splits, aliases, and cluster weights are useful rollout tools.
   - They are often probabilistic, relative, sampled over time, affected by low-volume variance, or overridden by stickiness, locality, connection reuse, or client behavior.
   - Steward should expose `weight`, `residual_weight`, `allocation_kind`, and `sample_caveat` when known instead of promising that exactly this request will follow the displayed percentage.

5. **Sticky, pinned, and affinity paths are first-class caveats**
   - A session-affinity cookie, source-IP affinity, tagged revision URL, direct test URL, durable client connection, or explicit pin can make one caller see a different target from the generic traffic split.
   - A traffic-binding witness should therefore say whether the binding is `ordinary`, `sticky`, `pinned`, `tagged`, `direct-test`, `connection-bound`, or `unknown-affinity` when that fact matters.
   - This keeps route explanation honest without requiring Steward to implement or standardize affinity itself.

6. **Mirrors and shadows are not serving success**
   - Mirrored or shadow traffic can copy real demand to a secondary target while ignoring the mirror response and keeping the primary path authoritative.
   - That is valuable for experiments, but it is not proof that the mirrored target served users, accepted custody, avoided side effects, or is safe for promotion.
   - Steward should distinguish `primary`, `mirror`, `shadow`, `tap`, and `observation-only` binding roles.

7. **Drain and deregistration are about new work versus existing work**
   - Removing a target from new traffic can coexist with in-flight requests, existing streams, sticky clients, connection-drain timers, or passive pool drain.
   - A binding should expose `no-new-work`, `draining-existing`, `deregistration-delay`, `connection-bound`, `unused-after-drain`, or `drain-unknown` rather than flattening everything into `off`.
   - This is adjacent to serve-state, custody, and work disposition, but not identical to any of them.

8. **Service abstraction is not endpoint certainty**
   - A service or route can target a logical backend set whose actual endpoints change underneath it.
   - Selectors, EndpointSlices, target groups, proxy clusters, and serverless revision pools may change membership without the surface name changing.
   - Steward should preserve backend-set identity and membership-generation hints when available, but not pretend that the route binding proves exact endpoint liveness.

9. **Topology and locality preferences are weaker than hard placement**
   - Same-zone, same-node, locality, least-request, weighted-random, and automatic target-weight behaviors can influence routing without granting a hard guarantee.
   - A useful binding can say `preference`, `strict-policy`, `fallback-possible`, `fallback-active`, or `default-routing` without turning topology hints into placement authority.
   - This is especially important when SlopOS later spans local components, remote cells, and host/guest membranes.

10. **DNS and client-side routing need propagation humility**
    - DNS failover, alias answers, cached clients, sticky SDKs, and long-lived connections can preserve old paths after an intended route change.
    - If a route binding is DNS-backed or client-side, Steward should prefer `ttl-bound`, `client-cache-possible`, `last-known`, `insufficient-data`, or `propagation-unknown` over claiming instantaneous global truth.
    - A control-plane update is not the same as every caller's next connection path.

11. **Rollback pointers are not rollback completion**
    - A route may point some or all new traffic back to an older revision before the new revision is stopped, before sticky clients clear, before mirrors stop, or before in-flight work finishes.
    - Steward should keep `rollback-route-selected`, `rollback-route-applying`, `rollback-route-active`, `rollback-route-partial`, and `rollback-route-unknown` separate from revision settlement and work fate.
    - This keeps rollback explanation useful without importing a rollback engine.

12. **Traffic binding can feed admission, but it is not admission**
    - A demand surface may bind a caller to a target set, then admission can still deny, shed, throttle, defer, or narrow the individual attempt.
    - Conversely, admission can allow a wake while no ordinary user route points at the target yet, such as test-tag, shadow, or direct admin activation.
    - Binding witnesses and admission receipts should cross-reference each other rather than collapse into one status bit.

13. **Binding freshness should have a generation and vantage**
    - Useful evidence includes `desired_binding_revision`, `observed_binding_revision`, `applied_generation`, `data_plane_as_of`, `membership_generation`, `last_transition`, `expires_or_recheck_by`, `source_vantage`, and `staleness_reason`.
    - If Steward cannot prove freshness, it should say `last-known binding` or `binding freshness unknown`.
    - This matches the broader Steward rule that status, verdicts, probes, and route observations all decay.

14. **Phase 1 shape is a binding witness, not a route API**
    - A tentative `activation_traffic_binding` witness can stay tiny: `traffic_surface_ref`, `binding_issuer`, optional `route_ref`, optional `service_ref`, optional `alias_ref`, optional `component_id`, optional `revision_ref`, optional `incarnation_id`, `binding_state`, optional `binding_role`, optional `allocation_kind`, optional `weights_or_targets_summary`, optional `affinity_caveat`, optional `drain_state`, optional `desired_binding_revision`, optional `observed_binding_revision`, optional `data_plane_as_of`, optional `basis_refs`, optional `staleness_reason`, and optional `unknown_reason`.
    - Field names remain provisional until real Steward components show which route-binding facts must cross membranes.

## Executable packet settlement
`ST-TBIND v0` is the first executable settlement for this posture. It deliberately proves less than the full posture: closed decode, canonical digest, required non-implications, target-summary bounds, endpoint redaction, freshness downgrade, weighted-target sanity, and route-drain-as-not-live-channel-fate. It is not a final routing API.

The deterministic corpus in `../40-verification/channel-binding-corpus-v0.md` is the current promotion gate: new traffic-binding language should either preserve those cases or add a new accept/reject case before becoming stronger posture.

## Phase-1 non-goals
- a portable load balancer, service mesh, DNS failover system, Gateway API implementation, route compiler, canary controller, rollout planner, target-group manager, topology router, session-affinity framework, or traffic simulator;
- promising deterministic per-request routing from weights, percentages, locality hints, or control-plane config;
- treating route binding as proof of readiness, health, serve-state, admission, custody, work completion, external effect success, or incident truth;
- treating data-plane route propagation as instantaneous or globally observable;
- flattening primary traffic, mirrored traffic, tagged test URLs, sticky sessions, direct admin paths, DNS answers, and draining connection pools into one `routed` bit.

## Adjacent docs
- `activation-control-verdict-posture-v0.md`
- `activation-probe-vantage-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `presence-advertisement-posture-v0.md`
- `activation-endpoint-witness-posture-v0.md`
- `activation-demand-episode-posture-v0.md`
- `activation-admission-posture-v0.md`
- `activation-custody-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `activation-incarnation-lineage-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-SERVICE
- REF-K8S-GATEWAY-TRAFFIC-SPLITTING
- REF-K8S-GATEWAY-REQUEST-MIRRORING
- REF-K8S-TOPOLOGY-AWARE-ROUTING
- REF-CLOUD-RUN-TRAFFIC-MIGRATION
- REF-AWS-LAMBDA-WEIGHTED-ALIASES
- REF-AWS-ALB-TARGET-GROUP-ATTRIBUTES
- REF-ENVOY-TRAFFIC-SPLITTING
- REF-ENVOY-DRAINING
- REF-ISTIO-TRAFFIC-SHIFTING
- REF-ISTIO-MIRRORING
