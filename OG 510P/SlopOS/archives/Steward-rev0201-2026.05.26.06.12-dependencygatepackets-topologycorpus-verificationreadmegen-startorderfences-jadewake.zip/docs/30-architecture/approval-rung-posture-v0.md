# Approval-rung posture v0

Purpose: define a **tiny approval-rung seam** so proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion stay visibly different powers instead of collapsing into one ambient automation mood.

## Posture
1. **Autonomy should climb visible rungs, not dissolve into one “smart terminal” mood**
   - A helpful terminal may range from proposal-only help, to reviewed one-shot execution, to scoped auto-approval, to stronger run-until-completion behavior.
   - Steward should keep those as named stronger moves instead of one flattering `assistant is enabled` bit.
2. **Proposal is not approval, and approval is not autonomy**
   - A proposal card may suggest commands without any standing right to execute them.
   - Approving one tool call or one command does not automatically grant ongoing retry, clarification, or follow-on execution rights.
3. **Higher rungs should stay lane-scoped and easy to revoke**
   - Any widening from `ask` to `allow this lane`, `allow this task`, or `run until completion` should stay attached to one exact proposal lane, session, pane, or reviewed task.
   - Steward should resist global hidden YOLO switches that outlive the moment and surface that earned them.
4. **Policy floors must outrank convenience rungs**
   - Some commands, tools, transports, or effect classes may always require approval or remain entirely disallowed regardless of user-selected convenience.
   - Steward should keep policy floors explicit instead of pretending the highest autonomy rung trumps every other bound.
5. **Run-until-completion is a distinct stronger rung**
   - Continuous iteration, auto-retry, and auto-answer behavior are stronger powers than merely auto-approving one command class.
   - Steward should name that rung separately and make entering it loud, temporary, and stoppable.
6. **Higher autonomy should pair with better containment and better audit**
   - As autonomy rises, the system should prefer narrower work roots, clearer receipts, replay-safe exact anchors, and stronger containment such as sandboxes, worktrees, or disposable panes when available.
   - That is healthier than widening authority in place while keeping the same vague shell footing.
7. **Resume and reconnect should degrade autonomy honestly**
   - If a lane reconnects, the terminal restarts, the runtime changes, or the reviewed basis drifts, Steward should be willing to fall back from stronger rungs to witness or ask-again states.
   - Silent carryover of a higher rung across stale footing would recreate ambient folklore.
8. **The transcript should remember which rung was in force**
   - Later explanation should be able to say whether a command was proposed only, approved once, session-auto-approved, or executed under run-until-completion.
   - Steward should not force users to reconstruct autonomy from vibes or remembered UI state.
9. **One compact rung seam beats many scattered approval loopholes**
   - Proposal lanes, helper CLIs, terminal agents, notebook command cards, and exact action surfaces all want the same anti-folklore discipline.
   - Steward should prefer one small approval-rung seam over ad hoc permission toggles attached to every product-shaped surface.

## Phase-1 non-goals
- a universal cross-session trust cache or approval-wallet family;
- a final portable auto-approve matrix for every tool, transport, and effect kind;
- silently carrying high-autonomy state across reconnect, restore, or retarget;
- allowing proposal/history search selection to imply a stronger approval rung;
- a giant policy language for every approval edge before SlopOS itself settles.

## Adjacent docs
- `proposal-lane-posture-v0.md`
- `assist-surface-posture-v0.md`
- `automation-surface-posture-v0.md`
- `fresh-intent-posture-v0.md`
- `session-injection-posture-v0.md`
- `history-lane-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `precision-fence-posture-v0.md`
- `replay-gate-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-VSCODE-UPDATE-1111
- REF-VSCODE-AGENT-TOOLS
- REF-VSCODE-AI-SETTINGS
- REF-WARP-AGENT-PROFILES
- REF-WARP-FULL-TERMINAL-USE

## Revision 190 packet pressure

Approval rungs now have a machine-checkable lifecycle neighbor. `ST-REVIEW v0` can record proposal or preflight review, `ST-APPROVAL v0` can record exact operation-digest approval, and `ST-AUTHCHECK v0` can record whether the lifecycle gate is currently allowed. None of these packets executes the operation or proves a component-state change.
