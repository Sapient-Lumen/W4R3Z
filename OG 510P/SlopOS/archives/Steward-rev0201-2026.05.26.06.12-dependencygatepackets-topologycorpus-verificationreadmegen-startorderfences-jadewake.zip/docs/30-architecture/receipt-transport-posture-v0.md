# Receipt transport posture v0

## Purpose
Steward now has enough lifecycle packets that evidence transport is itself a failure surface. This posture names the line between durable evidence and authority: a receipt may be chained, minimized, exported, replayed, and checked without becoming permission, present-tense state, freshness, work completion, or effect success.

## Objects
- `ST-RECEIPTCHAIN v0` records digest-linked receipt chain checkpoints.
- `ST-REDACTION v0` records minimized projection commitments.
- `ST-EXPORTBUNDLE v0` records exported evidence manifests.
- `ST-REPLAYOBS v0` records replay/import verification observations.

## Rules
1. Receipt chains carry receipt digests and chain heads, not raw packet bodies or bearer material.
2. A chain head proves only a digest path that Steward checked, not a complete global history.
3. Redaction commits to what was retained and which classes were stripped, but it is not full-fidelity source truth.
4. Export bundles require a redaction witness and sorted included receipt digests.
5. Export bundles are evidence handoffs, not authority grants or live-state snapshots.
6. Replay observations verify an exported bundle digest and included receipt digests; they do not reacquire freshness, authority, or current lifecycle state.
7. Partial replay is allowed only when the gap is explicit and downgraded.
8. Any packet or event that claims authority, freshness, effect success, readiness, serving, custody, or complete history from export/replay alone is malformed.

## Boundary with siblings
Ward may own durable stewardship authority and organizational policy. Schell or Helm may render witness cards. ViewFS may store packages or snapshots. Steward owns only the lifecycle receipt transport witness needed to avoid lying during handoff, release evidence export, manager recovery import, or sibling review.

## Executable settlement
The rules above are checked by [`../40-verification/receipt-transport-corpus-v0.md`](../40-verification/receipt-transport-corpus-v0.md).
