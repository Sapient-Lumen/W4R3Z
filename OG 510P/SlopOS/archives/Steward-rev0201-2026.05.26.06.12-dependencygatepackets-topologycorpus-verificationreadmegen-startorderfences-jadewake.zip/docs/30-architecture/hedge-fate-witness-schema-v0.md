# Hedge-fate witness schema v0

## Purpose
`ST-HEDGEFATE v0` is the first closed packet for one hedge group settlement: which speculative attempts existed, whether one response was accepted, and what is known or still ambiguous about the losing attempts.

The central rule: **a hedge winner is not effect success, no-side-effect proof, no-duplicate proof, exactly-once behavior, readiness, custody, or work completion.**

## Machine profile
- Machine profile: `../../schemas/st-hedgefate-v0.schema.json`
- Checker: `../../tools/steward_retry_settlement_harness.py`
- Corpus: `../40-verification/corpora/retry-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-HEDGEFATE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | client, proxy, library, mesh, runtime, or observer that reports the hedge fate |
| `hedge_group_ref` | canonical hedge group id |
| `group_state` | `speculative`, `winner_known`, `all_failed`, `canceled`, `abandoned`, or `unknown` |
| `canonical_intent_digest` | digest shared by the hedged attempts |
| `settlement_state` | no-winner, winner-response-accepted, all-resolved, loser-cleanup-pending, duplicate-possible, or unknown |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the hedge settlement |
| `attempt_refs` | attempt ids in the hedge group |
| `loser_fates` | per-losing-attempt fate records |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `winner_attempt_ref`, `accepted_response_ref`, `effect_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

Each loser fate names an attempt, a fate (`canceled`, `reset`, `ignored_after_winner`, `completed_late`, `still_in_flight`, `duplicate_effect_possible`, or `unknown`), and duplicate risk.

## Non-implication vocabulary
A valid hedge-fate witness must include:

- `not-effect-success`
- `not-no-side-effect`
- `not-exactly-once`
- `not-route-authority`
- `not-readiness`
- `not-work-completion`
- `not-custody`

## Hedge rules
`winner_known` requires both `winner_attempt_ref` and `accepted_response_ref`. The winner cannot also appear in `loser_fates`, and every non-winning attempt needs a loser fate. Cancel, reset, and ignored-after-winner states cannot prove `duplicate_risk = none` unless cleanup evidence is cited. `all_resolved` cannot hide in-flight, unknown, or duplicate-possible loser fates.

## Rejected surfaces
The corpus rejects:

- cancel/reset of a losing attempt promoted into no-side-effect proof;
- a winner also listed as a loser;
- all-resolved settlement with unknown or still-in-flight losers;
- hedge packets that claim effect success, exactly-once, readiness, route authority, custody, or work completion.

## Non-goals
- no hedge-racing subsystem, tail-latency policy engine, RPC framework, route controller, service mesh, or exactly-once effect plane;
- no standardization of transport-specific cancel/reset statuses as portable Steward proof.

## Adjacent docs
- `activation-retry-attempt-posture-v0.md`
- `retry-attempt-witness-schema-v0.md`
- `activation-live-channel-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `effect-key-posture-v0.md`
- `canonical-json-profile-v0.md`

## References
REF-GRPC-HEDGING; REF-GRPC-RETRY; REF-ENVOY-HTTP-ROUTING; REF-AWS-BUILDERS-IDEMPOTENT-APIS.
