# Observation gap witness schema v0

## Packet
`ST-OBSGAP v0` records one open, cleared, or unknown continuity gap for an observation subscription.

## Required meaning
The packet says the subscription ref, gap sequence interval, gap class, whether the gap is open or cleared, which verbs are blocked, which refreshes are required, and which evidence cleared the gap if cleared.

## Required non-implications
Every gap witness must explicitly refuse:

- `not-authority`
- `not-current-state`
- `not-readiness`
- `not-serving`
- `not-execution`
- `not-effect-success`
- `not-lossless`

## Canonicalization
The machine profile is [`../../schemas/st-obsgap-v0.schema.json`](../../schemas/st-obsgap-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
An open gap blocks risky lifecycle verbs until the view is refreshed or resynced. A cleared gap must name clearing evidence. Neither open nor cleared gaps prove that no lifecycle events were missed globally, and neither proves work drain, quiescence, or effect success.
