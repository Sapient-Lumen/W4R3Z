# Observation appraisal witness schema v0

## Packet
`ST-OBSAPPRAISE v0` records Steward's appraisal of one `ST-LOCALOBS v0` packet for limited lifecycle use.

## Required meaning
The packet says whether one observation may be used as weak evidence, must remain quarantined, should be rejected, has expired, or is unknown. It names the source class, source scope, confidence class, allowed weak uses, caveats, and expiry.

Allowed use classes are intentionally narrow: history, audit, explanation, operator review, recovery hint, recheck request, and weak basis. Current lifecycle state, readiness, serving, policy, global trust, authority, and execution are not valid uses.

## Required non-implications
Every packet must explicitly refuse:
- `not-global-trust`
- `not-authority`
- `not-current-state`
- `not-policy`
- `not-execution`
- `not-readiness`
- `not-serving`

## Canonicalization
The machine profile is [`../../schemas/st-obsappraise-v0.schema.json`](../../schemas/st-obsappraise-v0.schema.json). Active weak-evidence appraisals must expire after observation time, and quarantined, rejected, or expired appraisals cannot permit weak-basis use.

## Steward boundary
Ward owns global trust and delegation semantics. Steward appraises only whether a local observation may help explain or recheck lifecycle state.
