# Observation-subscription posture v0

Purpose: define a narrow, explicitly observational **subscription stream** so terminals, UIs, and tools can follow Steward state changes without polling, screen scraping, or accidentally creating a hidden control bus.

## Posture
1. **Subscriptions are observational, not mutating**
   - The subscription surface exists to report status / lifecycle changes, command-frame-adjacent observations, and recent receipt-like facts.
   - It must not become an ambient mutation channel.
2. **A subscription targets explicit objects or views**
   - Subscriptions should bind to a concrete component id, explicit watch set, or explicit view such as compact status, recent lifecycle observations, or command-frame observations.
   - Avoid “watch whatever this pane probably means right now.”
3. **Snapshot plus change notices is a promising default shape**
   - A subscriber often needs an initial bounded snapshot plus later change notices.
   - This is usually safer than making clients reconstruct truth only from a stream of deltas.
   - When a transport supports it, Steward should leave room for one exact `current state first` watch flow where synthetic current-state entries are followed by a synced-through marker and then ordinary later changes.
4. **The stream should stay compact and coalescible**
   - Status-like observations should be allowed to coalesce.
   - A subscriber that falls behind should receive an explicit overflow / resync signal instead of forcing Steward to buffer an unbounded event log.
5. **Subscriptions should reduce polling, not replace explicit reads**
   - A subscription is a hint that something changed.
   - Authoritative inspection should still be available via explicit reads of status, receipts, or transcript slices.
6. **Per-run identity should be allowed in change notices**
   - When relevant, a change notice may carry runtime-cycle witness and compact termination-cause information.
   - That helps terminals and UIs avoid stale actions without rebuilding a giant process API.
7. **Snapshot and stream continuity may carry one exact observation cursor**
   - A snapshot, bookmark-like progress marker, or later change notice may carry one opaque cursor that says what point the client is synced through for that exact view.
   - Clients should be allowed to resume from a prior cursor or receive an explicit continuity-lost explanation when that is no longer possible.
   - A synced-through marker after a bootstrap watch should count as honest currentness for that exact view, not as proof of global quiescence.
8. **Keep the portable envelope tiny at first**
   - A useful phase-1 envelope likely needs only:
     - watched target / view id,
     - change kind,
     - optional compact payload,
     - optional runtime-cycle witness,
     - optional observation cursor,
     - optional dropped / resync-needed / cursor-invalid indicator.
   - Avoid freezing a final full event schema too early.
9. **Backpressure and fairness matter**
   - A slow subscriber must not force unbounded buffering or make one chatty target starve everything else.
   - Coalescing, pause/resume, and resync are better than pretending every consumer can keep up forever.
10. **Subscriptions should survive simple transports**
   - A text-friendly stream that survives SSH-like hops and multiplexers is more valuable than a rich local-only API.
   - Reconnect paths should be allowed to present one last-known observation cursor and receive either resumed continuity or an explicit refresh-required explanation.
   - Steward should prefer transports that degrade honestly across local/remote boundaries.
11. **Versioning and explicit interface description are worth planning early**
   - If Steward grows a formal subscription API, it should have an explicit interface description and version story.
   - Do not rely on folklore clients parsing undocumented change strings forever.


## Executable settlement
The phase-1 subscription envelope is now pinned by four closed witness profiles:

- `ST-OBSSUB v0` for accepted bounded subscriptions;
- `ST-OBSDELIV v0` for delivered, coalesced, dropped, heartbeat, or resync-required batches;
- `ST-OBSSYNC v0` for exact-view snapshot and synced-through markers;
- `ST-OBSGAP v0` for open or cleared continuity gaps.

The corpus rejects ambient `current` subjects, wildcard event classes, delivery-before-subscription, delivery-as-currentness, synced-through-over-open-gap, and gap-as-lossless flattery.

## Phase-1 non-goals
- a universal event bus for every runtime and host detail;
- an always-on firehose of logs or traces;
- requiring lossless delivery of every change forever;
- a hidden mutation/control channel piggybacking on observation transport;
- forcing a single transport or serialization choice before real pressure exists.

## Adjacent docs
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `currentness-class-posture-v0.md`
- `termination-cause-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `provisional-state-posture-v0.md`
- `action-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-TMUX-CONTROL-MODE
- REF-TMUX-CHANGES
- REF-DBUS-API-DESIGN
- REF-KITTY-PROTOCOL-EXTENSIONS
- REF-K8S-API-CONCEPTS
