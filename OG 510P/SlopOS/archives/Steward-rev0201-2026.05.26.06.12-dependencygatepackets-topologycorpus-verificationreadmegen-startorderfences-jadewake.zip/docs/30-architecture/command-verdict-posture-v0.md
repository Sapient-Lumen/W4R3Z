# Command-verdict posture v0

Purpose: define a **tiny exact command-verdict seam** so Steward can treat “how this exact command finished” as one bounded shell-visible truth for decorations, watch resolution, last-failure selection, and quick follow-ons without confusing verdict, raw output, and lifecycle authority.

## Posture
1. **A command verdict binds to one stronger owning interaction**
   - The healthiest owner is one exact command frame, command-evidence object, output-slice owner frame, or another reviewed shell anchor.
   - Steward should resist folklore like “whatever the last nonzero-looking line said probably means failure”.
2. **Verdict, termination cause, and evidence are different truths**
   - A verdict is the compact shell-facing answer to “how did that command finish?”
   - A termination cause is the lower-level end reason when known (`clean exit`, `signal`, `timeout`, `policy kill`, `unknown`, and so on).
   - Command evidence is the bounded package of command text, output, timings, refs, and provenance that may later be attached or shared.
   - Steward should preserve those distinctions instead of forcing every shell affordance to choose between a full evidence bundle and raw transcript guesswork.
3. **Exact shell metadata should outrank bells, title churn, and text scraping**
   - When shell integration or exact frame metadata can report command start/finish plus exit code or finish status, decorations, summary chips, and failure-selection flows should bind to that exact footing.
   - BELs, prompt repaint, visible-text regexes, or parse-lens hints are useful fallbacks, but they must stay visibly weaker.
4. **The public verdict vocabulary should stay small and honest**
   - Phase 1 likely needs no more than compact states such as `running`, `succeeded`, `failed`, `interrupted`, `unknown`, `stale`, or `no-verdict` where the footing can prove them.
   - Exit code, termination-cause ref, duration, and exact output links may ride alongside that small verdict instead of exploding into a giant shell-result taxonomy.
5. **A verdict is observational, not replay or control authority**
   - A verdict may justify decorations, reveal, attach-last-failure defaults, or command-finished explainers.
   - It must not silently become permission to rerun, restart, stop, or mutate lifecycle state merely because the result was exact.
6. **Failure picking should prefer exact verdicts over transcript archaeology**
   - `Attach last failure`, `show me the last failed command`, or failure-tinted rails should prefer one exact failed verdict bound to one exact frame.
   - Steward should avoid inferring failure from nearby red text, shell prompt fragments, or exit-code-looking prose when a stronger exact verdict exists.
7. **Verdicts should compose with chrome and watches without becoming chrome truth**
   - Command decorations, sticky headers, watch cards, overview-ruler marks, output selection menus, and failure badges all want the same tiny verdict seam.
   - The chrome may summarize the verdict, but the canonical truth should remain the anchor-bound verdict object rather than whichever badge happened to be visible.
8. **Verdicts should admit downgrade and expiry honestly**
   - Hop loss, shell restart, prompt/frame replacement, transcript truncation, or capability downgrade may leave an old verdict known-but-no-longer-exactly-bound to the current surface.
   - Steward should be allowed to say `failed (exact)`, `failed (parsed candidate)`, `verdict stale`, or `finish unknown after hop` instead of preserving flattering certainty.
9. **Keep the phase-1 contract tiny**
   - Phase 1 likely needs only: owning command/frame anchor, compact verdict kind, optional exit code, optional termination-cause ref, optional timing summary, provenance/confidence, and visible stale/downgraded truth.
   - Avoid freezing a universal shell-result ontology, durable command-grade history service, or cross-tool verdict bus before repeated operating pressure proves it is worth standardizing.

## Phase-1 non-goals
- a universal mapping of every shell, signal, exit code, and tool-specific failure mode into one giant taxonomy;
- using command verdicts as lifecycle authority or replay permission;
- inferring high-confidence failure from visible text when stronger exact verdicts are absent;
- turning command verdicts into a durable issue tracker, workflow engine, or ambient notification system;
- freezing a host-wide result/decoration policy grammar before the archive truly earns it.

## Adjacent docs
- `command-frame-posture-v0.md`
- `termination-cause-posture-v0.md`
- `output-slice-posture-v0.md`
- `command-evidence-posture-v0.md`
- `attention-hint-posture-v0.md`
- `attention-watch-posture-v0.md`
- `notification-surface-posture-v0.md`
- `transcript-landmark-posture-v0.md`
- `command-guide-posture-v0.md`
- `precision-fence-posture-v0.md`
- `parse-lens-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1109
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-ITERM2-SHELL-INTEGRATION
- REF-WEZTERM-SEMANTIC-ZONES
- REF-GHOSTTY-RELEASE-130
