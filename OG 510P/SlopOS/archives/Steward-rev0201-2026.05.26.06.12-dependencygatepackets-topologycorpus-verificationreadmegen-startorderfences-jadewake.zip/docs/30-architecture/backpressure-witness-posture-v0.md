# Backpressure-witness posture v0

Purpose: define a **tiny backpressure-witness seam** so `queued`, `retry-after`, `shed`, `stop-accepting`, or similar admission-throttle truth can stay visibly separate from **pressure**, **headroom**, **approval**, and mere process liveness.

This seam stays intentionally small. It does **not** invent a universal fair-queuing service, traffic-management plane, retry-policy engine, or overload-control DSL. It only says that when a substrate can honestly report how it is pacing, queueing, or refusing *new work right now*, Steward should preserve that truth instead of flattening everything into vague `busy`, `slow`, or `temporarily unavailable` folklore.

## Posture
1. **Backpressure is admission truth, not authority truth**
   - A target may be fully allowed and healthy enough to exist, yet still queue, defer, or reject fresh work because it is protecting itself or its peers.
   - Steward should keep that separate from permission, readiness, and operator intent.
2. **Backpressure is not the same thing as resource pressure**
   - Pressure describes resource strain or stall; backpressure describes what the system is doing about fresh demand.
   - Either may exist without the other, so Steward should keep them distinct.
3. **Queueing, shedding, and retry-later are different truths**
   - Some systems queue briefly, some stop accepting new work, some shed at specific lifecycle junctions, and some explicitly ask the caller to retry later.
   - Steward should preserve those differences instead of one vague `throttled` badge when the adapter can prove more.
4. **Fairness or class isolation matters when the substrate can name it**
   - A backpressure witness may be scoped to a priority class, request lane, listener, or exact service subject rather than a whole component.
   - Steward should preserve that scope instead of pretending every caller is being treated the same way.
5. **Retry advice is a hint, not a durable lease**
   - `retry after 250ms`, `pushback: do not retry`, or similar advice explains the current lane policy.
   - It should not silently become a promise, reservation, or approval to act later under changed conditions.
6. **Backpressure may be graceful rather than binary**
   - Brief queueing, keepalive drain, shrinking timeouts, or selective load shed can be healthier than hard refusal.
   - Steward should keep those intermediate adaptation moves visible instead of forcing every overload response to look like failure.
7. **Shell and terminal chrome should make backpressure legible**
   - Execution-ground cards, command frames, and receipts may show compact truth such as `queued`, `retry after 1.2s`, `shed at accept`, `pushback: no retry`, or `class: low-priority queue`.
   - These labels explain present admission posture; they do not become a portable traffic-control plane.
8. **Unknown is healthier than fake precision**
   - Some adapters can prove exact queue class or retry delay; others may only know `backpressure present` or `temporarily refusing new work`.
   - Steward should preserve that honesty.
9. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `backpressure_state`, exact scope label, and whichever of `retry_after_ms`, `queue_class`, `reason`, or `source_class` the adapter can really prove.
   - Richer fair-queuing, weighted admission, and cross-runtime retry choreography remain intentionally undecided.

## Phase-1 non-goals
- a universal queue-management or fair-queuing service;
- a portable RateLimit-header or retry-budget family;
- automatic client retry orchestration or hedging policy encoded into the witness itself;
- a portable overload-controller or traffic-shaping plane;
- pretending queueing, shedding, retry advice, and permanent denial are the same truth.

## Adjacent docs
- `pressure-witness-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `retry-advice-posture-v0.md`
- `execution-ground-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-APF
- REF-ENVOY-OVERLOAD-MANAGER
- REF-GRPC-STATUS-CODES
- REF-GRPC-RETRY
- REF-RFC6585

## Executable settlement
Closed packet profiles and corpus checks now live in `pressure-admission-proof-posture-v0.md`, `pressure-witness-schema-v0.md`, `headroom-witness-schema-v0.md`, `backpressure-witness-schema-v0.md`, `admission-gate-witness-schema-v0.md`, and `../40-verification/pressure-admission-corpus-v0.md`.
