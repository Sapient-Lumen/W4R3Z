# Material-freshness witness schema v0

## Purpose
`ST-MATFRESH v0` is the first closed packet for one Steward material-freshness witness. It reports version, scope, lease, projection, expiry, revocation, reload-pending, reacquire-required, stale, or unknown truth for config, secrets, tokens, trust bundles, certificates, dynamic identity, projected files, environment material, or snapshot-restored material without becoming a vault or credential plane.

The central rule: **fresh material evidence is not proof that the component consumed it, reloaded it, holds current authority, is ready, is serving, or succeeded at an effect.**

## Machine profile
- Machine profile: `../../schemas/st-matfresh-v0.schema.json`
- Checker: `../../tools/steward_currentness_control_harness.py`
- Corpus: `../40-verification/corpora/currentness-control-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-MATFRESH v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the material observer or provider |
| `material_ref` | stable ref for the material being described |
| `material_kind` | `config`, `secret`, `token`, `trust_bundle`, `lease`, `projected_file`, `env`, `dynamic_identity`, `certificate`, `snapshot_restored`, or `unknown` |
| `material_state` | `version_pinned`, `projected`, `static_for_incarnation`, `renewable`, `fresh`, `reload_pending`, `expired`, `revoked`, `reacquire_required`, `stale`, or `unknown` |
| `freshness_scope` | `activation`, `incarnation`, `revision`, `projection`, `lease`, `trust_bundle`, `identity`, `snapshot_restore`, `external`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `basis_refs` | bounded evidence refs supporting the witness |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `source_vantage`, `version_ref`, `audience_ref`, `attachment_ref`, `runtime_cycle`, `valid_after_ms`, `expires_at_ms`, `stale_after_ms`, `refresh_after_ms`, `reload_ref`, `rotation_ref`, `revocation_ref`, `authority_digest`, and `unknown_reason`.

## Required non-implications
A valid packet must include:

- `not-readiness`
- `not-serving`
- `not-attachment`
- `not-material-use`
- `not-reload-success`
- `not-current-authority`
- `not-effect-success`

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Raw token, secret, bearer, path, handle, descriptor, host, or process fields reject.
- `fresh`, `renewable`, `projected`, and `version_pinned` material cannot already be expired.
- `expired` material needs `expires_at_ms` and the expiry cannot be in the future.
- `revoked` material needs `revocation_ref`.
- `reload_pending` material needs `reload_ref`.
- `expired`, `revoked`, `reacquire_required`, `stale`, and `unknown` states require `unknown_reason`.

## Rejected surfaces
The corpus rejects:

- raw secret leakage;
- current material with past expiry;
- revocation without downgrade reason;
- missing non-implications;
- duplicate JSON keys;
- flow-level promotion from freshness to reload success or material use.

## Non-goals
- no vault, secret/config store, credential filesystem, workload-identity plane, trust-bundle distribution service, reload controller, secret rollout system, or credential renewal engine;
- no proof that a process consumed, reloaded, or safely used material;
- no inference from attachment, projection, latest labels, environment presence, or snapshot restore to current authority.

## Adjacent docs
- `activation-material-freshness-posture-v0.md`
- `state-attachment-witness-schema-v0.md`
- `activation-state-attachment-posture-v0.md`
- `probe-vantage-witness-schema-v0.md`
- `activation-probe-vantage-posture-v0.md`
- `receipt-minimization-posture-v0.md`
- `canonical-json-profile-v0.md`
