# Status channel proof posture v0

## Purpose
The status channel makes Steward followable by UIs, terminals, and tools without screen scraping or polling. It is also a risky compression point: a stream that looks live can be mistaken for live truth.

This posture pins the narrow executable rule for status-channel delivery: **subscriptions, deliveries, sync markers, and gap barriers are observation transport facts, not lifecycle facts.**

## Packet family
The executable packet family is:

- `ST-OBSSUB v0` — accepted bounded subscription to an explicit subject/view.
- `ST-OBSDELIV v0` — one delivered, coalesced, dropped, heartbeat, or resync-required batch.
- `ST-OBSSYNC v0` — exact-view sync marker, initial snapshot marker, partial-window marker, or resync-required marker.
- `ST-OBSGAP v0` — open or cleared stream gap that blocks risky actions until refresh.

## Rule
A status-channel packet may prove that an observation was accepted, delivered, dropped, synced through, or gap-fenced for one exact view. It must not prove readiness, serving, global currentness, mutation, authorization, operation execution, work drain, quiescence, effect success, or lossless continuity.

## Refactor note
Revision 195 made this seam executable while refactoring corpus execution. `make corpus` now calls a single registry runner, and both the runner and lint import `tools/harness_registry.py`. That avoids the previous two-place edit where a new harness had to be added once to Makefile and once to lint.

## Adjacent surfaces
- [`observation-subscription-posture-v0.md`](observation-subscription-posture-v0.md)
- [`status-channel-posture-v0.md`](status-channel-posture-v0.md)
- [`witness-surface-posture-v0.md`](witness-surface-posture-v0.md)
- [`observation-cursor-posture-v0.md`](observation-cursor-posture-v0.md)
