# Incarnation-lineage witness schema v0

## Purpose
`ST-INCARN v0` is the first closed packet for one Steward incarnation-lineage witness. It names how one concrete incarnation relates to predecessors, successors, replacements, clone/restore siblings, same-platform-object subcycles, retired runs, or ambiguous split-risk without letting a stable component name or runtime-cycle id decide currentness by itself.

The central rule: **incarnation lineage explains replacement and stale-action fences; it does not settle readiness, residency, custody, work fate, effect fate, or global order.**

## Machine profile
- Machine profile: `../../schemas/st-incarn-v0.schema.json`
- Checker: `../../tools/steward_lineage_resume_harness.py`
- Corpus: `../40-verification/corpora/lineage-resume-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-INCARN v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the lineage observer |
| `lineage_id` | scoped lineage id matching `lin_[a-z0-9]{16}` |
| `incarnation_id` | concrete incarnation id matching `inc_[a-z0-9]{16}` |
| `relation` | `current`, `predecessor_of`, `successor_of`, `replacement_for`, `same_platform_object_new_subcycle`, `clone_of`, `restore_of`, `split_risk`, `retired`, or `unknown` |
| `currentness` | `current`, `current_as_of`, `candidate`, `warming`, `serving`, `draining`, `retired`, `reaped`, `superseded`, `ambiguous`, `split_risk`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `basis_refs` | bounded evidence refs supporting the witness |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `runtime_cycle`, `predecessor_incarnation_id`, `successor_incarnation_id`, `handoff_ref`, `expected_fence_ref`, `observed_generation_ref`, `restore_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Required non-implications
A valid packet must include:

- `not-runtime-cycle-equality`
- `not-readiness`
- `not-serving`
- `not-residency`
- `not-custody`
- `not-work-fate`
- `not-effect-success`
- `not-global-order`

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Raw host object names, process ids, handles, paths, tokens, and secrets reject.
- `current`, `current_as_of`, `warming`, `serving`, and `draining` currentness require a `runtime_cycle` fence.
- `successor_of`, `replacement_for`, `same_platform_object_new_subcycle`, and `clone_of` require `predecessor_incarnation_id`.
- `predecessor_of` requires `successor_incarnation_id`.
- `restore_of` requires `restore_ref`.
- `ambiguous`, `split_risk`, and `unknown` currentness require `unknown_reason`.
- An incarnation cannot cite itself as its predecessor or successor.

## Rejected surfaces
The corpus rejects:

- self-predecessor lineage;
- current-ish incarnations without a runtime-cycle fence;
- missing non-implication lists;
- accepted operations targeting a stale incarnation;
- successor incarnation claims that settle predecessor work or effects.

## Non-goals
- no rollout controller, migration protocol, consensus term, leader-election service, checkpoint API, or global epoch sequencer;
- no automatic work discard, redrive, compensation, or effect settlement merely because a successor exists;
- no bearer authority hidden in lineage ids.

## Adjacent docs
- `activation-incarnation-lineage-posture-v0.md`
- `runtime-cycle-witness-schema-v0.md`
- `activation-residency-posture-v0.md`
- `residency-witness-schema-v0.md`
- `resume-reconciliation-witness-schema-v0.md`
- `fence-token-posture-v0.md`
- `canonical-json-profile-v0.md`
