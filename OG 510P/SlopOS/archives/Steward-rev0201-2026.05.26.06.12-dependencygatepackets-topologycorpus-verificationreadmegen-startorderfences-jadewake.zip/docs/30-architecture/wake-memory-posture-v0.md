# Wake-memory posture v0

Purpose: name the smallest useful lifecycle truth for future-wake, reminder, alarm, queued-trigger, and hibernated/inactive continuity evidence without turning Steward into a scheduler, actor runtime, or durable workflow engine.

## Posture
1. **Wake memory is not execution**
   - A timer, reminder, alarm, trigger, or queued reentry record may explain why a later lifecycle cycle is attempted.
   - It does not prove the component is running, ready, current, serving, or still entitled to act.
   - Any later cycle still needs normal activation, launch, readiness, and currentness truth.
2. **A reference or stub is not instantiation**
   - A stable handle to an addressable component-like object can exist while no runtime instance is active.
   - Steward should be able to say `addressable` or `wakeable` without flattering that into `running`.
3. **Active timers and durable reminders deserve different names**
   - An active timer that disappears with the runtime is a different fact from a durable reminder/alarm that can wake an inactive component later.
   - Phase 1 should preserve that distinction as descriptive truth, not as a public scheduling API.
4. **Hibernated or inactive continuity is weaker than running**
   - Some substrates can preserve storage, sockets, or protocol continuity while discarding in-memory runtime state.
   - Steward should not call that ready, running, or warm-resumed unless a concrete adapter proves those stronger facts.
5. **Queued triggers during stop are next-cycle evidence**
   - A trigger that arrives while a component is draining or stopping should be preserved as explicit next-cycle wake memory when policy allows it.
   - It should not smuggle new work into a half-dead runtime or silently reclassify the stop as still serving.
6. **Wake memory should carry owner, scope, and expiry**
   - A useful witness should name who armed it, what component/surface it can wake, the reason label, the freshness/expiry bound if known, and whether it is still active, fired, consumed, expired, lost, or unknown.
   - If the next wake time is exact, record it; if it is provider-local or approximate, say so.
7. **Firing, delivery, consumption, and retry are separate receipts**
   - `armed`, `fired`, `delivered to activation`, `consumed by run`, `retried`, and `gave up` are different lifecycle facts.
   - At-least-once delivery should be visible where a substrate exposes it; exactly-once should not be implied by default.
8. **Companion extensions are participants, not hidden lifecycle authority**
   - Extension/adjunct processes may observe or participate in init/invoke/shutdown-style events, but they should not become an untracked second supervisor.
   - Any helper or extension that materially affects activation or shutdown needs an attributable receipt.
9. **Durable execution history is a warning label**
   - Durable workflow/event-history systems show how powerful replayable lifecycle history can be.
   - Steward should steal bounded receipts and event-history humility, not become a general workflow runtime just to remember that a wake happened.
10. **Phase 1 shape is a witness, not an API family**
   - A tentative `wake_memory` witness can stay tiny: `kind`, `owner`, `scope`, `armed_at`, optional `next_wake_at`, `reason`, `state`, `delivery_strength`, `retry_hint`, and `freshness`.
   - All field names remain provisional until concrete Steward components and SlopOS surfaces force the vocabulary to settle.

## Phase-1 non-goals
- a generic scheduler, cron, alarm, or reminder DSL;
- a durable actor placement/runtime family;
- a hibernation VM, checkpoint/restore, or warm-resume contract;
- a universal sidecar/extension lifecycle model;
- a durable workflow engine or replay history plane;
- treating wake memory as proof of readiness, serving, liveness, currentness, or user attention;
- letting future-wake records bypass normal activation policy, restart budgets, stop/quiesce truth, or repair gates.

## Adjacent docs
- `activation-cause-posture-v0.md`
- `bootstrap-reconciliation-posture-v0.md`
- `dynamic-condition-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `attention-watch-posture-v0.md`
- `return-ticket-posture-v0.md`
- `enablement-intent-posture-v0.md`
- `restart-budget-posture-v0.md`
- `transition-helper-posture-v0.md`
- `control-operation-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-DAPR-ACTOR-TIMERS-REMINDERS
- REF-DAPR-ACTOR-RUNTIME-FEATURES
- REF-CLOUDFLARE-DURABLE-OBJECT-LIFECYCLE
- REF-CLOUDFLARE-DURABLE-OBJECT-ALARMS
- REF-AWS-LAMBDA-EXTENSIONS-API
- REF-AWS-LAMBDA-RUNTIME-LIFECYCLE
- REF-TEMPORAL-WORKFLOWS
- REF-TEMPORAL-EVENT-HISTORY
- REF-WINDOWS-SERVICE-TRIGGER-EVENTS
- REF-K8S-CONTAINER-LIFECYCLE-HOOKS
