# Status barrier witness schema v0

## Packet
`ST-STATUSBARRIER v0` records one visible stale/evidence barrier for a subject and surface.

## Required meaning
The packet says which verbs are blocked and which stale refs or refresh requirements caused the block.

## Required non-implications
Every barrier must explicitly refuse:

- `not-execution`
- `not-authorization`
- `not-current-state`
- `not-readiness`
- `not-serving`
- `not-effect-success`

## Canonicalization
The machine profile is [`../../schemas/st-statusbarrier-v0.schema.json`](../../schemas/st-statusbarrier-v0.schema.json). It uses the Steward closed canonical JSON profile: duplicate keys reject, unknown fields reject, floats reject, and digests are computed over canonical bytes.

## Refusals
A clear barrier blocks no verbs. A blocking, stale, or refresh-needed barrier must name at least one blocked verb and at least one stale ref or required refresh. The barrier blocks risky UI actions; it does not prove the current state by itself.
