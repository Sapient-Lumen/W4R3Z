# Activation-endpoint witness posture v0

Purpose: keep **manager-owned on-demand activation surfaces** separate from **current runtime liveness**, **current serving truth**, and **published presence** so Steward can say `armed`, `disarmed`, `deferred`, `rate-limited`, or `unknown` without cloning a socket manager, bus registry, or giant service-discovery plane.

This seam stays intentionally small. It answers one narrower question: **is there currently a reviewed manager-owned activation surface that can wake or reattach this component on demand, and what should that not be mistaken for?**

## Posture
1. **An armed activation surface is not the same as a running leaf**
   - A component may be completely absent as a running process while the system still owns a stable demand path that can wake it.
   - Steward should keep `armed on demand` separate from runtime-cycle identity and process existence.
2. **An armed activation surface is not the same as current serving truth**
   - A manager-owned listener, service name, queue predicate, or other activation endpoint may remain live even while the worker is cold, restarting, or draining.
   - Steward should therefore keep activation-endpoint truth separate from `serving`, `draining`, `maintenance`, or `not serving`.
3. **Endpoint identity should belong to the manager, not to daemon folklore**
   - Healthy demand activation keeps the public wake-up path system-owned and reviewable.
   - The component should receive named delivered startup material or listener handles instead of reconstructing public identity from ambient descriptor order, pidfiles, or wrapper scripts.
4. **Activation-endpoint truth should stay exact but small**
   - A useful phase-1 shape is no more than optional compact truth such as `armed`, `disarmed`, `deferred`, `rate-limited`, or `unknown`, plus an optional basis such as `socket`, `mach-service`, `queue predicate`, or `request name` when the adapter can prove it.
   - Steward should resist freezing a portable socket API, bus schema, or universal activation-registry family through this seam.
5. **Armed and triggered are different truths**
   - `Armed` means the manager-owned demand path is currently available.
   - `Triggered` or `started because of first request / socket demand / queue nonempty` belongs to activation-cause and runtime-cycle receipts, not to the durable endpoint witness itself.
6. **Deferred and flood-limited endpoint behavior should stay endpoint-local**
   - Some substrates can defer triggering while a conflicting stop/restart operation completes, or can protect the endpoint with trigger/poll limits before the service even starts.
   - Those are healthy local facts, but Phase 1 should surface them only as compact witness detail instead of freezing a giant portable flood-control grammar.
7. **Public endpoint continuity is different from runtime continuity**
   - The same manager-owned activation surface may survive worker crash, restart, upgrade, or replacement while concrete runtime cycles change underneath.
   - Steward should preserve that difference instead of teaching users that stable endpoint identity implies stable process identity.
8. **Unknown is healthier than fake precision**
   - Some runtimes can prove exact armed/disarmed/deferred state for their demand surface.
   - Others may only know that a component can be started manually or that on-demand activation exists in some weaker form. Steward should preserve that honesty.
9. **Phase 1 keeps the seam explanatory, not controlling**
   - A compact endpoint witness can make lifecycle cards and explainers far more truthful for cold-start-on-demand components.
   - It should not thereby become a generic load balancer, socket broker, or ambient name-service API.

## Phase-1 non-goals
- a portable listener/socket/bus/service-name API;
- promising every runtime can preserve queued demand while a worker is absent;
- standardizing one universal rate-limit or defer-trigger grammar;
- implying `armed` proves current readiness or steady serving;
- turning endpoint witness into broad discovery, routing, or traffic-policy control.

## Adjacent docs
- `activation-posture-v0.md`
- `activation-cause-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `request-activation-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `presence-advertisement-posture-v0.md`
- `continuity-escrow-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-SOCKET-ACTIVATION
- REF-SYSTEMD-SERVICE
- REF-LAUNCHD-SOCKETS
- REF-LAUNCH-ACTIVATE-SOCKET
