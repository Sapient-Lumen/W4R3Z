# Control-verdict witness schema v0

## Purpose
`ST-CTRLVERDICT v0` is the first closed packet for one Steward control-verdict witness. It reports a controller, balancer, rollout loop, DNS-health adapter, deployment circuit, repair gate, admission hint, or operator verdict with explicit issuer, subject, basis, freshness, and effect class without letting that verdict impersonate observation truth, readiness, serving, route authority, rollback completion, remediation success, incident truth, or effect success.

The central rule: **a verdict is a scoped decision witness, not the world.**

## Machine profile
- Machine profile: `../../schemas/st-ctrlverdict-v0.schema.json`
- Checker: `../../tools/steward_currentness_control_harness.py`
- Corpus: `../40-verification/corpora/currentness-control-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-CTRLVERDICT v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | Steward component id |
| `issuer` | closed issuer object naming the controller/operator/adapter |
| `verdict_kind` | `readiness_gate`, `rollout`, `traffic`, `rollback`, `dns_health`, `deployment_circuit`, `repair`, `admission_hint`, `operator`, or `unknown` |
| `subject_ref` | revision, component, route, gate, operation, repair, or adapter subject |
| `verdict_state` | `eligible`, `withheld`, `stalled`, `failed`, `passed`, `denied`, `deferred`, `rollback_selected`, `rollback_started`, `action_required`, `inconclusive`, or `unknown` |
| `effect_class` | `report_only`, `advisory`, `gates_new_work`, `gates_traffic`, `requests_operation`, `blocks_operation`, or `unknown` |
| `observed_at_ms` | monotonic observation time within the issuing clock domain |
| `basis_refs` | bounded evidence refs supporting the verdict |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `probe_refs`, `material_freshness_refs`, `traffic_binding_ref`, `operation_receipt_ref`, `action_ref`, `revision_ref`, `runtime_cycle`, `expires_or_recheck_by_ms`, `staleness_reason`, `unknown_reason`, and `manual_action_hint`.

## Required non-implications
A valid packet must include:

- `not-readiness`
- `not-serving`
- `not-route-authority`
- `not-rollback-completion`
- `not-remediation-success`
- `not-incident-truth`
- `not-effect-success`
- `not-raw-observation`

## Settlement rules
- Unknown fields reject.
- Duplicate JSON keys reject before semantic validation.
- Fields claiming route authority, rollback completion, remediation success, incident truth, or component state reject.
- `unknown` and `inconclusive` verdicts require `unknown_reason`.
- `stalled`, `failed`, and `action_required` verdicts require `manual_action_hint`.
- Operation-affecting verdicts require `operation_receipt_ref` or `action_ref`.
- `expires_or_recheck_by_ms` cannot precede `observed_at_ms`.

## Flow rules
The currentness/control corpus adds flow-level checks:

- a verdict may cite material and probe witnesses without becoming readiness or serving;
- a revoked material witness can produce a withheld traffic gate;
- an eligible traffic-gating verdict cannot be based on stale, expired, revoked, reacquire-required, or unknown material without downgrade;
- a verdict may cite a separate traffic-binding witness, but it does not become route authority.

## Rejected surfaces
The corpus rejects:

- verdict packets claiming route authority;
- verdict packets claiming remediation success;
- unknown verdicts without reasons;
- missing non-implications;
- duplicate JSON keys;
- flow-level promotion from verdict to active route truth.

## Non-goals
- no rollout controller, canary framework, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, repair engine, incident manager, or SLO system;
- no automatic restart, rollback, route withdrawal, quarantine, or incident closure from verdict alone;
- no inference from controller state to raw observation truth, readiness, serving, route binding, rollback completion, effect success, or remediation success.

## Adjacent docs
- `activation-control-verdict-posture-v0.md`
- `probe-vantage-witness-schema-v0.md`
- `activation-probe-vantage-posture-v0.md`
- `traffic-binding-witness-schema-v0.md`
- `control-operation-receipt-schema-v0.md`
- `readiness-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `canonical-json-profile-v0.md`
