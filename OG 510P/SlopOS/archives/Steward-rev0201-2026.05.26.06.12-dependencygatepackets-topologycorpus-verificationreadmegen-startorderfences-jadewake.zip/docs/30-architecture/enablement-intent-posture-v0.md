# Enablement-intent posture v0

Purpose: define a **tiny durable activation-intent seam** so `manual`, `auto`, `auto-delayed`, `disabled`, and stronger `start-prohibited` / `masked` truth stay visibly separate from current liveness, temporary hold state, activation cause, and restart folklore.

This seam is intentionally small. It does **not** freeze a boot-target graph, install/preset algebra, service-install language, or host-global scheduler. It only says Steward should be able to represent the durable operator or policy stance about **future activation admission** without laundering that stance into current runtime truth.

## Posture
1. **Durable activation intent is different from current runtime state**
   - A component may be allowed to auto-activate later while currently `offline`, `waiting`, `draining`, or not running at all.
   - A component may also be currently running while future automatic activation is disabled or narrowed.
   - Steward should not flatten these into one smiling `on/off` bit.

2. **Manual start allowance is different from automatic activation allowance**
   - Some resources are `manual only`: a reviewed explicit start may be allowed even when automatic activation is not.
   - Stronger states such as `disabled` or `start-prohibited` may reject both automatic and manual activation until a narrower policy change occurs.

3. **`enabled but not yet runnable` is an honest state**
   - Oracle SMF's `disabled` / `offline` / `online` distinction is a useful reminder that future-run policy and current satisfiability are different truths.
   - Steward should be able to say `enabled but blocked on conditions` or equivalent instead of laundering the situation into either `failed` or `off`.

4. **Delayed automatic activation is a distinct idea, but still a tiny seam**
   - Windows delayed auto-start is a helpful precedent: `auto later` is different from both `auto now` and `manual`.
   - Steward may eventually need a compact `auto-delayed` or `auto-deferred` mode, but should avoid freezing a giant boot choreography around it too early.

5. **Temporary holds remain a different seam**
   - `paused`, `draining`, `frozen`, `quiescing`, or `held until ...` truth belongs to current hold state, not durable activation intent.
   - A component can be `auto` and still be temporarily held, or `manual` and not held at all.

6. **Current action surfaces should explain the intersection, not collapse it**
   - Cards, rails, and explainers may need to answer both `what is the durable activation stance?` and `what live verbs are currently admitted right now?`.
   - Example compact truths: `manual only`, `auto`, `auto-delayed`, `disabled`, `start-prohibited`, `enabled but offline`, `running but future start disabled`.

7. **Phase 1 should keep the vocabulary tiny**
   - A reasonable early shape is only: activation-intent mode, optional stronger prohibition reason, optional delay/defer hint, and provenance/freshness.
   - Rich boot targets, preset inheritance, milestone ordering, or host-global install policy remain intentionally undecided.

## Explicit non-goals
- a full boot or milestone graph;
- unit-file install/preset semantics;
- a generic timer/scheduler family;
- host-global service-install or package policy;
- a promise that every adapter can distinguish all modes equally well.

## References
- REF-SYSTEMCTL
- REF-SMF-SERVICE-STATES
- REF-WINDOWS-CREATESERVICE
- REF-WINDOWS-DELAYED-AUTO-START
