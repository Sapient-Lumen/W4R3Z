# Stop-escalation posture v0

Purpose: define a **tiny stop-escalation seam** so Steward can say whether a stop stayed cooperative, entered bounded grace, cut through forcefully, or allowed escape — without turning shutdown into a giant signal grammar or host-specific kill API.

This seam is intentionally small. It does **not** design a full process-control protocol, distributed drain scheduler, or portable signal taxonomy. It only says Steward should be able to answer a narrower question honestly: **when a stop or restart was carried out, what path did it actually take, over what reviewed scope, and what should not be mistaken for successful graceful shutdown?**

## Posture
1. **Stop request, grace, and force-cutthrough are different truths**
   - Asking a component to stop cooperatively is not the same thing as waiting a bounded grace window.
   - Waiting a bounded grace window is not the same thing as forcefully terminating the reviewed workload after that window expires.
   - Steward should keep those stages separate instead of flattening them into one vague `stopped` story.

2. **Escalation scope should follow the reviewed execution group**
   - If a platform can stop or kill the reviewed workload as one execution group, adapters should use that exact scope.
   - Steward should resist folklore such as killing only the nominal main leaf and hoping descendants clean themselves up.

3. **Escape or abandonment must stay explicit if it exists at all**
   - Some substrates permit descendants or sibling processes to remain alive when the nominal job dies, or expose knobs that deliberately disable group cleanup.
   - If an adapter relies on that, Steward should treat it as a visible downgrade or policy choice, not as ordinary supervised-service behavior.

4. **Grace windows should be bounded and explainable**
   - A component may get a short cooperative stop window, possibly extended by state-specific policy such as timeout-failure mode or shutdown-critical treatment.
   - Steward should preserve the difference between `still within grace`, `grace expired`, and `cut through by stronger policy` when the adapter can prove it.

5. **Stop and restart may use different initial cut-through choices**
   - Some substrates distinguish the signal or mechanism used for an ordinary stop from the one used during restart, or allow immediate hard-cutthrough for pathological timeout cases.
   - Steward should leave room for that honesty without standardizing every host knob.

6. **Final cut-through may be diagnostic, not only destructive**
   - A stronger final signal or abort path can be useful for analysis, for example when a stuck service should dump core rather than disappear silently.
   - Steward should treat that as explicit policy detail, not as invisible implementation trivia.

7. **Phase 1 should keep the public truth compact**
   - A healthy early shape is optional compact witness such as `stop requested`, `grace active`, `force cut-through`, `group cleared`, `escape allowed`, or `unknown`, plus optional native detail when the adapter can prove it.
   - Steward should resist freezing a giant portable signal, timeout, and watchdog grammar through this seam.

8. **Unknown is healthier than fake graceful-stop certainty**
   - Some hosts can prove precise escalation steps and cleanup scope.
   - Others may know only that the reviewed run stopped or that a stronger kill was attempted. Steward should preserve that honesty.

## Explicit non-goals
- a portable signal-by-signal shutdown API;
- promising that every adapter can prove whether all descendants observed a graceful stop request;
- standardizing one universal timeout / cut-through ladder;
- normalizing child escape or detached descendants as a healthy default;
- turning stop receipts into a giant distributed orchestration controller.

## Adjacent docs
- `supervision-posture-v0.md`
- `execution-group-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `termination-cause-posture-v0.md`
- `exit-disposition-posture-v0.md`
- `quiesce-posture-v0.md`
- `restart-budget-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `state-explainer-posture-v0.md`

## References
- REF-SYSTEMD-KILL
- REF-SYSTEMD-SERVICE
- REF-LAUNCHD-SOCKETS
- REF-WINDOWS-JOB-OBJECTS
- REF-WINDOWS-TERMINATE-JOB-OBJECT
- REF-ANDROID-INIT-README
