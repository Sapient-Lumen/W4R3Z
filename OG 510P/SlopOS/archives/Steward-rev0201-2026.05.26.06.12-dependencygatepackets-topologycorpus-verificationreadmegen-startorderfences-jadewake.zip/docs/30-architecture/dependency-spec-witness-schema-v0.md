# Dependency spec witness schema v0

## Purpose
`ST-DEPSPEC v0` is the closed packet profile for one declared lifecycle dependency edge. It records that a subject has a scoped dependency relation without claiming topology authority, start order, readiness, serving, currentness, admission, work completion, or effect success.

## Required fields
- `schema`: constant `ST-DEPSPEC v0`.
- `witness_id`: packet witness id.
- `dependency_spec_id`: stable dependency spec id.
- `cid`: component identity for the Steward subject being explained.
- `subject_ref`: exact subject reference.
- `dependency_ref`: exact dependency reference.
- `edge_kind`: `requires`, `prefers`, `ordered_before`, `ordered_after`, `observes`, `uses`, `optional`, or `unknown`.
- `strength`: `hard`, `soft`, `advisory`, `disabled`, or `unknown`.
- `direction`: `outbound`, `inbound`, `bidirectional`, `local`, or `unknown`.
- `declared_by`: bounded policy/operator/steward source id.
- `applies_to_refs`: exact lifecycle operation, condition, or generation refs for which this declaration matters.
- `declared_at_ms`: monotonic declaration time.
- `supersedes_ref`: exact prior dependency spec id or `none`.
- `reason`: bounded explanation.
- `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.

## Required non-implications
`non_implications` must include `not-topology-authority`, `not-start-order`, `not-readiness`, `not-serving`, `not-currentness`, `not-failure`, `not-authorization`, `not-admission`, `not-work-completion`, and `not-effect-success`.

## Cross-field rules
- Disabled dependency declarations cannot remain hard required or ordering edges.
- Raw host identifiers, paths, endpoints, bearer material, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A dependency spec is not a topology graph, start-order plan, scheduler rule, authorization grant, readiness proof, serving proof, failure proof, demand acceptance, work completion, or effect settlement.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/dependency-gate-corpus-v0.jsonl`; the checker is `../../tools/steward_dependency_gate_harness.py`.
