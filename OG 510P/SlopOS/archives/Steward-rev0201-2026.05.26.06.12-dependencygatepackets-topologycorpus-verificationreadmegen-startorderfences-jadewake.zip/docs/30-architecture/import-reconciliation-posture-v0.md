# Import reconciliation posture v0

## Purpose
Imported evidence is useful after manager recovery, sibling-cube handoff, support export return, or audit replay. It is also dangerous because it is easy to mistake old, redacted, partial, or foreign evidence for present-tense Steward truth.

This posture keeps the import membrane explicit: import observation, source appraisal, reconciliation planning, and local reconciliation decision are four different witnesses.

## Packet set
- `ST-IMPORT v0` says an evidence bundle was observed, parsed, quarantined, rejected, or released only as weak evidence.
- `ST-SRCAPPRAISE v0` says one imported source has been appraised for limited weak uses.
- `ST-RECONPLAN v0` proposes how imported evidence may map to a local subject and what local witnesses are still required.
- `ST-RECONDECISION v0` records the local decision: history adoption, weak-basis attachment, rejection, local recheck, quarantine, or unknown.

## Design rules
1. Import is not authority.
2. Source appraisal is not global trust.
3. A reconciliation plan is not execution.
4. A reconciliation decision is not currentness, readiness, serving, or effect success.
5. Weak-basis attachment must name the local witnesses required before stronger lifecycle use.
6. Gapful imports stay quarantined or require local recheck.
7. Redaction commitments and sorted digest lists are part of the import boundary, not decoration.

## Steward boundary
Steward may appraise imported evidence only for local lifecycle explanation, history, recovery hints, audit, or operator review. Ward owns broader trust and delegation semantics. ViewFS owns durable storage location semantics. SlopOS owns native primitive truth. Steward must not launder any of these into an import packet.

## Refusals
Steward refuses to treat imported evidence as:
- live state;
- freshness;
- authority;
- global trust;
- an approval;
- an operation receipt;
- an effect boundary;
- current readiness or serving;
- permission to execute a lifecycle mutation.

## Verification
The import/reconciliation corpus is [`../40-verification/import-reconciliation-corpus-v0.md`](../40-verification/import-reconciliation-corpus-v0.md). It checks redaction gates, sorted digest binding, currentness flattery rejection, source-appraisal use limits, ready-plan local witness requirements, blocked-plan quarantine, and import-to-execution refusal.
