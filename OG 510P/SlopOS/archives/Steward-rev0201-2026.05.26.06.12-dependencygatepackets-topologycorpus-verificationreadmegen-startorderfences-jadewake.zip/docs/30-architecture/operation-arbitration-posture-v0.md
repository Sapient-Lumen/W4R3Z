# Operation-arbitration posture v0

Purpose: define a **tiny explicit operation-arbitration seam** so when a new lifecycle request arrives while other lifecycle work is already pending or in-flight, Steward can say whether the new request was **rejected**, **queued behind**, **replaced**, **flushed through**, or **made effectively irreversible** without confusing that arbitration with steady component state, one operation's final result, or a giant transaction planner.

This seam stays intentionally small. It does **not** invent a portable workflow engine, global transaction solver, or broad dependency override language. It only answers a narrower question honestly: **what happened when this lifecycle request collided with other lifecycle work?**

## Posture
1. **Operation overlap is its own truth**
   - A new `start`, `stop`, `restart`, `clear`, or `refresh` request may arrive while another lifecycle action is already queued or being handled.
   - Steward should preserve that overlap truth instead of laundering it into ordinary state labels like `starting` or `stopping`.
2. **Admission and arbitration are different**
   - A request may be locally valid in principle yet still collide with pending work.
   - `verb admitted now` belongs to live control admission.
   - `request replaced pending stop`, `request queued behind existing start`, or `request rejected because control path busy` belong to arbitration.
3. **Reject, replace, flush, and irreversible-floor are materially different results**
   - Historical managers make very different choices when a new operation conflicts with pending work: fail, replace the old work, cancel other queued work, or prevent later conflicting replacement.
   - Steward should steal that honesty directly instead of flattening everything into `busy`.
4. **Serialization in the control path is real and should stay visible**
   - Some substrates handle only one service-control notification at a time, or refuse control traffic while a service is in pending transition states.
   - Steward should allow compact truth such as `control path serialized`, `cannot accept control during start`, or `timed out waiting for handler to return` when the adapter can prove it.
5. **Arbitration result is different from final operation result**
   - `replaced pending stop with restart` is not the same thing as `restart completed`.
   - `flushed conflicting queued jobs` is not the same thing as `service stopped`.
   - Steward should preserve both truths when they differ.
6. **Ordering uncertainty should fail honest**
   - If one request set might affect another and the substrate does not guarantee ordering, Steward should say so rather than invent a hidden sequence myth.
   - Separate exact requests are healthier than one ambient multi-target gesture when ordering matters.
7. **Exact receipts beat control folklore**
   - A healthy compact receipt can name the new verb, exact target, arbitration outcome, any prior pending work it displaced or waited behind, and the narrow reason when known.
   - Good compact chips include `queued behind current stop`, `replaced pending start`, `flush mode`, `irreversible floor`, `cannot accept control`, or `unknown arbitration`.
8. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional exact arbitration receipt with a small result vocabulary such as `accepted`, `queued`, `rejected`, `replaced`, `flushed`, `irreversible`, or `unknown`, plus optional cause text when provable.
   - Rich transaction graphs, queue introspection UIs, and host-specific override grammars remain intentionally undecided.

## Phase-1 non-goals
- a portable transaction planner or dependency-override language;
- promising that every adapter can enumerate or rewrite pending lifecycle work;
- silently merging distinct lifecycle requests into one flattering synthetic outcome;
- standardizing every host's cancellation, replacement, or flush mode;
- a giant operation-history or workflow-debugging family.

## Adjacent docs
- `control-operation-posture-v0.md`
- `action-surface-posture-v0.md`
- `stop-escalation-posture-v0.md`
- `start-gate-posture-v0.md`
- `status-authority-posture-v0.md`
- `state-explainer-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMCTL
- REF-SYSTEMD1-DBUS
- REF-SVCADM
- REF-WINDOWS-CONTROLSERVICEEX
- REF-WINDOWS-STARTSERVICE
