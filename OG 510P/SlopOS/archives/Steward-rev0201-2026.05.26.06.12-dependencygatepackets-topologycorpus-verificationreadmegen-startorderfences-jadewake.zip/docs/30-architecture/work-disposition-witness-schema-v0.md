# Work-disposition witness schema v0

## Purpose
`ST-WORKDISP v0` is the closed packet profile for the local fate of one work item after demand admission and custody.

It keeps local acknowledgement, local completion, redelivery, expiry, discard, dead-letter, abandonment, detachment, supersession, and unknown fate distinct from external effects.

## Required fields
- `schema`: constant `ST-WORKDISP v0`.
- `disposition_id`: stable packet-local disposition identifier.
- `item_ref`: exact work or demand item.
- `cid`: component identity.
- `issuer`: closed issuer object.
- `disposition`: `acknowledged`, `completed_local`, `redeliverable`, `redelivered`, `expired`, `dead_lettered`, `discarded`, `abandoned`, `detached`, `superseded`, or `unknown`.
- `observed_at_ms`: monotonic packet-time observation.
- `basis_refs`: bounded supporting observations.
- `non_implications`: must include at least `not-readiness`, `not-serving`, `not-effect-success`, and `not-exactly-once`.

## Optional fields
`demand_ref`, `custody_ref`, `runtime_cycle`, `effect_boundary_ref`, `retry_or_redelivery_ref`, `outcome_reason`, `duplicate_risk`, and `terminal_class`.

## Cross-field rules
- `acknowledged` and `completed_local` require `custody_ref`.
- `expired`, `dead_lettered`, `discarded`, `abandoned`, `superseded`, and `unknown` require `outcome_reason`.
- `effect_boundary_ref` may link adjacent evidence, but the disposition packet itself remains weaker than effect success.
- Raw logs, scrollback, host process identifiers, bearer material, and stronger effect claims are forbidden anywhere in the packet.

## Refusals
A work-disposition witness never proves readiness, serving, external confirmation, exactly-once execution, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/demand-custody-effect-corpus-v0.jsonl`; the checker is `../../tools/steward_work_effect_harness.py`.
