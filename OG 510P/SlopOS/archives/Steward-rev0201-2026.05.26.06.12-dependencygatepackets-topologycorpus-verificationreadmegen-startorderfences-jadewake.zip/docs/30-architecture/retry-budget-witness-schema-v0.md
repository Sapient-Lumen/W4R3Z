# Retry-budget witness schema v0

## Purpose
`ST-RETRYBUDGET v0` is the first closed packet for one bounded retry-budget, quota, token-bucket, adaptive limiter, route retry budget, or local retry allowance observation.

The central rule: **budget state may influence whether this issuer will automatically retry, but it is not route authority, admission, readiness, serving, capacity reservation, global quota, or effect success.**

## Machine profile
- Machine profile: `../../schemas/st-retrybudget-v0.schema.json`
- Checker: `../../tools/steward_retry_settlement_harness.py`
- Corpus: `../40-verification/corpora/retry-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-RETRYBUDGET v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | client, proxy, library, mesh, controller, adapter, or observer reporting the budget |
| `budget_id` | canonical budget witness id |
| `budget_scope` | `component`, `route`, `client`, `caller`, `operation`, `upstream`, `local`, or `unknown` |
| `budget_state` | `available`, `constrained`, `exhausted`, `disabled`, `adaptive_slow_start`, `open_circuit`, or `unknown` |
| `decision_effect` | `automatic_retry_allowed`, `automatic_retry_blocked`, `manual_review_required`, `observe_only`, or `unknown` |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the budget observation |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `attempt_group_ref`, `remaining_class`, `next_refill_after_ms`, `limit_ref`, `advice_ref`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Non-implication vocabulary
A valid retry-budget witness must include:

- `not-capacity-reservation`
- `not-route-authority`
- `not-readiness`
- `not-serving`
- `not-effect-success`
- `not-admission`
- `not-global-quota`

## Budget rules
Exhausted, open-circuit, or disabled budget states cannot allow automatic retry. A `zero` remaining class cannot allow automatic retry. Unknown budget state requires an explicit downgrade reason. Exact token counts are intentionally not public packet truth; the public packet only needs the effect class and bounded refs.

## Rejected surfaces
The corpus rejects:

- zero or exhausted budget states that still claim automatic retry is allowed;
- budget packets that claim route currentness, capacity reservation, readiness, serving, admission, or effect success;
- budget observations that smuggle raw host, endpoint, token, or counter secrets.

## Non-goals
- no portable quota service, token wallet, global rate-limit plane, route controller, retry scheduler, service mesh, or budget-optimization policy;
- no guarantee that a retry allowed by one issuer is safe, current, or globally admissible.

## Adjacent docs
- `activation-retry-attempt-posture-v0.md`
- `retry-advice-witness-schema-v0.md`
- `retry-attempt-witness-schema-v0.md`
- `backpressure-witness-posture-v0.md`
- `pressure-witness-posture-v0.md`
- `time-and-deadline-posture-v0.md`
- `canonical-json-profile-v0.md`

## References
REF-AWS-SDK-RETRY-BEHAVIOR; REF-AWS-BUILDERS-BACKOFF-JITTER; REF-ENVOY-HTTP-ROUTING; REF-ENVOY-OVERLOAD-MANAGER; REF-GRPC-RETRY.
