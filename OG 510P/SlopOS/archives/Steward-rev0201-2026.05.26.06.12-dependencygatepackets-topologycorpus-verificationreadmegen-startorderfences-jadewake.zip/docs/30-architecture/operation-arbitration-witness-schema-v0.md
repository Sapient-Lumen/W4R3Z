# Operation-arbitration witness schema v0

`ST-OPARBIT v0` is a closed Steward packet for one collision/ordering decision made around a reviewed lifecycle operation request.

## Purpose
An operation-arbitration witness records whether a request was accepted, queued, rejected, replaced, flushed, made irreversible, or left unknown when it met existing work, holds, preconditions, or serialized control-path limits. It does **not** prove the operation executed, succeeded, changed lifecycle state, or settled effects.

## Required fields
- `schema`: exactly `ST-OPARBIT v0`.
- `witness_id`: stable witness id.
- `cid`: component id.
- `issuer`: closed issuer object.
- `arbitration_id`: stable arbitration id.
- `request_ref`: exact `ST-OPREQ` ref.
- `target_ref`: exact lifecycle target.
- `verb`: `start`, `stop`, `restart`, `quiesce`, `clear_repair_gate`, `refresh`, `inspect`, or `explain`.
- `arbitration_result`: `accepted`, `queued`, `rejected`, `replaced`, `flushed`, `irreversible`, or `unknown`.
- `prior_operation_refs`: prior queued or in-flight operation refs when known.
- `queue_position`: positive only for queued results; zero otherwise.
- `irreversible_floor`: true only when the decision crosses an explicit cannot-replace floor.
- `decided_at_ms`: local monotonic decision time.
- `reason`: bounded reason string.
- `precondition_refs`: exact precondition witnesses considered.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for operation result, execution, mutation, readiness, serving, effect success, authorization, approval, current state, and reservation.

## Rejection examples
- ambient/current targets;
- queued result with zero queue position;
- non-queued result with a queue position;
- irreversible result without an irreversible floor;
- accepted/replaced/flushed/irreversible result while an active hold blocks the same mutating verb;
- stale or failed preconditions used for non-rejected arbitration;
- execution, operation-result, success, authorization, readiness, serving, or effect-success claims.
