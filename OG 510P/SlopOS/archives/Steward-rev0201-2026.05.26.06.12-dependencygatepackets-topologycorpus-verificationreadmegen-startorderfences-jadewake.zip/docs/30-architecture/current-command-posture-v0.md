# Current-command posture v0

Purpose: define a **tiny exact current-command seam** so the command the user is editing right now can be treated as an exact, expiring object for reveal, assist, copy, diff, and handoff without pane-wide guessing or transcript folklore.

## Posture
1. **The current command is its own object, not just nearby prompt text**
   - When the shell can prove one editable command line at the live prompt, Steward should be allowed to treat that line as one exact current-command object.
   - That object exists so nearby affordances can bind to what the user is actually editing instead of scraping visible text around the cursor.
2. **Current command, prompt lease, and command frame stay distinct**
   - A prompt lease names the live editable footing.
   - A current-command object names the editable command content currently attached to that footing.
   - A command frame names the broader interaction record that may later include launched command, output, receipt, and exit/result.
   - Steward should keep those truths separate instead of pretending they are interchangeable.
3. **Exact current-command luxuries belong only to live footing**
   - Copy-current-command, explain-current-command, lint-current-command, partial-accept assist, and prompt-local diff/rewrite suggestions should bind only to a fresh current-command object.
   - Historical transcript text should degrade to selection, reveal, or exact-frame actions rather than fake “edit the old command here” authority.
4. **The object may carry text first and structure later**
   - Phase 1 may only need exact command text plus lightweight metadata such as shell, cwd, hop lineage, freshness, and optional prompt-local selection span.
   - Some shells may later offer richer segmentation or argv-ish structure, but Steward should not require a universal parse tree before the design earns it.
5. **Expiry should be ordinary and explicit**
   - Executing the command, replacing the prompt, losing semantic markers, crossing a semantic epoch, or degrading across a hop may end the current-command object.
   - Steward should treat that expiry as normal lifecycle for editable command truth rather than as an error to hide.
6. **Assist and proposal surfaces should stay weaker than launch truth**
   - Current-command help, completion, rewrite suggestions, and proposal-lane affordances may attach to the exact current-command object while it is live.
   - They remain weaker than the later reviewed launch intent, activation request, or lifecycle receipt and must not silently become execution authority.
7. **Copy, diff, and handoff should preserve provenance**
   - Exporting or comparing the current command should carry freshness, hop lineage, confidence, and whether the object was exact shell-reported text or a weaker fallback.
   - Steward should not let a stale remembered command masquerade as the current editable truth.
8. **Riskier actions require fresher binding than convenience actions**
   - Low-risk actions such as copy, explain, or open-in-guide can survive weaker or stale command footing with visible downgrade.
   - Higher-risk actions such as “approve and run this exact edited command” should fence on the live current-command object and any other required fresh-intent or approval evidence.
9. **Keep the phase-1 contract tiny**
   - Phase 1 likely needs only one exact current-command object beside the prompt lease plus ordinary expiry and provenance.
   - Avoid freezing shell-grammar ASTs, portable rewrite APIs, multi-cursor command editing, or a universal command-object interchange before repeated pressure exists.

## Phase-1 non-goals
- freezing a universal shell grammar, parse tree, or cross-shell AST;
- making historical transcript commands permanently editable;
- treating current-command text as equivalent to reviewed launch truth or lifecycle authority;
- requiring every shell or multiplexer path to preserve exact current-command footing equally well;
- inventing a giant live-edit or rewrite protocol before small exact-object affordances prove their worth.

## Adjacent docs
- `prompt-lease-posture-v0.md`
- `command-frame-posture-v0.md`
- `input-surface-posture-v0.md`
- `assist-surface-posture-v0.md`
- `proposal-lane-posture-v0.md`
- `context-handoff-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `precision-fence-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-ITERM2-COMMAND-SELECTION
- REF-VSCODE-SHELL-INTEGRATION
- REF-FISH-TERMINAL-COMPAT
- REF-GHOSTTY-RELEASE-130
