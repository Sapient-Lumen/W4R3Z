# Dependency fallback witness schema v0

## Purpose
`ST-DEPFALLBACK v0` is the closed packet profile for one dependency-driven degraded or fallback mode. It records planned, armed, active, revoked, expired, or unknown fallback activation without claiming repair, rollback success, readiness, serving, currentness, work completion, or effect success.

## Required fields
- `schema`: constant `ST-DEPFALLBACK v0`.
- `witness_id`: packet witness id.
- `dependency_fallback_id`: stable fallback id.
- `cid`: subject component identity.
- `dependency_spec_refs`: exact dependency specs that motivated the fallback.
- `mode`: `none`, `degraded_mode`, `cached`, `alternate`, `queue_only`, `read_only`, `disabled`, or `unknown`.
- `activation_state`: `planned`, `armed`, `active`, `revoked`, `expired`, or `unknown`.
- `activation_refs`: exact generation, material, or operation refs that make the fallback active, if any.
- `decided_at_ms` and `expires_at_ms`: bounded freshness window.
- `degradation_class`: `none`, `capacity`, `freshness`, `feature`, `safety`, `availability`, or `unknown`.
- `reason`: bounded explanation.
- `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.

## Required non-implications
`non_implications` must include `not-authority`, `not-authorization`, `not-readiness`, `not-serving`, `not-currentness`, `not-failure`, `not-repair`, `not-rollback`, `not-work-completion`, and `not-effect-success`.

## Cross-field rules
- Active fallback requires exact activation basis refs.
- `none` mode cannot be armed or active.
- Raw host identifiers, paths, endpoints, bearer material, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A dependency fallback is not repair success, rollback success, readiness, serving, work completion, effect success, failure, or authority to continue forever.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/dependency-gate-corpus-v0.jsonl`; the checker is `../../tools/steward_dependency_gate_harness.py`.
