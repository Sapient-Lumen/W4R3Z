# Control-target posture v0

Purpose: define a **tiny exact lifecycle control-target seam** so stop/restart/quiesce/explain actions bind to explicit Steward objects instead of ambient PID, pane, jobs-table, or shell-session folklore.

## Posture
1. **Lifecycle control targets the supervised object first**
   - The public subject of stop, restart, quiesce, explain, or reveal actions should be a Steward component identity and, when useful, one exact runtime-cycle witness.
   - Operators should not need a PID, process group, cgroup path, shell jobspec, or host service name to act on reviewed work.
2. **Component target and concrete-run target stay distinct**
   - `component` answers “which reviewed component do I mean?”
   - `component + expected runtime-cycle witness` answers “which exact live run do I mean?”
   - Steward should be able to preserve both shapes without conflating them.
3. **Mutating actions should be fenceable when exactness matters**
   - A restart or stop request may optionally carry an expected runtime-cycle witness or other stale-action fence.
   - If the target has already rotated into a different run, Steward should be able to fail clearly instead of silently acting on whichever run happens to be current.
4. **Control targets stay smaller than host control handles**
   - Hosts may use pidfds, job objects, service managers, or supervisor-local control channels behind the membrane.
   - Those mechanisms are implementation detail; they are not the public Steward control target.
5. **Shell and terminal affordances may surface exact control-target objects**
   - A command frame, receipt, or chrome chip may carry a compact target such as `component`, `same run`, or `component as currently observed`.
   - UI affordances should bind to that explicit target object rather than guessing from visible process ids, pane focus, or last-used context.
6. **Current live-verb admission should be explicit when it matters**
   - A target may surface which live controls are currently admitted, such as `stop`, `quiesce`, `refresh`, or `inspect only`.
   - Transitional states like `starting`, `stop pending`, or `draining` may honestly narrow that set; Steward should preserve the narrowing instead of surfacing verbs that will only be rejected.
7. **Observational anchors and control targets are related but not identical**
   - A transcript span, receipt digest, or target anchor may help the user reach the right action.
   - The eventual mutating action should still resolve to one explicit lifecycle control target instead of inheriting whatever the anchor merely suggested.
8. **Ownership islands may scope targets later, but are not required now**
   - A future shallow realm/subtree seam may let Steward say “control this exact subtree” or “explain the parent ownership island.”
   - Phase 1 does not need to freeze a realm algebra before exact component/run targeting becomes useful.
9. **Degrade by visible narrowing, not silent weakening**
   - If an adapter cannot support same-run fences or exact cross-hop targeting, Steward should surface a weaker `component` target or deny the action.
   - It should not silently drop the fence and pretend exactness survived.
10. **Control-target objects are for action, not identity colonization**
   - A control target is a compact actionable description of what lifecycle object to operate on.
   - It should not become a general replacement for receipts, histories, component manifests, or shell objects that serve different jobs.
11. **Keep the portable contract tiny at first**
    - Phase 1 likely needs only a small target vocabulary such as `component`, `component + expected witness`, and maybe later `ownership island`.
    - Avoid freezing a giant lifecycle RPC, selector grammar, or distributed control-addressing family before repeated pressure exists.

## Phase-1 non-goals
- exposing raw PIDs, process groups, cgroup paths, or job handles as public Steward control identity;
- requiring every host to support exact same-run fencing for every verb;
- forcing every adapter to expose a rich portable verb-admission matrix before exact target objects are even useful;
- freezing a generic selector language over component graphs or transcripts;
- turning transcript anchors, hyperlinks, or pane focus into implicit mutation authority;
- inventing a giant lifecycle RPC/control bus before small exact target objects have been tried.

## Adjacent docs
- `supervision-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `execution-group-posture-v0.md`
- `action-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `request-context-posture-v0.md`
- `quiesce-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-S6-SVC
- REF-S6-SUPERVISE
- REF-FUCHSIA-REALMS
- REF-LAUNCHD-JOBS
- REF-SYSTEMD-UNIT
- REF-FUCHSIA-LIFECYCLE
- REF-WINDOWS-SERVICE-STATE-TRANSITIONS
- REF-WINDOWS-SERVICE-STATUS
