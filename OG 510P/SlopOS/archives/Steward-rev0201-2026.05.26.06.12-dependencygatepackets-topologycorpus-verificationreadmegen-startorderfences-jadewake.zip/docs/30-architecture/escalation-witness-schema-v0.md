# Escalation witness schema v0

## Purpose
`ST-ESCALATE v0` is the closed packet for one stronger intervention after a stop, quiesce, drain, policy, or safety boundary requires escalation.

The central rule: **escalation means stronger intervention was requested, armed, applied, refused, superseded, or unknown; it is not stopped, drained, clean exit, graceful exit, lossless continuity, or effect success.**

## Machine profile
- Machine profile: `../../schemas/st-escalate-v0.schema.json`
- Checker: `../../tools/steward_shutdown_harness.py`
- Corpus: `../40-verification/corpora/shutdown-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-ESCALATE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | supervisor, platform, runtime, adapter, controller, or operator reporting escalation |
| `escalation_id` | canonical escalation id matching `esc_[a-z0-9]{16}` |
| `runtime_cycle_ref` | concrete runtime cycle being escalated |
| `escalation_state` | `requested`, `armed`, `applied`, `refused`, `superseded`, or `unknown` |
| `reason` | reason for escalation |
| `force_level` | `notify`, `soft_stop`, `interrupt`, `terminate`, `kill`, `adapter_force`, `platform_evict`, or `unknown` |
| `previous_request_ref` | previous stop/quiesce/drain/control request basis |
| `deadline_basis` | deadline or policy class that justified escalation |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the escalation state |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `grace_elapsed_ms`, `authority_ref`, `drain_ref`, `signal_class`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Non-implication vocabulary
A valid escalation witness must include:

- `not-stopped`
- `not-drained`
- `not-effect-success`
- `not-clean-exit`
- `not-lossless`
- `not-graceful`

## Escalation rules
`grace_expired` requires `grace_elapsed_ms`. `applied` cannot use `force_level = unknown`. Strong force levels such as `kill`, `adapter_force`, and `platform_evict` require an `authority_ref` when applied.

Escalation can be useful evidence for a later termination-cause witness, but it is never final termination by itself.

## Rejected surfaces
The corpus rejects:

- escalation packets that claim stopped, drained, clean-exit, graceful-exit, lossless, or effect-success truth;
- grace-expired escalation without elapsed grace;
- applied strong force without authority basis;
- flow records that treat applied escalation as final stopped state.

## Non-goals
- no signal API, platform eviction API, host process model, incident policy engine, or universal force hierarchy;
- no claim that every substrate can perform or observe the same escalation levels.

## Adjacent docs
- `stop-escalation-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `shutdown-horizon-posture-v0.md`
- `control-operation-receipt-schema-v0.md`
- `runtime-cycle-witness-schema-v0.md`
- `canonical-json-profile-v0.md`
