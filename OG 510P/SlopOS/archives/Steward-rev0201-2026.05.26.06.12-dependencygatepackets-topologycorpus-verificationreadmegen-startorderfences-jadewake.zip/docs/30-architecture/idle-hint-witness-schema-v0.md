# Idle-hint witness schema v0

Purpose: define the closed human profile for `ST-IDLEHINT v0`, a bounded busy/idle/draining hint for one runtime cycle.

An idle hint helps Steward explain whether a runtime cycle appears idle, busy, draining, or unknown at a particular moment. It stays weaker than readiness, serving, stopped state, quiescence, drain completion, stop authority, work completion, or effect success.

## Required fields
- `schema`: `ST-IDLEHINT v0`.
- `witness_id`, `cid`, `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.
- `idle_hint_id`: stable id with `idle_` prefix.
- `runtime_cycle_ref`: exact runtime-cycle ref.
- `idle_state`: `idle`, `busy`, `draining`, or `unknown`.
- `precision`: `bracketed`, `counted`, `coarse`, `adapter`, or `unknown`.
- `active_bracket_refs`: exact bracket refs when the hint claims bracketed or counted busy/draining work.
- `as_of_ms` and `expires_at_ms`.
- `reason`: short redacted explanation.

## Required non-implications
`not-authority`, `not-authorization`, `not-currentness`, `not-readiness`, `not-serving`, `not-quiesce`, `not-drain`, `not-stop-authority`, `not-work-completion`, `not-effect-success`, and `not-idle-stop-grant`.

## Rules
Idle hints have bounded freshness. `idle` cannot cite active brackets. `busy` or `draining` with `bracketed` or `counted` precision must cite exact active bracket refs. Lack of bracket support should degrade to coarse, adapter, or unknown rather than invented precision.

## Non-goals
This packet does not prove the component is stopped, safe to kill, ready, serving, drained, or free of side effects.
