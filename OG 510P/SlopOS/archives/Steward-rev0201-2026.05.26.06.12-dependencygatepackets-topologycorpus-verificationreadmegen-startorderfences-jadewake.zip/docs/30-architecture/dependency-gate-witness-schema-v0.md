# Dependency gate witness schema v0

## Purpose
`ST-DEPGATE v0` is the closed packet profile for one dependency-informed lifecycle request decision. It can allow, block, defer, degrade, or report unknown for a request without executing that request, authorizing it, starting a component, accepting demand, proving readiness, proving failure, completing work, or settling an effect.

## Required fields
- `schema`: constant `ST-DEPGATE v0`.
- `witness_id`: packet witness id.
- `dependency_gate_id`: stable gate id.
- `cid`: subject component identity.
- `request_ref`: exact lifecycle operation request ref.
- `subject_ref`: exact subject ref.
- `decision_state`: `allow`, `block`, `defer`, `degrade`, or `unknown`.
- `dependency_spec_refs`: exact dependency spec refs considered.
- `dependency_check_refs`: exact dependency check refs considered.
- `fallback_ref`: exact fallback witness id or `none`.
- `decided_at_ms` and `expires_at_ms`: bounded decision freshness window.
- `reason`: bounded explanation.
- `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.

## Required non-implications
`non_implications` must include `not-authority`, `not-authorization`, `not-approval`, `not-started`, `not-executed`, `not-readiness`, `not-serving`, `not-demand`, `not-custody`, `not-work-completion`, `not-effect-success`, and `not-failure`.

## Cross-field rules
- Known dependency gates must still be within their freshness window.
- `degrade` requires an exact active fallback witness.
- `allow` cannot rely on an unavailable or stale hard dependency check.
- Raw host identifiers, paths, endpoints, bearer material, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A dependency gate is not authority, approval, operation execution, start success, demand acceptance, custody, readiness, serving, component failure, work completion, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/dependency-gate-corpus-v0.jsonl`; the checker is `../../tools/steward_dependency_gate_harness.py`.
