# Governance authorization posture v0

## Why this seam exists
Rev0183 made operator requests and operation receipts closed. That proved exact target, digest, idempotency, and result non-implication. It did not yet prove that the path from human or automation desire to executable lifecycle mutation keeps governance facts separate.

Rev0190 adds a narrow governance authorization seam:

1. **Delegation warrant** — scoped, expiring authority evidence for one delegate, component, verb family, and caveat set.
2. **Operator review** — request hygiene and risk review, not approval.
3. **Approval decision** — exact operation-digest approval or denial, not execution.
4. **Authorization check** — Steward's gate decision that composes delegation, review, and approval evidence, not an operation receipt.

## What Steward owns
Steward owns the lifecycle control boundary. It may refuse to pass an operation to execution unless the request has enough explicit authority evidence for the operation class.

Steward may record:

- which delegate is being checked;
- which operation digest is being checked;
- which lifecycle verb is in scope;
- which component and runtime-cycle fence are in scope;
- which warrant, review, and approval packets were considered;
- whether the gate decision is allowed, denied, stale, needs approval, or unknown.

## What Ward owns
Ward remains the better owner for stewardship charters, owner discovery, delegation chain policy, organization role semantics, standing, contest/remedy governance, and long-lived trust posture. Steward imports Ward-flavored delegation evidence only as scoped, checkable lifecycle warrant packets.

A Ward owner label does not become Steward approval. A Ward delegation hint does not execute a lifecycle operation. A Ward escalation route does not prove stop, restart, drain, or effect success.

## Collapse rules
Steward must reject these collapses:

- owner label means approval;
- delegation means approval;
- review pass means authorization;
- approval means operation execution;
- authorization means operation receipt;
- operation receipt means component state;
- break-glass approval means force was applied;
- expired delegation remains live because the same human is still on-call;
- stale review remains pass because the screen still displays green;
- denied approval can be bypassed by a later matching digest;
- review or authorization can carry raw token, PID, host unit, or terminal pane authority.

## Packet settlement
The governance authorization corpus gives this posture an executable center:

- `ST-DELEGATE v0` settles scoped warrant evidence;
- `ST-REVIEW v0` settles bounded request review;
- `ST-APPROVAL v0` settles exact approval/denial evidence;
- `ST-AUTHCHECK v0` settles the immediate authorization gate.

The flow checker only accepts an allowed authorization when all referenced packets agree on subject digest, delegate, component, verb, runtime-cycle fence, freshness, and approval status.

## Interaction with control operations
A future `ST-OPRECEIPT v0` may cite an `ST-AUTHCHECK v0` packet as authority basis. The reverse is forbidden: an authorization check cannot claim the operation receipt exists, that the action executed, or that the component changed state.

This gives the admin surface a safer order:

1. create or receive exact operation request;
2. review the request;
3. gather scoped delegation and approval evidence;
4. emit authorization check;
5. attempt execution;
6. emit operation receipt;
7. emit narrower lifecycle witnesses such as quiesce, drain, escalation, or termination as they occur.

## Emergency and break-glass
Break-glass is not magic. It is a stronger risk class and must stay explicit. A break-glass approval still requires exact subject digest, scope, expiry, and later execution receipts. If it leads to force, the force appears later through escalation and termination-cause witnesses.

## Non-goals
- no global authorization engine;
- no RBAC implementation;
- no org chart;
- no standing owner map;
- no permanent delegation chain;
- no re-delegation;
- no approval UI;
- no execution or effect settlement.

## Proof obligations
- every registered governance packet has accept and reject corpus coverage;
- allowed auth checks require delegation, review, and approval evidence;
- stale, denied, mismatched, or incomplete evidence cannot be flattened into allowed execution;
- authorization packets carry explicit non-implications.

## Adjacent docs
- `delegation-warrant-witness-schema-v0.md`
- `operator-review-witness-schema-v0.md`
- `approval-decision-witness-schema-v0.md`
- `authorization-check-witness-schema-v0.md`
- `control-operation-request-schema-v0.md`
- `control-operation-receipt-schema-v0.md`
- `admin-surface-posture-v0.md`
- `approval-rung-posture-v0.md`
- `companion-boundary-map-v0.md`
