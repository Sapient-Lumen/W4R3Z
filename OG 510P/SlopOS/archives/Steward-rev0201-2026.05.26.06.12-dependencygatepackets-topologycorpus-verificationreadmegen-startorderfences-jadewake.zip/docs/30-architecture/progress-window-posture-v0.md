# Progress-window posture v0

Purpose: keep **making progress toward ready/stable** separate from both **first readiness** and **repair-required quieting** so Steward can say “still warming”, “deadline extended”, or “stalled” without freezing a rollout engine, universal health-check grammar, or timer DSL.

This seam is intentionally small. It covers one narrow question: **while a component is not yet ready/stable (or is reloading toward a new ready state), what counts as progress, how long may that intermediate state last, and how does Steward explain that it is still legitimately in flight versus stalled?**

## Posture
1. **Progress window is not the same thing as readiness or stability**
   - A component may be alive but not yet ready.
   - A component may also be ready but not yet stable enough to admit as `stable`.
   - The progress window belongs to the earlier question: is the current bring-up / reload / resume attempt still making progress, or has it stalled?
2. **Progress should advance from explicit checkpoints or adapter evidence, not manager vibes**
   - Spawn success alone is too weak.
   - Useful progress anchors include explicit lifecycle checkpoints, a fresh reload checkpoint, or another reviewed adapter signal that the component moved materially forward.
3. **Do not renew pending state just to avoid being marked hung**
   - A pending window should extend only when a new real checkpoint or comparable reviewed forward signal lands.
   - Synthetic keepalive-style “still progressing” updates without concrete movement are worse than an honest `stalled` or `progress unknown` verdict.
4. **The window should be allowed to cover reload/reconfigure work, not only first boot**
   - The same seam can explain `starting`, `reloading`, or `resuming` as long as the adapter can still point to the concrete cycle/generation/checkpoint it refers to.
5. **Stall should surface as its own truth**
   - If progress stops for longer than the allowed window, Steward should be able to say `stalled`, `deadline exceeded`, or `progress unknown`.
   - That should stay distinct from `crashed`, `repair required`, or `ready but warming toward stable`.
6. **Paused or intentionally held work should not look like involuntary stall**
   - If an operator or policy deliberately pauses advancement, the honest story is `paused/held`, not “progress deadline exceeded because nothing happened while we intentionally waited”.
7. **Extensions should be explicit and bounded**
   - Some runtimes can honestly say “still making progress; extend the current start/reload timeout”.
   - Steward should preserve that as an explicit extension signal, not as infinite silent patience.
8. **A new checkpoint can renew the horizon without rewriting history**
   - If a component reaches a later explicit checkpoint, the progress window may renew from that new point.
   - Earlier waiting time should still remain explainable in receipts/history instead of vanishing into one happy `starting` label.
9. **Shell chrome should show stall truth compactly**
   - Ground cards, receipts, and status rows may show compact chips such as `starting`, `progress seen`, `extended`, `stalled`, `held`, or `progress unknown`.
   - Those chips should orient the user without becoming a hidden orchestration API.
10. **Unknown beats fake timing precision**
   - Some adapters can prove a progress deadline or renewal window.
   - Others can only say that the component is not yet ready and no trustworthy progress clock exists. Steward should keep that honesty.
11. **Phase 1 keeps the portable shape tiny**
    - Phase 1 likely needs no more than an optional current progress state, an optional target/remaining window when the adapter can prove it, and an optional note that the window was explicitly extended or intentionally held.

## Phase-1 non-goals
- a universal startup timeout / retry / backoff DSL;
- freezing one global set of lifecycle checkpoints for every runtime;
- turning progress windows into a rollout controller or dependency planner;
- pretending elapsed time alone proves useful progress;
- automatic pause/resume orchestration or a generic maintenance-mode language.

## Adjacent docs
- `activation-checkpoint-posture-v0.md`
- `readiness-posture-v0.md`
- `readiness-generation-posture-v0.md`
- `stability-window-posture-v0.md`
- `activation-cause-posture-v0.md`
- `restart-budget-posture-v0.md`
- `repair-gate-posture-v0.md`
- `status-channel-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-DEPLOYMENT
- REF-NOMAD-UPDATE
- REF-SD-NOTIFY
- REF-SYSTEMD-SERVICE
- REF-WINDOWS-SERVICE-STATUS
- REF-WINDOWS-SETSERVICESTATUS
