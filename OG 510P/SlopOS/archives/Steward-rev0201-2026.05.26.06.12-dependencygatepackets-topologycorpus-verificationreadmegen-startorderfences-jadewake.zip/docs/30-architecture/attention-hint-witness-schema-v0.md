# Attention-hint witness schema v0

`ST-ATTNHINT v0` is a closed Steward packet for one exact attention cue.

## Purpose
An attention hint says that a reviewed anchor deserves some attention treatment. It does **not** prove that the user saw it, that work completed, that a component is current, or that any lifecycle mutation is allowed.

## Required fields
- `schema`: exactly `ST-ATTNHINT v0`.
- `witness_id`: stable witness id.
- `cid`: component id.
- `issuer`: closed issuer object.
- `hint_id`: stable hint id.
- `anchor_ref`: exact frame, receipt, card, barrier, or other anchor.
- `hint_kind`: `command_finished`, `needs_input`, `warning`, `error`, `progress`, `barrier_crossed`, `receipt_settled`, or `unknown`.
- `severity`: `info`, `warning`, `error`, `urgent`, or `unknown`.
- `attention_state`: `observed`, `matched`, `stale`, `withdrawn`, or `unknown`.
- `confidence`: `exact`, `reported`, `inferred`, `provisional`, or `unknown`.
- `focus_state`: `focused`, `background`, `hidden`, or `unknown`.
- `stale_after_ms`: local stale boundary for the hint.
- `delivery_preferences`: bounded delivery preferences such as `badge`, `toast`, or `reveal_only`.
- `observed_at_ms`, `basis_refs`, and `non_implications`.

## Optional fields
- `message_digest`: digest of minimized display text when needed.
- `unknown_reason`.

## Required non-implications
The packet must carry non-implications for authority, current state, readiness, serving, effect success, work completion, user-seen, resolution, authorization, and mutation.

## Rejection examples
- ambient `pane:current` anchors;
- active hints whose stale boundary is already past;
- user-seen, currentness, readiness, authorization, mutation, or effect-success claims;
- raw command text, host paths, URLs, credentials, PIDs, host unit names, or container ids.
