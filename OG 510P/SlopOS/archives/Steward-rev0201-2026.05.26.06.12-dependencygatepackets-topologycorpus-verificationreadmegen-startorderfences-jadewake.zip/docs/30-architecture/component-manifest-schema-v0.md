# CH-COMP v0 component manifest schema

## Purpose
Pin the minimum reviewable component object for Steward-managed lifecycle without inventing a giant unit language.

CH-COMP is the thing whose lifecycle identity, entry selector, restart envelope, readiness expectations, declared imports, and activation allowlists can be digested and carried into lifecycle receipts.

## Machine-readable profile
The machine-readable schema profile is `../../schemas/ch-comp-v0.schema.json`.

The executable checker is `../../tools/steward_lifecycle_harness.py`.

The generated proof corpus is `../40-verification/corpora/component-lifecycle-activation-corpus-v0.jsonl`.

## Canonicalization
CH-COMP uses `canonical-json-profile-v0.md`:

- closed keys;
- duplicate keys reject;
- floats reject;
- enum variants reject unless listed;
- digest is `sha256:` over canonical bytes.

## Shape
Required fields:

- `schema = "CH-COMP v0"`
- `cid`: bounded component id;
- `image_digest`: exact artifact digest;
- `entry`: reviewed entry selector, not shell command text;
- `critical`: bool;
- `imports`: bounded unique list of declared lifecycle-relevant dependency or capability kinds.

Optional fields:

- `restart`: `policy`, `window_ms`, `max_restarts`, `backoff_ms`;
- `readiness`: `required`, `startup_timeout_ms`, `ready_timeout_ms`;
- `activation`: `stable_exports` and optional `escrow` allowlist;
- `notes_tag`: bounded operator-only tag.

## Constraints
- no ambient discovery fields;
- no host-manager-specific control fields;
- no embedded scripts;
- no raw PID, process-group, cgroup, job-object, or unit-name selectors as portable authority;
- no ambient shell command string or `PATH` search meaning hidden behind `entry`;
- no activation key outside the declared bounded syntax;
- no duplicate imports or allowlist keys.

## Cross-object role
CH-COMP is the authority boundary against which CH-ACTSET is checked. A restart may replay an activation set only if the delivered keys remain within the CH-COMP activation allowlists. Host redelivery of more descriptors, paths, env vars, or credentials is not enough.

## Refusals
This deliberately avoids:

- a full unit/dependency DSL;
- shell command strings;
- generic timer semantics;
- raw PID targeting;
- arbitrary descriptor inheritance;
- service-mesh or load-balancer policy;
- workflow history or durable job semantics.

## References
REF-SYSTEMD-FDSTORE; REF-K8S-POD-LIFECYCLE.
