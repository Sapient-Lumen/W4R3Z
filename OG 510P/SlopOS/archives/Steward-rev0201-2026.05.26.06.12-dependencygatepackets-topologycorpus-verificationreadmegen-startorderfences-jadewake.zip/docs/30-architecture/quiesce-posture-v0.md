# Quiesce posture v0

Purpose: pin cooperative maintenance semantics without smuggling in a scheduler.

## Posture
1. **Quiesce is component-local**
   - Phase 1 quiesce applies to one component root at a time.
2. **Quiesce gates new externally triggered work**
   - New work is rejected or deferred according to the component's explicit contract; there is no hidden “accept now, start later” default.
3. **Quiesce aims for bounded drain or cancel**
   - Existing work may drain or be canceled according to declared mode, but the outcome should be bounded and explainable.
4. **Force-kill is not a quiesce verb**
   - Escalation remains a supervision policy.
5. **Quiesce state is observational**
   - Status does not replace authority.

## Executable settlement
Rev0200 adds `activity-accounting-proof-posture-v0.md`, `activity-accounting-corpus-v0.md`, and closed ST-ACTBRACKET / ST-IDLEHINT / ST-STOPDEFER / ST-ACTACCT packet profiles. These executable checks keep activity, idle hints, stop deferral, and accounting separate from readiness, serving, custody, drain completion, keepalive authority, billing, work completion, and effect success.

## Phase-1 non-goals
- subtree freeze semantics;
- global orchestration trees;
- hidden retry queues or maintenance schedulers;
- forcing every runtime to implement the same drain mechanism.

## Adjacent docs
- `supervision-posture-v0.md`
- `readiness-posture-v0.md`

## References
- REF-FUCHSIA-RUNNER
- REF-FUCHSIA-IDLE-STOP
