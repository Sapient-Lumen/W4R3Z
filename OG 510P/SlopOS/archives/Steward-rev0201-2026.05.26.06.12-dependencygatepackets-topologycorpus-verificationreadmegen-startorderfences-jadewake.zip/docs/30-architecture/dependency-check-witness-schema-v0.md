# Dependency check witness schema v0

## Purpose
`ST-DEPCHECK v0` is the closed packet profile for one bounded check of a declared dependency. It reports available, degraded, unavailable, stale, or unknown condition from one vantage without turning the checked dependency into subject readiness, serving, currentness, material freshness, admission, failure, work completion, or effect success.

## Required fields
- `schema`: constant `ST-DEPCHECK v0`.
- `witness_id`: packet witness id.
- `dependency_check_id`: stable check id.
- `cid`: subject component identity.
- `dependency_spec_ref`: exact `ST-DEPSPEC` id.
- `dependency_ref`: exact dependency reference checked.
- `check_state`: `available`, `degraded`, `unavailable`, `stale`, or `unknown`.
- `vantage`: `local`, `route`, `control_surface`, `adapter`, `operator`, `probe`, `cache`, or `unknown`.
- `checked_at_ms` and `expires_at_ms`: bounded freshness window.
- `stale_policy`: `block`, `degrade`, `recheck`, `ignore`, or `unknown`.
- `latency_ms`: bounded descriptive timing summary.
- `reason`: bounded explanation.
- `issuer`, `observed_at_ms`, `basis_refs`, and `non_implications`.

## Required non-implications
`non_implications` must include `not-topology-authority`, `not-readiness`, `not-serving`, `not-currentness`, `not-material-freshness`, `not-admission`, `not-failure`, `not-work-completion`, `not-effect-success`, and `not-authorization`.

## Cross-field rules
- Known dependency checks must still be within their freshness window.
- Stale checks cannot be silently ignored.
- Raw host identifiers, endpoints, paths, bearer material, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A dependency check is not subject readiness, subject serving, current route authority, material freshness, lifecycle admission, component failure, or effect settlement.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/dependency-gate-corpus-v0.jsonl`; the checker is `../../tools/steward_dependency_gate_harness.py`.
