# Termination-cause witness schema v0

## Purpose
`ST-TERMCAUSE v0` is the closed packet for one observed end, suspected end, supersession, or unknown end state of a concrete runtime cycle.

The central rule: **termination cause means a cycle ended or appears to have ended for a named reason; it is not external effect success, drain completion, lossless continuity, restart success, successor readiness, or custody truth.**

## Machine profile
- Machine profile: `../../schemas/st-termcause-v0.schema.json`
- Checker: `../../tools/steward_shutdown_harness.py`
- Corpus: `../40-verification/corpora/shutdown-settlement-corpus-v0.jsonl`

## Required fields
| Field | Meaning |
| --- | --- |
| `schema` | constant `ST-TERMCAUSE v0` |
| `witness_id` | canonical witness id matching `wit_[a-z0-9]{16}` |
| `cid` | component id |
| `issuer` | runtime, supervisor, platform, adapter, controller, or observer reporting termination |
| `termination_id` | canonical termination id matching `term_[a-z0-9]{16}` |
| `runtime_cycle_ref` | concrete runtime cycle whose end is being reported |
| `termination_state` | `ended`, `suspected_ended`, `superseded`, or `unknown` |
| `end_cause` | `requested_stop`, `graceful_exit`, `forced_stop`, `crash`, `watchdog`, `host_eviction`, `dependency_lost`, or `unknown` |
| `exit_class` | `clean`, `failed`, `forced`, `ambiguous`, or `unknown` |
| `observed_at_ms` | monotonic observation time |
| `basis_refs` | bounded evidence refs supporting the termination state |
| `non_implications` | explicit stronger truths this witness refuses |

Optional fields include `drain_ref`, `escalation_ref`, `successor_cycle_ref`, `ended_at_ms`, `recovery_hint`, `expires_or_recheck_by_ms`, and `unknown_reason`.

## Non-implication vocabulary
A valid termination-cause witness must include:

- `not-effect-success`
- `not-drain-complete`
- `not-lossless`
- `not-restart-success`
- `not-successor-ready`
- `not-custody`

## Termination rules
`forced_stop` cannot be reported as `clean`. Clean exit requires `requested_stop` or `graceful_exit`. `ended_at_ms` cannot be later than `observed_at_ms`. `unknown` requires `unknown_reason`.

A termination witness can cite a drain or escalation witness, but those citations do not make the end lossless, effect-safe, successor-ready, or successfully restarted.

## Rejected surfaces
The corpus rejects:

- forced stops flattened into clean exits;
- termination packets that claim successor readiness, restart success, effect success, drain completion, or lossless continuity;
- future `ended_at_ms` values;
- clean graceful termination after an applied kill-level escalation.

## Non-goals
- no process-status API, host exit-code vocabulary, rollout controller, restart engine, crash analyzer, or incident report;
- no proof that old work or effects settled merely because a cycle ended.

## Adjacent docs
- `termination-cause-posture-v0.md`
- `runtime-cycle-witness-schema-v0.md`
- `resume-reconciliation-witness-schema-v0.md`
- `drain-witness-schema-v0.md`
- `escalation-witness-schema-v0.md`
- `canonical-json-profile-v0.md`
