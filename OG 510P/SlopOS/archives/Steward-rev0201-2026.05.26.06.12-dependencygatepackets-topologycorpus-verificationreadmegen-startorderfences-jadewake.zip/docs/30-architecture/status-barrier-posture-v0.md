# Status-barrier posture v0

Purpose: keep **status/checkpoint currentness confirmation** explicit and tiny so Steward can distinguish **"a status update was emitted"** from **"that update definitely crossed the boundary and is current enough to act on"** without teaching shells, adapters, or operators to sleep-and-hope.

This seam stays intentionally small. It does **not** invent a giant event log, a universal controller-runtime, a distributed transaction protocol, or a durable replay/history bus. It only says that when status, readiness, checkpoint, or stop-state updates cross an attribution boundary, Steward may preserve one compact way to say **whether the current observer has definitely caught up to that update**.

## Posture
1. **Emission and barrier-confirmed currentness stay different**
   - A component, runner, or helper may emit `ready`, `stopping`, `draining`, `checkpoint reached`, or similar status.
   - Steward should be allowed to keep a smaller stronger truth for when that update is definitely attributed, crossed the relevant boundary, and may safely fence follow-on UX or reviewed actions.
2. **The seam is about one observed update, not about global history**
   - A status barrier should bind to the exact update, runtime cycle, or small status-generation/checkpoint witness it confirms.
   - It should not quietly become a subscription cursor, replay log offset, or generic event-stream sequence number.
3. **Barrier truth is stronger than status text, weaker than service success**
   - `ready` emitted is weaker than `ready barrier crossed`.
   - `ready barrier crossed` is still weaker than `stable enough to admit`, `request completed`, or `declared work actually succeeded`.
4. **Barrier scope should stay explicit**
   - When possible, Steward should know whether a barrier confirms: receipt attribution, status delivery to the manager, checkpoint publication, shell-visible currentness, or some other narrow boundary.
   - One small exact scope label is healthier than one flattering `synced` bit.
5. **Currentness can be exact without becoming control authority**
   - A barrier may make shell chrome, command frames, or stale fences more trustworthy.
   - It must not silently widen mutation rights, bypass review, or promote observation into approval.
6. **Unknown and unbarriered are healthy states**
   - Some adapters can confirm crossing exactly.
   - Others may only expose emitted-without-barrier or unknown.
   - Steward should preserve that humility instead of faking certainty with elapsed time.
7. **Barrier truth should compose with exact shell objects**
   - Prompt leases, current-command objects, pending-request cards, detour outcomes, and execution-ground chips may use compact barrier truth to decide when to upgrade from `probably current` to `current enough to act on`.
   - The shell should not have to infer that from log quietness or cursor movement.
8. **Scoped event streams are useful, but Phase 1 keeps the portable seam tiny**
   - Runtime-specific systems may route lifecycle/status events as scoped streams, subscriptions, or callbacks.
   - Steward should steal only the tiny currentness/barrier seam first, not a whole event topology.
9. **Barrier truth should help explain races, not hide them**
   - Good UX may say `ready observed; barrier pending`, `stop requested; stop not yet barrier-confirmed`, or `checkpoint published; shell view catching up`.
   - That is healthier than pretending every observer is current at the same instant.
10. **One compact seam is healthier than many ad hoc sleeps**
   - If currentness matters, Steward should prefer an explicit tiny barrier path over wrapper delays, arbitrary retries, or folklore like “wait 200ms after READY”.

## Phase-1 non-goals
- a durable event-log or replay-history contract;
- a universal lifecycle-sequence-number algebra;
- exact cross-runtime total ordering of all status events;
- a hidden orchestration bus that tunnels mutations through status/barrier traffic.

## Adjacent docs
- `status-channel-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `stability-window-posture-v0.md`
- `execution-ground-posture-v0.md`

## References
- REF-SD-NOTIFY
- REF-FUCHSIA-EVENT-STREAM
- REF-XDG-PORTAL-REQUEST
- REF-VSCODE-SHELL-INTEGRATION
- REF-FFX-COMPONENT
