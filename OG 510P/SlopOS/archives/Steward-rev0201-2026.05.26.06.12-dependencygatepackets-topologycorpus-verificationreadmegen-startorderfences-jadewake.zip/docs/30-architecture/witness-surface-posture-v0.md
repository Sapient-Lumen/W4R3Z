# Witness surface posture v0

## Purpose
Witness surfaces are the human-facing compression layer for Steward evidence. They turn packets, receipts, barriers, and weak observations into cards, disabled/enabled actions, and audit findings.

This seam exists because rendered UI can accidentally create stronger truth than the packets beneath it. A green badge, enabled button, terse status line, or clean audit label can become folklore unless the surface is itself bounded.

## Rule
A witness surface may summarize evidence. It must not strengthen evidence.

A card that summarizes `ST-LOCALOBS v0` may say the host manager reported active. It must still say which stronger Steward witnesses are missing. A button that renders a stop action may point to an exact `ST-OPREQ v0` digest and authorization check. It must not claim the operation executed. A barrier may block stale actions. It must not claim currentness. An audit may identify and verify a refactor. It must not become authority, release proof, or correctness proof.

## Packet family
This posture is made executable by four packets:

- `ST-WITCARD v0` — a bounded witness card with evidence refs, missing stronger witnesses, display caveats, downgrade class, and required non-implications.
- `ST-ACTIONAFFORD v0` — an action affordance bound to exact target class, stale fences, operation request digest, authcheck ref, review state, and non-execution semantics.
- `ST-STATUSBARRIER v0` — a status/action barrier that blocks risky verbs until stale or missing evidence is refreshed.
- `ST-SURFAUDIT v0` — an audit/refactor witness for rendered surfaces or cube hygiene, explicitly not a fix, release, authority, or correctness proof by itself.

## Non-implications
Witness surfaces do not prove:

- readiness;
- serving;
- current state;
- freshness;
- authorization;
- operation execution;
- effect success;
- audit correctness;
- release completeness.

The surface must preserve these refusals in the packet, not merely rely on prose around the UI.

## Audit/refactor pressure
Revision 194 used this seam to audit the cube itself. The audit found that `minimum-steward-proof-slice.md` still counted eleven corpora after the local-observation corpus had been added, and that `run_lint_suite.py` had one ad hoc function per harness. The revision fixes the proof-slice inventory and refactors lint into a registry-driven harness loop so future packet families have one place to wire executable checks.

That audit is intentionally recorded as evidence, not as proof that the cube is complete.
