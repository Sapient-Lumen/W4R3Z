# Activation-incarnation lineage posture v0

Purpose: name the smallest useful truth for **which concrete incarnation of a component an activation fact belongs to, and how that incarnation relates to predecessors, successors, replacements, hot restarts, in-place restarts, reschedules, restores, or stale holders**.

This seam is intentionally small. It does **not** invent a rollout controller, migration protocol, checkpoint/restore system, leader-election service, distributed lock, global epoch sequencer, or service-mesh handoff plane. It answers one narrower question: **when the same logical component name survives while concrete execution turns over, what incarnation-lineage witness keeps Steward from treating stale work, stale effects, stale attach targets, or recycled names as current truth?**

## Posture
1. **Component identity, runtime-cycle witness, and incarnation lineage are different truths**
   - Component identity answers which reviewed component is meant.
   - A runtime-cycle witness answers which concrete run, process group, allocation attempt, or local execution cycle produced one observation.
   - Incarnation lineage answers whether that concrete run is the current incarnation, a predecessor, a successor candidate, a draining overlap, a replaced instance, an in-place sub-cycle, a clone/restore sibling, or unknown.
   - Steward should not let a stable name, target path, allocation id, PID, pod name, or user-facing component label silently carry all three meanings.

2. **Names can be reused; incarnation witnesses should not be**
   - Some systems let a human-stable name outlive or be reused by a new concrete object.
   - Steward should prefer a fresh incarnation witness when a logically same component is replaced, restored, moved, rescheduled, or relaunched, even if the public name stays the same.
   - If an implementation can only observe the stable name, the honest state is `incarnation-unknown`, not `same current run`.

3. **Runtime-cycle equality is useful but not enough for replacement stories**
   - Existing runtime-cycle witnesses are the right equality check for one concrete run.
   - Incarnation lineage adds the relation between runs: `predecessor-of`, `successor-of`, `replacement-for`, `same-platform-object-new-subcycle`, `clone-of`, `restore-of`, `split-risk`, `retired`, or `unknown`.
   - This avoids overloading one opaque witness with ordering, authority, or rollout semantics it was not meant to carry.

4. **Hot restart and handoff may have overlapping incarnations**
   - A successor can initialize, prove readiness, and begin accepting new work while the predecessor is still draining old work.
   - Existing connections, descriptors, or held obligations may remain with the predecessor until a named handoff or drain boundary completes.
   - Steward should be able to say `successor-serving`, `predecessor-draining`, `handoff-pending`, `handoff-acknowledged`, or `handoff-unknown` without pretending one binary `running` bit explains the overlap.

5. **In-place restart is not automatically same incarnation or new component**
   - Some substrates preserve a larger object identity while restarting all containers, tasks, helpers, or leaves inside it.
   - Steward should keep room for `same-platform-object-new-subcycle`: useful for local attribution, but not proof that old work, readiness, open descriptors, or side effects belong to the same concrete runtime cycle.
   - The portable seam should report the strongest observed distinction rather than forcing every restart into either full replacement or no change.

6. **Incarnation currentness must be observer-scoped and freshness-scoped**
   - Useful chips include `current`, `current-as-of`, `candidate`, `warming`, `serving`, `draining`, `retired`, `reaped`, `superseded`, `ambiguous`, `split-risk`, and `unknown`.
   - A client that last observed incarnation A should be able to notice that B is now current, that A is still draining, or that Steward cannot prove the relationship.
   - This complements observation cursors and currentness classes; it should not become a global linear time API.

7. **Stale actions should fence on the incarnation they actually saw**
   - Stop, attach, inspect, replay, compensate, redrive, deliver, or external-effect actions may need an expected incarnation witness in addition to component identity.
   - If the component has since replaced or forked, Steward should fail or downgrade with `wrong-incarnation`, `successor-current`, `predecessor-draining`, or `incarnation-ambiguous` instead of silently retargeting the new run.
   - This is especially important when a stale predecessor can still hold descriptors, deliver callbacks, or reach external resources.

8. **Fence tokens and incarnation lineage solve adjacent, not identical, problems**
   - A fence token can reject a stale live holder at effect time for one reassignable claim lineage.
   - Incarnation lineage explains which concrete component incarnation made, held, or observed the claim.
   - When both exist, the effect path should be free to require both `current holder/fence` and `expected incarnation` instead of using either as a magical universal authority.

9. **Terms and epochs are stealable as stale-information rejection, not as a global clock**
   - Consensus systems use terms/epochs to detect stale leaders and obsolete messages.
   - Steward can steal the discipline—carry an issuer-scoped epoch/witness and reject stale incarnations—without importing consensus, leader election, or a total order for all components.
   - The first portable claim should be stale rejection within one reviewed component/incarnation lineage.

10. **Leader-election and lock recipes warn that “lowest/current” is not the same as “acting”**
    - A process may be entitled to act by a sequence/lease/lock recipe before it has actually acknowledged or executed the leadership procedure.
    - Steward should preserve an explicit `incumbent-aware`, `successor-aware`, or `leadership-accepted` style boundary when a lifecycle role matters.
    - This keeps `eligible/current` separate from `has begun serving`, `has completed handoff`, or `has applied effect`.

11. **Work and effects should carry incarnation attribution but not derive fate from it**
    - Admission, custody, disposition, and effect-boundary witnesses should be allowed to cite the incarnation that accepted, held, acknowledged, discarded, submitted, or confirmed work.
    - A newer incarnation does not prove older work failed; an older incarnation being dead does not prove its side effects did not happen.
    - Incarnation lineage helps repair and explanation; it does not replace work disposition or effect-boundary truth.

12. **Clone/restore deserves explicit uncertainty**
    - Snapshot restore, warm restore, backup recovery, or copy/import can create two worlds that share too much old local state.
    - If an implementation has a generation counter or restore witness, Steward should bind it into incarnation lineage.
    - Without such a witness, `clone-or-restore-unknown` is safer than accepting old effect keys, descriptors, wake memories, or runtime-cycle observations as fresh.

13. **Phase 1 shape is a witness, not a rollout API**
    - A tentative `activation_incarnation_lineage` witness can stay tiny: `lineage_id`, `component_id`, `incarnation_id`, optional `runtime_cycle_witness`, optional `predecessor_incarnation_id`, optional `successor_incarnation_id`, `relation`, `currentness`, optional `handoff_boundary`, optional `expected_fence`, optional `observed_generation`, optional `restore_or_clone_witness`, optional `proof_strength`, and optional `basis`.
    - Field names remain provisional until real Steward components show which facts must travel across membranes.

## Phase-1 non-goals
- a universal rollout, migration, placement, reschedule, hot-restart, or checkpoint/restore protocol;
- a distributed lock, leader-election service, consensus layer, or global monotonic sequencer;
- a service-mesh handoff plane, connection migration protocol, or socket-transfer API;
- claiming that a stable name, PID, pod name, allocation id, object path, generation number, or readiness bit is portable incarnation truth by itself;
- turning incarnation witnesses into bearer authority, effect keys, queue handles, or transaction tokens;
- automatically discarding, redriving, compensating, or retargeting work merely because a successor incarnation exists.

## Adjacent docs
- `runtime-cycle-witness-posture-v0.md`
- `fence-token-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `activation-custody-posture-v0.md`
- `activation-work-disposition-posture-v0.md`
- `activation-effect-boundary-posture-v0.md`
- `readiness-generation-posture-v0.md`
- `continuity-escrow-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-EXEC
- REF-K8S-OBJECT-NAMES-IDS
- REF-K8S-POD-LIFECYCLE
- REF-K8S-RESTART-ALL-CONTAINERS
- REF-ENVOY-HOT-RESTART
- REF-ENVOY-HOT-RESTARTER
- REF-RAFT-PAPER
- REF-ZOOKEEPER-RECIPES
- REF-ETCD-API-TXN
- REF-ETCD-CONCURRENCY-LOCK
- REF-NOMAD-RESTART
- REF-NOMAD-RESCHEDULE
