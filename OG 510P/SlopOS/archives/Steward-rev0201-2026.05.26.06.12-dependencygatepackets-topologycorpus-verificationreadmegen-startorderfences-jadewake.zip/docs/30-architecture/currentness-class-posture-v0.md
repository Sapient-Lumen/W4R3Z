# Currentness-class posture v0

Purpose: define one **tiny explicit seam** for the **strength of a currentness claim** so Steward can say not only `current through <cursor>` but also **what kind of proving path earned that claim**.

This stays intentionally small. It does **not** invent a global consistency algebra, a distributed read protocol, or a final freshness taxonomy for every runtime. It only preserves a healthy distinction that many real systems already expose implicitly: **some synced-through markers are local-to-this-stream, some are backed by a stronger read or checkpoint path, and some truths become weaker or invalid when continuity is lost**.

## Posture
1. **Currentness class is not the same as confidence or trust**
   - Confidence answers how exact an observation seems.
   - Trust answers whether the source is authenticated enough for stronger affordances.
   - Currentness class answers a narrower question: what proving path lets Steward say this view is current through some point?
2. **Currentness class is scoped to one exact view and proving path**
   - A bookmark, cursor, or barrier may speak only for one component, subtree, publisher, subscription, or shell-visible projection.
   - Steward should avoid flattening that into one global `fresh now` myth.
3. **A tiny phase-1 vocabulary is enough**
   - A useful starter shape could look like:
     - `stream-current` — caught up through a point for this exact watch/stream,
     - `read-backed-current` — current through a point backed by a stronger snapshot / consistent-read path,
     - `barrier-current` — current through a point after a narrower explicit delivery/attribution barrier,
     - `unknown` / `degraded` — the path no longer justifies a stronger claim.
   - Implementations may keep richer local detail underneath.
4. **Bootstrap watch and steady-state watch should be allowed to differ**
   - A watch that begins from synthetic current-state entries plus a synced-through marker may justify a stronger initial claim than a later ordinary change stream.
   - Steward should leave room for `initial view is read-backed` while later continuity remains merely `stream-current`.
5. **Bookmarkable does not mean globally freshest**
   - Some systems can promise `all events through this revision were delivered` without promising the revision equals the freshest globally visible state.
   - Steward should preserve that humility instead of laundering every progress marker into universal freshness.
6. **Currentness class may upgrade or downgrade over time**
   - A view may start `unknown`, become `stream-current`, or strengthen after a later snapshot/barrier.
   - Partition, overflow, compaction, reconnect, or lost scope may downgrade the class again.
7. **Actions may require stronger currentness classes than browsing does**
   - Browsing, explaining, and copy-like actions can often tolerate weaker currentness.
   - Some reviewed mutations or stale-sensitive reveals may reasonably insist on stronger read-backed or barrier-backed footing.
8. **Unknown is healthy when the substrate cannot prove more**
   - If an adapter cannot distinguish stream-local progress from stronger read-backed freshness, Steward should say so.
   - Honesty is better than flattering one local watermark into system-wide truth.
9. **The seam should stay descriptive, not policy-omniscient**
   - Currentness class describes what sort of proof the view currently carries.
   - It should not silently become a scheduler, consensus, cache-coherency, or authorization plane.

## Phase-1 non-goals
- a universal global consistency hierarchy for every Steward surface;
- proving one total order over all runtime, shell, and UI observations;
- requiring every substrate to support resumable watches or strong read-backed bootstrap;
- turning currentness class into authority to mutate components;
- pretending a bookmark or progress marker means the same thing on every backend.

## Adjacent docs
- `status-barrier-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `precondition-witness-posture-v0.md`

## References
- REF-K8S-API-CONCEPTS
- REF-ETCD-LEASES
- REF-ETCD-API-GUARANTEES
