# Demand-episode witness schema v0

## Purpose
`ST-DEMAND v0` is the closed packet profile for one accepted activation demand. It names the per-demand episode without claiming custody, work completion, readiness, serving, or effect success.

This profile exists so a cold-start request, callback, connection, message, event, or timer can be receipted as admitted into an episode while stronger facts are still absent or unknown.

## Required fields
- `schema`: constant `ST-DEMAND v0`.
- `demand_id`: stable packet-local demand identifier.
- `cid`: component identity.
- `surface_ref`: activation or traffic surface that accepted the demand.
- `issuer`: closed issuer object with `kind`, `id`, and optional `authority_digest`.
- `demand_kind`: `http_request`, `rpc_call`, `message`, `event`, `connection`, `callback`, `timer`, or `unknown`.
- `episode_state`: `accepted`, `buffered`, `waking`, `delivered`, `accepted_by_runtime`, `completed`, `canceled`, `timed_out`, `shed`, `lost`, or `unknown`.
- `accepted_at_ms`: monotonic packet-time observation.
- `delivery_strength`: `none`, `delivered_unacknowledged`, `accepted_by_runtime`, `completion_reported`, or `unknown`.
- `basis_refs`: bounded references to observations supporting the packet.
- `non_implications`: must include at least `not-readiness`, `not-serving`, `not-custody`, `not-work-completion`, `not-effect-success`, and `not-exactly-once`.

## Optional fields
`deadline_ms`, `runtime_cycle`, `fanout_hint`, `cancellation_state`, `outcome_reason`, `request_context_ref`, `traffic_binding_ref`, `live_channel_ref`, and `retry_attempt_ref`.

## Cross-field rules
- `deadline_ms` must not precede `accepted_at_ms`.
- `accepted_by_runtime` and `completion_reported` delivery strengths require `runtime_cycle`.
- `canceled`, `timed_out`, `shed`, `lost`, and `unknown` episodes require `outcome_reason`.
- Raw bearer material, host process identifiers, raw logs, scrollback, and stronger lifecycle/effect claims are forbidden anywhere in the packet.

## Refusals
A demand witness never proves readiness, serving, custody, work completion, effect success, route authority, losslessness, or exactly-once execution.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/demand-custody-effect-corpus-v0.jsonl`; the checker is `../../tools/steward_work_effect_harness.py`.
