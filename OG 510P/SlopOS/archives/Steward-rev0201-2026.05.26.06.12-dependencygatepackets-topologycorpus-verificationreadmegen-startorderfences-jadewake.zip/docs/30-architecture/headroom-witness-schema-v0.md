# Headroom witness schema v0

## Purpose
`ST-HEADROOM v0` is the closed packet profile for one scoped spendability/headroom observation. It records a budget or window meter without becoming approval, authorization, reservation, retry grant, admission, execution, readiness, serving, or effect success.

## Required fields
- `schema`: constant `ST-HEADROOM v0`.
- `witness_id`: packet witness id.
- `headroom_id`: stable headroom observation id.
- `cid`: component identity.
- `scope_ref`: exact budget/window subject.
- `issuer`: closed issuer object.
- `observed_at_ms`: monotonic observation time.
- `budget_class`: `restart`, `rate_limit`, `quota`, `concurrency`, `seat`, `token_bucket`, `operator_window`, or `unknown`.
- `window_state`: `open`, `exhausted`, `closed`, `reset_pending`, `manual_clear_required`, or `unknown`.
- `ceiling`, `used`, and `remaining`: bounded integer meter values.
- `spendable_now`: boolean present spendability observation.
- `resets_at_ms`: reset/replenish hint, or zero when unknown.
- `manual_clear_required`: boolean manual-clear indicator.
- `limiting_reason`: bounded explanation.
- `basis_refs`: bounded evidence refs.
- `non_implications`: must include `not-authority`, `not-authorization`, `not-approval`, `not-reservation`, `not-retry-grant`, `not-admission`, `not-readiness`, `not-serving`, `not-execution`, and `not-effect-success`.

## Cross-field rules
- Known meters require `remaining == ceiling - used`.
- `spendable_now` requires positive remaining, an open window, and no manual clear requirement.
- `exhausted` requires zero remaining.
- Raw substrate handles, secrets, and stronger lifecycle/effect claims are forbidden anywhere.

## Refusals
A headroom witness never proves approval, authorization, reservation, future spend success, admission, retry permission, execution, readiness, serving, or effect success.

## Executable settlement
The deterministic corpus is `../40-verification/corpora/pressure-admission-corpus-v0.jsonl`; the checker is `../../tools/steward_pressure_admission_harness.py`.
