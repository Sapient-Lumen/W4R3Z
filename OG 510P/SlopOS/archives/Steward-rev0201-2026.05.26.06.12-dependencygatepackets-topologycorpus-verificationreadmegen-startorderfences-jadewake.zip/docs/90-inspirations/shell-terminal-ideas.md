# Shell + terminal ideas for Steward

## High-value ideas
1. **Command frames / blocks with stable IDs**
   - Treat one command plus its output as an explicit navigable unit.
   - That makes copy, bookmark, replay, receipt attachment, and “share exactly this interaction” much easier.
2. **Prompt / input / output zones**
   - Support semantic zones so the terminal can jump between prompts, copy exact command output, and alert when a command completes.
3. **Working-directory side channel**
   - The shell should report cwd changes explicitly instead of relying on guesswork.
4. **Explicit hyperlinks for receipts and docs**
   - Use terminal hyperlinks for digests, transcript slices, component docs, and error locations so the terminal can be rich without parsing arbitrary prose.
5. **Command receipts**
   - Lifecycle-aware commands should be able to emit a small structured sidecar: component id, action, outcome, digest, duration, maybe a transcript pointer.
6. **Plumbing rules**
   - File paths, URLs, digests, component ids, error locations, and object references should be plumbable to editors, viewers, or Steward introspection tools.
7. **Structured shell values**
   - The shell should preserve typed tables/records where possible and only render late.
8. **Marks, decorations, alerts, and failure tinting**
   - Long-running commands should set marks the terminal can navigate by, and failures should be visible at the command-frame level rather than buried in text.
8a. **Exact command verdict chips**
   - One exact command result should be able to drive decorations, “last failure” selection, quick reveal, and watch resolution without forcing every follow-on to inspect full output or raw exit-code trivia.
9. **Recent directories and command history keyed by remote identity**
   - Good terminals remember more than text; they remember which directory and host a command belonged to.
10. **Pane-scoped metadata**
   - Small pane variables like remote host, active component, or last receipt digest can power titles, tooltips, status bars, and safe explicit actions.
11. **Transcript slices**
   - One keystroke should attach the exact input/output/receipt slice for the last command to a bug report or approval request.
12. **Remote-aware semantic transport**
   - Shell integration should survive SSH-like hops rather than being purely local magic.
13. **Glitch-free prompt redraw**
   - Prompt-aware resizing and redraw reduce terminal jank and make rich prompts less fragile.
14. **Inline lifecycle explainers**
   - “Why is this component waiting?”, “why is it quiesced?”, and “what was restarted?” should be answerable inline from receipt/state metadata instead of log archaeology.
15. **Pluggable action chips, not hidden control planes**
   - A digest, component id, or error span can expose explicit actions like “open transcript” or “inspect component”, but only as clear user-invoked operations.
16. **Component + cycle witness chips**
   - If a command starts or inspects a component, the frame can remember the component id and optional runtime-cycle witness so later actions can answer “same run or newer run?” without guesswork.
17. **Stale-action fences for explicit buttons**
   - A visible “stop”, “tail status”, or “explain this wait” affordance can carry the expected cycle witness and fail safely if the component has already restarted.
18. **Trust-marked command frames**
   - Command boundaries should carry a provenance bit or confidence level: explicit shell-reported and nonce-bound is best, scrollback-inferred is second-best, manual selection is fallback.
19. **Lifecycle state/status strip**
   - A pane-local strip or tooltip can show compact Steward state, last receipt, remote identity, and current component without scraping the prompt.
20. **A parseable machine side channel**
   - The shell/terminal stack should have an SSH-friendly, text-oriented observation channel for frame boundaries, pane metadata, notifications, and subscriptions instead of forcing every tool to scrape ANSI output.
21. **Transient service affordances for long-running commands**
   - A shell command like a build, watch, or local server could be promoted explicitly into a transient Steward-tracked service with status, logs, and receipts.
22. **Explicit input semantics**
   - Bracketed paste, richer keyboard events, and click reporting should be treated as first-class protocol choices, not optional hacks.
23. **Shell-owned marker support**
   - The shell itself should happily emit cwd and prompt markers, including prompt-end markers, so terminal UX does not depend on fragile heuristics.
24. **Predictive local echo with visible provisional state**
   - For remote shells over weak links, the terminal could show immediate local editing feedback while visually marking unconfirmed predictions.
25. **Focus-aware command-finish notifications**
   - When a command frame ends, notify only if the pane is unfocused or the command opted in; this is a tiny semantic hook with big payoff.
26. **Roam/sleep tolerant remote sessions**
   - A future remote shell transport could survive IP changes, laptop sleep, and short outages without treating that as magical continuity of the remote workload.
27. **Command-frame to transient-object bridge**
   - A completed shell action should be able to say “this became transient object X” so status and explain UX stay connected to the originating frame.
28. **Latency-aware prompt interaction**
   - Prompt-local click-to-move, safer cursor navigation, and minimal round trips for line editing can make the shell feel local even when it is not.
29. **Semantic fences across hops and multiplexers**
   - SSH, tmux-like layers, shell restarts, or trust downgrades should be able to leave explicit fences in frame metadata so the terminal can say “precision changed here” instead of pretending nothing happened.
30. **Per-frame finish notifications with receipt provenance**
   - Long-running commands should be able to notify on completion using explicit frame boundaries and optional receipt/cycle data, not guessed output endings.
31. **Compact end-of-cycle badges**
   - A frame or pane strip can show “requested stop”, “clean exit”, “signal/crash”, “timeout”, or “policy/resource kill” when Steward knows it, giving users fast context without sending them to logs first.
31a. **Pending-request cards for mediated detours**
   - Choosers, OpenURI launches, approval sheets, and similar detours should be able to appear as small exact request cards with owner frame, requested action, cancel path, and final outcome.
   - That keeps asynchronous UI interactions attributable without inventing a giant callback or portal-object universe.
31b. **Parse-lens rails for weak-but-useful transcript structure**
   - When exact shell objects are unavailable, the terminal should still be allowed to surface file-path, diagnostic, selector, or remote-target candidates through clearly labeled parse lenses.
   - Those rails should stay span-bound, provenance-labeled, and stage-first for risky follow-on actions instead of pretending transcript parsing became lifecycle authority.
32. **Synchronized rendering hints for frame redraws**
   - When a terminal supports DECSET 2026 or equivalent batching, command-frame redraws, prompt refreshes, and status-strip updates can flush atomically and feel much less janky.
33. **Precision fences as first-class UX**
   - Hops, multiplexers, shell restarts, or missing capabilities should leave visible precision fences so the UI can admit “exact command/cwd trust changed here.”
34. **Capability honesty beats TERM folklore**
   - The shell+terminal stack should treat TERM strings and old assumptions as weak hints, then prefer fresh markers and explicit feature reporting before enabling richer affordances.
35. **A tiny feature-reporting handshake**
   - The terminal and shell should be able to exchange a compact view of supported semantics such as prompt markers, cwd refresh, hyperlinks, exact command reporting, keyboard richness, and redraw batching.
36. **Per-hop capability ledgers**
   - Keep a compact live record of which semantic features the current pane/hop path has actually preserved, degraded, or re-reported so same-context spawn, click-to-move, and exact-frame UX key off current truth.
37. **Capability knowledge should stay pane/hop scoped**
   - Capability knowledge should be scoped to the actual terminal/pane/hop path so nested shells, SSH, and multiplexers can say what they preserved and what they dropped.
38. **Safe-ignore rich semantics**
   - New markers and hints should be chosen so unsupported layers mostly ignore them safely, preserving a usable baseline stream rather than exploding.
39. **Explicit resync affordance**
   - When a layer gets confused, the shell/terminal pair should be able to force a fresh prompt/cwd/capability resync instead of relying on magic recovery.
40. **Hyperlink/open-action rules for Steward objects**
   - Receipts, transcript slices, digests, docs, and file/error locations should be routable through explicit hyperlink/open-action rules instead of prose scraping.
41. **Risk-tiered affordances**
   - Low-confidence data may justify copy/open actions; high-confidence data may justify inspect/explain; only explicitly fenced high-confidence targets should light up stop/restart-like actions.
42. **Semantic epochs for stale-action fences**
   - A prompt/cwd/capability resync, nested shell, or SSH hop should be allowed to mint a new semantic epoch so command frames, palette actions, and subscriptions can admit “that target belonged to an older semantic world.”
43. **Fresh resync beats stale certainty**
   - When the shell or terminal gets confused, it should favor a tiny explicit resync that refreshes prompt boundaries, cwd, capability, and trust rather than preserving half-stale markers forever.
44. **Explicit hop chips and remote path strips**
   - The terminal should be able to show the current semantic path: local pane, tmux-like layer, remote host, and whether cwd/markers were preserved.
45. **Same-host same-directory spawn that respects semantics**
   - New panes, tabs, or windows should be able to inherit remote host and cwd when the current hop path proved them explicitly.
46. **Per-hop history and recent-object memory**
   - Command history, recent directories, and recent Steward objects should be allowed to key off the remote/multiplexer path so unrelated contexts do not bleed together.
47. **Small prompt-critical mode baselines**
   - The shell/terminal pair should keep a tiny explicit baseline for things like prompt markers, cwd freshness, bracketed paste, focus-reporting, and prompt-local cursor shape instead of hoping every program leaves the tty in a good state.
48. **Fresh-prompt reassertion**
   - When the shell regains control, it should be able to restate the current semantic baseline so stale state from `ssh`, tmux-like layers, or TUIs does not linger invisibly.
49. **Light resync versus hard reset**
   - A custom terminal should distinguish “refresh prompt semantics”, “reassert baseline”, and “nuclear terminal reset” instead of collapsing them into one mystery ritual.
50. **Self-healing prompt chrome**
   - Cursor shape, prompt-local click behavior, and shell badges should reappear because the shell restated them, not because the terminal guessed them from whatever text happens to be on screen.

51. **Short-lived exact-target anchors**
   - Command frames, receipts, transcript spans, and concrete runs should be allowed to mint opaque short-lived anchors so affordances can point at the exact thing the user means instead of re-parsing visible text.
52. **Selection-to-anchor promotion**
   - Selecting a command or exact output zone should be promotable to a real anchor-backed object so later copy/share/open/explain actions stay bound to the same concrete slice.
53. **Risk-tiered target binding**
   - Low-risk navigation and copy can tolerate weaker anchors or link-detection fallbacks; inspect/restart/stop-the-same-run should require fresher exact anchors and stale fences.
54. **Anchor-aware notifications and chips**
   - A command-finished toast, tab badge, hyperlink, or palette entry should be able to carry an anchor to the exact frame/receipt/run it refers to rather than only focusing the whole pane.
55. **Safe downgrade to human-usable fallbacks**
   - When an exact anchor cannot cross a hop, copy boundary, or unsupported terminal, the system should degrade to plain text or hyperlink while admitting the precision loss.
56. **Observational chrome separate from transcript**
   - Badges, sticky headers, tab titles, side status cells, and progress chrome should summarize live state without pretending to be part of the canonical command/output transcript.
57. **Copy-safe chrome**
   - Copying text or exporting a transcript should default to the underlying command/output/receipt record, not silently include whatever badge or sticky header happened to be visible.
58. **Sticky headers with exact frame anchors**
   - A sticky command header should carry the exact frame anchor, confidence, and freshness bits so scrolling UX stays honest.
59. **Prompt pollution is fallback, not the goal**
   - Prefer richer chrome surfaces for remote host, cwd summary, active component, and progress when the live path supports them; fall back to prompt text only when necessary.
60. **Superseded-grant chips**
   - Exact handles, actions, or receipts tied to reassignable live claims should be able to say `superseded`, `stale holder rejected`, or `ownership moved` instead of failing like a mystery.
61. **Current-owner comparison lanes**
   - Where the lifecycle path can prove a current-owner witness or fence token, the shell should surface it as separate chrome rather than conflating it with general run identity or current health.

## Shell-specific opportunities
- make Steward verbs return structured values first and pretty text second;
- let the shell understand component ids, receipt ids, digests, transcript refs, and cycle witnesses as first-class typed atoms;
- offer a tiny “why” verb family so users can ask why something is waiting, restarting, quiesced, or denied without leaving the shell;
- keep a local notebook of the last interesting lifecycle actions, keyed by receipt digest rather than by brittle log positions;
- offer an explicit “promote to transient service” affordance for commands that turn into watches, local servers, or background loops;
- let trusted command-frame metadata make re-run, copy-exact-output, “open transcript for that command”, and “act on the same concrete run” safer and less guessy;
- carry per-host and per-hop command history, cwd, and recent-object memory across terminals;
- let remote-aware shell transports preserve semantic markers, trust levels, and capability ledgers instead of collapsing everything back to raw PTY bytes;
- use synchronized rendering as an optional redraw hint for prompt/frame/status updates instead of making users watch intermediate repaint noise;
- keep a visible “precision fence” model so the shell can admit when a hop, multiplexer, or fallback path downgraded what it knows about cwd, command lines, trust, or capabilities;
- let trusted command-finish signals carry compact end-of-cycle results and receipt pointers when a command launched or inspected a Steward-managed component;
- let frames/receipts surface tiny explicit action chips that stay target-bound, user-invoked, and stale-fenced instead of guessing what the pane “means”;
- use hyperlink/open-action rules to route receipts, digests, transcript refs, and docs to the right local or remote tool without inventing prose parsers;
- let clearly labeled parse lenses surface weak-but-useful candidates such as remote files, diagnostics, or target selectors when exact shell objects are absent, while keeping mutating follow-on actions staged and reviewable;
- let the shell request or refresh a tiny capability handshake so richer UX comes from observed support instead of TERM folklore;
- let the shell/terminal pair mint a fresh semantic epoch after hops, resync, or shell reset so exact actions can stale-fence honestly.
- let the shell surface `superseded grant`, `stale holder rejected`, or `current owner moved` chips when a reassignable live claim can prove a fence token or current-owner witness.
- let the terminal surface current remote host, cwd summary, active component, warning/progress state, and sticky command headers in a separate chrome lane instead of forcing all live context into the prompt or transcript.
- keep transcript export and ordinary copy semantics anchored to the underlying frame/receipt truth, with chrome snapshots only when the user asks for them explicitly.
- let the shell attach compact provenance/confidence/trust metadata to command frames, cwd reports, and explicit targets so richer affordances can stay honest about what they really know.
- let a finished frame upgrade from approximate to exact metadata when the shell later reports a higher-confidence command line, exit status, or receipt link.
- let exact command/output selections promote into short-lived target anchors so later copy/open/explain/act-on-same-run affordances stay bound to the same concrete object instead of whatever text is still visible.
- let prompt-local predictive feedback stay visibly provisional until the remote shell confirms it, so weak-link UX can improve without making tentative state look authoritative.
- let the shell/terminal pair record whether a command-frame field was provisional, later confirmed, revised, or withdrawn.
- let execution-ground cards and receipt chips distinguish `ready now`, `warming toward stable`, `stable`, and `stability unknown` when the lifecycle adapter can prove a post-ready dwell window.

## Big architectural move
Treat the shell+terminal pair as a first-class Steward client. That means:
- the shell knows when it invoked a lifecycle action;
- the shell can declare trusted command frames and their confidence level;
- the terminal knows where commands and outputs begin/end;
- both can preserve command frames, receipt refs, and explicit action targets as navigable objects;
- both can admit when precision or capability was downgraded by a hop, a multiplexer, or a fallback path;
- both can negotiate a small observed capability view instead of pretending compatibility folklore is the same as exact support;
- both can mint and consume tiny exact-target anchors so receipts, transcript spans, command frames, and concrete runs can survive beyond a single visible text scrape.

## Why this matters
If Steward wants to feel like a real next-generation operating environment, the shell and terminal cannot be an afterthought. They are where users will actually experience the difference between:
- ambient Unix folklore, and
- explicit lifecycle-aware ergonomics.

The opportunity is to make the terminal feel **smarter, safer, and more exact** without turning it into a hidden authority channel.


46. **Visible provisional badges for latency-hiding UX**
   - Predictive local echo, inferred command metadata, or pending finish cues should be able to show a small provisional badge until the shell confirms them.
47. **Commit / revise / withdraw transitions for shell metadata**
   - Exact command lines, exit status, and receipt links should be allowed to upgrade or correct earlier tentative frame metadata instead of pretending the first guess was perfect.
48. **Prompt-local optimism, transcript-level honesty**
   - The shell can feel faster by offering prompt-local feedback early, but the durable transcript should still remember what was tentative versus confirmed.
49. **Low-latency remote editing without false authority**
   - Remote shell transports should explore immediate local editing feel, but stop/restart/explain actions should stay fenced until explicit confirmation arrives.

## Attention and progress ideas worth stealing
- Add a **watch this command** affordance that binds to the current command frame and can later escalate from nothing → badge → bell → toast based on duration, focus state, and user preference.
- Let command-finished and needs-input hints target the frame, not just the pane, so the user can jump straight to the relevant interaction instead of a generic bell.
- When the capability handshake says progress is supported, let long-running tasks publish a tiny tab/taskbar progress ring or indeterminate busy state; otherwise degrade to ordinary status text.
- Keep every attention hint explicitly suppressible by kind, source, or focus state so the smart terminal does not become an annoying terminal.
- Make stale attention visible: if a hop changed, a semantic epoch rolled, or trust dropped, old “job finished” chips should admit they refer to an older semantic world rather than pretending they still apply.

References: REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE, REF-ITERM2-SHELL-INTEGRATION, REF-KITTY-DESKTOP-NOTIFICATIONS, REF-WEZTERM-NOTIFICATION-HANDLING, REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-FEATURE-REPORTING.

## Fresh ideas from the context-handoff pass
- **Attach last failure as evidence, not as paste**: the shell/terminal should be able to hand off a bounded exact bundle for the last failed command—including command line, exact output, exit code, duration, cwd, witnesses, and receipt refs—without exporting unrelated scrollback.
- **Redaction-before-share should be part of the affordance**: before a handoff leaves the local pane, users should be able to drop or mask exact fields such as cwd, host path, or selected output lines without breaking the bundle shape.
- **Collapsed frame summaries should still be anchorable**: a compact summary card is great UX, but it should still point at the exact frame/output/receipt record underneath instead of becoming the only surviving truth.

References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1110, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh ideas from the repair-gate pass
- **attach last failure bundle**: one keystroke should gather the most recent failed command or component cycle with exact output slice, end cause, restart/cooldown state, and any repair-required note instead of asking users to hunt through scrollback.
- **quieted-for-a-reason chrome**: when Steward has stopped retrying, show a tiny freshness-scoped badge like cooling down or repair required, with an exact anchor to recent cycles rather than a mysterious dead prompt.
- **retry with explanation, not blind rerun**: higher-risk “try again” affordances should first show what changed since the repair gate, what witness/run they point at, and whether the action is a true clear, a config revision, or just a plain rerun.

References: REF-VSCODE-UPDATE-1106, REF-ITERM2-COMMAND-SELECTION, REF-K8S-POD-LIFECYCLE, REF-SMF-MAINTENANCE.


## Fresh ideas from the launch-context pass
- **Paste firewall, not just bracketed paste**: pasted control characters, suspicious newlines, or remote clipboard surprises should be visibly fenced, previewable, or downgraded instead of being treated as ordinary typed intent.
- **Typed plumb targets everywhere**: receipts, digests, cycle witnesses, transcript refs, file paths, and remote host hints should travel as typed objects so the custom shell+terminal can open, inspect, route, and share them without prose scraping.
- **Remote-aware comfort that stays observational**: kitty-style remote shell integration is a great ergonomic idea, but Steward should preserve host/path/capability truth as explicit pane metadata rather than ambient environment myth.
- **Prompt-local editing niceties are worth stealing early**: click-to-move, exact last-command paging, precise frame search, and focus-aware notifications are small features that make a terminal feel radically better without widening authority.

References: REF-GHOSTTY-RELEASE-130, REF-KITTY-SHELL-INTEGRATION, REF-KITTY-SSH, REF-KITTY-DESKTOP-NOTIFICATIONS, REF-PLAN9-PLUMBING.

## Fresh ideas from the lifecycle-fabric pass
- **Capability ledger per hop**: keep a tiny visible ledger for each pane/hop path recording which semantic features are proven, absent, degraded, or stale-fenced, so rich UX comes from current truth instead of terminal folklore.
- **Frame-local explainers**: any command frame that launched, repaired, or inspected a component should be able to open a terse “why is it waiting / cooling down / repair-required?” explainer bound to the same exact frame, receipt, and run witness.
- **Receipts as typed terminal objects**: receipt ids, digests, cycle witnesses, transcript refs, and component ids should travel through the shell and terminal as typed plumbable objects instead of prose snippets.
- **Remote semantic sidecar**: preserve command markers, confidence, and target anchors across SSH-like hops with an explicit semantic sidecar when possible, and admit precision fences when the path falls back to raw PTY bytes.
- **Paste firewall**: detect and visibly fence control characters, suspicious multiline pastes, and mixed-origin clipboard payloads before they hit the line editor.
- **Open last output exactly**: kitty's pager flow is a great precedent — once command frames are exact, one keystroke should open the last command's output, not an approximation scraped from scrollback.
- **Per-frame notifications, not pane-only bells**: completion, needs-input, and warning cues should point to the exact frame anchor and degrade cleanly when that precision is unavailable.
- **Ignore-unknown terminal semantics by default**: richer Steward escape sequences should follow the same safe-ignore discipline as mainstream terminal compatibility guidance so mixed environments fail by losing enhancement, not by corrupting the session.

References: REF-KITTY-SHELL-INTEGRATION, REF-KITTY-SSH, REF-KITTY-DESKTOP-NOTIFICATIONS, REF-PLAN9-PLUMBING, REF-GHOSTTY-RELEASE-130, REF-FISH-TERMINAL-COMPAT.


## Fresh ideas from the dynamic-condition and remote-comfort pass
- **Frame-local “waiting on …” explainers**: a shell frame that launched or inspected a component should be able to show a terse exact explainer such as waiting on network, waiting on peer, or waiting on operator instead of a generic dead-looking prompt.
- **Remote comfort kit**: same-cwd spawn, jump-to-prompt, open-last-output-exactly, and click-to-move are worth stealing early because they make the terminal feel dramatically better without widening lifecycle authority.
- **Notification callbacks bound to exact frames**: an SSH-capable notification path should be able to focus or reveal the exact frame it refers to, not merely ring the whole pane.
- **Paste firewall with explicit downgrade choices**: pasted control bytes, suspicious multiline payloads, and mixed-origin clipboard content should be previewable, strip-able, or force-literal before they reach the line editor.

References: REF-KITTY-SHELL-INTEGRATION, REF-GHOSTTY-SHELL-INTEGRATION, REF-KITTY-NOTIFY, REF-GHOSTTY-RELEASE-130, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.


## Fresh ideas from the transition-helper pass
- **Helper-phase cards**: if a command triggers prepare, drain, cleanup, or repair helpers, let the frame show compact exact helper cards with outcome, duration, and transcript refs instead of forcing log dives.
- **Scoped command memory shelves**: keep recent commands, recent directories, and recent Steward object refs keyed by host or hop path, then show clearly when the shelf is remembered context rather than live confirmed state.
- **Paste firewall modes**: let the user switch between normal paste, literal-only, strip-control, and preview modes; bracketed paste is the floor, not the whole safety story.
- **Same-context spawn only when proven**: offer “new pane here” or “re-run on same remote host” only when the current hop lineage and capability ledger say that context was explicitly preserved.

References: REF-ITERM2-ONE-PAGE, REF-KITTY-SSH, REF-KITTY-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130, REF-XTERM-BRACKETED-PASTE.

58. **Semantic-zone navigation and exact selection**
   - Prompt/input/output zones should power “jump to previous prompt”, “select exact last output”, and “copy just this frame slice” without brittle screen scraping.
59. **Palette actions from exact semantic anchors**
   - A command palette should offer explicit actions for the current frame, receipt, or component only when the target binding is exact and fresh.
60. **Child-spawn descriptor audits**
   - The terminal and shell stack should be able to prove which descriptors/handles a launched child inherited so remote comfort features do not quietly widen authority.
61. **Safe-by-default child launch**
   - New panes, helpers, and shell-launched tools should inherit only explicit stdio and reviewed side channels, not whatever debug sockets or control pipes happened to be open.
62. **Semantic-zone inspector**
   - When command framing goes wrong, a debug view should show the current prompt/input/output zones, their provenance, and any precision fences instead of leaving users to guess.


## Fresh ideas from the activation-checkpoint pass
- **Checkpoint ribbon bound to exact frames**: when a command launches, restarts, or inspects a component, show a tiny sequence like delivered → control-ready → serve-ready → degraded or draining, anchored to the exact frame and run witness instead of a generic pane badge.
- **Jump-to-checkpoint**: semantic prompt and output zones should make it possible to jump straight to the frame where a component first became ready, later degraded, or finally stopped.
- **Descriptor-safe same-context helpers**: terminal actions like new pane here, open pager here, or remote rerun here should only appear when the current hop path and child-spawn audit prove that reviewed context survived without leaking extra descriptors.
- **Observational session variables**: let shells publish bounded user/session variables such as current branch, component id, or remote hop label into chrome and palette filtering without letting those remembered values masquerade as reviewed authority.

References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SCROLL-TO-PROMPT, REF-GHOSTTY-RELEASE-130, REF-KITTY-SHELL-INTEGRATION, REF-ITERM2-VARIABLES.


## Fresh ideas from the session-variable pass
- **Scoped context chips**: let shells publish tiny observational variables like remote hop label, current component id, branch, or last receipt digest into chrome and palette filtering, but keep those values visibly tied to publisher, hop path, and freshness.
- **Exact selection from semantic marks**: when semantic prompt/input/output zones are live, right-click or palette affordances should be able to select the current command or just its output exactly instead of scraping nearby text.
- **Remembered shelves with truth labels**: recent directories, recent component ids, and recent command shelves should show whether they are live confirmed state, publisher-reported context, or merely remembered convenience.
- **Transaction-aware busy badges**: if a runtime can honestly bracket in-flight work, the terminal can show a tiny busy/draining chip bound to the exact frame without pretending to know more than the component reported.

References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-ITERM2-VARIABLES, REF-LAUNCHD-SOCKETS, REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END.

## Fresh shell ideas from the activity-bracket pass
- **Frame-local busy/draining badges**: if a component or command can honestly bracket work, show that on the exact frame or pane instead of as a vague global spinner.
- **Quiet command-finished notifications while work is bracketed**: a shell can return to prompt before the real work is durably done; bracket-aware notification logic can avoid lying about completion.
- **Jump to active work**: semantic prompt zones plus exact activity state should make it easy to hop straight to the last still-busy command frame or component pane.
- **Busy state with freshness and publisher**: shell chrome should say who reported busy/draining state and when, so remembered context does not masquerade as live truth.

References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130, REF-ITERM2-STATUS-BAR.

## Fresh shell ideas from the stop-deferral pass
- **Delay countdown chips**: if a component or command has a real bounded stop-deferral window, show the remaining budget on the exact frame or pane instead of an ambient spinner.
- **Cut-through explanation inline**: when stronger policy wins over a deferral request, surface that as a tiny exact explanation like operator stop won, timeout expired, or repair gate cut through.
- **Explain waiting from the current frame**: palette or right-click actions should answer what is being delayed, which leaf asked for it, and what exact witness or handle owns it.
- **Remembered busy is not live busy**: stale status-bar chips or remembered shell variables should visibly decay once the exact deferral handle or current frame anchor is gone.

References: REF-SYSTEMD-INHIBIT-MAN, REF-XDG-PORTAL-INHIBIT, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130.

63. **Stale chrome should look stale**
   - Busy badges, progress rings, and waiting chips should visibly downgrade to last-known or stale once their publisher, renewal, or frame anchor is gone.
64. **Remembered context needs truth labels**
   - Recent cwd, remote host, and active-component hints should distinguish live confirmed, publisher-reported, and remembered convenience state.
65. **Renew-or-clear progress**
   - Progress bars and pane status strings should either receive fresh updates from an exact publisher or visibly expire rather than pretending the last percentage is current truth.
66. **Resync from the stale badge**
   - When a shell/terminal affordance admits stale or older-epoch state, it should make refresh or reveal-latest one click away.

## Fresh shell ideas from the freshness-decay pass
- **Live-until chips**: every busy/progress/delay badge can carry a tiny “live until” or “updated 8s ago” affordance bound to the same exact frame.
- **Grey-not-green stale comfort**: remote-aware cwd, component, and hop chips should gracefully decay in color/state before they disappear, so the user can tell remembered comfort from live truth.
- **Snapshot-aware status bars**: terminals with pane status metadata should treat those fields as snapshots and show age/publisher when it matters.
- **Refresh from here**: a stale frame or badge should be able to ask for the latest status/subscription snapshot without turning the terminal into an ambient control plane.

References: REF-WEZTERM-PANE-INFORMATION, REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-STATUS-BAR, REF-WEZTERM-PANE-USER-VARS, REF-SD-WATCHDOG-ENABLED.

## Fresh shell ideas from the trust-and-targeting pass
- **Trusted rerun affordances**: let the shell expose “rerun”, “explain”, or “attach context” actions only when the current command frame has enough provenance to deserve shortcut authority; otherwise degrade to inspect-and-confirm.
- **Named activation receipts**: when a launch or activation path handed a component reviewed listeners, service names, or other startup material, make that visible in a compact receipt so restart/debug flows do not depend on folklore about inherited process state.
- **Target-anchored open actions**: treat click/open affordances like routed actions over exact frame, output, receipt, file, or URL targets, not regex guesses over paint on glass.
- **Speculative local echo in its own lane**: predictive input and low-latency shell comfort are worth stealing, but they should render as visibly provisional until the remote or supervised truth confirms them.
- **Same-context comfort without same-context authority**: use explicit cwd/prompt/user-var reports to make new panes, tabs, and remotes feel seamless, while still saying when the shell only remembers context rather than knowing it is still live.

References: REF-VSCODE-SHELL-TRUST, REF-LAUNCH-ACTIVATE-SOCKET, REF-KITTY-OPEN-ACTIONS, REF-WEZTERM-HYPERLINKS, REF-OSC133-SPEC, REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-MOSH-PAPER.

## Fresh shell ideas from the named-activation and semantic-history pass
- **Line-local open routing**: when the user clicks a file path, stack frame, receipt id, or explainer anchor, the terminal should route using the exact line-local cwd/anchor metadata rather than the pane's newest cwd guess.
- **Semantic inspector overlay**: add a developer mode that paints prompt/input/output zones, active frame ids, provenance, and precision fences directly on the terminal so integration bugs are obvious.
- **Per-action context inheritance toggles**: allow new tab, split, window, and rerun actions to inherit cwd/hop context independently, with the resulting pane labeled current, reported, or remembered.
- **Prompt-click editing when semantics are live**: if the active prompt has real semantic boundaries, clicking inside it should move the cursor or select the exact prompt-local region instead of relying on terminal text heuristics.
- **Lifecycle receipts should surface named activation material**: if a command launched or restarted a component, its frame should be able to show the exact activation keys or labels that were delivered so later debugging is grounded in receipts, not memory.

References: REF-ITERM2-SEMANTIC-HISTORY, REF-GHOSTTY-RELEASE-130, REF-SD-LISTEN-FDS-WITH-NAMES, REF-LAUNCH-ACTIVATE-SOCKET.



## Fresh shell ideas from the escrow and command-guide pass
- **Sticky command headers tied to exact frames**: when the viewport cuts through a command's output, keep a compact sticky header with the exact command text, frame id, exit/result summary, and jump-back affordance.
- **Guide rails with truth labels**: a thin rail beside each semantic command frame can show running, exited, degraded, escrowed, or stale state, but the rail should also say whether that truth is live, manager-reported, or remembered.
- **Attach this exact command interaction**: make it one gesture to attach the precise command line, selected output span or full output, exit status, cwd/hop context, and receipt refs to an explainer, bug report, or teammate handoff.
- **Open-versus-focus split in the UI**: command actions should first resolve the exact target they mean to open; only after that should the UI optionally carry a platform activation token or focus request. The target descriptor and the foregrounding authority should never silently collapse into one field.
- **Escrow-aware lifecycle chips**: if a component stopped after escrowing narrow continuity, the terminal can show a tiny `escrowed` or `restartable from continuity` chip bound to the exact lifecycle receipt without pretending that the old process is still alive.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1106, REF-GHOSTTY-RELEASE-130, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-FUCHSIA-PROCESS-LIFECYCLE, REF-FUCHSIA-STOP-IDLE.


## Fresh shell ideas from the activation-receipt and exact-command-details pass
- **Activation receipt chips on the frame that launched the service**: when a command starts or restarts a component, its frame should be able to show the delivered activation keys, acknowledgement state, and concrete runtime-cycle witness without dumping a giant descriptor table.
- **Command-detail hovers and sticky cards**: every semantic command frame should be able to reveal cwd, host/hop lineage, start time, duration, exit code, receipt refs, and hidden-output reveal from one exact object.
- **Target first, focus second**: clicks and palette actions should resolve an exact file/receipt/frame target first, then optionally attach a foreground token or raise request as a second explicit field.
- **Repair from the guide rail**: when a frame is degraded, stale, or lacks acknowledgement, the guide rail should offer inspect, refresh, reveal latest receipt, or compare with current run instead of making the user grep scrollback.
- **Burst-failure summaries, not retry numerology**: if repeated failures matter, the shell should summarize burst window, last sustained rate, and repair-gate state in human language instead of exposing a bag of raw manager counters.
References: REF-SD-NOTIFY, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-DESKTOP-NOTIFICATIONS-SPEC, REF-VSCODE-UPDATE-1109, REF-VSCODE-UPDATE-1110, REF-ERLANG-OTP-SUPERVISOR.

## Fresh shell ideas from the context-inheritance pass
- **Same-context launch sheet**: when opening a tab, split, or rerun, show a compact sheet that names inherited cwd, domain, hop path, and profile selector before execution when the action is high-value.
- **Current/reported/remembered badges on new panes**: label inherited context quality directly in the tab title or guide chrome for the first frame.
- **Per-action inheritance defaults**: let users keep different defaults for new tab, new split, rerun, and “open shell here” actions instead of one terminal-wide inheritance rule.
- **Fallback toast with exact reason**: “remote domain unavailable; opened locally” is much better than quiet context drift.
- **Safe-mode launches from untrusted roots**: if a workspace or directory is not trusted, default to a stripped profile and require an explicit upgrade to inherit richer shell context.
References: REF-GHOSTTY-RELEASE-130, REF-WEZTERM-SPAWNCOMMAND, REF-WEZTERM-LAUNCHING-PROGRAMS, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1109.

## Fresh shell ideas from the command-guide and prompt-click pass
- **Guide rail with quality badge**: show a subtle vertical rail beside each exact frame and let it advertise trusted, approximate, stale, or guessed quality at a glance.
- **Ignore-list for noisy command chrome**: support a reviewed list of commands or frame classes that should not pin sticky headers or persistent rails.
- **Sticky header opens exact frame card**: clicking the sticky header should reveal one exact object with command text, cwd, hop path, start time, duration, exit/result, receipt refs, and any repair-required state.
- **Prompt-local cursor movement**: within a live prompt zone, clicking should move the cursor and preserve shell editing state; outside that zone, clicks should fall back to selection or exact-frame actions.
- **Auto-mark fallback styling**: if prompt marks were synthesized by the terminal rather than reported by the shell, render them differently and require stronger confirmation before rerun-sensitive actions.
- **Guide-debug view**: provide a developer-facing inspector showing prompt/input/output spans, anchor ids, semantic epoch, capability path, and why a frame is ignored or visible in sticky chrome.

- **Spawn recipe palette**: a command palette or hover sheet for tabs/splits/reruns/helper shells that shows program/profile/domain/cwd choices explicitly, with defaults like `clean`, `same domain`, `default domain`, `current-frame cwd`, `last-reported cwd`, and `root cwd`.
- **Launch-source badges**: when a new shell opens, show a tiny badge or receipt such as `cwd: last-reported`, `domain: current-pane`, `env: clean`, or `profile: build-sandbox` so convenience state never masquerades as exact truth.
- **Explain fallback instantly**: if same-context launch fell back to home directory, local domain, or a safer profile, surface that immediately near the new prompt instead of making the user reverse-engineer what happened.


## Fresh ideas from the spawn-palette pass
- **A real spawn palette**: one command palette should let users create tabs, splits, helper shells, reruns, and domain jumps from reviewed recipes rather than retyping command strings.
- **Disabled entries with reasons**: do not hide policy-bounded or trust-trimmed launches; show them greyed out with an exact reason and, when appropriate, the extra confirm/trust step that would unlock them.
- **Dynamic groups from explicit sets**: profile-, domain-, and recent-context groups can be generated at runtime as long as the source set is explicit and the expanded entries still resolve to reviewed selectors.
- **Launch receipts right in the UI**: after a palette launch, the terminal should be able to answer which selector ran, what context was inherited, and what was downgraded.
- **Presentation is not authority**: labels, icons, badges, and keyboard shortcuts are important UX, but they should never be mistaken for the actual launch recipe.

References: REF-WEZTERM-LAUNCH-MENU, REF-VSCODE-TERMINAL-PROFILES, REF-WINDOWS-TERMINAL-COMMAND-PALETTE, REF-GHOSTTY-RELEASE-120, REF-KITTY-ACTIONS.

## Fresh ideas from the remembered-shelf pass
- **Remembered shelves with exact truth labels**: recent commands, recent directories, and recent Steward objects should say whether they are remembered, shell-reported, manager-reported, or freshly confirmed.
- **Reveal-from-history before act-from-history**: a weakly anchored history entry should offer reveal, copy, paste, or “open details” before it offers same-run restart, stop, or inspect actions.
- **Pinned shelves by host or hop path**: let users star a directory, command, or object ref inside the explicit host/hop scope it belongs to instead of smearing favorites across unrelated contexts.
- **Current-command surface everywhere**: right-click, palette, and sticky-header actions should all be able to mean “the current exact command frame or its exact output”, not “whatever text near the cursor looks recent”.
- **History cards, not just history lines**: clicking a recent command should be able to reveal a compact card with command text, last known cwd, host/hop scope, last exit/result, and the safest next actions.

References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1106, REF-ITERM2-ONE-PAGE, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.


## Fresh ideas from the transcript-landmark pass
- **Landmark palette with exact cards**: give the terminal one palette for marks, failure landmarks, user annotations, receipt landmarks, and pinned output spans; selecting an entry should reveal an exact frame/span card instead of just scrolling vaguely nearby.
- **Annotate-this-span gesture**: selecting output should offer “annotate this span” so users can leave notes on the precise evidence slice they are debugging.
- **Watch-this-command from a landmark**: after starting a long command, let the user bind a focus-aware watch to its exact landmark so completion or failure alerts stay tied to the right frame.
- **Provenance-colored landmark chips**: shell, manager, user, and guessed landmarks should render differently and gate risky follow-on actions differently.
- **Optional local persistence for curated landmarks**: allow stars or pinned annotations to survive restart only when the user asked for that, and keep host/hop/freshness labels attached.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1066, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS, REF-ITERM2-MENU-ITEMS, REF-ITERM2-FEATURES.

## Fresh ideas from the workspace-snapshot pass
- **Restore badges with exact truth**: when the terminal reopens, every pane or tab should be able to say `reconnected`, `revived`, `content only`, `layout only`, `downgraded`, or `failed` instead of one mushy “session restored” banner.
- **Save this debugging cohort**: let the user snapshot the exact mix of log panes, helper shells, command cards, and receipts they are using for an investigation, then reopen that cohort later through reviewed selectors.
- **Partial-restore explainer**: after startup or crash recovery, show a compact card listing which panes reattached to live processes, which were relaunched cleanly, and which could not return because the domain, cwd, or trust state changed.
- **Layout shelf separate from process shelves**: remembered workspaces should live beside remembered commands and directories, but they should stay obviously structural rather than pretending to be a live process inventory.
- **Default startup workspace with policy labels**: opening a favorite layout on launch can be great as long as the UI also shows which selectors, cwd source classes, and domains each pane came from.
References: REF-VSCODE-TERMINAL-ADVANCED, REF-WINDOWS-TERMINAL-STARTUP, REF-ITERM2-SESSION-RESTORATION, REF-ITERM2-ONE-PAGE, REF-WEZTERM-MULTIPLEXING.



## Fresh shell ideas from the replay-gate pass
- **Review-before-run banners**: restored or remembered commands should reopen behind a compact banner or card that says what will run, where, why it is being offered, and what context fields are remembered versus freshly confirmed.
- **Suspended command panes**: treat heavyweight commands as first-class panes/cards that can sit in a layout pending explicit launch, with later exit status and rerun affordances on the same object.
- **Replay diff badges**: when a replay will use a downgraded cwd, different domain, stripped profile, or fresher selector than the original command, show the delta before execution instead of quietly running.
- **Launch-now / inspect / export / discard quartet**: every pending command surface should make the safe next actions obvious instead of forcing users back into raw copy-paste or ambient history hacks.
- **Inspector/tool panes that are not pretending to be shells**: exact repair summaries, receipt cards, multiple-target selectors, and command explainers can live as first-class panes or floating surfaces without pretending they are part of the canonical transcript.
References: REF-ZELLIJ-FEATURES, REF-ZELLIJ-SESSION-RESURRECTION, REF-ZELLIJ-PLUGINS, REF-VSCODE-UPDATE-1109, REF-WEZTERM-LAUNCH-MENU.


## Fresh ideas from the chooser-surface pass
- **A real built-in file/object chooser**: one picker should browse files, directories, remembered Steward objects, and exact transcript targets from the current pane context without collapsing everything into shell text.
- **Visible-output chooser with exact upgrades**: selecting a path-looking span, receipt id, or line-number reference from output should try to upgrade to an exact anchor or reviewed object and visibly say when it cannot.
- **Chooser action rail**: once something is selected, the terminal should offer explicit next steps like `open`, `open here`, `attach`, `copy selector`, `paste text`, or `pin on shelf`, rather than guessing one default action.
- **Chooser-mode safety**: modal chooser key tables should show a visible indicator and absorb unrelated keys instead of leaking them into the underlying shell session.
- **Picker pipes for two-dimensional workflows**: a chooser should be able to hand its exact result to an inspector pane, replay review card, or helper launcher without forcing the user back through raw prompt text.
References: REF-KITTY-HINTS, REF-KITTY-CHOOSE-FILES, REF-ZELLIJ-FILEPICKER, REF-ZELLIJ-PLUGIN-PIPES, REF-GHOSTTY-RELEASE-130, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.

## Fresh shell ideas from the assist-surface pass
- **Quick fix on the frame rail**: if a command failed in a known way, show a tiny affordance on that exact frame rail that opens repair choices, explanation, and output selection.
- **Explain-this-suggestion**: every suggestion should have a details view that shows its anchor, freshness, confidence, and whether it came from shell semantics, manager knowledge, extension logic, or a weaker heuristic.
- **Typed assist palettes**: one palette command can open to `current-line`, `recent-commands`, `quick-fixes`, or `tasks`, but those buckets should stay visibly distinct.
- **Dead-key-safe assist mode**: when a chooser or quick-fix menu is active, unrelated keys should be ignored or handled by the mode instead of leaking into the underlying prompt.
- **Downgrade from exact recipe to text only**: when a reviewed repair recipe is unavailable, the terminal can still offer raw shell text, but it should label that downgrade explicitly.
- **Assistant-free by default, assist-rich by design**: keep the terminal brilliant with exact anchors and reviewed recipes before reaching for heavyweight agent behavior.

References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1102, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS, REF-WEZTERM-AUGMENT-COMMAND-PALETTE, REF-GHOSTTY-RELEASE-130.



## Fresh ideas from the surface-diagnostics pass
- **Explain-this-surface cards**: every smart affordance should have a one-step detail card that says what enabled it, what exact anchor it is bound to, which fields are fresh versus remembered, and what policy narrowed the available actions.
- **Affordance health strip**: a compact per-pane or per-frame strip could show shell type, shell-integration quality, current cwd source class, trust/provenance tier, and downgrade fences without forcing users into hidden debug menus.
- **Semantic debug overlay**: when command framing goes weird, overlay prompt/input/output zones, anchor ids, and precision fences directly on the transcript so shell authors can fix the real seam instead of guessing from bytes.
- **Disabled-with-reason menus everywhere**: replay, quick-fix, spawn, and chooser menus should keep unavailable actions visible with a short reason rather than silently removing them.
- **Freshness-aware inspector history**: keep a tiny history of why an affordance changed from rich to basic to stale so users can see whether a hop, shell restart, or policy fence caused the downgrade.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1103, REF-ITERM2-FEATURE-REPORTING, REF-ITERM2-ESCAPE-CODES, REF-GHOSTTY-RELEASE-130.


## Fresh shell ideas from the session-injection pass
- **Command staging lane**: when an assist surface, replay card, or palette wants to affect the shell, stage the exact command in a distinct editable lane or block before execution rather than immediately typing-and-running on the user's behalf.
- **History provenance chips**: after a UI-originated command runs, show whether it was kept out of shell history, recorded normally, or stored only in a Steward-side remembered shelf.
- **Load env into subshell first**: make temporary environment overlays default to a clearly labeled child shell, with one explicit upgrade path for applying them to the parent session.
- **Clear/replace environment rail**: if the UI loaded a bundle into the current session, keep a tiny chip or rail action nearby to inspect, clear, or replace that overlay later.
- **Remote helper setup receipt**: when richer remote features depend on tmux, wrapper setup, or rcfile hooks, show the exact helper path and the current downgrade state instead of one vague “remote mode” badge.
References: REF-VSCODE-UPDATE-1108, REF-WARP-ENV-VARS, REF-WARP-SSH, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh shell ideas from the clipboard-surface pass
- **Command-aware copy everywhere**: right-click, palette, sticky-header, and chooser flows should all be able to mean “copy this exact command” or “copy this exact output slice”, not just “copy whatever text is selected”.
- **Paste preview lane**: when pasted content is multiline, privileged-looking, or selector-backed, stage it in a small editable lane with provenance and expected mode before execution.
- **Remote clipboard policy chip**: show when a pane is allowed, denied, or downgraded for OSC 52 or richer clipboard operations, with one-step diagnostics explaining why.
- **Selector-first copy**: if a path, receipt id, or Steward object can survive as a structured selector, keep that option alongside plain text copy rather than collapsing structure too early.
- **Clipboard downgrade labels**: when an exact frame copy becomes only raw text because of host boundaries or app limits, say so explicitly instead of pretending the richer meaning survived.
References: REF-KITTY-CLIPBOARD, REF-GHOSTTY-OSC52, REF-WINDOWS-TERMINAL-INTERACTION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-VSCODE-SHELL-INTEGRATION, REF-XTERM-BRACKETED-PASTE.

## Fresh shell ideas from the transfer-surface pass
- **Transfer rail on exact targets**: when a file, receipt attachment, or remote object is selected, offer explicit `open local`, `edit local+sync`, `download`, `attach`, `copy path text`, and `cancel` actions instead of one ambiguous default.
- **Drop-to-stage instead of drop-to-run**: dragging a file into the terminal should be able to land in a reviewed staging lane or chooser card before it mutates the prompt.
- **Transfer receipts with direction and helper path**: every richer transfer should be able to say what moved, in which direction, which anchor or cwd source class it used, and whether shell integration, hyperlink parsing, or a terminal-native protocol powered it.
- **Remote-file cards, not invisible magic**: clicking a file-looking span in remote output should open a compact card that distinguishes `open`, `edit`, `download`, and `copy selector`, with downgrade text only when exact remote-file semantics are unavailable.
- **Nested-hop precision badges**: show whether a transfer target is exact for the current hop path, first-hop only, or plain text only.
References: REF-KITTY-TRANSFER, REF-KITTY-REMOTE-FILES, REF-ITERM2-SHELL-INTEGRATION, REF-VSCODE-TERMINAL-BASICS, REF-WINDOWS-TERMINAL-TIPS.


## Fresh shell ideas from the automation-surface pass
- **Automation receipt cards**: when a script or helper CLI acts, show a tiny card with target, action class, control path, freshness, and downgrade information.
- **Dry-run / explain / run trio for scripted actions**: let automation surfaces preview what they would target before they mutate anything, especially for spawn, inject, and focus actions.
- **Action-class policy chips**: per-pane or per-workspace chips could say whether query, focus, spawn, inject, or transfer automation is allowed, denied, or degraded.
- **Exact-target automation palette**: one palette should let users and tools act on reviewed selectors, frames, receipts, and panes without falling back to “current pane” folklore.
- **In-flight automation shelf**: keep visible long-running scripted requests with cancel/retry/details instead of making the user infer state from cursor movement or changed scrollback.
References: REF-KITTY-REMOTE-CONTROL, REF-KITTY-RC-PROTOCOL, REF-WEZTERM-CLI, REF-ITERM2-RPCS, REF-ITERM2-HOOKS, REF-TMUX-CONTROL-MODE.


## Fresh shell ideas from the notification-surface pass
- **Watch-this-frame toast**: let the user arm one exact command frame for a later toast, badge, or alert instead of enabling blanket completion spam for the whole pane.
- **Reveal-not-run notification actions**: the primary toast action should be `show frame`, `show receipt`, or `focus workspace`, not hidden command execution.
- **Escalation receipts**: when a notification fires, keep a tiny trace of which anchor it came from, which focus policy allowed it, and whether it downgraded from OS toast to bell, badge, or no-op.
- **Per-kind notification budget controls**: users should be able to say “notify me for long-running builds when unfocused, never for short helper commands, badge only for needs-input”.
- **Durable-after-transient cards**: when a toast disappears, the same event should still be recoverable through an exact transcript landmark, frame rail, or receipt card rather than vanishing into folklore.
References: REF-DESKTOP-NOTIFICATIONS-SPEC, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-NOTIFICATION-HANDLING, REF-ITERM2-SHELL-INTEGRATION, REF-DESKTOP-ENTRY-DBUS-ACTIVATION.


## Fresh shell ideas from the input-surface pass
- **Leader-mode status chip**: when a chooser, resize mode, or review mode captures keys, show a tiny chip naming the active table, timeout, and unknown-key policy.
- **Input receipt on risky injection**: when a palette, replay card, or helper sends bytes, show whether the action produced staged text, bracketed paste, exact key events, or direct helper injection.
- **Prompt-local edit fence**: allow rich click-to-move and edit-in-place only inside a live prompt/input zone, and show a clear fallback outside it.
- **Read-only capture lane**: one explicit switch should let the user prefer selection/search/navigation over app mouse capture or PTY input, with visible diagnostics about what is blocked.
- **IME-aware shortcut debug view**: the custom shell should have a small inspector that can say whether a shortcut matched a physical key, a mapped key, composed text, or a helper-defined mode.
References: REF-WEZTERM-KEYBOARD-CONCEPTS, REF-WEZTERM-KEYBOARD-ENCODING, REF-KITTY-MAPPING, REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-KEYBIND-SEQUENCE, REF-GHOSTTY-KEYBIND-ACTIONS.


## Fresh shell ideas from the media-surface pass
- **Exact-frame media cards**: when a command emits a plot, image, PDF preview, or renderable receipt, bind it to the exact frame and offer `expand`, `collapse`, `open externally`, `download`, and `attach as context` as separate actions.
- **Placeholder-first restore honesty**: restored panes should be allowed to show "media used to be here" placeholders with exact anchors and follow-on actions instead of pretending the rich rendering still exists.
- **Budget chips for heavy rendering**: inline media should be able to explain whether it used GPU rendering, a host-local helper, a remote protocol, or a downgraded text/thumbnail path.
- **Preview rail, not transcript takeover**: let users pin a right-side or below-frame preview rail for richer media without forcing the durable transcript itself to become a giant canvas.
- **Backgrounds as low-authority chrome**: background images or ambient media should stay clearly in the chrome lane with visible budget controls, not become evidence or status surfaces.
- **Media collapse/export shortcuts**: a great custom shell should let users collapse media to a stable receipt, reopen it later, or export it as an exact artifact without screen scraping.

References: REF-KITTY-GRAPHICS-PROTOCOL, REF-WEZTERM-IMGCAT, REF-GHOSTTY-FEATURES, REF-GHOSTTY-RELEASE-120, REF-ITERM2-INLINE-IMAGES, REF-ITERM2-ONE-PAGE.


## Fresh shell ideas from the link-surface pass
- **Hover cards with exactness and action path**: when something is clickable, show whether it is a detected word link, OSC 8 hyperlink, semantic file link, or exact object target, along with the planned handler path.
- **Open-detected-link palette**: keep one searchable palette that can list local files, URLs, receipts, and downgraded text links with explicit classes and follow-on actions.
- **Exact file-fragment routing**: when a link is `file://...#line:column` or equivalent, route to the editor/open action directly instead of collapsing everything into generic browser open.
- **Stage-not-run fallback**: when only weak text survived, prefer staging the canonical target string or showing a review card over immediately running a helper command.
- **Split reveal/open/focus controls**: let the user choose `reveal target`, `open target`, and `bring handler forward` as separate actions rather than one overloaded click meaning.
- **Invocation-debug inspector**: the custom shell should be able to explain why a clickable thing was classified the way it was and what precision or policy fence applied.

References: REF-WEZTERM-HYPERLINKS, REF-WEZTERM-OPEN-URI, REF-KITTY-CONF, REF-KITTY-OPEN-ACTIONS, REF-ITERM2-SEMANTIC-HISTORY, REF-ITERM2-ESCAPE-CODES, REF-VSCODE-TERMINAL-BASICS, REF-VSCODE-TERMINAL-LINK-PROVIDER.


## Fresh shell ideas from the label-surface pass
- **Trusted label rail**: show a tiny chip that says `pinned`, `template`, `shell-reported`, `process-declared`, or `remembered` next to the current title/badge mode.
- **Pin current title / follow current frame**: a custom shell should let users freeze the current label, return to live-follow mode, or swap to a reviewed template without editing shell rc files.
- **Label inspector**: clicking a tab title or badge should explain the current text, which channel produced it, what stronger/weaker sources were ignored, and how stale the underlying context is.
- **Remote/current/remembered host chips in chrome**: current host and cwd summaries belong in badges, subtitles, or tab chrome, with exact truth labels, instead of inflating prompt text.
- **Restore label honesty**: on reopen, let panes say `remembered label` until live shell or manager context refreshes the chrome.
- **Copy-safe chrome export**: ordinary transcript copy should not silently capture title/badge text, but the user should be able to explicitly export a chrome snapshot when they want it.

References: REF-XTERM-CTLSEQS, REF-WINDOWS-TERMINAL-TAB-TITLE, REF-WINDOWS-TERMINAL-TIPS, REF-WEZTERM-FORMAT-TAB-TITLE, REF-WEZTERM-RIGHT-STATUS, REF-ITERM2-BADGES, REF-ITERM2-ESCAPE-CODES, REF-GHOSTTY-CONFIG-REFERENCE, REF-KITTY-CONF, REF-KITTY-REMOTE-CONTROL.

## Fresh shell ideas from the capability-bound and trusted-command pass
- **Trust ladder on every command chapter**: show whether command text and frame boundaries are guessed, marker-derived, shell-reported, nonce-trusted, or manager-attested before offering replay or repair actions.
- **Startup-footing witness**: one click should reveal whether current semantics came from builtin support, an explicit addon, compatibility injection, or degraded fallback.
- **Paste firewall modes**: pasted payloads should be eligible for preview, literal mode, staged here-doc insertion, or explicit refusal when they contain surprising control structure.
- **Lock-state badges**: if a helper shell or component tightened its authority baseline, show whether that narrowing is still configuring, locked, or unavailable instead of hiding it behind folklore.
- **Authority-ledger rails**: a thin per-frame rail can summarize cwd provenance, host lineage, trust grade, support level, and freshness without claiming to be the canonical transcript.
- **Remote file actions as reviewed sessions**: editing, opening, downloading, or uploading remote files should feel first-class, but remain explicit reviewed sessions rather than ambient PTY power.
References: REF-VSCODE-SHELL-TRUST, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION, REF-ITERM2-SHELL-INTEGRATION, REF-KITTY-TRANSFER, REF-KITTY-REMOTE-FILES, REF-XTERM-BRACKETED-PASTE.

## Fresh shell ideas from the authority-narrowing and reviewed-remote-session pass
- **Authority rail**: reserve one slim chrome lane for cwd provenance, hop lineage, trust grade, narrowing state, and freshness so the prompt does not have to carry every semantic burden.
- **Lock-state badge**: when a helper shell or launched component tightened its authority baseline, show whether it is `configuring`, `locked`, `degraded`, or `unsupported`.
- **Remote action cards**: clicking or selecting a remote target should open a compact card that distinguishes `open`, `edit`, `download`, `upload`, and `copy selector` instead of guessing one ambient default.
- **Startup-footing inspector**: one click should explain whether current semantic goodness came from builtin support, an explicit addon, compatibility injection, or degraded fallback.
- **Peer-scoped comfort with retention controls**: remembered commands, recent directories, and host breadcrumbs should be brilliant per peer/domain while still being easy to erase or keep session-local.
References: REF-KITTY-SHELL-INTEGRATION, REF-KITTY-REMOTE-FILES, REF-KITTY-TRANSFER, REF-VSCODE-SHELL-TRUST, REF-ITERM2-ONE-PAGE, REF-ITERM2-PREFERENCES-GENERAL.


## Fresh ideas from the request-activation pass
- **Launch cards with split identity**: when a shell action wakes a component, show the exact target separately from any startup-id / activation-token / attention hint the desktop path also carried.
- **First-request receipts**: a launch/open frame should be able to show accepted, activation-delivered, acknowledged, and ready as separate truths instead of one vague “started”.
- **Replay-small, not replay-everything**: when the shell needs to preserve the first request across activation, keep only the narrow typed request bundle, not a generic queue of shell text.
References: REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-DBUS-SPECIFICATION, REF-VSCODE-SHELL-INTEGRATION.

## Fresh shell ideas from the exact-run observation and advisory-foreground pass
- **Same-run action chips**: `stop same run`, `compare with current`, and `explain this exit` should carry a component id plus expected cycle witness and fail safely when the component has already restarted.
- **Command-confidence badge**: every chapter can show a tiny `guessed`, `derived`, `reported`, `trusted`, or `attested` badge that directly controls replay, quick-fix, and rerun affordances.
- **Activation card with split identity**: when a launch/open path also carries a startup-id or activation token, show that token as a trailing field on the card rather than burying it inside target identity.
- **Live deferral chip**: when a command or component is holding a short stop-deferral handle, show who owns it, when it expires, and what exact frame or activity bracket created it.
- **Local implementation inspector**: a debug pane should be able to say `same-run fence backed by pidfd`, `backed by job handle`, `backed only by manager witness`, or `historical only` without turning those host details into the public UX contract.
References: REF-LINUX-PIDFD-OPEN, REF-LINUX-WAITID-PIDFD, REF-VSCODE-SHELL-TRUST, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-INHIBIT.


## Fresh ideas from the semantic-zone and activation-token pass
- **Zone inspector overlay**: make it trivial to reveal the exact prompt/input/output zone under the cursor, its trust/provenance, and any attached Steward anchors or receipts.
- **Zone-addressable actions**: copy/open/explain/share should be able to target the exact semantic zone under a click or selection rather than a pane-wide cwd guess.
- **Launch cards with split truth**: when a shell action launched something with an activation token or startup hint, show target identity, lifecycle receipt, and any focus/activation hint as separate fields instead of one blended “launch succeeded” blob.
- **Monotonic authority rail**: keep a small visible rail for `configuring`, `locked`, `degraded`, or `unsupported` narrowing state so users can see whether a shell helper or launched component is still inside its reviewed baseline.

References: REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-SEMANTIC-ZONES, REF-WEZTERM-SEMANTIC-ZONE-AT, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-OPENURI, REF-OPENBSD-UNVEIL, REF-FREEBSD-CAP-ENTER, REF-FREEBSD-CAP-RIGHTS-LIMIT.

## Fresh ideas from the stackable-narrowing and request-handle pass
- **Pending request chips**: when a command opens a chooser, portal, or approval sheet, show a tiny chip with state like `waiting`, `responded`, `cancelled`, or `expired` instead of leaving the prompt to guess what happened.
- **Inspector view for pending requests**: let the terminal reveal the exact target class, originating frame, trust grade, and current response state of a mediated request.
- **Capability rail should show narrowing stack depth**: if local adapters layered extra narrowing beneath the reviewed baseline, surface that as observational depth or exact downgrade notes rather than pretending nothing changed.
- **Capsule digests over giant pasted launch blobs**: if a helper needs reviewed startup material, show a digest or label for the sealed capsule, not its raw body.


## Fresh shell ideas from the request-budget and input-capture pass
- **Deadline-bearing pending chips**: a chooser/open/approval chip should be able to show `waiting 12s left`, `cancel`, and the final `responded` / `expired` / `cancelled` outcome.
- **Shortcut-session shelf**: keep one tiny inspectable shelf for active global/out-of-focus shortcut sessions with owner, scope, and a revoke action.
- **Capture-state rail**: make keyboard/pointer capture say `armed`, `active`, `released`, `denied`, or `degraded` so the shell never has to guess why input feels different.
- **Budget-aware replay cards**: when a remembered command is reopened as a reviewed action, let it inherit or explicitly clear old deadlines/cancellation context instead of silently reusing stale time assumptions.
- **Launch/approve detours with one exact request object**: opening a portal, picker, or approval UI should always leave behind one object the transcript and chrome can point at later.

References: REF-GRPC-DEADLINES, REF-GRPC-CANCELLATION, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-PORTAL-GLOBALSHORTCUTS.

## Another compact cluster worth stealing
- **Run-group action chips**: a stop / inspect / reveal-processes chip should bind to one reviewed Steward run and, where available, its exact host-side execution group rather than to shell jobs or guessed descendants.
- **Transport lane separate from lifecycle lane**: let remote shell transport chase Mosh-like low-latency feel and roaming resilience, but keep lifecycle actions visibly confirmation-fenced until supervised truth catches up.
- **Narrowed helper modes**: small shell-side helpers should be able to report that they have dropped into a smaller one-way promise/authority floor after setup.

References: REF-WINDOWS-JOB-OBJECTS, REF-SOLARIS-PROCESS-CONTRACTS, REF-LINUX-CGROUP-V2, REF-OPENBSD-PLEDGE, REF-MOSH, REF-MOSH-PAPER.

- **Current through cursor X**: status shelves, watch-this-command chips, and sticky headers should be allowed to show the exact observation cursor they are synced through for that view when the path supports it.
- **Continuity-lost beats fake freshness**: if a shell view falls behind, loses its watch history, or crosses a hop that broke continuity, the terminal should say refresh required rather than leaving old badges looking live.
- **Reconnect shelves with exact resume state**: after a dropped hop or reconnect, a watch shelf should be able to show `resuming from cursor…`, then either settle into live continuity or admit `resume failed; refreshed from snapshot`.
- **Bookmark-style quiet progress**: even when no payload changed, a tiny synced-through marker can help the UI prove that a watch is alive and current without repainting the whole pane.

References: REF-K8S-API-CONCEPTS, REF-ETCD-DATA-MODEL, REF-ETCD-MAINTENANCE, REF-TMUX-CONTROL-MODE.


## New shell/terminal move: renewal rails and countdown chips
If a command or component holds a live deferral, capture, or mediated request handle with an expiry story, the shell should be able to show a compact chip such as `renewed through 14:03:12`, `18s remaining`, or `expired waiting for renewal`. That feels luxurious when it is exact, and it teaches the right anti-folklore lesson: live comfort is coming from one current handle or renewal path, not from ambient guesswork.
References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SEMANTIC-ZONES, REF-K8S-LEASES, REF-ETCD-LEASES.

- **Consumable action chips**: if an action rail or command frame carries a one-shot or use-bounded right, show `one use left`, `consumed`, or `already spent` explicitly instead of leaving stale replay affordances live.
- **Consume-on-use reveal/open actions**: some high-value shell actions should intentionally spend their exact grant when used once, especially when an older frame should not keep reopening a fresh foreground or reveal path forever.

## New shell/terminal move: retry-safe action chips
- **Retry-safe chips**: when a high-value action carries an effect key, show `retry-safe` or `keyed` explicitly so the user knows the action is not just a blind replay gamble.
- **Duplicate-versus-mismatch outcomes**: the shell should be able to say `duplicate suppressed`, `still processing`, `key mismatch`, or `dedupe window expired` instead of flattening every failed rerun into one generic error.
- **Prior-outcome anchors**: when a retry collapses to an earlier accepted outcome, let the chip or card point back to that earlier receipt/frame so the user can see exactly what was reused.
References: REF-GOOGLE-AIP-155, REF-AWS-EC2-IDEMPOTENCY, REF-AWS-ECS-IDEMPOTENCY, REF-IETF-IDEMPOTENCY-KEY.

- **Conditional action chips**: high-value chips should be able to say `wrong cycle`, `stale anchor`, `moved epoch`, or `precondition failed`, and jump to the fresher object instead of silently mutating the newest thing with a similar label.


## Fresh shell ideas from the attenuated-grant pass
- **Downscoped helper chips**: when a helper opens, uploads, reveals, or nudges attention on behalf of a frame, show that it is running on a narrower derived grant rather than on the broad parent capability.
- **Parent/child grant inspector**: let one click explain `derived from`, `narrowed to`, `expires at`, and `uses left` for a helper action without dumping raw grant material.
- **Safe helper replay**: when a remembered frame wants to reuse a helper action, prefer deriving a fresh narrowed child grant from a current parent or fail closed; never silently replay an old broad right from history.
- **Audience-target rails**: if a helper grant was downscoped to one target peer or UI surface, show that exact audience/target binding in chrome so the shell never has to guess where the authority is valid.

References: REF-RFC8693-TOKEN-EXCHANGE, REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY, REF-AWS-STS-ASSUMEROLE, REF-MACAROONS.

## Fresh shell idea: holder-proof rails
- let high-value action chips say `holder proof required`, `proof valid`, `wrong holder`, `holder rotated`, or `bearer only` instead of pretending an old frame can always replay them;
- let the terminal bind a live grant to one current pane/session/helper context so copied transcript text explains history but does not itself re-spend the power;
- keep holder proof visibly separate from target identity, attention hints, and stale-action fences so the shell can explain exactly why an action was denied.

References: REF-RFC9449-DPOP, REF-RFC8705-MTLS, REF-RFC9700-OAUTH-SECURITY-BCP.

## Fresh shell ideas from the fresh-intent pass
- **Action chips with intent state**: `fresh intent required`, `fresh`, `consumed`, `expired`, `wrong context`, `ignored by compositor`.
- **Gesture-bound rerun rails**: if an old command wants to re-open, reveal, promote, or foreground something sensitive, the shell should ask for a fresh local gesture instead of silently replaying stale history.
- **Shortcut-to-action honesty**: a live shortcut activation can carry fresh intent and maybe an activation token, but the shell should still show target identity, focus hint, and later success or denial as separate truths.
- **No fake remote clicks**: remote-control paths should stay visibly weaker than current local interaction unless a separately reviewed local mediation path upgrades them.

References: REF-HTML-USER-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-GLOBALSHORTCUTS.

## Fresh shell ideas from the retry-advice pass
- **Countdown rails for denied work**: action chips should be able to say `retry after 12s`, `try again at 14:03:12`, `still processing`, `wait for clear`, or `hint expired` instead of leaving the user with a mysteriously dead affordance.
- **No blind cooldown guessing**: when the path cannot prove a retry hint, the shell should say `no retry hint` rather than inventing one from stale timestamps or past manager behavior.
- **Cause plus time, not one vague status**: show `cooling down` separately from `rate limited` or `still processing`, and attach any exact retry hint beside that reason rather than flattening everything into `busy`.
References: REF-HTTP-RFC9110, REF-GRPC-HEDGING, REF-K8S-POD-LIFECYCLE, REF-K8S-KUBELET-CONFIG.

## Fresh shell ideas from the weak-edge and sibling-datacube pass
- **Ground cards**: every running or remembered command should be able to reveal one compact card with exact cwd root, hop lineage, component id, runtime-cycle witness, launch basis, and confidence.
- **Foreground baton chips**: keep `request woke work`, `attention hinted`, `foreground transferred`, and `needs fresh local intent` as visibly separate chips instead of one vague `activated` badge.
- **Weak-helper lamps**: when a pane or helper relies on optional side channels or degraded hops, say `optional helper absent`, `weak route`, or `fallback only` instead of flattening everything into `connected`.
- **Metadata lane that survives hops**: prefer a tiny parseable side lane for prompt/frame metadata, user vars, and receipts that can survive SSH/tmux hops when explicitly carried, rather than reparsing the rendered screen.
References: REF-FUCHSIA-CAPABILITIES, REF-TMUX-CONTROL-MODE, REF-WEZTERM-PANE-USER-VARS, REF-VSCODE-SHELL-INTEGRATION, REF-XDG-ACTIVATION-V1.


## Fresh shell moves from the execution-ground pass
- show one compact **ground card** under the prompt or beside a command frame with cwd root, hop lineage, runtime-cycle witness, launch basis, and a truth label like `current`, `manager-redelivered`, `reported`, or `remembered`;
- let interactive panes show a tiny **foreground baton pill** that distinguishes `foreground now`, `interactive attach`, `observe only`, and `history only` instead of one vague attached badge;
- label suggestions by **source** (`history`, `plugin`, `context completer`, `heuristic`) and let the user accept the next word, the full suggestion, or inspect details without inserting;
- keep completion metadata attached to the current pane context so good suggestions can still degrade honestly after a hop, resync, or stale shelf entry;
- steal a ViewFS-style **receipt/ground pairing** so the shell can show what context a command stood on and what durable record it produced without making either one pretend to be the other.
References: REF-POSIX-TCSETPGRP, REF-PSREADLINE-PREDICTORS, REF-NUSHELL-CUSTOM-COMPLETIONS.

## Fresh shell ideas from the launch-boundary and semantic-zone pass
- **Launch-shutter chips on exact frames**: when a command prepares helper context or launches a component, let the frame show `held here`, `selected for child`, `manager-redelivered`, or `receipt only` as separate truths.
- **Revive-as-pending by default**: restored command panes should come back as reviewed pending work unless the user intentionally chooses immediate rerun.
- **Zone-exact export**: when prompt/input/output zones exist, export or handoff actions should be able to attach exactly the prompt, the entered command, the output block, or the whole interaction without nearby text guesswork.
- **Feature-report-driven upgrades**: richer selection, export, and launch-shutter chrome should turn on from fresh feature reporting and semantic zones, not from terminal-name folklore.

References: REF-ZELLIJ-SESSION-RESURRECTION, REF-WEZTERM-SEMANTIC-ZONES, REF-WEZTERM-SEMANTIC-ZONE-AT, REF-ITERM2-FEATURE-REPORTING.

## Fresh shell ideas from the activation-cause pass
- **Start-cause chips on frames**: let a command frame or lifecycle card say `manual`, `first request`, `repair relaunch`, `restore replay`, or `scheduled` so the shell explains why current work exists.
- **Ground plus cause pairing**: pair the execution-ground card with a one-line start-cause chip so users can see both the context a command stood on and the reason the current cycle began.
- **Restore honesty by default**: revived panes should show `restore replay` or `revive pending` instead of pretending they are just another ordinary fresh shell.
- **Unknown is a UI state, not a failure**: when a host cannot say exactly why the cycle began, show `start cause unknown` rather than inferring from nearby output or focus changes.

References: REF-ZELLIJ-SESSION-RESURRECTION, REF-WEZTERM-SEMANTIC-ZONES, REF-ITERM2-FEATURE-REPORTING, REF-GHOSTTY-RELEASE-130, REF-LAUNCHD-JOBS, REF-DBUS-SPECIFICATION.


## Another fresh idea from this pass
Execution-ground cards and command-frame chips should be able to show compact **generation lamps** such as `ready@g12`, `reloading toward g13`, or `observed generation unknown`. That would make rerun/stop/explain flows much more honest for hot-reload and mutable launch/config stories without freezing a giant rollout UI.
References: REF-K8S-PODS-OBSERVED-GENERATION, REF-GHOSTTY-RELEASE-130.

## Fresh ideas from the restart-budget pass
- **Burst-budget chips**: command frames and ground cards should be able to show compact pressure cues like `restart budget 2/5 in 60s`, `auto-restart disabled`, or `budget exhausted`.
- **Cooling-down versus repair-required should look different**: a countdown rail is useful when auto-retry remains eligible, but once the budget is spent the UI should pivot to explain/repair flows instead of another fake timer.
- **First-start versus retry badges**: make `fresh launch`, `automatic retry`, and `manual retry` visibly distinct so a user can understand how the current runtime cycle began.
- **Budget pressure belongs next to the run, not hidden in logs**: shell chrome should expose restart pressure as small target-bound metadata instead of forcing users to reconstruct it from scattered log lines.
References: REF-ERLANG-OTP-SUPERVISOR, REF-SYSTEMD-UNIT, REF-K8S-POD-LIFECYCLE, REF-ITERM2-FEATURE-REPORTING.



## Fresh shell ideas from the progress-window pass
- let execution-ground cards and status chrome show compact progress chips such as `starting`, `progress seen`, `extended +20s`, `held`, `stalled`, or `unknown`;
- let exact command frames reveal the last checkpoint or receipt that proved progress instead of forcing users to infer it from raw logs;
- treat `held` and `stalled` as different UX states so pause buttons, repair suggestions, and retry affordances do not lie;
- keep progress-horizon explanation target-bound, so “why is this still warming?” bottoms out in an exact frame/receipt/run witness instead of ambient manager mood.

References: REF-K8S-DEPLOYMENT, REF-NOMAD-UPDATE, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE.

## Fresh shell ideas from the liveness-evidence pass
- let execution-ground cards and status chrome show compact pulse chips such as `watchdog current`, `last pulse 8s ago`, `startup shielded`, `liveness stale`, or `unknown`;
- let exact command frames reveal **what kind** of evidence last proved liveness — watchdog, probe, adapter checkpoint, or weaker fallback — instead of one vague alive badge;
- keep liveness chips visibly separate from readiness, progress, and restart-budget chips so the shell does not flatten different operational truths into one green dot;
- when support is absent, say `liveness unsupported` or `no current evidence` rather than inferring from a quiet pane.

References: REF-K8S-PROBES, REF-K8S-POD-LIFECYCLE, REF-SD-WATCHDOG-ENABLED, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE, REF-ITERM2-FEATURE-REPORTING, REF-WEZTERM-SEMANTIC-ZONES, REF-GHOSTTY-RELEASE-130.


## Fresh shell ideas from the continuity-escrow pass
- let execution-ground cards and launch receipts show compact escrow chips such as `escrow current`, `redelivered`, `escrow absent`, `flushed`, or `unknown`;
- pair those chips with a tiny explainer telling whether the claim came from manager-redelivery, a launch receipt, or only historical memory;
- keep `redelivered` visibly separate from `takeover proven`, `ready`, and `same run` so restart UX stays honest when the public edge survived but the concrete serving owner changed;
- prefer one explicit `show escrow receipt` or `show continuity lane` action over ambient log archaeology.

References: REF-SYSTEMD-FDSTORE, REF-FUCHSIA-COMPONENT-RUNNER, REF-FUCHSIA-IDLE-STOP, REF-WEZTERM-SEMANTIC-ZONES, REF-ITERM2-FEATURE-REPORTING.

## Fresh shell idea: discovery-presence chips
Command frames and execution-ground cards should be able to show `advertised`, `withheld`, `withdrawn`, `expired`, or `critical` when the adapter can actually prove current published presence. That would make shell-visible lifecycle truth much better than a vague green dot, especially during drain, repair, or warmup.
References: REF-ETCD-LEASE-API, REF-CONSUL-AGENT-CHECK, REF-K8S-LEASES, REF-ITERM2-FEATURE-REPORTING, REF-WEZTERM-SEMANTIC-ZONES, REF-GHOSTTY-SHELL-INTEGRATION.

## Fresh shell ideas from the projection-surface pass
- **Projection surfaces, not hidden shell law**: sticky command headers, command guides, command selection outlines, receipt shelves, and status chips should all be treated as host-owned projection surfaces bound to exact frame anchors instead of as invisible new shell grammar.
- **Observe / attach / control / debug ladder**: one terminal can safely feel super awesome if it keeps follow-only viewing, interactive attach, typed control actions, and injected debug exec as visibly different rungs.
- **Execution-ground strip**: give the active frame a tiny cwd / activation / hop / capability strip with freshness and publisher labels so rerun, split, and open-here affordances stop depending on vibes.
- **Armed versus active capture**: shortcuts, input capture, and stronger control lanes should show `armed`, `active`, `paused`, and `ended` explicitly instead of collapsing everything into a binary enabled badge.
- **Hop-aware comfort kit**: same-cwd spawn, jump-to-prompt, open-last-output-exactly, prompt-local click-to-move, and remote notification reveal should appear only when current hop lineage and capability truth really support them.
- **Typed open-uri / object routing**: hyperlinks, receipt ids, component ids, digests, and file/object refs should route through typed handlers and visible review ladders rather than raw transcript scraping or shell-string interpolation.
- **Keyboard richness only when proven**: richer key reporting is worth stealing, but it should sit behind an exact capability handshake so the terminal can admit fallback honestly when only legacy encodings are available.

References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1109, REF-ITERM2-COMMAND-SELECTION, REF-GHOSTTY-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-OPEN-URI, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-PORTAL-GLOBALSHORTCUTS, REF-KITTY-KEYBOARD-PROTOCOL.

## Fresh ideas from the approval-rail and remote-witness pass
- **Read-only attach / witness mode**: let a user or helper attach to a terminal workspace in a mode that can inspect frames, outputs, and component receipts but cannot type, resize, or trigger actions. Zellij's new read-only session sharing is the clearest recent precedent.
- **Approval rails, not one ambient automation bit**: shell-launched actions should surface choices like allow once, allow this session, or deny, with explicit expiry and visible provenance on later actions.
- **Frame hover / status cards**: a frame-local hover or side card showing start time, duration, exit status, run witness, and receipt refs would make the custom terminal feel dramatically smarter without polluting the transcript.
- **Chooser by pipe, not chooser by paste**: typed file/object pickers should be able to return an exact selected target into another command or plugin flow without pasting prose into the prompt.
- **Guarded resurrection**: if Steward ever offers workspace or command resurrection, default to revive-as-pending with explicit run-now confirmation instead of silently re-executing remembered commands.
References: REF-ZELLIJ-RELEASE-044, REF-ZELLIJ-PLUGIN-PIPES, REF-ZELLIJ-FILEPICKER, REF-ZELLIJ-SESSION-RESURRECTION, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1108.



## Fresh ideas from the witness-mode and guarded-resurrection pass
- **Live prompt lease**: treat the active prompt as a small lease-shaped object with exact start, current footing, and expiry-on-exec so click-to-move and inline editing luxuries stay bound to the current prompt only.
- **Observe-only attach rails**: a terminal attached for witnessing should keep its own `observe`, `request control`, `control denied`, and `control granted` rails instead of pretending every attach begins with equal authority.
- **Resurrected-is-historical until re-witnessed**: restored panes, saved layouts, and old command cards should appear as remembered context first, then upgrade only when the current hop, prompt, or component truth is reacquired.
- **Remote comfort should cite its footing**: same-cwd spawn, click-to-open paths, prompt-click, or last-output paging should say whether they are backed by live shell integration, remembered metadata, or degraded guesswork.
References: REF-ZELLIJ-SESSION-RESURRECTION, REF-ZELLIJ-RELEASE-044, REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION.


## Fresh ideas from the attach-lane pass
- **Request control, don't assume it**: an observe-only session should have an explicit `request control` rail with visible `pending`, `denied`, `expired`, or `granted` truth instead of silently upgrading because the transport already exists.
- **Transport card plus lane pill**: show `local pty`, `tmux`, `browser`, or `terminal-to-terminal` separately from `observe`, `attach`, `control`, or `debug` so users can see both *how* they are connected and *what* they can currently do.
- **Witness mode should still sing**: read-only sessions should still get exact frame navigation, command guides, bounded export, receipt reveal, and semantic search so they feel like a premium mode rather than a crippled shell.
- **Debug should be loud**: if a session crosses into injected-helper or stronger inspection territory, the terminal should say so with persistent chrome rather than blending it into ordinary attach.
References: REF-ZELLIJ-RELEASE-044, REF-XDG-PORTAL-INPUTCAPTURE, REF-GHOSTTY-RELEASE-130.


## Fresh shell moves from the attach-continuity pass
- **Attach-ground strip**: show lane, transport, runtime witness, and continuity state together: `observe · https attach · runtime abc123 · reconnecting` is much better than a flattering green dot.
- **Resume-to-witness banner**: after reconnect, land in a visible witness mode that offers `request input again`, `request control again`, or `refresh against current runtime` rather than silently restoring power.
- **Prompt-local luxuries only on live prompt truth**: click-to-move, command-local widgets, or same-command quick fixes should light up only when the current prompt/frame is still exact; otherwise degrade with an explanation.
- **One exact pending-handle chip for mediated attach**: if an approval, portal, or remote attach token is in flight, show one closeable chip with `pending`, `approved`, `denied`, `expired`, or `closed` instead of a vague spinner.
References: REF-ZELLIJ-RELEASE-044, REF-GHOSTTY-RELEASE-130, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION, REF-VSCODE-SHELL-INTEGRATION.


## Fresh shell/terminal moves from the proposal-lane pass
- Give the UI a visible **proposal lane badge**: `proposal`, `inserted`, `approved once`, `approved for this conversation`, `denied`, `stale context`, `witness only`.
- Default every generated command to one of three explicit landings: **insert into active prompt**, **open as reviewed card**, or **run in fresh reviewed pane**.
- Let users **attach exact frame context** into the proposal lane with one gesture: selected output, last failed command, one receipt, one transcript landmark, one notebook block.
- Keep **conversation-local command attempts** out of ordinary shell history unless the user explicitly promotes them.
- Add a compact **why this is safe / why this is blocked** explainer under proposed actions so approvals never feel mystical.
- Make `take over`, `hand back`, `run once`, `insert only`, and `open plan` first-class controls when a proposal lane is watching a live interactive session.
- Treat notebooks, prompts, and saved workflows as **rich proposal objects** whose default action is usually to stage or insert, not to silently execute.


## Fresh shell + terminal ideas from detour-return research

- **Pending detour chips**: if the terminal opens a browser, chooser, editor, or approval sheet, show a tiny pending chip bound to one exact request/ticket with `pending`, `returned`, `canceled`, `expired`, or `consumed`.
- **Return-to-here badges**: let a pane expose a visible `return target` badge while a detour is outstanding, then clear it when the ticket is spent.
- **Result-available without retargeting**: if the original pane is gone, do not guess a new home; show `result available` with `rebind`, `open in witness`, or `discard`.
- **Ignored command-guide noise**: make sticky command guides and command rails filterable so agentic CLIs and buffer-maintenance commands do not crowd out the frames users actually want to navigate by.
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-OPENURI, REF-XDG-PORTAL-REMOTE-DESKTOP, REF-GHOSTTY-RELEASE-130, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1109.


## Fresh shell + terminal ideas from the history-lane pass

- Give remembered search results visible **lane pills** such as `typed`, `workflow`, `notebook`, `proposal`, `conversation`, `receipt`, or `exact frame`.
- Let `Enter` be configurable per lane: `insert`, `open`, `resume as pending`, or `run now` only when that lane actually earned it.
- Show **history provenance chips** after execution: `typed here`, `inserted from workflow`, `assistant suggested`, `tool-run hidden from shell history`, `conversation-local only`.
- Keep one **promote / demote rail**: promote a great proposal into a durable recipe, or demote a noisy tool-run command out of ordinary shell history without erasing the exact frame.
- Make remembered search **hop-aware and scope-aware** so the same command on a different host/path still shows as related but not identical.
References: REF-WARP-COMMAND-SEARCH, REF-WARP-WORKFLOWS, REF-WARP-NOTEBOOKS, REF-VSCODE-UPDATE-1108.


## Fresh shell + terminal ideas from the approval-rung pass

- Give the terminal a compact **autonomy pill**: `proposal`, `ask`, `allow lane`, `allow task`, `run until completion`, `policy floor hit`, `downgraded on reconnect`.
- Make higher rungs **loud and stoppable**: visible countdowns, one-stop `drop to ask`, and a clear record of which rung each action actually used.
- Pair stronger autonomy with **narrower footing**: fresh reviewed pane, worktree, container, or disposable environment when available.
- Let reconnect land as **witness first** whenever the original basis drifted, then require an explicit climb back up the autonomy ladder.
References: REF-VSCODE-UPDATE-1111, REF-VSCODE-AGENT-TOOLS, REF-VSCODE-AI-SETTINGS, REF-WARP-AGENT-PROFILES.


## Fresh shell + terminal ideas from the preflight-lane pass

- **Preflight pills**: give actions a visible state such as `explain`, `diff ready`, `no changes`, `preview stale`, `preview denied`, or `saved plan loaded` instead of one generic review banner.
- **Review-before-apply cards**: when a command or chip could mutate something important, show a compact card with exact target, execution ground, policy notes, and the freshest preview or diff before the user chooses `apply`.
- **Saved-plan inspect rail**: if a review artifact exists, let the shell open, diff, and explain that exact saved plan separately from rerunning a fresh preview.
- **Preview footing badges**: cards and transcripts should say whether a preview came from local speculation, manager-backed inspection, or live remote/server-side dry-run so users can judge how strong it really is.
- **Diff status codes as first-class UI**: copy kubectl's instinct that `no differences`, `differences found`, and `preview failed` should be visibly different outcomes.
References: REF-TERRAFORM-PLAN, REF-TERRAFORM-APPLY, REF-KUBECTL-DIFF, REF-K8S-DECLARATIVE-CONFIG, REF-VSCODE-AGENT-PLANNING, REF-CLAUDE-CODE-PERMISSIONS.


## Fresh ideas from the revision-settlement pass
- **Revision ribbon in the execution ground**: show compact chips like `desired r14`, `observed r13`, `settled r12`, `pending promotion`, or `settlement unknown` so a pane can explain why a change has not really landed yet.
- **Rollback-to-last-settled affordance**: if a preview or apply card points at a failing newer revision, offer one honest path to inspect or return to the last settled basis instead of a generic try again button.
- **Pending-promotion headers**: command guides and sticky headers should be allowed to say `canary healthy, promotion pending` or `reload acknowledged, settlement pending` when that is the true bottleneck.

References: REF-K8S-PODS-OBSERVED-GENERATION, REF-K8S-DEPLOYMENT, REF-NOMAD-DEPLOYMENT-STATUS, REF-NOMAD-UPDATE, REF-SD-NOTIFY.

## Fresh ideas from the headroom-witness pass
- **Execution-ground headroom ribbon**: let panes and command frames show a tiny spendability strip such as `restart 2/5 in 60s`, `quota 3 pods remaining`, `rate resets 14:00`, or `manual clear required`.
- **Blocked for which reason?**: keep `policy floor`, `approval missing`, `quota exhausted`, `restart budget exhausted`, and `secondary limit unknown` visibly different so the terminal answers *why not now?* without log diving.
- **Budget-aware action affordances**: rerun / retry / promote / attach buttons should dim or relabel themselves based on exact current headroom rather than letting the user discover the ceiling only after failure.
- **Explain the next opening**: when there is a real reset time or trailing-window age-out, show it inline beside the frame instead of forcing users to infer it from silence.

References: REF-K8S-RESOURCE-QUOTAS, REF-NOMAD-QUOTA, REF-GITHUB-RATE-LIMITS, REF-SYSTEMD-UNIT, REF-SYSTEMCTL.


## Fresh shell + terminal ideas from the hold-state pass
- **Hold ribbon in the execution ground**: let panes and receipts show compact chips like `paused`, `draining`, `frozen`, `masked`, `ineligible`, or `held until 14:00` so users can see why movement stopped without log diving.
- **Resume affordances should match the mode**: offer `resume rollout`, `undrain node`, `thaw unit`, or `inspect hold` instead of one generic `retry` button that hides the actual operational state.
- **Do not flatter a hold into a failure**: sticky headers and command guides should be allowed to say `held for maintenance` or `draining current work` rather than turning every non-progress interval into `stalled`.
- **Let inspection holds be productive**: when a node or component is intentionally kept ineligible, keep exact frame navigation, receipts, and witness-mode tools first-class so `held for inspection` still feels useful.

References: REF-K8S-ROLLOUT-PAUSE, REF-K8S-ROLLOUT-RESUME, REF-NOMAD-NODE-DRAIN, REF-SYSTEMCTL, REF-SYSTEMD-UNIT.


## Fresh shell + terminal ideas from the exception-witness pass
- **Exception ribbon in the execution ground**: let panes, cards, and receipts show compact chips like `under exception`, `PDB bypassed`, `manual approval bypassed`, `waived until 14:00`, or `exception expired`.
- **Approval and exception should be separate chrome**: keep `approved`, `auto-approved`, and `under exception` visually distinct so operators can tell whether the gate passed normally or was bypassed.
- **Exception receipts should carry scope and expiry**: a command frame should be able to say what exact action/lane/revision the exception covered and whether it was single-use, session-scoped, or time-limited.
- **Offer mode-matched exits**: show `re-run through normal gate`, `inspect exception basis`, `request renewal`, or `clear waiver` instead of one fake `retry` path.

References: REF-KUBECTL-DRAIN, REF-VSCODE-AGENT-TOOLS, REF-VSCODE-UPDATE-1111, REF-GITHUB-PUSH-PROTECTION-BYPASS, REF-GITHUB-PROTECTED-BRANCHES.


## Fresh shell ideas from the serve-state pass
- **Serve-mode ribbon in the execution ground**: let a pane, frame, or receipt say `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, or `not serving`.
- **Sticky command chrome for serve-state changes**: pair explicit command markers with a sticky header so a user can see *which command or revision caused a target to become draining or degraded* and jump back to that exact frame.
- **Prompt-local comfort, lifecycle-global honesty**: Ghostty's click-to-move-at-prompt and VS Code's sticky command headers are lovely examples of UX that becomes even better when paired with explicit service-mode truth rather than guessed status.
- **Typed open routing for service cards**: use WezTerm-style `open-uri` interception or explicit action rails so clicking a `draining` or `maintenance` chip opens the exact receipt, status card, or latest observation instead of a guessed browser path.
References: REF-GHOSTTY-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1109, REF-WEZTERM-OPEN-URI.

## Fresh shell/terminal ideas from the pressure-witness pass
- **execution-ground pressure ribbon**: panes, receipts, and command frames should be able to say `memory warning`, `cpu stall some`, `io full`, `scope: component cgroup`, or `pressure unknown` instead of burying resource strain behind vague degraded badges.
- **pressure-aware calm chrome**: when pressure is high, suppress noisy speculative helpers and keep the shell focused on exact receipts, recent failures, drain state, and the smallest useful next step.
- **adaptation receipts**: when a component trimmed caches, slowed optional background work, or stopped new admissions because of pressure, show that as an explicit receipt rather than a mysterious mode flip.
- **scope-first troubleshooting**: let users jump from a pressure chip to the exact scope it belongs to—this component, this node, this cgroup, this service slot—without pretending every signal is globally comparable.
## Fresh shell ideas from the backpressure pass
- **Queue-versus-shed ribbons**: the execution ground should be able to say `queued`, `retry after 1.2s`, `shed at accept`, or `stop accepting` instead of one vague spinner.
- **Fairness-scope hints**: when a queue or throttle applies only to one priority lane, request class, or service surface, show that exact scope inline.
- **Retry-after countdowns that decay honestly**: render exact retry delay when known, and visibly decay it to last-known if the anchor or source expires.
- **Calmer chrome under overload**: when backpressure is active, suppress noisy helper automation and keep the nearby affordance focused on the exact next legal move such as wait, rerun later, or inspect queue footing.

## Fresh shell ideas from the adaptation-witness pass
- **Adaptation ribbon in the execution ground**: let panes, receipts, and command frames say `cache trimmed`, `concurrency capped`, `optional work deferred`, `read-only under pressure`, or `adaptation active` instead of one vague `degraded` label.
- **Protective response should link to its cause when known**: a chip like `concurrency capped ← latency rising` or `cache trimmed ← memory warning` is much more helpful than making users correlate scattered logs by hand.
- **Make reduced service modes feel explicit, not broken**: if the system intentionally narrowed optional work or luxuries, the shell should show that as a survival posture with exact nearby affordances, not as a mysterious half-failure.
- **Adaptation receipts should age honestly**: keep `last known adaptation` distinct from live active adaptation when the source goes stale or the scope is no longer exact.
References: REF-SYSTEMD-MEMORY-PRESSURE, REF-FUCHSIA-MEMORY-RECLAMATION, REF-K8S-NODE-PRESSURE-EVICTION, REF-ENVOY-OVERLOAD-MANAGER, REF-ENVOY-ADAPTIVE-CONCURRENCY.

## Fresh shell ideas from the realm-and-control pass
- **Realm breadcrumb rail**: if Steward grows a shallow ownership-island seam, show the current component realm/subtree in chrome as explicit remembered/current truth rather than burying it in logs.
- **Control buttons that target objects, not Unix ghosts**: restart, stop, quiesce, or reveal should bind to exact component/run objects, not to inferred PID lore.
- **Typed object shelf next to the transcript**: let a command frame surface plumbable objects such as `receipt`, `run`, `component`, `target`, or `proposal`; copy/open/explain actions should route those exact objects instead of screen-scraping visible text.
References: REF-FUCHSIA-REALMS, REF-S6-SVC, REF-NUSHELL-PIPELINES, REF-PLAN9-PLUMBING, REF-WEZTERM-SEMANTIC-ZONES.

## Fresh shell ideas from the current-command pass
- **Current-command card beside the live prompt**: show one tiny exact card for the editable command with copy, explain, diff, and reveal actions while the footing is live.
- **Accept-by-word and inspect-without-insert should target the exact current command**: proposal/help systems should be able to attach to the live command object instead of mutating prompt text by vibe.
- **Explain why this is no longer current**: if exec, hop drift, shell reset, or marker loss invalidates the current command object, show the expiry reason and downgrade to frame/selection affordances.
- **Structured later, tiny now**: start with exact text plus provenance/freshness, then only add argv-ish segments or richer structure when repeated pressure proves it is worth standardizing.
References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-COMMAND-SELECTION, REF-VSCODE-SHELL-INTEGRATION, REF-FISH-TERMINAL-COMPAT, REF-GHOSTTY-RELEASE-130.

## Fresh shell ideas from the active-prompt pass
- **Prompt-as-object editing**: clicking inside the active prompt should move the cursor or select editable regions only while that prompt is genuinely live; once the frame is historical, the same area should downgrade to selection/reveal affordances.
- **Exact command reveal card next to the frame**: let the shell publish one explicit current command-line object for the live prompt so the terminal can show, copy, diff, or explain it without pretending that string is the same thing as the eventual reviewed launch or receipt.
- **Semantic inspector overlay**: one toggle should reveal prompt/input/output zones, exactness, provenance, and freshness fences so shell developers and operators can see why luxury affordances are present, degraded, or denied.
References: REF-GHOSTTY-RELEASE-130, REF-FISH-TERMINAL-COMPAT, REF-VSCODE-SHELL-INTEGRATION, REF-ITERM2-ESCAPE-CODES, REF-OSC133-SPEC.

## Fresh shell ideas from the island-and-handoff pass
- **Ownership breadcrumb rail**: if the current pane is operating inside one reviewed ownership island, show that island/root in the execution ground as remembered/current truth instead of hiding the containment story in receipts.
- **Semantic inspector overlay**: let the terminal reveal the exact object under the cursor — prompt, command frame, receipt, target, island, or stale landmark — together with freshness and confidence.
- **Prompt lease chips**: treat the active prompt as a live object with an expiry reason such as `exec`, `hop changed`, `shell restarted`, or `semantic markers lost`, so click-to-move luxuries stay exact.
- **Handle-shaped handoff shelf**: chooser/open/share flows should come back as exact request, document, or return-ticket objects that the shell can inspect, open, or spend, not as guessed paths pasted into scrollback.
References: REF-FUCHSIA-REALMS, REF-FUCHSIA-TOPOLOGY, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-DOCUMENTS, REF-GHOSTTY-CONFIG-REFERENCE.
- **Prompt lease rail**: show one tiny live-prompt chip with freshness, hop path, and exact current-command reveal while the prompt is live; clear or downgrade it on exec, resync, or hop degradation instead of leaving fake editability behind.

## Fresh shell/terminal note
Pending-request cards are only half the story. The nicer UX is: request card while the detour is live, then a compact **detour-outcome card** when it finishes. That card should be able to say `target chosen`, `denied`, `canceled`, `expired`, `provider lost`, or `rebind required`, with exact reveal/copy/continue actions if the footing still holds. This feels much healthier than shoving results into the prompt or silently focusing some “best guess” pane.

The same shell should also be able to keep outcome cards *weaker* than fresh authority. A completed browser or chooser result may be wonderfully useful, but it should not automatically re-arm typing control, lifecycle control, or fresh intent. Steward can make this feel super awesome by letting the user inspect and continue from exact outcomes while still demanding fresh footing for any stronger next move.

References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-REMOTE-DESKTOP, REF-GHOSTTY-RELEASE-130, REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.

## Fresh shell ideas from the status-barrier pass
- **Currentness rail**: beside the prompt lease and current-command card, show one tiny rail that can honestly say whether the relevant `ready`, `stopping`, or checkpoint update is merely observed, barrier-confirmed, or unknown.
- **Barrier-aware action chips**: `restart`, `rerun`, `reveal outcome`, or `continue detour` should be allowed to wait for or require a narrow currentness barrier when the footing matters, instead of sleeping for arbitrary delays in helper code.
- **Scoped component shells**: make `shell into this component scope` a first-class shell action, with a visible breadcrumb and exact control target, rather than a cwd trick or best-guess helper shell.


## Fresh ideas from the paste-firewall pass
- **Paste risk rail**: show a tiny rail or chip when a pasted payload was staged, literalized, or denied, with one-click explanation and resend options.
- **Prompt-local smooth paste, transcript-level honesty**: if the shell has an exact live prompt and current command, direct paste can feel smooth; if not, the terminal should prefer stage-first instead of gambling on transcript neighborhood.
- **Remote paste provenance**: when clipboard or helper layers relay a paste across hosts or terminal helpers, keep a tiny provenance chip so users know what path actually delivered the bytes.

References: REF-XTERM-BRACKETED-PASTE, REF-BASH-COMMANDS-FOR-TEXT, REF-KITTY-CLIPBOARD, REF-GHOSTTY-RELEASE-130.

## Fresh shell ideas from the attention-watch pass
- **Watch cards, not invisible preference state**: `watch this command`, `watch this receipt`, or `watch this run` should mint one small exact card with state like `armed`, `matched`, `delivered`, `revealed`, `expired`, or `stale`.
- **Exact output-slice cards**: make `copy output`, `attach to chat`, `open in editor`, and `annotate this failure` all bind to one bounded command-output object instead of whatever text happens to be selected nearby.
- **Subslice without provenance loss**: allow users to narrow from whole command output to one exact subspan while keeping owning frame, cwd, exit code, and trust visible for later handoff.
- **Reveal-first completion watch**: when a watch fires, default to reveal/focus/open of the exact frame or receipt before any stronger follow-on action.
- **Boundary-specific watches**: let the user watch `frame finished`, `receipt settled`, `status barrier crossed`, or `request responded` explicitly instead of one vague `notify me when done`.
- **Parse-lens fallback should stay visibly weaker**: if exact shell footing is missing, allow `watch this candidate command block` as a weaker labeled move rather than laundering parse guesses into authority.

## Fresh shell ideas from the command-evidence pass
- **Attach last failure as one exact evidence card**: let one keystroke gather command text, exact output slice, exit code/end cause, duration, cwd, and nearby receipt/run refs without exporting unrelated scrollback.
- **Redact-before-share should be inline**: dropping cwd, host lineage, or selected output lines should preserve bundle provenance instead of forcing users to start over with raw copy/paste.
- **Whole interaction, not whole pane**: `share this run`, `attach to proposal`, and `open evidence elsewhere` should all resolve to one exact command-evidence object rather than to viewport history.
References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1109, REF-VSCODE-SHELL-INTEGRATION, REF-WEZTERM-SELECT-TEXT-AT-MOUSE.

## Fresh shell idea: component-scoped helper shells
- **Shell into this exact component scope**: make component-scoped helper shells a first-class action with an exact target anchor, visible breadcrumb, and policy-bounded recipe instead of a cwd trick or a hidden remote-exec hole.
- **Helper shell is not the service**: keep `observe`, `helper shell`, `control`, `debug`, and `reload` as visibly different cards so shell entry never flatters itself into lifecycle authority.
- **Expiry should be ordinary**: if the component restarts, reloads incompatibly, or the scope disappears, the shell should say `expired`, `rebind required`, or `replaced` instead of pretending the old prompt still speaks for the new run.
- **One-shot and interactive entry should share one seam**: `run one command in this scope` and `open an interactive shell in this scope` want the same exact target binding and the same downgrade story.
- **Reload humility beside shell entry**: when the UI offers `reload this scope`, it should say whether the helper shell survived, expired, or needs a fresh bind rather than implying in-place continuity.

## Fresh shell ideas from the repair-card pass
- **Failure chips should bloom into repair cards**: clicking a failed verdict chip should open one exact reviewable repair card over that frame instead of dumping the user into generic docs or rerunning blindly.
- **Disabled repairs should still teach**: keep blocked repair actions visible with `policy blocked`, `stale anchor`, `needs fresh intent`, `retry after`, or `missing capability` rather than hiding them.
- **Repair cards should show their footing**: exact frame/verdict/receipt, parsed candidate, or remembered history should be plainly labeled so the user knows how strong the card really is.
- **One action card, many safe exits**: `insert`, `stage`, `open target`, `copy selector`, and `explain` should usually beat auto-run for repair cards.
- **Component failures deserve the same UX as shell failures**: a repair-gated component should be able to surface frame-local `explain`, `open failure evidence`, `request clear`, or `reload scope` cards with the same exact-anchor honesty.

References: REF-VSCODE-UPDATE-1072, REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SEMANTIC-ZONES.

- **Patch-before-run rails**: when Steward has one exact current command or exact rerun source, quick fixes should open a tiny `before → after` patch card with `insert`, `replace`, `copy`, and `run` kept visibly distinct.


## Fresh shell ideas from the state-explainer pass
- **Explain-this-state chips**: every failed verdict chip, pending request chip, hold-state badge, or repair gate should be able to open one tiny exact explainer card instead of dumping the user into logs.
- **Reason rails over exact anchors**: `why waiting`, `why blocked`, `why repair-required`, and `why rebind-required` should bind to one frame/run/request anchor and reveal supporting facts with freshness labels.
- **Structured state detail hover**: steal the spirit of shell-integration detail views and semantic inspectors so users can see shell quality, anchor quality, and the exact facts behind an explainer without leaving the terminal.
- **Candidate explainers stay visibly weaker**: when only parse-lens footing survives, let the terminal say `candidate explanation` rather than pretending it knows the exact provider-owned reason.
References: REF-SD-NOTIFY, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1099, REF-WEZTERM-SEMANTIC-ZONES, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-FUCHSIA-INSPECT-TREE.

## Fresh shell ideas from the assist-receipt pass
- **Suggestion provenance chips**: every quick fix, repair card, chooser follow-on, or current-line assist should be able to open one tiny receipt card that says why it appeared, what exact anchor it targets, how fresh it is, and why stronger apply paths may be disabled.
- **Stable suggestion identity, richer later detail**: a suggestion may start as a tiny exact receipt and later reveal more detail like changed spans, diagnostics, or selector evidence, but it should not silently retarget to a different command or frame.
- **Candidate assist receipts stay visibly weaker**: when only parse-lens footing survives, let the terminal say `candidate suggestion` or `candidate repair` rather than flattering it into exact shell truth.
References: REF-VSCODE-CODEACTION-API, REF-LSP-317-CODEACTION, REF-VSCODE-SHELL-INTEGRATION.

## Fresh shell ideas from the injection-receipt pass
- **Mutation receipts beside prompt leases**: whenever Steward inserts, replaces, stages, or loads something into a live shell/session, leave a tiny exact receipt chip near the owning prompt/frame instead of acting like the shell magically changed itself.
- **Run and write are sibling actions, not one path**: `insert`, `replace`, `copy`, and `run` should feel like visibly different exits from the same suggestion/patch card.
- **History-aware receipts**: let the shell say `ordinary history`, `Steward remembered only`, or `tool history-suppressed` so later replay/explain UX knows what really happened.
- **Exact session mutation should still degrade honestly**: if the live prompt or session target vanished, surface `candidate mutation` rather than silently retargeting the old action.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-CODEACTION-API, REF-VSCODE-UPDATE-1108.

## Fresh shell/terminal ideas from the activation-demand episode pass
- Show cold-start demand as a small exact card: `accepted`, `buffered while waking`, `delivered`, `runtime accepted`, `timed out`, `caller canceled`, or `shed`.
- Let `cancel this wake` target the exact request context when the caller is no longer interested, instead of leaving a hidden background start in progress.
- When a first request timed out but later caused the component to become ready, keep both truths visible: the component warmed, but that request failed.
- Surface an event-lifetime chip when a runtime has explicitly asked for bounded work extension, and expire it visibly rather than pretending background work is ambient.
References: REF-KNATIVE-SERVING-ARCHITECTURE, REF-CLOUD-RUN-REQUEST-TIMEOUT, REF-MDN-EXTENDABLEEVENT-WAITUNTIL, REF-CHROME-EXTENSION-SW-LIFECYCLE.

