# Lessons from the past

These are the lessons Steward probably **must** learn before it hardens its semantics.

## 1. Services supervised by the fabric should stay foreground and accountable
launchd, daemontools, and runit all point to the same operational lesson: if the manager is responsible for lifecycle, the “real service” should not disappear behind daemonizing or double-fork folklore. Steward should not build a portable contract around backgrounding tricks and PID guessing.
References: REF-LAUNCHD-JOBS, REF-DAEMONTOOLS-SUPERVISE, REF-RUNIT-OVERVIEW.

## 2. Activation is powerful, but the stable public face should belong to the manager
systemd and launchd both show the value of manager-owned activation. The lesson to steal is not “inherit everything”; it is that the stable listener/end-point identity can belong to the system and be handed to a fresh instance.
References: REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-SD-LISTEN-FDS, REF-LAUNCHD-JOBS, REF-LAUNCHD-SOCKETS.

## 3. Name-based activation can be safer than path-and-environment folklore
D-Bus system activation is a sharp reminder that a launcher can accept only a validated service name, clear environment state, and keep the privileged helper extremely narrow. Steward should remember that activation identity can be a named object or capability key rather than “run this path with whatever session baggage we inherited.”
References: REF-DBUS-SYSTEM-ACTIVATION.

## 3a. Restartable launch context must be explicit, not ambient
## 3b. Request identity is not live interaction state
XDG portals and similar mediated systems teach a useful honesty rule: the requester may hold a stable local key or selector, but the live request object and its current state are provider-owned and expire in ordinary ways. Steward should keep pending chooser/open/approval detours object-shaped without mistaking their identities for durable grants or current live truth.
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION, REF-XDG-PORTAL-OPENURI.

## 3c. Completed detour outcomes should stay separate from live request and session state
XDG portals are equally clear that a request lives for the interaction and later responds with results, while some flows may also yield a separate session handle or single-use restore token. Steward should steal that shape for chooser/open/auth detours: one pending request object while the interaction is live, one typed outcome when it finishes, and any longer-lived grant/session truth named separately.
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-REMOTE-DESKTOP.

systemd's new-style daemon guidance, its execution-environment docs, and Fuchsia's runner split point to the same lesson: if the lifecycle fabric owns restart and accountability, the reviewed entry and launch baseline should be explicit. Steward should not let login-shell rc files, global manager environment knobs, terminal attachment, or ambient `PATH` resolution quietly become restart-critical semantics.
References: REF-SYSTEMD-DAEMON, REF-SYSTEMD-EXEC, REF-FUCHSIA-RUNNER.

## 3d. Weak parsed structure is valuable, but it must stay visibly weaker than exact shell truth
Kitty's hints/open-actions and VS Code's shell integration point to the same caution: when the terminal is guessing from visible text, it can still offer useful actions, but that path is weaker than explicit shell-reported command/frame metadata. Tree-sitter adds the useful reminder that partial incremental structure can improve over time without becoming canonical truth. Steward should steal parse lenses, but keep them candidate-only, provenance-labeled, and review-first for risky actions.
References: REF-KITTY-HINTS, REF-KITTY-OPEN-ACTIONS, REF-VSCODE-SHELL-INTEGRATION, REF-TREESITTER.

## 4. Keep supervision smaller than the total service-manager problem
Erlang/OTP, Solaris SMF, s6, daemontools, and runit all make it easier to reason when “keep this thing alive” is not collapsed into every other machine-state concern. That is a strong argument for Steward to keep component supervision narrow and resist becoming a giant dependency/admin/timer language too early.
References: REF-ERLANG-OTP-SUPERVISOR, REF-SOLARIS-SMF-RESTARTER, REF-S6-RC-WHY, REF-DAEMONTOOLS-SUPERVISE, REF-RUNIT-OVERVIEW.

## 5. Readiness is not the same thing as spawn success
s6 explicitly calls out the race between “daemon exec'd” and “service is really ready,” and Kubernetes institutionalized a clean split between startup, readiness, and liveness. Steward should not regress to guessing readiness from process birth.
References: REF-S6-READY, REF-K8S-PROBES.

## 6. Shallow readiness is real and should be named honestly
Historical systems often have a useful but weaker notion of “the control plane is listening” or “the supervisor can accept commands” before the real service can serve work. s6's shallow readiness warning and Dinit's readiness handling both suggest Steward should keep `control-ready` separate from declared-work ready when that distinction matters.
References: REF-S6-SHALLOW-READINESS, REF-S6-READY, REF-DINIT-SERVICE.

## 7. Restart loops need bounded semantics, not vibes
Historical supervisors all grow some response to crash loops: daemontools pauses after immediate failure, launchd warns about respawning too fast, and OTP makes restart intensity and period explicit. Steward should expose bounded restart intent and keep crash-loop handling explainable.
References: REF-DAEMONTOOLS-SUPERVISE, REF-LAUNCHD-JOBS, REF-ERLANG-OTP-SUPERVISOR.

## 8. Status deserves its own compact channel
systemd's notify protocol is useful not only for `READY=1` but also for `STATUS=...`, `STOPPING=1`, and barriers that close attribution races. The lesson is not “copy sd_notify whole”; it is that state/status updates should be compact, explicit, and distinct from log archaeology.
References: REF-SD-NOTIFY.

## 8a. Exact command result is different from raw output
Modern shell-integrated terminals keep rediscovering the same lesson: users want a tiny trustworthy answer to “did that exact command succeed or fail?” VS Code decorates commands based on exit codes, Windows Terminal lets the shell mark prompt/command/output boundaries and provide an exit code for command-finished marks, and iTerm2 uses marks to drive completion alerts and copy-the-last-command output. Steward should steal the compact command-verdict idea instead of forcing every shell affordance to scrape output or carry a full evidence bundle.
References: REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-SHELL-INTEGRATION.

## 8b. Reviewable command mutation is different from both source truth and execution
Git's interactive patch flow and VS Code's code-action model point to the same lesson: the most helpful fixes are often reviewed mutations over a stronger source, not silent rewrite magic. `git add -p` and `git add -e` explicitly let the user review or even edit the patch before it is applied, while VS Code code actions can carry an edit, a later command, and a human-readable disabled reason. Steward should steal the tiny command-patch seam so quick fixes, assisted rewrites, and history-backed reruns can stage one reviewable change over one stronger command anchor without pretending the patch is already executed truth.
References: REF-GIT-ADD, REF-VSCODE-CODEACTION-API, REF-VSCODE-SHELL-INTEGRATION.

## 9. Continuity should be bounded escrow, not magical resurrection
systemd's fd store and Fuchsia's idle-stop escrow both point toward a narrow continuity story: preserve exactly what matters, in bounded ways, instead of promising whole-process resurrection semantics.
References: REF-SYSTEMD-FDSTORE, REF-FUCHSIA-IDLE-STOP.

## 10. Persistent state can outlive execution without implying that the component is still “running”
Fuchsia's lifecycle docs make a useful point: component instances may keep isolated persistent state while they are not running. Steward should be able to express continuity and restart-adjacent persistence without implying that execution never really stopped.
References: REF-FUCHSIA-LIFECYCLE.

## 11. Runners and restarters are a useful seam
Fuchsia's runner model and Solaris restarters both demonstrate the value of separating framework-owned lifecycle meaning from how a particular runtime is launched. Steward should keep that seam visible.
References: REF-FUCHSIA-RUNNER, REF-SOLARIS-SMF-RESTARTER.

## 12. Oneshot transitions need accountability too
s6-rc's transition model is a good reminder that one-shot start/stop work should still be reproducible, bounded, and attributable to the lifecycle fabric rather than disappearing as random helper children of whatever happened to invoke them.
References: REF-S6-RC-TRANSITIONS.

## 13. Idleness needs explicit activity boundaries, not wishful heuristics
Apple's XPC transactions and Fuchsia's idle-stop flow both suggest the same lesson: the interesting question is not “is the process alive?” but “is work still in flight, and if not, what narrow state can be escrowed safely?” Steward should learn from explicit begin/end or drain/idle hints instead of pretending CPU quiet or log silence means “safe to stop”.
References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-FUCHSIA-IDLE-STOP.

## 13a. Renewal should confirm one exact live claim, not launder broad health truth
Kubernetes Lease renewals, etcd lease keepalives, and systemd watchdog pings all show the same design lesson: renewal is about the continuity of one exact asserted window, and managers often choose or clamp the real budget. Steward should steal that narrowness instead of treating any keepalive as proof that all surrounding work is healthy or all related authority should persist forever.
References: REF-K8S-LEASES, REF-ETCD-LEASES, REF-SD-WATCHDOG-ENABLED, REF-SD-NOTIFY.

## 13b. Renewal alone does not stop stale holders from acting
Hazelcast's FencedLock docs and etcd's concurrency API both point to the same harder lesson: once ownership can move, an old holder may still be delayed, paused, or partitioned and try to act anyway. The answer is not bigger folklore about lease timeouts; it is an exact stale-holder fence such as a monotonic fencing token or a current-owner proof that can be checked at effect time. Steward should steal that seam but keep it smaller than a universal distributed-lock family.
References: REF-HAZELCAST-FENCEDLOCK, REF-ETCD-CONCURRENCY-LOCK.

## 14. Health checks are useful, but they are an adjunct, not the primary portable truth
OpenRC's supervise-daemon shows that periodic health checks and unhealthy hooks can be operationally useful. The cautionary lesson for Steward is to keep such checks as local adapter policy unless and until a narrow portable contract is truly earned.
References: REF-OPENRC-SUPERVISE-DAEMON.

## 15. A user-service manager can be a good source of ideas without becoming the architecture
Dinit is a useful reminder that there is a middle ground between tiny supervise-only suites and giant integrated managers. Its split between manager control readiness and per-service ready notification is especially relevant to Steward's observation vocabulary.
References: REF-DINIT-OVERVIEW, REF-DINIT-SERVICE.

## 16. Transient work can still be accountable work
GNU Shepherd's transient services and systemd-run's transient units show that “run this now” does not have to mean “lose all lifecycle accountability.” Steward should steal the accountability lesson while refusing to inherit a giant transient-unit property language by default.
References: REF-GNU-SHEPHERD-OVERVIEW, REF-GNU-SHEPHERD-TRANSIENT, REF-GNU-SHEPHERD-TRANSIENT-MAKER, REF-SYSTEMD-RUN.

## 16a. Desired revision, observed revision, and settled revision are different truths
Kubernetes' `metadata.generation` and `status.observedGeneration` make a sharp point: status may honestly describe the previous sync loop even after a newer desired spec already exists. Nomad adds a sibling lesson by showing desired changes versus currently applied changes in deployment status and by keeping “last stable job” distinct for revert logic. systemd's `RELOADING=1` plus later `READY=1` and `MONOTONIC_USEC=` reinforce the same shape from another angle: mid-run transition acknowledgement is not the same as settled completion. Steward should steal the tiny seam, not the giant controller worldview: keep desired, observed, and settled revision truth visibly distinct.
References: REF-K8S-PODS-OBSERVED-GENERATION, REF-K8S-DEPLOYMENT, REF-NOMAD-DEPLOYMENT-STATUS, REF-NOMAD-UPDATE, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE.

## 16b. Allowed is not the same as spendable headroom
Kubernetes ResourceQuota, Nomad quotas, systemd start-rate limiting, and GitHub's explicit primary versus secondary rate limits all point to the same operational lesson: an action may be fully authorized and still not be spendable now because the relevant ceiling or window is exhausted. Steward should steal that honesty. It should say whether the blocker is restart budget, quota room, or rate window instead of flattening everything into a generic denial or busy state.
References: REF-K8S-RESOURCE-QUOTAS, REF-NOMAD-QUOTA, REF-SYSTEMD-UNIT, REF-SYSTEMCTL, REF-GITHUB-RATE-LIMITS.

## 17. Parseable side channels beat terminal scraping
tmux control mode demonstrates that a terminal-adjacent tool can expose command output, notifications, flow control, and subscriptions over a simple textual protocol that survives SSH, instead of forcing consumers to reverse-engineer the rendered screen.
References: REF-TMUX-CONTROL-MODE, REF-TMUX-CHANGES.

## 18. Good terminals are semantic, not only textual
WezTerm, kitty, iTerm2, VS Code, Windows Terminal, and Ghostty all demonstrate that prompt marks, cwd reporting, command frames, hyperlinks, and exact output selection materially improve shell UX. The lesson for Steward is to make those semantics explicit while keeping them observational.
References: REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION, REF-ITERM2-SHELL-INTEGRATION, REF-OSC133-SPEC, REF-ITERM2-ESCAPE-CODES, REF-GHOSTTY-SHELL-INTEGRATION.

## 19. Semantic shell markers need provenance, not just syntax
VS Code's shell integration trust model is a sharp lesson: a terminal can distinguish between guessed command boundaries and explicitly reported, nonce-bound command data. Steward should steal the idea that semantic shell markers can have confidence levels and trusted provenance instead of pretending every escape sequence is equally believable.
References: REF-VSCODE-SHELL-TRUST, REF-VSCODE-SHELL-INTEGRATION.

## 20. Fresh prompt metadata matters more than clever stale heuristics
Recent fish shell work and Ghostty's integration posture are a good reminder that shells should proactively report cwd and prompt boundaries on fresh prompts to avoid stale terminal state after nested shells or SSH hops. Steward's shell story should prefer explicit refresh over terminal-side guesswork.
References: REF-FISH-OSC-MARKERS, REF-FISH-TERMINAL-COMPAT, REF-GHOSTTY-SHELL-INTEGRATION.

## 21. Input ambiguity deserves the same respect as output ambiguity
Bracketed paste and enhanced keyboard protocols solve real ambiguity: pasted text is not the same as typed text, and ambiguous escape timings are not a great basis for a modern interactive shell. Steward's custom terminal should steal those lessons early.
References: REF-XTERM-BRACKETED-PASTE, REF-KITTY-KEYBOARD-PROTOCOL.

## 22. Focus-aware notifications are a real quality-of-life feature
Ghostty's command-finish notifications, iTerm2's mark-based alerting, and WezTerm's focus-sensitive notification handling all point to the same lesson: once command boundaries are explicit, the terminal can notify at the right moment and only as loudly as current focus really warrants. Steward should remember that tiny semantic hooks can produce outsized UX wins.
References: REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE, REF-ITERM2-SHELL-INTEGRATION, REF-WEZTERM-NOTIFICATION-HANDLING.


## 23. Users need filtering and suppression, not just more bells
kitty's desktop-notification protocol and Ghostty's command-finish settings both reinforce an operational lesson: once notifications exist, users must be able to filter classes, suppress noise, and decide whether a cue becomes a bell, a toast, or nothing at all. Steward should steal the filtering lesson early rather than inventing one noisy default.
References: REF-KITTY-DESKTOP-NOTIFICATIONS, REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE.

## 24. Progress deserves a tiny capability-scoped hint instead of screen scraping
Windows Terminal's OSC 9;4 progress support and iTerm2's feature-reporting `PROGRESS` bit suggest a useful modern pattern: long-running commands can expose compact progress or indeterminate-busy state in tab/taskbar chrome when the terminal explicitly says it supports it. Steward should keep any progress story small, optional, and capability-gated.
References: REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-FEATURE-REPORTING.

## 25. Remote shell UX can be made resilient without lying about state
Mosh proves that roaming, intermittent connectivity, and predictive local echo can materially improve shell feel without requiring every remote program to be rewritten. Steward should at least explore which parts of that resilience belong in a SlopOS shell/terminal stack.
References: REF-MOSH.

## 26. Snapshot-plus-change subscriptions beat polling and bespoke per-property signals
D-Bus API guidance and tmux's newer control-mode work point at the same lesson: bounded snapshot-plus-change interfaces reduce polling, coalesce better than ad hoc change signals, and remain easier to version than undocumented streams. Steward should prefer a tiny explicit observation-subscription seam over terminal scraping or dozens of one-off watcher hooks.
References: REF-DBUS-API-DESIGN, REF-TMUX-CONTROL-MODE, REF-TMUX-CHANGES.

## 27. Avoid speculative start and filesystem-trigger folklore
launchd's own man page warns that `RunAtLoad` should be avoided because speculative launches hurt boot/login, and it explicitly discourages path-watching keys because filesystem monitoring is race-prone and lossy. Steward should prefer activation, explicit jobs/background seams, and accountable requests over “watch this path and hope”.
References: REF-LAUNCHD-SOCKETS.

## 28. Small terminal extensions age better than “re-imagine the TTY” projects
kitty's protocol-extension design goal is refreshingly modest: add small unobtrusive capabilities, keep the TTY a byte stream, and move the minimum extra logic into the terminal. Steward should steal that restraint for its shell+terminal side channel.
References: REF-KITTY-PROTOCOL-EXTENSIONS.

## 29. Action surfaces are powerful when they stay explicit, local, and user-invoked
kitty's hyperlink open-actions and Ghostty's command-palette direction both suggest a good rule: rich terminal actions are useful, but they should stay explicit affordances over concrete targets, not become silent control semantics hidden in scrollback.
References: REF-KITTY-OPEN-ACTIONS, REF-GHOSTTY-RELEASE-120.

## 30. Stop policy should respect explicit in-flight boundaries, not vibes
launchd's transaction and Pressured Exit semantics are a useful reminder that “safe to stop now” and “currently inactive enough to reclaim” are not the same as a boolean process-alive check. Steward should keep that lesson narrow: explicit activity hints and stale-action fences are healthier than inferred safety from logs or terminal silence.
References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-LAUNCHD-XPC.

## 31. Per-run identity is worth stealing, but keep it opaque
systemd’s invocation identity and journal linkage are a useful reminder that “which concrete run was this?” is a different question from “which component is this?”. Steward should keep that distinction, but without letting it turn back into a portable PID/process-tree contract.
References: REF-SYSTEMD-EXEC, REF-SYSTEMD-SERVICE.

## 32. End-of-cycle cause should be explicit, compact, and humble
Fuchsia’s stop payloads and systemd’s result categories both suggest the same lesson: a lifecycle fabric is healthier when it can say “requested stop”, “clean exit”, “signal/crash”, “timeout/watchdog”, or “resource/policy kill” directly. Steward should steal the compact vocabulary, not a giant universal fault matrix.
References: REF-FUCHSIA-COMPONENT-RUNNER, REF-FUCHSIA-LIFECYCLE, REF-SYSTEMD-SERVICE.

## 33. Shell semantics get better when layer boundaries are admitted instead of hidden
OSC 133 prompt markers, tmux control mode, and VS Code’s nonce-bound command reporting all point the same way: a semantic shell/terminal stack should be willing to say when it knows something exactly, when it knows it approximately, and when a hop or multiplexer degraded precision.
References: REF-OSC133-SPEC, REF-TMUX-CONTROL-MODE, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-SHELL-TRUST.

## 34. Terminal capability names are not the same as terminal truth
The xterm and ncurses documentation are blunt about a long-running problem: many terminals claim xterm compatibility while differing in important behavior, and terminal descriptions sometimes must omit or pessimistically treat capabilities because support is uneven. Steward should learn the cultural lesson: prefer fresh markers, explicit capability use, and visible downgrade over folklore like “TERM says xterm, so it must work.”
References: REF-NCURSES-FAQ, REF-XTERM-FAQ, REF-FISH-TERMINAL-COMPAT.

## 35. Progressive enhancement beats giant mandatory baselines
fish compatibility docs, iTerm2 feature reporting, and kitty's keyboard/protocol work all point in the same direction: optional features can be discovered or ignored safely, and richer semantics should improve the experience without breaking the baseline stream. Steward should steal that approach for shell/terminal evolution.
References: REF-FISH-TERMINAL-COMPAT, REF-FISH-OSC-MARKERS, REF-ITERM2-FEATURE-REPORTING, REF-KITTY-KEYBOARD-PROTOCOL, REF-KITTY-PROTOCOL-EXTENSIONS.

## 36. Capability handshakes should report live support, not desired UX
Modern terminals still live with a messy substrate of nested shells, multiplexers, and partial compatibility. A small explicit feature-reporting or capability-handshake layer is useful precisely because desired affordances such as exact command reporting, hyperlinks, or synchronized redraw are not the same as what the current path has actually proven it can do.
References: REF-ITERM2-FEATURE-REPORTING, REF-FISH-TERMINAL-COMPAT, REF-XTERM-FAQ.

## 36a. Capability truth should stay path-scoped and refreshable
Modern terminal UX is a stack of shell reports, terminal feature signals, mux passthrough, and remote-hop preservation. WezTerm's pane user vars, kitty's remote-aware shell integration, Ghostty's newer OSC 133 click support, and iTerm2's feature reporting all point at the same lesson: what matters is not a machine-wide compatibility myth, but what the current pane/hop path has actually preserved right now. Steward should keep one tiny capability ledger for that live truth instead of relying on remembered success or `TERM` folklore.
References: REF-ITERM2-FEATURE-REPORTING, REF-WEZTERM-PANE-USER-VARS, REF-KITTY-SSH, REF-GHOSTTY-RELEASE-130.

## 37. Atomic redraw hints are worth stealing even when they are not universal
WezTerm's support for synchronized rendering is a nice reminder that not every terminal improvement has to be semantic metadata; reducing redraw tearing during prompt, frame, or status updates can make a shell feel dramatically more solid. Steward should treat this as an optional hint, not as a correctness dependency.
References: REF-WEZTERM-SYNC-RENDER.

## 38. Giant integrated managers accumulate hidden policy
This is the main cautionary lesson from classic service-manager evolution: once timers, readiness, logging, dependencies, sandboxes, environment shaping, socket activation, and admin UX all live in one product contract, it becomes hard to tell which semantics are essential and which are historical accidents. Steward should fight that drift from day 1.

## 39. Fresh resync is better than stale semantic confidence
VS Code's nonce-bound command reporting, iTerm2's live feature reporting, tmux's parseable control path, and Ghostty's command-finish UX all suggest the same lesson: shell semantics are most useful when they can be refreshed explicitly after a hop, restart, or confusion. Steward should prefer a tiny new semantic epoch over quietly carrying forward stale trust.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-SHELL-TRUST, REF-ITERM2-FEATURE-REPORTING, REF-TMUX-CONTROL-MODE, REF-GHOSTTY-CONFIG-REFERENCE.

## 40. Remote-aware shell semantics get much better when hop boundaries are explicit
WezTerm pane/user-var plumbing, kitty's SSH shell-integration path, and Ghostty's recent SSH integration work all point to the same lesson: host/path-aware shell UX improves sharply when remote host, cwd authority, and preserved markers are reported explicitly per path instead of guessed from prompts or ambient session ancestry. Steward should steal the explicit path hints, not a giant remote-control worldview.
References: REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-KITTY-SSH, REF-GHOSTTY-RELEASE-120.

## 41. Good shell UX should grade certainty instead of hiding it
VS Code's shell integration model is unusually clear about a helpful truth: command lines can be low, medium, or high confidence, and only nonce-verified high-confidence reports are safe to treat as trusted for rerun-sensitive UX. Steward should steal that honesty and extend it beyond command text to cwd, remote path hints, and action targets.
References: REF-VSCODE-SHELL-TRUST, REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.


## 42. Latency-hiding UX should stay visibly tentative until confirmation
Mosh is a sharp reminder that predictive local echo and line editing can make remote shells feel dramatically better on weak links, but the deeper lesson for Steward is about honesty: prompt-local optimism is useful only if the system can later confirm, refine, or visibly roll back what was tentative. VS Code's shell execution model points in the same direction by allowing command details to become more accurate later and treating nonce-verified reports differently from weaker observations.
References: REF-MOSH, REF-MOSH-PAPER, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-SHELL-TRUST.


## 43. Exact target anchors beat scraping rendered text
iTerm2 command selection, OSC 8 hyperlinks, kitty open-actions, tmux pane IDs in control mode, and VS Code's link-confidence ordering all reinforce the same lesson: if the user is meant to act on a specific command, output region, file, receipt, or concrete run, Steward should prefer an explicit target anchor over reconstructing intent from whatever text happens to be visible.
References: REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-HYPERLINKS, REF-KITTY-OPEN-ACTIONS, REF-TMUX-CONTROL-MODE, REF-VSCODE-TERMINAL-BASICS.

## 44. Riskier actions deserve stronger anchors than low-risk navigation
History already shows the difference between “open this link” and “run or mutate something over there.” iTerm2 command URLs, VS Code's low-confidence word links, and kitty's configurable open-actions all suggest the same caution: open/copy/reveal can tolerate weaker binding, but rerun/stop/act-on-same-run should demand fresher exact anchors, explicit confirmation, or both.
References: REF-ITERM2-COMMAND-SELECTION, REF-VSCODE-TERMINAL-BASICS, REF-KITTY-OPEN-ACTIONS.


## 45. The best terminal chrome is observational and separate from the durable transcript
iTerm2's status bar and badges, WezTerm's right-status area, Windows Terminal's smart tab titles and progress strings, and VS Code's command decorations/sticky-scroll style overlays all point to the same lesson: live shell context is often best shown in non-transcript chrome. Steward should steal that separation. Let the durable transcript stay command/output/receipt truth, and let chrome be a freshness-scoped summary layer that can clear, resync, or downgrade without rewriting history.
References: REF-ITERM2-STATUS-BAR, REF-ITERM2-BADGES, REF-WEZTERM-RIGHT-STATUS, REF-VSCODE-TERMINAL-BASICS, REF-VSCODE-UPDATE-1106, REF-WINDOWS-TERMINAL-TIPS, REF-WINDOWS-TERMINAL-PROGRESS.

## 46. Terminal modes and prompt semantics need a repair path
xterm's reset behavior, iTerm2's tmux-crash guidance, and Ghostty's explicit reset action all point to the same operational truth: shells and terminal programs leave state behind, and sometimes that state wedges. Steward should not pretend shell semantics are robust if the only repair story is folklore and manual incantation.
References: REF-XTERM-MANPAGE, REF-ITERM2-TMUX-INTEGRATION, REF-GHOSTTY-RESET-ACTION.

## 47. Fresh prompt reassertion beats trusting leftover terminal state
fish reporting cwd on every fresh prompt, and kitty letting shell integration reassert prompt-local cursor shape, reinforce a great small lesson: when the shell regains control, it should restate the semantic baseline it cares about instead of assuming intermediate programs left the terminal in the right mode.
References: REF-FISH-OSC-MARKERS, REF-KITTY-CONF.


## 48. Exact handoff bundles beat whole-scrollback folklore
Modern terminal UX is getting sharply better when users can share *the exact command interaction* rather than pasting random scrollback. VS Code's terminal command attachments now share the command line, captured output, and exit code as explicit context, later versions add compact status details and collapsible command sections, and iTerm2/WezTerm keep reinforcing the value of exact command or output-region selection. Steward should steal the bounded exact handoff idea, not an ambient “share the whole pane” habit.
References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1110, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SHELL-INTEGRATION.

## 49. Repeated failure should quiet visibly before it becomes invisible damage
OTP restart intensity, launchd throttle intervals, systemd start-rate limiting, Kubernetes CrashLoopBackOff, SMF maintenance, and Shepherd respawn limits all point to the same lesson: a lifecycle fabric needs a small, explicit answer to “what happens when this keeps failing?” Steward should steal the visibility, bounded retry, and explicit repair/clear lesson without freezing a giant portable policy grammar too early.
References: REF-ERLANG-OTP-SUPERVISOR, REF-LAUNCHD-SOCKETS, REF-SYSTEMD-SERVICE, REF-SYSTEMD-UNIT, REF-K8S-POD-LIFECYCLE, REF-SMF-MAINTENANCE, REF-GNU-SHEPHERD-MANUAL.

## 28. Attribution races are not theory; status delivery needs a visible synchronization story
`sd_notify()` is a reminder that a fabric can have explicit state updates and still lose attribution if the sender is not runtime-tracked or exits too quickly; the barrier primitive exists precisely because that race is real. Steward should keep provenance and synchronization visible anywhere component-owned status can cross the manager boundary.
References: REF-SD-NOTIFY.

## 29. A supervision leaf should really be a leaf
s6's explicit `run`/`finish` split sharpens an older lesson: the supervised leaf should stay the long-lived accountable thing, while cleanup is short-lived and visibly separate. Steward should not normalize wrapper trees where the interesting runtime escaped before the lifecycle fabric could name it.
References: REF-S6-SUPERVISE, REF-DAEMONTOOLS-SUPERVISE.

## 30. Dynamic dependencies should stay dynamic
launchd's old guidance about network availability is still an important caution: some dependencies are not stable boot-order facts. Steward should avoid hardening lifecycle semantics around ambient assumptions like “the network is up now forever” when the right contract is really a dynamic readiness or availability observation.
References: REF-LAUNCHD-JOBS.

## 31. Capability routing beats ambient inheritance
Fuchsia's component manager is a useful reminder that a lifecycle fabric can both launch things on demand and stay opinionated about capability routing and accountability. Steward should keep stealing the idea that activation is strongest when the manager mediates introductions explicitly instead of letting components inherit whatever the caller happened to have open.
References: REF-FUCHSIA-RUNNER, REF-FUCHSIA-LIFECYCLE.

## 32. Modern paste hazards are stronger than old bracketed-paste assumptions
Bracketed paste solved one real ambiguity, but recent terminal security work shows pasted control characters can still be dangerous in practice. Steward's custom shell+terminal should treat paste as its own reviewed intent path, not as "just keyboard input but faster".
References: REF-XTERM-BRACKETED-PASTE, REF-GHOSTTY-RELEASE-130.

## 33. Progressive enhancement is part of correctness, not just polish
fish's terminal-compatibility guidance points to a quiet but crucial lesson: unsupported valid terminal sequences should be ignored rather than treated as corruption. Steward should prefer tiny semantic extensions that degrade by safe omission, because that keeps richer UX compatible with mixed hops, multiplexers, and future terminals.
References: REF-FISH-TERMINAL-COMPAT.


## 50. Exact service leaves beat wrapper folklore
s6's service-directory model reinforces a subtle but valuable supervision lesson: the long-lived accountable thing should really be the supervised `run` leaf, not an opaque wrapper whose interesting child escaped elsewhere. Steward should keep the named supervised object as the thing users can restart, explain, and correlate.
References: REF-S6-SUPERVISE, REF-S6-SERVICEDIR.

## 51. Dynamic conditions are not durable dependencies
launchd's old network-availability warning is still the right caution: some things that matter to a service are changing conditions, not stable ordering facts. Steward should prefer explicit waiting/degraded/readiness truth over cargo-cult dependency edges for network, peer, or session availability.
References: REF-LAUNCHD-JOBS, REF-K8S-PROBES, REF-DINIT-SERVICE.

## 52. Remote comfort is worth stealing only when it stays observational
Modern terminal work shows a very attractive pattern: carry cwd, prompt marks, output paging, and notifications cleanly across remote hops when you can, but admit the transport facts and degrade honestly when you cannot. Steward should steal the comfort features without turning them into ambient authority.
References: REF-KITTY-SHELL-INTEGRATION, REF-KITTY-SSH, REF-GHOSTTY-SHELL-INTEGRATION, REF-KITTY-NOTIFY.


## 52. Transition helpers should be attributable and separate from the supervised leaf
s6-rc's longrun-versus-oneshot split, OTP's ordered start/stop model, and Shepherd's transient-service machinery all point to the same lesson: short-lived transition work is real lifecycle fabric work, but it should not be confused with the long-lived service leaf that remains accountable over time. Steward should steal the distinction and the attribution story without cloning a giant hook grammar.
References: REF-S6-RC-OVERVIEW, REF-ERLANG-OTP-SUPERVISOR, REF-GNU-SHEPHERD-TRANSIENT-MAKER.

## 53. Control-ready and serve-ready must stay honestly different
Dinit's explicit ready-notification options and Windows Terminal's stable shell marks both reinforce a valuable cross-domain lesson: “the control path is now up” is often useful, but it is not the same truth as “the thing you care about is fully ready for work.” Steward should keep small named seams for these differences instead of flattening them into one optimistic bit.
References: REF-DINIT-SERVICE, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-K8S-PROBES.

## 54. Good shell memory is scoped context, not ambient authority
iTerm2's host-scoped command history and recent-directory memory, together with kitty's same-remote-context comfort, suggest a sharp lesson for Steward's future console: remembering where a command happened can make the shell feel brilliant, but that memory should remain scoped convenience rather than proof that authority or precision survived every hop unchanged.
References: REF-ITERM2-ONE-PAGE, REF-KITTY-SSH, REF-KITTY-SHELL-INTEGRATION.

## 55. Inherited descriptors are real authority, not boring process trivia
Systemd's daemon guidance, Apple's secure-coding guidance, and Ghostty's 1.1.0 security fix all point at the same lesson: leaked descriptors and inherited control channels are not implementation dust, they are authority handoffs. Steward should keep launch descriptor sets explicit and testable instead of trusting `close-on-exec` folklore and hoping nothing important stayed open.
References: REF-SYSTEMD-DAEMON, REF-APPLE-INHERITING-FDS, REF-GHOSTTY-RELEASE-110, REF-SD-NOTIFY.

## 56. Exact semantic zones beat screen scraping
Modern terminals keep rediscovering the same win: if prompt, input, and output boundaries are explicit, the UI can jump, select, notify, and explain without scraping rendered text. Steward should steal that lesson early because it improves ergonomics while keeping targets exact and policy-bounded.
References: REF-OSC133-SPEC, REF-WEZTERM-SCROLL-TO-PROMPT, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION.


## 57. Tiny explicit checkpoints beat boot-script folklore
Modern managers keep rediscovering the same thing: launch progress needs a few named checkpoints, not a big superstition pile. systemd's explicit notify types, Dinit's distinction between manager readiness and service readiness, launchd's exact socket-delivery seam, and Fuchsia's explicit `OnStop` event all point toward the same rule for Steward: keep launch delivery, control-ready, serve-ready, and stop progression attributable and compact instead of reconstructing them from wrapper scripts or sleep loops.
References: REF-SD-NOTIFY, REF-SYSTEMD-SERVICE, REF-DINIT-SERVICE, REF-LAUNCH-ACTIVATE-SOCKET, REF-FUCHSIA-COMPONENT-RUNNER.


## 56. Remembered shell context should stay convenience, not authority
iTerm2's shell integration and variables, WezTerm's OSC 1337/user-var support, and Windows Terminal's semantic shell integration all point to the same lesson: remembered cwd, host, command, or component hints can make a shell feel brilliant, but they should remain scoped observational context rather than launch input or policy truth.
References: REF-ITERM2-SHELL-INTEGRATION, REF-ITERM2-VARIABLES, REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.

## 57. Explicit in-flight brackets beat sticky keepalive folklore
XPC's explicit begin/end transaction calls and launchd's Pressured Exit behavior reinforce a valuable lifecycle lesson: if a service needs a brief "do not stop me yet" window, it is healthier to bracket that state explicitly than to infer it from ambient wrappers, leaked activity, or perpetual keepalive policy.
References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-LAUNCHD-SOCKETS, REF-FUCHSIA-IDLE-STOP.

## 58. Explicit work brackets should be balanced, attributable, and cuttable
The old failure mode is familiar: a service says it is "still busy" forever, or the operator has to guess whether a stop would lose work. Apple's XPC transactions and launchd's Pressured Exit semantics suggest a healthier lesson: begin/end work scopes should be explicit when a runtime can express them, scoped to the concrete running leaf, and visibly cuttable when they go stale or conflict with stronger policy. Steward should steal the narrowness, not the host-specific machinery.

References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-LAUNCHD-SOCKETS, REF-FUCHSIA-IDLE-STOP.

## 59. Live handles beat sticky keepalive state
The healthiest stop-deferral patterns stay live and scoped: `systemd-inhibit` acquires a lock for the lifetime of the wrapped command, and the XDG portal inhibit API returns a request handle that must later be closed. Steward should prefer live, attributable deferral ownership over durable booleans or "still busy somehow" folklore.
References: REF-SYSTEMD-INHIBIT-MAN, REF-SYSTEMD-INHIBITOR-LOCKS, REF-XDG-PORTAL-INHIBIT.

## 60. Delay is the right default; stronger vetoes should stay rare
Official inhibitor APIs keep rediscovering the same lesson: there is a big difference between "give me a short grace window" and "I can veto this forever." Steward should bias runtime-facing stop deferral toward bounded delay semantics and keep stronger block semantics rare, policy-owned, and visibly cuttable.
References: REF-SYSTEMD-INHIBIT-MAN, REF-SYSTEMD-INHIBITOR-LOCKS, REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END.

## 61. Live hints need explicit decay rules
Activity, progress, stop deferral, and shell chrome all teach the same old lesson in different clothes: if a manager or UI keeps showing a live hint after the anchor or renewal path disappeared, users will treat stale comfort as current truth. systemd's watchdog and timeout-extension semantics, s6's explicit readiness polling helper, and WezTerm's pane-information snapshot model all point to the same answer: explicit renewals or explicit snapshot labeling beat sticky folklore.
References: REF-SD-NOTIFY, REF-SD-WATCHDOG-ENABLED, REF-SYSTEMD-SERVICE, REF-S6-NOTIFYONCHECK, REF-WEZTERM-PANE-INFORMATION, REF-ITERM2-STATUS-BAR.

## 62. Delivered activation material should be named, not positional folklore
launchd's `launch_activate_socket` API and D-Bus system activation both reinforce the same lesson: activation material is healthier when the caller asks for a reviewed name or service identity than when everyone quietly agrees that `fd 3` or some inherited process slot has special meaning. Steward should keep activation delivery named, reviewable, and replayable across restart.
References: REF-LAUNCH-ACTIVATE-SOCKET, REF-DBUS-SYSTEM-ACTIVATION, REF-SYSTEMD-SD-LISTEN-FDS.

## 63. Trusted shell shortcuts need provenance before they earn authority
VS Code's shell-integration trust model is a useful warning for any ambitious terminal UX: once the UI can rerun a command, attach structured context, or skip confirmation, the question stops being “did we parse a marker?” and becomes “why should we trust this marker enough to act on it?” Steward should keep syntax and authority separate.
References: REF-VSCODE-SHELL-TRUST, REF-VSCODE-SHELL-INTEGRATION.

## 64. Click-to-open UX should route through exact targets, not regex heroics
kitty's open-actions model, OSC 8 hyperlinks, and iTerm2's command URLs all point toward the same lesson: terminal affordances get dramatically better when the producer can identify *what this thing is* and the terminal can route it deliberately, instead of guessing from rendered text. Steward should steal that exact-target instinct for files, receipts, and lifecycle explainers.
References: REF-KITTY-OPEN-ACTIONS, REF-WEZTERM-HYPERLINKS, REF-ITERM2-COMMAND-SELECTION, REF-ITERM2-ESCAPE-CODES.

## 65. Low-latency shell comfort is worth stealing only when prediction stays visibly tentative
Mosh shows that speculative local echo and resilient session continuity can make shell UX feel magical on bad links, but the magic works because prediction is allowed to be corrected later. Steward's custom shell+terminal should steal the latency-hiding instinct while keeping provisional state visibly separate from confirmed lifecycle truth.
References: REF-MOSH, REF-MOSH-PAPER.

## Fresh lessons from the named-activation and semantic-history pass
- **Named activation material beats descriptor-order folklore**: systemd's named fd delivery and launchd's `launch_activate_socket` both reinforce the same lesson: once the manager owns activation material, services should retrieve it by reviewed name, not by hoping descriptor order or wrapper lore stayed stable.
- **Graceful stop is advisory, not sacred**: Fuchsia's runner protocol is refreshingly honest that a manager may escalate straight to kill, may kill after a stop request, and should still produce an explicit stop event/result. Steward should keep graceful stop cooperative but never make “Stop always ran first” part of the constitution.
- **Per-line cwd is worth more than pane-wide guessing**: iTerm2's semantic history shows the power of tracking working directory for the line actually clicked, not just the pane's current cwd. Steward should steal that idea for open/edit/explain actions so exact targets beat lucky guesses.
- **Debugging semantic zones deserves first-class UI**: Ghostty's OSC-133 inspector/debug overlay is a strong reminder that once a terminal grows semantic prompt zones, developers need a direct way to see them. Steward's custom shell+terminal should plan for semantic introspection early.
References: REF-SD-LISTEN-FDS-WITH-NAMES, REF-LAUNCH-ACTIVATE-SOCKET, REF-FUCHSIA-COMPONENT-RUNNER, REF-ITERM2-SEMANTIC-HISTORY, REF-GHOSTTY-RELEASE-130.



## Fresh lessons from the escrow and command-guide pass
- **Escrow should stay narrow, manager-redelivered, and replacement-safe**: Fuchsia's current lifecycle and idle-stop guidance is a good caution against inventing a magical resurrection ledger. The healthy lesson is narrower: escrow a small reviewed continuity payload, let the framework redeliver it to the next execution, and avoid turning continuity into a generic list/watch/import plane.
- **Graceful stop and continuity still need kill-first honesty**: Fuchsia's lifecycle protocol says a process should clean up on `Stop`, but the system may terminate it before cleanup finishes. Steward should keep cooperative drain and narrow escrow useful without ever making “the graceful path always completed” part of the constitution.
- **Command boundaries deserve visible guides, not just hidden semantics**: VS Code's command guide and sticky scroll, together with Ghostty's OSC-133 inspector, reinforce that semantic frames are dramatically more useful when users can *see* and jump by them. Steward's custom terminal should plan for frame guides and sticky headers early instead of treating semantic zones as an invisible implementation detail.
- **Open targets and focus authority should stay separate**: freedesktop's D-Bus activation platform-data keeps activation tokens as a separate field rather than smuggling window activation into the target itself. Steward should steal that separation: exact routed targets are one thing; permission to foreground or focus UI is another.
References: REF-FUCHSIA-PROCESS-LIFECYCLE, REF-FUCHSIA-STOP-IDLE, REF-FUCHSIA-COMPONENT-RUNNER, REF-VSCODE-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130, REF-DESKTOP-ENTRY-DBUS-ACTIVATION.


## 66. Restart budgets must account for bursts, sustained failure, and hierarchy
OTP's supervisor guidance remains one of the clearest warnings in this space: a restart budget is not just one retry counter, it is a statement about burst tolerance, sustained crash rate, and how those choices multiply across supervision levels. Steward should keep restart policy small, but it should still learn that identical retry knobs at every layer are how “bounded” restart loops quietly turn unbounded in practice.
References: REF-ERLANG-OTP-SUPERVISOR, REF-DINIT-SERVICE, REF-SMF-MAINTENANCE.

## 67. Delivery receipts and acknowledgement barriers beat wrapper folklore
systemd's named fd delivery and notify barrier, launchd's exact socket lookup, and Fuchsia's explicit lifecycle/escrow events all point toward the same lesson: startup material should leave behind compact reviewed evidence of what was delivered to which concrete run, and whether the manager observed acknowledgement, instead of relying on descriptor order, helper timing, or shell memory.
References: REF-SD-LISTEN-FDS-WITH-NAMES, REF-SD-NOTIFY, REF-LAUNCH-ACTIVATE-SOCKET, REF-FUCHSIA-PROCESS-LIFECYCLE.

## 68. Action targets and foreground tokens must stay separate
freedesktop's D-Bus activation and notifications specs are refreshingly explicit that a target action and a window-activation token are different pieces of data. Steward should steal that split for its shell and terminal: open the exact file/receipt/frame first, then optionally carry a platform foregrounding token as a second scoped field instead of smuggling focus authority into the target itself.
References: REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-DESKTOP-NOTIFICATIONS-SPEC.

## 69. Great terminal UX comes from exact command details, not just pretty scrollback
Recent VS Code terminal work keeps reinforcing the same lesson: once command boundaries are semantic, the UI can surface working directory, start time, duration, exit code, hidden-terminal reveal, and exact attachments without scraping text. Steward's custom shell+terminal should steal that data-rich exactness while keeping the command frame—not the pane—as the primary object.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1109, REF-VSCODE-UPDATE-1110.

## 70. Visible command guides need a noise budget
Once command boundaries become semantic, the next failure mode is obvious: every trivial frame starts competing for sticky-header and guide-rail attention. VS Code's sticky-scroll work, its later ignored-command setting, and the long history of terminal chrome turning into clutter all reinforce the same lesson: command guides need filtering and downranking for noisy or low-value frames.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1104, REF-VSCODE-UPDATE-1109.

## 71. Terminal-guessed prompt marks are useful scaffolding, not equal authority
Windows Terminal's stable `autoMarkPrompts` feature is a good reminder that a terminal can synthesize helpful structure even when the shell is not fully cooperating. But its own docs frame this as a convenience setting layered on top of shell integration, not as proof that the terminal now knows exact command truth. Steward should keep guessed marks visibly lower-confidence than shell-reported boundaries.
References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE, REF-VSCODE-SHELL-TRUST.

## 72. Prompt-local cursor motion is worth stealing only inside live prompt zones
Ghostty's current support for OSC 133 click-events and `cl=line`, together with fish's fresh prompt-end markers, shows how good prompt-local mouse editing can feel when the shell reports exactly where live input begins and ends. The caution is just as important as the delight: prompt-local editing should stay bound to live prompt zones, not guess into historical transcript text.
References: REF-GHOSTTY-RELEASE-130, REF-FISH-OSC-MARKERS, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.

## 73. Context inheritance should be per action, not pane folklore
Ghostty's new split/tab working-directory controls, WezTerm's explicit `SpawnCommand` domain and cwd fields, Windows Terminal's same-cwd tab support, and iTerm2's per-line cwd tracking all point toward the same lesson: opening a new tab, split, rerun, or helper shell should choose what it inherits deliberately. “Same context” is not one thing, and it should not ride on a hidden pane-global assumption.
References: REF-GHOSTTY-RELEASE-130, REF-WEZTERM-SPAWNCOMMAND, REF-WEZTERM-LAUNCHING-PROGRAMS, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-SEMANTIC-HISTORY.

## 74. Explicit spawn selectors beat ambient shell folklore
WezTerm's current launch docs are refreshingly blunt: the default program can be selected explicitly, cwd can be specified explicitly, and `$SHELL` is deliberately ignored in favor of a resolved account shell unless an explicit override is provided. That is the right instinct for Steward too: shell comfort is great, but profile selection and launch intent should be explicit enough to survive restart, remote hops, and untrusted launch contexts.
References: REF-WEZTERM-LAUNCHING-PROGRAMS, REF-VSCODE-UPDATE-1109.

## Fresh lessons from the context-inheritance pass
- **Cwd inheritance and domain inheritance are different knobs**: starting in the same directory and starting in the same remote/local execution domain should stay separately nameable.
- **Line-local routing is the healthiest inheritance source**: iTerm2's per-line cwd and semantic-history model reinforce that “open a shell here” should prefer exact line or frame context over pane-wide guesses.
- **Fallback should be honest, not invisible**: if same-context spawning degrades to default cwd or local domain, the terminal should say so instead of pretending exact inheritance worked.
- **Untrusted launch context should gate convenience inheritance**: VS Code's restricted-workspace terminal opt-in is a good reminder that shell comfort can carry risk when the surrounding workspace is not trusted.
References: REF-GHOSTTY-RELEASE-130, REF-WEZTERM-SPAWNCOMMAND, REF-WEZTERM-LAUNCHING-PROGRAMS, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-SEMANTIC-HISTORY, REF-VSCODE-UPDATE-1109.

## Fresh lessons from the command-guide and prompt-click pass
- **Guide rails should explain themselves**: VS Code's Show Details diagnostics and Ghostty's OSC-133 inspector reinforce that semantic UX gets much better when users can ask *why* a guide or sticky header exists and how trusted it is.
- **Fresh prompt markers beat stale remembered cwd**: fish's current relnotes keep sharpening the same truth — reporting cwd on every fresh prompt and marking prompt end explicitly is a much better recovery path than preserving pane-wide guesses after ssh or TUI detours.
- **One guide seam beats many chrome heuristics**: the healthiest direction is one explicit command-guide surface that can power sticky headers, rails, scrollbar marks, and hover cards, rather than a separate guessed heuristic for every widget.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1103, REF-GHOSTTY-RELEASE-130, REF-FISH-OSC-MARKERS, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.


## 75. Cwd source classes are worth naming instead of pretending “current” is one thing
kitty's launch docs are unusually honest here: `current`, `last_reported`, `oldest`, and `root` are meaningfully different cwd sources. That is a great lesson for Steward. A custom shell+terminal should be allowed to say whether a helper shell used exact current-frame cwd, last shell-reported cwd, or root/origin cwd instead of flattening them into one comforting fiction.
References: REF-KITTY-LAUNCH, REF-ITERM2-SEMANTIC-HISTORY.

## 76. Copied environment is explicit convenience, not live process truth
kitty's `--copy-env` warning is the kind of sentence architecture should memorize: the copied environment is only the one from when the source window was created, not the updated environment of an arbitrary foreground process. Steward should steal that honesty. Env carryover can be useful, but it needs freshness labels and should never masquerade as exact live launch truth.
References: REF-KITTY-LAUNCH, REF-VSCODE-UPDATE-1109.

## Fresh lessons from the spawn-selector pass
- **A great spawn palette names sources, not just destinations**: “clean”, “exact current frame”, “last shell-reported cwd”, “origin/root cwd”, and “same domain” are more useful than one magical “new tab here” button.
- **Profile choice and context inheritance should stay separate**: iTerm2's current-session profile switching/open-quickly ideas and WezTerm's spawn/domain fields reinforce that launch recipe choice is its own seam, not a side effect of remembered cwd.
- **Policy-bounded convenience is still convenience**: VS Code's restricted-workspace terminal opt-in is a sharp reminder that user-comfort launch helpers can still trigger code execution and need trust-aware gates.
References: REF-KITTY-LAUNCH, REF-WEZTERM-SPAWNCOMMAND, REF-WEZTERM-LAUNCHING-PROGRAMS, REF-ITERM2-ONE-PAGE, REF-VSCODE-UPDATE-1109.

## 77. Remembered shelves should stay obviously remembered
VS Code's Run Recent Command and Go to Recent Directory flows, together with iTerm2's username+hostname-scoped command history and frecency-sorted recent directories, reinforce the same lesson: remembered shell context is hugely valuable, but it should remain visibly remembered context rather than proof that the current host, cwd, or authority state is still live. Steward should steal the ergonomics while keeping stronger actions fenced behind fresher anchors or reports.
References: REF-VSCODE-SHELL-INTEGRATION, REF-ITERM2-ONE-PAGE.

## 78. Exact current-command surfaces beat pane-wide guessing
Windows Terminal's preview right-click support for selecting the current command or output, VS Code's current-command navigation/output reveal, and iTerm2's scroll-to-reveal command history entries all point toward the same lesson: once command frames are explicit, the UI should operate on the current command as an object instead of guessing from pane-local text neighborhoods. Steward's custom terminal should make “reveal this frame”, “copy this output”, and “open details for the current command” exact by default.
References: REF-WINDOWS-TERMINAL-ADVANCED-PROFILE, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1106, REF-ITERM2-ONE-PAGE.

## Fresh lessons from the remembered-shelf pass
- **Recent shelves want trust labels, not just timestamps**: remembered, shell-reported, and currently re-confirmed are different states, and the UI should be able to say which one a command, directory, or object shelf entry is using.
- **Host/hop scoping beats one giant history blob**: iTerm2's username+hostname split and VS Code's shell-aware recent-directory behavior reinforce that recent memory should key off explicit context instead of a flat terminal identity.
- **Reveal beats rerun when certainty is weak**: when an entry is remembered but not freshly anchored, revealing the prior frame or pasting the text is healthier than silently acting as if the old target is still live.
References: REF-VSCODE-SHELL-INTEGRATION, REF-ITERM2-ONE-PAGE, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.

## 79. Transcript landmarks should bind to exact anchors, not scrollback mythology
VS Code's scrollbar annotations and command navigation, Windows Terminal's shell-integration marks and explicit mark actions, and iTerm2's long-lived mark or annotation affordances all point to the same lesson: marks are healthiest when they are exact navigational landmarks over a command or span, not just paint in a viewport. Steward should keep marks, jump targets, and selection surfaces bound to exact anchors instead of hoping the user is still looking at the same scrollback region.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1066, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS, REF-ITERM2-MENU-ITEMS.

## 80. Notes and watchpoints belong on exact spans, not pane-wide memory
iTerm2's annotations and alert-on-next-mark affordances are a strong reminder that users often want to remember *this exact chunk* or *tell me when this exact command finishes*, not merely “something happened in this terminal.” Steward should steal that instinct: notes and watch surfaces are most trustworthy when they bind to an exact frame or landmark instead of a pane-wide ambient history blob.
References: REF-ITERM2-MENU-ITEMS, REF-ITERM2-FEATURES, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS.

## Fresh lessons from the transcript-landmark pass
- **One landmark seam beats many ad hoc mark widgets**: VS Code, Windows Terminal, and iTerm2 all show different UI for marks, scrollbar annotations, or notes, but the healthiest common lesson is structural — one exact-landmark seam should feed them all instead of each widget inventing its own folklore.
- **User annotations should stay exact-span and local by default**: iTerm2's annotation scratchpads are useful precisely because they attach to a chunk of terminal history; Steward should steal that idea while resisting the urge to make annotations into a hidden collaboration plane.
- **Watch-this-command cues should bind to landmarks, not panes**: iTerm2's alert-on-next-mark and Windows Terminal's mark navigation make a good pair of lessons — the watched thing should be a concrete mark or command frame, not a vague terminal tab feeling.
- **Scrollbar marks are navigation aids, not transcript truth**: scrollbars are a wonderful discovery surface, but the durable meaning still belongs to the underlying frame/span anchor, not the painted tick.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1066, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS, REF-ITERM2-MENU-ITEMS, REF-ITERM2-FEATURES.

## 81. Layout restore, process revive, and live continuity are different promises
VS Code's terminal docs split process reconnection from process revive, Windows Terminal's persisted layout restores pane arrangement without pane contents, and iTerm2's session restoration explicitly distinguishes reattached jobs from content-only restoration. Steward should steal that honesty: a pane that looks familiar is not necessarily a still-running process, and a restarted process is not the same thing as a reconnected one.
References: REF-VSCODE-TERMINAL-ADVANCED, REF-WINDOWS-TERMINAL-STARTUP, REF-ITERM2-SESSION-RESTORATION.

## 82. Saved arrangements should restore reviewed recipes, not ambient shell accidents
Windows Terminal only persists layout, profile, and optionally shell-reported cwd; WezTerm's mux model keeps domains explicit; and iTerm2's saved arrangements are snapshots of windows, tabs, and panes rather than a promise that every mutable shell detail can be resurrected. Steward should keep workspace restore grounded in reviewed spawn selectors and remembered context classes, not hidden env, shell, or host folklore.
References: REF-WINDOWS-TERMINAL-STARTUP, REF-WEZTERM-MULTIPLEXING, REF-ITERM2-ONE-PAGE, REF-VSCODE-TERMINAL-ADVANCED.

## Fresh lessons from the workspace-snapshot pass
- **Restore outcomes need visible truth labels**: reconnected, revived, layout-only, and content-only are different outcomes and should never share one vague “restored” badge.
- **Remembered layout is not live authority**: saving a workspace is like saving a request or shelf, not like proving that the old process, cwd, or remote domain still exists unchanged.
- **Partial restore explanation beats silent omission**: if one pane reconnects, another relaunches, and a third cannot come back because policy or domain availability changed, the UI should say so explicitly.
References: REF-VSCODE-TERMINAL-ADVANCED, REF-WINDOWS-TERMINAL-STARTUP, REF-ITERM2-SESSION-RESTORATION, REF-WEZTERM-MULTIPLEXING.



## 83. Restore should not silently become rerun
Zellij's current resurrection docs are a sharp reminder that “I can reconstruct this command” is not the same as “I should execute it immediately.” By default, resurrected commands sit behind a "Press `ENTER` to run..." banner, and Zellij documents a separate force-run path for people who intentionally want immediate replay. Steward should steal that instinct. Review-before-run is the healthy default when remembered shell context may be stale, wrapped, or policy-sensitive.
References: REF-ZELLIJ-SESSION-RESURRECTION, REF-ZELLIJ-FEATURES, REF-VSCODE-TERMINAL-ADVANCED.

## 84. Pending command surfaces can be first-class objects
Zellij's command panes are a great lesson in terminal honesty: a command can be a first-class pane object with exit status, re-run affordances, and even `start_suspended` behavior instead of being either raw shell text or a hidden launch recipe. Steward should steal that move. Pending commands, helper actions, and heavier reruns deserve exact object surfaces, not just more scrollback folklore.
References: REF-ZELLIJ-FEATURES, REF-ZELLIJ-PLUGINS, REF-VSCODE-UPDATE-1109.

## Fresh lessons from the replay-gate pass
- **Remembered command text is not enough**: a replay surface should carry why the command is available, what cwd/domain/hop truth is still known, and what has gone stale.
- **Review cards beat silent autoreplay**: Zellij's resurrection banner and VS Code's richer command-detail work both point toward the same healthier UX — inspect first, run second.
- **Force-run should be visible policy, not ambient default**: immediate rerun can be useful, but it should read like an override, not like the system forgot there was any risk.
- **Suspended command panes are better than ad hoc sticky notes**: when a build, test, or migration matters enough to keep around, treat it as a first-class object with exact launch context and later receipts.
References: REF-ZELLIJ-SESSION-RESURRECTION, REF-ZELLIJ-FEATURES, REF-ZELLIJ-PLUGINS, REF-VSCODE-UPDATE-1109, REF-VSCODE-TERMINAL-ADVANCED.


## 84. Great choosers return exact targets, not just text
kitty's hints/choose-files surfaces, Zellij's filepicker+pipes, and Windows Terminal's current-command selection all converge on the same lesson: chooser UX gets much better when selection can resolve into an exact object, frame, or action target instead of merely pasting guessed text back into the prompt. Steward should steal that idea and stay explicit about when only weaker matched text is available.
References: REF-KITTY-HINTS, REF-KITTY-CHOOSE-FILES, REF-ZELLIJ-FILEPICKER, REF-ZELLIJ-PLUGIN-PIPES, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.

## Fresh lessons from the chooser-surface pass
- **Chooser defaults should stay ephemeral**: Zellij's filepicker and kitty's choose-files are powerful precisely because they can do something useful *now* without silently enrolling the result into a long-lived grant or recent-item universe.
- **Visible text is a discovery source, not always authority**: selecting a path-looking string from output is great, but Steward should still be able to say whether it resolved to a reviewed target anchor, a fresh file handle, or only raw matched text.
- **Modal chooser ergonomics matter when they don't leak**: Ghostty's key tables and `catch_all` are a good reminder that chooser modes can be sharp and safe when unhandled keys do not dribble accidental input into the underlying shell.
References: REF-GHOSTTY-RELEASE-130, REF-KITTY-HINTS, REF-KITTY-CHOOSE-FILES, REF-ZELLIJ-FILEPICKER.

## Fresh lessons from the assist-surface pass
VS Code's terminal quick fixes and Windows Terminal's suggestions both point to the same rule: high-likelihood next actions are wonderful, but they should stay user-invoked suggestions over exact command/input context rather than silent terminal-side mutation. Steward should steal the helpfulness while refusing the ambient-authority trap.

VS Code's recent terminal work also suggests another important split: **input-time assist is not post-command repair**. Completions, inline docs, and current-command suggestions belong to the editable line, while repair cards, rerun advice, and "open this exact output" actions belong to the finished command frame. Steward should keep those seams distinct so typing help never quietly becomes replay authority.

Ghostty's new key tables and `catch_all` support, together with WezTerm's explicit command-palette augmentation hook, suggest a strong UI lesson: modal terminal help is fine when the mode is visible, bounded, and key-safe. Steward should prefer visible assist modes that trap or ignore stray keys over hidden shell fallthrough.

References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1072, REF-VSCODE-UPDATE-1102, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS, REF-WEZTERM-AUGMENT-COMMAND-PALETTE, REF-GHOSTTY-RELEASE-130.



## Fresh lessons from the surface-diagnostics pass
- **Rich terminal UX should expose rich reasons**: VS Code's shell-integration quality hover and Show Details diagnostics are a strong reminder that feature availability should be inspectable, not magical.
- **Per-affordance explanation beats pane-wide mythology**: iTerm2's feature reporting and shell/version/current-dir reporting show that support and freshness are better carried as specific facts than as one global “this session is good” badge.
- **Debug overlays are worth having when they map to exact semantics**: Ghostty's OSC 133 debug overlay is a useful lesson that prompt/input/output zones become much easier to trust when users and shell authors can inspect them directly.
- **Diagnostic detail should stay explanatory, not authoritative**: learning why a feature is available should help users reason about confidence and policy, but it should not silently grant more power.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1103, REF-ITERM2-FEATURE-REPORTING, REF-ITERM2-ESCAPE-CODES, REF-GHOSTTY-RELEASE-130.


## 85. Session convenience should not silently become shell truth
VS Code's terminal tool now has an explicit setting to keep tool-run commands out of ordinary shell history when shell integration is working, Warp's environment bundles require an explicit confirmation block before loading into the current session, and Warp's subshell load path exists specifically to reduce contamination of the wider workspace. Steward should steal the same lesson: UI-originated commands and env loads are useful, but they should stay visibly injected, scoped, and history-aware instead of pretending they were ordinary human keystrokes.
References: REF-VSCODE-UPDATE-1108, REF-WARP-ENV-VARS.

## 86. Rich remote terminal features often depend on wrappers or helpers, so consent and downgrade honesty matter
Warp's SSH flow is very explicit that richer remote UX is powered by `tmux`, remote helper commands, and optional rcfile setup, while WezTerm's shell integration and user vars similarly depend on deliberate prompt-side emission. Steward should keep that cultural lesson: remote magic is fine when the helper path is explicit and opt-in, but helper availability must never quietly harden into portable lifecycle truth.
References: REF-WARP-SSH, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh lessons from the session-injection pass
- **History is a policy surface, not an accident**: whether replayed, assisted, or tool-originated commands land in shell history should be explicit and inspectable rather than whatever the current wrapper trick happens to cause.
- **Subshell-scoped env loads are healthier than ambient contamination**: Warp's dedicated subshell load path is a good reminder that convenience state should often live in a clearly bounded child session instead of the parent shell.
- **Pane vars can enrich UX without becoming authority**: WezTerm's user vars are an excellent inspiration for status and filtering, but they should stay observational.
References: REF-VSCODE-UPDATE-1108, REF-WARP-ENV-VARS, REF-WARP-SSH, REF-WEZTERM-SHELL-INTEGRATION.

## 87. Clipboard and paste are authority crossings, not passive bytes
Terminals keep rediscovering the same truth from different directions: bracketed paste exists because pasted text is not the same thing as typed keystrokes, and remote clipboard protocols exist because clipboard access crosses trust boundaries. Steward should keep copy and paste as explicit transfer surfaces with policy and provenance rather than treating them as invisible PTY trivia.
References: REF-XTERM-BRACKETED-PASTE, REF-BASH-READLINE-INIT, REF-GHOSTTY-OSC52, REF-KITTY-CLIPBOARD.

## 88. Exact command-aware copy beats drag archaeology
VS Code, Windows Terminal, and iTerm2 all reward exact current-command or current-output selection because it is safer and more reproducible than scraping nearby scrollback with a mouse. Steward should steal that lesson aggressively: exact frame-backed copy should be stronger than raw text copy, with visible downgrade when only plain text survives.
References: REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-INTERACTION, REF-ITERM2-ONE-PAGE.

## Fresh lessons from the clipboard-surface pass
- **Bracketed paste is baseline hygiene, not a luxury add-on**: if pasted input is not distinguished from typed input, shells and prompts end up re-learning the same painful lesson about accidental execution and broken editing.
- **Remote clipboard should be explicit and denyable**: OSC 52 and richer clipboard protocols are useful, but they should behave like permissioned transport, not ambient authority for every remote process.
- **Copy mode is a real mode**: copy-on-select, command-aware selection, rectangular selection cleanup, and exact current-command selection all change meaning and should be explainable.
- **Typed clipboard payloads can preserve structure longer**: kitty's richer clipboard protocol is a useful reminder that not every transfer has to flatten into plain text immediately.
References: REF-XTERM-BRACKETED-PASTE, REF-BASH-READLINE-INIT, REF-GHOSTTY-OSC52, REF-KITTY-CLIPBOARD, REF-WINDOWS-TERMINAL-INTERACTION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-VSCODE-SHELL-INTEGRATION.

## 89. Transfer sessions should require exact approval, not ambient terminal trust
kitty's file-transfer protocol is unusually crisp about the core lesson: a terminal transfer session should be approved by the user before actual data moves, unless an explicit pre-shared secret or policy says otherwise. Steward should steal that instinct. Upload/download authority is stronger than ordinary screen output and deserves its own reviewable seam.
References: REF-KITTY-FILE-TRANSFER-PROTOCOL, REF-KITTY-TRANSFER.

## 90. Edit, open, download, upload, and paste-path are different actions
kitty's remote-file actions, iTerm2's line-local upload/download behavior, VS Code's shell-escaped path drop, and Windows Terminal's drag-a-folder-to-open flow all reinforce the same lesson: richer terminal UX improves when transfer actions stay explicit instead of collapsing into one generic “send this path somewhere”. Steward should keep transfer direction and follow-on action first-class.
References: REF-KITTY-REMOTE-FILES, REF-ITERM2-SHELL-INTEGRATION, REF-VSCODE-TERMINAL-BASICS, REF-WINDOWS-TERMINAL-TIPS.

## Fresh lessons from the transfer-surface pass
- **Transfer direction is policy, not presentation**: local-open, local-edit-and-sync, download, upload, attach, and paste-text have different consequences and should never share one mushy action label.
- **Line-local or anchor-local destinations beat pane-wide cwd guessing**: iTerm2's “directory you were in on the line you dropped the file on” is a sharp reminder that precise context can be stronger than whatever the whole pane vaguely means now.
- **Object-preserving transfer beats path folklore**: exact remote-file actions and reviewed object handoff are healthier than injecting escaped path text into a prompt and hoping the same meaning survives.
- **Nested-hop honesty matters**: terminals that can transfer over nested SSH or serial links should say so; terminals that only know the first remote host should also say so.
References: REF-KITTY-TRANSFER, REF-KITTY-FILE-TRANSFER-PROTOCOL, REF-KITTY-REMOTE-FILES, REF-ITERM2-SHELL-INTEGRATION, REF-VSCODE-TERMINAL-BASICS, REF-WINDOWS-TERMINAL-TIPS.


## 91. Control paths should be explicit, permissioned, and target-aware
kitty, tmux, WezTerm, and iTerm2 all converge on the same lesson: terminal automation becomes healthy only when it is clearly on a control path, clearly aimed at exact objects, and clearly bounded by action class or hook surface rather than one flat ambient “script me” power. Steward should steal that and keep control separate from transcript mythology.
References: REF-KITTY-REMOTE-CONTROL, REF-KITTY-RC-PROTOCOL, REF-TMUX-CONTROL-MODE, REF-WEZTERM-CLI, REF-ITERM2-RPCS, REF-ITERM2-HOOKS.

## Fresh lessons from the automation-surface pass
- **Fine-grained automation permissions beat one giant god switch**: kitty's per-password action limits and custom auth hooks are a strong reminder that focus, spawn, query, inject, and mutate are different powers.
- **Request identity matters for scripted work too**: kitty's async request ids and streaming chunks, together with tmux control mode's parseable control channel, show that long-running or interactive automation needs explicit request tracking instead of timing folklore.
- **CLI path disclosure is part of the contract**: WezTerm's distinction between `wezterm` and `wezterm-gui`, plus its experimental mux-server CLI, reinforces that scripts should know what controller they are talking to.
- **Hooks are useful when they stay named and scoped**: iTerm2's RPCs and hooks are a good reminder that extension points can stay powerful without silently inheriting universal authority.
References: REF-KITTY-REMOTE-CONTROL, REF-KITTY-RC-PROTOCOL, REF-TMUX-CONTROL-MODE, REF-WEZTERM-CLI, REF-ITERM2-RPCS, REF-ITERM2-HOOKS, REF-ITERM2-VARIABLES.


## 93. Notifications should escalate exact state, not become a second approval path
The freedesktop notifications spec is explicit that notifications are passive popups rather than modal message boxes, Ghostty and WezTerm both gate command-finished notification delivery by focus and duration, and iTerm2's alert-on-next-mark works because it is effectively user-armed on one exact completion boundary. Steward should steal the same lesson: notifications are great for waking the user up, but they should reveal or focus exact anchors, not quietly run commands or stand in for fresh approval.
References: REF-DESKTOP-NOTIFICATIONS-SPEC, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-NOTIFICATION-HANDLING, REF-ITERM2-SHELL-INTEGRATION.

## 94. Transient cues should stay separate from durable truth and foreground activation
Desktop notification ecosystems and desktop activation APIs both reinforce the same split: the toast text is not durable truth, and the request to foreground a window is separate from the exact target being acted on. Steward should keep that discipline. A notification may point to a command frame, receipt, or repair card, but durable state still belongs in explicit transcript/receipt surfaces, and any focus/raise token should stay distinct from the reviewed target selector.
References: REF-DESKTOP-NOTIFICATIONS-SPEC, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-KITTY-DESKTOP-NOTIFICATIONS.

## Fresh lessons from the notification-surface pass
- **Focus and duration are part of the contract**: Ghostty's `notify-on-command-finish` settings and WezTerm's notification-handling modes are a good reminder that “send a notification” is not one scalar switch.
- **User-armed watch flows are worth stealing**: iTerm2's alert-on-next-mark is compelling because it lets the user care about one exact long-running command without globally turning every pane into a noisemaker.
- **Buttons and rich actions are platform-variable, so degrade honestly**: the freedesktop notification protocol is explicit that servers may ignore actions or only support subsets of rich content.
- **Reveal beats run**: command-finished toasts should primarily reveal or focus exact transcript targets; using them as hidden command-launch surfaces is the wrong direction.
References: REF-DESKTOP-NOTIFICATIONS-SPEC, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-NOTIFICATION-HANDLING, REF-ITERM2-SHELL-INTEGRATION, REF-KITTY-DESKTOP-NOTIFICATIONS.

## 23. Rich input deserves the same anti-folklore discipline as rich output
kitty's keyboard protocol, WezTerm's encoding notes, Ghostty's modal key tables, and xterm's long modifyOtherKeys history all point to the same lesson: if a terminal wants to be modern, it has to treat key events, composed text, unknown-key policy, and injected bytes as explicit semantics instead of timing accidents. Steward should freeze that honesty before it freezes any grander input plane.
References: REF-KITTY-KEYBOARD-PROTOCOL, REF-WEZTERM-KEYBOARD-ENCODING, REF-WEZTERM-KEYBOARD-CONCEPTS, REF-KITTY-MAPPING, REF-GHOSTTY-RELEASE-130, REF-XTERM-MODIFIED-KEYS.

## 24. International input is not an optional corner case
WezTerm's keyboard concepts are an especially good reminder that IME, AltGr, and dead keys are normal parts of terminal life, not weird exceptions to be broken for the convenience of one shortcut scheme. Steward's custom shell should be careful not to trade away composed-text correctness in the name of modal cleverness.
References: REF-WEZTERM-KEYBOARD-CONCEPTS.

## 25. Modal key power is great only when leakage rules are explicit
Ghostty and kitty both show that leader sequences, key tables, timeouts, ignore/passthrough choices, and read-only modes can make a terminal fantastic. The lesson to steal is not “have modes”; it is “make capture, passthrough, exit, and unknown-key behavior explicit.”
References: REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-KEYBIND-SEQUENCE, REF-GHOSTTY-KEYBIND-ACTIONS, REF-KITTY-MAPPING.


## 95. Inline media should keep display authority separate from file authority
iTerm2's inline-image protocol is explicit that image display and file download are related but distinct behaviors, while kitty's graphics protocol is explicit about rendering graphics into the terminal viewport rather than silently changing file-open or local-app authority. Steward should steal that split. Seeing media inline should primarily mean "a rendered view exists here", not "the terminal now has ambient permission to open, persist, or transfer the underlying object".
References: REF-ITERM2-INLINE-IMAGES, REF-ITERM2-ONE-PAGE, REF-KITTY-GRAPHICS-PROTOCOL.

## 96. Rich media fidelity should degrade honestly across hops, multiplexers, and restore
WezTerm explicitly notes that the iTerm image protocol is not fully handled by multiplexer sessions, and Ghostty's recent release notes show that even background images and kitty-image behavior have real fidelity and memory edge cases. Steward should therefore treat inline media like any other semantic affordance: capability-gate it, budget it, and admit when only a placeholder, thumbnail, or exact receipt survived.
References: REF-WEZTERM-IMGCAT, REF-GHOSTTY-RELEASE-120, REF-GHOSTTY-FEATURES.

## Fresh lessons from the media-surface pass
- **Rendered pixels are not transcript truth**: an inline image or plot can share a frame with text without inheriting text semantics for copy, replay, or exact output selection.
- **Display/download/open are separate promises**: terminals that render media well still distinguish inline preview from download or local-open, and Steward should keep that separation explicit.
- **Render budgets deserve diagnostics**: GPU, VRAM, bandwidth, and redraw cost are part of the UX contract for media, not hidden implementation trivia.
- **Placeholder honesty beats fake fidelity**: restored panes or remote hops should be allowed to keep an anchor or thumbnail while clearly admitting when the rich rendering itself is gone.
References: REF-KITTY-GRAPHICS-PROTOCOL, REF-WEZTERM-IMGCAT, REF-GHOSTTY-FEATURES, REF-GHOSTTY-RELEASE-120, REF-ITERM2-INLINE-IMAGES, REF-ITERM2-ONE-PAGE.


## 97. Clickable text is not one evidence class
WezTerm's OSC 8/open-uri path, kitty's hyperlink processing and ask-before-open option, iTerm2's semantic history, and VS Code's link-provider APIs all point to the same lesson: detected text, declared hyperlinks, semantic file links, and exact object targets are different kinds of evidence. Steward should not flatten them into one generic click authority level.
References: REF-WEZTERM-HYPERLINKS, REF-WEZTERM-OPEN-URI, REF-KITTY-CONF, REF-ITERM2-SEMANTIC-HISTORY, REF-VSCODE-TERMINAL-BASICS, REF-VSCODE-TERMINAL-LINK-PROVIDER.

## 98. Open target identity and foreground behavior should stay separate
WezTerm explicitly lets link activation be intercepted before the default browser open happens, and iTerm2's semantic-history/file-fragment behavior shows that “what object did this refer to?” is separable from “which app comes to the front?” Steward should keep exact target selection separate from focus, reuse, or host activation folklore.
References: REF-WEZTERM-OPEN-URI, REF-ITERM2-SEMANTIC-HISTORY, REF-ITERM2-ESCAPE-CODES.

## Fresh lessons from the link-surface pass
- **Detected, declared, semantic, and exact are different strengths**: a regex word link, an OSC 8 hyperlink, a per-line semantic file route, and an exact reviewed object target should not get the same authority.
- **Line-local cwd helps, but it is not a magic object handle**: semantic-history style file routing is stronger than pane-wide guessing and still weaker than an exact object selector or receipt.
- **Providers can enrich invocation without owning truth**: extension or plugin link providers are great when they return typed targets or selectors instead of pasting guessed commands back into the shell.
- **Ask/review beats ambient open**: terminals that can ask before opening a link are teaching the right habit for risky or downgraded target classes.
References: REF-WEZTERM-HYPERLINKS, REF-WEZTERM-OPEN-URI, REF-KITTY-CONF, REF-KITTY-OPEN-ACTIONS, REF-ITERM2-SEMANTIC-HISTORY, REF-ITERM2-ESCAPE-CODES, REF-VSCODE-TERMINAL-BASICS, REF-VSCODE-TERMINAL-LINK-PROVIDER.


## 99. Visible titles and badges are not one authority class
Classic OSC title escapes, Windows Terminal's shell-controlled title behavior, WezTerm's split between explicit tab titles and active-pane fallback, iTerm2 badges, Ghostty's forced-title option, and kitty's title templates all point to the same lesson: user-pinned labels, manager-owned labels, shell-reported labels, and process-declared label text are different evidence classes. Steward should not let them collapse into one fuzzy “whatever the tab says” truth.
References: REF-XTERM-CTLSEQS, REF-WINDOWS-TERMINAL-TAB-TITLE, REF-WEZTERM-FORMAT-TAB-TITLE, REF-ITERM2-BADGES, REF-GHOSTTY-CONFIG-REFERENCE, REF-KITTY-CONF.

## 100. Title reporting is a real security boundary
Ghostty disables title reporting by default and warns that it can expose sensitive information or worse, while xterm has long exposed title-setting and title-reporting/window-operation control sequences. The lesson is not “never have labels”; it is “do not casually reflect label chrome back into the session without policy, diagnostics, and consent.”
References: REF-GHOSTTY-CONFIG-REFERENCE, REF-XTERM-CTLSEQS.

## Fresh lessons from the label-surface pass
- **Pinned beats ambient when the user asked for it**: a user-fixed title or reviewed workspace label should not be silently overwritten by the next shell escape sequence.
- **Label channels need provenance**: title bar text, tab text, badge text, and right-status text can summarize the same context while still having different writers and different trust.
- **Exact fields beat prompt scraping for chrome**: host, cwd, progress, and current task make great labels when they come from explicit side channels or exact selectors rather than prompt regexes.
- **Chrome should restore honestly**: remembered labels are useful after restart, but they should stay visibly remembered until refreshed instead of pretending they are still live truth.
References: REF-XTERM-CTLSEQS, REF-WINDOWS-TERMINAL-TAB-TITLE, REF-WINDOWS-TERMINAL-TIPS, REF-WEZTERM-FORMAT-TAB-TITLE, REF-WEZTERM-RIGHT-STATUS, REF-ITERM2-BADGES, REF-GHOSTTY-CONFIG-REFERENCE, REF-KITTY-CONF, REF-KITTY-REMOTE-CONTROL.

## 101. Capability narrowing should be explicit, reviewable, and lockable
OpenBSD's `unveil` is a powerful reminder that post-start authority narrowing can be both useful and disciplined: the first call hides the rest of the filesystem, later rules can be added deliberately, and the mechanism is explicitly recommended to be locked after configuration. FreeBSD's Capsicum pushes the same cultural lesson from a different direction by turning file descriptors into capabilities for compartmentalization. Steward should steal the discipline, not the host-specific mechanism: narrow authority through reviewed allowlists or delivered capabilities, admit when narrowing is still provisional, and avoid ambient namespace folklore.
References: REF-OPENBSD-UNVEIL, REF-FREEBSD-CAPSICUM.

## 102. The first meaningful request should be allowed to activate the service
The D-Bus specification is unusually explicit here: activation normally happens by sending the first message to a well-known name, and the bus can start the service and then deliver that message. The same specification also says `StartServiceByName` is often worse because it introduces a time-of-check/time-of-use gap before the follow-up call. Steward should learn from that. When practical, exact delivery to a manager-owned activation name is healthier than a separate "please start now" ritual followed by hope.
References: REF-DBUS-SPECIFICATION.

## Fresh lessons from the capability-bound and activation-contract pass
- **Lock after configuration beats ambient drift**: if launch-time narrowing matters, the system should be able to say when configuration is still open and when the narrowed world is locked.
- **Capabilities and allowlists are stronger than namespaces and path folklore**: reviewed handles or reviewed allowlists are healthier than ambient cwd / search-path assumptions.
- **Delivery should piggyback on the first real request when possible**: activating the service as part of first exact delivery is usually healthier than split-phase start-then-call ceremony.
- **Keep the portable grammar smaller than the local mechanisms**: learn from `unveil`, Capsicum, and D-Bus activation without cloning their whole host-specific surface areas into Steward v0.
References: REF-OPENBSD-UNVEIL, REF-FREEBSD-CAPSICUM, REF-DBUS-SPECIFICATION.

## 103. Lock after setup beats perpetual configurability
OpenBSD's `unveil` is unusually crisp about this: the first call removes visibility of the rest of the filesystem, more rules may be added deliberately, and then the interface is explicitly recommended to be locked. The lesson for Steward is not to copy `unveil` literally; it is to keep reviewed narrowing honest about whether it is still configuring or already locked.
References: REF-OPENBSD-UNVEIL.

## 104. Remote shell luxury should ride reviewed sessions, not ambient PTY power
kitty's remote-file and transfer features are a useful reminder that terminal UX can become dramatically better without turning every shell into a hidden file-control plane. When remote open/edit/download/upload is possible, Steward should prefer explicit reviewed sessions and exact target selectors over ambient "the PTY can probably do it" folklore.
References: REF-KITTY-REMOTE-FILES, REF-KITTY-TRANSFER, REF-KITTY-SHELL-INTEGRATION.


## 105. Activation and foreground are different powers
Desktop D-Bus activation is a nice reminder that an initial request can carry both meaningful work and platform data such as a startup id or activation token, but the target identity still comes from the well-known application name and object path. SlopOS's own OpenURI activation-control boundary reaches a similar conclusion from another direction: opening the right thing and winning user attention are related, but they should not collapse into one portable control plane. Steward should keep those truths separate.
References: REF-DESKTOP-ENTRY-DBUS-ACTIVATION.

## 106. Narrow replayable first requests beat giant activation ceremony
D-Bus system activation is careful about the helper input it accepts: the helper is passed one validated service name rather than arbitrary caller-controlled paths or startup bundles. The lesson for Steward is excellent: the first request may be replayable long enough to survive activation, but it should stay narrow, attributable, and reviewable instead of becoming a generic queued-work subsystem.
References: REF-DBUS-SYSTEM-ACTIVATION, REF-DBUS-SPECIFICATION.

## 107. Exact-run observation handles beat PID folklore under the membrane
Linux's `pidfd_open(2)` is a crisp reminder that local supervision should prefer non-reused run handles over ambient numeric IDs when it needs to wait, poll, or fence actions against one concrete process. The man pages are explicit that pidfds can be polled, can be waited on via `waitid(P_PIDFD)`, and are preferred over `/proc/<pid>` handles for this purpose. Steward should not standardize pidfds as public meaning, but adapters should absolutely steal the idea to back runtime-cycle witnesses and stale-action fences without PID-reuse folklore.
References: REF-LINUX-PIDFD-OPEN, REF-LINUX-WAITID-PIDFD.

## 108. Foreground tokens are advisory, not entitlement
The XDG activation protocol is explicit that a compositor may ignore an unknown or invalid activation token, and may also decline activation when the initiating event serial is missing or not recent enough. That is a superb lesson for Steward and Schell: focus or foreground tokens are trailing capability hints, not proof that user attention will be won and not part of target identity itself.
References: REF-XDG-ACTIVATION-V1, REF-DESKTOP-ENTRY-DBUS-ACTIVATION.

## 109. Command-confidence ladders beat binary “smart terminal” stories
VS Code's shell-integration API is unusually honest here: command lines can be low, medium, or high confidence, and `isTrusted` only becomes true when high-confidence reporting is paired with a nonce. Steward's custom shell+terminal should steal that directly. Command chapters do not need one fake smart/dumb bit; they need explicit confidence and trust grades that drive what actions can be offered safely.
References: REF-VSCODE-SHELL-TRUST, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.


## 28. Authority narrowing is healthiest when it is monotonic within one run
OpenBSD's lock-after-setup posture and Capsicum's capability mode and rights reduction all point the same way: once a component enters its narrowed baseline, the healthiest story is usually “stay this narrow or narrower until exit”, not “quietly widen again later because ambient context changed”. Steward should strongly prefer monotonic narrowing inside one runtime cycle and make widening look like a new explicit lifecycle decision.
References: REF-OPENBSD-UNVEIL, REF-FREEBSD-CAP-ENTER, REF-FREEBSD-CAP-RIGHTS-LIMIT.

## 29. Attention tokens are useful, but they are not lifecycle truth
Desktop D-Bus activation, XDG activation, and the OpenURI portal all show a recurring pattern: activation or startup tokens can accompany a request, but they are local proof-of-interaction material for focus policy, not proof that the right component launched, became ready, or may later be manipulated. Steward should keep those stories separate.
References: REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-OPENURI.

## 30. Semantic zones beat prompt regexes
WezTerm's semantic-zone APIs are a sharp reminder that a terminal can expose exact Prompt/Input/Output regions and answer “what semantic zone is under this cell?” directly. Steward's shell+terminal should steal that idea so copy/open/explain actions bind to exact regions instead of pane-wide cwd guesses or visible-text archaeology.
References: REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-SEMANTIC-ZONES, REF-WEZTERM-SEMANTIC-ZONE-AT.

## 31. Stackable deny layers beat one giant sandbox grammar
Landlock's userspace docs are a helpful reminder that a host can allow unprivileged processes to add more restrictions over time, and that inherited restrictions are evaluated so only more constraints get added. Steward should steal that spirit under the membrane: extra narrowing layers are great when they only reduce authority, but the public contract should stay at explicit narrowed-versus-not and locked-versus-degraded truth rather than freezing a portable layer algebra.

## 32. Sealed startup capsules beat env/argv folklore for bulky activation payloads
Linux's `memfd_create()` plus file seals is a sharp lesson that some startup material wants to travel as an anonymous local object with one-way immutability rather than as shell strings, giant environment bundles, or ad hoc temp files. Steward should not standardize a portable memfd-shaped object, but adapters should absolutely steal the idea when they need an exact immutable startup capsule under the membrane.

## 33. Pending request handles beat modal shell magic
The XDG portal Request flow is a nice reminder that mediated user interactions can be explicit objects with a handle, a lifetime, and a later response signal instead of becoming invisible modal side effects. Steward's shell+terminal should steal that idea for chooser/open/reveal detours: keep one exact pending request object the transcript and chrome can point at, then let it resolve, cancel, or expire honestly.

## 34. Deadlines and cancellation are part of request hygiene, not only RPC hygiene
gRPC's current guides are a good reminder that callers often know when work is no longer worth waiting for, and that deadline expiry or explicit cancellation should propagate so downstream work can stop too. Steward should steal that discipline for activation, chooser, and automation requests without freezing a giant RPC framework: one exact request id, one optional deadline, and one explicit cancellation path go a long way.
References: REF-GRPC-DEADLINES, REF-GRPC-CANCELLATION.

## 35. User-mediated requests deserve explicit pending objects
The XDG portal Request docs are very clear that long-running user interactions return a Request object that lives for the duration of the interaction and later emits a response. The lesson for Steward is excellent: chooser/open/approval detours should have one exact pending object that can be inspected, cancelled, or observed to expire rather than dissolving into modal folklore.
References: REF-XDG-PORTAL-REQUEST.

## 36. Input capture should distinguish armed from active
The InputCapture portal is unusually crisp about this: an application may request capture, but only the compositor decides when capture becomes active, may filter events, and may stop capture at any time. Steward should steal that state split for richer shell+terminal capture and modal input surfaces instead of pretending “capture requested” already means “input is flowing.”
References: REF-XDG-PORTAL-INPUTCAPTURE.

## 37. Global shortcuts are healthier as revocable sessions than as ambient entitlement
The GlobalShortcuts portal binds shortcuts to explicit sessions, and those sessions stay tied to the creating application while activation/deactivation arrives as signals. That is a great lesson for Schell: out-of-focus shortcuts can be delightful, but only when they are exact sessions with clear owner, visible state, and one revoke path rather than ambient magic.
References: REF-XDG-PORTAL-GLOBALSHORTCUTS.

## 38. Bulk descriptor cleanup is worth stealing locally without standardizing it publicly
Linux's `close_range(2)` is a sharp reminder that launch hygiene can be made much less fragile when a runtime can close or CLOEXEC a whole descriptor range, and `CLOSE_RANGE_UNSHARE` goes further by avoiding races with shared descriptor tables. Steward should steal that under the membrane while keeping the public contract at reviewed inherited-handle meaning rather than host-specific fd tricks.
References: REF-LINUX-CLOSE-RANGE.

## 39. Multi-process services need exact workload grouping, not PID folklore
Windows Job Objects, Solaris process contracts, and Linux control groups all show the same deeper lesson: the meaningful unit is often the reviewed workload, not whichever PID happened to look “main”. Steward should keep component identity public and use exact host grouping objects only under the membrane.
References: REF-WINDOWS-JOB-OBJECTS, REF-WINDOWS-TERMINATE-JOB-OBJECT, REF-SOLARIS-PROCESS-CONTRACTS, REF-SOLARIS-SMF-CONTRACT-SERVICE, REF-LINUX-CGROUP-V2.

## 40. One-way promise reduction is a wonderful shape for authority hygiene
OpenBSD's `pledge()` is a sharp reminder that narrowing gets much easier to reason about when permissions can only shrink, not elastically expand again later. Steward should steal that one-way cultural rule even while refusing to freeze one host's promise grammar.
References: REF-OPENBSD-PLEDGE, REF-OPENBSD-UNVEIL, REF-FREEBSD-CAP-RIGHTS-LIMIT, REF-LANDLOCK-USERSPACE.



## 50. Closeable handles beat sticky mode bits for transient authority
Portal Request and Session objects, portal Inhibit handles, and Windows Job Objects all point to the same operational lesson: if a power or interaction stays live, it is healthier when it has one exact object, one close/release path, and one visible end-of-life story. Steward should prefer exact closeable grant handles over vague modal state such as “capture is probably still armed” or “that inhibit is probably still on.”
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION, REF-XDG-PORTAL-INHIBIT, REF-WINDOWS-JOB-OBJECTS.

## 51. Owner-loss cleanup is a feature, not an implementation detail to hide from design
Windows Job Objects can be configured to kill on last handle close, portal requests and sessions have explicit close/closed lifetimes, and desktop input/session APIs keep their revocation surface visible. The design lesson for Steward is not “copy these APIs literally”; it is that ephemeral powers should have a fail-closed cleanup story when the holder disappears.
References: REF-WINDOWS-JOB-OBJECTS, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION, REF-XDG-PORTAL-INPUTCAPTURE.

## 52. Supervisors need a real orphan-adoption story under the membrane
Linux child subreapers are a sharp reminder that “main PID plus guessed descendants” is not robust enough when services fork helpers or lose parents unexpectedly. Steward should keep the public contract component-centric, but implementations should absolutely steal exact orphan-adoption and child-accounting tricks under the membrane when the host offers them.
References: REF-LINUX-CHILD-SUBREAPER, REF-WINDOWS-JOB-OBJECTS, REF-SOLARIS-PROCESS-CONTRACTS.

## 53. Snapshot-plus-change views need exact continuity markers and honest loss stories
Kubernetes watch semantics, etcd revision history, and tmux control mode all point at the same design lesson: a client needs more than “some updates happened”. It needs an exact point it is synced through, and an honest way to hear that history was compacted, output was paused, or continuity was lost. Steward should steal opaque observation cursors, bookmark-style progress markers, and explicit resume-or-refresh stories without turning them into a giant event-log contract.

## 54. Reconnect-friendly resume beats sticky fake freshness
Server-Sent Events bakes `Last-Event-ID` into reconnection for exactly this reason: a dropped stream should be able to rejoin from the last acknowledged point, or fail that resume explicitly. Steward should steal the reconnection discipline while keeping the cursor opaque and view-scoped rather than pretending to be a global event log.
References: REF-K8S-API-CONCEPTS, REF-ETCD-DATA-MODEL, REF-ETCD-MAINTENANCE, REF-TMUX-CONTROL-MODE.


## 55. Some transient grants should be consumed by use, not only by time
XDG activation tokens and OAuth authorization codes both reinforce the same lesson: a transient grant is often safest when it expires quickly, binds to a narrow target/context, and cannot be spent twice. Steward should steal that idea selectively. Not every live claim needs a use counter, but one-shot attention/focus hints, high-value reveal actions, and similar transient affordances should be allowed to say `consumed` instead of pretending old history can still spend them.
References: REF-XDG-ACTIVATION-V1, REF-OAUTH-RFC6749.

## 56. Retry-safe request identity is not the same thing as live state
Google's AIP-155, AWS client-token idempotency docs, and the current IETF Idempotency-Key draft all point at the same lesson: a stable request or effect key is valuable because clients may retry after transport uncertainty, but that key names retry-equivalent intent, not the current live resource, not current grant truth, and not a promise of universal exactly-once execution. Steward should steal the small seam: optional effect keys for reviewed non-commutative actions, explicit mismatch when the same key is reused with materially different meaning, and bounded retention windows instead of a mythical forever ledger.
References: REF-GOOGLE-AIP-155, REF-AWS-EC2-IDEMPOTENCY, REF-AWS-ECS-IDEMPOTENCY, REF-IETF-IDEMPOTENCY-KEY.

- **Conditional mutation beats stale optimism**: HTTP `If-Match`, S3 conditional writes, Kubernetes resource-version fences, and etcd compare clauses all show the same lesson: when a human or tool is acting on possibly stale observation, require an exact witness or fail closed instead of silently applying the change to the newest convenient target.


## 54. Downscoping beats broad parent-grant inheritance
OAuth token exchange, Google Cloud Credential Access Boundaries, AWS STS session policies, and macaroons all reinforce the same small lesson: when a helper or downstream call needs less power than the current holder already has, the healthier move is to mint or derive a narrower credential than to pass the broad parent through ambient state. Steward should steal the attenuation-only discipline without inheriting a giant token-exchange or delegation family.
References: REF-RFC8693-TOKEN-EXCHANGE, REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY, REF-AWS-STS-ASSUMEROLE, REF-MACAROONS.

## 13d. Sender-constrained powers beat replayable bearer folklore when raw history may leak
RFC 9700 now makes sender-constrained access tokens a best-current-practice direction, and RFC 9449 / RFC 8705 show two different ways to do it: bind the token to proof from the current presenter rather than trusting copied bearer material alone. The lesson for Steward is not to clone OAuth; it is to admit that some live grants are safer when old frames, copied environment, or detached helpers cannot spend them without current holder proof.

## 57. Fresh local intent should gate some powers, but it should not turn into a reusable approval cache
The HTML user-activation model is crisp about the difference between sticky activation, transient activation, and activation-consuming APIs, and it deliberately consumes some forms of activation to prevent multiple calls from one interaction. XDG activation and portal shortcut/open flows reinforce the same lesson from the desktop side: recent local interaction may yield a token or hint that helps activation or action routing, but that token can already be ineffective, may be ignored, and should not quietly become a durable authority object. Steward should steal the small seam: some high-risk or foreground-sensitive shell actions may require fresh local intent evidence, and that evidence should stay one-shot, current-session scoped, and clearly separate from grants or lifecycle truth.
References: REF-HTML-USER-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-GLOBALSHORTCUTS, REF-XDG-PORTAL-OPENURI.

## 58. Retry timing should be explicit guidance, not guessed folklore
HTTP's `Retry-After`, gRPC server pushback, and Kubernetes CrashLoopBackOff behavior all point at the same smaller lesson: when a system knows that a follow-up attempt should wait, it is healthier to say so explicitly than to make clients infer it from silence, dead buttons, or guessed cooldown math. Steward should steal one tiny seam here — an optional issuer-local earliest-follow-up hint — while refusing to freeze a giant quota or retry-policy family.
References: REF-HTTP-RFC9110, REF-GRPC-HEDGING, REF-K8S-POD-LIFECYCLE, REF-K8S-KUBELET-CONFIG, REF-SYSTEMD-SERVICE.

## 59. Optional helper edges should not silently harden lifecycle order
Fuchsia's capability routing is a useful warning here: optional or weak capabilities do not count for cycle detection or shutdown ordering, and consumers are expected to tolerate those capabilities being absent or disappearing. Steward should steal the caution without freezing a giant dependency algebra too early: some helpers are genuinely optional, and their existence should not quietly become a lifecycle promise.
References: REF-FUCHSIA-CAPABILITIES, REF-FUCHSIA-LIFECYCLE.

## 60. Pull-shaped capabilities keep activation lazy and explicit
Fuchsia's API rubric says the platform prefers pull semantics, specifically noting that component capabilities are assumed to be pulled so startup can stay lazy and shutdown ordering can be inferred from capability routes. Its `fuchsia.sys2` `StartInstance` + Binder pattern adds another small lesson: starting a component and wiring a lightweight wake/stop-notify channel are related operations, but they are still different pieces of meaning. Steward should learn from that without cloning a whole realm manager.
References: REF-FUCHSIA-API-RUBRIC, REF-FUCHSIA-SYS2, REF-FUCHSIA-RUNNER.

## 61. Live-state reconfiguration should be computed, reviewable, and willing to fail
`s6-rc-update` has exactly the right temperament for any future Steward activation-set or policy-set transition work: compute the service-state delta, offer a dry run, accept explicit user instructions for hard cases, and fail instead of relying on doubtful heuristics when the safe move is unclear. That is a much better ancestor for Steward than a manager that silently guesses its way through reconfiguration.
References: REF-S6-RC-UPDATE, REF-S6-RC-WHY.


## 62. First readiness and stable availability should not collapse into one happy bit
Kubernetes and Nomad both learned the same practical lesson the hard way: there is real value in saying a unit is healthy or ready *now* while still waiting a little longer before treating it as stable enough to unblock rollout or replacement. Kubernetes `minReadySeconds` requires a Pod to remain ready without crashes before it is considered available, and Nomad's `min_healthy_time` does the same for allocations before they unblock further updates. Steward should steal that lesson without importing a rollout engine: one tiny optional stability-window seam is enough to say `ready`, `warming toward stable`, or `stable`.
References: REF-K8S-DEPLOYMENT, REF-K8S-STATEFULSET, REF-NOMAD-UPDATE.

## Fresh lesson from legacy job control and newer shells
Classic foreground process-group semantics are a sharp warning sign for Steward. POSIX terminal job control absolutely proves that a shell can know who currently owns the foreground turn, but it also proves how fast that fact grows into a whole process-group worldview if you are careless. Steward should therefore treat `foreground now` as an **optional observational fact** rather than as the foundation of a portable control plane. In parallel, newer shells like PowerShell and Nushell show a healthier UI lesson: suggestions and completions become much better when they can say where they came from, what they mean, and how much of them is merely advisory. That is the right temperament for Steward's custom shell too — richer help, stronger truth labels, no ambient magic.
References: REF-POSIX-TCSETPGRP, REF-PSREADLINE-PREDICTORS, REF-NUSHELL-CUSTOM-COMPLETIONS.

## Fresh lessons from the launch-boundary and crash-only pass
Crash-only software is a useful pressure test, not a complete public lifecycle contract. The valuable lesson is that components should recover quickly and make abrupt stop or restart unsurprising; the dangerous lesson would be to erase explicit stop, quiesce, repair, or reviewed relaunch semantics just because the leaf can survive being killed. In parallel, Apple's file-descriptor inheritance guidance and manager-owned activation APIs reinforce that launch-boundary crossing is an authority handoff. Steward should default to `held here only`, make child delivery explicit, and let receipts remember one reviewed crossing without reviving it later. FreeBSD's process descriptors add a nice corroborating lesson under the membrane: exact run handles can be capability-shaped objects rather than ambient PIDs, which is another reason not to make PID folklore the public contract.
References: REF-CRASH-ONLY-SOFTWARE, REF-APPLE-INHERITING-FDS, REF-LAUNCH-ACTIVATE-SOCKET, REF-FREEBSD-PROCDESC, REF-LINUX-PIDFD-OPEN, REF-WINDOWS-JOB-OBJECTS.

## Fresh lesson from the activation-cause pass
Launchd, D-Bus activation, systemd socket activation, and Fuchsia component startup all point toward the same smaller lesson: the system often can explain **why this concrete cycle started** without needing a giant dependency graph. Sometimes the answer is `manual start`; sometimes it is `first request`; sometimes it is `repair relaunch` or `restore replay`. Steward should steal that tiny explanatory seam and keep it separate from readiness, launch-basis evidence, and restart policy. A small truthful start-cause vocabulary will do more good than a premature universal causality algebra.
References: REF-LAUNCHD-JOBS, REF-SYSTEMD-SD-LISTEN-FDS, REF-DBUS-SPECIFICATION, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-FUCHSIA-SYS2, REF-FUCHSIA-RUNNER.


## Fresh lesson from this pass
Kubernetes' newer `observedGeneration` reporting is a very useful reminder that readiness and status can belong to an **older observed generation** even while a newer desired generation already exists. systemd's `RELOADING=1` plus `MONOTONIC_USEC=` teaches a parallel lesson from another angle: mid-run transitions need explicit attribution if you want to avoid flattening them into one sticky `ready` myth. Steward should steal the tiny seam, not the whole controller worldview: keep an optional readiness-generation witness so shells, receipts, and stale-fenced actions can tell whether current status actually covers the reviewed generation the user is looking at.
References: REF-K8S-PODS-OBSERVED-GENERATION, REF-SD-NOTIFY.

## 62. Restart pressure needs one exact small story, or it leaks back in as folklore
OTP's supervisor intensity/period settings, systemd's `StartLimitIntervalSec=` and `StartLimitBurst=`, Kubernetes' repeated-start `CrashLoopBackOff` display, and SMF's maintenance posture all point at the same lesson: a lifecycle fabric needs one honest answer to **how many automatic restart admissions remain inside which trailing window**. The trick is to keep that answer smaller than a full retry grammar. Steward should separate restart-budget pressure from termination cause, repair gates, and timer choreography so users can tell whether a component is *still eligible for automatic retry*, *cooling down*, or *done auto-retrying for now*.
References: REF-ERLANG-OTP-SUPERVISOR, REF-SYSTEMD-UNIT, REF-SYSTEMD-SERVICE, REF-K8S-POD-LIFECYCLE, REF-SMF-MAINTENANCE, REF-GNU-SHEPHERD-MANUAL.



## Fresh lesson from progress windows and stall horizons
Kubernetes Deployments, Nomad's update block, and systemd's notify/timeout model all reinforce one small lesson Steward should steal: `not ready yet` is too coarse by itself. A system also needs a way to say whether bring-up or reload is still advancing, whether the current horizon was explicitly extended, and when the attempt should be considered stalled instead of merely slow. The public seam can stay tiny — `starting`, `progress seen`, `extended`, `held`, `stalled`, or `unknown` is already much healthier than one endless spinner.
References: REF-K8S-DEPLOYMENT, REF-NOMAD-UPDATE, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE.

## 58. Watchdog and liveness signals are not readiness or useful work progress
Kubernetes is very explicit that `livenessProbe`, `readinessProbe`, and `startupProbe` mean different things, and that startup probes can disable later liveness/readiness checks until startup succeeds. systemd's watchdog model teaches the same split from another direction: later keep-alive pings and timeout extension are explicit protocol, and they make sense only after startup has crossed the relevant boundary. Steward should steal the lesson that “still responsive enough to keep this run” is a distinct truth from “ready for traffic” and from “making meaningful forward progress”.
References: REF-K8S-PROBES, REF-K8S-POD-LIFECYCLE, REF-SD-WATCHDOG-ENABLED, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE.


## 63. Escrow is continuity, not resurrection
Fuchsia's `OnEscrow` and systemd's file-descriptor store both show the same healthy pattern: a supervisor may preserve and redeliver one narrow reviewed continuity object across restart, but that does not make the next run the same process, the same execution group, or automatic proof that takeover already happened. launchd's manager-owned socket delivery reinforces the same boundary from an older lineage. Steward should steal the tiny seam — explicit escrow current versus redelivered truth — while refusing a giant checkpoint/restore or generic state-broker family.
References: REF-FUCHSIA-COMPONENT-RUNNER, REF-FUCHSIA-IDLE-STOP, REF-SYSTEMD-FDSTORE, REF-LAUNCHD-SOCKETS.

## 23. Discovery presence is its own truth
etcd leases, ZooKeeper ephemeral nodes, Consul TTL/critical deregistration, and Kubernetes Lease objects all point to the same lesson: discoverable published presence can be renewed, expired, or withdrawn without being the same thing as readiness, serving truth, or runtime identity. Steward should not let “it is in discovery” collapse into “it is healthy and serving.”
References: REF-ETCD-LEASE-API, REF-ZOOKEEPER-PROGRAMMER, REF-CONSUL-AGENT-CHECK, REF-K8S-LEASES, REF-K8S-POD-LIFECYCLE.

## Fresh lesson from the launch-baseline pass
launchd's daemon guidance is unusually explicit about what a managed service should **not** do for itself: do not `setsid`, do not `chdir` or `chroot` ad hoc, do not retarget stdio to `/dev/null`, do not close stray descriptors, and prefer property-list keys for working directory, identity, and other launch context. Combined with systemd's new-style daemon guidance, the lesson is crisp: when a lifecycle fabric owns restart and accountability, the launch baseline belongs to the manager and should be explicit, not rebuilt by daemon self-surgery or login-shell folklore.
References: REF-LAUNCHD-JOBS, REF-SYSTEMD-DAEMON, REF-SYSTEMD-EXEC.

## Fresh lesson from the continuity-redelivery pass
systemd fdstore and Fuchsia escrow both make the same deeper point: preserved handles or state are useful precisely because they are **redelivered later** to a new execution, not because the old execution somehow never ended. Steward should therefore keep continuity receipts, redelivery, and fresh runtime-cycle identity visibly separate, and it should refuse any shell story that turns escrow into magical uninterrupted liveness.
References: REF-SYSTEMD-FDSTORE, REF-FUCHSIA-IDLE-STOP, REF-FUCHSIA-COMPONENT-RUNNER.

## Fresh lesson from the shell-power pass
The XDG InputCapture portal's enabled-versus-active distinction and XDG activation's consent-token model both reinforce the same shell lesson: a requested or armed power is not yet the same thing as a live active control path. Steward should steal that discipline for shortcut capture, input capture, and other stronger shell lanes so a pending request, an armed shortcut, and an active live claim stay different truths.
References: REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-GLOBALSHORTCUTS.

## Fresh lesson from the remote-comfort pass
Ghostty and kitty both show how attractive remote comfort becomes once the terminal can preserve cwd, prompt marks, terminfo, and shell integration across SSH-like hops. The cautionary lesson for Steward is that this comfort is best treated as **observed hop-scoped support**, not as proof that remote context, authority, or execution ground still match the local story. Rich remote comfort is worth stealing, but only with explicit hop lineage and visible downgrade when the path falls back.
References: REF-GHOSTTY-SHELL-INTEGRATION, REF-KITTY-SSH, REF-KITTY-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INTEGRATION.

## 50. Helper phases are useful, but they should not harden into a public ontology too early
Nomad's prestart/poststart/poststop hooks and its sidecar distinction are a good reminder that initialization helpers, companions, and cleanup tasks are practical patterns. The caution for Steward is to steal the accountability and ordered-stop lessons without freezing a universal taxonomy of sidecars, phases, or group-local lifecycle roles before SlopOS itself settles.
References: REF-NOMAD-LIFECYCLE, REF-GNU-SHEPHERD-TRANSIENT.

## 51. Restart budgets and relocation are different decisions
Nomad is unusually crisp that local restart policy and later rescheduling are separate mechanisms: restarts happen on the current client, while rescheduling happens after restart exhaustion or different node-level failure conditions. Its health-check restart rules also spend against the restart policy instead of quietly inventing another recovery story. Steward should keep the same separation: local restart pressure, repair-gate admission, and any future placement or relocation seam are different truths.
References: REF-NOMAD-RESTART, REF-NOMAD-CHECK-RESTART, REF-NOMAD-RESCHEDULE, REF-K8S-PROBES.

## 52. Shell integration quality should be graded, not binary
VS Code's distinction between rich, basic, and none is a useful cultural lesson for Steward's custom shell+terminal: semantic UX should degrade honestly as hops, multiplexers, or manual installs drop fidelity. That is healthier than one misleading boolean that says shell integration is simply on or off.
References: REF-VSCODE-UPDATE-1099, REF-VSCODE-SHELL-INTEGRATION.

## 53. Automation in a terminal needs an approval gradient, not ambient consent
Recent VS Code terminal tooling keeps surfacing approval as a scoped choice—per command, per session, and with explicit history suppression when automation injects commands. Steward should steal the lesson, not the product surface: keep reviewed actions visibly staged, scope any temporary widening, and do not quietly launder automated commands into ordinary shell history.
References: REF-VSCODE-UPDATE-1104, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1108.



## 54. Read-only witness sessions are a real product shape, not a toy demo mode
Recent terminal tooling is a good reminder that collaboration does not have to start with shared steering. Zellij's read-only session sharing and tmux control mode both show that observe-without-input can be a first-class state with its own transport, subscriptions, and expectations. Steward should steal that move for support, demos, and cross-machine witnessing instead of assuming that attach always implies control.
References: REF-ZELLIJ-RELEASE-044, REF-TMUX-CONTROL-MODE.


## 63. Shared terminal presence must not collapse into one vague attached state
Zellij's new read-only session sharing, the InputCapture portal's enabled-versus-active split, and GlobalShortcuts' session model all reinforce the same lesson: a useful shared session can expose observation, potential activation, active control, and denial as different truths. Steward should steal that discipline. `observe`, `attach`, `control`, and `debug` should stay visibly different lanes rather than one sticky attached bit that quietly widens authority.
References: REF-ZELLIJ-RELEASE-044, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-PORTAL-GLOBALSHORTCUTS.


## 52. Transport uncertainty should not masquerade as lifecycle truth
Nomad's `disconnect` block is unusually healthy about network partitions: with `lost_after`, an allocation can sit in `unknown` during reconnect grace, later become `lost`, or be replaced according to a separate reschedule story instead of flattening everything into one flattering `recovered` bit. XDG portals reinforce the same discipline from the UI side by making long-lived user interactions ride exact Request and Session handles that stay alive for the duration of the interaction and then complete or close explicitly. Steward should steal the small lesson: a dropped or resumed attach path needs explicit `reconnecting`, `resumed`, `expired`, `replaced`, or `lost` truth, and none of those should silently answer the separate question of what happened to the service runtime.
References: REF-NOMAD-DISCONNECT, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION.

## 53. Witness-first resume is safer than silent control carryover
Zellij's new remote attach and read-only sharing make a strong terminal-side argument for witness-first reconnect: it is useful to regain visibility fast, but much riskier to assume that interactive control, resize power, or lifecycle authority should silently survive a dropped path. Ghostty's active-prompt features point the same way from the UX edge: luxuries are wonderful when the live prompt is exact, but reconnect should be willing to degrade them honestly when that exactness is stale. Steward should therefore prefer `resume to observe`, then explicit re-upgrade when stronger lanes are still justified.
References: REF-ZELLIJ-RELEASE-044, REF-GHOSTTY-RELEASE-130.

## Fresh lesson from proposal lanes and agentic terminals
VS Code terminal inline chat has exactly the right instinct: help can appear inline with the terminal, but the user still reviews the response and chooses either `Run` or `Insert` before the command becomes shell reality. Warp's newer agent work sharpens the complementary lesson. It keeps a distinct terminal mode and agent mode, lets agents attach to a live PTY while still "proposing actions inside the session", and makes any session-scoped auto-accept widening explicit. Steward should steal that discipline, not the branding: proposal/help lanes can be luxurious, but they should remain visibly weaker than exact shell input and canonical lifecycle truth.
References: REF-VSCODE-INLINE-CHAT, REF-VSCODE-UPDATE-1110, REF-WARP-FULL-TERMINAL-USE, REF-WARP-AGENT-MODALITY, REF-WARP-NOTEBOOKS.


## Fresh lesson from detour-return and history-hygiene research

OpenURI and portal request/session work keep user-mediated detours object-shaped and closeable, while RFC 8252 insists native-app authorization should go through an external browser rather than an embedded fake one. Together they sharpen a lesson Steward should keep: a detour may leave the terminal, but its return should still come back as an exact bounded object with expiry, cancellation, and visible rebind truth rather than as ambient “some browser login probably succeeded” folklore.
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION, REF-XDG-PORTAL-OPENURI, REF-XDG-ACTIVATION-V1, REF-RFC8252-NATIVE-APPS.

VS Code's January 2026 terminal updates also reinforce a smaller shell lesson: some command kinds deserve less chrome. If agentic CLIs or `clear`-like commands make sticky command guides noisier rather than more truthful, the terminal should be able to ignore them explicitly instead of pretending every prompt-shaped block deserves the same guide treatment.
References: REF-VSCODE-UPDATE-1109.


## Fresh lesson from remembered-search and history-hygiene research

Warp's current Command Search is a great reminder that one search surface can span command history, workflows, notebooks, prompts, and agent conversation history without forcing them to become the same thing. Its Workflows and Notebooks docs also reinforce the healthiest default landing: results often insert into the active input editor so the user can review and adjust before running. VS Code's terminal-tool history controls sharpen the other half of the lesson: tool-run commands may deserve different shell-history treatment than typed commands. Steward should steal the small discipline, not the product shape: unify remembered search if it helps, but keep lane labels, lane-appropriate actions, and canonical execution truth visibly separate.
References: REF-WARP-COMMAND-SEARCH, REF-WARP-WORKFLOWS, REF-WARP-NOTEBOOKS, REF-WARP-AGENT-MODALITY, REF-VSCODE-UPDATE-1108.


## Fresh lesson from the approval-rung pass
Recent VS Code agent docs are unusually explicit that approval is not one flat setting: the current session can sit at Default Approvals, Bypass Approvals, or Autopilot, while enterprise policy can still hide the higher rungs entirely, force manual approval for specific tools, or disable rule-based terminal auto-approval. Warp sharpens the same lesson from another angle with Agent Decides, Always ask, Always allow, Never, and a louder run-until-completion mode whose denylist behavior is a special stronger case. Steward should steal the principle, not the product surfaces: proposal, ask, scoped auto-approval, and full autonomous continuation are different powers, and policy floors must outrank convenience.
References: REF-VSCODE-UPDATE-1111, REF-VSCODE-AGENT-TOOLS, REF-VSCODE-AI-SETTINGS, REF-WARP-AGENT-PROFILES.


## Fresh lesson from the preflight-lane pass
Terraform is unusually clear that `plan` creates a preview and `apply` is the separate step that actually performs operations; when you pass a saved plan file to `terraform apply`, the act of supplying that exact file is treated as approval of that exact planned result. Kubernetes sharpens the caution from the other side: `kubectl diff` is a preview, but because it uses server-side dry-run it still requires real `PATCH`, `CREATE`, and `UPDATE` permissions. Current coding agents reinforce the same cultural split—VS Code now has a dedicated Plan agent, and Claude Code exposes a distinct `plan` permission mode where it can analyze but not modify files or execute commands. Steward should steal the small lesson: explain, diff, speculative preview, reviewed saved plan, and apply are different moves, and preview may still need real footing and real policy.
References: REF-TERRAFORM-PLAN, REF-TERRAFORM-APPLY, REF-KUBECTL-DIFF, REF-K8S-DECLARATIVE-CONFIG, REF-VSCODE-AGENT-PLANNING, REF-CLAUDE-CODE-PERMISSIONS.

## Fresh lesson from the hold-state pass
Kubernetes rollout pause/resume, Nomad node drain, and systemd's freeze/thaw plus masking all reinforce one healthy operational lesson: deliberate holds are not one thing. A paused deployment keeps current state functioning but stops reconciliation, a drained node stops new placement and migrates or completes existing work, freezing suspends execution itself, and masking prevents activation entirely. Steward should steal that exact honesty. `paused`, `draining`, `frozen`, `start prevented`, `stalled`, and `failed` should stay visibly different truths.
References: REF-K8S-ROLLOUT-PAUSE, REF-K8S-ROLLOUT-RESUME, REF-K8S-DEPLOYMENT, REF-NOMAD-NODE-DRAIN, REF-SYSTEMCTL, REF-SYSTEMD-UNIT.


## Fresh lesson from the exception-witness pass
Kubernetes, VS Code, and GitHub all reinforce the same uncomfortable but healthy lesson: bypass is not satisfaction. `kubectl drain --disable-eviction` explicitly bypasses PodDisruptionBudget checks and tells operators to use that with caution; current VS Code agent docs say Bypass Approvals and Autopilot can ignore manual approval prompts for terminal commands and other tools; and GitHub push-protection bypass requests make contributors wait for designated reviewers when delegated bypass is enabled. Steward should steal the discipline, not the product surface: proceeding under exception should stay explicit, attributable, and visibly weaker than saying the underlying gate actually passed.
References: REF-KUBECTL-DRAIN, REF-VSCODE-AGENT-TOOLS, REF-VSCODE-UPDATE-1111, REF-GITHUB-PUSH-PROTECTION-BYPASS, REF-GITHUB-PROTECTED-BRANCHES.


## Fresh lesson from the serve-state pass
Kubernetes EndpointSlices, Envoy health/drain behavior, HAProxy's `ready` / `drain` / `maint` states, and systemd's overall `degraded` state all reinforce the same lesson: **readiness, current serving, drain posture, and impairment are different truths**. Steward should steal the discipline, not the whole products. `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, and `not serving` deserve explicit shell-visible truth when a substrate can prove them.
References: REF-K8S-ENDPOINTSLICES, REF-K8S-POD-LIFECYCLE, REF-ENVOY-HEALTHCHECKING, REF-HAPROXY-MANAGEMENT, REF-SYSTEMCTL.

## Fresh lesson from the pressure-witness pass
Linux PSI, systemd's memory-pressure handling, Fuchsia's memory-pressure levels, and Kubernetes node-pressure eviction all reinforce the same lifecycle lesson: **pressure is neither failure nor permission**. It is an early scoped warning about stall, scarcity, or likely reclaim/eviction pressure, and useful systems react before they start killing work. Steward should steal the small discipline, not the host APIs: keep compact scoped pressure truth such as `some`, `full`, `warning`, or `critical` visible, keep it separate from serve-state and headroom, and refuse to turn one provider's pressure-watch protocol into a portable autoscaler or reclaim-policy family.
References: REF-LINUX-PSI, REF-SYSTEMD-MEMORY-PRESSURE, REF-FUCHSIA-MEMORY-RECLAMATION, REF-K8S-NODE-PRESSURE-EVICTION.
## Fresh lessons from the backpressure pass
Envoy, Kubernetes API Priority and Fairness, gRPC, and RFC 6585 all keep rediscovering the same operational lesson: **pressure is not the same truth as backpressure**. Pressure describes strain; backpressure describes what the system is doing about fresh demand. Queueing, retry-later, selective shed, and stop-accepting are therefore different truths, and flattening them into one generic `busy` bit teaches operators the wrong mental model. References: REF-ENVOY-OVERLOAD-MANAGER, REF-K8S-APF, REF-GRPC-STATUS-CODES, REF-GRPC-RETRY, REF-RFC6585.

Another repeated lesson is that **retry advice is not durable permission**. HTTP 429 may include `Retry-After`, and gRPC pushback can ask clients to delay or avoid another attempt, but those are lane-local hints tied to current overload posture rather than future reservations. Steward should preserve that humility: `retry after 250ms` or `do not retry` should explain present footing, not mint ambient authority for later work. References: REF-GRPC-RETRY, REF-RFC6585.

Kubernetes APF adds another useful cut: **brief queueing with fairness is different from outright rejection**. That is exactly the sort of tiny honest distinction Steward should keep because it makes `why not now?` much more legible in the shell without forcing a giant scheduler or traffic family. References: REF-K8S-APF.

## Fresh lesson from the adaptation-witness pass
Systemd's memory-pressure protocol, Fuchsia's memory-pressure levels, Kubernetes node-pressure eviction, and Envoy's overload/adaptive-concurrency work all reinforce a slightly subtler lesson than mere `under pressure`: **protective response is its own truth**. Shrinking caches, reducing concurrency, deferring optional work, narrowing mode, or reclaiming before eviction are deliberate survival moves, not vague degradation and not proof that the underlying strain is gone. Steward should steal the discipline, not the knobs: keep small explicit protective-response truth visible when a substrate can prove it, and refuse to turn one stack's adaptation engine into a portable brownout or autoscaling family.
References: REF-SYSTEMD-MEMORY-PRESSURE, REF-FUCHSIA-MEMORY-RECLAMATION, REF-K8S-NODE-PRESSURE-EVICTION, REF-ENVOY-OVERLOAD-MANAGER, REF-ENVOY-ADAPTIVE-CONCURRENCY.

## Fresh lesson from the realm-and-control pass
Fuchsia's realm model and OTP's supervision trees both reinforce a quiet but important lesson: a lifecycle fabric gets more understandable when it has a shallow ownership subtree for failure containment, capability scope, and restart policy. Steward should steal that shape without cloning a giant framework. A small realm/island seam can be useful if it only means “these components share an ownership boundary and containment story,” not “here comes a whole unit-language empire.”
References: REF-FUCHSIA-REALMS, REF-ERLANG-OTP-SUPERVISOR.

## Fresh lesson from the explicit-control pass
s6's `s6-svc` is a wonderful reminder that operators should be able to stop, restart, or signal supervised work without knowing a PID or consulting a pidfile. The public target is the supervised object, not ambient host process trivia. Steward should keep that lesson aggressively: lifecycle control should bind to `cid` and exact run witnesses, while raw signals, job handles, cgroups, and process groups stay under the membrane.
References: REF-S6-SVC, REF-S6-SUPERVISE.

## Fresh lesson from the active-prompt pass
Semantic prompt markers keep teaching the same small lesson: **the active prompt is a real object, not just a pretty line of text**. FinalTerm/iTerm2's old shell integration, VS Code's shell integration, Fish's current OSC 133 markers, and Ghostty's current click-aware prompt support all converge on the idea that terminals get much smarter when prompt start, prompt end, command start, and command finish are explicit. Steward should steal that seam aggressively — but only as observational shell truth. Prompt click-to-cursor, exact command reveal, jump-to-output, and per-frame notifications are wonderful shell luxuries; they should not quietly become lifecycle authority or a universal shell-object protocol before the design earns that weight.
References: REF-ITERM2-ESCAPE-CODES, REF-VSCODE-SHELL-INTEGRATION, REF-FISH-TERMINAL-COMPAT, REF-GHOSTTY-RELEASE-130, REF-OSC133-SPEC.

## Fresh lesson from the island-and-handoff pass
Fuchsia's component topology docs make a very useful distinction: the component instance tree answers ownership and composition, while the capability routing graph answers who may use which capability. Steward should steal that separation aggressively. A shallow ownership island can be a great control and containment boundary without pretending it is the full routing, discovery, or environment story.
References: REF-FUCHSIA-REALMS, REF-FUCHSIA-TOPOLOGY.

## Fresh lesson from the portal-handle pass
XDG portals keep teaching a beautifully narrow lesson: interaction lifetimes and handoffs want exact handles. A Request object lives for the user interaction and can be closed explicitly, while document handoff uses explicit document IDs plus open-file-descriptor proof instead of ambient path blessing. Steward should steal that habit for chooser/open/share detours and shell return paths: exact request tickets and exact handoff objects beat callback folklore, focus folklore, or remembered paths.
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-DOCUMENTS.

## Fresh lesson from the current-command pass
Windows Terminal, iTerm2, VS Code, Fish, and Ghostty all reinforce the same shell lesson from slightly different angles: **the command being edited right now is its own exact object, not merely text near the prompt**. Once a shell can mark the current prompt and command boundary explicitly, the UI should be able to reveal, select, diff, and explain the current command without scraping pane-local neighborhoods or pretending old transcript text is still live input. Steward should steal the narrow seam — exact current-command object beside the prompt lease — while refusing a universal shell grammar or rewrite protocol too early.
References: REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-COMMAND-SELECTION, REF-VSCODE-SHELL-INTEGRATION, REF-FISH-TERMINAL-COMPAT, REF-GHOSTTY-RELEASE-130.

## Fresh lesson from the live-prompt pass
Ghostty's current prompt-click behavior reinforces a small but important rule: click-to-edit is wonderful precisely when the terminal knows it is looking at the current prompt, not just any old transcript line. Steward should treat the active prompt as a fresh lease-shaped object that expires on exec, hop confusion, or semantic loss rather than as perpetually editable scrollback.
References: REF-GHOSTTY-CONFIG-REFERENCE, REF-OSC133-SPEC.
## 73. Exact prompt leases beat permanently editable transcript folklore
Ghostty's current OSC 133 click-to-move support, Fish's newer prompt-end markers and fresh-prompt cwd reporting, iTerm2's long-running shell integration, and VS Code's command-tracking shell integration all point at the same lesson: the active prompt is a small live object with a beginning, an exact current footing, and an ordinary expiry. Steward should steal that seam directly. Prompt-local editing, current-command reveal, and nearby assist should light up only while that lease is exact, then degrade honestly to frame anchors or selection instead of pretending old transcript text is still live input.

References: REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-CONFIG-REFERENCE, REF-FISH-OSC-MARKERS, REF-FISH-TERMINAL-COMPAT, REF-ITERM2-SHELL-INTEGRATION, REF-VSCODE-SHELL-INTEGRATION.


## 68. Completed chooser/auth results should be exact outcome objects, not stale handle reinterpretation
Modern mediated systems keep request lifetime, response payload, and any later live session or restore token as separate things. That is healthier than teaching users or tools to remember one handle and reinterpret it forever. Steward should use the same discipline in the shell: pending request cards should resolve into exact outcome cards, with explicit rebind-required or degraded truth when the original footing is gone.
References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-REMOTE-DESKTOP, REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.

## Fresh lesson from the status-barrier pass
systemd's `sd_notify_barrier()` is the cleanest reminder that status emission and barrier-confirmed attribution/currentness are different truths, while XDG Portal's Request→Response shape shows the same pattern in a GUI-facing mediated world: one thing was emitted or requested, and a later stronger boundary says the observer can now treat the result as definitely current. Fuchsia's scoped `event_stream` capabilities add the missing composition lesson — subscriptions can be subtree-scoped and useful without forcing one giant global event topology. Steward should steal the tiny seam: exact barrier-confirmed currentness for specific status/checkpoint updates, while refusing a giant event-log or controller-runtime family too early.


## 33. Paste demarcation is useful, but it is only the floor
Bracketed paste is a healthy baseline because it lets terminals and line editors distinguish pasted text from typed input, and GNU Readline binds bracketed paste so pasted text is inserted as one self-insert unit instead of executing editing commands. But xterm also documents separate modes for character-quoting and newline pasting, which is a reminder that “this was a paste” is still weaker than “this paste was safe to send directly here.” Steward should steal the demarcation, then add an explicit paste firewall rather than pretending bracketed paste solved every risky input case.
References: REF-XTERM-BRACKETED-PASTE, REF-BASH-READLINE-INIT, REF-BASH-COMMANDS-FOR-TEXT.

## Fresh lesson from the attention-watch pass
iTerm2's alert-on-next-mark, Ghostty's newer command-finished notifications, and VS Code's shell-integration-backed command navigation all point at the same shell lesson: **user-armed exact watch is its own truth**. Watching one exact frame or receipt is healthier than one global notification toggle because it preserves which object mattered, which boundary was being watched, and whether delivery or reveal actually happened. Steward should steal that seam directly: one small live watch object over one exact anchor, visible expiry/cancel/reveal states, and no hidden conversion into automation or reminder folklore.
References: REF-ITERM2-SHELL-INTEGRATION, REF-ITERM2-MENU-ITEMS, REF-GHOSTTY-RELEASE-130, REF-VSCODE-SHELL-INTEGRATION, REF-WEZTERM-NOTIFICATION-HANDLING.

## Fresh lesson from the output-slice pass
VS Code's shell integration, Windows Terminal's shell integration, iTerm2's command selection, and WezTerm's semantic zones all reinforce the same shell lesson: **the exact output of one command is its own useful object**. Once command/output boundaries are explicit, the UI can select just the output, open it elsewhere, attach it as troubleshooting context, or annotate it without exporting unrelated scrollback. Steward should steal that seam directly: one bounded output-slice object tied to a stronger frame or anchor, clearly weaker when only parsed or text-selected fallbacks survive.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1106, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SEMANTIC-ZONES.

## Fresh lesson from the command-evidence pass
VS Code's newer terminal command attachments make a very healthy design point explicit: the useful thing to share is one exact command interaction with its command line, captured output, and exit code, not whatever scrollback happens to be visible nearby. Windows Terminal's command/output selection and WezTerm's semantic-zone selection reinforce the same lesson from the terminal side. Steward should steal the tiny seam — one exact command-evidence bundle — while refusing a transcript-export empire or durable evidence warehouse too early.
References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1109, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE, REF-WEZTERM-SELECT-TEXT-AT-MOUSE.

## 82. Scoped helper shells are useful, but they are adjuncts, not lifecycle truth
Fuchsia's `ffx component explore` is a great precedent because it explicitly spawns a shell scoped to a component instance. Kubernetes' `kubectl exec` makes the same point in a more common stack by requiring an explicit pod/container target for command execution. Docker's `docker exec` adds the cautionary half of the lesson: the helper command only runs while the container's primary process is running, and it is not restarted when the container restarts. Steward should steal the explicit scoped-shell verb while keeping helper shell entry separate from component identity, restart continuity, and lifecycle authority.
References: REF-FFX-COMPONENT, REF-KUBECTL-EXEC, REF-DOCKER-EXEC.

## Fresh lesson from the repair-card pass
VS Code's terminal quick fixes, Windows Terminal's shell-integration-backed command boundaries and recent-command suggestions, and WezTerm's semantic-zone / palette extension model all point at the same shell lesson: **post-command repair should be a reviewable card over one exact anchor, not ambient terminal mutability**. The right object is a small likely-next-fix card bound to one failed or blocked frame/verdict/receipt, with visible why-this-appeared and disabled-reason truth. Steward should steal that seam directly while refusing an auto-remediation or workflow-engine family too early.
References: REF-VSCODE-UPDATE-1072, REF-VSCODE-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WEZTERM-AUGMENT-COMMAND-PALETTE, REF-GHOSTTY-RELEASE-130.


## Fresh lesson from the state-explainer pass
systemd's notify/status vocabulary, Fuchsia Inspect's typed state trees, VS Code's shell-integration detail views, and WezTerm/Windows Terminal semantic zones all reinforce the same smaller lesson: **explanation should ride one exact anchor and stay smaller than diagnosis**. A component or command can often answer *why this state currently holds* without exporting a log firehose or pretending it solved root cause in the universal sense. Steward should steal that seam directly: one compact exact explainer bound to one frame/run/request/repair anchor, visibly fresher and stronger than transcript guesses, but much smaller than a doctor command or incident ontology.
References: REF-SD-NOTIFY, REF-FUCHSIA-INSPECT-TREE, REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1099, REF-WEZTERM-SEMANTIC-ZONES, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION.

## Fresh lesson from the assist-receipt pass
Modern code-action systems keep teaching a very healthy small lesson: **the suggestion is not the same thing as the explanation for why it appeared**. VS Code's API keeps disabled reason, diagnostics, workspace edit, and command as separate fields, while the LSP spec keeps diagnostics, disabled reasons, lazy resolve, and edit-versus-command ordering explicit. Steward should steal that discipline for shell help: a quick fix or repair card should carry one tiny assist receipt that explains provenance, anchor, freshness, and disabled reasons without becoming diagnosis truth, execution truth, or workflow state.
References: REF-VSCODE-CODEACTION-API, REF-LSP-317-CODEACTION, REF-VSCODE-UPDATE-1072.

## Fresh lesson from the injection-receipt pass
Current editor/terminal UX keeps teaching a subtle but important shell lesson: **writing reviewed text or env into a live session is not the same thing as running it**. VS Code's shell integration explicitly lets recent commands be written to the terminal without running them, its CodeAction model keeps edits separate from commands and applies edits first when both exist, and newer terminal-tool behavior can even keep tool-run commands out of ordinary shell history when shell integration is working. Steward should steal that whole split. A tiny injection receipt can say what exact reviewed mutation landed in the live prompt or session, how it was scoped, and what history policy applied — while still leaving later execution truth to command frames, receipts, and verdicts.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-CODEACTION-API, REF-VSCODE-UPDATE-1108, REF-GIT-ADD.

## Fresh lesson from the selective-restart and sandbox-ready pass
Kubernetes' current Pod lifecycle docs sharpen two lifecycle lessons that older supervisors only hinted at. First, container-level `restartPolicyRules` and in-place whole-Pod restart actions show that restart policy can be exact about *which* exit classes should replay local work. Second, `PodReadyToStartContainers` makes runtime-sandbox/network readiness a separate truth from init completion and service readiness. Dinit's restart windows, Nomad's split between restart and later reschedule, and OTP's restart intensity reinforce the same discipline from older lineages: helper exits, main-run exits, health-triggered restarts, sandbox-ready, serve-ready, and replacement after restart exhaustion are different truths. Steward should steal that separation instead of flattening everything into one vague `restarted` story.
References: REF-K8S-POD-LIFECYCLE, REF-K8S-KUBELET-CONFIG, REF-NOMAD-RESTART, REF-NOMAD-CHECK-RESTART, REF-DINIT-SERVICE, REF-ERLANG-OTP-SUPERVISOR.

## Fresh lesson from the scoped-observation and continuity-loss pass
Fuchsia's current component docs are refreshingly honest about observer limits: event streams can be scoped, components that restart must re-acquire capabilities, and a subscriber that dies with queued events simply loses them. That is the right temperament for Steward. Observation continuity should be resumable when possible, but continuity loss must stay explicit instead of being laundered into flattering live truth. Scoped watches, refresh-needed states, and exact rebind rules are healthier than pretending there is one immortal global watcher.
References: REF-FUCHSIA-EVENT-STREAM, REF-FUCHSIA-LIFECYCLE, REF-FUCHSIA-PROCESS-LIFECYCLE.

## Fresh lesson from the manager-owned activation-cause pass
GNU Shepherd's transient service maker and launchd's named keepalive / queue-driven activation continue to reinforce one old lesson that Steward should copy carefully: on-demand work is healthiest when the manager owns the trigger semantics and launch context, not when the service daemonizes itself and recreates its public world from ambient shell or session state. Solaris SMF sharpens the same point from another lineage by keeping service models and restarters explicit. Steward should steal the narrow discipline: activation should have exact causes, transient background promotion should stay reviewable, and durable service identity should remain manager-owned instead of folklore-shaped.
References: REF-GNU-SHEPHERD-TRANSIENT, REF-GNU-SHEPHERD-TRANSIENT-MAKER, REF-LAUNCHD-JOBS, REF-SOLARIS-SMF-CONTRACT-SERVICE, REF-SOLARIS-SMF-RESTARTER, REF-SMF-MAINTENANCE.

## Fresh lesson from the operator-and-queue-activation pass
Oracle SMF sharpens an old but easily forgotten lesson: **live operate verbs should be narrower than configure/edit powers**. Its rights split between `Service Operator` and `Service Management` is a clean reminder that restart, refresh, enable, disable, and clear-style actions do not have to imply broad manifest or policy editing rights. Launchd's queue-directory activation and Shepherd's transient service maker reinforce the neighboring lesson from another angle: background work is healthier when the manager owns the trigger, run footing, and cleanup story rather than when services daemonize themselves and smuggle persistence through folklore. Steward should steal both moves together — narrow live verbs over exact targets, and manager-owned activation causes for queued or transient work.
References: REF-SMF-SECURITY, REF-LAUNCHD-JOBS, REF-GNU-SHEPHERD-100.

## Fresh lesson from the generation-and-selective-restart pass
Current Kubernetes docs make a modern version of an older supervision lesson explicit. `restartPolicyRules` are now beta and enabled by default in v1.35, which reinforces that selective restart classes can stay local to one container instead of becoming one giant pod-wide retry myth. The current feature-gate docs also keep `PodReadyToStartContainers` and Pod `observedGeneration` tracking as distinct truths, which is a strong reminder that sandbox/network footing, readiness, and freshness-of-status are different things. Steward should steal the discipline, not the full machinery: exact restart windows, optional selective restart rules later, sandbox-ready separate from serve-ready, and freshness stamps on status so stale observations do not flatter themselves into current truth.
References: REF-K8S-POD-LIFECYCLE, REF-K8S-FEATURE-GATES, REF-K8S-V135-RELEASE, REF-DINIT-SERVICE, REF-ERLANG-OTP-SUPERVISOR.

## Fresh lesson from the sidecar-boundary pass
Kubernetes' current sidecar model is a very useful caution against flattening all helpers into one word. A sidecar-style init container with `restartPolicy: Always` starts in init order, may contribute to Pod readiness if it has a `readinessProbe`, and is terminated only after the main application containers stop, in reverse order. That means ordered adjunct work, persistent support work, and main-service truth are different things. Steward should steal the separation — one-shot helpers, persistent adjuncts, and the accountable long-lived leaf stay distinct — while still refusing a universal hook or sidecar taxonomy too early.
References: REF-K8S-SIDECAR-CONTAINERS, REF-K8S-POD-LIFECYCLE, REF-NOMAD-LIFECYCLE.

## Fresh lesson from the scope-is-a-first-class-knob pass
Fuchsia's component model keeps reminding us that observation scope is part of the contract, not a later optimization. Current CML syntax lets `event_stream` routes be downscoped with `scope`, and Fuchsia's principles explicitly describe component-scoped event streams about children. Steward should steal that cultural rule: every lifecycle watch should prefer an exact child / subtree / ownership-island scope and admit when continuity or breadth is lost, rather than defaulting to one giant machine-wide watcher.
References: REF-FUCHSIA-CML, REF-FUCHSIA-EVENT-STREAM, REF-FUCHSIA-REALMS.


## Fresh lesson from the full-reset versus leaf-restart pass
Kubernetes' new in-place `RestartAllContainers` work is a sharp reminder that at least three operations deserve separate names: **restart one leaf**, **reset the whole component environment in place and replay setup**, and **replace the object entirely**. The feature explicitly re-runs init containers from the beginning, preserves Pod identity-critical footing such as UID/IP/sandbox/volumes, adds an `AllContainersRestarting` condition, and warns that `preStop` hooks are not run during this reset path. Steward should learn the design lesson without importing the whole feature: a future exact whole-component reset might be useful, but it must stay visibly different from ordinary leaf restart, graceful stop→start, or replacement of the component object.
References: REF-K8S-RESTART-ALL-CONTAINERS, REF-K8S-POD-LIFECYCLE, REF-K8S-SIDECAR-CONTAINERS.

## Fresh lesson from the edge-type and work-unit-completion pass
Dinit, systemd, and OTP sharpen the same design warning from three different directions. Dinit distinguishes hard `depends-on:` from weaker `waits-for:` / ordering forms and explicitly warns that weak waiting often creates noisy half-starts when a dependency is actually essential. systemd's `Upholds=` shows that “keep this other unit alive while I am alive” is not the same relation as a one-shot startup pull-in. OTP's significant-child plus `auto_shutdown` model shows a third distinct truth: some children define completion of a cooperating work unit rather than a dependency that should be restarted forever. Steward should steal the lesson without importing a giant graph DSL: if it ever needs edge semantics, `need for start`, `optional accompaniment`, `continuous upkeep`, and `work-unit completion` should remain visibly different named relations.
References: REF-DINIT-AS-INIT, REF-DINITCTL, REF-SYSTEMD-UNIT, REF-ERLANG-OTP-SUPERVISOR.


## Fresh lesson from the durable-trigger and exact-ready pass
Current primary docs sharpen a lifecycle lesson that older service folklore often smudged: **not every activation source deserves the same trust**. Launchd's `launchd.plist(5)` explicitly warns that `WatchPaths` is highly discouraged because filesystem-event monitoring is race-prone, can miss modifications, and may launch a job before the file is in a consistent state; by contrast, `QueueDirectories` expresses the much healthier predicate “keep this job alive while work remains in this directory.” Windows Service Trigger Events pushes the same direction from another lineage: a service can start or stop on typed trigger events instead of boot-time overreach or active polling, and the SCM can queue trigger delivery until the service is ready to accept trigger events again. Steward should steal the tiny discipline: keep activation causes manager-owned and typed, treat raw path-watch activation as degraded/local-only evidence at best, and prefer durable predicates such as first request, queue nonempty, socket demand, device availability, or reviewed schedule over lossy file-change folklore.
References: REF-LAUNCHD-SOCKETS, REF-WINDOWS-SERVICE-TRIGGER-EVENTS.

## Fresh lesson from the spawned-versus-ready checkpoint pass
s6's current supervision docs are wonderfully blunt about checkpoint honesty. `s6-supervise` emits one event when `./run` is successfully spawned (`'u'`), a different event when readiness notification arrives (`'U'`), another when the run process dies (`'d'`), and yet another after `./finish` completes (`'D'`); `./finish` itself receives exact exit/signal information and can even request permanent failure-to-start handling by exiting 125. OpenRC's service-script guide reinforces the same anti-folklore temperament in a different way: it keeps hard dependency, soft dependency, startup ordering, and service-type provision distinct instead of letting one vague `restart` or `depends on` relation swallow them all. Steward should keep copying that honesty. Spawned, control-ready, serve-ready, run-died, cleanup-finished, and permanent-start-failure are different lifecycle truths, and helper ordering should stay explicit rather than disappearing into one flattering `started` badge.
References: REF-S6-SUPERVISE, REF-OPENRC-SERVICE-SCRIPT-GUIDE.

## Fresh lesson from queued-trigger reentry and component-local declaration
Windows Service Trigger Events makes one subtle lifecycle lesson explicit: if a new trigger arrives while a service is stopping, the manager can queue that trigger and replay it against a **fresh** later start instead of smuggling the work into a half-dead instance. Android init reinforces the neighboring packaging lesson from a very different lineage: service declarations should live next to the binaries/modules they govern, and versioned module-local init fragments are healthier than one monolithic lifecycle file. Steward should steal both ideas. A trigger that lands during drain/stop should become exact `queued for next cycle` truth, and lifecycle declarations should stay component-local and reviewable instead of dissolving into one host-global folklore file.
References: REF-WINDOWS-SERVICE-TRIGGER-EVENTS, REF-ANDROID-INIT-README.

## Fresh lesson from the live-verb-admission and honest-pending-progress pass
Windows service docs make an underappreciated lifecycle point painfully explicit: **liveness is not the same as mutability, and pending progress should not be faked**. A service tells the SCM which control requests it currently accepts, should not register to accept ordinary controls while start is still pending, and should advance checkpoint / wait-hint only when real work has actually moved forward. The state-transition rules sharpen the neighboring lesson: once a service reports `STOP_PENDING`, the SCM stops sending further controls and the only valid next state is `STOPPED`. Steward should steal the whole tiny discipline. Current live verbs should be explicit state-scoped truth, pending checkpoints should renew only on actual forward movement, and stopping should narrow admitted mutation instead of pretending every control is still live just because the process has not exited yet.
References: REF-WINDOWS-SERVICE-STATE-TRANSITIONS, REF-WINDOWS-SERVICE-STATUS, REF-WINDOWS-SETSERVICESTATUS.


## Fresh lesson from the durable-activation-intent pass
systemd, Oracle SMF, and the Windows SCM all reinforce the same design lesson from different lineages: **durable activation policy is not the same thing as current runtime state**. `systemctl` keeps enablement state separate from the current `Loaded`/`Active` runtime view and makes `mask` stronger than `disable`; Oracle SMF keeps `disabled`, `offline`, and `online` distinct; and Windows service creation plus delayed auto-start keeps `manual`, `automatic`, `delayed automatic`, and `disabled` as durable start-policy choices. Steward should steal that narrow seam directly: future automatic admission, manual-start allowance, and current runtime truth should stay visibly separate instead of collapsing into one ambient `service is on` myth.
References: REF-SYSTEMCTL, REF-SMF-SERVICE-STATES, REF-WINDOWS-CREATESERVICE, REF-WINDOWS-DELAYED-AUTO-START.


## 27. Durable activation policy, temporary overrides, and live control admission are different truths
systemd's runtime masking and per-unit refusal properties, SMF's layered service properties plus temporary disable paths, and Windows' accepted-control/status discipline all point the same way: baseline policy, short-lived overrides, and current accepted verbs answer different questions. Steward should preserve that distinction instead of teaching users that one `enabled` bit or one `disabled` badge explains everything.
References: REF-SYSTEMCTL, REF-SYSTEMD-DBUS-API, REF-SMF-LAYERS, REF-SVC-STARTD, REF-WINDOWS-SERVICE-STATUS.

## Fresh lesson from the start-gate pass
systemd's condition and assertion split is a good warning against flattening every unstarted unit into one generic failure story. Unmet `Condition*=` checks leave the unit in a clean skipped state, while unmet `Assert*=` checks fail the start job; `ExecCondition=` adds a similarly useful nuance by skipping the remaining start path without marking the unit failed for exit codes `1..254`, but treating `255` or abnormal exit as failure. Kubernetes' `startupProbe` points at the same seam from a different direction: startup may need a protected interval where later liveness/readiness judgment simply should not run yet. Steward should steal the lesson that **cleanly not-started, startup-shielded, and actually failed are different truths**.

## Fresh lesson from the exit-disposition pass
systemd's `SuccessExitStatus=` / `RestartPreventExitStatus=` / `RestartForceExitStatus=`, launchd's `KeepAlive.SuccessfulExit` and `Crashed` switches, Kubernetes Job `podFailurePolicy` actions, Windows SCM failure actions, and OTP's `permanent` / `transient` / `temporary` child semantics all point at the same lesson: **how a run ended is different from what policy should do next**. Steward should preserve that split directly. `clean stop`, `clean complete`, `retry`, `ignore for budget`, `fail work unit`, and `won't auto-retry` answer different questions and should not collapse into one crash-loop myth.
References: REF-SYSTEMD-SERVICE, REF-LAUNCHD-SOCKETS, REF-K8S-JOBS, REF-K8S-POD-FAILURE-POLICY, REF-WINDOWS-SERVICE-FAILURE-ACTIONS, REF-ERLANG-OTP-SUPERVISOR.





## Fresh lesson from the activation-fanout pass
Older superserver docs and newer socket activation docs keep rediscovering the same design seam: **one activation surface does not imply one worker topology**. systemd's `Accept=` split makes the tradeoff explicit: `Accept=no` wakes one shared service for all connections, while `Accept=yes` spawns one service instance per connection and is often preferable for sporadic use or stronger isolation. launchd's `inetdCompatibility.Wait` flag and classic `inetd` `wait/nowait` make the same distinction from another lineage: the listening socket may be handed through, or the manager may accept first and hand over only the accepted connection. Steward should steal the small discipline, not the host grammar: keep `shared worker`, `per-demand instance`, and `accepted-demand handoff` visibly separate from endpoint armedness, serve-state, and runtime-cycle receipts.
References: REF-SYSTEMD-SOCKET-ACTIVATION, REF-LAUNCHD-SOCKETS, REF-OPENBSD-INETD.

## Fresh lesson from the armed-endpoint pass
Current activation docs keep rediscovering a simple but easily lost truth: **an on-demand public endpoint can stay alive even when the worker is not**. systemd's socket units keep the socket under manager control, start services on incoming traffic, and even let services live in a different network namespace while receiving only the activation sockets. Launchd sharpens the same lesson from another lineage: the `Sockets` dictionary defines launch-on-demand sockets, the job later checks in via `launch_activate_socket(3)`, and Apple explicitly recommends solving inter-service coordination through IPC instead of a dependency graph. Steward should steal the smaller discipline, not the whole host API: a manager-owned activation surface may be `armed` while no leaf is running, and that truth should stay visibly separate from current serving, current runtime identity, and activation-cause receipts.
References: REF-SYSTEMD-SOCKET-ACTIVATION, REF-SYSTEMD-SERVICE, REF-LAUNCHD-SOCKETS, REF-LAUNCH-ACTIVATE-SOCKET.

## Fresh lesson from the in-place-reconfigure pass
Current primary docs sharpen a lifecycle lesson that old Unix folklore repeatedly smudged: **reload/refresh is not restart, and support for it should be explicit and acknowledged**. systemd.service warns that bare signal-driven reload is asynchronous and not a good choice for ordered reloads, recommending `Type=notify-reload` or an `ExecReload=` command that waits for completion. Oracle SMF is equally clear from another lineage: `svcadm restart` does **not** refresh configuration, while `svcadm refresh` commits configuration into the running snapshot and runs the refresh method when appropriate. Windows SCM adds the same lesson with explicit verb admission: a service may advertise `SERVICE_ACCEPT_PARAMCHANGE`, meaning it can reread startup parameters without being stopped and restarted. Steward should steal the tiny discipline, not the empire: keep `can reconfigure`, `reconfigure admitted now`, `reconfigure in progress`, `reconfigure applied`, `reconfigure failed`, and `restart required` visibly separate from ordinary restart or config-edit truth.
References: REF-SYSTEMD-SERVICE, REF-SYSTEMD1-DBUS, REF-SMF-REFRESH, REF-SMF-RESTART, REF-WINDOWS-CONTROLSERVICE, REF-WINDOWS-SERVICE-STATUS.


## Fresh lesson from the stop-escalation and cleanup-scope pass
systemd's kill policy, launchd's default process-group cleanup, Windows Job Objects, and Android init's shutdown-critical handling all point at the same uncomfortable but necessary lesson: **how stop was actually carried out is different from both stop intent and end cause**. A service may receive a polite stop request, enter bounded grace, get force-cut through later, or deliberately allow descendants to escape the supervisor's cleanup scope. Steward should keep those truths separate. `stop requested`, `grace active`, `force cut-through`, `group cleared`, and `escape allowed` are much healthier than one flattering `stopped cleanly` myth.
References: REF-SYSTEMD-KILL, REF-LAUNCHD-SOCKETS, REF-WINDOWS-JOB-OBJECTS, REF-WINDOWS-TERMINATE-JOB-OBJECT, REF-ANDROID-INIT-README.

## Fresh lesson from the failure-latch pass
systemd's `CollectMode=` and `reset-failed` behavior, `systemd-run --collect`, Solaris SMF's maintenance-and-clear flow, and Windows SCM's explicit failure-count reset period all point at the same smaller lesson: **remembered failure is its own lifecycle truth**. A service can be fully stopped and still have failed state latched, or a manager may deliberately age out / collect that memory after a quiet window. Steward should steal that seam directly: keep `failed (latched)` or `maintenance (latched)` separate from current liveness, restart-budget pressure, and one-cycle termination cause, while keeping clear/forget semantics explicit and smaller than a giant incident-retention family.
References: REF-SYSTEMD-UNIT, REF-SYSTEMD-RUN, REF-SYSTEMCTL, REF-SMF-MAINTENANCE, REF-WINDOWS-SERVICE-FAILURE-ACTIONS.

## Fresh lesson from the control-operation-result pass
systemd and Solaris SMF both make an underappreciated lifecycle distinction explicit: **a manager-mediated operation request is not the same thing as the unit's steady state**. systemd's queued job model can report `done`, `canceled`, `timeout`, `dependency`, or `skipped`, and `JobTimeoutSec=` explicitly times out the *job waiting for state change* without necessarily changing the unit state or moving the unit into `failed`. Oracle's `svcadm` similarly distinguishes successful completion, impossible-without-admin intervention because of dependency trouble, and plain wait timeout while watching a service reach the desired state. Windows service docs reinforce the same discipline from another lineage: pending-state checkpoints and wait hints are about progress of the current control operation, not blanket proof that the service state already changed. Steward should steal the small lesson directly. `start queued`, `start skipped`, `restart timed out waiting`, `stop dependency-blocked`, and `refresh done` are exact operation truths, and they should stay separate from current liveness, remembered failure, or the last runtime cycle's end cause.
References: REF-SYSTEMD-UNIT, REF-SYSTEMD1-DBUS, REF-SVCADM, REF-WINDOWS-SERVICE-STATUS.



## Fresh lesson from the operation-arbitration pass
Current primary docs sharpen a lifecycle lesson that old host folklore often leaves implicit: **when lifecycle requests overlap, the manager needs an explicit arbitration story**. systemctl's `--job-mode=` does not hide this — it can `fail`, `replace`, `replace-irreversibly`, `flush`, or choose other exact handling for conflicts with already queued jobs, and `replace-irreversibly` prevents later conflicting transactions from replacing the pending work. Windows' SCM is just as blunt from another lineage: `ControlServiceEx` only sends controls when the service both accepts them and is in a state where they may be sent, and the SCM processes service-control notifications serially; `StartServiceW` likewise returns a new service in `SERVICE_START_PENDING` with controls accepted set to none, and notes that service-control handling is serialized and can time out while another service is busy in a control handler. Solaris SMF adds the operational caution that if multiple FMRIs on one command line may affect each other, no ordering assumptions should be made and separate command lines should be used to enforce ordering. Steward should steal the tiny discipline, not the whole transaction engine: keep exact arbitration receipts such as `queued behind current stop`, `replaced pending start`, `flushed conflicting queue`, `irreversible floor`, or `cannot accept control`, and keep those truths separate from steady component state or the final outcome of the surviving operation.
References: REF-SYSTEMCTL, REF-SYSTEMD1-DBUS, REF-WINDOWS-CONTROLSERVICEEX, REF-WINDOWS-STARTSERVICE, REF-SVCADM.

## Fresh lesson from the shutdown-horizon pass
Kubernetes EndpointSlices, Pod termination flow, systemd stop-timeout extension, HAProxy drain/maint state, and Windows preshutdown handling all sharpen the same design lesson: **terminating with a bounded horizon is different from both `stopped` and ordinary `serving`**. Kubernetes keeps `terminating` separate from `serving` and `ready`, HAProxy keeps `drain` separate from `maint`, systemd allows explicit stop-time extension within bounded rules, and Windows preshutdown handling blocks later shutdown work only until a specific timeout expires. Steward should steal the small discipline, not the empire: preserve `terminating`, optional graceful deadline, optional horizon extension, and later `forced after deadline` truth without inventing a giant drain-orchestration family.
References: REF-K8S-ENDPOINTSLICES, REF-K8S-POD-LIFECYCLE, REF-HAPROXY-MANAGEMENT, REF-SYSTEMD-SERVICE, REF-WINDOWS-SERVICE-CONTROL-HANDLER, REF-WINDOWS-SERVICE-PRESHUTDOWN-INFO.

## Fresh lesson from the scoped-observation and compact-service-truth pass
Fuchsia's routed event streams and Kubernetes watch semantics sharpen the same lifecycle lesson from two different ecosystems: **observation should be scoped, resumable when possible, and honest when continuity is lost**. Fuchsia allows event streams to be downscoped to a child or subtree instead of forcing one global firehose, while Kubernetes watch supports bookmark-style progress and explicit resync from a later `resourceVersion` when the client can still resume. Kubernetes EndpointSlices sharpen the neighboring truth boundary: `ready`, `serving`, and `terminating` are different facts, and a component can be simultaneously serving and on the way out. Steward should steal the tiny discipline, not the whole substrate: keep observation views ownership-scoped, let them carry opaque currentness/bookmark markers, and keep `ready`, `serving`, `serving+terminating`, and `not serving` visibly separate from one another.
References: REF-FUCHSIA-EVENT-STREAM, REF-K8S-API-CONCEPTS, REF-K8S-ENDPOINTSLICES.

## Fresh lesson from the consumable-fresh-intent and advisory-pushback pass
The HTML user-activation model, gRPC retry semantics, and Windows / SMF service-state docs all point at the same small but valuable design rule: **some powers should be fresh and consumable, and some refusal paths should advise rather than silently stonewall**. HTML distinguishes sticky activation from transient activation and activation-consuming APIs; gRPC lets a server say "retry later" or "do not retry" with explicit pushback; Windows SCM and Solaris SMF both keep pending / maintenance / repair-needed truth explicit instead of laundering everything into generic unavailability. Steward should steal the seam selectively: let some higher-risk lifecycle or focus-affecting actions require fresh intent that can become `consumed`, and let denial / cooldown paths optionally carry exact earliest-follow-up hints without becoming a durable permission object or giant retry-policy language.
References: REF-HTML-USER-ACTIVATION, REF-GRPC-RETRY, REF-WINDOWS-SERVICE-STATUS, REF-SMF-MAINTENANCE.

## Fresh lesson from the bootstrap-watch pass
Kubernetes' current API concepts sharpen a deceptively important observation lesson: **the safest live view is often `current state, then a synced-through marker, then later changes`**. `sendInitialEvents=true` allows the API server to begin a watch with synthetic `ADDED` events for current objects and then emit a `BOOKMARK` marking the resource version through which the client is synced before ordinary later watch traffic continues. Steward should steal the discipline without importing the whole Kubernetes substrate: a scoped observation stream may sometimes want one bootstrap phase, one exact currentness marker, and only then ordinary incremental change notices. That is a healthier contract than forcing every client to race a separate list against a later watch attach or to infer currentness from silence.
References: REF-K8S-API-CONCEPTS.

## Fresh lesson from the scoped-currentness pass
Kubernetes' watch docs and etcd's watch-progress notes sharpen the same observational humility from two different directions: **a currentness marker only proves the exact thing that produced it**. Kubernetes can begin a watch with synthetic current-state entries and then emit a `BOOKMARK` showing the resource version through which that exact watch is synced; etcd's progress notifications are useful precisely because they say how far a watcher has advanced compared with stronger reads, and the docs explicitly warn that a partitioned local node may report a lower revision than a quorum read elsewhere. Steward should steal the discipline, not the distributed database worldview: `current through X` should stay scoped to one exact stream or view, and the UI should be free to say when that currentness is weaker than a stronger read class.
References: REF-K8S-API-CONCEPTS, REF-ETCD-LEASES.

## Fresh lesson from the transaction-counted-activity pass
Apple's XPC runtime and launchd's transaction / Pressured Exit docs make a beautiful anti-folklore point: **busy is not a vibe; it can be a counted, bounded claim, and reclaim pressure can be explicit**. Activity can be tied to the lifetime of an inbound message or outstanding reply, services can extend that with explicit transaction begin/end calls, and when the system needs the service to get out of the way it can emit a termination-imminent event that means “unwind quickly and do not begin new work”. Steward should steal that compact shape directly. A component may have attributable work in flight, may be asked to stop admitting fresh work, and may still owe a bounded drain before cut-through — all without pretending that any busy hint grants indefinite survival.
References: REF-XPC-TRANSACTION-BEGIN, REF-LAUNCHD-SOCKETS.

## Fresh lesson from bookmarkable-but-not-linearizable currentness
Kubernetes and etcd sharpen the same observation lesson in a way older service folklore usually misses. Kubernetes can bootstrap a watch with synthetic current-state events and then a `BOOKMARK` that is synced at least to a consistent read or requested resource version. etcd, by contrast, is refreshingly honest that watch progress notifications are bookmarkable and resumable but **not linearizable**, and that a progress revision may come from the local node and lag a quorum read if that node is partitioned. Steward should steal the humility, not the machinery: `current through cursor X` is useful truth, but it should carry a tiny class describing whether that claim is merely stream-local, backed by a stronger read/bootstrap path, barrier-confirmed, or now degraded.
References: REF-K8S-API-CONCEPTS, REF-ETCD-LEASES, REF-ETCD-API-GUARANTEES.

## Fresh lesson from narrow helper lifecycles
Nomad's lifecycle hooks keep a valuable boundary crisp: one-shot init helpers, long-lived companion sidecars, and cleanup-after-main work are different lifecycle roles, and shutdown order should respect that difference. Steward should keep copying the same restraint. Helper roles can be useful, but they should stay tiny, explicit, and attributable rather than expanding into a giant universal sidecar ontology or hidden dependency planner.
References: REF-NOMAD-LIFECYCLE.

## Fresh lesson from the trigger-bootstrap pass
Windows' current device-triggered service guidance sharpens a subtle but important activation lesson: **a trigger edge can wake a service without being enough to prove present-tense condition truth**. Microsoft explicitly warns that when a service is starting, the arrival notification may already have passed, so the service must also enumerate current device interfaces; it also warns that a device can appear between registration and enumeration, which means bootstrap state and later callbacks may legitimately duplicate each other. Steward should steal the humility, not the platform-specific API: a typed trigger cause may explain why this cycle woke up, but the cycle may still need one exact bootstrap reconciliation of current condition, and duplicate bootstrap-versus-live evidence should be treated as ordinary rather than suspicious.
References: REF-WINDOWS-SERVICE-DEVICE-INTERACTION, REF-WINDOWS-SERVICE-TRIGGER-EVENTS, REF-K8S-API-CONCEPTS.



## Fresh lesson from the bootstrap-reconciliation pass
Windows' current trigger-start guidance and Kubernetes' streaming-list watch shape strengthen the same small but important lesson: **waking because of an edge is not the same as reconciling present-tense condition truth**. Microsoft explicitly warns that a trigger-started service may miss the original arrival notification and therefore must enumerate current interfaces at startup, and Kubernetes now makes bootstrap-plus-bookmark watch streams a first-class shape for `current state, then synced-through marker, then later changes`. Steward should steal the humility rather than the platform APIs: one runtime cycle may start because of a request or trigger and still need one exact bootstrap reconciliation step before it can honestly claim the condition it woke for is current now.

## Fresh lesson from the activation-material and component-runner pass
systemd credentials, Fuchsia's runner API, launchd, and Android init all point to the same lesson from different eras: **startup material should be selected, named, delivered, and receipted by the manager, not inherited as ambient folklore**. systemd's service credentials make activation-time acquisition and deactivation release explicit; Fuchsia's `ComponentStartInfo` names namespace entries, runtime directories, outgoing directories, handles, and configuration; launchd and Android init show older versions of manager-owned sockets, files, capabilities, and module-local declarations. Steward should steal the small discipline — named activation material, scoped delivery, deactivation cleanup, and exact receipts — while postponing a universal activation-capsule filesystem or runner grammar until real components force it.
References: REF-SYSTEMD-CREDENTIALS, REF-FUCHSIA-COMPONENT-RUNNER, REF-LAUNCHD-JOBS, REF-LAUNCHD-SOCKETS, REF-ANDROID-INIT-README.

## Fresh lesson from the termination-status and stop-progress pass
Windows SCM progress rules, Fuchsia `ComponentController`, and systemd `sd_notify` all reinforce one uncomfortable lifecycle truth: **pending stop is an operation with evidence, not a flattering state label**. A service should not report `stopped` before all its threads and controlled work have actually exited; Fuchsia keeps `Stop`, possible `Kill`, and `OnStop` termination status distinct from mere channel closure; `sd_notify` has separate `STOPPING`, `STATUS`, timeout-extension, and barrier patterns. Steward should steal exact stop-progress receipts, bounded escalation truth, and termination status, but not freeze a giant workflow engine. The minimal seam is enough: `stop requested`, `still stopping with checkpoint`, `kill escalated`, `termination status observed`, and `cleanup finished` are different from `ready`, `live`, or `failed`.
References: REF-WINDOWS-MULTITHREADED-SERVICES, REF-WINDOWS-SERVICE-STATUS, REF-FUCHSIA-COMPONENT-RUNNER, REF-SD-NOTIFY.

## Fresh lesson from the bind-cause and present-condition pass
Fuchsia starts components most commonly when another component binds to an exposed capability; Windows triggers start or stop services when a typed condition is true or becomes true; Android explicitly distinguishes event triggers from property-currentness checks; Kubernetes keeps startup, readiness, and liveness probes as different questions. The shared lesson is that **why this cycle woke up is not the same fact as what is currently true**. Steward should preserve exact activation causes such as bind, socket demand, queue nonempty, trigger event, or reviewed manual start, but require a separate currentness/reconciliation path before claiming that a dependency, condition, listener, or work queue is still present.
References: REF-FUCHSIA-LIFECYCLE, REF-WINDOWS-SERVICE-TRIGGER-EVENTS, REF-ANDROID-INIT-README, REF-K8S-PROBES.

## Fresh lesson from the wake-memory and helper-hook pass
Wake references, lifecycle hooks, and durable histories all teach one uncomfortable rule: **future-wake evidence is not current execution truth**. Durable Object stubs and lifecycle states show that an addressable object can be inactive or hibernated while preserving stronger identity/storage facts than an ordinary stopped process. Dapr's actor split between timers and reminders shows why active callbacks and durable wake records should not share one name. Kubernetes and OCI hook docs show that lifecycle hooks can be racy, namespace-sensitive, warning-only, grace-budget-consuming, and at-least-once rather than exactly-once. Lambda Extensions show that adjunct processes can participate in lifecycle events and shutdown without becoming the main supervised leaf. Temporal shows the opposite cliff: durable event history is powerful enough that adopting it casually would turn Steward into a workflow engine.

The lesson to keep is small: name wake memory and helper receipts; keep them weaker than running, readiness, serving, or currentness; and keep the source of delivery guarantees visible.
References: REF-CLOUDFLARE-DURABLE-OBJECT-LIFECYCLE, REF-CLOUDFLARE-DURABLE-OBJECT-ALARMS, REF-DAPR-ACTOR-TIMERS-REMINDERS, REF-DAPR-ACTOR-RUNTIME-FEATURES, REF-K8S-CONTAINER-LIFECYCLE-HOOKS, REF-OCI-RUNTIME-LIFECYCLE, REF-OCI-RUNTIME-CONFIG-HOOKS, REF-AWS-LAMBDA-EXTENSIONS-API, REF-AWS-LAMBDA-RUNTIME-LIFECYCLE, REF-TEMPORAL-WORKFLOWS, REF-TEMPORAL-EVENT-HISTORY.

## Fresh lesson from the activation-demand episode pass
Cold-start systems teach one uncomfortable lifecycle lesson: **accepting demand is not the same as serving demand**. Knative's activator can sit in the data path, buffer traffic for scale-from-zero, and forward once capacity appears. Cloud Run draws hard startup and per-request timeout boundaries, and still treats listening/health/request delivery as separate facts. Service Workers and extension workers show an event-dispatch shape where work can extend lifetime only while a promise/event is active, while browser policy still owns termination. Android and Apple background APIs add another caution: background and exact-wake work is quota-, permission-, and expiration-bounded, not ambient generosity. Automount reminds us that even old on-demand activation can be triggered by ordinary access before the target object is truly mounted or served.

The Steward lesson is narrow: name the per-demand episode and its fate. `accepted`, `buffered`, `waking`, `delivered`, `accepted-by-runtime`, `completed`, `canceled`, `timed-out`, and `shed` should not be inferred from readiness or smeared into component health. The brilliant theft is the event-lifetime receipt: let one demand hold one bounded activation/work budget, but make expiry, cancellation, and loss visible.
References: REF-KNATIVE-SERVING-ARCHITECTURE, REF-KNATIVE-SERVING-REQUEST-FLOW, REF-KNATIVE-SCALE-TO-ZERO, REF-CLOUD-RUN-CONTAINER-CONTRACT, REF-CLOUD-RUN-REQUEST-TIMEOUT, REF-MDN-EXTENDABLEEVENT-WAITUNTIL, REF-W3C-SERVICE-WORKERS, REF-CHROME-EXTENSION-SW-LIFECYCLE, REF-ANDROID-WORKMANAGER-TASK-SCHEDULING, REF-ANDROID-EXACT-ALARMS, REF-APPLE-BACKGROUNDTASKS, REF-APPLE-BGTASK-EXPIRATION-HANDLER, REF-SYSTEMD-AUTOMOUNT.


## Fresh lesson from the activation-admission pass
Kubernetes admission, Lambda throttling, Cloud Run pending/max-instance behavior, Android background-start restrictions, and SlopOS ACP denial/acceptance discipline all point at the same smaller lesson: **admission is boundary truth, not service truth**. An attempt may be allowed, rejected, delayed, narrowed, throttled, or shed before any runtime exists, before readiness is known, and before a request is delivered or completed. Steward should steal the explanation seam directly while refusing to turn it into a portable policy engine, quota wallet, admission webhook framework, autoscaler, or durable queue.
References: REF-K8S-ADMISSION-CONTROLLERS, REF-K8S-DYNAMIC-ADMISSION, REF-AWS-LAMBDA-CONCURRENCY, REF-AWS-LAMBDA-METRICS, REF-CLOUD-RUN-AUTOSCALING, REF-CLOUD-RUN-MAX-INSTANCES, REF-ANDROID-FGS-BACKGROUND-STARTS, REF-ANDROID-BACKGROUND-ACTIVITY-STARTS.
## Fresh lesson from the activation-custody pass
The oldest lifecycle lie is that a thing was "handled" when it was merely handed somewhere. SQS visibility timeout makes the split painfully clear: delivery creates an in-flight lease, but deletion/ack is the completion signal, expiry makes redelivery possible, and duplicate delivery can still happen. Service-worker and Worker runtimes sharpen the event side: lifetime extension is bounded and can be too late, canceled, or explicitly not durable. systemd fdstore teaches the descriptor side: a manager-held duplicate can keep a resource pinned after the service closes its copy unless removal is explicit. Kubernetes EndpointSlices show the serving/drain side: an endpoint may be terminating and still serving under constrained routing. Steward should steal the tiny discipline, not the substrates: every activation handoff that matters should be able to say current holder, handoff strength, expiry, cancellation state, redelivery/duplicate risk, and unknown holder without pretending work completed.
References: REF-AWS-SQS-VISIBILITY-TIMEOUT, REF-CLOUDFLARE-WORKERS-CONTEXT, REF-W3C-SERVICE-WORKERS, REF-SYSTEMD-FDSTORE, REF-K8S-ENDPOINTSLICES, REF-GO-CANCEL-OPERATIONS.

## Fresh lesson from the activation-work disposition pass
HTTP 202 and Kubernetes finalizers both warn that “accepted” can mean work is only pending, cleanup is still outstanding, or another status path must be consulted. Android service restart modes warn that restart, restart-without-redelivery, and restart-with-redelivery are different promises. RabbitMQ, Pub/Sub, SQS, Lambda, and Kafka all teach the same older lesson in different forms: acknowledgement, commit position, redelivery, duplicate risk, dead-letter, discard, and side-effect completion are separate facts. Steward should steal those small distinctions, not a queue, redrive service, workflow engine, or exactly-once plane.

References: REF-HTTP-RFC9110, REF-K8S-FINALIZERS, REF-ANDROID-SERVICES, REF-RABBITMQ-ACKS-CONFIRMS, REF-RABBITMQ-CHANNELS, REF-GCP-PUBSUB-BASICS, REF-GCP-PUBSUB-EXACTLY-ONCE, REF-AWS-SQS-DEAD-LETTER-QUEUES, REF-AWS-LAMBDA-ASYNC-ERROR-HANDLING, REF-KAFKA-DESIGN.

## Fresh lesson from the activation-effect boundary pass
Retry and recovery systems teach a subtler lesson than “make it idempotent”: **work fate is not effect fate**. AWS's idempotent-API guidance and Stripe's idempotency keys show that caller-chosen intent keys, parameter mismatch checks, semantic-equivalent responses, and bounded retention are practical tools, but they still need explicit boundary records. Transactional outbox patterns show that a local commit plus outbox row is a useful dual-write floor, not proof that an external subscriber applied the effect. RabbitMQ's distinction between publisher confirms and consumer acknowledgements is the same warning in broker form. Pub/Sub's exactly-once delivery claims are scoped to acknowledgement behavior, not arbitrary external side effects. Azure's compensating-transaction guidance is even blunter: compensation is application-specific, may need progress tracking and manual intervention, and some effects cross irreversible floors.

Steward should steal the narrow evidence seam: a work item can say `no effect begun`, `local commit`, `outbox recorded`, `external submit`, `external accepted`, `external confirmed`, `duplicate suppressed`, `mismatch`, `compensation needed`, `irreversible floor`, or `unknown effect` without importing a saga engine, global idempotency ledger, transaction coordinator, or exactly-once side-effect plane.
References: REF-AWS-BUILDERS-IDEMPOTENT-APIS, REF-STRIPE-IDEMPOTENT-REQUESTS, REF-AWS-TRANSACTIONAL-OUTBOX, REF-DEBEZIUM-OUTBOX-EVENT-ROUTER, REF-RABBITMQ-ACKS-CONFIRMS, REF-GCP-PUBSUB-EXACTLY-ONCE, REF-AZURE-COMPENSATING-TRANSACTION.

## Fresh lesson from the activation-incarnation lineage pass
Stable service names are operationally convenient and dangerously sticky. The old Unix failure is not just PID reuse; it is assuming that a name, socket path, allocation label, or unit object still means the same living actor after restart, hot restart, reschedule, restore, or takeover. systemd's invocation ID, Kubernetes UIDs, Envoy hot-restart epochs, Raft terms, ZooKeeper sequential ephemeral leadership, etcd revision guards, and SlopOS's own generation-witness instincts all point to the same small rule: **currentness belongs to a concrete incarnation lineage, not to the recycled label**.

The lesson for Steward is to keep the successor/predecessor relation visible. A new incarnation may be preparing while the old one drains; a replacement may reuse the same name; an in-place restart may preserve a larger object while replacing leaves; a restored clone may carry old local state into a new world. None of those facts proves that old work completed, old side effects did not happen, or stale actions should retarget automatically. The portable seam should be one small incarnation-lineage witness, plus expected-incarnation fences for high-risk actions, not a rollout controller or leader-election plane.


## Fresh lesson from the activation-residency pass
The old failure is treating "somewhere" as "serving". Schedulers, warm pools, serverless platforms, and checkpoint systems all have useful intermediate states: desired placement, nominated placement, bound allocation, warm idle, frozen, restored, evicting, lost, or last-known. Each is useful evidence, but each lies if it is allowed to imply readiness, custody, completion, or safe retry. Steward should steal the vocabulary of placement and warm/restore evidence while refusing the ambient inference that a thing being resident, warm, or restored means the work is current or safe.

Checkpoint and warm-start designs add a second trap: restored memory feels like continuity, but the outside world kept moving. Credentials, connections, leases, clocks, entropy, topology, files, and peers may all need explicit after-restore checks. Steward should prefer a tiny residency witness that can say `restored-from-template` or `after-restore-check-pending` over a magical resume story.

## Fresh lesson from the activation-state attachment pass
The old failure is pretending that bytes nearby mean the service is safe. A scratch directory may survive one container crash but vanish on pod removal. A tmp area may be unique to one execution environment and vanish when that instance goes away. A projected token or certificate may refresh under a mount, but a subpath mount or split read can leave the application stale or mismatched. A sticky disk may be best-effort and suitable only for recreatable data. A persistent volume may outlive the run but still need replay, schema, stale-owner, or lease checks before reuse.

The lesson for Steward is to treat attached state as one more witness, not a storage contract. `attached`, `projected`, `persistent-known`, `migration-complete`, `snapshot-derived`, `cleanup-failed`, and `detached` should explain local lifecycle facts while refusing to imply readiness, serving, current incarnation, work disposition, side-effect success, or ambient path authority.


## Fresh lesson from the activation-material freshness pass
Activation systems keep rediscovering the same trap: **material being present is not the same thing as material being fresh or currently used**. systemd credentials are deliberately activation-scoped and immutable during a service run. Kubernetes projected tokens include audience and expiry, while Secret and ConfigMap volumes update eventually and subPath consumers miss automatic updates. Cloud Run makes a sharp split between secret volumes that read the latest value and environment variables resolved at instance startup. ECS warns that rotated secrets injected into env vars do not update a running container. Vault makes dynamic secrets lease-bound, renewable, and revocable. SPIFFE streams complete current SVID/bundle sets and says redacted identities should stop being used. Lambda SnapStart and SlopOS's own snapshot discipline both warn that uniqueness-sensitive or temporary credential material must be reacquired after restore.

Steward should steal the shape, not the provider stacks: version/epoch/audience/expiry/renewal/revocation/reload/reacquire chips are enough for now. Do not turn the lifecycle fabric into a vault, config bus, identity provider, or rollout controller just because material freshness needs a witness.
References: REF-SYSTEMD-CREDENTIALS, REF-K8S-PROJECTED-VOLUMES, REF-K8S-SECRETS, REF-K8S-CONFIGMAPS, REF-CLOUD-RUN-SECRETS, REF-AWS-ECS-SECRETS-ENVVAR, REF-VAULT-LEASES, REF-SPIFFE-WORKLOAD-API, REF-AWS-LAMBDA-SNAPSTART.

## Activation-probe vantage pass

The recurring failure mode is not that probes exist; it is that a probe result becomes a universal adjective. Kubernetes is valuable because startup, readiness, and liveness probes have different consequences, and EndpointSlices further split `ready`, `serving`, and `terminating`. gRPC is valuable because health can be service-specific and watched by clients. Envoy is valuable because active checks, cached pass-through answers, fast-fail drain signals, and health-check identity all show that who asked and what path was checked matter. AWS ALB is valuable because target health is thresholded, target-state-specific, and can fail open when all targets are unhealthy. Cloud Run is valuable because startup shielding, liveness restarts, readiness traffic gating, and restart-loop limiting are separate policy moves.

Lesson for Steward: a probe should become an attributable witness, not a green dot. It should say observer, target, path/service, scope, result freshness, threshold/cached state, identity basis, and failure hint. Readiness, liveness, serving, shutdown horizon, advertisement, material freshness, and policy action remain adjacent facts.

References: REF-K8S-PROBES, REF-K8S-ENDPOINTSLICES, REF-GRPC-HEALTH-CHECKING, REF-ENVOY-HEALTHCHECKING, REF-AWS-ALB-HEALTHCHECKS, REF-AWS-ALB-TARGET-HEALTH, REF-CLOUD-RUN-HEALTHCHECKS.

## Activation-control verdict pass

The recurring failure mode after probe vantage is subtler: a system observes something, then a controller decides something, and operators later talk as if those were the same fact. Kubernetes is useful here because a Deployment progress deadline can report `ProgressDeadlineExceeded` without taking rollback action, while its availability and progressing conditions carry different meanings. Pod readiness gates are useful because external controllers can contribute readiness conditions, but missing or false gates must remain legible instead of disappearing behind a boolean. Nomad, ECS, Envoy, Cloud Run, and Route 53 all show different forms of the same split: min-healthy windows, circuit-breaker thresholds, passive outlier ejection, traffic percentages, fail-open behavior, and insufficient-data defaults are policy-scoped verdicts over evidence, not universal service truth.

Lesson for Steward: keep one tiny control-verdict witness. It should name the issuer, subject, scope, basis hint, freshness, effect class, and state such as `progressing`, `gate-pending`, `eligible`, `withheld`, `ejected`, `fail-open`, `stalled`, `failed`, `rollback-started`, `manual-action-required`, or `unknown`. Do not turn that witness into a rollout controller, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, or incident manager.

References: REF-K8S-DEPLOYMENT, REF-K8S-POD-CONDITIONS, REF-NOMAD-UPDATE, REF-AWS-ECS-DEPLOYMENT-CIRCUIT-BREAKER, REF-ENVOY-OUTLIER-DETECTION, REF-CLOUD-RUN-TRAFFIC-MIGRATION, REF-ROUTE53-HEALTH-DETERMINATION.

## Fresh lesson from the activation-traffic binding pass
The old operational lie is that **traffic moved** means the same thing as **every new caller now reaches the intended safe target**. Weighted route rules, function aliases, serverless revision splits, service selectors, target groups, DNS answers, sticky sessions, topology hints, long-lived connections, and mirror routes all weaken that claim in different ways. Gateway-style weighted backends are allocation intent, not a deterministic per-request destiny. Request mirroring copies demand out-of-band while ignoring the mirror response. Cloud Run-style migrations and tags show that route changes can be gradual, targeted, and non-instant while in-flight requests continue. Lambda-style weighted aliases make low-volume variance visible. ALB and Envoy-style draining show that no-new-work and existing-work drain are different truths. Kubernetes Service and topology-aware routing show that a stable service abstraction can hide shifting endpoint and locality behavior.

The Steward lesson is small: name traffic binding as its own witness. A surface can say `desired-binding`, `observed-binding`, `active-binding`, `weighted`, `sticky`, `pinned`, `mirrored`, `shadow`, `no-new-work`, `draining-existing`, `stale-binding`, or `unknown` without claiming health, readiness, serving, admission, custody, rollback completion, or incident truth. The brilliant theft is the route-binding receipt; the thing to refuse is a full load balancer, service mesh, DNS failover system, Gateway API implementation, route compiler, canary framework, topology router, traffic simulator, or rollout controller.

References: REF-K8S-SERVICE, REF-K8S-GATEWAY-TRAFFIC-SPLITTING, REF-K8S-GATEWAY-REQUEST-MIRRORING, REF-K8S-TOPOLOGY-AWARE-ROUTING, REF-CLOUD-RUN-TRAFFIC-MIGRATION, REF-AWS-LAMBDA-WEIGHTED-ALIASES, REF-AWS-ALB-TARGET-GROUP-ATTRIBUTES, REF-ENVOY-TRAFFIC-SPLITTING, REF-ENVOY-DRAINING, REF-ISTIO-TRAFFIC-SHIFTING, REF-ISTIO-MIRRORING.

## Fresh lesson from the activation-live channel pass

Traffic binding and live-channel fate are different truths. HTTP/2 and HTTP/3 GOAWAY both show that a connection can stop accepting new streams while earlier streams may still be in progress or ambiguity remains about what was processed. gRPC graceful stop, Envoy drain, ALB deregistration delay, and Kubernetes endpoint termination all reinforce the same split: graceful usually means stop new work, let existing work finish until a deadline, then force close or reset; it does not prove readiness, serving, route authority, work completion, or effect success. See REF-RFC9113-HTTP2, REF-RFC9114-HTTP3, REF-GRPC-GRACEFUL-SHUTDOWN, REF-ENVOY-DRAINING, REF-AWS-ALB-TARGET-GROUP-ATTRIBUTES, and REF-K8S-POD-ENDPOINT-TERMINATION-FLOW.

Close and resume evidence are also weaker than they look. WebSocket close handshakes can be clean, abnormal, or disagreeing by side; NATS drain reduces timing loss by draining subscriptions and flushing before close; Kubernetes watch bookmarks and server-sent event last-event ids are useful cursors, not proof that no gap, duplicate, stale credential, or old incarnation remains. Steward should therefore steal close/reset reason chips, cursor/gap humility, and drain-layer names without importing a portable connection manager or session-resumption plane. See REF-RFC6455-WEBSOCKET, REF-NATS-DRAIN, REF-K8S-API-CONCEPTS, and REF-HTML-SERVER-SENT-EVENTS.

## Fresh lesson from the activation-retry attempt pass

Retries are not a moral good; they are a new attempt with a safety story. HTTP only lets clients lean on automatic retry because idempotent semantics constrain what repetition means, and even then non-idempotent requests need stronger knowledge or explicit review. gRPC makes the commitment boundary concrete: once response headers have been received or buffered outbound history is no longer replayable, retry semantics change. Steward should therefore name original demand, canonical intent, safety basis, commitment boundary, pushback, budget, and duplicate ambiguity instead of hiding them behind a single `retrying` badge. See REF-HTTP-RFC9110, REF-GRPC-RETRY, REF-GRPC-HEDGING, and REF-AWS-BUILDERS-IDEMPOTENT-APIS.

Retry storms are lifecycle bugs, not just networking bugs. AWS and Google SRE both emphasize backoff, jitter, retry quotas, and load-shedding humility because retries amplify overload; Envoy adds route-level retry budgets and hedging caveats. RFC 8470 adds the replay-risk version of the same lesson: early data can make fast activation look successful while replay safety is unresolved. Steward should steal retry-attempt receipts, same-key mismatch rejection, advisory pushback chips, and budget-exhausted truth, but not a retry engine, RPC framework, service mesh, broker, or exactly-once plane. See REF-AWS-BUILDERS-BACKOFF-JITTER, REF-AWS-SDK-RETRY-BEHAVIOR, REF-ENVOY-HTTP-ROUTING, REF-GOOGLE-CLOUD-STORAGE-RETRY-STRATEGY, REF-RFC6585, and REF-RFC8470-EARLY-DATA.

