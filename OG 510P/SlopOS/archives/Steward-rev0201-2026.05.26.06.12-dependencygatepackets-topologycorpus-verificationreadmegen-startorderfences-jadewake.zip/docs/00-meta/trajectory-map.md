# Trajectory map

## Current thesis

Steward should provide the **minimum coherent lifecycle fabric** for SlopOS:
- explicit component roots,
- foreground, accountable lifecycle ownership,
- supervisor-owned activation,
- explicit non-ambient launch context so reviewed entry and restart do not depend on login-shell or session folklore,
- explicit descriptor hygiene so inherited handles, stdio, and control channels do not become ambient launch truth,
- explicit tiny activation checkpoints so launch delivery, control-ready, serve-ready, and stop progression do not collapse into spawn folklore,
- explicit tiny continuity-escrow truth so preserved/redelivered continuity can stay separate from runtime-cycle identity, serving role, and takeover proof,
- explicit attributable short-lived transition helpers that stay separate from the supervised long-lived leaf,
- deterministic restart and stop semantics,
- readiness that is not guessed from spawn success,
- optional tiny readiness-generation witnesses so mid-run config/reload drift can be explained without a giant rollout algebra,
- optional tiny progress windows so start/reload work can be distinguished from stalled intermediate state without freezing a giant timeout grammar,
- explicit tiny hold-state truth so deliberate `paused`, `draining`, `frozen`, or `start-prevented` states can stay separate from `stalled`, `failed`, or ordinary `off`,
- dynamic external conditions that stay observational instead of hardening into fake boot-order facts,
- explicit but narrow activity accounting for in-flight work and drain state,
- explicit balanced activity brackets for runtimes that can honestly express begin/end work scopes,
- a small observational lifecycle/state vocabulary,
- bounded observation subscriptions that can carry snapshot-plus-change views without a hidden control bus,
- an optional tiny presence-advertisement seam so discoverable published presence can stay separate from readiness, serving truth, and runtime-cycle identity,
- an optional opaque runtime-cycle witness for correlating concrete runs without PID folklore,
- a compact end-of-cycle cause vocabulary so concrete runs can end with an explicit explanation instead of raw host trivia,
- compact status that is not log archaeology,
- explicit freshness decay so live status, busy/progress hints, and shell chrome can admit when they have become last-known rather than current,
- cooperative quiesce,
- shell/terminal integration with semantic boundaries rather than PTY folklore,
- an explicit action-surface posture so shell/terminal affordances stay target-bound and user-invoked,
- explicit precision fences so shell/terminal layers can admit capability or trust downgrade instead of preserving stale certainty,
- an explicit tiny mode-baseline and repair seam so prompt-critical shell/terminal state can be freshly reasserted instead of assumed after crashes, hops, or TUI detours,
- an explicit promotion path for selected long-running shell work that deserves first-class lifecycle accountability,
- explicit capability handshakes so richer shell/terminal semantics come from fresh observed support instead of compatibility folklore,
- explicit semantic epochs so shell/terminal markers, subscriptions, and actions can admit “that belonged to an older semantic world” after a hop or resync,
- explicit shell/terminal hop lineage so remote host, multiplexer, and preserved-semantic context stay scoped to the actual path rather than guessed from a flat PTY,
- compact confidence / provenance / trust annotations so shell/terminal observations can admit exactly how exact and rerun-safe they are,
- explicit provisional-state semantics so predictive local echo and incomplete shell metadata can stay useful without pretending tentative state is already confirmed,
- explicit attention hints so command-finished, needs-input, warning, and progress-like shell/terminal cues can stay focus-aware, freshness-scoped, and non-authoritative,
- explicit notification surfaces so OS toasts, mark-alert wakeups, and reveal actions can stay exact-anchor-bound, focus-aware, and action-bounded instead of becoming a hidden approval path,
- an explicit shell/terminal chrome lane so badges, sticky headers, tab titles, and side status cells can stay observational, freshness-scoped, and clearly separate from the canonical transcript,
- an explicit command-guide seam so visible rails, sticky headers, and prompt-local guide chrome can stay exact-frame-bound, filterable, and distinct from the durable transcript,
- an explicit transcript-landmark seam so marks, annotations, alerts, and exact jump targets can stay anchor-bound, provenance-labeled, and clearly separate from transcript truth or ambient control,
- an explicit context-inheritance seam so tabs, splits, reruns, and action-launched shells can inherit cwd or domain context per action without ambient pane folklore,
- an explicit spawn-selector seam so tabs, splits, reruns, and helper shells can choose reviewed program/profile/domain/cwd recipes instead of ambient `$SHELL`, profile, or pane folklore,
- an explicit remembered-shelf seam so recent commands, directories, and Steward objects can stay keyed to host/hop context, freshness-labeled, and clearly separate from live-state truth,
- an explicit observational session-variable seam so shell and terminal chrome, filtering, and remembered context stay scoped and useful without hardening into launch or policy truth,
- explicit target anchors so shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without rendered-text scraping or raw-capability leakage,
- explicit bounded context handoff so exact command frames, output slices, receipts, and concrete runs can be exported or attached without ambient whole-scrollback sharing,
- explicit transfer-surface semantics so uploads, downloads, remote-file actions, and drag/drop handoff stay exact, direction-labeled, and clearly separate from clipboard or prompt folklore,
- explicit media-surface semantics so inline images, plots, doc previews, and background media stay exact-targeted, budgeted, and clearly separate from transfer/open folklore,
- explicit link-surface semantics so detected text, declared hyperlinks, semantic file links, and exact object opens stay provenance-labeled, action-bounded, and clearly separate from generic open folklore,
- explicit label-surface semantics so titles, badges, right-status text, and similar chrome labels stay provenance-labeled, override-scoped, and clearly separate from transcript or policy truth,
- explicit repair-gate semantics so repeated failures can cool down, become repair-required, and stay explainable instead of hiding behind ambient restart folklore,
- explicit workspace-snapshot semantics so saved layouts, reconnected processes, revived processes, and content-only restores stay visibly distinct instead of collapsing into session folklore,
- explicit replay-gate semantics so remembered, restored, or suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore.
- explicit governance authorization witnesses so owner labels, delegation warrants, reviews, approvals, authorization checks, operation receipts, lifecycle state, and effect success stay separate.
- explicit exception witnesses so bypass-under-review, waived-under-expiry, and satisfied-gate truth can stay visibly separate from ordinary success or settled health.
- explicit headroom witnesses so allowed, approved, and ready can stay visibly separate from currently spendable restart / quota / rate-window headroom,
- explicit pressure witnesses so scoped stall / warning / critical pressure truth can stay visibly separate from serving mode, headroom, and failure,
- explicit backpressure witnesses so `queued`, `retry-after`, `shed`, and `stop-accepting` truth can stay visibly separate from pressure, headroom, and failure,
- explicit adaptation witnesses so cache trim, reduced concurrency, optional-work deferral, and other protective response truth can stay visibly separate from pressure, backpressure, and vague degraded folklore,
- explicit tiny wake-memory witnesses so future alarms, reminders, queued triggers, and inactive/hibernated continuity can explain later activation without becoming proof of current running, readiness, or a generic scheduler,
- explicit activation-admission receipts so one exact wake/start/demand attempt can be admitted, denied, deferred, narrowed, throttled, shed, or unknown before claiming any runtime, queue, readiness, serving, or completion truth,
- explicit activation-demand episodes so cold-start demand can be accepted, buffered, delivered, timed out, canceled, or shed without claiming the component is already running, ready, or serving.
- explicit activation-custody witnesses so one admitted demand, event, descriptor, or background obligation can reveal current holder, handoff strength, cancellation propagation, expiry, redelivery, duplicate risk, or holder ambiguity without becoming a broker.
- explicit activation-work disposition witnesses so admitted work can later report acknowledged, redeliverable, redelivered, expired, dead-lettered, discarded, abandoned, detached, superseded, or unknown fate without pretending admission, custody, restart, readiness, serving, or health means completion.
- explicit activation-effect boundary witnesses so retry, redelivery, and work fate stay separate from local commit, outbox record, external submit/accept/confirm, compensation, irreversible side effects, and unknown effect boundaries.
- explicit activation-incarnation lineage witnesses so stable component identity, concrete runtime cycles, replacement/successor relations, hot-restart overlap, in-place subcycles, clone/restore uncertainty, and stale-action fences stay separate from recycled names.
- explicit activation-residency witnesses so placement, nomination, binding, warm idle, frozen/snapshotted, restore-in-progress, eviction, loss, and unknown residency stay separate from identity, readiness, serving, custody, work fate, and effects.
- explicit activation-state attachment witnesses so scratch, tmp, projected material, managed runtime/state directories, sticky/migrated volumes, persistent storage, snapshot-derived bytes, detach, cleanup, and unknown attachment truth stay separate from readiness, serving, incarnation currentness, custody, work fate, and effects.
- explicit activation-material freshness witnesses so config, secrets, tokens, trust bundles, leases, projections, static injection, and restored material can explain version, epoch, audience, expiry, renewal, revocation, reload, reacquire, and unknown freshness without widening into a vault, config store, or workload-identity plane.
- explicit activation-probe vantage witnesses so startup, readiness, liveness, gRPC health, balancer target, mesh, and synthetic checks can preserve observer, scope, path/service, threshold, cache, freshness, failure hint, and identity basis without pretending one probe result is readiness, serving, currentness, or policy action.
- explicit activation-control verdict witnesses so controllers, balancers, rollout loops, DNS-health systems, deployment circuit breakers, and operator adapters can report issuer, scope, basis, freshness, effect class, and verdict state without collapsing observations, actions, route eligibility, rollback, or incident truth.
- explicit activation-traffic binding witnesses so route, alias, service, gateway, proxy, DNS, target-group, tagged-test, weighted, mirrored, sticky, draining, stale, and unknown new-demand mappings can stay separate from probes, verdicts, readiness, serving, admission, custody, and rollback truth.
- explicit activation-live channel witnesses so existing connections, streams, subscriptions, watches, WebSockets, server-sent event streams, multiplexed RPCs, and drainable clients can stay separate from route binding, readiness, serve-state, admission, custody, work fate, effects, and rollout truth.
- explicit activation-retry attempt witnesses so retries, replays, transparent retries, hedges, reconnect resends, and post-drain attempts can stay separate from route binding, live-channel fate, admission, custody, work disposition, effect success, and exactly-once folklore.
- explicit retry-settlement packets so retry advice, local retry budget observations, follow-up attempts, and hedge winner/loser fates can stay separate from reservations, grants, automatic retry authority, no-side-effect proof, work completion, and effect settlement.
- explicit closed control-operation request and receipt packets so operator/admin mutations can be stale-fenced, duplicate-suppressed, receipted, recovery-downgraded, and kept separate from component state.
- executable proof-slice discipline so central lifecycle distinctions gain deterministic corpus cases before Steward expands sideways.
- explicit adapter-membrane, manager-recovery, time/deadline, receipt-minimization, and companion-boundary posture so evidence can stay useful without strengthening into native truth.

The current architecture compression is in [`../30-architecture/design-principles-v0.md`](../30-architecture/design-principles-v0.md).
The current freeze-late refusal set is in [`../30-architecture/non-decisions-v0.md`](../30-architecture/non-decisions-v0.md).

## Open questions (tracked as decision surfaces)
- **OQ-0193 local observation adapter goldens**: which host/runtime/shell observation samples should become the first adapter-golden fixtures for ST-LOCALOBS / ST-OBSAPPRAISE / ST-OBSCURSOR / ST-OBSATTACH without creating a host inventory or telemetry bus?
- **OQ-0190 operation receipt authcheck policy**: should every mutating ST-OPRECEIPT cite ST-AUTHCHECK, or only higher-risk verbs and delegated/remote/admin surfaces?
- **OQ-0001 activation allowlist shape**: how much activation-key structure belongs in `CH-COMP v0`, and how much should stay provider-local?
- **OQ-0002 readiness vocabulary**: what is the smallest closed set of startup/control-ready/readiness/liveness states that remains useful?
- **OQ-0003 dependency planning**: does phase 1 need an offline planner layer, or only local start-order constraints?
- **OQ-0004 continuity escrow**: what kinds of handles or state can legally survive restart, and how are they allowlisted?
- **OQ-0005 quiesce evidence**: what exact transcript/receipt shape should explain “why is this component not taking new work?”
- **OQ-0006 shell/terminal side channel**: what exact semantic markers, command-frame fields, and receipts should exist between shell and terminal?
- **OQ-0007 admin surface**: what external control surface, if any, is needed before phase 1 is real?
- **OQ-0008 compat membrane**: how much host init/service-manager behavior can live behind a compat membrane without leaking into Steward semantics?
- **OQ-0009 service package shape**: does Steward benefit from a minimal service-as-directory / bundle discipline, or should packaging stay entirely outside the portable contract?
- **OQ-0010 restart-loop posture**: how much restart-budget / cooldown vocabulary is phase-1-portable, and how much should remain implementation policy?
- **OQ-0011 status channel**: what compact state/status vocabulary should components report beyond ready/not-ready without recreating a giant ad hoc logging protocol?
- **OQ-0012 idle / transaction semantics**: which kinds of components deserve explicit idle or in-flight work accounting, and how much of that belongs in Steward versus runtime-specific adapters?
- **OQ-0013 shell marker provenance**: what minimum provenance or trust model should shell/terminal semantic markers use so rerun/copy/receipt UX stays helpful without becoming spoofable authority?
- **OQ-0014 transient command seam**: when should long-running shell-launched work stay a plain command, and when should it become a first-class transient service or lease-bearing background object?
- **OQ-0015 terminal input protocol**: what minimum keyboard/paste/click reporting should the custom shell+terminal standardize so interactive UX is explicit instead of timing-hack folklore?
- **OQ-0016 resilient remote shell transport**: how much roaming/local-echo/offline tolerance belongs in the shell+terminal contract versus a host-local transport layer?
- **OQ-0017 runtime-cycle witness**: what is the smallest portable cycle-identity/fence shape that helps avoid stale actions without implying a giant process API?
- **OQ-0018 termination-cause vocabulary**: what is the smallest portable end-of-cycle cause vocabulary that remains useful without pretending every runtime exposes the same exit/fault detail?
- **OQ-0019 action surfaces**: what tiny portable descriptor should explicit shell/terminal actions use so they stay user-invoked, target-bound, and stale-fenced across local/remote hops?

- **OQ-0020 observation subscriptions**: what tiny portable snapshot-plus-change subscription shape is worth freezing so terminals and UIs can avoid polling without creating a giant event bus?
- **OQ-0021 precision fences**: what minimum portable vocabulary should say when hops, multiplexers, or fallback paths downgraded cwd/command/trust precision, and how should resync work?
- **OQ-0022 capability handshake**: what is the smallest portable way for shells, terminals, and hop layers to report fresh semantic-feature support without trusting `TERM` folklore or creating a giant negotiation protocol?
- **OQ-0023 semantic epochs**: what is the smallest portable freshness-token shape that lets shell/terminal frames, actions, and subscriptions say “this belonged to an older semantic world” after hops, resync, or shell reset?
- **OQ-0024 hop lineage**: what is the smallest portable remote/multiplexer path hint that helps scope histories, titles, actions, and capability truth to the actual host/path without implying authentication or a giant transport graph?
- **OQ-0025 observation confidence**: what is the smallest portable low/medium/high plus trusted/provenance model that remains useful across shells, hops, and fallback parsers without pretending confidence is the same as authorization?
- **OQ-0026 provisional state**: what is the smallest portable pending/confirmed/revised/withdrawn model that lets shell/terminal UX hide latency without turning prediction into lifecycle truth?
- **OQ-0027 attention hints**: what is the smallest portable command-finished / needs-input / warning / progress hint model that stays user-filterable, focus-aware, and freshness-scoped without becoming a hidden control or notification bus?
- **OQ-0028 target anchors**: what is the smallest portable way to bind shell/terminal affordances to exact frames, receipts, transcript spans, and concrete runs without scraping rendered text or leaking raw capability into copied/exported output?
- **OQ-0029 chrome lane**: what is the smallest portable observational chrome surface for badges, titles, sticky headers, and side status cells, and how should it stay freshness-scoped, copy-safe, and clearly separate from the canonical transcript?
- **OQ-0030 mode baseline**: what is the smallest portable prompt-critical shell/terminal baseline worth naming explicitly, and how should light resync, baseline reassertion, and user-invoked hard reset stay distinct?
- **OQ-0031 context handoff**: what is the smallest portable bounded bundle for “attach/share this exact command interaction” so command text, exact output, exit data, cwd, witnesses, and receipt refs can be handed off without exporting a whole pane or inventing a giant transcript schema?
- **OQ-0032 repair gates**: what is the smallest portable active / cooling-down / repair-required model, and what exact explicit signal should clear or reset a repair gate without sneaking ambient policy in through the side door?
- **OQ-0033 launch baseline**: what is the smallest portable reviewed launch context worth freezing so component entry and restart stay explicit without importing a giant spawn-profile grammar?
- **OQ-0034 transition helpers**: what is the smallest portable vocabulary for short-lived prepare/drain/cleanup helpers so they stay attributable and bounded without importing a giant hook grammar?
- **OQ-0035 descriptor hygiene**: what is the smallest portable inherited-handle baseline worth naming explicitly so launch, activation, and shell/terminal control paths stay reviewed without importing a giant fd-table DSL?
- **OQ-0036 activation checkpoints**: what is the smallest portable checkpoint vocabulary worth naming explicitly so launch delivery, control-ready, serve-ready, and stop progression stay honest without freezing a giant phase graph?

- **OQ-0037 session variables**: what is the smallest portable observational variable model worth naming explicitly so chrome, palette filtering, and remembered shell context stay useful without becoming authority?
- **OQ-0038 activity brackets**: what is the smallest portable begin/end work-bracket model worth naming explicitly so "do not stop me yet" state stays balanced and attributable without becoming a generic lease or keepalive loophole?
- **OQ-0039 freshness decay**: what is the smallest portable freshness / renewal / last-known vocabulary worth naming explicitly so status, busy hints, and shell chrome can decay honestly without freezing a universal heartbeat contract?
- **OQ-0040 activation receipts**: what is the smallest portable exact-run receipt for delivered startup material and acknowledgement worth naming explicitly so activation stays reviewable without freezing a giant startup protocol?
- **OQ-0041 command guides**: what is the smallest portable guide-rail / sticky-header / scrollbar-mark model worth naming explicitly so visible command boundaries stay exact-object-backed, filterable, and clearly separate from transcript truth?
- **OQ-0042 context inheritance**: what is the smallest portable per-action inheritance model worth naming explicitly so tabs, splits, reruns, and action-launched shells can carry cwd or domain context without smuggling ambient pane folklore?
- **OQ-0043 spawn selectors**: what is the smallest portable reviewed spawn-selector model worth naming explicitly so tabs, splits, reruns, and helper shells can choose program/profile/domain/cwd recipes without ambient `$SHELL`, profile, or pane folklore?
- **OQ-0044 remembered shelves**: what is the smallest portable remembered-shelf model worth naming explicitly so recent commands, directories, and Steward objects can stay host-or-hop-scoped, freshness-labeled, and clearly separate from current live-state truth?
- **OQ-0045 transcript landmarks**: what is the smallest portable mark / annotation / alert / jump-target model worth naming explicitly so transcript landmarks stay exact-anchor-bound, provenance-labeled, and clearly separate from remembered shelves, guide chrome, or ambient control?
- **OQ-0046 workspace snapshots**: what is the smallest portable saved-layout / reconnect / revive / content-only-restore model worth naming explicitly so workspaces can reopen honestly without pretending remembered arrangements are live process truth?
- **OQ-0047 replay gates**: what is the smallest portable restore-or-history replay model worth naming explicitly so remembered, restored, or suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore?
- **OQ-0048 assist surfaces**: what is the smallest portable quick-fix / suggestion / current-input-help model worth naming explicitly so terminals can offer likely next actions without becoming an ambient second shell or silent auto-repair plane?
- **OQ-0049 session injection**: what is the smallest portable staged-command / env-load / history-policy model worth naming explicitly so UI-originated shell mutation stays explicit, scoped, and policy-bounded instead of becoming ambient session folklore?
- **OQ-0050 clipboard surfaces**: what is the smallest portable exact-copy / paste-mode / remote-clipboard policy model worth naming explicitly so clipboard flows stay useful without becoming ambient terminal folklore or silent structured-data loss?
- **OQ-0051 transfer surfaces**: what is the smallest portable exact upload / download / open-local / edit-local-and-sync / attach-object handoff model worth naming explicitly so richer file and object transfer stays reviewed, direction-labeled, and separate from clipboard or prompt folklore?
- **OQ-0052 retention surfaces**: what is the smallest portable retention-class / persistence-scope / erase policy model worth naming explicitly so remembered command, directory, paste, and host breadcrumbs can persist usefully without turning into ambient retained authority or surprise sync?
- **OQ-0053 automation surfaces**: what is the smallest portable exact-target / action-class / control-path / receipt model worth naming explicitly so scripts, hooks, remote-control APIs, and helper CLIs stay useful without becoming an ambient second control plane?
- **OQ-0054 notification surfaces**: what is the smallest portable exact-anchor / focus-policy / reveal-action / durable-truth split worth naming explicitly so command-finished toasts and alert-on-mark flows stay useful without becoming a hidden approval or control path?
- **OQ-0055 input surfaces**: what is the smallest portable key-event / composed-text / modal-key-table / unknown-key-policy / helper-injected-input split worth naming explicitly so the custom shell+terminal can be powerful without confusing typed intent, replay, and terminal-side control?
- **OQ-0056 link surfaces**: what is the smallest portable detected-link / declared-hyperlink / semantic-file-link / exact-object-target split worth naming explicitly so clickable shell/terminal affordances stay useful without turning guessed text into ambient open authority?
- **OQ-0057 execution ground**: what is the smallest portable ground-summary vocabulary worth naming explicitly so panes, command frames, receipt cards, and prediction rails can say what context they stand on without turning chrome, remembered context, or foreground baton hints into lifecycle authority?
- **OQ-0058 progress windows**: what is the smallest portable in-progress / held / extended / stalled vocabulary worth naming explicitly so bring-up and reload can stay honest without freezing a giant startup-timeout, rollout, or watchdog grammar?
- **OQ-0059 presence advertisement**: what is the smallest portable advertised / withheld / withdrawn / expired vocabulary worth naming explicitly so discoverable presence can stay honest without freezing a generic registry, lease, or balancer-membership plane?
- **OQ-0060 attach lanes**: what is the smallest portable observe / attach / control / debug vocabulary worth naming explicitly so shared shell/terminal presence can stay useful without freezing a giant collaboration, transport, or role family?
- **OQ-0061 proposal lanes**: what is the smallest portable proposal/help/conversation lane worth naming explicitly so agent chat, notebook command blocks, and terminal suggestions can stay useful without collapsing into ambient shell execution or a giant notebook family?
- **OQ-0062 approval rungs**: what is the smallest portable proposal / ask / scoped-auto / run-until-completion vocabulary worth naming explicitly so terminal autonomy can be useful without freezing a giant approval-policy matrix or ambient YOLO plane?
- **OQ-0062A exception witnesses**: what is the smallest portable bypass-under-review / waived-until / exception-expired vocabulary worth naming explicitly so deliberate exceptions stay visibly weaker than satisfied gates without freezing a giant waiver, break-glass, or reviewer-workflow family?
- **OQ-0063 revision settlement**: what is the smallest portable desired / observed / settled revision vocabulary worth naming explicitly so pending promotion, stale status, and rollback-to-last-settled guidance stay honest without freezing a giant rollout controller?
- **OQ-0064 headroom witnesses**: what is the smallest portable spendability / headroom vocabulary worth naming explicitly so allowed, approved, and ready can stay separate from quota, restart, seat, or rate-window exhaustion without freezing a giant wallet or capacity family?
- **OQ-0065 hold states**: what is the smallest portable `paused` / `draining` / `frozen` / `start-prevented` vocabulary worth naming explicitly so deliberate maintenance or policy holds stay separate from stall, failure, and ordinary off truth without freezing a giant maintenance or inhibit family?

- **OQ-0066 serve-state witnesses**: what is the smallest portable `serving` / `serving+terminating` / `draining` / `maintenance` / `degraded` vocabulary worth naming explicitly so new-work admission truth stays honest without freezing a giant traffic or service-mesh family?
- **OQ-0067 pressure witnesses**: what is the smallest portable scoped `ok` / `some` / `full` / `warning` / `critical` pressure vocabulary worth naming explicitly so stall/pressure truth stays honest without freezing a giant autoscaling, scheduler, or reclaim-policy family?

- **OQ-0068 backpressure witnesses**: what is the smallest portable `queued` / `retry-after` / `shed` / `stop-accepting` vocabulary worth naming explicitly so admission-throttle truth stays honest without freezing a giant overload, fair-queuing, or traffic-shaping family?
- **OQ-0069 adaptation witnesses**: what is the smallest portable `trim-cache` / `reduce-concurrency` / `defer-optional-work` / `narrow-mode` vocabulary worth naming explicitly so protective response truth stays honest without freezing a giant brownout, autoscaling, or remediation-policy family?
- **OQ-0070 activation material**: what is the smallest portable named inventory for startup credentials, listeners, files, handles, namespace entries, runtime dirs, and config blobs before this becomes a universal capsule?
- **OQ-0071 stop progress**: what exact pending-stop / checkpoint / wait-hint / kill-escalation / termination-status vocabulary is useful without freezing a generic workflow engine?
- **OQ-0072 bind-caused activation**: what activation causes deserve portable names now, and which bind/trigger/currentness facts should remain provider-local until SlopOS settles adjacent component seams?
- **OQ-0073 queued reentry**: how should triggers that arrive during drain or stop become next-cycle truth without smuggling work into a half-dead runtime?
- **OQ-0074 helper hook delivery**: what minimum helper-role / timing-class / at-least-once / grace-budget receipt vocabulary is useful before Steward freezes any hook or sidecar taxonomy?
- **OQ-0075 wake memory**: what future-wake, reminder, alarm, and queued-trigger facts deserve portable names without turning Steward into a scheduler or durable reminder service?
- **OQ-0076 hibernation and inactive continuity**: what should be visible about hibernated, inactive, or addressable-but-not-instantiated component state without promising checkpoint/resume?
- **OQ-0077 durable execution boundary**: which lifecycle receipts merit durable event history before Steward accidentally becomes a workflow engine?
- **OQ-0078 activation demand episodes**: what per-demand accepted / buffered / waking / delivered / timed-out / canceled / shed truth deserves portable names without turning Steward into a queue, activator, proxy, autoscaler, or durable work system?
- **OQ-0079 activation admission**: what per-attempt admitted / denied / deferred / narrowed / throttled / shed truth deserves portable names without turning Steward into a policy engine, quota wallet, admission-controller framework, autoscaler, or durable queue?
- **OQ-0080 activation custody**: what per-holder / per-handoff custody, acknowledgement, expiry, cancellation, redelivery, duplicate-risk, and ambiguity truth deserves portable names without turning Steward into a broker, service mesh, workflow engine, global ownership graph, or exactly-once delivery system?
- **OQ-0081 activation work disposition**: what per-work acknowledged / redeliverable / redelivered / expired / dead-lettered / discarded / abandoned / detached / duplicate-risk / unknown truth deserves portable names before Steward becomes a queue, redrive service, transaction coordinator, job-status API, or exactly-once side-effect plane?
- **OQ-0082 activation effect boundaries**: what per-work local-commit / outbox-recorded / external-submit / external-accept / external-confirm / duplicate-suppressed / mismatch / compensation / irreversible / unknown-effect truth deserves portable names before Steward becomes a transaction coordinator, saga engine, global idempotency ledger, or exactly-once side-effect plane?
- **OQ-0083 activation incarnation lineage**: what per-component incumbent / successor / predecessor / hot-restart-overlap / in-place-subcycle / replacement / clone-restore / stale-incarnation truth deserves portable names before Steward becomes a rollout controller, migration protocol, distributed lock, leader-election service, or global epoch sequencer?
- **OQ-0084 activation residency**: what pending-placement / nominated / bound / resident / warm-idle / frozen / snapshotted / restoring / evicting / evicted / lost / topology-basis truth deserves portable names before Steward becomes a scheduler, autoscaler, warm-pool manager, checkpoint/restore API, migration protocol, or topology DSL?
- **OQ-0085 activation state attachment**: what scratch / tmp / projected config or secret / runtime directory / component data or cache / persistent volume / sticky or migrated disk / snapshot-derived / detached / cleanup truth deserves portable names before Steward becomes a filesystem namespace API, volume manager, secret/config store, storage scheduler, or checkpoint/migration system?
- **OQ-0086 activation material freshness**: what config / secret / token / trust-bundle / lease / version / audience / expiry / renewal / revocation / projection / reload / after-restore reacquire truth deserves portable names before Steward becomes a vault, config store, credential filesystem, workload-identity plane, trust-bundle distributor, reload controller, or secret-rollout system?
- **OQ-0087 activation probe vantage**: what observer / target / path-or-service / scope / threshold / cached-or-stale result / balancer-client gating / identity-basis / failure-hint truth deserves portable names before Steward becomes a health-check DSL, service mesh, load balancer, monitor, SLO engine, rollout controller, or incident system?
- **OQ-0088 activation control verdicts**: what issuer / scope / basis / effect-class / route-eligibility / ejection / stalled / rollback / fail-open / inconclusive verdict truth deserves portable names before Steward becomes a rollout controller, canary framework, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, or incident manager?
- **OQ-0089 activation traffic binding**: what route / alias / service / gateway / proxy / DNS / target-group / tag / weight / mirror / sticky / drain / propagation / topology-preference / stale-binding truth deserves portable names before Steward becomes a load balancer, service mesh, DNS failover system, Gateway API implementation, route compiler, target-group manager, canary framework, topology router, session-affinity grammar, traffic simulator, or rollout controller?
- **OQ-0090 activation live channels**: what live connection / stream / subscription / watch / WebSocket / SSE / gRPC / message drain / GOAWAY / close-handshake / cursor / resume / gap / duplicate / force-close truth deserves portable names before Steward becomes a connection manager, transport API, RPC framework, pub/sub broker, watch service, stream multiplexer, reconnect scheduler, session-resumption plane, service mesh, or sticky-session grammar?
- **OQ-0091 activation retry/replay attempts**: what retry, replay, transparent retry, hedge, reconnect resend, early-data replay, pushback, budget, canonical-intent-match, maybe-applied, duplicate-risk, and abandonment truth deserves portable names before Steward becomes a retry engine, RPC framework, service mesh, broker, durable queue, quota service, workflow engine, distributed idempotency ledger, or exactly-once plane?
- **OQ-0092 proof-slice promotion**: which existing posture seams deserve corpus promotion next, and which should remain sibling pressure or deferred until implementation pressure exists?
- **OQ-0093 control-operation adapter goldens**: which host/runtime operation facts should be translated into weak operation-basis receipts next, and which must remain under the adapter membrane until implementation pressure proves a safe promotion path?
- **OQ-0094 route/channel adapter goldens**: which route, drain, live-channel, resume, cursor, and endpoint facts should be translated into weak ST-TBIND / ST-LIVECHAN basis next, and which must remain under the adapter membrane until implementation pressure proves a safe promotion path?
- **OQ-0095 witness surfaces**: what rendered card, action affordance, status barrier, and audit/refactor truth deserves portable names before Steward becomes a UI framework, remote-control console, audit product, release-provenance system, or proof-of-correctness engine?

## Revision 194 focus
Promote witness-surface weakness into an executable packet seam and audit/refactor one cube surface: add closed ST-WITCARD, ST-ACTIONAFFORD, ST-STATUSBARRIER, and ST-SURFAUDIT schema profiles; add a deterministic witness-surface corpus; wire it into corpus/lint; fix proof-slice inventory drift; and refactor lint harness execution into a registry-driven loop. Keep the scope narrow: cards are not readiness, buttons are not execution, barriers are not currentness, and audits are not fixes, releases, authority, or proof of correctness.

## Revision 188 focus
Promote retry/hedge settlement weakness into an executable packet seam: add closed ST-RETRYADVICE, ST-RETRYBUDGET, ST-RETRYATTEMPT, and ST-HEDGEFATE schema profiles, a deterministic retry-settlement corpus, a lint-wired harness, human specs, assurance links, schema registry updates, and context/runbook updates. Keep the scope narrow: retry advice is not a reservation or grant, budget observation is not global capacity, transparent retry cannot cross commitment, same keys cannot hide different canonical intent, 425/early-data retry must wait for handshake, hedge losers remain duplicate-ambiguous unless stronger evidence says otherwise, and effect confirmation must cite an effect witness.

## Revision 187 focus
Promote turnover/reconciliation weakness into an executable packet seam: add closed ST-RTCYCLE, ST-INCARN, ST-RESIDENCY, and ST-RESUME schema profiles, a deterministic lineage-resume corpus, a lint-wired harness, human specs, assurance links, schema registry updates, and context/runbook updates. Keep the scope narrow: runtime-cycle identity must not become incarnation currentness, residency must not become readiness, resume must not become same-cycle/lossless continuity, stale operations must fence on both runtime cycle and incarnation, and successors must not settle predecessor work or effects.

## Revision 184 focus
Promote route/channel weakness into an executable packet seam: add closed ST-TBIND and ST-LIVECHAN schema profiles, a deterministic channel-binding corpus, a lint-wired route/channel harness, traffic-binding and live-channel human specs, assurance links, schema registry updates, and context/runbook updates. Keep the scope narrow: route facts must not become readiness, no-new-work must not erase existing channels, channel fate must not become effect success, resume must not become lossless continuity, and host endpoint names must stay under the adapter membrane.

## Revision 183 focus
Promote the observe-first admin surface into an executable packet seam: add closed ST-OPREQ and ST-OPRECEIPT schema profiles, a deterministic control-operation corpus, a lint-wired operation harness, operation request/receipt human specs, assurance links, schema registry updates, and context/runbook updates. Keep the scope narrow: exact Steward component targets, stale fences, canonical idempotency, digest-bound receipts, explicit non-implications, and recovery downgrade without designing a remote admin bus, workflow engine, job ledger, host compatibility layer, or component-state oracle.

## Revision 182 focus
Turn Steward from posture-rich to minimally falsifiable: add closed CH-COMP and CH-ACTSET schema profiles, a canonical JSON/digest profile, a deterministic component-lifecycle activation corpus, a lint-wired lifecycle harness, SlopOS and companion boundary docs, adapter membrane rules, lifecycle-currentness lattice, manager recovery/reconciliation posture, time/deadline posture, receipt minimization, observe-first admin surface, and a session working queue. Keep the new proof slice narrow enough to reject lifecycle truth collapse without turning Steward into a service manager, workflow engine, service mesh, shell empire, audit product, or host compatibility layer.

## Revision 181 focus
Deepen Steward research around retry/replay attempts after live-channel ambiguity, route movement, overload, early-data replay risk, timeout, and SlopOS exact request-idempotency pressure: gRPC retry commitment, hedging, and pushback; HTTP idempotent retry limits, `Retry-After`, 429, and 425; AWS SDK token buckets and backoff with jitter; Envoy retry budgets and hedging; Google Cloud retry anti-patterns; and Google SRE cascading-failure cautions. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a retry engine, RPC framework, service mesh, broker, durable queue, quota service, workflow engine, distributed idempotency ledger, or exactly-once plane.

## Revision 180 focus
Deepen Steward research around activation-live channel fate after traffic binding: HTTP/2 and HTTP/3 GOAWAY, gRPC graceful stop, Envoy drain and overload actions, ALB deregistration delay, Kubernetes endpoint termination and watch bookmarks, WebSocket close handshakes, server-sent event Last-Event-ID, NATS drain, and SlopOS network-lease/session-resumption restraint. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a connection manager, transport API, RPC framework, pub/sub broker, watch service, stream multiplexer, reconnect scheduler, session-resumption plane, service mesh, sticky-session grammar, or endpoint-drain controller.

## Revision 179 focus
Deepen Steward research around activation-traffic binding after control verdicts: Kubernetes Service and EndpointSlice abstraction, Gateway API weighted backendRefs and request mirroring, Cloud Run revision traffic migration / tags / non-instant propagation, Lambda weighted aliases and low-traffic variance, ALB deregistration delay and sticky-routing caveats, Envoy/Istio traffic shifting, splitting, mirroring, and draining, topology-aware routing, and SlopOS network-lease restraint. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a load balancer, service mesh, DNS failover system, Gateway API implementation, target-group manager, route compiler, canary framework, topology router, session-affinity grammar, traffic simulator, or rollout controller.

## Revision 178 focus
Deepen Steward research around activation-control verdicts after probe vantage: Kubernetes Deployment status, progress deadlines, report-only stalled conditions, and Pod readiness gates; Nomad update windows, canary promotion, and auto-revert pressure; Amazon ECS deployment circuit breaker stages and rollback behavior; Envoy passive outlier ejection; Cloud Run revision traffic migration and in-flight caveats; Route 53 health aggregation and insufficient-data behavior; and SlopOS control-state restraint. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a rollout controller, canary framework, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, or incident manager.

## Revision 177 focus
Deepen Steward research around probe vantage and health-observation drift: Kubernetes startup/readiness/liveness probes and EndpointSlice serving/terminating/ready splits, gRPC service-specific Check/Watch health semantics, Envoy active health checks and cached pass-through modes, AWS ALB target health states and fail-open caveats, Cloud Run startup/liveness/readiness probes, and SlopOS CH-HEALTH / CH-HEALTHREC discipline. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a health-check DSL, service mesh, load balancer, monitor, SLO engine, rollout controller, or incident system.

## Revision 176 focus
Deepen Steward research around material freshness after attachment and restore: systemd activation-time immutable credentials, Kubernetes projected service-account tokens, Secrets, ConfigMaps, and subPath update caveats, Cloud Run secret volume versus environment-variable behavior, ECS secret env-var injection and rotation limits, Vault dynamic-secret leases and revocation, SPIFFE streamed SVID/bundle updates and redaction, Lambda SnapStart uniqueness/temporary-data refresh, and SlopOS secret-clean snapshot discipline. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a vault, config store, workload-identity plane, trust-bundle service, reload controller, credential filesystem, or secret-rollout system.

## Revision 175 focus
Deepen Steward research around activation state attachment after residency, restore, and eviction: Kubernetes `emptyDir`, projected volumes, and StatefulSet storage; Nomad allocation filesystems, sticky disks, and migration warnings; Cloud Run and Lambda instance-local temporary storage; Docker writable layers, volumes, and tmpfs; systemd managed runtime/state/cache/log/config directories; Fuchsia `data` / `cache` / `tmp` storage capabilities; and SlopOS checkpoint/capshell restraint. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a filesystem namespace API, volume manager, secret/config store, storage scheduler, checkpoint/restore protocol, or migration system.

## Revision 174 focus
Deepen Steward research around activation residency after placement, nomination, warm idle, freeze, snapshot, restore, eviction, node loss, and SlopOS checkpoint-template pressure: Kubernetes scheduler/nominated-node truth, Nomad soft-vs-hard placement constraints, Cloud Run scale-to-zero/min-instance/idle behavior, Lambda provisioned concurrency/SnapStart/freeze/restore phases, and OpenJDK CRaC checkpoint/restore hooks. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a scheduler, autoscaler, warm-pool manager, checkpoint/restore API, migration protocol, or topology DSL.

## Revision 173 focus
Deepen Steward research around incarnation-lineage honesty after restart, hot restart, in-place restart, reschedule, clone/restore, stale action, and successor/predecessor overlap: systemd invocation IDs, Kubernetes UID/lifetime distinctions, Envoy hot restart epochs and drain handoff, Raft stale-term rejection, ZooKeeper leadership-awareness caveats, etcd revision guards, Nomad restart/reschedule behavior, and SlopOS generation-witness restraint. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a rollout controller, migration protocol, distributed lock, leader-election service, or global epoch sequencer.

## Revision 172 focus
Deepen Steward research around side-effect boundary honesty after activation work is admitted, retried, acknowledged, redelivered, or abandoned: caller-chosen idempotency keys, semantic-equivalent retry responses, transactional outbox boundaries, publisher and consumer ack separation, scoped exactly-once claims, compensation limits, irreversible floors, and SlopOS ACP retry/dedupe restraint. Keep the archive decision-light by landing one narrow posture doc plus source locks, notes, one open question, and one non-decision, while avoiding a transaction coordinator, saga engine, outbox service, or global idempotency ledger.

## Revision 171 focus
Deepen Steward research around accepted-not-completed work, acknowledgement/commit races, redelivery versus duplicate, poison/dead-letter disposition, offset/side-effect ordering, finalizer cleanup, and SlopOS ACP acceptance/completion restraint while keeping the archive decision-light: land one narrow posture doc plus source locks, notes, one open question, and one non-decision, but avoid freezing a queue, redrive service, transaction coordinator, job-status API, or exactly-once delivery plane.

## Revision 170 focus
Deepen Steward research around activation custody, visibility leases, event-lifetime bounds, initialization delivery gates, cancellation propagation, serving-while-terminating drain truth, and SlopOS activation-handoff restraint while keeping the archive decision-light: land one narrow posture doc plus source locks, notes, one open question, and one non-decision, but avoid freezing a broker, service mesh, workflow engine, distributed ownership graph, or exactly-once delivery plane.

## Revision 168 focus
Deepen Steward research around cold-start demand episodes, event-lifetime extension, background execution budgets, exact wake permissions, and demand-activation surfaces while keeping the archive decision-light: land one narrow posture doc plus source locks, notes, open questions, and non-decisions, but avoid freezing a queue, activator, proxy, autoscaler, browser service-worker runtime, mobile background scheduler, or durable work engine.

## Revision 167 focus
Deepen Steward research around wake memory, helper-hook delivery contracts, hibernated/inactive continuity, and durable-execution restraint while keeping the archive decision-light: land one narrow posture doc plus explicit source locks, notes, open questions, and non-decisions, but avoid freezing a generic scheduler, actor runtime, hibernation VM, sidecar taxonomy, or lifecycle workflow engine.

## Revision 166 focus
Continue Steward research around manager-owned activation material, explicit stop-progress truth, bind-caused activation, queued-next-cycle triggers, and SlopOS/companion datacube process restraint while keeping the archive decision-light: update source locks and notes, add non-decisions/open questions, but avoid freezing a giant component graph, credential filesystem, dependency planner, or lifecycle transaction engine.

## Revision 118 focus
Deepen Steward's research around pressure-versus-adaptation honesty, explicit protective responses such as cache trim and reduced concurrency, SlopOS D-PRESSURE alignment, and terminal adaptation receipts while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant brownout, autoscaling, or remediation-policy family.

## Revision 117 focus
Deepen Steward's research around queue-versus-shed honesty, retry-after and pushback hints, SlopOS pressure/backpressure alignment, and terminal backpressure chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant overload, fair-queuing, or traffic-shaping family.

## Revision 116 focus
Deepen Steward's research around scoped pressure truth, early adaptation before eviction, SlopOS pressure/backpressure alignment, and terminal pressure chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant scheduler, autoscaler, or reclaim-action family.

## Revision 115 focus
Deepen Steward's research around serve-state truth, drain-versus-serving honesty, SlopOS/Helm pressure around explicit new-work gating, and terminal serve-mode chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant traffic or service family.

## Revision 114 focus
Deepen Steward's research around explicit exception footing, bypass-weaker-than-satisfaction discipline, SlopOS/Helm waiver pressure, and terminal exception chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant waiver or break-glass family.

## Revision 113 focus
Deepen Steward's research around deliberate hold modes, resume-versus-thaw-versus-undrain honesty, SlopOS/Helm maintenance pressure, and terminal hold chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant maintenance or inhibit family.

## Revision 112 focus
Deepen Steward's research around spendability-versus-authority truth, primary-versus-secondary ceilings, reset-versus-manual-clear honesty, and terminal headroom chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant quota or wallet family.

## Recently resolved (keep short)
- **OQ-0200 activity-accounting proof-slice promotion**: activity brackets, busy/idle hints, bounded stop deferral, and descriptive accounting now have closed ST-ACTBRACKET / ST-IDLEHINT / ST-STOPDEFER / ST-ACTACCT profiles plus an executable corpus, without becoming workflow leases, idle-stop authority, drain receipts, billing, quota debit, work completion, or effect truth.
- **OQ-0199 pressure admission proof-slice promotion**: pressure, headroom, backpressure, and admission-gate truth now have closed ST-PRESSURE / ST-HEADROOM / ST-BACKPRESS / ST-ADMGATE profiles plus an executable corpus, without becoming a scheduler, autoscaler, overload controller, quota wallet, demand queue, repair system, or incident product.
- **OQ-0194 witness-surface proof-slice promotion**: witness-card, action-affordance, status-barrier, and surface-audit truth now have closed ST-WITCARD / ST-ACTIONAFFORD / ST-STATUSBARRIER / ST-SURFAUDIT profiles plus an executable corpus, without becoming a UI framework, remote-control console, audit product, release-provenance system, or proof-of-correctness engine.
- **OQ-0193 local observation provenance proof-slice promotion**: local observation, observation appraisal, observation cursor, and observation attachment truth now have closed ST-LOCALOBS / ST-OBSAPPRAISE / ST-OBSCURSOR / ST-OBSATTACH profiles plus an executable corpus, without becoming a host inventory, telemetry bus, global provenance engine, cursor database, or state-promotion engine.
- **RQ-0190 governance authorization packets**: closed ST-DELEGATE / ST-REVIEW / ST-APPROVAL / ST-AUTHCHECK packets now make local lifecycle gate authority executable without turning Steward into Ward, RBAC, an approval UI, or an audit product.
- shutdown-settlement packets: ST-QUIESCE, ST-DRAIN, ST-ESCALATE, and ST-TERMCAUSE now have closed schemas and a corpus for quiesce/drain/escalation/termination non-collapse.
- **OQ-0000 naming**: the project name is **Steward**.
- **OQ-0089/OQ-0090 first packet promotion**: traffic-binding and live-channel truth now have closed ST-TBIND / ST-LIVECHAN profiles plus an executable corpus, without becoming final route or transport APIs.
- **OQ-0092 current proof-slice promotion**: demand/custody/effect witness weakness is now promoted into ST-DEMAND / ST-CUSTODY / ST-WORKDISP / ST-EFFECT packets, with adapter golden traces deferred.
- **OQ-0085/OQ-0086/OQ-0087/OQ-0088 currentness-before-control promotion**: state attachment, material freshness, probe vantage, and control verdict truth now have closed ST-STATEATT / ST-MATFRESH / ST-PROBE / ST-CTRLVERDICT profiles plus an executable corpus, without becoming storage, vault, health, rollout, repair, route, or incident APIs.
- **OQ-0092 lineage/resume proof-slice promotion**: runtime-cycle, incarnation-lineage, residency, and resume/reconciliation truth now have closed ST-RTCYCLE / ST-INCARN / ST-RESIDENCY / ST-RESUME profiles plus an executable corpus, without becoming process, scheduler, rollout, checkpoint, hot-restart, or durable replay APIs.
- **OQ-0091/OQ-0092 retry-settlement proof-slice promotion**: retry advice, retry budget, retry attempt, and hedge-fate truth now have closed ST-RETRYADVICE / ST-RETRYBUDGET / ST-RETRYATTEMPT / ST-HEDGEFATE profiles plus an executable corpus, without becoming a retry engine, RPC framework, service mesh, quota service, hedge subsystem, idempotency ledger, or exactly-once plane.
- **OQ-0092 previous proof-slice promotion**: route/channel witness weakness was promoted into ST-TBIND / ST-LIVECHAN packets, with adapter golden traces deferred.

## Revision 111 focus
Deepen Steward's research around desired-versus-observed-versus-settled revision truth, pending-promotion honesty, rollback-to-last-settled guidance, and terminal revision ribbons while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant rollout family.

## Revision 109 focus
Deepen Steward's research around approval/autonomy rungs, policy floors, sandbox-paired higher autonomy, and witness-first downgrade on reconnect while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant automation-policy family.

## Revision 108 focus
Deepen Steward's research around lane-labeled remembered search, shell-history hygiene, insert-versus-run defaults, and explicit retention/sync truth while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant memory or search family.

## Revision 191 note
Receipt transport is now a named executable seam. Near-term follow-up should keep it minimized: use ST-RECEIPTCHAIN, ST-REDACTION, ST-EXPORTBUNDLE, and ST-REPLAYOBS only for lifecycle evidence handoff, manager recovery import, sibling review, and release evidence, not as a generic audit log, provenance system, export grammar, redaction engine, or authority mechanism.

## Revision 192 note
Import reconciliation is now a named executable seam. Near-term follow-up should keep it weak and local: use ST-IMPORT, ST-SRCAPPRAISE, ST-RECONPLAN, and ST-RECONDECISION only to admit, appraise, map, quarantine, or attach imported lifecycle evidence as history or weak basis. Do not turn it into a global trust engine, migration controller, durable workflow replay engine, audit product, provenance system, approval workflow, or way to resurrect currentness after recovery.

## Revision 193 note
Local observation provenance is now a named executable seam. Keep the next pressure lane adapter-specific and weak: translate concrete host/runtime/shell observations into categorical packets, then prove they only feed explanation, review, recovery hints, audit, history, or recheck paths unless a separate native Steward witness exists.

## Revision 194 note
Witness surfaces are now a named executable seam. Near-term follow-up should keep them render-only and exact: consume existing packet non-implications, show missing stronger witnesses, disable actions behind barriers, and record audits without treating cards, buttons, barriers, or audit findings as lifecycle truth, authority, execution, release proof, or correctness proof.

## Revision 195 note — status-channel settlement
- Settled: observation-subscription transport is represented by ST-OBSSUB / ST-OBSDELIV / ST-OBSSYNC / ST-OBSGAP packets and checked by `status-channel-corpus-v0`.
- Settled: corpus harness execution now has one registry source in `tools/harness_registry.py` and one Makefile runner in `tools/run_corpora.py`.
- Open: concrete transport, UI display of stream gaps, and adapter golden traces remain deferred until implementation pressure.

## OQ-ATTENTION-NOTIFICATION-PACKETS — exact attention watches without notification empire
State: pinned-for-corpus. Revision 196 adds ST-ATTNHINT, ST-ATTNWATCH, ST-NOTICE, and ST-ATTNACK plus an executable corpus. Keep future work focused on exact anchors, stale/downgrade honesty, and non-authoritative reveal paths rather than a general notification service, reminder inbox, macro engine, approval surface, or user-read plane.

## Revision 197 note
Preconditions, operation arbitration, deliberate holds, and progress windows now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a scheduler, distributed lock, generic queue manager, rollout controller, transaction planner, or policy engine. Instead, pressure-test packet translation against adapter goldens: one stale runtime-cycle precondition, one active maintenance hold that queues restart, one failed precondition that rejects mutation, one progress window held by policy, one deadline-exceeded stall, and one host-specific queued/replaced control operation that must not claim execution.


## Revision 198 note
Generation rollout movement is now a named executable seam. `ST-GENPLAN`, `ST-RECONFAPPLY`, `ST-GENREADY`, and `ST-PROMOTION` settle the first plan/apply/ready/promote packet chain while rejecting material-as-freshness, reload-as-readiness, readiness-as-traffic, promotion-as-serving/effect-success, rollback-as-compensation, stale-readiness promotion, and duplicate generation drift. Keep future work adapter-specific; do not turn this into a rollout controller or deployment platform.

## Revision 199 note
Pressure admission is now a named executable seam. `ST-PRESSURE`, `ST-HEADROOM`, `ST-BACKPRESS`, and `ST-ADMGATE` settle the first pressure/headroom/backpressure/gate packet chain while rejecting pressure-as-failure, headroom-as-authority, retry-after-as-reservation, backpressure-as-demand, gate-as-work, allow-with-exhausted-headroom, and duplicate gate id drift. Keep follow-up work adapter-specific and weak; do not turn this into an overload controller, resource manager, scheduler, autoscaler, quota wallet, or incident system.
## Revision 200 note
Activity accounting is now a named executable seam. `ST-ACTBRACKET`, `ST-IDLEHINT`, `ST-STOPDEFER`, and `ST-ACTACCT` settle the first bracket/idle/deferral/accounting packet chain while rejecting activity-as-demand, busy-as-readiness, idle-as-stopped, deferral-as-keepalive, accounting-as-billing, accounting-as-work-completion, and duplicate bracket id drift. Keep follow-up work adapter-specific and weak; do not turn this into a workflow lease plane, billing system, quota wallet, generic idle-stop API, or drain-completion protocol.

## Revision 201 note
Dependency gates are now executable. The newly resolved pressure lane keeps dependency specs, dependency checks, request gates, and degraded fallbacks weak and scoped; future work should pressure-test concrete adapters rather than broadening into a universal topology/dependency language.
