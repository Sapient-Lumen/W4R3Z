# Roadmap

## Revision 1: seed the datacube
- establish repo hygiene and packaging;
- identify narrow phase-1 seams;
- collect external lessons and shell/terminal ideas.

## Revision 2: harden the guardrails, not the whole architecture
- add a compact design-principles v0 note;
- strengthen lessons from historical supervisors and activation systems;
- sharpen shell/terminal direction around command frames, receipts, marks, and remote-aware semantic transport;
- automate source-review-queue generation to keep research hygiene light and repeatable.

## Revision 3: freeze late on purpose
- make non-decisions explicit so adjacent SlopOS uncertainties do not harden accidentally;
- improve shell/terminal notes around semantic markers and command-block UX;
- tighten source-lock hygiene and bibliography sync.

## Revision 4: observations before mutations
- add small posture notes for lifecycle observation vocabulary and compact current-state/status reporting;
- sharpen readiness around shallow/control-ready versus declared-work ready;
- collect shell-marker provenance and trust-model ideas instead of inventing a giant custom terminal protocol.

## Revision 11: subscriptions before bigger event stories
- add a narrow observation-subscription posture rather than freezing a giant event bus or control API;
- collect lessons around snapshot-plus-change views, coalescing, backpressure, and text-friendly remote-safe observation streams;
- tighten shell/terminal direction around prompt freshness, command-finish notifications, and subscription-backed UI without hidden ambient authority.



## Revision 197 note
Preconditions, operation arbitration, deliberate holds, and progress windows now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a scheduler, distributed lock, generic queue manager, rollout controller, transaction planner, or policy engine. Instead, pressure-test packet translation against adapter goldens: one stale runtime-cycle precondition, one active maintenance hold that queues restart, one failed precondition that rejects mutation, one progress window held by policy, one deadline-exceeded stall, and one host-specific queued/replaced control operation that must not claim execution.

## Revision 196 note
Attention-hint, attention-watch, notification-delivery, and acknowledgement witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a desktop notification service, durable reminder/inbox, macro engine, approval surface, or user-presence/read-receipt plane. Instead, pressure-test with one exact frame watch, one matched hint, one toast delivery, one stale delivery downgrade, and one reveal acknowledgement.

## Revision 195 note
Observation-subscription, delivery, sync, and gap witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a universal event bus, streaming firehose, remote-control protocol, cursor database, or status UI framework. Instead, pressure-test with one exact component-status subscription, one delivered batch, one overflow/resync gap, one initial snapshot marker, and one stale action blocked by a stream gap.

## Revision 194 note
Witness-card, action-affordance, status-barrier, and surface-audit witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a UI framework, remote-control console, audit product, release-provenance system, or proof-of-correctness engine. Instead, pressure-test rendering against concrete fixture bundles: one weak local observation card, one disabled stale-cycle stop action, one reviewable exact operation action, one blocking status barrier, and one audit/refactor report that must not claim authority or release correctness.

## Revision 193 note
Local observation provenance is now a named executable seam. Near-term follow-up should avoid designing a global provenance system, host inventory, Kubernetes/systemd API, shell telemetry bus, cursor database, or observation-to-state promotion engine. Instead, pressure-test packet translation against adapter goldens: one systemd active sample, one Kubernetes running phase, one proxy green summary, one file watcher material-change sample, one shell prompt sighting, and one overflowed cursor that can only create a recheck request.

## Revision 190 note
Delegation-warrant, operator-review, approval-decision, and authorization-check witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a global governance engine, RBAC system, Ward replacement, owner map, approval UI, audit product, or escalation workflow. Instead, pressure-test packet translation against adapter goldens: one Ward-issued scoped warrant, one stale owner-map label, one review that needs approval, one denied approval, one break-glass approval leading later to escalation, and one authcheck that must be cited by a separate operation receipt before any action is claimed.

## Revision 189 note
Quiesce, drain, escalation, and termination-cause witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a shutdown controller, signal API, endpoint-drain controller, broker-drain service, restart engine, crash analyzer, or lossless-stop guarantee. Instead, pressure-test packet translation against adapter goldens: one cooperative quiesce with old live channels, one component drain with pending none, one drain deadline hit with pending some, one applied kill-level escalation, one crash termination without drain evidence, and one graceful requested stop that must cite drain evidence before being called clean.

## Revision 188 note
Retry advice, retry budget, retry attempt, and hedge-fate witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a retry engine, RPC framework, service mesh, route-level retry-budget service, durable queue, broker, workflow engine, distributed idempotency ledger, hedge racing subsystem, early-data replay authority, or exactly-once plane. Instead, pressure-test packet translation against adapter goldens: one HTTP Retry-After delay, one gRPC transparent retry before commitment, one server-pushback retry, one zero-budget automatic-retry block, one 425 early-data retry after handshake, one hedged request with a duplicate-possible loser, and one effect-confirmed attempt that must cite a separate effect witness.

## Revision 187 note
Runtime-cycle, incarnation-lineage, residency, and resume/reconciliation witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a scheduler, rollout controller, checkpoint/restore protocol, hot-restart protocol, durable replay engine, or process inventory. Instead, pressure-test packet translation against adapter goldens: one systemd invocation/run turnover, one Kubernetes UID/pod restart/reschedule, one hot-restart predecessor/successor overlap, one warm/frozen residency restore, one manager-recovery downgrade, and one stale action that must fence on both runtime cycle and incarnation.

## Revision 186 note
State attachment, material freshness, probe vantage, and control verdict witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a storage API, vault, health-check plane, rollout controller, repair engine, route controller, or incident system. Instead, pressure-test packet translation against adapter goldens: one projected credential that is attached but stale, one snapshot restore that requires reacquire, one green local probe with withheld external gate, one failing outside-in probe without automatic repair, and one traffic verdict that must cite a separate route witness.

## Revision 185 note
Demand, custody, work-disposition, and effect-boundary witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a queue, broker, workflow runtime, transaction coordinator, outbox service, compensation engine, or exactly-once plane. Instead, pressure-test packet translation against adapter goldens: one cold-start request, one visibility-lease style redelivery, one local-completion-with-external-submit split, one same-key mismatch, one ambiguous external effect after channel loss, and one recovery downgrade that must not invent success.

## Revision 184 note
Route and channel witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a load balancer, stream manager, or reconnect API. Instead, pressure-test packet translation against adapter goldens: one route drain with old channels, one mirror/observation-only route, one watch resume with cursor gap, one message-client drain, and one stale endpoint observation that must stay under the membrane.

## Next likely revision
- add adapter golden traces that translate host/runtime local observation, coordination-gate, governance-authorization, lineage, residency, resume, currentness, probe, verdict, route, live-channel, demand, custody, work-disposition, effect-boundary, retry-advice, retry-budget, retry-attempt, hedge-fate, shutdown, and termination evidence into weak Steward basis without promoting it to native state;
- extend witness-surface fixtures beyond the first corpus with adapter-specific bundles that consume ST-LOCALOBS, ST-OBSAPPRAISE, ST-OBSCURSOR, ST-OBSATTACH, ST-OPRECEIPT, ST-RTCYCLE, ST-INCARN, ST-RESIDENCY, ST-RESUME, ST-STATEATT, ST-MATFRESH, ST-PROBE, ST-CTRLVERDICT, ST-TBIND, ST-LIVECHAN, ST-DEMAND, ST-CUSTODY, ST-WORKDISP, ST-EFFECT, ST-RETRYADVICE, ST-RETRYBUDGET, ST-RETRYATTEMPT, ST-HEDGEFATE, ST-QUIESCE, ST-DRAIN, ST-ESCALATE, ST-TERMCAUSE, ST-DELEGATE, ST-REVIEW, ST-APPROVAL, and ST-AUTHCHECK non-implications without strengthening them in UI copy;
- expand packet coverage from one accept/reject minimum into adapter-specific semantic boundary matrices;
- keep remote APIs, load-balancer APIs, transport/session APIs, retry engines, retry-budget services, broker APIs, workflow APIs, transaction APIs, distributed idempotency ledgers, hedge racing subsystems, and exactly-once APIs deferred until the local packet path proves useful.

## Revision 8: cycle witnesses before bigger control planes
- add a narrow runtime-cycle witness posture rather than a giant generation or admin API;
- collect lessons around per-runtime-cycle identity, transaction-aware stop behavior, and semantic prompt ancestry;
- tighten shell/terminal direction around action chips, provenance, and stale-action fences while keeping the archive light.

## Longer horizon
- prototype a minimal user-space supervisor;
- define transcripts/receipts for lifecycle events;
- prove that restart/activation does not widen authority;
- define compat membranes for host service managers without importing their semantics.

## Revision 5: command frames and transient ideas
- add a small command-frame posture rather than freezing a big terminal protocol;
- collect more lessons from Dinit, Shepherd, tmux, Ghostty, fish, kitty, and xterm;
- tighten shell/terminal direction around parseable side channels, input-side semantics, and transient-service inspiration;
- improve repo hygiene by checking the head-register against the source-lock set.

## Activation-admission follow-up
- Exercise the new activation-admission seam against two or three concrete SlopOS component sketches before naming any universal policy or quota grammar.
- Keep denial/defer/throttle/shed receipts tiny and per-attempt until repeated implementation pressure proves otherwise.
## Activation-custody follow-up
- Exercise the new activation-custody seam against a manager-held listener, a cold-start request, and a bounded background event before naming any universal holder-state grammar.
- Keep cancellation, expiry, redelivery, duplicate-risk, and handoff-ack truth per-demand or per-operation until repeated implementation pressure proves otherwise.


## Activation-work disposition follow-up
- Exercise the new disposition seam against one accepted-but-not-completed HTTP demand, one restart-redelivered intent/event, one ack-race channel close, one queue-backed background job, and one cleanup/finalizer path before naming any generic disposition grammar.
- Keep ack, retry/redrive, poison/dead-letter, discard, expiry, unknown fate, and duplicate-risk per-demand or per-operation until repeated implementation pressure proves otherwise.

## Activation-effect boundary follow-up
- Exercise the new effect-boundary seam against one idempotent create request, one local-commit-plus-outbox flow, one external publish/ack split, one compensable operation, and one deliberately irreversible effect before naming any generic effect grammar.
- Keep local commit, outbox, external acceptance, confirmation, compensation, irreversible floors, retention windows, and unknown effect fate per-work until repeated implementation pressure proves otherwise.

## Activation-live channel follow-up
- Exercise the new live-channel seam against one GOAWAY/no-new-streams path, one graceful-stop deadline, one close-handshake disagreement, one resumable watch cursor, one lost SSE reconnect, one drainable message client, and one old-route channel surviving a traffic flip before naming any generic live-channel grammar.
- Keep holder, layer, no-new-work fence, close/reset fate, cursor/resume hint, gap/duplicate ambiguity, and force-close truth per channel or stream until repeated implementation pressure proves otherwise.


## Activation-retry attempt follow-up
- Exercise the new retry-attempt seam against one safe retry, one idempotent exact replay, one same-key mismatch, one transparent retry, one hedged request, one pushback-delayed retry, one budget-exhausted path, and one early-data replay-risk path before naming any generic retry grammar.
- Keep original demand, canonical-intent match, safety basis, not-before/pushback, budget, commitment boundary, duplicate ambiguity, hedge cleanup, and abandonment truth per attempt or attempt group until repeated implementation pressure proves otherwise.



## Revision 174 note
Activation residency is now a named seam. Near-term follow-up should keep it observational: identify which real components need to report `pending-placement`, `nominated`, `bound`, `warm-idle`, `frozen`, `restoring`, `evicting`, `evicted`, `lost`, or `unknown`, and resist turning that vocabulary into a scheduler, autoscaler, warm-pool manager, checkpoint/restore API, migration protocol, or topology DSL.

## Activation-state attachment follow-up
- Exercise the new state-attachment seam against one `emptyDir`-style scratch area, one projected credential/config mount, one sticky or migrated cache disk, one persistent volume rebound, and one snapshot-derived restore before naming any generic attachment grammar.
- Keep attached, projected, persistent, rebound, migration, cleanup, and detach truth explanatory until repeated implementation pressure proves Steward needs a storage, namespace, secret/config, or migration family.

## Activation-material freshness follow-up
- Exercise the new material-freshness seam against one static env-injected secret, one projected service-account token, one ConfigMap/Secret volume update, one dynamic-secret lease, one streamed workload-identity bundle, and one snapshot-restored credential before naming any generic freshness grammar.
- Keep version, epoch, audience, expiry, renewal, revocation, projection, reload, and after-restore reacquire truth explanatory until repeated implementation pressure proves Steward needs a vault, config, identity, trust-bundle, or reload-controller family.

## Activation-probe vantage follow-up
- Exercise the new probe-vantage seam against one kubelet startup/readiness/liveness path, one gRPC service-specific health watch, one balancer target health state, one mesh cached/pass-through probe, one outside-in synthetic check, and one terminating-but-serving endpoint before naming any generic health grammar.
- Keep observer, target, path/service, threshold, cache, identity, and freshness truth explanatory until repeated implementation pressure proves Steward needs a health-check DSL, service mesh, load balancer, monitor, SLO, rollout, or incident family.

## Activation-control verdict follow-up
- Exercise the new control-verdict seam against one report-only stalled rollout, one readiness-gate hold, one deployment-circuit-breaker rollback, one passive outlier ejection, one traffic-split migration, and one DNS fail-open / insufficient-data case before naming any generic verdict grammar.
- Keep issuer, subject, scope, basis, freshness, effect class, and verdict state explanatory until repeated implementation pressure proves Steward needs a rollout controller, canary framework, service mesh, load balancer, DNS failover system, remediation engine, autoscaler, or incident manager.

## Activation-traffic binding follow-up
- Exercise the new traffic-binding seam against weighted aliases, tagged test URLs, service selectors, EndpointSlice membership drift, target-group deregistration delay, mirrored traffic, topology-preference fallback, sticky sessions, DNS/client-cache propagation, and direct admin paths before naming any generic route grammar.
- Keep surface, issuer, desired/observed/applied generation, weights, affinity, mirror/shadow roles, drain state, propagation, topology preference, stale-route truth, and unknown binding explanatory until repeated implementation pressure proves Steward needs a load balancer, service mesh, DNS failover system, Gateway API implementation, target-group manager, route compiler, canary framework, topology router, traffic simulator, or rollout controller.

## Receipt transport follow-up
- Exercise receipt transport against one manager-recovery import, one sibling-cube handoff, one public-redacted support export, one release-evidence bundle, and one intentionally partial replay before naming any general audit/export product.
- Keep chain head, redaction commitment, export manifest, replay verification, and gap downgrade explanatory until implementation pressure proves Steward needs more than minimized lifecycle evidence transport.

## Import reconciliation follow-up
- Exercise import reconciliation against one manager-recovery import, one sibling-cube handoff, one support-return bundle, one stale audit replay, one adapter dump, and one partially redacted public bug-report bundle before naming any generic import/adoption grammar.
- Keep import observation, source appraisal, reconciliation planning, and local decisions explanatory until repeated implementation pressure proves Steward needs more than weak evidence import, quarantine, and local recheck fences.

## Revision 198 note
Generation-plan, reconfiguration-apply, generation-readiness, and promotion witnesses now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a deployment orchestrator, rollout controller, service mesh, config store, rollback-compensation system, or global release engine. Instead, pressure-test packet translation against adapter goldens: one projected-but-stale material update, one reload applied but not ready, one degraded canary, one promotion blocked by expired readiness, one route rollback that does not compensate effects, and one duplicate generation id that must be rejected.

## Revision 199 note
Pressure admission is now executable. Next pressure should come from adapter golden traces: one memory pressure warning, one exhausted restart budget, one HTTP pushback, one allowed gate with separate demand witness, and one shed path that must not claim work completion. Avoid turning this into a scheduler, quota wallet, autoscaler, or overload controller.
## Revision 200 note
Activity brackets, idle hints, bounded stop deferral, and descriptive accounting now have closed packet profiles and an executable corpus. Near-term follow-up should pressure-test concrete adapter translations: one balanced begin/end scope, one lost end signal, one coarse busy-only runtime, one stop request held by open activity then forced at deadline, and one descriptive usage summary that must not become billing, quota debit, drain completion, work completion, or effect success.

## Revision 201 note
Dependency gating is now a named executable seam. `ST-DEPSPEC`, `ST-DEPCHECK`, `ST-DEPGATE`, and `ST-DEPFALLBACK` settle the first dependency declaration/check/gate/fallback packet chain while rejecting topology-authority flattery, dependency-as-readiness, stale checks, gate-as-execution, allow-with-unavailable-hard-dependency, degrade-without-active-fallback, and fallback-as-repair. Keep follow-up work adapter-specific and weak; do not turn this into a universal dependency planner, topology DSL, scheduler, service graph, mesh graph, repair system, or rollback controller.
