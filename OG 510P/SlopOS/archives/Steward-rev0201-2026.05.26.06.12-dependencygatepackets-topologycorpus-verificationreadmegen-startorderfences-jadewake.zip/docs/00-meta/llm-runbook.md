# LLM runbook

This runbook exists to reduce archive amnesia and premature architecture freeze.

## Non-negotiables
1. **No ambient lifecycle authority**: if Steward controls something, that target and authority should be explicit.
2. **Do not clone systemd by inertia**: cover the responsibility set, but keep the semantics narrow and reviewable.
3. **Readiness is not spawn success**: keep startup, readiness, liveness, and crash distinct.
4. **Activation is supervisor-owned**: do not drift into “process recreates its whole public world however it likes.”
5. **Foreground accountability matters**: supervised services must not disappear behind daemonizing folklore.
6. **Launch meaning must stay explicit**: restartable services should not depend on ambient login-shell, `PATH`, or session folklore.
7. **Dynamic conditions stay dynamic**: changing external conditions should not harden into fake boot-order facts.
8. **Tiny explicit checkpoints beat wrapper folklore**: if launch or stop progression matters, it should be named and attributable.
9. **Balanced work brackets beat sticky keepalive folklore**: if a runtime needs stop deferral, it should say so explicitly and boundedly.
10. **Shell and terminal must not smuggle authority through PTY folklore**.
11. **Keep the repo lighter than the parent SlopOS archive until the seams are truly stable**.
12. **Freshness should decay honestly**: live hints, badges, and stop/progress state should clear or downgrade when their renewal path goes stale.
13. **Freeze observations before broad mutations when possible**.
14. **Activation and attention are different powers**: waking the right component and bringing something to the foreground must not collapse into one ambient control story.
15. **Activation material delivery is not inheritance**: credentials, descriptors, sockets, namespace entries, runtime directories, and config should be selected, named, and receipted for a cycle.
16. **Pending stop/progress must not flatter itself**: do not report `stopped`, `ready`, or `current` until the exact boundary has actually been crossed or a bounded weaker receipt says otherwise.
17. **Wake memory is not execution**: a timer, reminder, alarm, stub, or queued trigger may explain a later wake, but it is not proof of running, readiness, serving, currentness, or attention.
18. **Activation demand is not service**: accepting or buffering one demand at an activation surface is not proof that the component is running, ready, serving, or will complete that demand.
19. **Activation admission is not execution**: allowing, denying, deferring, narrowing, throttling, or shedding one attempt should not be confused with runtime state, queue ownership, readiness, serving, or completion.
20. **Activation custody is not completion**: a demand, event, descriptor, or background obligation can be held, delivered, acknowledged, redeliverable, duplicated, abandoned, or unknown without proving readiness, serving, or success.
21. **Activation work disposition is not completion-by-folklore**: acknowledgement, redelivery, dead-letter, discard, expiry, or unknown fate must stay separate from admission, custody, restart, readiness, serving, health, and effect completion.
22. **Activation effect boundaries are not exactly-once folklore**: local commit, outbox record, external submit, external confirmation, compensation, irreversible floor, and unknown side-effect truth must stay separate from retries, acknowledgements, redelivery, disposition, and component health.
23. **Activation incarnation lineage is not name reuse folklore**: stable component names, runtime-cycle witnesses, predecessor/successor overlap, hot-restart drain, in-place subcycles, replacement, clone/restore, and currentness fences must stay visibly separate.
24. **Activation residency is not service or continuity**: placement, warm idle, freeze, snapshot, restore, eviction, and loss must stay separate from identity, readiness, serving, custody, work fate, and effects.
25. **Activation state attachment is not currentness or authority**: scratch, tmp, projected material, runtime directories, persistent volumes, sticky disks, snapshot-derived bytes, and cleanup state must stay separate from readiness, serving, current incarnation, custody, work fate, and effects.
26. **Activation material freshness is not path presence**: projected, env-injected, leased, streamed, rotated, revoked, or snapshot-restored material must not silently imply current authority, reload success, or safe reuse.
27. **Activation probe vantage is not service truth**: one startup/readiness/liveness/balancer/client/synthetic probe result must stay scoped to observer, path, freshness, threshold, and identity basis rather than proving readiness, serving, currentness, or incident policy.
28. **Activation control verdicts are not observations or actions**: a controller, balancer, rollout, circuit breaker, DNS-health system, or operator verdict must name issuer, scope, basis, freshness, and effect class rather than silently turning probe evidence into rollback, route, restart, incident, or global service truth.
29. **Activation traffic binding is not rollout truth**: a route, alias, service, gateway, proxy, DNS, target-group, or test tag must show its own desired/observed/applied, weighted, sticky, mirrored, draining, stale, or unknown binding instead of borrowing truth from probes, verdicts, readiness, serving, admission, or rollback labels.
30. **Activation live channels are not route or completion truth**: an open, draining, closing, reset, resumed, or lost connection/stream/subscription/watch must name holder, layer, cursor, close/reset evidence, and gap ambiguity instead of proving readiness, route authority, work completion, or effect success.
31. **Activation retry attempts are not effect or completion truth**: a follow-up retry, replay, transparent retry, hedge, reconnect resend, or post-drain attempt must name safety basis, canonical-intent match, not-before/pushback, budget, commitment boundary, and duplicate ambiguity instead of proving route authority, work completion, or external effect success.
32. **Proof before expansion**: when a lifecycle distinction becomes central, prefer adding a deterministic corpus case over adding another untested posture paragraph.
33. **Adapter facts are weak until promoted**: host/runtime observations may explain a state, but they must not become Steward readiness, serving, authority, or effect truth without a named witness.
34. **Receipts minimize by schema**: portable receipts should carry digests and scoped summaries, not raw handles, secrets, descriptor numbers, or whole transcripts.
35. **Operation receipts are not component state**: a completed, timed-out, failed, queued, or recovery-unknown control operation must not silently claim ready, serving, stopped, effect success, or currentness.
36. **Route/channel packets are weak witnesses**: traffic binding and live-channel packets must carry explicit non-implications instead of flattening route, channel, readiness, work, continuity, or effect truth.
37. **Lineage/resume packets are not continuity proof**: runtime-cycle, incarnation, residency, and resume witnesses must not flatten turnover into same-cycle identity, readiness, losslessness, exactly-once execution, or effect settlement.
38. **Retry/hedge packets are not retry success**: retry advice, retry budgets, retry attempts, and hedge fates must not flatten timing hints, local quota observations, replay safety, winner response, loser cleanup, or duplicate ambiguity into route authority, work completion, no-side-effect proof, exactly-once execution, or effect settlement.
39. **Shutdown packets are not clean stop proof**: quiesce, drain, escalation, and termination-cause witnesses must not flatten no-new-work, pending old work, stronger intervention, or cycle end into stopped, clean, lossless, successor-ready, or effect-success truth.

40. **Governance authorization packets are not execution proof**: delegation warrants, reviews, approvals, and authorization checks must not flatten owner labels, request hygiene, approval, gate allowance, operation receipts, lifecycle state, or effect success into one ambient authority story.
41. **Import reconciliation packets are not currentness proof**: imported evidence, source appraisal, reconciliation plans, and reconciliation decisions must not flatten handoff, recovery, audit replay, or adapter dumps into authority, freshness, readiness, serving, operation execution, or effect success.
42. **Local observation provenance is weak**: host-manager, orchestrator, adapter, shell, watcher, and cursor observations must remain appraised weak evidence or recheck pressure, not native currentness, readiness, serving, authority, execution, drain, or effect success.
43. **Generation rollout packets are not deployment success**: generation plans, apply attempts, readiness, and promotion must not flatten material projection, reload, traffic shift, rollback, serving, or external effect truth.
44. **Pressure admission packets are not health or work proof**: pressure, headroom, backpressure, and admission gates must not flatten resource strain, spendability, pacing, or shedding into failure, authority, demand acceptance, execution, readiness, serving, or effect success.

## Must-read set (refresh before making changes)
- `README.md`
- `docs/README.md`
- `docs/00-meta/charter.md`
- `docs/00-meta/archive-policy.md`
- `docs/00-meta/trajectory-map.md`
- `docs/00-meta/session-working-queue.md`
- `docs/00-meta/roadmap.md`
- `docs/00-meta/bibliography.md`
- `docs/00-meta/evidence-index.md`
- `docs/10-threat-model/threat-model.md`
- `docs/20-assurance/claim-registry.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/30-architecture/architecture-overview.md`
- `docs/30-architecture/design-principles-v0.md`
- `docs/30-architecture/non-decisions-v0.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/posture-index.md`
- `docs/30-architecture/schema-registry.md`
- `docs/30-architecture/canonical-json-profile-v0.md`
- `docs/30-architecture/slopos-boundary-crosswalk-v0.md`
- `docs/30-architecture/companion-boundary-map-v0.md`
- `docs/30-architecture/lifecycle-currentness-lattice-v0.md`
- `docs/30-architecture/adapter-membrane-posture-v0.md`
- `docs/30-architecture/local-observation-provenance-posture-v0.md`
- `docs/30-architecture/local-observation-witness-schema-v0.md`
- `docs/30-architecture/observation-appraisal-witness-schema-v0.md`
- `docs/30-architecture/observation-cursor-witness-schema-v0.md`
- `docs/30-architecture/observation-attachment-witness-schema-v0.md`
- `docs/30-architecture/manager-recovery-reconciliation-posture-v0.md`
- `docs/30-architecture/time-and-deadline-posture-v0.md`
- `docs/30-architecture/receipt-minimization-posture-v0.md`
- `docs/30-architecture/admin-surface-posture-v0.md`
- `docs/30-architecture/pressure-admission-proof-posture-v0.md`
- `docs/30-architecture/pressure-witness-schema-v0.md`
- `docs/30-architecture/headroom-witness-schema-v0.md`
- `docs/30-architecture/backpressure-witness-schema-v0.md`
- `docs/30-architecture/admission-gate-witness-schema-v0.md`
- `docs/40-verification/pressure-admission-corpus-v0.md`
- `docs/30-architecture/control-operation-request-schema-v0.md`
- `docs/30-architecture/control-operation-receipt-schema-v0.md`
- `docs/30-architecture/traffic-binding-witness-schema-v0.md`
- `docs/30-architecture/live-channel-witness-schema-v0.md`
- `docs/30-architecture/component-manifest-schema-v0.md`
- `docs/30-architecture/activation-set-schema-v0.md`
- `docs/30-architecture/supervision-posture-v0.md`
- `docs/30-architecture/launch-context-posture-v0.md`
- `docs/30-architecture/transition-helper-posture-v0.md`
- `docs/30-architecture/activation-checkpoint-posture-v0.md`
- `docs/30-architecture/activation-posture-v0.md`
- `docs/30-architecture/request-activation-posture-v0.md`
- `docs/30-architecture/activation-admission-posture-v0.md`
- `docs/30-architecture/activation-demand-episode-posture-v0.md`
- `docs/30-architecture/activation-custody-posture-v0.md`
- `docs/30-architecture/activation-work-disposition-posture-v0.md`
- `docs/30-architecture/activation-effect-boundary-posture-v0.md`
- `docs/30-architecture/activation-incarnation-lineage-posture-v0.md`
- `docs/30-architecture/activation-residency-posture-v0.md`
- `docs/30-architecture/activation-state-attachment-posture-v0.md`
- `docs/30-architecture/activation-material-freshness-posture-v0.md`
- `docs/30-architecture/activation-probe-vantage-posture-v0.md`
- `docs/30-architecture/activation-control-verdict-posture-v0.md`
- `docs/30-architecture/activation-traffic-binding-posture-v0.md`
- `docs/30-architecture/activation-live-channel-posture-v0.md`
- `docs/30-architecture/activation-retry-attempt-posture-v0.md`
- `docs/30-architecture/retry-advice-posture-v0.md`
- `docs/30-architecture/retry-advice-witness-schema-v0.md`
- `docs/30-architecture/retry-budget-witness-schema-v0.md`
- `docs/30-architecture/retry-attempt-witness-schema-v0.md`
- `docs/30-architecture/hedge-fate-witness-schema-v0.md`
- `docs/30-architecture/wake-memory-posture-v0.md`
- `docs/30-architecture/readiness-posture-v0.md`
- `docs/30-architecture/dynamic-condition-posture-v0.md`
- `docs/30-architecture/activity-accounting-posture-v0.md`
- `docs/30-architecture/activity-bracket-posture-v0.md`
- `docs/30-architecture/stop-deferral-posture-v0.md`
- `docs/30-architecture/lifecycle-observation-posture-v0.md`
- `docs/30-architecture/status-channel-posture-v0.md`
- `docs/30-architecture/freshness-decay-posture-v0.md`
- `docs/30-architecture/runtime-cycle-witness-posture-v0.md`
- `docs/30-architecture/termination-cause-posture-v0.md`
- `docs/30-architecture/quiesce-posture-v0.md`
- `docs/30-architecture/shell-terminal-integration-posture-v0.md`
- `docs/30-architecture/command-frame-posture-v0.md`
- `docs/30-architecture/observation-confidence-posture-v0.md`
- `docs/30-architecture/action-surface-posture-v0.md`
- `docs/30-architecture/target-anchor-posture-v0.md`
- `docs/30-architecture/context-handoff-posture-v0.md`
- `docs/30-architecture/attention-hint-posture-v0.md`
- `docs/30-architecture/chrome-lane-posture-v0.md`
- `docs/30-architecture/command-guide-posture-v0.md`
- `docs/30-architecture/transcript-landmark-posture-v0.md`
- `docs/30-architecture/context-inheritance-posture-v0.md`
- `docs/30-architecture/spawn-selector-posture-v0.md`
- `docs/30-architecture/transient-promotion-posture-v0.md`
- `docs/30-architecture/approval-rung-posture-v0.md`
- `docs/30-architecture/revision-settlement-posture-v0.md`
- `docs/30-architecture/rollout-generation-proof-posture-v0.md`
- `docs/30-architecture/generation-plan-witness-schema-v0.md`
- `docs/30-architecture/reconfiguration-apply-witness-schema-v0.md`
- `docs/30-architecture/generation-readiness-witness-schema-v0.md`
- `docs/30-architecture/promotion-witness-schema-v0.md`
- `tools/steward_rollout_generation_harness.py`
- `docs/40-verification/rollout-generation-corpus-v0.md`
- `docs/40-verification/README.md`
- `docs/40-verification/minimum-steward-proof-slice.md`
- `docs/40-verification/component-lifecycle-activation-corpus-v0.md`
- `docs/40-verification/control-operation-corpus-v0.md`
- `docs/40-verification/retry-settlement-corpus-v0.md`
- `docs/30-architecture/import-reconciliation-posture-v0.md`
- `docs/30-architecture/import-observation-witness-schema-v0.md`
- `docs/30-architecture/source-appraisal-witness-schema-v0.md`
- `docs/30-architecture/reconciliation-plan-witness-schema-v0.md`
- `docs/30-architecture/reconciliation-decision-witness-schema-v0.md`
- `tools/steward_import_reconciliation_harness.py`
- `docs/40-verification/import-reconciliation-corpus-v0.md`
- `tools/steward_shutdown_harness.py`
- `docs/40-verification/shutdown-settlement-corpus-v0.md`
- `docs/30-architecture/termination-cause-witness-schema-v0.md`
- `docs/30-architecture/escalation-witness-schema-v0.md`
- `docs/30-architecture/drain-witness-schema-v0.md`
- `docs/30-architecture/quiesce-witness-schema-v0.md`
- `tools/steward_lineage_resume_harness.py`
- `tools/steward_retry_settlement_harness.py`
- `docs/40-verification/lineage-resume-corpus-v0.md`
- `docs/30-architecture/resume-reconciliation-witness-schema-v0.md`
- `docs/30-architecture/residency-witness-schema-v0.md`
- `docs/30-architecture/incarnation-lineage-witness-schema-v0.md`
- `docs/30-architecture/runtime-cycle-witness-schema-v0.md`
- `tools/steward_lifecycle_harness.py`
- `tools/steward_governance_harness.py`
- `docs/40-verification/governance-authorization-corpus-v0.md`
- `docs/30-architecture/governance-authorization-posture-v0.md`
- `docs/30-architecture/delegation-warrant-witness-schema-v0.md`
- `docs/30-architecture/operator-review-witness-schema-v0.md`
- `docs/30-architecture/approval-decision-witness-schema-v0.md`
- `docs/30-architecture/authorization-check-witness-schema-v0.md`
- `docs/90-inspirations/lessons-from-the-past.md`
- `docs/90-inspirations/steal-these-ideas.md`
- `docs/90-inspirations/shell-terminal-ideas.md`
- `docs/90-inspirations/slopos-datacube-evaluation.md`

## Editing rules
- Prefer tightening an existing posture doc over creating a new family of docs.
- Keep open questions visible in `trajectory-map.md` and `decision-map.md`.
- If a new external source matters, register a REF and source lock in the same revision.
- Refresh `out/context_pack.md` after changing the top changelog entry.
- Refresh `docs/00-meta/external-source-review-queue.md` with `make source-review-queue` whenever the lock file changes.

## Packaging
- make source-review-queue
- make lint
- make context-pack
- make handoff-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>
