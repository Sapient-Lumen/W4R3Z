# Session working queue

## Purpose
Reduce open-question entropy while working on Steward.

This queue does not close the trajectory map. It clusters live questions by what kind of proof or pressure they need next.

## Question states
| State | Meaning |
| --- | --- |
| candidate | worth tracking, not yet shaped |
| promoted-to-posture | has a posture doc but no executable proof |
| pinned-for-corpus | should add or change a corpus case next |
| deferred | intentionally later; do not expand now |
| merged | folded into a broader surface |
| closed | resolved or superseded |
| blocked-on-SlopOS | waiting for parent primitive convergence |
| blocked-on-implementation-pressure | waiting for real adapter/product pressure |

## Current lanes
### Proof slice now
- CH-COMP v0 closed decode and digest;
- CH-ACTSET v0 closed decode, digest, and allowlist checks;
- activation receipt before readiness;
- restart replay without activation widening;
- runtime-cycle stale action fences;
- retry-attempt canonical-intent mismatch and effect-boundary checks;
- ST-OPREQ and ST-OPRECEIPT closed decode;
- control-operation idempotency, receipt binding, and recovery downgrade checks;
- ST-TBIND and ST-LIVECHAN closed decode;
- channel-binding route/readiness, route/live-channel, channel/effect, resume/continuity, endpoint-redaction, and drain-deadline checks;
- ST-DEMAND, ST-CUSTODY, ST-WORKDISP, and ST-EFFECT closed decode;
- work-path accepted-demand/work-completion, custody/effect-success, local-completion/effect-success, effect-before-work, same-effect-key mismatch, retention-inversion, secret-leakage, and exactly-once flattery checks;
- ST-STATEATT, ST-MATFRESH, ST-PROBE, and ST-CTRLVERDICT closed decode;
- currentness/control attachment-as-freshness, freshness-as-reload, probe-pass-as-serving, verdict-as-route-authority, stale-material traffic-gate, raw path/secret leakage, hidden repair action, and duplicate-key checks;
- ST-RTCYCLE, ST-INCARN, ST-RESIDENCY, and ST-RESUME closed decode;
- lineage/resume cycle-reuse, stale-cycle operation, stale-incarnation operation, residency-as-readiness, resume-as-same-cycle, lossless-continuity, and predecessor-effect-settlement checks;
- ST-RETRYADVICE, ST-RETRYBUDGET, ST-RETRYATTEMPT, and ST-HEDGEFATE closed decode;
- retry-settlement advice-as-reservation, zero-budget-auto-retry, same-key/different-intent replay, transparent-retry-after-commitment, unsafe early-data replay, effect-confirmed-without-effect witness, and hedge-loser no-side-effect flattery checks;
- ST-QUIESCE, ST-DRAIN, ST-ESCALATE, and ST-TERMCAUSE closed decode;
- shutdown-settlement quiesce-as-stopped, quiesce-as-no-live-channels, drained-with-pending-work, drain-as-lossless, escalation-as-stopped, forced-stop-as-clean-exit, termination-as-effect-success, clean-after-kill, successor-readiness, and duplicate-packet-id checks;
- ST-DELEGATE, ST-REVIEW, ST-APPROVAL, and ST-AUTHCHECK closed decode;
- governance authorization owner-label-as-approval, expired-delegation, review-as-authorization, approval-as-execution, digest-mismatch, delegate-mismatch, verb-widening, and effect-success flattery checks;
- schema/corpus coverage guard requiring every registered machine packet profile to have at least one accept and one reject case;
- ST-RECEIPTCHAIN, ST-REDACTION, ST-EXPORTBUNDLE, and ST-REPLAYOBS closed decode;
- receipt-transport chain-head binding, redaction binding, export-as-authority, replay-currentness, replay-missing-digest, and partial-replay downgrade checks;
- ST-IMPORT, ST-SRCAPPRAISE, ST-RECONPLAN, and ST-RECONDECISION closed decode;
- import-reconciliation redaction gates, sorted receipt digests, currentness refusal, source-appraisal use limits, local-witness requirements, quarantine/adoption fences, and import-to-operation-execution refusal checks;
- ST-LOCALOBS, ST-OBSAPPRAISE, ST-OBSCURSOR, and ST-OBSATTACH closed decode;
- local-observation raw-host-id rejection, currentness/readiness flattery, cursor-as-drain, expired-appraisal use, local-only native-witness refusal, attachment-without-appraisal rejection, adapter-green-as-current-state rejection, and duplicate-observation-id checks;
- ST-WITCARD, ST-ACTIONAFFORD, ST-STATUSBARRIER, and ST-SURFAUDIT closed decode;
- witness-surface weak-card-as-settled, card-as-readiness, mutating-affordance-without-authcheck, raw-target action, active-barrier enforcement, audit-as-fix, audit-as-release, and duplicate-key checks;
- ST-OBSSUB, ST-OBSDELIV, ST-OBSSYNC, and ST-OBSGAP closed decode;
- status-channel ambient-subscription, wildcard-view, delivery-as-currentness, sync-over-gap, future-as-of, open-gap-without-refresh, out-of-order-delivery, and subscription-as-mutation checks.
- ST-DEPSPEC, ST-DEPCHECK, ST-DEPGATE, and ST-DEPFALLBACK closed decode;
- dependency-gate topology-authority flattery, dependency-as-readiness, stale-check, gate-as-execution, allow-with-unavailable-hard-dependency, degrade-without-active-fallback, spec/check mismatch, fallback-as-repair, and duplicate-gate-id checks.

State: pinned-for-corpus for additional edge cases, with lifecycle, operation, route/channel, work-path, currentness/control, lineage/resume, retry/hedge settlement, shutdown settlement, governance authorization, receipt-transport, import-reconciliation, local-observation provenance, witness-surface, status-channel, attention-notification, activity-accounting, and dependency-gate packet corpora now executable.

### Boundary docs now
- SlopOS crosswalk;
- companion ownership map;
- Ward/Steward governance boundary;
- adapter membrane;
- receipt minimization;
- manager recovery and reconciliation;
- import reconciliation;
- local observation provenance;
- status-channel proof and observation-subscription settlement;
- attention-notification proof and exact watch/notice/ack settlement;
- dependency-gate proof and dependency/topology non-authority settlement.

State: promoted-to-posture.

### Specimen pressure later
- shell action cards;
- repair-card UX;
- workspace snapshots;
- transfer/media/link surfaces;
- richer admin UI;
- adapter golden traces for systemd, Kubernetes, Envoy, NATS, HTTP Retry-After / 425, gRPC retry / hedging, SDK retry budgets, route proxies, live-channel drains, and local shell surfaces;
- richer witness-surface rendering fixtures that consume operation, governance-authorization, state-attachment, material-freshness, probe-vantage, control-verdict, traffic-binding, live-channel, demand, custody, work-disposition, effect-boundary, retry-advice, retry-budget, retry-attempt, hedge-fate, quiesce, drain, escalation, termination-cause, receipt-transport, import-reconciliation, and local-observation provenance non-implications without strengthening them.

State: deferred unless a lifecycle or operation proof case needs them.

### Do not touch until implementation pressure
- scheduler;
- durable workflow history;
- distributed lease/lock service;
- route compiler;
- retry engine or retry-budget service;
- hedge racing subsystem or distributed idempotency ledger;
- shutdown controller, broker-drain service, signal API, restart engine, or crash analyzer;
- service mesh integration;
- universal dependency graph, topology query language, start-order planner, repair system, or rollback controller;
- universal terminal protocol;
- global RBAC or owner-map engine;
- approval workflow UI or audit product;
- UI framework, remote-control console, release-provenance product, or proof-of-correctness engine beyond the witness-surface packet slice;
- generic evidence export beyond the minimized receipt-transport packet slice;
- global import/trust/provenance/adoption engine beyond the weak import-reconciliation packet slice;
- host inventory, shell telemetry bus, cursor database, subscription firehose, hidden control bus, desktop notification service, reminder/inbox system, macro engine, or local-observation-to-state promotion engine beyond the weak local-observation/status-channel/attention-notification slices.

State: blocked-on-implementation-pressure.

## Working rule
When adding a new open question, immediately assign a state. A question with no state is archive debt.

## Revision 197 note
Preconditions, operation arbitration, deliberate holds, and progress windows now have closed packet profiles and an executable corpus. Near-term follow-up should avoid designing a scheduler, distributed lock, generic queue manager, rollout controller, transaction planner, or policy engine. Instead, pressure-test packet translation against adapter goldens: one stale runtime-cycle precondition, one active maintenance hold that queues restart, one failed precondition that rejects mutation, one progress window held by policy, one deadline-exceeded stall, and one host-specific queued/replaced control operation that must not claim execution.


## Rev0198 follow-up lane — generation rollout adapter goldens
- Translate one config projection into ST-GENPLAN plus ST-MATFRESH without claiming reload.
- Translate one in-place reload into ST-RECONFAPPLY without claiming readiness.
- Translate one canary probe bundle into ST-GENREADY without claiming global readiness.
- Translate one traffic shift into ST-PROMOTION without claiming serving, drain, rollback success, or effect success.
- Keep deployment orchestration, scheduler policy, and compensation workflows out of Steward until implementation pressure proves a tiny seam is necessary.

## Pressure-admission follow-up
- Add adapter golden traces for ST-PRESSURE, ST-HEADROOM, ST-BACKPRESS, and ST-ADMGATE once concrete host/runtime samples are available.
- Keep pressure cards weak: pressure is not failure, headroom is not authority, backpressure is not demand, and gate decisions are not work completion.
- Revisit whether pressure/headroom/backpressure should feed witness-surface bundles before adding any overload-controller behavior.
