# Shutdown-settlement corpus v0

## Purpose
`shutdown-settlement-corpus-v0.jsonl` is Steward's first executable settlement for the shutdown chain:

`quiesce gate → drain boundary → escalation boundary → termination cause`

The corpus proves that gating new work, draining old work or channels, applying stronger intervention, and observing final cycle end can compose as adjacent evidence while refusing the dangerous shortcuts that turn a stop path into clean success, lossless continuity, external effect success, successor readiness, or exactly-once folklore.

## Generator and checker
- Generator/checker: `../../tools/steward_shutdown_harness.py`
- Corpus: `corpora/shutdown-settlement-corpus-v0.jsonl`
- Machine profiles:
  - `../../schemas/st-quiesce-v0.schema.json`
  - `../../schemas/st-drain-v0.schema.json`
  - `../../schemas/st-escalate-v0.schema.json`
  - `../../schemas/st-termcause-v0.schema.json`

Run:

```sh
python3 ../../tools/steward_shutdown_harness.py --write --check
```

From the repository root, `make corpus` regenerates it and `make lint` checks it.

## What the corpus accepts
- A quiesce witness that gates new external demand without claiming stopped or drained truth.
- A component drain witness that cites a quiesce gate and reports `pending_class = none`.
- A clean requested-stop termination after prior quiesce and drain evidence.
- A crash termination without inventing quiesce or drain evidence.
- A force path where deadline-hit drain, applied escalation, and forced termination remain visibly forced rather than clean or lossless.

## What the corpus rejects
- Quiesce promoted into stopped, drained, no-live-channel, no-inflight-work, force-kill, readiness, serving, or effect-success truth.
- No-new-work backed only by observation.
- Drained state with hidden or remaining pending work.
- Component drain completion without a prior quiesce witness in the same flow.
- Drain promoted into lossless continuity, no-side-effect proof, stopped state, or effect success.
- Escalation promoted into stopped, clean exit, graceful exit, lossless continuity, or effect success.
- Grace-expired escalation without elapsed grace and strong force without authority basis.
- Termination promoted into effect success, drain completion, restart success, successor readiness, custody, or lossless continuity.
- Forced stops flattened into clean exits and clean termination after applied kill-level escalation.
- Duplicate JSON keys and duplicate packet ids reused for different canonical packet bytes.

## Boundary
The corpus does not prove a shutdown controller, service manager, signal API, process inventory, connection manager, broker drain protocol, lossless transport, crash analyzer, restart engine, or rollout controller. It proves only that the first closed shutdown packet shapes reject the high-risk collapses that make operational stop paths lie.
