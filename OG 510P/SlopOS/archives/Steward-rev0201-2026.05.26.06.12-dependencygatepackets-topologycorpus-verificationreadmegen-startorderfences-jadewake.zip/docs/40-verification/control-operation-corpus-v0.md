# Control-operation corpus v0

## Purpose
This corpus makes the observe-first admin surface executable. It checks that a reviewed control operation can be requested and receipted without becoming ambient host control, stale-cycle mutation, component-state flattery, recovery currentness, or effect-success folklore.

## Files
- Generator/checker: `../../tools/steward_operation_harness.py`
- Corpus: `corpora/control-operation-corpus-v0.jsonl`
- Request profile: `../../schemas/st-opreq-v0.schema.json`
- Receipt profile: `../../schemas/st-opreceipt-v0.schema.json`

## Covered object profiles
### ST-OPREQ v0
The corpus accepts exact `start` and cycle-fenced `stop` requests and rejects:

- raw PID targets;
- host unit targets;
- `stop` without expected runtime cycle;
- malformed idempotency keys;
- invalid not-before/deadline ordering;
- duplicate JSON keys.

### ST-OPRECEIPT v0
The corpus accepts completed, queued, timed-out, and recovery-unknown receipts and rejects:

- receipts that claim component stopped;
- non-finished receipts with terminal results;
- finished receipts without terminal results;
- completed receipts without operation boundary refs;
- recovery receipts that do not refuse currentness;
- timeout-like receipts that do not refuse component-state implication.

## Covered flows
The flow cases require:

1. A receipt must bind to the exact request digest.
2. The same idempotency key may replay the same canonical request digest.
3. The same idempotency key must reject a different canonical operation intent.
4. Manager recovery may downgrade an in-flight operation to `unknown`.
5. Manager recovery must not preserve pre-recovery queued/running currentness without reconciliation.

## What this proves
The corpus proves only a small safety claim: reviewed lifecycle mutations and their receipts are exact packets with closed decode, stale fences, duplicate suppression, and explicit non-implications.

## What this does not prove
It does not prove that Steward can start or stop real components, that any adapter reports rich operation jobs, that a completed operation changed component state, or that failures are recoverable. Those need future adapter goldens and implementation specimens.
