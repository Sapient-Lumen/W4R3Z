# Activity accounting corpus v0

This deterministic corpus settles the first executable activity-accounting boundary for Steward. It covers `ST-ACTBRACKET v0`, `ST-IDLEHINT v0`, `ST-STOPDEFER v0`, and `ST-ACTACCT v0`.

## What it proves
- activity brackets do not become demand, custody, drain, readiness, serving, keepalive leases, work completion, lossless continuity, or effect success;
- busy/idle/draining hints stay freshness-scoped and do not become stopped state, stop authority, quiescence, drain completion, readiness, serving, currentness, or effect truth;
- stop deferral stays bounded by explicit open activity and cannot outlive bracket freshness or become an immortal keepalive;
- activity accounting stays descriptive and does not become billing, quota debit, pressure, headroom, admission, demand, work completion, or effect success;
- closed accounting cannot settle open brackets, idle cannot be claimed while an open bracket exists for the same runtime cycle, and duplicate bracket ids cannot drift.

## Corpus and checker
- Corpus: `corpora/activity-accounting-corpus-v0.jsonl`
- Checker: `../../tools/steward_activity_accounting_harness.py`

The checker is invoked through `tools/run_corpora.py` and therefore by `make corpus` and `make lint`.
