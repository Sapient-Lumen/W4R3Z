# Currentness/control corpus v0

## Purpose
`currentness-control-corpus-v0.jsonl` is Steward's first executable settlement for the currentness-before-control chain:

`state attachment → material freshness → probe vantage → control verdict`

The corpus proves that attachment, freshness, probe, and verdict witnesses can compose as adjacent evidence while refusing the dangerous shortcuts that turn nearby evidence into stronger lifecycle or routing truth.

## Generator and checker
- Generator/checker: `../../tools/steward_currentness_control_harness.py`
- Corpus: `corpora/currentness-control-corpus-v0.jsonl`
- Machine profiles:
  - `../../schemas/st-stateatt-v0.schema.json`
  - `../../schemas/st-matfresh-v0.schema.json`
  - `../../schemas/st-probe-v0.schema.json`
  - `../../schemas/st-ctrlverdict-v0.schema.json`

Run:

```sh
python3 ../../tools/steward_currentness_control_harness.py --write --check
```

From the repository root, `make corpus` regenerates it and `make lint` checks it.

## What the corpus accepts
- A projected-material state attachment that remains weaker than material freshness and path authority.
- A snapshot-derived state attachment with explicit rebind pending state.
- Fresh dynamic identity material with version, scope, expiry, and non-implications.
- Revoked token material as useful downgraded evidence.
- A readiness probe pass that remains a probe-vantage witness rather than readiness or serving truth.
- An outside-in timeout with failure hint and no repair authority.
- An advisory eligible control verdict with probe/material basis.
- A withheld traffic gate based on revoked material.
- A composed flow where attachment, freshness, probe, and verdict stay separate.
- A flow where a verdict references a separate traffic-binding witness without becoming route authority.

## What the corpus rejects
- State attachment as raw path authority.
- State attachment as readiness.
- Projected attachment without a material ref.
- Attached state without runtime-cycle or incarnation fence.
- Material freshness packets that leak raw secrets.
- Fresh/current material whose expiry is already in the past.
- Revoked material without a downgrade reason.
- Missing required non-implications.
- Probe pass with stale freshness.
- Probe packets that claim serving.
- Probe failure without failure hint.
- Probe packets that hide repair actions.
- Control verdicts claiming route authority or remediation success.
- Unknown verdicts without reasons.
- Flow-level promotion from attachment to material freshness.
- Flow-level promotion from material freshness to reload success.
- Flow-level promotion from probe pass to serving.
- Eligible traffic-gating verdicts based on stale/degraded material without downgrade.
- Duplicate JSON keys in all four packet families.

## Boundary
The corpus does not prove a final storage, material, health, rollout, or routing API. It proves only that the first closed packet shapes reject the high-risk collapses that would make Steward lie at exactly the point operators most need humility.
