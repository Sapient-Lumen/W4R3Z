# Channel-binding corpus v0

## Purpose
This corpus makes Steward's route/channel boundary executable. It checks that traffic-binding witnesses and live-channel witnesses remain closed, digestable, freshness-scoped, and deliberately weak: route facts do not become lifecycle facts, and channel facts do not become route, work, continuity, or effect facts.

## Files
- Generator/checker: `../../tools/steward_channel_binding_harness.py`
- Corpus: `corpora/channel-binding-corpus-v0.jsonl`
- Traffic-binding profile: `../../schemas/st-tbind-v0.schema.json`
- Live-channel profile: `../../schemas/st-livechan-v0.schema.json`

## Covered object profiles
### ST-TBIND v0
The corpus accepts active weighted bindings, mirror/observation-only bindings, and no-new-work drain bindings. It rejects:

- bindings that claim readiness;
- active bindings with no targets;
- missing traffic-binding non-implications;
- negative weights;
- raw pod names in portable target summaries;
- duplicate JSON keys.

### ST-LIVECHAN v0
The corpus accepts draining HTTP/2-like channel witnesses and resumed watch-like witnesses with explicit gap ambiguity. It rejects:

- resume-as-lossless claims;
- channel packets that claim effect success;
- started drains without a deadline;
- raw bearer material;
- duplicate JSON keys.

## Covered flows
The flow cases require:

1. A route can move new demand while an old live channel drains.
2. A traffic-binding event cannot be promoted into readiness.
3. `no_new_work` binding does not prove existing live channels are gone.
4. Route drain and live-channel drain can coexist as adjacent weak witnesses.
5. Live-channel survival, drain, or close cannot claim external effect success.
6. Effect-boundary evidence may coexist with channel evidence, but remains a separate proof object.

## What this proves
The corpus proves only a narrow safety claim: selected route and channel witness packets reject the most dangerous semantic collapses around readiness, serving, live-channel fate, effect success, lossless continuity, and host endpoint leakage.

## What this does not prove
It does not prove that Steward implements routing, drains real transports, manages endpoints, preserves sessions, resumes watches without loss, or can infer application success from transport closure. Those need future adapter golden traces and implementation specimens.
