# Witness surface corpus v0

## Purpose
This deterministic corpus makes the human-facing witness surface executable. It proves that cards, buttons, barriers, and audit/refactor records can summarize evidence without strengthening it into readiness, serving, currentness, authorization, execution, or effect success.

## Packet profiles covered

- `ST-WITCARD v0` — rendered witness card with explicit caveats, missing stronger witnesses, downgrade class, and non-implications.
- `ST-ACTIONAFFORD v0` — visible action affordance bound to exact target class, request digest, authcheck ref, stale fences, and non-execution semantics.
- `ST-STATUSBARRIER v0` — stale/evidence barrier that blocks risky verbs without becoming currentness truth.
- `ST-SURFAUDIT v0` — audit/refactor witness for surfaces and cube hygiene without becoming a fix, authority, release, or proof of correctness.

## Flow pressure covered
The corpus includes accept and reject cases for:

- weak observation cards requiring missing stronger witnesses;
- weak cards refusing settled headlines;
- action affordances requiring authcheck, exact operation digest, stale fences, and review before mutating enablement;
- raw PID/host target rejection;
- blocking barriers requiring blocked verbs plus stale refs or refresh requirements;
- clear barriers blocking no verbs;
- active barriers preventing enabled mutating actions that ignore them;
- audit/refactor records naming findings, required changes, and changed refs;
- card-as-readiness, affordance-as-execution, and audit-as-fix flattery rejection.

## Generated corpus
The JSONL corpus is [`corpora/witness-surface-corpus-v0.jsonl`](corpora/witness-surface-corpus-v0.jsonl).

Regenerate and check it with:

```sh
python3 tools/steward_witness_surface_harness.py --write --check
```

`make corpus` and `make lint` both run this harness.
