# Receipt transport corpus v0

## Purpose
This corpus checks Steward's receipt/evidence transport seam. It prevents chained receipts, redaction commitments, export bundles, and replay observations from becoming authority, currentness, freshness, complete history, work completion, or effect-success claims.

The corpus is generated and checked by `../../tools/steward_receipt_transport_harness.py`.

## Packet families
- `ST-RECEIPTCHAIN v0` — digest-linked receipt chain checkpoints.
- `ST-REDACTION v0` — minimized projection and stripped-class commitments.
- `ST-EXPORTBUNDLE v0` — exported evidence manifests bound to redaction and chain-head evidence.
- `ST-REPLAYOBS v0` — replay/import verification observations.

## Covered positive cases
- a genesis receipt-chain checkpoint;
- a redaction witness that explicitly strips bearer/token material classes;
- an export bundle bound to a chain head, sorted included receipt digests, and redaction digest;
- a verified replay observation for all exported receipt digests;
- a partial replay observation that is explicitly downgraded with a gap reason.

## Covered rejection cases
The corpus rejects:

- receipt chain as authority;
- duplicate JSON keys;
- redaction without secret/bearer/token stripped-class coverage;
- unsorted export digest lists;
- replay as currentness;
- chain gaps without downgrade reason;
- previous-head mismatch;
- export without a known redaction packet;
- redaction digest mismatch;
- export-as-authority event claims;
- replay export digest mismatch;
- verified replay missing exported receipt digests;
- chain id and ordinal reuse for different canonical bytes.

## Non-claims
The corpus does not prove global audit correctness, complete history, organizational authority, external storage integrity, release provenance, witness-card UX, or any real adapter implementation. It only proves that selected evidence transport packets remain closed, digest-bound, minimized, and non-authoritative.

## Regeneration
Run:

```text
python3 tools/steward_receipt_transport_harness.py --write --check
```

`make corpus` and `make lint` run this harness.
