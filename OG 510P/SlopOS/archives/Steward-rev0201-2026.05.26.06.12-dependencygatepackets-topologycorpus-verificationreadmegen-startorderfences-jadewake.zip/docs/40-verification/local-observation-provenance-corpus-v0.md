# Local observation provenance corpus v0

## Purpose
This deterministic corpus makes the local observation membrane executable. It proves that host-manager, orchestrator, adapter, shell, file watcher, and cursor observations can become weak evidence or recheck prompts without becoming native Steward currentness, readiness, serving, freshness, authority, operation execution, demand drain, or effect success.

## Packet profiles covered
- `ST-LOCALOBS v0` — weak local observation without raw substrate handles.
- `ST-OBSAPPRAISE v0` — source/scope appraisal for limited weak use.
- `ST-OBSCURSOR v0` — observation stream cursor and gap witness.
- `ST-OBSATTACH v0` — local decision to attach, refuse, quarantine, or recheck an observation.

## Flow pressure covered
The corpus includes accept and reject cases for:
- host-manager active observations kept weak;
- raw systemd unit, pod, container, PID, path, endpoint, and token field rejection;
- required non-implications for authority, currentness, freshness, readiness, serving, execution, and effect success;
- source appraisal refusing current-state use;
- expired appraisal refusal;
- cursor gaps requiring downgrade reasons;
- cursor advance refusing demand-drained claims;
- weak-basis attachment requiring non-observation native witness requirements;
- attachment without appraisal rejection;
- adapter-green-as-current-state rejection;
- duplicate observation id reuse with different canonical bytes rejection.

## Generated corpus
The JSONL corpus is [`corpora/local-observation-provenance-corpus-v0.jsonl`](corpora/local-observation-provenance-corpus-v0.jsonl).

Regenerate and check it with:

```sh
python3 tools/steward_local_observation_harness.py --write --check
```

`make corpus` and `make lint` both run this harness.
