# Component lifecycle activation corpus v0

## Purpose
This corpus is the first narrow executable proof artifact for Steward. It exists to catch semantic drift where adjacent evidence impersonates stronger lifecycle truth.

The corpus is generated and checked by `../../tools/steward_lifecycle_harness.py`.

## Format
The generated file is JSONL:

- each row has a stable `case_id`;
- `kind = schema` rows validate CH-COMP or CH-ACTSET objects;
- `kind = lifecycle` rows validate witness sequences;
- `expect = accept` cases must pass;
- `expect = reject` cases must fail for the intended class of mistake.

The harness also verifies the JSONL rendering is deterministic. Manual edits to the corpus must be made by changing the harness and re-emitting the corpus.

## Current coverage
The v0 corpus covers:

- closed-world CH-COMP decode;
- CH-COMP digest formation;
- shell-command text rejection in `entry`;
- host-manager field rejection;
- CH-ACTSET closed decode;
- CH-ACTSET digest formation;
- duplicate key rejection;
- raw bearer material rejection;
- activation set allowlist checks against the component manifest;
- spawn not implying readiness;
- readiness not preceding activation receipt;
- restart replay with same envelope;
- restart widening rejection;
- runtime-cycle stale-action rejection;
- stop-request versus stopped boundary;
- quiesce versus force-kill boundary;
- adapter observation as weak evidence only;
- material presence versus freshness;
- traffic binding versus readiness;
- retry same-key/canonical-intent matching;
- retry-after as advice, not reservation;
- effect success requiring an effect-boundary witness;
- hedge-loser ambiguity.

## Case count
The v0 generated corpus contains 29 cases: 10 schema cases and 19 lifecycle cases.

## Regeneration
Run:

```sh
python3 tools/steward_lifecycle_harness.py --write --check
```

Then run:

```sh
make lint
```

## Non-goals
This corpus is not a model checker, scheduler, RPC simulator, service mesh test, Kubernetes conformance test, systemd conformance test, broker emulator, or exactly-once proof. It only exercises Steward's first canonical lifecycle truth boundaries.

## References
REF-GRPC-RETRY; REF-GRPC-HEDGING; REF-HTTP-RFC9110; REF-RFC8470-EARLY-DATA; REF-K8S-POD-LIFECYCLE; REF-K8S-CONTAINER-LIFECYCLE-HOOKS; REF-SYSTEMD-FDSTORE; REF-ENVOY-HTTP-ROUTING; REF-NATS-DRAIN; REF-TEMPORAL-EVENT-HISTORY.
