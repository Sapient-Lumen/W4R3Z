# Attention-notification corpus v0

## Purpose
This corpus makes Steward's attention/notification seam executable.

It checks that attention hints, exact watches, notification delivery attempts, and attention acknowledgements do not collapse into lifecycle truth, authorization, execution, user-read proof, or resolution.

## Packet families
- `ST-ATTNHINT v0`
- `ST-ATTNWATCH v0`
- `ST-NOTICE v0`
- `ST-ATTNACK v0`

## Positive cases
- exact background frame-finished hint;
- exact user-armed watch;
- toast delivery with reveal/dismiss actions only;
- stale notification downgrade for an expired watch;
- reveal acknowledgement;
- watch → hint → notice → ack flow.

## Negative cases
- ambient pane/current terminal anchors;
- active hint with already-past stale boundary;
- watch carrying hidden automation;
- armed watch already containing a matched hint;
- notification action that tries to restart or otherwise mutate lifecycle;
- notice claiming user-seen/read or resolution;
- stale notice without downgrade reason;
- notice without watch or hint;
- notification before hint;
- acknowledgement without notice;
- acknowledgement as resolution;
- watch as authorization;
- duplicate notice id reused for different canonical bytes.

## Command
`python3 tools/steward_attention_notification_harness.py --write --check`
