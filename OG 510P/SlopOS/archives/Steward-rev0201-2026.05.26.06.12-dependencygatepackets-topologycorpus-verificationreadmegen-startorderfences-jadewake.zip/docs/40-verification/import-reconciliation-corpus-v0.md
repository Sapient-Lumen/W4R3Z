# Import reconciliation corpus v0

## Purpose
This deterministic corpus makes the import/reconciliation membrane executable. It proves that imported evidence can be useful without becoming live authority, current lifecycle state, freshness, readiness, serving, operation execution, or effect success.

## Packet profiles covered
- `ST-IMPORT v0` — import observation and quarantine/release state.
- `ST-SRCAPPRAISE v0` — lifecycle-scoped source appraisal.
- `ST-RECONPLAN v0` — local reconciliation proposal and downgrade requirements.
- `ST-RECONDECISION v0` — local use decision for imported evidence.

## Flow pressure covered
The corpus includes accept and reject cases for:
- imported receipt digest sorting and duplicate-free canonical binding;
- accepted imports requiring known minimized redaction and no unresolved gaps;
- imported evidence refusing current-state claims;
- source appraisal refusing current-state or mutation-authority use;
- appraisal expiry and downgrade reasons;
- ready reconciliation plans requiring local witnesses and recheck horizons;
- reconciliation plans refusing lifecycle mutation verbs;
- gapped plans requiring downgrade reasons;
- weak-basis decisions requiring local witnesses;
- history adoption staying history scoped;
- decision-without-plan rejection;
- quarantined import preventing ready plans and weak-basis adoption;
- import reconciliation refusing lifecycle operation execution.

## Generated corpus
The JSONL corpus is [`corpora/import-reconciliation-corpus-v0.jsonl`](corpora/import-reconciliation-corpus-v0.jsonl).

Regenerate and check it with:

```sh
python3 tools/steward_import_reconciliation_harness.py --write --check
```

`make corpus` and `make lint` both run this harness.
