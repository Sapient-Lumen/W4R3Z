# Verification

This directory contains Steward's executable proof slices.

- `minimum-steward-proof-slice.md` — why the narrow executable slices exist and what they are allowed to prove.
- `component-lifecycle-activation-corpus-v0.md` — CH-COMP / CH-ACTSET / component lifecycle activation corpus v0 description.
- `control-operation-corpus-v0.md` — ST-OPREQ / ST-OPRECEIPT / control operation corpus v0 description.
- `coordination-gate-corpus-v0.md` — ST-PRECOND / ST-OPARBIT / ST-HOLD / ST-PROGRESS / coordination gate corpus v0 description.
- `pressure-admission-corpus-v0.md` — ST-PRESSURE / ST-HEADROOM / ST-BACKPRESS / ST-ADMGATE / pressure admission corpus v0 description.
- `activity-accounting-corpus-v0.md` — ST-ACTBRACKET / ST-IDLEHINT / ST-STOPDEFER / ST-ACTACCT / activity accounting corpus v0 description.
- `dependency-gate-corpus-v0.md` — ST-DEPSPEC / ST-DEPCHECK / ST-DEPGATE / ST-DEPFALLBACK / dependency gate corpus v0 description.
- `channel-binding-corpus-v0.md` — ST-TBIND / ST-LIVECHAN / channel binding corpus v0 description.
- `demand-custody-effect-corpus-v0.md` — ST-DEMAND / ST-CUSTODY / ST-WORKDISP / ST-EFFECT / demand custody effect corpus v0 description.
- `currentness-control-corpus-v0.md` — ST-STATEATT / ST-MATFRESH / ST-PROBE / ST-CTRLVERDICT / currentness control corpus v0 description.
- `rollout-generation-corpus-v0.md` — ST-GENPLAN / ST-RECONFAPPLY / ST-GENREADY / ST-PROMOTION / rollout generation corpus v0 description.
- `lineage-resume-corpus-v0.md` — ST-RTCYCLE / ST-INCARN / ST-RESIDENCY / ST-RESUME / lineage resume corpus v0 description.
- `retry-settlement-corpus-v0.md` — ST-RETRYADVICE / ST-RETRYBUDGET / ST-RETRYATTEMPT / ST-HEDGEFATE / retry settlement corpus v0 description.
- `shutdown-settlement-corpus-v0.md` — ST-QUIESCE / ST-DRAIN / ST-ESCALATE / ST-TERMCAUSE / shutdown settlement corpus v0 description.
- `governance-authorization-corpus-v0.md` — ST-DELEGATE / ST-REVIEW / ST-APPROVAL / ST-AUTHCHECK / governance authorization corpus v0 description.
- `receipt-transport-corpus-v0.md` — ST-RECEIPTCHAIN / ST-REDACTION / ST-EXPORTBUNDLE / ST-REPLAYOBS / receipt transport corpus v0 description.
- `import-reconciliation-corpus-v0.md` — ST-IMPORT / ST-SRCAPPRAISE / ST-RECONPLAN / ST-RECONDECISION / import reconciliation corpus v0 description.
- `local-observation-provenance-corpus-v0.md` — ST-LOCALOBS / ST-OBSAPPRAISE / ST-OBSCURSOR / ST-OBSATTACH / local observation provenance corpus v0 description.
- `witness-surface-corpus-v0.md` — ST-WITCARD / ST-ACTIONAFFORD / ST-STATUSBARRIER / ST-SURFAUDIT / witness surface corpus v0 description.
- `status-channel-corpus-v0.md` — ST-OBSSUB / ST-OBSDELIV / ST-OBSSYNC / ST-OBSGAP / status channel corpus v0 description.
- `attention-notification-corpus-v0.md` — ST-ATTNHINT / ST-ATTNWATCH / ST-NOTICE / ST-ATTNACK / attention notification corpus v0 description.
- `corpora/component-lifecycle-activation-corpus-v0.jsonl` — deterministic generated component lifecycle activation corpus v0 checked by lint.
- `corpora/control-operation-corpus-v0.jsonl` — deterministic generated control operation corpus v0 checked by lint.
- `corpora/coordination-gate-corpus-v0.jsonl` — deterministic generated coordination gate corpus v0 checked by lint.
- `corpora/pressure-admission-corpus-v0.jsonl` — deterministic generated pressure admission corpus v0 checked by lint.
- `corpora/activity-accounting-corpus-v0.jsonl` — deterministic generated activity accounting corpus v0 checked by lint.
- `corpora/dependency-gate-corpus-v0.jsonl` — deterministic generated dependency gate corpus v0 checked by lint.
- `corpora/channel-binding-corpus-v0.jsonl` — deterministic generated channel binding corpus v0 checked by lint.
- `corpora/demand-custody-effect-corpus-v0.jsonl` — deterministic generated demand custody effect corpus v0 checked by lint.
- `corpora/currentness-control-corpus-v0.jsonl` — deterministic generated currentness control corpus v0 checked by lint.
- `corpora/rollout-generation-corpus-v0.jsonl` — deterministic generated rollout generation corpus v0 checked by lint.
- `corpora/lineage-resume-corpus-v0.jsonl` — deterministic generated lineage resume corpus v0 checked by lint.
- `corpora/retry-settlement-corpus-v0.jsonl` — deterministic generated retry settlement corpus v0 checked by lint.
- `corpora/shutdown-settlement-corpus-v0.jsonl` — deterministic generated shutdown settlement corpus v0 checked by lint.
- `corpora/governance-authorization-corpus-v0.jsonl` — deterministic generated governance authorization corpus v0 checked by lint.
- `corpora/receipt-transport-corpus-v0.jsonl` — deterministic generated receipt transport corpus v0 checked by lint.
- `corpora/import-reconciliation-corpus-v0.jsonl` — deterministic generated import reconciliation corpus v0 checked by lint.
- `corpora/local-observation-provenance-corpus-v0.jsonl` — deterministic generated local observation provenance corpus v0 checked by lint.
- `corpora/witness-surface-corpus-v0.jsonl` — deterministic generated witness surface corpus v0 checked by lint.
- `corpora/status-channel-corpus-v0.jsonl` — deterministic generated status channel corpus v0 checked by lint.
- `corpora/attention-notification-corpus-v0.jsonl` — deterministic generated attention notification corpus v0 checked by lint.

The verification material intentionally avoids proving that Steward is a service manager, scheduler, broker, workflow engine, shell product, desktop notification framework, topology authority, or deployment controller. It proves that selected registered packet families do not collapse into each other or into stronger lifecycle truth: `CH-COMP`, `CH-ACTSET`, `ST-OPREQ`, `ST-OPRECEIPT`, `ST-PRECOND`, `ST-OPARBIT`, `ST-HOLD`, `ST-PROGRESS`, `ST-PRESSURE`, `ST-HEADROOM`, `ST-BACKPRESS`, `ST-ADMGATE`, `ST-ACTBRACKET`, `ST-IDLEHINT`, `ST-STOPDEFER`, `ST-ACTACCT`, `ST-DEPSPEC`, `ST-DEPCHECK`, `ST-DEPGATE`, `ST-DEPFALLBACK`, `ST-TBIND`, `ST-LIVECHAN`, `ST-DEMAND`, `ST-CUSTODY`, `ST-WORKDISP`, `ST-EFFECT`, `ST-STATEATT`, `ST-MATFRESH`, `ST-PROBE`, `ST-CTRLVERDICT`, `ST-GENPLAN`, `ST-RECONFAPPLY`, `ST-GENREADY`, `ST-PROMOTION`, `ST-RTCYCLE`, `ST-INCARN`, `ST-RESIDENCY`, `ST-RESUME`, `ST-RETRYADVICE`, `ST-RETRYBUDGET`, `ST-RETRYATTEMPT`, `ST-HEDGEFATE`, `ST-QUIESCE`, `ST-DRAIN`, `ST-ESCALATE`, `ST-TERMCAUSE`, `ST-DELEGATE`, `ST-REVIEW`, `ST-APPROVAL`, `ST-AUTHCHECK`, `ST-RECEIPTCHAIN`, `ST-REDACTION`, `ST-EXPORTBUNDLE`, `ST-REPLAYOBS`, `ST-IMPORT`, `ST-SRCAPPRAISE`, `ST-RECONPLAN`, `ST-RECONDECISION`, `ST-LOCALOBS`, `ST-OBSAPPRAISE`, `ST-OBSCURSOR`, `ST-OBSATTACH`, `ST-WITCARD`, `ST-ACTIONAFFORD`, `ST-STATUSBARRIER`, `ST-SURFAUDIT`, `ST-OBSSUB`, `ST-OBSDELIV`, `ST-OBSSYNC`, `ST-OBSGAP`, `ST-ATTNHINT`, `ST-ATTNWATCH`, `ST-NOTICE`, `ST-ATTNACK`.
