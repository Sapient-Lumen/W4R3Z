# Lineage/resume corpus v0

## Purpose
`lineage-resume-corpus-v0.jsonl` is Steward's first executable settlement for the turnover and reconciliation chain:

`runtime cycle → incarnation lineage → residency → resume/reconciliation`

The corpus proves that restart, hot replacement, manager recovery, restore ancestry, and residency observations can compose as adjacent evidence while refusing the dangerous shortcuts that turn a reused name, a running host object, a warm resident allocation, or a replayed activation envelope into lifecycle success.

## Generator and checker
- Generator/checker: `../../tools/steward_lineage_resume_harness.py`
- Corpus: `corpora/lineage-resume-corpus-v0.jsonl`
- Machine profiles:
  - `../../schemas/st-rtcycle-v0.schema.json`
  - `../../schemas/st-incarn-v0.schema.json`
  - `../../schemas/st-residency-v0.schema.json`
  - `../../schemas/st-resume-v0.schema.json`

Run:

```sh
python3 ../../tools/steward_lineage_resume_harness.py --write --check
```

From the repository root, `make corpus` regenerates it and `make lint` checks it.

## What the corpus accepts
- A runtime-cycle witness with exact manifest/activation digests and no host-handle export.
- A successor incarnation that names a predecessor while refusing work/effect fate.
- Active residency bound to a scoped location/pool ref and cycle/incarnation fence.
- Frozen residency with explicit restore ancestry.
- Restart activation replay into a new runtime cycle and new incarnation.
- Manager recovery that downgrades present-tense live state to explicit unknown instead of inventing continuity.
- An accepted operation that targets the current runtime cycle and current incarnation.

## What the corpus rejects
- PID-bearing runtime-cycle packets.
- Terminal cycle observations without end cause.
- Runtime-cycle witnesses claiming incarnation currentness.
- Self-predecessor incarnation lineage.
- Current-ish incarnation lineage without runtime-cycle fence.
- Active residency without incarnation or cycle fence.
- Host pod/node/allocation identifiers as portable residency truth.
- Resume packets claiming same runtime cycle after turnover.
- Resume packets claiming losslessness or exactly-once continuity.
- Gap ambiguity without a downgrade reason.
- Reusing a terminated cycle id as a later active run.
- Accepted stale-cycle or stale-incarnation operations.
- Residency promoted to readiness.
- Resume promoted to same-cycle identity.
- Successor incarnation promoted into predecessor work/effect settlement.

## Boundary
The corpus does not prove a final lifecycle manager, scheduler, checkpoint system, hot-restart protocol, or durable replay engine. It proves only that the first closed turnover/reconciliation packet shapes reject the high-risk collapses that would make Steward lie when names, processes, resident allocations, or resume cursors outlive their original meaning.
