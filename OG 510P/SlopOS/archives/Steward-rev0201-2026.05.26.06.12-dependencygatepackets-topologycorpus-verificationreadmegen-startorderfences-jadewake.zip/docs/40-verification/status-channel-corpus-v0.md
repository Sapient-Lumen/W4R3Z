# Status channel corpus v0

## Purpose
This deterministic corpus makes Steward's observation subscription/status-channel seam executable. It proves that accepted subscriptions, delivered batches, sync markers, and continuity gaps can help UIs follow Steward without becoming current lifecycle truth or a hidden control bus.

## Packet profiles covered

- `ST-OBSSUB v0` — bounded subscription to an explicit subject/view.
- `ST-OBSDELIV v0` — status-channel delivery batch with sequence, sorted refs, cursor-after, redaction refs, and drop state.
- `ST-OBSSYNC v0` — exact-view sync marker, initial snapshot marker, partial-window marker, or resync-required marker.
- `ST-OBSGAP v0` — open/cleared continuity gap and resync barrier.

## Flow pressure covered
The corpus includes accept and reject cases for:

- explicit snapshot-then-stream subscriptions;
- ambient current-pane subscription rejection;
- wildcard `all` event-class rejection;
- delivered-batch sorted-ref requirements;
- delivery drop state and dropped-count consistency;
- duplicate JSON key rejection;
- sync markers refusing known gaps;
- `as_of` future-time rejection;
- open gap barriers requiring mutating-verb blocks and refreshes;
- subscription-before-delivery ordering;
- delivery-as-current-state flattery rejection;
- synced-through-over-open-gap rejection;
- overlapping delivery sequence rejection;
- subscription-as-mutation rejection.

## Generated corpus
The JSONL corpus is [`corpora/status-channel-corpus-v0.jsonl`](corpora/status-channel-corpus-v0.jsonl).

Regenerate and check it with:

```sh
python3 tools/steward_status_channel_harness.py --write --check
```

`make corpus` and `make lint` both run this harness through the shared harness registry.
