# Pressure admission corpus v0

This deterministic corpus settles the first executable pressure/admission boundary for Steward. It covers `ST-PRESSURE v0`, `ST-HEADROOM v0`, `ST-BACKPRESS v0`, and `ST-ADMGATE v0`.

## What it proves
- scoped pressure does not become failure, readiness, serving, admission, execution, autoscale, repair, or effect success;
- spendable headroom does not become approval, authorization, reservation, retry grant, admission, execution, readiness, serving, or effect success;
- backpressure does not become demand acceptance, custody, work completion, retry reservation, readiness, serving, execution, or effect success;
- admission gates do not become authority, approval, demand acceptance, custody, work completion, readiness, serving, execution, or external effect truth;
- known meters keep bounded freshness and arithmetic consistency;
- non-allow gates need exact pressure/headroom/backpressure basis;
- allow gates cannot cite exhausted headroom or contradictory blocking backpressure.

## Corpus and checker
- Corpus: `corpora/pressure-admission-corpus-v0.jsonl`
- Checker: `../../tools/steward_pressure_admission_harness.py`

The checker is invoked through `tools/run_corpora.py` and therefore by `make corpus` and `make lint`.
