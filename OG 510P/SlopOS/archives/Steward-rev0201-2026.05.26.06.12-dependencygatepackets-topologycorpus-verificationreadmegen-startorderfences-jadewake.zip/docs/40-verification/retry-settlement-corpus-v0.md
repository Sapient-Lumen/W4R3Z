# Retry-settlement corpus v0

## Purpose
`retry-settlement-corpus-v0.jsonl` is Steward's first executable settlement for the retry and hedge chain:

`retry advice → retry budget → retry attempt → hedge fate`

The corpus proves that follow-up timing, budget availability, attempt safety, commitment boundaries, idempotency/effect-key matching, early-data replay risk, and hedge winner/loser fate can compose as adjacent evidence while refusing the dangerous shortcuts that turn a retry into success or a cancellation into no-side-effect proof.

## Generator and checker
- Generator/checker: `../../tools/steward_retry_settlement_harness.py`
- Corpus: `corpora/retry-settlement-corpus-v0.jsonl`
- Machine profiles:
  - `../../schemas/st-retryadvice-v0.schema.json`
  - `../../schemas/st-retrybudget-v0.schema.json`
  - `../../schemas/st-retryattempt-v0.schema.json`
  - `../../schemas/st-hedgefate-v0.schema.json`

Run:

```sh
python3 ../../tools/steward_retry_settlement_harness.py --write --check
```

From the repository root, `make corpus` regenerates it and `make lint` checks it.

## What the corpus accepts
- Retry advice carrying a not-before hint as advice only.
- Constrained or exhausted retry budget witnesses that affect automatic retry without becoming capacity or route truth.
- Transparent retry with transport-not-seen / commitment-not-crossed evidence.
- Idempotent replay under the same canonical intent digest.
- Pushback-delayed attempts linked to advice and budget witnesses.
- Budget-exhausted attempts that block automation without settling work or effects.
- A 425 / early-data-risk path retried after handshake rather than in early data again.
- A hedge winner with losing attempts still duplicate-possible.

## What the corpus rejects
- Retry advice promoted into reservation, grant, admission, readiness, serving, effect success, or retry success.
- Not-before values in the past, hidden delays on `no_hint`, and duplicate JSON keys.
- Zero or exhausted budgets that allow automatic retry.
- Budget observations promoted into route authority or admission.
- Transparent retry after response/application commitment boundary.
- External-effect-confirmed attempts without adjacent effect witness refs.
- Same idempotency or effect key reused for different canonical intent.
- Unsafe early-data replay and retry after 425 sent in early data again.
- Hedge loser cancellation promoted into no-side-effect proof.
- All-resolved hedge settlement while losers remain in-flight, unknown, or duplicate-possible.
- Exactly-once, no-duplicate, effect-success, route-authority, readiness, custody, or work-completion flattery.

## Boundary
The corpus does not prove a retry engine, RPC framework, quota service, broker, service mesh, durable queue, workflow engine, hedge-racing subsystem, distributed idempotency ledger, or exactly-once effect plane. It proves only that the first closed retry/hedge packet shapes reject the high-risk collapses that make operational retry surfaces lie.
