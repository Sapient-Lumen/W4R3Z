# Coordination-gate corpus v0

## Purpose
This corpus makes Steward's coordination-gate seam executable.

It checks that preconditions, operation arbitration, deliberate holds, and progress windows help explain why lifecycle work is allowed, waiting, blocked, held, or stalled without collapsing into authorization, execution, currentness, readiness, serving, work completion, or effect success.

## Packet families
- `ST-PRECOND v0`
- `ST-OPARBIT v0`
- `ST-HOLD v0`
- `ST-PROGRESS v0`

## Positive cases
- satisfied runtime-cycle precondition;
- rejected arbitration caused by failed precondition;
- queued arbitration behind an active hold;
- active maintenance hold that blocks selected verbs while allowing observation;
- released hold with a release ref;
- advanced progress that is not readiness;
- held progress past deadline with an active hold;
- stalled progress with a bounded reason;
- precondition → hold → queued arbitration → held progress flow.

## Negative cases
- ambient/current targets;
- precondition-as-authorization;
- satisfied precondition that is already expired;
- queued arbitration with zero queue position;
- arbitration-as-execution or operation result;
- active hold without blocked verbs;
- hold-as-failure/stopped/off;
- released hold without a release ref;
- progress-as-readiness;
- past-deadline progress without held/stalled/unknown downgrade;
- held progress without a known active hold;
- accepted mutating arbitration despite an active blocking hold;
- accepted arbitration using stale preconditions;
- duplicate arbitration id reused for different canonical bytes.

## Command
`python3 tools/steward_coordination_gate_harness.py --write --check`
