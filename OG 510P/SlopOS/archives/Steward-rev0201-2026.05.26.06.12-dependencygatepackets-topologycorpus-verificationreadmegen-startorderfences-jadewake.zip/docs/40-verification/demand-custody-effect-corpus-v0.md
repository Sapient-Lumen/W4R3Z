# Demand-custody-effect corpus v0

## Purpose
This corpus makes Steward's work path executable. It checks that demand episodes, custody, work disposition, and effect boundaries are closed, digestable, and deliberately separate.

The corpus exists because the most dangerous operational lie in this area is a shortcut from `accepted`, `delivered`, `held`, `acknowledged`, or `completed locally` to `external effect succeeded exactly once`.

## Files
- Generator/checker: `../../tools/steward_work_effect_harness.py`
- Corpus: `corpora/demand-custody-effect-corpus-v0.jsonl`
- Demand profile: `../../schemas/st-demand-v0.schema.json`
- Custody profile: `../../schemas/st-custody-v0.schema.json`
- Work-disposition profile: `../../schemas/st-workdisp-v0.schema.json`
- Effect-boundary profile: `../../schemas/st-effect-v0.schema.json`

## Covered object profiles
### ST-DEMAND v0
The corpus accepts cold-start demand admission, runtime-accepted demand with a cycle fence, and timed-out demand with explicit downgrade reason. It rejects missing non-implications, deadline inversion, runtime acceptance without a cycle fence, readiness claims, secret-like text, and duplicate JSON keys.

### ST-CUSTODY v0
The corpus accepts held custody with a lease, delivered-but-unacknowledged handoff, runtime-accepted custody, and lost custody with a reason. It rejects handoff without a transfer boundary, expired-before-observed custody leases, effect-success claims, and unknown custody without a reason.

### ST-WORKDISP v0
The corpus accepts local completion, acknowledgement, and expiry with reason. It rejects local completion without custody evidence, degraded terminal disposition without reason, effect-success claims, and unknown disposition without reason.

### ST-EFFECT v0
The corpus accepts external submission, external confirmation, same-intent replay under an effect key, and explicit ambiguity. It rejects retention expiry before observation, confirmation without external evidence, duplicate outcome without an effect key, exactly-once claims, and missing non-implications.

## Covered flows
The flow cases require:

1. A full chain can carry demand, custody, work, and effect packets without collapsing them.
2. Accepted demand cannot become work completion.
3. Custody cannot settle effect fate.
4. Local work completion cannot claim effect success without an effect-boundary packet.
5. Timeout and lost custody can terminate without hidden effect success.
6. The same effect key may replay the same canonical intent under bounded retention.
7. The same effect key must reject different canonical intent.
8. Effect boundaries that cite work cannot precede the work witness.
9. External confirmation still does not become exactly-once execution.
10. Ambiguous effect state is allowed when stated explicitly.

## What this proves
The corpus proves only a narrow safety claim: selected work-path witnesses reject semantic collapses between admission, custody, local disposition, side-effect boundaries, duplicate suppression, and exactly-once folklore.

## What this does not prove
It does not prove that Steward implements a queue, broker, durable workflow runtime, transaction coordinator, global idempotency ledger, outbox system, saga engine, compensation engine, or exactly-once effect plane. Those need future adapter golden traces and implementation specimens.
