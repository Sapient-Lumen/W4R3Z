# Governance authorization corpus v0

## Purpose
This corpus checks the first Steward governance authorization seam. It prevents lifecycle control from flattening owner labels, delegation hints, reviews, approvals, and authorization gates into one ambient permission story.

The corpus is generated and checked by `../../tools/steward_governance_harness.py`.

## Packet families
- `ST-DELEGATE v0` — scoped delegation warrant evidence.
- `ST-REVIEW v0` — bounded operation-request review evidence.
- `ST-APPROVAL v0` — exact operation-digest approval or denial evidence.
- `ST-AUTHCHECK v0` — Steward authorization gate decision.

## Covered positive cases
- an active non-redelegable delegation warrant for a component stop;
- a preflight review pass with target, reason, idempotency, and host-target checks;
- an approval bound to one exact request digest and warrant basis;
- an allowed authorization check citing delegation, review, and approval packets;
- a denied authorization check when no live warrant evidence exists.

## Covered rejection cases
The corpus rejects:

- owner labels as delegated authority;
- active delegations observed outside their validity window;
- re-delegation flags;
- observe-only delegation carrying mutating verbs;
- duplicate JSON keys;
- review pass without exact target fencing;
- review as authorization;
- stale review posing as pass;
- approval without warrant basis;
- denied approval without reason;
- kill-level approval without break-glass classification;
- approval as execution;
- allowed authorization without approval refs;
- authorization as effect success;
- stale authorization without reason;
- allowed checks using expired delegations;
- approval digest mismatch;
- needs-approval review treated as pass;
- denied approval used as authority;
- delegatee mismatch;
- verb outside delegation;
- authorization as execution;
- duplicate warrant ids reused for different canonical bytes.

## Non-claims
The corpus does not prove global authorization correctness, organizational ownership, Ward policy, RBAC semantics, UI quality, operation execution, stop completion, readiness, serving, custody, drain, or effect settlement.

## Regeneration
Run:

```text
python3 tools/steward_governance_harness.py --write --check
```

`make corpus` and `make lint` run this harness.
