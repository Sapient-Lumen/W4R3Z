#!/usr/bin/env python3
from __future__ import annotations

# Single source of truth for deterministic Steward corpus harnesses.
# Keep this list in the intended execution order: substrate and operation
# gates first, then lifecycle witness packets, then status/surface/attention.
# packet_ids names the machine packet families each harness settles; lint
# checks this against schema-registry rows so registry drift is visible.
HARNESS_ENTRIES = [
    {
        'script': 'tools/steward_lifecycle_harness.py',
        'corpus': 'docs/40-verification/corpora/component-lifecycle-activation-corpus-v0.jsonl',
        'doc': 'docs/40-verification/component-lifecycle-activation-corpus-v0.md',
        'packet_ids': ['CH-COMP', 'CH-ACTSET'],
    },
    {
        'script': 'tools/steward_operation_harness.py',
        'corpus': 'docs/40-verification/corpora/control-operation-corpus-v0.jsonl',
        'doc': 'docs/40-verification/control-operation-corpus-v0.md',
        'packet_ids': ['ST-OPREQ', 'ST-OPRECEIPT'],
    },
    {
        'script': 'tools/steward_coordination_gate_harness.py',
        'corpus': 'docs/40-verification/corpora/coordination-gate-corpus-v0.jsonl',
        'doc': 'docs/40-verification/coordination-gate-corpus-v0.md',
        'packet_ids': ['ST-PRECOND', 'ST-OPARBIT', 'ST-HOLD', 'ST-PROGRESS'],
    },
    {
        'script': 'tools/steward_pressure_admission_harness.py',
        'corpus': 'docs/40-verification/corpora/pressure-admission-corpus-v0.jsonl',
        'doc': 'docs/40-verification/pressure-admission-corpus-v0.md',
        'packet_ids': ['ST-PRESSURE', 'ST-HEADROOM', 'ST-BACKPRESS', 'ST-ADMGATE'],
    },
    {
        'script': 'tools/steward_activity_accounting_harness.py',
        'corpus': 'docs/40-verification/corpora/activity-accounting-corpus-v0.jsonl',
        'doc': 'docs/40-verification/activity-accounting-corpus-v0.md',
        'packet_ids': ['ST-ACTBRACKET', 'ST-IDLEHINT', 'ST-STOPDEFER', 'ST-ACTACCT'],
    },
    {
        'script': 'tools/steward_dependency_gate_harness.py',
        'corpus': 'docs/40-verification/corpora/dependency-gate-corpus-v0.jsonl',
        'doc': 'docs/40-verification/dependency-gate-corpus-v0.md',
        'packet_ids': ['ST-DEPSPEC', 'ST-DEPCHECK', 'ST-DEPGATE', 'ST-DEPFALLBACK'],
    },
    {
        'script': 'tools/steward_channel_binding_harness.py',
        'corpus': 'docs/40-verification/corpora/channel-binding-corpus-v0.jsonl',
        'doc': 'docs/40-verification/channel-binding-corpus-v0.md',
        'packet_ids': ['ST-TBIND', 'ST-LIVECHAN'],
    },
    {
        'script': 'tools/steward_work_effect_harness.py',
        'corpus': 'docs/40-verification/corpora/demand-custody-effect-corpus-v0.jsonl',
        'doc': 'docs/40-verification/demand-custody-effect-corpus-v0.md',
        'packet_ids': ['ST-DEMAND', 'ST-CUSTODY', 'ST-WORKDISP', 'ST-EFFECT'],
    },
    {
        'script': 'tools/steward_currentness_control_harness.py',
        'corpus': 'docs/40-verification/corpora/currentness-control-corpus-v0.jsonl',
        'doc': 'docs/40-verification/currentness-control-corpus-v0.md',
        'packet_ids': ['ST-STATEATT', 'ST-MATFRESH', 'ST-PROBE', 'ST-CTRLVERDICT'],
    },
    {
        'script': 'tools/steward_rollout_generation_harness.py',
        'corpus': 'docs/40-verification/corpora/rollout-generation-corpus-v0.jsonl',
        'doc': 'docs/40-verification/rollout-generation-corpus-v0.md',
        'packet_ids': ['ST-GENPLAN', 'ST-RECONFAPPLY', 'ST-GENREADY', 'ST-PROMOTION'],
    },
    {
        'script': 'tools/steward_lineage_resume_harness.py',
        'corpus': 'docs/40-verification/corpora/lineage-resume-corpus-v0.jsonl',
        'doc': 'docs/40-verification/lineage-resume-corpus-v0.md',
        'packet_ids': ['ST-RTCYCLE', 'ST-INCARN', 'ST-RESIDENCY', 'ST-RESUME'],
    },
    {
        'script': 'tools/steward_retry_settlement_harness.py',
        'corpus': 'docs/40-verification/corpora/retry-settlement-corpus-v0.jsonl',
        'doc': 'docs/40-verification/retry-settlement-corpus-v0.md',
        'packet_ids': ['ST-RETRYADVICE', 'ST-RETRYBUDGET', 'ST-RETRYATTEMPT', 'ST-HEDGEFATE'],
    },
    {
        'script': 'tools/steward_shutdown_harness.py',
        'corpus': 'docs/40-verification/corpora/shutdown-settlement-corpus-v0.jsonl',
        'doc': 'docs/40-verification/shutdown-settlement-corpus-v0.md',
        'packet_ids': ['ST-QUIESCE', 'ST-DRAIN', 'ST-ESCALATE', 'ST-TERMCAUSE'],
    },
    {
        'script': 'tools/steward_governance_harness.py',
        'corpus': 'docs/40-verification/corpora/governance-authorization-corpus-v0.jsonl',
        'doc': 'docs/40-verification/governance-authorization-corpus-v0.md',
        'packet_ids': ['ST-DELEGATE', 'ST-REVIEW', 'ST-APPROVAL', 'ST-AUTHCHECK'],
    },
    {
        'script': 'tools/steward_receipt_transport_harness.py',
        'corpus': 'docs/40-verification/corpora/receipt-transport-corpus-v0.jsonl',
        'doc': 'docs/40-verification/receipt-transport-corpus-v0.md',
        'packet_ids': ['ST-RECEIPTCHAIN', 'ST-REDACTION', 'ST-EXPORTBUNDLE', 'ST-REPLAYOBS'],
    },
    {
        'script': 'tools/steward_import_reconciliation_harness.py',
        'corpus': 'docs/40-verification/corpora/import-reconciliation-corpus-v0.jsonl',
        'doc': 'docs/40-verification/import-reconciliation-corpus-v0.md',
        'packet_ids': ['ST-IMPORT', 'ST-SRCAPPRAISE', 'ST-RECONPLAN', 'ST-RECONDECISION'],
    },
    {
        'script': 'tools/steward_local_observation_harness.py',
        'corpus': 'docs/40-verification/corpora/local-observation-provenance-corpus-v0.jsonl',
        'doc': 'docs/40-verification/local-observation-provenance-corpus-v0.md',
        'packet_ids': ['ST-LOCALOBS', 'ST-OBSAPPRAISE', 'ST-OBSCURSOR', 'ST-OBSATTACH'],
    },
    {
        'script': 'tools/steward_witness_surface_harness.py',
        'corpus': 'docs/40-verification/corpora/witness-surface-corpus-v0.jsonl',
        'doc': 'docs/40-verification/witness-surface-corpus-v0.md',
        'packet_ids': ['ST-WITCARD', 'ST-ACTIONAFFORD', 'ST-STATUSBARRIER', 'ST-SURFAUDIT'],
    },
    {
        'script': 'tools/steward_status_channel_harness.py',
        'corpus': 'docs/40-verification/corpora/status-channel-corpus-v0.jsonl',
        'doc': 'docs/40-verification/status-channel-corpus-v0.md',
        'packet_ids': ['ST-OBSSUB', 'ST-OBSDELIV', 'ST-OBSSYNC', 'ST-OBSGAP'],
    },
    {
        'script': 'tools/steward_attention_notification_harness.py',
        'corpus': 'docs/40-verification/corpora/attention-notification-corpus-v0.jsonl',
        'doc': 'docs/40-verification/attention-notification-corpus-v0.md',
        'packet_ids': ['ST-ATTNHINT', 'ST-ATTNWATCH', 'ST-NOTICE', 'ST-ATTNACK'],
    },
]

HARNESS_SCRIPTS = [entry['script'] for entry in HARNESS_ENTRIES]


def harness_names() -> set[str]:
    return {script.rsplit('/', 1)[-1] for script in HARNESS_SCRIPTS}


def harness_metadata() -> tuple[dict[str, object], ...]:
    return tuple({**entry, 'packet_ids': tuple(entry['packet_ids'])} for entry in HARNESS_ENTRIES)


def harness_packet_map() -> dict[str, tuple[str, ...]]:
    return {entry['script'].rsplit('/', 1)[-1]: tuple(entry['packet_ids']) for entry in HARNESS_ENTRIES}
