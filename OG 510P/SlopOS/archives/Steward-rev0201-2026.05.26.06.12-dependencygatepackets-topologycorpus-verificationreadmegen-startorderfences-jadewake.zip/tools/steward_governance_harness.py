#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/governance-authorization-corpus-v0.jsonl'

ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')
WARRANT_RE = re.compile(r'^del_[a-z0-9]{16}$')
APPROVAL_RE = re.compile(r'^apv_[a-z0-9]{16}$')
REVIEW_RE = re.compile(r'^rvw_[a-z0-9]{16}$')
AUTHZ_RE = re.compile(r'^auth_[a-z0-9]{16}$')
WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authorized', 'claims_approved', 'claims_executed', 'claims_started',
    'claims_stopped', 'claims_quiesced', 'claims_drained', 'claims_ready',
    'claims_serving', 'claims_effect_success', 'claims_component_state',
    'claims_owner_of_record', 'claims_permanent_authority', 'claims_redelegation',
    'authorized', 'approved', 'executed', 'started', 'stopped', 'quiesced',
    'drained', 'ready', 'serving', 'effect_success', 'component_state',
    'owner_label', 'owner', 'role', 'role_name', 'rbac_role', 'group_name',
    'admin', 'superuser', 'sudo', 'root', 'all_components', 'wildcard',
    'latest_matching_service', 'process_name', 'pid', 'ppid', 'pgid', 'cgroup',
    'cgroup_path', 'systemd_unit', 'systemd_job_path', 'pod_name',
    'container_id', 'host_unit', 'node_name', 'allocation_id', 'pane_text',
    'pty_name', 'shell_job', 'token', 'secret', 'raw_secret', 'raw_token',
    'raw_handle', 'bearer', 'credential', 'password', 'cookie', 'authorization',
    'value', 'path', 'raw_path', 'endpoint', 'raw_endpoint', 'url', 'uri',
    'redelegation_allowed', 'can_redelegate', 'delegate_all', 'allow_all',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {
    'steward', 'ward', 'operator', 'automation', 'policy', 'adapter',
    'controller', 'repair_gate', 'supervisor', 'platform',
}
VERBS = {'start', 'stop', 'restart', 'quiesce', 'refresh', 'inspect'}
FORCES = {'none', 'notify', 'soft_stop', 'interrupt', 'terminate', 'kill', 'unknown'}

DELEG_REQUIRED = {
    'schema', 'witness_id', 'warrant_id', 'cid', 'issuer', 'delegator',
    'delegatee', 'scope', 'status', 'effective_from_ms', 'expires_at_ms',
    'observed_at_ms', 'basis_refs', 'caveats', 'non_implications',
}
DELEG_OPTIONAL = {'revocation_ref', 'max_uses', 'remaining_uses', 'unknown_reason'}
DELEG_ALLOWED = DELEG_REQUIRED | DELEG_OPTIONAL
SCOPE_REQUIRED = {'kind', 'cid', 'allowed_verbs', 'max_force'}
SCOPE_OPTIONAL = {'runtime_cycle_ref'}
SCOPE_ALLOWED = SCOPE_REQUIRED | SCOPE_OPTIONAL
DELEG_STATUSES = {'active', 'expired', 'revoked', 'suspended', 'unknown'}
CAVEATS = {
    'no_redelegation', 'approval_required', 'dual_control', 'break_glass_only',
    'no_force', 'observe_only', 'repair_gate_required', 'ticket_required',
    'privacy_minimized', 'budget_required', 'fresh_intent_required',
}
DELEG_NON_IMPLICATIONS = {
    'not-approval', 'not-execution', 'not-effect-success',
    'not-permanent-authority', 'not-redelegation', 'not-owner-of-record',
}

APPROVAL_REQUIRED = {
    'schema', 'witness_id', 'approval_id', 'cid', 'issuer', 'approver',
    'subject_op_ref', 'subject_request_digest', 'decision', 'approval_scope',
    'observed_at_ms', 'valid_until_ms', 'basis_refs', 'required_warrant_refs',
    'non_implications',
}
APPROVAL_OPTIONAL = {'second_approver_ref', 'denial_reason', 'revocation_ref', 'unknown_reason', 'risk_class'}
APPROVAL_ALLOWED = APPROVAL_REQUIRED | APPROVAL_OPTIONAL
APP_SCOPE_REQUIRED = {'cid', 'verb', 'max_force'}
APP_SCOPE_OPTIONAL = {'runtime_cycle_ref'}
APP_SCOPE_ALLOWED = APP_SCOPE_REQUIRED | APP_SCOPE_OPTIONAL
APPROVAL_DECISIONS = {'approved', 'denied', 'needs_review', 'expired', 'revoked', 'unknown'}
RISK_CLASSES = {'ordinary', 'elevated', 'break_glass'}
APPROVAL_NON_IMPLICATIONS = {
    'not-execution', 'not-effect-success', 'not-component-state',
    'not-broad-delegation', 'not-owner-of-record', 'not-redelegation',
}

REVIEW_REQUIRED = {
    'schema', 'witness_id', 'review_id', 'cid', 'issuer', 'reviewer',
    'subject_op_ref', 'subject_request_digest', 'review_type', 'verdict',
    'checklist', 'observed_at_ms', 'basis_refs', 'non_implications',
}
REVIEW_OPTIONAL = {'finding_refs', 'expires_or_recheck_by_ms', 'unknown_reason'}
REVIEW_ALLOWED = REVIEW_REQUIRED | REVIEW_OPTIONAL
REVIEW_TYPES = {'preflight', 'risk', 'repair_gate', 'emergency', 'sibling', 'posture'}
REVIEW_VERDICTS = {'pass', 'block', 'needs_approval', 'needs_repair', 'expired', 'unknown'}
CHECKLIST_ITEMS = {
    'target_fenced', 'reason_present', 'idempotency_bound', 'no_host_target',
    'fresh_intent', 'approval_present', 'drain_plan_present',
    'rollback_plan_present', 'budget_checked', 'privacy_minimized',
}
REVIEW_PASS_REQUIRED = {'target_fenced', 'reason_present', 'idempotency_bound', 'no_host_target'}
REVIEW_NON_IMPLICATIONS = {
    'not-authorization', 'not-approval', 'not-execution',
    'not-effect-success', 'not-component-state',
}

AUTH_REQUIRED = {
    'schema', 'witness_id', 'authz_id', 'cid', 'issuer', 'subject_op_ref',
    'subject_request_digest', 'delegatee', 'verb', 'decision', 'checked_at_ms',
    'basis_refs', 'delegation_refs', 'approval_refs', 'review_refs',
    'non_implications',
}
AUTH_OPTIONAL = {'runtime_cycle_ref', 'denial_reason', 'expires_or_recheck_by_ms', 'break_glass_ref', 'residual_risk', 'unknown_reason'}
AUTH_ALLOWED = AUTH_REQUIRED | AUTH_OPTIONAL
AUTH_DECISIONS = {'allowed', 'denied', 'needs_approval', 'stale', 'unknown'}
AUTH_NON_IMPLICATIONS = {
    'not-execution', 'not-effect-success', 'not-component-state',
    'not-custody', 'not-readiness', 'not-serving',
}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if any(s in lowered for s in ['token=', 'secret=', 'bearer ', 'http://', 'https://', 'password=', 'cookie=']):
        fail(f'{path}: raw bearer, secret, cookie, or endpoint-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_actor(value: Any, path: str) -> None:
    require_pattern(value, ACTOR_RE, path)


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str, id_field: str, id_regex: re.Pattern[str]) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj[id_field], id_regex, f'$.{id_field}')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_scope(value: Any, path: str, cid: str) -> dict[str, Any]:
    scope = require_object(value, path)
    require_closed_keys(scope, SCOPE_ALLOWED, SCOPE_REQUIRED, path)
    if scope['kind'] != 'component':
        fail(f'{path}.kind: only component scope is portable in Steward')
    if scope['cid'] != cid:
        fail(f'{path}.cid: scope cid must equal packet cid')
    verbs = require_string_list(scope['allowed_verbs'], f'{path}.allowed_verbs', regex=REF_RE, maximum=8)
    bad = [v for v in verbs if v not in VERBS]
    if bad:
        fail(f'{path}.allowed_verbs: invalid verb(s) {bad}')
    if not verbs:
        fail(f'{path}.allowed_verbs: must not be empty')
    if scope['max_force'] not in FORCES:
        fail(f'{path}.max_force: invalid force class')
    if 'runtime_cycle_ref' in scope:
        require_pattern(scope['runtime_cycle_ref'], CYCLE_RE, f'{path}.runtime_cycle_ref')
    return scope


def validate_approval_scope(value: Any, path: str, cid: str) -> dict[str, Any]:
    scope = require_object(value, path)
    require_closed_keys(scope, APP_SCOPE_ALLOWED, APP_SCOPE_REQUIRED, path)
    if scope['cid'] != cid:
        fail(f'{path}.cid: approval scope cid must equal packet cid')
    if scope['verb'] not in VERBS:
        fail(f'{path}.verb: invalid')
    if scope['max_force'] not in FORCES:
        fail(f'{path}.max_force: invalid force class')
    if 'runtime_cycle_ref' in scope:
        require_pattern(scope['runtime_cycle_ref'], CYCLE_RE, f'{path}.runtime_cycle_ref')
    return scope


def validate_delegation(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, DELEG_ALLOWED, DELEG_REQUIRED, 'ST-DELEGATE v0', 'warrant_id', WARRANT_RE)
    validate_actor(obj['delegator'], '$.delegator')
    validate_actor(obj['delegatee'], '$.delegatee')
    scope = validate_scope(obj['scope'], '$.scope', obj['cid'])
    if obj['status'] not in DELEG_STATUSES:
        fail('$.status: invalid')
    for field in ('effective_from_ms', 'expires_at_ms', 'observed_at_ms'):
        require_int(obj[field], f'$.{field}', maximum=9_223_372_036_854_775_807)
    if obj['effective_from_ms'] > obj['expires_at_ms']:
        fail('$.effective_from_ms: exceeds expires_at_ms')
    caveats = set(require_string_list(obj['caveats'], '$.caveats', regex=REF_RE, maximum=16))
    bad = sorted(caveats - CAVEATS)
    if bad:
        fail(f'$.caveats: invalid caveat(s) {bad}')
    if 'no_redelegation' not in caveats:
        fail('$.caveats: no_redelegation is required in v0')
    require_non_implications(obj['non_implications'], DELEG_NON_IMPLICATIONS, '$.non_implications')
    if obj['status'] == 'active':
        if obj['observed_at_ms'] < obj['effective_from_ms'] or obj['observed_at_ms'] > obj['expires_at_ms']:
            fail('$.status: active delegation must be observed inside its validity window')
    if obj['status'] == 'expired' and obj['observed_at_ms'] <= obj['expires_at_ms']:
        fail('$.status: expired delegation must be observed after expires_at_ms')
    if obj['status'] == 'revoked' and 'revocation_ref' not in obj:
        fail('$.revocation_ref: required for revoked delegation')
    if obj['status'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown delegation')
    if 'observe_only' in caveats and set(scope['allowed_verbs']) != {'inspect'}:
        fail('$.scope.allowed_verbs: observe_only delegation can only inspect')
    if 'no_force' in caveats and scope['max_force'] not in {'none', 'notify', 'soft_stop'}:
        fail('$.scope.max_force: no_force delegation cannot allow strong intervention')
    if 'max_uses' in obj:
        require_int(obj['max_uses'], '$.max_uses', maximum=10_000)
    if 'remaining_uses' in obj:
        require_int(obj['remaining_uses'], '$.remaining_uses', maximum=10_000)
        if 'max_uses' in obj and obj['remaining_uses'] > obj['max_uses']:
            fail('$.remaining_uses: exceeds max_uses')
    return obj


def validate_approval(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, APPROVAL_ALLOWED, APPROVAL_REQUIRED, 'ST-APPROVAL v0', 'approval_id', APPROVAL_RE)
    validate_actor(obj['approver'], '$.approver')
    require_pattern(obj['subject_op_ref'], REF_RE, '$.subject_op_ref')
    require_pattern(obj['subject_request_digest'], DIGEST_RE, '$.subject_request_digest')
    scope = validate_approval_scope(obj['approval_scope'], '$.approval_scope', obj['cid'])
    if obj['decision'] not in APPROVAL_DECISIONS:
        fail('$.decision: invalid')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', maximum=9_223_372_036_854_775_807)
    require_int(obj['valid_until_ms'], '$.valid_until_ms', maximum=9_223_372_036_854_775_807)
    warrants = require_refs(obj['required_warrant_refs'], '$.required_warrant_refs', maximum=8)
    require_non_implications(obj['non_implications'], APPROVAL_NON_IMPLICATIONS, '$.non_implications')
    if 'second_approver_ref' in obj:
        require_pattern(obj['second_approver_ref'], REF_RE, '$.second_approver_ref')
    if 'denial_reason' in obj:
        require_text(obj['denial_reason'], '$.denial_reason')
    if 'risk_class' in obj and obj['risk_class'] not in RISK_CLASSES:
        fail('$.risk_class: invalid')
    if obj['decision'] == 'approved':
        if not warrants:
            fail('$.required_warrant_refs: approved decision requires warrant basis')
        if obj['valid_until_ms'] < obj['observed_at_ms']:
            fail('$.valid_until_ms: approved decision is already stale')
    if obj['decision'] == 'denied' and 'denial_reason' not in obj:
        fail('$.denial_reason: required for denied approval')
    if obj['decision'] == 'revoked' and 'revocation_ref' not in obj:
        fail('$.revocation_ref: required for revoked approval')
    if obj['decision'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown approval')
    if scope['max_force'] == 'kill' and obj.get('risk_class') != 'break_glass':
        fail('$.risk_class: kill-level approval requires break_glass risk class')
    return obj


def validate_review(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, REVIEW_ALLOWED, REVIEW_REQUIRED, 'ST-REVIEW v0', 'review_id', REVIEW_RE)
    validate_actor(obj['reviewer'], '$.reviewer')
    require_pattern(obj['subject_op_ref'], REF_RE, '$.subject_op_ref')
    require_pattern(obj['subject_request_digest'], DIGEST_RE, '$.subject_request_digest')
    if obj['review_type'] not in REVIEW_TYPES:
        fail('$.review_type: invalid')
    if obj['verdict'] not in REVIEW_VERDICTS:
        fail('$.verdict: invalid')
    checklist = set(require_string_list(obj['checklist'], '$.checklist', regex=REF_RE, maximum=16))
    bad = sorted(checklist - CHECKLIST_ITEMS)
    if bad:
        fail(f'$.checklist: invalid checklist item(s) {bad}')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', maximum=9_223_372_036_854_775_807)
    require_non_implications(obj['non_implications'], REVIEW_NON_IMPLICATIONS, '$.non_implications')
    if obj['verdict'] == 'pass':
        missing = sorted(REVIEW_PASS_REQUIRED - checklist)
        if missing:
            fail(f'$.checklist: pass verdict missing {missing}')
    if obj['verdict'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown review')
    if 'finding_refs' in obj:
        require_refs(obj['finding_refs'], '$.finding_refs', maximum=16)
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms'] and obj['verdict'] != 'expired':
            fail('$.expires_or_recheck_by_ms: past recheck requires expired verdict')
    return obj


def validate_authcheck(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, AUTH_ALLOWED, AUTH_REQUIRED, 'ST-AUTHCHECK v0', 'authz_id', AUTHZ_RE)
    require_pattern(obj['subject_op_ref'], REF_RE, '$.subject_op_ref')
    require_pattern(obj['subject_request_digest'], DIGEST_RE, '$.subject_request_digest')
    validate_actor(obj['delegatee'], '$.delegatee')
    if obj['verb'] not in VERBS:
        fail('$.verb: invalid')
    if obj['decision'] not in AUTH_DECISIONS:
        fail('$.decision: invalid')
    require_int(obj['checked_at_ms'], '$.checked_at_ms', maximum=9_223_372_036_854_775_807)
    delegation_refs = require_refs(obj['delegation_refs'], '$.delegation_refs', maximum=8)
    approval_refs = require_refs(obj['approval_refs'], '$.approval_refs', maximum=8)
    review_refs = require_refs(obj['review_refs'], '$.review_refs', maximum=8)
    require_non_implications(obj['non_implications'], AUTH_NON_IMPLICATIONS, '$.non_implications')
    if 'runtime_cycle_ref' in obj:
        require_pattern(obj['runtime_cycle_ref'], CYCLE_RE, '$.runtime_cycle_ref')
    if 'denial_reason' in obj:
        require_text(obj['denial_reason'], '$.denial_reason')
    if 'residual_risk' in obj:
        require_text(obj['residual_risk'], '$.residual_risk')
    if 'break_glass_ref' in obj:
        require_pattern(obj['break_glass_ref'], REF_RE, '$.break_glass_ref')
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['checked_at_ms'] and obj['decision'] == 'allowed':
            fail('$.expires_or_recheck_by_ms: allowed authcheck cannot already be stale')
    if obj['decision'] == 'allowed' and (not delegation_refs or not approval_refs or not review_refs):
        fail('allowed authcheck requires delegation, approval, and review refs')
    if obj['decision'] in {'denied', 'needs_approval', 'stale'} and 'denial_reason' not in obj:
        fail('$.denial_reason: required for non-allowed non-unknown authcheck')
    if obj['decision'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown authcheck')
    return obj


def issuer(kind: str = 'steward', ident: str = 'steward.local') -> dict[str, Any]:
    return {'kind': kind, 'id': ident}


def scope(verb: str = 'stop', **overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'kind': 'component',
        'cid': 'demo.web',
        'allowed_verbs': [verb],
        'max_force': 'terminate',
        'runtime_cycle_ref': 'cycle-demo-1',
    }
    obj.update(overrides)
    return obj


def approval_scope(verb: str = 'stop', **overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'cid': 'demo.web',
        'verb': verb,
        'max_force': 'terminate',
        'runtime_cycle_ref': 'cycle-demo-1',
    }
    obj.update(overrides)
    return obj


def base_delegation(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-DELEGATE v0',
        'witness_id': 'wit_2000000000000001',
        'warrant_id': 'del_2000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('ward', 'ward.local'),
        'delegator': 'owner.service',
        'delegatee': 'operator.alice',
        'scope': scope(),
        'status': 'active',
        'effective_from_ms': 1000,
        'expires_at_ms': 60000,
        'observed_at_ms': 2000,
        'basis_refs': ['ward:charter-demo-web'],
        'caveats': ['approval_required', 'dual_control', 'fresh_intent_required', 'no_redelegation', 'privacy_minimized'],
        'non_implications': sorted(DELEG_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_review(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-REVIEW v0',
        'witness_id': 'wit_2000000000000002',
        'review_id': 'rvw_2000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('steward'),
        'reviewer': 'operator.bob',
        'subject_op_ref': 'op:stop-demo-web-1',
        'subject_request_digest': 'sha256:' + '1' * 64,
        'review_type': 'preflight',
        'verdict': 'pass',
        'checklist': ['fresh_intent', 'idempotency_bound', 'no_host_target', 'reason_present', 'target_fenced'],
        'observed_at_ms': 3000,
        'basis_refs': ['op:stop-demo-web-1', 'cycle-demo-1'],
        'non_implications': sorted(REVIEW_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_approval(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-APPROVAL v0',
        'witness_id': 'wit_2000000000000003',
        'approval_id': 'apv_2000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('steward'),
        'approver': 'operator.carol',
        'subject_op_ref': 'op:stop-demo-web-1',
        'subject_request_digest': 'sha256:' + '1' * 64,
        'decision': 'approved',
        'approval_scope': approval_scope(),
        'observed_at_ms': 4000,
        'valid_until_ms': 45000,
        'basis_refs': ['rvw_2000000000000001', 'del_2000000000000001'],
        'required_warrant_refs': ['del_2000000000000001'],
        'risk_class': 'ordinary',
        'non_implications': sorted(APPROVAL_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_authcheck(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-AUTHCHECK v0',
        'witness_id': 'wit_2000000000000004',
        'authz_id': 'auth_2000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('steward'),
        'subject_op_ref': 'op:stop-demo-web-1',
        'subject_request_digest': 'sha256:' + '1' * 64,
        'delegatee': 'operator.alice',
        'verb': 'stop',
        'runtime_cycle_ref': 'cycle-demo-1',
        'decision': 'allowed',
        'checked_at_ms': 5000,
        'basis_refs': ['del_2000000000000001', 'rvw_2000000000000001', 'apv_2000000000000001'],
        'delegation_refs': ['del_2000000000000001'],
        'approval_refs': ['apv_2000000000000001'],
        'review_refs': ['rvw_2000000000000001'],
        'expires_or_recheck_by_ms': 30000,
        'residual_risk': 'Authorized stop only; execution and effects remain separate',
        'non_implications': sorted(AUTH_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def governance_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'governance', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    d = base_delegation()
    r = base_review()
    a = base_approval()
    z = base_authcheck()
    denied_z = base_authcheck(
        witness_id='wit_2000000000000005',
        authz_id='auth_2000000000000002',
        decision='denied',
        delegation_refs=[],
        approval_refs=[],
        review_refs=[],
        basis_refs=['op:restart-demo-web-2'],
        denial_reason='No active delegation warrant found',
    )

    cases: list[dict[str, Any]] = [
        schema_case('delegate.accept.active-stop', 'ST-DELEGATE', d, 'accept', 'delegation is scoped, expiring, non-redelegable lifecycle authority evidence'),
        schema_case('delegate.reject.owner-label', 'ST-DELEGATE', {**d, 'owner_label': 'team-sre'}, 'reject', 'owner labels cannot masquerade as delegated action authority'),
        schema_case('delegate.reject.active-expired-window', 'ST-DELEGATE', {**d, 'observed_at_ms': 70000}, 'reject', 'active delegation must be observed inside its validity window'),
        schema_case('delegate.reject.redelegation-flag', 'ST-DELEGATE', {**d, 'redelegation_allowed': True}, 'reject', 're-delegation creep is explicit forbidden surface'),
        schema_case('delegate.reject.observe-only-stop', 'ST-DELEGATE', {**d, 'scope': scope('stop'), 'caveats': ['no_redelegation', 'observe_only', 'privacy_minimized']}, 'reject', 'observe-only delegation cannot carry mutating verbs'),
        schema_case('delegate.reject.duplicate-json-key', 'ST-DELEGATE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-DELEGATE v0","schema":"ST-DELEGATE v0","witness_id":"wit_2000000000000001","warrant_id":"del_2000000000000001","cid":"demo.web","issuer":{"kind":"ward","id":"ward.local"},"delegator":"owner.service","delegatee":"operator.alice","scope":{"kind":"component","cid":"demo.web","allowed_verbs":["stop"],"max_force":"terminate"},"status":"active","effective_from_ms":1000,"expires_at_ms":60000,"observed_at_ms":2000,"basis_refs":["ward:charter-demo-web"],"caveats":["no_redelegation"],"non_implications":[]}'),
        schema_case('review.accept.preflight-pass', 'ST-REVIEW', r, 'accept', 'review can pass request hygiene without approving or authorizing execution'),
        schema_case('review.reject.pass-missing-target-fence', 'ST-REVIEW', {**r, 'checklist': ['idempotency_bound', 'no_host_target', 'reason_present']}, 'reject', 'a pass verdict must prove target fencing'),
        schema_case('review.reject.claims-authorized', 'ST-REVIEW', {**r, 'claims_authorized': True}, 'reject', 'review does not authorize execution'),
        schema_case('review.reject.past-recheck-not-expired', 'ST-REVIEW', {**r, 'expires_or_recheck_by_ms': 1000}, 'reject', 'stale review must not remain pass'),
        schema_case('approval.accept.approved-stop', 'ST-APPROVAL', a, 'accept', 'approval binds a specific operation digest and warrant basis without executing it'),
        schema_case('approval.reject.approved-without-warrant', 'ST-APPROVAL', {**a, 'required_warrant_refs': []}, 'reject', 'approval must cite the delegation warrant basis it relies on'),
        schema_case('approval.reject.denied-without-reason', 'ST-APPROVAL', {k: v for k, v in {**a, 'decision': 'denied'}.items() if k != 'denial_reason'}, 'reject', 'denied approval must explain why'),
        schema_case('approval.reject.kill-without-breakglass', 'ST-APPROVAL', {**a, 'approval_scope': approval_scope(max_force='kill'), 'risk_class': 'ordinary'}, 'reject', 'kill-level approval requires break-glass classification'),
        schema_case('approval.reject.claims-executed', 'ST-APPROVAL', {**a, 'claims_executed': True}, 'reject', 'approval is not execution'),
        schema_case('authcheck.accept.allowed', 'ST-AUTHCHECK', z, 'accept', 'authcheck settles allowed/denied status without executing the operation'),
        schema_case('authcheck.reject.allowed-without-approval', 'ST-AUTHCHECK', {**z, 'approval_refs': []}, 'reject', 'allowed authcheck needs approval evidence'),
        schema_case('authcheck.reject.claims-effect-success', 'ST-AUTHCHECK', {**z, 'claims_effect_success': True}, 'reject', 'authorization cannot claim external effect success'),
        schema_case('authcheck.reject.stale-without-reason', 'ST-AUTHCHECK', {k: v for k, v in {**z, 'decision': 'stale'}.items() if k != 'denial_reason'}, 'reject', 'stale authorization must name a reason'),

        governance_case('governance.accept.authorized-stop', [
            {'event': 'delegation', 'packet': d},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': a},
            {'event': 'authcheck', 'packet': z},
        ], 'accept', 'delegation, review, approval, and authcheck compose into allowed operation authority without execution truth'),
        governance_case('governance.accept.denied-no-warrant', [
            {'event': 'authcheck', 'packet': denied_z},
        ], 'accept', 'denied authorization can be recorded without inventing warrant or approval evidence'),
        governance_case('governance.reject.expired-delegation-used', [
            {'event': 'delegation', 'packet': base_delegation(witness_id='wit_2000000000000006', status='expired', observed_at_ms=70000)},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': a},
            {'event': 'authcheck', 'packet': z},
        ], 'reject', 'allowed authcheck cannot rely on expired delegation'),
        governance_case('governance.reject.approval-digest-mismatch', [
            {'event': 'delegation', 'packet': d},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': base_approval(witness_id='wit_2000000000000007', subject_request_digest='sha256:' + '2' * 64)},
            {'event': 'authcheck', 'packet': z},
        ], 'reject', 'approval must bind the same operation digest as authcheck'),
        governance_case('governance.reject.review-needs-approval-not-pass', [
            {'event': 'delegation', 'packet': d},
            {'event': 'review', 'packet': base_review(witness_id='wit_2000000000000008', verdict='needs_approval')},
            {'event': 'approval', 'packet': a},
            {'event': 'authcheck', 'packet': z},
        ], 'reject', 'needs-approval review is not a hygiene pass'),
        governance_case('governance.reject.denied-approval-used', [
            {'event': 'delegation', 'packet': d},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': base_approval(witness_id='wit_2000000000000009', decision='denied', denial_reason='Approval withheld')},
            {'event': 'authcheck', 'packet': z},
        ], 'reject', 'denied approval cannot support allowed authcheck'),
        governance_case('governance.reject.delegatee-mismatch', [
            {'event': 'delegation', 'packet': base_delegation(witness_id='wit_2000000000000010', delegatee='operator.mallory')},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': a},
            {'event': 'authcheck', 'packet': z},
        ], 'reject', 'authcheck delegate must match delegation delegatee'),
        governance_case('governance.reject.verb-outside-delegation', [
            {'event': 'delegation', 'packet': base_delegation(witness_id='wit_2000000000000011', scope=scope('refresh'))},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': a},
            {'event': 'authcheck', 'packet': z},
        ], 'reject', 'authcheck verb must be within delegated verbs'),
        governance_case('governance.reject.authcheck-as-execution', [
            {'event': 'delegation', 'packet': d},
            {'event': 'review', 'packet': r},
            {'event': 'approval', 'packet': a},
            {'event': 'authcheck', 'packet': z, 'claims_executed': True},
        ], 'reject', 'authorization does not prove operation execution'),
        governance_case('governance.reject.duplicate-warrant-different-digest', [
            {'event': 'delegation', 'packet': d},
            {'event': 'delegation', 'packet': base_delegation(witness_id='wit_2000000000000012', scope=scope('restart'))},
        ], 'reject', 'same warrant id cannot name different canonical packets'),
    ]
    return cases


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-DELEGATE':
            validate_delegation(obj)
        elif kind == 'ST-REVIEW':
            validate_review(obj)
        elif kind == 'ST-APPROVAL':
            validate_approval(obj)
        elif kind == 'ST-AUTHCHECK':
            validate_authcheck(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_governance_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        delegations: dict[str, dict[str, Any]] = {}
        reviews: dict[str, dict[str, Any]] = {}
        approvals: dict[str, dict[str, Any]] = {}
        seen_packet_digests: dict[str, str] = {}

        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'delegation':
                d = validate_delegation(packet)
                check_packet_identity(seen_packet_digests, d['warrant_id'], d, where)
                delegations[d['warrant_id']] = d
            elif kind == 'review':
                r = validate_review(packet)
                check_packet_identity(seen_packet_digests, r['review_id'], r, where)
                reviews[r['review_id']] = r
            elif kind == 'approval':
                a = validate_approval(packet)
                check_packet_identity(seen_packet_digests, a['approval_id'], a, where)
                approvals[a['approval_id']] = a
            elif kind == 'authcheck':
                z = validate_authcheck(packet)
                check_packet_identity(seen_packet_digests, z['authz_id'], z, where)
                if z['decision'] == 'allowed':
                    for ref in z['delegation_refs']:
                        if ref not in delegations:
                            fail(f'{where}: allowed authcheck cites unknown delegation {ref}')
                        d = delegations[ref]
                        if d['status'] != 'active':
                            fail(f'{where}: allowed authcheck cites non-active delegation {ref}')
                        if not (d['effective_from_ms'] <= z['checked_at_ms'] <= d['expires_at_ms']):
                            fail(f'{where}: delegation {ref} is stale at authcheck time')
                        if d['cid'] != z['cid'] or d['scope']['cid'] != z['cid']:
                            fail(f'{where}: delegation cid mismatch')
                        if d['delegatee'] != z['delegatee']:
                            fail(f'{where}: authcheck delegatee does not match delegation {ref}')
                        if z['verb'] not in d['scope']['allowed_verbs']:
                            fail(f'{where}: authcheck verb outside delegation {ref}')
                        if 'runtime_cycle_ref' in d['scope'] and z.get('runtime_cycle_ref') != d['scope']['runtime_cycle_ref']:
                            fail(f'{where}: authcheck runtime cycle mismatch for delegation {ref}')
                    for ref in z['review_refs']:
                        if ref not in reviews:
                            fail(f'{where}: allowed authcheck cites unknown review {ref}')
                        r = reviews[ref]
                        if r['subject_request_digest'] != z['subject_request_digest']:
                            fail(f'{where}: review digest mismatch')
                        if r['verdict'] != 'pass':
                            fail(f'{where}: allowed authcheck needs pass review, got {r["verdict"]}')
                    for ref in z['approval_refs']:
                        if ref not in approvals:
                            fail(f'{where}: allowed authcheck cites unknown approval {ref}')
                        a = approvals[ref]
                        if a['decision'] != 'approved':
                            fail(f'{where}: allowed authcheck needs approved approval, got {a["decision"]}')
                        if a['subject_request_digest'] != z['subject_request_digest']:
                            fail(f'{where}: approval digest mismatch')
                        if a['valid_until_ms'] < z['checked_at_ms']:
                            fail(f'{where}: approval is stale at authcheck time')
                        if a['approval_scope']['cid'] != z['cid'] or a['approval_scope']['verb'] != z['verb']:
                            fail(f'{where}: approval scope mismatch')
                        if 'runtime_cycle_ref' in a['approval_scope'] and z.get('runtime_cycle_ref') != a['approval_scope']['runtime_cycle_ref']:
                            fail(f'{where}: approval runtime cycle mismatch')
                        missing = sorted(set(a['required_warrant_refs']) - set(z['delegation_refs']))
                        if missing:
                            fail(f'{where}: approval requires warrant(s) not used by authcheck {missing}')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'governance':
            accepted, detail = validate_governance_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-governance-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-governance-corpus] FAIL: corpus is stale; run tools/steward_governance_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-governance-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
