#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from harness_registry import harness_metadata

ROOT = Path(__file__).resolve().parents[1]


def label_from_corpus(corpus: str) -> str:
    name = Path(corpus).stem
    return name.replace('-', ' ')


def render_verification_readme() -> str:
    entries = list(harness_metadata())
    lines: list[str] = []
    lines.append('# Verification')
    lines.append('')
    lines.append('This directory contains Steward\'s executable proof slices.')
    lines.append('')
    lines.append('- `minimum-steward-proof-slice.md` — why the narrow executable slices exist and what they are allowed to prove.')
    for entry in entries:
        packets = ' / '.join(entry['packet_ids'])
        doc = Path(entry['doc']).name
        lines.append(f"- `{doc}` — {packets} / {label_from_corpus(entry['corpus'])} description.")
    for entry in entries:
        corpus = entry['corpus'].removeprefix('docs/40-verification/')
        lines.append(f"- `{corpus}` — deterministic generated {label_from_corpus(entry['corpus'])} checked by lint.")
    lines.append('')
    packet_ids = [packet for entry in entries for packet in entry['packet_ids']]
    lines.append('The verification material intentionally avoids proving that Steward is a service manager, scheduler, broker, workflow engine, shell product, desktop notification framework, topology authority, or deployment controller. It proves that selected registered packet families do not collapse into each other or into stronger lifecycle truth: ' + ', '.join(f'`{packet}`' for packet in packet_ids) + '.')
    lines.append('')
    return '\n'.join(lines)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='docs/40-verification/README.md')
    args = ap.parse_args()
    out = ROOT / args.out
    out.write_text(render_verification_readme(), encoding='utf-8')
    print(out)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
