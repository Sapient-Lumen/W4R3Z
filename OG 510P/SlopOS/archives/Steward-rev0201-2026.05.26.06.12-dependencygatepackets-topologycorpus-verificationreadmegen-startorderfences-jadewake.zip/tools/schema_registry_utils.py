#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_REGISTRY = ROOT / 'docs/30-architecture/schema-registry.md'


def parse_schema_registry_rows(registry: Path = SCHEMA_REGISTRY) -> list[list[str]]:
    """Return data rows from docs/30-architecture/schema-registry.md.

    The lint suite, harness wiring checks, and future audit scripts all need the
    same interpretation of the schema-registry table. Keep this parser small and
    intentionally table-shaped: callers decide which columns they care about.
    """
    rows: list[list[str]] = []
    for line in registry.read_text(encoding='utf-8').splitlines():
        if not line.startswith('| '):
            continue
        cells = [cell.strip() for cell in line.strip().strip('|').split('|')]
        if len(cells) != 5 or cells[0] in {'ID', '---'}:
            continue
        rows.append(cells)
    return rows


def packet_ids_with_machine_profiles(registry: Path = SCHEMA_REGISTRY) -> set[str]:
    out: set[str] = set()
    for schema_id, _meaning, _human, machine, _checker in parse_schema_registry_rows(registry):
        if machine != 'n/a':
            out.add(schema_id.removesuffix(' v0'))
    return out


def machine_schema_filenames(registry: Path = SCHEMA_REGISTRY) -> set[str]:
    """Return machine schema filenames referenced by the schema registry."""
    out: set[str] = set()
    for _schema_id, _meaning, _human, machine, _checker in parse_schema_registry_rows(registry):
        if machine == 'n/a':
            continue
        if machine.startswith('`../../schemas/') and machine.endswith('`'):
            out.add(Path(machine.strip('`')).name)
    return out
