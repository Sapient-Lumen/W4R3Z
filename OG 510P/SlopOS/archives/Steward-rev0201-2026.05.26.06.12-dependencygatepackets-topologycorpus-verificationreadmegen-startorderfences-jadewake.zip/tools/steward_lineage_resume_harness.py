#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/lineage-resume-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')
INC_RE = re.compile(r'^inc_[a-z0-9]{16}$')
LINEAGE_RE = re.compile(r'^lin_[a-z0-9]{16}$')
RESIDENCY_RE = re.compile(r'^res_[a-z0-9]{16}$')
RESUME_RE = re.compile(r'^resm_[a-z0-9]{16}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_ready', 'claims_readiness', 'claims_serving', 'claims_stopped',
    'claims_current_incarnation', 'claims_same_runtime_cycle', 'claims_resident',
    'claims_lossless', 'claims_exactly_once', 'claims_work_complete',
    'claims_effect_success', 'claims_no_gap', 'ready', 'serving',
    'component_state', 'rollout_complete', 'work_completed', 'lossless',
    'exactly_once', 'raw_log', 'scrollback', 'token', 'secret', 'raw_secret',
    'raw_token', 'raw_handle', 'bearer', 'value', 'path', 'raw_path',
    'mount_path', 'fd', 'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path',
    'systemd_unit', 'systemd_job_path', 'pod_name', 'container_id',
    'process_name', 'host_unit', 'node_name', 'allocation_id', 'repair_action',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {
    'steward', 'operator', 'adapter', 'controller', 'runtime', 'scheduler',
    'runner', 'warm_pool', 'checkpoint_manager', 'platform', 'observer',
}

RT_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'cycle_id', 'cycle_state', 'cycle_role', 'manifest_digest', 'start_reason', 'observed_at_ms', 'host_evidence_strength', 'basis_refs', 'non_implications'}
RT_OPTIONAL = {'activation_digest', 'incarnation_id', 'end_cause', 'fence_ref', 'expires_or_recheck_by_ms', 'unknown_reason'}
RT_ALLOWED = RT_REQUIRED | RT_OPTIONAL
CYCLE_STATES = {'starting', 'active', 'stopping', 'terminated', 'lost', 'unknown'}
CYCLE_ROLES = {'primary', 'helper', 'predecessor', 'successor', 'sidecar', 'observer', 'unknown'}
START_REASONS = {'start_request', 'restart_policy', 'recovery_reconcile', 'hot_restart_successor', 'resume_restore', 'demand_activation', 'operator_repair', 'unknown'}
END_CAUSES = {'clean_stop', 'crash', 'escalated_stop', 'evicted', 'superseded', 'lost', 'unknown'}
HOST_EVIDENCE = {'steward_native', 'non_reused_host_handle', 'adapter_observed', 'inferred', 'unknown'}
RT_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-incarnation-currentness', 'not-residency', 'not-custody', 'not-work-completion', 'not-effect-success', 'not-host-handle-authority'}

INC_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'lineage_id', 'incarnation_id', 'relation', 'currentness', 'observed_at_ms', 'basis_refs', 'non_implications'}
INC_OPTIONAL = {'runtime_cycle', 'predecessor_incarnation_id', 'successor_incarnation_id', 'handoff_ref', 'expected_fence_ref', 'observed_generation_ref', 'restore_ref', 'expires_or_recheck_by_ms', 'unknown_reason'}
INC_ALLOWED = INC_REQUIRED | INC_OPTIONAL
RELATIONS = {'current', 'predecessor_of', 'successor_of', 'replacement_for', 'same_platform_object_new_subcycle', 'clone_of', 'restore_of', 'split_risk', 'retired', 'unknown'}
CURRENTNESS = {'current', 'current_as_of', 'candidate', 'warming', 'serving', 'draining', 'retired', 'reaped', 'superseded', 'ambiguous', 'split_risk', 'unknown'}
INC_NON_IMPLICATIONS = {'not-runtime-cycle-equality', 'not-readiness', 'not-serving', 'not-residency', 'not-custody', 'not-work-fate', 'not-effect-success', 'not-global-order'}

RES_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'residency_id', 'residency_state', 'basis_kind', 'proof_strength', 'observed_at_ms', 'basis_refs', 'non_implications'}
RES_OPTIONAL = {'incarnation_id', 'runtime_cycle', 'location_ref', 'pool_ref', 'topology_ref', 'snapshot_ref', 'restore_ref', 'warm_reason', 'eviction_reason', 'expires_or_recheck_by_ms', 'unknown_reason'}
RES_ALLOWED = RES_REQUIRED | RES_OPTIONAL
RESIDENCY_STATES = {'requested', 'nominated', 'bound', 'initializing', 'warm_idle', 'frozen', 'restoring', 'active', 'evicting', 'evicted', 'lost', 'unknown'}
BASIS_KINDS = {'scheduler', 'supervisor', 'runner', 'adapter', 'warm_pool', 'checkpoint_manager', 'platform', 'observer', 'unknown'}
PROOF_STRENGTHS = {'steward_native', 'substrate_native', 'adapter_observed', 'operator_claim', 'last_known', 'unknown'}
RES_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-incarnation-currentness', 'not-admission', 'not-custody', 'not-work-completion', 'not-effect-success', 'not-scheduler-authority'}

RESUME_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'resume_id', 'resume_kind', 'resume_state', 'continuity_class', 'safety_basis', 'gap_state', 'observed_at_ms', 'basis_refs', 'non_implications'}
RESUME_OPTIONAL = {'source_ref', 'previous_incarnation_id', 'target_incarnation_id', 'previous_runtime_cycle', 'target_runtime_cycle', 'activation_digest_ref', 'snapshot_ref', 'handoff_ref', 'cursor_ref', 'effect_key_ref', 'expires_or_recheck_by_ms', 'unknown_reason'}
RESUME_ALLOWED = RESUME_REQUIRED | RESUME_OPTIONAL
RESUME_KINDS = {'manager_recovery', 'restart_replay', 'hot_restart_handoff', 'snapshot_restore', 'live_channel_resume', 'demand_redelivery', 'custody_reconcile', 'unknown'}
RESUME_STATES = {'proposed', 'replayed', 'reconciled', 'degraded_unknown', 'blocked_stale_cycle', 'rejected_widening', 'handoff_pending', 'gap_ambiguous', 'abandoned', 'unknown'}
CONTINUITY_CLASSES = {'none', 'activation_replay', 'escrowed_state', 'snapshot_restore', 'channel_cursor', 'custody_reconcile', 'effect_key_reuse', 'unknown'}
SAFETY_BASES = {'digest_match', 'activation_digest_match', 'explicit_handoff', 'cursor_resume_with_gap', 'operator_review', 'no_safe_resume', 'unknown'}
GAP_STATES = {'none', 'possible_gap', 'known_gap', 'duplicate_possible', 'unknown'}
RESUME_NON_IMPLICATIONS = {'not-same-runtime-cycle', 'not-readiness', 'not-serving', 'not-lossless', 'not-exactly-once', 'not-effect-success', 'not-custody', 'not-work-completion'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered or '/var/' in lowered or 'node=' in lowered:
        fail(f'{path}: raw host/secret-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=16))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def require_optional_ref(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], REF_RE, f'{path}.{field}')


def require_optional_cycle(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], CYCLE_RE, f'{path}.{field}')


def require_optional_inc(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], INC_RE, f'{path}.{field}')


def validate_observation_window(obj: dict[str, Any], path: str) -> None:
    require_int(obj['observed_at_ms'], f'{path}.observed_at_ms', maximum=9_223_372_036_854_775_807)
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], f'{path}.expires_or_recheck_by_ms', maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail(f'{path}.expires_or_recheck_by_ms: precedes observed_at_ms')


def validate_rtcycle(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, RT_ALLOWED, RT_REQUIRED, '$')
    if obj['schema'] != 'ST-RTCYCLE v0':
        fail('$.schema: expected ST-RTCYCLE v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['cycle_id'], CYCLE_RE, '$.cycle_id')
    if obj['cycle_state'] not in CYCLE_STATES:
        fail('$.cycle_state: invalid')
    if obj['cycle_role'] not in CYCLE_ROLES:
        fail('$.cycle_role: invalid')
    require_pattern(obj['manifest_digest'], DIGEST_RE, '$.manifest_digest')
    if obj['start_reason'] not in START_REASONS:
        fail('$.start_reason: invalid')
    if obj['host_evidence_strength'] not in HOST_EVIDENCE:
        fail('$.host_evidence_strength: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], RT_NON_IMPLICATIONS, '$.non_implications')
    for field in ('activation_digest',):
        if field in obj:
            require_pattern(obj[field], DIGEST_RE, f'$.{field}')
    require_optional_inc(obj, 'incarnation_id', '$')
    require_optional_ref(obj, 'fence_ref', '$')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    if obj['cycle_state'] in {'terminated', 'lost'}:
        if obj.get('end_cause') not in END_CAUSES:
            fail('$.end_cause: required for terminated/lost cycles')
    elif 'end_cause' in obj:
        fail('$.end_cause: only terminated/lost cycles may carry an end cause')
    if obj['cycle_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown cycle state')
    return obj


def validate_incarn(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, INC_ALLOWED, INC_REQUIRED, '$')
    if obj['schema'] != 'ST-INCARN v0':
        fail('$.schema: expected ST-INCARN v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['lineage_id'], LINEAGE_RE, '$.lineage_id')
    require_pattern(obj['incarnation_id'], INC_RE, '$.incarnation_id')
    if obj['relation'] not in RELATIONS:
        fail('$.relation: invalid')
    if obj['currentness'] not in CURRENTNESS:
        fail('$.currentness: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], INC_NON_IMPLICATIONS, '$.non_implications')
    for field in ('runtime_cycle',):
        require_optional_cycle(obj, field, '$')
    for field in ('predecessor_incarnation_id', 'successor_incarnation_id'):
        require_optional_inc(obj, field, '$')
        if obj.get(field) == obj['incarnation_id']:
            fail(f'$.{field}: incarnation cannot cite itself')
    for field in ('handoff_ref', 'expected_fence_ref', 'observed_generation_ref', 'restore_ref'):
        require_optional_ref(obj, field, '$')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    if obj['currentness'] in {'current', 'current_as_of', 'warming', 'serving', 'draining'} and 'runtime_cycle' not in obj:
        fail('$.runtime_cycle: current-ish incarnation needs a runtime-cycle fence')
    if obj['currentness'] in {'ambiguous', 'split_risk', 'unknown'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for uncertain currentness')
    if obj['relation'] in {'successor_of', 'replacement_for', 'same_platform_object_new_subcycle', 'clone_of'} and 'predecessor_incarnation_id' not in obj:
        fail('$.predecessor_incarnation_id: required for successor/replacement/clone relation')
    if obj['relation'] == 'predecessor_of' and 'successor_incarnation_id' not in obj:
        fail('$.successor_incarnation_id: required for predecessor relation')
    if obj['relation'] == 'restore_of' and 'restore_ref' not in obj:
        fail('$.restore_ref: required for restore relation')
    return obj


def validate_residency(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, RES_ALLOWED, RES_REQUIRED, '$')
    if obj['schema'] != 'ST-RESIDENCY v0':
        fail('$.schema: expected ST-RESIDENCY v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['residency_id'], RESIDENCY_RE, '$.residency_id')
    if obj['residency_state'] not in RESIDENCY_STATES:
        fail('$.residency_state: invalid')
    if obj['basis_kind'] not in BASIS_KINDS:
        fail('$.basis_kind: invalid')
    if obj['proof_strength'] not in PROOF_STRENGTHS:
        fail('$.proof_strength: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], RES_NON_IMPLICATIONS, '$.non_implications')
    require_optional_inc(obj, 'incarnation_id', '$')
    require_optional_cycle(obj, 'runtime_cycle', '$')
    for field in ('location_ref', 'pool_ref', 'topology_ref', 'snapshot_ref', 'restore_ref'):
        require_optional_ref(obj, field, '$')
    for field in ('warm_reason', 'eviction_reason', 'unknown_reason'):
        if field in obj:
            require_text(obj[field], f'$.{field}')
    if obj['residency_state'] in {'bound', 'initializing', 'warm_idle', 'frozen', 'restoring', 'active', 'evicting', 'evicted', 'lost'} and not ({'incarnation_id', 'runtime_cycle'} & set(obj)):
        fail('$.incarnation_id/runtime_cycle: residency must bind to an incarnation or runtime cycle')
    if obj['residency_state'] in {'nominated', 'bound', 'warm_idle', 'active'} and not ({'location_ref', 'pool_ref'} & set(obj)):
        fail('$.location_ref/pool_ref: concrete residency state needs scoped location or pool ref')
    if obj['residency_state'] in {'frozen', 'restoring'} and not ({'snapshot_ref', 'restore_ref'} & set(obj)):
        fail('$.snapshot_ref/restore_ref: frozen/restoring residency needs restore ancestry')
    if obj['residency_state'] in {'evicted', 'lost'} and 'eviction_reason' not in obj:
        fail('$.eviction_reason: required for evicted/lost residency')
    if obj['residency_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown residency')
    return obj


def validate_resume(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, RESUME_ALLOWED, RESUME_REQUIRED, '$')
    if obj['schema'] != 'ST-RESUME v0':
        fail('$.schema: expected ST-RESUME v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['resume_id'], RESUME_RE, '$.resume_id')
    if obj['resume_kind'] not in RESUME_KINDS:
        fail('$.resume_kind: invalid')
    if obj['resume_state'] not in RESUME_STATES:
        fail('$.resume_state: invalid')
    if obj['continuity_class'] not in CONTINUITY_CLASSES:
        fail('$.continuity_class: invalid')
    if obj['safety_basis'] not in SAFETY_BASES:
        fail('$.safety_basis: invalid')
    if obj['gap_state'] not in GAP_STATES:
        fail('$.gap_state: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], RESUME_NON_IMPLICATIONS, '$.non_implications')
    for field in ('source_ref', 'snapshot_ref', 'handoff_ref', 'cursor_ref', 'effect_key_ref'):
        require_optional_ref(obj, field, '$')
    for field in ('previous_incarnation_id', 'target_incarnation_id'):
        require_optional_inc(obj, field, '$')
    for field in ('previous_runtime_cycle', 'target_runtime_cycle'):
        require_optional_cycle(obj, field, '$')
    if 'activation_digest_ref' in obj:
        require_pattern(obj['activation_digest_ref'], DIGEST_RE, '$.activation_digest_ref')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    if obj['resume_state'] in {'replayed', 'reconciled', 'handoff_pending', 'gap_ambiguous'}:
        if 'source_ref' not in obj:
            fail('$.source_ref: required for active resume/reconcile states')
        if not ({'target_incarnation_id', 'target_runtime_cycle'} & set(obj)):
            fail('$.target_incarnation_id/target_runtime_cycle: required for active resume/reconcile states')
    if obj['continuity_class'] == 'activation_replay':
        if 'activation_digest_ref' not in obj:
            fail('$.activation_digest_ref: required for activation replay continuity')
        if obj['safety_basis'] not in {'digest_match', 'activation_digest_match'}:
            fail('$.safety_basis: activation replay requires digest-matching basis')
    if obj['continuity_class'] == 'snapshot_restore':
        if 'snapshot_ref' not in obj or 'target_incarnation_id' not in obj:
            fail('$.snapshot_ref/target_incarnation_id: required for snapshot restore continuity')
    if obj['resume_state'] == 'gap_ambiguous':
        if obj['gap_state'] == 'none':
            fail('$.gap_state: gap_ambiguous cannot claim no gap')
        if 'unknown_reason' not in obj:
            fail('$.unknown_reason: required for gap ambiguity')
    if obj['resume_state'] in {'blocked_stale_cycle', 'rejected_widening', 'degraded_unknown', 'unknown'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for downgraded/blocked resume')
    if obj.get('previous_runtime_cycle') == obj.get('target_runtime_cycle') and obj['continuity_class'] != 'none':
        fail('$.target_runtime_cycle: resume continuity cannot claim the same runtime cycle after turnover')
    return obj


def base_issuer(kind: str = 'steward', ident: str = 'steward/core') -> dict[str, Any]:
    return {'kind': kind, 'id': ident}


def base_rtcycle(cycle_id: str = 'cycle-alpha', state: str = 'active', inc: str = 'inc_0000000000000001') -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-RTCYCLE v0',
        'witness_id': 'wit_0000000000001001',
        'cid': 'demo.web',
        'issuer': base_issuer('runtime', 'runner/local'),
        'cycle_id': cycle_id,
        'cycle_state': state,
        'cycle_role': 'primary',
        'manifest_digest': 'sha256:' + 'a' * 64,
        'activation_digest': 'sha256:' + 'b' * 64,
        'incarnation_id': inc,
        'start_reason': 'start_request',
        'observed_at_ms': 1000,
        'expires_or_recheck_by_ms': 5000,
        'host_evidence_strength': 'non_reused_host_handle',
        'basis_refs': ['basis/runtime-start'],
        'non_implications': sorted(RT_NON_IMPLICATIONS),
    }
    if state in {'terminated', 'lost'}:
        obj['end_cause'] = 'crash' if state == 'terminated' else 'lost'
    if state == 'unknown':
        obj['unknown_reason'] = 'Observer could not reconcile runtime handle'
    return obj


def base_incarn(inc: str = 'inc_0000000000000001', relation: str = 'current', currentness: str = 'current', cycle: str = 'cycle-alpha') -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-INCARN v0',
        'witness_id': 'wit_0000000000002001',
        'cid': 'demo.web',
        'issuer': base_issuer(),
        'lineage_id': 'lin_0000000000000001',
        'incarnation_id': inc,
        'relation': relation,
        'currentness': currentness,
        'runtime_cycle': cycle,
        'observed_at_ms': 1100,
        'expires_or_recheck_by_ms': 5100,
        'basis_refs': ['basis/lineage'],
        'non_implications': sorted(INC_NON_IMPLICATIONS),
    }
    if relation in {'successor_of', 'replacement_for', 'same_platform_object_new_subcycle', 'clone_of'}:
        obj['predecessor_incarnation_id'] = 'inc_0000000000000001'
    if relation == 'predecessor_of':
        obj['successor_incarnation_id'] = 'inc_0000000000000002'
    if relation == 'restore_of':
        obj['restore_ref'] = 'restore/snap-a'
    if currentness in {'ambiguous', 'split_risk', 'unknown'}:
        obj['unknown_reason'] = 'Lineage relation is not settled'
    return obj


def base_residency(state: str = 'active', inc: str = 'inc_0000000000000001', cycle: str = 'cycle-alpha') -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-RESIDENCY v0',
        'witness_id': 'wit_0000000000003001',
        'cid': 'demo.web',
        'issuer': base_issuer('scheduler', 'scheduler/local'),
        'residency_id': 'res_0000000000000001',
        'residency_state': state,
        'basis_kind': 'scheduler',
        'proof_strength': 'substrate_native',
        'incarnation_id': inc,
        'runtime_cycle': cycle,
        'location_ref': 'loc/zone-a/pool-web',
        'pool_ref': 'pool/web',
        'observed_at_ms': 1200,
        'expires_or_recheck_by_ms': 5200,
        'basis_refs': ['basis/residency'],
        'non_implications': sorted(RES_NON_IMPLICATIONS),
    }
    if state in {'frozen', 'restoring'}:
        obj['snapshot_ref'] = 'snapshot/web-template'
        obj['restore_ref'] = 'restore/snap-a'
    if state in {'evicted', 'lost'}:
        obj['eviction_reason'] = 'Placement lost during maintenance'
    if state == 'unknown':
        obj['unknown_reason'] = 'Scheduler observation stale'
    return obj


def base_resume(state: str = 'replayed', target_cycle: str = 'cycle-beta', target_inc: str = 'inc_0000000000000002') -> dict[str, Any]:
    return {
        'schema': 'ST-RESUME v0',
        'witness_id': 'wit_0000000000004001',
        'cid': 'demo.web',
        'issuer': base_issuer(),
        'resume_id': 'resm_0000000000000001',
        'resume_kind': 'restart_replay',
        'resume_state': state,
        'continuity_class': 'activation_replay',
        'safety_basis': 'activation_digest_match',
        'gap_state': 'none',
        'source_ref': 'receipt/activation-alpha',
        'previous_incarnation_id': 'inc_0000000000000001',
        'target_incarnation_id': target_inc,
        'previous_runtime_cycle': 'cycle-alpha',
        'target_runtime_cycle': target_cycle,
        'activation_digest_ref': 'sha256:' + 'b' * 64,
        'observed_at_ms': 1300,
        'expires_or_recheck_by_ms': 5300,
        'basis_refs': ['basis/restart-replay'],
        'non_implications': sorted(RESUME_NON_IMPLICATIONS),
    }


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'lineage_flow', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    rt1 = base_rtcycle('cycle-alpha', 'active', 'inc_0000000000000001')
    rt1_end = base_rtcycle('cycle-alpha', 'terminated', 'inc_0000000000000001')
    rt1_end['witness_id'] = 'wit_0000000000001002'
    rt1_end['observed_at_ms'] = 2000
    rt1_end['expires_or_recheck_by_ms'] = 6000
    rt2 = base_rtcycle('cycle-beta', 'active', 'inc_0000000000000002')
    rt2['witness_id'] = 'wit_0000000000001003'
    rt2['start_reason'] = 'restart_policy'
    rt2['observed_at_ms'] = 2100
    rt2['expires_or_recheck_by_ms'] = 6100
    inc1_current = base_incarn('inc_0000000000000001', 'current', 'current', 'cycle-alpha')
    inc1_retired = base_incarn('inc_0000000000000001', 'predecessor_of', 'retired', 'cycle-alpha')
    inc1_retired['witness_id'] = 'wit_0000000000002002'
    inc1_retired['observed_at_ms'] = 2200
    inc1_retired['expires_or_recheck_by_ms'] = 6200
    inc2_current = base_incarn('inc_0000000000000002', 'successor_of', 'current', 'cycle-beta')
    inc2_current['witness_id'] = 'wit_0000000000002003'
    inc2_current['observed_at_ms'] = 2300
    inc2_current['expires_or_recheck_by_ms'] = 6300
    resid2 = base_residency('active', 'inc_0000000000000002', 'cycle-beta')
    resid2['witness_id'] = 'wit_0000000000003002'
    resid2['residency_id'] = 'res_0000000000000002'
    resume = base_resume()

    degraded_resume = base_resume('degraded_unknown', 'cycle-alpha', 'inc_0000000000000001')
    degraded_resume['witness_id'] = 'wit_0000000000004002'
    degraded_resume['resume_id'] = 'resm_0000000000000002'
    degraded_resume['resume_kind'] = 'manager_recovery'
    degraded_resume['continuity_class'] = 'none'
    degraded_resume['safety_basis'] = 'unknown'
    degraded_resume['gap_state'] = 'unknown'
    degraded_resume['unknown_reason'] = 'Manager restarted and live present-tense state was downgraded to explicit unknown'
    degraded_resume.pop('activation_digest_ref', None)

    cases: list[dict[str, Any]] = [
        schema_case('rtcycle.accept.active', 'ST-RTCYCLE', rt1, 'accept', 'runtime cycle witness is closed, digestable, and weaker than incarnation currentness'),
        schema_case('rtcycle.reject.raw-pid', 'ST-RTCYCLE', {**rt1, 'pid': 1234}, 'reject', 'host process identifiers stay behind the membrane'),
        schema_case('rtcycle.reject.terminated-without-cause', 'ST-RTCYCLE', {k: v for k, v in rt1_end.items() if k != 'end_cause'}, 'reject', 'terminal cycle observations need an end cause, even if weak'),
        schema_case('rtcycle.reject.claims-current-incarnation', 'ST-RTCYCLE', {**rt1, 'claims_current_incarnation': True}, 'reject', 'runtime-cycle equality cannot become incarnation currentness'),
        schema_case('incarn.accept.successor-current', 'ST-INCARN', inc2_current, 'accept', 'incarnation lineage can name a successor without proving work or effect fate'),
        schema_case('incarn.reject.self-predecessor', 'ST-INCARN', {**inc2_current, 'predecessor_incarnation_id': 'inc_0000000000000002'}, 'reject', 'lineage cannot cite itself as predecessor'),
        schema_case('incarn.reject.current-without-cycle', 'ST-INCARN', {k: v for k, v in inc2_current.items() if k != 'runtime_cycle'}, 'reject', 'current-ish incarnation needs a cycle fence'),
        schema_case('incarn.reject.missing-nonimplication', 'ST-INCARN', {**inc2_current, 'non_implications': ['not-readiness']}, 'reject', 'incarnation witnesses must refuse adjacent stronger truths'),
        schema_case('residency.accept.active', 'ST-RESIDENCY', resid2, 'accept', 'residency can be observed without proving readiness or serving'),
        schema_case('residency.reject.pod-name', 'ST-RESIDENCY', {**resid2, 'pod_name': 'demo-web-abc'}, 'reject', 'host object names are not portable residency authority'),
        schema_case('residency.reject.active-without-incarnation-or-cycle', 'ST-RESIDENCY', {k: v for k, v in resid2.items() if k not in {'incarnation_id', 'runtime_cycle'}}, 'reject', 'active residency must bind to an incarnation or cycle'),
        schema_case('residency.accept.frozen-with-ancestry', 'ST-RESIDENCY', base_residency('frozen'), 'accept', 'frozen residency is acceptable only with restore ancestry'),
        schema_case('residency.reject.frozen-without-snapshot', 'ST-RESIDENCY', {k: v for k, v in base_residency('frozen').items() if k not in {'snapshot_ref', 'restore_ref'}}, 'reject', 'frozen residency without restore ancestry is unsafe'),
        schema_case('resume.accept.activation-replay', 'ST-RESUME', resume, 'accept', 'restart resume can replay the same activation digest while refusing same-cycle and lossless claims'),
        schema_case('resume.reject.same-cycle-continuity', 'ST-RESUME', {**resume, 'target_runtime_cycle': 'cycle-alpha'}, 'reject', 'resume continuity must not claim the old runtime cycle survived turnover'),
        schema_case('resume.reject.gap-ambiguous-no-reason', 'ST-RESUME', {**resume, 'resume_state': 'gap_ambiguous', 'gap_state': 'possible_gap'}, 'reject', 'gap ambiguity must explain its downgrade'),
        schema_case('resume.reject.lossless-claim', 'ST-RESUME', {**resume, 'claims_lossless': True}, 'reject', 'resume packets never prove lossless continuity'),
        schema_case('resume.reject.duplicate-json-key', 'ST-RESUME', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-RESUME v0","schema":"ST-RESUME v0","witness_id":"wit_0000000000004001"}'),

        flow_case('lineage.accept.restart-new-cycle-new-incarnation', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'incarnation', 'packet': inc1_current},
            {'event': 'runtime_cycle', 'packet': rt1_end},
            {'event': 'runtime_cycle', 'packet': rt2},
            {'event': 'incarnation', 'packet': inc1_retired},
            {'event': 'incarnation', 'packet': inc2_current},
            {'event': 'residency', 'packet': resid2},
            {'event': 'resume', 'packet': resume},
            {'event': 'operation', 'cid': 'demo.web', 'expected_runtime_cycle': 'cycle-beta', 'expected_incarnation_id': 'inc_0000000000000002', 'accepted': True},
        ], 'accept', 'restart creates a new runtime cycle and successor incarnation; stale targets are fenced'),
        flow_case('lineage.accept.manager-recovery-downgrade', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'incarnation', 'packet': inc1_current},
            {'event': 'resume', 'packet': degraded_resume},
        ], 'accept', 'manager recovery may downgrade live state to explicit unknown without claiming lifecycle success'),
        flow_case('lineage.reject.cycle-reuse-after-termination', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'runtime_cycle', 'packet': rt1_end},
            {'event': 'runtime_cycle', 'packet': {**rt1, 'witness_id': 'wit_0000000000001004', 'observed_at_ms': 3000, 'expires_or_recheck_by_ms': 7000}},
        ], 'reject', 'a terminated runtime-cycle witness cannot be reused for a later active run'),
        flow_case('lineage.reject.runtime-cycle-implies-incarnation-currentness', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'claim', 'claim': 'cycle_implies_current_incarnation'},
        ], 'reject', 'runtime-cycle observation is not incarnation currentness'),
        flow_case('lineage.reject.stale-cycle-operation-accepted', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'incarnation', 'packet': inc1_current},
            {'event': 'runtime_cycle', 'packet': rt1_end},
            {'event': 'runtime_cycle', 'packet': rt2},
            {'event': 'incarnation', 'packet': inc2_current},
            {'event': 'operation', 'cid': 'demo.web', 'expected_runtime_cycle': 'cycle-alpha', 'expected_incarnation_id': 'inc_0000000000000002', 'accepted': True},
        ], 'reject', 'accepted operations must fence on the current runtime cycle they actually target'),
        flow_case('lineage.reject.stale-incarnation-operation-accepted', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'incarnation', 'packet': inc1_current},
            {'event': 'runtime_cycle', 'packet': rt1_end},
            {'event': 'runtime_cycle', 'packet': rt2},
            {'event': 'incarnation', 'packet': inc2_current},
            {'event': 'operation', 'cid': 'demo.web', 'expected_runtime_cycle': 'cycle-beta', 'expected_incarnation_id': 'inc_0000000000000001', 'accepted': True},
        ], 'reject', 'accepted operations must fence on the current incarnation when an incarnation was observed'),
        flow_case('lineage.reject.residency-as-readiness', [
            {'event': 'runtime_cycle', 'packet': rt2},
            {'event': 'incarnation', 'packet': inc2_current},
            {'event': 'residency', 'packet': resid2},
            {'event': 'claim', 'claim': 'residency_implies_ready'},
        ], 'reject', 'active residency is not readiness'),
        flow_case('lineage.reject.resume-as-same-runtime-cycle', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'runtime_cycle', 'packet': rt1_end},
            {'event': 'runtime_cycle', 'packet': rt2},
            {'event': 'resume', 'packet': resume},
            {'event': 'claim', 'claim': 'resume_implies_same_runtime_cycle'},
        ], 'reject', 'resume continuity cannot preserve runtime-cycle identity'),
        flow_case('lineage.reject.successor-fails-predecessor-effects', [
            {'event': 'runtime_cycle', 'packet': rt1},
            {'event': 'incarnation', 'packet': inc1_current},
            {'event': 'runtime_cycle', 'packet': rt1_end},
            {'event': 'runtime_cycle', 'packet': rt2},
            {'event': 'incarnation', 'packet': inc2_current},
            {'event': 'claim', 'claim': 'successor_marks_predecessor_effects_failed'},
        ], 'reject', 'a successor incarnation does not settle predecessor work or effect fate'),
    ]
    return cases


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-RTCYCLE':
            validate_rtcycle(obj)
        elif kind == 'ST-INCARN':
            validate_incarn(obj)
        elif kind == 'ST-RESIDENCY':
            validate_residency(obj)
        elif kind == 'ST-RESUME':
            validate_resume(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        current_cycle: dict[str, str] = {}
        current_incarnation: dict[str, str] = {}
        ended_cycles: set[tuple[str, str]] = set()
        seen_cycles: set[tuple[str, str]] = set()
        seen_currentish: set[tuple[str, str]] = set()

        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'runtime_cycle':
                packet = validate_rtcycle(ev['packet'])
                key = (packet['cid'], packet['cycle_id'])
                if packet['cycle_state'] in {'starting', 'active', 'stopping'} and key in ended_cycles:
                    fail(f'{where}: runtime cycle reused after termination/loss')
                if packet['cycle_state'] in {'terminated', 'lost'}:
                    ended_cycles.add(key)
                else:
                    current_cycle[packet['cid']] = packet['cycle_id']
                    seen_cycles.add(key)
            elif kind == 'incarnation':
                packet = validate_incarn(ev['packet'])
                if 'runtime_cycle' in packet and (packet['cid'], packet['runtime_cycle']) not in seen_cycles and (packet['cid'], packet['runtime_cycle']) not in ended_cycles:
                    fail(f'{where}: incarnation cites unknown runtime cycle')
                if packet['currentness'] in {'current', 'current_as_of', 'serving'}:
                    current_incarnation[packet['cid']] = packet['incarnation_id']
                    seen_currentish.add((packet['cid'], packet['incarnation_id']))
            elif kind == 'residency':
                packet = validate_residency(ev['packet'])
                if packet.get('runtime_cycle') and current_cycle.get(packet['cid']) != packet['runtime_cycle']:
                    # Active residency for a terminated predecessor is allowed only when it says evicting/evicted/lost/frozen/restoring.
                    if packet['residency_state'] not in {'evicting', 'evicted', 'lost', 'frozen', 'restoring'}:
                        fail(f'{where}: active residency does not match current runtime cycle')
            elif kind == 'resume':
                packet = validate_resume(ev['packet'])
                target_cycle = packet.get('target_runtime_cycle')
                if packet['resume_state'] in {'replayed', 'reconciled', 'handoff_pending'} and target_cycle and current_cycle.get(packet['cid']) != target_cycle:
                    fail(f'{where}: resume targets a non-current runtime cycle')
            elif kind == 'operation':
                cid = ev.get('cid')
                expected_cycle = ev.get('expected_runtime_cycle')
                expected_inc = ev.get('expected_incarnation_id')
                accepted = ev.get('accepted') is True
                if accepted:
                    if expected_cycle != current_cycle.get(cid):
                        fail(f'{where}: accepted operation targeted stale runtime cycle')
                    if expected_inc and expected_inc != current_incarnation.get(cid):
                        fail(f'{where}: accepted operation targeted stale incarnation')
            elif kind == 'claim':
                claim = ev.get('claim')
                if claim in {
                    'cycle_implies_current_incarnation',
                    'residency_implies_ready',
                    'resume_implies_same_runtime_cycle',
                    'successor_marks_predecessor_effects_failed',
                    'restore_proves_old_effect_keys_safe',
                }:
                    fail(f'{where}: forbidden collapse {claim}')
                fail(f'{where}: unknown claim {claim}')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'lineage_flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-lineage-resume-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-lineage-resume-corpus] FAIL: corpus is stale; run tools/steward_lineage_resume_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-lineage-resume-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
