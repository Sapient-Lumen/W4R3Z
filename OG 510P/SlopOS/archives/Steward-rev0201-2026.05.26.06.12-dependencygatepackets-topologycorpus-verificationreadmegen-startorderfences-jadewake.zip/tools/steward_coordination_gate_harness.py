#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/coordination-gate-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
PRECOND_RE = re.compile(r'^precond_[a-z0-9]{16}$')
ARBIT_RE = re.compile(r'^arbit_[a-z0-9]{16}$')
HOLD_RE = re.compile(r'^hold_[a-z0-9]{16}$')
PROGRESS_RE = re.compile(r'^prog_[a-z0-9]{16}$')
OPREQ_RE = re.compile(r'^opreq_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_authorized', 'claims_authorization', 'claims_approval',
    'claims_current', 'claims_current_state', 'claims_fresh', 'claims_readiness',
    'claims_ready', 'claims_serving', 'claims_effect_success', 'claims_execution',
    'claims_mutation', 'claims_policy', 'claims_native_truth', 'claims_lossless',
    'claims_drained', 'claims_work_complete', 'claims_operation_executed', 'claims_scheduled',
    'claims_reserved', 'claims_lock', 'claims_success', 'claims_stable', 'claims_resolved',
    'authority', 'authorized', 'approved', 'current_state', 'current', 'fresh', 'ready',
    'readiness', 'serving', 'effect_success', 'execution', 'mutation', 'policy_authority',
    'native_truth', 'operation_executed', 'lossless', 'drained', 'work_complete', 'success',
    'stable', 'resolved', 'auto_execute', 'macro', 'raw', 'raw_value', 'raw_body',
    'raw_log', 'raw_handle', 'raw_text', 'token', 'secret', 'bearer', 'credential',
    'password', 'cookie', 'authorization', 'value', 'path', 'raw_path', 'host_path',
    'endpoint', 'raw_endpoint', 'url', 'uri', 'fd', 'descriptor_number', 'pid', 'ppid',
    'pgid', 'cgroup', 'cgroup_path', 'systemd_unit', 'host_unit', 'pod_name',
    'container_id', 'node_name', 'process_name', 'pty_name', 'shell_job', 'pane_text',
    'command_text', 'k8s_resource_name',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'policy', 'scheduler', 'auditor'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

PRECOND_REQUIRED = COMMON_REQUIRED | {
    'precondition_id', 'target_ref', 'condition_kind', 'condition_state',
    'required_refs', 'evaluated_at_ms', 'expires_at_ms', 'mismatch_reason',
}
PRECOND_OPTIONAL = COMMON_OPTIONAL
PRECOND_ALLOWED = PRECOND_REQUIRED | PRECOND_OPTIONAL
CONDITION_KINDS = {'runtime_cycle_match', 'incarnation_match', 'generation_match', 'cursor_match', 'material_fresh', 'barrier_clear', 'hold_absent', 'unknown'}
CONDITION_STATES = {'satisfied', 'failed', 'stale', 'unknown'}
PRECOND_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-approval', 'not-execution',
    'not-mutation', 'not-current-state', 'not-readiness', 'not-serving',
    'not-effect-success', 'not-reservation', 'not-lock',
}

OPARBIT_REQUIRED = COMMON_REQUIRED | {
    'arbitration_id', 'request_ref', 'target_ref', 'verb', 'arbitration_result',
    'prior_operation_refs', 'queue_position', 'irreversible_floor', 'decided_at_ms',
    'reason', 'precondition_refs',
}
OPARBIT_OPTIONAL = COMMON_OPTIONAL
OPARBIT_ALLOWED = OPARBIT_REQUIRED | OPARBIT_OPTIONAL
VERBS = {'start', 'stop', 'restart', 'quiesce', 'clear_repair_gate', 'refresh', 'inspect', 'explain'}
MUTATING_VERBS = {'start', 'stop', 'restart', 'quiesce', 'clear_repair_gate', 'refresh'}
ARBITRATION_RESULTS = {'accepted', 'queued', 'rejected', 'replaced', 'flushed', 'irreversible', 'unknown'}
OPARBIT_NON_IMPLICATIONS = {
    'not-operation-result', 'not-execution', 'not-mutation', 'not-readiness',
    'not-serving', 'not-effect-success', 'not-authorization', 'not-approval',
    'not-current-state', 'not-reservation',
}

HOLD_REQUIRED = COMMON_REQUIRED | {
    'hold_id', 'scope_ref', 'hold_kind', 'hold_state', 'blocks_verbs',
    'allows_work_classes', 'started_at_ms', 'expires_at_ms', 'release_ref', 'reason',
}
HOLD_OPTIONAL = COMMON_OPTIONAL
HOLD_ALLOWED = HOLD_REQUIRED | HOLD_OPTIONAL
HOLD_KINDS = {'maintenance', 'operator', 'policy', 'backpressure', 'repair_gate', 'drain', 'freeze', 'unknown'}
HOLD_STATES = {'active', 'released', 'expired', 'unknown'}
WORK_CLASSES = {'inspect', 'explain', 'read_status', 'export_receipts', 'finish_inflight', 'none'}
HOLD_NON_IMPLICATIONS = {
    'not-failure', 'not-stopped', 'not-off', 'not-drained', 'not-effect-success',
    'not-current-state', 'not-readiness', 'not-serving', 'not-authorization',
    'not-execution',
}

PROGRESS_REQUIRED = COMMON_REQUIRED | {
    'progress_id', 'attempt_ref', 'checkpoint_ref', 'progress_state',
    'window_opened_ms', 'checkpoint_observed_ms', 'deadline_ms', 'extension_count',
    'hold_refs', 'stall_reason',
}
PROGRESS_OPTIONAL = COMMON_OPTIONAL
PROGRESS_ALLOWED = PROGRESS_REQUIRED | PROGRESS_OPTIONAL
PROGRESS_STATES = {'in_progress', 'advanced', 'extended', 'held', 'stalled', 'unknown'}
PROGRESS_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-stable', 'not-effect-success',
    'not-work-completion', 'not-current-state', 'not-authorization',
    'not-execution', 'not-mutation',
}

AMBIENT_REFS = {'ambient', 'current', 'pane:current', 'terminal:current', 'component:current', 'whatever:current'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:',
        '/var/', '/proc/', '/tmp/', 'current state proof', 'ready proof',
        'already executed', 'effect success', 'authorized already', 'successfully completed',
        'safe to proceed as executed', 'lock acquired means success',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False, regex: re.Pattern[str] = REF_RE) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_pattern(item, regex, f'{path}[{idx}]')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_enum_list(value: Any, enum: set[str], path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    items = require_refs(value, path, maximum=maximum, allow_empty=allow_empty)
    bad = sorted(set(items) - enum)
    if bad:
        fail(f'{path}: invalid entries {bad}')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=32))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def require_explicit_ref(value: Any, path: str) -> None:
    require_pattern(value, REF_RE, path)
    if value in AMBIENT_REFS:
        fail(f'{path}: must be an exact ref, not ambient/current context')


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=32)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_precond(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, PRECOND_ALLOWED, PRECOND_REQUIRED, 'ST-PRECOND v0')
    require_pattern(obj['precondition_id'], PRECOND_RE, '$.precondition_id')
    require_explicit_ref(obj['target_ref'], '$.target_ref')
    if obj['condition_kind'] not in CONDITION_KINDS:
        fail('$.condition_kind: invalid')
    if obj['condition_state'] not in CONDITION_STATES:
        fail('$.condition_state: invalid')
    require_refs(obj['required_refs'], '$.required_refs', maximum=16)
    require_int(obj['evaluated_at_ms'], '$.evaluated_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_text(obj['mismatch_reason'], '$.mismatch_reason')
    if obj['evaluated_at_ms'] > obj['observed_at_ms']:
        fail('$.evaluated_at_ms: cannot be after observed_at_ms')
    if obj['condition_state'] == 'satisfied':
        if obj['expires_at_ms'] <= obj['observed_at_ms']:
            fail('$.expires_at_ms: satisfied precondition must still be fresh at observation')
        if obj['mismatch_reason'] != 'none':
            fail('$.mismatch_reason: satisfied precondition must use none')
    else:
        if obj['mismatch_reason'] == 'none':
            fail('$.mismatch_reason: failed/stale/unknown precondition needs a reason')
    require_non_implications(obj['non_implications'], PRECOND_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_oparbit(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OPARBIT_ALLOWED, OPARBIT_REQUIRED, 'ST-OPARBIT v0')
    require_pattern(obj['arbitration_id'], ARBIT_RE, '$.arbitration_id')
    require_pattern(obj['request_ref'], OPREQ_RE, '$.request_ref')
    require_explicit_ref(obj['target_ref'], '$.target_ref')
    if obj['verb'] not in VERBS:
        fail('$.verb: invalid')
    if obj['arbitration_result'] not in ARBITRATION_RESULTS:
        fail('$.arbitration_result: invalid')
    require_refs(obj['prior_operation_refs'], '$.prior_operation_refs', maximum=16, allow_empty=True)
    require_int(obj['queue_position'], '$.queue_position', minimum=0, maximum=1024)
    require_bool(obj['irreversible_floor'], '$.irreversible_floor')
    require_int(obj['decided_at_ms'], '$.decided_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_text(obj['reason'], '$.reason')
    require_refs(obj['precondition_refs'], '$.precondition_refs', maximum=16, allow_empty=True, regex=PRECOND_RE)
    if obj['decided_at_ms'] > obj['observed_at_ms']:
        fail('$.decided_at_ms: cannot be after observed_at_ms')
    if obj['arbitration_result'] == 'queued' and obj['queue_position'] < 1:
        fail('$.queue_position: queued result needs a positive queue position')
    if obj['arbitration_result'] != 'queued' and obj['queue_position'] != 0:
        fail('$.queue_position: non-queued result must use zero queue position')
    if obj['arbitration_result'] == 'irreversible' and not obj['irreversible_floor']:
        fail('$.irreversible_floor: irreversible result must set irreversible_floor')
    if obj['arbitration_result'] in {'rejected', 'unknown'} and obj['reason'] == 'none':
        fail('$.reason: rejected/unknown arbitration needs a reason')
    require_non_implications(obj['non_implications'], OPARBIT_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_hold(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, HOLD_ALLOWED, HOLD_REQUIRED, 'ST-HOLD v0')
    require_pattern(obj['hold_id'], HOLD_RE, '$.hold_id')
    require_explicit_ref(obj['scope_ref'], '$.scope_ref')
    if obj['hold_kind'] not in HOLD_KINDS:
        fail('$.hold_kind: invalid')
    if obj['hold_state'] not in HOLD_STATES:
        fail('$.hold_state: invalid')
    blocked = require_enum_list(obj['blocks_verbs'], VERBS, '$.blocks_verbs', maximum=8, allow_empty=obj['hold_state'] in {'released', 'expired', 'unknown'})
    require_enum_list(obj['allows_work_classes'], WORK_CLASSES, '$.allows_work_classes', maximum=8)
    require_int(obj['started_at_ms'], '$.started_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_pattern(obj['release_ref'], REF_RE, '$.release_ref')
    require_text(obj['reason'], '$.reason')
    if obj['started_at_ms'] > obj['observed_at_ms']:
        fail('$.started_at_ms: cannot be after observed_at_ms')
    if obj['expires_at_ms'] <= obj['started_at_ms']:
        fail('$.expires_at_ms: must be after started_at_ms')
    if obj['hold_state'] == 'active':
        if not blocked:
            fail('$.blocks_verbs: active holds must block at least one verb')
        if obj['release_ref'] != 'none':
            fail('$.release_ref: active hold must use none')
        if obj['expires_at_ms'] <= obj['observed_at_ms']:
            fail('$.expires_at_ms: active hold must not already be expired')
    if obj['hold_state'] == 'released' and obj['release_ref'] == 'none':
        fail('$.release_ref: released hold needs a release ref')
    if obj['hold_state'] == 'expired' and obj['expires_at_ms'] > obj['observed_at_ms']:
        fail('$.expires_at_ms: expired hold cannot expire in the future')
    require_non_implications(obj['non_implications'], HOLD_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_progress(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, PROGRESS_ALLOWED, PROGRESS_REQUIRED, 'ST-PROGRESS v0')
    require_pattern(obj['progress_id'], PROGRESS_RE, '$.progress_id')
    require_explicit_ref(obj['attempt_ref'], '$.attempt_ref')
    require_explicit_ref(obj['checkpoint_ref'], '$.checkpoint_ref')
    if obj['progress_state'] not in PROGRESS_STATES:
        fail('$.progress_state: invalid')
    require_int(obj['window_opened_ms'], '$.window_opened_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['checkpoint_observed_ms'], '$.checkpoint_observed_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['deadline_ms'], '$.deadline_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['extension_count'], '$.extension_count', minimum=0, maximum=1024)
    require_refs(obj['hold_refs'], '$.hold_refs', maximum=16, allow_empty=True, regex=HOLD_RE)
    require_text(obj['stall_reason'], '$.stall_reason')
    if obj['window_opened_ms'] > obj['observed_at_ms']:
        fail('$.window_opened_ms: cannot be after observed_at_ms')
    if obj['checkpoint_observed_ms'] > obj['observed_at_ms']:
        fail('$.checkpoint_observed_ms: cannot be after observed_at_ms')
    if obj['checkpoint_observed_ms'] < obj['window_opened_ms']:
        fail('$.checkpoint_observed_ms: cannot precede window_opened_ms')
    if obj['progress_state'] == 'held' and not obj['hold_refs']:
        fail('$.hold_refs: held progress needs at least one hold ref')
    if obj['progress_state'] in {'stalled', 'unknown'} and obj['stall_reason'] == 'none':
        fail('$.stall_reason: stalled/unknown progress needs a reason')
    if obj['progress_state'] in {'in_progress', 'advanced', 'extended', 'held'} and obj['stall_reason'] != 'none':
        fail('$.stall_reason: non-stalled progress must use none')
    if obj['deadline_ms'] < obj['observed_at_ms'] and obj['progress_state'] not in {'stalled', 'held', 'unknown'}:
        fail('$.deadline_ms: past-deadline progress must be stalled, held, or unknown')
    if obj['progress_state'] == 'extended' and obj['extension_count'] < 1:
        fail('$.extension_count: extended progress needs at least one extension')
    require_non_implications(obj['non_implications'], PROGRESS_NON_IMPLICATIONS, '$.non_implications')
    return obj


def schema_case(case_id: str, object_kind: str, obj: dict[str, Any] | None, expect: str, why: str, *, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        assert obj is not None
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'coordination_gate', 'events': events, 'expect': expect, 'why': why}


def base_common(schema: str, witness_id: str, *, observed: int = 1200, issuer_kind: str = 'steward') -> dict[str, Any]:
    return {
        'schema': schema,
        'witness_id': witness_id,
        'cid': 'demo.web',
        'issuer': {'kind': issuer_kind, 'id': f'steward.{issuer_kind}'},
        'observed_at_ms': observed,
        'basis_refs': ['sha256:' + '1' * 64],
    }


def build_cases() -> list[dict[str, Any]]:
    precond = {
        **base_common('ST-PRECOND v0', 'wit_1000000000000001'),
        'precondition_id': 'precond_1000000000000001',
        'target_ref': 'component:demo.web',
        'condition_kind': 'runtime_cycle_match',
        'condition_state': 'satisfied',
        'required_refs': ['rtcycle_1000000000000001'],
        'evaluated_at_ms': 1180,
        'expires_at_ms': 1800,
        'mismatch_reason': 'none',
        'non_implications': sorted(PRECOND_NON_IMPLICATIONS),
    }
    stale_precond = {**precond, 'witness_id': 'wit_1000000000000002', 'precondition_id': 'precond_1000000000000002', 'condition_state': 'stale', 'expires_at_ms': 1100, 'mismatch_reason': 'runtime cycle changed'}
    failed_precond = {**precond, 'witness_id': 'wit_1000000000000003', 'precondition_id': 'precond_1000000000000003', 'condition_state': 'failed', 'mismatch_reason': 'generation mismatch'}

    hold = {
        **base_common('ST-HOLD v0', 'wit_2000000000000001', issuer_kind='operator'),
        'hold_id': 'hold_1000000000000001',
        'scope_ref': 'component:demo.web',
        'hold_kind': 'operator',
        'hold_state': 'active',
        'blocks_verbs': ['restart', 'stop'],
        'allows_work_classes': ['explain', 'inspect'],
        'started_at_ms': 1000,
        'expires_at_ms': 5000,
        'release_ref': 'none',
        'reason': 'maintenance window active',
        'non_implications': sorted(HOLD_NON_IMPLICATIONS),
    }
    released_hold = {**hold, 'witness_id': 'wit_2000000000000002', 'hold_id': 'hold_1000000000000002', 'hold_state': 'released', 'blocks_verbs': [], 'release_ref': 'opreceipt_1000000000000001'}

    queued_arbit = {
        **base_common('ST-OPARBIT v0', 'wit_3000000000000001'),
        'arbitration_id': 'arbit_1000000000000001',
        'request_ref': 'opreq_1000000000000001',
        'target_ref': 'component:demo.web',
        'verb': 'restart',
        'arbitration_result': 'queued',
        'prior_operation_refs': ['opreceipt_1000000000000000'],
        'queue_position': 1,
        'irreversible_floor': False,
        'decided_at_ms': 1190,
        'reason': 'queued behind active hold',
        'precondition_refs': ['precond_1000000000000001'],
        'non_implications': sorted(OPARBIT_NON_IMPLICATIONS),
    }
    accepted_arbit = {**queued_arbit, 'witness_id': 'wit_3000000000000002', 'arbitration_id': 'arbit_1000000000000002', 'arbitration_result': 'accepted', 'prior_operation_refs': [], 'queue_position': 0, 'reason': 'accepted for review path'}
    rejected_arbit = {**queued_arbit, 'witness_id': 'wit_3000000000000003', 'arbitration_id': 'arbit_1000000000000003', 'arbitration_result': 'rejected', 'prior_operation_refs': [], 'queue_position': 0, 'reason': 'precondition failed', 'precondition_refs': ['precond_1000000000000003']}

    progress = {
        **base_common('ST-PROGRESS v0', 'wit_4000000000000001'),
        'progress_id': 'prog_1000000000000001',
        'attempt_ref': 'opreq_1000000000000001',
        'checkpoint_ref': 'checkpoint:demo.web.boot.2',
        'progress_state': 'advanced',
        'window_opened_ms': 1000,
        'checkpoint_observed_ms': 1180,
        'deadline_ms': 2200,
        'extension_count': 0,
        'hold_refs': [],
        'stall_reason': 'none',
        'non_implications': sorted(PROGRESS_NON_IMPLICATIONS),
    }
    held_progress = {**progress, 'witness_id': 'wit_4000000000000002', 'progress_id': 'prog_1000000000000002', 'progress_state': 'held', 'hold_refs': ['hold_1000000000000001'], 'deadline_ms': 1100}
    stalled_progress = {**progress, 'witness_id': 'wit_4000000000000003', 'progress_id': 'prog_1000000000000003', 'progress_state': 'stalled', 'deadline_ms': 1100, 'stall_reason': 'deadline exceeded'}

    return [
        schema_case('precond.accept.runtime-cycle-match', 'ST-PRECOND', precond, 'accept', 'a satisfied precondition may bind an exact runtime-cycle basis without authorizing execution'),
        schema_case('precond.reject.ambient-target', 'ST-PRECOND', {**precond, 'target_ref': 'component:current'}, 'reject', 'preconditions must target exact refs, not ambient current component folklore'),
        schema_case('precond.reject.authorization-flattery', 'ST-PRECOND', {**precond, 'claims_authorization': True}, 'reject', 'precondition satisfaction is not authorization'),
        schema_case('precond.reject.expired-satisfied', 'ST-PRECOND', {**precond, 'expires_at_ms': 1100}, 'reject', 'satisfied preconditions must still be fresh at observation'),
        schema_case('oparbit.accept.queued-behind-hold', 'ST-OPARBIT', queued_arbit, 'accept', 'arbitration may queue behind existing work or holds without claiming operation success'),
        schema_case('oparbit.accept.rejected-precondition', 'ST-OPARBIT', rejected_arbit, 'accept', 'arbitration can honestly reject a request because a precondition failed'),
        schema_case('oparbit.reject.execution-flattery', 'ST-OPARBIT', {**queued_arbit, 'claims_operation_executed': True}, 'reject', 'arbitration is not operation execution or result'),
        schema_case('oparbit.reject.queued-zero-position', 'ST-OPARBIT', {**queued_arbit, 'queue_position': 0}, 'reject', 'queued arbitration needs a positive queue position'),
        schema_case('oparbit.reject.ambient-target', 'ST-OPARBIT', {**queued_arbit, 'target_ref': 'current'}, 'reject', 'arbitration must not target current/ambient state'),
        schema_case('hold.accept.active-maintenance', 'ST-HOLD', hold, 'accept', 'an active hold can block selected verbs while allowing observation-only work'),
        schema_case('hold.accept.released-with-ref', 'ST-HOLD', released_hold, 'accept', 'released holds need a release witness and remain non-executing evidence'),
        schema_case('hold.reject.failure-flattery', 'ST-HOLD', {**hold, 'claims_stopped': True}, 'reject', 'a hold is not stopped/off/failure truth'),
        schema_case('hold.reject.active-without-blocks', 'ST-HOLD', {**hold, 'blocks_verbs': []}, 'reject', 'active holds must say what they block'),
        schema_case('hold.reject.released-without-release-ref', 'ST-HOLD', {**released_hold, 'release_ref': 'none'}, 'reject', 'released holds need a release ref'),
        schema_case('progress.accept.advanced-not-ready', 'ST-PROGRESS', progress, 'accept', 'progress can advance a window without proving readiness or stability'),
        schema_case('progress.accept.held-past-deadline', 'ST-PROGRESS', held_progress, 'accept', 'held progress can explain a past deadline without pretending stall or readiness'),
        schema_case('progress.accept.stalled', 'ST-PROGRESS', stalled_progress, 'accept', 'a past deadline can settle as stalled with a reason'),
        schema_case('progress.reject.ready-flattery', 'ST-PROGRESS', {**progress, 'claims_ready': True}, 'reject', 'progress is not readiness'),
        schema_case('progress.reject.past-deadline-in-progress', 'ST-PROGRESS', {**progress, 'deadline_ms': 1100}, 'reject', 'past-deadline progress cannot stay in progress without hold/stall/unknown downgrade'),
        schema_case('progress.reject.held-without-hold-ref', 'ST-PROGRESS', {**held_progress, 'hold_refs': []}, 'reject', 'held progress needs a hold ref'),
        schema_case('oparbit.reject.duplicate-json-key', 'ST-OPARBIT', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-OPARBIT v0","schema":"ST-OPARBIT v0","witness_id":"wit_3000000000000004","cid":"demo.web","issuer":{"kind":"steward","id":"steward.core"},"observed_at_ms":1200,"basis_refs":["sha256:1111111111111111111111111111111111111111111111111111111111111111"],"non_implications":[],"arbitration_id":"arbit_1000000000000004","request_ref":"opreq_1000000000000001","target_ref":"component:demo.web","verb":"restart","arbitration_result":"accepted","prior_operation_refs":[],"queue_position":0,"irreversible_floor":false,"decided_at_ms":1190,"reason":"accepted","precondition_refs":[]}'),

        flow_case('coordination.accept.hold-queues-restart-and-holds-progress', [
            {'event': 'precondition', 'packet': precond},
            {'event': 'hold', 'packet': hold},
            {'event': 'arbitration', 'packet': queued_arbit},
            {'event': 'progress', 'packet': held_progress},
        ], 'accept', 'a hold can gate a restart into a queued arbitration and held progress without changing lifecycle truth'),
        flow_case('coordination.accept.failed-precondition-rejects-request', [
            {'event': 'precondition', 'packet': failed_precond},
            {'event': 'arbitration', 'packet': rejected_arbit},
        ], 'accept', 'failed preconditions can produce explicit rejected arbitration'),
        flow_case('coordination.reject.accepted-despite-active-hold', [
            {'event': 'precondition', 'packet': precond},
            {'event': 'hold', 'packet': hold},
            {'event': 'arbitration', 'packet': accepted_arbit},
        ], 'reject', 'accepted mutating arbitration cannot ignore an active hold blocking that verb'),
        flow_case('coordination.reject.arbitration-uses-stale-precondition', [
            {'event': 'precondition', 'packet': stale_precond},
            {'event': 'arbitration', 'packet': {**accepted_arbit, 'precondition_refs': ['precond_1000000000000002']}},
        ], 'reject', 'accepted arbitration cannot use stale precondition evidence'),
        flow_case('coordination.reject.progress-past-deadline-without-downgrade', [
            {'event': 'progress', 'packet': {**progress, 'deadline_ms': 1100}},
        ], 'reject', 'progress windows must downgrade at expired deadlines'),
        flow_case('coordination.reject.progress-as-readiness', [
            {'event': 'progress', 'packet': progress, 'claims_ready': True},
        ], 'reject', 'progress events cannot claim readiness'),
        flow_case('coordination.reject.held-progress-without-known-hold', [
            {'event': 'progress', 'packet': held_progress},
        ], 'reject', 'held progress must point at a known hold'),
        flow_case('coordination.reject.duplicate-arbitration-drift', [
            {'event': 'precondition', 'packet': precond},
            {'event': 'arbitration', 'packet': queued_arbit},
            {'event': 'arbitration', 'packet': {**queued_arbit, 'reason': 'queued behind different work'}},
        ], 'reject', 'arbitration ids cannot be reused for different canonical packets'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-PRECOND':
            validate_precond(obj)
        elif kind == 'ST-OPARBIT':
            validate_oparbit(obj)
        elif kind == 'ST-HOLD':
            validate_hold(obj)
        elif kind == 'ST-PROGRESS':
            validate_progress(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        preconds: dict[str, dict[str, Any]] = {}
        holds: dict[str, dict[str, Any]] = {}
        seen_packets: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'precondition':
                precond = validate_precond(packet)
                check_packet_identity(seen_packets, precond['precondition_id'], precond, where)
                preconds[precond['precondition_id']] = precond
            elif kind == 'hold':
                hold = validate_hold(packet)
                check_packet_identity(seen_packets, hold['hold_id'], hold, where)
                holds[hold['hold_id']] = hold
            elif kind == 'arbitration':
                arbit = validate_oparbit(packet)
                check_packet_identity(seen_packets, arbit['arbitration_id'], arbit, where)
                for ref in arbit['precondition_refs']:
                    precond = preconds.get(ref)
                    if precond is None:
                        fail(f'{where}: arbitration references unknown precondition {ref}')
                    if arbit['arbitration_result'] in {'accepted', 'queued', 'replaced', 'flushed', 'irreversible'}:
                        if precond['condition_state'] != 'satisfied':
                            fail(f'{where}: non-rejected arbitration requires satisfied precondition {ref}')
                        if precond['expires_at_ms'] <= arbit['decided_at_ms']:
                            fail(f'{where}: arbitration uses expired precondition {ref}')
                for hold in holds.values():
                    if hold['hold_state'] == 'active' and arbit['verb'] in hold['blocks_verbs'] and arbit['arbitration_result'] in {'accepted', 'replaced', 'flushed', 'irreversible'}:
                        fail(f'{where}: arbitration accepted/overrode mutating verb despite active hold {hold["hold_id"]}')
            elif kind == 'progress':
                progress = validate_progress(packet)
                check_packet_identity(seen_packets, progress['progress_id'], progress, where)
                for ref in progress['hold_refs']:
                    hold = holds.get(ref)
                    if hold is None:
                        fail(f'{where}: progress references unknown hold {ref}')
                    if hold['hold_state'] != 'active':
                        fail(f'{where}: held progress references non-active hold {ref}')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'coordination_gate':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-coordination-gate-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-coordination-gate-corpus] FAIL: corpus is stale; run tools/steward_coordination_gate_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-coordination-gate-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
