#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    canonical_bytes,
    digest,
    fail,
    no_duplicate_object_pairs,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/control-operation-corpus-v0.jsonl'

OP_ID_RE = re.compile(r'^op_[a-z0-9]{16}$')
IDEMPOTENCY_RE = re.compile(r'^idem_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
REASON_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

OPREQ_REQUIRED = {'schema', 'op_id', 'cid', 'verb', 'issuer', 'target', 'reason', 'preconditions', 'idempotency_key'}
OPREQ_OPTIONAL = {'requested_at_ms', 'not_before_ms', 'deadline_ms'}
OPREQ_ALLOWED = OPREQ_REQUIRED | OPREQ_OPTIONAL
OPREQ_FORBIDDEN_ANYWHERE = {
    'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path', 'systemd_unit', 'systemd_job_path',
    'pod_name', 'container_id', 'process_name', 'host_unit', 'latest_matching_service',
    'pane_text', 'pty_name', 'shell_job', 'token', 'secret', 'raw_handle', 'bearer',
}
VERBS = {'start', 'stop', 'restart', 'quiesce', 'refresh'}
ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'operator', 'automation', 'repair_gate', 'adapter'}
TARGET_REQUIRED = {'kind', 'cid'}
TARGET_OPTIONAL = {'expected_manifest_digest', 'expected_cycle', 'expected_activation_digest', 'expected_status_barrier'}
TARGET_ALLOWED = TARGET_REQUIRED | TARGET_OPTIONAL
PRECOND_REQUIRED = {'kind', 'ref', 'state'}
PRECOND_ALLOWED = PRECOND_REQUIRED
PRECOND_KINDS = {'manifest_digest', 'runtime_cycle', 'fresh_intent', 'repair_gate', 'status_barrier', 'activation_digest', 'operator_approval'}
PRECOND_STATES = {'present', 'waived'}

OPRECEIPT_REQUIRED = {'schema', 'op_id', 'cid', 'verb', 'request_digest', 'issuer', 'phase', 'result', 'basis', 'boundary_refs', 'non_implications'}
OPRECEIPT_OPTIONAL = {'observed_at_ms', 'message'}
OPRECEIPT_ALLOWED = OPRECEIPT_REQUIRED | OPRECEIPT_OPTIONAL
OPRECEIPT_FORBIDDEN_ANYWHERE = OPREQ_FORBIDDEN_ANYWHERE | {
    'claims_ready', 'claims_stopped', 'claims_serving', 'result_is_state',
    'component_state', 'ready', 'stopped', 'serving', 'raw_log', 'scrollback',
}
PHASES = {'accepted', 'queued', 'running', 'finished'}
RESULTS = {'none', 'completed', 'denied', 'deferred', 'canceled', 'timed_out', 'dependency_blocked', 'skipped', 'failed', 'unknown'}
BASIS_REQUIRED = {'source', 'summary'}
BASIS_OPTIONAL = {'adapter_ref', 'recovery_epoch'}
BASIS_ALLOWED = BASIS_REQUIRED | BASIS_OPTIONAL
BASIS_SOURCES = {'steward', 'adapter', 'operator', 'recovery'}
NON_IMPLICATIONS = {
    'not-readiness',
    'not-serving',
    'not-effect-success',
    'not-component-terminal-state',
    'not-traffic-binding',
    'not-custody',
    'not-current-after-recovery',
}


def scan_forbidden_keys(value: Any, forbidden: set[str], path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in forbidden:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, forbidden, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, forbidden, f'{path}[{idx}]')


def require_reason(value: Any, path: str) -> None:
    require_pattern(value, REASON_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered:
        fail(f'{path}: raw secret-looking material is not a reason')


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_target(value: Any, cid: str, verb: str, path: str) -> dict[str, Any]:
    target = require_object(value, path)
    require_closed_keys(target, TARGET_ALLOWED, TARGET_REQUIRED, path)
    if target['kind'] != 'component':
        fail(f'{path}.kind: expected component')
    require_pattern(target['cid'], CID_RE, f'{path}.cid')
    if target['cid'] != cid:
        fail(f'{path}.cid: must match root cid')
    if 'expected_manifest_digest' in target:
        require_pattern(target['expected_manifest_digest'], DIGEST_RE, f'{path}.expected_manifest_digest')
    if 'expected_cycle' in target:
        require_pattern(target['expected_cycle'], CYCLE_RE, f'{path}.expected_cycle')
    if 'expected_activation_digest' in target:
        require_pattern(target['expected_activation_digest'], DIGEST_RE, f'{path}.expected_activation_digest')
    if 'expected_status_barrier' in target:
        require_pattern(target['expected_status_barrier'], REF_RE, f'{path}.expected_status_barrier')
    if verb == 'start' and 'expected_manifest_digest' not in target:
        fail(f'{path}: start requires expected_manifest_digest')
    if verb in {'stop', 'restart', 'quiesce', 'refresh'} and 'expected_cycle' not in target:
        fail(f'{path}: {verb} requires expected_cycle')
    return target


def validate_precondition(value: Any, path: str) -> dict[str, Any]:
    pre = require_object(value, path)
    require_closed_keys(pre, PRECOND_ALLOWED, PRECOND_REQUIRED, path)
    if pre['kind'] not in PRECOND_KINDS:
        fail(f'{path}.kind: invalid precondition kind')
    require_pattern(pre['ref'], REF_RE, f'{path}.ref')
    if pre['state'] not in PRECOND_STATES:
        fail(f'{path}.state: invalid precondition state')
    return pre


def validate_preconditions(value: Any, path: str) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > 8:
        fail(f'{path}: too many preconditions')
    out: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for idx, item in enumerate(value):
        pre = validate_precondition(item, f'{path}[{idx}]')
        pair = (pre['kind'], pre['ref'])
        if pair in seen:
            fail(f'{path}: duplicate precondition {pair}')
        seen.add(pair)
        out.append(pre)
    return out


def validate_st_opreq(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, OPREQ_FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, OPREQ_ALLOWED, OPREQ_REQUIRED, '$')
    if obj['schema'] != 'ST-OPREQ v0':
        fail('$.schema: expected ST-OPREQ v0')
    require_pattern(obj['op_id'], OP_ID_RE, '$.op_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    if obj['verb'] not in VERBS:
        fail('$.verb: invalid verb')
    validate_issuer(obj['issuer'], '$.issuer')
    validate_target(obj['target'], obj['cid'], obj['verb'], '$.target')
    require_reason(obj['reason'], '$.reason')
    validate_preconditions(obj['preconditions'], '$.preconditions')
    require_pattern(obj['idempotency_key'], IDEMPOTENCY_RE, '$.idempotency_key')
    for field in ('requested_at_ms', 'not_before_ms', 'deadline_ms'):
        if field in obj:
            require_int(obj[field], f'$.{field}', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'not_before_ms' in obj and 'deadline_ms' in obj and obj['not_before_ms'] > obj['deadline_ms']:
        fail('$.not_before_ms: cannot exceed deadline_ms')
    if 'requested_at_ms' in obj and 'deadline_ms' in obj and obj['requested_at_ms'] > obj['deadline_ms']:
        fail('$.deadline_ms: already before request time')
    return obj


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def validate_basis(value: Any, path: str) -> dict[str, Any]:
    basis = require_object(value, path)
    require_closed_keys(basis, BASIS_ALLOWED, BASIS_REQUIRED, path)
    if basis['source'] not in BASIS_SOURCES:
        fail(f'{path}.source: invalid source')
    require_reason(basis['summary'], f'{path}.summary')
    if 'adapter_ref' in basis:
        require_pattern(basis['adapter_ref'], REF_RE, f'{path}.adapter_ref')
    if 'recovery_epoch' in basis:
        require_pattern(basis['recovery_epoch'], REF_RE, f'{path}.recovery_epoch')
    return basis


def validate_st_opreceipt(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, OPRECEIPT_FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, OPRECEIPT_ALLOWED, OPRECEIPT_REQUIRED, '$')
    if obj['schema'] != 'ST-OPRECEIPT v0':
        fail('$.schema: expected ST-OPRECEIPT v0')
    require_pattern(obj['op_id'], OP_ID_RE, '$.op_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    if obj['verb'] not in VERBS:
        fail('$.verb: invalid verb')
    require_pattern(obj['request_digest'], DIGEST_RE, '$.request_digest')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['phase'] not in PHASES:
        fail('$.phase: invalid phase')
    if obj['result'] not in RESULTS:
        fail('$.result: invalid result')
    if obj['phase'] == 'finished' and obj['result'] == 'none':
        fail('$.result: finished receipt requires terminal result')
    if obj['phase'] != 'finished' and obj['result'] != 'none':
        fail('$.result: non-finished receipt must use none')
    validate_basis(obj['basis'], '$.basis')
    require_refs(obj['boundary_refs'], '$.boundary_refs', maximum=16)
    non_implications = require_refs(obj['non_implications'], '$.non_implications', maximum=16)
    invalid = [item for item in non_implications if item not in NON_IMPLICATIONS]
    if invalid:
        fail(f'$.non_implications: invalid values {invalid}')
    if obj['result'] in {'completed', 'timed_out', 'failed', 'unknown'} and 'not-component-terminal-state' not in non_implications:
        fail('$.non_implications: terminal-looking results must explicitly refuse component-state implication')
    if obj['result'] == 'completed' and not obj['boundary_refs']:
        fail('$.boundary_refs: completed operation needs operation boundary evidence')
    if obj['basis']['source'] == 'recovery' and 'not-current-after-recovery' not in non_implications:
        fail('$.non_implications: recovery receipts must refuse currentness')
    if 'observed_at_ms' in obj:
        require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'message' in obj:
        require_reason(obj['message'], '$.message')
    return obj


def base_issuer() -> dict[str, Any]:
    return {'kind': 'operator', 'id': 'operator/johnny'}


def base_start_request() -> dict[str, Any]:
    return {
        'schema': 'ST-OPREQ v0',
        'op_id': 'op_0000000000000001',
        'cid': 'demo.web',
        'verb': 'start',
        'issuer': base_issuer(),
        'target': {
            'kind': 'component',
            'cid': 'demo.web',
            'expected_manifest_digest': 'sha256:' + 'a' * 64,
        },
        'reason': 'operator requested start during proof slice',
        'preconditions': [
            {'kind': 'manifest_digest', 'ref': 'sha256:' + 'a' * 64, 'state': 'present'},
            {'kind': 'fresh_intent', 'ref': 'intent/start-demo-web', 'state': 'present'},
        ],
        'idempotency_key': 'idem_0000000000000001',
        'requested_at_ms': 1000,
        'deadline_ms': 30000,
    }


def base_stop_request() -> dict[str, Any]:
    return {
        'schema': 'ST-OPREQ v0',
        'op_id': 'op_0000000000000002',
        'cid': 'demo.web',
        'verb': 'stop',
        'issuer': base_issuer(),
        'target': {
            'kind': 'component',
            'cid': 'demo.web',
            'expected_cycle': 'cycle-1',
            'expected_status_barrier': 'barrier/ready-cycle-1',
        },
        'reason': 'operator requested bounded stop',
        'preconditions': [
            {'kind': 'runtime_cycle', 'ref': 'cycle-1', 'state': 'present'},
            {'kind': 'fresh_intent', 'ref': 'intent/stop-demo-web', 'state': 'present'},
        ],
        'idempotency_key': 'idem_0000000000000002',
        'requested_at_ms': 2000,
        'deadline_ms': 62000,
    }


def receipt_for(request: dict[str, Any], *, phase: str = 'finished', result: str = 'completed', source: str = 'steward') -> dict[str, Any]:
    non_implications = ['not-readiness', 'not-serving', 'not-effect-success', 'not-component-terminal-state']
    if source == 'recovery':
        non_implications.append('not-current-after-recovery')
    return {
        'schema': 'ST-OPRECEIPT v0',
        'op_id': request['op_id'],
        'cid': request['cid'],
        'verb': request['verb'],
        'request_digest': digest(request),
        'issuer': request['issuer'],
        'phase': phase,
        'result': result,
        'basis': {'source': source, 'summary': 'operation boundary recorded'},
        'boundary_refs': ['op-boundary/' + request['op_id']],
        'non_implications': non_implications,
        'observed_at_ms': request.get('requested_at_ms', 0) + 250,
    }


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {
        'case_id': case_id,
        'kind': 'operation_flow',
        'expect': expect,
        'why': why,
        'events': events,
    }


def build_cases() -> list[dict[str, Any]]:
    start = base_start_request()
    stop = base_stop_request()
    start_receipt = receipt_for(start)
    stop_receipt = receipt_for(stop)
    queued_receipt = receipt_for(stop, phase='queued', result='none')
    timeout_receipt = receipt_for(stop, phase='finished', result='timed_out')
    unknown_recovery = receipt_for(stop, phase='finished', result='unknown', source='recovery')
    unknown_recovery['basis'] = {'source': 'recovery', 'summary': 'manager recovery could not prove prior operation fate', 'recovery_epoch': 'recovery/epoch-1'}
    unknown_recovery['boundary_refs'] = []

    mismatched_stop = json.loads(json.dumps(stop))
    mismatched_stop['reason'] = 'operator requested different bounded stop'

    start_with_pid = json.loads(json.dumps(start))
    start_with_pid['target']['pid'] = 1234

    stop_without_cycle = json.loads(json.dumps(stop))
    del stop_without_cycle['target']['expected_cycle']

    host_unit_request = json.loads(json.dumps(stop))
    host_unit_request['target']['systemd_unit'] = 'demo.service'

    future_bad_time = json.loads(json.dumps(start))
    future_bad_time['not_before_ms'] = 50000
    future_bad_time['deadline_ms'] = 30000

    completion_claims_state = json.loads(json.dumps(stop_receipt))
    completion_claims_state['claims_stopped'] = True

    nonfinished_with_result = json.loads(json.dumps(queued_receipt))
    nonfinished_with_result['result'] = 'completed'

    finished_without_result = json.loads(json.dumps(stop_receipt))
    finished_without_result['result'] = 'none'

    completed_without_boundary = json.loads(json.dumps(stop_receipt))
    completed_without_boundary['boundary_refs'] = []

    recovery_flatters_current = json.loads(json.dumps(unknown_recovery))
    recovery_flatters_current['non_implications'] = [x for x in recovery_flatters_current['non_implications'] if x != 'not-current-after-recovery']

    timed_out_flatters_state = json.loads(json.dumps(timeout_receipt))
    timed_out_flatters_state['non_implications'] = ['not-readiness', 'not-serving']

    return [
        schema_case('opreq.accept.start', 'ST-OPREQ', start, 'accept', 'start request names exact component target and manifest precondition'),
        schema_case('opreq.accept.stop-cycle-fenced', 'ST-OPREQ', stop, 'accept', 'stop request names expected runtime cycle instead of host folklore'),
        schema_case('opreq.reject.raw-pid-target', 'ST-OPREQ', start_with_pid, 'reject', 'portable operation packets must not target raw PIDs'),
        schema_case('opreq.reject.host-unit-target', 'ST-OPREQ', host_unit_request, 'reject', 'host unit names are adapter facts, not portable control authority'),
        schema_case('opreq.reject.stop-without-cycle', 'ST-OPREQ', stop_without_cycle, 'reject', 'stop/restart/quiesce/refresh operations require a cycle fence'),
        schema_case('opreq.reject.bad-idempotency-key', 'ST-OPREQ', {**start, 'idempotency_key': 'retry-me'}, 'reject', 'idempotency keys must be canonical scoped selectors'),
        schema_case('opreq.reject-bad-time-window', 'ST-OPREQ', future_bad_time, 'reject', 'not-before cannot be later than deadline'),
        schema_case('opreq.reject.duplicate-json-key', 'ST-OPREQ', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-OPREQ v0","schema":"ST-OPREQ v0","op_id":"op_0000000000000001","cid":"demo.web","verb":"start","issuer":{"kind":"operator","id":"operator/johnny"},"target":{"kind":"component","cid":"demo.web","expected_manifest_digest":"sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},"reason":"operator start","preconditions":[],"idempotency_key":"idem_0000000000000001"}'),
        schema_case('opreceipt.accept.completed', 'ST-OPRECEIPT', start_receipt, 'accept', 'completed operation receipt has request digest, boundary evidence, and explicit non-implications'),
        schema_case('opreceipt.accept.queued', 'ST-OPRECEIPT', queued_receipt, 'accept', 'queued receipt uses result none and avoids pretending effect'),
        schema_case('opreceipt.accept.timeout', 'ST-OPRECEIPT', timeout_receipt, 'accept', 'timeout is a control-operation result, not component terminal state'),
        schema_case('opreceipt.accept.recovery-unknown', 'ST-OPRECEIPT', unknown_recovery, 'accept', 'manager recovery may preserve an operation receipt while downgrading currentness'),
        schema_case('opreceipt.reject.claims-stopped', 'ST-OPRECEIPT', completion_claims_state, 'reject', 'operation completion must not claim component stopped'),
        schema_case('opreceipt.reject.nonfinished-with-result', 'ST-OPRECEIPT', nonfinished_with_result, 'reject', 'non-finished receipt cannot report a terminal result'),
        schema_case('opreceipt.reject.finished-without-result', 'ST-OPRECEIPT', finished_without_result, 'reject', 'finished receipt must name terminal result'),
        schema_case('opreceipt.reject.completed-without-boundary', 'ST-OPRECEIPT', completed_without_boundary, 'reject', 'completed operation needs an operation boundary ref'),
        schema_case('opreceipt.reject.recovery-currentness-flattery', 'ST-OPRECEIPT', recovery_flatters_current, 'reject', 'recovery receipts must explicitly refuse currentness'),
        schema_case('opreceipt.reject.timeout-as-state', 'ST-OPRECEIPT', timed_out_flatters_state, 'reject', 'timeout-looking receipts must refuse component-state implication'),

        flow_case('opflow.accept.request-then-completed-receipt', [
            {'event': 'request', 'opreq': start},
            {'event': 'receipt', 'opreceipt': start_receipt},
        ], 'accept', 'receipt must bind to exact request digest'),
        flow_case('opflow.reject.receipt-request-digest-mismatch', [
            {'event': 'request', 'opreq': stop},
            {'event': 'receipt', 'opreceipt': {**stop_receipt, 'request_digest': digest(start)}},
        ], 'reject', 'receipt for one operation cannot settle a different request'),
        flow_case('opflow.reject.same-idempotency-different-request', [
            {'event': 'request', 'opreq': stop},
            {'event': 'request', 'opreq': {**mismatched_stop, 'op_id': 'op_0000000000000003'}},
        ], 'reject', 'same idempotency key cannot cover different canonical operation intent'),
        flow_case('opflow.accept.same-idempotency-same-request', [
            {'event': 'request', 'opreq': stop},
            {'event': 'request', 'opreq': stop},
        ], 'accept', 'duplicate operation packet with same digest is a replay, not a widened mutation'),
        flow_case('opflow.accept.recovery-downgrade', [
            {'event': 'request', 'opreq': stop},
            {'event': 'receipt', 'opreceipt': queued_receipt},
            {'event': 'manager_recovery', 'epoch': 'recovery/epoch-1'},
            {'event': 'receipt', 'opreceipt': unknown_recovery},
        ], 'accept', 'manager recovery can downgrade an in-flight operation to unknown without inventing success'),
        flow_case('opflow.reject.recovery-continues-running-current', [
            {'event': 'request', 'opreq': stop},
            {'event': 'receipt', 'opreceipt': queued_receipt},
            {'event': 'manager_recovery', 'epoch': 'recovery/epoch-1'},
            {'event': 'receipt', 'opreceipt': {**queued_receipt, 'observed_at_ms': 4000}},
        ], 'reject', 'after manager recovery, prior running or queued currentness must reconcile or downgrade'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        if case['object_kind'] == 'ST-OPREQ':
            validate_st_opreq(obj)
        elif case['object_kind'] == 'ST-OPRECEIPT':
            validate_st_opreceipt(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        requests_by_op: dict[str, dict[str, Any]] = {}
        request_digest_by_op: dict[str, str] = {}
        idem_digest: dict[str, str] = {}
        recovered = False
        recovery_epoch = ''
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'request':
                req = validate_st_opreq(ev['opreq'])
                req_digest = digest(req)
                op_id = req['op_id']
                if op_id in request_digest_by_op and request_digest_by_op[op_id] != req_digest:
                    fail(f'{where}: op_id reused for different request')
                idem = req['idempotency_key']
                if idem in idem_digest and idem_digest[idem] != req_digest:
                    fail(f'{where}: same idempotency key different request digest')
                requests_by_op[op_id] = req
                request_digest_by_op[op_id] = req_digest
                idem_digest[idem] = req_digest
            elif kind == 'receipt':
                receipt = validate_st_opreceipt(ev['opreceipt'])
                op_id = receipt['op_id']
                if op_id not in request_digest_by_op:
                    fail(f'{where}: receipt before request')
                if receipt['request_digest'] != request_digest_by_op[op_id]:
                    fail(f'{where}: request digest mismatch')
                req = requests_by_op[op_id]
                if receipt['cid'] != req['cid'] or receipt['verb'] != req['verb']:
                    fail(f'{where}: receipt cid/verb mismatch')
                if recovered and receipt['phase'] in {'queued', 'running'} and receipt['basis']['source'] != 'recovery':
                    fail(f'{where}: post-recovery receipt keeps pre-recovery currentness')
                if recovered and receipt['basis']['source'] == 'recovery':
                    if receipt['basis'].get('recovery_epoch') != recovery_epoch:
                        fail(f'{where}: wrong recovery epoch')
            elif kind == 'manager_recovery':
                require_pattern(ev.get('epoch'), REF_RE, f'{where}.epoch')
                recovered = True
                recovery_epoch = ev['epoch']
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        case_id = case.get('case_id')
        if not isinstance(case_id, str) or not case_id:
            failures.append('case without valid case_id')
            continue
        if case_id in seen:
            failures.append(f'{case_id}: duplicate case_id')
            continue
        seen.add(case_id)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'operation_flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{case_id}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{case_id}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-operation-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic operation corpus')
    ap.add_argument('--check', action='store_true', help='check operation corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-operation-corpus] FAIL: corpus is stale; run tools/steward_operation_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-operation-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
