#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

from gen_schema_readme import render_schema_readme
from gen_verification_readme import render_verification_readme
from harness_registry import HARNESS_SCRIPTS, harness_metadata, harness_names, harness_packet_map
from run_corpora import run_entries
from schema_registry_utils import machine_schema_filenames, parse_schema_registry_rows

ROOT = Path(__file__).resolve().parents[1]
ALLOW_URL_FILES = {
    'docs/00-meta/bibliography.md',
    'docs/00-meta/external-source-locks.json',
    'RELEASE-MANIFEST.json',
}
MD_LINK_RE = re.compile(r'\[[^\]]+\]\(([^)]+)\)')
REF_DEF_RE = re.compile(r'\*\*(REF-[A-Z0-9-]+)\*\*')
RAW_URL_RE = re.compile(r'https?://[^\s)>\]]+')
TOP_RE = re.compile(r'^##\s+Revised(\d+)\s+\((\d{4})-(\d{2})-(\d{2})\)\s*$')
BIB_RE = re.compile(r'^- \*\*(REF-[A-Z0-9-]+)\*\* .* URL: (https?://\S+)\s*$', re.M)


def fail(msg: str) -> None:
    raise SystemExit(f'[lint] FAIL: {msg}')


def parse_changelog_top() -> tuple[int, str, list[str]]:
    lines = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8').splitlines()
    for i, ln in enumerate(lines):
        m = TOP_RE.match(ln.strip())
        if not m:
            continue
        rev = int(m.group(1))
        date = f'{m.group(2)}-{m.group(3)}-{m.group(4)}'
        bullets: list[str] = []
        for rest in lines[i + 1:]:
            if rest.startswith('## '):
                break
            m2 = re.match(r'^-\s+(.+?)\s*$', rest)
            if m2:
                bullets.append(f'- {m2.group(1).strip()}')
        if not bullets:
            fail('top CHANGELOG entry has no bullets')
        return rev, date, bullets
    fail('CHANGELOG.md missing top revision')


def parse_changelog_bullets() -> list[str]:
    return parse_changelog_top()[2]


def check_readme_latest_sync() -> None:
    readme = (ROOT / 'README.md').read_text(encoding='utf-8').splitlines()
    start = None
    for i, ln in enumerate(readme):
        if ln.strip() == '## What the latest revision adds':
            start = i + 1
            break
    if start is None:
        fail('README.md missing latest revision section')
    bullets: list[str] = []
    for ln in readme[start:]:
        if ln.startswith('## '):
            break
        m = re.match(r'^-\s+(.+?)\s*$', ln)
        if m:
            bullets.append(f'- {m.group(1).strip()}')
    if bullets != parse_changelog_bullets():
        fail('README latest revision bullets are stale relative to top CHANGELOG entry')



def check_harness_registry_metadata() -> None:
    entries = list(harness_metadata())
    if not entries:
        fail('harness registry has no metadata entries')
    packet_re = re.compile(r'^(CH-[A-Z0-9]+|ST-[A-Z0-9]+)$')
    seen_scripts: set[str] = set()
    seen_corpora: set[str] = set()
    seen_docs: set[str] = set()
    seen_packets: set[str] = set()
    for idx, entry in enumerate(entries):
        for key in ('script', 'corpus', 'doc'):
            value = entry.get(key)
            if not isinstance(value, str) or not value:
                fail(f'harness metadata row {idx}: missing {key}')
            if value.startswith('/') or '..' in Path(value).parts:
                fail(f'harness metadata row {idx}: unsafe {key} path {value}')
        packets = entry.get('packet_ids')
        if not isinstance(packets, tuple) or not packets:
            fail(f'harness metadata row {idx}: packet_ids must be a non-empty tuple')
        for packet in packets:
            if not isinstance(packet, str) or not packet_re.match(packet):
                fail(f'harness metadata row {idx}: invalid packet id {packet!r}')
            if packet in seen_packets:
                fail(f'harness metadata duplicate packet id {packet}')
            seen_packets.add(packet)
        script = entry['script']
        corpus = entry['corpus']
        doc = entry['doc']
        if script in seen_scripts:
            fail(f'harness metadata duplicate script {script}')
        if corpus in seen_corpora:
            fail(f'harness metadata duplicate corpus {corpus}')
        if doc in seen_docs:
            fail(f'harness metadata duplicate doc {doc}')
        seen_scripts.add(script)
        seen_corpora.add(corpus)
        seen_docs.add(doc)
        if not (ROOT / script).exists():
            fail(f'harness metadata missing script {script}')
        if not (ROOT / corpus).exists():
            fail(f'harness metadata missing corpus {corpus}')
        if not (ROOT / doc).exists():
            fail(f'harness metadata missing doc {doc}')
        expected_doc = 'docs/40-verification/' + Path(corpus).with_suffix('.md').name
        if doc != expected_doc:
            fail(f'harness metadata doc mismatch for {corpus}; expected {expected_doc}, got {doc}')
        script_text = (ROOT / script).read_text(encoding='utf-8')
        if corpus not in script_text:
            fail(f'harness metadata corpus path {corpus} not declared in {script}')
        for packet in packets:
            if packet not in script_text:
                fail(f'harness metadata packet id {packet} not declared in {script}')
    if [entry['script'] for entry in entries] != HARNESS_SCRIPTS:
        fail('HARNESS_SCRIPTS must be derived from HARNESS_ENTRIES in the same order')


def check_registered_harnesses_exist() -> None:
    if len(HARNESS_SCRIPTS) != len(set(HARNESS_SCRIPTS)):
        fail('HARNESS_SCRIPTS contains duplicate entries')
    for rel in HARNESS_SCRIPTS:
        path = ROOT / rel
        if not path.exists():
            fail(f'missing harness listed in HARNESS_SCRIPTS: {rel}')


def check_corpora() -> None:
    check_registered_harnesses_exist()
    run_entries(write=False, check=True)



def check_schema_registry_sync() -> None:
    registry = ROOT / 'docs/30-architecture/schema-registry.md'
    rows = parse_schema_registry_rows()
    if not rows:
        fail('schema registry has no rows')
    listed_schemas: set[str] = set()
    for schema_id, _meaning, human, machine, checker in rows:
        for label, cell in [('human spec', human), ('machine profile', machine), ('checker', checker)]:
            if cell == 'n/a':
                continue
            m = re.fullmatch(r'`([^`]+)`', cell)
            if not m:
                fail(f'schema registry row {schema_id}: {label} must be a single backtick path or n/a')
            rel = m.group(1)
            target = (registry.parent / rel).resolve()
            try:
                target.relative_to(ROOT.resolve())
            except ValueError:
                fail(f'schema registry row {schema_id}: {label} escapes repo: {rel}')
            if not target.exists():
                fail(f'schema registry row {schema_id}: missing {label}: {rel}')
            if label == 'machine profile' and rel.startswith('../../schemas/'):
                listed_schemas.add(Path(rel).name)
    actual_schemas = {p.name for p in (ROOT / 'schemas').glob('*.schema.json')}
    if listed_schemas != actual_schemas:
        fail(f'schema registry/schema dir mismatch; listed={sorted(listed_schemas)}, actual={sorted(actual_schemas)}')


def check_corpus_docs_sync() -> None:
    corpora = ROOT / 'docs/40-verification/corpora'
    if not corpora.exists():
        fail('missing docs/40-verification/corpora')
    for path in sorted(corpora.glob('*.jsonl')):
        doc = ROOT / 'docs/40-verification' / (path.stem + '.md')
        if not doc.exists():
            fail(f'missing verification doc for corpus {path.name}')
    readme = (ROOT / 'docs/40-verification/README.md').read_text(encoding='utf-8')
    for path in sorted(corpora.glob('*.jsonl')):
        if path.name not in readme:
            fail(f'verification README missing corpus {path.name}')


def check_verification_readme_sync() -> None:
    readme = ROOT / 'docs/40-verification/README.md'
    if not readme.exists():
        fail('missing docs/40-verification/README.md')
    if readme.read_text(encoding='utf-8') != render_verification_readme():
        fail('docs/40-verification/README.md is stale; run make verification-readme')


def check_schema_readme_sync() -> None:
    readme = ROOT / 'schemas/README.md'
    if not readme.exists():
        fail('missing schemas/README.md')
    text = readme.read_text(encoding='utf-8')
    expected_text = render_schema_readme()
    if text != expected_text:
        fail('schemas/README.md is stale; run make schema-readme')
    mentioned = set(re.findall(r'`([^`]+\.schema\.json)`', text))
    actual = {p.name for p in (ROOT / 'schemas').glob('*.schema.json')}
    registered = machine_schema_filenames()
    if mentioned != actual:
        fail(f'schemas/README.md drift; mentioned={sorted(mentioned)}, actual={sorted(actual)}')
    if registered != actual:
        fail(f'schema registry machine filenames drift from schemas dir; registered={sorted(registered)}, actual={sorted(actual)}')

def check_schema_corpus_coverage() -> None:
    expected: set[str] = set()
    for schema_id, _meaning, _human, machine, _checker in parse_schema_registry_rows():
        if machine == 'n/a':
            continue
        expected.add(schema_id.removesuffix(' v0'))
    seen: dict[str, set[str]] = {kind: set() for kind in expected}
    for path in (ROOT / 'docs/40-verification/corpora').glob('*.jsonl'):
        for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
            if not line.strip():
                continue
            try:
                case = json.loads(line)
            except json.JSONDecodeError as exc:
                fail(f'{path.relative_to(ROOT)}:{lineno}: invalid JSON while checking schema coverage: {exc}')
            if case.get('kind') != 'schema':
                continue
            object_kind = case.get('object_kind')
            expect = case.get('expect')
            if object_kind in seen and expect in {'accept', 'reject'}:
                seen[object_kind].add(expect)
    missing = {kind: sorted({'accept', 'reject'} - got) for kind, got in seen.items() if got != {'accept', 'reject'}}
    if missing:
        fail(f'schema/corpus coverage missing accept/reject cases: {missing}')


def check_registered_checkers_wired() -> None:
    rows = parse_schema_registry_rows()
    checker_names: set[str] = set()
    expected_by_checker: dict[str, set[str]] = {}
    for schema_id, _meaning, _human, machine, checker in rows:
        if checker == 'n/a':
            continue
        m = re.fullmatch(r'`([^`]+)`', checker)
        if not m:
            fail(f'schema registry row {schema_id}: checker is not a backtick path: {checker}')
        name = Path(m.group(1)).name
        if name.startswith('steward_') and name.endswith('_harness.py'):
            checker_names.add(name)
            if machine != 'n/a':
                expected_by_checker.setdefault(name, set()).add(schema_id.removesuffix(' v0'))
    registered = harness_names()
    missing_registry = sorted(checker_names - registered)
    stale_registry = sorted(registered - checker_names)
    packet_map = {name: set(ids) for name, ids in harness_packet_map().items()}
    packet_mismatches = {
        name: {'registry': sorted(expected_by_checker.get(name, set())), 'harness': sorted(packet_map.get(name, set()))}
        for name in sorted(set(expected_by_checker) | set(packet_map))
        if expected_by_checker.get(name, set()) != packet_map.get(name, set())
    }
    makefile = (ROOT / 'Makefile').read_text(encoding='utf-8')
    if 'python3 tools/run_corpora.py --write --check' not in makefile:
        fail('Makefile corpus target must use registry runner tools/run_corpora.py')
    if 'python3 tools/gen_schema_readme.py' not in makefile:
        fail('Makefile schema-readme target must use tools/gen_schema_readme.py')
    if 'python3 tools/gen_verification_readme.py' not in makefile:
        fail('Makefile verification-readme target must use tools/gen_verification_readme.py')
    per_harness_make_entries = sorted(name for name in checker_names if f'python3 tools/{name} --write --check' in makefile)
    if missing_registry or stale_registry or per_harness_make_entries or packet_mismatches:
        fail(
            'registered checker wiring drift; '
            f'missing_registry={missing_registry}, stale_registry={stale_registry}, '
            f'per_harness_make_entries={per_harness_make_entries}, '
            f'packet_mismatches={packet_mismatches}'
        )
    runner = (ROOT / 'tools/run_corpora.py').read_text(encoding='utf-8')
    lint = (ROOT / 'tools/run_lint_suite.py').read_text(encoding='utf-8')
    if 'from harness_registry import HARNESS_SCRIPTS' not in runner:
        fail('tools/run_corpora.py must import HARNESS_SCRIPTS from harness_registry')
    if 'from harness_registry import HARNESS_SCRIPTS' not in lint:
        fail('tools/run_lint_suite.py must import HARNESS_SCRIPTS from harness_registry')


def check_changelog() -> None:
    parse_changelog_top()


def check_links() -> None:
    for p in ROOT.rglob('*.md'):
        rel = p.relative_to(ROOT).as_posix()
        text = p.read_text(encoding='utf-8')
        for m in MD_LINK_RE.finditer(text):
            target = m.group(1)
            if target.startswith(('http://', 'https://', '#', 'mailto:')):
                continue
            target_path = (p.parent / target).resolve()
            if not target_path.exists():
                fail(f'{rel}: broken relative link -> {target}')


def check_raw_urls() -> None:
    for p in ROOT.rglob('*'):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if rel in ALLOW_URL_FILES:
            continue
        if p.suffix not in {'.md', '.json'}:
            continue
        text = p.read_text(encoding='utf-8')
        if RAW_URL_RE.search(text):
            fail(f'{rel}: raw URL found outside allowed files')


def check_bibliography_refs() -> None:
    bib = (ROOT / 'docs/00-meta/bibliography.md').read_text(encoding='utf-8')
    refs = set(REF_DEF_RE.findall(bib))
    if not refs:
        fail('bibliography missing REF IDs')
    for p in ROOT.rglob('*.md'):
        rel = p.relative_to(ROOT).as_posix()
        if rel == 'docs/00-meta/bibliography.md':
            continue
        text = p.read_text(encoding='utf-8')
        for ref in set(re.findall(r'REF-[A-Z0-9-]+', text)):
            if ref not in refs:
                fail(f'{rel}: unknown REF {ref}')


def check_bibliography_lock_sync() -> None:
    bib_text = (ROOT / 'docs/00-meta/bibliography.md').read_text(encoding='utf-8')
    bib_rows = BIB_RE.findall(bib_text)
    if not bib_rows:
        fail('bibliography missing parseable entries')
    bib_map = {ref: url for ref, url in bib_rows}
    locks = json.loads((ROOT / 'docs/00-meta/external-source-locks.json').read_text(encoding='utf-8'))
    lock_ids = [row['ref_id'] for row in locks]
    lock_map = {row['ref_id']: row['url'] for row in locks}
    bib_ids = [ref for ref, _ in bib_rows]
    if bib_ids != lock_ids:
        fail('bibliography REF order/content does not match external-source-locks.json')
    for ref, url in bib_map.items():
        if lock_map.get(ref) != url:
            fail(f'bibliography URL mismatch for {ref}')


def check_head_register_sync() -> None:
    locks = json.loads((ROOT / 'docs/00-meta/external-source-locks.json').read_text(encoding='utf-8'))
    lock_ids = {row['ref_id'] for row in locks}
    head_text = (ROOT / 'docs/00-meta/external-source-head-register.md').read_text(encoding='utf-8')
    head_ids = set(re.findall(r'REF-[A-Z0-9-]+', head_text))
    if head_ids != lock_ids:
        missing_in_head = sorted(lock_ids - head_ids)
        missing_in_locks = sorted(head_ids - lock_ids)
        fail(f'head register mismatch; missing_in_head={missing_in_head}, missing_in_locks={missing_in_locks}')


def check_runbook_paths() -> None:
    rb = (ROOT / 'docs/00-meta/llm-runbook.md').read_text(encoding='utf-8')
    paths = re.findall(r'^-\s+`([^`]+)`\s*$', rb, re.M)
    for rel in paths:
        if not (ROOT / rel).exists():
            fail(f'llm-runbook missing path target: {rel}')


def check_source_review_queue() -> None:
    locks = json.loads((ROOT / 'docs/00-meta/external-source-locks.json').read_text(encoding='utf-8'))
    queue_path = ROOT / 'docs/00-meta/external-source-review-queue.md'
    if not queue_path.exists():
        fail('missing docs/00-meta/external-source-review-queue.md')
    lines = queue_path.read_text(encoding='utf-8').splitlines()
    expected = [
        '# External source review queue',
        '',
        'Generated from `external-source-locks.json`.',
        '',
        '| reference ID | Retrieved | Review by | Reason |',
        '| --- | --- | --- | --- |',
    ]
    for row in locks:
        expected.append(f"| {row['ref_id']} | {row['retrieved_on']} | {row['review_by']} | {row['notes']} |")
    if lines != expected:
        fail('external-source-review-queue.md is stale; run make source-review-queue')


def main() -> int:
    check_changelog()
    check_readme_latest_sync()
    check_harness_registry_metadata()
    check_corpora()
    check_schema_registry_sync()
    check_schema_readme_sync()
    check_verification_readme_sync()
    check_schema_corpus_coverage()
    check_corpus_docs_sync()
    check_registered_checkers_wired()
    check_links()
    check_raw_urls()
    check_bibliography_refs()
    check_bibliography_lock_sync()
    check_head_register_sync()
    check_runbook_paths()
    check_source_review_queue()
    print('[lint] OK')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
