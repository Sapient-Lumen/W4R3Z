#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from types import ModuleType

from harness_registry import HARNESS_SCRIPTS, HARNESS_ENTRIES

ROOT = Path(__file__).resolve().parents[1]
TOOLS = ROOT / 'tools'
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))


def load_harness(rel: str) -> ModuleType:
    path = ROOT / rel
    name = 'steward_inprocess_' + path.stem
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise SystemExit(f'cannot load harness {rel}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_entries(*, write: bool, check: bool) -> None:
    if not write and not check:
        raise ValueError('choose write and/or check')
    for entry in HARNESS_ENTRIES:
        rel = entry['script']
        corpus = ROOT / entry['corpus']
        module = load_harness(rel)
        expected = module.render_cases(module.build_cases())
        if write:
            corpus.parent.mkdir(parents=True, exist_ok=True)
            corpus.write_text(expected, encoding='utf-8')
            print(corpus)
        if check:
            if not corpus.exists():
                raise SystemExit(f'missing corpus: {corpus}')
            actual = corpus.read_text(encoding='utf-8')
            if actual != expected:
                raise SystemExit(f'[{Path(rel).stem}] FAIL: corpus is stale; run tools/run_corpora.py --write')
            module.check_cases(module.load_corpus(corpus))
            print(f'[{Path(rel).stem}] OK')


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpora before checking')
    ap.add_argument('--check', action='store_true', help='check deterministic corpora')
    args = ap.parse_args()
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    # Read HARNESS_SCRIPTS to keep the legacy derived-list invariant exercised.
    if [entry['script'] for entry in HARNESS_ENTRIES] != HARNESS_SCRIPTS:
        raise SystemExit('HARNESS_SCRIPTS is not derived from HARNESS_ENTRIES')
    run_entries(write=args.write, check=args.check)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
