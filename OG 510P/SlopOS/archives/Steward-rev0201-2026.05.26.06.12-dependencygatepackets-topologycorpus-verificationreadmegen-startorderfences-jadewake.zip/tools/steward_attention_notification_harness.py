#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/attention-notification-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
HINT_RE = re.compile(r'^hint_[a-z0-9]{16}$')
WATCH_RE = re.compile(r'^watch_[a-z0-9]{16}$')
NOTICE_RE = re.compile(r'^notice_[a-z0-9]{16}$')
ACK_RE = re.compile(r'^ack_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_authorized', 'claims_authorization', 'claims_approval',
    'claims_current', 'claims_current_state', 'claims_fresh', 'claims_read', 'claims_seen',
    'claims_readiness', 'claims_ready', 'claims_resolved', 'claims_serving',
    'claims_effect_success', 'claims_execution', 'claims_mutation', 'claims_policy',
    'claims_native_truth', 'claims_lossless', 'claims_drained', 'claims_work_complete',
    'claims_operation_executed', 'authority', 'authorized', 'approved', 'current_state',
    'current', 'fresh', 'ready', 'readiness', 'serving', 'effect_success', 'execution',
    'mutation', 'policy_authority', 'native_truth', 'operation_executed', 'lossless',
    'read_by_user', 'seen_by_user', 'resolved', 'auto_execute', 'macro',
    'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle', 'raw_text',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie', 'authorization',
    'value', 'path', 'raw_path', 'host_path', 'endpoint', 'raw_endpoint', 'url', 'uri',
    'fd', 'descriptor_number', 'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path',
    'systemd_unit', 'host_unit', 'pod_name', 'container_id', 'node_name', 'process_name',
    'pty_name', 'shell_job', 'pane_text', 'command_text', 'k8s_resource_name',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'renderer', 'status_channel', 'adapter', 'notifier', 'auditor'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

ATTNHINT_REQUIRED = COMMON_REQUIRED | {
    'hint_id', 'anchor_ref', 'hint_kind', 'severity', 'attention_state',
    'confidence', 'focus_state', 'stale_after_ms', 'delivery_preferences',
}
ATTNHINT_OPTIONAL = COMMON_OPTIONAL | {'message_digest'}
ATTNHINT_ALLOWED = ATTNHINT_REQUIRED | ATTNHINT_OPTIONAL
HINT_KINDS = {'command_finished', 'needs_input', 'warning', 'error', 'progress', 'barrier_crossed', 'receipt_settled', 'unknown'}
SEVERITIES = {'info', 'warning', 'error', 'urgent', 'unknown'}
ATTENTION_STATES = {'observed', 'matched', 'stale', 'withdrawn', 'unknown'}
CONFIDENCES = {'exact', 'reported', 'inferred', 'provisional', 'unknown'}
FOCUS_STATES = {'focused', 'background', 'hidden', 'unknown'}
DELIVERY_CLASSES = {'none', 'chip', 'badge', 'bell', 'toast', 'reveal_only'}
ATTNHINT_NON_IMPLICATIONS = {
    'not-authority', 'not-current-state', 'not-readiness', 'not-serving',
    'not-effect-success', 'not-work-completion', 'not-user-seen', 'not-resolution',
    'not-authorization', 'not-mutation',
}

ATTNWATCH_REQUIRED = COMMON_REQUIRED | {
    'watch_id', 'anchor_ref', 'condition_kind', 'watch_state', 'armed_at_ms',
    'expires_at_ms', 'min_age_ms', 'delivery_preferences', 'reveal_target_ref',
    'cancel_ref',
}
ATTNWATCH_OPTIONAL = COMMON_OPTIONAL | {'matched_hint_ref'}
ATTNWATCH_ALLOWED = ATTNWATCH_REQUIRED | ATTNWATCH_OPTIONAL
CONDITIONS = {'frame_finished', 'receipt_settled', 'status_barrier_crossed', 'pending_request_responded', 'attention_hint_matched', 'unknown'}
WATCH_STATES = {'armed', 'matched', 'delivered', 'canceled', 'expired', 'stale', 'unknown'}
ATTNWATCH_NON_IMPLICATIONS = {
    'not-authority', 'not-automation', 'not-mutation', 'not-authorization',
    'not-execution', 'not-current-state', 'not-readiness', 'not-serving',
    'not-effect-success',
}

NOTICE_REQUIRED = COMMON_REQUIRED | {
    'notice_id', 'watch_ref', 'hint_ref', 'delivery_state', 'delivery_class',
    'target_ref', 'delivery_actions', 'delivered_at_ms', 'downgrade_reason',
}
NOTICE_OPTIONAL = COMMON_OPTIONAL
NOTICE_ALLOWED = NOTICE_REQUIRED | NOTICE_OPTIONAL
DELIVERY_STATES = {'queued', 'delivered', 'suppressed', 'failed', 'stale', 'unknown'}
DELIVERY_ACTIONS = {'reveal', 'focus', 'open_receipt', 'dismiss'}
NOTICE_NON_IMPLICATIONS = {
    'not-authority', 'not-user-seen', 'not-user-read', 'not-resolution',
    'not-authorization', 'not-mutation', 'not-execution', 'not-current-state',
    'not-readiness', 'not-serving', 'not-effect-success',
}

ATTNACK_REQUIRED = COMMON_REQUIRED | {
    'ack_id', 'notice_ref', 'watch_ref', 'ack_kind', 'ack_state',
    'actor_ref', 'revealed_target_ref', 'acknowledged_at_ms', 'stale_after_ack_ms',
}
ATTNACK_OPTIONAL = COMMON_OPTIONAL
ATTNACK_ALLOWED = ATTNACK_REQUIRED | ATTNACK_OPTIONAL
ACK_KINDS = {'dismissed', 'revealed', 'focused', 'opened_receipt', 'cleared', 'unknown'}
ACK_STATES = {'recorded', 'stale_target', 'denied_by_policy', 'lost', 'unknown'}
ATTNACK_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-mutation', 'not-execution',
    'not-current-state', 'not-readiness', 'not-serving', 'not-effect-success',
    'not-resolution', 'not-work-completion',
}

AMBIENT_REFS = {'ambient', 'current', 'pane:current', 'terminal:current', 'whatever:current'}
MUTATING_ACTION_WORDS = {'approve', 'authorize', 'execute', 'run', 'restart', 'stop', 'quiesce', 'kill', 'clear_repair_gate'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:',
        '/var/', '/proc/', '/tmp/', 'current state proof', 'ready proof', 'user saw',
        'user approved', 'already executed', 'effect success', 'resolved automatically',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_string_list2(value: Any, path: str, *, regex: re.Pattern[str] = REF_RE, maximum: int = 16, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_pattern(item, regex, f'{path}[{idx}]')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_enum_list(value: Any, enum: set[str], path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    items = require_string_list2(value, path, regex=REF_RE, maximum=maximum, allow_empty=allow_empty)
    bad = sorted(set(items) - enum)
    if bad:
        fail(f'{path}: invalid entries {bad}')
    return items


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False) -> list[str]:
    return require_string_list2(value, path, regex=REF_RE, maximum=maximum, allow_empty=allow_empty)


def require_sorted_refs(value: Any, path: str, *, maximum: int = 32, allow_empty: bool = False) -> list[str]:
    items = require_refs(value, path, maximum=maximum, allow_empty=allow_empty)
    if items != sorted(items):
        fail(f'{path}: refs must be sorted for stable comparison')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def require_explicit_ref(value: Any, path: str) -> str:
    require_pattern(value, REF_RE, path)
    if value in AMBIENT_REFS:
        fail(f'{path}: must bind an exact anchor, not ambient/current context')
    return value


def require_delivery_preferences(value: Any, path: str) -> list[str]:
    prefs = require_enum_list(value, DELIVERY_CLASSES, path, maximum=8)
    if 'none' in prefs and len(prefs) > 1:
        fail(f'{path}: none cannot be combined with delivery classes')
    return prefs


def validate_attnhint(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ATTNHINT_ALLOWED, ATTNHINT_REQUIRED, 'ST-ATTNHINT v0')
    require_pattern(obj['hint_id'], HINT_RE, '$.hint_id')
    require_explicit_ref(obj['anchor_ref'], '$.anchor_ref')
    if obj['hint_kind'] not in HINT_KINDS:
        fail('$.hint_kind: invalid')
    if obj['severity'] not in SEVERITIES:
        fail('$.severity: invalid')
    if obj['attention_state'] not in ATTENTION_STATES:
        fail('$.attention_state: invalid')
    if obj['confidence'] not in CONFIDENCES:
        fail('$.confidence: invalid')
    if obj['focus_state'] not in FOCUS_STATES:
        fail('$.focus_state: invalid')
    require_int(obj['stale_after_ms'], '$.stale_after_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['stale_after_ms'] <= obj['observed_at_ms'] and obj['attention_state'] not in {'stale', 'withdrawn'}:
        fail('$.stale_after_ms: active hints must expire after observed_at_ms')
    require_delivery_preferences(obj['delivery_preferences'], '$.delivery_preferences')
    if 'message_digest' in obj:
        require_pattern(obj['message_digest'], DIGEST_RE, '$.message_digest')
    require_non_implications(obj['non_implications'], ATTNHINT_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_attnwatch(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ATTNWATCH_ALLOWED, ATTNWATCH_REQUIRED, 'ST-ATTNWATCH v0')
    require_pattern(obj['watch_id'], WATCH_RE, '$.watch_id')
    require_explicit_ref(obj['anchor_ref'], '$.anchor_ref')
    if obj['condition_kind'] not in CONDITIONS:
        fail('$.condition_kind: invalid')
    if obj['watch_state'] not in WATCH_STATES:
        fail('$.watch_state: invalid')
    require_int(obj['armed_at_ms'], '$.armed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['min_age_ms'], '$.min_age_ms', minimum=0, maximum=86_400_000)
    if obj['expires_at_ms'] <= obj['armed_at_ms']:
        fail('$.expires_at_ms: must be after armed_at_ms')
    if obj['armed_at_ms'] > obj['observed_at_ms']:
        fail('$.armed_at_ms: cannot be after observed_at_ms')
    if obj['watch_state'] in {'armed', 'matched', 'delivered'} and obj['expires_at_ms'] <= obj['observed_at_ms']:
        fail('$.expires_at_ms: active/matched watches cannot already be expired')
    require_delivery_preferences(obj['delivery_preferences'], '$.delivery_preferences')
    require_explicit_ref(obj['reveal_target_ref'], '$.reveal_target_ref')
    require_explicit_ref(obj['cancel_ref'], '$.cancel_ref')
    if 'matched_hint_ref' in obj:
        require_pattern(obj['matched_hint_ref'], HINT_RE, '$.matched_hint_ref')
        if obj['watch_state'] == 'armed':
            fail('$.matched_hint_ref: armed watches cannot carry a matched hint')
    require_non_implications(obj['non_implications'], ATTNWATCH_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_notice(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, NOTICE_ALLOWED, NOTICE_REQUIRED, 'ST-NOTICE v0')
    require_pattern(obj['notice_id'], NOTICE_RE, '$.notice_id')
    require_pattern(obj['watch_ref'], WATCH_RE, '$.watch_ref')
    require_pattern(obj['hint_ref'], HINT_RE, '$.hint_ref')
    if obj['delivery_state'] not in DELIVERY_STATES:
        fail('$.delivery_state: invalid')
    if obj['delivery_class'] not in DELIVERY_CLASSES:
        fail('$.delivery_class: invalid')
    require_explicit_ref(obj['target_ref'], '$.target_ref')
    actions = require_enum_list(obj['delivery_actions'], DELIVERY_ACTIONS, '$.delivery_actions', maximum=8, allow_empty=obj['delivery_state'] in {'failed', 'suppressed', 'stale'})
    if obj['delivery_state'] == 'delivered' and not actions:
        fail('$.delivery_actions: delivered notices must expose at least reveal/focus/dismiss')
    require_int(obj['delivered_at_ms'], '$.delivered_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['delivered_at_ms'] < obj['observed_at_ms'] and obj['delivery_state'] == 'queued':
        fail('$.delivered_at_ms: queued notices cannot have a past delivered timestamp')
    require_text(obj['downgrade_reason'], '$.downgrade_reason')
    if obj['delivery_state'] in {'suppressed', 'failed', 'stale'} and obj['downgrade_reason'] == 'none':
        fail('$.downgrade_reason: non-delivered notices need a reason')
    if any(action in MUTATING_ACTION_WORDS for action in actions):
        fail('$.delivery_actions: notification actions must reveal/focus/open/dismiss only')
    require_non_implications(obj['non_implications'], NOTICE_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_attnack(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ATTNACK_ALLOWED, ATTNACK_REQUIRED, 'ST-ATTNACK v0')
    require_pattern(obj['ack_id'], ACK_RE, '$.ack_id')
    require_pattern(obj['notice_ref'], NOTICE_RE, '$.notice_ref')
    require_pattern(obj['watch_ref'], WATCH_RE, '$.watch_ref')
    if obj['ack_kind'] not in ACK_KINDS:
        fail('$.ack_kind: invalid')
    if obj['ack_state'] not in ACK_STATES:
        fail('$.ack_state: invalid')
    require_pattern(obj['actor_ref'], REF_RE, '$.actor_ref')
    require_explicit_ref(obj['revealed_target_ref'], '$.revealed_target_ref')
    require_int(obj['acknowledged_at_ms'], '$.acknowledged_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['stale_after_ack_ms'], '$.stale_after_ack_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['acknowledged_at_ms'] > obj['observed_at_ms']:
        fail('$.acknowledged_at_ms: cannot be after observed_at_ms')
    if obj['stale_after_ack_ms'] < obj['acknowledged_at_ms']:
        fail('$.stale_after_ack_ms: cannot precede acknowledgement')
    require_non_implications(obj['non_implications'], ATTNACK_NON_IMPLICATIONS, '$.non_implications')
    return obj


def issuer(kind: str = 'notifier', ident: str = 'steward.notify') -> dict[str, str]:
    return {'kind': kind, 'id': ident}


def base_hint(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-ATTNHINT v0',
        'witness_id': 'wit_5000000000000001',
        'cid': 'demo.web',
        'issuer': issuer(),
        'hint_id': 'hint_1000000000000001',
        'anchor_ref': 'frame:demo.web.build.0001',
        'hint_kind': 'command_finished',
        'severity': 'info',
        'attention_state': 'matched',
        'confidence': 'exact',
        'focus_state': 'background',
        'stale_after_ms': 5000,
        'delivery_preferences': ['badge', 'toast'],
        'observed_at_ms': 1200,
        'basis_refs': ['frame:demo.web.build.0001'],
        'non_implications': sorted(ATTNHINT_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_watch(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-ATTNWATCH v0',
        'witness_id': 'wit_5000000000000002',
        'cid': 'demo.web',
        'issuer': issuer('operator', 'operator.alice'),
        'watch_id': 'watch_1000000000000001',
        'anchor_ref': 'frame:demo.web.build.0001',
        'condition_kind': 'frame_finished',
        'watch_state': 'matched',
        'armed_at_ms': 1000,
        'expires_at_ms': 10000,
        'min_age_ms': 30000,
        'delivery_preferences': ['badge', 'toast'],
        'reveal_target_ref': 'surface:demo.web.frame.0001',
        'cancel_ref': 'cancel:watch_1000000000000001',
        'matched_hint_ref': 'hint_1000000000000001',
        'observed_at_ms': 1210,
        'basis_refs': ['frame:demo.web.build.0001'],
        'non_implications': sorted(ATTNWATCH_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_notice(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-NOTICE v0',
        'witness_id': 'wit_5000000000000003',
        'cid': 'demo.web',
        'issuer': issuer(),
        'notice_id': 'notice_1000000000000001',
        'watch_ref': 'watch_1000000000000001',
        'hint_ref': 'hint_1000000000000001',
        'delivery_state': 'delivered',
        'delivery_class': 'toast',
        'target_ref': 'surface:demo.web.frame.0001',
        'delivery_actions': ['dismiss', 'reveal'],
        'delivered_at_ms': 1220,
        'downgrade_reason': 'none',
        'observed_at_ms': 1220,
        'basis_refs': ['hint_1000000000000001', 'watch_1000000000000001'],
        'non_implications': sorted(NOTICE_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_ack(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-ATTNACK v0',
        'witness_id': 'wit_5000000000000004',
        'cid': 'demo.web',
        'issuer': issuer('renderer', 'steward.surface'),
        'ack_id': 'ack_1000000000000001',
        'notice_ref': 'notice_1000000000000001',
        'watch_ref': 'watch_1000000000000001',
        'ack_kind': 'revealed',
        'ack_state': 'recorded',
        'actor_ref': 'operator:alice',
        'revealed_target_ref': 'surface:demo.web.frame.0001',
        'acknowledged_at_ms': 1300,
        'stale_after_ack_ms': 2000,
        'observed_at_ms': 1300,
        'basis_refs': ['notice_1000000000000001'],
        'non_implications': sorted(ATTNACK_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'attention_notification', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    hint = base_hint()
    watch = base_watch()
    notice = base_notice()
    ack = base_ack()
    stale_notice = base_notice(
        witness_id='wit_5000000000000005',
        notice_id='notice_1000000000000002',
        watch_ref='watch_1000000000000002',
        delivery_state='stale',
        delivery_class='none',
        delivery_actions=[],
        delivered_at_ms=0,
        downgrade_reason='watch expired before delivery',
        observed_at_ms=1300,
    )
    expired_watch = base_watch(
        witness_id='wit_5000000000000006',
        watch_id='watch_1000000000000002',
        watch_state='expired',
        expires_at_ms=1190,
        observed_at_ms=1300,
        matched_hint_ref='hint_1000000000000001',
    )

    return [
        schema_case('attnhint.accept.exact-background-finished', 'ST-ATTNHINT', hint, 'accept', 'an exact frame-finished hint may request attention without proving completion beyond its anchor'),
        schema_case('attnhint.reject.ambient-anchor', 'ST-ATTNHINT', {**hint, 'anchor_ref': 'pane:current'}, 'reject', 'attention hints must target an exact anchor, not current pane folklore'),
        schema_case('attnhint.reject.currentness-flattery', 'ST-ATTNHINT', {**hint, 'claims_current_state': True}, 'reject', 'attention hints cannot claim current lifecycle truth'),
        schema_case('attnhint.reject.stale-active-hint', 'ST-ATTNHINT', {**hint, 'stale_after_ms': 1000}, 'reject', 'non-stale hints need a future stale boundary'),
        schema_case('attnwatch.accept.exact-watch', 'ST-ATTNWATCH', watch, 'accept', 'a watch binds one anchor and one condition without creating automation authority'),
        schema_case('attnwatch.reject.ambient-anchor', 'ST-ATTNWATCH', {**watch, 'anchor_ref': 'terminal:current'}, 'reject', 'watches cannot bind to ambient terminal state'),
        schema_case('attnwatch.reject.matched-hint-on-armed', 'ST-ATTNWATCH', {**watch, 'watch_state': 'armed', 'matched_hint_ref': 'hint_1000000000000001'}, 'reject', 'armed watches cannot already carry matched hints'),
        schema_case('attnwatch.reject.automation-field', 'ST-ATTNWATCH', {**watch, 'auto_execute': True}, 'reject', 'watches must not become hidden automation'),
        schema_case('notice.accept.toast-delivered', 'ST-NOTICE', notice, 'accept', 'a delivered toast can reveal a target but remains non-authoritative'),
        schema_case('notice.accept.stale-downgrade', 'ST-NOTICE', stale_notice, 'accept', 'stale notices can honestly record delivery downgrade'),
        schema_case('notice.reject.mutating-action', 'ST-NOTICE', {**notice, 'delivery_actions': ['reveal', 'restart']}, 'reject', 'notification actions may not execute lifecycle mutations'),
        schema_case('notice.reject.user-seen-flattery', 'ST-NOTICE', {**notice, 'claims_seen_by_user': True}, 'reject', 'delivery is not proof the user saw or read the notice'),
        schema_case('notice.reject.missing-downgrade-reason', 'ST-NOTICE', {**stale_notice, 'downgrade_reason': 'none'}, 'reject', 'stale/failed/suppressed notices must carry downgrade reasons'),
        schema_case('attnack.accept.reveal-recorded', 'ST-ATTNACK', ack, 'accept', 'an acknowledgement records reveal/dismiss behavior without resolving the underlying condition'),
        schema_case('attnack.reject-resolution-flattery', 'ST-ATTNACK', {**ack, 'claims_resolved': True}, 'reject', 'acknowledgement or reveal is not resolution'),
        schema_case('attnack.reject-future-ack', 'ST-ATTNACK', {**ack, 'acknowledged_at_ms': 1400}, 'reject', 'acknowledgement cannot occur after observed_at'),
        schema_case('notice.reject.duplicate-json-key', 'ST-NOTICE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-NOTICE v0","schema":"ST-NOTICE v0","witness_id":"wit_5000000000000003","cid":"demo.web","issuer":{"kind":"notifier","id":"steward.notify"},"notice_id":"notice_1000000000000001","watch_ref":"watch_1000000000000001","hint_ref":"hint_1000000000000001","delivery_state":"delivered","delivery_class":"toast","target_ref":"surface:demo.web.frame.0001","delivery_actions":["reveal"],"delivered_at_ms":1220,"downgrade_reason":"none","observed_at_ms":1220,"basis_refs":["hint_1000000000000001"],"non_implications":[]}'),

        flow_case('attention.accept.watch-hint-notice-ack', [
            {'event': 'watch', 'packet': watch},
            {'event': 'hint', 'packet': hint},
            {'event': 'notice', 'packet': notice},
            {'event': 'ack', 'packet': ack},
        ], 'accept', 'watch, hint, notice, and acknowledgement compose without approval or resolution claims'),
        flow_case('attention.accept.expired-watch-stale-notice', [
            {'event': 'watch', 'packet': expired_watch},
            {'event': 'hint', 'packet': hint},
            {'event': 'notice', 'packet': stale_notice},
        ], 'accept', 'expired watches can produce explicit stale notice records instead of guessing delivery'),
        flow_case('attention.reject.notice-without-watch', [
            {'event': 'hint', 'packet': hint},
            {'event': 'notice', 'packet': notice},
        ], 'reject', 'notices must bind to a known exact watch'),
        flow_case('attention.reject.notice-without-hint', [
            {'event': 'watch', 'packet': watch},
            {'event': 'notice', 'packet': notice},
        ], 'reject', 'notices must bind to a known attention hint'),
        flow_case('attention.reject.notice-before-hint', [
            {'event': 'watch', 'packet': watch},
            {'event': 'notice', 'packet': notice},
            {'event': 'hint', 'packet': hint},
        ], 'reject', 'notice delivery cannot precede its hint evidence'),
        flow_case('attention.reject.ack-without-notice', [
            {'event': 'watch', 'packet': watch},
            {'event': 'hint', 'packet': hint},
            {'event': 'ack', 'packet': ack},
        ], 'reject', 'acknowledgements must bind to known notices'),
        flow_case('attention.reject.ack-as-resolution', [
            {'event': 'watch', 'packet': watch},
            {'event': 'hint', 'packet': hint},
            {'event': 'notice', 'packet': notice},
            {'event': 'ack', 'packet': ack, 'claims_resolved': True},
        ], 'reject', 'acknowledgement events cannot claim resolution'),
        flow_case('attention.reject.watch-as-authorization', [
            {'event': 'watch', 'packet': watch, 'claims_authorization': True},
        ], 'reject', 'arming a watch is not authorization'),
        flow_case('attention.reject.duplicate-notice-drift', [
            {'event': 'watch', 'packet': watch},
            {'event': 'hint', 'packet': hint},
            {'event': 'notice', 'packet': notice},
            {'event': 'notice', 'packet': {**notice, 'delivery_actions': ['focus', 'reveal']}},
        ], 'reject', 'notice ids cannot be reused for different canonical bytes'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-ATTNHINT':
            validate_attnhint(obj)
        elif kind == 'ST-ATTNWATCH':
            validate_attnwatch(obj)
        elif kind == 'ST-NOTICE':
            validate_notice(obj)
        elif kind == 'ST-ATTNACK':
            validate_attnack(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        watches: dict[str, dict[str, Any]] = {}
        hints: dict[str, dict[str, Any]] = {}
        notices: dict[str, dict[str, Any]] = {}
        seen_packets: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'hint':
                hint = validate_attnhint(packet)
                check_packet_identity(seen_packets, hint['hint_id'], hint, where)
                hints[hint['hint_id']] = hint
            elif kind == 'watch':
                watch = validate_attnwatch(packet)
                check_packet_identity(seen_packets, watch['watch_id'], watch, where)
                watches[watch['watch_id']] = watch
            elif kind == 'notice':
                notice = validate_notice(packet)
                check_packet_identity(seen_packets, notice['notice_id'], notice, where)
                if notice['watch_ref'] not in watches:
                    fail(f'{where}: notice has no known watch')
                if notice['hint_ref'] not in hints:
                    fail(f'{where}: notice has no known hint')
                watch = watches[notice['watch_ref']]
                if notice['delivery_state'] == 'delivered' and watch['watch_state'] in {'expired', 'canceled', 'stale'}:
                    fail(f'{where}: expired/canceled/stale watch cannot yield delivered notice')
                notices[notice['notice_id']] = notice
            elif kind == 'ack':
                ack = validate_attnack(packet)
                check_packet_identity(seen_packets, ack['ack_id'], ack, where)
                if ack['notice_ref'] not in notices:
                    fail(f'{where}: acknowledgement has no known notice')
                if ack['watch_ref'] not in watches:
                    fail(f'{where}: acknowledgement has no known watch')
                if notices[ack['notice_ref']]['watch_ref'] != ack['watch_ref']:
                    fail(f'{where}: acknowledgement watch does not match notice watch')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'attention_notification':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-attention-notification-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-attention-notification-corpus] FAIL: corpus is stale; run tools/steward_attention_notification_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-attention-notification-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
