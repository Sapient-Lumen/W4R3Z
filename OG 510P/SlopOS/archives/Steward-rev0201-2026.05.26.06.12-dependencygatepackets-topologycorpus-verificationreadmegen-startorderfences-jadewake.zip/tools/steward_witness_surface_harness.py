#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/witness-surface-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
CARD_RE = re.compile(r'^card_[a-z0-9]{16}$')
AFFORD_RE = re.compile(r'^aff_[a-z0-9]{16}$')
BARRIER_RE = re.compile(r'^bar_[a-z0-9]{16}$')
AUDIT_RE = re.compile(r'^aud_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')
REV_RE = re.compile(r'^rev[0-9]{4}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_current', 'claims_current_state', 'claims_fresh',
    'claims_readiness', 'claims_ready', 'claims_serving', 'claims_effect_success',
    'claims_execution', 'claims_policy', 'claims_mutation', 'claims_native_truth',
    'claims_lossless', 'claims_drained', 'claims_custody', 'claims_work_complete',
    'claims_authorization', 'claims_approval', 'claims_operation_executed',
    'authority', 'current_state', 'current', 'fresh', 'ready', 'readiness',
    'serving', 'effect_success', 'execution', 'mutation', 'policy_authority',
    'native_truth', 'operation_executed', 'approved', 'authorized',
    'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle', 'raw_text',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie',
    'authorization', 'value', 'path', 'raw_path', 'host_path', 'endpoint',
    'raw_endpoint', 'url', 'uri', 'fd', 'descriptor_number', 'pid', 'ppid',
    'pgid', 'cgroup', 'cgroup_path', 'systemd_unit', 'host_unit', 'pod_name',
    'container_id', 'node_name', 'process_name', 'pty_name', 'shell_job',
    'pane_text', 'command_text', 'k8s_resource_name',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'renderer', 'surface_auditor', 'policy', 'adapter'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

WITCARD_REQUIRED = COMMON_REQUIRED | {
    'card_id', 'subject_ref', 'card_kind', 'truth_class', 'headline_state',
    'evidence_refs', 'missing_witnesses', 'display_caveats', 'downgrade_class',
}
WITCARD_OPTIONAL = COMMON_OPTIONAL | {'expires_or_recheck_by_ms'}
WITCARD_ALLOWED = WITCARD_REQUIRED | WITCARD_OPTIONAL
CARD_KINDS = {
    'lifecycle_status', 'operation_result', 'observation_summary', 'retry_settlement',
    'shutdown_summary', 'reconciliation_summary', 'evidence_transport', 'unknown',
}
TRUTH_CLASSES = {'native_witness', 'weak_basis', 'historical', 'stale', 'blocked', 'unknown'}
HEADLINE_STATES = {'observed', 'settled', 'blocked', 'degraded', 'needs_witness', 'recheck_needed', 'unknown'}
DOWNGRADE_CLASSES = {'none', 'weak_basis', 'history_only', 'requires_recheck', 'blocked', 'stale', 'unknown'}
WITCARD_NON_IMPLICATIONS = {
    'not-authority', 'not-current-state', 'not-freshness', 'not-readiness',
    'not-serving', 'not-effect-success', 'not-execution',
}

ACTION_REQUIRED = COMMON_REQUIRED | {
    'affordance_id', 'subject_ref', 'verb', 'target_ref', 'enabled_state',
    'exact_target_class', 'precondition_refs', 'stale_fence_refs',
    'risk_class', 'review_required',
}
ACTION_OPTIONAL = COMMON_OPTIONAL | {'operation_request_digest', 'required_authcheck_ref', 'disabled_reason'}
ACTION_ALLOWED = ACTION_REQUIRED | ACTION_OPTIONAL
VERBS = {'start', 'stop', 'restart', 'quiesce', 'inspect', 'recheck', 'clear_repair_gate', 'explain', 'none'}
MUTATING_VERBS = {'start', 'stop', 'restart', 'quiesce', 'clear_repair_gate'}
ENABLED_STATES = {'disabled', 'enabled_for_review', 'requires_auth', 'requires_recheck', 'unknown'}
TARGET_CLASSES = {'component', 'runtime_cycle', 'operation', 'witness', 'surface', 'unknown'}
RISK_CLASSES = {'low', 'medium', 'high', 'break_glass', 'unknown'}
ACTION_NON_IMPLICATIONS = {
    'not-execution', 'not-authorization', 'not-approval', 'not-effect-success',
    'not-current-state', 'not-target-current',
}

BARRIER_REQUIRED = COMMON_REQUIRED | {
    'barrier_id', 'surface_ref', 'subject_ref', 'barrier_state', 'blocks_verbs',
    'stale_refs', 'required_refreshes', 'reason_class',
}
BARRIER_OPTIONAL = COMMON_OPTIONAL | {'override_ref'}
BARRIER_ALLOWED = BARRIER_REQUIRED | BARRIER_OPTIONAL
BARRIER_STATES = {'clear', 'blocking', 'needs_refresh', 'stale', 'unknown'}
REASON_CLASSES = {'stale_cycle', 'missing_witness', 'expired_freshness', 'conflicting_basis', 'manager_recovery', 'unknown'}
BARRIER_NON_IMPLICATIONS = {
    'not-execution', 'not-authorization', 'not-current-state', 'not-readiness',
    'not-serving', 'not-effect-success',
}

AUDIT_REQUIRED = COMMON_REQUIRED | {
    'audit_id', 'surface_ref', 'audited_refs', 'audit_scope', 'finding_state',
    'findings', 'required_changes', 'changed_refs', 'audit_target_revision',
}
AUDIT_OPTIONAL = COMMON_OPTIONAL | {'deferred_reason'}
AUDIT_ALLOWED = AUDIT_REQUIRED | AUDIT_OPTIONAL
AUDIT_SCOPES = {'witness_card', 'action_affordance', 'status_barrier', 'rendered_bundle', 'cube_refactor'}
FINDING_STATES = {'pass', 'fail', 'needs_refactor', 'deferred'}
AUDIT_NON_IMPLICATIONS = {
    'not-fix', 'not-authority', 'not-current-state', 'not-execution',
    'not-proof-of-correctness', 'not-release',
}

SURFACE_PACKET_PREFIXES = ('card_', 'aff_', 'bar_', 'aud_')


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:',
        '/var/', '/proc/', '/tmp/', 'current state proof', 'ready proof',
        'executed already', 'effect success', 'authorized already',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    return items


def require_text_list(value: Any, path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_text(item, f'{path}[{idx}]')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_enum_list(value: Any, enum: set[str], path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    bad = sorted(set(items) - enum)
    if bad:
        fail(f'{path}: invalid entries {bad}')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_window(obj: dict[str, Any], path: str) -> None:
    require_int(obj['observed_at_ms'], f'{path}.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    for field in ('expires_or_recheck_by_ms',):
        if field in obj:
            require_int(obj[field], f'{path}.{field}', minimum=0, maximum=9_223_372_036_854_775_807)
            if obj[field] < obj['observed_at_ms']:
                fail(f'{path}.{field}: precedes observed_at_ms')


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    validate_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_witcard(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, WITCARD_ALLOWED, WITCARD_REQUIRED, 'ST-WITCARD v0')
    require_pattern(obj['card_id'], CARD_RE, '$.card_id')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    if obj['card_kind'] not in CARD_KINDS:
        fail('$.card_kind: invalid')
    if obj['truth_class'] not in TRUTH_CLASSES:
        fail('$.truth_class: invalid')
    if obj['headline_state'] not in HEADLINE_STATES:
        fail('$.headline_state: invalid')
    require_refs(obj['evidence_refs'], '$.evidence_refs', maximum=24)
    missing = require_refs(obj['missing_witnesses'], '$.missing_witnesses', maximum=16, allow_empty=obj['truth_class'] == 'native_witness')
    require_text_list(obj['display_caveats'], '$.display_caveats', maximum=8)
    if obj['downgrade_class'] not in DOWNGRADE_CLASSES:
        fail('$.downgrade_class: invalid')
    if obj['truth_class'] in {'weak_basis', 'historical', 'stale', 'blocked', 'unknown'} and obj['headline_state'] == 'settled':
        fail('$.headline_state: weak, stale, historical, blocked, or unknown cards cannot render as settled')
    if obj['truth_class'] == 'weak_basis' and not missing:
        fail('$.missing_witnesses: weak-basis cards must name missing stronger witnesses')
    if obj['truth_class'] == 'native_witness' and obj['downgrade_class'] != 'none':
        fail('$.downgrade_class: native-witness cards use none downgrade')
    require_non_implications(obj['non_implications'], WITCARD_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_action(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ACTION_ALLOWED, ACTION_REQUIRED, 'ST-ACTIONAFFORD v0')
    require_pattern(obj['affordance_id'], AFFORD_RE, '$.affordance_id')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    require_pattern(obj['target_ref'], REF_RE, '$.target_ref')
    if obj['target_ref'].startswith(('pid:', 'host_unit:', 'systemd:', 'pod:', 'container:', 'cgroup:', 'fd:', 'path:', 'endpoint:')):
        fail('$.target_ref: raw host/runtime target classes are forbidden')
    if obj['verb'] not in VERBS:
        fail('$.verb: invalid')
    if obj['enabled_state'] not in ENABLED_STATES:
        fail('$.enabled_state: invalid')
    if obj['exact_target_class'] not in TARGET_CLASSES:
        fail('$.exact_target_class: invalid')
    require_refs(obj['precondition_refs'], '$.precondition_refs', maximum=16, allow_empty=obj['verb'] in {'inspect', 'explain', 'none'})
    require_refs(obj['stale_fence_refs'], '$.stale_fence_refs', maximum=16, allow_empty=obj['verb'] not in MUTATING_VERBS)
    if obj['risk_class'] not in RISK_CLASSES:
        fail('$.risk_class: invalid')
    require_bool(obj['review_required'], '$.review_required')
    if 'operation_request_digest' in obj:
        require_pattern(obj['operation_request_digest'], DIGEST_RE, '$.operation_request_digest')
    if 'required_authcheck_ref' in obj:
        require_pattern(obj['required_authcheck_ref'], REF_RE, '$.required_authcheck_ref')
    if 'disabled_reason' in obj:
        require_text(obj['disabled_reason'], '$.disabled_reason')
    if obj['verb'] in MUTATING_VERBS:
        if obj['enabled_state'] == 'enabled_for_review':
            if 'operation_request_digest' not in obj:
                fail('$.operation_request_digest: enabled mutating affordance requires exact ST-OPREQ digest')
            if 'required_authcheck_ref' not in obj:
                fail('$.required_authcheck_ref: enabled mutating affordance requires authorization-check ref')
            if not obj['review_required']:
                fail('$.review_required: mutating enabled affordance requires review')
        if obj['enabled_state'] == 'disabled' and 'disabled_reason' not in obj:
            fail('$.disabled_reason: disabled affordance requires reason')
    require_non_implications(obj['non_implications'], ACTION_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_barrier(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, BARRIER_ALLOWED, BARRIER_REQUIRED, 'ST-STATUSBARRIER v0')
    require_pattern(obj['barrier_id'], BARRIER_RE, '$.barrier_id')
    require_pattern(obj['surface_ref'], REF_RE, '$.surface_ref')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    if obj['barrier_state'] not in BARRIER_STATES:
        fail('$.barrier_state: invalid')
    blocks = require_enum_list(obj['blocks_verbs'], VERBS - {'none'}, '$.blocks_verbs', maximum=16, allow_empty=obj['barrier_state'] == 'clear')
    stale = require_refs(obj['stale_refs'], '$.stale_refs', maximum=16, allow_empty=True)
    refreshes = require_refs(obj['required_refreshes'], '$.required_refreshes', maximum=16, allow_empty=True)
    if obj['reason_class'] not in REASON_CLASSES:
        fail('$.reason_class: invalid')
    if obj['barrier_state'] == 'clear' and blocks:
        fail('$.blocks_verbs: clear barriers must not block verbs')
    if obj['barrier_state'] in {'blocking', 'needs_refresh', 'stale'}:
        if not blocks:
            fail('$.blocks_verbs: active barriers must block at least one verb')
        if not stale and not refreshes:
            fail('$.stale_refs: active barriers require stale refs or refresh requirements')
    if 'override_ref' in obj:
        require_pattern(obj['override_ref'], REF_RE, '$.override_ref')
    require_non_implications(obj['non_implications'], BARRIER_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_audit(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, AUDIT_ALLOWED, AUDIT_REQUIRED, 'ST-SURFAUDIT v0')
    require_pattern(obj['audit_id'], AUDIT_RE, '$.audit_id')
    require_pattern(obj['surface_ref'], REF_RE, '$.surface_ref')
    require_refs(obj['audited_refs'], '$.audited_refs', maximum=32)
    if obj['audit_scope'] not in AUDIT_SCOPES:
        fail('$.audit_scope: invalid')
    if obj['finding_state'] not in FINDING_STATES:
        fail('$.finding_state: invalid')
    findings = require_text_list(obj['findings'], '$.findings', maximum=16, allow_empty=obj['finding_state'] == 'pass')
    changes = require_text_list(obj['required_changes'], '$.required_changes', maximum=16, allow_empty=obj['finding_state'] in {'pass', 'deferred'})
    changed_refs = require_refs(obj['changed_refs'], '$.changed_refs', maximum=32, allow_empty=obj['finding_state'] in {'fail', 'deferred'})
    require_pattern(obj['audit_target_revision'], REV_RE, '$.audit_target_revision')
    if obj['finding_state'] in {'fail', 'needs_refactor'} and (not findings or not changes):
        fail('$.findings/required_changes: failing or refactor audits require findings and required changes')
    if obj['finding_state'] == 'needs_refactor' and not changed_refs:
        fail('$.changed_refs: needs_refactor audit must name changed refs')
    if obj['finding_state'] == 'deferred' and 'deferred_reason' not in obj:
        fail('$.deferred_reason: deferred audit requires reason')
    if 'deferred_reason' in obj:
        require_text(obj['deferred_reason'], '$.deferred_reason')
    require_non_implications(obj['non_implications'], AUDIT_NON_IMPLICATIONS, '$.non_implications')
    return obj


def issuer(kind: str = 'renderer', ident: str = 'steward.surface') -> dict[str, str]:
    return {'kind': kind, 'id': ident}


def base_witcard(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-WITCARD v0',
        'witness_id': 'wit_3000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('renderer'),
        'card_id': 'card_1000000000000001',
        'subject_ref': 'component:demo.web',
        'card_kind': 'observation_summary',
        'truth_class': 'weak_basis',
        'headline_state': 'observed',
        'evidence_refs': ['obs_1000000000000001', 'oba_1000000000000001'],
        'missing_witnesses': ['st-probe-or-ctrlverdict'],
        'display_caveats': ['Host manager active is weak evidence only'],
        'downgrade_class': 'weak_basis',
        'observed_at_ms': 1000,
        'expires_or_recheck_by_ms': 3000,
        'basis_refs': ['att_1000000000000001'],
        'non_implications': sorted(WITCARD_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_action(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-ACTIONAFFORD v0',
        'witness_id': 'wit_3000000000000002',
        'cid': 'demo.web',
        'issuer': issuer('renderer'),
        'affordance_id': 'aff_1000000000000001',
        'subject_ref': 'component:demo.web',
        'verb': 'stop',
        'target_ref': 'cycle-demo-web-0001',
        'enabled_state': 'enabled_for_review',
        'exact_target_class': 'runtime_cycle',
        'precondition_refs': ['bar_1000000000000001'],
        'stale_fence_refs': ['cycle-demo-web-0001'],
        'risk_class': 'medium',
        'review_required': True,
        'operation_request_digest': 'sha256:' + 'a' * 64,
        'required_authcheck_ref': 'auth_1000000000000001',
        'observed_at_ms': 1100,
        'basis_refs': ['card_1000000000000001', 'sha256:' + 'a' * 64],
        'non_implications': sorted(ACTION_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_barrier(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-STATUSBARRIER v0',
        'witness_id': 'wit_3000000000000003',
        'cid': 'demo.web',
        'issuer': issuer('steward'),
        'barrier_id': 'bar_1000000000000001',
        'surface_ref': 'surface:demo.web.status',
        'subject_ref': 'component:demo.web',
        'barrier_state': 'blocking',
        'blocks_verbs': ['restart', 'stop'],
        'stale_refs': ['cycle-demo-web-old'],
        'required_refreshes': ['st-rtcycle-current'],
        'reason_class': 'stale_cycle',
        'observed_at_ms': 1050,
        'basis_refs': ['cycle-demo-web-old'],
        'non_implications': sorted(BARRIER_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_audit(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-SURFAUDIT v0',
        'witness_id': 'wit_3000000000000004',
        'cid': 'demo.web',
        'issuer': issuer('surface_auditor'),
        'audit_id': 'aud_1000000000000001',
        'surface_ref': 'surface:steward.cube',
        'audited_refs': ['docs/40-verification/minimum-steward-proof-slice.md', 'tools/run_lint_suite.py'],
        'audit_scope': 'cube_refactor',
        'finding_state': 'needs_refactor',
        'findings': ['Proof slice count drifted after local observation pass'],
        'required_changes': ['Refactor lint harness list and update proof slice inventory'],
        'changed_refs': ['tools/run_lint_suite.py', 'docs/40-verification/minimum-steward-proof-slice.md'],
        'audit_target_revision': 'rev0194',
        'observed_at_ms': 1200,
        'basis_refs': ['docs/00-meta/session-working-queue.md'],
        'non_implications': sorted(AUDIT_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'witness_surface', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    card = base_witcard()
    action = base_action()
    barrier = base_barrier()
    audit = base_audit()
    disabled_action = base_action(
        witness_id='wit_3000000000000005',
        affordance_id='aff_1000000000000002',
        enabled_state='disabled',
        disabled_reason='Status barrier requires fresh runtime cycle witness',
        operation_request_digest='sha256:' + 'b' * 64,
        required_authcheck_ref='auth_1000000000000001',
    )
    clear_barrier = base_barrier(
        witness_id='wit_3000000000000006',
        barrier_id='bar_1000000000000002',
        barrier_state='clear',
        blocks_verbs=[],
        stale_refs=[],
        required_refreshes=[],
        reason_class='unknown',
    )
    pass_audit = base_audit(
        witness_id='wit_3000000000000007',
        audit_id='aud_1000000000000002',
        finding_state='pass',
        findings=[],
        required_changes=[],
        changed_refs=['tools/run_lint_suite.py'],
    )

    return [
        schema_case('witcard.accept.weak-observation-card', 'ST-WITCARD', card, 'accept', 'weak observation evidence can render only with missing stronger witnesses and caveats'),
        schema_case('witcard.reject.weak-rendered-settled', 'ST-WITCARD', {**card, 'headline_state': 'settled'}, 'reject', 'weak cards must not render as settled'),
        schema_case('witcard.reject.missing-nonimplications', 'ST-WITCARD', {**card, 'non_implications': ['not-authority']}, 'reject', 'witness cards must retain non-implications'),
        schema_case('witcard.reject.duplicate-json-key', 'ST-WITCARD', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-WITCARD v0","schema":"ST-WITCARD v0","witness_id":"wit_3000000000000001","cid":"demo.web","issuer":{"kind":"renderer","id":"steward.surface"},"card_id":"card_1000000000000001","subject_ref":"component:demo.web","card_kind":"observation_summary","truth_class":"weak_basis","headline_state":"observed","evidence_refs":["obs_1000000000000001"],"missing_witnesses":["st-probe-or-ctrlverdict"],"display_caveats":["Host manager active is weak evidence only"],"downgrade_class":"weak_basis","observed_at_ms":1000,"basis_refs":["att_1000000000000001"],"non_implications":[]}'),
        schema_case('action.accept.enabled-reviewed-stop', 'ST-ACTIONAFFORD', action, 'accept', 'mutating affordance can be shown only when bound to exact request digest, authcheck, review, and stale fence'),
        schema_case('action.accept.disabled-by-barrier', 'ST-ACTIONAFFORD', disabled_action, 'accept', 'disabled actions can explain the status barrier without executing anything'),
        schema_case('action.reject.mutating-without-authcheck', 'ST-ACTIONAFFORD', {k: v for k, v in action.items() if k != 'required_authcheck_ref'}, 'reject', 'enabled mutating affordances require authorization-check refs'),
        schema_case('action.reject.raw-pid-target', 'ST-ACTIONAFFORD', {**action, 'target_ref': 'pid:1234'}, 'reject', 'surface actions cannot target raw host identities'),
        schema_case('barrier.accept.blocking-stale-cycle', 'ST-STATUSBARRIER', barrier, 'accept', 'status barrier blocks risky verbs until stale cycle evidence is refreshed'),
        schema_case('barrier.accept.clear', 'ST-STATUSBARRIER', clear_barrier, 'accept', 'clear barrier blocks no verbs'),
        schema_case('barrier.reject.clear-blocking-verbs', 'ST-STATUSBARRIER', {**clear_barrier, 'blocks_verbs': ['stop']}, 'reject', 'clear barriers cannot secretly block verbs'),
        schema_case('barrier.reject.active-without-refresh', 'ST-STATUSBARRIER', {**barrier, 'stale_refs': [], 'required_refreshes': []}, 'reject', 'active barriers must name stale refs or refresh requirements'),
        schema_case('audit.accept.needs-refactor', 'ST-SURFAUDIT', audit, 'accept', 'cube audit can name findings and changed refs without becoming a fix by itself'),
        schema_case('audit.accept.pass-after-refactor', 'ST-SURFAUDIT', pass_audit, 'accept', 'audit pass can reference changed surfaces after refactor'),
        schema_case('audit.reject.needs-refactor-without-changed-refs', 'ST-SURFAUDIT', {**audit, 'changed_refs': []}, 'reject', 'needs_refactor audit must name changed refs'),
        schema_case('audit.reject.claims-fixed', 'ST-SURFAUDIT', {**audit, 'claims_execution': True}, 'reject', 'surface audit cannot claim execution or fix completion through forbidden fields'),

        flow_case('surface.accept.blocked-weak-observation', [
            {'event': 'card', 'packet': card},
            {'event': 'barrier', 'packet': barrier},
            {'event': 'action', 'packet': disabled_action},
        ], 'accept', 'weak observation card plus stale-cycle barrier renders a disabled lifecycle action'),
        flow_case('surface.accept.refactor-audit-recorded', [
            {'event': 'audit', 'packet': audit},
            {'event': 'audit', 'packet': pass_audit},
        ], 'accept', 'audit/refactor can record finding and changed refs without becoming authority'),
        flow_case('surface.reject.enabled-action-ignores-barrier', [
            {'event': 'card', 'packet': card},
            {'event': 'barrier', 'packet': barrier},
            {'event': 'action', 'packet': action},
        ], 'reject', 'enabled mutating action cannot ignore an active barrier that blocks its verb'),
        flow_case('surface.reject.card-as-readiness', [
            {'event': 'card', 'packet': card, 'claims_readiness': True},
        ], 'reject', 'rendered card metadata cannot promote weak evidence into readiness'),
        flow_case('surface.reject.action-as-execution', [
            {'event': 'action', 'packet': action, 'claims_operation_executed': True},
        ], 'reject', 'action affordance cannot claim operation execution'),
        flow_case('surface.reject.audit-as-fix', [
            {'event': 'audit', 'packet': audit, 'claims_fix': True},
        ], 'reject', 'audit event metadata cannot claim fixes or authority'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-WITCARD':
            validate_witcard(obj)
        elif kind == 'ST-ACTIONAFFORD':
            validate_action(obj)
        elif kind == 'ST-STATUSBARRIER':
            validate_barrier(obj)
        elif kind == 'ST-SURFAUDIT':
            validate_audit(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        cards_by_subject: dict[str, list[dict[str, Any]]] = {}
        active_barriers_by_subject: dict[str, list[dict[str, Any]]] = {}
        audits_by_id: dict[str, dict[str, Any]] = {}
        seen_packet_digests: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'card':
                card = validate_witcard(packet)
                check_packet_identity(seen_packet_digests, card['card_id'], card, where)
                cards_by_subject.setdefault(card['subject_ref'], []).append(card)
            elif kind == 'barrier':
                barrier = validate_barrier(packet)
                check_packet_identity(seen_packet_digests, barrier['barrier_id'], barrier, where)
                if barrier['barrier_state'] in {'blocking', 'needs_refresh', 'stale'}:
                    active_barriers_by_subject.setdefault(barrier['subject_ref'], []).append(barrier)
            elif kind == 'action':
                action = validate_action(packet)
                check_packet_identity(seen_packet_digests, action['affordance_id'], action, where)
                if action['enabled_state'] == 'enabled_for_review':
                    for barrier in active_barriers_by_subject.get(action['subject_ref'], []):
                        if action['verb'] in barrier['blocks_verbs'] and 'override_ref' not in barrier:
                            fail(f'{where}: enabled action ignores active status barrier')
                if action['verb'] in MUTATING_VERBS and action['subject_ref'] not in cards_by_subject:
                    fail(f'{where}: mutating affordance lacks visible witness card basis')
            elif kind == 'audit':
                audit = validate_audit(packet)
                check_packet_identity(seen_packet_digests, audit['audit_id'], audit, where)
                old = audits_by_id.get(audit['audit_id'])
                if old is not None and digest(old) != digest(audit):
                    fail(f'{where}: audit id reused for different packet')
                audits_by_id[audit['audit_id']] = audit
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'witness_surface':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-witness-surface-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-witness-surface-corpus] FAIL: corpus is stale; run tools/steward_witness_surface_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-witness-surface-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
