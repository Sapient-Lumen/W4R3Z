#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/local-observation-provenance-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
OBS_RE = re.compile(r'^obs_[a-z0-9]{16}$')
APP_RE = re.compile(r'^oba_[a-z0-9]{16}$')
CUR_RE = re.compile(r'^cur_[a-z0-9]{16}$')
ATTACH_RE = re.compile(r'^att_[a-z0-9]{16}$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_current', 'claims_current_state', 'claims_fresh',
    'claims_readiness', 'claims_ready', 'claims_serving', 'claims_effect_success',
    'claims_execution', 'claims_policy', 'claims_mutation', 'claims_native_truth',
    'claims_lossless', 'claims_drained', 'claims_custody', 'claims_work_complete',
    'authority', 'current_state', 'current', 'fresh', 'ready', 'readiness',
    'serving', 'effect_success', 'execution', 'mutation', 'policy_authority',
    'native_truth', 'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie',
    'authorization', 'value', 'path', 'raw_path', 'host_path', 'endpoint',
    'raw_endpoint', 'url', 'uri', 'fd', 'descriptor_number', 'pid', 'ppid',
    'pgid', 'cgroup', 'cgroup_path', 'systemd_unit', 'host_unit', 'pod_name',
    'container_id', 'node_name', 'process_name', 'pty_name', 'shell_job',
    'pane_text', 'k8s_resource_name',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {
    'steward', 'operator', 'adapter', 'runtime', 'supervisor', 'platform',
    'orchestrator', 'proxy', 'load_balancer', 'broker', 'queue', 'observer',
    'shell', 'file_watcher', 'policy',
}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

LOCALOBS_REQUIRED = COMMON_REQUIRED | {
    'observation_id', 'subject_ref', 'source_kind', 'source_scope',
    'observation_class', 'observed_state', 'vantage_kind', 'confidence_class',
    'freshness_class',
}
LOCALOBS_OPTIONAL = COMMON_OPTIONAL | {'runtime_cycle_ref', 'cursor_ref', 'expires_or_recheck_by_ms', 'adapter_digest'}
LOCALOBS_ALLOWED = LOCALOBS_REQUIRED | LOCALOBS_OPTIONAL
SOURCE_KINDS = {
    'systemd', 'kubernetes', 'runtime', 'supervisor', 'shell', 'proxy',
    'load_balancer', 'broker', 'queue', 'adapter', 'watcher', 'platform',
    'file_watch', 'timer', 'unknown',
}
SOURCE_SCOPES = {
    'host_manager', 'orchestrator', 'component_runtime', 'sidecar', 'proxy_route',
    'broker_subscription', 'queue_partition', 'shell_session', 'file_material',
    'timer_tick', 'unknown',
}
OBS_CLASSES = {
    'process_state', 'unit_state', 'pod_phase', 'container_state', 'probe_result',
    'route_state', 'channel_state', 'cursor_state', 'resource_pressure',
    'file_change', 'liveness_signal', 'log_pattern', 'adapter_summary', 'unknown',
}
OBS_STATES = {
    'green', 'red', 'active', 'inactive', 'running', 'pending', 'failed',
    'degraded', 'advanced', 'stale', 'present', 'absent', 'unknown',
}
VANTAGE_KINDS = {
    'inside_component', 'same_host', 'host_manager', 'orchestrator_api',
    'sidecar', 'proxy', 'broker', 'external_probe', 'shell_observer',
    'file_observer', 'unknown',
}
CONFIDENCE_CLASSES = {'weak', 'medium', 'strong', 'conflicting', 'unknown'}
FRESHNESS_CLASSES = {'fresh_when_observed', 'cached', 'stale', 'expired', 'unknown'}
LOCALOBS_NON_IMPLICATIONS = {
    'not-authority', 'not-current-state', 'not-freshness', 'not-readiness',
    'not-serving', 'not-effect-success', 'not-execution',
}

OBSAPP_REQUIRED = COMMON_REQUIRED | {
    'appraisal_id', 'observation_ref', 'source_kind', 'source_scope',
    'appraisal_state', 'confidence_class', 'usable_for', 'caveats',
    'expires_at_ms',
}
OBSAPP_OPTIONAL = COMMON_OPTIONAL | {'downgrade_reason'}
OBSAPP_ALLOWED = OBSAPP_REQUIRED | OBSAPP_OPTIONAL
APPRAISAL_STATES = {'allow_weak_evidence', 'quarantine', 'reject', 'expired', 'unknown'}
USABLE_FOR = {'history', 'audit', 'explanation', 'operator_review', 'recovery_hint', 'recheck_request', 'weak_basis'}
OBSAPP_NON_IMPLICATIONS = {
    'not-global-trust', 'not-authority', 'not-current-state', 'not-policy',
    'not-execution', 'not-readiness', 'not-serving',
}

OBSCURSOR_REQUIRED = COMMON_REQUIRED | {
    'cursor_id', 'stream_ref', 'source_kind', 'position_state', 'continuity_state',
    'cursor_digest', 'sequence_class',
}
OBSCURSOR_OPTIONAL = COMMON_OPTIONAL | {'latest_observation_ref', 'gap_reason', 'expires_or_recheck_by_ms'}
OBSCURSOR_ALLOWED = OBSCURSOR_REQUIRED | OBSCURSOR_OPTIONAL
POSITION_STATES = {'advanced', 'unchanged', 'reset', 'gap_detected', 'overflow', 'compacted', 'unknown'}
CONTINUITY_STATES = {'continuous', 'gap', 'reset', 'lost', 'unknown'}
SEQUENCE_CLASSES = {'monotonic_adapter_sequence', 'snapshot_plus_delta', 'opaque_cursor', 'poll_generation', 'wall_clock_sample', 'unknown'}
OBSCURSOR_NON_IMPLICATIONS = {
    'not-current-state', 'not-lossless-continuity', 'not-readiness',
    'not-serving', 'not-effect-success', 'not-demand-drained',
}

OBSATTACH_REQUIRED = COMMON_REQUIRED | {
    'attachment_id', 'observation_ref', 'appraisal_ref', 'attach_state',
    'target_surface', 'required_native_witnesses', 'resulting_refs',
    'downgrade_class',
}
OBSATTACH_OPTIONAL = COMMON_OPTIONAL | {'recheck_after_ms', 'downgrade_reason'}
OBSATTACH_ALLOWED = OBSATTACH_REQUIRED | OBSATTACH_OPTIONAL
ATTACH_STATES = {'attached_as_weak_basis', 'refused', 'needs_recheck', 'quarantined', 'unknown'}
TARGET_SURFACES = {'explanation', 'operator_review', 'recovery_hint', 'audit', 'recheck_request', 'history'}
DOWNGRADE_CLASSES = {'weak_basis', 'history_only', 'requires_recheck', 'quarantine', 'reject', 'unknown'}
OBSATTACH_NON_IMPLICATIONS = {
    'not-execution', 'not-authority', 'not-current-state', 'not-freshness',
    'not-readiness', 'not-serving', 'not-effect-success',
}

LOCAL_PACKET_PREFIXES = ('obs_', 'oba_', 'cur_', 'att_')


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = ['token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:', '/var/', '/proc/', '/tmp/', 'current state proof']
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or currentness flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    return items


def require_text_list(value: Any, path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_text(item, f'{path}[{idx}]')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_enum_list(value: Any, enum: set[str], path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    bad = sorted(set(items) - enum)
    if bad:
        fail(f'{path}: invalid entries {bad}')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_window(obj: dict[str, Any], path: str) -> None:
    require_int(obj['observed_at_ms'], f'{path}.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    for field in ('expires_or_recheck_by_ms', 'expires_at_ms', 'recheck_after_ms'):
        if field in obj:
            require_int(obj[field], f'{path}.{field}', minimum=0, maximum=9_223_372_036_854_775_807)


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    validate_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_localobs(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, LOCALOBS_ALLOWED, LOCALOBS_REQUIRED, 'ST-LOCALOBS v0')
    require_pattern(obj['observation_id'], OBS_RE, '$.observation_id')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    if obj['source_kind'] not in SOURCE_KINDS:
        fail('$.source_kind: invalid')
    if obj['source_scope'] not in SOURCE_SCOPES:
        fail('$.source_scope: invalid')
    if obj['observation_class'] not in OBS_CLASSES:
        fail('$.observation_class: invalid')
    if obj['observed_state'] not in OBS_STATES:
        fail('$.observed_state: invalid')
    if obj['vantage_kind'] not in VANTAGE_KINDS:
        fail('$.vantage_kind: invalid')
    if obj['confidence_class'] not in CONFIDENCE_CLASSES:
        fail('$.confidence_class: invalid')
    if obj['freshness_class'] not in FRESHNESS_CLASSES:
        fail('$.freshness_class: invalid')
    if 'runtime_cycle_ref' in obj:
        require_pattern(obj['runtime_cycle_ref'], CYCLE_RE, '$.runtime_cycle_ref')
    if 'cursor_ref' in obj:
        require_pattern(obj['cursor_ref'], CUR_RE, '$.cursor_ref')
    if 'adapter_digest' in obj:
        require_pattern(obj['adapter_digest'], DIGEST_RE, '$.adapter_digest')
    if 'expires_or_recheck_by_ms' in obj and obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
        fail('$.expires_or_recheck_by_ms: precedes observed_at_ms')
    require_non_implications(obj['non_implications'], LOCALOBS_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_obsappraise(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSAPP_ALLOWED, OBSAPP_REQUIRED, 'ST-OBSAPPRAISE v0')
    require_pattern(obj['appraisal_id'], APP_RE, '$.appraisal_id')
    require_pattern(obj['observation_ref'], OBS_RE, '$.observation_ref')
    if obj['source_kind'] not in SOURCE_KINDS:
        fail('$.source_kind: invalid')
    if obj['source_scope'] not in SOURCE_SCOPES:
        fail('$.source_scope: invalid')
    if obj['appraisal_state'] not in APPRAISAL_STATES:
        fail('$.appraisal_state: invalid')
    if obj['confidence_class'] not in CONFIDENCE_CLASSES:
        fail('$.confidence_class: invalid')
    usable = require_enum_list(obj['usable_for'], USABLE_FOR, '$.usable_for', maximum=8, allow_empty=obj['appraisal_state'] in {'reject', 'expired', 'unknown'})
    require_text_list(obj['caveats'], '$.caveats', maximum=8, allow_empty=False)
    if obj['appraisal_state'] == 'allow_weak_evidence' and obj['expires_at_ms'] <= obj['observed_at_ms']:
        fail('$.expires_at_ms: active appraisal must expire after observed_at_ms')
    if obj['appraisal_state'] in {'quarantine', 'reject', 'expired'} and 'weak_basis' in usable:
        fail('$.usable_for: quarantined/rejected/expired appraisals cannot allow weak_basis use')
    if 'downgrade_reason' in obj:
        require_text(obj['downgrade_reason'], '$.downgrade_reason')
    require_non_implications(obj['non_implications'], OBSAPP_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_obscursor(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSCURSOR_ALLOWED, OBSCURSOR_REQUIRED, 'ST-OBSCURSOR v0')
    require_pattern(obj['cursor_id'], CUR_RE, '$.cursor_id')
    require_pattern(obj['stream_ref'], REF_RE, '$.stream_ref')
    if obj['source_kind'] not in SOURCE_KINDS:
        fail('$.source_kind: invalid')
    if obj['position_state'] not in POSITION_STATES:
        fail('$.position_state: invalid')
    if obj['continuity_state'] not in CONTINUITY_STATES:
        fail('$.continuity_state: invalid')
    require_pattern(obj['cursor_digest'], DIGEST_RE, '$.cursor_digest')
    if obj['sequence_class'] not in SEQUENCE_CLASSES:
        fail('$.sequence_class: invalid')
    if 'latest_observation_ref' in obj:
        require_pattern(obj['latest_observation_ref'], OBS_RE, '$.latest_observation_ref')
    gapish = obj['continuity_state'] in {'gap', 'reset', 'lost'} or obj['position_state'] in {'gap_detected', 'overflow', 'compacted'}
    if gapish and 'gap_reason' not in obj:
        fail('$.gap_reason: required when continuity is gapped, reset, lost, overflowed, or compacted')
    if 'gap_reason' in obj:
        require_text(obj['gap_reason'], '$.gap_reason')
    if 'expires_or_recheck_by_ms' in obj and obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
        fail('$.expires_or_recheck_by_ms: precedes observed_at_ms')
    require_non_implications(obj['non_implications'], OBSCURSOR_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_obsattach(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSATTACH_ALLOWED, OBSATTACH_REQUIRED, 'ST-OBSATTACH v0')
    require_pattern(obj['attachment_id'], ATTACH_RE, '$.attachment_id')
    require_pattern(obj['observation_ref'], OBS_RE, '$.observation_ref')
    require_pattern(obj['appraisal_ref'], APP_RE, '$.appraisal_ref')
    if obj['attach_state'] not in ATTACH_STATES:
        fail('$.attach_state: invalid')
    if obj['target_surface'] not in TARGET_SURFACES:
        fail('$.target_surface: invalid')
    native_refs = require_refs(obj['required_native_witnesses'], '$.required_native_witnesses', maximum=16, allow_empty=obj['attach_state'] != 'attached_as_weak_basis')
    require_refs(obj['resulting_refs'], '$.resulting_refs', maximum=16, allow_empty=obj['attach_state'] != 'attached_as_weak_basis')
    if obj['downgrade_class'] not in DOWNGRADE_CLASSES:
        fail('$.downgrade_class: invalid')
    if obj['attach_state'] == 'attached_as_weak_basis' and obj['downgrade_class'] != 'weak_basis':
        fail('$.downgrade_class: weak attachments must stay weak_basis')
    if obj['attach_state'] == 'needs_recheck' and 'recheck_after_ms' not in obj:
        fail('$.recheck_after_ms: needs_recheck attachment requires a recheck time')
    if obj['attach_state'] == 'quarantined' and obj['downgrade_class'] != 'quarantine':
        fail('$.downgrade_class: quarantined attachment must use quarantine downgrade')
    if obj['attach_state'] == 'attached_as_weak_basis' and not any(not ref.startswith(LOCAL_PACKET_PREFIXES) for ref in native_refs):
        fail('$.required_native_witnesses: weak basis attachment must still require at least one non-observation native witness')
    if 'recheck_after_ms' in obj and obj['recheck_after_ms'] < obj['observed_at_ms']:
        fail('$.recheck_after_ms: precedes observed_at_ms')
    if 'downgrade_reason' in obj:
        require_text(obj['downgrade_reason'], '$.downgrade_reason')
    require_non_implications(obj['non_implications'], OBSATTACH_NON_IMPLICATIONS, '$.non_implications')
    return obj


def issuer(kind: str = 'adapter', ident: str = 'steward.local') -> dict[str, str]:
    return {'kind': kind, 'id': ident}


def base_localobs(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-LOCALOBS v0',
        'witness_id': 'wit_2000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('adapter'),
        'observation_id': 'obs_1000000000000001',
        'subject_ref': 'component:demo.web',
        'source_kind': 'systemd',
        'source_scope': 'host_manager',
        'observation_class': 'unit_state',
        'observed_state': 'active',
        'vantage_kind': 'host_manager',
        'confidence_class': 'weak',
        'freshness_class': 'fresh_when_observed',
        'observed_at_ms': 1000,
        'basis_refs': ['adapter:host-manager-sample'],
        'non_implications': sorted(LOCALOBS_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_obsappraise(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSAPPRAISE v0',
        'witness_id': 'wit_2000000000000002',
        'cid': 'demo.web',
        'issuer': issuer('observer'),
        'appraisal_id': 'oba_1000000000000001',
        'observation_ref': 'obs_1000000000000001',
        'source_kind': 'systemd',
        'source_scope': 'host_manager',
        'appraisal_state': 'allow_weak_evidence',
        'confidence_class': 'weak',
        'usable_for': ['explanation', 'recheck_request', 'weak_basis'],
        'caveats': ['Host manager active is not Steward readiness'],
        'observed_at_ms': 1100,
        'expires_at_ms': 3000,
        'basis_refs': ['obs_1000000000000001'],
        'non_implications': sorted(OBSAPP_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_obscursor(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSCURSOR v0',
        'witness_id': 'wit_2000000000000003',
        'cid': 'demo.web',
        'issuer': issuer('observer'),
        'cursor_id': 'cur_1000000000000001',
        'stream_ref': 'obsstream:demo.web',
        'source_kind': 'adapter',
        'position_state': 'advanced',
        'continuity_state': 'continuous',
        'cursor_digest': 'sha256:' + '3' * 64,
        'sequence_class': 'opaque_cursor',
        'latest_observation_ref': 'obs_1000000000000001',
        'observed_at_ms': 1200,
        'basis_refs': ['obsstream:demo.web'],
        'non_implications': sorted(OBSCURSOR_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_obsattach(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSATTACH v0',
        'witness_id': 'wit_2000000000000004',
        'cid': 'demo.web',
        'issuer': issuer('steward'),
        'attachment_id': 'att_1000000000000001',
        'observation_ref': 'obs_1000000000000001',
        'appraisal_ref': 'oba_1000000000000001',
        'attach_state': 'attached_as_weak_basis',
        'target_surface': 'explanation',
        'required_native_witnesses': ['probe:wit-native-1'],
        'resulting_refs': ['explain:demo-web-host-manager-active'],
        'downgrade_class': 'weak_basis',
        'observed_at_ms': 1300,
        'basis_refs': ['obs_1000000000000001', 'oba_1000000000000001'],
        'non_implications': sorted(OBSATTACH_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'local_observation', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    lo = base_localobs()
    app = base_obsappraise()
    cur = base_obscursor()
    att = base_obsattach()
    expired_app = base_obsappraise(
        witness_id='wit_2000000000000005',
        appraisal_id='oba_1000000000000002',
        appraisal_state='expired',
        usable_for=['history'],
        expires_at_ms=1250,
        downgrade_reason='Observation stale before attachment',
    )
    gap_cursor = base_obscursor(
        witness_id='wit_2000000000000006',
        cursor_id='cur_1000000000000002',
        position_state='overflow',
        continuity_state='gap',
        cursor_digest='sha256:' + '4' * 64,
        gap_reason='Adapter overflow requires local recheck',
    )
    recheck_att = base_obsattach(
        witness_id='wit_2000000000000007',
        attachment_id='att_1000000000000002',
        attach_state='needs_recheck',
        target_surface='recheck_request',
        required_native_witnesses=[],
        resulting_refs=[],
        downgrade_class='requires_recheck',
        recheck_after_ms=1400,
        downgrade_reason='Cursor continuity gap prevents weak-basis attachment',
    )

    cases: list[dict[str, Any]] = [
        schema_case('localobs.accept.host-manager-active', 'ST-LOCALOBS', lo, 'accept', 'host manager active is a weak local observation with explicit non-implications'),
        schema_case('localobs.reject.raw-systemd-unit', 'ST-LOCALOBS', {**lo, 'systemd_unit': 'demo.service'}, 'reject', 'raw host-manager identifiers do not enter public observation packets'),
        schema_case('localobs.reject.missing-currentness-refusal', 'ST-LOCALOBS', {**lo, 'non_implications': ['not-authority']}, 'reject', 'local observations must refuse currentness/readiness/service claims'),
        schema_case('localobs.reject.duplicate-json-key', 'ST-LOCALOBS', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-LOCALOBS v0","schema":"ST-LOCALOBS v0","witness_id":"wit_2000000000000001","cid":"demo.web","issuer":{"kind":"adapter","id":"steward.local"},"observation_id":"obs_1000000000000001","subject_ref":"component:demo.web","source_kind":"systemd","source_scope":"host_manager","observation_class":"unit_state","observed_state":"active","vantage_kind":"host_manager","confidence_class":"weak","freshness_class":"fresh_when_observed","observed_at_ms":1000,"basis_refs":["adapter:host-manager-sample"],"non_implications":[]}'),
        schema_case('obsappraise.accept.weak-evidence', 'ST-OBSAPPRAISE', app, 'accept', 'appraisal permits limited weak evidence use, not global trust or policy'),
        schema_case('obsappraise.reject.current-state-use', 'ST-OBSAPPRAISE', {**app, 'usable_for': ['current_state']}, 'reject', 'source appraisal cannot authorize current-state use'),
        schema_case('obsappraise.reject-expired-weak-basis', 'ST-OBSAPPRAISE', {**app, 'expires_at_ms': 1000}, 'reject', 'active weak-basis appraisals must be time-bounded into the future'),
        schema_case('obscursor.accept.advanced-continuous', 'ST-OBSCURSOR', cur, 'accept', 'cursor advance is continuity evidence, not current lifecycle truth'),
        schema_case('obscursor.reject.gap-without-reason', 'ST-OBSCURSOR', {**cur, 'continuity_state': 'gap'}, 'reject', 'cursor gaps require explicit downgrade reasons'),
        schema_case('obscursor.reject.claims-drained', 'ST-OBSCURSOR', {**cur, 'claims_drained': True}, 'reject', 'cursor motion cannot claim demand drain'),
        schema_case('obsattach.accept.weak-basis', 'ST-OBSATTACH', att, 'accept', 'attachment records weak use and names native witnesses still required'),
        schema_case('obsattach.reject.claims-readiness', 'ST-OBSATTACH', {**att, 'claims_readiness': True}, 'reject', 'weak observation attachment cannot claim readiness'),
        schema_case('obsattach.reject.local-only-native-witnesses', 'ST-OBSATTACH', {**att, 'required_native_witnesses': ['obs_1000000000000001']}, 'reject', 'weak-basis attachment must not satisfy itself only with local-observation packets'),
        schema_case('obsattach.reject.needs-recheck-without-time', 'ST-OBSATTACH', {k: v for k, v in recheck_att.items() if k != 'recheck_after_ms'}, 'reject', 'needs_recheck attachment must provide a concrete recheck time'),

        flow_case('localobs.accept.appraised-weak-attachment', [
            {'event': 'local_observation', 'packet': lo},
            {'event': 'appraisal', 'packet': app},
            {'event': 'attachment', 'packet': att},
        ], 'accept', 'local observation may become weak explanatory basis only with appraisal and native-witness requirements'),
        flow_case('localobs.accept.cursor-gap-to-recheck', [
            {'event': 'local_observation', 'packet': lo},
            {'event': 'appraisal', 'packet': app},
            {'event': 'cursor', 'packet': gap_cursor},
            {'event': 'attachment', 'packet': recheck_att},
        ], 'accept', 'cursor continuity loss can produce a recheck request rather than currentness'),
        flow_case('localobs.reject.observation-as-readiness', [
            {'event': 'local_observation', 'packet': lo, 'claims_readiness': True},
        ], 'reject', 'host-manager active cannot be promoted into Steward readiness by event metadata'),
        flow_case('localobs.reject.cursor-as-demand-drained', [
            {'event': 'cursor', 'packet': cur, 'claims_demand_drained': True},
        ], 'reject', 'cursor advancement cannot claim old demand drained'),
        flow_case('localobs.reject.expired-appraisal-used', [
            {'event': 'local_observation', 'packet': lo},
            {'event': 'appraisal', 'packet': expired_app},
            {'event': 'attachment', 'packet': base_obsattach(appraisal_ref='oba_1000000000000002', observed_at_ms=1400)},
        ], 'reject', 'expired appraisals cannot support weak-basis attachment'),
        flow_case('localobs.reject.attachment-without-appraisal', [
            {'event': 'local_observation', 'packet': lo},
            {'event': 'attachment', 'packet': att},
        ], 'reject', 'observation attachment requires an observed appraisal'),
        flow_case('localobs.reject.adapter-green-as-current-state', [
            {'event': 'local_observation', 'packet': base_localobs(observation_class='adapter_summary', observed_state='green', source_kind='adapter', source_scope='component_runtime')},
            {'event': 'appraisal', 'packet': app},
            {'event': 'attachment', 'packet': att, 'claims_current_state': True},
        ], 'reject', 'adapter green is not current lifecycle state'),
        flow_case('localobs.reject.weak-basis-with-local-only-witnesses', [
            {'event': 'local_observation', 'packet': lo},
            {'event': 'appraisal', 'packet': app},
            {'event': 'attachment', 'packet': {**att, 'required_native_witnesses': ['obs_1000000000000001']}},
        ], 'reject', 'local observations cannot be their own native witness requirement'),
        flow_case('localobs.reject.duplicate-observation-different-digest', [
            {'event': 'local_observation', 'packet': lo},
            {'event': 'local_observation', 'packet': base_localobs(witness_id='wit_2000000000000008', observed_state='inactive')},
        ], 'reject', 'same observation id cannot name two different canonical packets'),
    ]
    return cases


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-LOCALOBS':
            validate_localobs(obj)
        elif kind == 'ST-OBSAPPRAISE':
            validate_obsappraise(obj)
        elif kind == 'ST-OBSCURSOR':
            validate_obscursor(obj)
        elif kind == 'ST-OBSATTACH':
            validate_obsattach(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obs_by_id: dict[str, dict[str, Any]] = {}
        app_by_id: dict[str, dict[str, Any]] = {}
        cursor_by_id: dict[str, dict[str, Any]] = {}
        seen_packet_digests: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'local_observation':
                lo = validate_localobs(packet)
                check_packet_identity(seen_packet_digests, lo['observation_id'], lo, where)
                obs_by_id[lo['observation_id']] = lo
            elif kind == 'appraisal':
                app = validate_obsappraise(packet)
                check_packet_identity(seen_packet_digests, app['appraisal_id'], app, where)
                if app['observation_ref'] not in obs_by_id:
                    fail(f'{where}: appraisal cites unknown local observation')
                app_by_id[app['appraisal_id']] = app
            elif kind == 'cursor':
                cur = validate_obscursor(packet)
                check_packet_identity(seen_packet_digests, cur['cursor_id'], cur, where)
                cursor_by_id[cur['cursor_id']] = cur
            elif kind == 'attachment':
                att = validate_obsattach(packet)
                check_packet_identity(seen_packet_digests, att['attachment_id'], att, where)
                if att['observation_ref'] not in obs_by_id:
                    fail(f'{where}: attachment cites unknown local observation')
                if att['appraisal_ref'] not in app_by_id:
                    fail(f'{where}: attachment cites unknown appraisal')
                app = app_by_id[att['appraisal_ref']]
                if app['observation_ref'] != att['observation_ref']:
                    fail(f'{where}: attachment observation/appraisal mismatch')
                if att['attach_state'] == 'attached_as_weak_basis':
                    if app['appraisal_state'] != 'allow_weak_evidence':
                        fail(f'{where}: weak-basis attachment requires allow_weak_evidence appraisal')
                    if app['expires_at_ms'] <= att['observed_at_ms']:
                        fail(f'{where}: weak-basis attachment uses expired appraisal')
                    if 'weak_basis' not in app['usable_for']:
                        fail(f'{where}: appraisal does not permit weak_basis use')
                if att['attach_state'] == 'needs_recheck' and cursor_by_id:
                    # Recheck is the only allowed consequence of observed cursor discontinuity in this corpus.
                    if not any(cur['continuity_state'] in {'gap', 'reset', 'lost'} or cur['position_state'] in {'gap_detected', 'overflow', 'compacted'} for cur in cursor_by_id.values()):
                        fail(f'{where}: needs_recheck attachment lacks a cursor discontinuity basis')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'local_observation':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-local-observation-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-local-observation-corpus] FAIL: corpus is stale; run tools/steward_local_observation_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-local-observation-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
