#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

from schema_registry_utils import parse_schema_registry_rows

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'schemas/README.md'


def render_schema_readme() -> str:
    lines = [
        '# Schemas',
        '',
        'Generated from `docs/30-architecture/schema-registry.md`.',
        '',
        'Machine-readable closed JSON profiles for Steward proof-slice objects. These files are paired with deterministic harnesses under `tools/` and corpora under `docs/40-verification/corpora/`.',
        '',
    ]
    for schema_id, meaning, _human, machine, _checker in parse_schema_registry_rows():
        if machine == 'n/a':
            continue
        filename = Path(machine.strip('`')).name
        lines.append(f'- `{filename}` — {schema_id} {meaning}.')
    lines.append('')
    return '\n'.join(lines)


def main() -> int:
    OUT.write_text(render_schema_readme(), encoding='utf-8')
    print(OUT)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
