#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/retry-settlement-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
ADVICE_RE = re.compile(r'^radv_[a-z0-9]{16}$')
BUDGET_RE = re.compile(r'^rbud_[a-z0-9]{16}$')
ATTEMPT_RE = re.compile(r'^att_[a-z0-9]{16}$')
GROUP_RE = re.compile(r'^rgrp_[a-z0-9]{16}$')
HEDGE_RE = re.compile(r'^hedg_[a-z0-9]{16}$')
KEY_RE = re.compile(r'^(idem|effkey)_[a-z0-9]{16}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_ready', 'claims_readiness', 'claims_serving', 'claims_stopped',
    'claims_admitted', 'claims_custody', 'claims_work_complete', 'claims_effect_success',
    'claims_no_side_effect', 'claims_no_duplicate', 'claims_exactly_once', 'claims_lossless',
    'claims_route_current', 'claims_budget_capacity', 'claims_grant', 'claims_reservation',
    'ready', 'serving', 'admitted', 'custody', 'work_completed', 'effect_success',
    'no_side_effect', 'no_duplicate', 'exactly_once', 'lossless', 'route_current',
    'reservation', 'grant', 'quota_capacity', 'raw_log', 'scrollback', 'token', 'secret',
    'raw_secret', 'raw_token', 'raw_handle', 'bearer', 'value', 'path', 'raw_path',
    'mount_path', 'fd', 'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path', 'systemd_unit',
    'systemd_job_path', 'pod_name', 'container_id', 'process_name', 'host_unit', 'node_name',
    'allocation_id', 'endpoint', 'raw_endpoint', 'url', 'uri', 'authorization', 'cookie',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {
    'steward', 'operator', 'adapter', 'controller', 'runtime', 'client', 'proxy',
    'library', 'mesh', 'queue', 'broker', 'remote_peer', 'observer', 'platform',
}

ADVICE_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'advice_id', 'advice_state', 'reason',
    'scope_ref', 'observed_at_ms', 'basis_refs', 'non_implications',
}
ADVICE_OPTIONAL = {
    'attempt_group_ref', 'retry_after_source', 'not_before_ms', 'delay_ms',
    'pushback_ref', 'expires_or_recheck_by_ms', 'unknown_reason',
}
ADVICE_ALLOWED = ADVICE_REQUIRED | ADVICE_OPTIONAL
ADVICE_STATES = {
    'no_hint', 'not_before', 'cooling_down', 'pushed_back', 'rate_limited',
    'budget_exhausted', 'manual_review_required', 'expired', 'superseded', 'unknown',
}
ADVICE_REASONS = {
    'transient_error', 'overload', 'throttled', 'still_processing', 'early_data_rejected',
    'drain_in_progress', 'local_backoff', 'policy_denied', 'repair_required', 'unknown',
}
RETRY_AFTER_SOURCES = {
    'http_retry_after_delta', 'http_retry_after_date', 'grpc_pushback', 'envoy_route',
    'aws_sdk_quota', 'local_backoff', 'operator', 'none', 'unknown',
}
ADVICE_NON_IMPLICATIONS = {
    'not-grant', 'not-reservation', 'not-admission', 'not-readiness', 'not-serving',
    'not-effect-success', 'not-budget-capacity', 'not-retry-success',
}

BUDGET_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'budget_id', 'budget_scope', 'budget_state',
    'decision_effect', 'observed_at_ms', 'basis_refs', 'non_implications',
}
BUDGET_OPTIONAL = {
    'attempt_group_ref', 'remaining_class', 'next_refill_after_ms', 'limit_ref', 'advice_ref',
    'expires_or_recheck_by_ms', 'unknown_reason',
}
BUDGET_ALLOWED = BUDGET_REQUIRED | BUDGET_OPTIONAL
BUDGET_SCOPES = {'component', 'route', 'client', 'caller', 'operation', 'upstream', 'local', 'unknown'}
BUDGET_STATES = {'available', 'constrained', 'exhausted', 'disabled', 'adaptive_slow_start', 'open_circuit', 'unknown'}
BUDGET_EFFECTS = {'automatic_retry_allowed', 'automatic_retry_blocked', 'manual_review_required', 'observe_only', 'unknown'}
REMAINING_CLASSES = {'positive', 'low', 'zero', 'hidden', 'unknown'}
BUDGET_NON_IMPLICATIONS = {
    'not-capacity-reservation', 'not-route-authority', 'not-readiness', 'not-serving',
    'not-effect-success', 'not-admission', 'not-global-quota',
}

ATTEMPT_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'attempt_id', 'attempt_group_ref',
    'attempt_ordinal', 'attempt_state', 'original_ref', 'canonical_intent_digest',
    'safety_basis', 'commit_boundary', 'duplicate_risk', 'observed_at_ms',
    'basis_refs', 'non_implications',
}
ATTEMPT_OPTIONAL = {
    'idempotency_key_ref', 'effect_key_ref', 'advice_ref', 'budget_ref', 'route_ref',
    'live_channel_ref', 'demand_ref', 'custody_ref', 'work_disposition_ref', 'effect_ref',
    'early_data_state', 'winner_ref', 'expires_or_recheck_by_ms', 'unknown_reason',
}
ATTEMPT_ALLOWED = ATTEMPT_REQUIRED | ATTEMPT_OPTIONAL
ATTEMPT_STATES = {
    'fresh_attempt', 'transparent_retry', 'safe_retry', 'idempotent_replay',
    'same_key_mismatch', 'pushback_delayed', 'budget_exhausted', 'hedged',
    'hedge_winner_known', 'maybe_applied', 'early_data_replay_risk',
    'manual_review_required', 'retry_abandoned', 'retry_unknown',
}
SAFETY_BASES = {
    'safe_method', 'idempotency_key_match', 'effect_key_match', 'transport_not_seen',
    'commit_boundary_not_crossed', 'retry_after_handshake', 'explicit_operator_review',
    'hedge_only', 'unsafe', 'unknown',
}
COMMIT_BOUNDARIES = {
    'not_sent', 'transport_not_seen', 'application_not_seen', 'sent_unknown',
    'response_headers_seen', 'partial_response_seen', 'request_body_overflow',
    'external_effect_possible', 'external_effect_confirmed', 'unknown',
}
DUPLICATE_RISKS = {'none', 'duplicate_possible', 'duplicate_known', 'mismatch_rejected', 'unknown'}
EARLY_DATA_STATES = {'none', 'sent_early_data', 'rejected_425', 'replayed_after_handshake', 'unsafe_early_replay', 'unknown'}
ATTEMPT_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-route-authority', 'not-custody',
    'not-work-completion', 'not-effect-success', 'not-exactly-once', 'not-no-duplicate',
}

HEDGE_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'hedge_group_ref', 'group_state',
    'canonical_intent_digest', 'settlement_state', 'observed_at_ms', 'basis_refs',
    'attempt_refs', 'loser_fates', 'non_implications',
}
HEDGE_OPTIONAL = {'winner_attempt_ref', 'accepted_response_ref', 'effect_ref', 'expires_or_recheck_by_ms', 'unknown_reason'}
HEDGE_ALLOWED = HEDGE_REQUIRED | HEDGE_OPTIONAL
HEDGE_STATES = {'speculative', 'winner_known', 'all_failed', 'canceled', 'abandoned', 'unknown'}
SETTLEMENT_STATES = {'no_winner_yet', 'winner_response_accepted', 'all_resolved', 'loser_cleanup_pending', 'duplicate_possible', 'unknown'}
LOSER_REQUIRED = {'attempt_ref', 'fate', 'duplicate_risk'}
LOSER_OPTIONAL = {'cleanup_ref', 'unknown_reason'}
LOSER_ALLOWED = LOSER_REQUIRED | LOSER_OPTIONAL
LOSER_FATES = {'canceled', 'reset', 'ignored_after_winner', 'completed_late', 'still_in_flight', 'duplicate_effect_possible', 'unknown'}
HEDGE_NON_IMPLICATIONS = {
    'not-effect-success', 'not-no-side-effect', 'not-exactly-once', 'not-route-authority',
    'not-readiness', 'not-work-completion', 'not-custody',
}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered or 'http://' in lowered or 'https://' in lowered:
        fail(f'{path}: raw bearer or endpoint-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=16))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_observation_window(obj: dict[str, Any], path: str) -> None:
    require_int(obj['observed_at_ms'], f'{path}.observed_at_ms', maximum=9_223_372_036_854_775_807)
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], f'{path}.expires_or_recheck_by_ms', maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail(f'{path}.expires_or_recheck_by_ms: precedes observed_at_ms')


def require_optional_ref(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], REF_RE, f'{path}.{field}')


def require_optional_group(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], GROUP_RE, f'{path}.{field}')


def require_optional_advice(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], ADVICE_RE, f'{path}.{field}')


def require_optional_budget(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], BUDGET_RE, f'{path}.{field}')


def require_optional_attempt(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], ATTEMPT_RE, f'{path}.{field}')


def validate_retry_advice(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, ADVICE_ALLOWED, ADVICE_REQUIRED, '$')
    if obj['schema'] != 'ST-RETRYADVICE v0':
        fail('$.schema: expected ST-RETRYADVICE v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['advice_id'], ADVICE_RE, '$.advice_id')
    if obj['advice_state'] not in ADVICE_STATES:
        fail('$.advice_state: invalid')
    if obj['reason'] not in ADVICE_REASONS:
        fail('$.reason: invalid')
    require_pattern(obj['scope_ref'], REF_RE, '$.scope_ref')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], ADVICE_NON_IMPLICATIONS, '$.non_implications')
    require_optional_group(obj, 'attempt_group_ref', '$')
    require_optional_ref(obj, 'pushback_ref', '$')
    if 'retry_after_source' in obj and obj['retry_after_source'] not in RETRY_AFTER_SOURCES:
        fail('$.retry_after_source: invalid')
    if 'delay_ms' in obj:
        require_int(obj['delay_ms'], '$.delay_ms', minimum=0, maximum=86_400_000)
    if 'not_before_ms' in obj:
        require_int(obj['not_before_ms'], '$.not_before_ms', maximum=9_223_372_036_854_775_807)
        if obj['not_before_ms'] < obj['observed_at_ms']:
            fail('$.not_before_ms: precedes observed_at_ms')
    states_requiring_time = {'not_before', 'cooling_down', 'pushed_back', 'rate_limited'}
    if obj['advice_state'] in states_requiring_time and 'not_before_ms' not in obj:
        fail('$.not_before_ms: timed advice requires earliest follow-up')
    if obj['advice_state'] in {'expired', 'superseded', 'manual_review_required', 'unknown'}:
        if 'unknown_reason' not in obj:
            fail('$.unknown_reason: required for expired/superseded/manual/unknown advice')
        require_text(obj['unknown_reason'], '$.unknown_reason')
    if obj['advice_state'] == 'no_hint' and ('not_before_ms' in obj or 'delay_ms' in obj):
        fail('$.advice_state: no_hint cannot carry timing')
    return obj


def validate_retry_budget(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, BUDGET_ALLOWED, BUDGET_REQUIRED, '$')
    if obj['schema'] != 'ST-RETRYBUDGET v0':
        fail('$.schema: expected ST-RETRYBUDGET v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['budget_id'], BUDGET_RE, '$.budget_id')
    if obj['budget_scope'] not in BUDGET_SCOPES:
        fail('$.budget_scope: invalid')
    if obj['budget_state'] not in BUDGET_STATES:
        fail('$.budget_state: invalid')
    if obj['decision_effect'] not in BUDGET_EFFECTS:
        fail('$.decision_effect: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], BUDGET_NON_IMPLICATIONS, '$.non_implications')
    require_optional_group(obj, 'attempt_group_ref', '$')
    require_optional_ref(obj, 'limit_ref', '$')
    require_optional_advice(obj, 'advice_ref', '$')
    if 'remaining_class' in obj and obj['remaining_class'] not in REMAINING_CLASSES:
        fail('$.remaining_class: invalid')
    if 'next_refill_after_ms' in obj:
        require_int(obj['next_refill_after_ms'], '$.next_refill_after_ms', maximum=9_223_372_036_854_775_807)
        if obj['next_refill_after_ms'] < obj['observed_at_ms']:
            fail('$.next_refill_after_ms: precedes observed_at_ms')
    if obj['budget_state'] in {'exhausted', 'open_circuit', 'disabled'} and obj['decision_effect'] == 'automatic_retry_allowed':
        fail('$.decision_effect: exhausted/open/disabled budget cannot allow automatic retry')
    if obj.get('remaining_class') == 'zero' and obj['decision_effect'] == 'automatic_retry_allowed':
        fail('$.decision_effect: zero remaining class cannot allow automatic retry')
    if obj['budget_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown budget state')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_retry_attempt(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, ATTEMPT_ALLOWED, ATTEMPT_REQUIRED, '$')
    if obj['schema'] != 'ST-RETRYATTEMPT v0':
        fail('$.schema: expected ST-RETRYATTEMPT v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['attempt_id'], ATTEMPT_RE, '$.attempt_id')
    require_pattern(obj['attempt_group_ref'], GROUP_RE, '$.attempt_group_ref')
    require_int(obj['attempt_ordinal'], '$.attempt_ordinal', minimum=0, maximum=1000)
    if obj['attempt_state'] not in ATTEMPT_STATES:
        fail('$.attempt_state: invalid')
    require_pattern(obj['original_ref'], REF_RE, '$.original_ref')
    require_pattern(obj['canonical_intent_digest'], DIGEST_RE, '$.canonical_intent_digest')
    if obj['safety_basis'] not in SAFETY_BASES:
        fail('$.safety_basis: invalid')
    if obj['commit_boundary'] not in COMMIT_BOUNDARIES:
        fail('$.commit_boundary: invalid')
    if obj['duplicate_risk'] not in DUPLICATE_RISKS:
        fail('$.duplicate_risk: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], ATTEMPT_NON_IMPLICATIONS, '$.non_implications')
    for field in ('route_ref', 'live_channel_ref', 'demand_ref', 'custody_ref', 'work_disposition_ref', 'effect_ref'):
        require_optional_ref(obj, field, '$')
    require_optional_advice(obj, 'advice_ref', '$')
    require_optional_budget(obj, 'budget_ref', '$')
    require_optional_attempt(obj, 'winner_ref', '$')
    if 'idempotency_key_ref' in obj:
        require_pattern(obj['idempotency_key_ref'], KEY_RE, '$.idempotency_key_ref')
    if 'effect_key_ref' in obj:
        require_pattern(obj['effect_key_ref'], KEY_RE, '$.effect_key_ref')
    if 'early_data_state' in obj and obj['early_data_state'] not in EARLY_DATA_STATES:
        fail('$.early_data_state: invalid')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')

    if obj['attempt_state'] == 'transparent_retry':
        if obj['safety_basis'] not in {'transport_not_seen', 'commit_boundary_not_crossed'}:
            fail('$.safety_basis: transparent retry requires transport/not-crossed basis')
        if obj['commit_boundary'] not in {'not_sent', 'transport_not_seen', 'application_not_seen'}:
            fail('$.commit_boundary: transparent retry cannot cross application/response boundary')
    if obj['attempt_state'] == 'idempotent_replay' and 'idempotency_key_ref' not in obj and 'effect_key_ref' not in obj:
        fail('$.idempotency_key_ref: idempotent replay requires idempotency or effect key ref')
    if obj['attempt_state'] == 'same_key_mismatch' and obj['duplicate_risk'] != 'mismatch_rejected':
        fail('$.duplicate_risk: same-key mismatch must be visibly rejected')
    if obj['attempt_state'] == 'pushback_delayed' and 'advice_ref' not in obj:
        fail('$.advice_ref: pushback-delayed attempts require retry advice')
    if obj['attempt_state'] == 'budget_exhausted' and 'budget_ref' not in obj:
        fail('$.budget_ref: budget-exhausted attempts require budget witness')
    if obj['commit_boundary'] == 'external_effect_confirmed' and 'effect_ref' not in obj:
        fail('$.effect_ref: external-effect-confirmed requires adjacent effect witness ref')
    if obj['commit_boundary'] == 'external_effect_possible' and obj['safety_basis'] not in {'effect_key_match', 'explicit_operator_review', 'unsafe', 'unknown'}:
        fail('$.safety_basis: possible external effect requires effect key, review, unsafe, or unknown basis')
    if obj.get('early_data_state') == 'unsafe_early_replay':
        fail('$.early_data_state: unsafe early-data replay is not an acceptable attempt witness')
    if obj.get('early_data_state') == 'replayed_after_handshake' and obj['safety_basis'] != 'retry_after_handshake':
        fail('$.safety_basis: post-425 replay requires retry-after-handshake basis')
    if obj['attempt_state'] in {'retry_unknown', 'manual_review_required', 'retry_abandoned'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: ambiguous/manual/abandoned attempts require reason')
    return obj


def validate_loser_fate(value: Any, path: str, attempt_refs: set[str], winner: str | None) -> dict[str, Any]:
    loser = require_object(value, path)
    scan_forbidden_keys(loser, path)
    require_closed_keys(loser, LOSER_ALLOWED, LOSER_REQUIRED, path)
    require_pattern(loser['attempt_ref'], ATTEMPT_RE, f'{path}.attempt_ref')
    if loser['attempt_ref'] not in attempt_refs:
        fail(f'{path}.attempt_ref: not listed in attempt_refs')
    if winner and loser['attempt_ref'] == winner:
        fail(f'{path}.attempt_ref: winner cannot also be a loser')
    if loser['fate'] not in LOSER_FATES:
        fail(f'{path}.fate: invalid')
    if loser['duplicate_risk'] not in DUPLICATE_RISKS:
        fail(f'{path}.duplicate_risk: invalid')
    require_optional_ref(loser, 'cleanup_ref', path)
    if 'unknown_reason' in loser:
        require_text(loser['unknown_reason'], f'{path}.unknown_reason')
    if loser['fate'] in {'canceled', 'reset', 'ignored_after_winner'} and loser['duplicate_risk'] == 'none' and 'cleanup_ref' not in loser:
        fail(f'{path}.duplicate_risk: cancellation/reset/ignore alone cannot prove no duplicate side effect')
    if loser['fate'] in {'still_in_flight', 'unknown'} and 'unknown_reason' not in loser:
        fail(f'{path}.unknown_reason: required for in-flight/unknown loser fate')
    return loser


def validate_hedge_fate(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, HEDGE_ALLOWED, HEDGE_REQUIRED, '$')
    if obj['schema'] != 'ST-HEDGEFATE v0':
        fail('$.schema: expected ST-HEDGEFATE v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['hedge_group_ref'], HEDGE_RE, '$.hedge_group_ref')
    if obj['group_state'] not in HEDGE_STATES:
        fail('$.group_state: invalid')
    require_pattern(obj['canonical_intent_digest'], DIGEST_RE, '$.canonical_intent_digest')
    if obj['settlement_state'] not in SETTLEMENT_STATES:
        fail('$.settlement_state: invalid')
    validate_observation_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    require_non_implications(obj['non_implications'], HEDGE_NON_IMPLICATIONS, '$.non_implications')
    attempt_refs = set(require_string_list(obj['attempt_refs'], '$.attempt_refs', regex=ATTEMPT_RE, maximum=16))
    if len(attempt_refs) < 2:
        fail('$.attempt_refs: hedge settlement requires at least two attempts')
    winner = obj.get('winner_attempt_ref')
    if winner is not None:
        require_pattern(winner, ATTEMPT_RE, '$.winner_attempt_ref')
        if winner not in attempt_refs:
            fail('$.winner_attempt_ref: not listed in attempt_refs')
    require_optional_ref(obj, 'accepted_response_ref', '$')
    require_optional_ref(obj, 'effect_ref', '$')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    if obj['group_state'] == 'winner_known':
        if not winner or 'accepted_response_ref' not in obj:
            fail('$.winner_attempt_ref: winner-known hedge requires winner and accepted response refs')
        if obj['settlement_state'] not in {'winner_response_accepted', 'loser_cleanup_pending', 'duplicate_possible', 'all_resolved'}:
            fail('$.settlement_state: invalid for winner-known hedge')
    losers = obj['loser_fates']
    if not isinstance(losers, list):
        fail('$.loser_fates: expected list')
    if len(losers) > len(attempt_refs):
        fail('$.loser_fates: too many loser entries')
    seen_losers: set[str] = set()
    for idx, loser in enumerate(losers):
        parsed = validate_loser_fate(loser, f'$.loser_fates[{idx}]', attempt_refs, winner)
        if parsed['attempt_ref'] in seen_losers:
            fail(f'$.loser_fates[{idx}]: duplicate loser attempt')
        seen_losers.add(parsed['attempt_ref'])
    if winner and attempt_refs - {winner} - seen_losers:
        fail('$.loser_fates: every non-winning attempt needs a fate')
    if obj['settlement_state'] == 'all_resolved':
        for loser in losers:
            if loser['fate'] in {'still_in_flight', 'unknown'} or loser['duplicate_risk'] in {'duplicate_possible', 'unknown'}:
                fail('$.settlement_state: all_resolved cannot hide in-flight/unknown/duplicate-possible losers')
    return obj


def base_issuer(kind: str = 'steward', ident: str = 'steward.local') -> dict[str, Any]:
    return {'kind': kind, 'id': ident}


def non_implications(kind: str) -> list[str]:
    mapping = {
        'advice': sorted(ADVICE_NON_IMPLICATIONS),
        'budget': sorted(BUDGET_NON_IMPLICATIONS),
        'attempt': sorted(ATTEMPT_NON_IMPLICATIONS),
        'hedge': sorted(HEDGE_NON_IMPLICATIONS),
    }
    return mapping[kind]


def intent_digest(name: str = 'payment-10') -> str:
    return digest({'method': 'POST', 'path': 'route/payments', 'body_digest': digest({'intent': name})})


def base_advice() -> dict[str, Any]:
    return {
        'schema': 'ST-RETRYADVICE v0',
        'witness_id': 'wit_aaaaaaaaaaaaaaaa',
        'cid': 'demo.web',
        'issuer': base_issuer('proxy', 'edge.proxy'),
        'advice_id': 'radv_aaaaaaaaaaaaaaaa',
        'advice_state': 'pushed_back',
        'reason': 'overload',
        'scope_ref': 'route/public',
        'attempt_group_ref': 'rgrp_aaaaaaaaaaaaaaaa',
        'retry_after_source': 'http_retry_after_delta',
        'not_before_ms': 1_000_500,
        'delay_ms': 500,
        'observed_at_ms': 1_000_000,
        'expires_or_recheck_by_ms': 1_001_000,
        'basis_refs': ['resp/503'],
        'non_implications': non_implications('advice'),
    }


def base_budget() -> dict[str, Any]:
    return {
        'schema': 'ST-RETRYBUDGET v0',
        'witness_id': 'wit_bbbbbbbbbbbbbbbb',
        'cid': 'demo.web',
        'issuer': base_issuer('library', 'client.lib'),
        'budget_id': 'rbud_bbbbbbbbbbbbbbbb',
        'budget_scope': 'client',
        'budget_state': 'constrained',
        'decision_effect': 'automatic_retry_allowed',
        'attempt_group_ref': 'rgrp_aaaaaaaaaaaaaaaa',
        'remaining_class': 'low',
        'limit_ref': 'budget/client-low',
        'advice_ref': 'radv_aaaaaaaaaaaaaaaa',
        'observed_at_ms': 1_000_100,
        'expires_or_recheck_by_ms': 1_001_000,
        'basis_refs': ['budget/local'],
        'non_implications': non_implications('budget'),
    }


def base_attempt(attempt_id: str = 'att_aaaaaaaaaaaaaaaa', ordinal: int = 0, state: str = 'fresh_attempt') -> dict[str, Any]:
    return {
        'schema': 'ST-RETRYATTEMPT v0',
        'witness_id': 'wit_cccccccccccccccc',
        'cid': 'demo.web',
        'issuer': base_issuer('client', 'app.client'),
        'attempt_id': attempt_id,
        'attempt_group_ref': 'rgrp_aaaaaaaaaaaaaaaa',
        'attempt_ordinal': ordinal,
        'attempt_state': state,
        'original_ref': 'demand/payments/1',
        'canonical_intent_digest': intent_digest(),
        'safety_basis': 'safe_method' if state == 'fresh_attempt' else 'idempotency_key_match',
        'commit_boundary': 'not_sent' if state == 'fresh_attempt' else 'sent_unknown',
        'duplicate_risk': 'none' if state == 'fresh_attempt' else 'duplicate_possible',
        'idempotency_key_ref': 'idem_aaaaaaaaaaaaaaaa',
        'route_ref': 'route/public',
        'observed_at_ms': 1_000_200 + ordinal,
        'basis_refs': ['req/canonical'],
        'non_implications': non_implications('attempt'),
    }


def base_hedge() -> dict[str, Any]:
    return {
        'schema': 'ST-HEDGEFATE v0',
        'witness_id': 'wit_dddddddddddddddd',
        'cid': 'demo.web',
        'issuer': base_issuer('library', 'client.lib'),
        'hedge_group_ref': 'hedg_aaaaaaaaaaaaaaaa',
        'group_state': 'winner_known',
        'canonical_intent_digest': intent_digest(),
        'settlement_state': 'loser_cleanup_pending',
        'winner_attempt_ref': 'att_aaaaaaaaaaaaaaaa',
        'accepted_response_ref': 'resp/primary',
        'observed_at_ms': 1_000_400,
        'basis_refs': ['hedge/group'],
        'attempt_refs': ['att_aaaaaaaaaaaaaaaa', 'att_bbbbbbbbbbbbbbbb'],
        'loser_fates': [
            {'attempt_ref': 'att_bbbbbbbbbbbbbbbb', 'fate': 'canceled', 'duplicate_risk': 'duplicate_possible', 'cleanup_ref': 'cancel/sent'}
        ],
        'non_implications': non_implications('hedge'),
    }


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'retry_flow', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    advice = base_advice()
    budget = base_budget()
    attempt0 = base_attempt()
    attempt1 = base_attempt('att_bbbbbbbbbbbbbbbb', 1, 'idempotent_replay')
    attempt1['advice_ref'] = advice['advice_id']
    attempt1['budget_ref'] = budget['budget_id']
    attempt1['commit_boundary'] = 'sent_unknown'
    attempt1['duplicate_risk'] = 'duplicate_possible'
    transparent = base_attempt('att_cccccccccccccccc', 1, 'transparent_retry')
    transparent['safety_basis'] = 'transport_not_seen'
    transparent['commit_boundary'] = 'transport_not_seen'
    transparent['duplicate_risk'] = 'none'
    pushed = base_attempt('att_dddddddddddddddd', 1, 'pushback_delayed')
    pushed['advice_ref'] = advice['advice_id']
    pushed['budget_ref'] = budget['budget_id']
    pushed['safety_basis'] = 'idempotency_key_match'
    pushed['commit_boundary'] = 'sent_unknown'
    pushed['duplicate_risk'] = 'duplicate_possible'
    exhausted_attempt = base_attempt('att_eeeeeeeeeeeeeeee', 2, 'budget_exhausted')
    exhausted_attempt['budget_ref'] = 'rbud_bbbbbbbbbbbbbbbb'
    exhausted_attempt['safety_basis'] = 'unknown'
    exhausted_attempt['commit_boundary'] = 'unknown'
    exhausted_attempt['duplicate_risk'] = 'unknown'
    exhausted_attempt['unknown_reason'] = 'Retry budget is exhausted for this client scope'
    post425 = base_attempt('att_ffffffffffffffff', 1, 'safe_retry')
    post425['safety_basis'] = 'retry_after_handshake'
    post425['commit_boundary'] = 'not_sent'
    post425['duplicate_risk'] = 'none'
    post425['early_data_state'] = 'replayed_after_handshake'
    hedge = base_hedge()

    exhausted_budget = {**budget, 'budget_state': 'exhausted', 'decision_effect': 'automatic_retry_blocked', 'remaining_class': 'zero', 'next_refill_after_ms': 1_001_000}
    unknown_budget = {**budget, 'budget_id': 'rbud_cccccccccccccccc', 'budget_state': 'unknown', 'decision_effect': 'unknown', 'remaining_class': 'unknown', 'unknown_reason': 'Local retry quota could not be read after reconnect'}

    bad_intent_attempt = base_attempt('att_bbbbbbbbbbbbbbbb', 1, 'idempotent_replay')
    bad_intent_attempt['canonical_intent_digest'] = intent_digest('payment-999')
    bad_intent_attempt['commit_boundary'] = 'sent_unknown'
    bad_intent_attempt['duplicate_risk'] = 'duplicate_possible'

    early_first = base_attempt('att_1111111111111111', 0, 'early_data_replay_risk')
    early_first['safety_basis'] = 'unknown'
    early_first['commit_boundary'] = 'sent_unknown'
    early_first['duplicate_risk'] = 'duplicate_possible'
    early_first['early_data_state'] = 'sent_early_data'
    early_first['unknown_reason'] = 'Initial attempt used early data and response rejected replay risk'
    early_second_bad = base_attempt('att_2222222222222222', 1, 'safe_retry')
    early_second_bad['safety_basis'] = 'retry_after_handshake'
    early_second_bad['commit_boundary'] = 'not_sent'
    early_second_bad['duplicate_risk'] = 'none'
    early_second_bad['early_data_state'] = 'sent_early_data'

    committed_without_effect = base_attempt('att_3333333333333333', 2, 'maybe_applied')
    committed_without_effect['safety_basis'] = 'unknown'
    committed_without_effect['commit_boundary'] = 'external_effect_confirmed'
    committed_without_effect['duplicate_risk'] = 'duplicate_known'
    committed_without_effect['unknown_reason'] = 'Application reported effect but no effect witness was available'

    cases: list[dict[str, Any]] = [
        schema_case('retryadvice.accept.pushed-back', 'ST-RETRYADVICE', advice, 'accept', 'retry advice carries not-before timing as advice only'),
        schema_case('retryadvice.reject.reservation-claim', 'ST-RETRYADVICE', {**advice, 'claims_reservation': True}, 'reject', 'retry advice is not a capacity reservation or grant'),
        schema_case('retryadvice.reject.not-before-in-past', 'ST-RETRYADVICE', {**advice, 'not_before_ms': 999_999}, 'reject', 'not-before cannot precede observation time'),
        schema_case('retryadvice.reject.no-hint-with-delay', 'ST-RETRYADVICE', {**advice, 'advice_state': 'no_hint', 'delay_ms': 10, 'not_before_ms': 1_000_010}, 'reject', 'missing advice cannot secretly mean retry later'),
        schema_case('retryadvice.reject.duplicate-json-key', 'ST-RETRYADVICE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-RETRYADVICE v0","schema":"ST-RETRYADVICE v0","witness_id":"wit_aaaaaaaaaaaaaaaa","cid":"demo.web","issuer":{"kind":"proxy","id":"edge.proxy"},"advice_id":"radv_aaaaaaaaaaaaaaaa","advice_state":"no_hint","reason":"unknown","scope_ref":"route/public","observed_at_ms":1,"basis_refs":[],"non_implications":[]}'),

        schema_case('retrybudget.accept.constrained', 'ST-RETRYBUDGET', budget, 'accept', 'retry budget may allow an automatic retry while still refusing capacity truth'),
        schema_case('retrybudget.accept.exhausted-blocks', 'ST-RETRYBUDGET', exhausted_budget, 'accept', 'exhausted budget can block automatic retry without settling work or effects'),
        schema_case('retrybudget.accept.unknown-downgrade', 'ST-RETRYBUDGET', unknown_budget, 'accept', 'budget observations can degrade to unknown after local state loss'),
        schema_case('retrybudget.reject.zero-allows-retry', 'ST-RETRYBUDGET', {**budget, 'remaining_class': 'zero'}, 'reject', 'zero remaining class cannot allow automatic retry'),
        schema_case('retrybudget.reject.route-authority-claim', 'ST-RETRYBUDGET', {**budget, 'claims_route_current': True}, 'reject', 'retry budget is not route authority or admission'),

        schema_case('retryattempt.accept.fresh', 'ST-RETRYATTEMPT', attempt0, 'accept', 'first attempt can be represented inside a group without being a retry claim'),
        schema_case('retryattempt.accept.transparent', 'ST-RETRYATTEMPT', transparent, 'accept', 'transparent retry requires not-seen/not-crossed commitment evidence'),
        schema_case('retryattempt.accept.idempotent-replay', 'ST-RETRYATTEMPT', attempt1, 'accept', 'same canonical intent under a reviewed key may be replayed without exactly-once claims'),
        schema_case('retryattempt.accept.pushback-delayed', 'ST-RETRYATTEMPT', pushed, 'accept', 'attempt may be delayed by advice and budget witnesses'),
        schema_case('retryattempt.accept.budget-exhausted', 'ST-RETRYATTEMPT', exhausted_attempt, 'accept', 'attempt may stop because a retry budget blocks automation'),
        schema_case('retryattempt.accept.post-425-handshake', 'ST-RETRYATTEMPT', post425, 'accept', '425 retry can be represented only as replay after handshake, not early data again'),
        schema_case('retryattempt.reject.effect-confirmed-without-effect-ref', 'ST-RETRYATTEMPT', committed_without_effect, 'reject', 'confirmed external effect requires an adjacent effect witness ref'),
        schema_case('retryattempt.reject.transparent-after-headers', 'ST-RETRYATTEMPT', {**transparent, 'commit_boundary': 'response_headers_seen'}, 'reject', 'transparent retry cannot cross response/application commitment boundary'),
        schema_case('retryattempt.reject.pushback-without-advice', 'ST-RETRYATTEMPT', {k: v for k, v in pushed.items() if k != 'advice_ref'}, 'reject', 'pushback delayed state requires explicit advice witness'),
        schema_case('retryattempt.reject.unsafe-early-replay', 'ST-RETRYATTEMPT', {**post425, 'early_data_state': 'unsafe_early_replay'}, 'reject', 'unsafe early-data replay is never accepted as settled retry truth'),
        schema_case('retryattempt.reject.exactly-once-claim', 'ST-RETRYATTEMPT', {**attempt1, 'claims_exactly_once': True}, 'reject', 'attempt witnesses cannot claim exactly-once outcome'),

        schema_case('hedgefate.accept.winner-known', 'ST-HEDGEFATE', hedge, 'accept', 'hedge can accept one response while retaining loser duplicate ambiguity'),
        schema_case('hedgefate.reject.loser-no-side-effect-by-cancel', 'ST-HEDGEFATE', {**hedge, 'loser_fates': [{'attempt_ref': 'att_bbbbbbbbbbbbbbbb', 'fate': 'canceled', 'duplicate_risk': 'none'}]}, 'reject', 'canceling a losing hedge does not prove no side effect'),
        schema_case('hedgefate.reject.winner-also-loser', 'ST-HEDGEFATE', {**hedge, 'loser_fates': [{'attempt_ref': 'att_aaaaaaaaaaaaaaaa', 'fate': 'completed_late', 'duplicate_risk': 'duplicate_possible'}]}, 'reject', 'winner cannot also be listed as a losing attempt'),
        schema_case('hedgefate.reject.all-resolved-hides-unknown', 'ST-HEDGEFATE', {**hedge, 'settlement_state': 'all_resolved', 'loser_fates': [{'attempt_ref': 'att_bbbbbbbbbbbbbbbb', 'fate': 'still_in_flight', 'duplicate_risk': 'unknown', 'unknown_reason': 'No reset acknowledgement yet'}]}, 'reject', 'all-resolved cannot hide in-flight or unknown loser fate'),

        flow_case('retryflow.accept.advice-budget-idempotent-replay', [
            {'event': 'retry_advice', 'packet': advice},
            {'event': 'retry_budget', 'packet': budget},
            {'event': 'retry_attempt', 'packet': attempt0},
            {'event': 'retry_attempt', 'packet': attempt1},
        ], 'accept', 'same idempotency key and same canonical intent may replay with explicit advice/budget refs'),
        flow_case('retryflow.reject.same-key-different-intent', [
            {'event': 'retry_attempt', 'packet': attempt0},
            {'event': 'retry_attempt', 'packet': bad_intent_attempt},
        ], 'reject', 'same idempotency key with different canonical intent must reject instead of mutating old operation'),
        flow_case('retryflow.accept.early-data-425-retry-after-handshake', [
            {'event': 'retry_attempt', 'packet': early_first},
            {'event': 'early_data_425', 'attempt_group_ref': 'rgrp_aaaaaaaaaaaaaaaa'},
            {'event': 'retry_attempt', 'packet': post425},
        ], 'accept', '425 early-data path retries after handshake rather than in early data'),
        flow_case('retryflow.reject.early-data-retry-in-early-data-again', [
            {'event': 'retry_attempt', 'packet': early_first},
            {'event': 'early_data_425', 'attempt_group_ref': 'rgrp_aaaaaaaaaaaaaaaa'},
            {'event': 'retry_attempt', 'packet': early_second_bad},
        ], 'reject', 'after a 425 replay-risk response the retry must not be sent in early data again'),
        flow_case('retryflow.accept.hedge-winner-with-loser-ambiguity', [
            {'event': 'retry_attempt', 'packet': attempt0},
            {'event': 'retry_attempt', 'packet': {k: v for k, v in {**attempt1, 'attempt_state': 'hedged', 'safety_basis': 'hedge_only'}.items() if k not in {'advice_ref', 'budget_ref'}}},
            {'event': 'hedge_fate', 'packet': hedge},
        ], 'accept', 'hedge winner can be known while loser fate remains duplicate-possible'),
        flow_case('retryflow.reject.hedge-fate-before-attempts', [
            {'event': 'hedge_fate', 'packet': hedge},
        ], 'reject', 'hedge settlement cannot reference attempts not known to the flow'),
        flow_case('retryflow.reject.budget-unknown-as-allowed', [
            {'event': 'retry_budget', 'packet': unknown_budget},
            {'event': 'retry_attempt', 'packet': {**attempt1, 'budget_ref': unknown_budget['budget_id']}},
        ], 'reject', 'unknown budget state cannot be used as proof that automation was allowed'),
    ]
    return cases


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        if 'json_text' in case:
            obj = parse_json_text(case['json_text'])
        else:
            obj = case['json']
        object_kind = case['object_kind']
        if object_kind == 'ST-RETRYADVICE':
            validate_retry_advice(obj)
        elif object_kind == 'ST-RETRYBUDGET':
            validate_retry_budget(obj)
        elif object_kind == 'ST-RETRYATTEMPT':
            validate_retry_attempt(obj)
        elif object_kind == 'ST-HEDGEFATE':
            validate_hedge_fate(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        advices: dict[str, dict[str, Any]] = {}
        budgets: dict[str, dict[str, Any]] = {}
        attempts: dict[str, dict[str, Any]] = {}
        intent_by_key: dict[str, str] = {}
        early_425_groups: set[str] = set()
        effects: set[str] = set()
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'effect_boundary':
                ref = ev.get('effect_ref')
                require_pattern(ref, REF_RE, f'{where}.effect_ref')
                effects.add(ref)
            elif kind == 'retry_advice':
                packet = validate_retry_advice(ev['packet'])
                advices[packet['advice_id']] = packet
            elif kind == 'retry_budget':
                packet = validate_retry_budget(ev['packet'])
                budgets[packet['budget_id']] = packet
            elif kind == 'retry_attempt':
                packet = validate_retry_attempt(ev['packet'])
                if packet.get('advice_ref') and packet['advice_ref'] not in advices:
                    fail(f'{where}: attempt references unknown retry advice')
                if packet.get('budget_ref'):
                    budget = budgets.get(packet['budget_ref'])
                    if not budget:
                        fail(f'{where}: attempt references unknown retry budget')
                    if budget['decision_effect'] != 'automatic_retry_allowed' and packet['attempt_state'] not in {'budget_exhausted', 'manual_review_required', 'retry_abandoned'}:
                        fail(f'{where}: budget state does not allow automatic retry')
                if packet.get('effect_ref') and packet['effect_ref'] not in effects:
                    fail(f'{where}: attempt references unknown effect boundary')
                key = packet.get('idempotency_key_ref') or packet.get('effect_key_ref')
                if key:
                    intent = packet['canonical_intent_digest']
                    if key in intent_by_key and intent_by_key[key] != intent:
                        fail(f'{where}: same key different canonical intent')
                    intent_by_key[key] = intent
                if packet['attempt_group_ref'] in early_425_groups and packet.get('early_data_state') == 'sent_early_data':
                    fail(f'{where}: retry after 425 sent in early data again')
                attempts[packet['attempt_id']] = packet
            elif kind == 'early_data_425':
                require_pattern(ev.get('attempt_group_ref'), GROUP_RE, f'{where}.attempt_group_ref')
                early_425_groups.add(ev['attempt_group_ref'])
            elif kind == 'hedge_fate':
                packet = validate_hedge_fate(ev['packet'])
                for attempt_ref in packet['attempt_refs']:
                    if attempt_ref not in attempts:
                        fail(f'{where}: hedge references unknown attempt {attempt_ref}')
                canonical = {attempts[attempt_ref]['canonical_intent_digest'] for attempt_ref in packet['attempt_refs']}
                if len(canonical) != 1 or packet['canonical_intent_digest'] not in canonical:
                    fail(f'{where}: hedge intent mismatch across attempts')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'retry_flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-retry-settlement-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-retry-settlement-corpus] FAIL: corpus is stale; run tools/steward_retry_settlement_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-retry-settlement-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
