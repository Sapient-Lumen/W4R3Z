#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/import-reconciliation-corpus-v0.jsonl'

ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
IMPORT_RE = re.compile(r'^imp_[a-z0-9]{16}$')
APPRAISAL_RE = re.compile(r'^app_[a-z0-9]{16}$')
PLAN_RE = re.compile(r'^rcp_[a-z0-9]{16}$')
DECISION_RE = re.compile(r'^rcd_[a-z0-9]{16}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_current', 'claims_fresh', 'claims_live',
    'claims_readiness', 'claims_serving', 'claims_effect_success', 'claims_execution',
    'claims_global_trust', 'claims_policy', 'claims_secret_free', 'global_trust',
    'current_state', 'live_authority', 'authority', 'ready', 'serving', 'fresh',
    'effect_success', 'execution', 'raw', 'raw_value', 'raw_body', 'raw_packet',
    'raw_handle', 'token', 'secret', 'bearer', 'credential', 'password', 'cookie',
    'authorization', 'value', 'path', 'raw_path', 'host_path', 'endpoint', 'raw_endpoint',
    'url', 'uri', 'fd', 'descriptor_number', 'pid', 'ppid', 'pgid', 'cgroup',
    'systemd_unit', 'pod_name', 'container_id', 'pane_text', 'pty_name', 'shell_job',
}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}
ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'importer', 'verifier', 'reconciler', 'policy'}

IMPORT_REQUIRED = COMMON_REQUIRED | {
    'import_id', 'source_kind', 'source_ref', 'source_export_digest', 'source_replay_ref',
    'imported_receipt_digests', 'import_state', 'redaction_state', 'gap_state',
    'quarantine_state', 'import_manifest_digest',
}
IMPORT_OPTIONAL = COMMON_OPTIONAL | {'source_claimed_revision', 'missing_reason', 'expires_or_recheck_by_ms'}
IMPORT_ALLOWED = IMPORT_REQUIRED | IMPORT_OPTIONAL
SOURCE_KINDS = {'export_bundle', 'sibling_cube', 'manager_recovery', 'operator_upload', 'adapter_dump', 'audit_archive'}
IMPORT_STATES = {'observed', 'parsed', 'quarantined', 'rejected', 'accepted_as_evidence', 'unknown'}
REDACTION_STATES = {'known_minimized', 'unknown', 'missing', 'failed', 'not_applicable'}
GAP_STATES = {'none', 'missing_receipts', 'digest_mismatch', 'redaction_loss', 'unknown'}
QUARANTINE_STATES = {'pending', 'required', 'released_for_weak_evidence', 'rejected'}
IMPORT_NON_IMPLICATIONS = {'not-authority', 'not-current-state', 'not-freshness', 'not-live-state', 'not-effect-success', 'not-global-trust'}

APPRAISAL_REQUIRED = COMMON_REQUIRED | {
    'appraisal_id', 'import_ref', 'source_kind', 'subject_ref', 'appraisal_state',
    'trust_scope', 'usable_for', 'caveats', 'expires_at_ms',
}
APPRAISAL_OPTIONAL = COMMON_OPTIONAL | {'downgrade_reason', 'source_export_digest'}
APPRAISAL_ALLOWED = APPRAISAL_REQUIRED | APPRAISAL_OPTIONAL
APPRAISAL_STATES = {'allow_weak_evidence', 'quarantine', 'reject', 'stale', 'unknown'}
TRUST_SCOPES = {'this_import_only', 'component_history_only', 'recovery_hint_only', 'sibling_review_only'}
USABLE_FOR = {'history', 'audit', 'explanation', 'recovery_hint', 'operator_review'}
APPRAISAL_NON_IMPLICATIONS = {'not-global-trust', 'not-authority', 'not-current-state', 'not-freshness', 'not-effect-success', 'not-policy'}

PLAN_REQUIRED = COMMON_REQUIRED | {
    'plan_id', 'import_ref', 'appraisal_ref', 'local_subject_ref', 'imported_subject_ref',
    'mapping_state', 'candidate_actions', 'downgrade_class', 'required_local_witnesses',
    'gap_state',
}
PLAN_OPTIONAL = COMMON_OPTIONAL | {'conflict_refs', 'plan_expires_at_ms', 'downgrade_reason'}
PLAN_ALLOWED = PLAN_REQUIRED | PLAN_OPTIONAL
MAPPING_STATES = {'proposed', 'blocked', 'conflict', 'no_match', 'abandoned', 'ready_for_review'}
CANDIDATE_ACTIONS = {'adopt_as_history', 'attach_as_basis', 'request_recheck', 'ask_operator', 'discard_import', 'quarantine'}
DOWNGRADE_CLASSES = {'history_only', 'weak_basis', 'requires_recheck', 'human_review', 'reject'}
PLAN_NON_IMPLICATIONS = {'not-execution', 'not-authority', 'not-current-state', 'not-freshness', 'not-effect-success'}

DECISION_REQUIRED = COMMON_REQUIRED | {
    'decision_id', 'plan_ref', 'decision_state', 'adopted_scope', 'decision_reason',
    'required_local_witnesses', 'resulting_refs',
}
DECISION_OPTIONAL = COMMON_OPTIONAL | {'authority_basis_ref', 'expires_or_recheck_by_ms', 'rejected_reason'}
DECISION_ALLOWED = DECISION_REQUIRED | DECISION_OPTIONAL
DECISION_STATES = {'adopted_as_history', 'attached_as_weak_basis', 'rejected', 'needs_local_recheck', 'quarantined', 'unknown'}
ADOPTED_SCOPES = {'none', 'history', 'explanation', 'audit', 'recovery_hint', 'weak_basis'}
DECISION_NON_IMPLICATIONS = {'not-execution', 'not-authority', 'not-current-state', 'not-freshness', 'not-effect-success', 'not-readiness', 'not-serving'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = ['token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:', '/var/', '/proc/', '/tmp/', 'current state proof']
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or currentness flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    return items


def require_digest_list(value: Any, path: str, *, maximum: int = 32, allow_empty: bool = False, sorted_required: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=DIGEST_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    if sorted_required and items != sorted(items):
        fail(f'{path}: digest list must be lexicographically sorted for stable import binding')
    return items


def require_text_list(value: Any, path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_text(item, f'{path}[{idx}]')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_enum_list(value: Any, enum: set[str], path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    bad = sorted(set(items) - enum)
    if bad:
        fail(f'{path}: invalid entries {bad}')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_import(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, IMPORT_ALLOWED, IMPORT_REQUIRED, 'ST-IMPORT v0')
    require_pattern(obj['import_id'], IMPORT_RE, '$.import_id')
    if obj['source_kind'] not in SOURCE_KINDS:
        fail('$.source_kind: invalid')
    require_pattern(obj['source_ref'], REF_RE, '$.source_ref')
    require_pattern(obj['source_export_digest'], DIGEST_RE, '$.source_export_digest')
    require_pattern(obj['source_replay_ref'], REF_RE, '$.source_replay_ref')
    require_digest_list(obj['imported_receipt_digests'], '$.imported_receipt_digests', maximum=64, sorted_required=True)
    if obj['import_state'] not in IMPORT_STATES:
        fail('$.import_state: invalid')
    if obj['redaction_state'] not in REDACTION_STATES:
        fail('$.redaction_state: invalid')
    if obj['gap_state'] not in GAP_STATES:
        fail('$.gap_state: invalid')
    if obj['quarantine_state'] not in QUARANTINE_STATES:
        fail('$.quarantine_state: invalid')
    require_pattern(obj['import_manifest_digest'], DIGEST_RE, '$.import_manifest_digest')
    if 'source_claimed_revision' in obj:
        require_pattern(obj['source_claimed_revision'], REF_RE, '$.source_claimed_revision')
    if 'missing_reason' in obj:
        require_text(obj['missing_reason'], '$.missing_reason')
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail('$.expires_or_recheck_by_ms: cannot precede observed_at_ms')
    if obj['import_state'] == 'accepted_as_evidence':
        if obj['redaction_state'] != 'known_minimized':
            fail('$.redaction_state: accepted evidence requires known minimized redaction')
        if obj['gap_state'] != 'none':
            fail('$.gap_state: accepted evidence cannot carry unresolved gaps')
        if obj['quarantine_state'] != 'released_for_weak_evidence':
            fail('$.quarantine_state: accepted evidence only releases weak evidence')
    if obj['gap_state'] != 'none' and 'missing_reason' not in obj:
        fail('$.missing_reason: non-none gap state must explain downgrade')
    require_non_implications(obj['non_implications'], IMPORT_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_appraisal(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, APPRAISAL_ALLOWED, APPRAISAL_REQUIRED, 'ST-SRCAPPRAISE v0')
    require_pattern(obj['appraisal_id'], APPRAISAL_RE, '$.appraisal_id')
    require_pattern(obj['import_ref'], IMPORT_RE, '$.import_ref')
    if obj['source_kind'] not in SOURCE_KINDS:
        fail('$.source_kind: invalid')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    if obj['appraisal_state'] not in APPRAISAL_STATES:
        fail('$.appraisal_state: invalid')
    if obj['trust_scope'] not in TRUST_SCOPES:
        fail('$.trust_scope: invalid')
    usable_for = require_enum_list(obj['usable_for'], USABLE_FOR, '$.usable_for', maximum=8, allow_empty=(obj['appraisal_state'] != 'allow_weak_evidence'))
    require_text_list(obj['caveats'], '$.caveats', maximum=8)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['expires_at_ms'] <= obj['observed_at_ms']:
        fail('$.expires_at_ms: appraisal expires before or at observation time')
    if obj['appraisal_state'] in {'quarantine', 'reject', 'stale', 'unknown'} and 'downgrade_reason' not in obj:
        fail('$.downgrade_reason: downgraded appraisals need a reason')
    if 'downgrade_reason' in obj:
        require_text(obj['downgrade_reason'], '$.downgrade_reason')
    if 'source_export_digest' in obj:
        require_pattern(obj['source_export_digest'], DIGEST_RE, '$.source_export_digest')
    if obj['appraisal_state'] == 'allow_weak_evidence' and not usable_for:
        fail('$.usable_for: weak evidence allowance must name allowed uses')
    require_non_implications(obj['non_implications'], APPRAISAL_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_plan(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, PLAN_ALLOWED, PLAN_REQUIRED, 'ST-RECONPLAN v0')
    require_pattern(obj['plan_id'], PLAN_RE, '$.plan_id')
    require_pattern(obj['import_ref'], IMPORT_RE, '$.import_ref')
    require_pattern(obj['appraisal_ref'], APPRAISAL_RE, '$.appraisal_ref')
    require_pattern(obj['local_subject_ref'], REF_RE, '$.local_subject_ref')
    require_pattern(obj['imported_subject_ref'], REF_RE, '$.imported_subject_ref')
    if obj['mapping_state'] not in MAPPING_STATES:
        fail('$.mapping_state: invalid')
    require_enum_list(obj['candidate_actions'], CANDIDATE_ACTIONS, '$.candidate_actions', maximum=8)
    if obj['downgrade_class'] not in DOWNGRADE_CLASSES:
        fail('$.downgrade_class: invalid')
    require_refs(obj['required_local_witnesses'], '$.required_local_witnesses', maximum=16, allow_empty=True)
    if obj['gap_state'] not in GAP_STATES:
        fail('$.gap_state: invalid')
    if 'conflict_refs' in obj:
        require_refs(obj['conflict_refs'], '$.conflict_refs', maximum=16)
    if 'plan_expires_at_ms' in obj:
        require_int(obj['plan_expires_at_ms'], '$.plan_expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['plan_expires_at_ms'] <= obj['observed_at_ms']:
            fail('$.plan_expires_at_ms: plan cannot already be expired')
    if 'downgrade_reason' in obj:
        require_text(obj['downgrade_reason'], '$.downgrade_reason')
    if obj['mapping_state'] == 'ready_for_review':
        if not obj['required_local_witnesses']:
            fail('$.required_local_witnesses: ready plans must name local witnesses required before use')
        if 'plan_expires_at_ms' not in obj:
            fail('$.plan_expires_at_ms: ready plans need a recheck horizon')
    if obj['gap_state'] != 'none' and 'downgrade_reason' not in obj:
        fail('$.downgrade_reason: non-none gap state must explain downgrade')
    require_non_implications(obj['non_implications'], PLAN_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_decision(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, DECISION_ALLOWED, DECISION_REQUIRED, 'ST-RECONDECISION v0')
    require_pattern(obj['decision_id'], DECISION_RE, '$.decision_id')
    require_pattern(obj['plan_ref'], PLAN_RE, '$.plan_ref')
    if obj['decision_state'] not in DECISION_STATES:
        fail('$.decision_state: invalid')
    if obj['adopted_scope'] not in ADOPTED_SCOPES:
        fail('$.adopted_scope: invalid')
    require_text(obj['decision_reason'], '$.decision_reason')
    require_refs(obj['required_local_witnesses'], '$.required_local_witnesses', maximum=16, allow_empty=True)
    require_refs(obj['resulting_refs'], '$.resulting_refs', maximum=16, allow_empty=True)
    if 'authority_basis_ref' in obj:
        require_pattern(obj['authority_basis_ref'], REF_RE, '$.authority_basis_ref')
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail('$.expires_or_recheck_by_ms: cannot precede observed_at_ms')
    if 'rejected_reason' in obj:
        require_text(obj['rejected_reason'], '$.rejected_reason')
    if obj['decision_state'] == 'adopted_as_history' and obj['adopted_scope'] != 'history':
        fail('$.adopted_scope: history adoption must remain history scoped')
    if obj['decision_state'] == 'attached_as_weak_basis':
        if obj['adopted_scope'] != 'weak_basis':
            fail('$.adopted_scope: weak-basis attachment needs weak_basis scope')
        if not obj['required_local_witnesses']:
            fail('$.required_local_witnesses: weak-basis attachment requires local witnesses before stronger use')
    if obj['decision_state'] in {'adopted_as_history', 'attached_as_weak_basis'} and not obj['resulting_refs']:
        fail('$.resulting_refs: adopted decisions must name resulting evidence refs')
    if obj['decision_state'] == 'needs_local_recheck' and not obj['required_local_witnesses']:
        fail('$.required_local_witnesses: local recheck decision must name required witnesses')
    if obj['decision_state'] in {'rejected', 'quarantined'} and 'rejected_reason' not in obj:
        fail('$.rejected_reason: rejected/quarantined decisions need a reason')
    require_non_implications(obj['non_implications'], DECISION_NON_IMPLICATIONS, '$.non_implications')
    return obj


def schema_case(case_id: str, object_kind: str, obj: dict[str, Any] | None, expect: str, note: str, *, json_text: str | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'note': note}
    if json_text is not None:
        out['json_text'] = json_text
    else:
        out['json'] = obj
        if expect == 'accept':
            out['expected_digest'] = digest(obj)
    return out


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, note: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'flow', 'expect': expect, 'events': events, 'note': note}


def clone(obj: dict[str, Any]) -> dict[str, Any]:
    return json.loads(json.dumps(obj))


def build_cases() -> list[dict[str, Any]]:
    receipt_a = digest({'receipt': 'a'})
    receipt_b = digest({'receipt': 'b'})
    receipt_c = digest({'receipt': 'c'})
    export_digest = digest({'export': 'bundle', 'receipts': [receipt_a, receipt_b]})
    manifest_digest = digest({'import_manifest': [receipt_a, receipt_b], 'redaction': 'known'})
    cid = 'demo.web'
    issuer_importer = {'kind': 'importer', 'id': 'steward/importer'}
    issuer_verifier = {'kind': 'verifier', 'id': 'steward/verifier'}
    issuer_reconciler = {'kind': 'reconciler', 'id': 'steward/reconciler'}

    import_ok = {
        'schema': 'ST-IMPORT v0',
        'witness_id': 'wit_impobs0000000000',
        'import_id': 'imp_aaaaaaaaaaaaaaaa',
        'cid': cid,
        'issuer': issuer_importer,
        'source_kind': 'sibling_cube',
        'source_ref': 'sibling/steward-rev0191',
        'source_export_digest': export_digest,
        'source_replay_ref': 'rpl_aaaaaaaaaaaaaaaa',
        'imported_receipt_digests': sorted([receipt_b, receipt_a]),
        'import_state': 'accepted_as_evidence',
        'redaction_state': 'known_minimized',
        'gap_state': 'none',
        'quarantine_state': 'released_for_weak_evidence',
        'import_manifest_digest': manifest_digest,
        'observed_at_ms': 1000,
        'expires_or_recheck_by_ms': 5000,
        'basis_refs': ['sha256:' + '0' * 64, 'export/steward-rev0191'],
        'non_implications': sorted(IMPORT_NON_IMPLICATIONS),
    }
    import_gap = clone(import_ok)
    import_gap.update({
        'witness_id': 'wit_impobs0000000001',
        'import_id': 'imp_bbbbbbbbbbbbbbbb',
        'source_export_digest': digest({'export': 'partial'}),
        'imported_receipt_digests': [receipt_a],
        'import_state': 'quarantined',
        'redaction_state': 'unknown',
        'gap_state': 'missing_receipts',
        'quarantine_state': 'required',
        'import_manifest_digest': digest({'import_manifest': [receipt_a], 'redaction': 'unknown'}),
        'missing_reason': 'Bundle omitted one referenced receipt digest',
    })

    appraisal_ok = {
        'schema': 'ST-SRCAPPRAISE v0',
        'witness_id': 'wit_appsrc0000000000',
        'appraisal_id': 'app_aaaaaaaaaaaaaaaa',
        'cid': cid,
        'issuer': issuer_verifier,
        'import_ref': import_ok['import_id'],
        'source_kind': 'sibling_cube',
        'subject_ref': 'sibling/steward-rev0191',
        'appraisal_state': 'allow_weak_evidence',
        'trust_scope': 'this_import_only',
        'usable_for': ['audit', 'explanation', 'history', 'operator_review', 'recovery_hint'],
        'caveats': ['Use only as weak evidence until local witnesses refresh'],
        'expires_at_ms': 6000,
        'source_export_digest': export_digest,
        'observed_at_ms': 1500,
        'basis_refs': [import_ok['import_id'], export_digest],
        'non_implications': sorted(APPRAISAL_NON_IMPLICATIONS),
    }
    appraisal_quarantine = clone(appraisal_ok)
    appraisal_quarantine.update({
        'witness_id': 'wit_appsrc0000000001',
        'appraisal_id': 'app_bbbbbbbbbbbbbbbb',
        'import_ref': import_gap['import_id'],
        'appraisal_state': 'quarantine',
        'trust_scope': 'recovery_hint_only',
        'usable_for': [],
        'caveats': ['Gap must be resolved before reuse'],
        'downgrade_reason': 'Missing receipt digest prevents weak adoption',
        'source_export_digest': import_gap['source_export_digest'],
    })

    plan_ok = {
        'schema': 'ST-RECONPLAN v0',
        'witness_id': 'wit_recpla0000000000',
        'plan_id': 'rcp_aaaaaaaaaaaaaaaa',
        'cid': cid,
        'issuer': issuer_reconciler,
        'import_ref': import_ok['import_id'],
        'appraisal_ref': appraisal_ok['appraisal_id'],
        'local_subject_ref': 'component/demo.web',
        'imported_subject_ref': 'sibling/component/demo.web',
        'mapping_state': 'ready_for_review',
        'candidate_actions': ['adopt_as_history', 'attach_as_basis', 'request_recheck'],
        'downgrade_class': 'weak_basis',
        'required_local_witnesses': ['wit_stateatt00000000', 'wit_ctrlverd0000000'],
        'gap_state': 'none',
        'plan_expires_at_ms': 7000,
        'observed_at_ms': 2000,
        'basis_refs': [import_ok['import_id'], appraisal_ok['appraisal_id']],
        'non_implications': sorted(PLAN_NON_IMPLICATIONS),
    }
    plan_blocked = clone(plan_ok)
    plan_blocked.update({
        'witness_id': 'wit_recpla0000000001',
        'plan_id': 'rcp_bbbbbbbbbbbbbbbb',
        'import_ref': import_gap['import_id'],
        'appraisal_ref': appraisal_quarantine['appraisal_id'],
        'mapping_state': 'blocked',
        'candidate_actions': ['quarantine', 'request_recheck'],
        'downgrade_class': 'requires_recheck',
        'required_local_witnesses': ['wit_receiptchain000'],
        'gap_state': 'missing_receipts',
        'downgrade_reason': 'Imported chain has a missing receipt gap',
    })

    decision_ok = {
        'schema': 'ST-RECONDECISION v0',
        'witness_id': 'wit_recdec0000000000',
        'decision_id': 'rcd_aaaaaaaaaaaaaaaa',
        'cid': cid,
        'issuer': issuer_reconciler,
        'plan_ref': plan_ok['plan_id'],
        'decision_state': 'attached_as_weak_basis',
        'adopted_scope': 'weak_basis',
        'decision_reason': 'Attach imported history as weak basis pending local refresh',
        'required_local_witnesses': ['wit_stateatt00000000', 'wit_ctrlverd0000000'],
        'resulting_refs': ['basis/imported-history-demo-web'],
        'expires_or_recheck_by_ms': 6500,
        'observed_at_ms': 2500,
        'basis_refs': [plan_ok['plan_id'], appraisal_ok['appraisal_id']],
        'non_implications': sorted(DECISION_NON_IMPLICATIONS),
    }
    decision_quarantine = clone(decision_ok)
    decision_quarantine.update({
        'witness_id': 'wit_recdec0000000001',
        'decision_id': 'rcd_bbbbbbbbbbbbbbbb',
        'plan_ref': plan_blocked['plan_id'],
        'decision_state': 'quarantined',
        'adopted_scope': 'none',
        'decision_reason': 'Keep imported bundle out of live reasoning until gap resolves',
        'required_local_witnesses': ['wit_receiptchain000'],
        'resulting_refs': [],
        'rejected_reason': 'Missing imported receipt digest',
    })

    import_bad_redaction = clone(import_ok)
    import_bad_redaction['redaction_state'] = 'unknown'

    import_unsorted = clone(import_ok)
    import_unsorted['imported_receipt_digests'] = [receipt_b, receipt_a] if receipt_b < receipt_a else [receipt_a, receipt_b]
    if import_unsorted['imported_receipt_digests'] == sorted(import_unsorted['imported_receipt_digests']):
        import_unsorted['imported_receipt_digests'] = list(reversed(import_unsorted['imported_receipt_digests']))

    import_claim_current = clone(import_ok)
    import_claim_current['claims_current'] = True

    appraisal_bad_use = clone(appraisal_ok)
    appraisal_bad_use['usable_for'] = ['current_state']

    appraisal_expired = clone(appraisal_ok)
    appraisal_expired['expires_at_ms'] = appraisal_expired['observed_at_ms']

    plan_no_witness = clone(plan_ok)
    plan_no_witness['required_local_witnesses'] = []

    plan_execute = clone(plan_ok)
    plan_execute['candidate_actions'] = ['start']

    plan_gap_no_reason = clone(plan_blocked)
    del plan_gap_no_reason['downgrade_reason']

    decision_weak_no_witness = clone(decision_ok)
    decision_weak_no_witness['required_local_witnesses'] = []

    decision_current = clone(decision_ok)
    decision_current['claims_current'] = True

    decision_history_bad_scope = clone(decision_ok)
    decision_history_bad_scope['decision_state'] = 'adopted_as_history'
    decision_history_bad_scope['adopted_scope'] = 'weak_basis'

    return [
        schema_case('import.accept.weak-evidence-release', 'ST-IMPORT', import_ok, 'accept', 'imported evidence can be released only as weak evidence after redaction and gap checks'),
        schema_case('import.accept.quarantined-gap', 'ST-IMPORT', import_gap, 'accept', 'gapped imports stay quarantined with an explicit missing reason'),
        schema_case('import.reject.accepted-without-redaction', 'ST-IMPORT', import_bad_redaction, 'reject', 'accepted imports require known minimized redaction'),
        schema_case('import.reject.unsorted-receipts', 'ST-IMPORT', import_unsorted, 'reject', 'imported receipt digests must be sorted for stable binding'),
        schema_case('import.reject.claims-current', 'ST-IMPORT', import_claim_current, 'reject', 'imports must not claim current state'),
        schema_case('import.reject.duplicate-json-key', 'ST-IMPORT', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-IMPORT v0","schema":"ST-IMPORT v0","witness_id":"wit_impobs0000000002","import_id":"imp_cccccccccccccccc","cid":"demo.web","issuer":{"kind":"importer","id":"steward/importer"},"source_kind":"sibling_cube","source_ref":"sibling/x","source_export_digest":"sha256:0000000000000000000000000000000000000000000000000000000000000000","source_replay_ref":"rpl_cccccccccccccccc","imported_receipt_digests":["sha256:0000000000000000000000000000000000000000000000000000000000000000"],"import_state":"observed","redaction_state":"unknown","gap_state":"unknown","quarantine_state":"pending","import_manifest_digest":"sha256:0000000000000000000000000000000000000000000000000000000000000000","observed_at_ms":1,"basis_refs":["basis/x"],"non_implications":["not-authority","not-current-state","not-freshness","not-live-state","not-effect-success","not-global-trust"],"missing_reason":"Unknown gap"}'),

        schema_case('srcappraise.accept.weak-evidence', 'ST-SRCAPPRAISE', appraisal_ok, 'accept', 'source appraisal can allow only weak evidence scoped to this import'),
        schema_case('srcappraise.accept.quarantine', 'ST-SRCAPPRAISE', appraisal_quarantine, 'accept', 'quarantine appraisal names downgrade reason and allowed scope'),
        schema_case('srcappraise.reject.current-state-use', 'ST-SRCAPPRAISE', appraisal_bad_use, 'reject', 'source appraisal cannot authorize current-state use'),
        schema_case('srcappraise.reject.expired-at-observation', 'ST-SRCAPPRAISE', appraisal_expired, 'reject', 'source appraisals cannot already be expired'),
        schema_case('srcappraise.reject.duplicate-json-key', 'ST-SRCAPPRAISE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-SRCAPPRAISE v0","schema":"ST-SRCAPPRAISE v0","witness_id":"wit_appsrc0000000002","appraisal_id":"app_cccccccccccccccc","cid":"demo.web","issuer":{"kind":"verifier","id":"steward/verifier"},"import_ref":"imp_cccccccccccccccc","source_kind":"sibling_cube","subject_ref":"sibling/x","appraisal_state":"unknown","trust_scope":"this_import_only","usable_for":[],"caveats":["Unknown source"],"expires_at_ms":2,"observed_at_ms":1,"basis_refs":["imp_cccccccccccccccc"],"non_implications":["not-global-trust","not-authority","not-current-state","not-freshness","not-effect-success","not-policy"],"downgrade_reason":"Unknown source"}'),

        schema_case('reconplan.accept.ready-for-review', 'ST-RECONPLAN', plan_ok, 'accept', 'reconciliation plans can map import facts only to reviewed weak-basis actions with local witnesses'),
        schema_case('reconplan.accept.blocked-gap', 'ST-RECONPLAN', plan_blocked, 'accept', 'blocked plans keep gap downgrade visible'),
        schema_case('reconplan.reject.ready-without-local-witnesses', 'ST-RECONPLAN', plan_no_witness, 'reject', 'ready plans must name required local witnesses'),
        schema_case('reconplan.reject.execute-action', 'ST-RECONPLAN', plan_execute, 'reject', 'reconciliation plans cannot execute lifecycle mutations'),
        schema_case('reconplan.reject.gap-without-reason', 'ST-RECONPLAN', plan_gap_no_reason, 'reject', 'gapped plans must state downgrade reason'),

        schema_case('recondecision.accept.attach-weak-basis', 'ST-RECONDECISION', decision_ok, 'accept', 'decisions attach imported evidence only as weak basis with local witness requirements'),
        schema_case('recondecision.accept.quarantined', 'ST-RECONDECISION', decision_quarantine, 'accept', 'quarantine decision leaves no resulting evidence refs'),
        schema_case('recondecision.reject.weak-without-local-witnesses', 'ST-RECONDECISION', decision_weak_no_witness, 'reject', 'weak-basis attachment must preserve local witness requirements'),
        schema_case('recondecision.reject.claims-current', 'ST-RECONDECISION', decision_current, 'reject', 'reconciliation decisions must not claim current state'),
        schema_case('recondecision.reject.history-bad-scope', 'ST-RECONDECISION', decision_history_bad_scope, 'reject', 'history adoption must remain history scoped'),

        flow_case('importflow.accept.weak-history-attachment', [
            {'event': 'import', 'witness': import_ok},
            {'event': 'appraisal', 'witness': appraisal_ok},
            {'event': 'plan', 'witness': plan_ok},
            {'event': 'decision', 'witness': decision_ok},
        ], 'accept', 'imported evidence can become weak basis only through import, appraisal, plan, and decision witnesses'),
        flow_case('importflow.accept.quarantine-gap', [
            {'event': 'import', 'witness': import_gap},
            {'event': 'appraisal', 'witness': appraisal_quarantine},
            {'event': 'plan', 'witness': plan_blocked},
            {'event': 'decision', 'witness': decision_quarantine},
        ], 'accept', 'gapful imports remain quarantined through reconciliation'),
        flow_case('importflow.reject.decision-without-plan', [
            {'event': 'import', 'witness': import_ok},
            {'event': 'appraisal', 'witness': appraisal_ok},
            {'event': 'decision', 'witness': decision_ok},
        ], 'reject', 'decisions cannot bind directly to imports without a plan'),
        flow_case('importflow.reject.ready-plan-from-quarantine', [
            {'event': 'import', 'witness': import_gap},
            {'event': 'appraisal', 'witness': appraisal_quarantine},
            {'event': 'plan', 'witness': {**plan_ok, 'import_ref': import_gap['import_id'], 'appraisal_ref': appraisal_quarantine['appraisal_id']}},
        ], 'reject', 'quarantined appraisals cannot produce ready reconciliation plans'),
        flow_case('importflow.reject.blocked-plan-adopted', [
            {'event': 'import', 'witness': import_gap},
            {'event': 'appraisal', 'witness': appraisal_quarantine},
            {'event': 'plan', 'witness': plan_blocked},
            {'event': 'decision', 'witness': {**decision_ok, 'plan_ref': plan_blocked['plan_id']}},
        ], 'reject', 'blocked plans cannot be adopted as weak basis'),
        flow_case('importflow.reject.import-promoted-current', [
            {'event': 'import', 'witness': import_ok},
            {'event': 'appraisal', 'witness': appraisal_ok},
            {'event': 'plan', 'witness': plan_ok},
            {'event': 'decision', 'witness': decision_ok, 'promote_to_current': True},
        ], 'reject', 'flow events cannot promote imported evidence into current lifecycle truth'),
        flow_case('importflow.reject.import-executes-operation', [
            {'event': 'import', 'witness': import_ok},
            {'event': 'appraisal', 'witness': appraisal_ok},
            {'event': 'plan', 'witness': plan_ok},
            {'event': 'decision', 'witness': decision_ok},
            {'event': 'execute_operation_from_import', 'operation_ref': 'op/imported-stop', 'decision_ref': decision_ok['decision_id']},
        ], 'reject', 'import reconciliation cannot execute lifecycle operations'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        if case['object_kind'] == 'ST-IMPORT':
            validate_import(obj)
        elif case['object_kind'] == 'ST-SRCAPPRAISE':
            validate_appraisal(obj)
        elif case['object_kind'] == 'ST-RECONPLAN':
            validate_plan(obj)
        elif case['object_kind'] == 'ST-RECONDECISION':
            validate_decision(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        imports: dict[str, dict[str, Any]] = {}
        appraisals: dict[str, dict[str, Any]] = {}
        plans: dict[str, dict[str, Any]] = {}
        decisions: dict[str, dict[str, Any]] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'import':
                witness = validate_import(ev['witness'])
                imports[witness['import_id']] = witness
            elif kind == 'appraisal':
                witness = validate_appraisal(ev['witness'])
                imp = imports.get(witness['import_ref'])
                if imp is None:
                    fail(f'{where}: appraisal references unseen import')
                if witness.get('source_export_digest') and witness['source_export_digest'] != imp['source_export_digest']:
                    fail(f'{where}: source export digest mismatch')
                if witness['appraisal_state'] == 'allow_weak_evidence' and imp['import_state'] != 'accepted_as_evidence':
                    fail(f'{where}: weak-evidence appraisal requires accepted weak-evidence import')
                appraisals[witness['appraisal_id']] = witness
            elif kind == 'plan':
                witness = validate_plan(ev['witness'])
                imp = imports.get(witness['import_ref'])
                appraisal = appraisals.get(witness['appraisal_ref'])
                if imp is None:
                    fail(f'{where}: plan references unseen import')
                if appraisal is None:
                    fail(f'{where}: plan references unseen appraisal')
                if witness['mapping_state'] == 'ready_for_review' and appraisal['appraisal_state'] != 'allow_weak_evidence':
                    fail(f'{where}: ready plan requires weak-evidence appraisal')
                if witness['mapping_state'] == 'ready_for_review' and imp['quarantine_state'] != 'released_for_weak_evidence':
                    fail(f'{where}: ready plan requires import released only for weak evidence')
                plans[witness['plan_id']] = witness
            elif kind == 'decision':
                witness = validate_decision(ev['witness'])
                plan = plans.get(witness['plan_ref'])
                if plan is None:
                    fail(f'{where}: decision references unseen plan')
                if ev.get('promote_to_current') or ev.get('claims_execution') or ev.get('claims_authority'):
                    fail(f'{where}: decision event promotes import beyond weak evidence/history')
                if witness['decision_state'] in {'attached_as_weak_basis', 'adopted_as_history'} and plan['mapping_state'] != 'ready_for_review':
                    fail(f'{where}: adoption requires a ready-for-review plan')
                decisions[witness['decision_id']] = witness
            elif kind == 'execute_operation_from_import':
                require_pattern(ev.get('operation_ref'), REF_RE, f'{where}.operation_ref')
                require_pattern(ev.get('decision_ref'), DECISION_RE, f'{where}.decision_ref')
                if ev['decision_ref'] in decisions:
                    fail(f'{where}: import reconciliation decisions cannot execute lifecycle operations')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-import-reconciliation-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-import-reconciliation-corpus] FAIL: corpus is stale; run tools/steward_import_reconciliation_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-import-reconciliation-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
