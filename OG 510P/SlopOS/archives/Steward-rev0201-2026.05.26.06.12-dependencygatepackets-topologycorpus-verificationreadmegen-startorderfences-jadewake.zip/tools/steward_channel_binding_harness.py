#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/channel-binding-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
CURSOR_RE = re.compile(r'^[a-z][a-z0-9._:/#-]{0,127}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_ready', 'claims_readiness', 'claims_serving', 'claims_stopped',
    'claims_effect_success', 'ready', 'serving', 'component_state', 'rollout_complete',
    'work_completed', 'lossless', 'exactly_once', 'raw_log', 'scrollback', 'token',
    'secret', 'raw_handle', 'bearer', 'pid', 'ppid', 'pgid', 'cgroup',
    'systemd_unit', 'pod_name', 'container_id', 'process_name', 'host_unit',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'controller', 'proxy', 'balancer'}

FRESH_REQUIRED = {'source_vantage', 'observed_at_ms', 'state'}
FRESH_OPTIONAL = {'expires_or_recheck_by_ms', 'staleness_reason'}
FRESH_ALLOWED = FRESH_REQUIRED | FRESH_OPTIONAL
FRESH_STATES = {'fresh', 'last_known', 'stale', 'unknown'}

TBIND_REQUIRED = {'schema', 'witness_id', 'traffic_surface_ref', 'binding_issuer', 'binding_state', 'binding_role', 'allocation_kind', 'targets', 'freshness', 'basis_refs', 'non_implications'}
TBIND_OPTIONAL = {'route_ref', 'service_ref', 'alias_ref', 'component_id', 'revision_ref', 'incarnation_id', 'affinity_caveat', 'drain_state', 'desired_binding_revision', 'observed_binding_revision', 'data_plane_as_of_ms', 'staleness_reason', 'observed_at_ms'}
TBIND_ALLOWED = TBIND_REQUIRED | TBIND_OPTIONAL
BINDING_STATES = {'desired', 'observed', 'applying', 'active', 'partially_applied', 'draining', 'stale', 'unknown'}
BINDING_ROLES = {'primary', 'mirror', 'shadow', 'tap', 'observation_only'}
ALLOCATION_KINDS = {'none', 'weighted', 'direct', 'sticky', 'pinned', 'tagged', 'dns', 'topology_hint', 'unknown'}
AFFINITY_CAVEATS = {'ordinary', 'sticky', 'pinned', 'tagged', 'direct_test', 'connection_bound', 'unknown_affinity'}
TBIND_DRAIN_STATES = {'none', 'no_new_work', 'draining_existing', 'deregistration_delay', 'drain_unknown'}
TARGET_REQUIRED = {'target_ref', 'role', 'weight', 'state'}
TARGET_ALLOWED = TARGET_REQUIRED
TARGET_STATES = {'active', 'warming', 'draining', 'no_new_work', 'stale', 'unknown'}
TBIND_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-admission', 'not-custody',
    'not-work-completion', 'not-effect-success', 'not-rollout-settlement',
    'not-deterministic-per-request', 'not-live-channel-fate',
}
TBIND_BASE_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-admission', 'not-custody',
    'not-work-completion', 'not-effect-success', 'not-rollout-settlement',
    'not-deterministic-per-request',
}

LIVE_REQUIRED = {'schema', 'witness_id', 'live_channel_ref', 'channel_kind', 'holder_ref', 'layer', 'channel_state', 'freshness', 'basis_refs', 'non_implications'}
LIVE_OPTIONAL = {'traffic_surface_ref', 'listener_ref', 'subscription_ref', 'component_id', 'revision_ref', 'incarnation_id', 'peer_ref', 'new_substream_state', 'drain_layer', 'drain_state', 'drain_deadline_ms', 'last_stream_or_event_cursor', 'close_signal', 'resume_hint', 'route_binding_ref', 'material_freshness_refs', 'custody_or_disposition_refs', 'observed_at_ms', 'unknown_reason', 'gap_state'}
LIVE_ALLOWED = LIVE_REQUIRED | LIVE_OPTIONAL
CHANNEL_KINDS = {'http2', 'http3', 'grpc', 'websocket', 'sse', 'watch', 'message_subscription', 'tcp', 'quic', 'unknown'}
LAYERS = {'listener', 'connection', 'stream', 'subscription', 'publisher', 'application'}
CHANNEL_STATES = {'open', 'draining', 'closing', 'closed_cleanly', 'closed_abnormally', 'reset', 'peer_lost', 'resumed', 'lost', 'unknown'}
NEW_SUBSTREAM_STATES = {'accepting', 'no_new', 'last_accepted_known', 'last_maybe_processed_known', 'unknown'}
LIVE_DRAIN_STATES = {'none', 'drain_started', 'drain_complete', 'force_close_pending', 'force_closed', 'deadline_unknown', 'drain_unknown'}
CLOSE_SIGNALS = {'none', 'close_sent', 'close_received', 'closing_handshake', 'closed_cleanly', 'closed_abnormally', 'reset', 'transport_error', 'reason_disagrees', 'unknown'}
RESUME_HINTS = {'absent', 'hint_only', 'attempted', 'accepted', 'gap_possible', 'gap_known', 'duplicate_possible', 'continuity_unknown'}
GAP_STATES = {'gap_possible', 'gap_known', 'duplicate_possible', 'continuity_unknown', 'no_gap_proven'}
LIVE_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-route-authority', 'not-material-freshness',
    'not-current-incarnation', 'not-custody', 'not-work-completion',
    'not-effect-success', 'not-rollout-settlement', 'not-lossless-continuity',
}
LIVE_BASE_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-route-authority', 'not-custody',
    'not-work-completion', 'not-effect-success', 'not-lossless-continuity',
}


def scan_forbidden_keys(value: Any, forbidden: set[str], path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in forbidden:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, forbidden, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, forbidden, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered:
        fail(f'{path}: raw secret-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_ref_field(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], REF_RE, f'{path}.{field}')


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_freshness(value: Any, path: str) -> dict[str, Any]:
    freshness = require_object(value, path)
    require_closed_keys(freshness, FRESH_ALLOWED, FRESH_REQUIRED, path)
    require_pattern(freshness['source_vantage'], REF_RE, f'{path}.source_vantage')
    require_int(freshness['observed_at_ms'], f'{path}.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if freshness['state'] not in FRESH_STATES:
        fail(f'{path}.state: invalid freshness state')
    if 'expires_or_recheck_by_ms' in freshness:
        require_int(freshness['expires_or_recheck_by_ms'], f'{path}.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if freshness['expires_or_recheck_by_ms'] < freshness['observed_at_ms']:
            fail(f'{path}.expires_or_recheck_by_ms: cannot precede observed_at_ms')
    if freshness['state'] in {'stale', 'unknown'} and 'staleness_reason' not in freshness:
        fail(f'{path}.staleness_reason: stale/unknown freshness must explain downgrade')
    if 'staleness_reason' in freshness:
        require_text(freshness['staleness_reason'], f'{path}.staleness_reason')
    return freshness


def validate_target(value: Any, path: str) -> dict[str, Any]:
    target = require_object(value, path)
    require_closed_keys(target, TARGET_ALLOWED, TARGET_REQUIRED, path)
    require_pattern(target['target_ref'], REF_RE, f'{path}.target_ref')
    if target['role'] not in BINDING_ROLES:
        fail(f'{path}.role: invalid target role')
    require_int(target['weight'], f'{path}.weight', minimum=0, maximum=1_000_000)
    if target['state'] not in TARGET_STATES:
        fail(f'{path}.state: invalid target state')
    return target


def validate_targets(value: Any, path: str) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > 16:
        fail(f'{path}: too many targets')
    out: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for idx, item in enumerate(value):
        target = validate_target(item, f'{path}[{idx}]')
        pair = (target['target_ref'], target['role'])
        if pair in seen:
            fail(f'{path}: duplicate target role pair {pair}')
        seen.add(pair)
        out.append(target)
    return out


def validate_st_tbind(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, TBIND_ALLOWED, TBIND_REQUIRED, '$')
    if obj['schema'] != 'ST-TBIND v0':
        fail('$.schema: expected ST-TBIND v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['traffic_surface_ref'], REF_RE, '$.traffic_surface_ref')
    validate_issuer(obj['binding_issuer'], '$.binding_issuer')
    if obj['binding_state'] not in BINDING_STATES:
        fail('$.binding_state: invalid state')
    if obj['binding_role'] not in BINDING_ROLES:
        fail('$.binding_role: invalid role')
    if obj['allocation_kind'] not in ALLOCATION_KINDS:
        fail('$.allocation_kind: invalid allocation kind')
    targets = validate_targets(obj['targets'], '$.targets')
    if obj['binding_state'] in {'active', 'applying', 'partially_applied', 'draining'} and not targets:
        fail('$.targets: active/applying/draining binding needs at least one target')
    if obj['allocation_kind'] == 'weighted' and sum(t['weight'] for t in targets) <= 0:
        fail('$.targets: weighted binding needs positive target weight')
    validate_freshness(obj['freshness'], '$.freshness')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    non_implications = set(require_refs(obj['non_implications'], '$.non_implications', maximum=16))
    invalid = sorted(non_implications - TBIND_NON_IMPLICATIONS)
    if invalid:
        fail(f'$.non_implications: invalid values {invalid}')
    missing = sorted(TBIND_BASE_NON_IMPLICATIONS - non_implications)
    if missing:
        fail(f'$.non_implications: missing traffic-binding non-implications {missing}')
    for field in ('route_ref', 'service_ref', 'alias_ref', 'revision_ref', 'incarnation_id', 'desired_binding_revision', 'observed_binding_revision', 'staleness_reason'):
        require_ref_field(obj, field, '$')
    if 'component_id' in obj:
        require_pattern(obj['component_id'], CID_RE, '$.component_id')
    if 'affinity_caveat' in obj and obj['affinity_caveat'] not in AFFINITY_CAVEATS:
        fail('$.affinity_caveat: invalid caveat')
    if 'drain_state' in obj:
        if obj['drain_state'] not in TBIND_DRAIN_STATES:
            fail('$.drain_state: invalid drain state')
        if obj['drain_state'] in {'no_new_work', 'draining_existing', 'deregistration_delay'} and 'not-live-channel-fate' not in non_implications:
            fail('$.non_implications: draining traffic binding must refuse live-channel fate')
    if 'data_plane_as_of_ms' in obj:
        require_int(obj['data_plane_as_of_ms'], '$.data_plane_as_of_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'observed_at_ms' in obj:
        require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    return obj


def validate_st_livechan(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, LIVE_ALLOWED, LIVE_REQUIRED, '$')
    if obj['schema'] != 'ST-LIVECHAN v0':
        fail('$.schema: expected ST-LIVECHAN v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['live_channel_ref'], REF_RE, '$.live_channel_ref')
    if obj['channel_kind'] not in CHANNEL_KINDS:
        fail('$.channel_kind: invalid channel kind')
    require_pattern(obj['holder_ref'], REF_RE, '$.holder_ref')
    if obj['layer'] not in LAYERS:
        fail('$.layer: invalid layer')
    if obj['channel_state'] not in CHANNEL_STATES:
        fail('$.channel_state: invalid state')
    validate_freshness(obj['freshness'], '$.freshness')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    non_implications = set(require_refs(obj['non_implications'], '$.non_implications', maximum=16))
    invalid = sorted(non_implications - LIVE_NON_IMPLICATIONS)
    if invalid:
        fail(f'$.non_implications: invalid values {invalid}')
    missing = sorted(LIVE_BASE_NON_IMPLICATIONS - non_implications)
    if missing:
        fail(f'$.non_implications: missing live-channel non-implications {missing}')
    for field in ('traffic_surface_ref', 'listener_ref', 'subscription_ref', 'revision_ref', 'incarnation_id', 'peer_ref', 'route_binding_ref', 'unknown_reason'):
        require_ref_field(obj, field, '$')
    if 'component_id' in obj:
        require_pattern(obj['component_id'], CID_RE, '$.component_id')
    if 'new_substream_state' in obj and obj['new_substream_state'] not in NEW_SUBSTREAM_STATES:
        fail('$.new_substream_state: invalid state')
    if 'drain_layer' in obj and obj['drain_layer'] not in LAYERS:
        fail('$.drain_layer: invalid layer')
    if 'drain_state' in obj:
        if obj['drain_state'] not in LIVE_DRAIN_STATES:
            fail('$.drain_state: invalid drain state')
        if obj['drain_state'] == 'drain_started' and 'drain_deadline_ms' not in obj:
            fail('$.drain_deadline_ms: started drains need a deadline or explicit deadline_unknown state')
    if 'drain_deadline_ms' in obj:
        require_int(obj['drain_deadline_ms'], '$.drain_deadline_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'last_stream_or_event_cursor' in obj:
        require_pattern(obj['last_stream_or_event_cursor'], CURSOR_RE, '$.last_stream_or_event_cursor')
    if 'close_signal' in obj and obj['close_signal'] not in CLOSE_SIGNALS:
        fail('$.close_signal: invalid close signal')
    if 'resume_hint' in obj and obj['resume_hint'] not in RESUME_HINTS:
        fail('$.resume_hint: invalid resume hint')
    if 'gap_state' in obj and obj['gap_state'] not in GAP_STATES:
        fail('$.gap_state: invalid gap state')
    if obj.get('resume_hint', 'absent') != 'absent':
        if obj.get('gap_state') == 'no_gap_proven' and not obj.get('custody_or_disposition_refs'):
            fail('$.gap_state: resume hints cannot prove lossless continuity without adjacent disposition evidence')
        if 'not-lossless-continuity' not in non_implications:
            fail('$.non_implications: resume hints must refuse lossless continuity')
    if 'material_freshness_refs' in obj:
        require_refs(obj['material_freshness_refs'], '$.material_freshness_refs', maximum=16)
    if 'custody_or_disposition_refs' in obj:
        require_refs(obj['custody_or_disposition_refs'], '$.custody_or_disposition_refs', maximum=16)
    if 'observed_at_ms' in obj:
        require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    return obj


def base_issuer(kind: str = 'steward') -> dict[str, Any]:
    return {'kind': kind, 'id': f'{kind}/proof-harness'}


def base_freshness(source: str = 'vantage/public-gateway', observed: int = 1000, state: str = 'fresh') -> dict[str, Any]:
    out: dict[str, Any] = {'source_vantage': source, 'observed_at_ms': observed, 'state': state, 'expires_or_recheck_by_ms': observed + 5000}
    if state in {'stale', 'unknown'}:
        out['staleness_reason'] = 'observation expired before proof case'
    return out


def tbind_non_implications(*extra: str) -> list[str]:
    vals = sorted(TBIND_BASE_NON_IMPLICATIONS | set(extra))
    return vals


def live_non_implications(*extra: str) -> list[str]:
    vals = sorted(LIVE_BASE_NON_IMPLICATIONS | set(extra))
    return vals


def base_tbind() -> dict[str, Any]:
    return {
        'schema': 'ST-TBIND v0',
        'witness_id': 'wit_tbind00000000001',
        'traffic_surface_ref': 'surface/public-http',
        'binding_issuer': base_issuer('proxy'),
        'binding_state': 'active',
        'binding_role': 'primary',
        'allocation_kind': 'weighted',
        'targets': [
            {'target_ref': 'revision/demo-web-r1', 'role': 'primary', 'weight': 800000, 'state': 'active'},
            {'target_ref': 'revision/demo-web-r2', 'role': 'primary', 'weight': 200000, 'state': 'warming'},
        ],
        'freshness': base_freshness(),
        'basis_refs': ['route-observation/gw-1'],
        'non_implications': tbind_non_implications(),
        'route_ref': 'route/public-http',
        'component_id': 'demo.web',
        'revision_ref': 'revision/demo-web-r1',
        'desired_binding_revision': 'binding-rev/42',
        'observed_binding_revision': 'binding-rev/42',
        'data_plane_as_of_ms': 1000,
    }


def mirror_tbind() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_tbind()))
    obj['witness_id'] = 'wit_tbind00000000002'
    obj['binding_role'] = 'mirror'
    obj['allocation_kind'] = 'direct'
    obj['targets'] = [{'target_ref': 'revision/demo-web-r3', 'role': 'mirror', 'weight': 1000000, 'state': 'active'}]
    obj['basis_refs'] = ['mirror-observation/gw-1']
    obj['non_implications'] = tbind_non_implications('not-live-channel-fate')
    return obj


def no_new_tbind() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_tbind()))
    obj['witness_id'] = 'wit_tbind00000000003'
    obj['binding_state'] = 'draining'
    obj['allocation_kind'] = 'direct'
    obj['targets'] = [{'target_ref': 'revision/demo-web-r1', 'role': 'primary', 'weight': 0, 'state': 'no_new_work'}]
    obj['drain_state'] = 'no_new_work'
    obj['basis_refs'] = ['drain-observation/gw-1']
    obj['non_implications'] = tbind_non_implications('not-live-channel-fate')
    return obj


def base_livechan() -> dict[str, Any]:
    return {
        'schema': 'ST-LIVECHAN v0',
        'witness_id': 'wit_livechan00000001',
        'live_channel_ref': 'channel/http2-conn-7',
        'channel_kind': 'http2',
        'holder_ref': 'holder/proxy-gw-1',
        'layer': 'connection',
        'channel_state': 'draining',
        'traffic_surface_ref': 'surface/public-http',
        'component_id': 'demo.web',
        'revision_ref': 'revision/demo-web-r1',
        'new_substream_state': 'no_new',
        'drain_layer': 'connection',
        'drain_state': 'drain_started',
        'drain_deadline_ms': 7000,
        'last_stream_or_event_cursor': 'stream/148',
        'close_signal': 'close_sent',
        'route_binding_ref': 'wit_tbind00000000003',
        'freshness': base_freshness('vantage/proxy-gw-1', 2000),
        'basis_refs': ['goaway/proxy-gw-1'],
        'non_implications': live_non_implications('not-material-freshness', 'not-current-incarnation', 'not-rollout-settlement'),
    }


def resumed_livechan() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_livechan()))
    obj['witness_id'] = 'wit_livechan00000002'
    obj['live_channel_ref'] = 'channel/watch-12'
    obj['channel_kind'] = 'watch'
    obj['layer'] = 'subscription'
    obj['channel_state'] = 'resumed'
    obj['new_substream_state'] = 'unknown'
    obj['drain_state'] = 'none'
    del obj['drain_deadline_ms']
    obj['last_stream_or_event_cursor'] = 'resource/version-447'
    obj['resume_hint'] = 'accepted'
    obj['gap_state'] = 'gap_possible'
    obj['basis_refs'] = ['watch/bookmark-447']
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'channel_binding_flow', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    tbind = base_tbind()
    mirror = mirror_tbind()
    no_new = no_new_tbind()
    live = base_livechan()
    resumed = resumed_livechan()

    active_without_targets = json.loads(json.dumps(tbind))
    active_without_targets['targets'] = []

    route_claims_ready = json.loads(json.dumps(tbind))
    route_claims_ready['claims_ready'] = True

    route_missing_nonimp = json.loads(json.dumps(tbind))
    route_missing_nonimp['non_implications'] = ['not-readiness', 'not-serving']

    route_negative_weight = json.loads(json.dumps(tbind))
    route_negative_weight['targets'][0]['weight'] = -1

    route_raw_pod = json.loads(json.dumps(tbind))
    route_raw_pod['targets'][0]['pod_name'] = 'demo-web-abc123'

    live_lossless_resume = json.loads(json.dumps(resumed))
    live_lossless_resume['gap_state'] = 'no_gap_proven'

    live_claims_effect = json.loads(json.dumps(live))
    live_claims_effect['claims_effect_success'] = True

    live_no_deadline = json.loads(json.dumps(live))
    del live_no_deadline['drain_deadline_ms']

    live_secret = json.loads(json.dumps(live))
    live_secret['bearer'] = 'do-not-log'

    return [
        schema_case('tbind.accept.weighted-primary', 'ST-TBIND', tbind, 'accept', 'active weighted binding is digestable but explicitly non-authoritative for readiness and effects'),
        schema_case('tbind.accept.mirror-observation-only', 'ST-TBIND', mirror, 'accept', 'mirror binding stays observation-only and refuses live-channel fate'),
        schema_case('tbind.accept.no-new-work-drain', 'ST-TBIND', no_new, 'accept', 'route drain can say no new work without claiming existing channels are gone'),
        schema_case('tbind.reject.claims-ready', 'ST-TBIND', route_claims_ready, 'reject', 'route binding packets must not claim readiness'),
        schema_case('tbind.reject.active-without-targets', 'ST-TBIND', active_without_targets, 'reject', 'active binding needs at least one bounded target summary'),
        schema_case('tbind.reject.missing-non-implications', 'ST-TBIND', route_missing_nonimp, 'reject', 'traffic binding must refuse stronger lifecycle truths in the packet'),
        schema_case('tbind.reject.negative-weight', 'ST-TBIND', route_negative_weight, 'reject', 'traffic weights are bounded non-negative allocation hints'),
        schema_case('tbind.reject.raw-pod-name', 'ST-TBIND', route_raw_pod, 'reject', 'host/runtime endpoint names are adapter facts, not portable binding authority'),
        schema_case('tbind.reject.duplicate-json-key', 'ST-TBIND', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-TBIND v0","schema":"ST-TBIND v0","witness_id":"wit_tbind00000000001","traffic_surface_ref":"surface/public-http","binding_issuer":{"kind":"proxy","id":"proxy/proof-harness"},"binding_state":"unknown","binding_role":"primary","allocation_kind":"unknown","targets":[],"freshness":{"source_vantage":"vantage/public-gateway","observed_at_ms":1,"state":"unknown","staleness_reason":"unknown source"},"basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-admission","not-custody","not-work-completion","not-effect-success","not-rollout-settlement","not-deterministic-per-request"]}'),

        schema_case('livechan.accept.draining-http2-channel', 'ST-LIVECHAN', live, 'accept', 'draining connection names holder, layer, no-new fence, deadline, cursor, and non-implications'),
        schema_case('livechan.accept.resumed-watch-gap-possible', 'ST-LIVECHAN', resumed, 'accept', 'watch resume can be useful while still admitting a possible gap'),
        schema_case('livechan.reject.resume-as-lossless', 'ST-LIVECHAN', live_lossless_resume, 'reject', 'resume hints do not prove lossless continuity'),
        schema_case('livechan.reject.claims-effect-success', 'ST-LIVECHAN', live_claims_effect, 'reject', 'channel fate must not claim effect success'),
        schema_case('livechan.reject.drain-started-without-deadline', 'ST-LIVECHAN', live_no_deadline, 'reject', 'started channel drains need a deadline or explicit deadline-unknown state'),
        schema_case('livechan.reject.raw-bearer', 'ST-LIVECHAN', live_secret, 'reject', 'live-channel packets must not carry raw bearer material'),
        schema_case('livechan.reject.duplicate-json-key', 'ST-LIVECHAN', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-LIVECHAN v0","schema":"ST-LIVECHAN v0","witness_id":"wit_livechan00000001","live_channel_ref":"channel/http2-conn-7","channel_kind":"http2","holder_ref":"holder/proxy-gw-1","layer":"connection","channel_state":"open","freshness":{"source_vantage":"vantage/proxy-gw-1","observed_at_ms":1,"state":"fresh"},"basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-route-authority","not-custody","not-work-completion","not-effect-success","not-lossless-continuity"]}'),

        flow_case('chanflow.accept.route-moved-old-channel-drains', [
            {'event': 'traffic_binding', 'witness': no_new},
            {'event': 'live_channel', 'witness': live},
            {'event': 'traffic_binding', 'witness': {**tbind, 'witness_id': 'wit_tbind00000000004', 'revision_ref': 'revision/demo-web-r2'}},
        ], 'accept', 'new-demand route movement and old live-channel drain coexist without collapsing truths'),
        flow_case('chanflow.reject.binding-implies-readiness', [
            {'event': 'traffic_binding', 'witness': tbind, 'implies_ready': True},
        ], 'reject', 'traffic binding event cannot be promoted into readiness'),
        flow_case('chanflow.reject.no-new-work-implies-no-live-channels', [
            {'event': 'traffic_binding', 'witness': no_new},
            {'event': 'live_channel', 'witness': live},
            {'event': 'assert_no_live_channels', 'traffic_surface_ref': 'surface/public-http'},
        ], 'reject', 'no-new-work binding does not prove existing channels are gone'),
        flow_case('chanflow.accept.no-new-work-with-live-drain', [
            {'event': 'traffic_binding', 'witness': no_new},
            {'event': 'live_channel', 'witness': live},
        ], 'accept', 'route drain and live-channel drain are adjacent witnesses, not contradictions'),
        flow_case('chanflow.reject.channel-effect-without-boundary', [
            {'event': 'live_channel', 'witness': live, 'claims_effect_success': True, 'effect_ref': 'effect/payment-1'},
        ], 'reject', 'live-channel survival or closure cannot settle external effect success'),
        flow_case('chanflow.accept.effect-boundary-separate-from-channel', [
            {'event': 'traffic_binding', 'witness': no_new},
            {'event': 'live_channel', 'witness': live},
            {'event': 'effect_boundary', 'effect_ref': 'effect/payment-1'},
        ], 'accept', 'effect boundary may coexist with channel witness but remains a different proof object'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        if case['object_kind'] == 'ST-TBIND':
            validate_st_tbind(obj)
        elif case['object_kind'] == 'ST-LIVECHAN':
            validate_st_livechan(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        bindings: dict[str, dict[str, Any]] = {}
        live_channels: dict[str, dict[str, Any]] = {}
        effect_boundaries: set[str] = set()
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'traffic_binding':
                witness = validate_st_tbind(ev['witness'])
                if ev.get('implies_ready') or ev.get('implies_serving') or ev.get('claims_rollout_settlement'):
                    fail(f'{where}: binding promoted to stronger lifecycle truth')
                bindings[witness['witness_id']] = witness
            elif kind == 'live_channel':
                witness = validate_st_livechan(ev['witness'])
                if ev.get('implies_ready') or ev.get('implies_route_authority'):
                    fail(f'{where}: live channel promoted to stronger lifecycle truth')
                if ev.get('claims_effect_success') and ev.get('effect_ref') not in effect_boundaries:
                    fail(f'{where}: live channel claims effect success without boundary')
                binding_ref = witness.get('route_binding_ref')
                if binding_ref and binding_ref.startswith('wit_') and binding_ref not in bindings:
                    fail(f'{where}: live channel references unseen route binding')
                live_channels[witness['live_channel_ref']] = witness
            elif kind == 'assert_no_live_channels':
                surface = ev.get('traffic_surface_ref')
                require_pattern(surface, REF_RE, f'{where}.traffic_surface_ref')
                still_live = [ch['live_channel_ref'] for ch in live_channels.values() if ch.get('traffic_surface_ref') == surface and ch['channel_state'] in {'open', 'draining', 'closing', 'resumed'}]
                if still_live:
                    fail(f'{where}: existing live channels remain {still_live}')
            elif kind == 'effect_boundary':
                require_pattern(ev.get('effect_ref'), REF_RE, f'{where}.effect_ref')
                effect_boundaries.add(ev['effect_ref'])
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        case_id = case.get('case_id')
        if not isinstance(case_id, str) or not case_id:
            failures.append('case without valid case_id')
            continue
        if case_id in seen:
            failures.append(f'{case_id}: duplicate case_id')
            continue
        seen.add(case_id)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'channel_binding_flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{case_id}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{case_id}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-channel-binding-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic channel/binding corpus')
    ap.add_argument('--check', action='store_true', help='check channel/binding corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-channel-binding-corpus] FAIL: corpus is stale; run tools/steward_channel_binding_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-channel-binding-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
