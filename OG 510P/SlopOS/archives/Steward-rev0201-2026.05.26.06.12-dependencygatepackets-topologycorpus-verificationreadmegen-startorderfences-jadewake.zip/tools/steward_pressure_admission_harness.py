#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/pressure-admission-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
PRESSURE_RE = re.compile(r'^pressure_[a-z0-9]{16}$')
HEADROOM_RE = re.compile(r'^headroom_[a-z0-9]{16}$')
BACKPRESS_RE = re.compile(r'^backpress_[a-z0-9]{16}$')
ADMGATE_RE = re.compile(r'^admgate_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'policy', 'scheduler', 'auditor'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

PRESSURE_REQUIRED = COMMON_REQUIRED | {
    'pressure_id', 'scope_ref', 'resource_class', 'pressure_signal', 'pressure_level',
    'window_ms', 'measured_at_ms', 'expires_at_ms', 'stall_percent_basis', 'reclaim_advice', 'reason',
}
PRESSURE_ALLOWED = PRESSURE_REQUIRED | COMMON_OPTIONAL
RESOURCE_CLASSES = {'cpu', 'memory', 'io', 'network', 'storage', 'queue', 'scheduler', 'composite', 'unknown'}
PRESSURE_SIGNALS = {'stall', 'saturation', 'quota', 'latency', 'reclaim', 'adapter', 'operator', 'unknown'}
PRESSURE_LEVELS = {'normal', 'some', 'full', 'warning', 'critical', 'unknown'}
RECLAIM_ADVICE = {'none', 'trim_optional', 'avoid_new_work', 'shed_optional', 'operator_review', 'unknown'}
PRESSURE_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-readiness', 'not-serving', 'not-failure',
    'not-admission', 'not-backpressure', 'not-headroom', 'not-execution', 'not-effect-success',
}

HEADROOM_REQUIRED = COMMON_REQUIRED | {
    'headroom_id', 'scope_ref', 'budget_class', 'window_state', 'ceiling', 'used', 'remaining',
    'spendable_now', 'resets_at_ms', 'manual_clear_required', 'limiting_reason',
}
HEADROOM_ALLOWED = HEADROOM_REQUIRED | COMMON_OPTIONAL
BUDGET_CLASSES = {'restart', 'rate_limit', 'quota', 'concurrency', 'seat', 'token_bucket', 'operator_window', 'unknown'}
WINDOW_STATES = {'open', 'exhausted', 'closed', 'reset_pending', 'manual_clear_required', 'unknown'}
HEADROOM_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-approval', 'not-reservation', 'not-retry-grant',
    'not-admission', 'not-readiness', 'not-serving', 'not-execution', 'not-effect-success',
}

BACKPRESS_REQUIRED = COMMON_REQUIRED | {
    'backpressure_id', 'scope_ref', 'admission_class', 'backpressure_state', 'new_work_policy',
    'pressure_refs', 'headroom_refs', 'retry_after_ms', 'queue_class', 'started_at_ms',
    'expires_at_ms', 'reason',
}
BACKPRESS_ALLOWED = BACKPRESS_REQUIRED | COMMON_OPTIONAL
ADMISSION_CLASSES = {'http', 'rpc', 'message', 'timer', 'callback', 'operator_action', 'background', 'unknown'}
BACKPRESSURE_STATES = {'none', 'queueing', 'defer', 'shed', 'reject', 'pushback', 'unknown'}
NEW_WORK_POLICIES = {'accept', 'pace', 'queue', 'defer', 'shed', 'reject', 'unknown'}
BACKPRESS_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-demand', 'not-custody', 'not-work-completion',
    'not-readiness', 'not-serving', 'not-retry-reservation', 'not-execution', 'not-effect-success',
}

ADMGATE_REQUIRED = COMMON_REQUIRED | {
    'admission_gate_id', 'request_ref', 'scope_ref', 'decision_state', 'decision_basis',
    'pressure_refs', 'headroom_refs', 'backpressure_refs', 'decided_at_ms', 'expires_at_ms',
    'followup_demand_ref', 'reason',
}
ADMGATE_ALLOWED = ADMGATE_REQUIRED | COMMON_OPTIONAL
DECISION_STATES = {'allow', 'queue', 'defer', 'shed', 'reject', 'unknown'}
DECISION_BASES = {'pressure', 'headroom', 'backpressure', 'policy', 'operator', 'mixed', 'unknown'}
ADMGATE_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-approval', 'not-demand', 'not-custody',
    'not-work-completion', 'not-readiness', 'not-serving', 'not-execution', 'not-effect-success',
}

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_authorized', 'claims_authorization', 'claims_approval',
    'claims_current', 'claims_current_state', 'claims_fresh', 'claims_ready', 'claims_readiness',
    'claims_serving', 'claims_failure', 'claims_failed', 'claims_stopped', 'claims_admitted',
    'claims_admission', 'claims_demand', 'claims_custody', 'claims_work_complete',
    'claims_effect_success', 'claims_execution', 'claims_mutation', 'claims_policy',
    'claims_reserved', 'claims_retry_grant', 'claims_retry_success', 'claims_autoscale',
    'claims_repair', 'claims_incident', 'claims_stable', 'claims_success', 'authority',
    'authorized', 'approved', 'current_state', 'current', 'fresh', 'ready', 'readiness',
    'serving', 'failure', 'failed', 'stopped', 'admitted', 'admission', 'demand', 'custody',
    'work_complete', 'effect_success', 'execution', 'mutation', 'policy_authority',
    'reservation', 'retry_grant', 'autoscale', 'repair_action', 'incident', 'success',
    'stable', 'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle', 'raw_text',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie', 'authorization',
    'value', 'path', 'raw_path', 'host_path', 'endpoint', 'raw_endpoint', 'url', 'uri',
    'fd', 'descriptor_number', 'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path',
    'systemd_unit', 'host_unit', 'pod_name', 'container_id', 'node_name', 'process_name',
    'pty_name', 'shell_job', 'pane_text', 'command_text', 'k8s_resource_name',
}
AMBIENT_REFS = {'ambient', 'current', 'pane:current', 'terminal:current', 'component:current', 'budget:current', 'pressure:current'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:', '/var/', '/proc/', '/tmp/',
        'pressure proves failure', 'headroom is authority', 'quota authorizes', 'retry reservation',
        'admission proves demand', 'shed means completed', 'backpressure proves not serving',
        'safe to execute', 'autoscale now', 'incident resolved', 'effect success',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False, regex: re.Pattern[str] = REF_RE) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_pattern(item, regex, f'{path}[{idx}]')
        if item in AMBIENT_REFS:
            fail(f'{path}[{idx}]: must be exact ref, not ambient/current context')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_ref(value: Any, path: str, *, allow_none: bool = False, regex: re.Pattern[str] = REF_RE) -> None:
    require_pattern(value, regex, path)
    if value in AMBIENT_REFS:
        fail(f'{path}: must be exact ref, not ambient/current context')
    if not allow_none and value == 'none':
        fail(f'{path}: none is not allowed here')


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=32))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=32)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_pressure(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, PRESSURE_ALLOWED, PRESSURE_REQUIRED, 'ST-PRESSURE v0')
    require_pattern(obj['pressure_id'], PRESSURE_RE, '$.pressure_id')
    require_ref(obj['scope_ref'], '$.scope_ref')
    if obj['resource_class'] not in RESOURCE_CLASSES:
        fail('$.resource_class: invalid')
    if obj['pressure_signal'] not in PRESSURE_SIGNALS:
        fail('$.pressure_signal: invalid')
    if obj['pressure_level'] not in PRESSURE_LEVELS:
        fail('$.pressure_level: invalid')
    require_int(obj['window_ms'], '$.window_ms', minimum=0, maximum=86_400_000)
    require_int(obj['measured_at_ms'], '$.measured_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['stall_percent_basis'], '$.stall_percent_basis', minimum=0, maximum=10000)
    if obj['reclaim_advice'] not in RECLAIM_ADVICE:
        fail('$.reclaim_advice: invalid')
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], PRESSURE_NON_IMPLICATIONS, '$.non_implications')
    if obj['expires_at_ms'] <= obj['observed_at_ms'] and obj['pressure_level'] != 'unknown':
        fail('$.expires_at_ms: known pressure witness is already stale')
    if obj['pressure_level'] in {'normal', 'unknown'} and obj['reclaim_advice'] not in {'none', 'unknown'}:
        fail('$.reclaim_advice: calm/unknown pressure cannot carry reclaim advice')
    return obj


def validate_headroom(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, HEADROOM_ALLOWED, HEADROOM_REQUIRED, 'ST-HEADROOM v0')
    require_pattern(obj['headroom_id'], HEADROOM_RE, '$.headroom_id')
    require_ref(obj['scope_ref'], '$.scope_ref')
    if obj['budget_class'] not in BUDGET_CLASSES:
        fail('$.budget_class: invalid')
    if obj['window_state'] not in WINDOW_STATES:
        fail('$.window_state: invalid')
    require_int(obj['ceiling'], '$.ceiling', minimum=0, maximum=10_000_000_000)
    require_int(obj['used'], '$.used', minimum=0, maximum=10_000_000_000)
    require_int(obj['remaining'], '$.remaining', minimum=0, maximum=10_000_000_000)
    require_bool(obj['spendable_now'], '$.spendable_now')
    require_int(obj['resets_at_ms'], '$.resets_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_bool(obj['manual_clear_required'], '$.manual_clear_required')
    require_text(obj['limiting_reason'], '$.limiting_reason')
    require_non_implications(obj['non_implications'], HEADROOM_NON_IMPLICATIONS, '$.non_implications')
    if obj['budget_class'] != 'unknown':
        if obj['used'] > obj['ceiling']:
            fail('$.used: cannot exceed ceiling')
        if obj['remaining'] != obj['ceiling'] - obj['used']:
            fail('$.remaining: must equal ceiling minus used for known budgets')
    if obj['spendable_now'] and (obj['remaining'] <= 0 or obj['window_state'] != 'open' or obj['manual_clear_required']):
        fail('$.spendable_now: requires positive remaining, open window, and no manual clear requirement')
    if obj['window_state'] == 'exhausted' and obj['remaining'] != 0:
        fail('$.window_state: exhausted requires zero remaining')
    return obj


def validate_backpress(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, BACKPRESS_ALLOWED, BACKPRESS_REQUIRED, 'ST-BACKPRESS v0')
    require_pattern(obj['backpressure_id'], BACKPRESS_RE, '$.backpressure_id')
    require_ref(obj['scope_ref'], '$.scope_ref')
    if obj['admission_class'] not in ADMISSION_CLASSES:
        fail('$.admission_class: invalid')
    if obj['backpressure_state'] not in BACKPRESSURE_STATES:
        fail('$.backpressure_state: invalid')
    if obj['new_work_policy'] not in NEW_WORK_POLICIES:
        fail('$.new_work_policy: invalid')
    pressure_refs = require_refs(obj['pressure_refs'], '$.pressure_refs', maximum=16, allow_empty=True)
    headroom_refs = require_refs(obj['headroom_refs'], '$.headroom_refs', maximum=16, allow_empty=True)
    require_int(obj['retry_after_ms'], '$.retry_after_ms', minimum=0, maximum=86_400_000)
    require_text(obj['queue_class'], '$.queue_class')
    require_int(obj['started_at_ms'], '$.started_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], BACKPRESS_NON_IMPLICATIONS, '$.non_implications')
    if obj['expires_at_ms'] <= obj['observed_at_ms'] and obj['backpressure_state'] != 'unknown':
        fail('$.expires_at_ms: active backpressure witness is already stale')
    if obj['backpressure_state'] == 'none' and obj['new_work_policy'] != 'accept':
        fail('$.new_work_policy: none backpressure must accept or be unknown')
    if obj['backpressure_state'] in {'defer', 'pushback'} and obj['retry_after_ms'] == 0:
        fail('$.retry_after_ms: defer/pushback needs a retry-later hint')
    if obj['backpressure_state'] != 'none' and not (pressure_refs or headroom_refs):
        fail('$.pressure_refs/$.headroom_refs: non-none backpressure needs pressure or headroom basis')
    return obj


def validate_admgate(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ADMGATE_ALLOWED, ADMGATE_REQUIRED, 'ST-ADMGATE v0')
    require_pattern(obj['admission_gate_id'], ADMGATE_RE, '$.admission_gate_id')
    require_ref(obj['request_ref'], '$.request_ref')
    require_ref(obj['scope_ref'], '$.scope_ref')
    if obj['decision_state'] not in DECISION_STATES:
        fail('$.decision_state: invalid')
    if obj['decision_basis'] not in DECISION_BASES:
        fail('$.decision_basis: invalid')
    pressure_refs = require_refs(obj['pressure_refs'], '$.pressure_refs', maximum=16, allow_empty=True)
    headroom_refs = require_refs(obj['headroom_refs'], '$.headroom_refs', maximum=16, allow_empty=True)
    backpressure_refs = require_refs(obj['backpressure_refs'], '$.backpressure_refs', maximum=16, allow_empty=True)
    require_int(obj['decided_at_ms'], '$.decided_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_ref(obj['followup_demand_ref'], '$.followup_demand_ref', allow_none=True)
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], ADMGATE_NON_IMPLICATIONS, '$.non_implications')
    if obj['expires_at_ms'] <= obj['decided_at_ms'] and obj['decision_state'] != 'unknown':
        fail('$.expires_at_ms: non-unknown gate decision expires before it can be acted on')
    if obj['decision_basis'] in {'pressure', 'headroom', 'backpressure', 'mixed'} and not (pressure_refs or headroom_refs or backpressure_refs):
        fail('$.decision_basis: basis refs required')
    if obj['decision_state'] in {'queue', 'defer', 'shed', 'reject'} and not (pressure_refs or headroom_refs or backpressure_refs):
        fail('$.decision_state: non-allow decision needs pressure/headroom/backpressure basis')
    if obj['decision_state'] != 'allow' and obj['followup_demand_ref'] != 'none':
        fail('$.followup_demand_ref: only allow may cite a separate demand witness')
    return obj


VALIDATORS = {
    'ST-PRESSURE': validate_pressure,
    'ST-HEADROOM': validate_headroom,
    'ST-BACKPRESS': validate_backpress,
    'ST-ADMGATE': validate_admgate,
}


def validate_packet(obj: Any) -> dict[str, Any]:
    if not isinstance(obj, dict):
        fail('packet is not object')
    schema = obj.get('schema')
    if schema == 'ST-PRESSURE v0':
        return validate_pressure(obj)
    if schema == 'ST-HEADROOM v0':
        return validate_headroom(obj)
    if schema == 'ST-BACKPRESS v0':
        return validate_backpress(obj)
    if schema == 'ST-ADMGATE v0':
        return validate_admgate(obj)
    fail(f'unknown schema {schema!r}')


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    return {'id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why, 'object': obj, 'json_text': json_text}


def flow_case(case_id: str, packets: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'id': case_id, 'kind': 'flow', 'expect': expect, 'why': why, 'packets': packets}


def base_common(schema: str, witness_id: str, observed: int = 3000, issuer_kind: str = 'steward') -> dict[str, Any]:
    return {
        'schema': schema,
        'witness_id': witness_id,
        'cid': 'demo.web',
        'issuer': {'kind': issuer_kind, 'id': f'steward.{issuer_kind}'},
        'observed_at_ms': observed,
        'basis_refs': ['sha256:' + '3' * 64],
    }


def build_cases() -> list[dict[str, Any]]:
    pressure = {
        **base_common('ST-PRESSURE v0', 'wit_a100000000000001'),
        'pressure_id': 'pressure_1000000000000001',
        'scope_ref': 'scope/demo.web/runtime',
        'resource_class': 'memory',
        'pressure_signal': 'stall',
        'pressure_level': 'warning',
        'window_ms': 10000,
        'measured_at_ms': 2990,
        'expires_at_ms': 3400,
        'stall_percent_basis': 420,
        'reclaim_advice': 'avoid_new_work',
        'reason': 'memory stall above warning threshold',
        'non_implications': sorted(PRESSURE_NON_IMPLICATIONS),
    }
    normal_pressure = {**pressure, 'witness_id': 'wit_a100000000000002', 'pressure_id': 'pressure_1000000000000002', 'pressure_level': 'normal', 'stall_percent_basis': 0, 'reclaim_advice': 'none', 'reason': 'normal pressure observation'}
    expired_pressure = {**pressure, 'witness_id': 'wit_a100000000000003', 'pressure_id': 'pressure_1000000000000003', 'expires_at_ms': 2999}

    headroom_open = {
        **base_common('ST-HEADROOM v0', 'wit_b100000000000001'),
        'headroom_id': 'headroom_1000000000000001',
        'scope_ref': 'budget/demo.web/restarts',
        'budget_class': 'restart',
        'window_state': 'open',
        'ceiling': 5,
        'used': 2,
        'remaining': 3,
        'spendable_now': True,
        'resets_at_ms': 60000,
        'manual_clear_required': False,
        'limiting_reason': 'none',
        'non_implications': sorted(HEADROOM_NON_IMPLICATIONS),
    }
    headroom_exhausted = {
        **headroom_open,
        'witness_id': 'wit_b100000000000002',
        'headroom_id': 'headroom_1000000000000002',
        'window_state': 'exhausted',
        'used': 5,
        'remaining': 0,
        'spendable_now': False,
        'limiting_reason': 'restart budget exhausted',
    }
    bad_headroom_math = {**headroom_open, 'witness_id': 'wit_b100000000000003', 'headroom_id': 'headroom_1000000000000003', 'remaining': 4}

    backpress = {
        **base_common('ST-BACKPRESS v0', 'wit_c100000000000001'),
        'backpressure_id': 'backpress_1000000000000001',
        'scope_ref': 'admission/demo.web/http',
        'admission_class': 'http',
        'backpressure_state': 'pushback',
        'new_work_policy': 'defer',
        'pressure_refs': ['pressure_1000000000000001'],
        'headroom_refs': ['headroom_1000000000000002'],
        'retry_after_ms': 1500,
        'queue_class': 'public requests',
        'started_at_ms': 3000,
        'expires_at_ms': 3600,
        'reason': 'defer new requests until pressure clears',
        'non_implications': sorted(BACKPRESS_NON_IMPLICATIONS),
    }
    backpress_none = {**backpress, 'witness_id': 'wit_c100000000000002', 'backpressure_id': 'backpress_1000000000000002', 'backpressure_state': 'none', 'new_work_policy': 'accept', 'pressure_refs': [], 'headroom_refs': [], 'retry_after_ms': 0, 'queue_class': 'none', 'reason': 'no pacing active'}
    backpress_bad_no_basis = {**backpress, 'witness_id': 'wit_c100000000000003', 'backpressure_id': 'backpress_1000000000000003', 'pressure_refs': [], 'headroom_refs': []}

    gate_defer = {
        **base_common('ST-ADMGATE v0', 'wit_d100000000000001'),
        'admission_gate_id': 'admgate_1000000000000001',
        'request_ref': 'request/demo.web/0001',
        'scope_ref': 'admission/demo.web/http',
        'decision_state': 'defer',
        'decision_basis': 'mixed',
        'pressure_refs': ['pressure_1000000000000001'],
        'headroom_refs': ['headroom_1000000000000002'],
        'backpressure_refs': ['backpress_1000000000000001'],
        'decided_at_ms': 3010,
        'expires_at_ms': 3400,
        'followup_demand_ref': 'none',
        'reason': 'deferred by active pushback',
        'non_implications': sorted(ADMGATE_NON_IMPLICATIONS),
    }
    gate_allow = {
        **gate_defer,
        'witness_id': 'wit_d100000000000002',
        'admission_gate_id': 'admgate_1000000000000002',
        'decision_state': 'allow',
        'decision_basis': 'headroom',
        'pressure_refs': [],
        'headroom_refs': ['headroom_1000000000000001'],
        'backpressure_refs': [],
        'followup_demand_ref': 'demand_1000000000001',
        'reason': 'allowed by open headroom but demand is separate',
    }
    gate_shed = {**gate_defer, 'witness_id': 'wit_d100000000000003', 'admission_gate_id': 'admgate_1000000000000003', 'decision_state': 'shed', 'reason': 'shed optional work'}

    return [
        schema_case('pressure.accept.warning-memory', 'ST-PRESSURE', pressure, 'accept', 'pressure can report scoped resource strain without failure, readiness, serving, admission, or mutation claims'),
        schema_case('pressure.accept.normal', 'ST-PRESSURE', normal_pressure, 'accept', 'normal pressure is still only an observation and carries no reclaim advice'),
        schema_case('pressure.reject.failure-flattery', 'ST-PRESSURE', {**pressure, 'claims_failure': True}, 'reject', 'pressure is not failure or stopped-state truth'),
        schema_case('pressure.reject.stale-known-pressure', 'ST-PRESSURE', expired_pressure, 'reject', 'known pressure must not be accepted after its freshness window has expired'),
        schema_case('pressure.reject.normal-with-reclaim', 'ST-PRESSURE', {**normal_pressure, 'reclaim_advice': 'avoid_new_work'}, 'reject', 'calm pressure cannot smuggle adaptation advice'),
        schema_case('headroom.accept.open-restart-budget', 'ST-HEADROOM', headroom_open, 'accept', 'open headroom reports spendability without approval, reservation, retry grant, or execution'),
        schema_case('headroom.accept.exhausted-budget', 'ST-HEADROOM', headroom_exhausted, 'accept', 'exhausted headroom explains a limit without becoming denial authority by itself'),
        schema_case('headroom.reject.authority-flattery', 'ST-HEADROOM', {**headroom_open, 'claims_authorization': True}, 'reject', 'headroom is not authority or approval'),
        schema_case('headroom.reject.math-drift', 'ST-HEADROOM', bad_headroom_math, 'reject', 'known headroom must keep ceiling, used, and remaining consistent'),
        schema_case('headroom.reject.spendable-with-zero', 'ST-HEADROOM', {**headroom_exhausted, 'spendable_now': True}, 'reject', 'zero remaining cannot be spendable now'),
        schema_case('backpress.accept.pushback', 'ST-BACKPRESS', backpress, 'accept', 'backpressure can defer new work with retry advice without creating a lease or demand episode'),
        schema_case('backpress.accept.none', 'ST-BACKPRESS', backpress_none, 'accept', 'no backpressure is still scoped admission posture, not readiness or serving'),
        schema_case('backpress.reject.retry-reservation-flattery', 'ST-BACKPRESS', {**backpress, 'claims_reserved': True}, 'reject', 'retry-after style pacing is not a reservation'),
        schema_case('backpress.reject.no-basis', 'ST-BACKPRESS', backpress_bad_no_basis, 'reject', 'non-none backpressure needs pressure or headroom basis'),
        schema_case('backpress.reject.deferred-without-retry-after', 'ST-BACKPRESS', {**backpress, 'retry_after_ms': 0}, 'reject', 'defer/pushback needs a retry-later hint when known'),
        schema_case('admgate.accept.defer', 'ST-ADMGATE', gate_defer, 'accept', 'admission gate can defer without becoming demand, custody, work completion, serving, or effect truth'),
        schema_case('admgate.accept.allow-with-separate-demand-ref', 'ST-ADMGATE', gate_allow, 'accept', 'allow can cite a separate demand witness but still is not that demand witness'),
        schema_case('admgate.reject.demand-flattery', 'ST-ADMGATE', {**gate_allow, 'claims_demand': True}, 'reject', 'admission gate is not demand acceptance'),
        schema_case('admgate.reject.nonallow-with-demand-ref', 'ST-ADMGATE', {**gate_shed, 'followup_demand_ref': 'demand_1000000000001'}, 'reject', 'shed/defer/reject gates cannot cite a followup demand as if work was accepted'),
        schema_case('admgate.reject.duplicate-json-key', 'ST-ADMGATE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-ADMGATE v0","schema":"ST-ADMGATE v0","witness_id":"wit_d100000000000004","cid":"demo.web","issuer":{"kind":"steward","id":"steward.core"},"observed_at_ms":3000,"basis_refs":["sha256:3333333333333333333333333333333333333333333333333333333333333333"],"non_implications":[],"admission_gate_id":"admgate_1000000000000004","request_ref":"request/demo.web/0004","scope_ref":"admission/demo.web/http","decision_state":"defer","decision_basis":"mixed","pressure_refs":[],"headroom_refs":[],"backpressure_refs":[],"decided_at_ms":3010,"expires_at_ms":3400,"followup_demand_ref":"none","reason":"duplicate"}'),

        flow_case('pressure-admission.accept.defer-under-pressure', [pressure, headroom_exhausted, backpress, gate_defer], 'accept', 'pressure, exhausted headroom, backpressure, and admission deferral stay ordered and weak'),
        flow_case('pressure-admission.accept.allow-with-headroom', [normal_pressure, headroom_open, backpress_none, gate_allow], 'accept', 'open headroom can support allow while demand remains a separate witness'),
        flow_case('pressure-admission.reject.allow-with-exhausted-headroom', [pressure, headroom_exhausted, {**gate_allow, 'headroom_refs': ['headroom_1000000000000002']}], 'reject', 'gate allow cannot rely on an exhausted headroom witness'),
        flow_case('pressure-admission.reject.allow-under-reject-backpressure', [backpress, {**gate_allow, 'backpressure_refs': ['backpress_1000000000000001'], 'decision_basis': 'backpressure'}], 'reject', 'gate allow cannot cite active pushback/reject backpressure without contradiction'),
        flow_case('pressure-admission.reject.shed-as-effect-success', [pressure, headroom_exhausted, backpress, {**gate_shed, 'claims_effect_success': True}], 'reject', 'shedding or deferring new work is not effect success or work completion'),
        flow_case('pressure-admission.reject.duplicate-gate-id-drift', [gate_defer, {**gate_defer, 'witness_id': 'wit_d100000000000005', 'reason': 'same gate id with different bytes'}], 'reject', 'admission gate ids cannot be reused for different canonical bytes'),
    ]


def validate_flow(packets: list[dict[str, Any]]) -> None:
    ids: dict[str, dict[str, Any]] = {}
    by_schema: dict[str, list[dict[str, Any]]] = {}
    canonical_by_domain_id: dict[tuple[str, str], str] = {}
    for idx, packet in enumerate(packets):
        obj = validate_packet(packet)
        schema = obj['schema'].removesuffix(' v0')
        by_schema.setdefault(schema, []).append(obj)
        ids[obj['witness_id']] = obj
        if schema == 'ST-PRESSURE':
            domain_id = obj['pressure_id']
        elif schema == 'ST-HEADROOM':
            domain_id = obj['headroom_id']
        elif schema == 'ST-BACKPRESS':
            domain_id = obj['backpressure_id']
        elif schema == 'ST-ADMGATE':
            domain_id = obj['admission_gate_id']
        else:
            domain_id = obj['witness_id']
        key = (schema, domain_id)
        raw = json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
        prior = canonical_by_domain_id.get(key)
        if prior is not None and prior != raw:
            fail(f'packet {idx}: duplicate {schema} domain id with different canonical bytes')
        canonical_by_domain_id[key] = raw

    pressures = {p['pressure_id']: p for p in by_schema.get('ST-PRESSURE', [])}
    headrooms = {h['headroom_id']: h for h in by_schema.get('ST-HEADROOM', [])}
    backpressures = {b['backpressure_id']: b for b in by_schema.get('ST-BACKPRESS', [])}

    for bp in by_schema.get('ST-BACKPRESS', []):
        for ref in bp['pressure_refs']:
            if ref not in pressures:
                fail(f'backpressure {bp["backpressure_id"]}: missing pressure ref {ref}')
        for ref in bp['headroom_refs']:
            if ref not in headrooms:
                fail(f'backpressure {bp["backpressure_id"]}: missing headroom ref {ref}')

    for gate in by_schema.get('ST-ADMGATE', []):
        for ref in gate['pressure_refs']:
            if ref not in pressures:
                fail(f'admission gate {gate["admission_gate_id"]}: missing pressure ref {ref}')
        for ref in gate['headroom_refs']:
            if ref not in headrooms:
                fail(f'admission gate {gate["admission_gate_id"]}: missing headroom ref {ref}')
        for ref in gate['backpressure_refs']:
            if ref not in backpressures:
                fail(f'admission gate {gate["admission_gate_id"]}: missing backpressure ref {ref}')
        if gate['decision_state'] == 'allow':
            for ref in gate['headroom_refs']:
                if not headrooms[ref]['spendable_now']:
                    fail(f'admission gate {gate["admission_gate_id"]}: allow cites non-spendable headroom {ref}')
            for ref in gate['backpressure_refs']:
                if backpressures[ref]['new_work_policy'] in {'defer', 'shed', 'reject'}:
                    fail(f'admission gate {gate["admission_gate_id"]}: allow contradicts blocking backpressure {ref}')
        if gate['decision_state'] in {'defer', 'shed', 'reject'}:
            if gate['followup_demand_ref'] != 'none':
                fail(f'admission gate {gate["admission_gate_id"]}: non-allow has followup demand')


def run_schema_case(case: dict[str, Any]) -> None:
    try:
        if case.get('json_text') is not None:
            obj = parse_json_text(case['json_text'])
        else:
            obj = case['object']
        object_kind = case['object_kind']
        validator = VALIDATORS.get(object_kind)
        if validator is None:
            fail(f'unknown object_kind {object_kind}')
        validator(obj)
        actual = 'accept'
    except Exception:
        actual = 'reject'
    if actual != case['expect']:
        fail(f"{case['id']}: expected {case['expect']} got {actual}")


def run_flow_case(case: dict[str, Any]) -> None:
    try:
        validate_flow(case['packets'])
        actual = 'accept'
    except Exception:
        actual = 'reject'
    if actual != case['expect']:
        fail(f"{case['id']}: expected {case['expect']} got {actual}")


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path = CORPUS_PATH) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    for case in cases:
        if case['id'] in seen:
            fail(f"duplicate case id {case['id']}")
        seen.add(case['id'])
        if case['kind'] == 'schema':
            run_schema_case(case)
        elif case['kind'] == 'flow':
            run_flow_case(case)
        else:
            fail(f"{case['id']}: unknown kind")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true')
    ap.add_argument('--check', action='store_true')
    args = ap.parse_args()
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    if args.write:
        CORPUS_PATH.parent.mkdir(parents=True, exist_ok=True)
        CORPUS_PATH.write_text(render_cases(build_cases()), encoding='utf-8')
        print(CORPUS_PATH)
    if args.check:
        check_cases(load_corpus())
        print('[steward_pressure_admission_harness] OK')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
