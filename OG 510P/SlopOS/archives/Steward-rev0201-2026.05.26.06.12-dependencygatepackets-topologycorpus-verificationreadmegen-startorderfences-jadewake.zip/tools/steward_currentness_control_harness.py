#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/currentness-control-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_ready', 'claims_readiness', 'claims_serving', 'claims_stopped',
    'claims_material_current', 'claims_material_use', 'claims_reload_success',
    'claims_route_authority', 'claims_rollback_complete', 'claims_remediation_success',
    'claims_incident_truth', 'claims_effect_success', 'ready', 'serving',
    'component_state', 'rollout_complete', 'work_completed', 'lossless', 'exactly_once',
    'raw_log', 'scrollback', 'token', 'secret', 'raw_secret', 'raw_token',
    'raw_handle', 'bearer', 'value', 'path', 'raw_path', 'mount_path', 'fd',
    'pid', 'ppid', 'pgid', 'cgroup', 'systemd_unit', 'pod_name',
    'container_id', 'process_name', 'host_unit', 'repair_action',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'controller', 'proxy', 'balancer', 'runtime', 'identity_provider', 'storage_provider', 'probe'}

FRESH_REQUIRED = {'source_vantage', 'observed_at_ms', 'state'}
FRESH_OPTIONAL = {'expires_or_recheck_by_ms', 'staleness_reason'}
FRESH_ALLOWED = FRESH_REQUIRED | FRESH_OPTIONAL
FRESH_STATES = {'fresh', 'last_known', 'stale', 'unknown'}

STATE_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'attachment_ref', 'attachment_kind', 'attachment_state', 'authority_class', 'observed_at_ms', 'basis_refs', 'non_implications'}
STATE_OPTIONAL = {'incarnation_id', 'runtime_cycle', 'material_ref', 'snapshot_ref', 'version_ref', 'cleanup_ref', 'detach_ref', 'freshness_ref', 'retention_class', 'lifetime_class', 'rebind_state', 'migration_state', 'expires_or_recheck_by_ms', 'unknown_reason'}
STATE_ALLOWED = STATE_REQUIRED | STATE_OPTIONAL
ATTACHMENT_KINDS = {'image_readonly', 'runtime_scratch', 'incarnation_tmp', 'component_data', 'persistent_volume', 'projected_material', 'manager_runtime_dir', 'snapshot_derived', 'external_mount', 'unknown'}
ATTACHMENT_STATES = {'attaching', 'attached', 'detaching', 'detached', 'cleanup_pending', 'cleanup_complete', 'restored', 'stale', 'unknown'}
AUTHORITY_CLASSES = {'evidence_only', 'steward_attached', 'adapter_attached', 'substrate_attached', 'external_claim', 'unknown'}
RETENTION_CLASSES = {'ephemeral', 'persistent', 'policy_retained', 'external', 'unknown'}
LIFETIME_CLASSES = {'image', 'incarnation', 'runtime_cycle', 'component', 'persistent', 'external', 'unknown'}
REBIND_STATES = {'not_needed', 'pending', 'passed', 'failed', 'unknown'}
MIGRATION_STATES = {'not_applicable', 'sticky_preferred', 'migration_started', 'migration_complete', 'migration_failed', 'unknown'}
STATE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-material-currentness', 'not-current-incarnation', 'not-custody', 'not-work-completion', 'not-effect-success', 'not-path-authority'}
STATE_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-material-currentness', 'not-custody', 'not-work-completion', 'not-effect-success', 'not-path-authority'}

MAT_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'material_ref', 'material_kind', 'material_state', 'freshness_scope', 'observed_at_ms', 'basis_refs', 'non_implications'}
MAT_OPTIONAL = {'source_vantage', 'version_ref', 'audience_ref', 'attachment_ref', 'incarnation_id', 'runtime_cycle', 'valid_after_ms', 'expires_at_ms', 'stale_after_ms', 'refresh_after_ms', 'reload_ref', 'rotation_ref', 'revocation_ref', 'unknown_reason', 'authority_digest', 'snapshot_ref'}
MAT_ALLOWED = MAT_REQUIRED | MAT_OPTIONAL
MATERIAL_KINDS = {'config', 'secret', 'token', 'trust_bundle', 'lease', 'projected_file', 'env', 'dynamic_identity', 'certificate', 'snapshot_restored', 'unknown'}
MATERIAL_STATES = {'version_pinned', 'projected', 'static_for_incarnation', 'renewable', 'fresh', 'reload_pending', 'expired', 'revoked', 'reacquire_required', 'stale', 'unknown'}
FRESHNESS_SCOPES = {'activation', 'incarnation', 'revision', 'projection', 'lease', 'trust_bundle', 'identity', 'snapshot_restore', 'external', 'unknown'}
MAT_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-attachment', 'not-material-use', 'not-reload-success', 'not-current-authority', 'not-effect-success'}
MAT_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-attachment', 'not-material-use', 'not-reload-success', 'not-current-authority', 'not-effect-success'}

PROBE_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'probe_kind', 'vantage_kind', 'vantage_ref', 'scope', 'result', 'observed_at_ms', 'freshness', 'basis_refs', 'non_implications'}
PROBE_OPTIONAL = {'target_ref', 'endpoint_ref', 'route_binding_ref', 'live_channel_ref', 'material_freshness_ref', 'incarnation_id', 'runtime_cycle', 'failure_hint', 'threshold_state', 'consecutive_failures', 'next_due_ms', 'unknown_reason'}
PROBE_ALLOWED = PROBE_REQUIRED | PROBE_OPTIONAL
PROBE_KINDS = {'startup', 'readiness', 'liveness', 'grpc_health', 'balancer', 'mesh', 'synthetic', 'outside_in', 'adapter', 'unknown'}
VANTAGE_KINDS = {'local_runtime', 'supervisor', 'proxy', 'balancer', 'mesh', 'outside_in', 'user_path', 'adapter', 'unknown'}
PROBE_SCOPES = {'process', 'port', 'endpoint', 'route', 'dependency', 'control_surface', 'user_path', 'unknown'}
PROBE_RESULTS = {'pass', 'fail', 'degraded', 'timeout', 'inconclusive', 'skipped', 'stale', 'unknown'}
FAILURE_HINTS = {'timeout', 'response_mismatch', 'transport_failed', 'auth_failed', 'dependency_failed', 'observer_error', 'identity_mismatch', 'not_registered', 'target_draining', 'probe_disabled', 'unknown'}
THRESHOLD_STATES = {'single_sample', 'below_threshold', 'threshold_met', 'cached', 'sampled', 'fail_open', 'unknown'}
PROBE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-route-authority', 'not-material-freshness', 'not-rollout-settlement', 'not-remediation-success', 'not-effect-success', 'not-incident-truth'}
PROBE_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-route-authority', 'not-rollout-settlement', 'not-remediation-success', 'not-effect-success', 'not-incident-truth'}

VERDICT_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'verdict_kind', 'subject_ref', 'verdict_state', 'effect_class', 'observed_at_ms', 'basis_refs', 'non_implications'}
VERDICT_OPTIONAL = {'scope_ref', 'probe_refs', 'material_freshness_refs', 'traffic_binding_ref', 'operation_receipt_ref', 'action_ref', 'revision_ref', 'incarnation_id', 'runtime_cycle', 'expires_or_recheck_by_ms', 'staleness_reason', 'unknown_reason', 'manual_action_hint'}
VERDICT_ALLOWED = VERDICT_REQUIRED | VERDICT_OPTIONAL
VERDICT_KINDS = {'readiness_gate', 'rollout', 'traffic', 'rollback', 'dns_health', 'deployment_circuit', 'repair', 'admission_hint', 'operator', 'unknown'}
VERDICT_STATES = {'eligible', 'withheld', 'stalled', 'failed', 'passed', 'denied', 'deferred', 'rollback_selected', 'rollback_started', 'action_required', 'inconclusive', 'unknown'}
EFFECT_CLASSES = {'report_only', 'advisory', 'gates_new_work', 'gates_traffic', 'requests_operation', 'blocks_operation', 'unknown'}
VERDICT_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-route-authority', 'not-rollback-completion', 'not-remediation-success', 'not-incident-truth', 'not-effect-success', 'not-raw-observation'}
VERDICT_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-route-authority', 'not-rollback-completion', 'not-remediation-success', 'not-incident-truth', 'not-effect-success', 'not-raw-observation'}


def scan_forbidden_keys(value: Any, forbidden: set[str], path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in forbidden:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, forbidden, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, forbidden, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered or '/var/run' in lowered:
        fail(f'{path}: raw secret/path-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_ref_field(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], REF_RE, f'{path}.{field}')


def require_cycle_field(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], CYCLE_RE, f'{path}.{field}')


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_freshness(value: Any, path: str) -> dict[str, Any]:
    freshness = require_object(value, path)
    require_closed_keys(freshness, FRESH_ALLOWED, FRESH_REQUIRED, path)
    require_pattern(freshness['source_vantage'], REF_RE, f'{path}.source_vantage')
    require_int(freshness['observed_at_ms'], f'{path}.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if freshness['state'] not in FRESH_STATES:
        fail(f'{path}.state: invalid freshness state')
    if 'expires_or_recheck_by_ms' in freshness:
        require_int(freshness['expires_or_recheck_by_ms'], f'{path}.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if freshness['expires_or_recheck_by_ms'] < freshness['observed_at_ms']:
            fail(f'{path}.expires_or_recheck_by_ms: cannot precede observed_at_ms')
    if freshness['state'] in {'stale', 'unknown'} and 'staleness_reason' not in freshness:
        fail(f'{path}.staleness_reason: stale/unknown freshness must explain downgrade')
    if 'staleness_reason' in freshness:
        require_text(freshness['staleness_reason'], f'{path}.staleness_reason')
    return freshness


def validate_non_implications(value: Any, path: str, allowed: set[str], required: set[str]) -> set[str]:
    vals = set(require_refs(value, path, maximum=16))
    invalid = sorted(vals - allowed)
    if invalid:
        fail(f'{path}: invalid values {invalid}')
    missing = sorted(required - vals)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return vals


def validate_st_stateatt(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, STATE_ALLOWED, STATE_REQUIRED, '$')
    if obj['schema'] != 'ST-STATEATT v0':
        fail('$.schema: expected ST-STATEATT v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['attachment_ref'], REF_RE, '$.attachment_ref')
    if obj['attachment_kind'] not in ATTACHMENT_KINDS:
        fail('$.attachment_kind: invalid attachment kind')
    if obj['attachment_state'] not in ATTACHMENT_STATES:
        fail('$.attachment_state: invalid attachment state')
    if obj['authority_class'] not in AUTHORITY_CLASSES:
        fail('$.authority_class: invalid authority class')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail('$.expires_or_recheck_by_ms: cannot precede observed_at_ms')
    if obj['attachment_kind'] == 'projected_material' and 'material_ref' not in obj:
        fail('$.material_ref: projected material attachment needs material_ref')
    if obj['attachment_state'] in {'attached', 'restored'} and 'runtime_cycle' not in obj and 'incarnation_id' not in obj:
        fail('$.runtime_cycle: attached/restored state needs runtime_cycle or incarnation_id fence')
    if obj['attachment_state'] in {'stale', 'unknown'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: stale/unknown attachment needs reason')
    if 'retention_class' in obj and obj['retention_class'] not in RETENTION_CLASSES:
        fail('$.retention_class: invalid retention class')
    if 'lifetime_class' in obj and obj['lifetime_class'] not in LIFETIME_CLASSES:
        fail('$.lifetime_class: invalid lifetime class')
    if 'rebind_state' in obj and obj['rebind_state'] not in REBIND_STATES:
        fail('$.rebind_state: invalid rebind state')
    if 'migration_state' in obj and obj['migration_state'] not in MIGRATION_STATES:
        fail('$.migration_state: invalid migration state')
    if obj['attachment_kind'] == 'snapshot_derived' and obj.get('rebind_state') not in {'pending', 'passed', 'failed', 'unknown'}:
        fail('$.rebind_state: snapshot-derived attachment needs explicit rebind state')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', STATE_NON_IMPLICATIONS, STATE_BASE_NON_IMPLICATIONS)
    for field in ('incarnation_id', 'material_ref', 'snapshot_ref', 'version_ref', 'cleanup_ref', 'detach_ref', 'freshness_ref'):
        require_ref_field(obj, field, '$')
    require_cycle_field(obj, 'runtime_cycle', '$')
    return obj


def validate_st_matfresh(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, MAT_ALLOWED, MAT_REQUIRED, '$')
    if obj['schema'] != 'ST-MATFRESH v0':
        fail('$.schema: expected ST-MATFRESH v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['material_ref'], REF_RE, '$.material_ref')
    if obj['material_kind'] not in MATERIAL_KINDS:
        fail('$.material_kind: invalid material kind')
    if obj['material_state'] not in MATERIAL_STATES:
        fail('$.material_state: invalid material state')
    if obj['freshness_scope'] not in FRESHNESS_SCOPES:
        fail('$.freshness_scope: invalid freshness scope')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    for field in ('valid_after_ms', 'expires_at_ms', 'stale_after_ms', 'refresh_after_ms'):
        if field in obj:
            require_int(obj[field], f'$.{field}', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'valid_after_ms' in obj and obj['valid_after_ms'] > obj['observed_at_ms'] and obj['material_state'] in {'fresh', 'renewable', 'projected'}:
        fail('$.valid_after_ms: future-valid material cannot be marked fresh/projected/renewable yet')
    if 'expires_at_ms' in obj and obj['material_state'] in {'fresh', 'renewable', 'projected', 'version_pinned'} and obj['expires_at_ms'] <= obj['observed_at_ms']:
        fail('$.expires_at_ms: current material cannot already be expired')
    if obj['material_state'] == 'expired':
        if 'expires_at_ms' not in obj:
            fail('$.expires_at_ms: expired material needs expiry evidence')
        if obj['expires_at_ms'] > obj['observed_at_ms']:
            fail('$.expires_at_ms: expired material has future expiry')
    if obj['material_state'] in {'expired', 'revoked', 'reacquire_required', 'stale', 'unknown'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: degraded material freshness needs reason')
    if obj['material_state'] == 'revoked' and 'revocation_ref' not in obj:
        fail('$.revocation_ref: revoked material needs revocation evidence')
    if obj['material_state'] == 'reload_pending' and 'reload_ref' not in obj:
        fail('$.reload_ref: reload-pending material needs reload evidence ref')
    if 'authority_digest' in obj:
        require_pattern(obj['authority_digest'], DIGEST_RE, '$.authority_digest')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', MAT_NON_IMPLICATIONS, MAT_BASE_NON_IMPLICATIONS)
    for field in ('source_vantage', 'version_ref', 'audience_ref', 'attachment_ref', 'incarnation_id', 'reload_ref', 'rotation_ref', 'revocation_ref', 'snapshot_ref'):
        require_ref_field(obj, field, '$')
    require_cycle_field(obj, 'runtime_cycle', '$')
    return obj


def validate_st_probe(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, PROBE_ALLOWED, PROBE_REQUIRED, '$')
    if obj['schema'] != 'ST-PROBE v0':
        fail('$.schema: expected ST-PROBE v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['probe_kind'] not in PROBE_KINDS:
        fail('$.probe_kind: invalid probe kind')
    if obj['vantage_kind'] not in VANTAGE_KINDS:
        fail('$.vantage_kind: invalid vantage kind')
    require_pattern(obj['vantage_ref'], REF_RE, '$.vantage_ref')
    if obj['scope'] not in PROBE_SCOPES:
        fail('$.scope: invalid probe scope')
    if obj['result'] not in PROBE_RESULTS:
        fail('$.result: invalid probe result')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    freshness = validate_freshness(obj['freshness'], '$.freshness')
    if obj['result'] == 'pass' and freshness['state'] in {'stale', 'unknown'}:
        fail('$.result: stale/unknown freshness cannot be reported as pass')
    if obj['result'] in {'fail', 'timeout', 'degraded'} and 'failure_hint' not in obj:
        fail('$.failure_hint: failing/degraded probe needs failure hint')
    if obj['result'] in {'stale', 'unknown', 'inconclusive'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: uncertain probe result needs reason')
    if 'failure_hint' in obj and obj['failure_hint'] not in FAILURE_HINTS:
        fail('$.failure_hint: invalid failure hint')
    if 'threshold_state' in obj and obj['threshold_state'] not in THRESHOLD_STATES:
        fail('$.threshold_state: invalid threshold state')
    if 'consecutive_failures' in obj:
        require_int(obj['consecutive_failures'], '$.consecutive_failures', minimum=0, maximum=1_000_000)
    if 'next_due_ms' in obj:
        require_int(obj['next_due_ms'], '$.next_due_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['next_due_ms'] < obj['observed_at_ms']:
            fail('$.next_due_ms: cannot precede observed_at_ms')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', PROBE_NON_IMPLICATIONS, PROBE_BASE_NON_IMPLICATIONS)
    for field in ('target_ref', 'endpoint_ref', 'route_binding_ref', 'live_channel_ref', 'material_freshness_ref', 'incarnation_id'):
        require_ref_field(obj, field, '$')
    require_cycle_field(obj, 'runtime_cycle', '$')
    return obj


def validate_st_ctrlverdict(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, VERDICT_ALLOWED, VERDICT_REQUIRED, '$')
    if obj['schema'] != 'ST-CTRLVERDICT v0':
        fail('$.schema: expected ST-CTRLVERDICT v0')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['verdict_kind'] not in VERDICT_KINDS:
        fail('$.verdict_kind: invalid verdict kind')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    if obj['verdict_state'] not in VERDICT_STATES:
        fail('$.verdict_state: invalid verdict state')
    if obj['effect_class'] not in EFFECT_CLASSES:
        fail('$.effect_class: invalid effect class')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail('$.expires_or_recheck_by_ms: cannot precede observed_at_ms')
    if obj['verdict_state'] in {'unknown', 'inconclusive'} and 'unknown_reason' not in obj:
        fail('$.unknown_reason: uncertain verdict needs reason')
    if obj['verdict_state'] in {'stalled', 'failed', 'action_required'} and 'manual_action_hint' not in obj:
        fail('$.manual_action_hint: stalled/failed/action-required verdict needs manual action hint')
    if obj['effect_class'] in {'requests_operation', 'blocks_operation'} and 'operation_receipt_ref' not in obj and 'action_ref' not in obj:
        fail('$.operation_receipt_ref: operation-affecting verdict needs operation/action ref')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    if 'staleness_reason' in obj:
        require_text(obj['staleness_reason'], '$.staleness_reason')
    if 'manual_action_hint' in obj:
        require_text(obj['manual_action_hint'], '$.manual_action_hint')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    if 'probe_refs' in obj:
        require_refs(obj['probe_refs'], '$.probe_refs', maximum=16)
    if 'material_freshness_refs' in obj:
        require_refs(obj['material_freshness_refs'], '$.material_freshness_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', VERDICT_NON_IMPLICATIONS, VERDICT_BASE_NON_IMPLICATIONS)
    for field in ('scope_ref', 'traffic_binding_ref', 'operation_receipt_ref', 'action_ref', 'revision_ref', 'incarnation_id'):
        require_ref_field(obj, field, '$')
    require_cycle_field(obj, 'runtime_cycle', '$')
    return obj


def issuer(kind: str = 'steward', id_: str = 'steward/proof-harness') -> dict[str, str]:
    return {'kind': kind, 'id': id_}


def freshness(source: str = 'vantage/supervisor', observed: int = 2000, state: str = 'fresh') -> dict[str, Any]:
    obj: dict[str, Any] = {'source_vantage': source, 'observed_at_ms': observed, 'state': state}
    if state in {'stale', 'unknown'}:
        obj['staleness_reason'] = 'observer stale'
    if state == 'fresh':
        obj['expires_or_recheck_by_ms'] = observed + 1000
    return obj


def state_non_implications(*extra: str) -> list[str]:
    return sorted(STATE_BASE_NON_IMPLICATIONS | set(extra))


def mat_non_implications(*extra: str) -> list[str]:
    return sorted(MAT_BASE_NON_IMPLICATIONS | set(extra))


def probe_non_implications(*extra: str) -> list[str]:
    return sorted(PROBE_BASE_NON_IMPLICATIONS | set(extra))


def verdict_non_implications(*extra: str) -> list[str]:
    return sorted(VERDICT_BASE_NON_IMPLICATIONS | set(extra))


def base_stateatt() -> dict[str, Any]:
    return {
        'schema': 'ST-STATEATT v0',
        'witness_id': 'wit_stateatt00000001',
        'cid': 'demo.web',
        'issuer': issuer('storage_provider', 'adapter/k8s-volume'),
        'attachment_ref': 'attach/projected-config',
        'attachment_kind': 'projected_material',
        'attachment_state': 'attached',
        'authority_class': 'adapter_attached',
        'runtime_cycle': 'cycle-demo-web-r1',
        'material_ref': 'material/config-main',
        'retention_class': 'ephemeral',
        'lifetime_class': 'runtime_cycle',
        'observed_at_ms': 1000,
        'expires_or_recheck_by_ms': 2500,
        'basis_refs': ['adapter/volume-observation-1'],
        'non_implications': state_non_implications(),
    }


def snapshot_stateatt() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_stateatt()))
    obj.update({
        'witness_id': 'wit_stateatt00000002',
        'attachment_ref': 'attach/snapshot-cache',
        'attachment_kind': 'snapshot_derived',
        'attachment_state': 'restored',
        'authority_class': 'steward_attached',
        'snapshot_ref': 'snapshot/demo-web-44',
        'rebind_state': 'pending',
        'migration_state': 'not_applicable',
        'basis_refs': ['snapshot/restore-44'],
        'non_implications': state_non_implications('not-current-incarnation'),
    })
    del obj['material_ref']
    return obj


def base_matfresh() -> dict[str, Any]:
    return {
        'schema': 'ST-MATFRESH v0',
        'witness_id': 'wit_matfresh00000001',
        'cid': 'demo.web',
        'issuer': issuer('identity_provider', 'spiffe/agent'),
        'material_ref': 'material/svid-main',
        'material_kind': 'dynamic_identity',
        'material_state': 'fresh',
        'freshness_scope': 'identity',
        'source_vantage': 'vantage/workload-api',
        'version_ref': 'version/svid-71',
        'attachment_ref': 'attach/projected-config',
        'observed_at_ms': 2000,
        'expires_at_ms': 9000,
        'refresh_after_ms': 5000,
        'basis_refs': ['identity/update-71'],
        'non_implications': mat_non_implications(),
    }


def revoked_matfresh() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_matfresh()))
    obj.update({
        'witness_id': 'wit_matfresh00000002',
        'material_ref': 'material/token-old',
        'material_kind': 'token',
        'material_state': 'revoked',
        'freshness_scope': 'lease',
        'source_vantage': 'vantage/vault-lease',
        'observed_at_ms': 3000,
        'expires_at_ms': 8000,
        'revocation_ref': 'revocation/token-old-3',
        'unknown_reason': 'revoked before ordinary expiry',
        'basis_refs': ['lease/revocation-3'],
    })
    return obj


def stale_matfresh() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_matfresh()))
    obj.update({
        'witness_id': 'wit_matfresh00000003',
        'material_ref': 'material/config-main',
        'material_kind': 'config',
        'material_state': 'stale',
        'freshness_scope': 'projection',
        'observed_at_ms': 6000,
        'stale_after_ms': 4500,
        'unknown_reason': 'projection recheck failed',
        'basis_refs': ['config/recheck-timeout'],
    })
    obj.pop('expires_at_ms', None)
    obj.pop('refresh_after_ms', None)
    return obj


def base_probe() -> dict[str, Any]:
    return {
        'schema': 'ST-PROBE v0',
        'witness_id': 'wit_probe00000000001',
        'cid': 'demo.web',
        'issuer': issuer('probe', 'probe/supervisor'),
        'probe_kind': 'readiness',
        'vantage_kind': 'supervisor',
        'vantage_ref': 'vantage/supervisor',
        'scope': 'endpoint',
        'result': 'pass',
        'target_ref': 'endpoint/local-ready',
        'material_freshness_ref': 'wit_matfresh00000001',
        'observed_at_ms': 2200,
        'freshness': freshness('vantage/supervisor', 2200, 'fresh'),
        'threshold_state': 'threshold_met',
        'basis_refs': ['probe/readiness-77'],
        'non_implications': probe_non_implications('not-material-freshness'),
    }


def failing_probe() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_probe()))
    obj.update({
        'witness_id': 'wit_probe00000000002',
        'probe_kind': 'outside_in',
        'vantage_kind': 'outside_in',
        'vantage_ref': 'vantage/public-edge',
        'scope': 'user_path',
        'result': 'timeout',
        'failure_hint': 'timeout',
        'consecutive_failures': 3,
        'observed_at_ms': 2600,
        'freshness': freshness('vantage/public-edge', 2600, 'fresh'),
        'basis_refs': ['probe/outside-timeout-3'],
    })
    return obj


def base_verdict() -> dict[str, Any]:
    return {
        'schema': 'ST-CTRLVERDICT v0',
        'witness_id': 'wit_ctrlverdict00001',
        'cid': 'demo.web',
        'issuer': issuer('controller', 'controller/rollout'),
        'verdict_kind': 'readiness_gate',
        'subject_ref': 'revision/demo-web-r1',
        'verdict_state': 'eligible',
        'effect_class': 'advisory',
        'observed_at_ms': 3000,
        'probe_refs': ['wit_probe00000000001'],
        'material_freshness_refs': ['wit_matfresh00000001'],
        'basis_refs': ['controller/gate-17'],
        'expires_or_recheck_by_ms': 4000,
        'non_implications': verdict_non_implications(),
    }


def withheld_verdict() -> dict[str, Any]:
    obj = json.loads(json.dumps(base_verdict()))
    obj.update({
        'witness_id': 'wit_ctrlverdict00002',
        'verdict_kind': 'traffic',
        'verdict_state': 'withheld',
        'effect_class': 'gates_traffic',
        'material_freshness_refs': ['wit_matfresh00000002'],
        'probe_refs': [],
        'basis_refs': ['controller/material-revoked'],
        'manual_action_hint': 'reacquire material before traffic gate',
    })
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'currentness_control_flow', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    state = base_stateatt()
    snap = snapshot_stateatt()
    mat = base_matfresh()
    revoked = revoked_matfresh()
    stale = stale_matfresh()
    probe = base_probe()
    fprobe = failing_probe()
    verdict = base_verdict()
    withheld = withheld_verdict()

    state_raw_path = json.loads(json.dumps(state)); state_raw_path['path'] = '/var/run/app'
    state_claims_ready = json.loads(json.dumps(state)); state_claims_ready['claims_ready'] = True
    state_no_material = json.loads(json.dumps(state)); del state_no_material['material_ref']
    state_no_cycle = json.loads(json.dumps(state)); del state_no_cycle['runtime_cycle']

    mat_secret_leak = json.loads(json.dumps(mat)); mat_secret_leak['secret'] = 'do-not-log'
    mat_expired_fresh = json.loads(json.dumps(mat)); mat_expired_fresh['expires_at_ms'] = 1000
    mat_revoked_no_reason = json.loads(json.dumps(revoked)); del mat_revoked_no_reason['unknown_reason']
    mat_missing_nonimp = json.loads(json.dumps(mat)); mat_missing_nonimp['non_implications'] = ['not-readiness', 'not-serving']

    probe_claims_serving = json.loads(json.dumps(probe)); probe_claims_serving['claims_serving'] = True
    probe_stale_pass = json.loads(json.dumps(probe)); probe_stale_pass['freshness'] = freshness('vantage/supervisor', 2200, 'stale')
    probe_fail_no_hint = json.loads(json.dumps(fprobe)); del probe_fail_no_hint['failure_hint']
    probe_repair_action = json.loads(json.dumps(probe)); probe_repair_action['repair_action'] = 'restart now'

    verdict_route_claim = json.loads(json.dumps(verdict)); verdict_route_claim['claims_route_authority'] = True
    verdict_remediation_claim = json.loads(json.dumps(verdict)); verdict_remediation_claim['claims_remediation_success'] = True
    verdict_unknown_no_reason = json.loads(json.dumps(verdict)); verdict_unknown_no_reason['verdict_state'] = 'unknown'
    verdict_missing_nonimp = json.loads(json.dumps(verdict)); verdict_missing_nonimp['non_implications'] = ['not-readiness']
    verdict_stale_material_gate = json.loads(json.dumps(verdict)); verdict_stale_material_gate.update({'witness_id': 'wit_ctrlverdict00003', 'verdict_kind': 'traffic', 'effect_class': 'gates_traffic', 'material_freshness_refs': ['wit_matfresh00000003']})

    return [
        schema_case('stateatt.accept.projected-material-attached', 'ST-STATEATT', state, 'accept', 'attached projected material is digestable while refusing freshness and path authority'),
        schema_case('stateatt.accept.snapshot-derived-rebind-pending', 'ST-STATEATT', snap, 'accept', 'snapshot-derived attachment can be restored while still requiring rebind/currentness checks'),
        schema_case('stateatt.reject.raw-path-authority', 'ST-STATEATT', state_raw_path, 'reject', 'attachment witnesses must not become path grants'),
        schema_case('stateatt.reject.claims-ready', 'ST-STATEATT', state_claims_ready, 'reject', 'attached state must not claim readiness'),
        schema_case('stateatt.reject.projected-without-material-ref', 'ST-STATEATT', state_no_material, 'reject', 'projected-material attachment needs a material ref'),
        schema_case('stateatt.reject.attached-without-cycle-or-incarnation', 'ST-STATEATT', state_no_cycle, 'reject', 'attached current attachment needs a runtime-cycle or incarnation fence'),
        schema_case('stateatt.reject.duplicate-json-key', 'ST-STATEATT', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-STATEATT v0","schema":"ST-STATEATT v0","witness_id":"wit_stateatt00000001","cid":"demo.web","issuer":{"kind":"steward","id":"steward/proof"},"attachment_ref":"attach/x","attachment_kind":"unknown","attachment_state":"unknown","authority_class":"unknown","observed_at_ms":1,"basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-material-currentness","not-custody","not-work-completion","not-effect-success","not-path-authority"],"unknown_reason":"unknown source"}'),

        schema_case('matfresh.accept.dynamic-identity-fresh', 'ST-MATFRESH', mat, 'accept', 'fresh material names scope, version, expiry, and refusals without claiming use or reload'),
        schema_case('matfresh.accept.revoked-reacquire-required', 'ST-MATFRESH', revoked, 'accept', 'revoked material is useful evidence while remaining a downgrade'),
        schema_case('matfresh.reject.raw-secret-leak', 'ST-MATFRESH', mat_secret_leak, 'reject', 'material freshness packets must not export secret values'),
        schema_case('matfresh.reject.fresh-already-expired', 'ST-MATFRESH', mat_expired_fresh, 'reject', 'current material cannot already be expired'),
        schema_case('matfresh.reject.revoked-without-reason', 'ST-MATFRESH', mat_revoked_no_reason, 'reject', 'revocation needs downgrade explanation'),
        schema_case('matfresh.reject.missing-non-implications', 'ST-MATFRESH', mat_missing_nonimp, 'reject', 'material freshness must refuse use, reload, authority, and lifecycle truths'),
        schema_case('matfresh.reject.duplicate-json-key', 'ST-MATFRESH', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-MATFRESH v0","schema":"ST-MATFRESH v0","witness_id":"wit_matfresh00000001","cid":"demo.web","issuer":{"kind":"steward","id":"steward/proof"},"material_ref":"material/x","material_kind":"config","material_state":"unknown","freshness_scope":"unknown","observed_at_ms":1,"basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-attachment","not-material-use","not-reload-success","not-current-authority","not-effect-success"],"unknown_reason":"unknown source"}'),

        schema_case('probe.accept.readiness-probe-pass', 'ST-PROBE', probe, 'accept', 'probe pass is digestable but stays a probe vantage, not readiness or serving truth'),
        schema_case('probe.accept.outside-in-timeout', 'ST-PROBE', fprobe, 'accept', 'outside-in timeout can explain pressure without authorizing repair or incident truth'),
        schema_case('probe.reject.claims-serving', 'ST-PROBE', probe_claims_serving, 'reject', 'probe packets must not claim serving state'),
        schema_case('probe.reject.stale-pass', 'ST-PROBE', probe_stale_pass, 'reject', 'stale probe observations cannot remain pass results'),
        schema_case('probe.reject.fail-without-hint', 'ST-PROBE', probe_fail_no_hint, 'reject', 'failing probes need failure hints'),
        schema_case('probe.reject.repair-action', 'ST-PROBE', probe_repair_action, 'reject', 'probe witnesses are not hidden repair actions'),
        schema_case('probe.reject.duplicate-json-key', 'ST-PROBE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-PROBE v0","schema":"ST-PROBE v0","witness_id":"wit_probe00000000001","cid":"demo.web","issuer":{"kind":"probe","id":"probe/x"},"probe_kind":"readiness","vantage_kind":"supervisor","vantage_ref":"vantage/x","scope":"endpoint","result":"unknown","observed_at_ms":1,"freshness":{"source_vantage":"vantage/x","observed_at_ms":1,"state":"unknown","staleness_reason":"unknown source"},"basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-route-authority","not-rollout-settlement","not-remediation-success","not-effect-success","not-incident-truth"],"unknown_reason":"unknown source"}'),

        schema_case('ctrlverdict.accept.advisory-eligible', 'ST-CTRLVERDICT', verdict, 'accept', 'eligible verdict is advisory and refuses route/readiness/remediation truths'),
        schema_case('ctrlverdict.accept.withheld-on-revoked-material', 'ST-CTRLVERDICT', withheld, 'accept', 'traffic gate can be withheld by degraded material freshness without pretending route changed'),
        schema_case('ctrlverdict.reject.claims-route-authority', 'ST-CTRLVERDICT', verdict_route_claim, 'reject', 'control verdicts cannot become route authority'),
        schema_case('ctrlverdict.reject.claims-remediation-success', 'ST-CTRLVERDICT', verdict_remediation_claim, 'reject', 'verdict packets cannot claim remediation success'),
        schema_case('ctrlverdict.reject.unknown-without-reason', 'ST-CTRLVERDICT', verdict_unknown_no_reason, 'reject', 'unknown verdicts need a reason'),
        schema_case('ctrlverdict.reject.missing-non-implications', 'ST-CTRLVERDICT', verdict_missing_nonimp, 'reject', 'control verdicts must refuse stronger lifecycle and incident truths'),
        schema_case('ctrlverdict.reject.duplicate-json-key', 'ST-CTRLVERDICT', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-CTRLVERDICT v0","schema":"ST-CTRLVERDICT v0","witness_id":"wit_ctrlverdict00001","cid":"demo.web","issuer":{"kind":"controller","id":"controller/x"},"verdict_kind":"operator","subject_ref":"revision/x","verdict_state":"unknown","effect_class":"unknown","observed_at_ms":1,"basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-route-authority","not-rollback-completion","not-remediation-success","not-incident-truth","not-effect-success","not-raw-observation"],"unknown_reason":"unknown source"}'),

        flow_case('curflow.accept-currentness-chain-remains-separated', [
            {'event': 'state_attachment', 'witness': state},
            {'event': 'material_freshness', 'witness': mat},
            {'event': 'probe_vantage', 'witness': probe},
            {'event': 'control_verdict', 'witness': verdict},
        ], 'accept', 'attachment, freshness, probe, and verdict can compose as adjacent witnesses without collapsing into readiness or route authority'),
        flow_case('curflow.accept-revoked-material-withheld-traffic-gate', [
            {'event': 'material_freshness', 'witness': revoked},
            {'event': 'control_verdict', 'witness': withheld},
        ], 'accept', 'revoked material can drive a withheld traffic gate while remaining separate facts'),
        flow_case('curflow.reject-attachment-implies-material-freshness', [
            {'event': 'state_attachment', 'witness': state, 'implies_material_freshness': True},
        ], 'reject', 'state attachment cannot become material freshness'),
        flow_case('curflow.reject-material-freshness-implies-reload', [
            {'event': 'material_freshness', 'witness': mat, 'implies_reload_success': True},
        ], 'reject', 'material freshness cannot prove the component consumed or reloaded the material'),
        flow_case('curflow.reject-probe-pass-implies-serving', [
            {'event': 'probe_vantage', 'witness': probe, 'implies_serving': True},
        ], 'reject', 'probe pass cannot become serving truth'),
        flow_case('curflow.reject-verdict-implies-route-active', [
            {'event': 'control_verdict', 'witness': verdict, 'claims_route_authority': True},
        ], 'reject', 'control verdict cannot settle traffic binding'),
        flow_case('curflow.reject-stale-material-eligible-traffic-gate', [
            {'event': 'material_freshness', 'witness': stale},
            {'event': 'control_verdict', 'witness': verdict_stale_material_gate},
        ], 'reject', 'traffic-gating eligibility cannot be based on degraded material without a withholding/downgrade verdict'),
        flow_case('curflow.accept-verdict-adjacent-to-separate-traffic-binding', [
            {'event': 'material_freshness', 'witness': mat},
            {'event': 'probe_vantage', 'witness': probe},
            {'event': 'control_verdict', 'witness': {**verdict, 'traffic_binding_ref': 'wit_tbind00000000001'}},
            {'event': 'traffic_binding', 'witness_ref': 'wit_tbind00000000001'},
        ], 'accept', 'a verdict may cite a separate traffic-binding witness without becoming that route witness'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        if case['object_kind'] == 'ST-STATEATT':
            validate_st_stateatt(obj)
        elif case['object_kind'] == 'ST-MATFRESH':
            validate_st_matfresh(obj)
        elif case['object_kind'] == 'ST-PROBE':
            validate_st_probe(obj)
        elif case['object_kind'] == 'ST-CTRLVERDICT':
            validate_st_ctrlverdict(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        materials: dict[str, dict[str, Any]] = {}
        probes: dict[str, dict[str, Any]] = {}
        verdicts: dict[str, dict[str, Any]] = {}
        traffic_bindings: set[str] = set()
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'state_attachment':
                witness = validate_st_stateatt(ev['witness'])
                if ev.get('implies_material_freshness') or ev.get('implies_path_authority') or ev.get('implies_current_incarnation'):
                    fail(f'{where}: state attachment promoted to stronger truth')
            elif kind == 'material_freshness':
                witness = validate_st_matfresh(ev['witness'])
                if ev.get('implies_reload_success') or ev.get('implies_material_use') or ev.get('implies_readiness'):
                    fail(f'{where}: material freshness promoted to stronger truth')
                materials[witness['witness_id']] = witness
            elif kind == 'probe_vantage':
                witness = validate_st_probe(ev['witness'])
                if ev.get('implies_ready') or ev.get('implies_serving') or ev.get('claims_remediation_success') or ev.get('implies_incident_truth'):
                    fail(f'{where}: probe promoted to stronger truth')
                if witness.get('material_freshness_ref') and witness['material_freshness_ref'].startswith('wit_') and witness['material_freshness_ref'] not in materials:
                    fail(f'{where}: probe references unseen material freshness witness')
                probes[witness['witness_id']] = witness
            elif kind == 'control_verdict':
                witness = validate_st_ctrlverdict(ev['witness'])
                if ev.get('claims_route_authority') or ev.get('implies_readiness') or ev.get('claims_rollback_complete') or ev.get('claims_remediation_success'):
                    fail(f'{where}: control verdict promoted to stronger truth')
                for ref in witness.get('probe_refs', []):
                    if ref.startswith('wit_') and ref not in probes:
                        fail(f'{where}: verdict references unseen probe witness {ref}')
                degraded_material = []
                for ref in witness.get('material_freshness_refs', []):
                    if ref.startswith('wit_'):
                        if ref not in materials:
                            fail(f'{where}: verdict references unseen material freshness witness {ref}')
                        if materials[ref]['material_state'] in {'expired', 'revoked', 'reacquire_required', 'stale', 'unknown'}:
                            degraded_material.append(ref)
                if degraded_material and witness['effect_class'] == 'gates_traffic' and witness['verdict_state'] in {'eligible', 'passed'}:
                    fail(f'{where}: degraded material {degraded_material} cannot produce eligible traffic gate')
                tbind = witness.get('traffic_binding_ref')
                if tbind and tbind.startswith('wit_') and tbind not in traffic_bindings and not any(e.get('event') == 'traffic_binding' and e.get('witness_ref') == tbind for e in case['events'][idx+1:]):
                    fail(f'{where}: verdict references unseen traffic binding {tbind}')
                verdicts[witness['witness_id']] = witness
            elif kind == 'traffic_binding':
                require_pattern(ev.get('witness_ref'), REF_RE, f'{where}.witness_ref')
                traffic_bindings.add(ev['witness_ref'])
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        case_id = case.get('case_id')
        if not isinstance(case_id, str) or not case_id:
            failures.append('case without valid case_id')
            continue
        if case_id in seen:
            failures.append(f'{case_id}: duplicate case_id')
            continue
        seen.add(case_id)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'currentness_control_flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{case_id}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{case_id}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-currentness-control-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic currentness/control corpus')
    ap.add_argument('--check', action='store_true', help='check currentness/control corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-currentness-control-corpus] FAIL: corpus is stale; run tools/steward_currentness_control_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-currentness-control-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
