#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/shutdown-settlement-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')
QUIESCE_RE = re.compile(r'^qsc_[a-z0-9]{16}$')
DRAIN_RE = re.compile(r'^drn_[a-z0-9]{16}$')
ESC_RE = re.compile(r'^esc_[a-z0-9]{16}$')
TERM_RE = re.compile(r'^term_[a-z0-9]{16}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_ready', 'claims_readiness', 'claims_serving', 'claims_stopped',
    'claims_drained', 'claims_force_kill', 'claims_clean_exit', 'claims_graceful',
    'claims_lossless', 'claims_no_live_channels', 'claims_no_inflight_work',
    'claims_no_side_effect', 'claims_no_duplicate', 'claims_exactly_once',
    'claims_effect_success', 'claims_restart_success', 'claims_successor_ready',
    'ready', 'serving', 'stopped', 'drained', 'force_kill', 'clean_exit',
    'graceful', 'lossless', 'no_live_channels', 'no_inflight_work',
    'no_side_effect', 'no_duplicate', 'exactly_once', 'effect_success',
    'restart_success', 'successor_ready', 'component_state', 'rollout_complete',
    'raw_log', 'scrollback', 'token', 'secret', 'raw_secret', 'raw_token',
    'raw_handle', 'bearer', 'value', 'path', 'raw_path', 'mount_path', 'fd',
    'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path', 'systemd_unit',
    'systemd_job_path', 'pod_name', 'container_id', 'process_name', 'host_unit',
    'node_name', 'allocation_id', 'endpoint', 'raw_endpoint', 'url', 'uri',
    'authorization', 'cookie', 'signal_number', 'exit_code',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {
    'steward', 'operator', 'adapter', 'controller', 'runtime', 'supervisor',
    'platform', 'load_balancer', 'broker', 'queue', 'proxy', 'observer',
}

QUIESCE_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'quiesce_id', 'runtime_cycle_ref',
    'gate_state', 'demand_policy', 'observed_at_ms', 'basis_refs', 'non_implications',
}
QUIESCE_OPTIONAL = {
    'active_work_refs', 'allowed_exception_refs', 'release_ref',
    'expires_or_recheck_by_ms', 'unknown_reason',
}
QUIESCE_ALLOWED = QUIESCE_REQUIRED | QUIESCE_OPTIONAL
QUIESCE_STATES = {'requested', 'entering', 'no_new_work', 'exception_window', 'released', 'failed', 'unknown'}
DEMAND_POLICIES = {'no_new_external_demand', 'no_new_internal_demand', 'no_new_user_actions', 'drain_only', 'observe_only', 'unknown'}
QUIESCE_NON_IMPLICATIONS = {
    'not-stopped', 'not-drained', 'not-force-kill', 'not-effect-success',
    'not-no-live-channels', 'not-no-inflight-work', 'not-readiness', 'not-serving',
}

DRAIN_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'drain_id', 'runtime_cycle_ref',
    'drain_scope', 'drain_state', 'pending_class', 'horizon_ms',
    'observed_at_ms', 'basis_refs', 'non_implications',
}
DRAIN_OPTIONAL = {
    'quiesce_ref', 'traffic_binding_refs', 'live_channel_refs', 'demand_refs',
    'work_refs', 'completion_ref', 'deadline_ms', 'expires_or_recheck_by_ms',
    'unknown_reason',
}
DRAIN_ALLOWED = DRAIN_REQUIRED | DRAIN_OPTIONAL
DRAIN_SCOPES = {'traffic_binding', 'live_channels', 'demand_queue', 'work_inflight', 'component', 'mixed', 'unknown'}
DRAIN_STATES = {'not_started', 'draining', 'drained', 'partial', 'deadline_hit', 'forced', 'abandoned', 'unknown'}
PENDING_CLASSES = {'none', 'some', 'hidden', 'unknown'}
DRAIN_NON_IMPLICATIONS = {
    'not-stopped', 'not-effect-success', 'not-no-side-effect', 'not-lossless',
    'not-force-kill', 'not-no-new-work', 'not-readiness',
}

ESC_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'escalation_id',
    'runtime_cycle_ref', 'escalation_state', 'reason', 'force_level',
    'previous_request_ref', 'deadline_basis', 'observed_at_ms', 'basis_refs',
    'non_implications',
}
ESC_OPTIONAL = {'grace_elapsed_ms', 'authority_ref', 'drain_ref', 'signal_class', 'expires_or_recheck_by_ms', 'unknown_reason'}
ESC_ALLOWED = ESC_REQUIRED | ESC_OPTIONAL
ESC_STATES = {'requested', 'armed', 'applied', 'refused', 'superseded', 'unknown'}
ESC_REASONS = {'grace_expired', 'operator_override', 'safety', 'crash_loop', 'shutdown', 'host_eviction', 'policy', 'unknown'}
FORCE_LEVELS = {'notify', 'soft_stop', 'interrupt', 'terminate', 'kill', 'adapter_force', 'platform_evict', 'unknown'}
DEADLINE_BASES = {'operation_deadline', 'drain_deadline', 'shutdown_horizon', 'operator_override', 'policy', 'unknown'}
SIGNAL_CLASSES = {'none', 'soft', 'interrupt', 'terminate', 'kill', 'platform', 'unknown'}
ESC_NON_IMPLICATIONS = {
    'not-stopped', 'not-drained', 'not-effect-success', 'not-clean-exit',
    'not-lossless', 'not-graceful',
}

TERM_REQUIRED = {
    'schema', 'witness_id', 'cid', 'issuer', 'termination_id',
    'runtime_cycle_ref', 'termination_state', 'end_cause', 'exit_class',
    'observed_at_ms', 'basis_refs', 'non_implications',
}
TERM_OPTIONAL = {
    'drain_ref', 'escalation_ref', 'successor_cycle_ref', 'ended_at_ms',
    'recovery_hint', 'expires_or_recheck_by_ms', 'unknown_reason',
}
TERM_ALLOWED = TERM_REQUIRED | TERM_OPTIONAL
TERM_STATES = {'ended', 'suspected_ended', 'superseded', 'unknown'}
END_CAUSES = {'requested_stop', 'graceful_exit', 'forced_stop', 'crash', 'watchdog', 'host_eviction', 'dependency_lost', 'unknown'}
EXIT_CLASSES = {'clean', 'failed', 'forced', 'ambiguous', 'unknown'}
RECOVERY_HINTS = {'none', 'restart_allowed', 'repair_required', 'reconcile_required', 'unknown'}
TERM_NON_IMPLICATIONS = {
    'not-effect-success', 'not-drain-complete', 'not-lossless',
    'not-restart-success', 'not-successor-ready', 'not-custody',
}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered or 'http://' in lowered or 'https://' in lowered:
        fail(f'{path}: raw bearer or endpoint-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=16))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_window(obj: dict[str, Any], path: str) -> None:
    require_int(obj['observed_at_ms'], f'{path}.observed_at_ms', maximum=9_223_372_036_854_775_807)
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], f'{path}.expires_or_recheck_by_ms', maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail(f'{path}.expires_or_recheck_by_ms: precedes observed_at_ms')


def require_optional_ref(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], REF_RE, f'{path}.{field}')


def require_optional_cycle(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], CYCLE_RE, f'{path}.{field}')


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_pattern(obj['runtime_cycle_ref'], CYCLE_RE, '$.runtime_cycle_ref')
    validate_window(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs')
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_quiesce(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, QUIESCE_ALLOWED, QUIESCE_REQUIRED, 'ST-QUIESCE v0')
    require_pattern(obj['quiesce_id'], QUIESCE_RE, '$.quiesce_id')
    if obj['gate_state'] not in QUIESCE_STATES:
        fail('$.gate_state: invalid')
    if obj['demand_policy'] not in DEMAND_POLICIES:
        fail('$.demand_policy: invalid')
    require_non_implications(obj['non_implications'], QUIESCE_NON_IMPLICATIONS, '$.non_implications')
    for field in ('active_work_refs', 'allowed_exception_refs'):
        if field in obj:
            require_refs(obj[field], f'$.{field}', maximum=16)
    require_optional_ref(obj, 'release_ref', '$')
    if obj['gate_state'] == 'no_new_work' and obj['demand_policy'] in {'observe_only', 'unknown'}:
        fail('$.demand_policy: no_new_work requires an actual demand gate policy')
    if obj['gate_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown gate_state')
    if obj['gate_state'] == 'released' and 'release_ref' not in obj:
        fail('$.release_ref: required when quiesce is released')
    return obj


def validate_drain(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, DRAIN_ALLOWED, DRAIN_REQUIRED, 'ST-DRAIN v0')
    require_pattern(obj['drain_id'], DRAIN_RE, '$.drain_id')
    if obj['drain_scope'] not in DRAIN_SCOPES:
        fail('$.drain_scope: invalid')
    if obj['drain_state'] not in DRAIN_STATES:
        fail('$.drain_state: invalid')
    if obj['pending_class'] not in PENDING_CLASSES:
        fail('$.pending_class: invalid')
    require_int(obj['horizon_ms'], '$.horizon_ms', maximum=604_800_000)
    require_non_implications(obj['non_implications'], DRAIN_NON_IMPLICATIONS, '$.non_implications')
    if 'quiesce_ref' in obj:
        require_pattern(obj['quiesce_ref'], QUIESCE_RE, '$.quiesce_ref')
    for field in ('traffic_binding_refs', 'live_channel_refs', 'demand_refs', 'work_refs'):
        if field in obj:
            require_refs(obj[field], f'$.{field}', maximum=32)
    require_optional_ref(obj, 'completion_ref', '$')
    if 'deadline_ms' in obj:
        require_int(obj['deadline_ms'], '$.deadline_ms', maximum=9_223_372_036_854_775_807)
        if obj['deadline_ms'] < obj['observed_at_ms'] and obj['drain_state'] != 'deadline_hit':
            fail('$.deadline_ms: past deadline requires deadline_hit state')
    if obj['drain_state'] == 'drained' and obj['pending_class'] != 'none':
        fail('$.pending_class: drained requires none')
    if obj['drain_state'] == 'drained' and obj['drain_scope'] in {'component', 'mixed'} and 'quiesce_ref' not in obj:
        fail('$.quiesce_ref: component drain completion must cite quiesce witness')
    if obj['drain_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown drain_state')
    return obj


def validate_escalation(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ESC_ALLOWED, ESC_REQUIRED, 'ST-ESCALATE v0')
    require_pattern(obj['escalation_id'], ESC_RE, '$.escalation_id')
    if obj['escalation_state'] not in ESC_STATES:
        fail('$.escalation_state: invalid')
    if obj['reason'] not in ESC_REASONS:
        fail('$.reason: invalid')
    if obj['force_level'] not in FORCE_LEVELS:
        fail('$.force_level: invalid')
    require_pattern(obj['previous_request_ref'], REF_RE, '$.previous_request_ref')
    if obj['deadline_basis'] not in DEADLINE_BASES:
        fail('$.deadline_basis: invalid')
    require_non_implications(obj['non_implications'], ESC_NON_IMPLICATIONS, '$.non_implications')
    if 'grace_elapsed_ms' in obj:
        require_int(obj['grace_elapsed_ms'], '$.grace_elapsed_ms', maximum=604_800_000)
    elif obj['reason'] == 'grace_expired':
        fail('$.grace_elapsed_ms: grace_expired requires elapsed grace')
    require_optional_ref(obj, 'authority_ref', '$')
    if 'drain_ref' in obj:
        require_pattern(obj['drain_ref'], DRAIN_RE, '$.drain_ref')
    if 'signal_class' in obj and obj['signal_class'] not in SIGNAL_CLASSES:
        fail('$.signal_class: invalid')
    if obj['escalation_state'] == 'applied' and obj['force_level'] == 'unknown':
        fail('$.force_level: applied escalation cannot be unknown')
    if obj['force_level'] in {'kill', 'adapter_force', 'platform_evict'} and obj['escalation_state'] == 'applied' and 'authority_ref' not in obj:
        fail('$.authority_ref: strong force requires authority basis')
    if obj['escalation_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown escalation_state')
    return obj


def validate_termcause(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, TERM_ALLOWED, TERM_REQUIRED, 'ST-TERMCAUSE v0')
    require_pattern(obj['termination_id'], TERM_RE, '$.termination_id')
    if obj['termination_state'] not in TERM_STATES:
        fail('$.termination_state: invalid')
    if obj['end_cause'] not in END_CAUSES:
        fail('$.end_cause: invalid')
    if obj['exit_class'] not in EXIT_CLASSES:
        fail('$.exit_class: invalid')
    require_non_implications(obj['non_implications'], TERM_NON_IMPLICATIONS, '$.non_implications')
    if 'drain_ref' in obj:
        require_pattern(obj['drain_ref'], DRAIN_RE, '$.drain_ref')
    if 'escalation_ref' in obj:
        require_pattern(obj['escalation_ref'], ESC_RE, '$.escalation_ref')
    require_optional_cycle(obj, 'successor_cycle_ref', '$')
    if 'ended_at_ms' in obj:
        require_int(obj['ended_at_ms'], '$.ended_at_ms', maximum=9_223_372_036_854_775_807)
        if obj['ended_at_ms'] > obj['observed_at_ms']:
            fail('$.ended_at_ms: cannot follow observed_at_ms')
    if 'recovery_hint' in obj and obj['recovery_hint'] not in RECOVERY_HINTS:
        fail('$.recovery_hint: invalid')
    if obj['end_cause'] == 'forced_stop' and obj['exit_class'] == 'clean':
        fail('$.exit_class: forced stop cannot be clean')
    if obj['exit_class'] == 'clean' and obj['end_cause'] not in {'requested_stop', 'graceful_exit'}:
        fail('$.end_cause: clean exit requires requested_stop or graceful_exit')
    if obj['termination_state'] == 'unknown' and 'unknown_reason' not in obj:
        fail('$.unknown_reason: required for unknown termination_state')
    return obj


def issuer(kind: str = 'steward', ident: str = 'steward.local') -> dict[str, Any]:
    return {'kind': kind, 'id': ident}


def base_quiesce(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-QUIESCE v0',
        'witness_id': 'wit_1000000000000001',
        'cid': 'demo.web',
        'issuer': issuer('supervisor'),
        'quiesce_id': 'qsc_1000000000000001',
        'runtime_cycle_ref': 'cycle-demo-1',
        'gate_state': 'no_new_work',
        'demand_policy': 'no_new_external_demand',
        'observed_at_ms': 1000,
        'basis_refs': ['opreq:stop-1'],
        'active_work_refs': ['demand:old-1'],
        'non_implications': sorted(QUIESCE_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_drain(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-DRAIN v0',
        'witness_id': 'wit_1000000000000002',
        'cid': 'demo.web',
        'issuer': issuer('runtime'),
        'drain_id': 'drn_1000000000000001',
        'runtime_cycle_ref': 'cycle-demo-1',
        'drain_scope': 'component',
        'drain_state': 'drained',
        'pending_class': 'none',
        'horizon_ms': 30000,
        'observed_at_ms': 2000,
        'basis_refs': ['qsc_1000000000000001', 'livechan:drain-1'],
        'quiesce_ref': 'qsc_1000000000000001',
        'live_channel_refs': ['livechan:stream-1'],
        'work_refs': ['workdisp:old-1'],
        'completion_ref': 'receipt:drain-1',
        'deadline_ms': 31000,
        'non_implications': sorted(DRAIN_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_escalation(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-ESCALATE v0',
        'witness_id': 'wit_1000000000000003',
        'cid': 'demo.web',
        'issuer': issuer('supervisor'),
        'escalation_id': 'esc_1000000000000001',
        'runtime_cycle_ref': 'cycle-demo-1',
        'escalation_state': 'applied',
        'reason': 'grace_expired',
        'force_level': 'terminate',
        'previous_request_ref': 'opreq:stop-1',
        'deadline_basis': 'shutdown_horizon',
        'grace_elapsed_ms': 30000,
        'observed_at_ms': 32000,
        'basis_refs': ['drn_1000000000000001', 'policy:stop-grace'],
        'drain_ref': 'drn_1000000000000001',
        'signal_class': 'terminate',
        'non_implications': sorted(ESC_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_termcause(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-TERMCAUSE v0',
        'witness_id': 'wit_1000000000000004',
        'cid': 'demo.web',
        'issuer': issuer('runtime'),
        'termination_id': 'term_1000000000000001',
        'runtime_cycle_ref': 'cycle-demo-1',
        'termination_state': 'ended',
        'end_cause': 'requested_stop',
        'exit_class': 'clean',
        'observed_at_ms': 33000,
        'ended_at_ms': 32900,
        'basis_refs': ['drn_1000000000000001', 'receipt:exit-1'],
        'drain_ref': 'drn_1000000000000001',
        'recovery_hint': 'none',
        'non_implications': sorted(TERM_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {
        'case_id': case_id,
        'kind': 'schema',
        'object_kind': object_kind,
        'expect': expect,
        'why': why,
    }
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def shutdown_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'shutdown', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    q = base_quiesce()
    d = base_drain()
    e = base_escalation()
    t = base_termcause()
    crash_t = base_termcause(
        witness_id='wit_1000000000000005',
        termination_id='term_1000000000000002',
        end_cause='crash',
        exit_class='failed',
        basis_refs=['runtime:last-observed'],
        drain_ref=None,
        recovery_hint='restart_allowed',
    )
    crash_t.pop('drain_ref', None)

    cases: list[dict[str, Any]] = [
        schema_case('quiesce.accept.no-new-work', 'ST-QUIESCE', q, 'accept', 'quiesce is a closed no-new-demand gate, not stopped truth'),
        schema_case('quiesce.reject.claims-stopped', 'ST-QUIESCE', {**q, 'claims_stopped': True}, 'reject', 'quiesce cannot claim the component stopped'),
        schema_case('quiesce.reject.no-new-work-observe-only', 'ST-QUIESCE', {**q, 'demand_policy': 'observe_only'}, 'reject', 'no_new_work requires an actual gate, not observation-only folklore'),
        schema_case('quiesce.reject.duplicate-json-key', 'ST-QUIESCE', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-QUIESCE v0","schema":"ST-QUIESCE v0","witness_id":"wit_1000000000000001","cid":"demo.web","issuer":{"kind":"supervisor","id":"steward.local"},"quiesce_id":"qsc_1000000000000001","runtime_cycle_ref":"cycle-demo-1","gate_state":"no_new_work","demand_policy":"no_new_external_demand","observed_at_ms":1000,"basis_refs":["opreq:stop-1"],"non_implications":[]}'),
        schema_case('drain.accept.component-drained', 'ST-DRAIN', d, 'accept', 'drain completion is a bounded old-work/channel observation with pending none'),
        schema_case('drain.reject.drained-with-pending', 'ST-DRAIN', {**d, 'pending_class': 'some'}, 'reject', 'drained cannot hide remaining pending work'),
        schema_case('drain.reject.raw-endpoint', 'ST-DRAIN', {**d, 'endpoint': 'edge.internal.local'}, 'reject', 'drain receipts do not export raw endpoints'),
        schema_case('drain.reject.past-deadline-without-deadline-hit', 'ST-DRAIN', {**d, 'deadline_ms': 1000}, 'reject', 'a past deadline cannot still report ordinary drained progress'),
        schema_case('escalate.accept.applied-terminate', 'ST-ESCALATE', e, 'accept', 'escalation applied records stronger intervention without claiming stop completion'),
        schema_case('escalate.reject.claims-clean-exit', 'ST-ESCALATE', {**e, 'claims_clean_exit': True}, 'reject', 'escalation is not clean-exit proof'),
        schema_case('escalate.reject.grace-expired-without-elapsed', 'ST-ESCALATE', {k: v for k, v in e.items() if k != 'grace_elapsed_ms'}, 'reject', 'grace-expired escalation must name elapsed grace'),
        schema_case('escalate.reject.strong-force-without-authority', 'ST-ESCALATE', {**e, 'force_level': 'kill', 'authority_ref': None}, 'reject', 'strong force needs an authority basis'),
        schema_case('termcause.accept.clean-requested-stop', 'ST-TERMCAUSE', t, 'accept', 'termination cause records end of cycle without effect or restart truth'),
        schema_case('termcause.reject.forced-clean', 'ST-TERMCAUSE', {**t, 'end_cause': 'forced_stop', 'exit_class': 'clean'}, 'reject', 'forced stop cannot be flattened into clean exit'),
        schema_case('termcause.reject.successor-ready-claim', 'ST-TERMCAUSE', {**t, 'claims_successor_ready': True}, 'reject', 'termination cannot claim successor readiness'),
        schema_case('termcause.reject.future-ended-at', 'ST-TERMCAUSE', {**t, 'ended_at_ms': 40000}, 'reject', 'ended_at cannot be later than observation'),

        shutdown_case('shutdown.accept.graceful-quiesce-drain-end', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'drain', 'packet': d},
            {'event': 'termination', 'packet': t},
        ], 'accept', 'graceful stop composes no-new-work, drained old work, and clean requested-stop termination without extra claims'),
        shutdown_case('shutdown.accept.crash-without-drain', [
            {'event': 'termination', 'packet': crash_t},
        ], 'accept', 'crash termination may be recorded without inventing drain or quiesce truth'),
        shutdown_case('shutdown.accept.escalated-forced-end', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'drain', 'packet': base_drain(witness_id='wit_1000000000000006', drain_state='deadline_hit', pending_class='some', deadline_ms=31000)},
            {'event': 'escalation', 'packet': base_escalation(witness_id='wit_1000000000000007', force_level='kill', authority_ref='policy:force-stop')},
            {'event': 'termination', 'packet': base_termcause(witness_id='wit_1000000000000008', termination_id='term_1000000000000003', end_cause='forced_stop', exit_class='forced', escalation_ref='esc_1000000000000001', drain_ref='drn_1000000000000001')},
        ], 'accept', 'force can end a cycle only as forced termination, not graceful or lossless completion'),
        shutdown_case('shutdown.reject.quiesce-as-no-live-channels', [
            {'event': 'quiesce', 'packet': q, 'claims_no_live_channels': True},
        ], 'reject', 'no-new-work gates cannot claim all channels vanished'),
        shutdown_case('shutdown.reject.drain-without-prior-quiesce', [
            {'event': 'drain', 'packet': d},
        ], 'reject', 'component-level drained completion must cite an observed quiesce gate in this flow'),
        shutdown_case('shutdown.reject.drain-as-lossless', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'drain', 'packet': d, 'claims_lossless': True},
        ], 'reject', 'drain completion does not prove lossless behavior'),
        shutdown_case('shutdown.reject.escalation-as-stopped', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'escalation', 'packet': e, 'claims_stopped': True},
        ], 'reject', 'applied escalation does not itself prove termination'),
        shutdown_case('shutdown.reject.termination-effect-success', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'drain', 'packet': d},
            {'event': 'termination', 'packet': t, 'claims_effect_success': True},
        ], 'reject', 'termination of a cycle is not external effect success'),
        shutdown_case('shutdown.reject.clean-after-kill-escalation', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'drain', 'packet': base_drain(witness_id='wit_1000000000000009', drain_state='deadline_hit', pending_class='some', deadline_ms=31000)},
            {'event': 'escalation', 'packet': base_escalation(witness_id='wit_1000000000000010', force_level='kill', authority_ref='policy:force-stop')},
            {'event': 'termination', 'packet': base_termcause(witness_id='wit_1000000000000011', termination_id='term_1000000000000004', end_cause='graceful_exit', exit_class='clean', escalation_ref='esc_1000000000000001')},
        ], 'reject', 'a kill-level applied escalation cannot be rewritten as clean graceful exit'),
        shutdown_case('shutdown.reject.duplicate-quiesce-different-digest', [
            {'event': 'quiesce', 'packet': q},
            {'event': 'quiesce', 'packet': base_quiesce(witness_id='wit_1000000000000012', gate_state='released', release_ref='operator:release-1')},
        ], 'reject', 'the same quiesce id cannot name two different canonical packets'),
    ]
    return cases


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-QUIESCE':
            validate_quiesce(obj)
        elif kind == 'ST-DRAIN':
            validate_drain(obj)
        elif kind == 'ST-ESCALATE':
            validate_escalation(obj)
        elif kind == 'ST-TERMCAUSE':
            validate_termcause(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_shutdown_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        q_by_id: dict[str, dict[str, Any]] = {}
        d_by_id: dict[str, dict[str, Any]] = {}
        e_by_id: dict[str, dict[str, Any]] = {}
        seen_packet_digests: dict[str, str] = {}

        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'quiesce':
                q = validate_quiesce(packet)
                check_packet_identity(seen_packet_digests, q['quiesce_id'], q, where)
                q_by_id[q['quiesce_id']] = q
            elif kind == 'drain':
                d = validate_drain(packet)
                check_packet_identity(seen_packet_digests, d['drain_id'], d, where)
                if d['drain_state'] == 'drained' and d['drain_scope'] in {'component', 'mixed'}:
                    qref = d.get('quiesce_ref')
                    if qref not in q_by_id:
                        fail(f'{where}: drained component flow lacks prior quiesce witness')
                    q = q_by_id[qref]
                    if q['runtime_cycle_ref'] != d['runtime_cycle_ref']:
                        fail(f'{where}: drain/quiesce runtime cycle mismatch')
                    if q['gate_state'] != 'no_new_work':
                        fail(f'{where}: drain completion needs a no_new_work quiesce gate')
                d_by_id[d['drain_id']] = d
            elif kind == 'escalation':
                e = validate_escalation(packet)
                check_packet_identity(seen_packet_digests, e['escalation_id'], e, where)
                if 'drain_ref' in e and e['drain_ref'] not in d_by_id:
                    fail(f'{where}: escalation cites unknown drain')
                e_by_id[e['escalation_id']] = e
            elif kind == 'termination':
                t = validate_termcause(packet)
                check_packet_identity(seen_packet_digests, t['termination_id'], t, where)
                if 'drain_ref' in t:
                    if t['drain_ref'] not in d_by_id:
                        fail(f'{where}: termination cites unknown drain')
                    d = d_by_id[t['drain_ref']]
                    if t['end_cause'] in {'requested_stop', 'graceful_exit'} and d['drain_state'] != 'drained':
                        fail(f'{where}: clean/requested termination cites non-drained drain')
                if 'escalation_ref' in t:
                    if t['escalation_ref'] not in e_by_id:
                        fail(f'{where}: termination cites unknown escalation')
                    e = e_by_id[t['escalation_ref']]
                    if e['force_level'] in {'kill', 'adapter_force', 'platform_evict'} and t['exit_class'] == 'clean':
                        fail(f'{where}: kill-level escalation cannot settle as clean termination')
                    if e['escalation_state'] == 'applied' and t['termination_state'] != 'ended':
                        fail(f'{where}: applied escalation cited by non-ended termination')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'shutdown':
            accepted, detail = validate_shutdown_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-shutdown-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-shutdown-corpus] FAIL: corpus is stale; run tools/steward_shutdown_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-shutdown-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
