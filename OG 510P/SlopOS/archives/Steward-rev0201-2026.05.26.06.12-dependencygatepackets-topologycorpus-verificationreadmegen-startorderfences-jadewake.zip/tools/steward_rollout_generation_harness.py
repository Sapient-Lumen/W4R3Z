#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/rollout-generation-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
PLAN_RE = re.compile(r'^gplan_[a-z0-9]{16}$')
GEN_RE = re.compile(r'^gen_[a-z0-9]{16}$')
APPLY_RE = re.compile(r'^apply_[a-z0-9]{16}$')
READY_RE = re.compile(r'^gready_[a-z0-9]{16}$')
PROMO_RE = re.compile(r'^promo_[a-z0-9]{16}$')
RTCYCLE_RE = re.compile(r'^rtcycle_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_authorized', 'claims_authorization', 'claims_approval',
    'claims_current', 'claims_current_state', 'claims_fresh', 'claims_material_freshness',
    'claims_reload', 'claims_reloaded', 'claims_readiness', 'claims_ready', 'claims_global_ready',
    'claims_serving', 'claims_traffic', 'claims_traffic_binding', 'claims_promotion',
    'claims_effect_success', 'claims_execution', 'claims_mutation', 'claims_policy',
    'claims_native_truth', 'claims_lossless', 'claims_drained', 'claims_work_complete',
    'claims_operation_executed', 'claims_scheduled', 'claims_reserved', 'claims_lock',
    'claims_success', 'claims_stable', 'claims_resolved', 'claims_rollback_success',
    'claims_all_workers_updated', 'authority', 'authorized', 'approved', 'current_state',
    'current', 'fresh', 'ready', 'readiness', 'global_ready', 'serving', 'effect_success',
    'execution', 'mutation', 'policy_authority', 'native_truth', 'operation_executed',
    'lossless', 'drained', 'work_complete', 'success', 'stable', 'resolved',
    'auto_execute', 'macro', 'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle',
    'raw_text', 'token', 'secret', 'bearer', 'credential', 'password', 'cookie',
    'authorization', 'value', 'path', 'raw_path', 'host_path', 'endpoint', 'raw_endpoint',
    'url', 'uri', 'fd', 'descriptor_number', 'pid', 'ppid', 'pgid', 'cgroup',
    'cgroup_path', 'systemd_unit', 'host_unit', 'pod_name', 'container_id', 'node_name',
    'process_name', 'pty_name', 'shell_job', 'pane_text', 'command_text', 'k8s_resource_name',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'policy', 'scheduler', 'auditor'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

GENPLAN_REQUIRED = COMMON_REQUIRED | {
    'plan_id', 'generation_id', 'prior_generation_ref', 'material_refs', 'change_kind',
    'plan_state', 'created_at_ms', 'expires_at_ms', 'rollback_from_ref', 'reason',
}
GENPLAN_ALLOWED = GENPLAN_REQUIRED | COMMON_OPTIONAL
CHANGE_KINDS = {'initial', 'reload', 'reconfigure', 'rollback', 'rollforward', 'hot_patch', 'unknown'}
PLAN_STATES = {'planned', 'admitted', 'deferred', 'abandoned', 'unknown'}
GENPLAN_NON_IMPLICATIONS = {
    'not-material-freshness', 'not-apply', 'not-reload', 'not-readiness',
    'not-serving', 'not-traffic-binding', 'not-promotion', 'not-effect-success',
    'not-execution', 'not-rollback-success',
}

RECONF_REQUIRED = COMMON_REQUIRED | {
    'apply_id', 'plan_ref', 'generation_ref', 'runtime_cycle_ref', 'material_freshness_refs',
    'apply_state', 'reload_mode', 'applied_at_ms', 'restart_required', 'error_reason',
}
RECONF_ALLOWED = RECONF_REQUIRED | COMMON_OPTIONAL
APPLY_STATES = {'started', 'applied', 'failed', 'partial', 'rolled_back', 'unknown'}
RELOAD_MODES = {'none', 'signal', 'api', 'restart', 'hot_swap', 'supervisor', 'unknown'}
RECONF_NON_IMPLICATIONS = {
    'not-material-freshness', 'not-readiness', 'not-serving', 'not-traffic-binding',
    'not-promotion', 'not-effect-success', 'not-all-workers-updated', 'not-current-state',
}

GENREADY_REQUIRED = COMMON_REQUIRED | {
    'readiness_id', 'generation_ref', 'apply_ref', 'probe_refs', 'ready_state',
    'readiness_scope', 'evaluated_at_ms', 'expires_at_ms', 'required_probe_count',
    'passing_probe_count', 'failure_reason',
}
GENREADY_ALLOWED = GENREADY_REQUIRED | COMMON_OPTIONAL
READY_STATES = {'candidate', 'ready', 'degraded', 'failed', 'unknown'}
READINESS_SCOPES = {'control_plane', 'serve_path', 'canary', 'operator_view', 'unknown'}
GENREADY_NON_IMPLICATIONS = {
    'not-global-readiness', 'not-serving', 'not-traffic-binding', 'not-promotion',
    'not-effect-success', 'not-stability', 'not-work-completion', 'not-current-state',
}

PROMOTION_REQUIRED = COMMON_REQUIRED | {
    'promotion_id', 'generation_ref', 'readiness_ref', 'traffic_binding_ref',
    'promotion_state', 'promotion_scope', 'weight_percent', 'previous_generation_ref',
    'applied_at_ms', 'rollback_ref', 'reason',
}
PROMOTION_ALLOWED = PROMOTION_REQUIRED | COMMON_OPTIONAL
PROMOTION_STATES = {'planned', 'applied', 'rolled_back', 'aborted', 'unknown'}
PROMOTION_SCOPES = {'none', 'shadow', 'canary', 'partial', 'full', 'unknown'}
PROMOTION_NON_IMPLICATIONS = {
    'not-readiness', 'not-serving', 'not-effect-success', 'not-work-completion',
    'not-lossless', 'not-drain', 'not-global-stability', 'not-rollback-success',
}

AMBIENT_REFS = {'ambient', 'current', 'pane:current', 'terminal:current', 'component:current', 'generation:current', 'traffic:current'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:',
        '/var/', '/proc/', '/tmp/', 'ready for all traffic', 'global readiness',
        'rolled back safely', 'effect success', 'all workers updated', 'traffic proves success',
        'reload proves ready', 'projected means fresh', 'safe to proceed as executed',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False, regex: re.Pattern[str] = REF_RE) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_pattern(item, regex, f'{path}[{idx}]')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=32))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def require_ref(value: Any, path: str, *, allow_none: bool = False, regex: re.Pattern[str] = REF_RE) -> None:
    require_pattern(value, regex, path)
    if value in AMBIENT_REFS:
        fail(f'{path}: must be an exact ref, not ambient/current context')
    if not allow_none and value == 'none':
        fail(f'{path}: none is not allowed here')


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=32)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_genplan(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, GENPLAN_ALLOWED, GENPLAN_REQUIRED, 'ST-GENPLAN v0')
    require_pattern(obj['plan_id'], PLAN_RE, '$.plan_id')
    require_pattern(obj['generation_id'], GEN_RE, '$.generation_id')
    require_ref(obj['prior_generation_ref'], '$.prior_generation_ref', allow_none=True)
    require_refs(obj['material_refs'], '$.material_refs', maximum=16, allow_empty=obj['change_kind'] == 'unknown')
    if obj['change_kind'] not in CHANGE_KINDS:
        fail('$.change_kind: invalid')
    if obj['plan_state'] not in PLAN_STATES:
        fail('$.plan_state: invalid')
    require_int(obj['created_at_ms'], '$.created_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_ref(obj['rollback_from_ref'], '$.rollback_from_ref', allow_none=True)
    require_text(obj['reason'], '$.reason')
    if obj['created_at_ms'] > obj['observed_at_ms']:
        fail('$.created_at_ms: cannot be after observed_at_ms')
    if obj['expires_at_ms'] <= obj['created_at_ms']:
        fail('$.expires_at_ms: must be after created_at_ms')
    if obj['plan_state'] in {'planned', 'admitted'} and obj['expires_at_ms'] <= obj['observed_at_ms']:
        fail('$.expires_at_ms: active plan state cannot already be expired')
    if obj['change_kind'] == 'initial' and obj['prior_generation_ref'] != 'none':
        fail('$.prior_generation_ref: initial generation must not name a prior generation')
    if obj['change_kind'] != 'initial' and obj['prior_generation_ref'] == 'none':
        fail('$.prior_generation_ref: non-initial generation needs a prior generation ref')
    if obj['change_kind'] == 'rollback' and obj['rollback_from_ref'] == 'none':
        fail('$.rollback_from_ref: rollback plan needs rollback_from_ref')
    if obj['change_kind'] != 'rollback' and obj['rollback_from_ref'] != 'none':
        fail('$.rollback_from_ref: non-rollback plan must use none')
    if obj['plan_state'] in {'deferred', 'abandoned', 'unknown'} and obj['reason'] == 'none':
        fail('$.reason: deferred/abandoned/unknown plan needs a reason')
    if obj['plan_state'] in {'planned', 'admitted'} and obj['reason'] != 'none':
        fail('$.reason: active plan state must use none')
    require_non_implications(obj['non_implications'], GENPLAN_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_reconfapply(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, RECONF_ALLOWED, RECONF_REQUIRED, 'ST-RECONFAPPLY v0')
    require_pattern(obj['apply_id'], APPLY_RE, '$.apply_id')
    require_pattern(obj['plan_ref'], PLAN_RE, '$.plan_ref')
    require_pattern(obj['generation_ref'], GEN_RE, '$.generation_ref')
    require_pattern(obj['runtime_cycle_ref'], RTCYCLE_RE, '$.runtime_cycle_ref')
    material_refs = require_refs(obj['material_freshness_refs'], '$.material_freshness_refs', maximum=16, allow_empty=obj['apply_state'] in {'started', 'failed', 'unknown'})
    if obj['apply_state'] not in APPLY_STATES:
        fail('$.apply_state: invalid')
    if obj['reload_mode'] not in RELOAD_MODES:
        fail('$.reload_mode: invalid')
    require_int(obj['applied_at_ms'], '$.applied_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_bool(obj['restart_required'], '$.restart_required')
    require_text(obj['error_reason'], '$.error_reason')
    if obj['applied_at_ms'] > obj['observed_at_ms']:
        fail('$.applied_at_ms: cannot be after observed_at_ms')
    if obj['apply_state'] == 'applied':
        if obj['error_reason'] != 'none':
            fail('$.error_reason: applied state must use none')
        if not material_refs:
            fail('$.material_freshness_refs: applied state needs material freshness refs')
        if obj['reload_mode'] in {'none', 'unknown'}:
            fail('$.reload_mode: applied state needs an explicit reload/apply mode')
    if obj['apply_state'] in {'failed', 'partial', 'rolled_back', 'unknown'} and obj['error_reason'] == 'none':
        fail('$.error_reason: failed/partial/rolled_back/unknown state needs a reason')
    if obj['apply_state'] in {'started', 'applied'} and obj['error_reason'] != 'none':
        fail('$.error_reason: started/applied state must use none')
    require_non_implications(obj['non_implications'], RECONF_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_genready(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, GENREADY_ALLOWED, GENREADY_REQUIRED, 'ST-GENREADY v0')
    require_pattern(obj['readiness_id'], READY_RE, '$.readiness_id')
    require_pattern(obj['generation_ref'], GEN_RE, '$.generation_ref')
    require_pattern(obj['apply_ref'], APPLY_RE, '$.apply_ref')
    probe_refs = require_refs(obj['probe_refs'], '$.probe_refs', maximum=16, allow_empty=obj['ready_state'] in {'candidate', 'unknown'})
    if obj['ready_state'] not in READY_STATES:
        fail('$.ready_state: invalid')
    if obj['readiness_scope'] not in READINESS_SCOPES:
        fail('$.readiness_scope: invalid')
    require_int(obj['evaluated_at_ms'], '$.evaluated_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['required_probe_count'], '$.required_probe_count', minimum=0, maximum=64)
    require_int(obj['passing_probe_count'], '$.passing_probe_count', minimum=0, maximum=64)
    require_text(obj['failure_reason'], '$.failure_reason')
    if obj['evaluated_at_ms'] > obj['observed_at_ms']:
        fail('$.evaluated_at_ms: cannot be after observed_at_ms')
    if obj['expires_at_ms'] <= obj['evaluated_at_ms']:
        fail('$.expires_at_ms: must be after evaluated_at_ms')
    if obj['passing_probe_count'] > len(probe_refs):
        fail('$.passing_probe_count: cannot exceed probe_refs length')
    if obj['ready_state'] == 'ready':
        if obj['expires_at_ms'] <= obj['observed_at_ms']:
            fail('$.expires_at_ms: ready generation must still be fresh at observation')
        if obj['failure_reason'] != 'none':
            fail('$.failure_reason: ready state must use none')
        if obj['required_probe_count'] < 1:
            fail('$.required_probe_count: ready state needs at least one required probe')
        if obj['passing_probe_count'] < obj['required_probe_count']:
            fail('$.passing_probe_count: ready state needs enough passing probes')
        if len(probe_refs) < obj['required_probe_count']:
            fail('$.probe_refs: ready state needs probe refs for required probes')
    if obj['ready_state'] in {'degraded', 'failed', 'unknown'} and obj['failure_reason'] == 'none':
        fail('$.failure_reason: degraded/failed/unknown readiness needs a reason')
    if obj['ready_state'] in {'candidate', 'ready'} and obj['failure_reason'] != 'none':
        fail('$.failure_reason: candidate/ready state must use none')
    require_non_implications(obj['non_implications'], GENREADY_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_promotion(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, PROMOTION_ALLOWED, PROMOTION_REQUIRED, 'ST-PROMOTION v0')
    require_pattern(obj['promotion_id'], PROMO_RE, '$.promotion_id')
    require_pattern(obj['generation_ref'], GEN_RE, '$.generation_ref')
    require_ref(obj['readiness_ref'], '$.readiness_ref', allow_none=True, regex=READY_RE if obj['readiness_ref'] != 'none' else REF_RE)
    require_ref(obj['traffic_binding_ref'], '$.traffic_binding_ref', allow_none=True)
    if obj['promotion_state'] not in PROMOTION_STATES:
        fail('$.promotion_state: invalid')
    if obj['promotion_scope'] not in PROMOTION_SCOPES:
        fail('$.promotion_scope: invalid')
    require_int(obj['weight_percent'], '$.weight_percent', minimum=0, maximum=100)
    require_ref(obj['previous_generation_ref'], '$.previous_generation_ref', allow_none=True)
    require_int(obj['applied_at_ms'], '$.applied_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_ref(obj['rollback_ref'], '$.rollback_ref', allow_none=True)
    require_text(obj['reason'], '$.reason')
    if obj['applied_at_ms'] > obj['observed_at_ms']:
        fail('$.applied_at_ms: cannot be after observed_at_ms')
    if obj['promotion_scope'] == 'none' and obj['weight_percent'] != 0:
        fail('$.weight_percent: none scope must use zero weight')
    if obj['promotion_state'] == 'applied':
        if obj['readiness_ref'] == 'none':
            fail('$.readiness_ref: applied promotion needs readiness witness ref')
        if obj['traffic_binding_ref'] == 'none':
            fail('$.traffic_binding_ref: applied promotion needs traffic-binding witness ref')
        if obj['weight_percent'] < 1:
            fail('$.weight_percent: applied promotion needs positive weight')
        if obj['promotion_scope'] == 'full' and obj['weight_percent'] != 100:
            fail('$.weight_percent: full applied promotion must be 100')
        if obj['promotion_scope'] in {'none', 'unknown'}:
            fail('$.promotion_scope: applied promotion needs concrete scope')
        if obj['rollback_ref'] != 'none':
            fail('$.rollback_ref: applied promotion must use none')
        if obj['reason'] != 'none':
            fail('$.reason: applied promotion must use none')
    if obj['promotion_state'] == 'rolled_back':
        if obj['rollback_ref'] == 'none':
            fail('$.rollback_ref: rolled_back promotion needs rollback ref')
        if obj['previous_generation_ref'] == 'none':
            fail('$.previous_generation_ref: rolled_back promotion needs previous generation ref')
        if obj['reason'] == 'none':
            fail('$.reason: rolled_back promotion needs a reason')
    if obj['promotion_state'] in {'aborted', 'unknown'} and obj['reason'] == 'none':
        fail('$.reason: aborted/unknown promotion needs a reason')
    if obj['promotion_state'] in {'planned', 'applied'} and obj['reason'] != 'none':
        fail('$.reason: planned/applied promotion must use none')
    require_non_implications(obj['non_implications'], PROMOTION_NON_IMPLICATIONS, '$.non_implications')
    return obj


def schema_case(case_id: str, object_kind: str, obj: dict[str, Any] | None, expect: str, why: str, *, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        assert obj is not None
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'rollout_generation', 'events': events, 'expect': expect, 'why': why}


def base_common(schema: str, witness_id: str, *, observed: int = 2200, issuer_kind: str = 'steward') -> dict[str, Any]:
    return {
        'schema': schema,
        'witness_id': witness_id,
        'cid': 'demo.web',
        'issuer': {'kind': issuer_kind, 'id': f'steward.{issuer_kind}'},
        'observed_at_ms': observed,
        'basis_refs': ['sha256:' + '2' * 64],
    }


def build_cases() -> list[dict[str, Any]]:
    plan = {
        **base_common('ST-GENPLAN v0', 'wit_a000000000000001'),
        'plan_id': 'gplan_1000000000000001',
        'generation_id': 'gen_1000000000000002',
        'prior_generation_ref': 'gen_1000000000000001',
        'material_refs': ['matfresh_1000000000000001'],
        'change_kind': 'reconfigure',
        'plan_state': 'admitted',
        'created_at_ms': 2100,
        'expires_at_ms': 5000,
        'rollback_from_ref': 'none',
        'reason': 'none',
        'non_implications': sorted(GENPLAN_NON_IMPLICATIONS),
    }
    rollback_plan = {
        **base_common('ST-GENPLAN v0', 'wit_a000000000000002'),
        'plan_id': 'gplan_1000000000000002',
        'generation_id': 'gen_1000000000000003',
        'prior_generation_ref': 'gen_1000000000000002',
        'material_refs': ['matfresh_1000000000000002'],
        'change_kind': 'rollback',
        'plan_state': 'admitted',
        'created_at_ms': 2100,
        'expires_at_ms': 5000,
        'rollback_from_ref': 'gen_1000000000000002',
        'reason': 'none',
        'non_implications': sorted(GENPLAN_NON_IMPLICATIONS),
    }
    abandoned_plan = {**plan, 'witness_id': 'wit_a000000000000003', 'plan_id': 'gplan_1000000000000003', 'plan_state': 'abandoned', 'reason': 'operator canceled'}

    apply = {
        **base_common('ST-RECONFAPPLY v0', 'wit_b000000000000001'),
        'apply_id': 'apply_1000000000000001',
        'plan_ref': 'gplan_1000000000000001',
        'generation_ref': 'gen_1000000000000002',
        'runtime_cycle_ref': 'rtcycle_1000000000000001',
        'material_freshness_refs': ['matfresh_1000000000000001'],
        'apply_state': 'applied',
        'reload_mode': 'api',
        'applied_at_ms': 2180,
        'restart_required': False,
        'error_reason': 'none',
        'non_implications': sorted(RECONF_NON_IMPLICATIONS),
    }
    started_apply = {**apply, 'witness_id': 'wit_b000000000000002', 'apply_id': 'apply_1000000000000002', 'apply_state': 'started', 'reload_mode': 'api', 'material_freshness_refs': [], 'applied_at_ms': 2160}
    failed_apply = {**apply, 'witness_id': 'wit_b000000000000003', 'apply_id': 'apply_1000000000000003', 'apply_state': 'failed', 'reload_mode': 'api', 'error_reason': 'component rejected configuration'}
    rollback_apply = {
        **apply,
        'witness_id': 'wit_b000000000000004',
        'apply_id': 'apply_1000000000000004',
        'plan_ref': 'gplan_1000000000000002',
        'generation_ref': 'gen_1000000000000003',
        'material_freshness_refs': ['matfresh_1000000000000002'],
        'apply_state': 'rolled_back',
        'error_reason': 'rollback applied but effects remain separately unsettled',
    }

    ready = {
        **base_common('ST-GENREADY v0', 'wit_c000000000000001'),
        'readiness_id': 'gready_1000000000000001',
        'generation_ref': 'gen_1000000000000002',
        'apply_ref': 'apply_1000000000000001',
        'probe_refs': ['probe_1000000000000001', 'probe_1000000000000002'],
        'ready_state': 'ready',
        'readiness_scope': 'canary',
        'evaluated_at_ms': 2190,
        'expires_at_ms': 4500,
        'required_probe_count': 2,
        'passing_probe_count': 2,
        'failure_reason': 'none',
        'non_implications': sorted(GENREADY_NON_IMPLICATIONS),
    }
    candidate_ready = {**ready, 'witness_id': 'wit_c000000000000002', 'readiness_id': 'gready_1000000000000002', 'ready_state': 'candidate', 'required_probe_count': 0, 'passing_probe_count': 0, 'probe_refs': []}
    degraded_ready = {**ready, 'witness_id': 'wit_c000000000000003', 'readiness_id': 'gready_1000000000000003', 'ready_state': 'degraded', 'passing_probe_count': 1, 'failure_reason': 'one vantage stale'}
    expired_ready = {**ready, 'witness_id': 'wit_c000000000000004', 'readiness_id': 'gready_1000000000000004', 'expires_at_ms': 2150}

    promotion = {
        **base_common('ST-PROMOTION v0', 'wit_d000000000000001'),
        'promotion_id': 'promo_1000000000000001',
        'generation_ref': 'gen_1000000000000002',
        'readiness_ref': 'gready_1000000000000001',
        'traffic_binding_ref': 'tbind_1000000000000001',
        'promotion_state': 'applied',
        'promotion_scope': 'canary',
        'weight_percent': 10,
        'previous_generation_ref': 'gen_1000000000000001',
        'applied_at_ms': 2200,
        'rollback_ref': 'none',
        'reason': 'none',
        'non_implications': sorted(PROMOTION_NON_IMPLICATIONS),
    }
    full_promotion = {**promotion, 'witness_id': 'wit_d000000000000002', 'promotion_id': 'promo_1000000000000002', 'promotion_scope': 'full', 'weight_percent': 100}
    rollback_promotion = {
        **promotion,
        'witness_id': 'wit_d000000000000003',
        'promotion_id': 'promo_1000000000000003',
        'generation_ref': 'gen_1000000000000003',
        'readiness_ref': 'none',
        'traffic_binding_ref': 'tbind_1000000000000002',
        'promotion_state': 'rolled_back',
        'promotion_scope': 'full',
        'weight_percent': 100,
        'previous_generation_ref': 'gen_1000000000000001',
        'applied_at_ms': 2200,
        'rollback_ref': 'apply_1000000000000004',
        'reason': 'returned traffic to previous generation mapping',
    }

    return [
        schema_case('genplan.accept.reconfigure-admitted', 'ST-GENPLAN', plan, 'accept', 'a generation plan can admit a reconfiguration without applying, reloading, readiness, promotion, or effect claims'),
        schema_case('genplan.accept.rollback-plan', 'ST-GENPLAN', rollback_plan, 'accept', 'rollback planning names a source generation without claiming compensation or success'),
        schema_case('genplan.reject.material-freshness-flattery', 'ST-GENPLAN', {**plan, 'claims_material_freshness': True}, 'reject', 'planned material is not material freshness'),
        schema_case('genplan.reject.rollback-without-source', 'ST-GENPLAN', {**rollback_plan, 'rollback_from_ref': 'none'}, 'reject', 'rollback plans must name the generation being rolled back from'),
        schema_case('genplan.reject.noninitial-without-prior', 'ST-GENPLAN', {**plan, 'prior_generation_ref': 'none'}, 'reject', 'non-initial generation plans must name the prior generation'),
        schema_case('reconfapply.accept.applied-api', 'ST-RECONFAPPLY', apply, 'accept', 'an apply witness can say reload/application happened without readiness or promotion'),
        schema_case('reconfapply.accept.started', 'ST-RECONFAPPLY', started_apply, 'accept', 'a started apply window is not reload completion or readiness'),
        schema_case('reconfapply.reject.readiness-flattery', 'ST-RECONFAPPLY', {**apply, 'claims_ready': True}, 'reject', 'applied reconfiguration is not readiness'),
        schema_case('reconfapply.reject.applied-without-material-freshness', 'ST-RECONFAPPLY', {**apply, 'material_freshness_refs': []}, 'reject', 'applied reconfiguration needs adjacent material freshness refs'),
        schema_case('reconfapply.reject.applied-without-reload-mode', 'ST-RECONFAPPLY', {**apply, 'reload_mode': 'none'}, 'reject', 'applied reconfiguration must say how it was applied or reloaded'),
        schema_case('genready.accept.ready-canary', 'ST-GENREADY', ready, 'accept', 'generation readiness can be scoped and fresh without global traffic or serving claims'),
        schema_case('genready.accept.degraded', 'ST-GENREADY', degraded_ready, 'accept', 'generation readiness may honestly degrade without collapsing into failure or traffic binding'),
        schema_case('genready.reject.probe-count-mismatch', 'ST-GENREADY', {**ready, 'passing_probe_count': 1}, 'reject', 'ready state needs enough passing probes'),
        schema_case('genready.reject.global-ready-flattery', 'ST-GENREADY', {**ready, 'claims_global_ready': True}, 'reject', 'scoped generation readiness is not global readiness'),
        schema_case('genready.reject.expired-ready', 'ST-GENREADY', expired_ready, 'reject', 'ready generation evidence must still be fresh'),
        schema_case('promotion.accept.applied-canary', 'ST-PROMOTION', promotion, 'accept', 'promotion can apply a scoped traffic shift without serving or effect-success claims'),
        schema_case('promotion.accept.rolled-back', 'ST-PROMOTION', rollback_promotion, 'accept', 'rolled-back promotion records route restoration without proving effect compensation'),
        schema_case('promotion.reject.effect-success-flattery', 'ST-PROMOTION', {**promotion, 'claims_effect_success': True}, 'reject', 'promotion is not work or effect success'),
        schema_case('promotion.reject.applied-without-readiness', 'ST-PROMOTION', {**promotion, 'readiness_ref': 'none'}, 'reject', 'applied promotion needs a generation readiness ref'),
        schema_case('promotion.reject.full-weight-mismatch', 'ST-PROMOTION', {**full_promotion, 'weight_percent': 50}, 'reject', 'full promotion must carry 100 percent weight'),
        schema_case('promotion.reject.duplicate-json-key', 'ST-PROMOTION', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-PROMOTION v0","schema":"ST-PROMOTION v0","witness_id":"wit_d000000000000004","cid":"demo.web","issuer":{"kind":"steward","id":"steward.core"},"observed_at_ms":2200,"basis_refs":["sha256:2222222222222222222222222222222222222222222222222222222222222222"],"non_implications":[],"promotion_id":"promo_1000000000000004","generation_ref":"gen_1000000000000002","readiness_ref":"gready_1000000000000001","traffic_binding_ref":"tbind_1000000000000001","promotion_state":"applied","promotion_scope":"canary","weight_percent":10,"previous_generation_ref":"gen_1000000000000001","applied_at_ms":2200,"rollback_ref":"none","reason":"none"}'),

        flow_case('rollout.accept.reconfigure-to-canary-promotion', [
            {'event': 'plan', 'packet': plan},
            {'event': 'apply', 'packet': apply},
            {'event': 'readiness', 'packet': ready},
            {'event': 'promotion', 'packet': promotion},
        ], 'accept', 'a full generation path can move from plan to apply to scoped readiness to canary promotion without claiming effects'),
        flow_case('rollout.accept.rollback-route-restoration', [
            {'event': 'plan', 'packet': rollback_plan},
            {'event': 'apply', 'packet': rollback_apply},
            {'event': 'promotion', 'packet': rollback_promotion},
        ], 'accept', 'rollback route restoration can be recorded without compensation or effect success'),
        flow_case('rollout.reject.apply-without-plan', [
            {'event': 'apply', 'packet': apply},
        ], 'reject', 'reconfiguration apply must bind to a known generation plan'),
        flow_case('rollout.reject.apply-abandoned-plan', [
            {'event': 'plan', 'packet': abandoned_plan},
            {'event': 'apply', 'packet': {**apply, 'plan_ref': 'gplan_1000000000000003'}},
        ], 'reject', 'abandoned generation plans cannot be applied'),
        flow_case('rollout.reject.ready-without-applied-generation', [
            {'event': 'plan', 'packet': plan},
            {'event': 'apply', 'packet': started_apply},
            {'event': 'readiness', 'packet': {**ready, 'apply_ref': 'apply_1000000000000002'}},
        ], 'reject', 'generation readiness cannot be ready before the generation was applied'),
        flow_case('rollout.reject.promotion-without-ready-generation', [
            {'event': 'plan', 'packet': plan},
            {'event': 'apply', 'packet': apply},
            {'event': 'readiness', 'packet': degraded_ready},
            {'event': 'promotion', 'packet': {**promotion, 'readiness_ref': 'gready_1000000000000003'}},
        ], 'reject', 'applied promotion cannot use degraded readiness as ready truth'),
        flow_case('rollout.reject.promotion-uses-expired-readiness', [
            {'event': 'plan', 'packet': plan},
            {'event': 'apply', 'packet': apply},
            {'event': 'readiness', 'packet': expired_ready},
            {'event': 'promotion', 'packet': {**promotion, 'readiness_ref': 'gready_1000000000000004'}},
        ], 'reject', 'applied promotion cannot use expired readiness evidence'),
        flow_case('rollout.reject.promotion-as-serving', [
            {'event': 'plan', 'packet': plan},
            {'event': 'apply', 'packet': apply},
            {'event': 'readiness', 'packet': ready},
            {'event': 'promotion', 'packet': promotion, 'claims_serving': True},
        ], 'reject', 'promotion events cannot claim serving'),
        flow_case('rollout.reject.duplicate-generation-drift', [
            {'event': 'plan', 'packet': plan},
            {'event': 'plan', 'packet': {**plan, 'material_refs': ['matfresh_9999999999999999']}},
        ], 'reject', 'generation ids cannot be reused for different canonical generation plans'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-GENPLAN':
            validate_genplan(obj)
        elif kind == 'ST-RECONFAPPLY':
            validate_reconfapply(obj)
        elif kind == 'ST-GENREADY':
            validate_genready(obj)
        elif kind == 'ST-PROMOTION':
            validate_promotion(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        plans: dict[str, dict[str, Any]] = {}
        plans_by_generation: dict[str, dict[str, Any]] = {}
        applies: dict[str, dict[str, Any]] = {}
        readiness: dict[str, dict[str, Any]] = {}
        seen_packets: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'plan':
                plan = validate_genplan(packet)
                check_packet_identity(seen_packets, plan['generation_id'], plan, where)
                check_packet_identity(seen_packets, plan['plan_id'], plan, where)
                plans[plan['plan_id']] = plan
                existing = plans_by_generation.get(plan['generation_id'])
                if existing is not None and digest(existing) != digest(plan):
                    fail(f'{where}: generation id reused for different canonical plan')
                plans_by_generation[plan['generation_id']] = plan
            elif kind == 'apply':
                apply = validate_reconfapply(packet)
                check_packet_identity(seen_packets, apply['apply_id'], apply, where)
                plan = plans.get(apply['plan_ref'])
                if plan is None:
                    fail(f'{where}: apply references unknown generation plan {apply["plan_ref"]}')
                if plan['generation_id'] != apply['generation_ref']:
                    fail(f'{where}: apply generation does not match plan generation')
                if plan['plan_state'] not in {'planned', 'admitted'}:
                    fail(f'{where}: apply cannot use {plan["plan_state"]} generation plan')
                applies[apply['apply_id']] = apply
            elif kind == 'readiness':
                ready = validate_genready(packet)
                check_packet_identity(seen_packets, ready['readiness_id'], ready, where)
                apply = applies.get(ready['apply_ref'])
                if apply is None:
                    fail(f'{where}: readiness references unknown apply {ready["apply_ref"]}')
                if apply['generation_ref'] != ready['generation_ref']:
                    fail(f'{where}: readiness generation does not match apply generation')
                if ready['ready_state'] == 'ready' and apply['apply_state'] != 'applied':
                    fail(f'{where}: ready generation requires applied reconfiguration')
                readiness[ready['readiness_id']] = ready
            elif kind == 'promotion':
                promo = validate_promotion(packet)
                check_packet_identity(seen_packets, promo['promotion_id'], promo, where)
                if promo['promotion_state'] == 'applied':
                    ready = readiness.get(promo['readiness_ref'])
                    if ready is None:
                        fail(f'{where}: promotion references unknown readiness {promo["readiness_ref"]}')
                    if ready['generation_ref'] != promo['generation_ref']:
                        fail(f'{where}: promotion generation does not match readiness generation')
                    if ready['ready_state'] != 'ready':
                        fail(f'{where}: applied promotion needs ready generation evidence')
                    if ready['expires_at_ms'] <= promo['applied_at_ms']:
                        fail(f'{where}: promotion uses expired readiness evidence')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'rollout_generation':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-rollout-generation-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-rollout-generation-corpus] FAIL: corpus is stale; run tools/steward_rollout_generation_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-rollout-generation-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
