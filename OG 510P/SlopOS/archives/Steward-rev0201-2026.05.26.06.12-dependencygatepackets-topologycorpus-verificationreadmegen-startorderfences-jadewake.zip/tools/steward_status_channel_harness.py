#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/status-channel-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
SUB_RE = re.compile(r'^sub_[a-z0-9]{16}$')
DELIV_RE = re.compile(r'^del_[a-z0-9]{16}$')
SYNC_RE = re.compile(r'^sync_[a-z0-9]{16}$')
GAP_RE = re.compile(r'^gap_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_current', 'claims_current_state', 'claims_fresh',
    'claims_readiness', 'claims_ready', 'claims_serving', 'claims_effect_success',
    'claims_execution', 'claims_policy', 'claims_mutation', 'claims_native_truth',
    'claims_lossless', 'claims_drained', 'claims_custody', 'claims_work_complete',
    'claims_authorization', 'claims_approval', 'claims_operation_executed',
    'authority', 'current_state', 'current', 'fresh', 'ready', 'readiness',
    'serving', 'effect_success', 'execution', 'mutation', 'policy_authority',
    'native_truth', 'operation_executed', 'approved', 'authorized', 'lossless',
    'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle', 'raw_text',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie',
    'authorization', 'value', 'path', 'raw_path', 'host_path', 'endpoint',
    'raw_endpoint', 'url', 'uri', 'fd', 'descriptor_number', 'pid', 'ppid',
    'pgid', 'cgroup', 'cgroup_path', 'systemd_unit', 'host_unit', 'pod_name',
    'container_id', 'node_name', 'process_name', 'pty_name', 'shell_job',
    'pane_text', 'command_text', 'k8s_resource_name', 'firehose', 'bus_mutation',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'renderer', 'status_channel', 'adapter', 'auditor'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

LIMITS_REQUIRED = {'max_batch', 'max_lag_ms', 'coalesce', 'overflow_policy'}
LIMITS_ALLOWED = LIMITS_REQUIRED
OVERFLOW_POLICIES = {'drop_and_resync', 'coalesce_and_mark', 'block_until_read', 'unknown'}

OBSSUB_REQUIRED = COMMON_REQUIRED | {
    'subscription_id', 'consumer_ref', 'subject_ref', 'view_kind', 'delivery_mode',
    'accepted_kinds', 'limits', 'created_at_ms',
}
OBSSUB_OPTIONAL = COMMON_OPTIONAL | {'expires_at_ms', 'resume_cursor_ref'}
OBSSUB_ALLOWED = OBSSUB_REQUIRED | OBSSUB_OPTIONAL
VIEW_KINDS = {'component_status', 'lifecycle_witnesses', 'recent_receipts', 'observation_summary', 'witness_surface', 'unknown'}
DELIVERY_MODES = {'snapshot', 'stream', 'snapshot_then_stream', 'replay', 'unknown'}
ACCEPTED_KINDS = {'status', 'witness', 'receipt', 'barrier', 'gap', 'sync', 'surface_card'}
OBSSUB_NON_IMPLICATIONS = {
    'not-authority', 'not-mutation', 'not-authorization', 'not-current-state',
    'not-readiness', 'not-serving', 'not-effect-success',
}

OBSDELIV_REQUIRED = COMMON_REQUIRED | {
    'delivery_id', 'subscription_ref', 'seq_first', 'seq_last', 'delivery_state',
    'delivered_refs', 'dropped_count', 'cursor_after_ref', 'redaction_refs',
}
OBSDELIV_OPTIONAL = COMMON_OPTIONAL
OBSDELIV_ALLOWED = OBSDELIV_REQUIRED | OBSDELIV_OPTIONAL
DELIVERY_STATES = {'delivered', 'coalesced', 'dropped', 'requires_resync', 'heartbeat'}
OBSDELIV_NON_IMPLICATIONS = {
    'not-authority', 'not-current-state', 'not-readiness', 'not-serving',
    'not-execution', 'not-effect-success', 'not-lossless',
}

OBSSYNC_REQUIRED = COMMON_REQUIRED | {
    'sync_id', 'subscription_ref', 'synced_through_seq', 'sync_class',
    'snapshot_refs', 'gap_refs', 'as_of_ms', 'requires_recheck_refs',
}
OBSSYNC_OPTIONAL = COMMON_OPTIONAL | {'expires_or_recheck_by_ms'}
OBSSYNC_ALLOWED = OBSSYNC_REQUIRED | OBSSYNC_OPTIONAL
SYNC_CLASSES = {'initial_snapshot', 'synced_through', 'partial_window', 'resync_required', 'unknown'}
OBSSYNC_NON_IMPLICATIONS = {
    'not-authority', 'not-global-currentness', 'not-readiness', 'not-serving',
    'not-effect-success', 'not-quiescence', 'not-authorization',
}

OBSGAP_REQUIRED = COMMON_REQUIRED | {
    'gap_id', 'subscription_ref', 'gap_state', 'gap_from_seq', 'gap_to_seq',
    'gap_class', 'blocks_verbs', 'required_refreshes', 'cleared_by_refs',
}
OBSGAP_OPTIONAL = COMMON_OPTIONAL
OBSGAP_ALLOWED = OBSGAP_REQUIRED | OBSGAP_OPTIONAL
GAP_STATES = {'open', 'cleared', 'unknown'}
GAP_CLASSES = {'overflow', 'cursor_invalid', 'retention_expired', 'source_reset', 'consumer_lag', 'unknown'}
VERBS = {'start', 'stop', 'restart', 'quiesce', 'clear_repair_gate', 'inspect', 'recheck', 'explain'}
MUTATING_VERBS = {'start', 'stop', 'restart', 'quiesce', 'clear_repair_gate'}
OBSGAP_NON_IMPLICATIONS = {
    'not-authority', 'not-current-state', 'not-readiness', 'not-serving',
    'not-execution', 'not-effect-success', 'not-lossless',
}

AMBIENT_SUBJECTS = {'ambient', 'current', 'pane:current', 'terminal:current', 'whatever:current'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:',
        '/var/', '/proc/', '/tmp/', 'current state proof', 'ready proof',
        'executed already', 'effect success', 'authorized already', 'lossless stream',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    return items


def require_enum_list(value: Any, enum: set[str], path: str, *, maximum: int = 8, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=REF_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    bad = sorted(set(items) - enum)
    if bad:
        fail(f'{path}: invalid entries {bad}')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def require_sorted_refs(value: Any, path: str, *, maximum: int = 32, allow_empty: bool = False) -> list[str]:
    items = require_refs(value, path, maximum=maximum, allow_empty=allow_empty)
    if items != sorted(items):
        fail(f'{path}: refs must be sorted for canonical batch comparison')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_time_common(obj: dict[str, Any], path: str) -> None:
    require_int(obj['observed_at_ms'], f'{path}.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], f'{path}.unknown_reason')


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    validate_time_common(obj, '$')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    return obj


def validate_limits(value: Any, path: str) -> dict[str, Any]:
    limits = require_object(value, path)
    require_closed_keys(limits, LIMITS_ALLOWED, LIMITS_REQUIRED, path)
    require_int(limits['max_batch'], f'{path}.max_batch', minimum=1, maximum=1024)
    require_int(limits['max_lag_ms'], f'{path}.max_lag_ms', minimum=1, maximum=86_400_000)
    require_bool(limits['coalesce'], f'{path}.coalesce')
    if limits['overflow_policy'] not in OVERFLOW_POLICIES:
        fail(f'{path}.overflow_policy: invalid')
    if not limits['coalesce'] and limits['overflow_policy'] == 'coalesce_and_mark':
        fail(f'{path}.overflow_policy: coalesce_and_mark requires coalesce true')
    return limits


def validate_obssub(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSSUB_ALLOWED, OBSSUB_REQUIRED, 'ST-OBSSUB v0')
    require_pattern(obj['subscription_id'], SUB_RE, '$.subscription_id')
    require_pattern(obj['consumer_ref'], REF_RE, '$.consumer_ref')
    require_pattern(obj['subject_ref'], REF_RE, '$.subject_ref')
    if obj['subject_ref'] in AMBIENT_SUBJECTS:
        fail('$.subject_ref: subscription must target an explicit subject, not ambient/current context')
    if obj['view_kind'] not in VIEW_KINDS:
        fail('$.view_kind: invalid')
    if obj['delivery_mode'] not in DELIVERY_MODES:
        fail('$.delivery_mode: invalid')
    accepted = require_enum_list(obj['accepted_kinds'], ACCEPTED_KINDS, '$.accepted_kinds', maximum=8)
    if 'all' in accepted:
        fail('$.accepted_kinds: all is not an explicit view kind')
    validate_limits(obj['limits'], '$.limits')
    require_int(obj['created_at_ms'], '$.created_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['created_at_ms'] > obj['observed_at_ms']:
        fail('$.created_at_ms: cannot be after observed_at_ms')
    if 'expires_at_ms' in obj:
        require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['expires_at_ms'] <= obj['created_at_ms']:
            fail('$.expires_at_ms: must be after created_at_ms')
    if 'resume_cursor_ref' in obj:
        require_pattern(obj['resume_cursor_ref'], REF_RE, '$.resume_cursor_ref')
    require_non_implications(obj['non_implications'], OBSSUB_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_obsdeliv(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSDELIV_ALLOWED, OBSDELIV_REQUIRED, 'ST-OBSDELIV v0')
    require_pattern(obj['delivery_id'], DELIV_RE, '$.delivery_id')
    require_pattern(obj['subscription_ref'], SUB_RE, '$.subscription_ref')
    require_int(obj['seq_first'], '$.seq_first', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['seq_last'], '$.seq_last', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['seq_last'] < obj['seq_first']:
        fail('$.seq_last: precedes seq_first')
    if obj['delivery_state'] not in DELIVERY_STATES:
        fail('$.delivery_state: invalid')
    delivered = require_sorted_refs(obj['delivered_refs'], '$.delivered_refs', maximum=64, allow_empty=obj['delivery_state'] in {'dropped', 'requires_resync', 'heartbeat'})
    require_int(obj['dropped_count'], '$.dropped_count', minimum=0, maximum=1_000_000)
    require_pattern(obj['cursor_after_ref'], REF_RE, '$.cursor_after_ref')
    require_sorted_refs(obj['redaction_refs'], '$.redaction_refs', maximum=8, allow_empty=True)
    if obj['delivery_state'] in {'delivered', 'coalesced'} and not delivered:
        fail('$.delivered_refs: delivered/coalesced deliveries must carry refs')
    if obj['delivery_state'] in {'delivered', 'coalesced', 'heartbeat'} and obj['dropped_count']:
        fail('$.dropped_count: drops require dropped or requires_resync state')
    if obj['delivery_state'] in {'dropped', 'requires_resync'} and obj['dropped_count'] == 0:
        fail('$.dropped_count: dropped/requires_resync must name a positive dropped count')
    require_non_implications(obj['non_implications'], OBSDELIV_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_obssync(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSSYNC_ALLOWED, OBSSYNC_REQUIRED, 'ST-OBSSYNC v0')
    require_pattern(obj['sync_id'], SYNC_RE, '$.sync_id')
    require_pattern(obj['subscription_ref'], SUB_RE, '$.subscription_ref')
    require_int(obj['synced_through_seq'], '$.synced_through_seq', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['sync_class'] not in SYNC_CLASSES:
        fail('$.sync_class: invalid')
    require_sorted_refs(obj['snapshot_refs'], '$.snapshot_refs', maximum=64, allow_empty=obj['sync_class'] not in {'initial_snapshot'})
    gap_refs = require_sorted_refs(obj['gap_refs'], '$.gap_refs', maximum=16, allow_empty=True)
    rechecks = require_sorted_refs(obj['requires_recheck_refs'], '$.requires_recheck_refs', maximum=16, allow_empty=True)
    require_int(obj['as_of_ms'], '$.as_of_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['as_of_ms'] > obj['observed_at_ms']:
        fail('$.as_of_ms: cannot be after observed_at_ms')
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail('$.expires_or_recheck_by_ms: precedes observed_at_ms')
    if obj['sync_class'] in {'initial_snapshot', 'synced_through'} and gap_refs:
        fail('$.gap_refs: gap refs are incompatible with initial_snapshot/synced_through')
    if obj['sync_class'] == 'resync_required' and not (gap_refs or rechecks):
        fail('$.requires_recheck_refs: resync_required must name a gap or recheck requirement')
    require_non_implications(obj['non_implications'], OBSSYNC_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_obsgap(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, OBSGAP_ALLOWED, OBSGAP_REQUIRED, 'ST-OBSGAP v0')
    require_pattern(obj['gap_id'], GAP_RE, '$.gap_id')
    require_pattern(obj['subscription_ref'], SUB_RE, '$.subscription_ref')
    if obj['gap_state'] not in GAP_STATES:
        fail('$.gap_state: invalid')
    require_int(obj['gap_from_seq'], '$.gap_from_seq', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['gap_to_seq'], '$.gap_to_seq', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['gap_to_seq'] < obj['gap_from_seq']:
        fail('$.gap_to_seq: precedes gap_from_seq')
    if obj['gap_class'] not in GAP_CLASSES:
        fail('$.gap_class: invalid')
    blocks = require_enum_list(obj['blocks_verbs'], VERBS, '$.blocks_verbs', maximum=16, allow_empty=obj['gap_state'] == 'cleared')
    refreshes = require_sorted_refs(obj['required_refreshes'], '$.required_refreshes', maximum=16, allow_empty=obj['gap_state'] == 'cleared')
    cleared_by = require_sorted_refs(obj['cleared_by_refs'], '$.cleared_by_refs', maximum=16, allow_empty=obj['gap_state'] != 'cleared')
    if obj['gap_state'] == 'open':
        if not blocks or not refreshes:
            fail('$.blocks_verbs/required_refreshes: open gaps must block verbs and require refreshes')
        if not (set(blocks) & MUTATING_VERBS):
            fail('$.blocks_verbs: open gaps must block at least one mutating verb')
    if obj['gap_state'] == 'cleared' and not cleared_by:
        fail('$.cleared_by_refs: cleared gaps must name clearing evidence')
    require_non_implications(obj['non_implications'], OBSGAP_NON_IMPLICATIONS, '$.non_implications')
    return obj


def issuer(kind: str = 'status_channel', ident: str = 'steward.status') -> dict[str, str]:
    return {'kind': kind, 'id': ident}


def base_sub(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSSUB v0',
        'witness_id': 'wit_4000000000000001',
        'cid': 'demo.web',
        'issuer': issuer(),
        'subscription_id': 'sub_1000000000000001',
        'consumer_ref': 'surface:demo.web.status',
        'subject_ref': 'component:demo.web',
        'view_kind': 'component_status',
        'delivery_mode': 'snapshot_then_stream',
        'accepted_kinds': ['status', 'sync', 'witness'],
        'limits': {'max_batch': 64, 'max_lag_ms': 2000, 'coalesce': True, 'overflow_policy': 'coalesce_and_mark'},
        'created_at_ms': 1000,
        'expires_at_ms': 10000,
        'observed_at_ms': 1000,
        'basis_refs': ['component:demo.web'],
        'non_implications': sorted(OBSSUB_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_delivery(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSDELIV v0',
        'witness_id': 'wit_4000000000000002',
        'cid': 'demo.web',
        'issuer': issuer(),
        'delivery_id': 'del_1000000000000001',
        'subscription_ref': 'sub_1000000000000001',
        'seq_first': 1,
        'seq_last': 2,
        'delivery_state': 'delivered',
        'delivered_refs': ['card_1000000000000001', 'sync_1000000000000001'],
        'dropped_count': 0,
        'cursor_after_ref': 'cur_demo_web_0002',
        'redaction_refs': ['red_1000000000000001'],
        'observed_at_ms': 1100,
        'basis_refs': ['sub_1000000000000001'],
        'non_implications': sorted(OBSDELIV_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_sync(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSSYNC v0',
        'witness_id': 'wit_4000000000000003',
        'cid': 'demo.web',
        'issuer': issuer(),
        'sync_id': 'sync_1000000000000001',
        'subscription_ref': 'sub_1000000000000001',
        'synced_through_seq': 2,
        'sync_class': 'synced_through',
        'snapshot_refs': [],
        'gap_refs': [],
        'as_of_ms': 1090,
        'requires_recheck_refs': [],
        'expires_or_recheck_by_ms': 3000,
        'observed_at_ms': 1100,
        'basis_refs': ['del_1000000000000001'],
        'non_implications': sorted(OBSSYNC_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def base_gap(**overrides: Any) -> dict[str, Any]:
    obj: dict[str, Any] = {
        'schema': 'ST-OBSGAP v0',
        'witness_id': 'wit_4000000000000004',
        'cid': 'demo.web',
        'issuer': issuer(),
        'gap_id': 'gap_1000000000000001',
        'subscription_ref': 'sub_1000000000000001',
        'gap_state': 'open',
        'gap_from_seq': 3,
        'gap_to_seq': 8,
        'gap_class': 'overflow',
        'blocks_verbs': ['restart', 'stop'],
        'required_refreshes': ['sync-resnapshot-demo-web'],
        'cleared_by_refs': [],
        'observed_at_ms': 1300,
        'basis_refs': ['del_1000000000000002'],
        'non_implications': sorted(OBSGAP_NON_IMPLICATIONS),
    }
    obj.update(overrides)
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any | None, expect: str, why: str, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'status_channel', 'expect': expect, 'why': why, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    sub = base_sub()
    delivery = base_delivery()
    sync = base_sync()
    gap = base_gap()
    dropped_delivery = base_delivery(
        witness_id='wit_4000000000000005',
        delivery_id='del_1000000000000002',
        seq_first=3,
        seq_last=8,
        delivery_state='requires_resync',
        delivered_refs=[],
        dropped_count=6,
        cursor_after_ref='cur_demo_web_0008',
        observed_at_ms=1250,
    )
    resync = base_sync(
        witness_id='wit_4000000000000006',
        sync_id='sync_1000000000000002',
        synced_through_seq=8,
        sync_class='resync_required',
        gap_refs=['gap_1000000000000001'],
        requires_recheck_refs=['sync-resnapshot-demo-web'],
        observed_at_ms=1300,
        as_of_ms=1250,
        basis_refs=['gap_1000000000000001'],
    )
    cleared_gap = base_gap(
        witness_id='wit_4000000000000007',
        gap_id='gap_1000000000000002',
        gap_state='cleared',
        blocks_verbs=[],
        required_refreshes=[],
        cleared_by_refs=['sync_1000000000000003'],
        observed_at_ms=1600,
    )
    initial_snapshot = base_sync(
        witness_id='wit_4000000000000008',
        sync_id='sync_1000000000000003',
        synced_through_seq=10,
        sync_class='initial_snapshot',
        snapshot_refs=['card_1000000000000001', 'wit_3000000000000001'],
        gap_refs=[],
        requires_recheck_refs=[],
        observed_at_ms=1550,
        as_of_ms=1540,
        basis_refs=['sub_1000000000000001'],
    )

    return [
        schema_case('obssub.accept.explicit-snapshot-stream', 'ST-OBSSUB', sub, 'accept', 'explicit subject subscriptions can request snapshot then stream without becoming control'),
        schema_case('obssub.reject.ambient-current-target', 'ST-OBSSUB', {**sub, 'subject_ref': 'pane:current'}, 'reject', 'subscriptions must not bind to ambient current pane folklore'),
        schema_case('obssub.reject.unknown-kind-all', 'ST-OBSSUB', {**sub, 'accepted_kinds': ['all']}, 'reject', 'accepted kinds must be explicit bounded categories'),
        schema_case('obssub.reject.missing-nonimplications', 'ST-OBSSUB', {**sub, 'non_implications': ['not-authority']}, 'reject', 'subscriptions must refuse mutation/currentness/readiness/service claims'),
        schema_case('obsdeliv.accept.delivered-batch', 'ST-OBSDELIV', delivery, 'accept', 'deliveries carry sorted refs and a cursor without becoming current state'),
        schema_case('obsdeliv.reject.unsorted-refs', 'ST-OBSDELIV', {**delivery, 'delivered_refs': ['sync_1000000000000001', 'card_1000000000000001']}, 'reject', 'delivery refs must be sorted for stable batch digests'),
        schema_case('obsdeliv.reject.drop-with-delivered-state', 'ST-OBSDELIV', {**delivery, 'dropped_count': 1}, 'reject', 'drops require explicit dropped or resync state'),
        schema_case('obsdeliv.reject.duplicate-json-key', 'ST-OBSDELIV', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-OBSDELIV v0","schema":"ST-OBSDELIV v0","witness_id":"wit_4000000000000002","cid":"demo.web","issuer":{"kind":"status_channel","id":"steward.status"},"delivery_id":"del_1000000000000001","subscription_ref":"sub_1000000000000001","seq_first":1,"seq_last":2,"delivery_state":"delivered","delivered_refs":["card_1000000000000001"],"dropped_count":0,"cursor_after_ref":"cur_demo_web_0002","redaction_refs":[],"observed_at_ms":1100,"basis_refs":["sub_1000000000000001"],"non_implications":[]}'),
        schema_case('obssync.accept.synced-through-marker', 'ST-OBSSYNC', sync, 'accept', 'sync markers can identify exact-view progress while refusing global currentness'),
        schema_case('obssync.accept.initial-snapshot', 'ST-OBSSYNC', initial_snapshot, 'accept', 'initial snapshot can carry bounded snapshot refs for the exact view'),
        schema_case('obssync.reject.synced-through-with-gap', 'ST-OBSSYNC', {**sync, 'gap_refs': ['gap_1000000000000001']}, 'reject', 'synced-through markers cannot hide known gaps'),
        schema_case('obssync.reject.future-as-of', 'ST-OBSSYNC', {**sync, 'as_of_ms': 1200}, 'reject', 'as_of cannot be after the observation time'),
        schema_case('obsgap.accept.open-gap-barrier', 'ST-OBSGAP', gap, 'accept', 'open stream gaps block risky lifecycle verbs until refresh'),
        schema_case('obsgap.accept.cleared-gap', 'ST-OBSGAP', cleared_gap, 'accept', 'cleared stream gaps must name clearing evidence'),
        schema_case('obsgap.reject.open-without-refresh', 'ST-OBSGAP', {**gap, 'blocks_verbs': [], 'required_refreshes': []}, 'reject', 'open gaps must block mutating verbs and require refresh'),
        schema_case('obsgap.reject.lossless-field', 'ST-OBSGAP', {**gap, 'lossless': True}, 'reject', 'gap witnesses cannot claim lossless continuity'),

        flow_case('status.accept.snapshot-stream-progress', [
            {'event': 'subscription', 'packet': sub},
            {'event': 'delivery', 'packet': delivery},
            {'event': 'sync', 'packet': sync},
        ], 'accept', 'subscription, delivery, and exact-view sync can compose without current-state flattery'),
        flow_case('status.accept.gap-requires-resync', [
            {'event': 'subscription', 'packet': sub},
            {'event': 'delivery', 'packet': dropped_delivery},
            {'event': 'gap', 'packet': gap},
            {'event': 'sync', 'packet': resync},
        ], 'accept', 'overflow delivery downgrades to an explicit gap and resync requirement'),
        flow_case('status.reject.delivery-without-subscription', [
            {'event': 'delivery', 'packet': delivery},
        ], 'reject', 'delivery batches must be bound to a known subscription'),
        flow_case('status.reject.delivery-as-current-state', [
            {'event': 'subscription', 'packet': sub},
            {'event': 'delivery', 'packet': delivery, 'claims_current_state': True},
        ], 'reject', 'delivery events cannot claim current lifecycle state'),
        flow_case('status.reject.synced-through-open-gap', [
            {'event': 'subscription', 'packet': sub},
            {'event': 'gap', 'packet': gap},
            {'event': 'sync', 'packet': sync},
        ], 'reject', 'a synced-through marker cannot pass over an open gap'),
        flow_case('status.reject.out-of-order-delivery', [
            {'event': 'subscription', 'packet': sub},
            {'event': 'delivery', 'packet': delivery},
            {'event': 'delivery', 'packet': base_delivery(witness_id='wit_4000000000000009', delivery_id='del_1000000000000003', seq_first=2, seq_last=3, delivered_refs=['card_1000000000000002'], cursor_after_ref='cur_demo_web_0003')},
        ], 'reject', 'delivery sequences for one subscription must not overlap or go backwards'),
        flow_case('status.reject.subscription-as-mutation', [
            {'event': 'subscription', 'packet': sub, 'claims_mutation': True},
        ], 'reject', 'subscription acceptance cannot be presented as lifecycle mutation'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-OBSSUB':
            validate_obssub(obj)
        elif kind == 'ST-OBSDELIV':
            validate_obsdeliv(obj)
        elif kind == 'ST-OBSSYNC':
            validate_obssync(obj)
        elif kind == 'ST-OBSGAP':
            validate_obsgap(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def check_packet_identity(seen: dict[str, str], packet_id: str, packet: dict[str, Any], where: str) -> None:
    got = digest(packet)
    old = seen.get(packet_id)
    if old is not None and old != got:
        fail(f'{where}: packet id reused for different canonical packet')
    seen[packet_id] = got


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        subscriptions: dict[str, dict[str, Any]] = {}
        last_seq_by_sub: dict[str, int] = {}
        open_gaps_by_sub: dict[str, set[str]] = {}
        seen_packets: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'subscription':
                sub = validate_obssub(packet)
                check_packet_identity(seen_packets, sub['subscription_id'], sub, where)
                subscriptions[sub['subscription_id']] = sub
                last_seq_by_sub.setdefault(sub['subscription_id'], -1)
            elif kind == 'delivery':
                delivery = validate_obsdeliv(packet)
                check_packet_identity(seen_packets, delivery['delivery_id'], delivery, where)
                sid = delivery['subscription_ref']
                if sid not in subscriptions:
                    fail(f'{where}: delivery has no known subscription')
                if delivery['delivery_state'] != 'heartbeat':
                    last = last_seq_by_sub.get(sid, -1)
                    if delivery['seq_first'] <= last:
                        fail(f'{where}: delivery sequence overlaps or moves backwards')
                    last_seq_by_sub[sid] = delivery['seq_last']
            elif kind == 'sync':
                sync = validate_obssync(packet)
                check_packet_identity(seen_packets, sync['sync_id'], sync, where)
                sid = sync['subscription_ref']
                if sid not in subscriptions:
                    fail(f'{where}: sync has no known subscription')
                if sync['sync_class'] in {'initial_snapshot', 'synced_through'}:
                    gaps = open_gaps_by_sub.get(sid, set())
                    if gaps:
                        fail(f'{where}: sync marker ignores open gap(s) {sorted(gaps)}')
            elif kind == 'gap':
                gap = validate_obsgap(packet)
                check_packet_identity(seen_packets, gap['gap_id'], gap, where)
                sid = gap['subscription_ref']
                if sid not in subscriptions:
                    fail(f'{where}: gap has no known subscription')
                if gap['gap_state'] == 'open':
                    open_gaps_by_sub.setdefault(sid, set()).add(gap['gap_id'])
                elif gap['gap_state'] == 'cleared':
                    open_gaps_by_sub.setdefault(sid, set()).discard(gap['gap_id'])
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'status_channel':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-status-channel-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-status-channel-corpus] FAIL: corpus is stale; run tools/steward_status_channel_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-status-channel-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
