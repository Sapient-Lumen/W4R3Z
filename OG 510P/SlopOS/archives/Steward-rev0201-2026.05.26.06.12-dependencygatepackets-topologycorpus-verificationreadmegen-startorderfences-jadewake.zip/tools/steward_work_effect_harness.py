#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/demand-custody-effect-corpus-v0.jsonl'

ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')
DEMAND_ID_RE = re.compile(r'^dem_[a-z0-9]{16}$')
CUSTODY_ID_RE = re.compile(r'^cus_[a-z0-9]{16}$')
DISPOSITION_ID_RE = re.compile(r'^disp_[a-z0-9]{16}$')
EFFECT_ID_RE = re.compile(r'^eff_[a-z0-9]{16}$')
EFFECT_KEY_RE = re.compile(r'^effkey_[a-z0-9]{16}$')
CYCLE_RE = re.compile(r'^cycle-[a-z0-9][a-z0-9._-]{0,63}$')

FORBIDDEN_ANYWHERE = {
    'claims_ready', 'claims_readiness', 'claims_serving', 'claims_stopped',
    'claims_work_completion', 'claims_work_completed', 'claims_effect_success',
    'ready', 'serving', 'component_state', 'work_completed', 'effect_success',
    'exactly_once', 'lossless', 'raw_log', 'scrollback', 'token', 'secret',
    'raw_handle', 'bearer', 'pid', 'ppid', 'pgid', 'cgroup', 'systemd_unit',
    'pod_name', 'container_id', 'process_name', 'host_unit', 'queue_message_id',
}

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'controller', 'proxy', 'runtime', 'client'}

DEMAND_REQUIRED = {'schema', 'demand_id', 'cid', 'surface_ref', 'issuer', 'demand_kind', 'episode_state', 'accepted_at_ms', 'delivery_strength', 'basis_refs', 'non_implications'}
DEMAND_OPTIONAL = {'deadline_ms', 'runtime_cycle', 'fanout_hint', 'cancellation_state', 'outcome_reason', 'request_context_ref', 'traffic_binding_ref', 'live_channel_ref', 'retry_attempt_ref'}
DEMAND_ALLOWED = DEMAND_REQUIRED | DEMAND_OPTIONAL
DEMAND_KINDS = {'http_request', 'rpc_call', 'message', 'event', 'connection', 'callback', 'timer', 'unknown'}
EPISODE_STATES = {'accepted', 'buffered', 'waking', 'delivered', 'accepted_by_runtime', 'completed', 'canceled', 'timed_out', 'shed', 'lost', 'unknown'}
DELIVERY_STRENGTHS = {'none', 'delivered_unacknowledged', 'accepted_by_runtime', 'completion_reported', 'unknown'}
FANOUT_HINTS = {'single_runtime', 'shared_runtime', 'per_demand_runtime', 'broadcast', 'unknown'}
CANCELLATION_STATES = {'not_requested', 'propagated', 'queued', 'not_supported', 'detached', 'unknown'}
DEMAND_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-custody', 'not-work-completion', 'not-effect-success', 'not-exactly-once', 'not-route-authority'}
DEMAND_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-custody', 'not-work-completion', 'not-effect-success', 'not-exactly-once'}

CUSTODY_REQUIRED = {'schema', 'custody_id', 'item_ref', 'cid', 'issuer', 'custody_state', 'holder_ref', 'observed_at_ms', 'duplicate_risk', 'basis_refs', 'non_implications'}
CUSTODY_OPTIONAL = {'demand_ref', 'work_ref', 'previous_holder_ref', 'next_holder_ref', 'transfer_boundary_ref', 'lease_expires_at_ms', 'runtime_cycle', 'cancellation_state', 'loss_reason'}
CUSTODY_ALLOWED = CUSTODY_REQUIRED | CUSTODY_OPTIONAL
CUSTODY_STATES = {'held', 'delivered_unacknowledged', 'accepted_by_runtime', 'released', 'returned', 'redeliverable', 'abandoned', 'lost', 'unknown'}
DUPLICATE_RISKS = {'none', 'possible', 'known', 'unknown'}
CUSTODY_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-work-completion', 'not-effect-success', 'not-exactly-once', 'not-lossless'}
CUSTODY_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-work-completion', 'not-effect-success', 'not-exactly-once'}

WORK_REQUIRED = {'schema', 'disposition_id', 'item_ref', 'cid', 'issuer', 'disposition', 'observed_at_ms', 'basis_refs', 'non_implications'}
WORK_OPTIONAL = {'demand_ref', 'custody_ref', 'runtime_cycle', 'effect_boundary_ref', 'retry_or_redelivery_ref', 'outcome_reason', 'duplicate_risk', 'terminal_class'}
WORK_ALLOWED = WORK_REQUIRED | WORK_OPTIONAL
DISPOSITIONS = {'acknowledged', 'completed_local', 'redeliverable', 'redelivered', 'expired', 'dead_lettered', 'discarded', 'abandoned', 'detached', 'superseded', 'unknown'}
TERMINAL_CLASSES = {'success_local', 'caller_cancel', 'timeout', 'policy_shed', 'poison', 'cleanup', 'unknown'}
WORK_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-effect-success', 'not-exactly-once', 'not-external-confirmation', 'not-lossless'}
WORK_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-effect-success', 'not-exactly-once'}

EFFECT_REQUIRED = {'schema', 'effect_id', 'cid', 'issuer', 'boundary_kind', 'effect_state', 'canonical_intent_digest', 'observed_at_ms', 'basis_refs', 'retention', 'duplicate_outcome', 'non_implications'}
EFFECT_OPTIONAL = {'effect_key', 'work_ref', 'disposition_ref', 'external_ref', 'outbox_ref', 'commit_ref', 'compensation_ref', 'retention_expires_at_ms', 'ambiguity_reason'}
EFFECT_ALLOWED = EFFECT_REQUIRED | EFFECT_OPTIONAL
BOUNDARY_KINDS = {'none', 'local_commit', 'outbox_recorded', 'external_submitted', 'external_acknowledged', 'external_confirmed', 'compensated', 'irreversible', 'unknown'}
EFFECT_STATES = {'not_attempted', 'pending', 'submitted', 'confirmed', 'failed', 'compensated', 'ambiguous', 'unknown'}
RETENTIONS = {'none', 'bounded', 'expired', 'unknown'}
DUPLICATE_OUTCOMES = {'none', 'suppressed', 'same_intent_replay', 'same_key_mismatch', 'duplicate_possible', 'unknown'}
EFFECT_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-work-completion', 'not-exactly-once', 'not-rollbackable', 'not-current-authority'}
EFFECT_BASE_NON_IMPLICATIONS = {'not-readiness', 'not-serving', 'not-work-completion', 'not-exactly-once', 'not-rollbackable'}


def scan_forbidden_keys(value: Any, forbidden: set[str], path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in forbidden:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, forbidden, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, forbidden, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    if 'token=' in lowered or 'secret=' in lowered or 'bearer ' in lowered:
        fail(f'{path}: raw secret-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_ref_field(obj: dict[str, Any], field: str, path: str) -> None:
    if field in obj:
        require_pattern(obj[field], REF_RE, f'{path}.{field}')


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_non_implications(value: Any, path: str, allowed: set[str], required: set[str]) -> set[str]:
    vals = set(require_refs(value, path, maximum=16))
    invalid = sorted(vals - allowed)
    if invalid:
        fail(f'{path}: invalid values {invalid}')
    missing = sorted(required - vals)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return vals


def validate_common_refs(obj: dict[str, Any], fields: tuple[str, ...]) -> None:
    for field in fields:
        require_ref_field(obj, field, '$')


def validate_st_demand(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, DEMAND_ALLOWED, DEMAND_REQUIRED, '$')
    if obj['schema'] != 'ST-DEMAND v0':
        fail('$.schema: expected ST-DEMAND v0')
    require_pattern(obj['demand_id'], DEMAND_ID_RE, '$.demand_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    require_pattern(obj['surface_ref'], REF_RE, '$.surface_ref')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['demand_kind'] not in DEMAND_KINDS:
        fail('$.demand_kind: invalid demand kind')
    if obj['episode_state'] not in EPISODE_STATES:
        fail('$.episode_state: invalid episode state')
    if obj['delivery_strength'] not in DELIVERY_STRENGTHS:
        fail('$.delivery_strength: invalid delivery strength')
    require_int(obj['accepted_at_ms'], '$.accepted_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if 'deadline_ms' in obj:
        require_int(obj['deadline_ms'], '$.deadline_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['deadline_ms'] < obj['accepted_at_ms']:
            fail('$.deadline_ms: cannot precede accepted_at_ms')
    if 'runtime_cycle' in obj:
        require_pattern(obj['runtime_cycle'], CYCLE_RE, '$.runtime_cycle')
    if obj['delivery_strength'] in {'accepted_by_runtime', 'completion_reported'} and 'runtime_cycle' not in obj:
        fail('$.runtime_cycle: runtime acceptance/completion report needs a cycle fence')
    if 'fanout_hint' in obj and obj['fanout_hint'] not in FANOUT_HINTS:
        fail('$.fanout_hint: invalid fanout hint')
    if 'cancellation_state' in obj and obj['cancellation_state'] not in CANCELLATION_STATES:
        fail('$.cancellation_state: invalid cancellation state')
    if obj['episode_state'] in {'canceled', 'timed_out', 'shed', 'lost', 'unknown'} and 'outcome_reason' not in obj:
        fail('$.outcome_reason: degraded terminal demand states need a reason')
    if 'outcome_reason' in obj:
        require_text(obj['outcome_reason'], '$.outcome_reason')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', DEMAND_NON_IMPLICATIONS, DEMAND_BASE_NON_IMPLICATIONS)
    validate_common_refs(obj, ('request_context_ref', 'traffic_binding_ref', 'live_channel_ref', 'retry_attempt_ref'))
    return obj


def validate_st_custody(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, CUSTODY_ALLOWED, CUSTODY_REQUIRED, '$')
    if obj['schema'] != 'ST-CUSTODY v0':
        fail('$.schema: expected ST-CUSTODY v0')
    require_pattern(obj['custody_id'], CUSTODY_ID_RE, '$.custody_id')
    require_pattern(obj['item_ref'], REF_RE, '$.item_ref')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['custody_state'] not in CUSTODY_STATES:
        fail('$.custody_state: invalid custody state')
    require_pattern(obj['holder_ref'], REF_RE, '$.holder_ref')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['duplicate_risk'] not in DUPLICATE_RISKS:
        fail('$.duplicate_risk: invalid duplicate risk')
    if 'lease_expires_at_ms' in obj:
        require_int(obj['lease_expires_at_ms'], '$.lease_expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['lease_expires_at_ms'] < obj['observed_at_ms']:
            fail('$.lease_expires_at_ms: cannot precede observed_at_ms')
    if obj['custody_state'] in {'delivered_unacknowledged', 'released', 'returned'} and 'transfer_boundary_ref' not in obj:
        fail('$.transfer_boundary_ref: handoff-like custody states need boundary evidence')
    if obj['custody_state'] == 'accepted_by_runtime' and 'runtime_cycle' not in obj:
        fail('$.runtime_cycle: accepted custody needs runtime-cycle fence')
    if 'runtime_cycle' in obj:
        require_pattern(obj['runtime_cycle'], CYCLE_RE, '$.runtime_cycle')
    if 'cancellation_state' in obj and obj['cancellation_state'] not in CANCELLATION_STATES:
        fail('$.cancellation_state: invalid cancellation state')
    if obj['custody_state'] in {'lost', 'abandoned', 'unknown'} and 'loss_reason' not in obj:
        fail('$.loss_reason: degraded custody states need a reason')
    if 'loss_reason' in obj:
        require_text(obj['loss_reason'], '$.loss_reason')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', CUSTODY_NON_IMPLICATIONS, CUSTODY_BASE_NON_IMPLICATIONS)
    validate_common_refs(obj, ('demand_ref', 'work_ref', 'previous_holder_ref', 'next_holder_ref', 'transfer_boundary_ref'))
    return obj


def validate_st_workdisp(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, WORK_ALLOWED, WORK_REQUIRED, '$')
    if obj['schema'] != 'ST-WORKDISP v0':
        fail('$.schema: expected ST-WORKDISP v0')
    require_pattern(obj['disposition_id'], DISPOSITION_ID_RE, '$.disposition_id')
    require_pattern(obj['item_ref'], REF_RE, '$.item_ref')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['disposition'] not in DISPOSITIONS:
        fail('$.disposition: invalid disposition')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['disposition'] in {'acknowledged', 'completed_local'} and 'custody_ref' not in obj:
        fail('$.custody_ref: local completion/acknowledgement needs custody evidence')
    if obj['disposition'] in {'expired', 'dead_lettered', 'discarded', 'abandoned', 'superseded', 'unknown'} and 'outcome_reason' not in obj:
        fail('$.outcome_reason: degraded work disposition needs a reason')
    if 'outcome_reason' in obj:
        require_text(obj['outcome_reason'], '$.outcome_reason')
    if 'duplicate_risk' in obj and obj['duplicate_risk'] not in DUPLICATE_RISKS:
        fail('$.duplicate_risk: invalid duplicate risk')
    if 'terminal_class' in obj and obj['terminal_class'] not in TERMINAL_CLASSES:
        fail('$.terminal_class: invalid terminal class')
    if 'runtime_cycle' in obj:
        require_pattern(obj['runtime_cycle'], CYCLE_RE, '$.runtime_cycle')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', WORK_NON_IMPLICATIONS, WORK_BASE_NON_IMPLICATIONS)
    validate_common_refs(obj, ('demand_ref', 'custody_ref', 'effect_boundary_ref', 'retry_or_redelivery_ref'))
    return obj


def validate_st_effect(obj: Any) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj, FORBIDDEN_ANYWHERE)
    require_closed_keys(obj, EFFECT_ALLOWED, EFFECT_REQUIRED, '$')
    if obj['schema'] != 'ST-EFFECT v0':
        fail('$.schema: expected ST-EFFECT v0')
    require_pattern(obj['effect_id'], EFFECT_ID_RE, '$.effect_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    if obj['boundary_kind'] not in BOUNDARY_KINDS:
        fail('$.boundary_kind: invalid boundary kind')
    if obj['effect_state'] not in EFFECT_STATES:
        fail('$.effect_state: invalid effect state')
    require_pattern(obj['canonical_intent_digest'], DIGEST_RE, '$.canonical_intent_digest')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['retention'] not in RETENTIONS:
        fail('$.retention: invalid retention state')
    if obj['duplicate_outcome'] not in DUPLICATE_OUTCOMES:
        fail('$.duplicate_outcome: invalid duplicate outcome')
    if 'effect_key' in obj:
        require_pattern(obj['effect_key'], EFFECT_KEY_RE, '$.effect_key')
    if obj['duplicate_outcome'] in {'suppressed', 'same_intent_replay', 'same_key_mismatch'} and 'effect_key' not in obj:
        fail('$.effect_key: duplicate-key outcome needs an effect key')
    if 'retention_expires_at_ms' in obj:
        require_int(obj['retention_expires_at_ms'], '$.retention_expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
        if obj['retention_expires_at_ms'] < obj['observed_at_ms']:
            fail('$.retention_expires_at_ms: cannot precede observed_at_ms')
    if obj['retention'] == 'bounded' and 'retention_expires_at_ms' not in obj:
        fail('$.retention_expires_at_ms: bounded retention needs expiry')
    if obj['boundary_kind'] == 'local_commit' and 'commit_ref' not in obj:
        fail('$.commit_ref: local commit boundary needs commit evidence')
    if obj['boundary_kind'] == 'outbox_recorded' and 'outbox_ref' not in obj:
        fail('$.outbox_ref: outbox boundary needs outbox evidence')
    if obj['boundary_kind'] in {'external_acknowledged', 'external_confirmed', 'irreversible'} and 'external_ref' not in obj:
        fail('$.external_ref: external boundary needs external evidence')
    if obj['effect_state'] in {'ambiguous', 'unknown'} and 'ambiguity_reason' not in obj:
        fail('$.ambiguity_reason: ambiguous or unknown effects need a reason')
    if 'ambiguity_reason' in obj:
        require_text(obj['ambiguity_reason'], '$.ambiguity_reason')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=16)
    validate_non_implications(obj['non_implications'], '$.non_implications', EFFECT_NON_IMPLICATIONS, EFFECT_BASE_NON_IMPLICATIONS)
    validate_common_refs(obj, ('work_ref', 'disposition_ref', 'external_ref', 'outbox_ref', 'commit_ref', 'compensation_ref'))
    return obj


def schema_case(case_id: str, object_kind: str, obj: dict[str, Any] | None, expect: str, why: str, *, json_text: str | None = None) -> dict[str, Any]:
    case: dict[str, Any] = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'why': why}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
    if expect == 'accept' and obj is not None:
        case['expected_digest'] = digest(obj)
    return case


def flow_case(case_id: str, events: list[dict[str, Any]], expect: str, why: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'demand_custody_effect_flow', 'events': events, 'expect': expect, 'why': why}


def build_cases() -> list[dict[str, Any]]:
    issuer_proxy = {'kind': 'proxy', 'id': 'proxy/proof-harness'}
    issuer_runtime = {'kind': 'runtime', 'id': 'runtime/demo-web'}
    issuer_adapter = {'kind': 'adapter', 'id': 'adapter/outbox'}
    common_non_demand = ['not-custody', 'not-effect-success', 'not-exactly-once', 'not-readiness', 'not-serving', 'not-work-completion']
    common_non_custody = ['not-effect-success', 'not-exactly-once', 'not-readiness', 'not-serving', 'not-work-completion']
    common_non_work = ['not-effect-success', 'not-exactly-once', 'not-readiness', 'not-serving']
    common_non_effect = ['not-exactly-once', 'not-readiness', 'not-rollbackable', 'not-serving', 'not-work-completion']
    intent_digest = digest({'method': 'POST', 'path': '/orders', 'body_digest': 'sha256:' + '1' * 64})
    other_intent_digest = digest({'method': 'POST', 'path': '/orders', 'body_digest': 'sha256:' + '2' * 64})

    demand = {
        'schema': 'ST-DEMAND v0',
        'demand_id': 'dem_0000000000000001',
        'cid': 'demo.web',
        'surface_ref': 'surface/public-http',
        'issuer': issuer_proxy,
        'demand_kind': 'http_request',
        'episode_state': 'accepted',
        'accepted_at_ms': 1000,
        'deadline_ms': 7000,
        'delivery_strength': 'none',
        'fanout_hint': 'single_runtime',
        'basis_refs': ['route-observation/gw-1'],
        'non_implications': common_non_demand,
    }
    demand_delivered = {
        **demand,
        'demand_id': 'dem_0000000000000002',
        'episode_state': 'accepted_by_runtime',
        'delivery_strength': 'accepted_by_runtime',
        'runtime_cycle': 'cycle-demo-web-a',
        'basis_refs': ['delivery/demo-web-a'],
    }
    demand_timed_out = {
        **demand,
        'demand_id': 'dem_0000000000000003',
        'episode_state': 'timed_out',
        'delivery_strength': 'unknown',
        'outcome_reason': 'caller deadline expired before runtime accepted',
        'cancellation_state': 'propagated',
        'basis_refs': ['deadline/request-1'],
    }
    demand_missing_nonimp = {**demand, 'non_implications': ['not-readiness', 'not-serving']}
    demand_bad_deadline = {**demand, 'deadline_ms': 999}
    demand_accept_no_cycle = {**demand, 'delivery_strength': 'accepted_by_runtime'}
    demand_claims_ready = {**demand, 'claims_ready': True}
    demand_secret = {**demand, 'outcome_reason': 'Bearer token=abc'}

    custody = {
        'schema': 'ST-CUSTODY v0',
        'custody_id': 'cus_0000000000000001',
        'item_ref': 'dem_0000000000000001',
        'demand_ref': 'dem_0000000000000001',
        'cid': 'demo.web',
        'issuer': issuer_proxy,
        'custody_state': 'held',
        'holder_ref': 'holder/activator',
        'observed_at_ms': 1200,
        'lease_expires_at_ms': 6200,
        'duplicate_risk': 'possible',
        'basis_refs': ['custody/activator-1'],
        'non_implications': common_non_custody,
    }
    custody_delivered = {
        **custody,
        'custody_id': 'cus_0000000000000002',
        'custody_state': 'delivered_unacknowledged',
        'holder_ref': 'holder/proxy-gw-1',
        'next_holder_ref': 'holder/runtime-demo-web-a',
        'transfer_boundary_ref': 'handoff/proxy-to-runtime-1',
        'basis_refs': ['handoff/proxy-to-runtime-1'],
    }
    custody_accepted = {
        **custody,
        'custody_id': 'cus_0000000000000003',
        'custody_state': 'accepted_by_runtime',
        'holder_ref': 'holder/runtime-demo-web-a',
        'runtime_cycle': 'cycle-demo-web-a',
        'duplicate_risk': 'none',
        'basis_refs': ['runtime-ack/demo-web-a'],
    }
    custody_lost = {
        **custody,
        'custody_id': 'cus_0000000000000004',
        'custody_state': 'lost',
        'holder_ref': 'holder/activator',
        'duplicate_risk': 'unknown',
        'loss_reason': 'manager restarted before release acknowledgement',
        'basis_refs': ['recovery/manager-1'],
    }
    custody_no_boundary = {**custody_delivered}
    custody_no_boundary.pop('transfer_boundary_ref')
    custody_bad_lease = {**custody, 'lease_expires_at_ms': 1199}
    custody_claims_effect = {**custody, 'claims_effect_success': True}
    custody_unknown_no_reason = {**custody, 'custody_state': 'unknown'}

    work = {
        'schema': 'ST-WORKDISP v0',
        'disposition_id': 'disp_0000000000000001',
        'item_ref': 'dem_0000000000000001',
        'demand_ref': 'dem_0000000000000001',
        'custody_ref': 'cus_0000000000000003',
        'cid': 'demo.web',
        'issuer': issuer_runtime,
        'disposition': 'completed_local',
        'observed_at_ms': 3000,
        'runtime_cycle': 'cycle-demo-web-a',
        'duplicate_risk': 'none',
        'terminal_class': 'success_local',
        'basis_refs': ['runtime-complete/demo-web-a'],
        'non_implications': common_non_work,
    }
    work_ack = {**work, 'disposition_id': 'disp_0000000000000002', 'disposition': 'acknowledged', 'basis_refs': ['ack/runtime-demo-web-a']}
    work_expired = {
        **work,
        'disposition_id': 'disp_0000000000000003',
        'custody_ref': 'cus_0000000000000004',
        'disposition': 'expired',
        'duplicate_risk': 'unknown',
        'terminal_class': 'timeout',
        'outcome_reason': 'caller deadline exceeded before semantic acknowledgement',
        'basis_refs': ['deadline/request-1'],
    }
    work_missing_custody = {**work}
    work_missing_custody.pop('custody_ref')
    work_expired_no_reason = {**work_expired}
    work_expired_no_reason.pop('outcome_reason')
    work_claims_effect = {**work, 'claims_effect_success': True}
    work_unknown_no_reason = {**work, 'disposition': 'unknown'}

    effect = {
        'schema': 'ST-EFFECT v0',
        'effect_id': 'eff_0000000000000001',
        'cid': 'demo.web',
        'issuer': issuer_adapter,
        'boundary_kind': 'external_submitted',
        'effect_state': 'submitted',
        'canonical_intent_digest': intent_digest,
        'observed_at_ms': 3400,
        'effect_key': 'effkey_0000000000000001',
        'work_ref': 'disp_0000000000000001',
        'retention': 'bounded',
        'retention_expires_at_ms': 86_403_400,
        'duplicate_outcome': 'none',
        'basis_refs': ['submit/payment-gateway-1'],
        'non_implications': common_non_effect,
    }
    effect_confirmed = {
        **effect,
        'effect_id': 'eff_0000000000000002',
        'boundary_kind': 'external_confirmed',
        'effect_state': 'confirmed',
        'external_ref': 'external/payment-gateway-confirmation-1',
        'basis_refs': ['external/payment-gateway-confirmation-1'],
    }
    effect_duplicate = {
        **effect,
        'effect_id': 'eff_0000000000000003',
        'duplicate_outcome': 'same_intent_replay',
        'basis_refs': ['dedupe/effect-key-window-1'],
    }
    effect_ambiguous = {
        **effect,
        'effect_id': 'eff_0000000000000004',
        'boundary_kind': 'unknown',
        'effect_state': 'ambiguous',
        'retention': 'unknown',
        'duplicate_outcome': 'duplicate_possible',
        'ambiguity_reason': 'transport closed after submit boundary became possible',
        'basis_refs': ['channel/reset-1'],
    }
    effect_bad_retention = {**effect, 'retention_expires_at_ms': 1000}
    effect_confirmed_no_external = {**effect_confirmed}
    effect_confirmed_no_external.pop('external_ref')
    effect_same_key_mismatch = {**effect, 'effect_id': 'eff_0000000000000005', 'canonical_intent_digest': other_intent_digest, 'duplicate_outcome': 'same_key_mismatch'}
    effect_duplicate_no_key = {**effect, 'duplicate_outcome': 'suppressed'}
    effect_duplicate_no_key.pop('effect_key')
    effect_claims_exactly_once = {**effect, 'exactly_once': True}
    effect_missing_nonimp = {**effect, 'non_implications': ['not-readiness', 'not-serving']}

    return [
        schema_case('demand.accept.accepted-cold-start', 'ST-DEMAND', demand, 'accept', 'accepted demand is digestable and weak'),
        schema_case('demand.accept.accepted-by-runtime-cycle-fenced', 'ST-DEMAND', demand_delivered, 'accept', 'runtime acceptance requires a cycle fence'),
        schema_case('demand.accept.timed-out-with-reason', 'ST-DEMAND', demand_timed_out, 'accept', 'timeout is explicit and does not imply work or effect fate'),
        schema_case('demand.reject.missing-nonimplications', 'ST-DEMAND', demand_missing_nonimp, 'reject', 'demand witnesses must refuse stronger truths'),
        schema_case('demand.reject.deadline-before-accept', 'ST-DEMAND', demand_bad_deadline, 'reject', 'deadline cannot precede accepted_at'),
        schema_case('demand.reject.runtime-acceptance-without-cycle', 'ST-DEMAND', demand_accept_no_cycle, 'reject', 'accepted-by-runtime needs runtime-cycle fence'),
        schema_case('demand.reject.claims-ready', 'ST-DEMAND', demand_claims_ready, 'reject', 'demand acceptance cannot claim readiness'),
        schema_case('demand.reject.secret-like-text', 'ST-DEMAND', demand_secret, 'reject', 'demand outcome text cannot carry bearer material'),
        schema_case('demand.reject.duplicate-json-key', 'ST-DEMAND', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-DEMAND v0","schema":"ST-DEMAND v0","demand_id":"dem_0000000000000999","cid":"demo.web","surface_ref":"surface/public-http","issuer":{"kind":"proxy","id":"proxy/proof-harness"},"demand_kind":"http_request","episode_state":"accepted","accepted_at_ms":1,"delivery_strength":"none","basis_refs":["basis/x"],"non_implications":["not-readiness","not-serving","not-custody","not-work-completion","not-effect-success","not-exactly-once"]}'),

        schema_case('custody.accept.held-with-lease', 'ST-CUSTODY', custody, 'accept', 'custody can be held with lease expiry and duplicate risk'),
        schema_case('custody.accept.delivered-unacknowledged', 'ST-CUSTODY', custody_delivered, 'accept', 'delivery and semantic acceptance stay separate'),
        schema_case('custody.accept.accepted-by-runtime', 'ST-CUSTODY', custody_accepted, 'accept', 'accepted custody is cycle-fenced and still not completion'),
        schema_case('custody.accept.lost-with-reason', 'ST-CUSTODY', custody_lost, 'accept', 'lost custody downgrades honestly'),
        schema_case('custody.reject.handoff-without-boundary', 'ST-CUSTODY', custody_no_boundary, 'reject', 'handoff-like custody needs boundary evidence'),
        schema_case('custody.reject.lease-before-observation', 'ST-CUSTODY', custody_bad_lease, 'reject', 'custody lease cannot expire before observation'),
        schema_case('custody.reject.claims-effect-success', 'ST-CUSTODY', custody_claims_effect, 'reject', 'custody cannot claim external effects'),
        schema_case('custody.reject.unknown-without-reason', 'ST-CUSTODY', custody_unknown_no_reason, 'reject', 'unknown custody needs a reason'),

        schema_case('work.accept.completed-local', 'ST-WORKDISP', work, 'accept', 'local completion stays weaker than effect success'),
        schema_case('work.accept.acknowledged', 'ST-WORKDISP', work_ack, 'accept', 'acknowledgement remains disposition not external effect'),
        schema_case('work.accept.expired-with-reason', 'ST-WORKDISP', work_expired, 'accept', 'expired work admits no hidden success'),
        schema_case('work.reject.completion-without-custody', 'ST-WORKDISP', work_missing_custody, 'reject', 'local completion needs custody evidence'),
        schema_case('work.reject.expired-without-reason', 'ST-WORKDISP', work_expired_no_reason, 'reject', 'degraded terminal disposition needs reason'),
        schema_case('work.reject.claims-effect-success', 'ST-WORKDISP', work_claims_effect, 'reject', 'work disposition cannot claim effect success'),
        schema_case('work.reject.unknown-without-reason', 'ST-WORKDISP', work_unknown_no_reason, 'reject', 'unknown work disposition needs reason'),

        schema_case('effect.accept.external-submitted', 'ST-EFFECT', effect, 'accept', 'external submit boundary remains weaker than exact-once confirmation'),
        schema_case('effect.accept.external-confirmed', 'ST-EFFECT', effect_confirmed, 'accept', 'external confirmation is named without becoming exactly-once'),
        schema_case('effect.accept.same-intent-replay', 'ST-EFFECT', effect_duplicate, 'accept', 'same intent replay can be recognized under bounded retention'),
        schema_case('effect.accept.ambiguous-after-channel-reset', 'ST-EFFECT', effect_ambiguous, 'accept', 'effect ambiguity is explicit'),
        schema_case('effect.reject.retention-expiry-before-observation', 'ST-EFFECT', effect_bad_retention, 'reject', 'bounded retention expiry cannot precede observation'),
        schema_case('effect.reject.confirmed-without-external-ref', 'ST-EFFECT', effect_confirmed_no_external, 'reject', 'external confirmation needs external evidence'),
        schema_case('effect.reject.duplicate-outcome-without-key', 'ST-EFFECT', effect_duplicate_no_key, 'reject', 'duplicate suppression needs an effect key'),
        schema_case('effect.reject.claims-exactly-once', 'ST-EFFECT', effect_claims_exactly_once, 'reject', 'effect boundary cannot claim exactly once'),
        schema_case('effect.reject.missing-nonimplications', 'ST-EFFECT', effect_missing_nonimp, 'reject', 'effect boundary must refuse rollbackability and exact-once'),

        flow_case('flow.accept.full-chain-with-external-submit', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody_accepted},
            {'event': 'work_disposition', 'witness': work},
            {'event': 'effect_boundary', 'witness': effect},
        ], 'accept', 'full chain preserves separate demand, custody, work, and effect truth'),
        flow_case('flow.reject.demand-as-work-complete', [
            {'event': 'demand', 'witness': demand, 'implies_work_completion': True},
        ], 'reject', 'accepted demand cannot imply work completion'),
        flow_case('flow.reject.custody-as-effect-success', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody, 'claims_effect_success': True},
        ], 'reject', 'custody holder cannot settle effect fate'),
        flow_case('flow.reject.work-as-effect-without-boundary', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody_accepted},
            {'event': 'work_disposition', 'witness': work, 'claims_effect_success': True},
        ], 'reject', 'local work completion cannot claim effect success without boundary'),
        flow_case('flow.accept.timeout-loss-without-effect', [
            {'event': 'demand', 'witness': demand_timed_out},
            {'event': 'custody', 'witness': {**custody_lost, 'item_ref': 'dem_0000000000000003', 'demand_ref': 'dem_0000000000000003'}},
            {'event': 'work_disposition', 'witness': {**work_expired, 'item_ref': 'dem_0000000000000003', 'demand_ref': 'dem_0000000000000003'}},
        ], 'accept', 'timeout and lost custody can terminate without effect boundary'),
        flow_case('flow.accept.effect-key-same-intent-replay', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody_accepted},
            {'event': 'work_disposition', 'witness': work},
            {'event': 'effect_boundary', 'witness': effect},
            {'event': 'effect_boundary', 'witness': effect_duplicate},
        ], 'accept', 'same effect key and same canonical intent may replay under bounded retention'),
        flow_case('flow.reject.effect-key-different-intent', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody_accepted},
            {'event': 'work_disposition', 'witness': work},
            {'event': 'effect_boundary', 'witness': effect},
            {'event': 'effect_boundary', 'witness': effect_same_key_mismatch},
        ], 'reject', 'same effect key cannot silently cover different canonical intent'),
        flow_case('flow.reject.effect-before-work', [
            {'event': 'demand', 'witness': demand},
            {'event': 'effect_boundary', 'witness': effect},
        ], 'reject', 'effect boundary that cites work must not arrive before that work witness'),
        flow_case('flow.reject.exactly-once-assertion', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody_accepted},
            {'event': 'work_disposition', 'witness': work},
            {'event': 'effect_boundary', 'witness': effect_confirmed},
            {'event': 'assert_exactly_once', 'effect_ref': 'eff_0000000000000002'},
        ], 'reject', 'external confirmation still does not prove exactly once'),
        flow_case('flow.accept.ambiguous-effect-after-channel-loss', [
            {'event': 'demand', 'witness': demand},
            {'event': 'custody', 'witness': custody_accepted},
            {'event': 'work_disposition', 'witness': work},
            {'event': 'effect_boundary', 'witness': effect_ambiguous},
        ], 'accept', 'ambiguous effect state is allowed when stated explicitly'),
    ]


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        if case['object_kind'] == 'ST-DEMAND':
            validate_st_demand(obj)
        elif case['object_kind'] == 'ST-CUSTODY':
            validate_st_custody(obj)
        elif case['object_kind'] == 'ST-WORKDISP':
            validate_st_workdisp(obj)
        elif case['object_kind'] == 'ST-EFFECT':
            validate_st_effect(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def validate_flow_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        demands: dict[str, dict[str, Any]] = {}
        custodies: dict[str, dict[str, Any]] = {}
        work: dict[str, dict[str, Any]] = {}
        effects: dict[str, dict[str, Any]] = {}
        effect_key_intents: dict[str, str] = {}
        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            if kind == 'demand':
                witness = validate_st_demand(ev['witness'])
                if ev.get('implies_ready') or ev.get('implies_serving') or ev.get('implies_work_completion') or ev.get('claims_effect_success'):
                    fail(f'{where}: demand promoted to stronger truth')
                demands[witness['demand_id']] = witness
            elif kind == 'custody':
                witness = validate_st_custody(ev['witness'])
                if ev.get('implies_work_completion') or ev.get('claims_effect_success'):
                    fail(f'{where}: custody promoted to stronger truth')
                demand_ref = witness.get('demand_ref')
                if demand_ref and demand_ref not in demands:
                    fail(f'{where}: custody references unseen demand')
                custodies[witness['custody_id']] = witness
            elif kind == 'work_disposition':
                witness = validate_st_workdisp(ev['witness'])
                demand_ref = witness.get('demand_ref')
                custody_ref = witness.get('custody_ref')
                if demand_ref and demand_ref not in demands:
                    fail(f'{where}: work references unseen demand')
                if custody_ref and custody_ref not in custodies:
                    fail(f'{where}: work references unseen custody')
                if ev.get('claims_effect_success'):
                    effect_ref = witness.get('effect_boundary_ref')
                    if not effect_ref or effect_ref not in effects:
                        fail(f'{where}: work disposition claims effect success without prior effect boundary')
                work[witness['disposition_id']] = witness
            elif kind == 'effect_boundary':
                witness = validate_st_effect(ev['witness'])
                work_ref = witness.get('work_ref')
                if work_ref and work_ref not in work:
                    fail(f'{where}: effect references unseen work disposition')
                key = witness.get('effect_key')
                if key:
                    intent = witness['canonical_intent_digest']
                    if key in effect_key_intents and effect_key_intents[key] != intent:
                        fail(f'{where}: same effect key used for different canonical intent')
                    effect_key_intents[key] = intent
                effects[witness['effect_id']] = witness
            elif kind == 'assert_exactly_once':
                ref = ev.get('effect_ref')
                require_pattern(ref, EFFECT_ID_RE, f'{where}.effect_ref')
                if ref not in effects:
                    fail(f'{where}: assertion references unseen effect')
                fail(f'{where}: exactly-once assertion is outside Steward proof slice')
            elif kind == 'assert_effect_success':
                ref = ev.get('effect_ref')
                require_pattern(ref, EFFECT_ID_RE, f'{where}.effect_ref')
                if ref not in effects:
                    fail(f'{where}: assertion references unseen effect')
                effect = effects[ref]
                if effect['effect_state'] != 'confirmed' or effect['boundary_kind'] not in {'external_confirmed', 'irreversible'}:
                    fail(f'{where}: effect not externally confirmed')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        case_id = case.get('case_id')
        if not isinstance(case_id, str) or not case_id:
            failures.append('case without valid case_id')
            continue
        if case_id in seen:
            failures.append(f'{case_id}: duplicate case_id')
            continue
        seen.add(case_id)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'demand_custody_effect_flow':
            accepted, detail = validate_flow_case(case)
        else:
            failures.append(f'{case_id}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{case_id}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-work-effect-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic demand/custody/effect corpus')
    ap.add_argument('--check', action='store_true', help='check demand/custody/effect corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-work-effect-corpus] FAIL: corpus is stale; run tools/steward_work_effect_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-work-effect-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
