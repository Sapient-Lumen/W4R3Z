#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    fail,
    parse_json_text,
    require_bool,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/activity-accounting-corpus-v0.jsonl'

WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
BRACKET_RE = re.compile(r'^bracket_[a-z0-9]{16}$')
IDLE_RE = re.compile(r'^idle_[a-z0-9]{16}$')
STOPDEFER_RE = re.compile(r'^stopdef_[a-z0-9]{16}$')
ACTACCT_RE = re.compile(r'^actacct_[a-z0-9]{16}$')
ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')
UNIT_RE = re.compile(r'^[a-z][a-z0-9._/-]{0,31}$')

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'adapter', 'policy', 'scheduler', 'auditor'}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

ACTBRACKET_REQUIRED = COMMON_REQUIRED | {
    'activity_bracket_id', 'runtime_cycle_ref', 'activity_kind', 'bracket_state',
    'began_at_ms', 'ended_at_ms', 'stale_after_ms', 'in_flight_count',
    'stop_deferral_hint', 'reason',
}
ACTBRACKET_ALLOWED = ACTBRACKET_REQUIRED | COMMON_OPTIONAL
ACTIVITY_KINDS = {'request', 'message', 'stream', 'timer', 'operator_action', 'background', 'maintenance', 'unknown'}
BRACKET_STATES = {'open', 'closing', 'closed', 'abandoned', 'expired', 'unknown'}
ACTBRACKET_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-demand', 'not-custody',
    'not-work-completion', 'not-effect-success', 'not-readiness', 'not-serving',
    'not-drain', 'not-quiesce', 'not-keepalive-lease', 'not-lossless',
}

IDLEHINT_REQUIRED = COMMON_REQUIRED | {
    'idle_hint_id', 'runtime_cycle_ref', 'idle_state', 'precision',
    'active_bracket_refs', 'as_of_ms', 'expires_at_ms', 'reason',
}
IDLEHINT_ALLOWED = IDLEHINT_REQUIRED | COMMON_OPTIONAL
IDLE_STATES = {'idle', 'busy', 'draining', 'unknown'}
PRECISIONS = {'bracketed', 'counted', 'coarse', 'adapter', 'unknown'}
IDLEHINT_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-currentness', 'not-readiness',
    'not-serving', 'not-quiesce', 'not-drain', 'not-stop-authority',
    'not-work-completion', 'not-effect-success', 'not-idle-stop-grant',
}

STOPDEFER_REQUIRED = COMMON_REQUIRED | {
    'stop_deferral_id', 'stop_request_ref', 'runtime_cycle_ref', 'activity_refs',
    'decision_state', 'decided_at_ms', 'force_after_ms', 'quiesce_ref', 'reason',
}
STOPDEFER_ALLOWED = STOPDEFER_REQUIRED | COMMON_OPTIONAL
STOP_DEFERRAL_STATES = {'honor_until', 'defer', 'deny', 'force_after', 'expired', 'unknown'}
STOPDEFER_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-approval', 'not-stopped', 'not-drained',
    'not-clean-exit', 'not-work-completion', 'not-effect-success', 'not-keepalive-lease',
}

ACTACCT_REQUIRED = COMMON_REQUIRED | {
    'activity_accounting_id', 'scope_ref', 'bracket_refs', 'meter_class', 'unit',
    'quantity', 'window_start_ms', 'window_end_ms', 'estimate_state',
    'settled_state', 'source_refs', 'reason',
}
ACTACCT_ALLOWED = ACTACCT_REQUIRED | COMMON_OPTIONAL
METER_CLASSES = {'activity_count', 'duration_ms', 'bytes', 'messages', 'cpu_ms', 'memory_byte_ms', 'composite', 'unknown'}
ESTIMATE_STATES = {'exact', 'bounded', 'approximate', 'unknown'}
SETTLED_STATES = {'open', 'closed', 'partial', 'abandoned', 'unknown'}
ACTACCT_NON_IMPLICATIONS = {
    'not-authority', 'not-authorization', 'not-billing', 'not-quota-debit',
    'not-pressure', 'not-headroom', 'not-admission', 'not-demand',
    'not-work-completion', 'not-effect-success',
}

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_authorized', 'claims_authorization', 'claims_approval',
    'claims_current', 'claims_current_state', 'claims_fresh', 'claims_readiness',
    'claims_ready', 'claims_serving', 'claims_quiesced', 'claims_drained',
    'claims_stopped', 'claims_clean_exit', 'claims_effect_success', 'claims_execution',
    'claims_mutation', 'claims_policy', 'claims_demand', 'claims_custody',
    'claims_work_complete', 'claims_lossless', 'claims_idle_stop_grant',
    'claims_keepalive_lease', 'claims_billable', 'claims_quota_debit', 'claims_pressure',
    'claims_headroom', 'claims_admission', 'claims_success', 'authority', 'authorized',
    'approved', 'current_state', 'current', 'fresh', 'ready', 'readiness', 'serving',
    'quiesced', 'drained', 'stopped', 'clean_exit', 'effect_success', 'execution',
    'mutation', 'policy_authority', 'demand', 'custody', 'work_complete', 'lossless',
    'idle_stop_grant', 'keepalive_lease', 'billable', 'quota_debit', 'admission',
    'success', 'raw', 'raw_value', 'raw_body', 'raw_log', 'raw_handle', 'raw_text',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie', 'authorization',
    'value', 'path', 'raw_path', 'host_path', 'endpoint', 'raw_endpoint', 'url', 'uri',
    'fd', 'descriptor_number', 'pid', 'ppid', 'pgid', 'cgroup', 'cgroup_path',
    'systemd_unit', 'host_unit', 'pod_name', 'container_id', 'node_name',
    'process_name', 'pty_name', 'shell_job', 'pane_text', 'command_text',
    'k8s_resource_name', 'invoice', 'billing_record', 'chargeback',
}
AMBIENT_REFS = {'ambient', 'current', 'pane:current', 'terminal:current', 'component:current', 'runtime:current', 'activity:current'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = [
        'token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:',
        '/var/', '/proc/', '/tmp/', 'busy proves ready', 'idle proves stopped',
        'activity proves custody', 'bracket proves completion', 'safe to kill',
        'lossless drain', 'keepalive lease', 'billable invoice', 'effect success',
    ]
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, host-path-looking material, or semantic flattery is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16, allow_empty: bool = False, regex: re.Pattern[str] = REF_RE) -> list[str]:
    if not isinstance(value, list):
        fail(f'{path}: expected list')
    if len(value) > maximum:
        fail(f'{path}: too many entries')
    if not allow_empty and not value:
        fail(f'{path}: must not be empty')
    seen: set[str] = set()
    out: list[str] = []
    for idx, item in enumerate(value):
        require_pattern(item, regex, f'{path}[{idx}]')
        if item in AMBIENT_REFS:
            fail(f'{path}[{idx}]: must be exact ref, not ambient/current context')
        if item in seen:
            fail(f'{path}: duplicate entry {item}')
        seen.add(item)
        out.append(item)
    return out


def require_ref(value: Any, path: str, *, allow_none: bool = False, regex: re.Pattern[str] = REF_RE) -> None:
    require_pattern(value, regex, path)
    if value in AMBIENT_REFS:
        fail(f'{path}: must be exact ref, not ambient/current context')
    if not allow_none and value == 'none':
        fail(f'{path}: none is not allowed here')


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=36))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=32)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def validate_actbracket(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ACTBRACKET_ALLOWED, ACTBRACKET_REQUIRED, 'ST-ACTBRACKET v0')
    require_pattern(obj['activity_bracket_id'], BRACKET_RE, '$.activity_bracket_id')
    require_ref(obj['runtime_cycle_ref'], '$.runtime_cycle_ref')
    if obj['activity_kind'] not in ACTIVITY_KINDS:
        fail('$.activity_kind: invalid activity kind')
    if obj['bracket_state'] not in BRACKET_STATES:
        fail('$.bracket_state: invalid bracket state')
    require_int(obj['began_at_ms'], '$.began_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['ended_at_ms'], '$.ended_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['stale_after_ms'], '$.stale_after_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['in_flight_count'], '$.in_flight_count', minimum=0, maximum=1_000_000)
    require_bool(obj['stop_deferral_hint'], '$.stop_deferral_hint')
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], ACTBRACKET_NON_IMPLICATIONS, '$.non_implications')
    state = obj['bracket_state']
    if obj['stale_after_ms'] < obj['began_at_ms']:
        fail('$.stale_after_ms: must not predate begin')
    if state in {'open', 'closing'}:
        if obj['ended_at_ms'] != 0:
            fail('$.ended_at_ms: open/closing bracket must not have an end time')
        if obj['in_flight_count'] < 1:
            fail('$.in_flight_count: open/closing bracket needs in-flight work')
    elif state in {'closed', 'abandoned', 'expired'}:
        if obj['ended_at_ms'] < obj['began_at_ms']:
            fail('$.ended_at_ms: closed/abandoned/expired bracket cannot end before begin')
        if obj['in_flight_count'] != 0:
            fail('$.in_flight_count: finished bracket cannot still count in-flight work')
        if obj['stop_deferral_hint']:
            fail('$.stop_deferral_hint: finished bracket cannot defer stop')
    elif state == 'unknown':
        if obj['stop_deferral_hint']:
            fail('$.stop_deferral_hint: unknown bracket cannot defer stop')
    if obj['stop_deferral_hint'] and state not in {'open', 'closing'}:
        fail('$.stop_deferral_hint: only open/closing brackets can defer stop')
    return obj


def validate_idlehint(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, IDLEHINT_ALLOWED, IDLEHINT_REQUIRED, 'ST-IDLEHINT v0')
    require_pattern(obj['idle_hint_id'], IDLE_RE, '$.idle_hint_id')
    require_ref(obj['runtime_cycle_ref'], '$.runtime_cycle_ref')
    if obj['idle_state'] not in IDLE_STATES:
        fail('$.idle_state: invalid idle state')
    if obj['precision'] not in PRECISIONS:
        fail('$.precision: invalid precision')
    require_refs(obj['active_bracket_refs'], '$.active_bracket_refs', maximum=32, allow_empty=True, regex=BRACKET_RE)
    require_int(obj['as_of_ms'], '$.as_of_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['expires_at_ms'], '$.expires_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], IDLEHINT_NON_IMPLICATIONS, '$.non_implications')
    if obj['expires_at_ms'] <= obj['as_of_ms']:
        fail('$.expires_at_ms: idle hint must have a positive freshness window')
    if obj['idle_state'] == 'idle' and obj['active_bracket_refs']:
        fail('$.active_bracket_refs: idle hint cannot cite active brackets')
    if obj['idle_state'] in {'busy', 'draining'} and obj['precision'] in {'bracketed', 'counted'} and not obj['active_bracket_refs']:
        fail('$.active_bracket_refs: bracketed/counted busy or draining hint needs exact bracket refs')
    return obj


def validate_stopdefer(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, STOPDEFER_ALLOWED, STOPDEFER_REQUIRED, 'ST-STOPDEFER v0')
    require_pattern(obj['stop_deferral_id'], STOPDEFER_RE, '$.stop_deferral_id')
    require_ref(obj['stop_request_ref'], '$.stop_request_ref')
    require_ref(obj['runtime_cycle_ref'], '$.runtime_cycle_ref')
    require_refs(obj['activity_refs'], '$.activity_refs', maximum=32, regex=BRACKET_RE)
    if obj['decision_state'] not in STOP_DEFERRAL_STATES:
        fail('$.decision_state: invalid stop-deferral decision state')
    require_int(obj['decided_at_ms'], '$.decided_at_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['force_after_ms'], '$.force_after_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_ref(obj['quiesce_ref'], '$.quiesce_ref', allow_none=True)
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], STOPDEFER_NON_IMPLICATIONS, '$.non_implications')
    if obj['decision_state'] in {'honor_until', 'defer', 'force_after'}:
        if obj['force_after_ms'] <= obj['decided_at_ms']:
            fail('$.force_after_ms: honoring deferral must be bounded in the future')
    if obj['decision_state'] in {'deny', 'expired', 'unknown'} and obj['force_after_ms'] != 0:
        fail('$.force_after_ms: deny/expired/unknown must not imply a future lease')
    return obj


def validate_actacct(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, ACTACCT_ALLOWED, ACTACCT_REQUIRED, 'ST-ACTACCT v0')
    require_pattern(obj['activity_accounting_id'], ACTACCT_RE, '$.activity_accounting_id')
    require_ref(obj['scope_ref'], '$.scope_ref')
    require_refs(obj['bracket_refs'], '$.bracket_refs', maximum=32, allow_empty=True, regex=BRACKET_RE)
    if obj['meter_class'] not in METER_CLASSES:
        fail('$.meter_class: invalid meter class')
    require_pattern(obj['unit'], UNIT_RE, '$.unit')
    require_int(obj['quantity'], '$.quantity', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['window_start_ms'], '$.window_start_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    require_int(obj['window_end_ms'], '$.window_end_ms', minimum=0, maximum=9_223_372_036_854_775_807)
    if obj['estimate_state'] not in ESTIMATE_STATES:
        fail('$.estimate_state: invalid estimate state')
    if obj['settled_state'] not in SETTLED_STATES:
        fail('$.settled_state: invalid settled state')
    require_refs(obj['source_refs'], '$.source_refs', maximum=32)
    require_text(obj['reason'], '$.reason')
    require_non_implications(obj['non_implications'], ACTACCT_NON_IMPLICATIONS, '$.non_implications')
    if obj['settled_state'] == 'open':
        if obj['window_end_ms'] != 0:
            fail('$.window_end_ms: open accounting window must not have final end')
    else:
        if obj['window_end_ms'] <= obj['window_start_ms']:
            fail('$.window_end_ms: settled accounting window must close after start')
    if obj['estimate_state'] == 'exact' and obj['meter_class'] == 'unknown':
        fail('$.estimate_state: exact accounting cannot use unknown meter class')
    return obj


VALIDATORS = {
    'ST-ACTBRACKET': validate_actbracket,
    'ST-IDLEHINT': validate_idlehint,
    'ST-STOPDEFER': validate_stopdefer,
    'ST-ACTACCT': validate_actacct,
}


def common(schema: str, witness: str, basis: str) -> dict[str, Any]:
    return {
        'schema': f'{schema} v0',
        'witness_id': witness,
        'cid': 'demo.web',
        'issuer': {'kind': 'steward', 'id': 'steward.core'},
        'observed_at_ms': 1000,
        'basis_refs': [basis],
        'non_implications': [],
    }


def bracket_open() -> dict[str, Any]:
    obj = common('ST-ACTBRACKET', 'wit_a100000000000001', 'sha256:' + '1' * 64)
    obj.update({
        'non_implications': sorted(ACTBRACKET_NON_IMPLICATIONS),
        'activity_bracket_id': 'bracket_1000000000000001',
        'runtime_cycle_ref': 'rtcycle/demo.web/0001',
        'activity_kind': 'request',
        'bracket_state': 'open',
        'began_at_ms': 900,
        'ended_at_ms': 0,
        'stale_after_ms': 1900,
        'in_flight_count': 1,
        'stop_deferral_hint': True,
        'reason': 'request in flight during bounded drain',
    })
    return obj


def bracket_closed() -> dict[str, Any]:
    obj = bracket_open()
    obj.update({
        'witness_id': 'wit_a100000000000002',
        'basis_refs': ['sha256:' + '2' * 64],
        'activity_bracket_id': 'bracket_1000000000000002',
        'bracket_state': 'closed',
        'ended_at_ms': 1300,
        'stale_after_ms': 1400,
        'in_flight_count': 0,
        'stop_deferral_hint': False,
        'reason': 'request bracket ended with external outcome separate',
    })
    return obj


def idle_busy() -> dict[str, Any]:
    obj = common('ST-IDLEHINT', 'wit_b100000000000001', 'sha256:' + '3' * 64)
    obj.update({
        'non_implications': sorted(IDLEHINT_NON_IMPLICATIONS),
        'idle_hint_id': 'idle_1000000000000001',
        'runtime_cycle_ref': 'rtcycle/demo.web/0001',
        'idle_state': 'busy',
        'precision': 'bracketed',
        'active_bracket_refs': ['bracket_1000000000000001'],
        'as_of_ms': 1000,
        'expires_at_ms': 1200,
        'reason': 'activity bracket is still open',
    })
    return obj


def idle_idle() -> dict[str, Any]:
    obj = idle_busy()
    obj.update({
        'witness_id': 'wit_b100000000000002',
        'basis_refs': ['sha256:' + '4' * 64],
        'idle_hint_id': 'idle_1000000000000002',
        'idle_state': 'idle',
        'precision': 'bracketed',
        'active_bracket_refs': [],
        'as_of_ms': 1400,
        'expires_at_ms': 1700,
        'reason': 'no active brackets known in this runtime cycle',
    })
    return obj


def stopdefer_honor() -> dict[str, Any]:
    obj = common('ST-STOPDEFER', 'wit_c100000000000001', 'sha256:' + '5' * 64)
    obj.update({
        'non_implications': sorted(STOPDEFER_NON_IMPLICATIONS),
        'stop_deferral_id': 'stopdef_1000000000000001',
        'stop_request_ref': 'opreq/demo.web/stop/0001',
        'runtime_cycle_ref': 'rtcycle/demo.web/0001',
        'activity_refs': ['bracket_1000000000000001'],
        'decision_state': 'honor_until',
        'decided_at_ms': 1100,
        'force_after_ms': 1800,
        'quiesce_ref': 'quiesce/demo.web/0001',
        'reason': 'bounded in flight bracket defers force',
    })
    return obj


def stopdefer_deny() -> dict[str, Any]:
    obj = stopdefer_honor()
    obj.update({
        'witness_id': 'wit_c100000000000002',
        'basis_refs': ['sha256:' + '6' * 64],
        'stop_deferral_id': 'stopdef_1000000000000002',
        'activity_refs': ['bracket_1000000000000002'],
        'decision_state': 'deny',
        'decided_at_ms': 1500,
        'force_after_ms': 0,
        'reason': 'closed bracket cannot defer stop',
    })
    return obj


def acct_partial() -> dict[str, Any]:
    obj = common('ST-ACTACCT', 'wit_d100000000000001', 'sha256:' + '7' * 64)
    obj.update({
        'non_implications': sorted(ACTACCT_NON_IMPLICATIONS),
        'activity_accounting_id': 'actacct_1000000000000001',
        'scope_ref': 'runtime/demo.web/0001',
        'bracket_refs': ['bracket_1000000000000001'],
        'meter_class': 'activity_count',
        'unit': 'brackets',
        'quantity': 1,
        'window_start_ms': 900,
        'window_end_ms': 0,
        'estimate_state': 'exact',
        'settled_state': 'open',
        'source_refs': ['bracket_1000000000000001'],
        'reason': 'open activity count is descriptive only',
    })
    return obj


def acct_closed() -> dict[str, Any]:
    obj = acct_partial()
    obj.update({
        'witness_id': 'wit_d100000000000002',
        'basis_refs': ['sha256:' + '8' * 64],
        'activity_accounting_id': 'actacct_1000000000000002',
        'bracket_refs': ['bracket_1000000000000002'],
        'window_end_ms': 1400,
        'settled_state': 'closed',
        'source_refs': ['bracket_1000000000000002'],
        'reason': 'closed accounting window records usage only',
    })
    return obj


def schema_case(id_: str, object_kind: str, obj: dict[str, Any] | None, expect: str, note: str, *, json_text: str | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {'id': id_, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'note': note}
    if json_text is not None:
        out['json_text'] = json_text
    else:
        out['object'] = obj
    return out


def flow_case(id_: str, packets: list[dict[str, Any]], expect: str, note: str) -> dict[str, Any]:
    return {'id': id_, 'kind': 'flow', 'expect': expect, 'note': note, 'packets': packets}


def build_cases() -> list[dict[str, Any]]:
    b_open = bracket_open()
    b_closed = bracket_closed()
    i_busy = idle_busy()
    i_idle = idle_idle()
    sd_honor = stopdefer_honor()
    sd_deny = stopdefer_deny()
    a_partial = acct_partial()
    a_closed = acct_closed()
    return [
        schema_case('actbracket.accept.open', 'ST-ACTBRACKET', b_open, 'accept', 'an open bracket can describe in-flight activity without authority'),
        schema_case('actbracket.accept.closed', 'ST-ACTBRACKET', b_closed, 'accept', 'a closed bracket records an ended activity without effect success'),
        schema_case('actbracket.reject.readiness-flattery', 'ST-ACTBRACKET', {**b_open, 'claims_ready': True}, 'reject', 'activity is not readiness'),
        schema_case('actbracket.reject.open-with-end', 'ST-ACTBRACKET', {**b_open, 'ended_at_ms': 1200}, 'reject', 'open brackets cannot claim an end time'),
        schema_case('actbracket.reject.closed-inflight', 'ST-ACTBRACKET', {**b_closed, 'in_flight_count': 1}, 'reject', 'closed brackets cannot still count in-flight work'),
        schema_case('idlehint.accept.busy', 'ST-IDLEHINT', i_busy, 'accept', 'busy can cite exact brackets but remains weaker than readiness or serving'),
        schema_case('idlehint.accept.idle', 'ST-IDLEHINT', i_idle, 'accept', 'idle is a scoped hint and not stopped or drained truth'),
        schema_case('idlehint.reject.idle-with-active-ref', 'ST-IDLEHINT', {**i_idle, 'active_bracket_refs': ['bracket_1000000000000001']}, 'reject', 'idle cannot cite active brackets'),
        schema_case('idlehint.reject.busy-no-bracket', 'ST-IDLEHINT', {**i_busy, 'active_bracket_refs': []}, 'reject', 'bracketed busy hints need exact bracket refs'),
        schema_case('idlehint.reject.stop-authority-flattery', 'ST-IDLEHINT', {**i_idle, 'claims_stopped': True}, 'reject', 'idle is not stopped or stop authority'),
        schema_case('stopdefer.accept.honor', 'ST-STOPDEFER', sd_honor, 'accept', 'a stop deferral can honor bounded in-flight activity without becoming a lease'),
        schema_case('stopdefer.accept.deny', 'ST-STOPDEFER', sd_deny, 'accept', 'denying deferral remains explicit and does not prove stopped state'),
        schema_case('stopdefer.reject.keepalive-flattery', 'ST-STOPDEFER', {**sd_honor, 'claims_keepalive_lease': True}, 'reject', 'stop deferral is not an immortal keepalive lease'),
        schema_case('stopdefer.reject.unbounded-defer', 'ST-STOPDEFER', {**sd_honor, 'force_after_ms': 0}, 'reject', 'honored deferral must be bounded'),
        schema_case('actacct.accept.partial', 'ST-ACTACCT', a_partial, 'accept', 'open accounting is descriptive usage, not billing or success'),
        schema_case('actacct.accept.closed', 'ST-ACTACCT', a_closed, 'accept', 'closed accounting still does not imply work completion or effect success'),
        schema_case('actacct.reject.billing-flattery', 'ST-ACTACCT', {**a_closed, 'claims_billable': True}, 'reject', 'activity accounting is not billing or quota debit'),
        schema_case('actacct.reject.open-with-end', 'ST-ACTACCT', {**a_partial, 'window_end_ms': 1200}, 'reject', 'open accounting window cannot claim final end'),
        schema_case('actacct.reject.duplicate-json-key', 'ST-ACTACCT', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-ACTACCT v0","schema":"ST-ACTACCT v0","witness_id":"wit_d100000000000003","cid":"demo.web","issuer":{"kind":"steward","id":"steward.core"},"observed_at_ms":1000,"basis_refs":["sha256:9999999999999999999999999999999999999999999999999999999999999999"],"non_implications":[],"activity_accounting_id":"actacct_1000000000000003","scope_ref":"runtime/demo.web/0001","bracket_refs":[],"meter_class":"activity_count","unit":"brackets","quantity":0,"window_start_ms":900,"window_end_ms":0,"estimate_state":"exact","settled_state":"open","source_refs":["sha256:9999999999999999999999999999999999999999999999999999999999999999"],"reason":"duplicate"}'),

        flow_case('activity-accounting.accept.open-busy-deferral', [b_open, i_busy, sd_honor, a_partial], 'accept', 'open activity can support bounded deferral while staying weaker than custody, drain, and success'),
        flow_case('activity-accounting.accept.closed-idle-accounted', [b_closed, i_idle, a_closed], 'accept', 'closed bracket can support idle and closed accounting without implying work success'),
        flow_case('activity-accounting.reject.idle-while-open-bracket', [b_open, i_idle], 'reject', 'idle cannot be claimed for a runtime with an open bracket'),
        flow_case('activity-accounting.reject.deferral-cites-closed-bracket', [b_closed, sd_deny], 'reject', 'closed activity bracket cannot defer stop in the flow'),
        flow_case('activity-accounting.reject.deferral-after-stale-bracket', [b_open, {**sd_honor, 'force_after_ms': 2500}], 'reject', 'stop deferral cannot outlive the activity bracket freshness fence'),
        flow_case('activity-accounting.reject.closed-accounting-open-bracket', [b_open, {**a_closed, 'bracket_refs': ['bracket_1000000000000001'], 'source_refs': ['bracket_1000000000000001']}], 'reject', 'closed accounting cannot settle an open bracket'),
        flow_case('activity-accounting.reject.duplicate-bracket-id-drift', [b_open, {**b_open, 'witness_id': 'wit_a100000000000009', 'reason': 'same bracket id with different bytes'}], 'reject', 'activity bracket ids cannot be reused for different canonical bytes'),
    ]


def validate_packet(packet: dict[str, Any]) -> dict[str, Any]:
    schema = packet.get('schema')
    if not isinstance(schema, str) or not schema.endswith(' v0'):
        fail('packet schema missing')
    kind = schema.removesuffix(' v0')
    validator = VALIDATORS.get(kind)
    if validator is None:
        fail(f'unknown schema {schema}')
    return validator(packet)


def validate_flow(packets: list[dict[str, Any]]) -> None:
    by_schema: dict[str, list[dict[str, Any]]] = {}
    canonical_by_domain_id: dict[tuple[str, str], str] = {}
    for idx, packet in enumerate(packets):
        obj = validate_packet(packet)
        schema = obj['schema'].removesuffix(' v0')
        by_schema.setdefault(schema, []).append(obj)
        if schema == 'ST-ACTBRACKET':
            domain_id = obj['activity_bracket_id']
        elif schema == 'ST-IDLEHINT':
            domain_id = obj['idle_hint_id']
        elif schema == 'ST-STOPDEFER':
            domain_id = obj['stop_deferral_id']
        elif schema == 'ST-ACTACCT':
            domain_id = obj['activity_accounting_id']
        else:
            domain_id = obj['witness_id']
        key = (schema, domain_id)
        raw = json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
        prior = canonical_by_domain_id.get(key)
        if prior is not None and prior != raw:
            fail(f'packet {idx}: duplicate {schema} domain id with different canonical bytes')
        canonical_by_domain_id[key] = raw

    brackets = {b['activity_bracket_id']: b for b in by_schema.get('ST-ACTBRACKET', [])}
    open_by_runtime: dict[str, list[dict[str, Any]]] = {}
    for bracket in brackets.values():
        if bracket['bracket_state'] in {'open', 'closing'}:
            open_by_runtime.setdefault(bracket['runtime_cycle_ref'], []).append(bracket)

    for idle in by_schema.get('ST-IDLEHINT', []):
        for ref in idle['active_bracket_refs']:
            if ref not in brackets:
                fail(f'idle hint {idle["idle_hint_id"]}: missing bracket ref {ref}')
            if brackets[ref]['bracket_state'] not in {'open', 'closing'}:
                fail(f'idle hint {idle["idle_hint_id"]}: active ref {ref} is not open')
            if brackets[ref]['runtime_cycle_ref'] != idle['runtime_cycle_ref']:
                fail(f'idle hint {idle["idle_hint_id"]}: bracket {ref} belongs to a different runtime cycle')
        if idle['idle_state'] == 'idle' and open_by_runtime.get(idle['runtime_cycle_ref']):
            fail(f'idle hint {idle["idle_hint_id"]}: cannot claim idle while open brackets exist for runtime cycle')

    for sd in by_schema.get('ST-STOPDEFER', []):
        for ref in sd['activity_refs']:
            if ref not in brackets:
                fail(f'stop deferral {sd["stop_deferral_id"]}: missing activity ref {ref}')
            bracket = brackets[ref]
            if bracket['runtime_cycle_ref'] != sd['runtime_cycle_ref']:
                fail(f'stop deferral {sd["stop_deferral_id"]}: activity ref {ref} belongs to a different runtime cycle')
            if bracket['bracket_state'] not in {'open', 'closing'}:
                fail(f'stop deferral {sd["stop_deferral_id"]}: activity ref {ref} is not open/closing')
            if sd['decision_state'] in {'honor_until', 'defer', 'force_after'} and sd['force_after_ms'] > bracket['stale_after_ms']:
                fail(f'stop deferral {sd["stop_deferral_id"]}: force_after outlives bracket freshness')

    for acct in by_schema.get('ST-ACTACCT', []):
        for ref in acct['bracket_refs']:
            if ref not in brackets:
                fail(f'accounting {acct["activity_accounting_id"]}: missing bracket ref {ref}')
        if acct['settled_state'] in {'closed', 'abandoned'}:
            for ref in acct['bracket_refs']:
                if brackets[ref]['bracket_state'] in {'open', 'closing'}:
                    fail(f'accounting {acct["activity_accounting_id"]}: cannot close accounting over open bracket {ref}')


def run_schema_case(case: dict[str, Any]) -> None:
    try:
        if case.get('json_text') is not None:
            obj = parse_json_text(case['json_text'])
        else:
            obj = case['object']
        object_kind = case['object_kind']
        validator = VALIDATORS.get(object_kind)
        if validator is None:
            fail(f'unknown object_kind {object_kind}')
        validator(obj)
        actual = 'accept'
    except Exception:
        actual = 'reject'
    if actual != case['expect']:
        fail(f"{case['id']}: expected {case['expect']} got {actual}")


def run_flow_case(case: dict[str, Any]) -> None:
    try:
        validate_flow(case['packets'])
        actual = 'accept'
    except Exception:
        actual = 'reject'
    if actual != case['expect']:
        fail(f"{case['id']}: expected {case['expect']} got {actual}")


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path = CORPUS_PATH) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    for case in cases:
        if case['id'] in seen:
            fail(f"duplicate case id {case['id']}")
        seen.add(case['id'])
        if case['kind'] == 'schema':
            run_schema_case(case)
        elif case['kind'] == 'flow':
            run_flow_case(case)
        else:
            fail(f"{case['id']}: unknown kind")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true')
    ap.add_argument('--check', action='store_true')
    args = ap.parse_args()
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    if args.write:
        CORPUS_PATH.parent.mkdir(parents=True, exist_ok=True)
        CORPUS_PATH.write_text(render_cases(build_cases()), encoding='utf-8')
        print(CORPUS_PATH)
    if args.check:
        check_cases(load_corpus())
        print('[steward_activity_accounting_harness] OK')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
