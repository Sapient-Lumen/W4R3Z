#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from steward_lifecycle_harness import (
    CID_RE,
    DIGEST_RE,
    digest,
    fail,
    parse_json_text,
    require_closed_keys,
    require_int,
    require_object,
    require_pattern,
    require_string_list,
)

ROOT = Path(__file__).resolve().parents[1]
CORPUS_PATH = ROOT / 'docs/40-verification/corpora/receipt-transport-corpus-v0.jsonl'

ACTOR_RE = re.compile(r'^[a-z][a-z0-9._@/-]{0,95}$')
REF_RE = re.compile(r'^(sha256:[0-9a-f]{64}|[a-z][a-z0-9._:/-]{0,95})$')
WITNESS_RE = re.compile(r'^wit_[a-z0-9]{16}$')
CHAIN_RE = re.compile(r'^rch_[a-z0-9]{16}$')
EXPORT_RE = re.compile(r'^exp_[a-z0-9]{16}$')
REDACTION_RE = re.compile(r'^red_[a-z0-9]{16}$')
REPLAY_RE = re.compile(r'^rpl_[a-z0-9]{16}$')
FIELD_RE = re.compile(r'^[a-z][a-z0-9._-]{0,63}$')
TEXT_RE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9 .,;:_/@#()\[\]-]{0,239}$')

ISSUER_REQUIRED = {'kind', 'id'}
ISSUER_OPTIONAL = {'authority_digest'}
ISSUER_ALLOWED = ISSUER_REQUIRED | ISSUER_OPTIONAL
ISSUER_KINDS = {'steward', 'operator', 'automation', 'adapter', 'exporter', 'verifier', 'archivist', 'policy'}

FORBIDDEN_ANYWHERE = {
    'claims_authority', 'claims_current', 'claims_fresh', 'claims_live',
    'claims_complete_history', 'claims_full_fidelity', 'claims_effect_success',
    'claims_execution', 'claims_readiness', 'claims_serving', 'claims_custody',
    'claims_work_completion', 'claims_secret_free_by_assertion', 'claims_lossless',
    'authority', 'current', 'fresh', 'effect_success', 'readiness', 'serving',
    'raw', 'raw_value', 'raw_body', 'raw_packet', 'raw_handle', 'raw_secret',
    'token', 'secret', 'bearer', 'credential', 'password', 'cookie', 'authorization',
    'value', 'path', 'raw_path', 'host_path', 'endpoint', 'raw_endpoint', 'url', 'uri',
    'fd', 'descriptor_number', 'pid', 'ppid', 'pgid', 'cgroup', 'systemd_unit',
    'pod_name', 'container_id', 'pane_text', 'pty_name', 'shell_job',
}

COMMON_REQUIRED = {'schema', 'witness_id', 'cid', 'issuer', 'observed_at_ms', 'basis_refs', 'non_implications'}
COMMON_OPTIONAL = {'unknown_reason'}

CHAIN_REQUIRED = COMMON_REQUIRED | {
    'chain_id', 'chain_state', 'ordinal', 'previous_link_digest', 'receipt_digest',
    'receipt_kind', 'emitted_at_ms', 'head_digest',
}
CHAIN_OPTIONAL = COMMON_OPTIONAL | {'gap_reason'}
CHAIN_ALLOWED = CHAIN_REQUIRED | CHAIN_OPTIONAL
CHAIN_STATES = {'genesis', 'append', 'sealed', 'gap', 'unknown'}
RECEIPT_KINDS = {
    'ST-OPRECEIPT', 'ST-AUTHCHECK', 'ST-EFFECT', 'ST-DRAIN', 'ST-TERMCAUSE',
    'ST-RETRYATTEMPT', 'ST-CTRLVERDICT', 'ST-REVIEW', 'ST-APPROVAL', 'external', 'unknown',
}
CHAIN_NON_IMPLICATIONS = {'not-authority', 'not-current-state', 'not-effect-success', 'not-complete-history'}

RED_REQUIRED = COMMON_REQUIRED | {
    'redaction_id', 'profile', 'source_digest', 'retained_fields', 'stripped_classes',
    'commitment_digest',
}
RED_OPTIONAL = COMMON_OPTIONAL | {'loss_note'}
RED_ALLOWED = RED_REQUIRED | RED_OPTIONAL
REDACTION_PROFILES = {'minimal_handoff', 'operator_summary', 'audit_minimized', 'public_bug_report'}
STRIPPED_CLASSES = {
    'bearer_material', 'raw_endpoint', 'host_path', 'payload_body', 'operator_note',
    'shell_text', 'token_value', 'descriptor_number', 'secret_value', 'raw_transcript',
}
RED_NON_IMPLICATIONS = {'not-source-truth', 'not-full-fidelity', 'not-authority', 'not-secret-free-proof'}

EXPORT_REQUIRED = COMMON_REQUIRED | {
    'export_id', 'export_scope', 'audience_class', 'chain_head_digest',
    'included_receipt_digests', 'redaction_ref', 'redaction_digest', 'export_manifest_digest',
}
EXPORT_OPTIONAL = COMMON_OPTIONAL | {'expires_or_recheck_by_ms'}
EXPORT_ALLOWED = EXPORT_REQUIRED | EXPORT_OPTIONAL
EXPORT_SCOPES = {'handoff', 'incident_review', 'support_case', 'release_evidence', 'operator_explanation'}
AUDIENCE_CLASSES = {'same_operator', 'sibling_cube', 'support_minimized', 'public_redacted', 'internal_audit'}
EXPORT_NON_IMPLICATIONS = {'not-authority', 'not-live-state', 'not-freshness', 'not-secret-carrier'}

REPLAY_REQUIRED = COMMON_REQUIRED | {
    'replay_id', 'source_export_ref', 'source_export_digest', 'replay_context',
    'verification_status', 'verified_receipt_digests', 'gap_state',
}
REPLAY_OPTIONAL = COMMON_OPTIONAL | {'gap_reason', 'recheck_after_ms'}
REPLAY_ALLOWED = REPLAY_REQUIRED | REPLAY_OPTIONAL
REPLAY_CONTEXTS = {'handoff_import', 'manager_recovery', 'audit_replay', 'sibling_review'}
REPLAY_STATUSES = {'verified', 'partial', 'failed', 'stale', 'unknown'}
GAP_STATES = {'none', 'missing_receipts', 'digest_mismatch', 'redaction_loss', 'unknown'}
REPLAY_NON_IMPLICATIONS = {'not-authority', 'not-current-state', 'not-freshness', 'not-effect-success'}


def scan_forbidden_keys(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in FORBIDDEN_ANYWHERE:
                fail(f'{path}: forbidden field {key}')
            scan_forbidden_keys(child, f'{path}.{key}')
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            scan_forbidden_keys(child, f'{path}[{idx}]')


def require_text(value: Any, path: str) -> None:
    require_pattern(value, TEXT_RE, path)
    lowered = value.lower()
    banned = ['token=', 'secret=', 'bearer ', 'password=', 'cookie=', 'http:', 'https:', '/var/', '/proc/', '/tmp/']
    if any(item in lowered for item in banned):
        fail(f'{path}: raw secret, endpoint, cookie, or host-path-looking material is not allowed')


def require_refs(value: Any, path: str, *, maximum: int = 16) -> list[str]:
    return require_string_list(value, path, regex=REF_RE, maximum=maximum)


def require_digest_list(value: Any, path: str, *, maximum: int = 32, allow_empty: bool = False) -> list[str]:
    items = require_string_list(value, path, regex=DIGEST_RE, maximum=maximum)
    if not allow_empty and not items:
        fail(f'{path}: must not be empty')
    return items


def require_non_implications(value: Any, required: set[str], path: str) -> set[str]:
    items = set(require_refs(value, path, maximum=24))
    missing = sorted(required - items)
    if missing:
        fail(f'{path}: missing non-implications {missing}')
    return items


def validate_issuer(value: Any, path: str) -> dict[str, Any]:
    issuer = require_object(value, path)
    require_closed_keys(issuer, ISSUER_ALLOWED, ISSUER_REQUIRED, path)
    if issuer['kind'] not in ISSUER_KINDS:
        fail(f'{path}.kind: invalid issuer kind')
    require_pattern(issuer['id'], ACTOR_RE, f'{path}.id')
    if 'authority_digest' in issuer:
        require_pattern(issuer['authority_digest'], DIGEST_RE, f'{path}.authority_digest')
    return issuer


def validate_common(obj: Any, allowed: set[str], required: set[str], schema: str) -> dict[str, Any]:
    obj = require_object(obj, '$')
    scan_forbidden_keys(obj)
    require_closed_keys(obj, allowed, required, '$')
    if obj['schema'] != schema:
        fail(f'$.schema: expected {schema}')
    require_pattern(obj['witness_id'], WITNESS_RE, '$.witness_id')
    require_pattern(obj['cid'], CID_RE, '$.cid')
    validate_issuer(obj['issuer'], '$.issuer')
    require_int(obj['observed_at_ms'], '$.observed_at_ms')
    require_refs(obj['basis_refs'], '$.basis_refs', maximum=24)
    if 'unknown_reason' in obj:
        require_text(obj['unknown_reason'], '$.unknown_reason')
    return obj


def chain_material(obj: dict[str, Any]) -> dict[str, Any]:
    return {
        'chain_id': obj['chain_id'],
        'cid': obj['cid'],
        'ordinal': obj['ordinal'],
        'previous_link_digest': obj['previous_link_digest'],
        'receipt_digest': obj['receipt_digest'],
        'receipt_kind': obj['receipt_kind'],
        'emitted_at_ms': obj['emitted_at_ms'],
    }


def redaction_material(obj: dict[str, Any]) -> dict[str, Any]:
    return {
        'profile': obj['profile'],
        'source_digest': obj['source_digest'],
        'retained_fields': obj['retained_fields'],
        'stripped_classes': obj['stripped_classes'],
    }


def export_material(obj: dict[str, Any]) -> dict[str, Any]:
    return {
        'export_scope': obj['export_scope'],
        'audience_class': obj['audience_class'],
        'chain_head_digest': obj['chain_head_digest'],
        'included_receipt_digests': obj['included_receipt_digests'],
        'redaction_ref': obj['redaction_ref'],
        'redaction_digest': obj['redaction_digest'],
    }


def validate_receipt_chain(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, CHAIN_ALLOWED, CHAIN_REQUIRED, 'ST-RECEIPTCHAIN v0')
    require_pattern(obj['chain_id'], CHAIN_RE, '$.chain_id')
    if obj['chain_state'] not in CHAIN_STATES:
        fail('$.chain_state: invalid')
    require_int(obj['ordinal'], '$.ordinal')
    if obj['previous_link_digest'] != 'genesis':
        require_pattern(obj['previous_link_digest'], DIGEST_RE, '$.previous_link_digest')
    if obj['chain_state'] == 'genesis' and obj['previous_link_digest'] != 'genesis':
        fail('$.previous_link_digest: genesis chain must use genesis previous link')
    if obj['chain_state'] != 'genesis' and obj['ordinal'] == 0:
        fail('$.ordinal: ordinal zero must be genesis')
    require_pattern(obj['receipt_digest'], DIGEST_RE, '$.receipt_digest')
    if obj['receipt_kind'] not in RECEIPT_KINDS:
        fail('$.receipt_kind: invalid')
    require_int(obj['emitted_at_ms'], '$.emitted_at_ms')
    require_pattern(obj['head_digest'], DIGEST_RE, '$.head_digest')
    if obj['head_digest'] != digest(chain_material(obj)):
        fail('$.head_digest: does not match canonical chain material')
    if obj['chain_state'] == 'gap' and 'gap_reason' not in obj:
        fail('$.gap_reason: gap state needs reason')
    if 'gap_reason' in obj:
        require_text(obj['gap_reason'], '$.gap_reason')
    require_non_implications(obj['non_implications'], CHAIN_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_redaction(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, RED_ALLOWED, RED_REQUIRED, 'ST-REDACTION v0')
    require_pattern(obj['redaction_id'], REDACTION_RE, '$.redaction_id')
    if obj['profile'] not in REDACTION_PROFILES:
        fail('$.profile: invalid')
    require_pattern(obj['source_digest'], DIGEST_RE, '$.source_digest')
    fields = require_string_list(obj['retained_fields'], '$.retained_fields', regex=FIELD_RE, maximum=32)
    if not fields:
        fail('$.retained_fields: must not be empty')
    stripped = require_string_list(obj['stripped_classes'], '$.stripped_classes', regex=FIELD_RE, maximum=16)
    bad = [x for x in stripped if x not in STRIPPED_CLASSES]
    if bad:
        fail(f'$.stripped_classes: invalid class(es) {bad}')
    if 'bearer_material' not in stripped and 'token_value' not in stripped and 'secret_value' not in stripped:
        fail('$.stripped_classes: must explicitly strip bearer, token, or secret class')
    require_pattern(obj['commitment_digest'], DIGEST_RE, '$.commitment_digest')
    if obj['commitment_digest'] != digest(redaction_material(obj)):
        fail('$.commitment_digest: does not match canonical redaction material')
    if 'loss_note' in obj:
        require_text(obj['loss_note'], '$.loss_note')
    require_non_implications(obj['non_implications'], RED_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_export_bundle(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, EXPORT_ALLOWED, EXPORT_REQUIRED, 'ST-EXPORTBUNDLE v0')
    require_pattern(obj['export_id'], EXPORT_RE, '$.export_id')
    if obj['export_scope'] not in EXPORT_SCOPES:
        fail('$.export_scope: invalid')
    if obj['audience_class'] not in AUDIENCE_CLASSES:
        fail('$.audience_class: invalid')
    require_pattern(obj['chain_head_digest'], DIGEST_RE, '$.chain_head_digest')
    included = require_digest_list(obj['included_receipt_digests'], '$.included_receipt_digests', maximum=64)
    if included != sorted(included):
        fail('$.included_receipt_digests: must be sorted for canonical export manifests')
    require_pattern(obj['redaction_ref'], REDACTION_RE, '$.redaction_ref')
    require_pattern(obj['redaction_digest'], DIGEST_RE, '$.redaction_digest')
    require_pattern(obj['export_manifest_digest'], DIGEST_RE, '$.export_manifest_digest')
    if obj['export_manifest_digest'] != digest(export_material(obj)):
        fail('$.export_manifest_digest: does not match canonical export material')
    if 'expires_or_recheck_by_ms' in obj:
        require_int(obj['expires_or_recheck_by_ms'], '$.expires_or_recheck_by_ms')
        if obj['expires_or_recheck_by_ms'] < obj['observed_at_ms']:
            fail('$.expires_or_recheck_by_ms: cannot be before observed_at_ms')
    require_non_implications(obj['non_implications'], EXPORT_NON_IMPLICATIONS, '$.non_implications')
    return obj


def validate_replay_observation(obj: Any) -> dict[str, Any]:
    obj = validate_common(obj, REPLAY_ALLOWED, REPLAY_REQUIRED, 'ST-REPLAYOBS v0')
    require_pattern(obj['replay_id'], REPLAY_RE, '$.replay_id')
    require_pattern(obj['source_export_ref'], EXPORT_RE, '$.source_export_ref')
    require_pattern(obj['source_export_digest'], DIGEST_RE, '$.source_export_digest')
    if obj['replay_context'] not in REPLAY_CONTEXTS:
        fail('$.replay_context: invalid')
    if obj['verification_status'] not in REPLAY_STATUSES:
        fail('$.verification_status: invalid')
    require_digest_list(obj['verified_receipt_digests'], '$.verified_receipt_digests', maximum=64, allow_empty=obj['verification_status'] != 'verified')
    if obj['gap_state'] not in GAP_STATES:
        fail('$.gap_state: invalid')
    if obj['verification_status'] == 'verified' and obj['gap_state'] != 'none':
        fail('$.gap_state: verified replay cannot carry a gap')
    if obj['verification_status'] in {'partial', 'failed', 'stale', 'unknown'} and 'gap_reason' not in obj:
        fail('$.gap_reason: non-verified replay needs a reason')
    if 'gap_reason' in obj:
        require_text(obj['gap_reason'], '$.gap_reason')
    if 'recheck_after_ms' in obj:
        require_int(obj['recheck_after_ms'], '$.recheck_after_ms')
        if obj['recheck_after_ms'] < obj['observed_at_ms']:
            fail('$.recheck_after_ms: cannot be before observed_at_ms')
    require_non_implications(obj['non_implications'], REPLAY_NON_IMPLICATIONS, '$.non_implications')
    return obj


def issuer(kind: str = 'steward', ident: str = 'steward.core') -> dict[str, Any]:
    return {'kind': kind, 'id': ident}


def receipt_digest(label: str) -> str:
    return digest({'receipt': label, 'cid': 'demo.web', 'result': 'bounded'})


def base_chain(*, witness_id: str = 'wit_3000000000000001', chain_id: str = 'rch_aaaaaaaaaaaaaaaa', ordinal: int = 0, prev: str = 'genesis', rd: str | None = None, receipt_kind: str = 'ST-OPRECEIPT', emitted: int = 1000, state: str | None = None) -> dict[str, Any]:
    obj = {
        'schema': 'ST-RECEIPTCHAIN v0',
        'witness_id': witness_id,
        'chain_id': chain_id,
        'cid': 'demo.web',
        'issuer': issuer(),
        'chain_state': state or ('genesis' if ordinal == 0 else 'append'),
        'ordinal': ordinal,
        'previous_link_digest': prev,
        'receipt_digest': rd or receipt_digest('op.receipt.1'),
        'receipt_kind': receipt_kind,
        'emitted_at_ms': emitted,
        'observed_at_ms': emitted + 5,
        'basis_refs': ['oprec_aaaaaaaaaaaaaaaa'],
        'non_implications': sorted(CHAIN_NON_IMPLICATIONS),
    }
    obj['head_digest'] = digest(chain_material(obj))
    return obj


def base_redaction(*, witness_id: str = 'wit_3000000000000002', redaction_id: str = 'red_aaaaaaaaaaaaaaaa', source_digest: str | None = None, profile: str = 'minimal_handoff') -> dict[str, Any]:
    obj = {
        'schema': 'ST-REDACTION v0',
        'witness_id': witness_id,
        'redaction_id': redaction_id,
        'cid': 'demo.web',
        'issuer': issuer('exporter', 'steward.export'),
        'profile': profile,
        'source_digest': source_digest or receipt_digest('op.receipt.1'),
        'retained_fields': ['basis_refs', 'cid', 'observed_at_ms', 'schema', 'witness_id'],
        'stripped_classes': ['bearer_material', 'host_path', 'raw_endpoint', 'token_value'],
        'observed_at_ms': 1020,
        'basis_refs': ['policy.minimize.lifecycle'],
        'non_implications': sorted(RED_NON_IMPLICATIONS),
    }
    obj['commitment_digest'] = digest(redaction_material(obj))
    return obj


def base_export(*, witness_id: str = 'wit_3000000000000003', export_id: str = 'exp_aaaaaaaaaaaaaaaa', chain_head: str | None = None, included: list[str] | None = None, redaction: dict[str, Any] | None = None) -> dict[str, Any]:
    red = redaction or base_redaction()
    obj = {
        'schema': 'ST-EXPORTBUNDLE v0',
        'witness_id': witness_id,
        'export_id': export_id,
        'cid': 'demo.web',
        'issuer': issuer('exporter', 'steward.export'),
        'export_scope': 'handoff',
        'audience_class': 'sibling_cube',
        'chain_head_digest': chain_head or base_chain()['head_digest'],
        'included_receipt_digests': sorted(included or [receipt_digest('op.receipt.1')]),
        'redaction_ref': red['redaction_id'],
        'redaction_digest': digest(red),
        'observed_at_ms': 1030,
        'basis_refs': [red['redaction_id'], 'rch_aaaaaaaaaaaaaaaa'],
        'non_implications': sorted(EXPORT_NON_IMPLICATIONS),
    }
    obj['export_manifest_digest'] = digest(export_material(obj))
    return obj


def base_replay(*, witness_id: str = 'wit_3000000000000004', replay_id: str = 'rpl_aaaaaaaaaaaaaaaa', export: dict[str, Any] | None = None, verified: list[str] | None = None, status: str = 'verified', gap_state: str = 'none') -> dict[str, Any]:
    exp = export or base_export()
    obj = {
        'schema': 'ST-REPLAYOBS v0',
        'witness_id': witness_id,
        'replay_id': replay_id,
        'cid': 'demo.web',
        'issuer': issuer('verifier', 'steward.import'),
        'source_export_ref': exp['export_id'],
        'source_export_digest': digest(exp),
        'replay_context': 'handoff_import',
        'verification_status': status,
        'verified_receipt_digests': verified if verified is not None else list(exp['included_receipt_digests']),
        'gap_state': gap_state,
        'observed_at_ms': 1040,
        'basis_refs': [exp['export_id']],
        'non_implications': sorted(REPLAY_NON_IMPLICATIONS),
    }
    if status != 'verified' or gap_state != 'none':
        obj['gap_reason'] = 'Replay cannot prove complete continuity'
    return obj


def schema_case(case_id: str, object_kind: str, obj: Any, expect: str, note: str, *, json_text: str | None = None) -> dict[str, Any]:
    case = {'case_id': case_id, 'kind': 'schema', 'object_kind': object_kind, 'expect': expect, 'note': note}
    if json_text is not None:
        case['json_text'] = json_text
    else:
        case['json'] = obj
        if expect == 'accept':
            case['expected_digest'] = digest(obj)
    return case


def transport_case(case_id: str, events: list[dict[str, Any]], expect: str, note: str) -> dict[str, Any]:
    return {'case_id': case_id, 'kind': 'transport', 'expect': expect, 'note': note, 'events': events}


def build_cases() -> list[dict[str, Any]]:
    rd1 = receipt_digest('op.receipt.1')
    rd2 = receipt_digest('effect.receipt.2')
    c0 = base_chain(rd=rd1)
    c1 = base_chain(witness_id='wit_3000000000000005', ordinal=1, prev=c0['head_digest'], rd=rd2, receipt_kind='ST-EFFECT', emitted=1010)
    red = base_redaction(source_digest=rd1)
    exp = base_export(chain_head=c1['head_digest'], included=[rd1, rd2], redaction=red)
    rpl = base_replay(export=exp, verified=[rd1, rd2])

    bad_chain_unknown = {**c0, 'claims_authority': True}
    bad_red = {**red, 'stripped_classes': ['host_path', 'raw_endpoint']}
    bad_export = {**exp, 'included_receipt_digests': list(reversed(exp['included_receipt_digests']))}
    bad_replay = {**rpl, 'claims_current': True}

    cases: list[dict[str, Any]] = [
        schema_case('receiptchain.accept.genesis', 'ST-RECEIPTCHAIN', c0, 'accept', 'receipt chain genesis packets are closed and digestable'),
        schema_case('receiptchain.reject.authority-claim', 'ST-RECEIPTCHAIN', bad_chain_unknown, 'reject', 'receipt chain packets do not carry authority claims'),
        schema_case('receiptchain.reject.duplicate-key', 'ST-RECEIPTCHAIN', None, 'reject', 'duplicate JSON keys reject before semantic validation', json_text='{"schema":"ST-RECEIPTCHAIN v0","schema":"ST-RECEIPTCHAIN v0","witness_id":"wit_3000000000000099","chain_id":"rch_aaaaaaaaaaaaaaaa","cid":"demo.web","issuer":{"kind":"steward","id":"steward.core"},"chain_state":"genesis","ordinal":0,"previous_link_digest":"genesis","receipt_digest":"' + rd1 + '","receipt_kind":"ST-OPRECEIPT","emitted_at_ms":1000,"observed_at_ms":1005,"basis_refs":[],"non_implications":["not-authority","not-current-state","not-effect-success","not-complete-history"],"head_digest":"' + c0['head_digest'] + '"}'),
        schema_case('redaction.accept.minimal', 'ST-REDACTION', red, 'accept', 'redaction packets commit to retained fields and stripped classes'),
        schema_case('redaction.reject-no-secret-strip-class', 'ST-REDACTION', bad_red, 'reject', 'redaction must explicitly cover bearer/token/secret stripping'),
        schema_case('exportbundle.accept.handoff', 'ST-EXPORTBUNDLE', exp, 'accept', 'export bundles bind chain head, included receipts, and redaction digest'),
        schema_case('exportbundle.reject-unsorted-digests', 'ST-EXPORTBUNDLE', bad_export, 'reject', 'export included receipt digests must be canonical sorted'),
        schema_case('replayobs.accept.verified', 'ST-REPLAYOBS', rpl, 'accept', 'verified replay observes exported digests without restoring authority'),
        schema_case('replayobs.reject-currentness-claim', 'ST-REPLAYOBS', bad_replay, 'reject', 'replay observations cannot claim present currentness'),

        transport_case('transport.accept.chain-redact-export-replay', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'redaction', 'packet': red},
            {'event': 'export', 'packet': exp},
            {'event': 'replay', 'packet': rpl},
        ], 'accept', 'receipt chain, redaction, export, and replay can bind by digest without strengthening truth'),
        transport_case('transport.reject-chain-gap-without-reason', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': {**base_chain(witness_id='wit_3000000000000006', ordinal=2, prev=c0['head_digest'], rd=rd2, receipt_kind='ST-EFFECT', emitted=1010), 'chain_state': 'gap'}},
        ], 'reject', 'chain gaps require downgrade reason and cannot skip ordinal silently'),
        transport_case('transport.reject-previous-head-mismatch', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': base_chain(witness_id='wit_3000000000000007', ordinal=1, prev=receipt_digest('wrong.previous'), rd=rd2, receipt_kind='ST-EFFECT', emitted=1010)},
        ], 'reject', 'append must bind to the previous chain head'),
        transport_case('transport.reject-export-without-redaction', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'export', 'packet': exp},
        ], 'reject', 'exports need a known redaction packet'),
        transport_case('transport.reject-redaction-digest-mismatch', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'redaction', 'packet': red},
            {'event': 'export', 'packet': {**exp, 'redaction_digest': receipt_digest('not.redaction')}},
        ], 'reject', 'export redaction digest must match the referenced redaction packet'),
        transport_case('transport.reject-export-as-authority', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'redaction', 'packet': red},
            {'event': 'export', 'packet': exp, 'claims_authority': True},
        ], 'reject', 'export logs are evidence, not authority grants'),
        transport_case('transport.reject-replay-export-digest-mismatch', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'redaction', 'packet': red},
            {'event': 'export', 'packet': exp},
            {'event': 'replay', 'packet': {**rpl, 'source_export_digest': receipt_digest('wrong.export')}},
        ], 'reject', 'replay observation must bind to the exact exported bundle digest'),
        transport_case('transport.reject-verified-replay-missing-receipt', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'redaction', 'packet': red},
            {'event': 'export', 'packet': exp},
            {'event': 'replay', 'packet': base_replay(export=exp, verified=[rd1])},
        ], 'reject', 'verified replay must account for all exported receipt digests'),
        transport_case('transport.accept-partial-replay-downgrade', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': c1},
            {'event': 'redaction', 'packet': red},
            {'event': 'export', 'packet': exp},
            {'event': 'replay', 'packet': base_replay(export=exp, verified=[rd1], status='partial', gap_state='missing_receipts')},
        ], 'accept', 'partial replay is allowed only as downgraded observation with gap reason'),
        transport_case('transport.reject-chain-id-reuse-different-digest', [
            {'event': 'chain', 'packet': c0},
            {'event': 'chain', 'packet': {**c0, 'receipt_digest': rd2}},
        ], 'reject', 'same chain id and ordinal cannot name different canonical bytes'),
    ]
    return cases


def render_cases(cases: list[dict[str, Any]]) -> str:
    return ''.join(json.dumps(case, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n' for case in cases)


def load_corpus(path: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for lineno, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            out.append(parse_json_text(line))
        except Exception as exc:
            raise SystemExit(f'{path}:{lineno}: cannot parse JSONL: {exc}') from exc
    return out


def validate_schema_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        obj = parse_json_text(case['json_text']) if 'json_text' in case else case['json']
        kind = case['object_kind']
        if kind == 'ST-RECEIPTCHAIN':
            validate_receipt_chain(obj)
        elif kind == 'ST-REDACTION':
            validate_redaction(obj)
        elif kind == 'ST-EXPORTBUNDLE':
            validate_export_bundle(obj)
        elif kind == 'ST-REPLAYOBS':
            validate_replay_observation(obj)
        else:
            fail('unknown object_kind')
        if case['expect'] == 'accept':
            got = digest(obj)
            if got != case.get('expected_digest'):
                fail(f'digest mismatch: got {got}')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def event_claim_check(ev: dict[str, Any], where: str) -> None:
    forbidden_claims = sorted(k for k in ev if k.startswith('claims_') and ev[k])
    if forbidden_claims:
        fail(f'{where}: forbidden event claim(s) {forbidden_claims}')


def validate_transport_case(case: dict[str, Any]) -> tuple[bool, str]:
    try:
        redactions: dict[str, dict[str, Any]] = {}
        exports: dict[str, dict[str, Any]] = {}
        chains_last: dict[str, tuple[int, str]] = {}
        chain_ordinals: dict[tuple[str, int], str] = {}
        receipt_digests: set[str] = set()

        for idx, ev in enumerate(case['events']):
            kind = ev.get('event')
            where = f"{case['case_id']} event {idx} ({kind})"
            event_claim_check(ev, where)
            packet = ev.get('packet')
            if kind == 'chain':
                ch = validate_receipt_chain(packet)
                key = (ch['chain_id'], ch['ordinal'])
                ch_digest = digest(ch)
                old = chain_ordinals.get(key)
                if old is not None and old != ch_digest:
                    fail(f'{where}: chain id/ordinal reused for different canonical packet')
                chain_ordinals[key] = ch_digest
                if ch['ordinal'] == 0:
                    if ch['previous_link_digest'] != 'genesis' or ch['chain_state'] != 'genesis':
                        fail(f'{where}: ordinal zero must be genesis')
                else:
                    last = chains_last.get(ch['chain_id'])
                    if last is None:
                        fail(f'{where}: append without prior chain head')
                    last_ord, last_head = last
                    if ch['ordinal'] != last_ord + 1:
                        fail(f'{where}: chain ordinal gap')
                    if ch['previous_link_digest'] != last_head:
                        fail(f'{where}: previous link digest mismatch')
                chains_last[ch['chain_id']] = (ch['ordinal'], ch['head_digest'])
                receipt_digests.add(ch['receipt_digest'])
            elif kind == 'redaction':
                red = validate_redaction(packet)
                redactions[red['redaction_id']] = red
            elif kind == 'export':
                ex = validate_export_bundle(packet)
                if ex['redaction_ref'] not in redactions:
                    fail(f'{where}: export cites unknown redaction')
                red = redactions[ex['redaction_ref']]
                if ex['redaction_digest'] != digest(red):
                    fail(f'{where}: redaction digest mismatch')
                if ex['chain_head_digest'] not in {head for _ord, head in chains_last.values()}:
                    fail(f'{where}: export cites unknown chain head')
                missing = sorted(set(ex['included_receipt_digests']) - receipt_digests)
                if missing:
                    fail(f'{where}: export includes unknown receipt digest(s) {missing}')
                exports[ex['export_id']] = ex
            elif kind == 'replay':
                rp = validate_replay_observation(packet)
                if rp['source_export_ref'] not in exports:
                    fail(f'{where}: replay cites unknown export')
                ex = exports[rp['source_export_ref']]
                if rp['source_export_digest'] != digest(ex):
                    fail(f'{where}: export digest mismatch')
                if rp['verification_status'] == 'verified':
                    if set(rp['verified_receipt_digests']) != set(ex['included_receipt_digests']):
                        fail(f'{where}: verified replay digest set does not match export')
            else:
                fail(f'{where}: unknown event kind')
        return True, 'accepted'
    except Exception as exc:
        return False, str(exc)


def check_cases(cases: list[dict[str, Any]]) -> None:
    seen: set[str] = set()
    failures: list[str] = []
    for case in cases:
        cid = case.get('case_id')
        if not isinstance(cid, str) or not cid:
            failures.append('case without valid case_id')
            continue
        if cid in seen:
            failures.append(f'{cid}: duplicate case_id')
            continue
        seen.add(cid)
        if case.get('kind') == 'schema':
            accepted, detail = validate_schema_case(case)
        elif case.get('kind') == 'transport':
            accepted, detail = validate_transport_case(case)
        else:
            failures.append(f'{cid}: unknown case kind')
            continue
        expect_accept = case.get('expect') == 'accept'
        if accepted != expect_accept:
            failures.append(f"{cid}: expected {case.get('expect')} but got {'accept' if accepted else 'reject'}: {detail}")
    if failures:
        raise SystemExit('[steward-receipt-transport-corpus] FAIL\n' + '\n'.join(failures))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true', help='write deterministic corpus')
    ap.add_argument('--check', action='store_true', help='check corpus and deterministic rendering')
    ap.add_argument('--path', default=str(CORPUS_PATH))
    args = ap.parse_args()
    path = Path(args.path)
    expected = render_cases(build_cases())
    if args.write:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(expected, encoding='utf-8')
        print(path)
    if args.check:
        if not path.exists():
            raise SystemExit(f'missing corpus: {path}')
        actual = path.read_text(encoding='utf-8')
        if actual != expected:
            raise SystemExit('[steward-receipt-transport-corpus] FAIL: corpus is stale; run tools/steward_receipt_transport_harness.py --write')
        check_cases(load_corpus(path))
        print('[steward-receipt-transport-corpus] OK')
    if not args.write and not args.check:
        ap.error('choose --write and/or --check')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
