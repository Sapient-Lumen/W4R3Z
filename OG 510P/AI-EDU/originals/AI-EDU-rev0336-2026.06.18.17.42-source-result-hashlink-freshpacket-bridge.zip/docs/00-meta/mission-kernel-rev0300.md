# rev0300 mission kernel

The mission remains unchanged: keep the AI-EDU cube answerable to real learning,
agency, access, teacher capacity, source truth, and public-claim humility after
AI becomes ordinary education infrastructure.

The live risk remains `FT-0181`: local tooling can make the archive feel active
while no real owner evidence has been accepted. `rev0300` therefore avoids a new
registry family and shortens one late execution seam after a human terminal
live-window card.

## Current field rail

```text
owner-field-work
→ owner-after-human-send after real human send
→ owner-returned-reply-work when a real CSV returns
→ owner-workbench-review-brief
→ owner-workbench-review by a human
→ owner-first-packet-decision-brief
→ owner-first-packet-decision by a human
→ owner-post-decision-change-ticket-brief
→ owner-post-decision-change-ticket by a human
→ owner-activation-live-window-brief
→ activation receipt only from the same real SRC2+ packet, or live-window card only from active_change
→ owner-live-window-terminal-brief after staged/active card
→ owner-live-window-readout-brief after terminal card
```

`owner-field-work` may now prepare safe local bridges only: first-contact packet,
workbench review brief, first-packet decision brief, post-decision change-ticket
brief, activation/live-window entry brief, live-window terminal-state brief, or
terminal readout brief. It cannot record a send, route block, contact clock,
returned CSV intake, human review, board decision, change ticket, activation
receipt, live-window card, terminal card, readout, post-readout dispatch,
custody, acceptance, public support, lifecycle movement, or closure.

## Mission heart

Make the smallest real next field action easier than writing another doctrine
surface. The next archive operator should see the command to run, the boundary it
cannot cross, and the missing human-owned action.
