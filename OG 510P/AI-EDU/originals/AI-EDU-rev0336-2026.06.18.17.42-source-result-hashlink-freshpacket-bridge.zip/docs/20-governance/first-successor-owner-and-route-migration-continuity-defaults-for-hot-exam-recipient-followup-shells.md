# First successor-owner and route-migration continuity defaults for hot-exam recipient followup shells

The archive can now publish one still smaller layer for the hottest exam-like learner-request
routes.

It can already say:

- when a de-watched shell relapses and when minimized repair memory may be recalled;
- when a relapse should be classified as fresh case, repeat pattern, split-surface shell, or
  redesign failure;
- what current proof is needed before a redesigned route exits probation; and
- how old redesign-failure proof minimizes once current trust has returned.

That is still not enough.

A redesigned workflow can later change hands. A local owner may retire a route and move it into a
campus web platform. A content office may split source-page ownership from accessibility support. A
provider may replace a temporary search block with a different permanent-removal path. A recipient
or official-record office may migrate its intake portal. A search route may remain exact-URL based
even after a source URL, canonical, redirect, CMS, image host, or property owner changes. An archive
or mirror route may require a different control-period showing after site ownership moves. Or a
campus may honestly name a successor owner but quietly carry over old proof, old deadlines, or old
stigma without saying what is current.

This document adds one thing only:

- a **tiny successor-owner / route-migration continuity field set** for hot-exam recipient followup
  shells after redesign proof and any post-redesign probation have exited or handed back, but the
  repaired workflow is later transferred, decommissioned, replaced, merged, or split across owners.

That means the archive now asks a different question than before. It no longer asks only **what
proof closes redesign and exits probation**. It now asks **what proof, owner truth, learner action,
clock status, and minimized redesign memory may travel when the route itself moves — without
pretending proof automatically carries over, without pretending migration erases prior repair
history, and without keeping an owner-transition dossier learner-facing forever**.

Current official signals support a deliberately narrow answer. Google Search Console's Removals tool
is property-owner, URL, status, history-window, and temporary-block based; the tool says it removes
content only from Google Search, not from the internet or other search engines, and it requires
source-side permanent methods for durable removal. Google's Refresh Outdated Content route is for
non-owners, exact page or image URLs, request queues, status checks, and changed/gone content rather
than all-owner migration. Google personal-content routes may require URLs, screenshots, status
review, and source-site contact, while still warning that Search removal does not remove the source
page. Princeton separates local deletion, document/media cleanup, cache layers, Google/Bing search
behavior, custom-search exclusion, and Wayback persistence. WiscWeb separates WiscWeb-hosted edits
from campus search, directory, lookahead, Google/Bing, normal-hours support, and referral to the
right host when WiscWeb is not the owner. Rowan exposes Web Services, Cascade CMS, Siteimprove
monitoring, contributor training, accessibility support, content-audit/redesign review, and Web
Ambassador resolution as different ownership and support surfaces. Internet Archive requires URL,
time period, control period, and review context before excluding material, and gives no guaranteed
outcome beforehand. Bing exposes temporary block / up-to-90-day boundaries and source-side
permanent-removal methods such as 404/410 or noindex. Together those signals support a tighter
archive rule: **the next truthful portability gain here is one tiny migration-continuity layer for
successor owner, migrated route, transferred proof, learner action-now truth, and memory
minimization — but not one automatic proof carryover rule, no-memory migration fiction, permanent
owner-transition dossier, or all-surface successor certificate.** See `B255`.

## Small field set for successor-owner and route-migration continuity

| Code | Meaning | Default archive action |
|---|---|---|
| `YM0-NO-AUTOMATIC-PROOF-CARRYOVER-NO-MEMORY-MIGRATION-FICTION-OR-PERMANENT-TRANSITION-DOSSIER` | route migration can preserve live continuity, but it does not automatically transfer every proof item, erase prior redesign memory, or keep a public transition file open forever | require a current migration event, affected surface, successor owner, transferred-proof basis, and live learner dependency before migration changes the learner-facing shell |
| `YM1-PUBLISH-MIGRATION-EVENT-SURFACE-SCOPE-AND-SUCCESSOR-OWNER` | a migrated route must say what moved and who now owns it | publish whether the event is same-owner renaming, successor local owner, campus-platform merge, provider-route replacement, decommissioned route, recipient-record migration, archive/mirror handoff, split-owner migration, or no visible successor |
| `YM2-PUBLISH-TRANSFERRED-PROOF-BASIS-AND-REPROOF-NEEDS` | proof may travel only as scoped continuity, not as a universal repair certificate | publish what proof is current, what is historical only, what must be reproved because URL/property/owner/recipient/time-slice/prerequisite changed, and what is sealed or local-only |
| `YM3-PUBLISH-LEARNER-ACTION-NOW-AND-CLOCK-CONTINUITY` | migration must not create surprise learner duties or retroactive adverse clocks | publish whether learner action is none, confirm-only, refile-on-new-route, submit-new-proof, wait for successor owner, contact recipient, or local support; publish whether any clock is paused, preserved, restarted prospectively, route-native, expired, or not portable |
| `YM4-PUBLISH-MIGRATION-EXIT-MINIMIZATION-AND-REOPEN-TRIGGERS` | once the successor route is ordinary or closed, transition proof should minimize to the narrowest truthful state | publish ordinary handback, split-surface shell, no-active-route residue, sealed local memory, recipient/record hold, or reopen only on material new proof, owner change, route expiry, reappearance, or successor-route denial |

## Field values that now travel together

When this layer is used, the shell should publish only six concrete fields:

1. `migration_event_token` — `same owner rename`, `successor local owner`, `campus platform merge`,
   `provider route replacement`, `provider route decommissioned`, `recipient record route migrated`,
   `archive mirror route migrated`, `source url canonical redirect or cms migration`, `split owner
   migration`, `no visible successor`, `none inherited`, or `not published`;
2. `successor_owner_token` — `same owner`, `named successor owner`, `campus web owner`,
   `accessibility owner`, `recipient owner`, `provider or platform owner`, `archive or mirror route
   owner`, `split owners named`, `no active owner`, `owner not visible`, `none inherited`, or `not
   published`;
3. `transferred_proof_token` — `current proof carries scoped`, `current proof carries affected
   surface only`, `historical proof local only`, `sealed privacy proof local only`, `recipient proof
   carries only to recipient dependency`, `source proof requires recrawl or refresh`, `url property
   or control changed reproof needed`, `time slice or archive control reproof needed`, `proof
   expired or unavailable`, `none inherited`, or `not published`;
4. `migration_action_now_token` — `no learner action`, `learner confirm only`, `successor owner
   action`, `refile on migrated route`, `submit new route proof`, `recipient confirmation needed`,
   `wait route-native status`, `local support handoff`, `no active route action`, `none inherited`,
   or `not published`;
5. `migration_clock_token` — `no clock`, `clock preserved`, `clock paused during migration`, `clock
   restarted prospectively after notice`, `route-native window applies`, `provider expiry applies`,
   `recipient window applies`, `clock expired before migration`, `clock not portable`, `none
   inherited`, or `not published`;
6. `migration_exit_memory_token` — `ordinary handback`, `minimized transition pointer`, `sealed
   local memory`, `recipient or record hold`, `split surface shell opened`, `no active route
   residue`, `successor route denied`, `reopen on owner change or route expiry`, `reopen on material
   new proof`, `none inherited`, or `not published`.

That is deliberately small. It is enough to show what moved, who owns the successor route, what
proof remains current, what proof must be reproved, what the learner needs to do now, and when
migration memory exits learner-facing publication. It is not enough to create an automatic
proof-carryover rule, a no-memory migration fiction, a universal successor-owner packet, a public
transition dossier, or an all-surface successor certificate.

## First successor-owner / route-migration continuity assignments

| Route or family | Migration continuity truth now admitted | Why |
|---|---|---|
| Google Search Console temporary-removal route after property, CMS, canonical, redirect, or source-owner migration | `source url canonical redirect or cms migration` or `successor local owner`, `campus web owner` plus `provider or platform owner` where the Search Console route remains live, `source proof requires recrawl or refresh` or `url property or control changed reproof needed`, `successor owner action` or `refile on migrated route`, and `clock restarted prospectively after notice` only where a current route window is visible | temporary blocks are Google-Search-only, property/URL based, time limited, and need source-side permanent methods; migration should not convert an old temporary block into a new owner's durable repair certificate |
| Google Refresh Outdated Content route after the page URL, image host, result URL, or owner path changes | `provider route replacement` or `source url canonical redirect or cms migration`, `provider or platform owner`, `current proof carries affected surface only` or `url property or control changed reproof needed`, `refile on migrated route` if the visible result URL changed, and `route-native window applies` only to the current request | the route is non-owner, exact page/image/result-URL based, and may require separate image/container-page handling; migrated URLs or images need scoped reproof rather than automatic request inheritance |
| Google personal-content / Results-about-you style route after a privacy/safety route moves to a new form, status page, or source owner | `provider route replacement` or `split owner migration`, `provider or platform owner` plus source owner where visible, `sealed privacy proof local only`, `submit new route proof` only when the new route requires it, and `clock restarted prospectively after notice` | sensitive proof may be necessary for a new form or status route, but migration is not permission to republish old screenshots, contact details, or safety facts |
| campus source-page, media-library, CMS, custom-search, or access-control route after a platform merge | `campus platform merge` or `source url canonical redirect or cms migration`, `campus web owner` or `named successor owner`, `current proof carries scoped` for source state but `source proof requires recrawl or refresh` for external search, `successor owner action`, and `ordinary handback` after source and local-search proof settle | local owners can carry source-state proof through a platform migration, but external search, archive, social, and recipient surfaces remain separate proof objects |
| WiscWeb-style emergency edit after ownership moves outside WiscWeb or to a new primary contact | `successor local owner` or `no visible successor`, `named successor owner` or `owner not visible`, `historical proof local only`, `local support handoff` or `no active route action`, and `no active route residue` if the host or owner cannot be named | WiscWeb can assist WiscWeb sites and help redirect to the right host, but it does not control campus directory/search or major search engines and cannot remain the public owner when the site is outside its service |
| Rowan-style Web Services / Cascade / Siteimprove / accessibility support after a content-audit or redesign handoff | `successor local owner`, `campus platform merge`, or `split owner migration`, `campus web owner` plus `accessibility owner` or Web Ambassador where visible, `current proof carries scoped` for accessibility/QA monitoring and `historical proof local only` for old redesign failure, `successor owner action`, and `minimized transition pointer` | Rowan separates web maintenance, contributor support, accessibility monitoring, training, content audit/redesign, and local Web Ambassador resolution; migration should name the current support owner without keeping old failure proof public |
| recipient confirmation, score-report, transcript, or official-record route after a recipient portal or record owner migration | `recipient record route migrated`, `recipient owner` or `split owners named`, `recipient proof carries only to recipient dependency`, `recipient confirmation needed` or `successor owner action`, `recipient window applies`, and `recipient or record hold` until the current record dependency closes | downstream proof belongs to the current recipient or official-record dependency, not to all public search/source surfaces, and should not become an all-recipient certificate |
| Internet Archive / Wayback or mirror-copy route after site ownership, domain control, or time-slice scope changes | `archive mirror route migrated`, `archive or mirror route owner`, `time slice or archive control reproof needed`, `submit new route proof` or `no active route action`, and `split surface shell opened` or `no active route residue` | archive exclusion requests are URL/time/control-period and review-context specific; a new owner or domain-control period may require new proof and does not certify all captures |
| Bing temporary block or permanent-removal route after provider route, source URL, or ownership migration | `provider route replacement` or `source url canonical redirect or cms migration`, `provider or platform owner` plus source owner where visible, `source proof requires recrawl or refresh` or `url property or control changed reproof needed`, `refile on migrated route`, and `provider expiry applies` | Bing temporary block and permanent-removal guidance distinguish temporary hiding from source-side 404/410/noindex; migration should not treat a 90-day block as durable successor proof |
| decommissioned provider, retired campus form, or unsupported old route after redesign probation exit | `provider route decommissioned` or `no visible successor`, `no active owner` or `owner not visible`, `proof expired or unavailable`, `no active route action`, `clock not portable`, and `no active route residue` | if no current route or owner exists, the shell should preserve as-of truth without pretending either successor proof or learner abandonment |
| split source/search/recipient/archive route after a successor owner takes only one part | `split owner migration`, `split owners named`, `current proof carries affected surface only`, `successor owner action` for the owned surface and `refile on migrated route` or `recipient confirmation needed` elsewhere, and `split surface shell opened` | migration often moves one surface but not all; the truthful shell splits instead of giving one successor owner control over source, search, archive, recipient, and official-record truth |

## Boundary conditions

This layer should not be used when only one of the following is true:

- a new owner is rumored but no current owner, route, or action path is visible;
- the old proof belongs to a different URL, image, recipient, archive time slice, source owner,
  platform property, or learner-facing dependency;
- the migration is only a branding rename with no change in owner, route, proof, clock, or learner
  action;
- the only remaining fact is an expired request-history row, old screenshot, old ticket, or old
  support email with no live dependency;
- sensitive or safety proof can be retained locally without learner-facing publication; or
- the migration is inside a legal, records, provider, or appeal process whose proof should not
  become a portable public field.

In those cases, publish `owner not visible`, `proof expired or unavailable`, `historical proof local
only`, `sealed privacy proof local only`, `clock not portable`, `no active route residue`, or `none
inherited` rather than pretending migration either carries everything forward or wipes the slate
clean.

## What this closes

This closes `FT-0141`.

The archive no longer stops at "redesign probation exited". It can now publish a minimal
migration-continuity shell: what moved, who owns the successor route, what proof carries, what must
be reproved, what action or clock is live now, and how transition memory minimizes.

It also opens one narrower seam.

After migration continuity is published, the archive may still need a tiny post-migration drift /
successor-owner proof-refresh layer for cases where the successor owner later goes silent, the
migrated route changes prerequisites, transferred proof expires, a redirected URL or recipient
portal drifts, or a split-owner shell needs refresh without turning migration into perpetual
surveillance or no-memory abandonment.
