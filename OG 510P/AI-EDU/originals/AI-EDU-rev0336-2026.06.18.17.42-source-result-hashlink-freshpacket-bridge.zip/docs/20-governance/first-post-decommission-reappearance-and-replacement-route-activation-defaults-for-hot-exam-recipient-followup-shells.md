# First post-decommission reappearance and replacement-route activation defaults for hot-exam recipient followup shells

The archive can now publish one still smaller operating layer for the hottest exam-like
learner-request routes.

It can already say:

- when a migrated successor route later drifts and needs proof refresh rather than automatic proof
  carryover;
- when repeated successor-route drift crosses a stability threshold;
- how an opened successor-route stability posture runs, proves repair, splits, decommissions,
  migrates, or exits; and
- how decommissioned-route residue or no-active-route residue can remain visible without becoming
  permanent migration surveillance.

That is still not enough.

After a successor-route stability posture exits, the most confusing facts often arrive late. A
retired provider path can reappear in search, a portal, a screenshot, an archive capture, or a
recipient workflow. A replacement route can fail its first visible cycle, change prerequisites, or
lose its named owner. A decommissioned path can receive new source-owner proof, redirect proof,
noindex proof, provider proof, or recipient proof. A no-active-route residue can suddenly expose a
current owner or action path. A temporary block or outdated-content request can expire and let the
old result become eligible again. A local source can stay corrected while an external search result,
image result, cache, custom search, archive time slice, mirror, or downstream record tells a
different story. A learner can also be told to refile into a replacement route even though the only
changed fact is owner-side route activation.

This document adds one thing only:

- a **tiny post-decommission reappearance / replacement-route activation field set** for hot-exam
  recipient followup shells after `YS0-YS4` has already exited a successor-route stability posture
  as ordinary successor status, replacement-route migration, decommissioned-route residue,
  no-active-route residue, split-surface operation, or minimized local memory.

That means the archive now asks a different question than before. It no longer asks only **how a
threshold-opened successor-route stability posture operates or exits**. It now asks **what happens
after that exit if the old route reappears, the replacement route fails, decommissioned residue
gains current proof, or no-active-route residue exposes a current path — without treating
decommission as permanent failure, replacement as total fresh-start amnesia, route revival as an
automatic all-surface reopen, or old proof as a public transition dossier**.

Current official signals support a deliberately narrow answer. Google Search Console's Removals tool
remains property-owner, exact-URL, current/expired-history, cancellation, temporary-removal, and
source-side permanent-method based; it also says temporary removals can expire and pages can become
eligible to appear again unless permanent site-side action is taken. Google's Refresh Outdated
Content route is exact page/image URL, changed/gone-content, queue/status, and 180-day expiry based;
it does not remove unchanged live pages and does not create a global source-side disappearance
certificate. Google's owner-facing removal guidance separates temporary Search removal from
source-side removal, login protection, noindex, or other permanent methods. WiscWeb separates
source-site decommissioning, primary-contact follow-up, campus search/lookahead/directory handling,
normal-hours constraints, and major-search-engine non-control. Princeton separates local content
deletion, document/media cleanup, cache, Google/Bing/custom-search exclusion, access control, and
Wayback persistence. Rowan separates Cascade CMS, Web Services support, Siteimprove/accessibility
monitoring, content-audit/redesign work, contributor responsibility, and accommodation routes rather
than one central route-activation desk. Internet Archive requires URL, time-period, control-period,
and review context before exclusion and gives no guaranteed outcome before review. Bing
distinguishes temporary blocks, 90-day expiry, cached/outdated-content handling, extension or
permanent-removal prerequisites, and source-side methods such as 404/410 or noindex. Together those
signals support a tighter archive rule: **the next truthful portability gain here is one tiny
post-decommission / replacement-activation layer for trigger, affected surface, current owner/proof,
learner action-now, clock continuity, disposition, minimization, and reopen triggers — but not one
permanent decommission-failure label, replacement-route fresh-start fiction, all-surface revival
certificate, public old-proof dossier, or automatic learner refile rule.** See `B259`.

## Small field set for post-decommission reappearance and replacement-route activation

| Code | Meaning | Default archive action |
|---|---|---|
| `YP0-NO-DECOMMISSION-PERMANENT-FAILURE-REPLACEMENT-AMNESIA-OR-AUTOMATIC-ALL-SURFACE-REOPEN` | a later post-exit fact does not make the old route permanently failed, the replacement route memoryless, or every surface reopened | keep the new fact tied to its named surface, owner, route, proof object, and learner dependency; do not widen it to every URL, archive, provider, recipient, or future copy |
| `YP1-PUBLISH-POST-DECOMMISSION-TRIGGER-AND-AFFECTED-SURFACE` | the shell must say what actually changed after decommission, replacement migration, or no-active-route residue | publish whether the trigger is old-route reappearance, temporary-block expiry, search/outdated-status expiry, replacement-route failure, replacement-owner change, new source proof, new provider proof, new recipient/record proof, archive capture, redirect/canonical drift, or no-active-route owner discovery |
| `YP2-PUBLISH-ACTIVATION-OWNER-ROUTE-AND-PROOF-BASIS` | activation needs current proof from the owner or route that can actually carry the next action | label the proof as old-owner revival, replacement-owner current proof, provider-route proof, source/CMS proof, redirect/canonical/noindex proof, search-provider state, archive/platform review, recipient confirmation, official-record correction, accessibility/remediation proof, decommission notice superseded, or no-active-route owner proof |
| `YP3-PUBLISH-LEARNER-ACTION-CLOCK-AND-MEMORY-CONTINUITY` | the shell must say whether the learner has to act now, which clock applies, and what prior timely action still protects them | make action prospective and route-native; preserve prior timely filings, proof, and no-fault posture unless the current route itself lawfully requires a new learner act; do not treat owner activation work as learner abandonment |
| `YP4-PUBLISH-ACTIVATION-DISPOSITION-MINIMIZATION-AND-REOPEN-TRIGGERS` | the shell must exit, split, reactivate, stay residue, or reopen a stability posture with a visible minimization rule | publish revived-route active, replacement-route active, replacement failed and split, replacement migration reopened, successor-stability posture reopened, proof refresh opened, decommissioned-route residue retained, no-active-route residue retained, ordinary replacement restored, or minimized local memory with reopen only on material change |

## Field values that now travel together

When this layer is used, the shell should publish only six concrete fields:

1. `post_decommission_trigger_token` — `no post-decommission trigger`, `retired route reappeared`,
   `temporary block expired and result returned`, `outdated-content request expired`, `replacement
   route failed`, `replacement route changed owner`, `decommissioned path received owner proof`,
   `no-active-route residue exposed current path`, `old source page restored`, `old URL redirect or
   canonical changed`, `provider path revived`, `provider path formally retired`, `archive capture
   reappeared`, `recipient portal opened`, `recipient portal failed`, `official-record field
   resumed`, `unrelated copy only`, `none inherited`, or `not published`;
2. `activation_scope_token` — `old decommissioned path only`, `replacement route only`, `old and
   replacement route disagreement`, `one exact URL`, `one redirected or canonical family`, `one
   provider route`, `one recipient portal`, `one official-record field`, `one archive time slice`,
   `one image or snippet family`, `one local source or CMS workflow`, `one accessibility or QA
   workflow`, `no-active-route residue only`, `split-surface shell`, `none inherited`, or `not
   published`;
3. `activation_owner_proof_token` — `old owner revived and current`, `replacement owner current`,
   `successor owner still current`, `provider route proof current`, `source or CMS proof current`,
   `redirect canonical or noindex proof current`, `search-provider state proof current`, `archive or
   platform proof current`, `recipient confirmation proof current`, `official-record correction
   proof current`, `accessibility remediation proof current`, `decommission notice superseded`,
   `no-active-route now has owner`, `owner claim without proof`, `stale proof only`, `sensitive
   proof local-only`, `no proof yet`, `none inherited`, or `not published`;
4. `activation_learner_clock_token` — `no learner action now`, `information-only notice`, `wait for
   owner proof`, `learner may use replacement route`, `learner may use revived route`, `learner may
   choose replacement or revived route`, `learner should not refile into dead path`, `clock starts
   only after current notice`, `route-native window continues prospectively`, `prior timely action
   preserved`, `stale clock invalid`, `protected or accommodation route controls`, `manual local
   support only`, `none inherited`, or `not published`;
5. `activation_disposition_token` — `revived route active`, `replacement route active`, `replacement
   route failed and split`, `replacement proof refresh opened`, `successor stability posture
   reopened`, `route migration reopened`, `decommissioned-route residue retained`, `no-active-route
   residue retained`, `local-only redesign or redirection`, `ordinary replacement status restored`,
   `ordinary old-route status restored`, `minimized prior decommission memory`, `reopen only on
   material failure owner change revival or new proof`, `none inherited`, or `not published`;
6. `activation_memory_minimization_token` — `public pointer only`, `local proof retained`, `old
   proof sealed except named route need`, `prior timely action retained without public proof`, `old
   route failure label removed`, `replacement transition summary retained`, `decommission residue
   minimized`, `no-active-route residue minimized`, `split-surface note retained`, `delete public
   activation detail after closure`, `retain under records law only`, `protected route local-only`,
   `none inherited`, or `not published`.

## Starter defaults by route family

| Route family | Starter publication | Why |
|---|---|---|
| Google Search Console temporary removal or property-owner route after decommissioned URL reappears | `temporary block expired and result returned`, `one exact URL`, `search-provider state proof current`, `clock starts only after current notice`, and `replacement proof refresh opened` or `decommissioned-route residue retained` | the route is exact-URL, property, status, current/expired-history, temporary, and source-side permanent-method based; expiry can make a page eligible again without proving source repair failed everywhere |
| Google Refresh Outdated Content route after old snippet/image/page resurfaces | `outdated-content request expired`, `one image or snippet family` or `one exact URL`, `search-provider state proof current`, `prior timely action preserved`, and `replacement proof refresh opened` only for the affected result | the route is exact page/image URL, changed/gone-content, queue/status, and 180-day expiry based; additional URLs may need separate requests, but that does not reopen every source, archive, or recipient surface |
| owner-facing source-page removal / login / noindex / 404 / 410 route after old source proof changes | `old source page restored` or `old URL redirect or canonical changed`, `one local source or CMS workflow`, `source or CMS proof current` or `redirect canonical or noindex proof current`, `route-native window continues prospectively`, and `local-only redesign or redirection` | source-side permanence depends on the current page state, access state, noindex/canonical/redirect state, or removal status, not on a global search/cache/archive certificate |
| WiscWeb decommissioned site, campus search/lookahead, directory, or major-search-engine residue | `decommissioned path received owner proof`, `one local source or CMS workflow` plus possible campus-search split, `source or CMS proof current`, `learner should not refile into dead path`, and `no-active-route residue retained` or `replacement route active` | WiscWeb distinguishes hosted-source removal, primary-contact follow-up, decommissioning, campus search/lookahead/directory, normal-hours constraints, and no control over major search-engine timing/status |
| Rowan Cascade CMS / Web Services / Siteimprove / accessibility / content-redesign route after replacement support path changes | `replacement route changed owner` or `replacement route failed`, `one accessibility or QA workflow` or `one local source or CMS workflow`, `replacement owner current` plus `accessibility remediation proof current` or `source or CMS proof current`, and `replacement proof refresh opened` | Rowan routes separate contributor responsibility, CMS support, Web Services, accessibility monitoring, content audits/redesign, training, support requests, and accommodation routing; activation should name the exact owner now carrying the route |
| Princeton local deletion / cache / document media / Google / Bing / custom-search / Wayback split after a deleted page resurfaces | `old source page restored`, `archive capture reappeared`, or `temporary block expired and result returned`, `split-surface shell`, matching local/search/archive proof, and `prior timely action preserved` | Princeton separates local deletion, document/media cleanup, cache, access control, Google/Bing, custom search, and Wayback persistence; revival on one surface should not imply all-surface reopen |
| Bing temporary block, cached/outdated page, or permanent-removal preparation after replacement-route failure | `temporary block expired and result returned` or `replacement route failed`, `one provider route`, `provider route proof current` or `redirect canonical or noindex proof current`, `clock starts only after current notice`, and `replacement route active` or `replacement proof refresh opened` | Bing exposes temporary blocking, up-to-90-day expiry, cached/outdated handling, extensions, and source-side permanent methods; block expiry is a route-native signal, not a permanent route-failure label |
| Internet Archive / Wayback or mirror route after decommissioned residue gains a new capture or owner proof | `archive capture reappeared` or `decommissioned path received owner proof`, `one archive time slice`, `archive or platform proof current`, `information-only notice` or `manual local support only`, and `decommissioned-route residue retained` or `no-active-route residue retained` | archive review is URL/time/control-period specific and not guaranteed beforehand; reappearance should remain tied to the affected capture or time slice unless a current owner path exists |
| recipient confirmation, transcript, score-report, official-record, or downstream portal route after a replacement recipient path fails | `recipient portal failed` or `official-record field resumed`, `one recipient portal` or `one official-record field`, `recipient confirmation proof current` or `official-record correction proof current`, `prior timely action preserved`, and `replacement route failed and split` | the live dependency may be recipient-side even when public search/source/archive state is ordinary; activation should not reopen public proof unless that surface also changed |
| no-active-route residue later exposes a current owner, route, or protected local path | `no-active-route residue exposed current path`, `no-active-route residue only` or `split-surface shell`, `no-active-route now has owner`, `wait for owner proof` or `learner may use replacement route`, and `route migration reopened` or `successor stability posture reopened` | a newly visible owner or route can revive actionability only prospectively and only for the affected surface; it does not erase the earlier no-active-route truth or make prior learner silence fault |
| unrelated mirror, screenshot, stale ticket row, history-row expiry, or generic search lag after decommission exit | `unrelated copy only`, `split-surface shell` or `one image or snippet family`, `stale proof only`, `no learner action now`, and `minimized prior decommission memory` | old proof or ordinary lag should not reactivate a route unless a current owner, action path, proof object, recipient dependency, or route-native expiry makes the fact live |

## What this layer now makes portable

Hot-exam recipient followup shells may now publish one tiny `YP0-YP4` layer after `YS0-YS4` when the
archive needs to say not merely that **a successor-route stability posture exited**, but that **a
post-exit fact has appeared and either activates the old route, activates a replacement route,
reopens proof refresh, keeps decommission/no-active-route residue, or stays minimized**.

That means a shell may now truthfully say things like:

- `the old provider path reappeared in search after the temporary block expired; reopen only the
  affected provider/search proof, preserve prior timely action, and do not label the replacement
  route failed unless it also fails`;
- `the replacement route is current and named, so the old decommissioned path remains minimized
  residue; learner action is prospective on the replacement route only`;
- `no-active-route residue now has a current owner; reopen route migration or proof refresh from the
  current notice date, not retroactively from the abandoned-route date`;
- `a recipient portal failed while the source/search replacement stayed stable; split recipient
  action from public-source/search/archive proof`; or
- `a Wayback capture resurfaced after decommission; keep archive residue time-slice-specific and do
  not reopen the live replacement route without a current owner or learner dependency`.

It still may not pretend:

- that route decommission proves permanent route failure;
- that a replacement route begins with total amnesia about prior timely proof, no-fault status, or
  repair limits;
- that old-route reappearance automatically reopens every source, search, archive, recipient, and
  official-record surface;
- that a replacement-route owner can impose a retroactive clock before current notice;
- that unrelated mirrors, screenshots, or expired history rows prove current route activation;
- that sensitive learner proof should return to public view merely because a route revived;
- that no-active-route residue was false just because a later owner appeared; or
- that a learner must refile into a dead path to preserve rights that prior timely action already
  preserved.

## Why this matters for the larger archive

The archive's education-with-AI program is not only about forcing route owners to keep current proof
visible. It is also about preventing route mechanics from laundering blame onto learners when
official infrastructure moves.

This layer matters because decommission and replacement create two opposite fictions. One fiction
says a decommissioned route is permanently failed and every later reappearance proves broad owner
fault. The other fiction says a replacement route starts from zero and can ask the learner to prove
again what the old route already accepted or what the owner already failed to carry. Both are wrong.
The point here is narrower: publish **what post-exit trigger appeared**, **which surface it
affects**, **which owner/proof now exists**, **whether the learner actually has to act**, **which
clock is prospective**, **what prior timely action remains protected**, and **how the shell
minimizes or reopens only the affected path**. Everything else remains route-native casework,
local-only retention, privacy-aware minimization, ordinary search/cache lag, or no-active-route
residue.

## Boundary conditions

This layer should not be used when only one of the following is true:

- `YS0-YS4` has not exited a stability posture, so ordinary `YD0-YD4` proof refresh, `YR0-YR4`
  thresholding, or `YS0-YS4` stability operation is still enough;
- the replacement route is still inside its own published review, implementation, reflection,
  temporary-block, or owner-response window;
- the only signal is ordinary search/cache/crawl lag, status-history aging, or a screenshot with no
  current owner, action path, proof object, recipient dependency, or route-native expiry;
- the fact belongs only to a different URL, owner, route, learner, recipient, archive time slice,
  image family, platform, or official-record field and does not affect the published shell;
- a protected accommodation, privacy, safety, records, legal, provider, or appeal process already
  controls activation, proof, notice, or retention;
- the old route is still formally decommissioned and no current owner or replacement path exists, in
  which case publish decommissioned-route or no-active-route residue rather than activation; or
- a current route names a specific restart, reactivation, appeal, replacement, or expiry rule that
  should govern instead of a portable activation layer.

In those cases, publish `no post-decommission trigger`, `ordinary route-native window applies`,
`ordinary search or cache lag`, `unrelated copy only`, `protected local-only route`, `no active
route`, `decommissioned-route residue`, `no proof yet`, `fresh proof refresh required`, or `none
inherited` rather than treating every post-exit fact as all-surface revival, permanent decommission
failure, or learner fault.

## What this closes

This closes `FT-0145`.

The archive no longer stops at "successor-route stability operation exited". It can now publish a
minimal post-decommission / replacement-route activation layer: the trigger, affected surface,
current owner/proof basis, learner action-now truth, clock and prior-proof continuity, activation
disposition, minimization, and reopen triggers when a retired route reappears, a replacement route
fails, a decommissioned route gains proof, or no-active-route residue exposes a current path.

It also opens one narrower seam.

After a post-decommission or replacement-route activation layer has opened a revived route,
replacement route, proof refresh, split, or reopened stability posture, the archive may still need a
tiny first-cycle activation drift / route-choice conflict layer for cases where the revived old
route and replacement route disagree, the first replacement cycle drifts, or a learner is offered
two paths with different clocks — without making every activation a new standing watch, every
old-route revival a replacement failure, or every route-choice conflict learner fault.
