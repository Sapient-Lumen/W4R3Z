# First repeat activation-cycle conflict and route-stability-threshold defaults for hot-exam recipient followup shells

The archive can now publish one still smaller layer for the hottest exam-like learner-request
routes.

It can already say:

- when a successor route decommissions, activates a replacement, revives, or exposes a
  no-active-route current path;
- when the first activated cycle exposes disagreement among revived routes, replacement routes,
  source/search/archive surfaces, recipient portals, protected routes, proof objects, or clocks;
- which owner, precedence proof, learner-safe action, clock posture, and conflict disposition govern
  that first cycle; and
- how conflict memory minimizes after the first cycle resolves, splits, reopens proof refresh, or
  stays residue.

That is still not enough.

The same revived/replacement pair can disagree again after the first conflict was supposedly
resolved. A recipient portal can repeatedly accept the retired route even after the replacement
owner says the new path controls. A protected route can repeatedly diverge from the public route. A
source page, Google result, Bing result, image result, custom search result, archive capture,
provider form, official-record field, transcript queue, or score-report recipient can repeatedly
split after minimization. The same two clocks can recur. Or a route can look unstable only because
unrelated search/cache/archive lag is being counted as the same pattern.

This document adds one thing only:

- a **tiny repeat activation-cycle conflict / route-stability-threshold field set** for hot-exam
  recipient followup shells after `YC0-YC4` has already handled a first-cycle route-choice conflict,
  but the same route pair, owner split, proof object, clock, recipient portal, protected route, or
  surface keeps materially disagreeing.

That means the archive now asks a different question than before. It no longer asks only **what
should a learner do during the first activated conflict**. It now asks **when repeated route-choice
conflict after resolution, split, or minimization proves the route pair or affected surface is
unstable enough to open a named threshold — without making every first-cycle conflict a standing
watch, every repeated conflict learner fault, every old-route recurrence replacement failure, or
every route-pair history a permanent public instability label**.

Current official signals support a deliberately narrow answer. Google Search Console's Removals tool
is property-owner, exact-URL, current/expired-history, temporary-removal, cancellation, six-month,
Google-Search-only, and source-side-permanent-method based rather than a global route-stability
authority. Google's Refresh Outdated Content route is exact page/image URL, changed/gone-content,
queue/status, additional-URL, and 180-day-expiry based rather than an automatic all-recipient
precedence monitor. Google's personal-content and site-owner removal surfaces keep Search removal,
source-page removal, screenshot proof, notifications, new-result handling, and sensitive proof
separate. WiscWeb separates local WiscWeb source edits, emergency edits, primary-contact support,
redirection, caching, campus search/lookahead/directory behavior, and major-search-engine
non-control. Princeton separates local deletion, document/media cleanup, access control, cache
behavior, Google/Bing/custom-search exclusion, and Wayback persistence. Rowan separates CMS
ownership, Web Services support, Siteimprove/accessibility monitoring, contributor training,
content-audit/redesign work, support tickets, and accommodation routing. Internet Archive asks for
URL, time-period, control-period, and review context before exclusion. Bing distinguishes temporary
block, up-to-90-day expiry, cached/outdated-content handling, exact URL submission, extension or
permanent-removal prerequisites, and source-side methods such as 404/410 or noindex. Together those
signals support a tighter archive rule: **the next truthful portability gain here is one tiny
repeat-conflict threshold layer for pattern count, route-pair scope, threshold source, stability
owner, learner-safe action, disposition, minimization, and reopen triggers — but not one standing
activation watch for every first conflict, one repeated-conflict learner-fault rule, one public
route-pair stigma ledger, one all-surface replacement-failure label, or one no-memory reset.** See
`B261`.

## Small field set for repeat activation-cycle conflict and route-stability thresholds

| Code | Meaning | Default archive action |
|---|---|---|
| `YQ0-NO-AUTOMATIC-STANDING-ACTIVATION-WATCH-REPEATED-CONFLICT-FAULT-OR-ROUTE-PAIR-STIGMA` | repeated route-choice conflict can matter, but it is not automatically learner fault, replacement failure, permanent watch, or public route-pair stigma | require a material repeat pattern on the same route pair, surface, owner split, proof object, clock, protected path, recipient dependency, or archive/search family before widening beyond `YC0-YC4` first-cycle handling |
| `YQ1-PUBLISH-REPEAT-CONFLICT-COUNT-SCOPE-AND-MATERIALITY` | repeat conflict must be counted by affected route-choice scope rather than by anecdote or unrelated stale copies | publish whether the pattern is repeated revived-vs-replacement disagreement, repeated portal wrong-path acceptance, repeated protected-route conflict, repeated clock conflict, repeated prerequisite conflict, repeated source/search/archive split, repeated proof-object mismatch, repeated official-record mismatch, or ordinary lag only |
| `YQ2-PUBLISH-ROUTE-STABILITY-THRESHOLD-SOURCE-OWNER-AND-PROOF-LIMIT` | a route-stability threshold needs a named source and owner before conflict becomes watch, reconciliation, redesign, split, or decommission posture | publish the threshold basis, current controlling or unresolved owner, last conflict disposition, whether another first-cycle handling is still proportionate, and whether the owner must prove route stability, reconcile owners, redesign the path, split the shell, retire one path, or disclose no-active-route residue |
| `YQ3-SEPARATE-ROUTE-STABILITY-WORK-FROM-LEARNER-FAULT-AND-DUPLICATE-FILING` | repeated owner-side disagreement should not be charged to the learner without conflict-aware notice and a current route-native rule | publish learner action only when current proof requires it; otherwise publish wait, owner reconciliation, dual-route recognition, submit-once recognition, more-protective route, longer-window protection, protected local-only handling, or no learner action now |
| `YQ4-PUBLISH-THRESHOLD-DISPOSITION-MINIMIZATION-AND-REOPEN-TRIGGERS` | repeat-conflict thresholding can settle, split, open a bounded watch, or retire a route without keeping conflict proof public forever | publish ordinary activation restored, bounded route-stability watch opened, owner reconciliation opened, route redesign opened, route split retained, replacement route controls, revived route controls, protected local-only route controls, decommissioned-route residue, no-active-route residue, minimized conflict memory, or reopen only on material route, owner, proof, clock, recipient, protected-route, or surface facts |

## Field values that now travel together

When this layer is used, the shell should publish only six concrete fields:

1. `repeat_activation_conflict_pattern_token` — `none`, `one prior first-cycle conflict only`,
   `repeated revived and replacement disagreement`, `repeated recipient wrong-path acceptance`,
   `repeated protected route conflict`, `repeated clock conflict`, `repeated prerequisite conflict`,
   `repeated source and search split`, `repeated source and archive split`, `repeated proof-object
   mismatch`, `repeated official-record mismatch`, `repeated two-route notice`, `ordinary lag
   pattern only`, `none inherited`, or `not published`;
2. `route_pair_threshold_basis_token` — `no threshold met`, `route-native repeat threshold`, `local
   owner threshold`, `two material conflicts same route pair`, `two clock conflicts same route
   pair`, `two wrong-path portal acceptances`, `two protected-route conflicts`, `split-owner repeat
   threshold`, `recipient dependency threshold`, `archive/search repeat threshold`, `redesign-review
   threshold`, `decommission review threshold`, `none inherited`, or `not published`;
3. `route_stability_owner_token` — `replacement owner current`, `revived-route owner current`,
   `successor owner must prove stability`, `source owner must reconcile`, `provider route owner
   pending`, `recipient-of-record pending`, `official-record owner pending`, `protected or
   accommodation owner pending`, `archive or search provider state only`, `split owners must
   separate`, `local redesign owner named`, `no active owner`, `none inherited`, or `not published`;
4. `repeat_conflict_disposition_token` — `ordinary YC handling only`, `bounded activation stability
   watch`, `owner reconciliation required`, `route redesign required`, `route split retained`,
   `replacement route controls`, `revived route controls`, `dual-route recognition retained`,
   `protected local-only route retained`, `recipient confirmation path`, `decommissioned-route
   posture`, `no active route residue`, `non-material lag`, `none inherited`, or `not published`;
5. `repeat_conflict_learner_action_token` — `none current`, `wait for owner stability proof`, `use
   replacement route`, `use revived route`, `submit once with dual-route recognition`, `use more
   protective route until resolved`, `use longer current window until resolved`, `do not duplicate
   filing`, `do not refile into dead path`, `protected or sensitive local-only submission`, `manual
   local support only`, `owner-only action`, `none inherited`, or `not published`;
6. `route_stability_exit_token` — `ordinary activation restored`, `stability watch opened`, `watch
   closed after clean route-choice cycle`, `owner reconciliation closed`, `route redesign handoff`,
   `route split retained`, `replacement route decommissioned`, `revived route retired`, `no active
   route residue`, `local-only memory retained`, `minimized conflict memory`, `reopen on material
   conflict`, `reopen on owner change or route expiry`, `none inherited`, or `not published`.

That is deliberately small. It is enough to show what repeated, where it repeated, what threshold
source makes the repeat material, who owns stability work, what the learner may safely do, and how
the threshold exits learner-facing publication. It is not enough to create a standing activation
watch for every first conflict, a permanent wrong-route learner-fault rule, a public route-pair
stigma label, a cross-owner override, or a global replacement-route failure certificate.

## First repeat activation-cycle conflict / route-stability-threshold assignments

| Situation | Minimal publication | Why |
|---|---|---|
| revived route and replacement route disagree again after the first conflict closed | `repeated revived and replacement disagreement`, `two material conflicts same route pair`, current owner or `split owners must separate`, `owner reconciliation required` or `bounded activation stability watch`, and `submit once with dual-route recognition` or `use more protective route until resolved` | repetition can justify a route-pair threshold, but not learner fault or automatic replacement failure while owners still publish two official-looking paths |
| recipient portal repeatedly accepts the retired path while the source or replacement route says the new path controls | `repeated recipient wrong-path acceptance`, `recipient dependency threshold`, `recipient-of-record pending`, `recipient confirmation path`, and `do not duplicate filing` or `submit once with dual-route recognition` | repeated downstream acceptance can affect the learner's record dependency; it should be handled as owner/recipient reconciliation rather than repeated learner wrong-route risk |
| protected accommodation route repeatedly conflicts with the public replacement route | `repeated protected route conflict`, `two protected-route conflicts`, protected/accommodation owner, `protected local-only route retained`, and `protected or sensitive local-only submission` | protected routes may legitimately diverge; repetition should clarify local handling and proof limits, not expose sensitive proof in a public conflict ledger |
| revived and replacement routes repeatedly publish different clocks | `repeated clock conflict`, `two clock conflicts same route pair`, owner precedence unresolved or current owner proof, `use longer current window until resolved`, and `owner reconciliation required` | repeated clock conflict is owner-side instability; adverse clocks should not run against the learner before conflict-aware notice names the controlling route-native window |
| Google/Bing/custom search or image results repeatedly show old-route snippets after source correction and first refresh | `repeated source and search split`, `archive/search repeat threshold`, source owner plus provider state, `owner-only action` or `no learner action now`, and `ordinary YC handling only` or `bounded activation stability watch` | exact-URL search refresh can repeat without reopening all recipient obligations; the threshold belongs to the affected search result or image family |
| Wayback, mirror, screenshot, or archive copies repeatedly preserve a retired route after replacement activation | `repeated source and archive split`, `archive/search repeat threshold`, archive or platform state, `decommissioned-route posture` or `minimized conflict memory`, and `none current` unless a live dependency exists | archive persistence is time-slice specific; repeated captures may justify a local archive-proof posture without proving route-pair instability for source or recipient surfaces |
| first-cycle prerequisite proof changes, resolves, and then changes again for the same route | `repeated prerequisite conflict`, `local owner threshold` or `redesign-review threshold`, source/replacement owner, `route redesign required` or `owner reconciliation required`, and `wait for owner stability proof` | repeated prerequisite drift may show the route needs redesign or clearer publication, but prior timely learner action should remain protected unless a current route-native rule says otherwise |
| official-record or transcript field repeatedly disagrees with the current route-choice disposition | `repeated official-record mismatch`, `recipient dependency threshold` or official-record owner pending, `recipient confirmation path`, and `use more protective route until resolved` | official-record dependency can be live even when source/search/archive surfaces are settled; do not reopen every surface when the repeat is downstream-record-specific |
| repeated two-route notices are sent to learners after prior minimization | `repeated two-route notice`, `split-owner repeat threshold`, `split owners must separate`, `route split retained`, and `manual local support only` where needed | repeated ambiguous notice means one shell may be hiding two route truths; split before assigning learner action or route-fault meaning |
| repeated stale search/cache/archive signals do not affect any current learner dependency | `ordinary lag pattern only`, `no threshold met`, `archive or search provider state only`, `non-material lag`, and `none current` | not every repeated visible old copy is a route-stability problem; without owner, proof, clock, recipient, protected-route, or learner-dependency effect, keep it out of threshold handling |

## Boundary conditions

This layer should not be used when only one of the following is true:

- there has been only one first-cycle conflict and `YC0-YC4` can still resolve, split, hand back, or
  minimize it honestly;
- the current route, owner, provider, recipient, archive, or support path is still inside its own
  published review, status, reflection, or expiry window;
- the repeated signal concerns different learners, URLs, image results, providers, recipients,
  official-record fields, protected paths, owners, or route pairs and does not form one material
  pattern;
- the only repeated signal is ordinary search, cache, archive, screenshot, or mirror lag with no
  current route-choice, proof, clock, recipient, protected-route, or learner-dependency effect;
- a protected accommodation, privacy, safety, legal, records, appeal, or recipient-of-record process
  already controls repeat handling;
- prior proof was minimized or local-only and no current authority needs it to classify the present
  conflict; or
- a current route names a specific repeat-conflict, duplicate-filing, appeal, precedence, status,
  escalation, or expiry rule that should govern instead of a portable threshold.

In those cases, publish `one prior first-cycle conflict only`, `ordinary lag pattern only`, `no
threshold met`, `current route-native window applies`, `protected local-only route`, `none current`,
`no active route residue`, or `none inherited` rather than treating repeated visibility as automatic
route instability, learner fault, replacement failure, or public route-pair stigma.

## What this closes

This closes `FT-0147`.

The archive no longer stops at "first activated cycle conflict resolved". It can now publish a
minimal repeat activation-cycle conflict / route-stability threshold: what repeated, where it
repeated, what threshold basis makes the repeat material, who owns stability or reconciliation work,
what safe action the learner has now, and when threshold memory exits or narrows.

It also opens one narrower seam.

After a repeat activation-cycle conflict threshold opens a bounded route-stability watch, owner
reconciliation, route redesign, route split, retired-route posture, or no-active-route residue, the
archive may still need a tiny activation route-stability operation / deconflict-exit layer for cases
where the threshold is actively operated, repair is proven, two routes are reconciled or split, or
one path exits — without turning threshold status into permanent activation surveillance, public
route-pair stigma, or an all-surface replacement-failure certificate.
