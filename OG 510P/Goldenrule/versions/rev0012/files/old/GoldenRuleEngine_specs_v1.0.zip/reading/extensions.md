# Speculative Extensions

## Golden Rule Under Hierarchy
- How does reciprocity scale when agents differ in power or role?

## Third-Party Justice in N-Player Games
- When and how do agents punish not for personal harm but for the group?

## Soft Norms under Bounded Rationality
- How can partially coherent norms still sustain prosocial behavior?

## Meta-Rules for Rule Modifiers
- Are there good meta-norms for how agents evolve or overwrite their ethical logic?