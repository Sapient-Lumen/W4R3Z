# Research Links and Citations (v1.0)

- [Hilbe et al. 2013: Zero-determinant strategies](https://www.nature.com/articles/ncomms2193)
- [Fudenberg & Levine: Learning to Forgive](https://www.nber.org/papers/w17541)
- [Nowak et al.: Indirect Reciprocity and Image Scoring](https://www.nature.com/articles/35012260)
- [Axelrod Tournament GitHub Archive](https://github.com/Axelrod-Python/Axelrod)
- [Ethical Oracle Testing paper (Google Brain)](https://arxiv.org/abs/2305.09997)
- [Causal Confusion in RL](https://arxiv.org/abs/1811.12438)
