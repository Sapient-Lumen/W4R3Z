# Tombstone: OONI corroboration (supplementary)

**Track:** A (Deployable core)


This file is kept as a **stable alias** for older references.

The canonical doc is:

- `119-ooni-corroboration.md`

No normative content should live here.
